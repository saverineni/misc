#! /bin/bash

DIR=$(cd `dirname $0` && pwd)

MAX_RETRIES=10
retry_count=1

pushd $DIR/../e2e
docker-compose up -d

while [ $retry_count -lt $MAX_RETRIES ]
do
  sleep 1
  printf '.'
  API_STATUS=$(curl --output /dev/null -w '%{http_code}' --silent http://localhost:9080/api/health)
  if [[ $API_STATUS -eq 200 ]]; then
    exit 0 
  else
    ((retry_count++))
  fi
done

exit 1
