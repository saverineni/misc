import { UserDetails } from "./user-details.po";
import { SignInPage } from "./sign-in.po";
import { Wiremock } from "./wiremock";

describe('user details', () => {
  let userDetails: UserDetails;
  let signInPage: SignInPage;

  beforeEach((done) => {
    userDetails = new UserDetails();
    signInPage = new SignInPage();
    Wiremock.reset().then(done);
  });

  describe('signed in', () => {
    beforeEach((done) => {
      signInPage.givenUserIsSignedIn().then(done, done);
    });

    it("should display the user's pid", () => {
      expect(userDetails.getPid()).toEqual(SignInPage.DEFAULT_PID);
    });

    describe('sign out', () => {
      beforeEach((done) => {
        expect(userDetails.isDisplayed()).toBe(true);

        userDetails.signOut().then(done, done);
      });

      it('should route to the sign in page', () => {
        expect(signInPage.isCurrentPage()).toBe(true);
      })

      it('user details should not be displayed', () => {
        expect(userDetails.isDisplayed()).toBeFalsy();
      });
    });
  });
});
