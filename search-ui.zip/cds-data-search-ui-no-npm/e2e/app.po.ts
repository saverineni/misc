import { browser, by, element } from 'protractor';

export class AppPage {
  navigateTo() {
    return browser.get('/');
  }

  pageHeading() {
    return element(by.css('app-root h1')).getText();
  }

  navbarLabels() {
    return element.all(by.css('.nav__item-label')).map(item => item.getText());
  }

  getOperationError() {
    return element(by.css('.operation-error')).getText();
  }
}
