import { AppPage } from './app.po';

describe('cds-data-search-ui App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should have the correct title', () => {
    page.navigateTo();
    expect(page.pageHeading()).toEqual('Customs Declaration Search');
  });

  it('should have nav bar with a home label', () => {
    page.navigateTo();
    expect(page.navbarLabels()).toEqual(['Customs Declaration Search']);
  });
});
