import { DeclarationRow } from './DeclarationRow';

type FieldDefinition = { viewField: string; value: any; };
type DeclarationFieldDefinitions = (declaration: any) => FieldDefinition[];

const headerFields: DeclarationFieldDefinitions = declaration => [
    { viewField: 'entryReference', value: declaration.entry_reference },
    { viewField: 'epuNumber', value: declaration.epu_number },
    { viewField: 'entryNumber', value: declaration.entry_number },
    { viewField: 'entryDate', value: declaration.entry_date },
    { viewField: 'goodsLocation', value: declaration.goods_location },
    { viewField: 'modeOfTransport', value: declaration.transport_mode_code },
    { viewField: 'route', value: declaration.route },
    { viewField: 'dispatchCountry', value: declaration.dispatch_country },
    { viewField: 'destinationCountry', value: declaration.destination_country_name },
    { viewField: 'consignee', value:
        declaration.importer_trader_turn + '\n' +
        declaration.consignee_nad_name + '\n' +
        declaration.consignee_nad_postcode
    },
    {
      viewField: 'consignor', value:
        declaration.consignor_trader_turn + '\n' +
        declaration.consignor_nad_name + '\n' +
        declaration.consignor_nad_postcode
    }
];

const lineFields: DeclarationFieldDefinitions = declarationLine => [
    { viewField:'entryNumber', value: declarationLine.entry_number },
    { viewField:'entryDate', value: declarationLine.entry_date },
    { viewField:'route', value: declarationLine.route },
    { viewField:'dispatchCountry', value: declarationLine.dispatch_country },
    { viewField:'destinationCountry', value: declarationLine.destination_country },
    { viewField:'clearanceDate', value: declarationLine.clearance_datetime },
    { viewField:'cpc', value: declarationLine.customs_procedure_code },
    { viewField:'originCountry', value: declarationLine.origin_country.country_name },
    { viewField:'commodityCode', value: declarationLine.commodity.commodity_code },
    {
      viewField:'consignee',
      value: declarationLine.importer_trader_turn + '\n' +
        declarationLine.item_consignee_nad_name + '\n' +
        declarationLine.item_consignee_nad_postcode
    },
    {
      viewField:'consignor',
      value: declarationLine.item_consignor_trader_turn + '\n' +
        declarationLine.item_consignor_nad_name + '\n' +
        declarationLine.item_consignor_nad_postcode
    }
  ];

function newResult(): jasmine.CustomMatcherResult {
    return {
        pass: false,
        message: ''
    }
};

const removeNullsAndNewLines = value => value.replace(/null(\s)?/mg, '').trim();

function compareFields(fieldDefinitions: DeclarationFieldDefinitions) {
    return (util, customEqualityTesters) => {
        const isEqual = (a, b) => util.equals(a, b, customEqualityTesters);
        return {
            compare: (actual: any, expected: any): jasmine.CustomMatcherResult => {
                if (expected === undefined) {
                    expected = {};
                }

                const result = newResult();

                if (actual === undefined) {
                    result.message = `Could not check actual element as it was undefined`;
                } else {
                    result.pass = Promise.all(
                        fieldDefinitions(expected).map(field =>
                            actual.fieldTextOf(field.viewField)
                                .then(value => {
                                    const expectedValue = removeNullsAndNewLines(field.value);
                                    if (isEqual(value, expectedValue)) {
                                        return true;
                                    } else {
                                        result.message += `Expected ${field.viewField} field to be ${expectedValue} but was ${value}\n`;
                                        return false;
                                    }
                                })
                            )
                        )
                        .then(
                            values => values.every(isEqual => isEqual),
                            () => false
                        ) as any;
                }

                return result;
            }
        }
    }
}

const declarationMatchers: jasmine.CustomMatcherFactories = {
    "isHeaderRowWithData": compareFields(headerFields),
    "isDeclarationLineWithData": compareFields(lineFields)
};

export { declarationMatchers };
