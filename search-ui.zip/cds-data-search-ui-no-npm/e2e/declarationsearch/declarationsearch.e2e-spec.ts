/// <reference path="./declarationMatchers.d.ts"/>

import { DeclarationSearchPage } from './declarationsearch.po';
import { declarationMatchers } from './declarationMatchers';
import { Wiremock } from '../wiremock';
import { browser } from 'protractor';
import { AppPage } from '../app.po';
import { SignInPage } from '../sign-in.po';
import { UserDetails } from '../user-details.po';
const fs = require('fs');

const fetch = require('node-fetch');

describe('Declaration search', () => {
  let signInPage: SignInPage;
  let searchPage: DeclarationSearchPage;

  beforeAll((done) => {
    signInPage = new SignInPage();
    signInPage.givenUserIsSignedIn()
      .then(done, done.fail);
  });

  beforeEach((done) => {
    Wiremock.reset().then(done, done.fail);

    searchPage = new DeclarationSearchPage();
    searchPage.navigateTo();
  });

  it('should be the current page', () => {
    expect(searchPage.isCurrentPage()).toBeTruthy();
  });

  it('the page title should be set', () => {
    expect(browser.getTitle()).toEqual("Customs Declaration Search");
  });

  describe('perform search', () => {
    describe('no matching declaration found', () => {
      it('display no results found message', (done) => {
        whenISearchFor(searchPage, 'made up')
          .then(() => expect(searchPage.isNoResultsFound()).toEqual(true))
          .then(done, done.fail);
      });
    });

    describe('declaration found', () => {
      const DECLARATION_FILE_NAME = 'declaration-id-found-response-body.json';

      let declaration;
      let declarationId;

      beforeEach((done) => {
        declaration = JSON.parse(fs.readFileSync(`e2e/wiremock/__files/${DECLARATION_FILE_NAME}`));
        declarationId = declaration.header.entry_reference;
        stubAuthenticatedDeclarationWithId(declarationId)
          .then(() => whenISearchFor(searchPage, declarationId))
          .then(done, done.fail);

        jasmine.addMatchers(declarationMatchers)
      });

      it('displays declaration if found', () => {
        expect(searchPage.isResultsDisplayed()).toEqual(true);
        expect(searchPage.getDeclarationRow(0)).isHeaderRowWithData(declaration.header);
      });

      it('displays declaration lines on clicking the header row', (done) => {
        whenIClickOnAHeaderRow(searchPage)
          .then(() => expect(searchPage.getDeclarationRow(0).lineCount()).toEqual(4))
          .then(done, done.fail);
      });

      it('displays declaration line populated with expected data', (done) => {
        whenIClickOnAHeaderRow(searchPage)
          .then(() => expect(searchPage.getDeclarationRow(0).line(0)).isDeclarationLineWithData(declaration.lines[0]))
          .then(done, done.fail);
      });

      function stubAuthenticatedDeclarationWithId(declarationId: string) {
        return Wiremock.stubRequest({
            "priority": 1,
            "request": {
              "method": "GET",
              "url": "/api/declaration?declarationId=" + declarationId,
              "headers": {
                "Authorization": {
                  "equalTo": "Bearer " + SignInPage.DEFAULT_AUTH_TOKEN
                }
              }
            },
            "response": {
              "status": 200,
              "bodyFileName": DECLARATION_FILE_NAME
            }
          });
      }
    });

    describe('server errors', () => {
      beforeEach((done) => {
        Wiremock.reset()
          .then(() => Wiremock.givenSearchServiceIsOffline())
          .then(done, done.fail);
      });

      it('displays global error message', (done) => {
        whenISearchFor(searchPage, 'made up')
          .then(() => expect(new AppPage().getOperationError()).toEqual('Server error. Please contact support if this problem persists.\nOK'))
          .then(done, done.fail);
      });

      it('does not display search results', (done) => {
        whenISearchFor(searchPage, 'made up')
          .then(() => expect(searchPage.isNoResultsFound()).toEqual(false))
          .then(done, done.fail);
      });
    });
  });

  describe('Declaration search when not signed in', () => {
    let userDetails: UserDetails;
    beforeEach((done) => {
      userDetails = new UserDetails();
      userDetails.signOut()
        .then(searchPage.navigateTo)
        .then(done, done.fail);
    });

    it('should redirect you to the sign in page', () => {
      expect(signInPage.isCurrentPage()).toBe(true);
    });
  });
});

function whenISearchFor(page: DeclarationSearchPage, declarationId: string) {
  return page.search(declarationId);
}

function whenIClickOnAHeaderRow(page: DeclarationSearchPage) {
  return page.clickHeaderRow();
}


