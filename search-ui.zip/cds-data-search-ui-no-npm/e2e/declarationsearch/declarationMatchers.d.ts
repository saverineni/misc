declare namespace jasmine {
    interface Matchers<T> {
        isHeaderRowWithData(expected: object): boolean;
        isDeclarationLineWithData(expected: object): boolean;
    }
}