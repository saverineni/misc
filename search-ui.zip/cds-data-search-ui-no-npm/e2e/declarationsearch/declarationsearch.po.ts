import { browser, by, element } from 'protractor';
import { DeclarationRow } from './DeclarationRow';

export class DeclarationSearchPage {
  navigateTo() {
    return browser.get('/');
  }

  isCurrentPage() {
    return element(by.css('.search-section')).isPresent();
  }

  search(freeText: string) {
    element(by.css('.search-form__freetext-input')).sendKeys(freeText);
    return element(by.css(".search-form__button")).click();
  }

  clickHeaderRow() {
    return element(by.css('.search-results-table__declaration-header-row')).click();
  }

  isNoResultsFound() {
    return element(by.css('.no-search-results')).isPresent();
  }

  isResultsDisplayed() {
    return element(by.css('.search-results-table')).isPresent();
  }

  getDeclarationRow(row: number): DeclarationRow {
    return new DeclarationRow(element.all(by.css('.search-results-table__declaration-header-row')).get(row));
  }
}
