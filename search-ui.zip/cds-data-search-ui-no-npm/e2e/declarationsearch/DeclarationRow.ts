import { ElementFinder, by, element } from 'protractor';

export class DeclarationRow {
    constructor(private rowElement: ElementFinder) { }

    fieldTextOf(fieldName: string) {
        return this.rowElement.element(by.css(`.search-results-table__${fieldName}`)).getText();
    }

    line(index: number) {
        return this.lines().then(lines => new DeclarationLine(lines[index]));
    }

    lineCount() {
        return this.lines().then(lines => lines.length);
    }

    private lines() {
        return this.fieldTextOf('entryReference')
            .then(declarationId => element.all(by.css(`[data-dec-id="${declarationId}"] .declaration-lines__row`)));
    }
}

export class DeclarationLine {
    constructor(private lineElement: ElementFinder) { }

    fieldTextOf(fieldName: string) {
        return this.lineElement.element(by.css(`.declaration-lines__${fieldName}`)).getText();
    }
}
