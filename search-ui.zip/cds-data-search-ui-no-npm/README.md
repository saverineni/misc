# CdsDataSearchUi

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.6.4.

## Running the project

To build and run the project, first start docker compose, this will create and run a container with the settings required to build the project:

`docker-compose up` or `docker-compose up -d` to run in a daemon

In another tab (or the same if you ran as a daemon) run `docker-compose exec ng sh` to connect to the container. From here, you can run the development server. See commands below

## Development server (run in angular-cli on front end container)

`npm install` - installs dependencies via node package manager.
`npm start` - command to serve the web app, defaults to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.
`npm test` - executes the unit tests via [Karma](https://karma-runner.github.io)
`npm run e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Utility Scripts (run on host machine)

`angular-cli.sh` - will execute the docker-compose commands above and launch straight into the angular-cli within the container.
`pre-checkin-checks.sh` - builds, runs unit tests, and runs e2e tests in turn, producing a pass/fail result.
`build-scripts/start-app-dev.sh` - launches nginx and wiremock containers to provide stubbed responses to api calls, allowing front end testing without requiring the back end running. If this fails try running `pre-checkin-checks.sh` first.
`build-scripts/stop-app-dev.sh` - stops the nginx and wiremock containers.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
