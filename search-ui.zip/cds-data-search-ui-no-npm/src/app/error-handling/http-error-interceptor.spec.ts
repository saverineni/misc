import {Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import {HttpErrorInterceptor} from './http-error-interceptor';
import {OperationErrorNotifier} from './operation-error-notifier';
import {HttpErrorResponse, HttpHandler, HttpRequest} from '@angular/common/http';

describe('HttpErrorInterceptor', () => {
    let interceptor: HttpErrorInterceptor;
    let errorNotifier: OperationErrorNotifier;
    let req: HttpRequest<any>;
    let next: HttpHandler;
    let httpEvent: Observable<any>;

    beforeEach(() => {
        httpEvent = { catch: err => null } as Observable<any>;
        req = {} as HttpRequest<any>;
        next = { handle: req => httpEvent } as HttpHandler;
        spyOn(next, 'handle').and.callThrough();

        errorNotifier = { notifyUser(message) { } } as OperationErrorNotifier;
        spyOn(errorNotifier, 'notifyUser');

        interceptor = new HttpErrorInterceptor(errorNotifier);
    });

    function givenErrorResponseWithStatus(statusCode: number) {
        const err = new HttpErrorResponse({ status: statusCode });
        spyOn(httpEvent, 'catch').and.callFake(handler => handler(err));
    }

    function itReturnsErrorObservable() {
        it('returns error observable', (done) => {
            interceptor.intercept(req, next).subscribe(
                success => done.fail('expected error'),
                error => done()
            );
        });
    };

    describe('intercept connection errors', () => {
        beforeEach(() => {
            const err = new HttpErrorResponse({ status: 0 });
            spyOn(httpEvent, 'catch').and.callFake(handler => handler(err));
        });

        it('notifies user', () => {
            interceptor.intercept(req, next);
            expect(errorNotifier.notifyUser).toHaveBeenCalledWith('Connection error');
        });

        itReturnsErrorObservable();

    });

    [500, 502, 503, 504].forEach(statusCode => {
        describe('intercept ${statusCode} server error', () => {
            beforeEach(() => {
                givenErrorResponseWithStatus(statusCode);
            });

            it('notifies user', () => {
                interceptor.intercept(req, next);
                expect(errorNotifier.notifyUser).toHaveBeenCalledWith('Server error');
            });

            itReturnsErrorObservable();
        });
    });

    [400, 401, 403, 404, 405].forEach(statusCode => {
        describe('intercept ${statusCode} client error', () => {
            beforeEach(() => {
                givenErrorResponseWithStatus(statusCode);
            });

            it('does not notifies user', () => {
                interceptor.intercept(req, next);
                expect(errorNotifier.notifyUser).not.toHaveBeenCalled();
            });

            itReturnsErrorObservable();
        });
    });
});
