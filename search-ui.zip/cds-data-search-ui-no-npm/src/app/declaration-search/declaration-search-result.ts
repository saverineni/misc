import { DeclarationSearch } from "./declaration-search";
import { Declaration } from "./declaration";

export class DeclarationSearchResult {
    declarations: Array<Declaration> = [];
}
