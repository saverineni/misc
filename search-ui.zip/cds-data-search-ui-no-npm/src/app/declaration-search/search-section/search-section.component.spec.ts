import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { SearchSectionComponent } from './search-section.component';
import { Directive, EventEmitter, Output, Input } from '@angular/core';
import { SearchService } from '../search.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { DeclarationSearch } from '../declaration-search';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DeclarationSearchResult } from '../declaration-search-result';

@Directive({
  selector: 'cds-search-form'
})
export class SearchFormStub {
  @Output() submitSearch = new EventEmitter<DeclarationSearch>();
}

@Directive({
  selector: 'cds-search-results'
})
export class SearchResultsStub {
  @Input() result;
}

describe('SearchPageComponent', () => {
  let component: SearchSectionComponent;
  let fixture: ComponentFixture<SearchSectionComponent>;

  function nullSafeDirective(debugElement, clazz) {
    const childDebugElement = debugElement.query(By.directive(clazz));
    if (childDebugElement == null) {
      return null;
    }
    return childDebugElement.injector.get(clazz);
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SearchSectionComponent, SearchFormStub, SearchResultsStub],
      providers: [SearchService],
      imports: [HttpClientTestingModule]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('declaration search section', () => {
    let section;
    beforeEach(async(() => {
      section = fixture.debugElement.query(By.css('.search-section'));
    }));

    it('should be displayed', () => {
      expect(section).toBeTruthy();
    });

    it('should have a heading', () => {
      const heading = section.query(By.css('h1')).nativeElement;
      expect(heading.innerText).toEqual('Customs Declaration Search');
    });

    describe('search form', () => {
      it('should have a search form', () => {
        const searchForm = section.query(By.directive(SearchFormStub));
        expect(searchForm).toBeTruthy();
      });

      it('should perform search on form submission', () => {
        const expected = new DeclarationSearchResult();
        const searchService = fixture.debugElement.injector.get(SearchService);
        const searchServiceSpy = spyOn(searchService, 'search').and.returnValue(Observable.of(expected));

        const searchForm = section.query(By.directive(SearchFormStub));
        const searchFormDirective = searchForm.injector.get(SearchFormStub);

        searchFormDirective.submitSearch.emit(new DeclarationSearch('free text'));

        expect(component.result).toBe(expected);
      });
    });

    describe('search results', () => {
      it('should not include search results on page load', () => {
        const searchResults = section.query(By.directive(SearchResultsStub));
        expect(searchResults != null).toBeFalsy();
      });

      it('should include search results after search', () => {
        component.result = new DeclarationSearchResult();
        fixture.detectChanges();

        const searchResults = section.query(By.directive(SearchResultsStub));
        const searchResultsDirective = searchResults.injector.get(SearchResultsStub);

        expect(searchResultsDirective.result).toEqual(component.result);
      });

    });
  });
});

