import { Component, OnInit } from '@angular/core';
import { DeclarationSearch } from '../declaration-search';
import { SearchService } from '../search.service';
import { DeclarationSearchResult } from '../declaration-search-result';

@Component({
  selector: 'cds-search-section',
  templateUrl: './search-section.component.html',
  styleUrls: ['./search-section.component.scss']
})
export class SearchSectionComponent {

  result: DeclarationSearchResult = null;

  constructor(private searchService: SearchService) { }

  onSearch(search: DeclarationSearch) {
    this.searchService.search(search).subscribe(result => {
      this.result = result;
    });
  }

}
