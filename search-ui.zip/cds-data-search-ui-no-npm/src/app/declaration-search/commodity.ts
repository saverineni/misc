export class Commodity {
    commodity_code: string;
}
