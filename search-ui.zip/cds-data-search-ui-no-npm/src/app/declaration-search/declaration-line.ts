import { Country } from './country';
import { Commodity } from './commodity';

export class DeclarationLine {
    entry_number: string;
    entry_date: string;
    route: string;
    dispatch_country: string;
    destination_country: string;
    clearance_datetime: string;
    customs_procedure_code: string;
    origin_country: Country;
    commodity: Commodity;
    importer_trader_turn: string;
    item_consignee_nad_name: string;
    item_consignee_nad_postcode: string;
    item_consignor_trader_turn: string;
    item_consignor_nad_name: string;
    item_consignor_nad_postcode: string;
}
