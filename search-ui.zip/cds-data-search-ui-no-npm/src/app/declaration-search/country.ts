export class Country {
    country_name: string;
}
