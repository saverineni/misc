import { Component, Input, ViewChild, TemplateRef } from '@angular/core';
import { Declaration } from '../../declaration';
import { DataSource } from '@angular/cdk/table';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { DeclarationLine } from '../../declaration-line';
import { Trader } from '../../trader';

@Component({
  selector: 'cds-declaration-lines',
  templateUrl: './declaration-lines.component.html',
  styleUrls: ['./declaration-lines.component.scss']
})
export class DeclarationLinesComponent {

  @ViewChild("entryNumber") entryNumber: TemplateRef<any>;
  @ViewChild("entryDate") entryDate: TemplateRef<any>;
  @ViewChild("route") route: TemplateRef<any>;
  @ViewChild("dispatchCountry") dispatchCountry: TemplateRef<any>;
  @ViewChild("destinationCountry") destinationCountry: TemplateRef<any>;
  @ViewChild("clearanceDate") clearanceDate: TemplateRef<any>;
  @ViewChild("cpc") cpc: TemplateRef<any>;
  @ViewChild("originCountry") originCountry: TemplateRef<any>;
  @ViewChild("commodityCode") commodityCode: TemplateRef<any>;
  @ViewChild("consignee") consignee: TemplateRef<any>;
  @ViewChild("consignor") consignor: TemplateRef<any>;

  @Input() declaration: Declaration;

  declarationLineColumns = [
    { id: 'entryNumber', label: 'Entry Number' },
    { id: 'entryDate', label: 'Entry Date' },
    { id: 'route', label: 'Route of Entry' },
    { id: 'dispatchCountry', label: 'Country of Dispatch' },
    { id: 'destinationCountry', label: 'Country of Destination' },
    { id: 'clearanceDate', label: 'Clearance Date' },
    { id: 'cpc', label: 'CPC' },
    { id: 'originCountry', label: 'Country of Origin' },
    { id: 'commodityCode', label: 'Commodity Code' },
    { id: 'consignee', label: 'Consignee' },
    { id: 'consignor', label: 'Consignor' }
  ];

  declarationLineColumnRefs = this.declarationLineColumns.map(column => column.id);

  ngAfterContentInit() {
    this.declarationLineColumns.forEach(column => column['template'] = this[column.id]);
  }

  dataSource() {
    return new DeclarationLineDataSource(this.declaration);
  }
}

class DeclarationLineDataSource extends DataSource<any> {
  constructor(private declaration: Declaration) {
    super();
  }

  connect(): Observable<DeclarationLine[]> {
    return of(this.declaration.lines.map( line => this.decorate(line)));
  }

  decorate(line: DeclarationLine): DeclarationLine {
    line['consignee'] = this.consigneeFrom(line);
    line['consignor'] = this.consignorFrom(line);
    return line;
  }

  consigneeFrom(line: DeclarationLine): Trader {
    return {
      number: line.importer_trader_turn,
      name: line.item_consignee_nad_name,
      postcode: line.item_consignee_nad_postcode
    };
  }

  consignorFrom(line: DeclarationLine): Trader {
    return {
      number: line.item_consignor_trader_turn,
      name: line.item_consignor_nad_name,
      postcode: line.item_consignor_nad_postcode
    };
  }

  disconnect() { }

}
