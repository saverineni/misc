export class DeclarationSearch {
    constructor(public freeText:string) {}
}
