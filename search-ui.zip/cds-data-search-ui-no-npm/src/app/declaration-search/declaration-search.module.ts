import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchSectionComponent } from './search-section/search-section.component';
import { SearchFormComponent } from './search-form/search-form.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { SearchService } from './search.service';
import { HttpClientModule } from '@angular/common/http';
import { SearchResultsComponent } from './search-results/search-results.component';
import { DeclarationLinesComponent } from './search-results/declaration-lines/declaration-lines.component';
import { TraderComponent } from './search-results/trader/trader.component';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    MatButtonModule,
    MatInputModule,
    MatTableModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule
  ],
  declarations: [SearchSectionComponent, SearchFormComponent, SearchResultsComponent, DeclarationLinesComponent, TraderComponent],
  exports: [SearchSectionComponent],
  providers: [SearchService]
})
export class DeclarationSearchModule { }
