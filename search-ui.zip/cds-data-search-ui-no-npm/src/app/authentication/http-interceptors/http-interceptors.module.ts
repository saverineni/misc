import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

import { RequestInterceptor } from './request-interceptor';

@NgModule({
  imports: [
    CommonModule
  ],
  providers: [],
  declarations: []
})
export class HttpInterceptorsModule {

  static forRoot(): ModuleWithProviders {
    return  {
      ngModule: HttpInterceptorsModule,
      providers: [
        { provide: HTTP_INTERCEPTORS, useClass: RequestInterceptor, multi: true }
      ]
    };
  }
}
