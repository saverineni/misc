import {Injectable} from "@angular/core";
import {HttpEvent, HttpHandler, HttpInterceptor, HttpRequest} from "@angular/common/http";
import {Observable} from "rxjs/Observable";
import {CacheService} from "../cache.service";

@Injectable()
export class RequestInterceptor implements HttpInterceptor{

  constructor(private cacheService: CacheService) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    const authenticationRequest = (req.url != "/api/authentication/token") ? req.clone({
      setHeaders: {
        Authorization : `Bearer ${this.cacheService.getToken()}`
      }
    }) : req;

    return next.handle(authenticationRequest);

  }
}
