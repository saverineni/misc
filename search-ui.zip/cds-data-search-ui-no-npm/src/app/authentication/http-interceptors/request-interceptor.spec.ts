import {HttpHandler, HttpRequest} from "@angular/common/http";
import {RequestInterceptor} from "./request-interceptor";
import {CacheService} from "../cache.service";


describe('RequestInterceptor will', () => {
  let cacheService: CacheService;
  let requestInterceptor: RequestInterceptor;

  let request: HttpRequest<any>;
  let cloneReq: HttpRequest<any>;

  let next: HttpHandler;
  let spyHandler: jasmine.Spy;

  beforeEach(() => {
    cacheService = {
      getToken() {
        return 'token'
      }
    } as CacheService;

    next = { handle: request => {}} as HttpHandler;

    spyHandler = spyOn(next, 'handle');
    requestInterceptor = new RequestInterceptor(cacheService);
  });


  it('not add token to the header if url is /authentication/token', () => {
    request = {
      url : '/api/authentication/token'
    } as HttpRequest<any>;

    requestInterceptor.intercept(request, next)
    expect(spyHandler).toHaveBeenCalledWith(request);
  });


  it('add token to the header if url is NOT /authentication/token', () => {
    request = {
      url : '/',
      clone() {
        return cloneReq
      }
    } as HttpRequest<any>;

    cloneReq = {
      url: '/'
     } as HttpRequest<any>;


    spyOn(request, 'clone').and.callThrough();
    requestInterceptor.intercept(request, next)

    expect(spyHandler).toHaveBeenCalledWith(cloneReq);
    expect(request.clone).toHaveBeenCalledWith({
      setHeaders: {
        Authorization : 'Bearer token'
      }
    })
  });

});

