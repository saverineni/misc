import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { SignInComponent } from './sign-in.component';

import { FlexLayoutModule } from '@angular/flex-layout';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DebugElement, ErrorHandler } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { AuthenticationResult } from '../authentication-result';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { RouterTestingModule } from "@angular/router/testing";
import { Router } from "@angular/router";
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';

class MockAuthenticationService {
  signIn(pid: string, password: string) { }
}

class MyErrorHandler implements ErrorHandler {
  readonly errors = [];

  handleError(error) {
    this.errors.push(error);
  }

}
describe('SignInComponent', () => {
  let component: SignInComponent;
  let fixture: ComponentFixture<SignInComponent>;
  let authenticationService: AuthenticationService;
  let authenticationServiceSpy: jasmine.Spy;
  let errorHandler;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SignInComponent],
      imports: [
        FlexLayoutModule,
        MatButtonModule,
        MatInputModule,
        BrowserAnimationsModule,
        FormsModule,
        RouterTestingModule.withRoutes([]),
      ],
      providers: [
        { provide: AuthenticationService, useClass: MockAuthenticationService },
        { provide: ErrorHandler, useClass: MyErrorHandler }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    authenticationService = TestBed.get(AuthenticationService);
    authenticationServiceSpy = spyOn(authenticationService, 'signIn');
    authenticationServiceSpy.and.returnValue(Observable.of({}));

    fixture = TestBed.createComponent(SignInComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    errorHandler = TestBed.get(ErrorHandler);
  });

  describe('sign in form', () => {
    let form: DebugElement;
    let pidInput: DebugElement;
    let passwordInput: DebugElement;
    let signInFormButton: DebugElement;
    const getErrorMessageElement = () => fixture.debugElement.query(By.css('.sign-in-form__error-message'));

    beforeEach(async(() => {
      form = fixture.debugElement.query(By.css('.sign-in-form'));
      pidInput = form.query(By.css('.sign-in-form__pid-input'));
      passwordInput = form.query(By.css('.sign-in-form__password-input'));
      signInFormButton = form.query(By.css('.sign-in-form__button'));

      fixture.detectChanges();
    }));

    it('should be displayed', () => {
      expect(form).toBeTruthy();
    });

    it('should have a username field', () => {
      expect(pidInput).toBeTruthy();
    });

    it('should have a password field', () => {
      expect(passwordInput).toBeTruthy();
    });

    it('should have a button', () => {
      expect(signInFormButton).toBeTruthy();
    });

    it('should not display error section', () => {
      expect(getErrorMessageElement() == null).toBeTruthy()
    });

    describe('sign in credentials', () => {
      describe('entered', () => {
        const pid: any = 'pid';
        const password: any = 'password';

        beforeEach(() => {
          pidInput.nativeElement.value = pid;
          passwordInput.nativeElement.value = password;
        });

        it('should be submitted for authentication on button click', () => {
          signInFormButton.nativeElement.click();

          expect(authenticationService.signIn).toHaveBeenCalledWith(pid, password);
        });

        it('should be submitted for authentication on form submit', () => {
          form.nativeElement.dispatchEvent(new Event('submit'));

          expect(authenticationService.signIn).toHaveBeenCalledWith(pid, password);
        });

        describe('authentication fails', () => {
          beforeEach(() => {
            authenticationServiceSpy.and.returnValue(Observable.of(new AuthenticationResult(false)));
            form.nativeElement.dispatchEvent(new Event('submit'));
          });

          it('should display error message', () => {
            fixture.detectChanges();
            expect(getErrorMessageElement().nativeElement.innerText).toBe('You have entered invalid credentials');
          });
        });

        describe('authentication success', () => {
          let routerNavigateByUrlSpy;
          beforeEach(() => {
            authenticationServiceSpy.and.returnValue(Observable.of(new AuthenticationResult(true)));
            routerNavigateByUrlSpy = spyOn(TestBed.get(Router), 'navigateByUrl');
            form.nativeElement.dispatchEvent(new Event('submit'));
          });

          it('should invoke router', () => {
            expect(routerNavigateByUrlSpy).toHaveBeenCalledWith('');
          });
        });

        describe('unexpected error', () => {
          beforeEach(() => {
            authenticationServiceSpy.and.returnValue(new ErrorObservable('unexpected error'));
            form.nativeElement.dispatchEvent(new Event('submit'));
          });

          it('should not display a form error', () => {
            fixture.detectChanges();
            expect(getErrorMessageElement() === null).toBe(true);
          });

          it('bubble up the exception', () => {
            fixture.detectChanges();
            expect(errorHandler.errors.length).toEqual(1);
          });
        });
      });

      describe('missing', () => {
        it('should disable the submit button', () => {
          fixture.detectChanges();

          expect(signInFormButton.nativeElement.disabled).toBe(true);
        });

        it('should not be submitted on form submit', () => {
          form.nativeElement.dispatchEvent(new Event('submit'));

          expect(authenticationService.signIn).not.toHaveBeenCalled;
        });
      });
    });
  });
});
