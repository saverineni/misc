import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { Router } from "@angular/router";
import { catchError } from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'cds-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.scss']
})
export class SignInComponent {

  private unauthorised: boolean = false;

  constructor(private authenticationService: AuthenticationService, private router: Router) { }

  signIn(pid: string, password: string) {
    this.authenticationService
      .signIn(pid, password)
      .subscribe(authenticationResult => {
        if (authenticationResult.authorised) {
          this.router.navigateByUrl('');
        } else {
          this.unauthorised = true;
        }
      });
  }

  isUnauthorised() {
    return this.unauthorised;
  }
}
