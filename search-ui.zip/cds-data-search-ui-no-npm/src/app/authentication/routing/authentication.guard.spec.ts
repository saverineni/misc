import { TestBed, async, inject } from '@angular/core/testing';

import { AuthenticationGuard } from './authentication.guard';
import { AuthenticationService } from '../authentication.service';
import { Router } from '@angular/router';

describe('AuthenticationGuard', () => {
  let guard: AuthenticationGuard;
  let authenticationService: AuthenticationService;
  let router: Router;

  beforeEach(() => {
    authenticationService = {
      isAuthenticated: () => true
    } as AuthenticationService;

    router = {
      navigateByUrl: url => {}
    } as Router;

    guard = new AuthenticationGuard(authenticationService, router);
    spyOn(router, 'navigateByUrl');
  });

  describe('authenticated', () => {
    it('can activate should return true',() => {
      expect(guard.canActivate(null, null)).toBe(true);
    });

    it('should not do any navigation',() => {
      expect(router.navigateByUrl).not.toHaveBeenCalled();
    });
  });

  describe('not authenticated',  () => {
    beforeEach(() => {
      spyOn(authenticationService, 'isAuthenticated').and.returnValue(false);
    });

    it('can activate should return false',() => {
      expect(guard.canActivate(null, null)).toBe(false);
    });

    it('should route to the sign in page', () => {
      guard.canActivate(null, null);

      expect(router.navigateByUrl).toHaveBeenCalledWith('signin');
    });
  });
});
