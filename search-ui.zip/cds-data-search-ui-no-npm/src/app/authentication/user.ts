
export class User {
    constructor(readonly pid: string) {}
}