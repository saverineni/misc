import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserDetailsComponent } from './user-details.component';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core/src/debug/debug_node';
import { UserService } from '../user.service';
import { User } from '../user';
import { AuthenticationService } from '../authentication.service';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';

describe('UserDetailsComponent', () => {
  let component: UserDetailsComponent;
  let fixture: ComponentFixture<UserDetailsComponent>;

  beforeEach(async(() => {
    let testUserService = {
      isSignedIn: () => false,
      getUser: (): User => null
    } as UserService;

    let testAuthenticationService = {
      signOut: () => {}
    } as AuthenticationService;

    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes([]),
      ],
      declarations: [ UserDetailsComponent ],
      providers: [
        { provide: UserService, useValue: testUserService },
        { provide: AuthenticationService, useValue: testAuthenticationService }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('user is not signed in', () => {
    it('should not display the user details', () => {
      const userDetails: DebugElement = fixture.debugElement.query(By.css('.user-details'));

      expect(userDetails == null).toBeTruthy();
    });
  });

  describe('user signed in', () => {
    const pid = 'the-pid';
    const user = new User(pid);

    beforeEach(() => {
      const userService = TestBed.get(UserService);
      spyOn(userService, 'isSignedIn').and.returnValue(true);
      spyOn(userService, 'getUser').and.returnValue(user);
      fixture.detectChanges();
    });

    it('should display the user details', () => {
      const userDetails: DebugElement = fixture.debugElement.query(By.css('.user-details'));
      expect(userDetails != null).toBeTruthy();
    });

    it("should display the user's pid", () => {
      const pidElement: HTMLElement = fixture.debugElement.query(By.css('.user-details__pid')).nativeElement;
      expect(pidElement.textContent).toEqual(pid);
    });

    describe('sign out', () => {
      let authenticationService;
      let signOutLink;

      beforeEach(() => {
        authenticationService = TestBed.get(AuthenticationService);
        spyOn(authenticationService, 'signOut');
        signOutLink = fixture.debugElement.query(By.css('.user-details__sign-out'));
      });

      it('should display the sign out link', () => {
        expect(signOutLink != null).toBeTruthy();
      });

      describe('click', () => {
        let routerNavigateByUrlSpy;

        beforeEach(() => {
          routerNavigateByUrlSpy = spyOn(TestBed.get(Router), 'navigateByUrl');
          signOutLink.nativeElement.click();
        });

        it('should signOut with the authentication service on click', () => {
          expect(authenticationService.signOut).toHaveBeenCalled();
        });

        it('should route to the sign in page', () => {
          expect(routerNavigateByUrlSpy).toHaveBeenCalledWith('signin');
        });
      });
    });
  });
});
