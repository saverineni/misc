import { Component } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../user';
import { AuthenticationService } from '../authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'cds-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.scss']
})
export class UserDetailsComponent {

  constructor(
    private userService: UserService,
    private authenticationService: AuthenticationService,
    private router: Router
  ) {}

  isSignedIn() {
    return this.userService.isSignedIn();
  }

  user(): User {
    return this.userService.getUser();
  }

  signOut() {
    this.authenticationService.signOut();
    this.router.navigateByUrl('signin');
  }
}
