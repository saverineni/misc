import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SearchSectionComponent } from './declaration-search/search-section/search-section.component';
import { AuthenticationGuard } from './authentication/routing/authentication.guard';

const routes: Routes = [
  {
    path: '',
    canActivate: [ AuthenticationGuard ],
    component: SearchSectionComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes),
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
