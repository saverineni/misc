package uk.gov.gsi.hmrc.cds.search.elasticsearch.query;

import lombok.RequiredArgsConstructor;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.query.SearchQueryConstants.*;

import java.util.Optional;

import static java.util.Arrays.asList;
import static org.elasticsearch.search.aggregations.AggregationBuilders.terms;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.query.SearchQueryConstants.*;

@Component
@RequiredArgsConstructor
public class SearchQuerySource {
    static final int MAX_AGGREGATION_SIZE = 1000;
    
    public String getFacetFieldName(String facetType) {
        return LINE_FACETS.contains(facetType) ? "lines." + facetType + ".prefix" : facetType + ".prefix";
    }

    public SearchSourceBuilder getQueryBuilderWithPagination(SearchCriteria searchCriteria) {
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        SearchSourceBuilder searchSourceBuilderWithQuery = searchSourceBuilder.query(getQueryBuilder(searchCriteria).toQueryBuilder());
        
        int offSet = (searchCriteria.getPageNumber() - 1) * searchCriteria.getPageSize();
        searchSourceBuilderWithQuery.from(offSet);
        searchSourceBuilderWithQuery.size(searchCriteria.getPageSize());
        return searchSourceBuilderWithQuery;
    }

    public SearchSourceBuilder getQueryBuilderWithFacets(SearchCriteria searchCriteria, String facetType, Optional<String> prefix) {
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        String field = FacetFields.valueOf(facetType).getField();
        SearchQueryBuilder query = getQueryBuilder(searchCriteria);

        prefix.ifPresent(value -> {
           final String replaceReservedCharPrefix = replaceReservedCharacters.apply(value);
           if (REGEX_FACETS.contains(facetType)) {
               query.withFieldRegex(field, replaceReservedCharPrefix);
           } else {
               query.withField(getFacetFieldName(facetType), replaceReservedCharPrefix);
           }
        });
        searchSourceBuilder.query(query.toQueryBuilder()).size(0);
        searchSourceBuilder
                .aggregation(
                        terms("facets").field(field).size(MAX_AGGREGATION_SIZE)
                );
        return searchSourceBuilder;
    }

    /*
     * This method is used to build search query on all search criteria fields including query facets
     */
    private SearchQueryBuilder getQueryBuilder(SearchCriteria searchCriteria) {
        SearchQueryBuilder builder = newSearchQueryBuilder();
        searchCriteria.optionalSearchTerm().ifPresent(it -> builder.withMultiMatchField(asList(ALL_SEARCH_FIELDS), it));
        searchCriteria.optionalEori().ifPresent(it -> builder.withMultiMatchField(asList(EORI_FIELDS), it));

        builder.withDateRange(ENTRY_DATE, searchCriteria.optionalEntryDateTimeFrom(), searchCriteria.optionalEntryDateTimeTo())
               .withDateRange(ACCEPTANCE_DATE, searchCriteria.optionalAcceptanceDateTimeFrom(), searchCriteria.optionalAcceptanceDateTimeTo())
               .withDateRange(CLEARANCE_DATE, searchCriteria.optionalClearanceDateTimeFrom(), searchCriteria.optionalClearanceDateTimeTo())
               .withRange(NET_MASS, searchCriteria.optionalNetMassFrom(), searchCriteria.optionalNetMassTo())
               .withRange(ITEM_PRICE, searchCriteria.optionalItemPriceFrom(), searchCriteria.optionalItemPriceTo());

        buildTermsQuery(searchCriteria, builder);

        return builder;
    }

    SearchQueryBuilder newSearchQueryBuilder() {
        return new SearchQueryBuilder();
    }

    private void buildTermsQuery(SearchCriteria searchCriteria, SearchQueryBuilder builder) {
        builder.withFieldValues(LINES_ORIGIN_COUNTRY_CODE, searchCriteria.getOriginCountryCode())
               .withFieldValues(DISPATCH_COUNTRY_CODE, searchCriteria.getDispatchCountryCode())
               .withFieldValues(DESTINATION_COUNTRY_CODE, searchCriteria.getDestinationCountryCode())
               .withFieldValues(TRANSPORT_MODE_CODE, searchCriteria.getTransportModeCode())
               .withFieldValues(GOODS_LOCATION, searchCriteria.getGoodsLocation())
               .withFieldValues(LINES_COMMODITY_CODE, searchCriteria.getCommodityCode())
               .withFieldValues(LINES_PREFERENCE_NUMBER, searchCriteria.getPreferenceNumber())
               .withFieldValues(LINES_CPC, searchCriteria.getCpc())
               .withFieldValues(DECLARATION_TYPE, searchCriteria.getDeclarationType())
               .withFieldValues(DECLARATION_SOURCE, searchCriteria.getDeclarationSource())
               .withFieldValues(PROCESSING_STATUS, searchCriteria.getProcessingStatus());
    }
}