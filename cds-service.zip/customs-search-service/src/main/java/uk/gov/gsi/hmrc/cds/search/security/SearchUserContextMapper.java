package uk.gov.gsi.hmrc.cds.search.security;

import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.ldap.userdetails.LdapUserDetailsImpl;
import org.springframework.security.ldap.userdetails.LdapUserDetailsMapper;
import org.springframework.security.ldap.userdetails.UserDetailsContextMapper;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchUserDetails;

import java.util.Collection;
import java.util.Optional;

@Component
public class SearchUserContextMapper extends LdapUserDetailsMapper implements UserDetailsContextMapper {

    @Override
    public SearchUserDetails mapUserFromContext(DirContextOperations context, String username,
            Collection<? extends GrantedAuthority> authorities) {
        LdapUserDetailsImpl ldapUserDetailsImpl = (LdapUserDetailsImpl) super.mapUserFromContext(context, username,
                authorities);
        SearchUserDetails searchUserDetails = new SearchUserDetails();
        populateSearchUserDetails(username, ldapUserDetailsImpl, searchUserDetails);
        populateSearchUserDetailFromContext(context, searchUserDetails);

        return searchUserDetails;
    }

    @Override
    public void mapUserToContext(UserDetails userDetails, DirContextAdapter dirContextAdapter) {
        super.mapUserToContext(userDetails, dirContextAdapter);
    }

    private void populateSearchUserDetails(String username, LdapUserDetailsImpl ldapUserDetailsImpl,
            SearchUserDetails searchUserDetails) {
        searchUserDetails.setPid(username);
        searchUserDetails.setPassword(ldapUserDetailsImpl.getPassword());
        searchUserDetails.setAccountNonExpired(ldapUserDetailsImpl.isAccountNonExpired());
        searchUserDetails.setAccountNonLocked(ldapUserDetailsImpl.isAccountNonLocked());
        searchUserDetails.setCredentialsNonExpired(ldapUserDetailsImpl.isCredentialsNonExpired());
        searchUserDetails.setEnabled(ldapUserDetailsImpl.isEnabled());
        searchUserDetails.setAuthorities(ldapUserDetailsImpl.getAuthorities());
    }

    private void populateSearchUserDetailFromContext(DirContextOperations context,
            SearchUserDetails searchUserDetails) {
        searchUserDetails.setFirstName(context.getStringAttribute("givenName"));
        searchUserDetails.setLastName(context.getStringAttribute("sn"));
        String department = Optional.ofNullable(context.getStringAttribute("department"))
                .orElse(context.getStringAttribute("description"));
        searchUserDetails.setDepartment(department);
    }

}
