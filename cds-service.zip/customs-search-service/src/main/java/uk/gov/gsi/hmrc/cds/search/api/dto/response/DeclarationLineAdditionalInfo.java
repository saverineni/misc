package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.definition.ViewDefinition;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeclarationLineAdditionalInfo {

    @ViewDefinition(id = "additionalInfoSequenceNumber", order = 46, label = "AI Sequence Number", parentId="additionalInfo")
    private String additionalInfoSequenceNumber;
    @ViewDefinition(id = "additionalInfoStatement", order = 47, label = "AI Statement", parentId="additionalInfo")
    private String additionalInfoStatement;
    @ViewDefinition(id = "additionalInfoStatementDescription", order = 48, label = "AI Statement Description", parentId="additionalInfo")
    private String additionalInfoStatementDescription;

}
