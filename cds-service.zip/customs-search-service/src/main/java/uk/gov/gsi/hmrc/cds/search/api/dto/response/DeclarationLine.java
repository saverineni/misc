package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.Trader;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.definition.ViewDefinition;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.definition.ViewType;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeclarationLine {
    private int itemNumber;

    @ViewDefinition(id = "itemRoute", order = 1, label = "Route of Entry")
    private String itemRoute;
    @ViewDefinition(id = "cpc", order = 2, label = "CPC")
    private String cpc;
    @ViewDefinition(id = "clearanceDate", order = 3, label = "Clearance Date", type = ViewType.TIMESTAMP)
    private String clearanceDate;

    @ViewDefinition(id = "originCountry", order = 4, label = "Country of Origin", path = ".code")
    private Country originCountry;
    @ViewDefinition(id = "itemDispatchCountry", order = 5, label = "Country of Dispatch", path = ".code")
    private Country itemDispatchCountry;
    @ViewDefinition(id = "itemDestinationCountry", order = 6, label = "Country Of Final Destination", path = ".code")
    private Country itemDestinationCountry;

    @ViewDefinition(id = "goodsDescription", order = 7, label = "Goods Description")
    private String goodsDescription;
    @ViewDefinition(id = "grossMass", order = 8, label = "Gross Mass (Kg)")
    private String grossMass;
    @ViewDefinition(id = "netMass", order = 9, label = "Net Mass (Kg)")
    private String netMass;
    @ViewDefinition(id = "quotaNumber", order = 10, label = "Quota Number")
    private String quotaNumber;
    @ViewDefinition(id = "preferenceNumber", order = 11, label = "Preference Number")
    private String preferenceNumber;
    @ViewDefinition(id = "supplementaryUnits", order = 12, label = "Supplementary Units")
    private String supplementaryUnits;

    @ViewDefinition(id = "invoiceCurrency", order = 13, label = "Item Currency")
    private String invoiceCurrency;
    @ViewDefinition(id = "itemPrice", order = 14, label = "Item Price")
    private String itemPrice;
    @ViewDefinition(id = "statisticalValue", order = 15, label = "Statistical Value")
    private String statisticalValue;
    @ViewDefinition(id = "commodityCode", order = 16, label = "Commodity Code")
    private String commodityCode;

    @ViewDefinition(id = "valuationMethod", order = 17, label = "Valuation Method")
    private String valuationMethod;
    @ViewDefinition(id = "valuationAdjustmentCode", order = 18, label = "Valuation Adjustment Code")
    private String valuationAdjustmentCode;
    @ViewDefinition(id = "valuationAdjustmentCurrency", order = 19, label = "Valuation Adjustment Currency")
    private String valuationAdjustmentCurrency;
    @ViewDefinition(id = "valuationAdjustmentAmount", order = 20, label = "Valuation Adjustment Amount")
    private String valuationAdjustmentAmount;

    @ViewDefinition(id = "itemConsignee", order = 21, label = "Consignee EORI", path = ".eori")
    @ViewDefinition(id = "itemConsignee", order = 22, label = "Consignee Name", path = ".name")
    @ViewDefinition(id = "itemConsignee", order = 23, label = "Consignee Postcode", path = ".postcode")
    private Trader itemConsignee;
    @ViewDefinition(id = "itemConsignor", order = 24, label = "Consignor EORI", path = ".eori")
    @ViewDefinition(id = "itemConsignor", order = 25, label = "Consignor Name", path = ".name")
    @ViewDefinition(id = "itemConsignor", order = 26, label = "Consignor Postcode", path = ".postcode")
    private Trader itemConsignor;
    @ViewDefinition(id = "itemDeclarant", order = 27, label = "Declarant EORI", path = ".eori")
    @ViewDefinition(id = "itemDeclarant", order = 28, label = "Declarant Name", path = ".name")
    @ViewDefinition(id = "itemDeclarant", order = 29, label = "Declarant Postcode", path = ".postcode")
    private Trader itemDeclarant;

    @ViewDefinition(id = "taxLines", order = 30, label = "Tax Lines", type = ViewType.LIST)
    private List<DeclarationLineTaxLine> taxLines;
    @ViewDefinition(id = "routes", order = 42, label = "Routes", type = ViewType.LIST)
    private List<DeclarationLineRoute> routes;
    @ViewDefinition(id = "additionalInfo", order = 45, label = "Additional Info", type = ViewType.LIST)
    private List<DeclarationLineAdditionalInfo> additionalInfo;
    @ViewDefinition(id = "previousDocuments", order = 49, label = "Previous Documents", type = ViewType.LIST)
    private List<DeclarationLinePreviousDocument> previousDocuments;
    @ViewDefinition(id = "containers", order = 52, label = "Containers", type = ViewType.LIST)
    private List<DeclarationLineContainer> containers;
    @ViewDefinition(id = "packages", order = 55, label = "Packages", type = ViewType.LIST)
    private List<DeclarationLinePackage> packages;

}
