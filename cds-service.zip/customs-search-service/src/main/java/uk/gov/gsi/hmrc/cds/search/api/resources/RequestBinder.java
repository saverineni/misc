package uk.gov.gsi.hmrc.cds.search.api.resources;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ResponseStatus;

import uk.gov.gsi.hmrc.cds.search.elasticsearch.query.SearchQueryConstants.FacetFields;

@Component
public class RequestBinder {

    public static final List<String> ALLOWED_FACET_TYPES = Stream.of(FacetFields.values()).map(FacetFields::name).collect(Collectors.toList());

    @InitBinder
    protected void initBinder(WebDataBinder binder) {
        binder.setAllowedFields(
                "pageNumber",
                "pageSize",
                "facetType",
                "prefix",
                "searchTerm",
                "eori",
                "originCountryCode",
                "dispatchCountryCode",
                "destinationCountryCode",
                "transportModeCode",
                "goodsLocation",
                "declarationType",
                "declarationSource",
                "commodityCode",
                "cpc",
                "entryDateFrom",
                "entryDateTo",
                "clearanceDateFrom",
                "clearanceDateTo",
                "acceptanceDateFrom",
                "acceptanceDateTo",
                "netMassFrom",
                "netMassTo",
                "itemPriceFrom",
                "itemPriceTo",
                "preferenceNumber",
                "processingStatus");
    }


    @SuppressWarnings("serial")
    @ResponseStatus(code = HttpStatus.BAD_REQUEST)
    static class UnsupportedRequestParameterException extends RuntimeException {

        UnsupportedRequestParameterException(String[] suppressedFields) {
            super("Unsupported request parameters: " + String.join(",", suppressedFields));
        }
    }

    @SuppressWarnings("serial")
    @ResponseStatus(code = HttpStatus.BAD_REQUEST)
    static class BadRequestException extends RuntimeException {
        BadRequestException() {
            super("Bad Request");
        }
    }
}
