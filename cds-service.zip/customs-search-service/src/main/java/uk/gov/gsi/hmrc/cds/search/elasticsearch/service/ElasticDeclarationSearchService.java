package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import lombok.RequiredArgsConstructor;
import org.elasticsearch.action.search.SearchResponse;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.FacetSearchResult;

import java.util.Optional;


@Component
@RequiredArgsConstructor
public class ElasticDeclarationSearchService {

    private final SearchResponseMapperService searchResponseMapperService;

    private final SearchClient searchClient;

    public Optional<Declaration> fetchDeclarationById(String declarationId) {
        SearchResponse searchResponse = searchClient.getDeclarationById(declarationId);
        return searchResponseMapperService.mapDeclarationByIdResponse(searchResponse);
    }

    public DeclarationSearchResult fetchDeclarationSearchResult(SearchCriteria searchCriteria) {
        SearchResponse searchResponse = searchClient.declarationSearch(searchCriteria);
        return searchResponseMapperService.mapDeclarationsResponse(searchResponse);
    }

    public FacetSearchResult fetchFacetSearchResult(SearchCriteria searchCriteria, String facetType, Optional<String> prefix) {
        SearchResponse searchFacetsResponse = searchClient.facetSearch(searchCriteria, facetType, prefix);
        return searchResponseMapperService.mapFacetsResponse(searchFacetsResponse, facetType, prefix);
    }
}
