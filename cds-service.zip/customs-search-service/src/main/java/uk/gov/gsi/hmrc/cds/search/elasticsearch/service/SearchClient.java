package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import java.io.IOException;
import java.util.Optional;

import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.connection.headers.ESHeaders;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.query.SearchQuerySource;

@Service
public class SearchClient {

    private final RestHighLevelClient client;
    private final String searchAlias;
    private final ESHeaders esHeaders;
    private final SearchQuerySource searchQueryBuilder;

    SearchClient(RestHighLevelClient client,
                 @Value("${elasticsearch.alias}") String searchAlias,
                 ESHeaders esHeaders,
                 SearchQuerySource searchQueryBuilder) {
        this.client = client;
        this.searchAlias = searchAlias;
        this.esHeaders = esHeaders;
        this.searchQueryBuilder = searchQueryBuilder;
    }

    SearchResponse getDeclarationById(String declarationId) {
        try {
            SearchRequest searchRequest = new SearchRequest(searchAlias);
            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();

            searchSourceBuilder.query(QueryBuilders.matchQuery("_id", declarationId));
            searchRequest.source(searchSourceBuilder);

            return client.search(searchRequest, esHeaders.getHeaders());
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    SearchResponse declarationSearch(SearchCriteria searchCriteria) {
        try{
            SearchRequest searchRequest = new SearchRequest(searchAlias);
            searchRequest.source(searchQueryBuilder.getQueryBuilderWithPagination(searchCriteria));

            return client.search(searchRequest, esHeaders.getHeaders());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    SearchResponse facetSearch(SearchCriteria searchCriteria, String facetType, Optional<String> prefix) {
        try {
            SearchRequest searchRequest = new SearchRequest(searchAlias);
            searchRequest.source(searchQueryBuilder.getQueryBuilderWithFacets(searchCriteria, facetType, prefix));

            return client.search(searchRequest, esHeaders.getHeaders());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
