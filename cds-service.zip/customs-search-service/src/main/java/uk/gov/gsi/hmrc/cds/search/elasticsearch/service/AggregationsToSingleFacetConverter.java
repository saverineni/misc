package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import lombok.RequiredArgsConstructor;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.Facet;

import java.util.List;

import static java.util.stream.Collectors.toList;

@Component
@RequiredArgsConstructor
public class AggregationsToSingleFacetConverter implements Converter<Aggregations, List<Facet>> {
    private final BucketToFacetConverter facetConverter;

    @Override
    public List<Facet> convert(Aggregations aggregations) {
        return parseFacets(aggregations, "facets");
    }

    private List<Facet> parseFacets(Aggregations aggregations, String facetType) {
        Terms termsAggregation = aggregations.get(facetType);
        return termsAggregation.getBuckets().stream()
                .map(facetConverter::convert)
                .collect(toList());
    }
}
