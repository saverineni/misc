package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.definition.ViewDefinition;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeclarationLinePackage {
    @ViewDefinition(id = "packageSequenceNumber", order = 56, label = "Package Sequence Number", parentId="packages")
    private String packageSequenceNumber;
    @ViewDefinition(id = "packageCount", order = 57, label = "Package Count", parentId="packages")
    private String packageCount;
    @ViewDefinition(id = "packageKind", order = 58, label = "Package Kind", parentId="packages")
    private String packageKind;
    @ViewDefinition(id = "packageMarks", order = 59, label = "Package Marks", parentId="packages")
    private String packageMarks;
}
