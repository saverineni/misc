package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.definition.ViewDefinition;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeclarationLinePreviousDocument {

    @ViewDefinition(id = "previousDocumentSequenceNumber", order = 50, label = "Previous Document Sequence Number", parentId="previousDocuments")
    private String previousDocumentSequenceNumber;
    @ViewDefinition(id = "previousDocumentClass", order = 51, label = "Previous Document Class", parentId="previousDocuments")
    private String previousDocumentClass;

}
