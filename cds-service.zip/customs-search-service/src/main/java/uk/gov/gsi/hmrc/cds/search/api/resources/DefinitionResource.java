package uk.gov.gsi.hmrc.cds.search.api.resources;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Definitions;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.definition.ViewDefinition;

import java.util.List;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static uk.gov.gsi.hmrc.cds.search.api.dto.response.definition.ViewDefinition.Utils.orderedViewDefinitions;

@RestController
@RequiredArgsConstructor
@RequestMapping(value = "/declarations")
public class DefinitionResource {

    @GetMapping(value = "/definition")
    public Definitions getDeclarationDefinition() {
        final List<ViewDefinition> definitions = orderedViewDefinitions(Declaration.class , FALSE);
        return Definitions.builder().definitions(definitions).build();
    }

    @GetMapping(value = "/items/definition")
    public Definitions getDeclarationItemsDefinition() {
        final List<ViewDefinition> definitions = orderedViewDefinitions(DeclarationLine.class , TRUE);
        return Definitions.builder().definitions(definitions).build();
    }

}