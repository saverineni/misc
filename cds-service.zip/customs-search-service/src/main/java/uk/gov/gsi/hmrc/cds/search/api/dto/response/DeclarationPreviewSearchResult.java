package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import java.util.List;
import java.util.Optional;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class DeclarationPreviewSearchResult {
    Hits hits;
    List<DeclarationPreview> declarations;

    public static DeclarationPreviewSearchResult fromDeclarationSearchResult(DeclarationSearchResult searchResult) {
        return Optional.ofNullable(searchResult).map(search ->
                DeclarationPreviewSearchResult.builder()
                .hits(search.getHits())
                .declarations(search.getDeclarationPreviews())
                .build())
                .orElse(DeclarationPreviewSearchResult.builder().build());
    }
}



