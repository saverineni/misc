package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.definition.ViewDefinition;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeclarationLineRoute {

    @ViewDefinition(id = "routeSequenceNumber", order = 43, label = "Route Sequence Number", parentId="routes")
    private String routeSequenceNumber;
    @ViewDefinition(id = "routeCountryCode", order = 44, label = "Route Country Code", parentId="routes")
    private String routeCountryCode;

}
