package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import lombok.RequiredArgsConstructor;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHit;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.FacetSearchResult;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Hits;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.Facet;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toList;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.query.SearchQueryConstants.*;


@Component
@RequiredArgsConstructor
public class SearchResponseMapperService {

    private final ConversionService conversionService;

    public Optional<Declaration> mapDeclarationByIdResponse(SearchResponse searchResponse) {
        SearchHit[] hits = searchResponse.getHits().getHits();
        if (hits.length == 1) {
            return Optional.of(conversionService.convert(hits[0], Declaration.class));
        } else {
            return Optional.empty();
        }
    }

    public DeclarationSearchResult mapDeclarationsResponse(SearchResponse searchResponse) {
        return DeclarationSearchResult.builder()
                .declarations(Stream.of(searchResponse.getHits().getHits())
                        .map(searchHit -> conversionService.convert(searchHit, Declaration.class))
                        .collect(toList()))
                .hits(new Hits(searchResponse.getHits().getTotalHits()))
                .build();
    }

    public FacetSearchResult mapFacetsResponse(SearchResponse searchFacetsResponse, String facetType, Optional<String> prefix) {
        @SuppressWarnings("unchecked")
        List<Facet> facets = conversionService.convert(searchFacetsResponse.getAggregations(), List.class);

        if (LINE_FACETS.contains(facetType)) {
            facets = filterFacetsByPrefix(facetType, facets, prefix);
        }

        return FacetSearchResult.builder()
                .facets(facets)
                .build();
    }

    List<Facet> filterFacetsByPrefix(String facetType, List<Facet> facets, Optional<String> prefix) {
        return prefix.map(value -> facets.stream().filter(facet -> {
            final String replaceReservedCharPrefix = replaceReservedCharacters.apply(value);
            final boolean filterFacet = REGEX_FACETS.contains(facetType) ? facet.getId().matches(replaceReservedCharPrefix) : facet.getId().startsWith(replaceReservedCharPrefix);
            return filterFacet;
        }).collect(toList())).orElse(facets);
    }
}
