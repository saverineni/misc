package uk.gov.gsi.hmrc.cds.search.elasticsearch.query;

import lombok.Value;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.RangeQueryBuilder;

import java.time.LocalDateTime;
import java.util.*;

import static org.elasticsearch.index.query.QueryBuilders.*;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.query.SearchQueryConstants.esDateTimeFormatter;

public class SearchQueryBuilder {
    private Map<String, List<String>> fieldValues = new LinkedHashMap<>();
    private Map<List<String>, String> fieldsWithValue = new LinkedHashMap<>();
    private Map<String, Range> ranges = new LinkedHashMap<>();
    private Map<String, String> fields = new LinkedHashMap<>();
    private Map<String, String> fieldsWithRegex = new LinkedHashMap<>();
    
    @Value
    private class Range {
        Optional<String> from;
        Optional<String> to;
        
        boolean hasValues() {
            return from.isPresent() || to.isPresent();
        }
    }
    
    public SearchQueryBuilder withFieldValues(String field, List<String> values) {
        if (!values.isEmpty()) {
            fieldValues.put(field, new LinkedList<>(values));
        }
        return this;
    }
    
    public SearchQueryBuilder withMultiMatchField(List<String> fields, String value) {
        fieldsWithValue.put(new LinkedList<>(fields), value);
        return this;
    }
    
    public SearchQueryBuilder withDateRange(String field, Optional<LocalDateTime> from, Optional<LocalDateTime> to) {
        withRange(
            field,
            from.map(it -> it.format(esDateTimeFormatter)),
            to.map(it -> it.format(esDateTimeFormatter))
        );
        
        return this;
    }
    
    public SearchQueryBuilder withRange(String field, Optional<String> from, Optional<String> to) {
        Range range = new Range(from, to);
        if (range.hasValues()) {
            ranges.put(field, range);
        }
        return this;
    }
    
    public SearchQueryBuilder withField(String field, String value) {
        fields.put(field, value);
        
        return this;
    }

    public SearchQueryBuilder withFieldRegex(String field, String regex) {
        fieldsWithRegex.put(field, regex);

        return this;
    }

    public BoolQueryBuilder toQueryBuilder() {
        BoolQueryBuilder query = boolQuery().must(matchAllQuery());

        fieldValues.entrySet().stream().forEach(it -> buildFieldListQuery(query, it.getKey(), it.getValue()));
        fieldsWithValue.entrySet().forEach(it -> query.must(multiMatchQuery(it.getValue(), it.getKey().stream().toArray(String[]::new))));
        ranges.entrySet().forEach(it -> buildRange(query, it.getKey(), it.getValue()));
        fields.entrySet().forEach(it -> query.must(matchQuery(it.getKey(), it.getValue())));
        fieldsWithRegex.entrySet().forEach(it -> buildRegexQuery(query, it.getKey() , it.getValue()));

        return query;
    }

    private void buildRange(BoolQueryBuilder query, String field, Range value) {
        RangeQueryBuilder rangeQuery = rangeQuery(field);
        value.getFrom().map(rangeQuery::gte);
        value.getTo().map(rangeQuery::lte);
        
        query.must(rangeQuery);
    }

    private void buildFieldListQuery(BoolQueryBuilder query, String field, List<String> values) {
        BoolQueryBuilder queryBuilder = boolQuery();
        values.stream().map(value -> termQuery(field, value)).forEach(queryBuilder::should);

        query.must(queryBuilder);
    }

    private void buildRegexQuery(BoolQueryBuilder query, String facet, String prefix) {
        BoolQueryBuilder queryBuilder = boolQuery();
        queryBuilder.should(regexpQuery(facet , prefix));
        query.must(queryBuilder);
    }
}
