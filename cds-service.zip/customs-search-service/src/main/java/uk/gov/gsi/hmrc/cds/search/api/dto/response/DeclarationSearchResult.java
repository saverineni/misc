package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import lombok.Builder;
import lombok.Value;

import static java.util.Collections.emptyList;

@Value
@Builder
public class DeclarationSearchResult {
    Hits hits;
    List<Declaration> declarations;

    List<DeclarationPreview> getDeclarationPreviews() {
        return Optional.ofNullable(this.getDeclarations()).orElse(emptyList()).stream()
                .map(DeclarationPreview::fromDeclaration)
                .collect(Collectors.toList());
    }
}


