package uk.gov.gsi.hmrc.cds.search.api.resources;

import java.util.List;

import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.definition.ViewDefinition;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationPreview;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationPreviewSearchResult;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Definitions;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.ElasticDeclarationSearchService;

import static java.lang.Boolean.FALSE;

@RestController
@RequiredArgsConstructor
public class SearchResource extends RequestBinder {

    private final ElasticDeclarationSearchService elasticDeclarationSearchService;

    @GetMapping(value = "/search/definition")
    public Definitions getSearchDefinition() {
        final List<ViewDefinition> definitions = ViewDefinition.Utils.orderedViewDefinitions(DeclarationPreview.class , FALSE);
        return Definitions.builder().definitions(definitions).build();
    }

    @GetMapping(value = "/search")
    public DeclarationPreviewSearchResult getDeclarationSearchResult(SearchCriteria searchCriteria, BindingResult errors) {
        if (errors.getSuppressedFields().length > 0) {
            throw new UnsupportedRequestParameterException(errors.getSuppressedFields());
        }

        DeclarationSearchResult searchResult = elasticDeclarationSearchService.fetchDeclarationSearchResult(searchCriteria);
        return DeclarationPreviewSearchResult.fromDeclarationSearchResult(searchResult);
    }
}
