package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.definition.ViewDefinition;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeclarationLineContainer {

    @ViewDefinition(id = "containerSequenceNumber", order = 53, label = "Container Sequence Number", parentId="containers")
    private String containerSequenceNumber;
    @ViewDefinition(id = "containerNumber", order = 54, label = "Container Number", parentId="containers")
    private String containerNumber;

}
