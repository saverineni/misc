package uk.gov.gsi.hmrc.cds.search.api.dto.response.definition;

public enum ViewType {
    STRING,
    TIMESTAMP,
    TRUNCATED,
    LIST
}
