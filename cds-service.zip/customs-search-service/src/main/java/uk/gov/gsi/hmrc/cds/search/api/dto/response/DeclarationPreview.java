package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.definition.ViewDefinition;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.definition.ViewType;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeclarationPreview {
    @ViewDefinition(id = "declarationId", order = 1, label = "Declaration ID", header = true)
    private String declarationId;
    @ViewDefinition(id = "importExportIndicator", order = 2, label = "Import/Export", header = true)
    private String importExportIndicator;
    @ViewDefinition(id = "declarationSource" , order = 3, label = "Declaration Source", header = true)
    private String declarationSource;
    @ViewDefinition(id = "entryDate" , order = 4, label = "Entry Date", type = ViewType.TIMESTAMP)
    private String entryDate;
    @ViewDefinition(id = "route" , order = 5, label = "Route of Entry")
    private String route;
    @ViewDefinition(id = "goodsLocation" , order = 6, label = "Goods Location")
    private String goodsLocation;
    @ViewDefinition(id = "dispatchCountry" , order = 7, label = "Country of Dispatch", path = ".code")
    private Country dispatchCountry;
    @ViewDefinition(id = "destinationCountry" , order = 8, label = "Country of Destination", path = ".code")
    private Country destinationCountry;
    @ViewDefinition(id = "transportModeCode" , order = 9, label = "Mode of Transport")
    private String transportModeCode;

    private int lineCount;

    static DeclarationPreview fromDeclaration(Declaration declaration) {
        return DeclarationPreview.builder()
                .declarationId(declaration.getDeclarationId())
                .importExportIndicator(declaration.getImportExportIndicator())
                .declarationSource(declaration.getDeclarationSource())
                .entryDate(declaration.getEntryDate())
                .route(declaration.getRoute())
                .goodsLocation(declaration.getGoodsLocation())
                .dispatchCountry(declaration.getDispatchCountry())
                .destinationCountry(declaration.getDestinationCountry())
                .transportModeCode(declaration.getTransportModeCode())
                .lineCount(declaration.getLines().size())
                .build();
    }
}
