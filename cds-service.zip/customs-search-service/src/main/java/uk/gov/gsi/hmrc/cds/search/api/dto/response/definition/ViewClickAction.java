package uk.gov.gsi.hmrc.cds.search.api.dto.response.definition;

public enum ViewClickAction {
    NONE,
    COPY
}
