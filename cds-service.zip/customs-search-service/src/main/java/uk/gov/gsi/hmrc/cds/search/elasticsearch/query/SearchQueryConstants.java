package uk.gov.gsi.hmrc.cds.search.elasticsearch.query;

import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Stream;

public class SearchQueryConstants {

    static final String LINES_ORIGIN_COUNTRY_CODE = "lines.originCountry.code";
    static final String DISPATCH_COUNTRY_CODE = "dispatchCountry.code";
    static final String DESTINATION_COUNTRY_CODE = "destinationCountry.code";
    static final String TRANSPORT_MODE_CODE = "transportModeCode";
    static final String DECLARATION_TYPE = "declarationType";
    static final String DECLARATION_SOURCE = "declarationSource";
    static final String GOODS_LOCATION = "goodsLocation";
    static final String LINES_COMMODITY_CODE = "lines.commodityCode";
    static final String ENTRY_DATE = "entryDate";
    static final String LINES_CPC = "lines.cpc";
    static final String LINES_PREFERENCE_NUMBER = "lines.preferenceNumber";
    static final String PROCESSING_STATUS = "processingStatus";
    static final String CLEARANCE_DATE = "lines.clearanceDate";
    static final String ACCEPTANCE_DATE = "acceptanceDate";
    static final String NET_MASS = "lines.netMass";
    static final String ITEM_PRICE = "lines.itemPrice";

    public static final DateTimeFormatter esDateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
    public static final List<String> LINE_FACETS = Arrays.asList("originCountryCode", "commodityCode" , "cpc", "preferenceNumber");
    public static final List<String> REGEX_FACETS = Arrays.asList("cpc");

    private static final String RESERVED_CHARS = "[-+^:,*]";

    public static final String[] SEARCH_TERM_FIELDS = {
            "declarationId",
            "epuNumber",
            "entryNumber",
            "consignee.name",
            "consignee.postcode",
            "consignor.name",
            "consignor.postcode",
            "declarant.name",
            "declarant.postcode",
            LINES_COMMODITY_CODE,
            "lines.originCountry.code.codeText",
            LINES_CPC,
            "lines.itemConsignee.name",
            "lines.itemConsignee.postcode",
            "lines.itemConsignor.name",
            "lines.itemConsignor.postcode",
            "lines.itemDeclarant.name",
            "lines.itemDeclarant.postcode",
            "lines.preferenceNumber"
    };

    public static final String[] EORI_FIELDS = {
            "consignee.eori",
            "consignor.eori",
            "declarant.eori",
            "lines.itemConsignee.eori",
            "lines.itemConsignor.eori",
            "lines.itemDeclarant.eori"
    };

    public static final String[] ALL_SEARCH_FIELDS = Stream.of(SEARCH_TERM_FIELDS, EORI_FIELDS)
            .flatMap(Stream::of)
            .toArray(String[]::new);


    public enum FacetFields {
        originCountryCode(LINES_ORIGIN_COUNTRY_CODE),
        dispatchCountryCode(DISPATCH_COUNTRY_CODE),
        destinationCountryCode(DESTINATION_COUNTRY_CODE),
        commodityCode(LINES_COMMODITY_CODE),
        transportModeCode(TRANSPORT_MODE_CODE),
        goodsLocation(GOODS_LOCATION),
        cpc(LINES_CPC),
        declarationType(DECLARATION_TYPE),
        preferenceNumber(LINES_PREFERENCE_NUMBER),
        processingStatus(PROCESSING_STATUS);

        private String field;

        FacetFields(String field) {
            this.field = field;
        }

        public String getField() {
            return field;
        }
    }

    public static Function<String,String> replaceReservedCharacters = input -> input.replaceAll(RESERVED_CHARS,".");
}
