package uk.gov.gsi.hmrc.cds.search.api.converters;

import com.opencsv.CSVWriter;
import net.logstash.logback.encoder.org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.converter.AbstractHttpMessageConverter;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.definition.ViewDefinition;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.definition.ViewType;

import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static java.util.Collections.emptyList;
import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;
import static uk.gov.gsi.hmrc.cds.search.api.converters.CsvConverterUtils.mapToStream;

@Component
public class DeclarationLineCsvConverter extends AbstractHttpMessageConverter<Declaration> {

    private static final String CONVERTER_MEDIA_TYPE = "text/csv";
    private static final List EMPTY_LIST = emptyList();
    private static final String EMPTY_STRING = "";

    private static final Stream<String> DEC_HEADERS = getHeaderFields(EMPTY_LIST);

    private static final Stream<String> LINE_HEADERS = getLineFields(EMPTY_LIST);

    static final String[] HEADERS = Stream.concat(DEC_HEADERS, LINE_HEADERS).toArray(String[]::new);

    static final LinkedHashMap<String, List<ViewDefinition>> LINES_VIEW_DEFINITIONS = ViewDefinition.Utils
            .orderedViewDefinitions(DeclarationLine.class, TRUE)
            .stream()
            .collect(groupingBy(ViewDefinition::parentId ,
                                LinkedHashMap::new ,  // Preserves the order
                                toList()));

    public DeclarationLineCsvConverter() {
        super(MediaType.valueOf(CONVERTER_MEDIA_TYPE));
    }

    private static Stream<String> getHeaderFields(List fields) {
        return Stream.concat(Stream.of("Item Number"),
                ViewDefinition.Utils.orderedViewDefinitionFields(Declaration.class,fields , FALSE)
                .flatMap(field -> Stream.of(field.getAnnotationsByType(ViewDefinition.class)))
                .filter(ViewDefinition::header)
                .map(ViewDefinition::label));
    }

    private static Stream<String> getLineFields(List fields) {
        return ViewDefinition.Utils.orderedViewDefinitionFields(DeclarationLine.class,fields, FALSE)
                .flatMap(field -> Stream.of(field.getAnnotationsByType(ViewDefinition.class)))
                .filter(viewDefinition -> !viewDefinition.type().equals(ViewType.LIST))
                .map(ViewDefinition::label);
    }

    private static String[] getViewDefinitionHeaders(List<ViewDefinition> viewDefinitions) {
        return Stream.concat(Stream.of("Item Number"),
                viewDefinitions.stream().map(ViewDefinition::label))
                .toArray(String[]::new);
    }

    @Override
    protected boolean supports(Class<?> aClass) {
        return Declaration.class.isAssignableFrom(aClass);
    }

    @Override
    protected Declaration readInternal(Class<? extends Declaration> aClass, HttpInputMessage httpInputMessage)
            throws HttpMessageNotReadableException {
        throw new HttpMessageNotReadableException("Not supported");
    }

    private String[] asOrderedStringValues(Declaration declaration, DeclarationLine declarationLine, List fields) {
        Stream<String> header = Stream.concat(Stream.of(declarationLine.getItemNumber() + ""),
                ViewDefinition.Utils.orderedViewDefinitionFields(Declaration.class,fields , FALSE)
                        .filter(field -> Stream.of(field.getAnnotationsByType(ViewDefinition.class)).allMatch(ViewDefinition::header))
                        .flatMap(field -> mapToStream(field, declaration)));

        return Stream.concat(header,
                ViewDefinition.Utils.orderedViewDefinitionFields(DeclarationLine.class,fields , FALSE)
                .filter(field -> !Collection.class.isAssignableFrom(field.getType()))
                .flatMap(field -> mapToStream(field, declarationLine)))
                .toArray(String[]::new);
    }

    private String[] asOrderedStringHeaders(List fields) {
        final Stream<String> headerLabels = getHeaderFields(fields);
        final Stream<String> lineLabels = getLineFields(fields);
        return Stream.concat(headerLabels, lineLabels).toArray(String[]::new);
    }

    private List<String[]> asOrderedLineAssociationValues(String parentId, DeclarationLine declarationLine) {
        final String itemNumber = declarationLine.getItemNumber() + "";

        return ViewDefinition.Utils.orderedViewDefinitionFields(DeclarationLine.class,EMPTY_LIST , FALSE)
                .filter(field -> Collection.class.isAssignableFrom(field.getType()))
                .filter(field -> field.getName().equalsIgnoreCase(parentId))
                .flatMap(field -> CsvConverterUtils.mapToStream(itemNumber, field, declarationLine))
                .collect(toList());
    }

    @Override
    protected void writeInternal(Declaration declaration, HttpOutputMessage httpOutputMessage) throws HttpMessageNotWritableException {
        httpOutputMessage.getHeaders().add(HttpHeaders.CONTENT_TYPE, CONVERTER_MEDIA_TYPE);

        final List<String> filterFields = (List<String> ) ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
                .getRequest().getAttribute("fields");

        final List<String> fields = ofNullable(filterFields).orElse(EMPTY_LIST);

        try (final Writer writer = new OutputStreamWriter(httpOutputMessage.getBody())) {

            try (CSVWriter csvWriter = new CSVWriter(writer,
                    CSVWriter.DEFAULT_SEPARATOR,
                    CSVWriter.NO_QUOTE_CHARACTER,
                    CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                    CSVWriter.DEFAULT_LINE_END)) {

                LINES_VIEW_DEFINITIONS.forEach((parentId,viewDefinitions) -> writeToCSV(parentId,viewDefinitions, csvWriter , declaration , fields));
            }
        } catch (Exception ex) {
            logger.error("Unable to output declaration lines in CSV format.", ex);
        }
    }

    private void writeToCSV(String parentId, List<ViewDefinition> viewDefinitions, CSVWriter csvWriter, Declaration declaration , List<String> fields) {
        if(StringUtils.isEmpty(parentId)) {
            final String[] FILTER_HEADERS = (fields.isEmpty()) ? HEADERS : asOrderedStringHeaders(fields);
            csvWriter.writeNext(FILTER_HEADERS);

            final List<String[]> declarationLines = declaration.getLines().stream()
                    .sorted(Comparator.comparing(DeclarationLine::getItemNumber))
                    .map(line -> asOrderedStringValues(declaration, line ,fields))
                    .collect(Collectors.toList());

            csvWriter.writeAll(declarationLines);
        } else {
            final List<String[]> lineAssociations = declaration.getLines().stream()
                    .sorted(Comparator.comparing(DeclarationLine::getItemNumber))
                    .map(line -> asOrderedLineAssociationValues(parentId,line))
                    .flatMap(List::stream)
                    .collect(toList());

            if(lineAssociations.size() > 0 ){
                csvWriter.writeNext(new String[]{EMPTY_STRING});
                csvWriter.writeNext(LINES_VIEW_DEFINITIONS.get(EMPTY_STRING)
                        .stream()
                        .filter(viewDefinition -> viewDefinition.id().equalsIgnoreCase(parentId))
                        .map(ViewDefinition::label)
                        .toArray(String[]::new));

                csvWriter.writeNext(getViewDefinitionHeaders(viewDefinitions));
                csvWriter.writeAll(lineAssociations);
            }

        }
    }
}
