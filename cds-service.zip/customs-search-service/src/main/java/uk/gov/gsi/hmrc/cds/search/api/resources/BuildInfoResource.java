package uk.gov.gsi.hmrc.cds.search.api.resources;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class BuildInfoResource {

    @Autowired
    private BuildProperties buildProperties;

    @GetMapping(value = "/build/info")
    public Build getSearchDefinition() {
        return new Build(buildProperties.getVersion(), buildProperties.getArtifact());
     }

    @Data
    class Build {

        private String version;
        private String artifact;

        Build(String version, String artifact) {
            this.version = version;
            this.artifact = artifact;
        }
    }
}
