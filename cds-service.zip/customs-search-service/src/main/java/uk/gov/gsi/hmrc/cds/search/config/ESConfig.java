package uk.gov.gsi.hmrc.cds.search.config;

import java.io.File;

import javax.net.ssl.SSLContext;

import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.ssl.SSLContexts;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

@Configuration
public class ESConfig {

    @Value("${elasticsearch.host}")
    String elasticSearchHost;
    @Value("${elasticsearch.port}")
    int elasticSearchPort;
    @Value("${elasticsearch.scheme}")
    String elasticSearchScheme;
    @Value("${elasticsearch.username}")
    String username;
    @Value("${elasticsearch.password}")
    String password;
    @Value("${elasticsearch.connectTimeout}")
    int connectTimeout;
    @Value("${elasticsearch.socketTimeout}")
    int socketTimeout;
    @Value("${elasticsearch.retryTimeout}")
    int retryTimeout;

    @Bean
    public RestHighLevelClient esRestHighlevelClient(@Qualifier("es") SSLContext sslContext) {
        return new RestHighLevelClient(RestClient
                .builder(new HttpHost(elasticSearchHost, elasticSearchPort, elasticSearchScheme))
                .setRequestConfigCallback(requestConfigBuilder -> requestConfigBuilder.setConnectTimeout(connectTimeout)
                        .setSocketTimeout(socketTimeout))
                .setMaxRetryTimeoutMillis(retryTimeout).setHttpClientConfigCallback(httpClientConfig -> httpClientConfig
                        .setDefaultCredentialsProvider(esCredentialsProvider())
                        .setSSLContext(sslContext))
                );
    }

    private CredentialsProvider esCredentialsProvider() {
        CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
        credentialsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(username, password));

        return credentialsProvider;
    }


    @Profile({ "test", "contract" })
    @Configuration
    public static class TestConfig {
        @Profile("test")
        @Bean
        @Primary
        @Qualifier("es")
        public SSLContext testSSLContext() throws Exception {
            return SSLContexts.createDefault();
        }
    }

    @Profile({ "!test", "!contract" })
    @Configuration
    public static class NonTestConfig {

        @Value("${elasticsearch.ssl.trust-store}")
        String truststoreLocation;

        @Profile("!e2e")
        @Bean
        @Qualifier("es")
        public SSLContext esSSLContext() throws Exception {
            return SSLContexts.custom().loadTrustMaterial(new File(truststoreLocation)).build();
        }

        @Profile("e2e")
        @Bean
        @Qualifier("es")
        public SSLContext e2eEsSSLContext() throws Exception {
            return SSLContexts.custom().loadTrustMaterial(new TrustSelfSignedStrategy()).build();
        }
    }
}
