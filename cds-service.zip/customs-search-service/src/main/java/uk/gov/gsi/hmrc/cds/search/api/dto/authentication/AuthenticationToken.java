package uk.gov.gsi.hmrc.cds.search.api.dto.authentication;

import lombok.Data;

@Data
public class AuthenticationToken {
    private String token;
    private int timeToLive;
}