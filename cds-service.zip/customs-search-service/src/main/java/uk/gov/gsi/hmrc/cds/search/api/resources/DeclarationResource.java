package uk.gov.gsi.hmrc.cds.search.api.resources;

import lombok.RequiredArgsConstructor;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.request.FilterFields;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;
import uk.gov.gsi.hmrc.cds.search.api.exceptions.ResourceNotFoundException;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.ElasticDeclarationSearchService;

import java.util.List;

import static java.util.Optional.ofNullable;
import static org.springframework.web.context.request.RequestAttributes.SCOPE_REQUEST;

@RestController
@RequiredArgsConstructor
@RequestMapping(value="/declarations")
public class DeclarationResource extends RequestBinder {

    public static final String FIELDS = "fields";
    private final ElasticDeclarationSearchService elasticDeclarationSearchService;

    @GetMapping()
    public DeclarationSearchResult getDeclarationSearchResult(SearchCriteria searchCriteria, BindingResult errors) {
        if (errors.getSuppressedFields().length > 0) {
            throw new UnsupportedRequestParameterException(errors.getSuppressedFields());
        }

        return elasticDeclarationSearchService.fetchDeclarationSearchResult(searchCriteria);
    }

    @PostMapping()
    public DeclarationSearchResult postDeclarationSearchResult(@RequestBody FilterFields filterFields, SearchCriteria searchCriteria, BindingResult errors) {
        if (errors.getSuppressedFields().length > 0) {
            throw new UnsupportedRequestParameterException(errors.getSuppressedFields());
        }

        final List<String> fields = ofNullable(filterFields).map(FilterFields::getFields)
                .orElseThrow(BadRequestException::new);
        RequestContextHolder.getRequestAttributes().setAttribute(FIELDS,fields,SCOPE_REQUEST);

        return elasticDeclarationSearchService.fetchDeclarationSearchResult(searchCriteria);
    }

    @GetMapping(value = "/{declarationId}")
    public Declaration getDeclarationById(@PathVariable String declarationId) {
        return elasticDeclarationSearchService.fetchDeclarationById(declarationId)
                .orElseThrow(ResourceNotFoundException::new);
    }


    @PostMapping(value = "/{declarationId}")
    public Declaration postDeclarationById(@PathVariable String declarationId,@RequestBody FilterFields filterFields) {

        final List<String> fields = ofNullable(filterFields).map(FilterFields::getFields)
                .orElseThrow(BadRequestException::new);

        RequestContextHolder.getRequestAttributes().setAttribute(FIELDS,fields,SCOPE_REQUEST);

        return elasticDeclarationSearchService.fetchDeclarationById(declarationId)
                .orElseThrow(ResourceNotFoundException::new);
    }
}