package uk.gov.gsi.hmrc.cds.search.api.dto.response.definition;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.lang.annotation.*;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Stream;

import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@Repeatable(ViewDefinition.ViewDefinitions.class)
public @interface ViewDefinition {
    @JsonIgnore
    int order();
    @JsonProperty
    String id();
    @JsonProperty
    String label();
    @JsonProperty
    boolean header() default false;
    @JsonProperty
    ViewType type() default ViewType.STRING;
    @JsonProperty
    String path() default "";
    @JsonProperty
    ViewClickAction clickAction() default ViewClickAction.NONE;
    @JsonProperty
    String tooltip() default "";
    @JsonProperty
    String parentId() default "";

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.FIELD)
    @interface ViewDefinitions {
        ViewDefinition[] value();
    }

    final class Utils {

        public static Stream<Field> orderedViewDefinitionFields(Class<?> clazz,List filterFields,Boolean nestedFields) {
            List<Field> orderedViewDefinitionFields = nestedFields(clazz , nestedFields)
                    .filter(field -> field.getAnnotationsByType(ViewDefinition.class).length > 0)
                    .filter(field -> filterFields.isEmpty() || filterFields.contains(field.getAnnotationsByType(ViewDefinition.class)[0].id()))
                    .sorted((a, b) -> {
                        int aOrder = a.getAnnotationsByType(ViewDefinition.class)[0].order();
                        int bOrder = b.getAnnotationsByType(ViewDefinition.class)[0].order();
                        return Integer.compare(aOrder, bOrder);
                    }).collect(toList());

            return orderedViewDefinitionFields.stream();
        }

        public static List<ViewDefinition> orderedViewDefinitions(Class<?> clazz , Boolean nestedFields) {
            return orderedViewDefinitionFields(clazz,emptyList() , nestedFields)
                    .flatMap(field -> Stream.of(field.getAnnotationsByType(ViewDefinition.class)))
                    .collect(toList());
        }

        private static Stream<Field> nestedFields(Class<?> clazz , Boolean nestedFields)  {
            final Field[] fields = clazz.getDeclaredFields();
            return Stream.concat(Arrays.stream(fields),
                    Arrays.stream(fields)
                            .filter(field -> nestedFields && Collection.class.isAssignableFrom(field.getType()))
                            .flatMap(field -> nestedFields(nestedClass(field) , nestedFields)));
        }

        public static Class nestedClass(Field field ) {
            try {
                String genericString = field.toGenericString();
                String clazz = genericString.split("\\<")[1].split("\\>")[0];
                return Class.forName(clazz);
            } catch(ClassNotFoundException ex) {
                return null;
            }
        }
    }

}
