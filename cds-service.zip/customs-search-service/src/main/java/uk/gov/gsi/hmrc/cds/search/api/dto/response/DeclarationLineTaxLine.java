package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.definition.ViewDefinition;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeclarationLineTaxLine {

    @ViewDefinition(id = "taxLineSequenceNumber", order = 31, label = "Tax Sequence Number" , parentId="taxLines")
    private String taxLineSequenceNumber;
    @ViewDefinition(id = "taxTypeCode", order = 32, label = "Tax Type Code", parentId="taxLines")
    private String taxTypeCode;
    @ViewDefinition(id = "taxBaseAmount", order = 33, label = "Tax Base (Amount)", parentId="taxLines")
    private String taxBaseAmount;
    @ViewDefinition(id = "taxBaseAmountCalculated", order = 34, label = "Tax Base (Amount) Calculated", parentId="taxLines")
    private String taxBaseAmountCalculated;
    @ViewDefinition(id = "taxBaseQuantity", order = 35, label = "Tax Base (Quantity)", parentId="taxLines")
    private String taxBaseQuantity;
    @ViewDefinition(id = "taxRateIdentifier", order = 36, label = "Tax Rate Identifier", parentId="taxLines")
    private String taxRateIdentifier;
    @ViewDefinition(id = "taxOverrideCode", order = 37, label = "Tax Override Code", parentId="taxLines")
    private String taxOverrideCode;
    @ViewDefinition(id = "taxAmount", order = 38, label = "Tax Amount", parentId="taxLines")
    private String taxAmount;
    @ViewDefinition(id = "taxAmountCalculated", order = 39, label = "Tax Amount Calculated", parentId="taxLines")
    private String taxAmountCalculated;
    @ViewDefinition(id = "methodOfPaymentCode", order = 40, label = "Method Of Payment Code", parentId="taxLines")
    private String methodOfPaymentCode;
    @ViewDefinition(id = "taxAmountIndicator", order = 41, label = "Declared or Calculated", parentId="taxLines")
    private String taxAmountIndicator;
}
