package uk.gov.gsi.hmrc.cds.search.api.converters;

import lombok.extern.slf4j.Slf4j;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.Trader;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.*;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.definition.ViewDefinition;

import java.lang.reflect.Field;
import java.util.*;
import java.util.stream.Stream;

@Slf4j
class CsvConverterUtils {

    static Stream<? extends String> mapToStream(Field field, Object hostObject) {
        field.setAccessible(true);
        try {
            return getStream(field, field.get(hostObject));
        } catch (IllegalAccessException e) {
            log.error("Unable to access view definition field for object " + hostObject.getClass().getSimpleName(), e);
            return Stream.empty();
        }
    }

    private static Stream<? extends String> getStream(Field field, Object value) {
        if (field.getType() == String.class) {
            return Stream.of((String) value);
        } else if (field.getType() == Country.class) {
            return Optional.ofNullable((Country) value)
                    .map(c -> Stream.of(c.getCode())).orElse(Stream.of(""));
        } else if (field.getType() == Trader.class) {
            return Optional.ofNullable((Trader) value)
                    .map(t -> Stream.of(t.getEori(), t.getName(), t.getPostcode())).orElse(Stream.of("", "", ""));
        } else {
            return Stream.of("");
        }
    }

    static Stream<? extends String[]> mapToStream(String itemNumber, Field field, Object hostObject) {
        field.setAccessible(true);
        try {
            return getStream(itemNumber, field, field.get(hostObject));
        } catch (IllegalAccessException e) {
            log.error("Unable to access view definition field for object " + hostObject.getClass().getSimpleName(), e);
            return Stream.empty();
        }
    }

    private static Stream<? extends String[]> getStream(String itemNumber, Field field, Object value) {
        final Class clazz = ViewDefinition.Utils.nestedClass(field);

        if(clazz == DeclarationLineTaxLine.class) {
            final List<DeclarationLineTaxLine> taxLinesData = (List<DeclarationLineTaxLine>) value;
            final List taxLines = new ArrayList<>();

            Optional.ofNullable(taxLinesData)
                    .ifPresent(lines -> lines.stream()
                            .map(taxLine -> Stream.of(itemNumber, taxLine.getTaxLineSequenceNumber(), taxLine.getTaxTypeCode(), taxLine.getTaxBaseAmount()
                                            , taxLine.getTaxBaseAmountCalculated(), taxLine.getTaxBaseQuantity()
                                            , taxLine.getTaxRateIdentifier(), taxLine.getTaxOverrideCode()
                                            , taxLine.getTaxAmount(), taxLine.getTaxAmountCalculated()
                                            , taxLine.getMethodOfPaymentCode(), taxLine.getTaxAmountIndicator()).toArray(String[]::new))
                            .forEach(taxLines::add));

            return taxLines.stream();
        } else if(clazz == DeclarationLineRoute.class) {
            final List<DeclarationLineRoute> routes = (List<DeclarationLineRoute>) value;
            final List lineRoutes = new ArrayList<>();

            Optional.ofNullable(routes)
                    .ifPresent(lines -> lines.stream()
                            .map(route -> Stream.of(itemNumber, route.getRouteSequenceNumber(), route.getRouteCountryCode()).toArray(String[]::new))
                            .forEach(lineRoutes::add));

            return lineRoutes.stream();
        } else if(clazz == DeclarationLineAdditionalInfo.class) {
            final List<DeclarationLineAdditionalInfo> additionalInfo = (List<DeclarationLineAdditionalInfo>) value;
            final List lineAdditionalInfo = new ArrayList<>();

            Optional.ofNullable(additionalInfo)
                    .ifPresent(lines -> lines.stream()
                            .map(info -> Stream.of(itemNumber, info.getAdditionalInfoSequenceNumber(), info.getAdditionalInfoStatement() , info.getAdditionalInfoStatementDescription()).toArray(String[]::new))
                            .forEach(lineAdditionalInfo::add));

            return lineAdditionalInfo.stream();
        } else if(clazz == DeclarationLinePreviousDocument.class) {
            final List<DeclarationLinePreviousDocument> previousDocuments = (List<DeclarationLinePreviousDocument>) value;
            final List linePreviousDocuments = new ArrayList<>();

            Optional.ofNullable(previousDocuments)
                    .ifPresent(lines -> lines.stream()
                            .map(previousDocument -> Stream.of(itemNumber, previousDocument.getPreviousDocumentSequenceNumber(), previousDocument.getPreviousDocumentClass()).toArray(String[]::new))
                            .forEach(linePreviousDocuments::add));

            return linePreviousDocuments.stream();
        } else if(clazz == DeclarationLineContainer.class) {
            final List<DeclarationLineContainer> containers = (List<DeclarationLineContainer>) value;
            final List lineContainers = new ArrayList<>();

            Optional.ofNullable(containers)
                    .ifPresent(lines -> lines.stream()
                            .map(container -> Stream.of(itemNumber, container.getContainerSequenceNumber(), container.getContainerNumber()).toArray(String[]::new))
                            .forEach(lineContainers::add));

            return lineContainers.stream();
        } else if(clazz == DeclarationLinePackage.class) {
            final List<DeclarationLinePackage> packages = (List<DeclarationLinePackage>) value;
            final List linePackages = new ArrayList<>();

            Optional.ofNullable(packages)
                    .ifPresent(lines -> lines.stream()
                            .map(linePackage -> Stream.of(itemNumber, linePackage.getPackageSequenceNumber(), linePackage.getPackageCount(),
                                    linePackage.getPackageKind(), linePackage.getPackageMarks()).toArray(String[]::new))
                            .forEach(linePackages::add));

            return linePackages.stream();
        } else {
            return Stream.empty();
        }
    }

}
