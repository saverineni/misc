package uk.gov.gsi.hmrc.cds.search.elasticsearch.query;

import org.elasticsearch.index.query.*;
import org.junit.Test;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import static java.util.Arrays.asList;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static java.util.stream.Collectors.toList;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

public class SearchQueryBuilderTest {
    private static final LocalDateTime FROM_DATE = LocalDateTime.of(2017, 1, 1, 12, 00, 59);
    private static final String FROM_DATE_STRING = "2017-01-01 12:00:59.000";
    private static final LocalDateTime TO_DATE = LocalDateTime.of(2018, 12, 30, 23, 1, 2);
    private static final String TO_DATE_STRING = "2018-12-30 23:01:02.000";
    private static final String FROM = "1234";
    private static final String TO = "2345";
    
    SearchQueryBuilder builder = new SearchQueryBuilder();
    
    // add match all query builder check
    
    @Test
    public void firstPartOfQueryShouldBeMatchAll() {
        builder.withFieldValues("field", asList("a"));
        
        QueryBuilder queryBuilder = getBuiltQuery().must().get(0);
        
        assertThat(queryBuilder, is(instanceOf(MatchAllQueryBuilder.class)));
    }
    
    @Test
    public void shouldNotAddQueryForEmptyList() {
        builder.withFieldValues("field", asList());
        
        int queryCount = getBuiltQuery().must().size();
        
        assertThat(queryCount, is(1));
    }

    private BoolQueryBuilder getBuiltQuery() {
        return builder.toQueryBuilder();
    }

    @Test
    public void shouldAddFieldListToQuery() {
        builder.withFieldValues("search-field", asList("a", "b", "c"));
        
        BoolQueryBuilder fieldValuesBuilder = (BoolQueryBuilder)getBuiltQuery().must().get(1);
        
        assertThat(toQueryFieldNames(fieldValuesBuilder), contains("search-field", "search-field", "search-field"));
        assertThat(toQueryValues(fieldValuesBuilder), contains("a", "b", "c"));
    }


    @Test
    public void shouldAddFieldRegexToQuery() {
        builder.withFieldRegex("regex-field", "..ab..");

        BoolQueryBuilder fieldRegexValuesBuilder = (BoolQueryBuilder)getBuiltQuery().must().get(1);

        assertThat(toQueryRegexFieldNames(fieldRegexValuesBuilder), contains("regex-field"));
        assertThat(toQueryRegexValues(fieldRegexValuesBuilder), contains("..ab.."));
    }

    @Test
    public void shouldAddMultipleFieldListsToQuery() {
        builder.withFieldValues("field1", asList("a"));
        builder.withFieldValues("field2", asList("b"));
        
        BoolQueryBuilder queryBuilder = getBuiltQuery();
        BoolQueryBuilder fieldValuesBuilder1 = (BoolQueryBuilder)queryBuilder.must().get(1);
        BoolQueryBuilder fieldValuesBuilder2 = (BoolQueryBuilder)queryBuilder.must().get(2);
        
        assertThat(toQueryFieldNames(fieldValuesBuilder1), contains("field1"));
        assertThat(toQueryValues(fieldValuesBuilder1), contains("a"));
        
        assertThat(toQueryFieldNames(fieldValuesBuilder2), contains("field2"));
        assertThat(toQueryValues(fieldValuesBuilder2), contains("b"));
    }


    @Test
    public void shouldAddMultiMatchFieldsToQuery()  {
        List<String> fields = asList("field1", "field2", "field3");
        
        builder.withMultiMatchField(fields, "value");
        MultiMatchQueryBuilder multiMatchQuery = (MultiMatchQueryBuilder)getBuiltQuery().must().get(1);

        assertThat(new ArrayList<>(multiMatchQuery.fields().keySet()), is(fields));
        assertThat(multiMatchQuery.value(), is("value"));
    }

    @Test
    public void shouldAddMultipleMultiMatchFieldsToQuery()  {
        List<String> field2 = asList("field2", "field3");
        
        builder.withMultiMatchField(asList("field1", "field2", "field3"), "value1");
        builder.withMultiMatchField(field2, "value2");
        
        MultiMatchQueryBuilder multiMatchQuery = (MultiMatchQueryBuilder)getBuiltQuery().must().get(2);

        assertThat(new ArrayList<>(multiMatchQuery.fields().keySet()), is(field2));
        assertThat(multiMatchQuery.value(), is("value2"));
    }

    @Test
    public void shouldAddMustMatchDateRangeToTheQuery() {
        builder.withDateRange("dateField", of(FROM_DATE), of(TO_DATE));
        
        RangeQueryBuilder rangeQuery = (RangeQueryBuilder)getBuiltQuery().must().get(1);
        assertThat(rangeQuery.from(), is(FROM_DATE_STRING));
        assertThat(rangeQuery.to(), is(TO_DATE_STRING));
    }

    @Test
    public void shouldAddOnlyFromDateToTheQuery() {
        builder.withDateRange("dateField", of(FROM_DATE), empty());
        
        RangeQueryBuilder rangeQuery = (RangeQueryBuilder)getBuiltQuery().must().get(1);
        assertThat(rangeQuery.from(), is(FROM_DATE_STRING));
        assertThat(rangeQuery.to(), is(nullValue()));
    }

    @Test
    public void shouldAddOnlyToDateToTheQuery() {
        builder.withDateRange("dateField", empty(), of(TO_DATE));
        
        RangeQueryBuilder rangeQuery = (RangeQueryBuilder)getBuiltQuery().must().get(1);
        assertThat(rangeQuery.from(), is(nullValue()));
        assertThat(rangeQuery.to(), is(TO_DATE_STRING));
    }

    @Test
    public void shouldNotAddMustMatchDateRangeWhenNoValues() {
        builder.withDateRange("dateField", empty(), empty());
        
        BoolQueryBuilder query = getBuiltQuery();
        assertThat(query.must().size(), is(1));
    }

    @Test
    public void shouldAddMustMatchRangeToTheQuery() {
        builder.withRange("dateField", of(FROM), of(TO));
        
        RangeQueryBuilder rangeQuery = (RangeQueryBuilder)getBuiltQuery().must().get(1);
        assertThat(rangeQuery.from(), is(FROM));
        assertThat(rangeQuery.to(), is(TO));
    }

    @Test
    public void shouldAddOnlyFromToTheQuery() {
        builder.withRange("dateField", of(FROM), empty());
        
        RangeQueryBuilder rangeQuery = (RangeQueryBuilder)getBuiltQuery().must().get(1);
        assertThat(rangeQuery.from(), is(FROM));
        assertThat(rangeQuery.to(), is(nullValue()));
    }

    @Test
    public void shouldAddOnlyToToTheQuery() {
        builder.withRange("dateField", empty(), of(TO));
        
        RangeQueryBuilder rangeQuery = (RangeQueryBuilder)getBuiltQuery().must().get(1);
        assertThat(rangeQuery.from(), is(nullValue()));
        assertThat(rangeQuery.to(), is(TO));
    }

    @Test
    public void shouldNotAddMustMatchRangeWhenNoValues() {
        builder.withRange("dateField", empty(), empty());
        
        BoolQueryBuilder query = getBuiltQuery();
        assertThat(query.must().size(), is(1));
    }
    
    @Test
    public void shouldAddMatchFieldToQuery() {
        builder.withField("field", "value");
        
        MatchQueryBuilder query = (MatchQueryBuilder)getBuiltQuery().must().get(1);
        assertThat(query.fieldName(), is("field"));
        assertThat(query.value(), is("value"));
    }


    private List<Object> toQueryValues(BoolQueryBuilder queryBuilder) {
        return fieldQueryBuilders(queryBuilder).map(TermQueryBuilder::value).collect(toList());
    }

    private List<String> toQueryFieldNames(BoolQueryBuilder queryBuilder) {
        return fieldQueryBuilders(queryBuilder).map(TermQueryBuilder::fieldName).collect(toList());
    }

    private List<Object> toQueryRegexValues(BoolQueryBuilder queryBuilder) {
        return fieldRegexQueryBuilders(queryBuilder).map(RegexpQueryBuilder::value).collect(toList());
    }

    private List<String> toQueryRegexFieldNames(BoolQueryBuilder queryBuilder) {
        return fieldRegexQueryBuilders(queryBuilder).map(RegexpQueryBuilder::fieldName).collect(toList());
    }

    private Stream<TermQueryBuilder> fieldQueryBuilders(BoolQueryBuilder queryBuilder) {
        return queryBuilder.should().stream().map(it -> (TermQueryBuilder)it);
    }

    private Stream<RegexpQueryBuilder> fieldRegexQueryBuilders(BoolQueryBuilder queryBuilder) {
        return queryBuilder.should().stream().map(it -> (RegexpQueryBuilder)it);
    }
}
