package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.core.convert.ConversionService;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.FacetSearchResult;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.Facet;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

public class SearchResponseMapperServiceTest {

    private SearchResponseMapperService mapper;

    @Mock
    private ConversionService conversionService;

    @Mock
    private SearchResponse searchResponse;

    @Mock
    private Declaration declaration;

    @Mock
    private Terms facetTerms;

    final Facet facet1 = Facet.builder().id("123456789").count(10).build();
    final Facet facet2 = Facet.builder().id("128912345").count(10).build();

    List<Facet> facets = Arrays.asList(facet1, facet2);

    @Before
    public void setUp() {
        initMocks(this);
        mapper = new SearchResponseMapperService(conversionService);
    }

    @Test
    public void mapsSearchHitsToDeclarations() {
        SearchHit[] searchHits = new SearchHit[1];
        SearchHit searchHit = new SearchHit(1);
        searchHits[0] = searchHit;

        when(conversionService.convert(searchHit, Declaration.class)).thenReturn(declaration);
        when(searchResponse.getHits()).thenReturn(new SearchHits(searchHits, 1l, 0.0f));

        DeclarationSearchResult actual = mapper.mapDeclarationsResponse(searchResponse);
        assertThat(actual.getHits().getTotal(), is(1L));
        assertThat(actual.getDeclarations().size(), is(1));
    }

    @Test
    public void mapFacetsResponse() {
        givenSearchResponseWithAggregations();
        FacetSearchResult actual = mapper.mapFacetsResponse(searchResponse, "headerFacet", Optional.empty());
        assertThat(actual.getFacets(), is(facets));
    }

    @Test
    public void mapFilteredFacetsResponseByPrefix(){
        givenSearchResponseWithAggregations();
        FacetSearchResult actual = mapper.mapFacetsResponse(searchResponse, "commodityCode", Optional.of("12"));
        assertThat(actual.getFacets().size(), is(2));
        assertThat(actual.getFacets().get(0).getId(), is("123456789"));
    }

    @Test
    public void mapFilteredCPCFacetsResponseByPrefix(){
        givenSearchResponseWithAggregations();
        FacetSearchResult actual = mapper.mapFacetsResponse(searchResponse, "cpc", Optional.of("**34*****"));
        assertThat(actual.getFacets().size(), is(1));
        assertThat(actual.getFacets().get(0).getId(), is("123456789"));
    }

    @Test
    public void mapFilteredCPCFacetsResponseByPrefixForExactValue(){
        givenSearchResponseWithAggregations();
        FacetSearchResult actual = mapper.mapFacetsResponse(searchResponse, "cpc", Optional.of("128912345"));
        assertThat(actual.getFacets().size(), is(1));
        assertThat(actual.getFacets().get(0).getId(), is("128912345"));
    }

    private void givenSearchResponseWithAggregations() {
        when(facetTerms.getName()).thenReturn("facets");
        Aggregations aggregations = new Aggregations(asList(facetTerms));
        when(searchResponse.getAggregations()).thenReturn(aggregations);
        when(conversionService.convert(aggregations, List.class)).thenReturn(facets);
    }
}