package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.junit.Before;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLine;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.elasticsearch.common.xcontent.XContentType.JSON;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.TermsBucketMatchers.termsBucket;

@SuppressWarnings("unchecked")
public class DeclarationTypeFacetAggregationIT extends CustomsSearchESIntegTestCase {

  private static final String CUSTOMS_INDEX = "DeclarationTypeFacetAggregationIT".toLowerCase();

    private static final String COUNTRY_CODE_GB = "GB";
    private static final String COUNTRY_CODE_FR = "FR";
    private static final String DECLARATION_TYPE_A = "A";
    private static final String DECLARATION_TYPE_B = "B";
    private static final String DECLARATION_TYPE_C = "C";
    private static final String DECLARATION_TYPE_D = "D";

    private ObjectMapper objectMapper = new ObjectMapper();

    @Before
    public void setUp() throws Exception {
        super.setUp(CUSTOMS_INDEX);
        createCustomsIndexWithDocuments();
    }

    @Test
    public void returnsAlldeclarationTypes() {
        SearchResponse searchResponse = this.service.facetSearch(newSearchCriteria("",Arrays.asList(COUNTRY_CODE_GB,COUNTRY_CODE_FR)),"declarationType", Optional.empty());
        assertThat(searchResponse.getHits().totalHits, is(4L));

        Terms termsAggregation = searchResponse.getAggregations().get("facets");
        assertThat(termsAggregation.getBuckets(), containsInAnyOrder(
            termsBucket(DECLARATION_TYPE_A, 1),
            termsBucket(DECLARATION_TYPE_B, 1),
            termsBucket(DECLARATION_TYPE_C, 1),
            termsBucket(DECLARATION_TYPE_D, 1)
        ));
    }

    @Test
    public void returnsMultiMatchdeclarationTypes() {
        SearchResponse searchResponse = this.service.facetSearch(newSearchCriteria("",Arrays.asList(COUNTRY_CODE_GB)),"declarationType", Optional.empty());
        assertThat(searchResponse.getHits().totalHits, is(3L));

        Terms termsAggregation = searchResponse.getAggregations().get("facets");
        assertThat(termsAggregation.getBuckets(), containsInAnyOrder(
                termsBucket(DECLARATION_TYPE_A, 1),
                termsBucket(DECLARATION_TYPE_C, 1),
                termsBucket(DECLARATION_TYPE_D, 1)
        ));
    }

    @Test
    public void returnsMatchingdeclarationTypes() {
        SearchResponse searchResponse = this.service.facetSearch(newSearchCriteria("",Arrays.asList(COUNTRY_CODE_FR)),"declarationType", Optional.empty());
        assertThat(searchResponse.getHits().totalHits, is(1L));

        Terms termsAggregation = searchResponse.getAggregations().get("facets");
        assertThat(termsAggregation.getBuckets(), contains(
                termsBucket(DECLARATION_TYPE_B, 1)
        ));
    }

    private SearchCriteria newSearchCriteria(String searchTerm, List<String> originCountryCodes) {
        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setSearchTerm(searchTerm);
        searchCriteria.setOriginCountryCode(originCountryCodes);
        return searchCriteria;
    }

    private void createCustomsIndexWithDocuments() throws Exception {
        createIndex(CUSTOMS_INDEX);

        BulkRequest request = new BulkRequest();
        addDeclaration(request, newDeclaration("dec-id-1", COUNTRY_CODE_GB, DECLARATION_TYPE_A));
        addDeclaration(request, newDeclaration("dec-id-2", COUNTRY_CODE_FR, DECLARATION_TYPE_B));
        addDeclaration(request, newDeclaration("dec-id-3", COUNTRY_CODE_GB, DECLARATION_TYPE_C));
        addDeclaration(request, newDeclaration("dec-id-4", COUNTRY_CODE_GB, DECLARATION_TYPE_D));


        client.bulk(request);

        refresh(CUSTOMS_INDEX);
    }

    private void addDeclaration(BulkRequest request, Declaration declaration) throws JsonProcessingException {
        request.add(new IndexRequest(CUSTOMS_INDEX, DECLARATION_TYPE, declaration.getDeclarationId())
                .source(objectMapper.writer().writeValueAsString(declaration), JSON));
    }

    private Declaration newDeclaration(String id, String originCountryCode, String declarationType ) {
        return Declaration.builder()
                .declarationId(id)
                .declarationType(declarationType)
                .lines(
                        Lists.newArrayList(
                                DeclarationLine.builder()
                                        .originCountry(Country.builder().code(originCountryCode).build())
                                        .build()
                        )
                )
                .build();
    }
}
