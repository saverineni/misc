package uk.gov.gsi.hmrc.cds.search.security;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import uk.gov.gsi.hmrc.cds.search.security.SecurityConfig;
import uk.gov.gsi.hmrc.cds.search.security.jwt.JwtAuthenticationProvider;

@Configuration
@Profile({"test"})
@EnableWebSecurity
@RequiredArgsConstructor
public class InMemorySecurityConfig extends SecurityConfig {

    private final JwtAuthenticationProvider jwtAuthenticationProvider;

    private final UserDetailsService userDetailsService;

    protected void configure(AuthenticationManagerBuilder auth) {
        auth
                .authenticationProvider(authenticationProvider())
                .authenticationProvider(jwtAuthenticationProvider);
    }

    private DaoAuthenticationProvider authenticationProvider() {
        final DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider();
        daoAuthenticationProvider.setUserDetailsService(userDetailsService);
        return daoAuthenticationProvider;
    }

}
