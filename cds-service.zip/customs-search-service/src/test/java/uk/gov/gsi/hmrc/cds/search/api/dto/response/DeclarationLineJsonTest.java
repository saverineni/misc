package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.Trader;
import uk.gov.gsi.hmrc.cds.search.utils.TestHelper;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@JsonTest
@ActiveProfiles("test")
public class DeclarationLineJsonTest {

    @Autowired
    private JacksonTester<DeclarationLine> json;

    @Test
    public void deserializeEmptyDeclarationLine() throws Exception {
        String content = "{}";

        assertThat(this.json.parse(content))
                .isEqualTo(DeclarationLine.builder().build());
    }

}