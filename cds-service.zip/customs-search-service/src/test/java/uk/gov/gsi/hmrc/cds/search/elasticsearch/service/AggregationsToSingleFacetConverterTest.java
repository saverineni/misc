package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import java.util.List;

import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.Facet;

public class AggregationsToSingleFacetConverterTest {


    @Mock
    private BucketToFacetConverter facetConverter;
    @Mock
    private Terms facetTerms;
    private AggregationsToSingleFacetConverter converter;
    private Aggregations aggregations;

    @Before
    public void setUp() {
        initMocks(this);
        when(facetTerms.getName()).thenReturn("facets"); // name of the aggregation

        aggregations = new Aggregations(asList(facetTerms));
        converter = new AggregationsToSingleFacetConverter(facetConverter);
    }

    @Test
    public void convertOne() {
        Terms.Bucket bucket = givenBucket();
        givenBuckets(bucket);
        Facet expected = givenCanConvertBucketToFacet(bucket);

        List<Facet> facets = converter.convert(aggregations);
        assertThat(facets, contains(expected));
    }

    @Test
    public void convertMany() {
        Terms.Bucket bucket1 = givenBucket();
        Terms.Bucket bucket2 = givenBucket();

        givenBuckets(bucket1, bucket2);

        Facet expected1 = givenCanConvertBucketToFacet(bucket1);
        Facet expected2 = givenCanConvertBucketToFacet(bucket2);

        List<Facet> facets = converter.convert(aggregations);
        assertThat(facets, contains(expected1, expected2));
    }

    @Test
    public void convertsEmptyBuckets() {
        givenBuckets();
        List<Facet> facets = converter.convert(aggregations);
        assertThat(facets, is(empty()));
    }

    private Terms.Bucket givenBucket() {
        return mock(Terms.Bucket.class);
    }

    @SuppressWarnings("unchecked")
    private void givenBuckets(Terms.Bucket... buckets) {
        @SuppressWarnings("rawtypes")
        List bucketList = asList(buckets);
        when(facetTerms.getBuckets()).thenReturn(bucketList);
    }

    private Facet givenCanConvertBucketToFacet(Terms.Bucket bucket) {
        Facet facet = Facet.builder().build();
        when(facetConverter.convert(bucket)).thenReturn(facet);
        return facet;
    }

}