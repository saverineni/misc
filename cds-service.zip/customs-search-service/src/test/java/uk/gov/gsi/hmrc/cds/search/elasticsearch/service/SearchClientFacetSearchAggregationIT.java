package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.junit.Before;
import org.junit.Test;

import static org.elasticsearch.common.xcontent.XContentType.JSON;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.TermsBucketMatchers.termsBucket;

import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLine;

@SuppressWarnings("unchecked")
public class SearchClientFacetSearchAggregationIT extends CustomsSearchESIntegTestCase {

  private static final String CUSTOMS_INDEX = "customs_search_service".toLowerCase();

    private static final String COUNTRY_CODE_GB = "GB";
    private static final String COUNTRY_CODE_FR = "FR";
    private static final String COMMODITY_CODE_1 = "123456789";
    private static final String COMMODITY_CODE_2 = "123467896";
    private static final String COMMODITY_CODE_3 = "513345678";
    private static final String COMMODITY_CODE_4 = "525445987";

    private ObjectMapper objectMapper = new ObjectMapper();

    @Before
    public void setUp() throws Exception {
        super.setUp(CUSTOMS_INDEX);
        createCustomsIndexWithDocuments();
    }

    @Test
    public void returnsAllCommodityCodesForEmptyPrefix() {
        SearchResponse searchResponse = this.service.facetSearch(newSearchCriteria("",Arrays.asList(COUNTRY_CODE_GB,COUNTRY_CODE_FR)),"commodityCode", Optional.empty());
        assertThat(searchResponse.getHits().totalHits, is(4L));

        Terms termsAggregation = searchResponse.getAggregations().get("facets");
        assertThat(termsAggregation.getBuckets(), containsInAnyOrder(
            termsBucket(COMMODITY_CODE_1, 1),
            termsBucket(COMMODITY_CODE_2, 1),
            termsBucket(COMMODITY_CODE_3, 1),
            termsBucket(COMMODITY_CODE_4, 1)
        ));
    }

    @Test
    public void returnsMultiMatchCommodityCodesForEmptyPrefix() {
        SearchResponse searchResponse = this.service.facetSearch(newSearchCriteria("",Arrays.asList(COUNTRY_CODE_GB)),"commodityCode", Optional.empty());
        assertThat(searchResponse.getHits().totalHits, is(3L));

        Terms termsAggregation = searchResponse.getAggregations().get("facets");
        assertThat(termsAggregation.getBuckets(), containsInAnyOrder(
                termsBucket(COMMODITY_CODE_1, 1),
                termsBucket(COMMODITY_CODE_3, 1),
                termsBucket(COMMODITY_CODE_4, 1)
        ));
    }

    @Test
    public void returnsMatchingCommodityCodesForEmptyPrefix() {
        SearchResponse searchResponse = this.service.facetSearch(newSearchCriteria("",Arrays.asList(COUNTRY_CODE_FR)),"commodityCode", Optional.empty());
        assertThat(searchResponse.getHits().totalHits, is(1L));

        Terms termsAggregation = searchResponse.getAggregations().get("facets");
        assertThat(termsAggregation.getBuckets(), contains(
                termsBucket(COMMODITY_CODE_2, 1)
        ));
    }

    @Test
    public void returnsMultiCommodityCodesForMatchingPrefix() {
        SearchResponse searchResponse = this.service.facetSearch(newSearchCriteria("",Arrays.asList(COUNTRY_CODE_GB,COUNTRY_CODE_FR)),"commodityCode", Optional.of("12"));
        assertThat(searchResponse.getHits().totalHits, is(2L));

        Terms termsAggregation = searchResponse.getAggregations().get("facets");
        assertThat(termsAggregation.getBuckets(), containsInAnyOrder(
                termsBucket(COMMODITY_CODE_1, 1),
                termsBucket(COMMODITY_CODE_2, 1)
        ));
    }

    @Test
    public void returnsSingleCommodityCodesForMatchingPrefix() {
        SearchResponse searchResponse = this.service.facetSearch(newSearchCriteria("",Arrays.asList(COUNTRY_CODE_GB)),"commodityCode", Optional.of("12"));
        assertThat(searchResponse.getHits().totalHits, is(1L));

        Terms termsAggregation = searchResponse.getAggregations().get("facets");
        assertThat(termsAggregation.getBuckets(), contains(
                termsBucket(COMMODITY_CODE_1, 1)
        ));
    }

    @Test
    public void returnsNoCommodityCodesForNonMatchingPrefix() {
        SearchResponse searchResponse = this.service.facetSearch(newSearchCriteria("",Arrays.asList(COUNTRY_CODE_GB)),"commodityCode", Optional.of("11"));
        assertThat(searchResponse.getHits().totalHits, is(0L));

        Terms termsAggregation = searchResponse.getAggregations().get("facets");
        assertThat(termsAggregation.getBuckets().size(), is(0));
    }


    private SearchCriteria newSearchCriteria(String searchTerm, List<String> originCountryCodes) {
        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setSearchTerm(searchTerm);
        searchCriteria.setOriginCountryCode(originCountryCodes);
        return searchCriteria;
    }

    private void createCustomsIndexWithDocuments() throws Exception {
        createIndex(CUSTOMS_INDEX);

        BulkRequest request = new BulkRequest();
        addDeclaration(request, newDeclaration("dec-id-1", COUNTRY_CODE_GB, COMMODITY_CODE_1));
        addDeclaration(request, newDeclaration("dec-id-2", COUNTRY_CODE_FR, COMMODITY_CODE_2 ));
        addDeclaration(request, newDeclaration("dec-id-3", COUNTRY_CODE_GB, COMMODITY_CODE_3));
        addDeclaration(request, newDeclaration("dec-id-4", COUNTRY_CODE_GB, COMMODITY_CODE_4));


        client.bulk(request);

        refresh(CUSTOMS_INDEX);
    }

    private void addDeclaration(BulkRequest request, Declaration declaration) throws JsonProcessingException {
        request.add(new IndexRequest(CUSTOMS_INDEX, DECLARATION_TYPE, declaration.getDeclarationId())
                .source(objectMapper.writer().writeValueAsString(declaration), JSON));
    }

    private Declaration newDeclaration(String id, String originCountryCode, String commodityCode ) {
        return Declaration.builder()
                .declarationId(id)
                .lines(
                        Lists.newArrayList(
                                DeclarationLine.builder()
                                        .originCountry(Country.builder().code(originCountryCode).build())
                                        .commodityCode(commodityCode)
                                        .build()
                        )
                )
                .build();
    }
}
