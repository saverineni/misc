package uk.gov.gsi.hmrc.cds.search.api.converters;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.Trader;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.stream.Stream;

import static java.util.Arrays.asList;
import static java.util.stream.Collectors.joining;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.MockitoAnnotations.initMocks;

public class DeclarationHeaderCsvConverterTest extends CSVConverterTest{

    private DeclarationHeaderCsvConverter converter = new DeclarationHeaderCsvConverter();
    private String headerLine = Stream.of(DeclarationHeaderCsvConverter.HEADERS).collect(joining(","));

    @Before
    public void setup() {
        initMocks(this);
        headers = new HttpHeaders();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
    }

    @Test
    public void shouldAddMediaTypeHeader() throws IOException {
        whenGivenOutput(EMPTY_LIST);
        converter.writeInternal(DeclarationSearchResult.builder().declarations(EMPTY_LIST).build(), mockHttpOutputMessage);

        assertThat(headers.getContentType(), is(equalTo(MediaType.valueOf("text/csv"))));
    }

    @Test
    public void shouldReturnHeaderWithNoResults() throws IOException {
        ByteArrayOutputStream output = whenGivenOutput(EMPTY_LIST);
        converter.writeInternal(DeclarationSearchResult.builder().declarations(EMPTY_LIST).build(), mockHttpOutputMessage);

        assertThat(output.toString(), is(equalTo(headerLine + "\n")));
    }

    @Test
    public void shouldReturnHeaderWithResults() throws IOException {
        ByteArrayOutputStream output = whenGivenOutput(EMPTY_LIST);
        DeclarationSearchResult result = DeclarationSearchResult.builder()
                .declarations(asList(
                    Declaration.builder().build(),
                    Declaration.builder()
                            .declarationId("Declaration ID")
                            .declarationSource("Declaration Source")
                            .importExportIndicator("Import/Export")
                            .epuNumber("Epu Number")
                            .entryNumber("Entry Number")
                            .entryDate("Entry Date")
                            .acceptanceDate("Acceptance Date")
                            .route("Route")
                            .dispatchCountry(Country.builder().code("Dispatch Country").build())
                            .destinationCountry(Country.builder().code("Destination Country").build())
                            .declarationCurrency("Duty Currency")
                            .totalDuty("Total Duty")
                            .consignee(Trader.builder().eori("Consignee EORI").name("Consignee Name").postcode("Consignee Postcode").build())
                            .consignor(Trader.builder().eori("Consignor EORI").name("Consignor Name").postcode("Consignor Postcode").build())
                            .declarant(Trader.builder().eori("Declarant EORI").name("Declarant Name").postcode("Declarant Postcode").build())
                            .goodsLocation("Goods Location")
                            .transportModeCode("Transport Mode")
                            .inlandTransportMode("Inland Transport Mode")
                            .transportId("Transport ID")
                            .placeOfLoading("Place Of Loading")
                            .premisesId("Premises ID")
                            .totalPackages("Total Packages")
                            .invoiceCurrency("Invoice Currency")
                            .invoiceTotal("Invoice Total")
                            .grossMass("Gross Mass")
                            .declarationType("Declaration Type")
                            .processingStatus("Processing Status")
                            .declarantRepresentation("Declarant Representation")
                            .communicationId("Communication ID")
                            .build()
                ))
                .build();
        converter.writeInternal(result, mockHttpOutputMessage);

        assertThat(output.toString(), is(equalTo(
                headerLine + "\n" +
                        ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,\n" +
                        "Declaration ID,Import/Export,Declaration Source,Declaration Type,Processing Status,Entry Date,Epu Number," +
                        "Entry Number,Acceptance Date,Route,Goods Location,Dispatch Country,Destination Country," +
                        "Place Of Loading,Transport Mode,Inland Transport Mode,Transport ID,Premises ID," +
                        "Total Packages,Gross Mass,Invoice Currency,Invoice Total,Duty Currency,Total Duty,Consignee EORI,Consignee Name," +
                        "Consignee Postcode,Consignor EORI,Consignor Name,Consignor Postcode,Declarant EORI,Declarant Name," +
                        "Declarant Postcode,Declarant Representation,Communication ID\n"
        )));
    }

    @Test
    public void shouldReturnHeaderWithResultsForFilteredFields() throws IOException {
        ByteArrayOutputStream output = whenGivenOutput(asList("declarationId","entryNumber","declarationSource"));
        DeclarationSearchResult result = DeclarationSearchResult.builder()
                .declarations(asList(
                        Declaration.builder().build(),
                        Declaration.builder()
                                .declarationId("dec-id")
                                .declarationSource("dec-source")
                                .importExportIndicator("Import/Export")
                                .epuNumber("Epu Number")
                                .entryNumber("entry-number")
                                .entryDate("Entry Date")
                                .acceptanceDate("Acceptance Date")
                                .route("Route")
                                .goodsLocation("Goods Location")
                                .transportModeCode("Transport Mode")
                                .inlandTransportMode("Inland Transport Mode")
                                .transportId("Transport ID")
                                .placeOfLoading("Place Of Loading")
                                .premisesId("Premises ID")
                                .totalPackages("Total Packages")
                                .invoiceCurrency("Invoice Currency")
                                .invoiceTotal("Invoice Total")
                                .grossMass("Gross Mass")
                                .declarationType("Declaration Type")
                                .processingStatus("Processing Status")
                                .declarantRepresentation("Declarant Representation")
                                .communicationId("Communication ID")
                                .build()
                ))
                .build();
        converter.writeInternal(result, mockHttpOutputMessage);

        assertThat(output.toString(), is(equalTo(
                "Declaration ID,Declaration Source,Entry Number\n" +
                        ",,\n" +
                        "dec-id,dec-source,entry-number\n"
        )));
    }

}
