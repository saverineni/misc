package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.junit.Before;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLine;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.elasticsearch.common.xcontent.XContentType.JSON;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.TermsBucketMatchers.termsBucket;

@SuppressWarnings("unchecked")
public class CPCFacetAggregationIT extends CustomsSearchESIntegTestCase {

    private static final String CUSTOMS_INDEX = "CPCFacetAggregationIT".toLowerCase();

    private static final SearchCriteria SEARCH_CRITERIA = new SearchCriteria();
    private static final String CPC = "cpc";

    private static final String CPC_CODE_1 = "1211122";
    private static final String CPC_CODE_2 = "3322116";

    private static final String CPC_CODE_3 = "1234567";
    private static final String CPC_CODE_4 = "2235648";

    private ObjectMapper objectMapper = new ObjectMapper();

    @Before
    public void setUp() throws Exception {
        super.setUp(CUSTOMS_INDEX);
        createCustomsIndexWithDocuments();
    }

    @Test
    public void returnsAllCPCsForAnEmptyPrefix() {
        SearchResponse searchResponse = this.service.facetSearch(SEARCH_CRITERIA, CPC, Optional.empty());
        assertThat(searchResponse.getHits().totalHits, is(3L));

        Terms termsAggregation = searchResponse.getAggregations().get("facets");
        assertThat(termsAggregation.getBuckets(), containsInAnyOrder(
                termsBucket(CPC_CODE_1, 1),
                termsBucket(CPC_CODE_2, 1),
                termsBucket(CPC_CODE_3, 1),
                termsBucket(CPC_CODE_4, 1)
        ));
    }

    @Test
    public void returnsAllCPCs() {
        SearchResponse searchResponse = this.service.facetSearch(SEARCH_CRITERIA, CPC, Optional.of("*******"));
        assertThat(searchResponse.getHits().totalHits, is(3L));

        Terms termsAggregation = searchResponse.getAggregations().get("facets");
        assertThat(termsAggregation.getBuckets(), containsInAnyOrder(
                termsBucket(CPC_CODE_1, 1),
                termsBucket(CPC_CODE_2, 1),
                termsBucket(CPC_CODE_3, 1),
                termsBucket(CPC_CODE_4, 1)
        ));
    }


    @Test
    public void returnsMultiMatchCPCs() {
        SearchResponse searchResponse = this.service.facetSearch(SEARCH_CRITERIA,CPC, Optional.of("12*****"));
        assertThat(searchResponse.getHits().totalHits, is(2L));

        Terms termsAggregation = searchResponse.getAggregations().get("facets");
        assertThat(termsAggregation.getBuckets(), containsInAnyOrder(
                termsBucket(CPC_CODE_1, 1),
                termsBucket(CPC_CODE_2, 1),
                termsBucket(CPC_CODE_3, 1)
        ));
    }

    @Test
    public void returnsMatchingCPC() {
        SearchResponse searchResponse = this.service.facetSearch(SEARCH_CRITERIA,CPC, Optional.of("****12*"));
        assertThat(searchResponse.getHits().totalHits, is(1L));

        Terms termsAggregation = searchResponse.getAggregations().get("facets");
        assertThat(termsAggregation.getBuckets(), containsInAnyOrder(
                termsBucket(CPC_CODE_1, 1),
                termsBucket(CPC_CODE_2, 1)
        ));
    }

    @Test
    public void returnsExactMatchCPC() {
        SearchResponse searchResponse = this.service.facetSearch(SEARCH_CRITERIA,CPC, Optional.of("2235648"));
        assertThat(searchResponse.getHits().totalHits, is(1L));

        Terms termsAggregation = searchResponse.getAggregations().get("facets");
        assertThat(termsAggregation.getBuckets(), contains(
                termsBucket(CPC_CODE_4, 1)
        ));
    }


    private void createCustomsIndexWithDocuments() throws Exception {
        createIndex(CUSTOMS_INDEX);

        BulkRequest request = new BulkRequest();
        addDeclaration(request, newDeclaration("dec-id-1", CPC_CODE_1, CPC_CODE_2));
        addDeclaration(request, newDeclaration("dec-id-2", CPC_CODE_3));
        addDeclaration(request, newDeclaration("dec-id-3", CPC_CODE_4));

        client.bulk(request);

        refresh(CUSTOMS_INDEX);
    }

    private void addDeclaration(BulkRequest request, Declaration declaration) throws JsonProcessingException {
        request.add(new IndexRequest(CUSTOMS_INDEX, DECLARATION_TYPE, declaration.getDeclarationId())
                .source(objectMapper.writer().writeValueAsString(declaration), JSON));
    }

    private Declaration newDeclaration(String id, String ... cpcCodes) {
        return Declaration.builder()
                .declarationId(id)
                .lines(
                        Stream.of(cpcCodes)
                                .map(code -> DeclarationLine.builder()
                                        .cpc(code)
                                        .build())
                                .collect(Collectors.toList()))
                .build();
    }
}
