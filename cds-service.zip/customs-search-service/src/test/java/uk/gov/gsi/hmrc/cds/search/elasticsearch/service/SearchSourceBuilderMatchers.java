package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.hamcrest.FeatureMatcher;
import org.hamcrest.Matcher;

import com.jayway.jsonpath.JsonPath;

public class SearchSourceBuilderMatchers {

    private static final String aggregationsPath = "$.aggregations.facets.terms.field";

    private static Matcher<SearchSourceBuilder> fieldValue(String jsonPath, Matcher<Object> expectedValue) {
        return new FeatureMatcher<SearchSourceBuilder, Object>(expectedValue, jsonPath, jsonPath) {

            @Override
            protected Object featureValueOf(SearchSourceBuilder searchSourceBuilder) {
                return JsonPath.read(searchSourceBuilder.toString(), jsonPath);
            }
        };
    }

    public static Matcher<SearchSourceBuilder> facets(Matcher<Object> expectedValue) {
        return fieldValue(aggregationsPath , expectedValue);
    }
}
