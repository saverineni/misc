package uk.gov.gsi.hmrc.cds.search.api.converters;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.Trader;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLineRoute;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLineTaxLine;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.MockitoAnnotations.initMocks;

public class DeclarationLineCsvConverterTest extends CSVConverterTest{

    private DeclarationLineCsvConverter converter = new DeclarationLineCsvConverter();
    private String headerLine = Stream.of(DeclarationLineCsvConverter.HEADERS).collect(Collectors.joining(","));

    @Before
    public void setup() {
        initMocks(this);
        headers = new HttpHeaders();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
    }

    @Test
    public void shouldAddMediaTypeHeader() throws IOException {
        whenGivenOutput(EMPTY_LIST);
        converter.writeInternal(Declaration.builder().build(), mockHttpOutputMessage);

        assertThat(headers.getContentType(), is(equalTo(MediaType.valueOf("text/csv"))));
    }

    @Test
    public void shouldReturnHeaderLineWithNoResults() throws IOException {
        ByteArrayOutputStream output = whenGivenOutput(EMPTY_LIST);
        converter.writeInternal(Declaration.builder().build(), mockHttpOutputMessage);

        assertThat(output.toString(), is(equalTo(headerLine + "\n")));
    }


    @Test
    public void shouldReturnHeaderLineWithResults() throws IOException {
        DeclarationLineTaxLine taxLine1 = DeclarationLineTaxLine.builder().taxLineSequenceNumber("1").taxAmount("100") .build();
        DeclarationLineTaxLine taxLine2 = DeclarationLineTaxLine.builder().taxLineSequenceNumber("2").taxAmount("200") .build();
        DeclarationLineTaxLine taxLine3 = DeclarationLineTaxLine.builder().taxLineSequenceNumber("3").taxAmount("300") .build();

        DeclarationLineRoute route1 = DeclarationLineRoute.builder().routeCountryCode("UK").routeSequenceNumber("1").build();
        DeclarationLineRoute route2 = DeclarationLineRoute.builder().routeCountryCode("IN").routeSequenceNumber("2").build();

        ByteArrayOutputStream output = whenGivenOutput(EMPTY_LIST);
        Declaration result = Declaration.builder()
                .declarationId("declarationId")
                .importExportIndicator("importExport")
                .declarationSource("declarationSource")
                .declarationType("declarationType")
                .lines(asList(
                        DeclarationLine.builder()
                                .itemNumber(1)
                                .taxLines(asList(taxLine1,taxLine2))
                                .routes(asList(route1))
                                .build(),
                        DeclarationLine.builder()
                                .itemNumber(2)
                                .taxLines(asList(taxLine3))
                                .routes(asList(route2))
                                .itemRoute("itemRoute")
                                .itemDispatchCountry(Country.builder().code("itemDispatchCountry").build())
                                .itemDestinationCountry(Country.builder().code("itemDestinationCountry").build())
                                .clearanceDate("clearanceDate")
                                .cpc("cpc")
                                .originCountry(Country.builder().code("originCountry").build())
                                .commodityCode("commodityCode")
                                .itemConsignee(Trader.builder().eori("itemConsigneeEori").name("itemConsigneeName").postcode("itemConsigneePostcode").build())
                                .itemConsignor(Trader.builder().eori("itemConsignorEori").name("itemConsignorName").postcode("itemConsignorPostcode").build())
                                .itemDeclarant(Trader.builder().eori("itemDeclarantEori").name("itemDeclarantName").postcode("itemDeclarantPostcode").build())
                                .goodsDescription("goodsDescription")
                                .grossMass("grossMass")
                                .preferenceNumber("preferenceNumber")
                                .netMass("netMass")
                                .quotaNumber("quotaNumber")
                                .supplementaryUnits("supplementaryUnits")
                                .itemPrice("itemPrice")
                                .invoiceCurrency("invoiceCurrency")
                                .valuationMethod("valuationMethod")
                                .valuationAdjustmentCode("valuationAdjustmentCode")
                                .valuationAdjustmentAmount("valuationAdjustmentAmount")
                                .valuationAdjustmentCurrency("valuationAdjustmentCurrency")
                                .statisticalValue("statisticalValue")
                                .build()
                ))
                .build();
        converter.writeInternal(result, mockHttpOutputMessage);

        assertThat(output.toString(), is(equalTo(
                headerLine + "\n" +
                        "1,declarationId,importExport,declarationSource,declarationType,,,,,,,,,,,,,,,,,,,,,,,,,,,,,\n" +
                        "2,declarationId,importExport,declarationSource,declarationType,itemRoute,cpc,clearanceDate," +
                        "originCountry,itemDispatchCountry,itemDestinationCountry," +
                        "goodsDescription,grossMass,netMass,quotaNumber,preferenceNumber,supplementaryUnits," +
                        "invoiceCurrency,itemPrice," +
                        "statisticalValue,commodityCode,valuationMethod,valuationAdjustmentCode,valuationAdjustmentCurrency," +
                        "valuationAdjustmentAmount," +
                        "itemConsigneeEori,itemConsigneeName,itemConsigneePostcode," +
                        "itemConsignorEori,itemConsignorName,itemConsignorPostcode,itemDeclarantEori,itemDeclarantName,itemDeclarantPostcode\n" +
                        "\n" +
                        "Tax Lines\n" +
                        "Item Number,Tax Sequence Number,Tax Type Code,Tax Base (Amount),Tax Base (Amount) Calculated,Tax Base (Quantity),Tax Rate Identifier,Tax Override Code,Tax Amount,Tax Amount Calculated,Method Of Payment Code,Declared or Calculated\n" +
                        "1,1,,,,,,,100,,,\n" +
                        "1,2,,,,,,,200,,,\n" +
                        "2,3,,,,,,,300,,,\n" +
                        "\n" +
                        "Routes\n" +
                        "Item Number,Route Sequence Number,Route Country Code\n" +
                        "1,1,UK\n" +
                        "2,2,IN\n"
        )));
    }

    @Test
    public void shouldReturnHeaderLineWithResultsForFilteredFields() throws IOException {
        ByteArrayOutputStream output = whenGivenOutput(asList("declarationId","itemDestinationCountry"));
        Declaration result = Declaration.builder()
                .declarationId("declarationId")
                .importExportIndicator("importExport")
                .declarationSource("declarationSource")
                .declarationType("declarationType")
                .lines(asList(
                        DeclarationLine.builder()
                                .itemNumber(1)
                                .build(),
                        DeclarationLine.builder()
                                .itemNumber(2)
                                .itemRoute("itemRoute")
                                .itemDispatchCountry(Country.builder().code("itemDispatchCountry").build())
                                .itemDestinationCountry(Country.builder().code("itemDestinationCountry").build())
                                .build()
                ))
                .build();
        converter.writeInternal(result, mockHttpOutputMessage);

        assertThat(output.toString(), is(equalTo(
                "Item Number,Declaration ID,Country Of Final Destination\n" +
                        "1,declarationId,\n" +
                        "2,declarationId,itemDestinationCountry\n"
        )));
    }

}
