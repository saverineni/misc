package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import static com.google.common.collect.Lists.newArrayList;
import static java.util.Arrays.asList;
import static java.util.Optional.empty;
import static org.elasticsearch.common.xcontent.XContentType.JSON;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.TermsBucketMatchers.termsBucket;

import java.util.Optional;

import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLine;

@SuppressWarnings("unchecked")
public class PreferenceNumberFacetAggregationIT extends CustomsSearchESIntegTestCase {

    private static final String CUSTOMS_INDEX = PreferenceNumberFacetAggregationIT.class.getSimpleName().toLowerCase();

    private static final String COUNTRY_CODE_GB = "GB";
    private static final String COUNTRY_CODE_FR = "FR";
    private static final String PREFERENCE_NUMBER_1 = "123";
    private static final String PREFERENCE_NUMBER_2 = "234";
    private static final String PREFERENCE_NUMBER_3 = "345";
    private static final String PREFERENCE_NUMBER_4 = "134";

    private ObjectMapper objectMapper = new ObjectMapper();

    @Before
    public void setUp() throws Exception {
        super.setUp(CUSTOMS_INDEX);
        createCustomsIndexWithDocuments();
    }

    @Test
    public void returnsAllPreferenceNumberFacets() {
        SearchResponse searchResponse = service.facetSearch(newSearchCriteria(), "preferenceNumber", empty());
        assertThat(searchResponse.getHits().totalHits, is(4L));

        Terms termsAggregation = searchResponse.getAggregations().get("facets");
        assertThat(termsAggregation.getBuckets(), containsInAnyOrder(
            termsBucket(PREFERENCE_NUMBER_1, 1),
            termsBucket(PREFERENCE_NUMBER_2, 1),
            termsBucket(PREFERENCE_NUMBER_3, 1),
            termsBucket(PREFERENCE_NUMBER_4, 1)
        ));
    }

    @Test
    public void returnsPrefenceNumberFacetsForCriteria() {
        SearchResponse searchResponse = this.service.facetSearch(newSearchCriteria(COUNTRY_CODE_GB), "preferenceNumber", empty());
        assertThat(searchResponse.getHits().totalHits, is(3L));

        Terms termsAggregation = searchResponse.getAggregations().get("facets");
        assertThat(termsAggregation.getBuckets(), containsInAnyOrder(
                termsBucket(PREFERENCE_NUMBER_1, 1),
                termsBucket(PREFERENCE_NUMBER_3, 1),
                termsBucket(PREFERENCE_NUMBER_4, 1)
        ));
    }

    @Test
    public void returnsAllPreferenceNumberFacetsWithPrefix() {
        SearchResponse searchResponse = this.service.facetSearch(newSearchCriteria(), "preferenceNumber", Optional.of("1"));
        assertThat(searchResponse.getHits().totalHits, is(2L));

        Terms termsAggregation = searchResponse.getAggregations().get("facets");
        assertThat(termsAggregation.getBuckets(), contains(
            termsBucket(PREFERENCE_NUMBER_1, 1),
            termsBucket(PREFERENCE_NUMBER_4, 1)
        ));
    }

    private SearchCriteria newSearchCriteria(String... dispatchCountryCodes) {
        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setSearchTerm("");
        if (dispatchCountryCodes.length > 0) {
            searchCriteria.setDispatchCountryCode(asList(dispatchCountryCodes));
        }
        return searchCriteria;
    }

    private void createCustomsIndexWithDocuments() throws Exception {
        createIndex(CUSTOMS_INDEX);

        BulkRequest request = new BulkRequest();
        addDeclaration(request, newDeclaration("dec-id-1", COUNTRY_CODE_GB, PREFERENCE_NUMBER_1));
        addDeclaration(request, newDeclaration("dec-id-2", COUNTRY_CODE_FR, PREFERENCE_NUMBER_2));
        addDeclaration(request, newDeclaration("dec-id-3", COUNTRY_CODE_GB, PREFERENCE_NUMBER_3));
        addDeclaration(request, newDeclaration("dec-id-4", COUNTRY_CODE_GB, PREFERENCE_NUMBER_4));

        client.bulk(request);

        refresh(CUSTOMS_INDEX);
    }

    private void addDeclaration(BulkRequest request, Declaration declaration) throws JsonProcessingException {
        request.add(new IndexRequest(CUSTOMS_INDEX, DECLARATION_TYPE, declaration.getDeclarationId())
                .source(objectMapper.writer().writeValueAsString(declaration), JSON));
    }

    private Declaration newDeclaration(String id, String dispatchCountryCode, String preferenceNumber) {
        return Declaration.builder()
                .declarationId(id)
                .dispatchCountry(Country.builder().code(dispatchCountryCode).build())
                .lines(
                        newArrayList(
                                DeclarationLine.builder()
                                        .preferenceNumber(preferenceNumber)
                                        .build()
                        )
                )
                .build();
    }
}
