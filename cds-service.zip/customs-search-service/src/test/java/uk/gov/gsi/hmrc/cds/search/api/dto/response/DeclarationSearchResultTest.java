package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;

import java.util.List;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

public class DeclarationSearchResultTest {

    private static final String DECLARATION_ID = "id";
    private static final String IMPORT_EXPORT_INDICATOR = "export";
    private static final String DECLARATION_SOURCE = "source";
    private static final String ENTRY_DATE = "date";
    private static final String ROUTE = "route";
    private static final String GOODS_LOCATION = "goods";
    private static final Country DISPATCH_COUNTRY = Country.builder().code("dispatch").build();
    private static final Country DESTINATION_COUNTRY = Country.builder().code("destination").build();
    private static final String TRANSPORT_MODE_CODE = "transport";

    private final Declaration declaration = Declaration.builder()
            .declarationId(DECLARATION_ID)
            .importExportIndicator(IMPORT_EXPORT_INDICATOR)
            .declarationSource(DECLARATION_SOURCE)
            .entryDate(ENTRY_DATE)
            .route(ROUTE)
            .goodsLocation(GOODS_LOCATION)
            .dispatchCountry(DISPATCH_COUNTRY)
            .destinationCountry(DESTINATION_COUNTRY)
            .transportModeCode(TRANSPORT_MODE_CODE)
            .lines(emptyList())
            .build();

    private final DeclarationPreview preview = DeclarationPreview.builder()
            .declarationId(DECLARATION_ID)
            .importExportIndicator(IMPORT_EXPORT_INDICATOR)
            .declarationSource(DECLARATION_SOURCE)
            .entryDate(ENTRY_DATE)
            .route(ROUTE)
            .goodsLocation(GOODS_LOCATION)
            .dispatchCountry(DISPATCH_COUNTRY)
            .destinationCountry(DESTINATION_COUNTRY)
            .transportModeCode(TRANSPORT_MODE_CODE)
            .lineCount(0)
            .build();

    @Test
    public void getDeclarationPreviewsShouldReturnListOfPreviews() {
        DeclarationSearchResult result = DeclarationSearchResult.builder().declarations(asList(declaration, declaration)).build();
        List<DeclarationPreview> previews = asList(preview, preview);
        assertThat(result.getDeclarationPreviews(), is(equalTo(previews)));
    }

    @Test
    public void getDeclarationPreviewsShouldHandleNullList() {
        DeclarationSearchResult result = DeclarationSearchResult.builder().build();
        assertThat(result.getDeclarations(), is(nullValue()));
        assertThat(result.getDeclarationPreviews(), hasSize(0));
    }

}