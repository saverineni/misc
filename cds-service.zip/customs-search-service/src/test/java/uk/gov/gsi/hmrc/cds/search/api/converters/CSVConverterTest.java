package uk.gov.gsi.hmrc.cds.search.api.converters;

import org.mockito.Mock;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpOutputMessage;
import org.springframework.mock.web.MockHttpServletRequest;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import static java.util.Collections.emptyList;
import static org.mockito.Mockito.when;

public class CSVConverterTest {

    final List EMPTY_LIST = emptyList();

    @Mock
    HttpOutputMessage mockHttpOutputMessage;

    @Mock
    MockHttpServletRequest request;

    HttpHeaders headers;

    ByteArrayOutputStream whenGivenOutput(List fields) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        when(request.getAttribute("fields")).thenReturn(fields);
        when(mockHttpOutputMessage.getBody()).thenReturn(output);
        when(mockHttpOutputMessage.getHeaders()).thenReturn(headers);
        return output;
    }
}
