package uk.gov.gsi.hmrc.cds.search.filter;

import javax.servlet.FilterChain;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.text.MatchesPattern.matchesPattern;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CorrelationIdFilterTest {

    private static final String UUID_REGEX= "[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}";

    private static final String CORRELATION_ID = "correlation-id";

    CorrelationIdFilter filter = new CorrelationIdFilter();

    @Mock
    private FilterChain chain;
    @Mock
    private HttpServletRequest request;
    @Mock
    private ServletResponse response;

    @Test
    public void shouldCallTheNextFilterInTheChain() throws Exception {
        filter.doFilter(request, response, chain);
        verify(chain).doFilter(request, response);
    }

    @Test
    public void shouldAddTheCorrelationIdToTheLoggerMDC() throws Exception {
        when(request.getHeader("X-Correlation-ID")).thenReturn(CORRELATION_ID);
        filter.populateMDCWithCorrelationId(request);
        assertThat(MDC.get(CorrelationIdFilter.MDC_CORRELATION_ID), is(CORRELATION_ID));
    }

    @Test
    public void shouldGenerateTheCorrelationIdIfNotPresentInTheRequest() throws Exception {
        filter.populateMDCWithCorrelationId(request);
        assertThat(MDC.get(CorrelationIdFilter.MDC_CORRELATION_ID), matchesPattern(UUID_REGEX));
    }

    @Test
    public void clearsCorrelationIdFromMDC() throws Exception {
        when(request.getHeader("X-Correlation-ID")).thenReturn(CORRELATION_ID);
        filter.doFilter(request, null, chain);
        assertNull(MDC.get(CorrelationIdFilter.MDC_CORRELATION_ID));
    }
}
