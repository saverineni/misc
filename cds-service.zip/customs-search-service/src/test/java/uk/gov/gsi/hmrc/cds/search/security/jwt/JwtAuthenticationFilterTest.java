package uk.gov.gsi.hmrc.cds.search.security.jwt;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class JwtAuthenticationFilterTest {
    JwtAuthenticationFilter filter = new JwtAuthenticationFilter();

    HttpServletRequest request = mock(HttpServletRequest.class);
    HttpServletResponse response = mock(HttpServletResponse.class);
    FilterChain filterChain = mock(FilterChain.class);

    @Before
    public void clearSecurityContext() {
        SecurityContextHolder.clearContext();
    }

    @After
    public void shouldCallFilterChainOnEveryInvocation() throws IOException, ServletException {
        verify(filterChain).doFilter(request, response);
    }

    @Test
    public void shouldNotUpdateSecurityContextOnEmptyAuthorizationHeader() throws Exception {
        when(request.getHeader("Authorization")).thenReturn(null);

        filter.doFilterInternal(request, response, filterChain);

        assertThat(SecurityContextHolder.getContext().getAuthentication(), is(nullValue()));
    }

    @Test
    public void invalidTokenFormatShouldNotSetAuthenticationToTheSecurityContext() throws Exception {
        when(request.getHeader("Authorization")).thenReturn("invalid format");

        filter.doFilterInternal(request, response, filterChain);

        assertThat(SecurityContextHolder.getContext().getAuthentication(), is(nullValue()));
    }

    @Test
    public void validAuthenticationTokenShouldUpdateTheSecurityContext() throws Exception {
        when(request.getHeader("Authorization")).thenReturn("Bearer my.token.value");

        filter.doFilterInternal(request, response, filterChain);

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        JwtAuthenticationToken expectedAuthentication = new JwtAuthenticationToken("my.token.value");
        assertThat(authentication, is(expectedAuthentication));
    }
}
