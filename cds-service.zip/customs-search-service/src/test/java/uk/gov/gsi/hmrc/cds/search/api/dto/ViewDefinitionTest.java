package uk.gov.gsi.hmrc.cds.search.api.dto;

import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.definition.ViewDefinition;

import java.util.List;
import java.util.stream.Stream;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

public class ViewDefinitionTest {

    @Test
    public void orderedViewDefinitionsShouldOnlyReturnViewDefinitionFields() {
        List<ViewDefinition> definitions = ViewDefinition.Utils.orderedViewDefinitions(Declaration.class , FALSE);

        for (ViewDefinition definition : definitions) {
            assertThat(definition, is(notNullValue()));
        }
    }

    @Test
    public void orderedViewDefinitionsShouldReturnSortedFields() {
        List<ViewDefinition> definitions = ViewDefinition.Utils.orderedViewDefinitions(Declaration.class , FALSE);

        for (int i = 0; i < definitions.size() - 1; i++) {
            assertThat(definitions.get(i).order() <= definitions.get(i + 1).order(), is(true));
        }
    }

    @Test
    public void orderedViewDefinitionsShouldReturnRepeatedFields() {

        List<ViewDefinition> definitions = ViewDefinition.Utils.orderedViewDefinitions(Declaration.class , FALSE);

        assertThat(definitions.get(24).id(), is(equalTo("consignee")));
        assertThat(definitions.get(25).id(), is(equalTo("consignee")));
        assertThat(definitions.get(26).id(), is(equalTo("consignee")));
    }

    @Test
    public void orderedViewDefinitionsShouldReturnWithNestedViewDefinitionFields() {
        List<ViewDefinition> definitions = ViewDefinition.Utils
                .orderedViewDefinitionFields(DeclarationLine.class , emptyList() , TRUE)
                .flatMap(field -> Stream.of(field.getAnnotationsByType(ViewDefinition.class)))
                .collect(toList());

        assertThat(definitions.size(), is(59));

        assertThat(definitions.get(29).id(), is(equalTo("taxLines")));
        assertThat(definitions.get(41).id(), is(equalTo("routes")));
        assertThat(definitions.get(44).id(), is(equalTo("additionalInfo")));
        assertThat(definitions.get(48).id(), is(equalTo("previousDocuments")));
        assertThat(definitions.get(51).id(), is(equalTo("containers")));
        assertThat(definitions.get(54).id(), is(equalTo("packages")));
    }

}