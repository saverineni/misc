package uk.gov.gsi.hmrc.cds.search.elasticsearch.query;

import static java.util.Arrays.asList;
import static java.util.Optional.of;
import static org.elasticsearch.index.query.QueryBuilders.boolQuery;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.sameInstance;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchSourceBuilderMatchers.facets;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;

public class SearchQuerySourceTest {
    
    private SearchQueryBuilder builder = mock(SearchQueryBuilder.class);
    private SearchQuerySource searchQuerySource = new SearchQuerySource() {
        SearchQueryBuilder newSearchQueryBuilder() {
            return builder;
        }
    };
    private SearchCriteria searchCriteria;

    private static final String SEARCH_TERM = "122";
    private static final String EORI = "582109443894367";
    private static final String IN_CODE = "IN";
    private static final String NZ_CODE = "NZ";
    private static final String CA_CODE = "CA";
    private static final String CH_CODE = "CH";
    private static final String ABC_GOODS_LOCATION = "ABC";
    private static final String DEF_GOODS_LOCATION = "DEF";
    private static final String COMMODITY_CODE_1 = "0123456789";
    private static final String COMMODITY_CODE_2 = "9876543210";
    private static final String CPC_CODE_1 = "1111122222";
    private static final String CPC_CODE_2 = "3355116699";
    private static final List<String> DEC_TYPES = Arrays.asList("X","Y");
    private static final String DEC_SOURCE = "DMS";
    private static final LocalDate FROM_DATE_1 = LocalDate.of(2018, 1, 6);
    private static final LocalDate TO_DATE_1 = LocalDate.of(2018, 1, 7);
    private static final LocalDate FROM_DATE_2 = LocalDate.of(2018, 2, 6);
    private static final LocalDate TO_DATE_2 = LocalDate.of(2018, 2, 7);
    private static final LocalDate FROM_DATE_3 = LocalDate.of(2018, 3, 6);
    private static final LocalDate TO_DATE_3 = LocalDate.of(2018, 3, 7);
    private static final String TMC_1 = "transportMode2";
    private static final String TMC_2 = "transportMode2";
    private static final String NET_MASS_FROM = "1234";
    private static final String NET_MASS_TO = "2345";
    private static final String ITEM_PRICE_FROM = "1234";
    private static final String ITEM_PRICE_TO = "2345";
    private static final String PREFERENCE_NUMBER = "123";
    private static final String PROCESSING_STATUS = "16";

    BoolQueryBuilder theQuery = boolQuery();
    
    @Before
    public void setUp() {
        when(builder.withFieldValues(Mockito.any(), Mockito.any())).thenReturn(builder);
        when(builder.withMultiMatchField(Mockito.any(), Mockito.any())).thenReturn(builder);
        when(builder.withDateRange(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(builder);
        when(builder.withRange(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(builder);
        when(builder.withFieldRegex(Mockito.any(), Mockito.any())).thenReturn(builder);
        when(builder.toQueryBuilder()).thenReturn(theQuery);
        
        searchCriteria = new SearchCriteria();
    }

    @Test
    public void facetFieldNameForLineFacets() {
        assertEquals(searchQuerySource.getFacetFieldName("originCountryCode"), "lines.originCountryCode.prefix");
        assertEquals(searchQuerySource.getFacetFieldName("commodityCode"), "lines.commodityCode.prefix");
        assertEquals(searchQuerySource.getFacetFieldName("cpc"), "lines.cpc.prefix");
    }

    @Test
    public void facetFieldNameForOtherFacets() {
        assertEquals(searchQuerySource.getFacetFieldName("dispatchCountryCode"), "dispatchCountryCode.prefix");
    }

    @Test
    public void paginatedQueryShouldAddSearchCriteriaValues() {
        setSearchCriteria(searchCriteria);
        searchQuerySource.getQueryBuilderWithPagination(searchCriteria);
        assertSearchCriteriaAddedToQuery();
    }

    @Test
    public void builtPaginatedQueryShouldBeAddedToTheSource() {
        setSearchCriteria(searchCriteria);
        SearchSourceBuilder searchSourceBuilder = searchQuerySource.getQueryBuilderWithPagination(searchCriteria);
        
        assertThat(searchSourceBuilder.query(), sameInstance(theQuery));
    }


    @Test
    public void facetQueryShouldAddSearchCriteriaValues() {
        setSearchCriteria(searchCriteria);
        searchQuerySource.getQueryBuilderWithFacets(searchCriteria, "originCountryCode", Optional.empty());
        assertSearchCriteriaAddedToQuery();
    }

    @Test
    public void facetQueryShouldAddFacetToSearchSource() {
        setSearchCriteria(searchCriteria);
        SearchSourceBuilder searchSourceBuilder = searchQuerySource.getQueryBuilderWithFacets(searchCriteria, "originCountryCode", Optional.empty());
        assertThat(searchSourceBuilder,facets(equalTo("lines.originCountry.code")));
    }

    @Test
    public void facetQueryWithPrefixShouldAddMatchFacetToQuery() {
        setSearchCriteria(searchCriteria);
        searchQuerySource.getQueryBuilderWithFacets(searchCriteria, "originCountryCode", Optional.of("prefix"));
        verify(builder).withField("lines.originCountryCode.prefix", "prefix");
    }

    @Test
    public void facetQueryWithRegexPrefixShouldAddMatchFacetToQuery() {
        setSearchCriteria(searchCriteria);
        searchQuerySource.getQueryBuilderWithFacets(searchCriteria, "cpc", Optional.of("**prefix**"));
        verify(builder).withFieldRegex("lines.cpc", "..prefix..");
    }

    @Test
    public void shouldAddTheDateRangeValuesToTheQuery() {
        searchCriteria.setEntryDateFrom(FROM_DATE_1);
        searchCriteria.setEntryDateTo(TO_DATE_1);
        searchCriteria.setClearanceDateFrom(FROM_DATE_2);
        searchCriteria.setClearanceDateTo(TO_DATE_2);
        searchCriteria.setAcceptanceDateFrom(FROM_DATE_3);
        searchCriteria.setAcceptanceDateTo(TO_DATE_3);
        
        searchQuerySource.getQueryBuilderWithPagination(searchCriteria);
        
        verify(builder).withDateRange("entryDate", fromDate(FROM_DATE_1), toDate(TO_DATE_1));
        verify(builder).withDateRange("lines.clearanceDate", fromDate(FROM_DATE_2), toDate(TO_DATE_2));
        verify(builder).withDateRange("acceptanceDate", fromDate(FROM_DATE_3), toDate(TO_DATE_3));
    }


    @Test
    public void shouldAddValueRangeValuesToTheQuery() {
        searchCriteria.setNetMassFrom(NET_MASS_FROM);
        searchCriteria.setNetMassTo(NET_MASS_TO);
        searchCriteria.setItemPriceFrom(ITEM_PRICE_FROM);
        searchCriteria.setItemPriceTo(ITEM_PRICE_TO);

        searchQuerySource.getQueryBuilderWithPagination(searchCriteria);

        verify(builder).withRange("lines.netMass", of(NET_MASS_FROM), of(NET_MASS_TO));
        verify(builder).withRange("lines.itemPrice", of(ITEM_PRICE_FROM), of(ITEM_PRICE_TO));
    }


    private Optional<LocalDateTime> fromDate(LocalDate date) {
        return of(LocalDateTime.of(date, LocalTime.MIN));
    }
    
    private Optional<LocalDateTime> toDate(LocalDate date) {
        return of(LocalDateTime.of(date, LocalTime.MAX));
    }

    private void setSearchCriteria(SearchCriteria searchCriteria) {
        searchCriteria.setSearchTerm(SEARCH_TERM);
        searchCriteria.setEori(EORI);
        searchCriteria.setOriginCountryCode(asList(IN_CODE, NZ_CODE));
        searchCriteria.setDestinationCountryCode(asList(CA_CODE));
        searchCriteria.setDispatchCountryCode(asList(CH_CODE));
        searchCriteria.setGoodsLocation(asList(ABC_GOODS_LOCATION, DEF_GOODS_LOCATION));
        searchCriteria.setTransportModeCode(asList(TMC_1,TMC_2));
        searchCriteria.setCommodityCode(asList(COMMODITY_CODE_1, COMMODITY_CODE_2));
        searchCriteria.setCpc(asList(CPC_CODE_1, CPC_CODE_2));
        searchCriteria.setDeclarationType(DEC_TYPES);
        searchCriteria.setDeclarationSource(asList(DEC_SOURCE));
        searchCriteria.setPreferenceNumber(asList(PREFERENCE_NUMBER));
        searchCriteria.setProcessingStatus(asList(PROCESSING_STATUS));
    }

    private void assertSearchCriteriaAddedToQuery() {
        verify(builder).withMultiMatchField(asList(
                "declarationId",
                "epuNumber",
                "entryNumber",
                "consignee.name",
                "consignee.postcode",
                "consignor.name",
                "consignor.postcode",
                "declarant.name",
                "declarant.postcode",
                "lines.commodityCode",
                "lines.originCountry.code.codeText",
                "lines.cpc",
                "lines.itemConsignee.name",
                "lines.itemConsignee.postcode",
                "lines.itemConsignor.name",
                "lines.itemConsignor.postcode",
                "lines.itemDeclarant.name",
                "lines.itemDeclarant.postcode",
                "lines.preferenceNumber",
                "consignee.eori",
                "consignor.eori",
                "declarant.eori",
                "lines.itemConsignee.eori",
                "lines.itemConsignor.eori",
                "lines.itemDeclarant.eori"), SEARCH_TERM);

        verify(builder).withMultiMatchField(asList(
                "consignee.eori",
                "consignor.eori",
                "declarant.eori",
                "lines.itemConsignee.eori",
                "lines.itemConsignor.eori",
                "lines.itemDeclarant.eori"), EORI);

        verify(builder).withFieldValues("lines.originCountry.code", asList(IN_CODE, NZ_CODE));
        verify(builder).withFieldValues("dispatchCountry.code", asList(CH_CODE));
        verify(builder).withFieldValues("destinationCountry.code", asList(CA_CODE));
        verify(builder).withFieldValues("goodsLocation", asList(ABC_GOODS_LOCATION, DEF_GOODS_LOCATION));
        verify(builder).withFieldValues("transportModeCode", asList(TMC_1, TMC_2));
        verify(builder).withFieldValues("lines.commodityCode", asList(COMMODITY_CODE_1, COMMODITY_CODE_2));
        verify(builder).withFieldValues("lines.cpc", asList(CPC_CODE_1, CPC_CODE_2));
        verify(builder).withFieldValues("declarationType", DEC_TYPES);
        verify(builder).withFieldValues("lines.preferenceNumber", asList(PREFERENCE_NUMBER));
        verify(builder).withFieldValues("declarationSource", asList(DEC_SOURCE));
        verify(builder).withFieldValues("processingStatus", asList(PROCESSING_STATUS));
    }

}
