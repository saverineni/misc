package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import static org.elasticsearch.common.xcontent.XContentType.JSON;
import static org.junit.Assert.assertEquals;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchHitMatchers.declarationId;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchResponseAssert.assertSearchHits;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLine;

public class SearchClientNetMassIT extends CustomsSearchESIntegTestCase {

    private static final String CUSTOMS_INDEX = "SearchServiceNetMassIntegrationTest".toLowerCase();
    private static final String EPU = "EPU";

    private ObjectMapper objectMapper = new ObjectMapper();

    @Before
    public void setUp() throws Exception {
        super.setUp(CUSTOMS_INDEX);
        createCustomsIndexWithDocuments();
    }

    @Test
    public void searchWithNetMassFrom() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(
                "20.111", null
        ));
        assertSearchHits(searchResponse,
                declarationId("dec-id-3"),
                declarationId("dec-id-4"),
                declarationId("dec-id-6"));
    }

    @Test
    public void searchWithNetMassTo() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(
                null, "16"
        ));

        assertSearchHits(searchResponse,
                declarationId("dec-id-1"),
                declarationId("dec-id-2"));
    }

    @Test
    public void searchWithNetMassFromAndTo() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(
                "15", "20.222"
        ));

        assertSearchHits(searchResponse,
                declarationId("dec-id-2"),
                declarationId("dec-id-3"));
    }

    @Test
    public void searchWithNetMassWithFromAfterTo() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(
                "30", "10"
        ));

        assertEquals(searchResponse.getHits().totalHits, 0);
    }

    @Test
    public void searchWithNetMassWithSearchTerm() {
        SearchCriteria searchCriteria = newSearchCriteria(
                "12", "16"
        );
        searchCriteria.setSearchTerm(EPU);
        SearchResponse searchResponse = this.service.declarationSearch(searchCriteria);

        assertSearchHits(searchResponse,
                declarationId("dec-id-2"));
    }

    @Test
    public void searchWithoutNetMasses() {
        SearchCriteria searchCriteria = newSearchCriteria(null, null);
        SearchResponse searchResponse = this.service.declarationSearch(searchCriteria);

        assertSearchHits(searchResponse,
                declarationId("dec-id-1"),
                declarationId("dec-id-2"),
                declarationId("dec-id-3"),
                declarationId("dec-id-4"),
                declarationId("dec-id-5"),
                declarationId("dec-id-6"));
    }

    private SearchCriteria newSearchCriteria(String netMassFrom, String netMassTo) {
        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setNetMassFrom(netMassFrom);
        searchCriteria.setNetMassTo(netMassTo);
        return searchCriteria;
    }

    private void createCustomsIndexWithDocuments() throws Exception {
        createIndex(CUSTOMS_INDEX);

        BulkRequest request = new BulkRequest();
        addDeclaration(request, newDeclaration("dec-id-1", "10"));
        addDeclaration(request, newDeclaration("dec-id-2", "15"));
        addDeclaration(request, newDeclaration("dec-id-3", "20.222"));
        addDeclaration(request, newDeclaration("dec-id-4", "30.111"));
        addDeclaration(request, newDeclaration("dec-id-5"));
        addDeclaration(request, newDeclaration("dec-id-6", "22", "40.123"));

        client.bulk(request);

        refresh(CUSTOMS_INDEX);
    }

    private void addDeclaration(BulkRequest request, Declaration declaration) throws JsonProcessingException {
        request.add(new IndexRequest(CUSTOMS_INDEX, DECLARATION_TYPE, declaration.getDeclarationId())
                .source(objectMapper.writer().writeValueAsString(declaration), JSON));
    }


    private Declaration newDeclaration(String id, String... netMasses) {
        return Declaration.builder()
                .declarationId(id)
                .epuNumber(EPU)
                .lines(
                        Stream.of(netMasses)
                                .map(netMass -> DeclarationLine.builder()
                                        .netMass(netMass)
                                        .build()
                                )
                                .collect(Collectors.toList())
                )
                .build();
    }

}
