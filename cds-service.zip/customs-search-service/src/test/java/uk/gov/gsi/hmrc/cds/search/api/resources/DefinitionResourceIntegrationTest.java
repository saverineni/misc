package uk.gov.gsi.hmrc.cds.search.api.resources;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(value = DefinitionResource.class, secure = false)
@ActiveProfiles("test")
public class DefinitionResourceIntegrationTest {

    private static String ACCEPT = "application/json";

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void getDeclarationDefinitionOk() throws Exception {
        this.mockMvc
                .perform(get("/declarations/definition").accept(ACCEPT))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.definitions[0].id", is("declarationId")))
                .andExpect(jsonPath("$.definitions[0].header", is(true)))
                .andExpect(jsonPath("$.definitions[0].label", is("Declaration ID")))
                .andExpect(jsonPath("$.definitions[0].type", is("STRING")))
                .andExpect(jsonPath("$.definitions[0].path", is("")))
                .andExpect(jsonPath("$.definitions[5].type", is("TIMESTAMP")))
                .andExpect(jsonPath("$.definitions[11].path", is(".code")))
                .andExpect(jsonPath("$.definitions[34].tooltip", is("Click on the Conversation ID value to copy to clipboard.")))
                .andExpect(jsonPath("$.definitions[34].clickAction", is("COPY")))
                .andExpect(jsonPath("$.definitions", hasSize(35)));
    }

    @Test
    public void getDeclarationItemDefinitionOk() throws Exception {
        this.mockMvc
                .perform(get("/declarations/items/definition").accept(ACCEPT))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.definitions[0].id", is("itemRoute")))
                .andExpect(jsonPath("$.definitions[0].header", is(false)))
                .andExpect(jsonPath("$.definitions[0].label", is("Route of Entry")))
                .andExpect(jsonPath("$.definitions[0].type", is("STRING")))
                .andExpect(jsonPath("$.definitions[0].path", is("")))
                .andExpect(jsonPath("$.definitions[0].tooltip", is("")))
                .andExpect(jsonPath("$.definitions[0].clickAction", is("NONE")))
                .andExpect(jsonPath("$.definitions[2].type", is("TIMESTAMP")))
                .andExpect(jsonPath("$.definitions[29].type", is("LIST")))
                .andExpect(jsonPath("$.definitions[4].path", is(".code")))
                .andExpect(jsonPath("$.definitions", hasSize(59)));
    }

}