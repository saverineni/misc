package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.junit.Before;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;

import java.util.Arrays;

import static org.elasticsearch.common.xcontent.XContentType.JSON;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchHitMatchers.declarationId;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchResponseAssert.assertSearchHits;

public class SearchClientDeclarationSourceIT extends CustomsSearchESIntegTestCase {
    private static final String CUSTOMS_INDEX = "SearchClientDeclarationSourceIntegrationTest".toLowerCase();
    private static final String DEC_SOURCE_CHIEF = "CHIEF";
    private static final String DEC_SOURCE_CDS = "CDS";
    private static final String EPU = "EPU";

    private ObjectMapper objectMapper = new ObjectMapper();

    @Before
    public void setUp() throws Exception {
        super.setUp(CUSTOMS_INDEX);
        createCustomsIndexWithDocuments();
    }

    @Test
    public void searchWithBlankDeclarationSourceFilter() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(""));
        assertSearchHits(searchResponse, declarationId("dec-id-5"));
    }

    @Test
    public void searchWithOneImportDeclarationSource() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(DEC_SOURCE_CHIEF));
        assertSearchHits(searchResponse,
                declarationId("dec-id-1"),
                declarationId("dec-id-2"));
    }

    @Test
    public void searchWithMultipleImportDeclarationSource() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(DEC_SOURCE_CHIEF, DEC_SOURCE_CDS));

        assertSearchHits(searchResponse,
                declarationId("dec-id-1"),
                declarationId("dec-id-2"),
                declarationId("dec-id-3"),
                declarationId("dec-id-4"));
    }

    @Test
    public void searchWithOneImportDeclarationSourceWithSearchTerm() {
        SearchCriteria searchCriteria = newSearchCriteria(DEC_SOURCE_CDS);
        searchCriteria.setSearchTerm(EPU);
        SearchResponse searchResponse = this.service.declarationSearch(searchCriteria);

        assertSearchHits(searchResponse,
                declarationId("dec-id-3"),
                declarationId("dec-id-4"));
    }

    private SearchCriteria newSearchCriteria(String... declarationSources) {
        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDeclarationSource(Arrays.asList(declarationSources));
        return searchCriteria;
    }

    private void createCustomsIndexWithDocuments() throws Exception {
        createIndex(CUSTOMS_INDEX);

        BulkRequest request = new BulkRequest();
        addDeclaration(request, newDeclaration("dec-id-1", DEC_SOURCE_CHIEF));
        addDeclaration(request, newDeclaration("dec-id-2", DEC_SOURCE_CHIEF));
        addDeclaration(request, newDeclaration("dec-id-3", DEC_SOURCE_CDS));
        addDeclaration(request, newDeclaration("dec-id-4", DEC_SOURCE_CDS));
        addDeclaration(request, newDeclaration("dec-id-5", ""));

        client.bulk(request);
        refresh(CUSTOMS_INDEX);
    }

    private void addDeclaration(BulkRequest request, Declaration declaration) throws JsonProcessingException {
        request.add(new IndexRequest(CUSTOMS_INDEX, DECLARATION_TYPE, declaration.getDeclarationId())
                .source(objectMapper.writer().writeValueAsString(declaration), JSON));
    }

    private Declaration newDeclaration(String id, String declarationSource) {
        return Declaration.builder()
                .declarationId(id)
                .epuNumber(EPU)
                .declarationSource(declarationSource)
                .build();
    }
}
