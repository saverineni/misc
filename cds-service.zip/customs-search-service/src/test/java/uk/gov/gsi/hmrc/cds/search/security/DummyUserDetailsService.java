package uk.gov.gsi.hmrc.cds.search.security;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Profile;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import static java.lang.String.format;

@Component
@Qualifier("userDetailsService")
@Profile({"test"})
public class DummyUserDetailsService implements UserDetailsService {
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        switch(username) {
            case "dev":
                return new User("dev","{noop}dev",true,true,true,true, AuthorityUtils.createAuthorityList("DEV"));
            case "superdev":
                return new User("superdev","{noop}superdev",true,true,true,true, AuthorityUtils.createAuthorityList("SUPERDEV", "DEV"));
            case "tony":
                return new User("tony","{noop}cdsd@t@",true,true,true,true, AuthorityUtils.createAuthorityList("DEV"));
            case "mandy":
                return new User("mandy","{noop}cdsd@t@",true,true,true,true, AuthorityUtils.createAuthorityList("DEV"));
        }
        throw new UsernameNotFoundException(format("No such user %s", username));
    }
}