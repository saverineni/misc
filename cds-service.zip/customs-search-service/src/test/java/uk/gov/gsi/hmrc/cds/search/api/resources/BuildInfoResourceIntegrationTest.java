package uk.gov.gsi.hmrc.cds.search.api.resources;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(value = BuildInfoResource.class, secure = false)
@ActiveProfiles("test")
public class BuildInfoResourceIntegrationTest {

    public static final String VERSION = "1.0.0";
    public static final String ARTIFACT = "search-service";
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BuildProperties buildProperties;

    @Before
    public void setup() {
        when(buildProperties.getVersion()).thenReturn(VERSION);
        when(buildProperties.getArtifact()).thenReturn(ARTIFACT);
    }


    @Test
    public void getBuildInfoOk() throws Exception {

       this.mockMvc.perform(get("/build/info")
               .accept("application/json"))
               .andExpect(status().isOk())
               .andExpect(MockMvcResultMatchers.jsonPath("$.version", is(VERSION)))
               .andExpect(MockMvcResultMatchers.jsonPath("$.artifact", is(ARTIFACT)));
    }

}
