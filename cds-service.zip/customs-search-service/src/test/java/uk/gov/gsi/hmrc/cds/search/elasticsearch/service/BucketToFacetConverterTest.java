package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.Facet;

public class BucketToFacetConverterTest {

    @Mock
    private Terms.Bucket bucket;

    private BucketToFacetConverter converter = new BucketToFacetConverter();

    @Before
    public void setUp() {
        initMocks(this);
        when(bucket.getKeyAsString()).thenReturn("01");
        when(bucket.getDocCount()).thenReturn(3L);
    }

    @Test
    public void convertsFacetId() {
        Facet actual = converter.convert(bucket);
        assertThat(actual.getId(), is("01"));
    }

    @Test
    public void convertsCount() {
        Facet actual = converter.convert(bucket);
        assertThat(actual.getCount(), is(3L));
    }

    @Test
    public void convertsBlankFacet() {
        when(bucket.getKeyAsString()).thenReturn("");
        Facet actual = converter.convert(bucket);
        assertThat(actual.getId(), is(""));
    }
}
