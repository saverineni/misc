# Generating certs

__Run__

```openssl req -newkey rsa:2048 -nodes -keyout e2e.key -x509 -days 3650 -out e2e.crt```

__Options__
```
Country Name (2 letter code) [AU]:GB
State or Province Name (full name) [Some-State]:
Locality Name (eg, city) []:Manchester
Organization Name (eg, company) [Internet Widgits Pty Ltd]:HMRC
Organizational Unit Name (eg, section) []:
Common Name (e.g. server FQDN or YOUR name) []:localhost
Email Address []:
```

__Convert to p12__

```openssl pkcs12 -export -in "e2e.crt" -inkey "e2e.key" -name e2ecert -out "e2e-PKCS-12.p12" -password pass:```

__Generate jks from p12__

```keytool -importkeystore -noprompt -deststorepass "password" -destkeystore "e2e.jks" -srcstorepass "" -srckeystore "e2e-PKCS-12.p12" -srcstoretype PKCS12```
