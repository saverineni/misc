package search.declarations

import org.apache.http.impl.client.BasicResponseHandler
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

class DeclarationSearchResultSpec extends Specification {

    @Shared expectedDeclaration

    def setupSpec() {
        def index = new DeclarationsIndex()
        index.recreateAndPopulateIndex()
        expectedDeclaration = index.getApiFormatDeclaration('/declarations/2000000000000001.json')
    }

    def 'Response status should be OK'() {
        when:
        def response = SearchResource.authenticatedGet(['searchTerm': [expectedDeclaration.declarationId]])

        then:
        response.statusLine.statusCode == 200
    }

    def 'should not accept unknown parameters'() {
        when:
        def response = SearchResource.authenticatedGet(['unknown': [expectedDeclaration.declarationId]])

        then:
        response.statusLine.statusCode == 400
    }

    def 'unauthenticated request should give unauthorized'() {
        when:
        def response = SearchResource.unauthenticatedGet(['searchTerm': ['']])

        then:
        response.statusLine.statusCode == 401
    }

    def 'declaration without lines should be formatted correctly'() {
        when:
        def response = SearchResource.authenticatedGet(['searchTerm': ['2000000000000004']])
        def result = SearchResource.asJson(response)

        then:
        result.declarations[0].lines == []
    }

    def 'declarations as csv'() {
        when:
        def response = SearchResource.authenticatedPost('declarations', ['searchTerm': ['']],'{"fields": []}', 'text/csv')
        def responseString = new BasicResponseHandler().handleResponse(response)
        def resultsArray = responseString.split('\n')
        def firstDecId = resultsArray.find { dec -> dec.contains('2000000000000001') }
        def expectedCsvArray = new DeclarationsIndex().getFileContent('/2000000000000001-csv.txt').split('\n')

        then:
        resultsArray.length == 6
        resultsArray[0] == expectedCsvArray[0]
        firstDecId == expectedCsvArray[1]
    }

    def 'declarations as csv with filter fields'() {
        when:
        def response = SearchResource.authenticatedPost('declarations', ['searchTerm': ['']],'{"fields": ["declarationId","entryNumber","declarationSource"]}' ,'text/csv')
        def responseString = new BasicResponseHandler().handleResponse(response)
        def resultsArray = responseString.split('\n')
        def firstDecId = resultsArray.find { dec -> dec.contains('2000000000000001') }
        def expectedCsvArray = new DeclarationsIndex().getFileContent('/2000000000000001-filters-csv.txt').split('\n')

        then:
        resultsArray.length == 6
        resultsArray[0] == expectedCsvArray[0]
        firstDecId == expectedCsvArray[1]
    }

    def 'declaration items as csv'() {
        when:
        def response = SearchResource.authenticatedPost('declarations/2000000000000003', ['searchTerm': ['']], '{"fields": []}', 'text/csv')
        def responseString = new BasicResponseHandler().handleResponse(response)
        def resultsArray = responseString.split('\n')
        def expectedCsvArray = new DeclarationsIndex().getFileContent('/2000000000000003-item1-csv.txt').split('\n')

        then:
        resultsArray.length == 31
        resultsArray == expectedCsvArray
    }

    def 'declaration items as csv with filter fields'() {
        when:
        def response = SearchResource.authenticatedPost('declarations/2000000000000003', ['searchTerm': ['']], '{"fields": ["declarationId","declarationSource","itemRoute","cpc"]}','text/csv')
        def responseString = new BasicResponseHandler().handleResponse(response)
        def resultsArray = responseString.split('\n')
        def expectedCsvArray = new DeclarationsIndex().getFileContent('/2000000000000003-item1-filters-csv.txt').split('\n')

        then:
        resultsArray.length == 31
        resultsArray == expectedCsvArray
    }

    def 'declaration search result as csv'() {
        when:
        def response = SearchResource.authenticatedGet('declarations', ['searchTerm': ['2000000000000002']], 'text/csv')
        def responseString = new BasicResponseHandler().handleResponse(response)
        def expectedCsvString = new DeclarationsIndex().getFileContent('/2000000000000002-csv.txt')

        then:
        responseString == expectedCsvString
    }

    @Unroll
    def 'valid search term for #field gives the correct declaration response'(String searchTerm, String field) {
        given:
        def response = SearchResource.authenticatedGet(['searchTerm': [searchTerm]])
        def result = SearchResource.asJson(response)

        expect:
        result.declarations == [expectedDeclaration]

        where:
        searchTerm                  | field
        '2000000000000001'          | 'declarationId'
        '219'                       | 'epuNumber'
        '249099X'                   | 'entryNumber'
        'Header%20NAD%20NAME'       | 'consignee.name'
        'hN4%200Pc'                 | 'consignee.postcode'
        'HEADer%20Consignor%20naME' | 'consignor.name'
        'Ab4%206cd'                 | 'consignor.postcode'
        'Header%20DeclaranT%20Name' | 'declarant.name'
        'EF4%206gh'                 | 'declarant.postcode'
        '976072558688'              | 'consignee.eori'
        '582109443894367'           | 'consignor.eori'
        '957518101221'              | 'declarant.eori'
        'Header%20NAD%20NAME'       | 'consigneeName'
        'hN4%200Pc'                 | 'consigneePostcode'
        'HEADer%20Consignor%20naME' | 'consignorName'
        'Ab4%206cd'                 | 'consignorPostcode'
        '976072558688'              | 'consigneeTurn'
        '582109443894367'           | 'consignorTurn'
        '551030'                    | 'line.commodityCode'
        'Pg'                        | 'line.originCountry.code.codeText'
        '4000136'                   | 'line.cpc'
        'item%20NAD%20NaMe'         | 'line.itemConsignee.name'
        'In4%200Pc'                 | 'line.itemConsignee.postcode'
        'Item-conSignor-NAME'       | 'line.itemConsignor.name'
        'ITem-Consignor-Postcode'   | 'line.itemConsignor.postcode'
        'Item%20DeclaranT%20Name'   | 'line.itemDeclarant.name'
        'WA14%205bb'                | 'line.itemDeclarant.postcode'
        '731411813911'              | 'line.itemConsignee.eori'
        'item-consignor-turn'       | 'line.itemConsignor.eori'
        '123455432145'              | 'line.itemDeclarant.eori'
    }

    @Unroll
    def 'valid eori for #field gives the correct declaration response'() {
        given:
        def response = SearchResource.authenticatedGet(['eori': [eori]])
        def result = SearchResource.asJson(response)

        expect:
        result.declarations == [expectedDeclaration]

        where:
        eori                  | field
        '976072558688'        | 'consignee.eori'
        '582109443894367'     | 'consignor.eori'
        '957518101221'        | 'declarant.eori'
        '731411813911'        | 'itemConsignee.eori'
        'item-consignor-turn' | 'itemConsignor.eori'
        '123455432145'        | 'itemDeclarant.eori'
    }

    def 'first page of results should be returned for no search term'() {
        given:
        def response = SearchResource.authenticatedGet([])
        def result = SearchResource.asJson(response)

        expect:
        result.hits.total == 5
    }

    def 'first page of results should be returned for empty search term'() {
        given:
        def response = SearchResource.authenticatedGet(['searchTerm': ['']])
        def result = SearchResource.asJson(response)

        expect:
        result.hits.total == 5
    }

    def 'first page of results number determined by pageSize parameter'() {
        given:
        def response = SearchResource.authenticatedGet(['pageSize': ['2']])
        def result = SearchResource.asJson(response)

        expect:
        result.declarations.size() == 2
    }

    def 'search for 0 pageSize returns no results'() {
        given:
        def response = SearchResource.authenticatedGet(['pageSize': ['0']])
        def result = SearchResource.asJson(response)

        expect:
        result.declarations.size() == 0
    }

    def 'no matching declarations returns an empty result'() {
        given: 'user signed in successfully'

        when:
        def response = SearchResource.authenticatedGet(['searchTerm': ['INVALID_DEC_ID']])

        then:
        response.statusLine.statusCode == 200
        SearchResource.asJson(response) == [
                hits        : [
                        total: 0
                ],
                declarations: []
        ]
    }

    @Unroll
    def 'search for #params returns matching declarations'(params, expectedDeclarationIds) {
        given:
        def response = SearchResource.authenticatedGet(params)

        expect:
        response.statusLine.statusCode == 200
        SearchResource.asDeclarationIds(response).sort() == expectedDeclarationIds

        where:
        params                                                                        | expectedDeclarationIds
        ['originCountryCode': ['PG']]                                                 | ['2000000000000001']
        ['originCountryCode': ['PI', 'PH']]                                           | ['2000000000000002', '2000000000000003', '2000000000000005']

        ['dispatchCountryCode': ['dispatch-country-code2']]                           | ['2000000000000002']
        ['destinationCountryCode': ['TX']]                                            | ['2000000000000003', '2000000000000004']
        ['transportModeCode': ['tme']]                                                | ['2000000000000003', '2000000000000004']
        ['entryDateFrom': ['2018-01-03']]                                             | ['2000000000000003', '2000000000000004']
        ['entryDateTo': ['2018-01-02']]                                               | ['2000000000000001', '2000000000000002', '2000000000000005']
        ['entryDateFrom': ['2018-01-02'], 'entryDateTo': ['2018-01-03']]              | ['2000000000000002', '2000000000000003', '2000000000000005']
        ['entryDateFrom': ['2018-01-02'], 'entryDateTo': ['2018-01-02']]              | ['2000000000000002', '2000000000000005']
        ['acceptanceDateFrom': ['2018-02-02']]                                        | ['2000000000000002']
        ['acceptanceDateTo': ['2018-02-01']]                                          | ['2000000000000001']
        ['acceptanceDateFrom': ['2018-02-01'], 'acceptanceDateTo': ['2018-02-02']]    | ['2000000000000001', '2000000000000002']
        ['clearanceDateFrom': ['2018-01-02']]                                         | ['2000000000000002', '2000000000000003']
        ['clearanceDateTo': ['2018-01-02']]                                           | ['2000000000000001', '2000000000000002']
        ['clearanceDateFrom': ['2018-01-02'], 'clearanceDateTo': ['2018-01-02']]      | ['2000000000000002']
        ['clearanceDateFrom': ['2018-01-08'], 'clearanceDateTo': ['2018-01-10']]      | ['2000000000000003']
        ['netMassFrom': ['8.888'], 'netMassTo': ['12.222']]                           | ['2000000000000001']
        ['itemPriceFrom': ['8.888'], 'itemPriceTo': ['12.222']]                       | ['2000000000000001']
        ['searchTerm': ['220'], 'dispatchCountryCode': ['dispatch-country-code2']]    | ['2000000000000002']

        ['processingStatus': ['16']]                                                  | ['2000000000000001']

        ['entryDateFrom'    : ['2018-01-02'], 'entryDateTo': ['2018-01-02'],
         'originCountryCode': ['PH']]                                                 | ['2000000000000002', '2000000000000005']

        ['goodsLocation': ['LCX']]                                                    | ['2000000000000002']
        ['goodsLocation': ['LCZ']]                                                    | ['2000000000000003', '2000000000000004']
        ['goodsLocation': ['LCY', 'LCZ']]                                             | ['2000000000000001', '2000000000000003', '2000000000000004']

        ['commodityCode': ['551030']]                                                 | ['2000000000000001']
        ['cpc': ['4000136']]                                                          | ['2000000000000001']
        ['declarationType': ['X']]                                                    | ['2000000000000001']
        ['declarationType': ['Y']]                                                    | ['2000000000000002']

        ['declarationSource': ['CHIEF']]                                              | ['2000000000000001', '2000000000000002', '2000000000000003', '2000000000000004']
        ['declarationSource': ['DMS']]                                                | ['2000000000000005']

        ['searchTerm'            : ['220'], 'originCountryCode': ['PH'],
         'dispatchCountryCode'   : ['dispatch-country-code2'], 'commodityCode': ['551031'],'cpc': ['5000237'],
         'destinationCountryCode': ['TW'], 'transportModeCode': ['tmd'],
         'goodsLocation'         : ['LCX'], 'declarationType': ['Y'], 'declarationSource': ['CHIEF'],
         'entryDateFrom'         : ['2018-01-02'], 'entryDateTo': ['2018-01-02'],
         'acceptanceDateFrom'    : ['2018-02-02'], 'acceptanceDateTo': ['2018-02-02'],
         'clearanceDateFrom'     : ['2018-01-02'], 'clearanceDateTo': ['2018-01-02'],
         'netMassFrom'           : ['20'], 'netMassTo': ['30'],
         'itemPriceFrom'         : ['20'], 'itemPriceTo': ['30']]                     | ['2000000000000002']
        [ preferenceNumber: [ '223' ]]                                                | ['2000000000000003']
    }

    String getFileContent(String fileName) {
        new File(getClass().getResource(fileName).toURI()).text
    }
}
