package search.declarations

import spock.lang.Specification
import spock.lang.Unroll

class FacetSearchResultSpec extends Specification {

    static facetResourcePath = "facets"

    def setupSpec() {
        new DeclarationsIndex().recreateAndPopulateIndex()
    }

    @Unroll('')
    def 'Response status should be OK'(facetType) {
        given:
            def response = SearchResource.authenticatedGet("$facetResourcePath/$facetType", [])

        expect:
            response.statusLine.statusCode == 200

        where:
            facetType << [
                    'originCountryCode',
                    'dispatchCountryCode',
                    'destinationCountryCode',
                    'transportModeCode',
                    'goodsLocation',
                    'commodityCode',
                    'cpc',
                    'declarationType',
                    'preferenceNumber',
                    'processingStatus'
            ]
    }

    def 'should not accept unknown facet type'() {
        when:
            def response = SearchResource.authenticatedGet(facetResourcePath + '/unknown', [])

        then:
            response.statusLine.statusCode == 400
    }

    def 'should return aggregations only for the provided header facet type'() {
        given:
            def response = SearchResource.authenticatedGet(facetResourcePath + '/goodsLocation', [])
            def result = SearchResource.asJson(response)

        expect:
            result.facets == [
                    [
                            id   : "LCZ",
                            count: 2
                    ],
                    [
                            id   : "LCX",
                            count: 1
                    ],
                    [
                            id   : "LCY",
                            count: 1
                    ]
            ]
    }

    def 'should return aggregations only for the provided facet type with search criteria'() {
        given:
            def response = SearchResource.authenticatedGet(facetResourcePath + '/goodsLocation', ['searchTerm': ['221']])
            def result = SearchResource.asJson(response)

        expect:
            result.facets == [
                    [
                            id   : "LCZ",
                            count: 2
                    ]
            ]
    }

    @Unroll("The #facet facet with prefix #prefix should return #expectedCount results")
    def 'should return aggregations only for facet with prefix'(facet, prefix, expectedCount) {
        given:
            def response = SearchResource.authenticatedGet(facetResourcePath + "/$facet/$prefix", [])
            def result = SearchResource.asJson(response)

        expect:
            result.facets.size() == expectedCount
            result.facets*.id.findAll { it ==~ /^${prefix}.+/ }.size() == expectedCount

        where:
            facet              | prefix     | expectedCount
            'commodityCode'    | '55'       | 3
            'preferenceNumber' | '1'        | 3
    }


    @Unroll("The #facet facet with a regex prefix #regexPrefix should return #expectedCount results")
    def 'should return aggregations only for facet with regex prefix'(facet, regexPrefix, expectedCount) {
        given:
        def response = SearchResource.authenticatedGet(facetResourcePath + "/$facet/$regexPrefix", [])
        def result = SearchResource.asJson(response)

        expect:
        result.facets.size() == expectedCount
        result.facets*.id.findAll { it -> it.toString().matches(regexPrefix.replaceAll("\\*",".")) }.size() == expectedCount

        where:
        facet              | regexPrefix     | expectedCount
        'cpc'              | '4000***'       | 3
        'cpc'              | '40*****'       | 3
        'cpc'              | '**00***'       | 5
        'cpc'              | '4000136'       | 1
        'cpc'              | '****538'       | 1
        'cpc'              | '****5**'       | 2
        'cpc'              | '*******'       | 5
    }


}
