package search.manage.info

import search.manage.ManageResource
import spock.lang.Shared
import spock.lang.Specification

class InfoSpec extends Specification {

    @Shared response

    def setupSpec() {
        response = ManageResource.GET('info')
    }

    def 'the health resource should be available'() {
        expect:
        response.status == 200
    }

    def 'the build info value should be set'() {
        expect:
        response.json().build.version ==~ /.+/
    }
}
