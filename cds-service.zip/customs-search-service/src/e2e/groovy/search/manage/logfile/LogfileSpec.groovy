package search.manage.logfile

import search.manage.ManageResource
import spock.lang.Specification

class LogfileSpec extends Specification {


    def 'the logfile should be available'() {
        when:
        def response = ManageResource.GET('logfile')

        then:
        response.status == 200
    }
}
