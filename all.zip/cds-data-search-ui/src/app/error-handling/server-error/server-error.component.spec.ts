import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ServerErrorComponent } from './server-error.component';
import { By } from '@angular/platform-browser';

describe('ServerErrorComponent', () => {
  let component: ServerErrorComponent;
  let fixture: ComponentFixture<ServerErrorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServerErrorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServerErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display something went wrong message', () => {
    const wrong_message = fixture.debugElement.query(By.css('.server-error__page-heading')).nativeElement;
    expect(wrong_message.textContent).toBe('Oops! Something went wrong.');
  });

  it('should display incovenience message', () => {
    const incovenience_message = fixture.debugElement.query(By.css('.server-error__inconvenience-message')).nativeElement;
    expect(incovenience_message.textContent).toBe(
      `We're sorry for the inconvenience caused. We will look in to the issue as soon as we can.`
    );
  });

  it('should display help message', () => {
    const help_message = fixture.debugElement.query(By.css('.server-error__help-message')).nativeElement;
    expect(help_message.textContent).toBe(
      `Please use the ‘Customs Declaration Search’ link in the navigation bar above to return to the search landing page.`
    );
  });

});
