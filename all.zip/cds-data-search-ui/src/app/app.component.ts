import {Component} from '@angular/core';
import {HttpNotificationService} from './http-notification.service';
import {OnDestroy, OnInit} from '@angular/core/src/metadata/lifecycle_hooks';
import {ActivatedRouteSnapshot, NavigationEnd, Router} from '@angular/router';
import {Observable, Subscription} from 'rxjs';
import {Title} from '@angular/platform-browser';
import {BuildInfoService} from './authentication/build-info.service';
import {BuildInfo} from './authentication/build-info';
import { UserService } from './authentication/user.service';

@Component({
  selector: 'cds-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit, OnDestroy {
  readonly homeLabel: string = 'Customs Declaration Search';
  isSignInPage: boolean;

  httpRequest: HttpNotificationService;
  urlSubscription: Subscription;
  buildInfo$: Observable<BuildInfo>;
  today: number = Date.now();

  constructor(private httpNotification: HttpNotificationService,
              private buildInfoService: BuildInfoService,
              private router: Router,
              private title: Title,
              private userService: UserService) {}

  private getDeepestTitle(routeSnapshot: ActivatedRouteSnapshot) {
    let title = routeSnapshot.data ? routeSnapshot.data.title : '';
    if (routeSnapshot.firstChild) {
      title = this.getDeepestTitle(routeSnapshot.firstChild) || title;
    }
    return title;
  }

  ngOnInit(): void {
    this.httpRequest = this.httpNotification;
    this.urlSubscription = this.router.events.subscribe((event) => {
      const routeSnapshot = this.router.routerState.snapshot.root;
      if (event instanceof NavigationEnd) {
        this.title.setTitle(this.getDeepestTitle(routeSnapshot));
        this.isSignInPage = this.router.url.includes('signin') ? true : false;
      }
    });

    this.buildInfo$ = this.buildInfoService.buildInfo;
  }

  ngOnDestroy(): void {
    this.urlSubscription.unsubscribe();
  }

  getUserPid(): string {
    const user = this.userService.getUser();
    return user ? user.pid : '';
  }

  getCurrentDateTime(): Date {
    return new Date();
  }

}
