export class LinesSelection {

  selectedItemNumber: number;

  readonly lines: Array<any>;

  constructor(
    _lines: Array<any>,
    readonly declarationId: string,
    readonly importExportIndicator: string,
    readonly declarationSource: string,
    readonly declarationType: string
  ) {
    this.lines = _lines.map(line => {
        const newLine = Object.assign({}, line);
        newLine.declarationId = declarationId;
        newLine.importExportIndicator = importExportIndicator;
        newLine.declarationSource = declarationSource;
        newLine.declarationType = declarationType;
        return newLine;
      })
      .sort((a, b) => a.itemNumber - b.itemNumber);
  }

  isSelectionValid() {
    return this.lines.find(it => it.itemNumber === this.selectedItemNumber) !== undefined;
  }
}
