import { Country } from '../country';

export class DeclarationLine {
    declarationId: string;
    importExportIndicator: string;
    declarationSource: string;
    declarationType: string;
    itemNumber: number;
    itemDispatchCountry: Country;
    itemDestinationCountry: Country;
    clearanceDate: string;
    cpc: string;
    originCountry: Country;
    commodityCode: string;
    itemRoute: string;
}
