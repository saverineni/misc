import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { Directive , Input , DebugElement} from '@angular/core';
import { MatTableModule , MatTabsModule } from '@angular/material';
import { ItemAssociationsComponent } from './associations.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ViewDefinition } from '../../../../elements-library/cds-data-grid/view-definition';
import { By } from '@angular/platform-browser';

@Directive({
  selector: 'cds-data-table'
})
export class MockDeclarationDataTableDirective {
  @Input() dataSource: Array<any>;
  @Input() headers: Array<any>;
  @Input() filterText: string;
}

const ITEM = {itemNumber: 1, associations1: [{seqId1: 'value1'}], associations2: [{seqId2: 'value2'}]};

const VIEW_DEFINITIONS: ViewDefinition[] = [
  new ViewDefinition({ id: 'associations1', label: 'Association1 Header', parentId: '', type: 'LIST' }),
  new ViewDefinition({ id: 'seqId1', label: 'Sequence1', parentId: 'associations1' }),
  new ViewDefinition({ id: 'associations2', label: 'Association2 Header', parentId: '', type: 'LIST' }),
  new ViewDefinition({ id: 'seqId2', label: 'Sequence2', parentId: 'associations2' })
];

describe('ItemAssociationsComponent', () => {
  let component: ItemAssociationsComponent;
  let fixture: ComponentFixture<ItemAssociationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MatTableModule , MatTabsModule , BrowserAnimationsModule],
      declarations: [ ItemAssociationsComponent , MockDeclarationDataTableDirective ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemAssociationsComponent);
    component = fixture.componentInstance;

    component.viewDefinitions = VIEW_DEFINITIONS;
    component.filterText = '';
    component.item = ITEM;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('associations exists' , () => {
    const associationItemId = fixture.debugElement.query(By.css('.declaration-item-detail__association[item-id="1"]'));
    expect(associationItemId).toBeTruthy();
  });

  it('should display the active tab', () => {
    const activeTab = fixture.debugElement.query(By.css('.mat-tab-label-active')).nativeElement;
    expect(activeTab.innerText.trim()).toEqual('Association1 Header');
  });

  it('all mat tabs displayed' , () => {
    expect(getItemTabLabels()).toEqual(['Association1 Header', 'Association2 Header']);
  });

  it('default tab content displayed' , () => {
    let dataTableDirective: DebugElement[];
    dataTableDirective = fixture.debugElement.queryAll(By.directive(MockDeclarationDataTableDirective));

    expect(dataTableDirective.length).toEqual(1);
    expect(dataTableDirective[0].injector.get(MockDeclarationDataTableDirective).dataSource).toEqual([{seqId1: 'value1'}]);
  });

  describe('click the next tab' , () => {

    it('should set the tab to active and display content', () => {
      const element = fixture.debugElement.query(By.css('.declaration-item-detail__association'));
      const matTab = element.query(
                By.css(`.declaration-item-detail__association__tab-label[association-id='associations2']`)).nativeElement;

      matTab.click();
      fixture.detectChanges();

      fixture.whenStable().then(() => {
        fixture.detectChanges();
        const activeTab = fixture.debugElement.query(By.css('.mat-tab-label-active')).nativeElement;
        expect(activeTab.innerText.trim()).toEqual('Association2 Header');

        let dataTableDirective: DebugElement[];
        dataTableDirective = fixture.debugElement.queryAll(By.directive(MockDeclarationDataTableDirective));

        expect(dataTableDirective.length).toEqual(2);
        expect(dataTableDirective[1].injector.get(MockDeclarationDataTableDirective).dataSource).toEqual([{seqId2: 'value2'}]);
      });
    });
  });

  function getItemTabLabels() {
    return fixture.debugElement.queryAll(By.css('.mat-tab-label'))
      .map(e => e.nativeElement.innerText.trim());
  }

});
