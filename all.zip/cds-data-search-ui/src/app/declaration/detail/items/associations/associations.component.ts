import { Component, OnInit, ChangeDetectionStrategy, ViewEncapsulation , Input } from '@angular/core';
import { ViewDefinition } from '../../../../elements-library/cds-data-grid/view-definition';

@Component({
  selector: 'cds-item-detail-associations',
  templateUrl: './associations.component.html',
  styleUrls: ['./associations.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class ItemAssociationsComponent implements OnInit {

  @Input() viewDefinitions: ViewDefinition[];
  @Input() item: any;
  @Input() filterText: string;

  constructor() { }

  ngOnInit() {
  }

  checkForAssociations(item): boolean {
    return this.itemAssociations().find(association => item[association.id]) !== undefined;
  }

  itemAssociations(): ViewDefinition[] {
    return this.viewDefinitions.filter(viewDefinition => viewDefinition.type === 'LIST');
  }

  checkForAssociation(item, id): boolean {
    return item[id] !== undefined;
  }

  itemAssociationHeaders(id): Array<any> {
    return this.viewDefinitions
                .filter(viewDefinition => viewDefinition.parentId === id)
                .map(viewDefinition => ({id: viewDefinition.id, label: viewDefinition.label}));
  }

}
