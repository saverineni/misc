import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DeclarationItemDetailComponent } from './declaration-item-detail.component';
import { MatCardModule, MatDividerModule, MatTabsModule, MatInputModule, MatIconModule ,
  MatDialog, MatDialogModule, MatCheckboxModule , MatTableModule} from '@angular/material';
import { Input, Directive } from '@angular/core';
import { of, Observable } from 'rxjs';
import { ActivatedRoute, Router, RouterState } from '@angular/router';
import { Location } from '@angular/common';
import { DeclarationLine } from '../declaration-line';
import { By } from '@angular/platform-browser';
import { DeclarationService } from '../declaration.service';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule } from '@angular/forms';
import { LinesSelection } from '../lines-selection';
import { Cell, ViewDefinition } from '../../../elements-library/cds-data-grid/view-definition';
import { RouterStateSnapshot} from '@angular/router/src/router_state';
import { Breadcrumb } from '../../breadcrumb/breadcrumb';
import { DefinitionService } from '../../search/definition.service';
import { SignInRouterService } from '../../../authentication/sign-in/sign-in-router.service';
import { AuthenticationService } from '../../../authentication/authentication.service';
import { ExtractCsvComponent } from '../../search/extract-csv/extract-csv.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { FlexLayoutModule } from '@angular/flex-layout';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AttributesPicker } from '../../search/attributes-picker';

@Directive({
  selector: 'cds-data-grid'
})
export class MockDeclarationDataGridDirective {
  @Input() columnCount: number;
  @Input() cells: Observable<Cell[]>;
  @Input() filterText: string;
}
@Directive({
  selector: 'cds-breadcrumb'
})
export class MockBreadCrumbDirective {
  @Input() breadcrumbs = [];
}

@Directive({
  selector: 'cds-item-detail-associations'
})
export class MockItemAssociationsDirective {
  @Input() viewDefinitions: ViewDefinition[];
  @Input() item: any;
  @Input() filterText: string;
}

describe('DeclarationItemDetailComponent', () => {
  let component: DeclarationItemDetailComponent;
  let fixture: ComponentFixture<DeclarationItemDetailComponent>;
  let linesSelection: LinesSelection;
  let declarationService: DeclarationService;
  let mockDefinitionService: DefinitionService;
  let authenticationService: AuthenticationService;
  let mockAuthenticationService: AuthenticationService;
  let signInRouterService: SignInRouterService;

  let location: Location;

  const headerDefinition: ViewDefinition[] = [
    new ViewDefinition({ id: 'header', label: 'Header', header: true }),
    new ViewDefinition({ id: 'nonheader', label: 'NonHeader', header: false })
  ];

  const itemDefinition: ViewDefinition[] = [
    new ViewDefinition({ id: 'item', label: 'Item' })
  ];

  const dialog = {
    open(a, b) {
      return {
        afterClosed: () => of([])
      };
    },
    closeAll() {}
  } as MatDialog;

  const mockActivatedRoute = {} as ActivatedRoute;
  const routerStateSnapshotStub = { url: '/declarations/1234/items/1'} as RouterStateSnapshot;
  const mockRouter = {
    routerState: {
      snapshot: routerStateSnapshotStub
    } as RouterState
  } as Router;

  mockAuthenticationService = {
    isAuthenticated: () => {}
  } as AuthenticationService;

  signInRouterService = {
    navigateToSignIn: () => {}
  } as SignInRouterService;

  beforeEach(async(() => {
    linesSelection = new LinesSelection([
        { itemNumber: 1, itemRoute: 'one', importExportIndicator: 'Export'} as DeclarationLine,
        { itemNumber: 2, itemRoute: 'two', importExportIndicator: 'Import'} as DeclarationLine,
        { itemNumber: 3, itemRoute: 'three', importExportIndicator: 'Import'} as DeclarationLine,
      ],
      'id', 'import', 'mss', 'X');

    linesSelection.selectedItemNumber = 2;


    const obs: any = of(linesSelection);
    const obsCsv: any = of('');

    declarationService = {
      itemsForRoute: (route) => obs,
      downloadCsv: (a, b) => {}
    } as DeclarationService;

    spyOn(declarationService, 'downloadCsv').and.returnValue(obsCsv);

    const headerObsDefinition: any = of(headerDefinition);
    const itemObsDefinition: any = of(itemDefinition);
    mockDefinitionService = {
      getDeclarationDefinition: () => headerObsDefinition,
      getDeclarationItemDefinition: () => itemObsDefinition
    } as DefinitionService;

    TestBed.configureTestingModule({
      imports: [MatCardModule, MatDividerModule, MatTabsModule, RouterTestingModule, FlexLayoutModule, BrowserAnimationsModule ,
         FormsModule, MatInputModule, MatIconModule , MatCheckboxModule , MatDialogModule , MatTableModule],
      declarations: [ DeclarationItemDetailComponent, MockDeclarationDataGridDirective,
        MockBreadCrumbDirective , MockItemAssociationsDirective, ExtractCsvComponent ],
      providers: [
        {provide: MatDialog, useValue: dialog },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: DeclarationService, useValue: declarationService },
        { provide: AuthenticationService, useValue: mockAuthenticationService },
        { provide: SignInRouterService, useValue: signInRouterService },
        { provide: Router, useValue: mockRouter },
        { provide: DefinitionService, useValue: mockDefinitionService }
      ]
    }).overrideModule(BrowserDynamicTestingModule, {
      set: {
        entryComponents: [ExtractCsvComponent]
      }
    })
    .compileComponents();

  }));

  beforeEach(() => {

    fixture = TestBed.createComponent(DeclarationItemDetailComponent);
    component = fixture.componentInstance;
    location = TestBed.get(Location);
    authenticationService = TestBed.get(AuthenticationService);
    signInRouterService = TestBed.get(SignInRouterService);

    spyOn(location, 'replaceState');
    window.print = jasmine.createSpy().and.callThrough();
    spyOn(component.dialog, 'open').and.callThrough();
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should have focus on the search input item', () => {
    const declarationItemDetail = fixture.debugElement.query(By.css('.declaration-item-detail'));
    const itemDetail = declarationItemDetail.nativeElement as HTMLElement;

    const itemFilter = declarationItemDetail.query(By.css('.declaration-item-detail__item-filter-input')).nativeElement as HTMLElement;
    const focusedElement = itemDetail.querySelector('[autofocus]') as HTMLElement;
    expect(itemFilter).toBe(focusedElement);
  });

  it('should combine the header fields from the declaration definition with the item definition fields', () => {
    component.viewDefinitions$.forEach(definitions => {
      expect(definitions.map(def => def.id )).toEqual(['header', 'item' ]);
    });
  });

  describe('click the download csv link', () => {
    it('opens the dialog window with the correct properties', () => {
      component.viewDefinitions$.forEach(definitions => {
        component.attributes = definitions.map(def => new AttributesPicker(def.id, def.label));
      });

      fixture.debugElement.query(By.css('.declaration-item-detail__download-csv')).nativeElement.click();
      fixture.detectChanges();
      expect(component.dialog.open).toHaveBeenCalledWith(
        ExtractCsvComponent,
        {
          width: '600px',
          maxHeight: '60vh',
          minHeight: '30vh',
          data: {
            id: 'item',
            fields: [new AttributesPicker('header', 'Header'), new AttributesPicker('item', 'Item')]
          }
        });
    });

    it('should call declaration service to download csv when download csv icon clicked', () => {
      fixture.debugElement.query(By.css('.declaration-item-detail__download-csv')).nativeElement.click();
      fixture.detectChanges();
      expect(declarationService.downloadCsv).toHaveBeenCalledWith('id', []);
    });

  });

  describe('data grid with items', () => {
    let dataGrid: MockDeclarationDataGridDirective;

    it('should be given the correct column count', () => {
      dataGrid = fixture.debugElement.query(By.directive(MockDeclarationDataGridDirective)).injector.get(MockDeclarationDataGridDirective);
      expect(dataGrid.columnCount).toEqual(4);
    });
  });


  describe('item associations', () => {
    let itemAssociation: MockItemAssociationsDirective;

    it('exists', () => {
      itemAssociation = fixture.debugElement.query(By.directive(MockItemAssociationsDirective))
                              .injector.get(MockItemAssociationsDirective);
      expect(itemAssociation.viewDefinitions.length).toEqual(2);
      expect(itemAssociation.item).toEqual({ itemNumber: 2, itemRoute: 'two',
            importExportIndicator: 'import' , declarationId: 'id', declarationSource: 'mss' , declarationType: 'X'});
      expect(itemAssociation.filterText).toBeUndefined();
    });
  });

  function getActiveItemNumber() {
    return fixture.debugElement.query(By.css('.declaration-item-detail__declarations'))
      .nativeElement.getAttribute('data-declaration-item-number');
  }

  function getItemTabLabels() {
    return fixture.debugElement.queryAll(By.css('.declaration-item-detail__tab-label'))
      .map(e => e.nativeElement.innerText.trim());
  }

  describe('declaration item search filter', () => {
    function filterBy(text) {
      const filterElement = fixture.debugElement.query(By.css('.declaration-item-detail__item-filter-input')).nativeElement;
      filterElement.value = text;
      filterElement.dispatchEvent(new Event('input'));

      fixture.detectChanges();
    }

    it('should select the tab for the given item number', () => {
      filterBy('3');

      // need to query tabs directly as mat-tab-group value doesn't seem to get updated
      // due to an unknown...?
      expect(component.tabs.selectedIndex).toEqual(2);
    });

    describe('no matches', () => {
      beforeEach(() => {
        filterBy('99');
      });

      it('should display message', () => {
        const messageElement = fixture.debugElement.query(By.css('.declaration-item-detail__no-results-message'));

        expect(messageElement).not.toBeNull();
      });

      it('should not display the tabs', () => {
        expect(getItemTabLabels()).toEqual([]);
      });

      describe('then cleared', () => {
        beforeEach(() => {
          filterBy('');
        });

        it('should display all tabs again', () => {
          expect(getItemTabLabels()).toEqual(['1', '2', '3']);
        });
      });
    });
  });

  describe('declaration item selection tabs', () => {

    it('should have the correct tab selected on load', () => {
      expect(getActiveItemNumber()).toEqual('2');
    });

    it('should have the item numbers for tab labels', () => {
      expect(getItemTabLabels()).toEqual(['1', '2', '3']);
    });

    it('should update the browser url when clicked', async(() => {
      const item3Tab = fixture.debugElement.query(By.css('.declaration-item-detail__tab-label[data-declaration-item-number="3"]'));
      item3Tab.nativeElement.click();
      fixture.detectChanges();

      fixture.whenStable().then(() => {
        expect(location.replaceState).toHaveBeenCalledWith('/declarations/id/items/3');
      });
    }));
  });

  describe('declaration item resolution', () => {
    it('should map declaration ids onto the item objects', (done) => {
      component.linesSelection$.subscribe(items => {
        expect(items.lines.map(it => it.declarationId)).toEqual(['id', 'id', 'id']);
        done();
      });
    });

    it('should map declaration import export indicators onto the item objects', (done) => {
      component.linesSelection$.subscribe(items => {
        expect(items.lines.map(it => it.importExportIndicator)).toEqual(['import', 'import', 'import']);
        done();
      });
    });

    it('should map declaration sources onto the item objects', (done) => {
      component.linesSelection$.subscribe(items => {
        expect(items.lines.map(it => it.declarationSource)).toEqual(['mss', 'mss', 'mss']);
        done();
      });
    });

    it('should map declaration type onto the item objects', (done) => {
      component.linesSelection$.subscribe(items => {
        expect(items.lines.map(it => it.declarationType)).toEqual(['X', 'X', 'X']);
        done();
      });
    });

    it('should sort the items by their item number', (done) => {
      component.linesSelection$.subscribe(items => {
        expect(items.lines.map(it => it.itemNumber)).toEqual([1, 2, 3]);
        done();
      });
    });
  });

  describe('result count', () => {
    it('should display the correct number of total items', () => {
      const itemCount = fixture.debugElement.query(By.css('.declaration-item-detail__results-count')).nativeElement.innerText.trim();
      expect(itemCount).toEqual('3');
    });
  });

  describe('get declaration detail link', () => {
    it('get declaration detail url from item detail url', () => {
      const url = component.getDeclarationDetailUrl();
      expect(url).toBe('/declarations/1234');
    });
  });

  describe('breadcrumbs', () => {
    it('initialised with valid values', () => {
      const breadcrumbs: Array<Breadcrumb> = component.breadcrumbs;
      const expectedBreadCrumbs = [
        new Breadcrumb('Declaration Detail', '/declarations/1234'),
        new Breadcrumb('Item Detail')
      ];
      expect(breadcrumbs).toEqual(expectedBreadCrumbs);
    });
  });

  describe('print', () => {

    describe('for an expired/invalid token', () => {
      beforeEach(() => {
        spyOn(signInRouterService, 'navigateToSignIn').and.callThrough();
        spyOn(authenticationService, 'isAuthenticated').and.returnValue(false);

        component.print();
        fixture.detectChanges();
      });

      it('should route to sign in page', () => {
        expect(signInRouterService.navigateToSignIn).toHaveBeenCalled();
      });
    });

    describe('for a valid token', () => {
      beforeEach(() => {
        spyOn(authenticationService, 'isAuthenticated').and.returnValue(true);

        component.print();
        fixture.detectChanges();
      });

      it('should call window print', () => {
        expect(window.print).toHaveBeenCalled();
      });
    });

  });

});
