import { Component, OnInit, ElementRef, AfterContentInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ChangeDetectionStrategy } from '@angular/core';
import { Cell, ViewDefinition } from '../../../elements-library/cds-data-grid/view-definition';
import { DeclarationService } from '../declaration.service';
import { Observable, combineLatest , of } from 'rxjs';
import { Location } from '@angular/common';
import { TrackBy } from '../../../track-by';
import { ViewChild } from '@angular/core';
import { LinesSelection } from '../lines-selection';
import { Breadcrumb } from '../../breadcrumb/breadcrumb';
import { DefinitionService } from '../../search/definition.service';
import { map } from 'rxjs/operators';
import { AuthenticationService } from '../../../authentication/authentication.service';
import { SignInRouterService } from '../../../authentication/sign-in/sign-in-router.service';
import * as moment from 'moment';
import * as FileSaver from 'file-saver';
import { AttributesPicker } from '../../search/attributes-picker';
import { MatDialog, MatTabChangeEvent, MatTabGroup } from '@angular/material';
import { ExtractCsvComponent } from '../../search/extract-csv/extract-csv.component';

@Component({
  selector: 'cds-declaration-item-detail',
  templateUrl: './declaration-item-detail.component.html',
  styleUrls: ['./declaration-item-detail.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DeclarationItemDetailComponent implements OnInit, AfterContentInit {
  TIMESTAMP_FORMAT = 'YYYY-MM-DD-HH-mm';
  trackByItemNumber = TrackBy.property('itemNumber');

  @ViewChild('tabs') tabs: MatTabGroup;
  @ViewChild('itemFilter') itemFilter;
  @ViewChild('itemFilter') set content(content: ElementRef) {
    if (content) {
        content.nativeElement.focus();
    }
 }

  columnCount = 4;

  linesSelection$: Observable<LinesSelection>;
  viewDefinitions$: Observable<ViewDefinition[]>;
  viewDefinitions: ViewDefinition[] = [];
  searchTerm: string;
  noResults = false;
  breadcrumbs: Array<Breadcrumb>;
  selectedHeaderFields: Array<AttributesPicker>;
  attributes: Array<AttributesPicker>;
  previousItems;

  private CSV_DIALOG_WIDTH = '600px';
  private CSV_DIALOG_MAX_HEIGHT = '60vh';
  private CSV_DIALOG_MIN_HEIGHT = '30vh';

  constructor(public dialog: MatDialog,
              private route: ActivatedRoute,
              private router: Router,
              private declarationService: DeclarationService,
              private definitionService: DefinitionService,
              private authenticationService: AuthenticationService,
              private signInRouterService: SignInRouterService,
              private location: Location) { }

  ngOnInit() {
    this.linesSelection$ = this.declarationService.itemsForRoute(this.route);
    this.breadcrumbs = [
      new Breadcrumb('Declaration Detail', this.getDeclarationDetailUrl()),
      new Breadcrumb('Item Detail')
    ];

    this.viewDefinitions$ = combineLatest(this.definitionService.getDeclarationDefinition(),
      this.definitionService.getDeclarationItemDefinition()).pipe(
        map(([headerDefinitions, itemDefinitions]) => {
          const declarationHeaders = headerDefinitions.filter(definition => definition.header);
          return declarationHeaders.concat(itemDefinitions);
        })
    );
  }

  ngAfterContentInit() {
    this.viewDefinitions$.subscribe(definitions => this.viewDefinitions = definitions);
  }

  onTabChange(declarationId, tabChangeEvent: MatTabChangeEvent) {
    if (tabChangeEvent.tab) {
      this.location.replaceState(`/declarations/${declarationId}/items/${tabChangeEvent.tab.textLabel}`);
    }
  }

  onFilterInput(itemFilter, items) {
    this.noResults = false;
    const itemNumber = +itemFilter;

    if (!itemFilter || itemFilter === '') {
      this.searchTerm = '';
    } else if (!isNaN(itemNumber) && itemNumber > 0 && itemNumber <= items.length) {
      this.searchTerm = '';
      this.tabs.selectedIndex = itemNumber - 1;
    } else  {
      this.searchTerm = itemFilter;
      const filteredItems = this.filteredItems(items);
      const currentItems = filteredItems.map(item => item.itemNumber).toString();

      if (filteredItems.length === 0) {
        this.noResults = true;
      } else if (this.previousItems !== currentItems) {
        this.tabs.selectedIndex = 0;
        this.onTabChange(filteredItems[0].declarationId, { tab: { textLabel: filteredItems[0].itemNumber }} as MatTabChangeEvent);
      }

      this.previousItems = currentItems;
    }
  }

  filteredItems(items) {
    return items.filter(item => {
      if (!this.searchTerm) {
        return true;
      }
      return this.getObjectFields(item).some(str => str.toLowerCase().includes(this.searchTerm.toLowerCase()));
    });
  }

  getObjectFields(object): String[] {
    let arr = [];
    for (const property in object) {
      if (typeof object[property] === 'object') {
        arr = arr.concat(this.getObjectFields(object[property]));
      } else {
        arr.push(object[property] + '');
      }
    }
    return arr;
  }

  itemCells(item): Observable<Cell[]> {
    const headerCount = this.viewDefinitions.filter(def => def.header).length;
    const cellDefinitions = this.viewDefinitions
                                .filter(viewDefinition =>
                                  viewDefinition.parentId === '' && viewDefinition.type !== 'LIST');

    this.attributes = cellDefinitions.map(viewDefinition =>
              new AttributesPicker(viewDefinition.id, viewDefinition.label));

    return of(cellDefinitions.map((viewDefinition , index) =>
                    viewDefinition.toCell(item, index, headerCount, this.columnCount)));
  }

  getDeclarationDetailUrl(): string {
    const itemDetailUrl: string = this.router.routerState.snapshot.url;
    return itemDetailUrl.replace(/\/items\/.*/, '');
  }

  print() {
    if (!this.authenticationService.isAuthenticated()) {
      this.signInRouterService.navigateToSignIn();
    } else {
      window.print();
    }
  }

  downloadCsv(declarationId) {
    const dialogRef = this.dialog.open(
      ExtractCsvComponent,
      {
        width: this.CSV_DIALOG_WIDTH,
        maxHeight: this.CSV_DIALOG_MAX_HEIGHT,
        minHeight: this.CSV_DIALOG_MIN_HEIGHT,
        data: {
          id: 'item',
          fields: this.attributes
        }
      });

    dialogRef.afterClosed().subscribe(extractFields => {
      if (extractFields) {
        const timestamp = moment(new Date()).format(this.TIMESTAMP_FORMAT);

        this.declarationService.downloadCsv(declarationId, extractFields).forEach(csv => {
          if (csv) {
            const blob = new Blob([csv], {type: 'text/csv;charset=utf-8'});
            FileSaver.saveAs(blob, `${declarationId}-items-${timestamp}.csv`);
          }
        });
      }
    });
  }
}
