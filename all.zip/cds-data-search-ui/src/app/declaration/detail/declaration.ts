import { DeclarationLine } from './declaration-line';
import { Country } from '../country';

export class Declaration {
    declarationSource: string;
    importExportIndicator: string;
    declarationId: string;
    declarationType: string;
    epuNumber: string;
    entryNumber: string;
    entryDate: string;
    route: string;
    dispatchCountry: Country;
    destinationCountry: Country;
    goodsLocation: string;
    transportModeCode: string;
    lines: Array<any>;
}
