export class Breadcrumb {
    private static CURRENT_PAGE = '.';

    private _label: string;
    private _url: string;

    constructor(label: string, url: string = Breadcrumb.CURRENT_PAGE) {
        this._label = label;
        this._url = url;
    }

    get label() {
        return this._label;
    }

    get url() {
        return this._url;
    }

    isForCurrentPage() {
        return this._url === Breadcrumb.CURRENT_PAGE;
    }
}
