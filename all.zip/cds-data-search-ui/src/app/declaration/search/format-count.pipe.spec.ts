import { FormatCountPipe } from './format-count.pipe';

describe('FormatCountPipe', () => {

  let pipe;

  beforeEach(() => {
    pipe = new FormatCountPipe();
  });

  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  it('displays 0 for null count', () => {
    expect(pipe.transform(null)).toBe('0');
  });

  it('displays 0 for zero count', () => {
    expect(pipe.transform(0)).toBe('0');
  });

  it('displays same value for counts below than 999', () => {
    const value = 999;
    expect(pipe.transform(value)).toBe('999');
  });

  it('displays K at the end for counts greater than 999', () => {
    const value = 1000;
    expect(pipe.transform(value)).toBe('1K');
  });

  it('displays K at the end for 20000 count value', () => {
    const value = 20000;
    expect(pipe.transform(value)).toBe('20K');
  });

  it('displays M at the end for counts greater than 999999', () => {
    const value = 1000000;
    expect(pipe.transform(value)).toBe('1M');
  });

  it('displays M at the end for 147 million count value', () => {
    const value = 145700000;
    expect(pipe.transform(value)).toBe('145.7M');
  });

  it('displays K at the end for counts greater than 999999999', () => {
    const value = 1000000000;
    expect(pipe.transform(value)).toBe('1B');
  });

});
