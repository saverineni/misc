import { HttpParams } from '@angular/common/http';
import { SearchCriteria } from './search-criteria';

export class SearchParamsBuilder {

  static toHttpParams(searchCriteria: SearchCriteria): HttpParams {
    const extractedParams = Object.getOwnPropertyNames(searchCriteria)
      .reduce((params, key) => this.applyNonNullParam(params, key, searchCriteria[key]), {});

    return new HttpParams({ fromObject: extractedParams });
  }

  private static applyNonNullParam(params, key, value) {
    if (value != null) {
      params[key] = value;
    }

    return params;
  }
}
