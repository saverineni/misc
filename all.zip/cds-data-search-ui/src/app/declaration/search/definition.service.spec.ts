import {TestBed} from '@angular/core/testing';
import { DefinitionService } from './definition.service';
import { DeclarationService } from '../detail/declaration.service';
import { ViewDefinition } from '../../elements-library/cds-data-grid/view-definition';
import { of } from 'rxjs';
import { SearchService } from './search.service';

describe('DefinitionService', () => {
  let service: DefinitionService;
  let searchServiceMock: SearchService;
  let declarationServiceMock: DeclarationService;
  let declarationPreviewDefinitionSpy;
  let declarationDefinitionSpy;
  let declarationItemDefinitionSpy;
  const definitions = [new ViewDefinition({
    'header': true,
    'label': 'Declaration ID',
    'type': 'string',
    'path': '',
    'id': 'declarationId'
})];

  beforeEach(() => {
    searchServiceMock = {
        declarationPreviewDefinition: () => {
            return of(definitions);
        }
    } as SearchService;

    declarationServiceMock = {
        declarationDefinition: () => {
            return of(definitions);
        },
        declarationItemDefinition: () => {
            return of(definitions);
        }
    } as DeclarationService;

    declarationPreviewDefinitionSpy = spyOn(searchServiceMock, 'declarationPreviewDefinition').and.callThrough();
    declarationDefinitionSpy = spyOn(declarationServiceMock, 'declarationDefinition').and.callThrough();
    declarationItemDefinitionSpy = spyOn(declarationServiceMock, 'declarationItemDefinition').and.callThrough();

    TestBed.configureTestingModule({
      providers: [
            DefinitionService,
            { provide: SearchService, useValue: searchServiceMock },
            { provide: DeclarationService, useValue: declarationServiceMock }
        ]
    });
    service = TestBed.get(DefinitionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should request the preview definition on first request', (done) => {
    service.getDeclarationPreviewDefinition().toPromise().then((definition) => {
        expect(searchServiceMock.declarationPreviewDefinition).toHaveBeenCalled();
        expect(definition[0].id).toEqual('declarationId');
    }).then(done, done.fail);
  });

  it('should return the persisted preview definition on subsequent requests', (done) => {
    service.getDeclarationPreviewDefinition().toPromise().then((definition) => {
        expect(searchServiceMock.declarationPreviewDefinition).toHaveBeenCalled();
        expect(definition[0].id).toEqual('declarationId');
        declarationPreviewDefinitionSpy.calls.reset();
    }).then(() => {
        return service.getDeclarationPreviewDefinition().toPromise().then((definition) => {
            expect(searchServiceMock.declarationPreviewDefinition).not.toHaveBeenCalled();
            expect(definition[0].id).toEqual('declarationId');
        });
    }).then(done, done.fail);
  });

  it('should request the definition on first request', (done) => {
    service.getDeclarationDefinition().toPromise().then((definition) => {
        expect(declarationServiceMock.declarationDefinition).toHaveBeenCalled();
        expect(definition[0].id).toEqual('declarationId');
    }).then(done, done.fail);
  });

  it('should return the persisted definition on subsequent requests', (done) => {
    service.getDeclarationDefinition().toPromise().then((definition) => {
        expect(declarationServiceMock.declarationDefinition).toHaveBeenCalled();
        expect(definition[0].id).toEqual('declarationId');
        declarationDefinitionSpy.calls.reset();
    }).then(() => {
        return service.getDeclarationDefinition().toPromise().then((definition) => {
            expect(declarationServiceMock.declarationDefinition).not.toHaveBeenCalled();
            expect(definition[0].id).toEqual('declarationId');
        });
    }).then(done, done.fail);
  });

  it('should request the items definition on first request', (done) => {
    service.getDeclarationItemDefinition().toPromise().then((definition) => {
        expect(declarationServiceMock.declarationItemDefinition).toHaveBeenCalled();
        expect(definition[0].id).toEqual('declarationId');
    }).then(done, done.fail);
  });

  it('should return the persisted items definition on subsequent requests', (done) => {
    service.getDeclarationItemDefinition().toPromise().then((definition) => {
        expect(declarationServiceMock.declarationItemDefinition).toHaveBeenCalled();
        expect(definition[0].id).toEqual('declarationId');
        declarationItemDefinitionSpy.calls.reset();
    }).then(() => {
        return service.getDeclarationItemDefinition().toPromise().then((definition) => {
            expect(declarationServiceMock.declarationItemDefinition).not.toHaveBeenCalled();
            expect(definition[0].id).toEqual('declarationId');
        });
    }).then(done, done.fail);
  });

});

