import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DeclarationCardComponent } from './declaration-card.component';
import { By } from '@angular/platform-browser';
import { Input, DebugElement, Directive } from '@angular/core';
import { MatCardModule, MatDividerModule, MatExpansionModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { Cell } from '../../../elements-library/cds-data-grid/view-definition';
import { DeclarationPreview } from '../declaration-preview';
import { Observable, of } from 'rxjs';
import { Country } from '../../country';
import { DefinitionService } from '../definition.service';
import { SearchCriteriaService } from '../search-criteria.service';

@Directive({
  selector: 'cds-data-grid'
})
export class MockDataGridDirective {
  @Input() columnCount: number;
  @Input() cells: Observable<Cell[]>;
  @Input() filterText: string;
}

describe('DeclarationCardComponent', () => {
  let component: DeclarationCardComponent;
  let fixture: ComponentFixture<DeclarationCardComponent>;
  let declaration: DeclarationPreview;
  let definitionService: DefinitionService;

  beforeEach(async(() => {
    definitionService = {
      getDeclarationPreviewDefinition: () => of([])
    } as DefinitionService;

    TestBed.configureTestingModule({
      imports: [MatCardModule, MatDividerModule, MatExpansionModule, BrowserAnimationsModule, RouterTestingModule],
      declarations: [
        DeclarationCardComponent, MockDataGridDirective
      ],
      providers: [{ provide: DefinitionService, useValue: definitionService }, SearchCriteriaService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeclarationCardComponent);
    component = fixture.componentInstance;
    declaration = new DeclarationPreview();
    declaration.declarationId = 'id';
    declaration.dispatchCountry = {code: 'IN'} as Country;
    declaration.destinationCountry = {code: 'UK'} as Country;
    declaration.lineCount = 2;
    component.declaration = declaration;
  });

  describe('should display', () => {
    let importDeclarationTypeCard: DebugElement;
    let exportDeclarationTypeCard: DebugElement;

    function findImportExportTypes() {
      importDeclarationTypeCard = fixture.debugElement.query(By.css(
        '.search-results-cards__declarations--import[data-declaration-id="id"]'
      ));
      exportDeclarationTypeCard = fixture.debugElement.query(By.css(
        '.search-results-cards__declarations--export[data-declaration-id="id"]'
      ));
    }

    beforeEach(() => {
      fixture.detectChanges();
    });

    it('declarations', () => {
      expect(fixture.debugElement.query(By.css('.search-results-cards__declarations')) === null).toEqual(false);
    });

    it('no colour coded cards for other import/export types', () => {
      findImportExportTypes();
      expect(importDeclarationTypeCard).toBeFalsy();
      expect(exportDeclarationTypeCard).toBeFalsy();
    });

    describe('import/export type', () => {

      function setImportExportType(declarationType) {
        declaration = new DeclarationPreview();
        declaration.declarationId = 'id';
        declaration.importExportIndicator = declarationType;
        component.declaration = declaration;

        fixture.detectChanges();
      }

      beforeEach(() => {
        fixture = TestBed.createComponent(DeclarationCardComponent);
        component = fixture.componentInstance;
      });

      it('with colour yellow for an import', () => {
        setImportExportType('Import');
        findImportExportTypes();

        expect(importDeclarationTypeCard).toBeTruthy();
        expect(exportDeclarationTypeCard).toBeFalsy();

      });

      it('with colour blue for an export', () => {
        setImportExportType('Export');
        findImportExportTypes();

        expect(importDeclarationTypeCard).toBeFalsy();
        expect(exportDeclarationTypeCard).toBeTruthy();
      });
    });
  });

  describe('declaration details button', () => {
    it('should have the correct link for the declaration details', () => {
      fixture.detectChanges();
      const href = fixture.debugElement.query(By.css('.search-results-cards__declaration-details-button'))
      .nativeElement.getAttribute('ng-reflect-router-link');
      expect(href).toEqual('/declarations/id');
    });
  });

  describe('data grid', () => {
    let dataGrid: MockDataGridDirective;

    beforeEach(() => {
      fixture.detectChanges();
      dataGrid = fixture.debugElement.query(By.directive(MockDataGridDirective)).injector.get(MockDataGridDirective);
    });

    it('should be created with the correct column count', () => {
      expect(dataGrid.columnCount).toBe(3);
    });
  });

  describe('item details button', () => {

    function getItemDetailDisabledButton() {
      return fixture.debugElement.query(By.css('button.search-results-cards__item-details-button'));
    }

    function getItemDetailLink() {
      return fixture.debugElement.query(By.css('a.search-results-cards__item-details-button'));
    }

    it('should have the correct link for the first items details', () => {
      fixture.detectChanges();
      const href = getItemDetailLink().nativeElement.getAttribute('ng-reflect-router-link');
      expect(href).toEqual('/declarations/id/items/1');
    });

    it('should report the correct number of items', () => {
      fixture.detectChanges();
      expect(getItemDetailLink().nativeElement.innerText).toEqual('ITEM DETAIL (2)');
    });

    it('should not be disabled when there are items', () => {
      fixture.detectChanges();
      expect(getItemDetailLink() === null).toBe(false);
      expect(getItemDetailDisabledButton() === null).toBe(true);
    });

    it('should report zero items correctly', () => {
      declaration.lineCount = 0;
      fixture.detectChanges();
      expect(getItemDetailDisabledButton().nativeElement.innerText).toEqual('ITEM DETAIL (0)');
    });

    it('should be disabled when there are zero items', () => {
      declaration.lineCount = 0;
      fixture.detectChanges();
      expect(getItemDetailDisabledButton().nativeElement.disabled).toBe(true);
    });
  });
});
