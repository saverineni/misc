import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SearchSectionComponent } from './search-section.component';
import { DebugElement, Directive, Input } from '@angular/core';
import { SearchService } from '../search.service';
import { SearchCriteria } from '../search-criteria';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DeclarationSearchResult } from '../declaration-search-result';
import { Observable, of, Subscription } from 'rxjs';
import { MatDividerModule, MatIconModule , MatDialog ,  MatCheckboxModule, MatDialogModule } from '@angular/material';
import { FormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';

import { SearchCriteriaService } from '../search-criteria.service';
import { By } from '@angular/platform-browser';
import { FormatCountPipe } from '../format-count.pipe';
import { NavigationService } from '../navigation.service';
import { TogglePanelService } from '../search-filter/toggle-panel.service';
import { TogglePanel } from '../search-filter/toggle-panel';
import { DeclarationPreview } from '../declaration-preview';
import { ExtractCsvComponent } from '../extract-csv/extract-csv.component';
import { DefinitionService } from '../definition.service';
import { ViewDefinition } from '../../../elements-library/cds-data-grid/view-definition';
import { AttributesPicker } from '../attributes-picker';

@Directive({
  selector: 'cds-search-form'
})
export class MockSearchFormDirective { }

@Directive({
  selector: 'cds-declaration-card'
})
export class MockDeclarationCardDirective {
  @Input() declaration;
}

@Directive({
  selector: 'cds-search-filter'
})
export class MockSearchFilterDirective {
}

@Directive({
  selector: 'cds-search-paginator'
})
export class MockSearchPaginatorDirective {
  @Input() totalResults = 10;
}

describe('SearchSectionComponent', () => {
  let component: SearchSectionComponent;
  let fixture: ComponentFixture<SearchSectionComponent>;
  let searchServiceStub;
  let searchCriteriaServiceStub;
  let testObservable: Observable<SearchCriteria>;
  let testSubscription: Subscription;
  let result: DeclarationSearchResult;
  let navigationService: NavigationService;
  let togglePanelService: TogglePanelService;
  let definitionService: DefinitionService;
  const headerDefinition: ViewDefinition[] = [
    new ViewDefinition({ id: 'header', label: 'Header', header: true }),
    new ViewDefinition({ id: 'nonheader', label: 'NonHeader', header: false })
  ];

  const dialog = {
    open(a, b) {
      return {
        afterClosed: () => of([])
      };
    },
    closeAll() {}
  } as MatDialog;

  beforeEach(async(() => {
    testObservable = of(new SearchCriteria());
    testSubscription = new Subscription();
    result = new DeclarationSearchResult();
    const obsDefinition: any = of(headerDefinition);

    searchServiceStub = {
      search: () =>  of(result),
      downloadCsv: () => of('')
    };

    navigationService = {
      navigateToSearch: (bool) => {}
    } as NavigationService;

    togglePanelService = {
      updatePartial: (togglePanel) => {},
      replace: (togglePanel) => {}
    } as TogglePanelService;

    definitionService = {
      getDeclarationDefinition: () => obsDefinition
    } as DefinitionService;

    searchCriteriaServiceStub = { searchCriteria: testObservable };
    spyOn(searchServiceStub, 'search').and.callThrough();
    spyOn(searchServiceStub, 'downloadCsv').and.callThrough();
    spyOn(definitionService, 'getDeclarationDefinition').and.callThrough();

    TestBed.configureTestingModule({
      declarations: [SearchSectionComponent, ExtractCsvComponent, MockSearchFormDirective, MockDeclarationCardDirective,
         MockSearchFilterDirective, MockSearchPaginatorDirective, FormatCountPipe],
      providers: [
        {provide: MatDialog, useValue: dialog },
        {provide: NavigationService, useValue: navigationService },
        {provide: SearchService, useValue: searchServiceStub},
        {provide: SearchCriteriaService, useValue: searchCriteriaServiceStub},
        { provide: DefinitionService, useValue: definitionService },
        {provide: TogglePanelService, useValue: togglePanelService }
      ],
      imports: [HttpClientTestingModule, MatDividerModule, MatIconModule, MatDialogModule,
        MatCheckboxModule,
        FlexLayoutModule,
        BrowserAnimationsModule,
        FormsModule]
    }).overrideModule(BrowserDynamicTestingModule, {
      set: {
        entryComponents: [ExtractCsvComponent]
      }
    }).compileComponents();
  }));

  let successHandler;

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchSectionComponent);
    component = fixture.componentInstance;
    navigationService = TestBed.get(NavigationService);
    togglePanelService = TestBed.get(TogglePanelService);
    spyOn(testObservable, 'subscribe')
    .and.callFake(success => {
        successHandler = success;
        return testSubscription;
      });

    spyOn(testSubscription, 'unsubscribe');
    spyOn(navigationService, 'navigateToSearch');
    spyOn(togglePanelService, 'replace');

    fixture.detectChanges();
  });

  describe('on initialisation', () => {
    it('should subscribe to successful search criteria updates', () => {
      expect(successHandler).toBeTruthy();
    });

    it('should display help text message ', () => {
      const message = fixture.debugElement.query(By.css('.search-section__hmrc__display-text')).nativeElement;
      expect(message.innerText).toBe('Please use the search box or the filters on the left hand side to start a new search.');
    });

    it('should display the hmrc logo', () => {
      const logo = fixture.debugElement.query(By.css('.search-section__hmrc__display-logo')).nativeElement;
      expect(logo).toBeTruthy();
    });

    it('should not display the reset search button', () => {
      const resetButton = fixture.debugElement.query(By.css('.search-section__reset-button'));
      expect(resetButton).toBeFalsy();
    });
  });

  describe('empty search criteria', () => {
    beforeEach(() => {
      const criteria = new SearchCriteria();
      criteria.searchTerm = null;
      successHandler(criteria);
      fixture.detectChanges();
    });

    ['.search-section__no-search-results', '.search-section__results', '.search-section__reset',
      '.search-section__results-count-section'].forEach(elementClass => {
      it(`should not display the ${elementClass}`, () => {
        const message = fixture.debugElement.query(By.css(elementClass));
        expect(message == null).toBeTruthy();
      });
    });
  });

  describe('results', () => {
    let search;

    beforeEach(() => {
      search = new SearchCriteria();
      search.searchTerm = '';
    });

    describe('not found', () => {

      beforeEach(() => {
        result.hits = { total: 0 };
        successHandler(search);
        fixture.detectChanges();
      });

      it('should display message', () => {
        const message = fixture.debugElement.query(By.css('.search-section__no-search-results'));
        expect(message != null).toBeTruthy();
      });

      it('should display the reset search button', () => {
        const resetButton = fixture.debugElement.query(By.css('.search-section__reset-button')).nativeElement;
        expect(resetButton).toBeTruthy();
      });

      it('should call navigation and toggle panel services when reset button is clicked', () => {
        fixture.debugElement.query(By.css('.search-section__reset-button')).nativeElement.click();
        fixture.detectChanges();
        expect(navigationService.navigateToSearch).toHaveBeenCalledWith(true);
        expect(togglePanelService.replace).toHaveBeenCalledWith(new TogglePanel());
      });

      it('should display the result count', () => {
        const resultCount = fixture.debugElement.query(By.css('.search-section__results-count')).nativeElement;
        expect(resultCount.innerText).toEqual('0');
      });

      it('should not display help text message ', () => {
        const message = fixture.debugElement.query(By.css('.search-section__hmrc__display-text'));
        expect(message).toBeNull();
      });

      it('should not display hmrc logo', () => {
        const logo = fixture.debugElement.query(By.css('.search-section__hmrc__display-logo'));
        expect(logo).toBeNull();
      });

      it('should not display the download csv icon', () => {
        const icon = fixture.debugElement.query(By.css('.search-section__download-csv'));
        expect(icon).toBeNull();
      });

    });

    describe('found', () => {
      let directive: DebugElement;
      let paginator;

      beforeEach(() => {
        result.hits = { total: 20000 };
        result.declarations = [new DeclarationPreview()];
        successHandler(search);
        directive = fixture.debugElement.query(By.directive(MockSearchPaginatorDirective));
        paginator = directive.injector.get(MockSearchPaginatorDirective);

        fixture.detectChanges();
      });

      it('should display the result count', () => {
        const resultCount = fixture.debugElement.query(By.css('.search-section__results-count')).nativeElement;
        expect(resultCount.innerText).toEqual('20K');
      });

      it('should display the results', () => {
        const message = fixture.debugElement.query(By.css('.search-section__results'));
        expect(message != null).toBeTruthy();
      });

      it('should have the paginator component', () => {
        expect(paginator).toBeTruthy();
      });

      it('should display the paginator at the header', () => {
        const paginatorHeader = fixture.debugElement.query(By.css('.search-section__paginator-header')).nativeElement;
        expect(paginatorHeader).toBeTruthy();
      });

      it('should not display help text message ', () => {
        const message = fixture.debugElement.query(By.css('.search-section__hmrc__display-text'));
        expect(message).toBeNull();
      });

      it('should not display hmrc logo', () => {
        const logo = fixture.debugElement.query(By.css('.search-section__hmrc__display-logo'));
        expect(logo).toBeNull();
      });

      it('should call navigation service when reset button is clicked', () => {
        fixture.debugElement.query(By.css('.search-section__reset-button')).nativeElement.click();
        fixture.detectChanges();
        expect(navigationService.navigateToSearch).toHaveBeenCalledWith(true);
      });

      it('should display the hidden download csv icon', () => {
        const icon = fixture.debugElement.query(By.css('.search-section__download-csv--hidden'));
        expect(icon).toBeTruthy();
      });

      it('should not call search service to download csv when download csv hidden icon clicked' , () => {
        fixture.debugElement.query(By.css('.search-section__download-csv--hidden')).nativeElement.click();
        const csvDownloadSearch = Object.assign(new SearchCriteria(), search);
        expect(searchServiceStub.downloadCsv).not.toHaveBeenCalledWith(csvDownloadSearch, []);
      });

      describe('with results less than 10K', () => {
        beforeEach(() => {
          result.hits = { total: 9999 };
          result.declarations = [new DeclarationPreview()];
          successHandler(search);
          directive = fixture.debugElement.query(By.directive(MockSearchPaginatorDirective));
          paginator = directive.injector.get(MockSearchPaginatorDirective);
          spyOn(component.dialog, 'open').and.callThrough();

          fixture.detectChanges();
        });

        it('should display the download csv icon', () => {
          const downloadIcon = fixture.debugElement.query(By.css('.search-section__download-csv'));
          const hiddenIcon = fixture.debugElement.query(By.css('.search-section__download-csv--hidden'));
          expect(downloadIcon).toBeTruthy();
          expect(hiddenIcon).toBeFalsy();
        });

        it('opens the dialog window with the correct properties', () => {
          fixture.debugElement.query(By.css('.search-section__download-csv')).nativeElement.click();

          expect(component.dialog.open).toHaveBeenCalledWith(
            ExtractCsvComponent,
            {
              width: '600px',
              maxHeight: '60vh',
              minHeight: '30vh',
              data: {
                id: 'header',
                fields: [new AttributesPicker('header', 'Header'), new AttributesPicker('nonheader', 'NonHeader')]
              }
            });
        });

        it('should call search service to download csv when download csv icon clicked', () => {
          fixture.debugElement.query(By.css('.search-section__download-csv')).nativeElement.click();
          const csvDownloadSearch = Object.assign(new SearchCriteria(), search);
          csvDownloadSearch.pageSize = result.hits.total;
          csvDownloadSearch.pageNumber = 1;
          expect(searchServiceStub.downloadCsv).toHaveBeenCalledWith(csvDownloadSearch, []);
        });
      });

    });

  });

  describe('with search criteria', () => {
    let searchCriteria: SearchCriteria;

    beforeEach(() => {
      searchCriteria = new SearchCriteria();
      searchCriteria.searchTerm = 'term';

      successHandler(searchCriteria);
    });

    it('should perform a search', () => {
      expect(searchServiceStub.search).toHaveBeenCalledWith(searchCriteria);
    });

    it('should set the result', () => {
      expect(component.result).toBe(result);
    });

  });

  describe('on destroy', () => {
    it('should unsubscribe from criteria events', () => {
      fixture.destroy();
      expect(testSubscription.unsubscribe).toHaveBeenCalled();
    });
  });
});

