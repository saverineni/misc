import { getTestBed, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController, TestRequest } from '@angular/common/http/testing';
import { SearchService } from './search.service';
import { SearchCriteria } from './search-criteria';
import { DeclarationSearchResult, Hits } from './declaration-search-result';
import { SearchParamsBuilder } from './search-params-builder';


describe('SearchService', () => {
  let httpMock: HttpTestingController;
  let service: SearchService;
  let searchCriteria: SearchCriteria;

  beforeEach(() => {
    searchCriteria = new SearchCriteria();

    TestBed.configureTestingModule({
      providers: [SearchService],
      imports: [HttpClientTestingModule]
    });
    httpMock = getTestBed().get(HttpTestingController);
    service = getTestBed().get(SearchService);
  });

  function mockRequest(endpoint = 'search', expectedParams = {}): TestRequest {
    const url = Object.getOwnPropertyNames(expectedParams)
      .reduce((urlSegment, key) => `${urlSegment}${key}=${expectedParams[key]}&`, `/api/${endpoint}?`);
    return httpMock.expectOne(url.substring(0, url.length - 1));
  }

  describe('submit search request', () => {
    let testRequest;

    beforeEach(() => {
      spyOn(SearchParamsBuilder, 'toHttpParams').and.callThrough();
      searchCriteria.searchTerm = '123-456';
      searchCriteria.originCountryCode = ['A', 'B', 'C'];

      service.search(searchCriteria).toPromise();

      testRequest = mockRequest('search', { searchTerm: '123-456', originCountryCode: 'A&originCountryCode=B&originCountryCode=C' });
      testRequest.flush({});
    });

    it('should as a http GET', () => {
      expect(testRequest.request.method).toBe('GET');
    });

    it('should use the search params builder', () => {
      expect(SearchParamsBuilder.toHttpParams).toHaveBeenCalledWith(searchCriteria);
    });
  });

  describe('submit download csv request', () => {
    let testRequest;

    beforeEach(() => {
      spyOn(SearchParamsBuilder, 'toHttpParams').and.callThrough();
      searchCriteria.searchTerm = '123-456';
      searchCriteria.originCountryCode = ['A', 'B', 'C'];
      service.downloadCsv(searchCriteria, []).toPromise();

      testRequest = mockRequest('declarations', { searchTerm: '123-456', originCountryCode: 'A&originCountryCode=B&originCountryCode=C' });
      testRequest.flush({});
    });

    it('should send the filtered fields to the api', () => {
      expect(testRequest.request.body).toEqual({ fields: [] });
    });

    it('should as a http POST', () => {
      expect(testRequest.request.method).toBe('POST');
    });

    it('should have the accept header', () => {
      expect(testRequest.request.headers.get('Accept')).toEqual('text/csv');
    });

    it('should use the search params builder', () => {
      expect(SearchParamsBuilder.toHttpParams).toHaveBeenCalledWith(searchCriteria);
    });
  });

  it('should throw error on 500', (done) => {
    const errorEvent = new ErrorEvent('');
    service.search(searchCriteria).subscribe(
      result => done.fail('expect error'),
      error => {
        expect(error.error).toBe(errorEvent);
        done();
      });
    const testRequest = mockRequest();
    testRequest.error(errorEvent, { status: 500 });
  });

  it('should return Declaration search result', () => {
    let actual: DeclarationSearchResult = null;
    service.search(searchCriteria).subscribe(result => actual = result);
    const testRequest = mockRequest();
    testRequest.flush({ hits: new Hits(), declarations: [{}] }, { status: 200, statusText: '' });
    expect(actual.declarations.length).toEqual(1);
  });

  it('should parse the json response', () => {
    const declaration: any = {};
    declaration.declarationId = searchCriteria.searchTerm;
    const hits = new Hits();
    hits.total = 1;

    let actual: DeclarationSearchResult = null;
    service.search(searchCriteria).subscribe(result => actual = result);
    const testRequest = mockRequest();
    testRequest.flush({ hits, declarations: [declaration] }, { status: 200, statusText: '' });
    expect(actual.declarations[0]).toEqual(declaration);
    expect(actual.hits).toEqual(hits);
  });

  afterEach(() => {
    httpMock.verify();
  });
});
