import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {FlexLayoutModule} from '@angular/flex-layout';
import {FormsModule} from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import {By} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ActivatedRoute} from '@angular/router';
import {of, ReplaySubject} from 'rxjs';
import {SearchFormComponent} from './search-form.component';
import {SearchCriteria} from '../search-criteria';
import {SearchCriteriaService} from '../search-criteria.service';
import {MatIconModule} from '@angular/material';

class ActivatedRouteStub {

  private subject = new ReplaySubject<any>();

  readonly queryParams = this.subject.asObservable();

  setQueryParams(queryParams?: any) {
    this.subject.next(queryParams);
  }
}

describe('SearchFormComponent', () => {
  let fixture: ComponentFixture<SearchFormComponent>;
  let component: SearchFormComponent;
  let newRoute;
  let searchCriteriaService;

  beforeEach(async(() => {
    newRoute = new ActivatedRouteStub();
    searchCriteriaService = {
      searchCriteria: of(new SearchCriteria()),
      updatePartial: (params) => {}
    } as SearchCriteriaService;
    spyOn(searchCriteriaService, 'updatePartial');

    TestBed.configureTestingModule({
        declarations: [SearchFormComponent],
        providers: [
          {provide: SearchCriteriaService, useValue: searchCriteriaService},
          {provide: ActivatedRoute, useValue: newRoute}
        ],
        imports: [
          FlexLayoutModule,
          MatIconModule,
          MatInputModule,
          BrowserAnimationsModule,
          FormsModule
        ]
      })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('search form', () => {
    it('should be displayed', () => {
      expect(fixture.debugElement.query(By.css('.search-form'))).toBeTruthy();
    });

    describe('Free text search field', () => {
      let searchTermInput;
      beforeEach(() => {
        searchTermInput = fixture.debugElement.query(By.css('.search-form__searchterm-input'));
      });

      it('should have a free text search field', () => {
        expect(searchTermInput).toBeTruthy();
      });

      it('should have focus when no search term', () => {
        const focusedElement = fixture.debugElement.query(By.css(':focus')).nativeElement;
        expect(searchTermInput.nativeElement).toBe(focusedElement);
      });

      it('should have a label for free text search field', () => {
        expect(searchTermInput.nativeElement.labels[0].textContent).toEqual('Search');
      });

      it('should not have focus if there is a search term', () => {
        const searchCriteria = new SearchCriteria();
        searchCriteria.searchTerm = 'search';
        searchCriteriaService.searchCriteria = of(new SearchCriteria());
        fixture = TestBed.createComponent(SearchFormComponent);

        expect(fixture.debugElement.query(By.css(':focus')) == null).toBe(true);
      });
    });

    describe('search icon', () => {
      let searchicon;
      beforeEach(() => {
        searchicon = fixture.debugElement.query(By.css('.search-form__perform-search'));
        fixture.detectChanges();
      });

      it('should have a button', () => {
        expect(searchicon).toBeTruthy();
      });
    });

    describe('submit form', () => {
      let searchTerm;
      let form;

      beforeEach(() => {
        form = fixture.debugElement.query(By.css('.search-form'));
      });

      afterEach(() => {
        expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(
          {searchTerm: searchTerm, pageNumber: undefined, pageSize: undefined}
        );
      });

      describe('with search term', () => {
        beforeEach(() => {
          searchTerm = 'search term';
          inputSearchTerm(searchTerm);
        });

        it('should call update on service', () => {
          fixture.debugElement.query(By.css('.search-form__perform-search')).nativeElement.click();
        });

        it('should update on submit event', () => {
          form.nativeElement.dispatchEvent(new Event('submit'));
        });
      });

      describe('with null search term', () => {
        beforeEach(() => {
          searchTerm = null;
          inputSearchTerm(searchTerm);
          form.nativeElement.dispatchEvent(new Event('submit'));
        });

        it('should submit empty string for null search term', () => {
          searchTerm = '';
        });
      });
    });

    describe('clear icon click', () => {
      let searchTerm;
      let searchTermInput;
        beforeEach(() => {
        searchTerm = 'search term';
        inputSearchTerm(searchTerm);
        fixture.debugElement.query(By.css('.search-form__clear-search')).nativeElement.click();
        searchTermInput = fixture.debugElement.query(By.css('.search-form__searchterm-input')).nativeElement;
      });

      it('clears search term', () => {
        expect(searchTermInput.value).toEqual('');
      });

      it('retains focus', () => {
        const focusedElement = fixture.debugElement.query(By.css(':focus')).nativeElement;
        expect(searchTermInput).toBe(focusedElement);
      });
    });

    function inputSearchTerm(searchTerm) {
      const searchTermInput = fixture.debugElement.query(By.css('.search-form__searchterm-input')).nativeElement;
      searchTermInput.value = searchTerm;
      searchTermInput.dispatchEvent(new Event('input'));
      fixture.detectChanges();
    }
  });
});
