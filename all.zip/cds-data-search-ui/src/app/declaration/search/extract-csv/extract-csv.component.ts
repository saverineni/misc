import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material';
import { TrackBy } from '../../../track-by';
import { isEqual } from 'lodash';
import { AttributesPicker } from '../attributes-picker';

export class SelectedAttributes extends AttributesPicker {

  constructor(attributesPicker: AttributesPicker) {
    super(attributesPicker.id, attributesPicker.label);
  }

  selected = false;
}

@Component({
  selector: 'cds-extract-csv',
  templateUrl: './extract-csv.component.html',
  styleUrls: ['./extract-csv.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ExtractCsvComponent implements OnInit {

  id: string;
  fields: Array<AttributesPicker>;
  selectedAttributes: Array<SelectedAttributes> = [];
  checkAll = false;
  trackByCheckboxId = TrackBy.property('id');

  constructor(@Inject(MAT_DIALOG_DATA) data) {
      this.id = data.id;
      this.fields = data.fields;
  }

  ngOnInit() {
    this.selectedAttributes = this.fields.map(it => new SelectedAttributes(it));
  }

  onClick(event, checkbox) {
    const index = this.selectedAttributes.findIndex(it => it.label === checkbox.label);
    const newIndex = index >= 0 ? index : this.selectedAttributes.length;
    this.selectedAttributes[newIndex] = {id: checkbox.id , label: checkbox.label, selected: event.checked} as SelectedAttributes;
    this.checkForExtractAll();
  }

  check(checkboxId) {
    const checkbox = this.selectedAttributes.find(it => it.label === checkboxId);
    return checkbox !== undefined ? checkbox.selected : false;
  }

  onClickAll(event) {
    this.checkAll = event.checked;
    this.selectedAttributes = this.selectedAttributes
          .map(it => ({id: it.id, label: it.label , selected : event.checked } as SelectedAttributes) );
  }

  extractToCSV() {
    const extractedFields: Set<string> = new Set();
    this.selectedAttributes.filter(it => it.selected === true).forEach(it => extractedFields.add(it.id));
    return isEqual(Array.from(extractedFields), this.selectedAttributes.map(it => it.id)) ? [] : Array.from(extractedFields);
  }

  filtersNotChanged() {
    return this.selectedAttributes.find(it => it.selected === true) === undefined;
  }

  private checkForExtractAll() {
    const allSelectedCheckBoxes = this.selectedAttributes.find(it => it.selected === false);
    this.checkAll = (allSelectedCheckBoxes === undefined) ? true : false;
  }

}
