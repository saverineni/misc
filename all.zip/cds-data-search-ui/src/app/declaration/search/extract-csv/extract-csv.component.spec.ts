import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MAT_CHECKBOX_CLICK_ACTION, MAT_DIALOG_DATA, MatDialogRef,
  MatCheckboxModule, MatCheckboxChange, MatDialogModule, MatDividerModule } from '@angular/material';
import { FormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ExtractCsvComponent } from './extract-csv.component';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { AttributesPicker } from '../attributes-picker';

describe('ExtractCsvComponent', () => {
  let component: ExtractCsvComponent;
  let fixture: ComponentFixture<ExtractCsvComponent>;
  const id = 'id';
  const checkbox1 = {id: '1', label: 'checkbox1'} as AttributesPicker; const checkbox2 = {id: '2', label: 'checkbox2'} as AttributesPicker;
  const fields: Array<AttributesPicker> = [checkbox1, checkbox2];
  const extractAllCheckbox = 'Extract all data';

  let matDialogRef: MatDialogRef<any>;
  let headerTitle: DebugElement;
  let headerContent: DebugElement;
  let cancelButton: DebugElement;
  let extractCSVButton: DebugElement;
  const checkboxChange = new MatCheckboxChange();

  beforeEach(async(() => {
    matDialogRef = { close: () => { } } as MatDialogRef<any>;
    spyOn(matDialogRef, 'close');

    TestBed.configureTestingModule({
      imports: [
        MatDialogModule,
        MatCheckboxModule,
        MatDividerModule,
        FlexLayoutModule,
        BrowserAnimationsModule,
        FormsModule
      ],
      declarations: [ ExtractCsvComponent ],
      providers: [
        { provide: MatDialogRef, useValue: matDialogRef },
        { provide: MAT_DIALOG_DATA, useValue: { id: id, fields: fields } },
        { provide: MAT_CHECKBOX_CLICK_ACTION, useValue: 'check'}
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExtractCsvComponent);
    component = fixture.componentInstance;

    headerTitle = fixture.debugElement.query(By.css('.extract-csv__header__title'));
    headerContent = fixture.debugElement.query(By.css('.extract-csv__header__content'));
    cancelButton = fixture.debugElement.query(By.css('.extract-csv__cancel'));
    extractCSVButton = fixture.debugElement.query(By.css('.extract-csv__apply'));

    fixture.detectChanges();

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display header title', () => {
    expect(headerTitle.nativeElement.innerText).toContain('Choose id data to extract to CSV');
  });

  it('should display header content', () => {
    const text = ['Use the checkboxes to select the id attribute(s) that you would like to extract to a CSV file (maximum 10k records).'
                  , `If you want to extract all id attributes, select the 'Extract all data' checkbox.`].join(' ');
    expect(headerContent.nativeElement.innerText.trim()).toContain(text.trim());
  });

  it('should display cancel button', () => {
    expect(cancelButton).toBeTruthy();
    expect(cancelButton.nativeElement.disabled).toBe(false);
  });

  it('should display extract to CSV button and disabled initially', () => {
    expect(extractCSVButton).toBeTruthy();
    expect(extractCSVButton.nativeElement.disabled).toBe(true);
  });

  it('should display checkboxes', () => {
    const checkBoxes = fixture.debugElement.queryAll(By.css('.mat-checkbox-input'));
    expect(checkBoxes.length).toBe(3);
  });

  it('should display proper labels for all the checkboxes', () => {
    const checkBoxes = fixture.debugElement.queryAll(By.css('.mat-checkbox-label'));
    const array: Array<string> = [];
    checkBoxes.forEach(element => array.push(element.nativeElement.textContent.trim()));
    expect(array).toEqual(fields.map(it => it.label).concat(extractAllCheckbox));
  });

  describe('checkbox' , () => {

    it('select will generate checked event', () => {
      const checkboxElement = findCheckBoxElement(checkbox1.id);

      expect(findCheckBox(checkbox1.id).selected).toBe(false);
      itemClick(checkboxElement);

      expect(findCheckBox(checkbox1.id).selected).toBe(true);
      expect(extractCSVButton.nativeElement.disabled).toBe(false);
    });

    it('unselect will generate unchecked event', () => {
      const checkboxElement = findCheckBoxElement(checkbox1.id);

      itemClick(checkboxElement, false);
      expect(findCheckBox(checkbox1.id).selected).toBe(false);
      expect(extractCSVButton.nativeElement.disabled).toBe(true);
    });

  });

  describe('extract all checkboxes' , () => {

    it('selection will check all the checkboxes ', () => {
      const extractAllCheckboxElement = findCheckAllBoxElement();

      itemClick(extractAllCheckboxElement);
      fields.forEach(it => expect(findCheckBox(it.id).selected).toBe(true));
      expect(extractCSVButton.nativeElement.disabled).toBe(false);
    });

    it('unselect will generate unchecked event', () => {
      const extractAllCheckboxElement = findCheckAllBoxElement();

      itemClick(extractAllCheckboxElement, false);
      fields.forEach(it => expect(findCheckBox(it.id).selected).toBe(false));
      expect(extractCSVButton.nativeElement.disabled).toBe(true);
    });

  });

  describe('clicking cancel', () => {

    beforeEach(() => {
      cancelButton.nativeElement.click();
    });

    it('closes dialog', () => {
      expect(matDialogRef.close).toHaveBeenCalled();
    });
  });

  describe('clicking extract to csv', () => {

    describe('for some selected checkboxes', () => {
      beforeEach(() => {
        const checkboxElement = findCheckBoxElement(checkbox1.id);
        itemClick(checkboxElement);
        expect(findCheckBox(checkbox1.id).selected).toBe(true);
        extractCSVButton.nativeElement.click();
      });

      it('closes dialog and returns selected checkboxes', () => {
        expect(matDialogRef.close).toHaveBeenCalledWith([checkbox1.id]);
      });
    });

    describe('for all checkboxes', () => {
      beforeEach(() => {
        itemClick(findCheckAllBoxElement());

        fields.forEach(it => expect(findCheckBox(it.id).selected).toBe(true));
        extractCSVButton.nativeElement.click();
      });

      it('closes dialog and returns all checkboxes', () => {
        expect(matDialogRef.close).toHaveBeenCalledWith([]);
      });
    });

  });


  function itemClick(item: DebugElement , checked: boolean = true) {
    checkboxChange.checked = checked;
    item.nativeElement.click();
    item.triggerEventHandler('change', checkboxChange);
    fixture.detectChanges();
  }

  function findCheckBox(checkBoxId: string ) {
    return component.selectedAttributes.find(item => item.id === checkBoxId);
  }

  function findCheckBoxElement(checkBoxId: string ) {
   return fixture.debugElement.query(By.css(`.extract-csv__checkboxes-${checkBoxId}`));
  }

  function findCheckAllBoxElement() {
    return fixture.debugElement.query(By.css('.extract-csv__dialog-content__extract-all'));
   }
});
