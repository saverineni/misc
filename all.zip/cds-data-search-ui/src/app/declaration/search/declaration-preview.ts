import { Country } from '../country';

export class DeclarationPreview {
  declarationId: string;
  importExportIndicator: string;
  declarationSource: string;
  epuNumber: string;
  entryNumber: string;
  entryDate: string;
  route: string;
  dispatchCountry: Country;
  destinationCountry: Country;
  goodsLocation: string;
  transportModeCode: string;
  lineCount: number;
}
