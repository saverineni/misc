export class SearchCriteria {
  pageNumber: number;
  pageSize: number;
  searchTerm: string;
  originCountryCode: string[];
  dispatchCountryCode: string[];
  destinationCountryCode: string[];
  transportModeCode: string[];
  goodsLocation: string[];
  commodityCode: string[];
  cpc: string[];
  declarationType: string[];
  declarationSource: string[];
  preferenceNumber: string[];
  processingStatus: string[];
  entryDateFrom: string;
  entryDateTo: string;
  clearanceDateFrom: string;
  clearanceDateTo: string;
  acceptanceDateFrom: string;
  acceptanceDateTo: string;
  netMassFrom: string;
  netMassTo: string;
  itemPriceFrom: string;
  itemPriceTo: string;
  eori: string;

  isEmpty(): boolean {
    return Object.getOwnPropertyNames(this)
                 .find(property  => this[property] !== undefined && this[property] !== null) === undefined;
  }

  filtersEmpty(): boolean {
    return Object.getOwnPropertyNames(this)
                  .filter(key => ['pageNumber', 'pageSize', 'searchTerm'].indexOf(key) === -1)
                  .find(property  => this[property] !== undefined && this[property] !== null) === undefined;
  }
}
