import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {SearchPaginatorComponent} from './search-paginator.component';
import {SearchCriteriaService} from '../search-criteria.service';
import {SearchCriteria} from '../search-criteria';
import {Observable, of, Subscription} from 'rxjs';
import {MatPaginator, MatPaginatorIntl, MatPaginatorModule , PageEvent} from '@angular/material';
import {SearchPaginatorIntl} from './search-paginator';
import {NoopAnimationsModule} from '@angular/platform-browser/animations';
import {By} from '@angular/platform-browser';

describe('SearchPaginatorComponent', () => {
  let component: SearchPaginatorComponent;
  let fixture: ComponentFixture<SearchPaginatorComponent>;
  let searchCriteriaService: SearchCriteriaService;
  let testObservable: Observable<SearchCriteria>;
  let testSubscription: Subscription;
  let successHandler;

  beforeEach(async(() => {
    testObservable = of(new SearchCriteria());
    testSubscription = new Subscription();

    spyOn(testObservable, 'subscribe').and.callFake(
      success => {
        successHandler = success;
        return testSubscription;
      }
    );
    spyOn(testSubscription, 'unsubscribe');

    searchCriteriaService = {
      searchCriteria: testObservable,
      updatePartial: (searchCriteria) => { }
    } as SearchCriteriaService;

    spyOn(searchCriteriaService, 'searchCriteria');
    spyOn(searchCriteriaService, 'updatePartial');

    TestBed.configureTestingModule({
      imports: [ MatPaginatorModule, NoopAnimationsModule ],
      declarations: [ SearchPaginatorComponent ],
      providers: [
        {provide: MatPaginatorIntl, useClass: SearchPaginatorIntl},
        {provide: SearchCriteriaService, useValue: searchCriteriaService}
      ]
    })
    .compileComponents();

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchPaginatorComponent);
    component = fixture.componentInstance;
    component.totalResults = 100;
    fixture.detectChanges();
  });

  describe('paginator', () => {
    let paginator: MatPaginator;

    beforeEach(() => {
      expect(component).toBeTruthy();
      paginator = component.paginator;
      expect(paginator).toBeTruthy();
    });

    it('exists', () => {
      expect(paginator).toBeTruthy();
    });

    it('should have page size set to 10', () => {
      expect(paginator.pageSize).toBe(10);
    });

    it('should have page index set to 0', () => {
      expect(paginator.pageIndex).toBe(0);
    });

    it('should have page size set to 10', () => {
      expect(paginator.pageSize).toBe(10);
    });

    it('should have page size options', () => {
      expect(paginator.pageSizeOptions).toEqual([10, 20, 30, 40, 50]);
    });

    it('should show the right range text for page 0', () => {
      expect(paginatorRangeLabelText()).toEqual('1 - 10 of 100');
    });

    it('should show the right range text for page 1', () => {
      paginator.pageIndex = 1;
      fixture.detectChanges();
      expect(paginatorRangeLabelText()).toEqual('11 - 20 of 100');
    });

    it('should display the correct label text', () => {
      const label = fixture.debugElement.query(By.css('.mat-select')).nativeElement;
      expect(label.getAttribute('aria-label')).toBe('Declarations per page');
    });

  });

  describe('on initialisation', () => {
    it('should subscribe to search criteria updates', () => {
      expect(successHandler).toBeTruthy();
    });
  });

  describe('succesful updates to search criteria', () => {
    const newSearchCriteria = new SearchCriteria();
    beforeEach(() => {
      newSearchCriteria['pageNumber'] = 2;
      newSearchCriteria['pageSize'] = 20;
      successHandler(newSearchCriteria);
      fixture.detectChanges();
    });

    it('should update page index and page size', () => {
      const paginator: MatPaginator = component.paginator;
      expect(paginator.pageIndex).toBe(1);
      expect(paginator.pageSize).toBe(20);
      expect(paginatorRangeLabelText()).toEqual('21 - 40 of 100');
    });

  });

  describe('page events', () => {
    beforeEach(() => {
      const debugElement = fixture.debugElement.query(By.css('.mat-paginator-navigation-next'));
      debugElement.triggerEventHandler('click', new PageEvent());
      fixture.detectChanges();
    });

    it('should update the search criteria service with page number and page size', () => {
      const searchCriteria: any = {};
      searchCriteria.pageNumber = 2;
      searchCriteria.pageSize = 10;
      expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteria);
      expect(paginatorRangeLabelText()).toEqual('11 - 20 of 100');
    });
  });

  describe('on destroy', () => {
    beforeEach(() => {
      fixture.destroy();
    });

    it('should unsubscribe from search criteria updates', () => {
      expect(testSubscription.unsubscribe).toHaveBeenCalled();
    });
  });

  function paginatorRangeLabelText() {
    const paginatorRangeLabel = fixture.debugElement.query(By.css('.mat-paginator-range-label')).nativeElement;
    return paginatorRangeLabel.innerText;
  }

});
