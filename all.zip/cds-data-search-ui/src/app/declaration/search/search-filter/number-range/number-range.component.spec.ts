import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NumberRangeComponent } from './number-range.component';
import { By } from '@angular/platform-browser';
import {
  MAT_DATE_LOCALE,
  MatExpansionModule,
  MatFormFieldModule,
  MatInputModule,
  MatDividerModule
} from '@angular/material';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SearchCriteriaService } from '../../search-criteria.service';
import { TogglePanelService } from '../toggle-panel.service';

describe('NumberRangeComponent', () => {
  let component: NumberRangeComponent;
  let fixture: ComponentFixture<NumberRangeComponent>;
  let searchCriteriaService: SearchCriteriaService;
  let togglePanelService: TogglePanelService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, BrowserAnimationsModule, MatFormFieldModule,
        MatExpansionModule, MatInputModule, MatDividerModule],
      declarations: [ NumberRangeComponent ],
      providers: [
        {provide: MAT_DATE_LOCALE, useValue: 'en-GB'}, SearchCriteriaService , TogglePanelService
      ]
    })
    .compileComponents();
  }));

  let filterExpansionPanel;

  beforeEach(() => {
    fixture = TestBed.createComponent(NumberRangeComponent);
    component = fixture.componentInstance;
    component.label = 'netMass';
    component.fromField = 'netMassFrom';
    component.toField = 'netMassTo';
    component.maxValue = 1000;
    searchCriteriaService = TestBed.get(SearchCriteriaService);
    togglePanelService = TestBed.get(TogglePanelService);
    filterExpansionPanel = fixture.debugElement.query(By.css('.number-range__header'));
    spyOn(component.panel, 'open');
    spyOn(component.panel, 'close');
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('within expansion panel', () => {

    let fromInput;
    let toInput;
    let applyFiltersButton;
    let clearButton;
    const from = 1.2;
    const to = 3.4;

    beforeEach(() => {
      fromInput = fixture.debugElement.query(By.css('.number-range__from-input'));
      toInput = fixture.debugElement.query(By.css('.number-range__to-input'));
      applyFiltersButton = fixture.debugElement.query(By.css('.number-range__apply-filters-button'));
      clearButton = fixture.debugElement.query(By.css('.number-range__clear-button'));
      filterExpansionPanel.nativeElement.click();
      fixture.detectChanges();
    });

    describe('number range inputs', () => {

      it('from input should be bound to the from model', () => {
        givenFrom(from);
        expect(component.from).toEqual(from);
      });

      it('to input should be bound to the to model', () => {
        givenTo(to);
        expect(component.to).toEqual(to);
      });

    });

    describe('toggle panel', () => {
      beforeEach(() => {
        givenFrom(from);
        component.toggleExpansionPanel();
      });

      it('should open the panel', () => {
        expect(component.panel.open).toHaveBeenCalled();
      });
    });

    describe('number range input validation', () => {

      it('when from is greater than to', () => {
        givenFrom(to);
        givenTo(from);
        clickApplyFilter();

        const errorMessage = fixture.debugElement.query(By.css('.number-range__from-value-greater'));
        expect(errorMessage).toBeTruthy();
      });

      it('when to is null (no value) should not be greater than from (with value)', () => {
        givenFrom(from);
        givenTo(null);
        clickApplyFilter();

        const errorMessage = fixture.debugElement.query(By.css('.number-range__from-value-greater'));
        expect(errorMessage).toBeFalsy();
      });

      it('when from is greater than max value', () => {
        givenFrom('2000');
        clickApplyFilter();

        const greaterThanMaxErrorMessage = fixture.debugElement.query(By.css('.number-range__exceeds-max-value'));
        expect(greaterThanMaxErrorMessage).toBeTruthy();
      });

      it('when to is greater than max value', () => {
        givenTo('2000');
        clickApplyFilter();

        const greaterThanMaxErrorMessage = fixture.debugElement.query(By.css('.number-range__exceeds-max-value'));
        expect(greaterThanMaxErrorMessage).toBeTruthy();
      });

      function clickApplyFilter() {
        applyFiltersButton.nativeElement.click();
        fixture.detectChanges();
      }

    });

    describe('apply filters button', () => {

      it('should start disabled', () => {
        expect(applyFiltersButton.nativeElement.disabled).toBe(true);
      });

      describe('should be disabled with invalid input', () => {
        afterEach(() => {
          fixture.detectChanges();
          expect(applyFiltersButton.nativeElement.disabled).toBe(true);
        });

        it('when an invalid number is entered into the from input', () => {
          fromInput.nativeElement.value = 'invalid';
          fromInput.nativeElement.dispatchEvent(new Event('input'));
        });

        it('when an invalid number is entered into the to input', () => {
          toInput.nativeElement.value = 'invalid';
          toInput.nativeElement.dispatchEvent(new Event('input'));
        });
      });

      describe('should be enabled', () => {
        afterEach(() => {
          fixture.detectChanges();
          expect(applyFiltersButton.nativeElement.disabled).toBe(false);
        });

        it('when a valid number is entered into the from input', () => {
          fromInput.nativeElement.value = from;
          fromInput.nativeElement.dispatchEvent(new Event('input'));
        });

        it('when a valid number is entered into the to input', () => {
          toInput.nativeElement.value = to;
          toInput.nativeElement.dispatchEvent(new Event('input'));
        });

        it('when from number is after to number', () => {
          fromInput.nativeElement.value = to;
          fromInput.nativeElement.dispatchEvent(new Event('input'));

          toInput.nativeElement.value = from;
          toInput.nativeElement.dispatchEvent(new Event('input'));
        });

        it('when zero entered into the to input', () => {
          toInput.nativeElement.value = 0;
          toInput.nativeElement.dispatchEvent(new Event('input'));
        });

      });

    });

    describe('submit filters',  () => {
      beforeEach ( () => {
        spyOn(searchCriteriaService, 'updatePartial');
        givenFrom(from);
        givenTo(to);
      });

      it('should update the search criteria service when apply filters clicked', () => {
        applyFiltersButton.nativeElement.click();
        const searchCriteria: any = {};
        searchCriteria.netMassFrom = from;
        searchCriteria.netMassTo = to;
        searchCriteria.pageNumber = undefined;
        searchCriteria.pageSize = undefined;
        expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteria);
      });

      it('clears the numbers and should update the search criteria service when cancel clicked', () => {
        clearButton.nativeElement.click();
        const searchCriteria: any = {};
        searchCriteria.netMassFrom = null;
        searchCriteria.netMassTo = null;
        searchCriteria.pageNumber = undefined;
        searchCriteria.pageSize = undefined;
        expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteria);
      });
    });

    describe('clear button', () => {
      it('should contain clear label', () => {
        const clearLabel = clearButton.nativeElement;
        expect(clearLabel.textContent).toEqual('Clear');
      });

      it('should be enabled when an invalid number is entered into the from input', () => {
        fromInput.nativeElement.value = 'invalid';
        fromInput.nativeElement.dispatchEvent(new Event('input'));
        fixture.detectChanges();
        expect(clearButton.nativeElement.disabled).toBe(false);
      });

      it('should clear invalid input field when clicked', () => {
        fromInput.nativeElement.value = 'invalid';
        fromInput.nativeElement.dispatchEvent(new Event('input'));
        toInput.nativeElement.value = 'invalid';
        toInput.nativeElement.dispatchEvent(new Event('input'));
        fixture.detectChanges();

        clearButton.nativeElement.click();
        expect(fromInput.nativeElement.value).toEqual('');
        expect(toInput.nativeElement.value).toEqual('');
      });
    });

    function givenFrom(value: any) {
      fromInput.nativeElement.value = value;
      fromInput.nativeElement.dispatchEvent(new Event('input'));
      fixture.detectChanges();
    }

    function givenTo(value: any) {
      toInput.nativeElement.value = value;
      toInput.nativeElement.dispatchEvent(new Event('input'));
      fixture.detectChanges();
    }

  });


  describe('number range filter expansion panel', () => {
    beforeEach(() => {
      spyOn(togglePanelService, 'updatePartial');
    });

    it('should not start expanded', () => {
      expect(filterExpansionPanel.nativeElement.classList).not.toContain('mat-expanded');
    });

    describe('when clicked', () => {
      beforeEach(() => {
        filterExpansionPanel.nativeElement.click();
        fixture.detectChanges();
      });

      it('should be expanded', () => {
        expect(filterExpansionPanel.nativeElement.classList).toContain('mat-expanded');
      });

      it('should call toggle panel service', () => {
        expect(togglePanelService.updatePartial).toHaveBeenCalled();
      });

      it('should collapse when clicked again', () => {
        filterExpansionPanel.nativeElement.click();
        fixture.detectChanges();
        expect(filterExpansionPanel.nativeElement.classList).not.toContain('mat-expanded');
      });
    });
  });
});
