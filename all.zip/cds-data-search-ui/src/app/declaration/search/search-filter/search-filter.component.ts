import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  HostListener,
  Inject,
  OnDestroy,
  OnInit
} from '@angular/core';
import {TrackBy} from '../../../track-by';
import {SearchCriteriaService} from '../search-criteria.service';
import {Subscription} from 'rxjs';
import {SearchCriteria} from '../search-criteria';
import {DOCUMENT} from '@angular/common';
import {TogglePanel} from './toggle-panel';
import {TogglePanelService} from './toggle-panel.service';

@Component({
  selector: 'cds-search-filter',
  templateUrl: './search-filter.component.html',
  styleUrls: ['./search-filter.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SearchFilterComponent implements OnInit, OnDestroy {
  private SCROLL_SEARCH_THRESHOLD = 170;
  private criteriaSubscription: Subscription;
  private searchCriteria: SearchCriteria;

  trackByIndex = TrackBy.index;
  unknownChipName = 'Unknown';
  scrolled = false;

  private processingStatusToolTipText = `1 - Received
                                                 2 - Rejected
                                                 3 - Registered
                                                 4 - Accepted
                                                 7 - Under Amendment
                                                 8 - Preparing for Release
                                                 9 - Provisional Customs Debt Determined
                                                 10 - Provisional Customs Debt Covered
                                                 11 - Goods Released
                                                 12 - Preparing for Clearance
                                                 13 - Final Customs Debt Determined
                                                 14 - Final Customs Debt Covered
                                                 15 - Clearance Provided
                                                 16 - Completed Successfully
                                                 17 - Handled externally (no clearance)
                                                 18 - Invalidated
                                                 26 - Irregularity Detected
                                                 27 - Functional Exception Detected`;

  private cpcToolTipText = `Accepted CPC formats are as below.

                            1 -   XX*****
                            2 -   **XX***
                              3 -   ****XXX
                              4 -   ****X**
                              5 -   XXXX***
                              6 -   XXXXXXX`;

  facets: Array<any> = [
    {
      label: 'Country of Origin',
      searchParam: 'originCountryCode'
    }, {
      label: 'Country of Dispatch',
      searchParam: 'dispatchCountryCode'
    },
    {
      label: 'Country of Destination',
      searchParam: 'destinationCountryCode'
    },
    {
      label: 'Mode of Transport',
      searchParam: 'transportModeCode'
    }, {
      label: 'Goods Location',
      searchParam: 'goodsLocation'
    }, {
      label: 'Commodity Code',
      searchParam: 'commodityCode',
      facetSearch: {
        length: 2,
        type: 'numbers'
      }
    }, {
      label: 'CPC',
      searchParam: 'cpc',
      facetSearch: {
        length: 7,
        type: 'alpha numeric or asterisks',
        validation: '(([a-zA-Z0-9]{2}|[*]{2})([a-zA-Z0-9]{2}|[*]{2})(([a-zA-Z0-9]{1}[*]{2})|([*]{3})|([a-zA-Z0-9]{3}))$)'
      },
      toolTipText: this.cpcToolTipText
    }, {
      label: 'Preference Number',
      searchParam: 'preferenceNumber',
      facetSearch: {
        length: 1,
        type: 'number'
      }
    },
    {
      label: 'Declaration Type (Imports)',
      searchParam: 'declarationType'
    },
    {
      label: 'Processing Status',
      searchParam: 'processingStatus',
      toolTipText: this.processingStatusToolTipText
    }
  ];

  constructor(private searchCriteriaService: SearchCriteriaService,
              private changeDetectorRef: ChangeDetectorRef,
              private togglePanelService: TogglePanelService,
              @Inject(DOCUMENT) private document: Document) { }

  ngOnInit() {
    this.criteriaSubscription = this.searchCriteriaService.searchCriteria.subscribe(
      criteria => {
        this.searchCriteria = criteria;
        this.facets.forEach((it: any) =>
          it.chips = this.mapChipsFromSearchCriteria(this.searchCriteria[it.searchParam])
        );

        this.changeDetectorRef.markForCheck();
      }
    );
  }

  private mapChipsFromSearchCriteria(criteria) {
    return criteria && criteria.map(chipId => chipId === '' ? this.unknownChipName : chipId);
  }

  removeSelectedChip(chipId, facetType) {
    const update = {};
    chipId = chipId === this.unknownChipName ? '' : chipId;
    let newSelection = this.searchCriteria[facetType].filter(id => id !== chipId);
    if (newSelection.length === 0) {
      newSelection = null;
    }
    update[facetType] = newSelection;
    update['pageNumber'] = undefined;
    update['pageSize'] = undefined;
    this.searchCriteriaService.updatePartial(update);
  }

  ngOnDestroy() {
    if (this.criteriaSubscription) {
      this.criteriaSubscription.unsubscribe();
    }
  }

  clearAllActive() {
    return (this.searchCriteria && !this.searchCriteria.filtersEmpty()) || false;
  }

  clearAll() {
    if (this.clearAllActive()) {
      this.togglePanelService.replace(new TogglePanel());
      const update = new SearchCriteria();
      update.searchTerm = this.searchCriteria.searchTerm;
      this.searchCriteriaService.replace(update);
    }
  }

  @HostListener('window:scroll', ['$event'])
  onScrollEvent(event) {
    const scrollPosition = this.document.documentElement.scrollTop || this.document.body.scrollTop || 0;
    if (scrollPosition >= this.SCROLL_SEARCH_THRESHOLD) {
      this.scrolled = true;
    } else {
      this.scrolled = false;
    }
  }
}
