import { TogglePanel } from './toggle-panel';
import { camelCase } from 'lodash';

describe('TogglePanel', () => {

  describe('is empty', () => {
    it('should give true when no values set', () => {
      const togglePanel = new TogglePanel();
      expect(togglePanel.isEmpty()).toBe(true);
    });
  });

  describe('is not empty', () => {
    let togglePanel: TogglePanel;

    beforeEach(() => {
      togglePanel = new TogglePanel();
    });

    it('should give false when eori panel is set', () => {
      togglePanel.eori = true;
      expect(togglePanel.isEmpty()).toBe(false);
    });

    it('should give false when entry date panel is set', () => {
      togglePanel.entryDate = true;
      expect(togglePanel.isEmpty()).toBe(false);
    });

    it('should give false when clearance date panel is set', () => {
      togglePanel.clearanceDate = true;
      expect(togglePanel.isEmpty()).toBe(false);
    });

    it('should give false when acceptance date panel is set', () => {
      togglePanel.acceptanceDate = true;
      expect(togglePanel.isEmpty()).toBe(false);
    });

    it('should give false when declaration type panel is set', () => {
      togglePanel.declarationType = true;
      expect(togglePanel.isEmpty()).toBe(false);
    });

    it('should give false when declaration source panel is set', () => {
      togglePanel.declarationSource = true;
      expect(togglePanel.isEmpty()).toBe(false);
    });

    it('should give false when clearance date panel is set1', () => {
      expect(camelCase('Clearance Date')).toBe('clearanceDate');
      expect(camelCase('EORI')).toBe('eori');
    });

  });

  describe('is closed', () => {
    let togglePanel: TogglePanel;

    beforeEach(() => {
      togglePanel = new TogglePanel();
    });

    it('should give false when nothing is set', () => {
      expect(togglePanel.isOpened('eori')).toBe(false);
    });

    it('should give true when eori panel is opened', () => {
      togglePanel.eori = true;
      expect(togglePanel.isOpened('eori')).toBe(true);
    });

    it('should give true when entry date panel is opened', () => {
      togglePanel.entryDate = true;
      expect(togglePanel.isOpened('entryDate')).toBe(true);
    });

    it('should give true when clearance date panel is opened', () => {
      togglePanel.clearanceDate = true;
      expect(togglePanel.isOpened('clearanceDate')).toBe(true);
    });

    it('should give true when acceptance date panel is opened', () => {
      togglePanel.acceptanceDate = true;
      expect(togglePanel.isOpened('acceptanceDate')).toBe(true);
    });

    it('should give true when declaration type panel is opened', () => {
      togglePanel.declarationType = true;
      expect(togglePanel.isOpened('declarationType')).toBe(true);
    });

    it('should give true when declaration source panel is opened', () => {
      togglePanel.declarationSource = true;
      expect(togglePanel.isOpened('declarationSource')).toBe(true);
    });

  });
});
