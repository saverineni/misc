import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ElementRef,
  Input,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation
} from '@angular/core';
import { SearchCriteria } from '../../search-criteria';
import * as moment from 'moment';
import { SearchCriteriaService } from '../../search-criteria.service';
import { NgModel } from '@angular/forms';
import { camelCase } from 'lodash';
import { TogglePanelService } from '../toggle-panel.service';
import { TogglePanel } from '../toggle-panel';

@Component({
  selector: 'cds-date-range-filter',
  templateUrl: './date-range.component.html',
  styleUrls: ['./date-range.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class DateRangeComponent implements OnInit, OnDestroy {
  DATE_FORMAT = 'YYYY-MM-DD';
  dateFrom: string = null;
  dateTo: string = null;
  datePrecedes = false;
  futureDate = false;

  private closePanel: boolean;
  private openPanel: boolean;

  private searchCriteriaSubscription;
  private togglePanelSubscription;
  private togglePanelField;
  private searchCriteria: SearchCriteria = null;

  @Input() label: string;
  @Input() fromField: string;
  @Input() toField: string;
  @ViewChild('datePanel') datePanel;
  @ViewChild('fromDate') fromDate: NgModel;
  @ViewChild('toDate') toDate: NgModel;
  @ViewChild('fromDate', { read: ElementRef }) fromDateElementRef: ElementRef;
  @ViewChild('toDate', { read: ElementRef }) toDateElementRef: ElementRef;

  constructor(private searchCriteriaService: SearchCriteriaService,
              private togglePanelService: TogglePanelService,
              private changeDetectorRef: ChangeDetectorRef) { }

  ngOnInit() {
    this.togglePanelField = camelCase(this.label);
    this.searchCriteriaSubscription = this.searchCriteriaService.searchCriteria.subscribe(
      data  => {
        this.searchCriteria = data as SearchCriteria;
        this.datePrecedes = false;
        this.futureDate = false;
        this.dateFrom = this.searchCriteria[this.fromField];
        this.dateTo = this.searchCriteria[this.toField];
        this.toggleExpansionPanel();
        this.changeDetectorRef.detectChanges();
      }
    );

    this.togglePanelSubscription = this.togglePanelService.togglePanel.subscribe(
      (data: TogglePanel) => {
        this.openPanel = data.isOpened(this.togglePanelField);
        this.closePanel = data.isClosed(this.togglePanelField);
        this.toggleExpansionPanel();
      });
  }

  toggleExpansionPanel() {
    if (this.isDataExists() && !this.closePanel) {
      this.datePanel.open();
    } else if (!this.openPanel) {
      this.datePanel.close();
    }
  }

  fromMaxDate(): Date {
    if (!this.dateTo) {
      return new Date();
    } else {
      return moment(this.dateTo).toDate();
    }
  }

  toMinDate(): Date {
    if (!this.dateFrom) {
      return null;
    } else {
      return moment(this.dateFrom).toDate();
    }
  }

  toMaxDate(): Date {
    return new Date();
  }

  onClear() {
    this.resetModel(this.fromDate, this.fromDateElementRef);
    this.resetModel(this.toDate, this.toDateElementRef);

    this.dateFrom = null;
    this.dateTo = null;
    this.onApplyFilters();
  }

  ngOnDestroy(): void {
    this.searchCriteriaSubscription.unsubscribe();
    this.togglePanelSubscription.unsubscribe();
  }

  onApplyFilters() {

    this.datePrecedes = this.fromDatePrecedesToDate();
    this.futureDate = this.isFutureDate();

    const updates: any = {};
    if (this.dateFrom !== null) {
      updates[this.fromField] = moment(this.dateFrom).format(this.DATE_FORMAT);
    } else {
      updates[this.fromField] = null;
    }
    if (this.dateTo !== null) {
      updates[this.toField] = moment(this.dateTo).format(this.DATE_FORMAT);
    } else {
      updates[this.toField] = null;
    }

    updates['pageNumber'] = undefined;
    updates['pageSize'] = undefined;

    if (this.fromDate.valid && this.toDate.valid) {
      this.searchCriteriaService.updatePartial(updates);
    }
  }

  private resetModel(model: NgModel, elementRef: ElementRef) {
    elementRef.nativeElement.value = null;
    model.control.root.reset();
  }

  private fromDatePrecedesToDate() {
    return moment(this.dateFrom).isAfter(this.dateTo);
  }

  private isFutureDate() {
    return moment(this.dateFrom).isAfter(this.toMaxDate()) || moment(this.dateTo).isAfter(this.toMaxDate());
  }

  onToggle(expand: boolean) {
    this.togglePanelService.toggle(this.togglePanelField, expand);
  }

  private isDataExists() {
    return this.dateFrom || this.dateTo;
  }

}
