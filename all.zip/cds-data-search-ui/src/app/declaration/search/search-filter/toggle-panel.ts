export class TogglePanel {
    eori: boolean;
    netMass: boolean;
    entryDate: boolean;
    clearanceDate: boolean;
    acceptanceDate: boolean;
    declarationType: boolean;
    declarationSource: boolean;

    isEmpty(): boolean {
        return Object.getOwnPropertyNames(this)
                     .find(property  => this[property] !== undefined && this[property] !== null) === undefined;
    }

    isOpened(property): boolean {
        return this[property] === true;
    }

    isClosed(property): boolean {
        return this[property] === false;
    }
}
