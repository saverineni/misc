export class Country {
    code: string;
}
