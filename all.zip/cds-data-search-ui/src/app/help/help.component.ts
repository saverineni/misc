import {Component, ViewEncapsulation} from '@angular/core';

@Component({
  selector: 'cds-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.scss'],
  encapsulation : ViewEncapsulation.None
})
export class HelpComponent {}
