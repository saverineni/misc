import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HelpComponent } from './help.component';
import { By } from '@angular/platform-browser';
import { MatDividerModule, MatTabsModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('HelpComponent', () => {
  let fixture: ComponentFixture<HelpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        MatTabsModule,
        MatDividerModule,
        BrowserAnimationsModule
      ],
      declarations: [HelpComponent]
    })
      .compileComponents();
  }));


  beforeEach(() => {
    fixture = TestBed.createComponent(HelpComponent);
    fixture.detectChanges();

  });

  it('should display faqs label', () => {
    const label = fixture.debugElement.query(By.css('.help-tab__label[data-help-type="faqs"]'));
    expect(label.nativeElement.textContent).toBe('FAQs');
  });

  it('should display pdfs and links label', () => {
    const label = fixture.debugElement.query(By.css('.help-tab__label[data-help-type="pdfs-links"]'));
    expect(label.nativeElement.textContent).toBe('PDFs and Links');
  });

  it('should display user guides', () => {
    const label = fixture.debugElement.query(By.css('.help-tab__label[data-help-type="user-guides"]'));
    expect(label.nativeElement.textContent).toBe('User Guides');
  });

  it('should display need more help label', () => {
    const need_more_help_label = fixture.debugElement.query(By.css('.help-content__more-help-pre-text')).nativeElement;
    expect(need_more_help_label.textContent).toBe('Still need help?');
  });
});
