import {ChangeDetectionStrategy, Component, Input} from '@angular/core';
import {NavigationService} from '../../declaration/search/navigation.service';
import {SignInRouterService} from '../../authentication/sign-in/sign-in-router.service';
import {AuthenticationService} from '../../authentication/authentication.service';
import { TogglePanelService } from '../../declaration/search/search-filter/toggle-panel.service';
import { TogglePanel } from '../../declaration/search/search-filter/toggle-panel';

@Component({
  selector: 'cds-navbar',
  templateUrl: './cds-navbar.component.html',
  styleUrls: ['./cds-navbar.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CdsNavbarComponent {

  @Input() homeLabel;
  @Input() isSignInPage;
  backgroundColor: string;
  greenColor = '#10866E';
  darkGreenColor = '#0C6B58';


  constructor(private navigationService: NavigationService,
              private authenticationService: AuthenticationService,
              private togglePanelService: TogglePanelService,
              private signInRouterService: SignInRouterService) {}

  navigateToSearch() {
    this.backgroundColor = this.greenColor;
    this.togglePanelService.replace(new TogglePanel());
    this.navigationService.navigateToSearch(true);
  }

  signOut() {
    this.authenticationService.signOut();
    this.navigateToSearch();
    this.signInRouterService.navigateToSignIn(undefined);
  }

  help() {
    this.navigationService.navigateToHelp();
  }

  changeBackground() {
    this.backgroundColor = this.darkGreenColor;
  }

}
