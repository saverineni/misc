import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {TooltipComponent} from './cds-tooltip.component';
import {MatTooltipModule} from '@angular/material';
import {By} from '@angular/platform-browser';

describe('TooltipComponent', () => {
  let component: TooltipComponent;
  let fixture: ComponentFixture<TooltipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TooltipComponent ],
      imports: [
        MatTooltipModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TooltipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Tooltip', () => {

    it('should display icon', () => {
      expect(fixture.debugElement.query(By.css('.tooltip__icon')).nativeElement.textContent).toEqual('i');
    });

  });


});
