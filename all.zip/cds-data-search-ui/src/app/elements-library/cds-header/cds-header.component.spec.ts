import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { CdsHeaderComponent } from './cds-header.component';
import { Component } from '@angular/core';

@Component({
  selector: 'cds-test-inner',
  template: '<span class="test-content">child component content</span>'
})
class TestInnerComponent {}

@Component({
  selector: 'cds-test-host-component',
  template: `
    <cds-header [title]="'the title'">
      <cds-test-inner #headerDetail></cds-test-inner>
    </cds-header>
  `
})
class TestHostComponent {}

describe('CdsHeaderComponent', () => {
  let component: TestHostComponent;
  let fixture: ComponentFixture<TestHostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CdsHeaderComponent, TestInnerComponent, TestHostComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestHostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should add the title', () => {
    const title = fixture.debugElement.query(By.css('h1')).nativeElement;
    expect(title.textContent).toBe('the title');
  });

  it('should add the header detail', () => {
    const headerDetail = fixture.debugElement.query(By.css('.header__inner-detail')).nativeElement;

    expect(headerDetail.textContent.trim()).toBe('child component content');
  });
});
