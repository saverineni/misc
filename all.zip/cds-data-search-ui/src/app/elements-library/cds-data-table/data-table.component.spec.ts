import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatTableModule } from '@angular/material';
import { DataTableComponent } from './data-table.component';
import { By } from '@angular/platform-browser';

const ELEMENT_DATA = [
  {position: '1', user: 'Search User1', department: 'Search'},
  {position: '2', user: 'Search User2', department: 'Report'}
];

const HEADER_DATA = [
  {id: 'position', label: 'Position'},
  {id: 'user', label: 'User Name'}
];

const FILTER_TEXT = 'Search User2';

describe('DataTableComponent', () => {
  let component: DataTableComponent;
  let fixture: ComponentFixture<DataTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MatTableModule],
      declarations: [ DataTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataTableComponent);
    component = fixture.componentInstance;
    component.dataSource = ELEMENT_DATA;
    component.headers = HEADER_DATA;
    component.filterText = FILTER_TEXT;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('should display', () => {
    const getRootElement = () => fixture.debugElement.query(By.css('.data-table'));

    it('all header labels' , () => {
      expect(getContent('.data-table__headercell')).toEqual(['Position', 'User Name']);
    });

    it('all the table content' , () => {
      expect(getContent('.data-table__cell')).toEqual(['1', 'Search User1', '2', 'Search User2']);
    });

    it('the search term with the hightlighted class', () => {
      const searchTermElement = getRootElement().query(By.css('.data-table__cell.highlight')).nativeElement;
      expect(searchTermElement).toBeTruthy();
      expect(searchTermElement.innerText).toBe('Search User2');
    });

     function getContent(filter) {
      return getRootElement().queryAll(By.css(filter))
        .map(e => e.nativeElement.innerText.trim());
    }

  });

});
