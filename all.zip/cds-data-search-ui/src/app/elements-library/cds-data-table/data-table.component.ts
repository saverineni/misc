import { Component, OnInit , Input , ViewEncapsulation, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'cds-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DataTableComponent implements OnInit {

  @Input() dataSource: Array<any>;
  @Input() headers: Array<any>;
  @Input() filterText: string;

  constructor() { }

  ngOnInit() {
  }

  headerLabels(): string[] {
    return this.headers.map(header => header.label);
  }

  matchesFilterText(value) {
    if (!this.filterText || !value) {
      return false;
    }
    return value.toLowerCase().includes(this.filterText.toLowerCase());
  }
}
