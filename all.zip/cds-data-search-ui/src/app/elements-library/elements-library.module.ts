import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CdsHeaderComponent } from './cds-header/cds-header.component';
import { CdsNavbarComponent } from './cds-navbar/cds-navbar.component';
import { RouterModule } from '@angular/router';
import { DataGridComponent } from './cds-data-grid/data-grid.component';
import { MatGridListModule, MatTooltipModule , MatIconModule , MatTableModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CdsFooterComponent } from './cds-footer/cds-footer.component';
import { TooltipComponent } from './cds-tooltip/cds-tooltip.component';
import { DataTableComponent } from './cds-data-table/data-table.component';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    RouterModule,
    MatGridListModule,
    MatIconModule,
    MatTableModule,
    MatTooltipModule
  ],
  declarations: [CdsHeaderComponent, CdsNavbarComponent, DataGridComponent, CdsFooterComponent, TooltipComponent, DataTableComponent],
  exports: [CdsHeaderComponent, CdsNavbarComponent, DataGridComponent, CdsFooterComponent, TooltipComponent , DataTableComponent]
})
export class ElementsLibraryModule { }
