import {Injectable} from '@angular/core';
import {HttpEvent, HttpHandler, HttpInterceptor, HttpRequest} from '@angular/common/http';
import {Observable} from 'rxjs';
import {finalize} from 'rxjs/operators';
import {HttpNotificationService} from './http-notification.service';

@Injectable()
export class HttpNotificationInterceptor implements HttpInterceptor {
  constructor(private httpNotificationService: HttpNotificationService) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    this.httpNotificationService.requesting();

    return next.handle(req).pipe(
      finalize(() => this.httpNotificationService.complete())
    );
  }
}
