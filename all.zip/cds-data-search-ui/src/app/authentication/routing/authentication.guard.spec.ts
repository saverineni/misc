import {AuthenticationGuard} from './authentication.guard';
import {AuthenticationService} from '../authentication.service';
import {SignInRouterService} from '../sign-in/sign-in-router.service';
import {RouterStateSnapshot} from '@angular/router';

describe('AuthenticationGuard', () => {
  let guard: AuthenticationGuard;
  let authenticationService: AuthenticationService;
  let signInRouterService: SignInRouterService;

  beforeEach(() => {
    authenticationService = {
      isAuthenticated: () => true,
      signOut: {},
    } as AuthenticationService;

    signInRouterService = {
      navigateToSignIn: () => {}
    } as SignInRouterService;

    guard = new AuthenticationGuard(authenticationService, signInRouterService);
    spyOn(signInRouterService, 'navigateToSignIn');
    spyOn(authenticationService, 'signOut');
  });

  describe('authenticated', () => {
    it('can activate should return true', () => {
      expect(guard.canActivate(null, null)).toBe(true);
      expect(signInRouterService.navigateToSignIn).not.toHaveBeenCalled();
    });
  });

  describe('not authenticated',  () => {
    beforeEach(() => {
      spyOn(authenticationService, 'isAuthenticated').and.returnValue(false);
    });

    it('can activate should return false', () => {
      expect(guard.canActivate(null, null)).toBe(false);
    });

    it('should route to the sign in page and call auth service to clear the cache', () => {
      const routerStateSnapshot = {url: ''} as RouterStateSnapshot;
      guard.canActivate(null, routerStateSnapshot);
      expect(signInRouterService.navigateToSignIn).toHaveBeenCalledWith(routerStateSnapshot);
      expect(authenticationService.signOut).toHaveBeenCalled();
    });
  });
});
