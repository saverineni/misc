import { Injectable, Inject, InjectionToken } from '@angular/core';
import {ActivatedRouteSnapshot, NavigationExtras, Router, RouterStateSnapshot} from '@angular/router';

export const LOCATION_TOKEN = new InjectionToken<Location>('Window location object');

@Injectable()
export class SignInRouterService {

  constructor(private router: Router,
              @Inject(LOCATION_TOKEN) private location: Location) { }

  navigateToSignIn(routerState?: RouterStateSnapshot) {
    const navigationExtras: NavigationExtras = {};
    navigationExtras.queryParams = (routerState !== undefined) ?
      {returnUrl: routerState.url} : {returnUrl: this.router.routerState.snapshot.url};

    this.router.navigate(['signin'], navigationExtras);
  }

  navigateToReturnUrl(route: ActivatedRouteSnapshot) {
    this.location.assign(route.queryParams['returnUrl'] || '/');
  }
}
