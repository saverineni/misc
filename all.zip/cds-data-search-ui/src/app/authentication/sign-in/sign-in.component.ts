import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, ViewChild } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { ActivatedRoute, ActivatedRouteSnapshot } from '@angular/router';
import { SignInRouterService } from './sign-in-router.service';

@Component({
  selector: 'cds-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SignInComponent implements OnInit {
  private unauthorised = false;
  private forbidden = false;
  private routeSnapshot: ActivatedRouteSnapshot;

  @ViewChild('pid') pidElement;

  constructor(
    private authenticationService: AuthenticationService,
    private route: ActivatedRoute,
    private signInRouterService: SignInRouterService,
    private changeDetectorRef: ChangeDetectorRef) { }

  ngOnInit() {
    this.routeSnapshot = this.route.snapshot;
    this.pidElement.nativeElement.focus();
  }

  signIn(pid: string, password: string) {
    this.authenticationService
      .signIn(pid, password)
      .subscribe(authenticationResult => {
        if (authenticationResult.authorised) {
          this.signInRouterService.navigateToReturnUrl(this.routeSnapshot);
        } else if (authenticationResult.forbidden) {
          this.forbidden = true; this.unauthorised = false;
          this.changeDetectorRef.detectChanges();
        } else {
          this.unauthorised = true; this.forbidden = false;
          this.changeDetectorRef.detectChanges();
        }
      });
  }

  isUnauthorised() {
    return this.unauthorised;
  }

  isForbidden() {
    return this.forbidden;
  }
}
