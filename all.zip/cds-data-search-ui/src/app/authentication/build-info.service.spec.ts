import { getTestBed , TestBed, inject } from '@angular/core/testing';
import { BuildInfo } from './build-info';
import { BuildInfoService } from './build-info.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

describe('BuildInfoService', () => {
  let httpMock: HttpTestingController;
  let service: BuildInfoService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [BuildInfoService]
    });

    httpMock = getTestBed().get(HttpTestingController);
    service = getTestBed().get(BuildInfoService);
  });

  it('should be created', inject([BuildInfoService], (buildInfoService: BuildInfoService) => {
    expect(buildInfoService).toBeTruthy();
  }));

  describe('getBuildInfo', () => {
    let request;

    beforeEach(() => {
      service.buildInfo.toPromise();
      request = httpMock.expectOne('/build/info');
      request.flush({});
    });

    it('should request http GET', () => {
      expect(request.request.method).toBe('GET');
    });

  });

  it('should throw error on 500', (done) => {
    const errorEvent = new ErrorEvent('');
    service.buildInfo.subscribe(
      result => done.fail('expect error'),
      error => {
        expect(error.error).toBe(errorEvent);
        done();
      });
    const request = httpMock.expectOne('/build/info');
    request.error(errorEvent, { status: 500 });
  });

  it('should return build info', () => {
    let request;
    let buildInfoResult: BuildInfo;
    const buildInfo = {version: '1.0.0', environment: 'local'};

    service.buildInfo.subscribe(build => buildInfoResult = build);
    request = httpMock.expectOne('/build/info');
    request.flush(buildInfo);

    expect(buildInfoResult.version).toBe('1.0.0');
    expect(buildInfoResult.environment).toBe('local');

  });

  afterEach(() => {
    httpMock.verify();
  });

});
