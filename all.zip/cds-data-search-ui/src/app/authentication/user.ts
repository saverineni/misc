
export class User {
    pid: string;
    firstName: string;
    lastName: string;
    department: string;
}
