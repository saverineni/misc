import {CacheService} from './cache.service';
import { User } from './user';

describe('CacheService', () => {
  let service: CacheService;

  beforeEach(() => {
    service = new CacheService();
    spyOn(localStorage , 'setItem');
  });

  describe('token cache', () => {
    const token = '123';

    beforeEach(() => {
      spyOn(localStorage , 'getItem').and.returnValue(token);
    });

    it('returns token', () => {
      expect(service.getToken()).toBe(token);
      expect(localStorage.getItem).toHaveBeenCalledWith(CacheService.TOKEN_KEY);
    });

    it('saves token', () => {
      service.setToken(token);
      expect(localStorage.setItem).toHaveBeenCalledWith(CacheService.TOKEN_KEY, token);
    });
  });

  describe('time to live cache', () => {
    const timeToLive = '123';

    beforeEach(() => {
      spyOn(localStorage , 'getItem').and.returnValue(timeToLive);
    });

    it('returns expiration time to live', () => {
      expect(service.getExpiration()).toBe(+timeToLive);
      expect(localStorage.getItem).toHaveBeenCalledWith(CacheService.EXPIRATION_KEY);
    });

    it('saves expiration time to live', () => {
      service.setExpiration(+timeToLive);
      expect(localStorage.setItem).toHaveBeenCalledWith(CacheService.EXPIRATION_KEY, timeToLive);
    });
  });

  describe('user cache with valid token', () => {
    const testUser = {pid: 'test', firstName: '', lastName: '' , department: ''} as User;
    const userPayload = 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ0ZXN0IiwidXNlciI6eyJwaWQiOiJ0ZXN0IiwiZmlyc3ROYW1lIjoiIiwibGFzdE5hbWUiOiIiLCJkZX' +
      'BhcnRtZW50IjoiIn0sImV4cCI6MTUzNDc3MTc5Mn0.3MYbIJzhRaiqFQqxlrIiRFFpBjuESJVGWH6weYr7RMGM91Vs1F7RsgPIvmDXgnZ3ZmfY8rIxgfQVylrRw-dHXA';

    it('returns null if not present', () => {
      spyOn(localStorage, 'getItem').and.returnValue(null);
      expect(service.getUser()).toBeNull();
    });

    it('returns user if present', () => {
      spyOn(localStorage, 'getItem').and.returnValue(userPayload);
      expect(service.getUser()).toEqual(testUser);
    });
  });

  describe('user cache with invalid token', () => {
    const userPayload = 'test';

    it('returns user if present', () => {
      spyOn(localStorage, 'getItem').and.returnValue(userPayload);
      expect(service.getUser()).toEqual(null);
    });
  });

  describe('clear', () => {
    beforeEach(() => {
      spyOn(localStorage , 'clear');
    });

    it('should clear the cached values', () => {
      service.clear();
      expect(localStorage.clear).toHaveBeenCalled();
    });
  });
});
