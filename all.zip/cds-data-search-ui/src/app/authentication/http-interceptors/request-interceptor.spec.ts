import {HttpHandler, HttpRequest} from '@angular/common/http';
import {RequestInterceptor} from './request-interceptor';
import {CacheService} from '../cache.service';
import {EMPTY} from 'rxjs';
import {SignInRouterService} from '../sign-in/sign-in-router.service';
import {Router, RouterState} from '@angular/router';
import {RouterStateSnapshot} from '@angular/router/src/router_state';


describe('RequestInterceptor ', () => {
  let cacheService: CacheService;
  let requestInterceptor: RequestInterceptor;
  let signInRouterService: SignInRouterService;
  let request: HttpRequest<any>;
  let cloneReq: HttpRequest<any>;

  let next: HttpHandler;
  let spyHandler: jasmine.Spy;

  const routerStateSnapshotStub = { url: 'url'} as RouterStateSnapshot;
  const router = {
    routerState: {
      snapshot: routerStateSnapshotStub
    } as RouterState
  } as Router;

  describe('for url ', () => {

    beforeEach(() => {
      cacheService = {
        getToken() {
          return 'token';
        }
      } as CacheService;

      signInRouterService = {
        navigateToSignIn: () => { }
      } as SignInRouterService;


      next = {
        handle: r => {}
      } as HttpHandler;
      spyHandler = spyOn(next, 'handle');
      requestInterceptor = new RequestInterceptor(cacheService, signInRouterService, router);
    });

    it('/build/info will not add token to the header', () => {
      request = {
        url: '/build/info'
      } as HttpRequest<any>;

      requestInterceptor.intercept(request, next);
      expect(spyHandler).toHaveBeenCalledWith(request);
    });

    it('/authentication/token will not add token to the header', () => {
      request = {
        url: '/api/authentication/token'
      } as HttpRequest<any>;

      requestInterceptor.intercept(request, next);
      expect(spyHandler).toHaveBeenCalledWith(request);
    });

    it('other than /authentication/token adds token to the header', () => {
      request = {
        url: '/',
        clone() {
          return cloneReq;
        }
      } as HttpRequest<any>;

      cloneReq = {
        url: '/'
      } as HttpRequest<any>;


      spyOn(request, 'clone').and.callThrough();
      requestInterceptor.intercept(request, next);

      expect(spyHandler).toHaveBeenCalledWith(cloneReq);
      expect(request.clone).toHaveBeenCalledWith({
        setHeaders: {
          Authorization: 'Bearer token'
        }
      });
    });
  });

  describe('for search ', () => {

    beforeEach(() => {
      cacheService = {
        getToken() {
          return null;
        }
      } as CacheService;

      signInRouterService = {
        navigateToSignIn: () => { }
      } as SignInRouterService;

      next = {
        handle: r => {}
      } as HttpHandler;

      spyOn(signInRouterService, 'navigateToSignIn');
      spyHandler = spyOn(next, 'handle');
      requestInterceptor = new RequestInterceptor(cacheService, signInRouterService, router);
    });

    it('redirects to signin page when token does not exist for any urls except authentication url', () => {
      request = {
        url: '/api/declarations'
      } as HttpRequest<any>;

      const observable = requestInterceptor.intercept(request, next);
      expect(signInRouterService.navigateToSignIn).toHaveBeenCalledWith(routerStateSnapshotStub);
      expect(observable).toEqual(EMPTY);
    });

    it('redirects to signin page when token does not exist for authentication url', () => {
      request = {
        url: '/api/authentication/token'
      } as HttpRequest<any>;

      requestInterceptor.intercept(request, next);
      expect(signInRouterService.navigateToSignIn).not.toHaveBeenCalled();
      expect(spyHandler).toHaveBeenCalledWith(request);
    });

  });


});
