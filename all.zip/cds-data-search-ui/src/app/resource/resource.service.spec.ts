import { TestBed, inject } from '@angular/core/testing';

import { ResourceService } from './resource.service';
import { Router } from '@angular/router';
import { HttpParams } from '@angular/common/http/src/params';
import { ParamMap } from '@angular/router/src/shared';
import { ActivatedRoute } from '@angular/router/src/router_state';
import { of, OperatorFunction, throwError, empty } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';
import { HttpErrorResponse } from '@angular/common/http';

describe('ResourceService', () => {
  let router: Router;
  let resourceService: ResourceService;

  beforeEach(() => {
    router = { navigate: (a, b) => {} } as Router;
    spyOn(router, 'navigate');

    resourceService = new ResourceService(router);
  });

  describe('handle for params', () => {
    const paramMap: ParamMap = { } as ParamMap;
    let activatedRoute: ActivatedRoute;
    let result: Observable<any>;

    beforeEach(() => {
      activatedRoute = { paramMap: of(paramMap) } as ActivatedRoute;
    });

    describe('no errors', () => {
      let params;
      let handledParamsResponse;

      beforeEach(() => {
        handledParamsResponse = { response:  'success' };
        result = resourceService.handleNotFound(activatedRoute, (givenParams) => {
          params = givenParams;
          return of(handledParamsResponse);
        });
      });

      it('should call the params handler with the route params', () => {
        result.toPromise();
        expect(params).toBe(paramMap);
      });

      it('should give an observable of the params handler response', (done) => {
        result.subscribe(
          success => {
            expect(success).toBe(handledParamsResponse);
            done();
          },
          done.fail
        );
      });
    });

    describe('handle resource request errors', () => {
      let error;

      describe('not HttpErrorResponse', () => {
        beforeEach(() => {
          error = { err: 'the-error' };
          result = resourceService.handleNotFound(
            activatedRoute,
            (givenParams) => throwError(error)
          );
        });

        it('should throw error', (done) =>
          result.toPromise().then(
            done.fail,
            err => {
              expect(err).toBe(error);
              done();
            }
          )
        );
      });

      describe('is HttpErrorResponse', () => {
        [ 401, 403, 500, 502 ].forEach(status => {
          beforeEach(() => {
            error = new HttpErrorResponse({ status: status });
            result = resourceService.handleNotFound(
              activatedRoute,
              (givenParams) => throwError(error)
            );
          });

          it(`not ${status} should throw error`, (done) =>
            result.toPromise().then(
              done.fail,
              err => {
                expect(err).toBe(error);
                done();
              }
            )
          );
        });

        describe('status 404', () => {
          beforeEach(() => {
            error = new HttpErrorResponse({ status: 404 });
            result = resourceService.handleNotFound(
              activatedRoute,
              (givenParams) => throwError(error)
            );
          });

          it('should not throw error', (done) =>
            result.toPromise().then(done, done.fail)
          );

          it('should navigate to the not found page relative to the activated route', () => {
            result.toPromise();

            expect(router.navigate).toHaveBeenCalledWith(
              ['not-found'],
              { relativeTo: activatedRoute, skipLocationChange: true }
            );
          });
        });
      });
    });
  });

  describe('not found', () => {
    let activatedRoute: ActivatedRoute;

    beforeEach(() => {
      activatedRoute = {} as ActivatedRoute;
      resourceService.notFound(activatedRoute);
    });

    it('should navigate to the not found page relative to the activated route', () => {
      expect(router.navigate).toHaveBeenCalledWith(
        ['not-found'],
        { relativeTo: activatedRoute, skipLocationChange: true }
      );
    });
  });
});
