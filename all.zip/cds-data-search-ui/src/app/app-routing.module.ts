import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchSectionComponent } from './declaration/search/search-section/search-section.component';
import { AuthenticationGuard } from './authentication/routing/authentication.guard';
import { DeclarationDetailComponent } from './declaration/detail/declaration-detail.component';
import { DeclarationItemDetailComponent } from './declaration/detail/items/declaration-item-detail.component';
import { NotFoundComponent } from './error-handling/not-found/not-found.component';
import { ServerErrorComponent } from './error-handling/server-error/server-error.component';
import { HelpComponent} from './help/help.component';

const routes: Routes = [
  {
    path: '',
    component: SearchSectionComponent,
    canActivate: [ AuthenticationGuard ],
    runGuardsAndResolvers: 'always',
    data: {
      title: 'CDS - Search Results'
    }
  },
  {
    path: 'declarations/:id',
    component: DeclarationDetailComponent,
    canActivate: [ AuthenticationGuard ],
    runGuardsAndResolvers: 'always',
    data: {
      title: 'CDS - Declaration Detail'
    }
  },
  {
    path: 'declarations/:id/items/:number',
    component: DeclarationItemDetailComponent,
    canActivate: [ AuthenticationGuard ],
    runGuardsAndResolvers: 'always',
    data: {
      title: 'CDS - Item Detail'
    }
  },
  {
    path: 'help',
    component: HelpComponent,
    canActivate: [ AuthenticationGuard ],
    runGuardsAndResolvers: 'always',
    data: {
      title: 'CDS - Help'
    }
  },
  {
    path: 'error',
    component: ServerErrorComponent,
    canActivate: [ AuthenticationGuard ],
    runGuardsAndResolvers: 'always',
    data: {
      title: 'CDS - Server Error'
    }
  },
  {
    path: '**',
    component: NotFoundComponent,
    canActivate: [ AuthenticationGuard ],
    runGuardsAndResolvers: 'always',
    data: {
      title: 'CDS - 404 Page Not Found'
    }
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {onSameUrlNavigation: 'reload'}),
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
