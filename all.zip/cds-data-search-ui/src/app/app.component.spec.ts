import { async, TestBed, ComponentFixture } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { Component, ContentChild, Directive, Input } from '@angular/core';
import { MatProgressSpinnerModule } from '@angular/material';
import { HttpNotificationService } from './http-notification.service';
import {RouterTestingModule } from '@angular/router/testing';
import { Observable, Subscription, of } from 'rxjs';
import { BuildInfo } from './authentication/build-info';
import { BuildInfoService } from './authentication/build-info.service';
import { Router, RouterState, RouterStateSnapshot, Params, NavigationEnd } from '@angular/router';
import { UserService } from './authentication/user.service';

@Directive({
  selector: 'cds-header'
})
export class MockCdsHeaderDirective {
  @Input() title;
  @ContentChild('headerDetail') headerDetail;
}

@Component({
  selector: 'cds-user-details',
  template: '<span>user details</span>'
})
export class MockCdsUserDetailsComponent {}

@Directive({
  selector: 'cds-navbar',
})
export class MockCdsNavbarDirective {
  @Input() homeLabel;
  @Input() isSignInPage;
}

@Directive({
  selector: 'cds-footer',
})
export class MockCdsFooterDirective {
  @Input() buildInfo: BuildInfo;
  @Input() isSignInPage: boolean;
}

class MockRouter {
  public events = of(new NavigationEnd(0, '/declarations/1234', '/declarations/1234'));
  public url = 'signin';
  public activatedRouteSnapshotStub: any = {
    firstChild: {
      params: {
        subscribe: (fn: (value: Params) => void) => fn({
          tab: 0,
        }),
      }
    },
    paramMap: {
      get: function () {
        return 'test';
        }
      },
    data: {
      title: 'title'
    }
  };
  public routerStateSnapshotStub = { url: this.url, root: this.activatedRouteSnapshotStub} as RouterStateSnapshot;
  public routerState = {snapshot: this.routerStateSnapshotStub } as RouterState;
}

describe('AppComponent', () => {
  let fixture: ComponentFixture<AppComponent>;
  let httpNotificationServiceWaitingSpy;
  let buildInfoService;
  let testObservable: Observable<BuildInfo>;
  let testSubscription: Subscription;

  beforeEach(async(() => {
    const buildInfo = new BuildInfo();
    buildInfo.version = '1.0.0';
    buildInfo.environment = 'local';

    testObservable = of(buildInfo);
    testSubscription = new Subscription();

    const stubHttpNotificationService = { waiting: () => false };

    buildInfoService = {
      buildInfo: testObservable
    } as BuildInfoService;

    httpNotificationServiceWaitingSpy = spyOn(stubHttpNotificationService, 'waiting');

    spyOn(buildInfoService, 'buildInfo').and.callThrough();

    TestBed.configureTestingModule({
      declarations: [
        AppComponent,
        MockCdsHeaderDirective,
        MockCdsNavbarDirective,
        MockCdsUserDetailsComponent,
        MockCdsFooterDirective
      ],
      imports: [
        MatProgressSpinnerModule,
        RouterTestingModule
      ],
      providers: [
        { provide: HttpNotificationService, useValue: stubHttpNotificationService },
        { provide: BuildInfoService, useValue: buildInfoService },
        { provide: Router, useClass: MockRouter },
        { provide: UserService, useValue: { getUser: () => ({ pid: 'pid' })}}
      ]
    }).compileComponents();

  }));


  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
  });

  describe('header', () => {
    let directive;
    let header;

    beforeEach(() => {
      directive = fixture.debugElement.query(By.directive(MockCdsHeaderDirective));
      header = directive.injector.get(MockCdsHeaderDirective);
    });

    it('should be added to the app with the title', () => {
      expect(header.title).toBe('Customs Declaration Search');
    });

    it('should be added to the app with the header detail', () => {
      expect(header.headerDetail instanceof MockCdsUserDetailsComponent).toBe(true);
    });
  });

  it('should create the app with the navbar', () => {
    const directive = fixture.debugElement.query(By.directive(MockCdsNavbarDirective));
    const navbar = directive.injector.get(MockCdsNavbarDirective);

    expect(navbar.homeLabel).toBe('Customs Declaration Search');
  });

  describe('footer', () => {

    it('should popultae the build info', () => {
      const directive = fixture.debugElement.query(By.directive(MockCdsFooterDirective));
      const footer = directive.injector.get(MockCdsFooterDirective);

      expect(footer.buildInfo.version).toBe('1.0.0');
      expect(footer.buildInfo.environment).toBe('local');
    });
  });


  it('should route requests', () => {
    const directive = fixture.debugElement.query(By.css('router-outlet'));
    expect(directive).toBeTruthy();
  });

  it('should return a user pid', () => {
    expect(fixture.componentInstance.getUserPid()).toEqual('pid');
  });

  describe('spinner', () => {
    it('should be displayed when waiting', () => {
      httpNotificationServiceWaitingSpy.and.returnValue(true);
      fixture.detectChanges();
      const waitingOverlay = fixture.debugElement.query(By.css('.waiting-overlay--show'));
      expect(waitingOverlay == null).toBeFalsy();
    });

    it('should not be displayed when not waiting', () => {
      httpNotificationServiceWaitingSpy.and.returnValue(false);
      fixture.detectChanges();
      const waitingOverlay = fixture.debugElement.query(By.css('.waiting-overlay--show'));
      expect(waitingOverlay == null).toBeTruthy();
    });
  });

});
