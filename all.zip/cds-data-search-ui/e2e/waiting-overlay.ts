import { browser, by, element, protractor } from 'protractor';

export class WaitingOverlay {
  spinnerIsDisplayed() {
    const EC = protractor.ExpectedConditions;
    const spinner = element(by.css('.waiting-overlay--show'));
    return browser.wait(EC.presenceOf(spinner), 2000).then(() => spinner.isDisplayed(), () => false);
  }
}
