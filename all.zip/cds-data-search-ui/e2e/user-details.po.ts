import { by, element } from 'protractor';

export class UserDetails {
  isDisplayed() {
    return element(by.css('.user-details')).isPresent();
  }

  getFullName() {
    return element(by.css('.user-details__info__name')).getText();
  }

  getDeparment() {
    return element(by.css('.user-details__info__department')).getText();
  }

  isUserIconDisplayed() {
    return element(by.css('.user-details__icon')).isPresent();
  }
}
