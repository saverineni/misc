import {NavigationBar} from './navigation-bar.po';
import {SignInPage} from './sign-in/sign-in.po';
import {Wiremock} from './wiremock';
import {SignInScenario} from './sign-in/sign-in-scenario';
import {UserDetails} from './user-details.po';
import { HelpPage } from './help/help.po';

describe('navbar', () => {
  let navigationBar: NavigationBar;
  let userDetails: UserDetails;
  let signInPage: SignInPage;
  let helpPage: HelpPage;

  beforeEach((done) => {
    navigationBar = new NavigationBar();
    userDetails = new UserDetails();
    signInPage = new SignInPage();
    helpPage = new HelpPage();
    Wiremock.reset().then(done);
  });

  describe('signed in', () => {
    beforeEach((done) => {
      new SignInScenario().givenUserIsSignedIn().then(done, done);
    });

   describe('sign out', () => {
      beforeEach((done) => {
        expect(userDetails.isDisplayed()).toBe(true);
        navigationBar.signOut().then(done, done);
      });

      it('should route to the sign in page', () => {
        expect(signInPage.isCurrentPage()).toBe(true);
      });

      it('user details should not be displayed', () => {
        expect(userDetails.isDisplayed()).toBeFalsy();
      });
    });

    describe('help', () => {
      beforeEach((done) => {
        navigationBar.help().then(done, done);
      });

      it('should route to the help page', () => {
        expect(helpPage.isCurrentPage()).toBe(true);
      });

    });

  });
});
