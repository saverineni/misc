import { by, element } from 'protractor';

export class DataTable {

  getTableHeaders() {
    return element.all(by.css('.data-table__headercell')).getText();
  }

  isDataDisplayed() {
    return element(by.css('.data-table')).isPresent();
  }

  rowsDisplayed() {
    return element.all(by.css('.mat-row')).then(rows => rows.length);
  }

  getTableCellContent(id) {
    return element.all(by.css(`.data-table__cell[cell-id="${id}"]`)).getText();
  }
}
