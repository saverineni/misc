import {DeclarationSearchPage} from '../declaration/search/declarationsearch.po';
import {SignInPage} from './sign-in.po';
import {NavigationBar} from '../navigation-bar.po';

export class SignInScenario {

  givenUserIsSignedIn(pid: string = SignInPage.DEFAULT_PID, password: string = SignInPage.DEFAULT_PASSWORD) {
    const searchPage = new DeclarationSearchPage();
    const signInPage = new SignInPage();

    // try to navigate to the search page to check sign-in state
    // if redirects to the sign-in page then sign-in required
    // else already signed in
    return searchPage.navigateTo()
      .then(() => signInPage.isCurrentPage())
      .then((isNotSignedIn) => {
        if (isNotSignedIn) {
          signInPage.completeSignInFormWithValidUser(pid, password);
        }
      });
  }

  givenUserIsNotSignedIn() {
    const searchPage = new DeclarationSearchPage();
    return searchPage.navigateTo()
      .then(() => searchPage.isCurrentPage())
      .then((isSignedIn) => {
        if (isSignedIn) {
          new NavigationBar().signOut();
        }
      });
  }
}
