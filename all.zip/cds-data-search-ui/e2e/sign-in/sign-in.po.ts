import { browser, by, element, ExpectedConditions } from 'protractor';

export class SignInPage {
  public static DEFAULT_PID = 'search';
  public static DEFAULT_PASSWORD = 'search';
  public static SHORT_LIVED_PID = 'cdssearch';
  public static SHORT_LIVED_PASSWORD = 'cdssearch';
  public static DEFAULT_AUTH_TOKEN = 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJzZWFyY2giLCJ1c2VyIjp7InBpZCI6InNlYXJjaCIsImZpcnN0TmFt' +
    'ZSI6IlNlYXJjaCIsImxhc3ROYW1lIjoiVXNlciIsImRlcGFydG1lbnQiOiJPcGVyYXRpb25zIFVuaXQifSwiZXhwIjoxNTM0ODYzNjc1fQ.lwyDTYgo8B9' +
    'Ci3EzKCKO2hp8l3K1ZF8PU16bmXFl2Rn7KOUTTEOFkOUuZ1lCQ1DeGIaxxu92YLs5Uoo_txb6sQ';

  navigateTo() {
    return browser.get('/signin').then(() => browser.waitForAngular());
  }

  isCurrentPage() {
    return element(by.css('.signin-content__card')).isPresent();
  }

  enterPid(pid: string) {
    return element(by.css('.signin-content__card__sign-in-form__pid-input')).sendKeys(pid);
  }

  enterPassword(password: string) {
    return element(by.css('.signin-content__card__sign-in-form__password-input')).sendKeys(password);
  }

  clickSignIn() {
    return element(by.css('.signin-content__card__sign-in-form__footer-layout__button')).click();
  }

  /**
   * Successful sign in requires an additional wait to account for the forced browser refresh.
   */
  successfulSignIn() {
    return element(by.css('.signin-content__card__sign-in-form__footer-layout__button')).click()
            .then(() => browser.wait(ExpectedConditions.not(ExpectedConditions.titleContains('CDS - Sign In')), 10000))
            .then(() => browser.waitForAngular());
  }

  unsuccessfulSignIn() {
    return element(by.css('.signin-content__card__sign-in-form__footer-layout__button')).click()
            .then(() => browser.waitForAngular());
  }

  errorMessage() {
    return this.errorMessageElement().getText();
  }

  forbiddenErrorMessage() {
    return this.forbiddenErrorMessageElement().getText();
  }

  errorMessagePresent() {
    return this.errorMessageElement().isPresent();
  }

  forbiddenErrorMessagePresent() {
    return this.forbiddenErrorMessageElement().isPresent();
  }

  getTitle() {
    return element(by.css('.signin-content__card__title')).getText();
  }

  getSubTitle() {
    return element(by.css('.signin-content__card__subtitle')).getText();
  }

  getHelpMessage() {
    return element(by.css('.signin-content__card__sign-in-form__footer-layout__label')).getText();
  }

  isHelpdeskLinkPresent() {
    return this.getHelpDeskLink().isPresent();
  }

  helpdeskLinkUrl() {
    return this.getHelpDeskLink().getAttribute('href').then(value => value);
  }

  private getHelpDeskLink() {
    return element(by.css('.signin-content__card__sign-in-form__footer-layout__link'));
  }

  private errorMessageElement() {
    return element(by.css('.signin-content__card__sign-in-form__error-message'));
  }

  private forbiddenErrorMessageElement() {
    return element(by.css('.signin-content__card__sign-in-form__forbidden-message'));
  }

  completeSignInFormWithValidUser(pid: string = SignInPage.DEFAULT_PID, password: string = SignInPage.DEFAULT_PASSWORD) {
    return this.enterPid(pid)
      .then(() => this.enterPassword(password))
      .then(() => this.successfulSignIn());
  }
}
