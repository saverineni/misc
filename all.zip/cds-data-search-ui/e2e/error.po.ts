import { browser, by, element } from 'protractor';

export class ErrorPage {
  navigateTo() {
    return browser.get('/error').then(() => browser.waitForAngular());
  }

  isCurrentPage() {
    return this.getPageHeading().isPresent();
  }

  pageHeading() {
    return this.getPageHeading().getText();
  }

  incovenienceMessage() {
    return element(by.css('.server-error__inconvenience-message')).getText();
  }

  helpMessage() {
    return element(by.css('.server-error__help-message')).getText();
  }

  private getPageHeading() {
    return element(by.css('.server-error__page-heading'));
  }

  getCurrentTitle() {
    return browser.getTitle();
  }
}
