import { DeclarationDetailPage } from './declarationdetail.po';
import { DeclarationDetailScenario } from './declarationdetail-scenario';
import { Wiremock } from '../../wiremock';
import { SignInPage } from '../../sign-in/sign-in.po';
import { SignInScenario } from '../../sign-in/sign-in-scenario';
import { BrowserCache } from '../../browser-cache';

describe('Declaration Details Authentication', () => {
  let detailPage: DeclarationDetailPage;
  let signInPage: SignInPage;
  const browserCache = new BrowserCache();

  beforeEach(() => {
    signInPage = new SignInPage();
    detailPage = new DeclarationDetailPage();
  });

  describe('When signed in with token missing', () => {
    beforeEach((done) => {
      Wiremock.reset()
        .then(() => DeclarationDetailScenario.stubDeclaration(DeclarationDetailScenario.TEST_ID))
        .then(() => new SignInScenario().givenUserIsSignedIn())
        .then(done, done.fail);
    });

    it('should redirect to signin page', (done) => {
      browserCache.clearLocalStorage()
        .then(() => detailPage.navigateTo(DeclarationDetailScenario.TEST_ID))
        .then(() => expect(signInPage.isCurrentPage()).toBe(true))
        .then(done, done.fail);
    });
  });

  describe('When signed in with invalid token', () => {
    beforeEach((done) => {
      Wiremock.reset()
        .then(() => DeclarationDetailScenario.stubDeclarationWithInvalidToken(DeclarationDetailScenario.TEST_ID))
        .then(() => new SignInScenario().givenUserIsSignedIn())
        .then(done, done.fail);
    });

    it('should redirect to signin page', (done) => {
      browserCache.makeTokenInvalid()
        .then(() => detailPage.navigateTo(DeclarationDetailScenario.TEST_ID))
        .then(() => expect(signInPage.isCurrentPage()).toBe(true))
        .then(done, done.fail);
    });
  });
});
