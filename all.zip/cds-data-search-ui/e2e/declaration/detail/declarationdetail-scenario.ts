import { Wiremock } from '../../wiremock';
const fs = require('fs');

export class DeclarationDetailScenario {
  private static DECLARATION_DEFINITION_FILE_NAME = 'declaration-definition.json';
  private static DECLARATION_FILE_NAME = 'declaration-with-lines.json';
  private static DECLARATION_WITHOUT_LINES_FILE = 'declaration-without-lines.json';

  static readonly TEST_ID = '670-954107X-2017-08-22';
  static readonly WITHOUT_LINES_ID = 'declaration-without-lines';

  static defaultDetailResponse() {
    return JSON.parse(fs.readFileSync(`e2e/wiremock/__files/${this.DECLARATION_FILE_NAME}`));
  }

  static declarationUrl(id) {
    return `/declarations/${id}`;
  }

  static stubDeclarationWithInvalidToken(id) {
    return Wiremock.stubRequest({
      'priority': 1,
      'request': {
        'method': 'GET',
        'url': this.declarationUrl(id),
        'headers': {
          'Authorization': {
            'equalTo': 'Bearer invalid token'
          }
        }
      },
      'response': {
        'status': 401
      }
    });
  }

  static stubDeclarationDefinition() {
    return Wiremock.stubRequest({
      'priority': 1,
      'request': {
        'method': 'GET',
        'url': '/declarations/definition'
      },
      'response': {
        'status': 200,
        'bodyFileName': this.DECLARATION_DEFINITION_FILE_NAME
      }
    });
  }

  static stubDeclaration(id) {
    return Wiremock.stubRequest({
      'priority': 1,
      'request': {
        'method': 'GET',
        'url': this.declarationUrl(id)
      },
      'response': {
        'status': 200,
        'bodyFileName': this.DECLARATION_FILE_NAME
      }
    });
  }

  static stubDeclarationWithoutLines() {
    return Wiremock.stubRequest({
      'priority': 1,
      'request': {
        'method': 'GET',
        'url': this.declarationUrl(this.WITHOUT_LINES_ID)
      },
      'response': {
        'status': 200,
        'bodyFileName': this.DECLARATION_WITHOUT_LINES_FILE
      }
    });
  }
}
