/// <reference path="../declarationMatchers.d.ts"/>

import { DeclarationDetailPage } from './declarationdetail.po';
import { DeclarationDetailScenario } from './declarationdetail-scenario';
import { declarationMatchers } from '../declarationMatchers';
import { AppPage } from '../../app.po';
import { SignInScenario } from '../../sign-in/sign-in-scenario';
import { Wiremock } from '../../wiremock';
import { DeclarationSearchPage } from '../search/declarationsearch.po';
import { NotFoundPage } from '../../not-found.po';
import { NavigationBar } from '../../navigation-bar.po';
import {browser} from 'protractor';
import { SignInPage } from '../../sign-in/sign-in.po';
import { Footer } from '../../footer.po';

describe('Declaration detail', () => {
  const detailPage: DeclarationDetailPage = new DeclarationDetailPage();
  const footer = new Footer();

  beforeAll((done) => {
    new SignInScenario().givenUserIsSignedIn().then(done, done.fail);
  });

  describe('declaration with lines', () => {

    let declarationDetail;

    beforeAll((done) => {
      declarationDetail = DeclarationDetailScenario.defaultDetailResponse();
      jasmine.addMatchers(declarationMatchers);
      Wiremock.reset()
        .then(() => DeclarationDetailScenario.stubDeclarationDefinition())
        .then(() => DeclarationDetailScenario.stubDeclaration(DeclarationDetailScenario.TEST_ID))
        .then(() => detailPage.navigateTo(DeclarationDetailScenario.TEST_ID))
        .then(() => detailPage.waitForDeclarationData())
        .then(done, done.fail);
    });

    it('should be the current page', () => {
      expect(detailPage.isCurrentPage()).toBeTruthy();
    });

    it('should display footer', () => {
      expect(footer.getVerison()).toContain('VERSION ');
    });

    it('updates the title in the browser', () => {
      expect(new AppPage().getCurrentTitle()).toEqual(`CDS - Declaration Detail`);
    });

    it('updates the url in the browser', () =>
      expect(new AppPage().getCurrentUrl()).toMatch(`\/declarations\/${DeclarationDetailScenario.TEST_ID}$`)
    );

    it('displays the declaration if found', () => {
      expect(detailPage.getDataGridElement()).isDeclarationHeaderWithData(declarationDetail);
      expect(detailPage.getImportDeclaration().isPresent()).toBeTruthy();
      expect(detailPage.getExportDeclaration().isPresent()).toBeFalsy();
      expect(detailPage.getImportDeclaration().getCssValue('border-right')).toBe('10px solid rgb(252, 243, 200)');
    });

    it('displays the declaration item count in the item details button', () => {
      expect(detailPage.getItemDetailButtonText()).toEqual('ITEM DETAIL (4)');
    });

    it('has an enabled item details button', () => {
      expect(detailPage.isItemDetailButtonEnabled()).toBe(true);
    });

    describe('breadcrumbs', () => {
      it('declaration detail breadcrumb is visible', () => {
        expect(detailPage.declarationDetailBreadcrumbIsPresent()).toBeTruthy();
      });

      it('click on search results breadcrumb navigates back to search', (done) => {
        detailPage.clickSearchResultsBreadcrumb()
          .then(() => expect(new DeclarationSearchPage().isCurrentPage()).toBe(true))
          .then(done, done.fail);
      });
    });
  });

  describe('declaration without lines', () => {
    beforeAll((done) => {
      Wiremock.reset()
      .then(() => DeclarationDetailScenario.stubDeclarationWithoutLines())
      .then(() => detailPage.navigateTo(DeclarationDetailScenario.WITHOUT_LINES_ID))
      .then(() => detailPage.waitForDeclarationData())
      .then(done, done.fail);
    });

    it('displays the declaration item count in the item details button', () => {
      expect(detailPage.getItemDetailButtonText()).toEqual('ITEM DETAIL (0)');
    });

    it('has a disabled item details button', () => {
      expect(detailPage.isItemDetailButtonEnabled()).toBe(false);
    });

    it('displays the declaration if found', () => {
      expect(detailPage.getImportDeclaration().isPresent()).toBeFalsy();
      expect(detailPage.getExportDeclaration().isPresent()).toBeTruthy();
      expect(detailPage.getExportDeclaration().getCssValue('border-right')).toBe('10px solid rgb(178, 209, 236)');
    });
  });

  describe('declaration not found', () => {
    const notFoundPage = new NotFoundPage();
    let declarationUrl;

    beforeAll((done) => {
      declarationUrl = DeclarationDetailScenario.declarationUrl('dec-id');

      Wiremock.reset()
      .then(() => Wiremock.givenNotFound(declarationUrl))
      .then(() => detailPage.navigateTo('dec-id'))
      .then(done, done.fail);
    });

    it('should display the not found page', () => {
      expect(notFoundPage.isDisplayed()).toBeTruthy();
    });

    it('should not change the declaration page url', () => {
      expect(notFoundPage.getCurrentUrl()).toMatch(`${declarationUrl}$`);
    });
  });

  describe(`given i bookmark declaration details page
            and i click search results
            and it should return back to search page with empty results`, () => {

    let bookmarkedUrl;
    let signInPage;
    const searchPage = new DeclarationSearchPage();

    beforeAll((done) => {
      signInPage = new SignInPage();
      jasmine.addMatchers(declarationMatchers);
      Wiremock.reset()
        .then(() => DeclarationDetailScenario.stubDeclaration(DeclarationDetailScenario.TEST_ID))
        .then(() => detailPage.navigateTo(DeclarationDetailScenario.TEST_ID))
        .then(() => browser.getCurrentUrl())
        .then(url => {
          bookmarkedUrl = url;
          return Promise.resolve(url);
        })
        .then(() => new NavigationBar().signOut())
        .then(() => browser.get(bookmarkedUrl))
        .then(done, done.fail);
    });

    it('should redirect you to the sign in page', () => {
      expect(signInPage.isCurrentPage()).toBe(true);
    });

    it(`click search results breadcrumb
        should return to search page with no results`, (done) => {
      signInPage.completeSignInFormWithValidUser()
        .then(() => expect(browser.getCurrentUrl()).toBe(bookmarkedUrl))
        .then(() => detailPage.clickSearchResultsBreadcrumb())
        .then(() => expect(searchPage.isCurrentPage()).toBe(true))
        .then(() => expect(searchPage.isHmrcHelpTextPresent()).toBe(true))
        .then(() => expect(searchPage.isHmrcLogoPresent()).toBe(true))
        .then(done, done.fail);
    });

  });
});
