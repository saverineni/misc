import * as moment from 'moment';

interface FieldDefinition { viewField: string; value: any; }
type DeclarationFieldDefinitions = (declaration: any) => FieldDefinition[];

const previewFields: DeclarationFieldDefinitions = declaration => [
    { viewField: 'declarationId', value: declaration.declarationId },
    { viewField: 'entryDate', value: moment(declaration.entryDate).format('DD-MM-YYYY HH:mm') },
    { viewField: 'goodsLocation', value: declaration.goodsLocation },
    { viewField: 'transportModeCode', value: declaration.transportModeCode },
    { viewField: 'route', value: declaration.route },
    { viewField: 'dispatchCountry-code', value: declaration.dispatchCountry.code },
    { viewField: 'destinationCountry-code', value: declaration.destinationCountry.code }
];

const headerFields: DeclarationFieldDefinitions = (declaration) => previewFields(declaration).concat([
    { viewField: 'consignee-eori', value: declaration.consignee.eori },
    { viewField: 'consignee-name', value: declaration.consignee.name },
    { viewField: 'consignee-postcode', value: declaration.consignee.postcode },
    { viewField: 'consignor-eori', value: declaration.consignor.eori },
    { viewField: 'consignor-name', value: declaration.consignor.name },
    { viewField: 'consignor-postcode', value: declaration.consignor.postcode },
    { viewField: 'declarant-eori', value: declaration.declarant.eori },
    { viewField: 'declarant-name', value: declaration.declarant.name },
    { viewField: 'declarant-postcode', value: declaration.declarant.postcode },
    { viewField: 'declarantRepresentation', value: declaration.declarantRepresentation },
    { viewField: 'placeOfLoading', value: declaration.placeOfLoading },
    { viewField: 'transportId', value: declaration.transportId },
    { viewField: 'inlandTransportMode', value: declaration.inlandTransportMode },
    { viewField: 'totalPackages', value: declaration.totalPackages },
    { viewField: 'invoiceCurrency', value: declaration.invoiceCurrency },
    { viewField: 'invoiceTotal', value: declaration.invoiceTotal }
]);

const itemFields: DeclarationFieldDefinitions = declarationLine => [
    { viewField: 'itemRoute', value: declarationLine.itemRoute },
    { viewField: 'itemDispatchCountry-code', value: declarationLine.itemDispatchCountry.code },
    { viewField: 'itemDestinationCountry-code', value: declarationLine.itemDestinationCountry.code },
    { viewField: 'clearanceDate', value: moment(declarationLine.clearanceDate).format('DD-MM-YYYY HH:mm') },
    { viewField: 'cpc', value: declarationLine.cpc },
    { viewField: 'originCountry-code', value: declarationLine.originCountry.code },
    { viewField: 'commodityCode', value: declarationLine.commodityCode },
    { viewField: 'itemConsignee-eori', value: declarationLine.itemConsignee.eori },
    { viewField: 'itemConsignee-name', value: declarationLine.itemConsignee.name },
    { viewField: 'itemConsignee-postcode', value: declarationLine.itemConsignee.postcode },
    { viewField: 'itemConsignor-eori', value: declarationLine.itemConsignor.eori },
    { viewField: 'itemConsignor-name', value: declarationLine.itemConsignor.name },
    { viewField: 'itemConsignor-postcode', value: declarationLine.itemConsignor.postcode }
];

function newResult(): jasmine.CustomMatcherResult {
    return {
        pass: false,
        message: ''
    };
}

const removeNullsAndNewLines = value => value ? value.replace(/null(\s)?/mg, '').trim() : '';

function compareFields(fieldDefinitions: DeclarationFieldDefinitions) {
    return (util, customEqualityTesters) => {
        const isEqual = (a, b) => util.equals(a, b, customEqualityTesters);
        return {
            compare: (actual: any, expected: any): jasmine.CustomMatcherResult => {
                if (expected === undefined) {
                    expected = {};
                }

                const result = newResult();

                if (actual === undefined) {
                    result.message = `Could not check actual element as it was undefined`;
                } else {
                    result.pass = Promise.all(
                        fieldDefinitions(expected).map(field =>
                            actual.fieldTextOf(field.viewField)
                                .then(value => {
                                    const expectedValue = removeNullsAndNewLines(field.value);
                                    if (isEqual(value, expectedValue)) {
                                        return true;
                                    } else {
                                        result.message += `Expected ${field.viewField} field to be ${expectedValue} but was ${value}\n`;
                                        return false;
                                    }
                                }).then(value => value,
                                    error => {
                                        console.error(error);
                                        result.message += 'Error comparing field: ' + JSON.stringify(field);
                                        return false;
                                    }
                                )
                            )
                        )
                        .then(
                            values => values.every(value => value),
                            () => false
                        ) as any;
                }

                return result;
            }
        };
    };
}

const declarationMatchers: jasmine.CustomMatcherFactories = {
    'isDeclarationPreviewWithData': compareFields(previewFields),
    'isDeclarationHeaderWithData': compareFields(headerFields),
    'isDeclarationItemWithData': compareFields(itemFields)
};

export { declarationMatchers };
