/// <reference path="../declarationMatchers.d.ts"/>

import {DeclarationSearchPage} from './declarationsearch.po';
import {declarationMatchers} from '../declarationMatchers';
import {DeclarationSearchScenario} from './declaration-search-scenario';
import {SignInScenario} from '../../sign-in/sign-in-scenario';
import {Wiremock} from '../../wiremock';
import {browser, by, element, ExpectedConditions} from 'protractor';
import {SignInPage} from '../../sign-in/sign-in.po';

describe('Declaration search', () => {
  const searchPage: DeclarationSearchPage = new DeclarationSearchPage();

  beforeAll((done) => {
    new SignInScenario().givenUserIsSignedIn(SignInPage.SHORT_LIVED_PID, SignInPage.SHORT_LIVED_PASSWORD)
      .then(done, done.fail);
  });

  beforeAll((done) => {
    Wiremock.reset()
      .then(() => DeclarationSearchScenario.stubPerformSearch())
      .then(() => DeclarationSearchScenario.stubDeclarationPreviewDefinition())
      .then(() => searchPage.navigateTo())
      .then(done, done.fail);
  });


  describe('perform search', () => {
    describe('declaration', () => {

      beforeAll((done) => {
        DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found')
          .then(() => searchPage.whenISearchFor('found'))
          .then(done, done.fail);

        jasmine.addMatchers(declarationMatchers);
      });

      it('should display the result count', () => {
        expect(searchPage.resultCount()).toEqual('20K');
      });

      describe('wait for token to expire', () => {
        const signInPage = new SignInPage();
        beforeAll((done) => {
          browser.sleep(10000)
          .then(() => browser.refresh())
          .then(() => browser.wait(ExpectedConditions.visibilityOf(element(by.css('.signin-content__card'))), 5000))
          .then(done, done.fail);
        });

        // ignoring this test for now
        xit('should redirect to signin page', () => {
          expect(signInPage.isCurrentPage()).toBe(true);
        });
      });

    });

  });

});
