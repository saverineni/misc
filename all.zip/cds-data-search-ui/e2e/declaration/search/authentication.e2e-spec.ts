import { DeclarationSearchPage } from './declarationsearch.po';
import { Wiremock } from '../../wiremock';
import { SignInPage } from '../../sign-in/sign-in.po';
import { SignInScenario } from '../../sign-in/sign-in-scenario';
import { BrowserCache } from '../../browser-cache';

describe('Declaration Search Authentication', () => {
  let searchPage: DeclarationSearchPage;
  let signInPage: SignInPage;
  const browserCache = new BrowserCache();

  beforeEach((done) => {
    signInPage = new SignInPage();
    searchPage = new DeclarationSearchPage();
    Wiremock.reset()
      .then(() => new SignInScenario().givenUserIsSignedIn())
      .then(() => searchPage.navigateTo())
      .then(done, done.fail);
  });

   describe('When signed in', () => {
    it('and token missing should redirect to signin page', (done) => {
      browserCache.clearLocalStorage()
        .then(() => searchPage.whenISearchFor('made up'))
        .then(() => expect(signInPage.isCurrentPage()).toBe(true))
        .then(done, done.fail);
    });

    it('and token is invalid should redirect to signin page', (done) => {
      browserCache.makeTokenInvalid()
        .then(() => searchPage.whenISearchFor('invalidToken'))
        .then(() => expect(signInPage.isCurrentPage()).toBe(true))
        .then(done, done.fail);
    });
  });
});
