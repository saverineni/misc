import { browser, by, element } from 'protractor';

export class SearchFilters {

  private linksFacetFilter(dataLinkId) {
    return element(by.css(`.links[data-links-id="${dataLinkId}"]`)).element(by.css('.links__facet'));
  }

  clickLinksFacetFilter(dataLinkId) {
    // sleep after click due to animation of dialog open
    return this.linksFacetFilter(dataLinkId)
               .click()
               .then(() => browser.driver.sleep(500));
  }

  isFiltersClearAllEnabled() {
    return element(by.css('.search-filter__clear-all--active')).isPresent();
  }

  clickFiltersClearAll() {
    return element(by.css('.search-filter__clear-all')).click();
  }

}
