import {browser, by, element, ExpectedConditions} from 'protractor';

export class ExportCSVDialog {

    isDisplayed() {
        return element.all(by.css('.extract-csv')).then(dialogs => dialogs.length > 0);
    }

    getHeaderTitle() {
        return element(by.css('.extract-csv__header__title')).getText();
    }

    getHeaderContent() {
        return element(by.css('.extract-csv__header__content')).getText();
    }

    selectCheckbox(id) {
        const checkbox = this.getCheckbox(id);
        return browser.wait(ExpectedConditions.elementToBeClickable(checkbox)).then(() => checkbox.click());
    }

    isCheckboxSelected(id) {
        return this.getCheckbox(id)
          .getAttribute('aria-checked').then(value => value === 'true');
    }

    clickCancel() {
        // add sleep due to animated closure of dialog
        return this.getCancelButton().click()
        .then(() => browser.driver.sleep(500));
    }

    clickExtractAllButton() {
        return this.getExtractAllCheckbox().click()
        .then(() => browser.driver.sleep(500));
    }

    clickExtractToCSVButton() {
        // add sleep due to animated closure of dialog
        return this.getExtractToCSVButton().click()
          .then(() =>  browser.driver.sleep(500));
    }

    isExtractButtonEnabled() {
        return this.getExtractToCSVButton().isEnabled();
    }

    getCheckbox(id) {
        return element(by.css(`.extract-csv__checkboxes-${id}`));
    }

    private getCancelButton() {
        return element(by.css('.extract-csv__cancel'));
    }

    private getExtractAllCheckbox() {
        return element(by.css('.extract-csv__dialog-content__extract-all'));
    }

    private getExtractToCSVButton() {
        return element(by.css('.extract-csv__apply'));
    }

}
