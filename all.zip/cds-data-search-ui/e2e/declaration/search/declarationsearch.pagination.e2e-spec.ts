/// <reference path="../declarationMatchers.d.ts"/>

import {DeclarationSearchPage} from './declarationsearch.po';
import {declarationMatchers} from '../declarationMatchers';
import {AppPage} from '../../app.po';
import {SignInScenario} from '../../sign-in/sign-in-scenario';
import {Wiremock} from '../../wiremock';

describe('Declaration search', () => {
  const searchPage: DeclarationSearchPage = new DeclarationSearchPage();

  beforeAll((done) => {
    new SignInScenario().givenUserIsSignedIn()
      .then(done, done.fail);
  });

  beforeAll((done) => {
    Wiremock.reset()
      .then(() => searchPage.navigateTo())
      .then(done, done.fail);
  });

  describe('perform search', () => {
    describe('declaration', () => {

      beforeAll((done) => {
        searchPage.whenISearchFor('more-results')
          .then(done, done.fail);

        jasmine.addMatchers(declarationMatchers);
      });

      it('updates the url in the browser', (done) => {
        expect(new AppPage().getCurrentUrl()).toMatch(/\/\?searchTerm=more-results$/)
          .then(done, done.fail);
      });

      it('should display paginator', () => {
        expect(searchPage.isPaginatorHeaderDisplayed()).toBeTruthy();
      });

      it('should disable the previous page', () => {
        expect(searchPage.paginatorPreviousElement().isEnabled()).toBeFalsy();
      });

      it('should enable the next page', () => {
        expect(searchPage.paginatorNextElement().isEnabled()).toBeTruthy();
      });

      it('should display range label', () => {
        expect(searchPage.paginatorRangeLabelText()).toBe('1 - 10 of 12');
      });

      it('should display page label', () => {
        expect(searchPage.paginatorItemPageLabelText()).toBe('Declarations per page');
      });

      it('displays page results', () => {
        expect(searchPage.isResultsDisplayed()).toEqual(true);
        expect(searchPage.getDeclarationResultsCount()).toBe(10);
      });

      describe('click the next page', () => {

        beforeAll((done) => {
          searchPage.paginatorNextElement().click()
          .then(done, done.fail);
        });

        it('updates the url in the browser', (done) => {
          expect(new AppPage().getCurrentUrl()).toMatch(/\/\?searchTerm=more-results&pageNumber=2&pageSize=10$/)
            .then(done, done.fail);
        });

        it('should disable the next page', () => {
          expect(searchPage.paginatorNextElement().isEnabled()).toBeFalsy();
        });

        it('should enable the previous page', () => {
          expect(searchPage.paginatorPreviousElement().isEnabled()).toBeTruthy();
        });

        it('should display range label', () => {
          expect(searchPage.paginatorRangeLabelText()).toBe('11 - 12 of 12');
        });

        it('should display next page results', () => {
          expect(searchPage.isResultsDisplayed()).toEqual(true);
          expect(searchPage.getDeclarationResultsCount()).toBe(2);
        });

        describe('click on previous page', () => {
          beforeAll((done) => {
            searchPage.paginatorPreviousElement().click()
              .then(done, done.fail);
          });

          it('updates the url in the browser', (done) => {
            expect(new AppPage().getCurrentUrl()).toMatch(/\/\?searchTerm=more-results&pageNumber=1&pageSize=10$/)
              .then(done, done.fail);
          });

          it('should enable the next page', () => {
            expect(searchPage.paginatorNextElement().isEnabled()).toBeTruthy();
          });

          it('should disable the previous page', () => {
            expect(searchPage.paginatorPreviousElement().isEnabled()).toBeFalsy();
          });

          it('should display range label', () => {
            expect(searchPage.paginatorRangeLabelText()).toBe('1 - 10 of 12');
          });

          it('should display next page results', () => {
            expect(searchPage.isResultsDisplayed()).toEqual(true);
            expect(searchPage.getDeclarationResultsCount()).toBe(10);
          });
        });
      });
    });
  });
});
