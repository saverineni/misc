/// <reference path="../declarationMatchers.d.ts"/>

import {DeclarationSearchPage} from './declarationsearch.po';
import {DeclarationDetailPage} from '../detail/declarationdetail.po';
import {declarationMatchers} from '../declarationMatchers';
import {DeclarationSearchScenario} from './declaration-search-scenario';
import {AppPage} from '../../app.po';
import {NavigationBar} from '../../navigation-bar.po';
import {SignInScenario} from '../../sign-in/sign-in-scenario';
import {Wiremock} from '../../wiremock';
import {ErrorPage} from '../../error.po';
import {DateRangeFilter} from './facets/date-range-filter.po';
import {EORIFilter} from './facets/eori-filter.po';
import {SearchFilters} from './search-filters.po';
import {DeclarationDetailScenario} from '../detail/declarationdetail-scenario';
import {browser} from 'protractor';

describe('Declaration search', () => {
  const searchPage: DeclarationSearchPage = new DeclarationSearchPage();
  const errorPage: ErrorPage = new ErrorPage();

  beforeAll((done) => {
    new SignInScenario().givenUserIsSignedIn()
      .then(done, done.fail);
  });

  beforeAll((done) => {
    Wiremock.reset()
      .then(() => DeclarationSearchScenario.stubPerformSearch())
      .then(() => DeclarationSearchScenario.stubDeclarationPreviewDefinition())
      .then(() => searchPage.navigateTo())
      .then(done, done.fail);
  });

  it('should be the current page', () => {
    expect(searchPage.isCurrentPage()).toBe(true);
  });

  it('updates the title in the browser', () => {
    expect(new AppPage().getCurrentTitle()).toEqual(`CDS - Search Results`);
  });

  it('should not display result count', () => {
    expect(searchPage.isResultCountSectionDisplayed()).toBe(false);
  });

  it('should not display reset button', () => {
    expect(searchPage.isResetButtonDisplayed()).toBe(false);
  });

  it('should not display footer', () => {
    expect(searchPage.isFooterPresent()).toBe(false);
  });

  it('should not display paginator', () => {
    expect(searchPage.isPaginatorHeaderDisplayed()).toBe(false);
  });

  it('should not display the download csv icon', () => {
    expect(searchPage.isDownloadCsvDisplayed()).toBe(false);
  });

  it('should display help text message ', () => {
    expect(searchPage.getHmrcHelpText()).toBe('Please use the search box or the filters on the left hand side to start a new search.');
  });

  it('should display the hmrc logo', () => {
    expect(searchPage.isHmrcLogoPresent()).toBeTruthy();
  });

  [
    'originCountryCode',
    'dispatchCountryCode',
    'destinationCountryCode',
    'transportModeCode',
    'goodsLocation',
    'commodityCode',
    'cpc',
    'declarationType',
    'preferenceNumber'
  ].forEach(facetType => {
    it(`the page should display the enabled ${facetType} filter`, () => {
      expect(searchPage.linksFacetFilterEnabled(facetType)).toBe(true);
    });
  });

  it('should focus the search field', (done) => {
    expect(searchPage.isDeclarationSearchFieldFocused()).toBe(true)
      .then(done, done.fail);
  });

  describe('perform search', () => {
    describe('with not found search term', () => {

      beforeAll((done) => {
        searchPage.whenISearchFor('made-up')
          .then(done, done.fail);
      });

      it('should display the filters section', () => {
        expect(searchPage.isFiltersSectionDisplayed()).toBe(true);
      });

      it('should display reset button', () => {
        expect(searchPage.isResetButtonDisplayed()).toBe(true);
      });

      it('should display the result count', () => {
        expect(searchPage.resultCount()).toEqual('0');
      });

      it('should display no results found message', (done) => {
        expect(searchPage.isNoResultsFound()).toEqual(true)
          .then(() => expect(searchPage.getNoResultsFoundMessage()).toEqual('No results found for search criteria.'))
          .then(done, done.fail);
      });

      it('should not display help text message ', () => {
        expect(searchPage.isHmrcHelpTextPresent()).toBeFalsy();
      });

      it('should not display the hmrc logo', () => {
        expect(searchPage.isHmrcLogoPresent()).toBeFalsy();
      });

      [
        'originCountryCode',
        'dispatchCountryCode',
        // 'destinationCountryCode', // Commented out for now
        'transportModeCode',
        'goodsLocation',
        'commodityCode',
        'cpc',
        'declarationType',
        'preferenceNumber'
      ].forEach(facetType => {
        it(`filters section is display the enabled ${facetType} filter`, () => {
          expect(searchPage.linksFacetFilterEnabled(facetType)).toBe(true);
        });
      });

      it('updates the url in the browser', (done) => {
        expect(new AppPage().getCurrentUrl()).toMatch(/\/\?searchTerm=made-up$/)
          .then(done, done.fail);
      });

      describe('and click the home link', () => {
        beforeAll((done) => {
          new NavigationBar().clickHome()
            .then(done, done.fail);
        });

        it('clears the results', (done) => {
          expect(searchPage.isResultsDisplayed()).toEqual(false)
            .then(() => expect(searchPage.isNoResultsFound()).toEqual(false))
            .then(done, done.fail);
        });

        it('clears the declaration search field', (done) => {
          expect(searchPage.getDeclarationSearchFieldText()).toEqual('')
            .then(done, done.fail);
        });

        it('should focus the search field', (done) => {
          expect(searchPage.isDeclarationSearchFieldFocused()).toBe(true)
            .then(done, done.fail);
        });

        it('should display help text message ', () => {
          expect(searchPage.isHmrcHelpTextPresent()).toBeTruthy();
        });

        it('should display the hmrc logo', () => {
          expect(searchPage.isHmrcLogoPresent()).toBeTruthy();
        });
      });

      describe('and click the reset button', () => {
        beforeEach((done) => {
          searchPage.whenISearchFor('made-up')
            .then(() => searchPage.clickResetButton())
            .then(done, done.fail);
        });

        it('clears the results', (done) => {
          expect(searchPage.isResultsDisplayed()).toEqual(false)
            .then(() => expect(searchPage.isNoResultsFound()).toEqual(false))
            .then(done, done.fail);
        });
      });

    });

    describe('with empty search term', () => {
      it('displays declarations with no search term', (done) => {
        DeclarationSearchScenario.stubAuthenticatedSearchForTerm('')
          .then(() => searchPage.clickSearchIcon())
          .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
          .then(() => expect(searchPage.isResetButtonDisplayed()).toBe(true))
          .then(done, done.fail);
      });

      it('displays declarations when browser is refreshed ', (done) => {
        DeclarationSearchScenario.stubAuthenticatedSearchForTerm('')
          .then(() => searchPage.refresh())
          .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
          .then(() => expect(searchPage.isResetButtonDisplayed()).toBe(true))
          .then(done, done.fail);
      });
    });

    describe('declaration', () => {

      let declarationSearchResult;
      const DECLARATION_ID = '670-954107X-2017-08-22';
      const DECLARATION_ID_NO_LINES = 'declaration-with-no-lines';
      const DECLARATION_WITH_LINES_INDEX = 0;
      const DECLARATION_WITHOUT_LINES_INDEX = 1;

      beforeAll((done) => {
        declarationSearchResult = DeclarationSearchScenario.defaultSearchResponse();
        DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found')
          .then(() => searchPage.whenISearchFor('found'))
          .then(done, done.fail);

        jasmine.addMatchers(declarationMatchers);
      });

      it('updates the url in the browser', (done) => {
        expect(new AppPage().getCurrentUrl()).toMatch(/\/\?searchTerm=found$/)
          .then(done, done.fail);
      });

      it('should display the result count', () => {
        expect(searchPage.resultCount()).toEqual('20K');
      });

      it('should display paginator', () => {
        expect(searchPage.isPaginatorHeaderDisplayed()).toBe(true);
      });

      it('should display the download csv icon', () => {
        expect(searchPage.isDownloadCsvDisplayed()).toBe(true);
      });

      it('displays declarations if found', () => {
        expect(searchPage.isResultsDisplayed()).toBe(true);
      });

      it('displays export declaration if found', () => {
        expect(searchPage.getDataGridElement(DECLARATION_WITH_LINES_INDEX))
          .isDeclarationPreviewWithData(declarationSearchResult.declarations.find(declaration =>
            declaration.declarationId === DECLARATION_ID
          )
        );

        expect(searchPage.getExportDeclaration(DECLARATION_ID).isPresent()).toBeTruthy();
        expect(searchPage.getImportDeclaration(DECLARATION_ID).isPresent()).toBeFalsy();

        expect(searchPage.getExportDeclaration(DECLARATION_ID).getCssValue('border-right')).toBe('10px solid rgb(178, 209, 236)');
      });

      it('displays import declaration if found', () => {
        expect(searchPage.getDataGridElement(DECLARATION_WITHOUT_LINES_INDEX))
          .isDeclarationPreviewWithData(declarationSearchResult.declarations.find(declaration =>
            declaration.declarationId === DECLARATION_ID_NO_LINES
          )
        );

        expect(searchPage.getExportDeclaration(DECLARATION_ID_NO_LINES).isPresent()).toBeFalsy();
        expect(searchPage.getImportDeclaration(DECLARATION_ID_NO_LINES).isPresent()).toBeTruthy();

        expect(searchPage.getImportDeclaration(DECLARATION_ID_NO_LINES).getCssValue('border-right')).toBe('10px solid rgb(252, 243, 200)');

      });

      it('should not display help text message ', () => {
        expect(searchPage.isHmrcHelpTextPresent()).toBeFalsy();
      });

      it('should not display the hmrc logo', () => {
        expect(searchPage.isHmrcLogoPresent()).toBeFalsy();
      });

      it('filters section is displayed', () => {
        expect(searchPage.isFiltersSectionDisplayed()).toBe(true);
      });

      it('routes you to the declaration detail page when the button is clicked', (done) => {
        const detailPage = new DeclarationDetailPage();
        DeclarationDetailScenario.stubDeclaration(DECLARATION_ID)
          .then(() => searchPage.clickDeclarationDetail(DECLARATION_WITH_LINES_INDEX))
          .then(() => expect(detailPage.isCurrentPage()).toBe(true))
          .then(() => expect(detailPage.getDeclarationId()).toEqual(DECLARATION_ID))
          .then(() => searchPage.navigateTo())
          .then(done, done.fail);
      });

      describe('and click the reset button', () => {
        beforeAll((done) => {
          DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found')
            .then(() => searchPage.whenISearchFor('found'))
            .then(() => searchPage.clickResetButton())
            .then(done, done.fail);

        });

        it('clears the results', (done) => {
          expect(searchPage.isResultsDisplayed()).toEqual(false)
            .then(() => expect(searchPage.isResultsDisplayed()).toEqual(false))
            .then(done, done.fail);
        });
      });

    });

    describe('when backend is offline', () => {
      beforeAll((done) => {
        Wiremock.reset()
          .then(() => DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found'))
          .then(() => Wiremock.givenSearchServiceIsOffline())
          .then(() => searchPage.whenISearchFor('found'))
          .then(done, done.fail);
      });

      it('redirects to error page', () => {
        expect(errorPage.isCurrentPage()).toBeTruthy();
      });

      it('displays error page heading', () => {
        expect(errorPage.pageHeading()).toBe('Oops! Something went wrong.');
      });

      it('displays error incovenience message', () => {
        expect(errorPage.incovenienceMessage()).toBe(
          `We're sorry for the inconvenience caused. We will look in to the issue as soon as we can.`
        );
      });

      it('displays error help message', () => {
        expect(errorPage.helpMessage()).toBe(
          'Please use the ‘Customs Declaration Search’ link in the navigation bar above to return to the search landing page.'
        );
      });

      it('updates the title in the browser', () => {
        expect(errorPage.getCurrentTitle()).toBe(`CDS - Server Error`);
      });

      it('does not display search results', () => {
        expect(searchPage.isNoResultsFound()).toEqual(false);
      });

      describe('then back online', () => {
        beforeAll((done) => {
          Wiremock.reset()
            .then(() => new NavigationBar().clickHome())
            .then(() => DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found'))
            .then(() => searchPage.typeIntoSearchTermField('found'))
            .then(done, done.fail);
        });

        it('retries the search on clicking the search button a second time', (done) => {
          searchPage.clickSearchIcon()
            .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
            .then(done, done.fail);
        });
      });
    });
  });

  describe('cross icon', () => {

    beforeAll((done) => {
      DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found')
        .then(() => searchPage.whenISearchFor('found'))
        .then(done, done.fail);

      jasmine.addMatchers(declarationMatchers);
    });

    it('should display help text message', (done) => {
      searchPage.clearSearchTerm()
        .then(() => expect(searchPage.getHmrcHelpText()).toBe(
          'Please use the search box or the filters on the left hand side to start a new search.'
        ))
        .then(done, done.fail);
    });

    it('clears search field', () => {
      expect(searchPage.getDeclarationSearchFieldText()).toEqual('');
    });

    it('does not clear results when searchterm does not match the searchterm in the url', (done) => {
      DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found')
        .then(() => searchPage.whenISearchFor('found'))
        .then(() => searchPage.typeIntoSearchTermField('newfound'))
        .then(() => searchPage.clearSearchTerm())
        .then(() => expect(new AppPage().getCurrentUrl()).toMatch(/\/\?searchTerm=found$/))
        .then(done, done.fail);
    });

  });

  describe('filters clear all', () => {
    const searchFilters = new SearchFilters();

    describe('without filters', () => {
      it('is greyed out when no filters entered', () => {
        expect(searchFilters.isFiltersClearAllEnabled()).toBe(false);
      });
    });

    describe('with filters', () => {
      const entryDateFilter = new DateRangeFilter('entry');
      const eoriFilter = new EORIFilter();

      beforeAll((done) => {
        Wiremock.reset()
          .then(() => DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found'))
          .then(() => searchPage.navigateTo('?searchTerm=found&entryDateFrom=2016-01-01&eori=eori&originCountryCode=GB'))
          .then(done, done.fail);
      });

      it('starts with drop down filters open', () => {
        expect(eoriFilter.isPanelCollapsed()).toBe(false);
        expect(entryDateFilter.isPanelCollapsed()).toBe(false);
      });

      it('is green when filters are active', () => {
        expect(searchFilters.isFiltersClearAllEnabled()).toBe(true);
      });

      it('clears the filters when clicked but not the search term', (done) => {
        searchFilters.clickFiltersClearAll()
          .then(() => expect(new AppPage().getCurrentUrl()).toMatch(/\/\?searchTerm=found$/))
          .then(done, done.fail);
      });

      it('closes the drop down filters when cleared', () => {
        expect(eoriFilter.isPanelCollapsed()).toBe(true);
        expect(entryDateFilter.isPanelCollapsed()).toBe(true);
      });
    });

  });

  describe('with filters', () => {
    const entryDateFilter = new DateRangeFilter('entry');
    const eoriFilter = new EORIFilter();

    beforeAll((done) => {
      Wiremock.reset()
        .then(() => DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found'))
        .then(() => searchPage.navigateTo('?searchTerm=found&entryDateFrom=2016-01-01&eori=eori&originCountryCode=GB'))
        .then(done, done.fail);
    });

    it('should have the panels in open state at the start', () => {
      expect(eoriFilter.isPanelCollapsed()).toBe(false);
      expect(entryDateFilter.isPanelCollapsed()).toBe(false);
    });

    it('should close all the panels when reset search button is clicked', (done) => {
      searchPage.clickResetButton()
        .then(() => expect(eoriFilter.isPanelCollapsed()).toBe(true))
        .then(() => expect(entryDateFilter.isPanelCollapsed()).toBe(true))
        .then(done, done.fail);
    });
  });

  describe('bookmark search', () => {
    const bookmarkSpecialChars = ';/:@&?=<>#%{}|\^~[]` шеллы';
    const url = '?searchTerm=' + encodeURIComponent(bookmarkSpecialChars);

    beforeAll((done) => {
      DeclarationSearchScenario.stubAuthenticatedSearchForTerm(bookmarkSpecialChars)
        .then(() => searchPage.navigateTo(url))
        .then(done, done.fail);
    });

    it('populates the declaration search field', () => {
      expect(searchPage.getDeclarationSearchFieldText()).toEqual(bookmarkSpecialChars);
    });

    it('display results', () => {
      expect(searchPage.isResultsDisplayed()).toEqual(true);
    });
  });

  describe('search term on clear', () => {
    beforeAll((done) => {
      DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found')
        .then(() => searchPage.typeIntoSearchTermField('found'))
        .then(() => searchPage.clickSearchIcon())
        .then(() => searchPage.clearSearchTerm())
        .then(done, done.fail);

      jasmine.addMatchers(declarationMatchers);
    });

    it('clears the search results', (done) => {
      expect(searchPage.isResultsDisplayed()).toEqual(false)
        .then(() => expect(searchPage.isNoResultsFound()).toEqual(false))
        .then(done, done.fail);
    });


    it('clears search field text', () => {
      expect(searchPage.getDeclarationSearchFieldText()).toEqual('');
    });


    it('should display help text message', (done) => {
      browser.driver.sleep(500)
        .then(() => expect(searchPage.getHmrcHelpText()).toBe(
          'Please use the search box or the filters on the left hand side to start a new search.'
        ))
        .then(done, done.fail);
    });

    it('clears the searchterm in the url', (done) => {
      browser.driver.sleep(500)
      .then(() => expect(new AppPage().getCurrentUrl()).toBe(browser.baseUrl + '/'))
      .then(done, done.fail);
    });

  });
});
