import { browser, by, element, ExpectedConditions } from 'protractor';
import { DataGridElement } from '../DataGridElement';

export class DeclarationSearchPage {
  navigateTo(queryString = '') {
    return browser.get(`/${queryString}`)
      .then(() => browser.waitForAngular());
  }

  refresh() {
    return browser.refresh();
  }

  urlQueryString() {
    return browser.waitForAngular()
      .then(() => browser.getCurrentUrl())
      .then(url => url.replace(/^https:\/\/\w+:\d+\/\?(.+)$/, '$1'));
  }

  isCurrentPage() {
    return element(by.css('.search-section')).isPresent();
  }

  isResultCountSectionDisplayed() {
    return element(by.css('.search-section__results-count-section')).isPresent();
  }

  resultCount() {
    const resultCountElement = element(by.css('.search-section__results-count'));
    return resultCountElement && resultCountElement.getText();
  }

  search(searchTerm: string) {
    return this.typeIntoSearchTermField(searchTerm)
      .then(() => this.clickSearchIcon());
  }

  typeIntoSearchTermField(searchTerm: string) {
    return this.getDeclarationField().sendKeys(searchTerm);
  }

  clearSearchTerm() {
    return element(by.css('.search-form__clear-search')).click();
  }

  getDeclarationSearchFieldText() {
    return this.getDeclarationField().getAttribute('value');
  }

  isDeclarationSearchFieldFocused() {
    return browser.driver.switchTo().activeElement().getAttribute('name')
      .then((fieldname) => fieldname === 'searchTerm');
  }

  isFooterPresent() {
    return element(by.css('.footer')).isPresent();
  }

  private getDeclarationField() {
    return element(by.css('.search-form__searchterm-input'));
  }

  clickSearchIcon() {
    return element(by.css('.search-form__perform-search')).click();
  }

  isNoResultsFound() {
    return element(by.css('.search-section__no-search-results')).isPresent();
  }

  getNoResultsFoundMessage() {
    return element(by.css('.search-section__no-search-results')).getText();
  }

  isResultsDisplayed() {
    return element(by.css('.search-section__results')).isPresent();
  }

  isFiltersSectionDisplayed() {
    return element(by.css('.search-section__filters')).isPresent();
  }

  isPaginatorHeaderDisplayed() {
    return element(by.css('.search-section__paginator-header')).isPresent();
  }

  paginatorPreviousElement() {
    return element(by.css('.search-section__paginator-header .mat-paginator-navigation-previous'));
  }

  paginatorNextElement() {
    return element(by.css('.search-section__paginator-header .mat-paginator-navigation-next'));
  }

  paginatorRangeLabelText() {
    return element(by.css('.search-section__paginator-header .mat-paginator-range-label')).getText();
  }

  paginatorItemPageLabelText() {
    return element(by.css('.search-section__paginator-header .mat-select')).getAttribute('aria-label');
  }

  isDownloadCsvDisplayed() {
    return this.downloadCsv().isPresent();
  }

  linksFacetFilterEnabled(dataLinkId) {
    return this.linksFacetFilter(dataLinkId).isDisplayed();
  }

  isResetButtonDisplayed() {
    return this.resetButton().isPresent();
  }

  clickResetButton() {
    return this.resetButton().click();
  }

  clickDownloadCsv() {
  // sleep after click due to animation of dialog open

    return browser.wait(ExpectedConditions.elementToBeClickable(this.downloadCsv()))
        .then(() => this.downloadCsv().click())
        .then(() => browser.driver.sleep(500));
  }



  private downloadCsv() {
    return element(by.css('.search-section__download-csv'));
  }

  private hiddenCsv() {
    return element(by.css('.search-section__download-csv--hidden'));
  }

  private linksFacetFilter(dataLinkId) {
    return element(by.css(`.links[data-links-id="${dataLinkId}"]`));
  }

  private resetButton() {
    return element(by.css('.search-section__reset-button'));
  }

  getDeclarationResultsCount() {
    return element.all(by.css('.search-results-cards__declarations')).count();
  }

  getDataGridElement(row: number): DataGridElement {
    return new DataGridElement(element.all(by.css('.search-results-cards__declarations')).get(row));
  }

  getImportDeclaration(id) {
    return element(by.css(`.search-results-cards__declarations--import[data-declaration-id="${id}"]`));
  }

  getExportDeclaration(id) {
    return element(by.css(`.search-results-cards__declarations--export[data-declaration-id="${id}"]`));
  }

  clickDeclarationDetail(row: number) {
    return element.all(by.css('.search-results-cards__declaration-details-button')).get(row).click();
  }

  whenISearchFor(searchTerm: string) {
    return this.search(searchTerm);
  }

  isHmrcLogoPresent() {
    return this.hmrcHelpLogo().isPresent();
  }

  isHmrcHelpTextPresent() {
    return this.hmrcHelpText().isPresent();
  }

  getHmrcHelpText() {
    return this.hmrcHelpText().getText();
  }

  private hmrcHelpText() {
    return element(by.css('.search-section__hmrc__display-text'));
  }

  private hmrcHelpLogo() {
    return element(by.css('.search-section__hmrc__display-logo'));
  }
}
