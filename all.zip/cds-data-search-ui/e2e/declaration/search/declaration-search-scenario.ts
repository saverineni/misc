import { SignInPage } from '../../sign-in/sign-in.po';
import { Wiremock } from '../../wiremock';
import { HttpParams } from '@angular/common/http';
const fs = require('fs');

export class DeclarationSearchScenario {
    private static DECLARATION_PREVIEW_DEFINITION_FILE_NAME = 'declaration-preview-definition.json';
    private static DECLARATION_FILE_NAME = 'default-declarations-response.json';
    private static DECLARATION_DEFINITION_FILE_NAME = 'declaration-definition.json';

    static defaultSearchResponse() {
      return JSON.parse(fs.readFileSync(`e2e/wiremock/__files/${this.DECLARATION_FILE_NAME}`));
    }

    static stubPerformSearch() {
      return this.stubPerformSearchWithDelayMillis(0);
    }

    static stubDeclarationPreviewDefinition() {
      return Wiremock.stubRequest({
        'priority': 1,
        'request': {
          'method': 'GET',
          'url': '/search/definition'
        },
        'response': {
          'status': 200,
          'bodyFileName': this.DECLARATION_PREVIEW_DEFINITION_FILE_NAME
        }
      });
    }

    static stubPerformSearchWithDelayMillis(delay) {
        return Wiremock.stubRequest({
          'priority': 1,
          'request': {
            'method': 'GET',
            'urlPattern': '/search\\?searchTerm=found.*'
          },
          'response': {
            'status': 200,
            'bodyFileName': this.DECLARATION_FILE_NAME,
            'fixedDelayMilliseconds': delay
          }
       });
    }

    static stubAuthenticatedSearchForTerm(searchTerm: string) {
      return this.stubAuthenticatedSearchForParams({ searchTerm: searchTerm });
    }

    static stubAuthenticatedSearchForParams(params: any) {
      const queryString = new HttpParams({fromObject: params}).toString();

      return Wiremock.stubRequest({
        'priority': 1,
        'request': {
          'method': 'GET',
          'url': `/search?${queryString}`,
          'headers': {
            'Authorization': {
              'equalTo': 'Bearer ' + SignInPage.DEFAULT_AUTH_TOKEN
            }
          }
        },
        'response': {
          'status': 200,
          'bodyFileName': this.DECLARATION_FILE_NAME
        }
      });
  }

  static stubDeclarationDefinition() {
    return Wiremock.stubRequest({
      'priority': 1,
      'request': {
        'method': 'GET',
        'url': '/declarations/definition'
      },
      'response': {
        'status': 200,
        'bodyFileName': this.DECLARATION_DEFINITION_FILE_NAME
      }
    });
  }
}
