import {browser, by, element, ExpectedConditions} from 'protractor';
import {Filter} from './filter.po';

export class NumberRangeFilter implements Filter {
  filterId: string;

  constructor(dateFilterClass: string) {
    this.filterId = dateFilterClass;
  }

  private getFromInput() {
    return element(by.css(`.search-filter__${this.filterId} .number-range__from-input`));
  }

  private getToInput() {
    return element(by.css(`.search-filter__${this.filterId} .number-range__to-input`));
  }

  populateFrom(input) {
    return browser.wait(ExpectedConditions.visibilityOf(this.getFromInput())).then(() => this.getFromInput().sendKeys(input));
  }

  getFrom() {
    return this.getFromInput().getText();
  }

  populateTo(input) {
    return browser.wait(ExpectedConditions.visibilityOf(this.getToInput())).then(() => this.getToInput().sendKeys(input));
  }

  getTo() {
    return this.getToInput().getText();
  }

  clickClear() {
    return element(by.css(`.search-filter__${this.filterId} .number-range__clear-button`)).click();
  }

  clickApplyFilters() {
    return element(by.css(`.search-filter__${this.filterId} .number-range__apply-filters-button`)).click();
  }

  clickExpandingHeader() {
    const header = element(by.css(`.search-filter__${this.filterId} .number-range__header`));
    return browser.wait(ExpectedConditions.elementToBeClickable(header)).then(() => header.click());
  }

  isPanelCollapsed() {
    return element(by.css(`.search-filter__${this.filterId} .number-range__header`)).getAttribute('aria-expanded')
          .then(value => value === 'false');
  }
}
