export interface Filter {
    filterId: string;
    isPanelCollapsed();
  }
