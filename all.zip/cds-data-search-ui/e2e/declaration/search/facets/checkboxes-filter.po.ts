import {browser, by, element, ExpectedConditions} from 'protractor';
import {Filter} from './filter.po';

export class CheckboxesFilter implements Filter {

  filterId: string;

  constructor(private checkBoxesId: string) {
    this.filterId = checkBoxesId;
  }

  private getParentElement() {
      return element(by.css(`.checkboxes[checkboxes-id="${this.filterId}"]`));
  }

  getHeader() {
      return this.getParentElement().element(by.css('.checkboxes__title')).getText();
  }

  getAllCheckboxes() {
    return this.getParentElement()
             .all(by.css('.mat-checkbox-label'))
             .map(elem => elem.getAttribute('textContent').then(it => it.trim()));
   }

  isPanelCollapsed() {
    return element(by.css(`.checkboxes[checkboxes-id="${this.filterId}"] .checkboxes__header`)).getAttribute('aria-expanded')
          .then(value => value === 'false');
  }

  clickExpandingHeader() {
    const header = element(by.css(`.checkboxes[checkboxes-id="${this.filterId}"] .checkboxes__header`));
    return browser.wait(ExpectedConditions.elementToBeClickable(header)).then(() => header.click());
  }

  clickClear() {
    const clear_filter =  this.getParentElement().element(by.css('.checkboxes__clear'));
    return browser.wait(ExpectedConditions.elementToBeClickable(clear_filter)).then(() => clear_filter.click());
  }

  clickApplyFilters() {
    const apply_filters = this.getApplyFilters();
    return browser.wait(ExpectedConditions.elementToBeClickable(apply_filters)).then(() => apply_filters.click());
  }

  isApplyFiltersEnabled() {
    return this.getApplyFilters().isEnabled();
  }

  private getApplyFilters() {
    return this.getParentElement().element(by.css('.checkboxes__apply-filters'));
  }

  isAllCheckboxesCleared() {
    return this.getParentElement().all(by.css('.mat-checkbox-input'))
            .filter(elem => (elem.isSelected().then(it => it === false))) !== undefined;
  }

  selectCheckbox(id) {
    const checkbox = element(by.css(`.checkboxes[checkboxes-id="${this.filterId}"] .checkboxes__form-${id} .mat-checkbox-label`));
    return browser.wait(ExpectedConditions.elementToBeClickable(checkbox)).then(() => checkbox.click());
  }

  isCheckboxSelected(id) {
    return element(by.css(`.checkboxes[checkboxes-id="${this.filterId}"] .checkboxes__form-${id} .mat-checkbox-input`))
      .getAttribute('aria-checked').then(value => value === 'true');
  }

}
