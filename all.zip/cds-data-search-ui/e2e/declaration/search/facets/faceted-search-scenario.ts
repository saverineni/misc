import { Wiremock } from '../../../wiremock';
import { SignInPage } from '../../../sign-in/sign-in.po';

export class FacetedSearchScenario {

  static stubFacetWithPrefixRequest(searchParam) {
    return this.facetRequest( {
        'status': 200,
        'bodyFileName': `facets/${searchParam}-filtered-response.json`
      });
  }

  static stubUnauthorizeFacetRequest() {
    return this.facetRequest({
        'status': 401
      });
  }

  private static facetRequest(response) {
    return Wiremock.stubRequest({
      'priority': 1,
      'request': {
        'method': 'GET',
        'urlPattern': '/facets/[a-zA-Z]+/[a-zA-Z0-9\\*]+\\?searchTerm=found$',
        'headers': {
          'Authorization': {
            'equalTo': 'Bearer ' + SignInPage.DEFAULT_AUTH_TOKEN
          }
        }
      },
      'response': response
    });
  }
}
