import {browser, by, element, ExpectedConditions} from 'protractor';
import {Filter} from './filter.po';

export class EORIFilter implements Filter {

  filterId = 'search-field';

  clickExpandingHeader() {
    const header = element(by.css(`.${this.filterId}__header`));
    return browser.wait(ExpectedConditions.elementToBeClickable(header)).then(() => header.click());
  }

  isPanelCollapsed() {
    return element(by.css(`.${this.filterId}__header`)).getAttribute('aria-expanded')
      .then(value => value === 'false');
  }

  private getInputField() {
    return element(by.css(`.${this.filterId}__searchfield-input`));
  }

  populateEori(eori) {
    return browser.wait(ExpectedConditions.visibilityOf(this.getInputField())).then(() => this.getInputField().sendKeys(eori));
  }

  clickClear() {
    return element(by.css(`.${this.filterId}__clear-search`)).click();
  }

  getInputFieldText() {
    return this.getInputField().getText();
  }

  clickSearch() {
    return element(by.css(`.${this.filterId}__perform-search`)).click();
  }
}
