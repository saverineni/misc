import {browser, by, element, ExpectedConditions} from 'protractor';
import {Filter} from './filter.po';

export class DateRangeFilter implements Filter {
  filterId: string;

  constructor(dateFilterClass: string) {
    this.filterId = dateFilterClass;
  }

  private getDateFromInput() {
    return element(by.css(`.search-filter__${this.filterId}-date .date-range__from-input`));
  }

  private getDateToInput() {
    return element(by.css(`.search-filter__${this.filterId}-date .date-range__to-input`));
  }

  populateDateFrom(date) {
    return browser.wait(ExpectedConditions.visibilityOf(this.getDateFromInput())).then(() => this.getDateFromInput().sendKeys(date));
  }

  getDateFrom() {
    return this.getDateFromInput().getText();
  }

  populateDateTo(date) {
    return browser.wait(ExpectedConditions.visibilityOf(this.getDateToInput())).then(() => this.getDateToInput().sendKeys(date));
  }

  getDateTo() {
    return this.getDateToInput().getText();
  }

  clickClear() {
    return element(by.css(`.search-filter__${this.filterId}-date .date-range__clear-button`)).click();
  }

  clickApplyFilters() {
    return element(by.css(`.search-filter__${this.filterId}-date .date-range__apply-filters-button`)).click();
  }

  clickExpandingHeader() {
    const header = element(by.css(`.search-filter__${this.filterId}-date .date-range__header`));
    return browser.wait(ExpectedConditions.elementToBeClickable(header)).then(() => header.click());
  }

  isPanelCollapsed() {
    return element(by.css(`.search-filter__${this.filterId}-date .date-range__header`)).getAttribute('aria-expanded')
          .then(value => value === 'false');
  }
}
