import {DeclarationSearchPage} from '../declarationsearch.po';
import {Wiremock} from '../../../wiremock';
import {SignInScenario} from '../../../sign-in/sign-in-scenario';
import {DeclarationSearchScenario} from '../declaration-search-scenario';
import {DateRangeFilter} from './date-range-filter.po';
import {browser} from 'protractor';
import { NavigationBar } from '../../../navigation-bar.po';

describe('Date range faceted search', () => {
  const entryDateId = 'entry';
  const clearanceDateId = 'clearance';
  const acceptanceDateId = 'acceptance';
  let searchPage: DeclarationSearchPage;
  const filters: string[] = [entryDateId, clearanceDateId, acceptanceDateId];

  beforeAll((done) => {
    searchPage = new DeclarationSearchPage();
    new SignInScenario().givenUserIsSignedIn()
      .then(() => Wiremock.reset())
      .then(() => searchPage.navigateTo())
      .then(done, done.fail);
  });

  describe('url updated with date parameters', () => {
    beforeEach((done) => {
      DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found')
        .then(() => searchPage.whenISearchFor('found'))
        .then(done, done.fail);
    });

    filters.forEach(filterId => {
      describe(`filter results by ${filterId} dates`, () => {
        const fromDate =  '22/10/2016';
        const toDate =  '24/10/2017';
        const currentFilter = new DateRangeFilter(filterId);

        it('select dates and click cancel to clear', (done) => {
          currentFilter.clickExpandingHeader()
            .then(() => currentFilter.populateDateFrom(fromDate))
            .then(() => currentFilter.populateDateTo(toDate))
            .then(() => currentFilter.clickClear())
            .then(() => expect(currentFilter.isPanelCollapsed()).toEqual(false))
            .then(() => expect(currentFilter.getDateFrom()).toEqual(''))
            .then(() => expect(currentFilter.getDateTo()).toEqual(''))
            .then(() => expect(browser.getCurrentUrl()).not.toContain(`${filterId}DateFrom=`))
            .then(() => expect(browser.getCurrentUrl()).not.toContain(`${filterId}DateTo=`))
            .then(done, done.fail);
        });

        it('input invalid dates and click cancel to clear', (done) => {
          currentFilter.populateDateFrom('invalid')
            .then(() => currentFilter.populateDateTo('invalid'))
            .then(() => currentFilter.clickClear())
            .then(() => expect(currentFilter.getDateFrom()).toEqual(''))
            .then(() => expect(currentFilter.getDateTo()).toEqual(''))
            .then(() => expect(browser.getCurrentUrl()).not.toContain(`${filterId}DateFrom=`))
            .then(() => expect(browser.getCurrentUrl()).not.toContain(`${filterId}DateTo=`))
            .then(done, done.fail);
        });

        it('on apply filters the url should contain the dates selected in ISO format', (done) => {
          currentFilter.populateDateFrom(fromDate)
            .then(() => currentFilter.populateDateTo(toDate))
            .then(() => currentFilter.clickApplyFilters())
            .then(() => expect(browser.getCurrentUrl()).toContain(`${filterId}DateFrom=2016-10-22`))
            .then(() => expect(browser.getCurrentUrl()).toContain(`${filterId}DateTo=2017-10-24`))
            .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
            .then(done, done.fail);
        });

        describe('clicking the home link should', () => {

          beforeAll((done) => {
            currentFilter.populateDateFrom(fromDate)
              .then(() => currentFilter.populateDateTo(toDate))
              .then(() => currentFilter.clickApplyFilters())
              .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
              .then(() => new NavigationBar().clickHome())
              .then(done, done.fail);
          });

          it('clear the date fields', (done) => {
            currentFilter.clickExpandingHeader()
              .then(() => expect(currentFilter.getDateFrom()).toBe(''))
              .then(() => expect(currentFilter.getDateTo()).toBe(''))
              .then(done, done.fail);
          });

          afterAll((done) => {
            currentFilter.clickExpandingHeader()
              .then(done, done.fail);
          });
        });
      });
    });
  });
});
