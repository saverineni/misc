import {DeclarationSearchPage} from '../declarationsearch.po';
import {Wiremock} from '../../../wiremock';
import {SignInScenario} from '../../../sign-in/sign-in-scenario';
import {DeclarationSearchScenario} from '../declaration-search-scenario';
import {browser} from 'protractor';
import {CheckboxesFilter} from './checkboxes-filter.po';
import {NavigationBar} from '../../../navigation-bar.po';
import {startCase} from 'lodash';


describe('Checkboxes type filter', () => {
  let searchPage: DeclarationSearchPage;

  beforeAll((done) => {
    searchPage = new DeclarationSearchPage();

    new SignInScenario().givenUserIsSignedIn()
      .then(() => Wiremock.reset())
      .then(() => searchPage.navigateTo())
      .then(done, done.fail);
  });

  [{
    name: 'declaration source',
    filterId: 'declarationSource',
    data: ['CHIEF', 'CDS'],
    selectCheckbox: 'CHIEF'
  }
  ].forEach((test: any) => {
    describe(`url updated with ${test.name} parameters`, () => {
        beforeAll((done) => {
          DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found')
            .then(() => searchPage.whenISearchFor('found'))
            .then(done, done.fail);
        });
        const checkboxesTypeFilter: CheckboxesFilter = new CheckboxesFilter(test.filterId);
          describe(`filter results by ${test.name}`, () => {

            it('should display the header title' , () => {
                expect(checkboxesTypeFilter.getHeader()).toBe(startCase(test.name));
            });

            it('should display the checkboxes' , () => {
              expect(checkboxesTypeFilter.getAllCheckboxes()).toEqual(test.data);
            });

            it(`on clear ${test.name} should not be in url`, (done) => {
              checkboxesTypeFilter.clickExpandingHeader()
                .then(() => checkboxesTypeFilter.selectCheckbox(test.selectCheckbox))
                .then(() => checkboxesTypeFilter.clickApplyFilters())
                .then(() => checkboxesTypeFilter.clickClear())
                .then(() => expect(checkboxesTypeFilter.isCheckboxSelected(test.selectCheckbox)).toEqual(false))
                .then(() => expect(browser.getCurrentUrl()).not.toContain(`${test.filterId}=`))
                .then(() => checkboxesTypeFilter.clickExpandingHeader())
                .then(done, done.fail);
            });

            it(`apply filters should be enabled if url contain the ${test.name} even if checkbox is unchecked`, (done) => {
              checkboxesTypeFilter.clickExpandingHeader()
                .then(() => checkboxesTypeFilter.clickClear())
                .then(() => checkboxesTypeFilter.selectCheckbox(test.selectCheckbox))
                .then(() => checkboxesTypeFilter.clickApplyFilters())
                .then(() => expect(browser.getCurrentUrl()).toContain(`${test.filterId}=${test.selectCheckbox}`))
                .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
                .then(() => expect(checkboxesTypeFilter.isCheckboxSelected(test.selectCheckbox)).toEqual(true))
                .then(() => checkboxesTypeFilter.selectCheckbox(test.selectCheckbox))
                .then(() => expect(checkboxesTypeFilter.isCheckboxSelected(test.selectCheckbox)).toEqual(false))
                .then(() => expect(checkboxesTypeFilter.isApplyFiltersEnabled()).toEqual(true))
                .then(done, done.fail);
            });

          });

        describe('clicking the home link', () => {
          beforeAll((done) => {
              new NavigationBar().clickHome()
              .then(() => browser.driver.sleep(500))
              .then(done, done.fail);
          });

          it(`clears the ${test.name} filter`, (done) => {
            checkboxesTypeFilter.clickExpandingHeader()
              .then(() => expect(checkboxesTypeFilter.isAllCheckboxesCleared()).toEqual(true))
              .then(done, done.fail);
          });
        });

     });
    });
});
