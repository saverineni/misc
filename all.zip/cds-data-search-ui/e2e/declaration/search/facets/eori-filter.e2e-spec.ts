import {DeclarationSearchPage} from '../declarationsearch.po';
import {Wiremock} from '../../../wiremock';
import {SignInScenario} from '../../../sign-in/sign-in-scenario';
import {DeclarationSearchScenario} from '../declaration-search-scenario';
import {EORIFilter} from './eori-filter.po';
import {browser} from 'protractor';
import {NavigationBar} from '../../../navigation-bar.po';
import {ToolTip} from '../../../tooltip/tooltip.po';

describe('EORI filter', () => {
  let searchPage: DeclarationSearchPage;
  let eoriFilter: EORIFilter;
  let toolTip: ToolTip;
  const greenColour = 'rgba(16, 134, 110, 1)';
  const greyColour = 'rgba(136, 136, 136, 1)';

  beforeAll((done) => {
    searchPage = new DeclarationSearchPage();
    eoriFilter = new EORIFilter();
    toolTip = new ToolTip();

    new SignInScenario().givenUserIsSignedIn()
      .then(() => Wiremock.reset())
      .then(() => searchPage.navigateTo())
      .then(done, done.fail);
  });

  describe('url updated with eori parameters', () => {
    beforeAll((done) => {
      DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found')
        .then(() => searchPage.whenISearchFor('found'))
        .then(done, done.fail);
    });

    describe('filter results by EORI', () => {
      const eoriValue =  '123456789';

      it('enter EORI and and click cancel to clear', (done) => {
        eoriFilter.clickExpandingHeader()
          .then(() => eoriFilter.populateEori(eoriValue))
          .then(() => eoriFilter.clickClear())
          .then(() => expect(eoriFilter.getInputFieldText()).toEqual(''))
          .then(() => expect(browser.getCurrentUrl()).not.toContain('eori='))
          .then(done, done.fail);
      });

      it('on apply filters the url should contain the eori', (done) => {
        eoriFilter.populateEori(eoriValue)
          .then(() => eoriFilter.clickSearch())
          .then(() => expect(browser.getCurrentUrl()).toContain('eori=' + eoriValue))
          .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
          .then(done, done.fail);
      });

      describe('clicking the home link should', () => {
        beforeAll((done) => {
          eoriFilter.clickSearch()
            .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
            .then(() => new NavigationBar().clickHome())
            .then(() => browser.driver.sleep(500))
            .then(done, done.fail);
        });

        it('clears the eori field', (done) => {
          eoriFilter.clickExpandingHeader()
            .then(() => expect(eoriFilter.getInputFieldText()).toBe(''))
            .then(done, done.fail);
        });
      });
    });
  });

  describe('Tooltip', () => {

    it('changes colour on hover', (done) => {
      expect(toolTip.getTooltipColour()).toBe(greenColour);

      toolTip.hoverEORIToolTipIcon()
        .then(() => browser.driver.sleep(2000))
        .then( () =>  expect(toolTip.getTooltipColour()).toBe(greyColour))
        .then(done, done.fail);

    });
  });
});
