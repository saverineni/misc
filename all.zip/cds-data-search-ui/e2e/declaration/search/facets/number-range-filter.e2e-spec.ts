import {DeclarationSearchPage} from '../declarationsearch.po';
import {Wiremock} from '../../../wiremock';
import {SignInScenario} from '../../../sign-in/sign-in-scenario';
import {DeclarationSearchScenario} from '../declaration-search-scenario';
import {browser} from 'protractor';
import { NavigationBar } from '../../../navigation-bar.po';
import { NumberRangeFilter } from './number-range-filter.po';

describe('Number range faceted search', () => {
  const netMassId = 'net-mass';
  const itemPriceId = 'item-price';
  let searchPage: DeclarationSearchPage;
  const filters: string[] = [netMassId, itemPriceId];

  beforeAll((done) => {
    searchPage = new DeclarationSearchPage();
    new SignInScenario().givenUserIsSignedIn()
      .then(() => Wiremock.reset())
      .then(() => searchPage.navigateTo())
      .then(done, done.fail);
  });

  describe('url updated with parameters', () => {
    beforeEach((done) => {
      DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found')
        .then(() => searchPage.whenISearchFor('found'))
        .then(done, done.fail);
    });

    filters.forEach(filterId => {
      describe(`filter results by ${filterId}`, () => {
        const from =  '1.2';
        const to =  '2.3';
        const currentFilter = new NumberRangeFilter(filterId);
        const camelCasedId = filterId.replace(/-([a-z])/g, function (g) { return g[1].toUpperCase(); });

        it('input valid values and click cancel to clear', (done) => {
          currentFilter.clickExpandingHeader()
            .then(() => currentFilter.populateFrom(from))
            .then(() => currentFilter.populateTo(to))
            .then(() => currentFilter.clickClear())
            .then(() => expect(currentFilter.isPanelCollapsed()).toEqual(false))
            .then(() => expect(currentFilter.getFrom()).toEqual(''))
            .then(() => expect(currentFilter.getTo()).toEqual(''))
            .then(() => expect(browser.getCurrentUrl()).not.toContain(`${camelCasedId}From=`))
            .then(() => expect(browser.getCurrentUrl()).not.toContain(`${camelCasedId}To=`))
            .then(done, done.fail);
        });

        it('input invalid values and click cancel to clear', (done) => {
          currentFilter.populateFrom('invalid')
            .then(() => currentFilter.populateTo('invalid'))
            .then(() => currentFilter.clickClear())
            .then(() => expect(currentFilter.getFrom()).toEqual(''))
            .then(() => expect(currentFilter.getTo()).toEqual(''))
            .then(() => expect(browser.getCurrentUrl()).not.toContain(`${camelCasedId}From=`))
            .then(() => expect(browser.getCurrentUrl()).not.toContain(`${camelCasedId}To=`))
            .then(done, done.fail);
        });

        it('on apply filters the url should contain the values selected', (done) => {
          currentFilter.populateFrom(from)
            .then(() => currentFilter.populateTo(to))
            .then(() => currentFilter.clickApplyFilters())
            .then(() => expect(browser.getCurrentUrl()).toContain(`${camelCasedId}From=${from}`))
            .then(() => expect(browser.getCurrentUrl()).toContain(`${camelCasedId}To=${to}`))
            .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
            .then(done, done.fail);
        });

        describe('clicking the home link should', () => {

          beforeAll((done) => {
            currentFilter.populateFrom(from)
              .then(() => currentFilter.populateTo(to))
              .then(() => currentFilter.clickApplyFilters())
              .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
              .then(() => new NavigationBar().clickHome())
              .then(done, done.fail);
          });

          it('clear the input fields', (done) => {
            currentFilter.clickExpandingHeader()
              .then(() => expect(currentFilter.getFrom()).toBe(''))
              .then(() => expect(currentFilter.getTo()).toBe(''))
              .then(done, done.fail);
          });

          afterAll((done) => {
            currentFilter.clickExpandingHeader()
              .then(done, done.fail);
          });

        });

      });
    });

  });
});
