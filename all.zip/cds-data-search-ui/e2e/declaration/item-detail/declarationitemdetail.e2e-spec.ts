/// <reference path="../declarationMatchers.d.ts"/>

import { declarationMatchers } from '../declarationMatchers';
import { AppPage } from '../../app.po';
import { SignInScenario } from '../../sign-in/sign-in-scenario';
import { Wiremock } from '../../wiremock';
import { DeclarationSearchPage } from '../search/declarationsearch.po';
import { DeclarationItemDetailPage } from './declarationitemdetail.po';
import { DeclarationItemDetailScenario } from './declarationitemdetail-scenario';
import { DeclarationDetailScenario } from '../detail/declarationdetail-scenario';
import { NotFoundPage } from '../../not-found.po';
import { browser } from 'protractor';
import { DeclarationDetailPage } from '../detail/declarationdetail.po';
import { Footer } from '../../footer.po';
import { DataTable } from '../../datatable.po';

describe('Declaration Item Detail', () => {
  const detailPage: DeclarationItemDetailPage = new DeclarationItemDetailPage();
  const declarationDetailPage: DeclarationDetailPage = new DeclarationDetailPage();
  const footer = new Footer();
  const dataTable = new DataTable();

  beforeAll((done) => {
    new SignInScenario().givenUserIsSignedIn().then(done, done.fail);
  });

  describe('declaration item that exists', () => {

    let declarationItemDetail;
    const itemNumber = 2;

    beforeAll((done) => {
        declarationItemDetail = DeclarationItemDetailScenario.defaultDeclarationItemDetailResponse(itemNumber);
        jasmine.addMatchers(declarationMatchers);
        Wiremock.reset()
            .then(() => DeclarationItemDetailScenario.stubDeclarationItemDefinition())
            .then(() => DeclarationDetailScenario.stubDeclaration(DeclarationDetailScenario.TEST_ID))
            .then(() => detailPage.navigateTo(DeclarationDetailScenario.TEST_ID, itemNumber))
            .then(() => browser.driver.sleep(500))
            .then(done, done.fail);
    });

    it('should be the current page', () => {
        expect(detailPage.isCurrentPage()).toBeTruthy();
    });

    it('should display footer', () => {
      expect(footer.getVerison()).toContain('VERSION ');
    });

    it('updates the title in the browser', () => {
        expect(new AppPage().getCurrentTitle()).toEqual(`CDS - Item Detail`);
    });

    it('updates the url in the browser', () => {
        expect(new AppPage().getCurrentUrl()).toMatch(`\/declarations\/${DeclarationDetailScenario.TEST_ID}\/items\/${itemNumber}$`);
    });

    it('uses the correct declaration id', () => {
        expect(detailPage.getDeclarationId()).toEqual(DeclarationDetailScenario.TEST_ID);
    });

    it('displays the correct item tab', () => {
        expect(detailPage.getSelectedItemNumber()).toEqual(itemNumber.toString());
    });

    it('displays the correct declaration item values', () => {
        expect(detailPage.getDataGridElement()).isDeclarationItemWithData(declarationItemDetail);
    });

    it('displays the correct item count', () => {
        expect(detailPage.getItemResultsCount()).toEqual('4');
    });

    it('should focus on the search item filter field', () => {
        expect(detailPage.isItemFilterFieldFocused()).toBeTruthy();
    });


    describe('item associations', () => {
      const LABELS = ['Tax Lines', 'Routes', 'Additional Info', 'Previous Documents', 'Containers', 'Packages'];

      it('should be displayed', () => {
        expect(detailPage.isItemAssociationsExists()).toBeTruthy();
      });

      it('displays all the labels', (done) => {
        detailPage.getTabLabels().then(labels =>
          expect(labels).toEqual(LABELS)
        ).then(done, done.fail);
      });

      describe('tax lines', () => {
        beforeAll((done) => {
          detailPage.clickAssociationTab('taxLines')
                    .then(() => browser.waitForAngular())
                    .then(done, done.fail);
        });

        it('should display data', () => {
          expect(dataTable.isDataDisplayed()).toBeTruthy();
        });

        it('should display correct number of rows', () => {
          expect(dataTable.rowsDisplayed()).toEqual(2);
        });

        it('should display all the headers', () => {
          const HEADERS = ['Sequence Number', 'Tax Type Code', 'Tax Base (Amount)', 'Tax Base (Amount) Calculated',
                          'Tax Base (Quantity)', 'Tax Rate Identifier', 'Tax Override Code', 'Tax Amount',
                            'Tax Amount Calculated', 'Method Of Payment Code', 'Declared or Calculated'];

          expect(dataTable.getTableHeaders()).toEqual(HEADERS);
        });

        describe('should display all the', () => {
          it('sequence numbers', () => {
            expect(dataTable.getTableCellContent('taxLineSequenceNumber')).toEqual(['1', '2']);
          });

          it('tax type codes', () => {
            expect(dataTable.getTableCellContent('taxTypeCode')).toEqual(['code1', 'code2']);
          });

          it('tax base amount', () => {
            expect(dataTable.getTableCellContent('taxBaseAmount')).toEqual(['100', '90']);
          });

          it('tax base amount calculated', () => {
            expect(dataTable.getTableCellContent('taxBaseAmountCalculated')).toEqual(['112', '130']);
          });

          it('tax base quantity', () => {
            expect(dataTable.getTableCellContent('taxBaseQuantity')).toEqual(['11', '13']);
          });

          it('tax rate identifier', () => {
            expect(dataTable.getTableCellContent('taxRateIdentifier')).toEqual(['', '6']);
          });

          it('tax override code', () => {
            expect(dataTable.getTableCellContent('taxOverrideCode')).toEqual(['', '7']);
          });

          it('tax amount', () => {
            expect(dataTable.getTableCellContent('taxAmount')).toEqual(['130', '220']);
          });

          it('tax amount calculated', () => {
            expect(dataTable.getTableCellContent('taxAmountCalculated')).toEqual(['120', '12']);
          });

          it('payment codes', () => {
            expect(dataTable.getTableCellContent('methodOfPaymentCode')).toEqual(['debit', 'cash']);
          });

          it('tax amount indicators', () => {
            expect(dataTable.getTableCellContent('taxAmountIndicator')).toEqual(['Declared', 'Calculated']);
          });
        });

      });

      describe('routes', () => {
        beforeAll((done) => {
          detailPage.clickAssociationTab('routes')
                    .then(() => browser.waitForAngular())
                    .then(done, done.fail);
        });

        it('should display data', () => {
          expect(dataTable.isDataDisplayed()).toBeTruthy();
        });

        it('should display correct number of rows', () => {
          expect(dataTable.rowsDisplayed()).toEqual(1);
        });

        it('should display all the headers', () => {
          const HEADERS = ['Route Sequence Number', 'Route Country Code'];

          expect(dataTable.getTableHeaders()).toEqual(HEADERS);
        });

        describe('should display all the', () => {
          it('route sequence numbers', () => {
            expect(dataTable.getTableCellContent('routeSequenceNumber')).toEqual(['routeSequenceNumber']);
          });

          it('route country codes', () => {
            expect(dataTable.getTableCellContent('routeCountryCode')).toEqual(['routeCountryCode']);
          });
        });

      });

      describe('additional info', () => {
        beforeAll((done) => {
          detailPage.clickAssociationTab('additionalInfo')
                    .then(() => browser.waitForAngular())
                    .then(done, done.fail);
        });

        it('should display data', () => {
          expect(dataTable.isDataDisplayed()).toBeTruthy();
        });

        it('should display correct number of rows', () => {
          expect(dataTable.rowsDisplayed()).toEqual(1);
        });

        it('should display all the headers', () => {
          const HEADERS = ['AI Sequence Number', 'AI Statement', 'AI Statement Description'];

          expect(dataTable.getTableHeaders()).toEqual(HEADERS);
        });

        describe('should display all the', () => {
          it('AI sequence numbers', () => {
            expect(dataTable.getTableCellContent('additionalInfoSequenceNumber')).toEqual(['1']);
          });

          it('AI statements', () => {
            expect(dataTable.getTableCellContent('additionalInfoStatement')).toEqual(['AI Statement']);
          });

          it('AI statements', () => {
            expect(dataTable.getTableCellContent('additionalInfoStatementDescription')).toEqual(['statementDescription']);
          });
        });

      });

      describe('previous documents', () => {
        beforeAll((done) => {
          detailPage.clickAssociationTab('previousDocuments')
                    .then(() => browser.waitForAngular())
                    .then(done, done.fail);
        });

        it('should display data', () => {
          expect(dataTable.isDataDisplayed()).toBeTruthy();
        });

        it('should display correct number of rows', () => {
          expect(dataTable.rowsDisplayed()).toEqual(1);
        });

        it('should display all the headers', () => {
          const HEADERS = ['Previous Document Sequence Number', 'Previous Document Class'];

          expect(dataTable.getTableHeaders()).toEqual(HEADERS);
        });

        describe('should display all the', () => {
          it('sequence numbers', () => {
            expect(dataTable.getTableCellContent('previousDocumentSequenceNumber')).toEqual(['previousDocumentSequenceNumber']);
          });

          it('document class', () => {
            expect(dataTable.getTableCellContent('previousDocumentClass')).toEqual(['previousDocumentClass']);
          });

        });

      });

      describe('containers', () => {
        beforeAll((done) => {
          detailPage.clickAssociationTab('containers')
                    .then(() => browser.waitForAngular())
                    .then(done, done.fail);
        });

        it('should display data', () => {
          expect(dataTable.isDataDisplayed()).toBeTruthy();
        });

        it('should display correct number of rows', () => {
          expect(dataTable.rowsDisplayed()).toEqual(1);
        });

        it('should display all the headers', () => {
          const HEADERS = ['Container Sequence Number', 'Container Number'];

          expect(dataTable.getTableHeaders()).toEqual(HEADERS);
        });

        describe('should display all the', () => {
          it('sequence numbers', () => {
            expect(dataTable.getTableCellContent('containerSequenceNumber')).toEqual(['2']);
          });

          it('container numbers', () => {
            expect(dataTable.getTableCellContent('containerNumber')).toEqual(['containerId']);
          });

        });

      });

      describe('packages', () => {
        beforeAll((done) => {
          detailPage.clickAssociationTab('packages')
                    .then(() => browser.waitForAngular())
                    .then(done, done.fail);
        });

        it('should display data', () => {
          expect(dataTable.isDataDisplayed()).toBeTruthy();
        });

        it('should display correct number of rows', () => {
          expect(dataTable.rowsDisplayed()).toEqual(1);
        });

        it('should display all the headers', () => {
          const HEADERS = ['Package Sequence Number', 'Package Count', 'Package Kind', 'Package Marks'];

          expect(dataTable.getTableHeaders()).toEqual(HEADERS);
        });

        describe('should display all the', () => {
          it('sequence numbers', () => {
            expect(dataTable.getTableCellContent('packageSequenceNumber')).toEqual(['2']);
          });

          it('package counts', () => {
            expect(dataTable.getTableCellContent('packageCount')).toEqual(['package - count']);
          });

          it('different package kinds', () => {
            expect(dataTable.getTableCellContent('packageKind')).toEqual(['package - kind']);
          });

          it('package marks', () => {
            expect(dataTable.getTableCellContent('packageMarks')).toEqual(['package - marks']);
          });

        });

      });

    });

    describe('item switch widget', () => {

        it('should display all of the item numbers', () => {
            expect(detailPage.getItemTabNumbers()).toEqual(['1', '2', '3', '4']);
        });

        it('should select another item when clicked', (done) => {
            detailPage.clickItemTab(4)
                .then(() => expect(detailPage.getSelectedItemNumber()).toEqual('4'))
                .then(done, done.fail);
        });
    });

    describe('filter items', () => {
        it('should select another item when item number entered', (done) => {
            detailPage.filterBy('3')
                .then(() => expect(detailPage.getSelectedItemNumber()).toEqual('3'))
                .then(done, done.fail);
        });

        it('should display no results message when item does not exist', (done) => {
            detailPage.filterBy('99=')
                .then(() => expect(detailPage.hasNoResults()).toBe(true))
                .then(done, done.fail);
        });

        it('should only display results which match the term', (done) => {
          detailPage.filterBy('Ic')
            .then(() => expect(detailPage.getSelectedItemNumber()).toEqual('2'))
            .then(() => expect(detailPage.getItemTabNumbers()).toEqual(['2', '3', '4']))
            .then(done, done.fail);
        });

        // unable to get it to work!!!!
        xit('should display all tabs when invalid search removed', (done) => {
            detailPage.filterBy('')
                .then(() => expect(detailPage.getItemTabNumbers()).toEqual(['1', '2', '3', '4']))
                .then(done, done.fail);
        });
    });

    describe('breadcrumbs', () => {

      beforeEach((done) => {
        browser.sleep(500).then(done, done.fail);
      });

      it('declaration detail breadcrumb is visible', () => {
        expect(detailPage.declarationDetailBreadcrumbIsPresent()).toBeTruthy();
      });

      it('item detail breadcrumb is visible', () => {
        expect(detailPage.itemDetailBreadcrumbIsPresent()).toBeTruthy();
      });

      it('click on declaration detail breadcrumb navigates to declaration details page', (done) => {
        detailPage.clickDeclarationDetailBreadcrumb()
          .then(() => expect(new DeclarationDetailPage().isCurrentPage()).toBe(true))
          .then(done, done.fail);
      });

      it('check the url in the browser', () => {
        expect(new AppPage().getCurrentUrl()).toMatch(`\/declarations\/${DeclarationDetailScenario.TEST_ID}$`);
      });

      it('click to item detail page', (done) => {
        declarationDetailPage.clickItemDetailButton()
          .then(() => expect(new DeclarationItemDetailPage().isCurrentPage()).toBe(true))
          .then(done, done.fail);
      });

      it('check the url in the browser', () => {
        expect(new AppPage().getCurrentUrl()).toMatch(`\/declarations\/${DeclarationDetailScenario.TEST_ID}\/items\/1$`);
      });

      it('click on search results breadcrumb navigates back to search', (done) => {
        detailPage.clickSearchResultsBreadcrumb()
          .then(() => expect(new DeclarationSearchPage().isCurrentPage()).toBe(true))
          .then(done, done.fail);
      });
    });
  });

  describe('non-existent declaration item', () => {
    const notFoundPage = new NotFoundPage();
    const itemNumber = 5;

    beforeAll((done) => {
        Wiremock.reset()
            .then(() => DeclarationDetailScenario.stubDeclarationWithoutLines())
            .then(() => detailPage.navigateTo(DeclarationDetailScenario.WITHOUT_LINES_ID, itemNumber))
            .then(done, done.fail);
    });

    it('should display the not found page', () => {
      expect(notFoundPage.isDisplayed()).toBeTruthy();
    });

    it('should not change the declaration item page url', () => {
      expect(notFoundPage.getCurrentUrl()).toMatch(`\/declarations\/${DeclarationDetailScenario.WITHOUT_LINES_ID}\/items\/${itemNumber}$`);
    });
  });

  describe('declaration not found', () => {
    const notFoundPage = new NotFoundPage();
    let declarationUrl;

    beforeAll((done) => {
      declarationUrl = DeclarationDetailScenario.declarationUrl('dec-id');

      Wiremock.reset()
        .then(() => Wiremock.givenNotFound(declarationUrl))
        .then(() => detailPage.navigateTo('dec-id', 1))
        .then(done, done.fail);
    });

    it('should display the not found page', () => {
      expect(notFoundPage.isDisplayed()).toBeTruthy();
    });

    it('should not change the declaration item page url', () => {
      expect(notFoundPage.getCurrentUrl()).toMatch(`${declarationUrl}/items/1$`);
    });
  });
});
