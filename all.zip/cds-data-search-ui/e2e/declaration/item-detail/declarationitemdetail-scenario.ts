import { Wiremock } from '../../wiremock';

const fs = require('fs');

export class DeclarationItemDetailScenario {
  private static DECLARATION_ITEM_DEFINITION_FILE_NAME = 'declaration-items-definition.json';
  private static DECLARATION_FILE_NAME = 'declaration-with-lines.json';

  static stubDeclarationItemDefinition() {
    return Wiremock.stubRequest({
      'priority': 1,
      'request': {
        'method': 'GET',
        'url': '/declarations/items/definition'
      },
      'response': {
        'status': 200,
        'bodyFileName': this.DECLARATION_ITEM_DEFINITION_FILE_NAME
      }
    });
  }

  static defaultDeclarationItemDetailResponse(itemNumber: number) {
    return JSON.parse(fs.readFileSync(`e2e/wiremock/__files/${this.DECLARATION_FILE_NAME}`)).lines
        .find(line => line.itemNumber === itemNumber);
  }
}
