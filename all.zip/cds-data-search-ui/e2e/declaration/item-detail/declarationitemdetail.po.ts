import { browser, by, element } from 'protractor';
import { DataGridElement } from '../DataGridElement';

export class DeclarationItemDetailPage {

  navigateTo(id, itemNumber) {
    return browser.get(`/declarations/${id}/items/${itemNumber}`).then(() => browser.waitForAngular());
  }

  isCurrentPage() {
    return element(by.css('.declaration-item-detail')).isPresent();
  }

  getDeclarationId() {
    return element(by.css('.declaration-item-detail__declarations')).getAttribute('data-declaration-id');
  }

  clickSearchResultsBreadcrumb() {
    return element(by.css('.breadcrumb-container__breadcrumb-link[data-breadcrumb="searchresults"]')).click();
  }

  clickDeclarationDetailBreadcrumb() {
    return element(by.css('.breadcrumb-container__breadcrumb-link[data-breadcrumb="declarationdetail"]')).click();
  }

  itemDetailBreadcrumbIsPresent() {
    return browser.sleep(1000).then(() =>
      element(by.css('.breadcrumb-container__breadcrumb-link[data-breadcrumb="itemdetail"]')).isPresent()
    );
  }

  declarationDetailBreadcrumbIsPresent() {
    return browser.sleep(1000).then(() =>
      element(by.css('.breadcrumb-container__breadcrumb-link[data-breadcrumb="declarationdetail"]')).isPresent()
    );
  }

  isItemAssociationsExists() {
    return element(by.css('.declaration-item-detail__association')).isPresent();
  }

  getSelectedItemNumber() {
    return element(by.css('.declaration-item-detail__declarations')).getAttribute('data-declaration-item-number');
  }

  getItemResultsCount() {
    return element(by.css('.declaration-item-detail__results-count')).getText();
  }

  getItemTabNumbers() {
    return element.all(by.css('.declaration-item-detail__tab-label')).map(e => e.getText());
  }

  getCurrentActiveItemTab() {
      return element(by.css('.mat-tab-label-active'));
  }

  // Sleep after click due to waiting for tab animation
  clickItemTab(number) {
    return element(by.css(`.declaration-item-detail__tab-label[data-declaration-item-number="${number}"]`)).click()
      .then(() => browser.waitForAngular())
      .then(() => browser.driver.sleep(500));
  }

  filterBy(text) {
    const filterInput = element(by.css('.declaration-item-detail__item-filter-input'));
    return filterInput.clear().then(() => filterInput.sendKeys(text)).then(() => browser.driver.sleep(500));
  }

  hasNoResults() {
    return element(by.css('.declaration-item-detail__no-results-message')).isPresent();
  }

  getDataGridElement(): DataGridElement {
    return new DataGridElement(element(by.css('.declaration-item-detail__declarations')));
  }

  isItemFilterFieldFocused() {
    return browser.driver.switchTo().activeElement().getAttribute('class').then((fieldname) =>
      fieldname.startsWith('declaration-item-detail__item-filter-input')
    );
  }

  getCurrentUrl() {
    return browser.getCurrentUrl();
  }

  getTabLabels() {
    return element.all(by.css('.declaration-item-detail__association__tab-label')).getText();
  }

  clickAssociationTab(id) {
    return element(by.css(`.declaration-item-detail__association__tab-label[association-id="${id}"]`)).click()
    .then(() => browser.waitForAngular())
    .then(() => browser.driver.sleep(500));
  }

}
