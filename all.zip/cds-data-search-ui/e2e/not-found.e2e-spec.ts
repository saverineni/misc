import { AppPage } from './app.po';
import { NotFoundPage } from './not-found.po';
import { SignInPage } from './sign-in/sign-in.po';
import { browser } from 'protractor';
import { SignInScenario } from './sign-in/sign-in-scenario';

describe('Not Found', () => {
  let appPage: AppPage;
  let signInPage: SignInPage;
  let page: NotFoundPage;

  beforeAll(() => {
    appPage = new AppPage();
    page = new NotFoundPage();
  });

  describe('signed-in', () => {
    beforeAll((done) => {
      signInPage = new SignInPage();
      new SignInScenario().givenUserIsSignedIn()
        .then(() => browser.get('/unknown-page'))
        .then(done, done.fail);
    });

    it('updates the title in the browser', () => {
      expect(new AppPage().getCurrentTitle()).toEqual(`CDS - 404 Page Not Found`);
    });

    it('should display the not found page when page is not recognised', () => {
      expect(appPage.componentHeading()).toEqual('404 the requested URL was not found');
    });

    it('should not change the url', () => {
      expect(page.getCurrentUrl()).toMatch(/.*\/unknown-page$/);
    });
  });

  describe('not signed in', () => {
    beforeAll((done) =>
      new SignInScenario().givenUserIsNotSignedIn()
        .then(() => browser.get('/unknown-page'))
        .then(done, done.fail)
    );

    it('should take you to the sign-in page', () => {
      expect(signInPage.isCurrentPage()).toEqual(true);
    });
  });
});
