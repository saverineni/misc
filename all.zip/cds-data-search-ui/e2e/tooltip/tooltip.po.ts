import {browser, by, element} from 'protractor';

export class ToolTip {

  toolTipCssEORI = '.search-filter__eori  cds-tooltip .tooltip .tooltip__icon';

  getTooltipColour() {
    return element(by.css(this.toolTipCssEORI)).getCssValue('color').then(value => value);
  }

  hoverEORIToolTipIcon() {
    return browser.actions().mouseMove(element(by.css(this.toolTipCssEORI))).perform();
  }

}
