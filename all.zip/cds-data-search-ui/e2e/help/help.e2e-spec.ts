import {NavigationBar} from '../navigation-bar.po';
import {SignInScenario} from '../sign-in/sign-in-scenario';
import {HelpPage} from './help.po';

describe('Help page', () => {
  const helpPage: HelpPage = new HelpPage();
  const navigationBar: NavigationBar = new NavigationBar();

  beforeAll((done) => {
    new SignInScenario().givenUserIsSignedIn()
      .then(done, done.fail);
  });

  describe('help', () => {
    beforeEach((done) => {
      navigationBar.help().then(done, done);
    });

    it('should display FAQs', () => {
      helpPage.clickFaqs();
      expect(helpPage.faqsContentFound()).toBe(true);
    });

    it('should display pdfs and links', () => {
      helpPage.clickPdfsAndLinks();
      expect(helpPage.pdfsAndLinksContentFound()).toBe(true);
    });

    it('should display more help', () => {
      expect(helpPage.moreHelpContentFound()).toBe(true);
    });
  });
});
