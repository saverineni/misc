import {by, element} from 'protractor';

export class HelpPage {

  isCurrentPage() {
    return element(by.css('.help-content')).isPresent();
  }

  clickFaqs() {
    return element(by.css('.help-tab__label[data-help-type="faqs"]')).click();
  }

  faqsContentFound() {
    return element(by.css('.help-tab__label[data-help-type="faqs"]')).isPresent();
  }

  clickPdfsAndLinks() {
    return element(by.css('.help-tab__label[data-help-type="pdfs-links"]')).click();
  }

  pdfsAndLinksContentFound() {
    return element(by.css('.help-tab__label[data-help-type="pdfs-links"]')).isPresent();
  }

  moreHelpContentFound() {
    return element(by.css('.help-content__more-help-text')).isPresent();
  }

}
