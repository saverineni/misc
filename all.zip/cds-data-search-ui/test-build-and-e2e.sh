#!/bin/bash

set -e

./angular-cli.sh 'ng lint'
./angular-cli.sh 'ng test --single-run true --code-coverage'
./angular-cli.sh 'ng build -prod --skip-app-shell true --aot true --build-optimizer true'

docker build --build-arg VERSION=dev --build-arg IMAGE_NAME=local/build -t cdsdar/customs-search-ui .

./run-e2e-tests.sh
