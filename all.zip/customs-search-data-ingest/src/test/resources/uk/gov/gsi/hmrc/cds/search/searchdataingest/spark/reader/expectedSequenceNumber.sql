SELECT 
    column_one as ONE,
    column_two as TWO,
    column_three as THREE,
FROM db_name.TABLE_NAME
WHERE ids IN ("1","2")