CREATE TABLE IF NOT EXISTS DATABASE_NAME.iipk(
	iekey DECIMAL(38,0),
	ieitno INT,
	clrncdate VARCHAR(19),
	pkgcount INT,
	pkgkind VARCHAR(2),
	pkgmarks VARCHAR(42),
	pkgmarkslng VARCHAR(2),
	iipkdataseqno INT,
	da_iv_id VARCHAR(30),
	cdap_file_date VARCHAR(8),
	standard_cdap_file_date VARCHAR(29),
	cdap_base_sequence_number INT,
	standard_cdap_load_date VARCHAR(29),
	cdap_health_warning VARCHAR(30),
	cdap_purge_date VARCHAR(30),
	standard_clrncdate VARCHAR(29),
	source_iekey DECIMAL(38,0),
	cdap_source VARCHAR(5),
	cdap_consol_load_date VARCHAR(29),
	cdap_consol_sequence_number INT)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
