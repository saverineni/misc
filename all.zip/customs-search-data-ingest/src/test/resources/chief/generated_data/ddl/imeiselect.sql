CREATE TABLE IF NOT EXISTS DATABASE_NAME.imeiselect(
  iekey DECIMAL(38,0),
  ieitno BIGINT,
  clrncdate VARCHAR(19),
  cmdtycode VARCHAR(11),
  cpc VARCHAR(7),
  origcntry VARCHAR(2),
  tariffchap VARCHAR(2),
  itemimptrturncc VARCHAR(2),
  itemimptrturn VARCHAR(16),
  itemcnsgrturncc VARCHAR(2),
  itemcnsgrturn VARCHAR(16),
  itemdispcntry VARCHAR(2),
  da_iv_id VARCHAR(30),
  cdap_file_date VARCHAR(8),
  standard_cdap_file_date VARCHAR(29),
  cdap_base_sequence_number INT,
  standard_cdap_load_date VARCHAR(29),
  cdap_health_warning VARCHAR(30),
  cdap_purge_date VARCHAR(30),
  standard_clrncdate VARCHAR(29),
  source_iekey DECIMAL(38,0),
  cdap_source VARCHAR(5),
  cdap_consol_load_date VARCHAR(29),
  cdap_consol_sequence_number INT)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
