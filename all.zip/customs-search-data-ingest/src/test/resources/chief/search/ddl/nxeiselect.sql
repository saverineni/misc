CREATE TABLE search.nxeiselect(
  iekey string,
  ieitno int,
  generationno int,
  itemdestcntry string,
  cpc string,
  origcntry string,
  cmdtycode string,
  itemimptrturn string,
  itemcnsgrturn string,
  standard_dtofent string,
  itemnetmass string,
  itemsuppunits string,
  itemstatvaldc string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
