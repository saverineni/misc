CREATE TABLE IF NOT EXISTS search.nxirt(
	iekey string,
	ieitno int,
	generationno int,
	nxirtdataseqno int,
	itemroutecntry string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
