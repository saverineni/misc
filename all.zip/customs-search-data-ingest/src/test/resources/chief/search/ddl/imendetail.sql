CREATE TABLE IF NOT EXISTS search.imendetail(
  iekey string,
  gdslocn string,
  trptmodecode string,
  totpkgs string,
  invtotac string,
  trptmodeinld string,
  plaldgcode string,
  trptid string,
  invcrrn string,
  ocdcrrn string,
  declncrrn string,
  entgrsmass string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
