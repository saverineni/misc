CREATE TABLE IF NOT EXISTS search.nxendetail(
  iekey string,
  generationno int,
  trptmodecode string,
  totpkgs string,
  decltrep string,
  invtotac string,
  trptmodeinld string,
  trptid string,
  entgrsmass string,
  invcrrn string,
  ocdcrrn string,
  declncrrn string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
