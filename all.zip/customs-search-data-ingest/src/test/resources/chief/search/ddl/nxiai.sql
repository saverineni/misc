CREATE TABLE IF NOT EXISTS search.nxiai(
	iekey string,
	ieitno int,
	generationno int,
	aistmtsno int,
	itemaistmt string,
	itemaistmttxt string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
