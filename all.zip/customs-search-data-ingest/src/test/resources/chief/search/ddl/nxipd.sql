CREATE TABLE IF NOT EXISTS search.nxipd(
	iekey string,
	ieitno int,
	generationno int,
	nxipddataseqno int,
	prevdocclass string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
