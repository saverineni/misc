CREATE TABLE IF NOT EXISTS search.nxict(
	iekey string,
	ieitno int,
	generationno int,
	nxictdataseqno int,
	cntrno string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
