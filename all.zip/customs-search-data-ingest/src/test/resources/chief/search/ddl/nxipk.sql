CREATE TABLE IF NOT EXISTS search.nxipk(
	iekey string,
	ieitno int,
	generationno int,
	nxipkdataseqno int,
	pkgcount string,
	pkgkind string,
	pkgmarks string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
