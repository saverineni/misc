CREATE TABLE IF NOT EXISTS search.iipk(
	iekey  string,
	ieitno  int,
	iipkdataseqno int,
	pkgcount  string,
	pkgkind  string,
	pkgmarks  string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
