CREATE TABLE IF NOT EXISTS search.iict(
  iekey string,
  ieitno int,
  iictdataseqno int,
  cntrno string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','