CREATE TABLE IF NOT EXISTS search.iipd(
  iekey string,
  ieitno int,
  iipddataseqno int,
  prevdocclass string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
