CREATE TABLE search.inad(
  iekey string,
  hdrnadtype string,
  hdrnadname string,
  hdrnadpostcode string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
