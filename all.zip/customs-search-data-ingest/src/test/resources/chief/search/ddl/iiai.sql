 CREATE TABLE IF NOT EXISTS search.iiai(
  iekey string,
  ieitno int,
  aistmtsno int,
  itemaistmt string,
  itemaistmttxt string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','