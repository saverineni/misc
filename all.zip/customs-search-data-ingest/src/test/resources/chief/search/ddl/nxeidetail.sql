CREATE TABLE search.nxeidetail(
  iekey string,
  ieitno int,
  generationno int,
  itemdispcntry string,
  gdsdesc string,
  itemgrsmass string,
  preference string,
  qtano string,
  itemprcac string,
  valmthdcode string,
  valadjtcode string,
  itemvaladjt string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
