  CREATE TABLE IF NOT EXISTS search.iitl(
  iekey string,
  ieitno int,
  itlnsno int,
  ttycode string,
  itlnbaseamtdc string,
  itlnbaseqty string,
  taxrateid string,
  ttyovrcode string,
  itlndecltaxdc string,
  mopcode string,
  itlnbaseamt string,
  taxamt string,
  deccalind string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
