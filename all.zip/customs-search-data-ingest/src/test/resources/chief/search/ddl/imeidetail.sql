CREATE TABLE search.imeidetail(
  iekey string,
  ieitno int,
  gdsdesc string,
  itemgrsmass string,
  preference string,
  itemnetmass string,
  qtano string,
  itemsuppunits string,
  itemprcac string,
  valmthdcode string,
  valadjtcode string,
  itemvaladjt string,
  itemstatvaldc string,
  itemcstmsval string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
