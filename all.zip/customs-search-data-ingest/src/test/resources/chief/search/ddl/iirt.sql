CREATE TABLE IF NOT EXISTS search.iirt(
	iekey string,
	ieitno int,
	iirtdataseqno int,
	itemroutecntry string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
