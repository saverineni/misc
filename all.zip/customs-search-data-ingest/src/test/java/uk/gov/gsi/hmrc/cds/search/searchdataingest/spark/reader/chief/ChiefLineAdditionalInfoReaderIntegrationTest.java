package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.chief;

import org.apache.spark.sql.Dataset;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLineAdditionalInfo;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLineAdditionalInfoReader;

import static org.apache.spark.sql.functions.column;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class ChiefLineAdditionalInfoReaderIntegrationTest extends SparkTest {

    @Autowired
    private DeclarationLineAdditionalInfoReader declarationLineReader;

    private static final String IMPORT_HEADER_ID = "IM002";
    private static final int IMPORT_ITEM_NO = 2;
    private static final int IMPORT_ADDITIONAL_INFO_SEQ_NO = 1;

    private static final String EXPORT_HEADER_ID = "EX002";
    private static final int EXPORT_ITEM_NO = 2;
    private static final int EXPORT_ADDITIONAL_INFO_SEQ_NO = 2;

    private Dataset<DeclarationLineAdditionalInfo> lineAdditionalInfoDataset;

    @Before
    public void setUp() {
        lineAdditionalInfoDataset = declarationLineReader.declarationLineAdditionalInfoDataset();
    }

    @Test
    public void loadingLines() {
        assertThat(lineAdditionalInfoDataset.count(), is(equalTo(10L)));
    }

    @Test
    public void mappingImportLine() {
        DeclarationLineAdditionalInfo lineAdditionalInfo = getLineAdditionalInfo(IMPORT_HEADER_ID, IMPORT_ITEM_NO, IMPORT_ADDITIONAL_INFO_SEQ_NO);
        assertThat(lineAdditionalInfo.getJoinId(), is(equalTo(IMPORT_HEADER_ID)));
        assertThat(lineAdditionalInfo.getSequenceId(), is(equalTo("1")));
        assertThat(lineAdditionalInfo.getItemNumber(), is(IMPORT_ITEM_NO));
        assertThat(lineAdditionalInfo.getAdditionalInfoSequenceNumber(), is(IMPORT_ADDITIONAL_INFO_SEQ_NO));
        assertThat(lineAdditionalInfo.getAdditionalInfoStatement(), is("IM002-21AISTMT"));
        assertThat(lineAdditionalInfo.getAdditionalInfoStatementDescription(), is("IM002-21STMTDESC"));
    }

    @Test
    public void mappingExportLine() {
        DeclarationLineAdditionalInfo lineAdditionalInfo = getLineAdditionalInfo(EXPORT_HEADER_ID, EXPORT_ITEM_NO, EXPORT_ADDITIONAL_INFO_SEQ_NO);
        assertThat(lineAdditionalInfo.getJoinId(), is(equalTo(EXPORT_HEADER_ID)));
        assertThat(lineAdditionalInfo.getSequenceId(), is(equalTo("1")));
        assertThat(lineAdditionalInfo.getItemNumber(), is(EXPORT_ITEM_NO));
        assertThat(lineAdditionalInfo.getAdditionalInfoSequenceNumber(), is(EXPORT_ADDITIONAL_INFO_SEQ_NO));
        assertThat(lineAdditionalInfo.getAdditionalInfoStatement(), is("EX002-22AISTMT"));
        assertThat(lineAdditionalInfo.getAdditionalInfoStatementDescription(), is("EX002-22STMTDESC"));
    }

//    @Test
//    public void getAllAdditionalInfoForLine() {
//
//    }

    private DeclarationLineAdditionalInfo getLineAdditionalInfo(String id, int itemNo, int aiSequenceNumber) {
        Dataset<DeclarationLineAdditionalInfo> filter = lineAdditionalInfoDataset
                .where(column("joinId").isNotNull()
                        .and(column("itemNumber").isNotNull())
                        .and(column("additionalInfoSequenceNumber").isNotNull())
                )
                .filter((DeclarationLineAdditionalInfo l) -> l.getJoinId().equals(id) &&
                                                            l.getItemNumber() == itemNo &&
                                                            l.getAdditionalInfoSequenceNumber() == aiSequenceNumber
                );
        assertThat(filter.count(), is(1L));
        return filter.first();
    }
}
