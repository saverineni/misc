package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.chief;

import org.apache.spark.sql.Dataset;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLineAdditionalInfo;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLineContainer;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLineContainerReader;

import static org.apache.spark.sql.functions.column;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class ChiefLineContainerReaderIntegrationTest extends SparkTest {

    @Autowired
    private DeclarationLineContainerReader lineContainerReader;

    private static final String IMPORT_HEADER_ID = "IM002";
    private static final int IMPORT_ITEM_NO = 2;
    private static final int IMPORT_CONTAINER_SEQ_NO = 1;

    private static final String EXPORT_HEADER_ID = "EX002";
    private static final int EXPORT_ITEM_NO = 2;
    private static final int EXPORT_CONTAINER_SEQ_NO = 2;

    private Dataset<DeclarationLineContainer> lineContainerDataset;

    @Before
    public void setUp() {
        lineContainerDataset = lineContainerReader.declarationLineContainerDataset();
    }

    @Test
    public void loadingLines() {
        assertThat(lineContainerDataset.count(), is(equalTo(10L)));
    }

    @Test
    public void mappingImportLine() {
        DeclarationLineContainer lineContainer = getLineContainer(IMPORT_HEADER_ID, IMPORT_ITEM_NO, IMPORT_CONTAINER_SEQ_NO);
        assertThat(lineContainer.getJoinId(), is(equalTo(IMPORT_HEADER_ID)));
        assertThat(lineContainer.getSequenceId(), is(equalTo("1")));
        assertThat(lineContainer.getItemNumber(), is(IMPORT_ITEM_NO));
        assertThat(lineContainer.getContainerSequenceNumber(), is(IMPORT_CONTAINER_SEQ_NO));
        assertThat(lineContainer.getContainerNumber(), is("IM002-21CONTAINER"));
    }

    @Test
    public void mappingExportLine() {
        DeclarationLineContainer lineContainer = getLineContainer(EXPORT_HEADER_ID, EXPORT_ITEM_NO, EXPORT_CONTAINER_SEQ_NO);
        assertThat(lineContainer.getJoinId(), is(equalTo(EXPORT_HEADER_ID)));
        assertThat(lineContainer.getSequenceId(), is(equalTo("1")));
        assertThat(lineContainer.getItemNumber(), is(EXPORT_ITEM_NO));
        assertThat(lineContainer.getContainerSequenceNumber(), is(EXPORT_CONTAINER_SEQ_NO));
        assertThat(lineContainer.getContainerNumber(), is("EX002-22CONTAINER"));
    }

//    @Test
//    public void getAllContainersForLine() {
//
//    }

    private DeclarationLineContainer getLineContainer(String id, int itemNo, int containerSequenceNumber) {
        Dataset<DeclarationLineContainer> filter = lineContainerDataset
                .where(column("joinId").isNotNull()
                        .and(column("itemNumber").isNotNull())
                        .and(column("containerSequenceNumber").isNotNull())
                )
                .filter((DeclarationLineContainer l) -> l.getJoinId().equals(id) &&
                                                            l.getItemNumber() == itemNo &&
                                                            l.getContainerSequenceNumber() == containerSequenceNumber
                );
        assertThat(filter.count(), is(1L));
        return filter.first();
    }
}
