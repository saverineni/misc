package uk.gov.gsi.hmrc.cds.search.searchdataingest.metric;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class IngestionCountReaderIntegrationTest extends SparkTest {

    @Autowired
    IngestionCountReader ingestionCountReader;


    @Test
    public void getImportCountDataset() throws Exception {
        final Dataset<Long> importCountDataset = ingestionCountReader.getImportCountDataset();
        Long importDeclarationCount = importCountDataset.select("importDeclarationCount").as(Encoders.LONG()).first();
        assertThat(importDeclarationCount, is(equalTo(3l)));
    }

    @Test
    public void getExportCountDataset() throws Exception {
        final Dataset<Long> exportCountDataset = ingestionCountReader.getExportCountDataset();
        Long exportDeclarationCount = exportCountDataset.select("exportDeclarationCount").as(Encoders.LONG()).first();
        assertThat(exportDeclarationCount, is(equalTo(3l)));
    }

    @Test
    public void getExportCountAllDataset() throws Exception {
        final Dataset<Long> exportCountAllDataset = ingestionCountReader.getExportCountAllDataset();
        Long exportDeclarationAllCount = exportCountAllDataset.select("exportDeclarationAllCount").as(Encoders.LONG()).first();
        assertThat(exportDeclarationAllCount, is(equalTo(3l)));
    }
}