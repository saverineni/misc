package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.chief;

import org.apache.spark.sql.Dataset;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLinePreviousDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLinePreviousDocumentReader;

import static org.apache.spark.sql.functions.column;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class ChiefLinePreviousDocumentReaderIntegrationTest extends SparkTest {

    @Autowired
    private DeclarationLinePreviousDocumentReader linePreviousDocumentReader;

    private static final String IMPORT_HEADER_ID = "IM002";
    private static final int IMPORT_ITEM_NO = 1;
    private static final int IMPORT_PREVDOC_SEQ_NO = 1;

    private static final String EXPORT_HEADER_ID = "EX002";
    private static final int EXPORT_ITEM_NO = 3;
    private static final int EXPORT_PREVDOC_SEQ_NO = 1;

    private Dataset<DeclarationLinePreviousDocument> linePreviousDocumentDataset;

    @Before
    public void setUp() {
        linePreviousDocumentDataset = linePreviousDocumentReader.declarationLinePreviousDocumentDataset();
    }

    @Test
    public void loadingLines() {
        assertThat(linePreviousDocumentDataset.count(), is(equalTo(8L)));
    }

    @Test
    public void mappingImportLine() {
        DeclarationLinePreviousDocument linePreviousDocument = getLinePreviousDocument(IMPORT_HEADER_ID, IMPORT_ITEM_NO, IMPORT_PREVDOC_SEQ_NO);
        assertThat(linePreviousDocument.getJoinId(), is(equalTo(IMPORT_HEADER_ID)));
        assertThat(linePreviousDocument.getSequenceId(), is(equalTo("1")));
        assertThat(linePreviousDocument.getItemNumber(), is(IMPORT_ITEM_NO));
        assertThat(linePreviousDocument.getPreviousDocumentSequenceNumber(), is(IMPORT_PREVDOC_SEQ_NO));
        assertThat(linePreviousDocument.getPreviousDocumentClass(), is("IM002-11PREVDOC"));
    }

    @Test
    public void mappingExportLine() {
        DeclarationLinePreviousDocument linePreviousDocument = getLinePreviousDocument(EXPORT_HEADER_ID, EXPORT_ITEM_NO, EXPORT_PREVDOC_SEQ_NO);
        assertThat(linePreviousDocument.getJoinId(), is(equalTo(EXPORT_HEADER_ID)));
        assertThat(linePreviousDocument.getSequenceId(), is(equalTo("1")));
        assertThat(linePreviousDocument.getItemNumber(), is(EXPORT_ITEM_NO));
        assertThat(linePreviousDocument.getPreviousDocumentSequenceNumber(), is(EXPORT_PREVDOC_SEQ_NO));
        assertThat(linePreviousDocument.getPreviousDocumentClass(), is("EX002-31PREVDOC"));
    }

//    @Test
//    public void getAllPreviousDocumentForLine() {
//
//    }

    private DeclarationLinePreviousDocument getLinePreviousDocument(String id, int itemNo, int previousDocumentSequenceNumber) {
        Dataset<DeclarationLinePreviousDocument> filter = linePreviousDocumentDataset
                .where(column("joinId").isNotNull()
                        .and(column("itemNumber").isNotNull())
                        .and(column("previousDocumentSequenceNumber").isNotNull())
                )
                .filter((DeclarationLinePreviousDocument l) -> l.getJoinId().equals(id) &&
                                                            l.getItemNumber() == itemNo &&
                                                            l.getPreviousDocumentSequenceNumber() == previousDocumentSequenceNumber
                );
        assertThat(filter.count(), is(1L));
        return filter.first();
    }
}
