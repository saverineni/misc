package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.chief;

import org.apache.spark.sql.Dataset;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationHeader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationHeaderReader;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

public class ChiefHeaderReaderIntegrationTest extends SparkTest {

    @Autowired
    private DeclarationHeaderReader declarationHeaderReader;

    private static final String IMPORT_HEADER_ID_IM001 = "IM001";
    private static final String IMPORT_HEADER_ID_IM003 = "IM003";
    private static final String EXPORT_HEADER_ID_EX002 = "EX002";
    private static final String EXPORT_HEADER_ID_EX003 = "EX003";

    private Dataset<DeclarationHeader> declarationHeaderDataset;

    @Before
    public void setUp() {
        declarationHeaderDataset = declarationHeaderReader.declarationHeaderDataset();
    }

    @Test
    public void loadingHeaders() {
        assertThat(declarationHeaderDataset.count(), is(6L));
    }

    @Test
    public void mappingImportHeader() {
        DeclarationHeader header = getHeader(IMPORT_HEADER_ID_IM001);
        assertThat(header.getJoinId(), is(equalTo(IMPORT_HEADER_ID_IM001)));
        assertThat(header.getDeclarationId(), is(equalTo(IMPORT_HEADER_ID_IM001)));
        assertThat(header.getDeclarationSource(), is(equalTo("CHIEF")));
        assertThat(header.getImportExportIndicator(), is(equalTo("Import")));
        assertThat(header.getSequenceId(), is(equalTo("1")));
        assertThat(header.getEpuNumber(), is("EPU01"));
        assertThat(header.getEntryNumber(), is("ENTRY001"));
        assertThat(header.getEntryDate(), is("2018-01-01 00:00:00.00"));
        assertThat(header.getRoute(), is("ROE01"));
        assertThat(header.getConsignee().getEori(), is(equalTo("CONSIGNEE01")));
        assertThat(header.getConsignee().getName(), is(equalTo("CONSIGNEENAME01")));
        assertThat(header.getConsignee().getPostcode(), is(equalTo("CONSIGNEEPOSTCODE01")));
        assertThat(header.getConsignor().getEori(), is(equalTo("CONSIGNOR01")));
        assertThat(header.getConsignor().getName(), is(equalTo("CONSIGNORNAME01")));
        assertThat(header.getConsignor().getPostcode(), is(equalTo("CONSIGNORPOSTCODE01")));
        assertThat(header.getDeclarant().getEori(), is(equalTo("DECLARANT01")));
        assertThat(header.getDeclarant().getName(), is(equalTo("DECLARANTNAME01")));
        assertThat(header.getDeclarant().getPostcode(), is(equalTo("DECLARANTPOSTCODE01")));
        assertThat(header.getDispatchCountry().getCode(), is("COUNTRY01"));
        assertThat(header.getDestinationCountry(), is(nullValue()));
        assertThat(header.getGoodsLocation(), is("GOODSLOC01"));
        assertThat(header.getTransportModeCode(), is("TRANSPORTMODE01"));
        assertThat(header.getTotalPackages(), is("TOTALPACKAGES01"));
        assertThat(header.getInvoiceCurrency(), is("INVOICECURRRENCY01"));
        assertThat(header.getInvoiceTotal(), is("INVOICETOTAL01"));
        assertThat(header.getInlandTransportMode(), is("INLANDTRANSMODE01"));
        assertThat(header.getProcessingStatus(), is(nullValue()));
        assertThat(header.getPlaceOfLoading(), is("PLACEOFLOADING01"));
        assertThat(header.getDeclarationType(), is("IMX"));
        assertThat(header.getDeclarantRepresentation(), is("DECLARANTREP01"));
        assertThat(header.getTransportId(), is("TRANSPORTID01"));
        assertThat(header.getAcceptanceDate(), is("2018-01-01 00:00:00.00"));
        assertThat(header.getPremisesId(), is("PREMISEID01"));
        assertThat(header.getTotalDuty(), is("TOTALDUTY01"));
        assertThat(header.getGrossMass(), is("GROSSMASS01"));
        assertThat(header.getDeclarationCurrency(), is("DECLARATIONCURRENCY01"));
    }

    @Test
    public void mappingImportHeaderForNullDecType() {
        DeclarationHeader header = getHeader(IMPORT_HEADER_ID_IM003);
        assertThat(header.getDeclarationType(), is(nullValue()));
    }

    @Test
    public void mappingExportHeader() {
        DeclarationHeader header = getHeader(EXPORT_HEADER_ID_EX002);
        assertThat(header.getDeclarationSource(), is(equalTo("CHIEF")));
        assertThat(header.getImportExportIndicator(), is(equalTo("Export")));
        assertThat(header.getDeclarationId(), is(equalTo(EXPORT_HEADER_ID_EX002)));
        assertThat(header.getSequenceId(), is(equalTo("1")));
        assertThat(header.getEpuNumber(), is("EPU02"));
        assertThat(header.getEntryNumber(), is("ENTRY002"));
        assertThat(header.getEntryDate(), is("2018-01-02 00:00:00.00"));
        assertThat(header.getGoodsLocation(), is("GOODSLOC02"));
        assertThat(header.getRoute(), is("ROE02"));
        assertThat(header.getConsignee().getEori(), is(equalTo("CONSIGNEE02")));
        assertThat(header.getConsignee().getName(), is(equalTo("CONSIGNEENAME02")));
        assertThat(header.getConsignee().getPostcode(), is(equalTo("CONSIGNEEPOSTCODE02")));
        assertThat(header.getConsignor().getEori(), is(equalTo("CONSIGNOR02")));
        assertThat(header.getConsignor().getName(), is(equalTo("CONSIGNORNAME02")));
        assertThat(header.getConsignor().getPostcode(), is(equalTo("CONSIGNORPOSTCODE02")));
        assertThat(header.getDeclarant().getEori(), is("DECLARANT02"));
        assertThat(header.getDeclarant().getName(), is("DECLARANTNAME02"));
        assertThat(header.getDeclarant().getPostcode(), is("DECLARANTPOSTCODE02"));
        assertThat(header.getDispatchCountry().getCode(), is("COUNTRY02"));
        assertThat(header.getDestinationCountry().getCode(), is("DESTCOUNTRY02"));
        assertThat(header.getTransportModeCode(), is("TRANSPORTMODE02"));
        assertThat(header.getTotalPackages(), is("TOTALPACKAGES02"));
        assertThat(header.getInvoiceCurrency(), is("INVOICECURRRENCY02"));
        assertThat(header.getInvoiceTotal(), is("INVOICETOTAL02"));
        assertThat(header.getInlandTransportMode(), is("INLANDTRANSMODE02"));
        assertThat(header.getPlaceOfLoading(), is("PLACEOFLOADING02"));
        assertThat(header.getDeclarationType(), is("IMF"));
        assertThat(header.getDeclarantRepresentation(), is("DECLARANTREP02"));
        assertThat(header.getProcessingStatus(), is(nullValue()));
        assertThat(header.getTransportId(), is("TRANSPORTID02"));
        assertThat(header.getAcceptanceDate(), is("2018-01-02 00:00:00.00"));
        assertThat(header.getPremisesId(), is("PREMISEID02"));
        assertThat(header.getTotalDuty(), is("TOTALDUTY02"));
        assertThat(header.getGrossMass(), is("GROSSMASS02"));
        assertThat(header.getDeclarationCurrency(), is("DECLARATIONCURRENCY02"));
    }

    @Test
    public void mappingExportHeaderForNullDecType() {
        DeclarationHeader header = getHeader(EXPORT_HEADER_ID_EX003);
        assertThat(header.getDeclarationType(), is(nullValue()));
    }

    private DeclarationHeader getHeader(String id) {
        Dataset<DeclarationHeader> filter = declarationHeaderDataset.filter((DeclarationHeader h) -> h.getDeclarationId().equals(id));
        assertThat(filter.count(), is(1L));
        return filter.first();
    }
}
