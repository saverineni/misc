package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.chief;

import org.apache.spark.sql.Dataset;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLineRoute;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLineRouteReader;

import static org.apache.spark.sql.functions.column;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class ChiefLineRouteReaderIntegrationTest extends SparkTest {

    @Autowired
    private DeclarationLineRouteReader lineRouteReader;

    private static final String IMPORT_HEADER_ID = "IM002";
    private static final int IMPORT_ITEM_NO = 2;
    private static final int IMPORT_ROUTE_SEQ_NO = 2;

    private static final String EXPORT_HEADER_ID = "EX002";
    private static final int EXPORT_ITEM_NO = 2;
    private static final int EXPORT_ROUTE_SEQ_NO = 1;

    private Dataset<DeclarationLineRoute> lineRouteDataset;

    @Before
    public void setUp() {
        lineRouteDataset = lineRouteReader.declarationLineRouteDataset();
    }

    @Test
    public void loadingLines() {
        assertThat(lineRouteDataset.count(), is(equalTo(10L)));
    }

    @Test
    public void mappingImportLine() {
        DeclarationLineRoute lineRoute = getLineRoute(IMPORT_HEADER_ID, IMPORT_ITEM_NO, IMPORT_ROUTE_SEQ_NO);
        assertThat(lineRoute.getJoinId(), is(equalTo(IMPORT_HEADER_ID)));
        assertThat(lineRoute.getSequenceId(), is(equalTo("1")));
        assertThat(lineRoute.getItemNumber(), is(IMPORT_ITEM_NO));
        assertThat(lineRoute.getRouteSequenceNumber(), is(IMPORT_ROUTE_SEQ_NO));
        assertThat(lineRoute.getRouteCountryCode(), is("IM002-22ROUTE"));
    }

    @Test
    public void mappingExportLine() {
        DeclarationLineRoute lineClineRoutentainer = getLineRoute(EXPORT_HEADER_ID, EXPORT_ITEM_NO, EXPORT_ROUTE_SEQ_NO);
        assertThat(lineClineRoutentainer.getJoinId(), is(equalTo(EXPORT_HEADER_ID)));
        assertThat(lineClineRoutentainer.getSequenceId(), is(equalTo("1")));
        assertThat(lineClineRoutentainer.getItemNumber(), is(EXPORT_ITEM_NO));
        assertThat(lineClineRoutentainer.getRouteSequenceNumber(), is(EXPORT_ROUTE_SEQ_NO));
        assertThat(lineClineRoutentainer.getRouteCountryCode(), is("EX002-21ROUTE"));
    }

//    @Test
//    public void getAllContainersForLine() {
//
//    }

    private DeclarationLineRoute getLineRoute(String id, int itemNo, int routeSequenceNumber) {
        Dataset<DeclarationLineRoute> filter = lineRouteDataset
                .where(column("joinId").isNotNull()
                        .and(column("itemNumber").isNotNull())
                        .and(column("routeSequenceNumber").isNotNull())
                )
                .filter((DeclarationLineRoute l) -> l.getJoinId().equals(id) &&
                                                            l.getItemNumber() == itemNo &&
                                                            l.getRouteSequenceNumber() == routeSequenceNumber
                );
        assertThat(filter.count(), is(1L));
        return filter.first();
    }
}
