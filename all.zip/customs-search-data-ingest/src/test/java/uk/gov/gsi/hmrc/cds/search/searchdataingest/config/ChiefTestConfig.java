package uk.gov.gsi.hmrc.cds.search.searchdataingest.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Profile;

@Profile({"!cds"})
@Configuration
@Import({SparkChiefReaderConfig.class})
public class ChiefTestConfig  extends TestConfig {

}
