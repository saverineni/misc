package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.group;

import org.apache.spark.sql.Dataset;
import org.assertj.core.util.Lists;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLineGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLineReader;

import java.util.Arrays;

import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

public class DeclarationLineGroupDatasetIntegrationTest extends SparkTest {

    private static final String IMPORT_DECLARATION_ID = "IM002";
    private static final int IMPORT_ITEM_NUMBER_2 = 2;
    private static String[] declarationLineGroupStructFields = toArray(
            Lists.newArrayList(
                    "joinId",
                    "itemNumber",
                    "sequenceId",
                    "routes",
                    "packages",
                    "containers",
                    "previousDocuments",
                    "additionalInfo",
                    "taxLines"
            )
    );
    private Dataset<DeclarationLineGroup> result;

    @Autowired
    private DeclarationLineReader declarationLineReader;
    @Autowired
    private DeclarationLineRouteGroupDataset lineRouteGroupDataset;
    @Autowired
    private DeclarationLinePackageGroupDataset linePackageGroupDataset;
    @Autowired
    private DeclarationLineContainerGroupDataset lineContainerGroupDataset;
    @Autowired
    private DeclarationLinePreviousDocumentGroupDataset linePreviousDocumentGroupDataset;
    @Autowired
    private DeclarationLineAdditionalInfoGroupDataset lineAdditionalInfoGroupDataset;
    @Autowired
    private DeclarationLineTaxLineGroupDataset lineTaxLineGroupDataset;

    @Before
    public void setUp() throws Exception {
        DeclarationLineGroupDataset lineGroupDataset = new DeclarationLineGroupDataset(
                declarationLineReader, lineRouteGroupDataset, linePackageGroupDataset, lineContainerGroupDataset,
                linePreviousDocumentGroupDataset, lineAdditionalInfoGroupDataset, lineTaxLineGroupDataset);
        result = lineGroupDataset.build();
    }

    @Test
    public void validateSchema() {
        String[] fieldNames = result.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), containsInAnyOrder(declarationLineGroupStructFields));
    }

    @Test
    public void shouldGroupByLine() {
        assertThat(result.count(), is(8L));
    }

    @Test
    public void shouldAggregateByLine() {
        DeclarationLineGroup firstLine = filterDataset(IMPORT_DECLARATION_ID, IMPORT_ITEM_NUMBER_2);

        assertThat(firstLine.getJoinId(), is(IMPORT_DECLARATION_ID));
        assertThat(firstLine.getItemNumber(), is(IMPORT_ITEM_NUMBER_2));

        assertAdditionalInfo(firstLine);
        assertContainers(firstLine);
        assertPackages(firstLine);
        assertPreviousDocuments(firstLine);
        assertRoutes(firstLine);
        assertTaxLines(firstLine);
    }

    private void assertTaxLines(DeclarationLineGroup firstLine) {
        assertThat(firstLine.getTaxLines().size(), is(2));
        assertThat(firstLine.getTaxLines().get(0).getTaxLineSequenceNumber(), is(1));
        assertThat(firstLine.getTaxLines().get(0).getTaxTypeCode(), is("IM002-21TTYCODE"));
        assertThat(firstLine.getTaxLines().get(0).getTaxBaseAmount(), is("IM002-21TAXBASEAMT"));
        assertThat(firstLine.getTaxLines().get(0).getTaxBaseQuantity(), is("IM002-21TAXBASEQTY"));
        assertThat(firstLine.getTaxLines().get(0).getTaxRateIdentifier(), is("IM002-21TAXRATE"));
        assertThat(firstLine.getTaxLines().get(0).getTaxOverrideCode(), is("IM002-21TAXOVERRIDECODE"));
        assertThat(firstLine.getTaxLines().get(0).getTaxAmount(), is("IM002-21TAXAMT"));
        assertThat(firstLine.getTaxLines().get(0).getMethodOfPaymentCode(), is("IM002-21METHODOFPAYMENT"));
        assertThat(firstLine.getTaxLines().get(0).getTaxBaseAmountCalculated(), is("IM002-21TAXBASEAMTCALC"));
        assertThat(firstLine.getTaxLines().get(0).getTaxAmountCalculated(), is("IM002-21TAXAMTCALC"));
        assertThat(firstLine.getTaxLines().get(0).getTaxAmountIndicator(), is("IM002-21TAXAMTINDICATOR"));


        assertThat(firstLine.getTaxLines().get(1).getTaxLineSequenceNumber(), is(2));
        assertThat(firstLine.getTaxLines().get(1).getTaxTypeCode(), is("IM002-22TTYCODE"));
        assertThat(firstLine.getTaxLines().get(1).getTaxBaseAmount(), is("IM002-22TAXBASEAMT"));
        assertThat(firstLine.getTaxLines().get(1).getTaxBaseQuantity(), is("IM002-22TAXBASEQTY"));
        assertThat(firstLine.getTaxLines().get(1).getTaxRateIdentifier(), is("IM002-22TAXRATE"));
        assertThat(firstLine.getTaxLines().get(1).getTaxOverrideCode(), is("IM002-22TAXOVERRIDECODE"));
        assertThat(firstLine.getTaxLines().get(1).getTaxAmount(), is("IM002-22TAXAMT"));
        assertThat(firstLine.getTaxLines().get(1).getMethodOfPaymentCode(), is("IM002-22METHODOFPAYMENT"));
        assertThat(firstLine.getTaxLines().get(1).getTaxBaseAmountCalculated(), is("IM002-22TAXBASEAMTCALC"));
        assertThat(firstLine.getTaxLines().get(1).getTaxAmountCalculated(), is("IM002-22TAXAMTCALC"));
        assertThat(firstLine.getTaxLines().get(1).getTaxAmountIndicator(), is("IM002-22TAXAMTINDICATOR"));
    }

    private void assertRoutes(DeclarationLineGroup firstLine) {
        assertThat(firstLine.getRoutes().size(), is(2));
        assertThat(firstLine.getRoutes().get(0).getRouteSequenceNumber(), is(1));
        assertThat(firstLine.getRoutes().get(0).getRouteCountryCode(), is("IM002-21ROUTE"));

        assertThat(firstLine.getRoutes().get(1).getRouteSequenceNumber(), is(2));
        assertThat(firstLine.getRoutes().get(1).getRouteCountryCode(), is("IM002-22ROUTE"));
    }

    private void assertPreviousDocuments(DeclarationLineGroup firstLine) {
        assertThat(firstLine.getPreviousDocuments().size(), is(1));
        assertNull(firstLine.getPreviousDocuments().get(0).getPreviousDocumentSequenceNumber());
        assertNull(firstLine.getPreviousDocuments().get(0).getPreviousDocumentClass());
    }

    private void assertAdditionalInfo(DeclarationLineGroup firstLine) {
        assertThat(firstLine.getAdditionalInfo().size(), is(2));
        assertThat(firstLine.getAdditionalInfo().get(0).getAdditionalInfoSequenceNumber(), is(1));
        assertThat(firstLine.getAdditionalInfo().get(0).getAdditionalInfoStatement(), is("IM002-21AISTMT"));
        assertThat(firstLine.getAdditionalInfo().get(0).getAdditionalInfoStatementDescription(), is("IM002-21STMTDESC"));

        assertThat(firstLine.getAdditionalInfo().get(1).getAdditionalInfoSequenceNumber(), is(2));
        assertThat(firstLine.getAdditionalInfo().get(1).getAdditionalInfoStatement(), is("IM002-22AISTMT"));
        assertThat(firstLine.getAdditionalInfo().get(1).getAdditionalInfoStatementDescription(), is("IM002-22STMTDESC"));
    }

    private void assertContainers(DeclarationLineGroup firstLine) {
        assertThat(firstLine.getContainers().size(), is(2));
        assertThat(firstLine.getContainers().get(0).getContainerSequenceNumber(), is(1));
        assertThat(firstLine.getContainers().get(0).getContainerNumber(), is("IM002-21CONTAINER"));

        assertThat(firstLine.getContainers().get(1).getContainerSequenceNumber(), is(2));
        assertThat(firstLine.getContainers().get(1).getContainerNumber(), is("IM002-22CONTAINER"));
    }

    private void assertPackages(DeclarationLineGroup firstLine) {
        assertThat(firstLine.getPackages().size(), is(2));
        assertThat(firstLine.getPackages().get(0).getPackageSequenceNumber(), is(1));
        assertThat(firstLine.getPackages().get(0).getPackageCount(), is("IM002-21COUNT"));
        assertThat(firstLine.getPackages().get(0).getPackageKind(), is("IM002-21KIND"));
        assertThat(firstLine.getPackages().get(0).getPackageMarks(), is("IM002-21MARK"));

        assertThat(firstLine.getPackages().get(1).getPackageSequenceNumber(), is(2));
        assertThat(firstLine.getPackages().get(1).getPackageCount(), is("IM002-22COUNT"));
        assertThat(firstLine.getPackages().get(1).getPackageKind(), is("IM002-22KIND"));
        assertThat(firstLine.getPackages().get(1).getPackageMarks(), is("IM002-22MARK"));
    }

    private DeclarationLineGroup filterDataset(String declarationId, int itemNumber) {
        Dataset<DeclarationLineGroup> filter = result
                .filter((DeclarationLineGroup l) ->
                        l.getJoinId().equals(declarationId) && l.getItemNumber() == itemNumber
                )
                .as(DeclarationLineGroup.declarationLineGroupEncoder);

        assertThat(filter.count(), is(1L));

        /* Weird deserialization issue when using dataset.first(). The  java object contains incorrect values, though the dataset.show() displays correct values.
         * Guess, some issue with the way the encoders are used for lists (nested object inside a group type)
         * Work around -  get the first row as json and use jackson to build the java object.
         */
        return parseJson(filter.toJSON().first(), DeclarationLineGroup.class);
    }
}
