package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.cds;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.Trader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLineReader;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

@TestPropertySource(properties = "sequence.ids=1,2")
@ActiveProfiles({ "test", "cds" })
public class CdsLineReaderIntegrationTest extends SparkTest {

    @Autowired
    private DeclarationLineReader declarationLineReader;

    private List<DeclarationLine> declarationLines;

    @Before
    public void setUp() {
        declarationLines = declarationLineReader.declarationLineDataset().collectAsList();
    }

    @Test
    public void loadingLines() {
        assertThat(declarationLines.size(), is(equalTo(6)));
    }

    @Test
    public void mappingImportLine() {
        DeclarationLine line = getLine("1", 1);
        assertThat(line.getJoinId(), is(equalTo("1")));
        assertThat(line.getItemNumber(), is(1));
        assertThat(line.getSequenceId(), is("1"));
        assertThat(line.getCpc(), is("CPC1"));
        assertThat(line.getCommodityCode(), is("COMMODITY1"));
        assertThat(line.getPreferenceNumber(),is("P"));
    }

    @Test
    public void countryFieldsShouldBePopulated() {
        DeclarationLine line = getLine("1", 1);

        assertThat(line.getOriginCountry().getCode(), is("COUNTRY_O1"));
        assertThat(line.getItemDispatchCountry().getCode(), is("COUNTRY_DIS1"));
        assertThat(line.getItemDestinationCountry().getCode(), is("COUNTRY_DEST1"));
    }

    @Test
    public void missingCdsFieldsShouldBeNull() {
        DeclarationLine line = getLine("1", 1);

        assertThat(line.getClearanceDate(), is(nullValue()));
        assertThat(line.getItemRoute(), is(nullValue()));
    }

    private DeclarationLine getLine(String decId, int itemNumber) {
        return declarationLines.stream()
                .filter(it -> it.getJoinId().equals(decId))
                .filter(it -> it.getItemNumber() == itemNumber)
                .findFirst().get();
    }

    @Test
    public void importTraderProperties() {
        DeclarationLine line = getLine("1", 1);

        assertThat(line.getItemConsignee(), is(trader("CONSIGNEE1")));
        assertThat(line.getItemConsignor(), is(trader("CONSIGNOR1")));
    }

    private Trader trader(String eori) {
        Trader trader = new Trader();
        trader.setEori(eori);
        return trader;
    }

    @Test
    public void nullStructColumnValuesShouldGiveNullProperties() {
        DeclarationLine line = getLine("4", 2);

        assertThat(line.getOriginCountry(), is(nullValue()));
        assertThat(line.getItemDispatchCountry(), is(nullValue()));
        assertThat(line.getItemDestinationCountry(), is(nullValue()));
        assertThat(line.getItemConsignee(), is(nullValue()));
        assertThat(line.getItemConsignor(), is(nullValue()));
    }
}
