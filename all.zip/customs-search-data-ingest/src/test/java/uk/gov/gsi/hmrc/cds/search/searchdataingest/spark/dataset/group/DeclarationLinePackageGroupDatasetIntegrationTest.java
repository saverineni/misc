package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.group;

import org.apache.spark.sql.Dataset;
import org.assertj.core.util.Lists;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLinePackageGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLinePackageReader;

import java.util.Arrays;

import static org.apache.spark.sql.functions.col;
import static org.apache.spark.sql.functions.explode;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class DeclarationLinePackageGroupDatasetIntegrationTest extends SparkTest {

    private static final String IMPORT_DECLARATION_ID = "IM002";
    private static final int IMPORT_ITEM_NUMBER_2 = 2;
    private static final String GROUPED_COLUMN_NAME = "packages";
    private static String[] declarationLinePackageGroupStructFields = toArray(
            Lists.newArrayList(
                    "joinId",
                    "itemNumber",
                    "sequenceId",
                    GROUPED_COLUMN_NAME
            )
    );
    private static String[] packageExplodeStructFields = toArray(
            Lists.newArrayList(
                    "packageSequenceNumber",
                    "packageKind",
                    "packageCount",
                    "packageMarks"
            )
    );
    private Dataset<DeclarationLinePackageGroup> result;

    @Autowired
    DeclarationLinePackageReader declarationLinePackageReader;

    @Before
    public void setUp() throws Exception {
        DeclarationLinePackageGroupDataset packageGroupDataset = new DeclarationLinePackageGroupDataset(declarationLinePackageReader);
        result = packageGroupDataset.build();
    }

    @Test
    public void validateSchema() {
        String[] fieldNames = result.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), containsInAnyOrder(declarationLinePackageGroupStructFields));
    }

    @Test
    public void validateGroupedColumnSchema() {
        String[] fieldNames = result
                .select(explode(col(GROUPED_COLUMN_NAME)))
                .select(col("col.*"))
                .schema()
                .fieldNames();

        assertThat(Arrays.asList(fieldNames), containsInAnyOrder(packageExplodeStructFields));
    }

    @Test
    public void shouldGroupPackageByLine() {
        assertThat(result.count(), is(8L));
    }

    @Test
    public void shouldAggregatePackageByLine() {
        DeclarationLinePackageGroup firstLine = filterDataset(IMPORT_DECLARATION_ID, IMPORT_ITEM_NUMBER_2);

        assertThat(firstLine.getJoinId(), is(IMPORT_DECLARATION_ID));
        assertThat(firstLine.getItemNumber(), is(IMPORT_ITEM_NUMBER_2));

        assertThat(firstLine.getPackages().size(), is(2));
        assertThat(firstLine.getPackages().get(0).getPackageSequenceNumber(), is(1));
        assertThat(firstLine.getPackages().get(0).getPackageCount(), is("IM002-21COUNT"));
        assertThat(firstLine.getPackages().get(0).getPackageKind(), is("IM002-21KIND"));
        assertThat(firstLine.getPackages().get(0).getPackageMarks(), is("IM002-21MARK"));

        assertThat(firstLine.getPackages().get(1).getPackageSequenceNumber(), is(2));
        assertThat(firstLine.getPackages().get(1).getPackageCount(), is("IM002-22COUNT"));
        assertThat(firstLine.getPackages().get(1).getPackageKind(), is("IM002-22KIND"));
        assertThat(firstLine.getPackages().get(1).getPackageMarks(), is("IM002-22MARK"));
    }

    private DeclarationLinePackageGroup filterDataset(String declarationId, int itemNumber) {

        Dataset<DeclarationLinePackageGroup> filter = result
                .filter((DeclarationLinePackageGroup l) ->
                        l.getJoinId().equals(declarationId) && l.getItemNumber() == itemNumber
                )
                .as(DeclarationLinePackageGroup.declarationLinePackageGroupEncoder);

        assertThat(filter.count(), is(1L));

        /* Weird deserialization issue when using dataset.first(). The  java object contains incorrect values, though the dataset.show() displays correct values.
         * Guess, some issue with the way the encoders are used for lists (nested object inside a group type)
         * Work around -  get the first row as json and use jackson to build the java object.
         */
        return parseJson(filter.toJSON().first(), DeclarationLinePackageGroup.class);
    }

}
