package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.group;

import org.apache.spark.sql.Dataset;
import org.assertj.core.util.Lists;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLineTaxLineGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLineTaxLineReader;

import java.util.Arrays;

import static org.apache.spark.sql.functions.col;
import static org.apache.spark.sql.functions.explode;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class DeclarationLineTaxLineGroupDatasetIntegrationTest extends SparkTest {

    private static final String IMPORT_DECLARATION_ID = "IM002";
    private static final int IMPORT_ITEM_NUMBER_2 = 2;
    private static final String GROUPED_COLUMN_NAME = "taxLines";
    private static String[] declarationLineTaxLineGroupStructFields = toArray(
            Lists.newArrayList(
                    "joinId",
                    "itemNumber",
                    "sequenceId",
                    GROUPED_COLUMN_NAME
            )
    );
    private static String[] taxLineExplodeStructFields = toArray(
            Lists.newArrayList(
                    "taxLineSequenceNumber",
                    "taxTypeCode",
                    "taxBaseAmount",
                    "taxBaseQuantity",
                    "taxRateIdentifier",
                    "taxOverrideCode",
                    "taxAmount",
                    "methodOfPaymentCode",
                    "taxBaseAmountCalculated",
                    "taxAmountCalculated",
                    "taxAmountIndicator"
            )
    );
    private Dataset<DeclarationLineTaxLineGroup> result;

    @Autowired
    DeclarationLineTaxLineReader declarationLineTaxLineReader;

    @Before
    public void setUp() throws Exception {
        DeclarationLineTaxLineGroupDataset taxLineGroupDataset = new DeclarationLineTaxLineGroupDataset(declarationLineTaxLineReader);
        result = taxLineGroupDataset.build();
    }

    @Test
    public void validateSchema() {
        String[] fieldNames = result.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), containsInAnyOrder(declarationLineTaxLineGroupStructFields));
    }

    @Test
    public void validateGroupedColumnSchema() {
        String[] fieldNames = result
                .select(explode(col(GROUPED_COLUMN_NAME)))
                .select(col("col.*"))
                .schema()
                .fieldNames();

        assertThat(Arrays.asList(fieldNames), containsInAnyOrder(taxLineExplodeStructFields));
    }

    @Test
    public void shouldGroupTaxLineByLine() {
        assertThat(result.count(), is(8L));
    }

    @Test
    public void shouldAggregateTaxLineByLine() {
        DeclarationLineTaxLineGroup firstLine = filterDataset(IMPORT_DECLARATION_ID, IMPORT_ITEM_NUMBER_2);

        assertThat(firstLine.getJoinId(), is(IMPORT_DECLARATION_ID));
        assertThat(firstLine.getItemNumber(), is(IMPORT_ITEM_NUMBER_2));

        assertThat(firstLine.getTaxLines().size(), is(2));
        assertThat(firstLine.getTaxLines().get(0).getTaxLineSequenceNumber(), is(1));
        assertThat(firstLine.getTaxLines().get(0).getTaxTypeCode(), is("IM002-21TTYCODE"));
        assertThat(firstLine.getTaxLines().get(0).getTaxBaseAmount(), is("IM002-21TAXBASEAMT"));
        assertThat(firstLine.getTaxLines().get(0).getTaxBaseQuantity(), is("IM002-21TAXBASEQTY"));
        assertThat(firstLine.getTaxLines().get(0).getTaxRateIdentifier(), is("IM002-21TAXRATE"));
        assertThat(firstLine.getTaxLines().get(0).getTaxOverrideCode(), is("IM002-21TAXOVERRIDECODE"));
        assertThat(firstLine.getTaxLines().get(0).getTaxAmount(), is("IM002-21TAXAMT"));
        assertThat(firstLine.getTaxLines().get(0).getMethodOfPaymentCode(), is("IM002-21METHODOFPAYMENT"));
        assertThat(firstLine.getTaxLines().get(0).getTaxBaseAmountCalculated(), is("IM002-21TAXBASEAMTCALC"));
        assertThat(firstLine.getTaxLines().get(0).getTaxAmountCalculated(), is("IM002-21TAXAMTCALC"));
        assertThat(firstLine.getTaxLines().get(0).getTaxAmountIndicator(), is("IM002-21TAXAMTINDICATOR"));

        assertThat(firstLine.getTaxLines().get(1).getTaxLineSequenceNumber(), is(2));
        assertThat(firstLine.getTaxLines().get(1).getTaxTypeCode(), is("IM002-22TTYCODE"));
        assertThat(firstLine.getTaxLines().get(1).getTaxBaseAmount(), is("IM002-22TAXBASEAMT"));
        assertThat(firstLine.getTaxLines().get(1).getTaxBaseQuantity(), is("IM002-22TAXBASEQTY"));
        assertThat(firstLine.getTaxLines().get(1).getTaxRateIdentifier(), is("IM002-22TAXRATE"));
        assertThat(firstLine.getTaxLines().get(1).getTaxOverrideCode(), is("IM002-22TAXOVERRIDECODE"));
        assertThat(firstLine.getTaxLines().get(1).getTaxAmount(), is("IM002-22TAXAMT"));
        assertThat(firstLine.getTaxLines().get(1).getMethodOfPaymentCode(), is("IM002-22METHODOFPAYMENT"));
        assertThat(firstLine.getTaxLines().get(1).getTaxBaseAmountCalculated(), is("IM002-22TAXBASEAMTCALC"));
        assertThat(firstLine.getTaxLines().get(1).getTaxAmountCalculated(), is("IM002-22TAXAMTCALC"));
        assertThat(firstLine.getTaxLines().get(1).getTaxAmountIndicator(), is("IM002-22TAXAMTINDICATOR"));

    }

    private DeclarationLineTaxLineGroup filterDataset(String declarationId, int itemNumber) {
        Dataset<DeclarationLineTaxLineGroup> filter = result
                .filter((DeclarationLineTaxLineGroup l) ->
                        l.getJoinId().equals(declarationId) && l.getItemNumber() == itemNumber
                )
                .as(DeclarationLineTaxLineGroup.declarationLineTaxLineGroupEncoder);

        assertThat(filter.count(), is(1L));

        /* Weird deserialization issue when using dataset.first(). The  java object contains incorrect values, though the dataset.show() displays correct values.
         * Guess, some issue with the way the encoders are used for lists (nested object inside a group type)
         * Work around -  get the first row as json and use jackson to build the java object.
         */
        return parseJson(filter.toJSON().first(), DeclarationLineTaxLineGroup.class);
    }
}
