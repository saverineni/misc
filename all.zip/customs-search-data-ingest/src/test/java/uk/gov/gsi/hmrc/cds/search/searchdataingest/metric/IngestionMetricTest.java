package uk.gov.gsi.hmrc.cds.search.searchdataingest.metric;

import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.SparkSession;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.util.StopWatch;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;

import java.util.ArrayList;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

public class IngestionMetricTest extends SparkTest {

    @MockBean
    ESMetricIngester mockEsMetricIngester;

    @MockBean
    IngestionCountReader mockIngestionCountReader;

    @MockBean
    IngestionMetricCapture mockMetricCapture;

    @MockBean
    StopWatch mockStopWatch;

    @Captor
    ArgumentCaptor<JavaRDD<String>> metricAsRDDCaptor;

    @Autowired
    SparkSession sparkSession;

    @Autowired
    IngestionMetric ingestionMetric;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
    }

    @Test
    public void metadataWhenSuccess() throws Exception{
        Dataset<IngestionMetricTest.Count> mockCountDataset = getCountDataset();

        Dataset<Long> importCountDataset = mockCountDataset.select("importDeclarationCount").as(Encoders.LONG());
        when(mockIngestionCountReader.getImportCountDataset()).thenReturn(importCountDataset);

        Dataset<Long> exportCountDataset = mockCountDataset.select("exportDeclarationCount").as(Encoders.LONG());
        when(mockIngestionCountReader.getExportCountDataset()).thenReturn(exportCountDataset);

        Dataset<Long> exportCountAllDataset = mockCountDataset.select("exportDeclarationAllCount").as(Encoders.LONG());
        when(mockIngestionCountReader.getExportCountAllDataset()).thenReturn(exportCountAllDataset);

        when(mockMetricCapture.getIngestionState()).thenReturn(IngestMetadata.INGESTION_SUCCESSFUL);
        when(mockMetricCapture.getIngestionStartDateTime()).thenReturn("ingestionStartDateTime");
        when(mockMetricCapture.getIngestionEndDateTime()).thenReturn("ingestionEndDateTime");
        when(mockMetricCapture.getStopwatch()).thenReturn(mockStopWatch);
        when(mockStopWatch.getTotalTimeSeconds()).thenReturn(100.0);

        ingestionMetric.saveToES(mockMetricCapture);

        verify(mockEsMetricIngester, atLeast(1)).ingestMetric(metricAsRDDCaptor.capture());
        JavaRDD<String> metricAsRDD = metricAsRDDCaptor.getValue();
        assertThat(metricAsRDD, is(notNullValue()));

        IngestMetadata ingestMetadata = parseJson(metricAsRDD.first(), IngestMetadata.class);

        assertThat(ingestMetadata.getDeclarationSource(), is(equalTo("TEST")));
        assertThat(ingestMetadata.getIngestionState(), is(equalTo("Success")));
        assertThat(ingestMetadata.getIngestionStartDateTime(), is(equalTo("ingestionStartDateTime")));
        assertThat(ingestMetadata.getIngestionEndDateTime(), is(equalTo("ingestionEndDateTime")));
        assertThat(ingestMetadata.getTotalIngestionTimeInSeconds(), is(equalTo(100.0)));
        assertThat(ingestMetadata.getImportDeclarationCount(), is(equalTo(10l)));
        assertThat(ingestMetadata.getExportDeclarationCount(), is(equalTo(20l)));
        assertThat(ingestMetadata.getTotalDeclarationCount(), is(equalTo(30l)));
        assertThat(ingestMetadata.getExportDeclarationAllCount(), is(equalTo(40l)));
        assertThat(ingestMetadata.getIndexName(), is(equalTo("test")));
        assertThat(ingestMetadata.getSequenceNumber(), is(equalTo("")));
    }


    @Test
    public void metaDataCountIsZeroOnException() throws Exception{
        when(mockIngestionCountReader.getImportCountDataset()).thenThrow(new RuntimeException("Just Error"));
        when(mockIngestionCountReader.getExportCountDataset()).thenThrow(new RuntimeException("Just Error"));
        when(mockIngestionCountReader.getExportCountAllDataset()).thenThrow(new RuntimeException("Just Error"));

        when(mockMetricCapture.getIngestionState()).thenReturn(IngestMetadata.INGESTION_FAILURE);
        when(mockMetricCapture.getIngestionStartDateTime()).thenReturn("ingestionStartDateTime");
        when(mockMetricCapture.getIngestionEndDateTime()).thenReturn("ingestionEndDateTime");
        when(mockMetricCapture.getStopwatch()).thenReturn(mockStopWatch);
        when(mockStopWatch.getTotalTimeSeconds()).thenReturn(50.0);

        ingestionMetric.saveToES(mockMetricCapture);

        verify(mockEsMetricIngester).ingestMetric(metricAsRDDCaptor.capture());
        JavaRDD<String> metricAsRDD = metricAsRDDCaptor.getValue();
        assertThat(metricAsRDD, is(notNullValue()));

        IngestMetadata ingestMetadata = parseJson(metricAsRDD.first(), IngestMetadata.class);

        assertThat(ingestMetadata.getDeclarationSource(), is(equalTo("TEST")));
        assertThat(ingestMetadata.getIngestionState(), is(equalTo("Failure")));
        assertThat(ingestMetadata.getIngestionStartDateTime(), is(equalTo("ingestionStartDateTime")));
        assertThat(ingestMetadata.getIngestionEndDateTime(), is(equalTo("ingestionEndDateTime")));
        assertThat(ingestMetadata.getTotalIngestionTimeInSeconds(), is(equalTo(50.0)));
        assertThat(ingestMetadata.getImportDeclarationCount(), is(equalTo(0l)));
        assertThat(ingestMetadata.getExportDeclarationCount(), is(equalTo(0l)));
        assertThat(ingestMetadata.getTotalDeclarationCount(), is(equalTo(0l)));
        assertThat(ingestMetadata.getExportDeclarationAllCount(), is(equalTo(0l)));
        assertThat(ingestMetadata.getIndexName(), is(equalTo("test")));
        assertThat(ingestMetadata.getSequenceNumber(), is(equalTo("")));

    }

    @Test
    public void totalDeclarationCountIsSumOfImportAndLatestExportCount() throws Exception {
        Dataset<IngestionMetricTest.Count> mockCountDataset = getCountDataset();

        Dataset<Long> importCountDataset = mockCountDataset.select("importDeclarationCount").as(Encoders.LONG());
        when(mockIngestionCountReader.getImportCountDataset()).thenReturn(importCountDataset);

        when(mockIngestionCountReader.getExportCountDataset()).thenThrow(new RuntimeException("Just Error"));

        when(mockMetricCapture.getIngestionState()).thenReturn(IngestMetadata.INGESTION_SUCCESSFUL);
        when(mockMetricCapture.getIngestionStartDateTime()).thenReturn("ingestionStartDateTime");
        when(mockMetricCapture.getIngestionEndDateTime()).thenReturn("ingestionEndDateTime");
        when(mockMetricCapture.getStopwatch()).thenReturn(mockStopWatch);
        when(mockStopWatch.getTotalTimeSeconds()).thenReturn(100.0);

        ingestionMetric.saveToES(mockMetricCapture);

        verify(mockEsMetricIngester).ingestMetric(metricAsRDDCaptor.capture());
        JavaRDD<String> metricAsRDD = metricAsRDDCaptor.getValue();
        assertThat(metricAsRDD, is(notNullValue()));

        IngestMetadata ingestMetadata = parseJson(metricAsRDD.first(), IngestMetadata.class);

        assertThat(ingestMetadata.getDeclarationSource(), is(equalTo("TEST")));
        assertThat(ingestMetadata.getIngestionState(), is(equalTo("Success")));
        assertThat(ingestMetadata.getIngestionStartDateTime(), is(equalTo("ingestionStartDateTime")));
        assertThat(ingestMetadata.getIngestionEndDateTime(), is(equalTo("ingestionEndDateTime")));
        assertThat(ingestMetadata.getTotalIngestionTimeInSeconds(), is(equalTo(100.0)));
        assertThat(ingestMetadata.getImportDeclarationCount(), is(equalTo(10l)));
        assertThat(ingestMetadata.getExportDeclarationCount(), is(equalTo(0l)));
        assertThat(ingestMetadata.getTotalDeclarationCount(), is(equalTo(10l)));
        assertThat(ingestMetadata.getExportDeclarationAllCount(), is(equalTo(0l)));
        assertThat(ingestMetadata.getIndexName(), is(equalTo("test")));
        assertThat(ingestMetadata.getSequenceNumber(), is(equalTo("")));

    }

    private Dataset<IngestionMetricTest.Count> getCountDataset() {
        ArrayList<IngestionMetricTest.Count> givenCountValues = Lists.newArrayList(
                new IngestionMetricTest.Count(10l, 20l, 40l)
        );

        return sparkSession.createDataset(givenCountValues, Encoders.bean(IngestionMetricTest.Count.class));
    }

    @AllArgsConstructor
    @Data
    public static class Count {
        long importDeclarationCount;
        long exportDeclarationCount;
        long exportDeclarationAllCount;
    }
}