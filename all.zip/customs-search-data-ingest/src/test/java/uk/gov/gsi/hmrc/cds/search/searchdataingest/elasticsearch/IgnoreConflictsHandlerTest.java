package uk.gov.gsi.hmrc.cds.search.searchdataingest.elasticsearch;

import org.elasticsearch.hadoop.handler.HandlerResult;
import org.elasticsearch.hadoop.rest.bulk.handler.BulkWriteFailure;
import org.elasticsearch.hadoop.rest.bulk.handler.DelayableErrorCollector;
import org.junit.Test;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class IgnoreConflictsHandlerTest {

    private IgnoreConflictsHandler handler = new IgnoreConflictsHandler();

    private BulkWriteFailure bulkWriteFailure = mock(BulkWriteFailure.class);
    @SuppressWarnings("unchecked")
    private DelayableErrorCollector<byte[]> errorCollector = mock(DelayableErrorCollector.class);

    @Test
    public void shouldHandleVersionMismatchErrors() throws Exception {
        when(bulkWriteFailure.getResponseCode()).thenReturn(409);
        when(bulkWriteFailure.getException()).thenReturn(new Exception());
        HandlerResult result = handler.onError(bulkWriteFailure, errorCollector);
        assertThat(result, is(equalTo(HandlerResult.HANDLED)));
    }

    @Test
    public void shouldPassNonVersionMismatchErrors() throws Exception {
        when(bulkWriteFailure.getResponseCode()).thenReturn(500);
        when(bulkWriteFailure.getException()).thenReturn(new Exception());
        when(errorCollector.pass(anyString())).thenReturn(HandlerResult.PASS);
        HandlerResult result = handler.onError(bulkWriteFailure, errorCollector);
        assertThat(result, is(equalTo(HandlerResult.PASS)));
    }

}
