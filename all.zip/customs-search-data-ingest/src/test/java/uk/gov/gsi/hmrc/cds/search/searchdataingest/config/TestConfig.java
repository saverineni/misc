package uk.gov.gsi.hmrc.cds.search.searchdataingest.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.spark.sql.SparkSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.HiveDatabaseSetup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.utils.ResourceService;

import javax.annotation.PostConstruct;
import java.io.File;

public abstract class TestConfig {
    public static final String TEST_HIVE_METASTORE_DB = "target/hive/metastore_db";
    public static final String TEST_HIVE_WAREHOUSE = "target/hive/spark-warehouse";

    @Bean
    public SparkSession sparkSession() {
        String hiveMetastoreDbAbsolutePath = new File(TEST_HIVE_METASTORE_DB).getAbsolutePath();
        String hiveWarehouseAbsolutePath = new File(TEST_HIVE_WAREHOUSE).getAbsolutePath();
        return SparkSession
                .builder()
                .appName("customs-search-data-ingest")
                .master("local[*]")
                .config("spark.sql.warehouse.dir", hiveWarehouseAbsolutePath)
                .config("javax.jdo.option.ConnectionURL", String.format("jdbc:derby:%s;create=true", hiveMetastoreDbAbsolutePath))
                .config("spark.driver.memory", "1g")
                .config("spark.executor.memory", "1g")
                .config("spark.driver.extraJavaOptions", "-XX:+UseG1GC")
                .config("spark.executor.extraJavaOptions", "-XX:+UseG1GC")
                .enableHiveSupport()
                .getOrCreate();
    }

    @Autowired
    public ResourceService resourceService;

    @Bean
    public HiveDatabaseSetup hiveDatabaseSetup() {
        return new HiveDatabaseSetup(sparkSession(), resourceService);
    }

    @Bean
    public ObjectMapper objectMapper() {
        return new ObjectMapper();
    }

    @PostConstruct
    public void dbSetup() {
        HiveDatabaseSetup hiveDatabaseSetup = new HiveDatabaseSetup(sparkSession(), resourceService);
        hiveDatabaseSetup.createTestDb();
        hiveDatabaseSetup.setUpChiefDb();
        hiveDatabaseSetup.setUpCdsDb();
    }
}
