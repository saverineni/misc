package uk.gov.gsi.hmrc.cds.search.searchdataingest.test;

import java.io.File;
import java.net.URL;

import org.apache.commons.io.Charsets;
import org.apache.commons.io.IOUtils;

public class TestResourceLoader {

    public static String load(Object test, String resource) {
        try {
            Class<?> testClass = test.getClass();
            URL url = testClass.getClassLoader().getResource(packagePath(testClass) + File.separator + resource);
            return IOUtils.toString(url, Charsets.UTF_8);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    private static String packagePath(Class<?> testClass) {
        return testClass.getPackage().getName().replace(".", File.separator);
    }
}
