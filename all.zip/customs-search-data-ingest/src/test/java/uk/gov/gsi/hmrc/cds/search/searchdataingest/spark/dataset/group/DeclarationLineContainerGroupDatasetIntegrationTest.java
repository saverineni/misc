package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.group;

import org.apache.spark.sql.Dataset;
import org.assertj.core.util.Lists;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLineContainerGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLinePackageGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLineContainerReader;

import java.util.Arrays;

import static org.apache.spark.sql.functions.col;
import static org.apache.spark.sql.functions.explode;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class DeclarationLineContainerGroupDatasetIntegrationTest extends SparkTest {
    private static final String IMPORT_DECLARATION_ID = "IM002";
    private static final int IMPORT_ITEM_NUMBER_2 = 2;
    private static final int IMPORT_ITEM_NUMBER_1 = 1;
    private static final String GROUPED_COLUMN_NAME = "containers";
    private static String[] declarationLineContainerGroupStructFields = toArray(
            Lists.newArrayList(
                    "joinId",
                    "itemNumber",
                    "sequenceId",
                    GROUPED_COLUMN_NAME
            )
    );
    private static String[] containersExplodeStructFields = toArray(
            Lists.newArrayList(
                    "containerSequenceNumber",
                    "containerNumber"
            )
    );
    private Dataset<DeclarationLineContainerGroup> result;

    @Autowired
    DeclarationLineContainerReader declarationLineContainerReader;

    @Before
    public void setUp() throws Exception {
        DeclarationLineContainerGroupDataset containerGroupDataset = new DeclarationLineContainerGroupDataset(declarationLineContainerReader);
        result = containerGroupDataset.build();
    }

    @Test
    public void validateSchema() {
        String[] fieldNames = result.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), containsInAnyOrder(declarationLineContainerGroupStructFields));
    }

    @Test
    public void validateGroupedColumnSchema() {
        String[] fieldNames = result
                .select(explode(col(GROUPED_COLUMN_NAME)))
                .select(col("col.*"))
                .schema()
                .fieldNames();

        assertThat(Arrays.asList(fieldNames), containsInAnyOrder(containersExplodeStructFields));
    }

    @Test
    public void shouldGroupContainersByLine() {
        assertThat(result.count(), is(8L));
    }

    @Test
    public void shouldAggregateContainerByLine() {
        DeclarationLineContainerGroup firstLine = filterDataset(IMPORT_DECLARATION_ID, IMPORT_ITEM_NUMBER_2);

        assertThat(firstLine.getJoinId(), is(IMPORT_DECLARATION_ID));
        assertThat(firstLine.getItemNumber(), is(IMPORT_ITEM_NUMBER_2));

        assertThat(firstLine.getContainers().size(), is(2));
        assertThat(firstLine.getContainers().get(0).getContainerSequenceNumber(), is(1));
        assertThat(firstLine.getContainers().get(0).getContainerNumber(), is("IM002-21CONTAINER"));

        assertThat(firstLine.getContainers().get(1).getContainerSequenceNumber(), is(2));
        assertThat(firstLine.getContainers().get(1).getContainerNumber(), is("IM002-22CONTAINER"));
    }

    private DeclarationLineContainerGroup filterDataset(String declarationId, int itemNumber) {
        Dataset<DeclarationLineContainerGroup> filter = result
                .filter((DeclarationLineContainerGroup l) ->
                        l.getJoinId().equals(declarationId) && l.getItemNumber() == itemNumber
                )
                .as(DeclarationLineContainerGroup.declarationLineContainerGroupEncoder);

        assertThat(filter.count(), is(1L));

        /* Weird deserialization issue when using dataset.first(). The  java object contains incorrect values, though the dataset.show() displays correct values.
         * Guess, some issue with the way the encoders are used for lists (nested object inside a group type)
         * Work around -  get the first row as json and use jackson to build the java object.
         */
        return parseJson(filter.toJSON().first(), DeclarationLineContainerGroup.class);
    }
}