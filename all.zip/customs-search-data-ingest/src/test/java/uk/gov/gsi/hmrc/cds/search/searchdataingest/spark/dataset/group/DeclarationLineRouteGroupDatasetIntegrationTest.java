package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.group;

import org.apache.spark.sql.Dataset;
import org.assertj.core.util.Lists;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLineRouteGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLineRouteReader;

import java.util.Arrays;

import static org.apache.spark.sql.functions.col;
import static org.apache.spark.sql.functions.explode;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

public class DeclarationLineRouteGroupDatasetIntegrationTest extends SparkTest {

    private static final String IMPORT_DECLARATION_ID = "IM002";
    private static final int IMPORT_ITEM_NUMBER_2 = 2;
    private static final int IMPORT_ITEM_NUMBER_3 = 3;
    private static final String GROUPED_COLUMN_NAME = "routes";
    private static String[] declarationLineRouteGroupStructFields = toArray(
            Lists.newArrayList(
                    "joinId",
                    "itemNumber",
                    "sequenceId",
                    GROUPED_COLUMN_NAME
            )
    );
    private static String[] routeExplodeStructFields = toArray(
            Lists.newArrayList(
                    "routeSequenceNumber",
                    "routeCountryCode"
            )
    );
    private Dataset<DeclarationLineRouteGroup> result;

    @Autowired
    DeclarationLineRouteReader declarationLineRouteReader;

    @Before
    public void setUp() throws Exception {
        DeclarationLineRouteGroupDataset routeGroupDataset = new DeclarationLineRouteGroupDataset(declarationLineRouteReader);
        result = routeGroupDataset.build();
    }

    @Test
    public void validateSchema() {
        String[] fieldNames = result.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), containsInAnyOrder(declarationLineRouteGroupStructFields));
    }

    @Test
    public void validateGroupedColumnSchema() {
        String[] fieldNames = result
                .select(explode(col(GROUPED_COLUMN_NAME)))
                .select(col("col.*"))
                .schema()
                .fieldNames();

        assertThat(Arrays.asList(fieldNames), containsInAnyOrder(routeExplodeStructFields));
    }

    @Test
    public void shouldGroupRouteByLine() {
        assertThat(result.count(), is(8L));
    }

    @Test
    public void shouldAggregateRouteByLine() {
        DeclarationLineRouteGroup firstLine = filterDataset(IMPORT_DECLARATION_ID, IMPORT_ITEM_NUMBER_2);

        assertThat(firstLine.getJoinId(), is(IMPORT_DECLARATION_ID));
        assertThat(firstLine.getItemNumber(), is(IMPORT_ITEM_NUMBER_2));

        assertThat(firstLine.getRoutes().size(), is(2));
        assertThat(firstLine.getRoutes().get(0).getRouteSequenceNumber(), is(1));
        assertThat(firstLine.getRoutes().get(0).getRouteCountryCode(), is("IM002-21ROUTE"));

        assertThat(firstLine.getRoutes().get(1).getRouteSequenceNumber(), is(2));
        assertThat(firstLine.getRoutes().get(1).getRouteCountryCode(), is("IM002-22ROUTE"));
    }

    @Test
    public void shouldAggregateLineWithNullAdditionalInfo() {
        DeclarationLineRouteGroup firstLine = filterDataset(IMPORT_DECLARATION_ID, IMPORT_ITEM_NUMBER_3);

        assertThat(firstLine.getJoinId(), is(IMPORT_DECLARATION_ID));
        assertThat(firstLine.getItemNumber(), is(IMPORT_ITEM_NUMBER_3));

        assertThat(firstLine.getRoutes().size(), is(1));
        assertNull(firstLine.getRoutes().get(0).getRouteSequenceNumber());
        assertNull(firstLine.getRoutes().get(0).getRouteCountryCode());
    }

    private DeclarationLineRouteGroup filterDataset(String declarationId, int itemNumber) {
        Dataset<DeclarationLineRouteGroup> filter = result
                .filter((DeclarationLineRouteGroup l) ->
                        l.getJoinId().equals(declarationId) && l.getItemNumber() == itemNumber
                )
                .as(DeclarationLineRouteGroup.declarationLineRouteGroupEncoder);

        assertThat(filter.count(), is(1L));

        /* Weird deserialization issue when using dataset.first(). The  java object contains incorrect values, though the dataset.show() displays correct values.
         * Guess, some issue with the way the encoders are used for lists (nested object inside a group type)
         * Work around -  get the first row as json and use jackson to build the java object.
         */
        return parseJson(filter.toJSON().first(), DeclarationLineRouteGroup.class);
    }
}
