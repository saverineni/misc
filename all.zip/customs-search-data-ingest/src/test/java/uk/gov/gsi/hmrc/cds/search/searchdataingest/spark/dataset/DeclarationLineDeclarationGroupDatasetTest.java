package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.SparkSession;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.Country;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.Trader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.group.DeclarationLineGroupDataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.DeclarationLineDeclarationGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.*;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLineGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLineReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.HiveSqlService;

import java.util.List;

import static org.apache.spark.sql.functions.col;
import static org.apache.spark.sql.functions.explode;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

public class DeclarationLineDeclarationGroupDatasetTest extends SparkTest {

    @Mock
    DeclarationLineReader mockReader;

    @Mock
    private DeclarationLineGroupDataset mockLineGroupDataset;

    @MockBean
    HiveSqlService sqlService;

    DeclarationLineDeclarationGroupDataset declarationLineDeclarationGroupDataset;

    @Autowired
    SparkSession spark;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        declarationLineDeclarationGroupDataset = new DeclarationLineDeclarationGroupDataset(mockReader, mockLineGroupDataset);
    }

    @Test
    public void declarationLinesAreSortedByItemNumber() {
        givenLinesDataset(
                Lists.newArrayList(
                        getDeclarationLine(ITEM_NUMBER_4),
                        getDeclarationLine(ITEM_NUMBER_2),
                        getDeclarationLine(ITEM_NUMBER_3),
                        getDeclarationLine(ITEM_NUMBER_13)
                ),
                Lists.newArrayList(
                        getDeclarationLineGroup(ITEM_NUMBER_4),
                        getDeclarationLineGroup(ITEM_NUMBER_2),
                        getDeclarationLineGroup(ITEM_NUMBER_3),
                        getDeclarationLineGroup(ITEM_NUMBER_13)
                )
        );
        Dataset<DeclarationLineDeclarationGroup> result = declarationLineDeclarationGroupDataset.build();
        Dataset<DeclarationLine> declarationLineDataset = getDeclarationLineDataset(result);

        thenTheSameNumberOfLinesAreReturned(declarationLineDataset);
        thenTheLinesAreSorted(declarationLineDataset);
    }

    @Test
    public void verifyDeclarationLineIsPopulated() {
        givenLinesDataset(
                Lists.newArrayList(getDeclarationLine(1)),
                Lists.newArrayList(getDeclarationLineGroup(1))
        );

        Dataset<DeclarationLineDeclarationGroup> result = declarationLineDeclarationGroupDataset.build();
        Dataset<DeclarationLine> declarationLineDataset = getDeclarationLineDataset(result);

        thenTheFieldValuesMatch(declarationLineDataset);
    }

    // If heads' spinning looking at data setup, perhaps can look into autowiring readers directly eg) DeclarationLineGroupDatasetIntegrationTest
    private static final String JOIN_ID = "declarationId";
    private static final String COMMODITY_CODE = "commodity code";
    private static final String CLEARANCE_DATE = "2018-02-01 00:00:00.00";
    private static final String CPC = "cpc";
    private static final String ORIGIN_COUNTRY_CODE = "origin country";
    private static final String FIRST_DESTINATION_COUNTRY_CODE = "first dest country";
    private static final String DESTINATION_COUNTRY_CODE = "dest country";
    private static final String DISPATCH_COUNTRY_CODE = "dispatch country";
    private static final String ITEM_CONSIGNEE_NAME = "consignee name";
    private static final String ITEM_CONSIGNEE_TURN = "consignee turn";
    private static final String ITEM_CONSIGNEE_POSTCODE = "consignee postcode";
    private static final String ITEM_CONSIGNOR_NAME = "consignor name";
    private static final String ITEM_CONSIGNOR_TURN = "consignor turn";
    private static final String ITEM_CONSIGNOR_POSTCODE = "consignor postcode";
    private static final String ITEM_DECLARANT_NAME = "declarant name";
    private static final String ITEM_DECLARANT_TURN = "declarant turn";
    private static final String ITEM_DECLARANT_POSTCODE = "declarant postcode";
    private static final String PACKAGE_KIND = "package kind";
    private static final String PACKAGE_COUNT = "package count";
    private static final String PACKAGE_MARKS = "package marks";
    private static final String GOODS_DESCRIPTION = "goods description";
    private static final String GROSS_MASS = "gross mass";
    private static final String PREFERENCE_NUMBER = "preference number";
    private static final String NET_MASS = "net mass";
    private static final String QUOTA_NUMBER = "quota number";
    private static final String PREVIOUS_DOC_CLASS = "previous doc class";
    private static final String SUPPLEMENTARY_UNITS = "supplementary units";
    private static final String INVOICE_CURRENCY = "invoice currency";
    private static final String ITEM_PRICE = "item price";
    private static final String CUSTOMS_VALUE = "customs value";
    private static final String VALUATION_METHOD = "valuation method";
    private static final String AI_STATEMENT = "ai statement";
    private static final String AI_STATEMENT_DESCRIPTION = "statement description";
    private static final String CONTAINER = "container";
    private static final String ROUTE_COUNTRY_CODE = "route country code";
    private static final String VALUATION_ADJUSTMENT_CODE = "valuation adjustment code";
    private static final String VALUATION_ADJUSTMENT_AMOUNT = "valuation adjustment amount";
    private static final String VALUATION_ADJUSTMENT_CURRENCY = "valuation adjustment currency";
    private static final String DECLARATION_CURRENCY = "declaration currency";
    private static final String STATISTICAL_VALUE = "statistical value";
    private static final String TAX_TYPE_CODE = "tax type code";
    private static final String TAX_BASE_AMOUNT = "tax base amount";
    private static final String TAX_BASE_QUANTITY = "tax base quantity";
    private static final String TAX_RATE = "tax rate";
    private static final String TAX_OVERRIDE_CODE = "tax override code";
    private static final String TAX_AMOUNT = "tax amount";
    private static final String TAX_METHOD_PAYMENT = "tax method payment";
    private static final Integer SEQUENCE_ID = 1;
    private static final int ITEM_NUMBER_4 = 4;
    private static final int ITEM_NUMBER_2 = 2;
    private static final int ITEM_NUMBER_3 = 3;
    private static final int ITEM_NUMBER_13 = 13;

    private void thenTheFieldValuesMatch(Dataset<DeclarationLine> declarationLineDataset) {
        DeclarationLine declarationLine = getDeclarationLine(declarationLineDataset);

        assertEquals(COMMODITY_CODE, declarationLine.getCommodityCode());
        assertEquals(CLEARANCE_DATE, declarationLine.getClearanceDate());
        assertEquals(CPC, declarationLine.getCpc());
        assertEquals(ORIGIN_COUNTRY_CODE, declarationLine.getOriginCountry().getCode());
        assertEquals(DESTINATION_COUNTRY_CODE, declarationLine.getItemDestinationCountry().getCode());
        assertEquals(DISPATCH_COUNTRY_CODE, declarationLine.getItemDispatchCountry().getCode());

        Trader itemConsignee = declarationLine.getItemConsignee();
        assertEquals(ITEM_CONSIGNEE_NAME, itemConsignee.getName());
        assertEquals(ITEM_CONSIGNEE_TURN, itemConsignee.getEori());
        assertEquals(ITEM_CONSIGNEE_POSTCODE, itemConsignee.getPostcode());

        Trader itemConsignor = declarationLine.getItemConsignor();
        assertEquals(ITEM_CONSIGNOR_NAME, itemConsignor.getName());
        assertEquals(ITEM_CONSIGNOR_TURN, itemConsignor.getEori());
        assertEquals(ITEM_CONSIGNOR_POSTCODE, itemConsignor.getPostcode());

        Trader itemDeclarant = declarationLine.getItemDeclarant();
        assertEquals(ITEM_DECLARANT_NAME, itemDeclarant.getName());
        assertEquals(ITEM_DECLARANT_TURN, itemDeclarant.getEori());
        assertEquals(ITEM_DECLARANT_POSTCODE, itemDeclarant.getPostcode());

        assertEquals(GOODS_DESCRIPTION, declarationLine.getGoodsDescription());
        assertEquals(GROSS_MASS, declarationLine.getGrossMass());
        assertEquals(PREFERENCE_NUMBER, declarationLine.getPreferenceNumber());
        assertEquals(NET_MASS, declarationLine.getNetMass());
        assertEquals(QUOTA_NUMBER, declarationLine.getQuotaNumber());
        assertEquals(INVOICE_CURRENCY, declarationLine.getInvoiceCurrency());
        assertEquals(ITEM_PRICE, declarationLine.getItemPrice());
        assertEquals(CUSTOMS_VALUE, declarationLine.getCustomsValue());
        assertEquals(VALUATION_METHOD, declarationLine.getValuationMethod());
        assertEquals(VALUATION_ADJUSTMENT_CODE, declarationLine.getValuationAdjustmentCode());
        assertEquals(VALUATION_ADJUSTMENT_AMOUNT, declarationLine.getValuationAdjustmentAmount());
        assertEquals(VALUATION_ADJUSTMENT_CURRENCY, declarationLine.getValuationAdjustmentCurrency());
        assertEquals(DECLARATION_CURRENCY, declarationLine.getDeclarationCurrency());
        assertEquals(STATISTICAL_VALUE, declarationLine.getStatisticalValue());

        DeclarationLineAdditionalInfo additionalInfo = declarationLine.getAdditionalInfo().get(0);
        assertEquals(SEQUENCE_ID, additionalInfo.getAdditionalInfoSequenceNumber());
        assertEquals(AI_STATEMENT, additionalInfo.getAdditionalInfoStatement());
        assertEquals(AI_STATEMENT_DESCRIPTION, additionalInfo.getAdditionalInfoStatementDescription());

        DeclarationLineContainer container = declarationLine.getContainers().get(0);
        assertEquals(SEQUENCE_ID, container.getContainerSequenceNumber());
        assertEquals(CONTAINER, container.getContainerNumber());

        DeclarationLinePackage linePackage = declarationLine.getPackages().get(0);
        assertEquals(SEQUENCE_ID, linePackage.getPackageSequenceNumber());
        assertEquals(PACKAGE_COUNT, linePackage.getPackageCount());
        assertEquals(PACKAGE_KIND, linePackage.getPackageKind());
        assertEquals(PACKAGE_MARKS, linePackage.getPackageMarks());

        DeclarationLinePreviousDocument previousDocument = declarationLine.getPreviousDocuments().get(0);
        assertEquals(SEQUENCE_ID, previousDocument.getPreviousDocumentSequenceNumber());
        assertEquals(PREVIOUS_DOC_CLASS, previousDocument.getPreviousDocumentClass());

        DeclarationLineRoute route = declarationLine.getRoutes().get(0);
        assertEquals(SEQUENCE_ID, route.getRouteSequenceNumber());
        assertEquals(ROUTE_COUNTRY_CODE, route.getRouteCountryCode());

        DeclarationLineTaxLine taxLine = declarationLine.getTaxLines().get(0);
        assertEquals(SEQUENCE_ID, taxLine.getTaxLineSequenceNumber());
        assertEquals(TAX_AMOUNT, taxLine.getTaxAmount());
        assertEquals(TAX_BASE_AMOUNT, taxLine.getTaxBaseAmount());
        assertEquals(TAX_BASE_QUANTITY, taxLine.getTaxBaseQuantity());
        assertEquals(TAX_METHOD_PAYMENT, taxLine.getMethodOfPaymentCode());
        assertEquals(TAX_OVERRIDE_CODE, taxLine.getTaxOverrideCode());
        assertEquals(TAX_RATE, taxLine.getTaxRateIdentifier());
        assertEquals(TAX_TYPE_CODE, taxLine.getTaxTypeCode());
    }

    private void thenTheSameNumberOfLinesAreReturned(Dataset<DeclarationLine> declarationLineDataset) {
        assertThat(declarationLineDataset.count(), is(4L));
    }

    private void thenTheLinesAreSorted(Dataset<DeclarationLine> declarationLineDataset) {
        List<DeclarationLine> declarationLines = declarationLineDataset.collectAsList();

        assertEquals(ITEM_NUMBER_2, declarationLines.get(0).getItemNumber());
        assertEquals(ITEM_NUMBER_3, declarationLines.get(1).getItemNumber());
        assertEquals(ITEM_NUMBER_4, declarationLines.get(2).getItemNumber());
        assertEquals(ITEM_NUMBER_13, declarationLines.get(3).getItemNumber());
    }

    private void givenLinesDataset(List<uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLine> declarationLines, List<DeclarationLineGroup> lineGroups) {
        Dataset<uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLine> dataset = spark.createDataset(declarationLines, Encoders.bean(uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLine.class));
        when(mockReader.declarationLineDataset()).thenReturn(dataset);
        Dataset<DeclarationLineGroup> lineGroupDataset = spark.createDataset(lineGroups, Encoders.bean(DeclarationLineGroup.class));
        when(mockLineGroupDataset.build()).thenReturn(lineGroupDataset);
    }

    private DeclarationLineGroup getDeclarationLineGroup(int itemNumber) {
        DeclarationLineGroup lineGroup = new DeclarationLineGroup();
        lineGroup.setJoinId(JOIN_ID);
        lineGroup.setItemNumber(itemNumber);
        lineGroup.setSequenceId("1");

        DeclarationLineAdditionalInfo additionalInfo = new DeclarationLineAdditionalInfo();
        additionalInfo.setAdditionalInfoSequenceNumber(SEQUENCE_ID);
        additionalInfo.setAdditionalInfoStatement(AI_STATEMENT);
        additionalInfo.setAdditionalInfoStatementDescription(AI_STATEMENT_DESCRIPTION);
        lineGroup.setAdditionalInfo(Lists.newArrayList(additionalInfo));

        DeclarationLineContainer container = new DeclarationLineContainer();
        container.setContainerSequenceNumber(SEQUENCE_ID);
        container.setContainerNumber(CONTAINER);
        lineGroup.setContainers(Lists.newArrayList(container));

        DeclarationLinePackage linePackage = new DeclarationLinePackage();
        linePackage.setPackageSequenceNumber(SEQUENCE_ID);
        linePackage.setPackageCount(PACKAGE_COUNT);
        linePackage.setPackageKind(PACKAGE_KIND);
        linePackage.setPackageMarks(PACKAGE_MARKS);
        lineGroup.setPackages(Lists.newArrayList(linePackage));

        DeclarationLinePreviousDocument previousDocument = new DeclarationLinePreviousDocument();
        previousDocument.setPreviousDocumentSequenceNumber(SEQUENCE_ID);
        previousDocument.setPreviousDocumentClass(PREVIOUS_DOC_CLASS);
        lineGroup.setPreviousDocuments(Lists.newArrayList(previousDocument));

        DeclarationLineRoute route = new DeclarationLineRoute();
        route.setRouteSequenceNumber(SEQUENCE_ID);
        route.setRouteCountryCode(ROUTE_COUNTRY_CODE);
        lineGroup.setRoutes(Lists.newArrayList(route));

        DeclarationLineTaxLine taxLine = new DeclarationLineTaxLine();
        taxLine.setTaxLineSequenceNumber(SEQUENCE_ID);
        taxLine.setTaxTypeCode(TAX_TYPE_CODE);
        taxLine.setTaxBaseAmount(TAX_BASE_AMOUNT);
        taxLine.setTaxBaseQuantity(TAX_BASE_QUANTITY);
        taxLine.setTaxRateIdentifier(TAX_RATE);
        taxLine.setTaxOverrideCode(TAX_OVERRIDE_CODE);
        taxLine.setTaxAmount(TAX_AMOUNT);
        taxLine.setMethodOfPaymentCode(TAX_METHOD_PAYMENT);
        lineGroup.setTaxLines(Lists.newArrayList(taxLine));

        return lineGroup;
    }

    private uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLine getDeclarationLine(int itemNumber) {
        Country originCountry = new Country();
        originCountry.setCode(ORIGIN_COUNTRY_CODE);

        Country dispatchCountry = new Country();
        dispatchCountry.setCode(DISPATCH_COUNTRY_CODE);

        Country firstDestinationCountry = new Country();
        firstDestinationCountry.setCode(FIRST_DESTINATION_COUNTRY_CODE);

        Country destinationCountry = new Country();
        destinationCountry.setCode(DESTINATION_COUNTRY_CODE);

        Trader itemConsignee = new Trader();
        itemConsignee.setEori(ITEM_CONSIGNEE_TURN);
        itemConsignee.setName(ITEM_CONSIGNEE_NAME);
        itemConsignee.setPostcode(ITEM_CONSIGNEE_POSTCODE);

        Trader itemConsignor = new Trader();
        itemConsignor.setEori(ITEM_CONSIGNOR_TURN);
        itemConsignor.setName(ITEM_CONSIGNOR_NAME);
        itemConsignor.setPostcode(ITEM_CONSIGNOR_POSTCODE);

        Trader itemDeclarant = new Trader();
        itemDeclarant.setEori(ITEM_DECLARANT_TURN);
        itemDeclarant.setName(ITEM_DECLARANT_NAME);
        itemDeclarant.setPostcode(ITEM_DECLARANT_POSTCODE);

        uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLine line = new uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLine();
        line.setJoinId(JOIN_ID);
        line.setSequenceId("1");
        line.setItemNumber(itemNumber);
        line.setCommodityCode(COMMODITY_CODE);
        line.setClearanceDate(CLEARANCE_DATE);
        line.setCpc(CPC);
        line.setOriginCountry(originCountry);
        line.setItemDestinationCountry(destinationCountry);
        line.setItemDispatchCountry(dispatchCountry);
        line.setItemConsignee(itemConsignee);
        line.setItemConsignor(itemConsignor);
        line.setItemDeclarant(itemDeclarant);
        line.setGoodsDescription(GOODS_DESCRIPTION);
        line.setGrossMass(GROSS_MASS);
        line.setPreferenceNumber(PREFERENCE_NUMBER);
        line.setNetMass(NET_MASS);
        line.setQuotaNumber(QUOTA_NUMBER);
        line.setSupplementaryUnits(SUPPLEMENTARY_UNITS);
        line.setInvoiceCurrency(INVOICE_CURRENCY);
        line.setItemPrice(ITEM_PRICE);
        line.setCustomsValue(CUSTOMS_VALUE);
        line.setValuationMethod(VALUATION_METHOD);
        line.setValuationAdjustmentCode(VALUATION_ADJUSTMENT_CODE);
        line.setValuationAdjustmentAmount(VALUATION_ADJUSTMENT_AMOUNT);
        line.setValuationAdjustmentCurrency(VALUATION_ADJUSTMENT_CURRENCY);
        line.setDeclarationCurrency(DECLARATION_CURRENCY);
        line.setStatisticalValue(STATISTICAL_VALUE);
        return line;
    }

    private Dataset<DeclarationLine> getDeclarationLineDataset(Dataset<DeclarationLineDeclarationGroup> groupDataset) {
        return groupDataset
                .filter(col("joinId").equalTo(JOIN_ID))
                .select(explode(col("lines")).as("linesAll"))
                .select(col("linesAll.*"))
                .as(Encoders.bean(DeclarationLine.class));
    }

    private DeclarationLine getDeclarationLine(Dataset<DeclarationLine> declarationLineDataset) {
        List<DeclarationLine> declarationLines =
                declarationLineDataset.collectAsList();
        assertThat(declarationLines.size(), is(1));

        return declarationLines.get(0);
    }
}