package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Iterables;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.SearchIngestion;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.elasticsearch.ESIngester;

import java.io.IOException;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public abstract class SparkTest {

    @Autowired
    public HiveDatabaseSetup hiveDatabaseSetup;

    @MockBean
    private ESIngester esIngester;

    @MockBean
    private SearchIngestion searchIngestion;

    @Autowired
    private ObjectMapper objectMapper;

    public <T> T parseJson(String json, Class<T> entityClass) {
        T value = null;
        try {
            value = objectMapper.readValue(json, entityClass);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return value;
    }

    public static String[] toArray(List<String> columns) {
        return Iterables.toArray(columns, String.class);
    }
}
