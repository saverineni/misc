package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader;

import org.apache.velocity.app.VelocityEngine;
import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import uk.gov.gsi.hmrc.cds.search.searchdataingest.test.TestResourceLoader;

public class VelocityHiveSqlServiceTest {
    private static final String DATABASE_NAME = "db_name";

    String template = TestResourceLoader.load(this, "cds.sql.template");

    VelocityEngine velocityEngine = new VelocityEngine();
    VelocityHiveSqlService service;

    @Before
    public void setup() {
        velocityEngine.init();
        service = new VelocityHiveSqlService(DATABASE_NAME, velocityEngine);
    }

    @Test
    public void shouldReplaceTemplatePlaceholders() {
        String expected = TestResourceLoader.load(this, "expected.sql");

        String result = service.replaceSqlPlaceholders(template);

        assertThat(result, is(expected));
    }

    @Test
    public void shouldReplaceTemplatePlaceholdersAddingTheSequenceNumberClause() {
        String expected = TestResourceLoader.load(this, "expectedSequenceNumber.sql");

        String result = service.replaceSqlPlaceholders(template, "1", "2");

        assertThat(result, is(expected));
    }
}
