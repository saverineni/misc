package uk.gov.gsi.hmrc.cds.search.searchdataingest.metric;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.util.StopWatch;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;

public class IngestionMetricCaptureTest {

    IngestionMetricCapture ingestionMetricCapture;
    StopWatch stopwatch;

    @Before
    public void setUp() throws Exception {
        stopwatch = new StopWatch();
        ingestionMetricCapture = new IngestionMetricCapture(stopwatch);
        stopwatch.start();
    }

    @After
    public void tearDown() throws Exception {
        if (stopwatch.isRunning()) {
            stopwatch.stop();
        }
    }

    @Test
    public void startStopWatch() {
        if (stopwatch.isRunning()) {
            stopwatch.stop();
        }

        ingestionMetricCapture.startStopWatch();
        assertThat(ingestionMetricCapture.getIngestionStartDateTime(), is(notNullValue()));
        assertTrue(stopwatch.isRunning());
    }

    @Test
    public void invokeSuccessMetrics() {
        ingestionMetricCapture.invokeSuccessMetrics();
        assertTrue(stopwatch.isRunning());
        assertThat(ingestionMetricCapture.getIngestionState(), is((equalTo("Success"))));
        assertThat(ingestionMetricCapture.getIngestionEndDateTime(), is(nullValue()));
        assertThat(ingestionMetricCapture.getIngestionTimeInSeconds(), is(notNullValue(Double.class)));
    }

    @Test
    public void invokeFailureMetrics() {
        ingestionMetricCapture.invokeFailureMetrics();
        assertTrue(stopwatch.isRunning());
        assertThat(ingestionMetricCapture.getIngestionState(), is((equalTo("Failure"))));
        assertThat(ingestionMetricCapture.getIngestionStartDateTime(), is(nullValue()));
        assertThat(ingestionMetricCapture.getIngestionEndDateTime(), is(nullValue()));
        assertThat(ingestionMetricCapture.getIngestionTimeInSeconds(), is(notNullValue(Double.class)));
    }


    @Test
    public void endStopWatch() {
        ingestionMetricCapture.endStopWatch();
        assertFalse(stopwatch.isRunning());
        assertThat(ingestionMetricCapture.getIngestionEndDateTime(), is(notNullValue()));

    }


}