package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.chief;

import org.apache.spark.sql.Dataset;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLineReader;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

public class ChiefLineReaderIntegrationTest extends SparkTest {

    @Autowired
    private DeclarationLineReader declarationLineReader;

    private static final String IMPORT_HEADER_ID = "IM001";
    private static final int IMPORT_ITEM_NO = 1;

    private static final String EXPORT_HEADER_ID = "EX002";
    private static final int EXPORT_ITEM_NO = 2;

    private Dataset<DeclarationLine> declarationLineDataset;

    @Before
    public void setUp() {
        declarationLineDataset = declarationLineReader.declarationLineDataset();
    }

    @Test
    public void loadingLines() {
        assertThat(declarationLineDataset.count(), is(equalTo(8L)));
    }

    @Test
    public void mappingImportLine() {
        DeclarationLine line = getLine(IMPORT_HEADER_ID, IMPORT_ITEM_NO);
        assertThat(line.getJoinId(), is(equalTo(IMPORT_HEADER_ID)));
        assertThat(line.getSequenceId(), is(equalTo("1")));
        assertThat(line.getItemNumber(), is(IMPORT_ITEM_NO));
        assertThat(line.getItemDispatchCountry().getCode(), is("COUNTRY01"));
        assertThat(line.getItemDestinationCountry(), is(nullValue()));
        assertThat(line.getClearanceDate(), is("2018-02-01 00:00:00.00"));
        assertThat(line.getCpc(), is("CPC01"));
        assertThat(line.getOriginCountry().getCode(), is("COUNTRY99"));
        assertThat(line.getCommodityCode(), is("COMMODITY01"));
        assertThat(line.getItemConsignee().getEori(), is(equalTo("ITEMCONSIGNEE01")));
        assertThat(line.getItemConsignee().getName(), is(equalTo("ITEMCONSIGNEENAME-IM001-01")));
        assertThat(line.getItemConsignee().getPostcode(), is(equalTo("ITEMCONSIGNEEPOSTCODE-IM001-01")));
        assertThat(line.getItemConsignor().getEori(), is(equalTo("ITEMCONSIGNOR01")));
        assertThat(line.getItemConsignor().getName(), is(equalTo("ITEMCONSIGNORNAME-IM001-01")));
        assertThat(line.getItemConsignor().getPostcode(), is(equalTo("ITEMCONSIGNORPOSTCODE-IM001-01")));;
        assertThat(line.getItemRoute(), is("ITEMROE-IM001-01"));
        assertThat(line.getGoodsDescription(), is("GOODSDESC11"));
        assertThat(line.getGrossMass(), is("GROSSMASS11"));
        assertThat(line.getPreferenceNumber(), is("PREFERENCE11"));
        assertThat(line.getNetMass(), is("NETMASS11"));
        assertThat(line.getQuotaNumber(), is("QUOTANO11"));
        assertThat(line.getSupplementaryUnits(), is("ITEMSUPUNIT11"));
        assertThat(line.getInvoiceCurrency(), is("INVOICECURRRENCY01"));
        assertThat(line.getItemPrice(), is("ITEMPRICE11"));
        assertThat(line.getCustomsValue(), is("ITEMCUSTOMSVAL1"));
        assertThat(line.getValuationMethod(), is("VALMETHOD11"));
        assertThat(line.getValuationAdjustmentCode(), is("VALADJUSTCODE11"));
        assertThat(line.getValuationAdjustmentCurrency(), is("VALADJUSTCURRENCY01"));
        assertThat(line.getValuationAdjustmentAmount(), is("VALADJUSTAMT11"));
        assertThat(line.getDeclarationCurrency(), is("DECLARATIONCURRENCY01"));
        assertThat(line.getStatisticalValue(), is("STATVAL11"));
    }

    @Test
    public void mappingImportLineWithNullOriginCountryCode() {
        DeclarationLine line = getLine("IM002", 3);
        assertThat(line.getOriginCountry().getCode(), is(""));
    }

    @Test
    public void mappingExportLine() {
        DeclarationLine line = getLine(EXPORT_HEADER_ID, EXPORT_ITEM_NO);
        assertThat(line.getJoinId(), is(equalTo(EXPORT_HEADER_ID)));
        assertThat(line.getSequenceId(), is(equalTo("1")));
        assertThat(line.getItemNumber(), is(EXPORT_ITEM_NO));
        assertThat(line.getItemDispatchCountry().getCode(), is("ITEMDISPATCHCOUNTRY03"));
        assertThat(line.getItemDestinationCountry().getCode(), is("ITEMDESTCOUNTRY03"));
        assertThat(line.getClearanceDate(), is("2018-02-02 00:00:00.00"));
        assertThat(line.getCpc(), is("CPC03"));
        assertThat(line.getOriginCountry().getCode(), is("COUNTRY97"));
        assertThat(line.getCommodityCode(), is("COMMODITY03"));
        assertThat(line.getItemConsignee().getEori(), is(equalTo("ITEMCONSIGNEE03")));
        assertThat(line.getItemConsignee().getName(), is(equalTo("ITEMCONSIGNEENAME-EX002-02")));
        assertThat(line.getItemConsignee().getPostcode(), is(equalTo("ITEMCONSIGNEEPOSTCODE-EX002-02")));
        assertThat(line.getItemConsignor().getEori(), is(equalTo("ITEMCONSIGNOR03")));
        assertThat(line.getItemConsignor().getName(), is(equalTo("ITEMCONSIGNORNAME-EX002-02")));
        assertThat(line.getItemConsignor().getPostcode(), is(equalTo("ITEMCONSIGNORPOSTCODE-EX002-02")));
        assertThat(line.getItemRoute(), is("ITEMROE-EX002-02"));
        assertThat(line.getGoodsDescription(), is("GOODSDESC22"));
        assertThat(line.getGrossMass(), is("GROSSMASS22"));
        assertThat(line.getPreferenceNumber(), is("PREFERENCE22"));
        assertThat(line.getNetMass(), is("NETMASS22"));
        assertThat(line.getQuotaNumber(), is("QUOTANO22"));
        assertThat(line.getSupplementaryUnits(), is("ITEMSUPUNIT22"));
        assertThat(line.getInvoiceCurrency(), is("INVOICECURRRENCY02"));
        assertThat(line.getItemPrice(), is("ITEMPRICE22"));
        assertThat(line.getCustomsValue(), is(nullValue()));
        assertThat(line.getValuationMethod(), is("VALMETHOD22"));
        assertThat(line.getValuationAdjustmentCode(), is("VALADJUSTCODE22"));
        assertThat(line.getValuationAdjustmentCurrency(), is("VALADJUSTCURRENCY02"));
        assertThat(line.getValuationAdjustmentAmount(), is("VALADJUSTAMT22"));
        assertThat(line.getDeclarationCurrency(), is("DECLARATIONCURRENCY02"));
        assertThat(line.getStatisticalValue(), is("STATVAL22"));

    }

    @Test
    public void mappingExportLineWithNullOriginCountryCode() {
        DeclarationLine line = getLine("EX002", 3);
        assertThat(line.getOriginCountry().getCode(), is(""));
    }

    private DeclarationLine getLine(String id, int itemNo) {
        Dataset<DeclarationLine> filter = declarationLineDataset.filter((DeclarationLine l) -> l.getJoinId().equals(id) && l.getItemNumber() == itemNo);
        assertThat(filter.count(), is(1L));
        return filter.first();
    }
}
