package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.cds;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.Trader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationHeader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationHeaderReader;

import java.util.List;
import java.util.stream.Collectors;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.contains;
import static org.junit.Assert.assertThat;

@TestPropertySource(properties = "sequence.ids=1,2")
@ActiveProfiles({ "test", "cds" })
public class CdsHeaderReaderIntegrationTest extends SparkTest {

    @Autowired
    private DeclarationHeaderReader declarationHeaderReader;

    private static final String[] IMPORT_HEADER_ID_IM001 = { "DEC01", "DEC02", "DEC03", "DEC04" };

    private List<DeclarationHeader> declarationHeaders;

    @Before
    public void setUp() {
        declarationHeaders = declarationHeaderReader.declarationHeaderDataset().collectAsList();
    }

    @Test
    public void loadsHeaders() {
        assertThat(declarationHeaders.stream()
                                     .map(DeclarationHeader::getDeclarationId)
                                     .collect(Collectors.toList()),
                   contains(IMPORT_HEADER_ID_IM001));
    }

    @Test
    public void mappingImportHeader() {
        DeclarationHeader header = getHeader("DEC01");

        assertThat(header.getDeclarationId(), is("DEC01"));
        assertThat(header.getDeclarationSource(), is("CDS"));
        assertThat(header.getImportExportIndicator(), is("Import"));
        assertThat(header.getDeclarationType(), is("IMTYPE1"));
        assertThat(header.getEntryDate(), is("2018-10-01 00:00:00.00"));
        assertThat(header.getRoute(), is("ROE1"));
        assertThat(header.getTransportModeCode(), is("MOT1"));
        assertThat(header.getInlandTransportMode(), is("IMT1"));
        assertThat(header.getTransportId(), is("TRANSPID1"));
        assertThat(header.getTotalPackages(), is("1"));
        assertThat(header.getInvoiceCurrency(), is("CUR1"));
        assertThat(header.getInvoiceTotal(), is("1234"));
        assertThat(header.getSequenceId(), is("1"));
        assertThat(header.getDeclarantRepresentation(), is("1"));
        assertThat(header.getProcessingStatus(),is("GOOD"));
    }


    @Test
    public void countryFieldsShouldBePopulated() {
        DeclarationHeader header = getHeader("DEC01");

        assertThat(header.getDispatchCountry().getCode(), is("COUNTRY_DIS1"));
    }

    @Test
    public void missingCdsFieldsShouldBeNull() {
        DeclarationHeader header = getHeader("DEC01");

        assertThat(header.getEpuNumber(), is(nullValue()));
        assertThat(header.getEntryNumber(), is(nullValue()));
        assertThat(header.getDestinationCountry(), is(nullValue()));
    }

    private DeclarationHeader getHeader(String decId) {
        return declarationHeaders.stream().filter(it -> it.getDeclarationId().equals(decId)).findFirst().get();
    }

    @Test
    public void importTraderProperties() {
        DeclarationHeader header = getHeader("DEC01");

        assertThat(header.getConsignee(), is(trader("CONSIGNEE1")));
        assertThat(header.getConsignor(), is(trader("CONSIGNOR1")));
        assertThat(header.getDeclarant(), is(trader("DECLARANT1")));
    }

    private Trader trader(String eori) {
        Trader trader = new Trader();
        trader.setEori(eori);
        return trader;
    }

    @Test
    public void placeOfLoadingShouldBeSetForCorrectType() {
        DeclarationHeader header = getHeader("DEC02");
        assertThat(header.getPlaceOfLoading(), is("LOC2"));
    }

    @Test
    public void placeOfLoadingShouldBeNullForCorrectType() {
        DeclarationHeader header = getHeader("DEC01");
        assertThat(header.getPlaceOfLoading(), is(nullValue()));
    }

    @Test
    public void goodLocationShouldBeSetForCorrectType() {
        DeclarationHeader header = getHeader("DEC01");
        assertThat(header.getGoodsLocation(), is("LOC1"));
    }

    @Test
    public void goodsLocationShouldBeNullForCorrectType() {
        DeclarationHeader header = getHeader("DEC02");
        assertThat(header.getGoodsLocation(), is(nullValue()));
    }

    @Test
    public void nullStructColumnValuesShouldGiveNullProperties() {
        DeclarationHeader header = getHeader("DEC04");

        assertThat(header.getDispatchCountry(), is(nullValue()));
        assertThat(header.getConsignee(), is(nullValue()));
        assertThat(header.getConsignor(), is(nullValue()));
        assertThat(header.getDeclarant(), is(nullValue()));
    }
}
