package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.FileUtils;
import org.junit.Test;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.Country;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.Trader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLine;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

import static org.assertj.core.api.Assertions.assertThat;

public class DeclarationJsonTest {
    private  ObjectMapper objectMapper = new ObjectMapper();
    @Test
    public void deserializeEmptyDeclaration() throws Exception {
        String content = "{}";
        assertThat( objectMapper.readValue(content, Declaration.class)).isEqualTo(new Declaration());
    }

    @Test
    public void serializeDeclaration() throws Exception {

        Declaration declaration = new Declaration();
        declaration.setDeclarationSource("");
        declaration.setImportExportIndicator("");
        declaration.setSequenceId("");
        declaration.setDeclarationId("");
        declaration.setDestinationCountry(new Country());
        declaration.setDispatchCountry(new Country());
        declaration.setConsignee(new Trader());
        declaration.setConsignor(new Trader());
        declaration.setDeclarant(new Trader());
        declaration.setEntryDate("");
        declaration.setAcceptanceDate("");
        declaration.setEntryNumber("");
        declaration.setEpuNumber("");
        declaration.setGoodsLocation("");
        declaration.setDeclarationType("");
        declaration.setRoute("");
        declaration.setTransportModeCode("");
        declaration.setTotalPackages("");
        declaration.setInvoiceCurrency("");
        declaration.setInvoiceTotal("");
        declaration.setInlandTransportMode("");
        declaration.setPlaceOfLoading("");
        declaration.setDeclarantRepresentation("");
        declaration.setTransportId("");
        declaration.setGrossMass("");
        declaration.setPremisesId("");
        declaration.setCommunicationId("");
        declaration.setProcessingStatus("");
        declaration.setDeclarationCurrency("");
        declaration.setTotalDuty("");
        declaration.setLines(Arrays.asList(createDeclarationLine()));

        String expectedDeclarationJson = getFileContent("declaration/declaration.json");
        JSONAssert.assertEquals(expectedDeclarationJson, objectMapper.writeValueAsString(declaration), JSONCompareMode.STRICT);
    }

    private DeclarationLine createDeclarationLine() {

        DeclarationLine declarationLine = new DeclarationLine();
        declarationLine.setItemNumber(1);
        declarationLine.setClearanceDate("");
        declarationLine.setCpc("");
        declarationLine.setOriginCountry(new Country());
        declarationLine.setItemDispatchCountry(new Country());
        declarationLine.setItemDestinationCountry(new Country());
        declarationLine.setCommodityCode("");
        declarationLine.setItemConsignee(new Trader());
        declarationLine.setItemConsignor(new Trader());
        declarationLine.setItemDeclarant(new Trader());
        declarationLine.setGoodsDescription("");
        declarationLine.setGrossMass("");
        declarationLine.setPreferenceNumber("");
        declarationLine.setNetMass("");
        declarationLine.setQuotaNumber("");
        declarationLine.setSupplementaryUnits("");
        declarationLine.setInvoiceCurrency("");

        declarationLine.setItemPrice("");
        declarationLine.setCustomsValue("");
        declarationLine.setValuationMethod("");
        declarationLine.setValuationAdjustmentCode("");
        declarationLine.setValuationAdjustmentAmount("");
        declarationLine.setValuationAdjustmentCurrency("");
        declarationLine.setDeclarationCurrency("");
        declarationLine.setStatisticalValue("");
        declarationLine.setItemRoute("");
        return declarationLine;
    }

    public static String getFileContent(String fileName) {
        String response = "";
        try {
            Path path = Paths.get(DeclarationJsonTest.class.getClassLoader().getResource(fileName).toURI());
            response = FileUtils.readFileToString(path.toFile(), "UTF-8");
        } catch (IOException | URISyntaxException e) {
            e.printStackTrace();
        }

        return response;
    }

}
