package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.group;

import org.apache.spark.sql.Dataset;
import org.assertj.core.util.Lists;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLineAdditionalInfoGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLineContainerGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLineAdditionalInfoReader;

import java.util.Arrays;

import static org.apache.spark.sql.functions.col;
import static org.apache.spark.sql.functions.explode;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

public class DeclarationLineAdditionalInfoGroupDatasetIntegrationTest extends SparkTest {

    private static final String IMPORT_DECLARATION_ID = "IM002";
    private static final int IMPORT_ITEM_NUMBER_2 = 2;
    private static final int IMPORT_ITEM_NUMBER_1 = 1;
    private static final String GROUPED_COLUMN_NAME = "additionalInfo";
    private static String[] declarationLineAdditionalInfoGroupStructFields = toArray(
            Lists.newArrayList(
                    "joinId",
                    "itemNumber",
                    "sequenceId",
                    GROUPED_COLUMN_NAME
            )
    );
    private static String[] additionalInfoExplodeStructFields = toArray(
            Lists.newArrayList(
                    "additionalInfoSequenceNumber",
                    "additionalInfoStatement",
                    "additionalInfoStatementDescription"
            )
    );
    private Dataset<DeclarationLineAdditionalInfoGroup> result;

    @Autowired
    DeclarationLineAdditionalInfoReader declarationLineAdditionalInfoReader;

    @Before
    public void setUp() throws Exception {
        DeclarationLineAdditionalInfoGroupDataset additionalInfoGroupDataset = new DeclarationLineAdditionalInfoGroupDataset(declarationLineAdditionalInfoReader);
        result = additionalInfoGroupDataset.build();
    }

    @Test
    public void validateSchema() {
        String[] fieldNames = result.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), containsInAnyOrder(declarationLineAdditionalInfoGroupStructFields));
    }

    @Test
    public void validateGroupedColumnSchema() {
        String[] fieldNames = result
                .select(explode(col(GROUPED_COLUMN_NAME)))
                .select(col("col.*"))
                .schema()
                .fieldNames();

        assertThat(Arrays.asList(fieldNames), containsInAnyOrder(additionalInfoExplodeStructFields));
    }

    @Test
    public void shouldGroupAdditionalInfoByLine() {
        assertThat(result.count(), is(8L));
    }

    @Test
    public void shouldAggregateAdditionalInfoByLine() {
        DeclarationLineAdditionalInfoGroup firstLine = filterDataset(IMPORT_DECLARATION_ID, IMPORT_ITEM_NUMBER_2);

        assertThat(firstLine.getJoinId(), is(IMPORT_DECLARATION_ID));
        assertThat(firstLine.getItemNumber(), is(IMPORT_ITEM_NUMBER_2));

        assertThat(firstLine.getAdditionalInfo().size(), is(2));
        assertThat(firstLine.getAdditionalInfo().get(0).getAdditionalInfoSequenceNumber(), is(1));
        assertThat(firstLine.getAdditionalInfo().get(0).getAdditionalInfoStatement(), is("IM002-21AISTMT"));
        assertThat(firstLine.getAdditionalInfo().get(0).getAdditionalInfoStatementDescription(), is("IM002-21STMTDESC"));

        assertThat(firstLine.getAdditionalInfo().get(1).getAdditionalInfoSequenceNumber(), is(2));
        assertThat(firstLine.getAdditionalInfo().get(1).getAdditionalInfoStatement(), is("IM002-22AISTMT"));
        assertThat(firstLine.getAdditionalInfo().get(1).getAdditionalInfoStatementDescription(), is("IM002-22STMTDESC"));
    }

    @Test
    public void shouldAggregateLineWithNullAdditionalInfo() {
        DeclarationLineAdditionalInfoGroup firstLine = filterDataset(IMPORT_DECLARATION_ID, IMPORT_ITEM_NUMBER_1);

        assertThat(firstLine.getJoinId(), is(IMPORT_DECLARATION_ID));
        assertThat(firstLine.getItemNumber(), is(IMPORT_ITEM_NUMBER_1));

        assertThat(firstLine.getAdditionalInfo().size(), is(1));
        assertNull(firstLine.getAdditionalInfo().get(0).getAdditionalInfoSequenceNumber());
        assertNull(firstLine.getAdditionalInfo().get(0).getAdditionalInfoStatement());
        assertNull(firstLine.getAdditionalInfo().get(0).getAdditionalInfoStatementDescription());
    }

    private DeclarationLineAdditionalInfoGroup filterDataset(String declarationId, int itemNumber) {
        Dataset<DeclarationLineAdditionalInfoGroup> filter = result
                .filter((DeclarationLineAdditionalInfoGroup l) ->
                        l.getJoinId().equals(declarationId) && l.getItemNumber() == itemNumber
                )
                .as(DeclarationLineAdditionalInfoGroup.declarationLineAdditionalInfoGroupEncoder);

        assertThat(filter.count(), is(1L));

        /* Weird deserialization issue when using dataset.first(). The  java object contains incorrect values, though the dataset.show() displays correct values.
         * Guess, some issue with the way the encoders are used for lists (nested object inside a group type)
         * Work around -  get the first row as json and use jackson to build the java object.
         */
        return parseJson(filter.toJSON().first(), DeclarationLineAdditionalInfoGroup.class);
    }
}
