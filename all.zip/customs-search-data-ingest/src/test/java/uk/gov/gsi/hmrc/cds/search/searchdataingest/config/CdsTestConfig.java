package uk.gov.gsi.hmrc.cds.search.searchdataingest.config;

import com.google.common.base.Stopwatch;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.metric.IngestionCountReader;

@Profile({"cds"})
@Configuration
public class CdsTestConfig extends TestConfig {

    @MockBean
    public IngestionCountReader ingestionCountReader;

    @Bean
    public Stopwatch stopwatch() {
        return Stopwatch.createUnstarted();
    }

}
