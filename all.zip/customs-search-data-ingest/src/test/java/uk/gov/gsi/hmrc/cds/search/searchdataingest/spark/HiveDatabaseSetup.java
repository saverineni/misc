package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark;

import static java.util.Arrays.asList;

import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.utils.ResourceService;

import java.io.File;
import java.util.List;

import org.apache.spark.sql.SparkSession;

public class HiveDatabaseSetup {

    private SparkSession sparkSession;
    private ResourceService resourceService;

    public HiveDatabaseSetup(SparkSession sparkSession, ResourceService resourceService) {
        this.sparkSession = sparkSession;
        this.resourceService = resourceService;
    }

    private File chiefSourceFilePath = new File("src/test/resources/chief/search/data");
    private File cdsSourceFilePath = new File("src/test/resources/cds/search/data");

    private List<String> chiefTables = asList(
            "imenselect",
            "imendetail",
            "imeiselect",
            "imeidetail",
            "inad",
            "iica",
            "iina",
            "iiai",
            "iict",
            "iipd",
            "iipk",
            "iirt",
            "iitl",
            "nxenselect",
            "nxendetail",
            "nxeiselect",
            "nxeidetail",
            "nxnad",
            "nxica",
            "nxina",
            "nxiai",
            "nxict",
            "nxipd",
            "nxipk",
            "nxirt",
            "nxitl");

    private List<String> cdsTables = asList(
            "cdap_declaration_process_consolidated",
            "cdap_goodsitems_consolidated");

    public void createTestDb() {
        sparkSession.sql("DROP DATABASE IF EXISTS search CASCADE");
        sparkSession.sql("CREATE DATABASE IF NOT EXISTS search");
    }

    public void setUpChiefDb() {
        String chiefSourceFilePathAbsolutePath = chiefSourceFilePath.getAbsolutePath();

        chiefTables.forEach(table -> {
            sparkSession.sql(getDdlFor("chief", table));
            loadDataFor(chiefSourceFilePathAbsolutePath, table);
        });
    }

    public void setUpCdsDb() {
        String cdsSourceFilePathAbsolutePath = cdsSourceFilePath.getAbsolutePath();

        cdsTables.forEach(table -> {
            sparkSession.sql(getDdlFor("cds", table));
            loadDataFor(cdsSourceFilePathAbsolutePath, table);
        });
    }

    private String getDdlFor(String sourceType, String tableName) {
        return resourceService.getResourceAsString(String.format("%s/search/ddl/%s.sql", sourceType, tableName));
    }

    private void loadDataFor(String sourceFilePath, String tableName) {
        String loadfileTemplate = "load data local inpath '%s/%s/part-00000' overwrite into table search.%s";
        sparkSession.sql(String.format(loadfileTemplate, sourceFilePath, tableName, tableName));
    }
}
