package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.chief;

import org.apache.spark.sql.Dataset;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLinePackage;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLinePackageReader;

import static org.apache.spark.sql.functions.column;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class ChiefLinePackageReaderIntegrationTest extends SparkTest {

    @Autowired
    private DeclarationLinePackageReader linePackageReader;

    private static final String IMPORT_HEADER_ID = "IM002";
    private static final int IMPORT_ITEM_NO = 2;
    private static final int IMPORT_PACKAGE_SEQ_NO = 2;

    private static final String EXPORT_HEADER_ID = "EX002";
    private static final int EXPORT_ITEM_NO = 2;
    private static final int EXPORT_PACKAGE_SEQ_NO = 1;

    private Dataset<DeclarationLinePackage> linePackageDataset;

    @Before
    public void setUp() {
        linePackageDataset = linePackageReader.declarationLinePackageDataset();
    }

    @Test
    public void loadingLines() {
        assertThat(linePackageDataset.count(), is(equalTo(10L)));
    }

    @Test
    public void mappingImportLine() {
        DeclarationLinePackage linePackage = getLinePackage(IMPORT_HEADER_ID, IMPORT_ITEM_NO, IMPORT_PACKAGE_SEQ_NO);
        assertThat(linePackage.getJoinId(), is(equalTo(IMPORT_HEADER_ID)));
        assertThat(linePackage.getSequenceId(), is(equalTo("1")));
        assertThat(linePackage.getItemNumber(), is(IMPORT_ITEM_NO));
        assertThat(linePackage.getPackageSequenceNumber(), is(IMPORT_PACKAGE_SEQ_NO));
        assertThat(linePackage.getPackageKind(), is("IM002-22KIND"));
        assertThat(linePackage.getPackageCount(), is("IM002-22COUNT"));
        assertThat(linePackage.getPackageMarks(), is("IM002-22MARK"));
    }

    @Test
    public void mappingExportLine() {
        DeclarationLinePackage linePackage = getLinePackage(EXPORT_HEADER_ID, EXPORT_ITEM_NO, EXPORT_PACKAGE_SEQ_NO);
        assertThat(linePackage.getJoinId(), is(equalTo(EXPORT_HEADER_ID)));
        assertThat(linePackage.getSequenceId(), is(equalTo("1")));
        assertThat(linePackage.getItemNumber(), is(EXPORT_ITEM_NO));
        assertThat(linePackage.getPackageSequenceNumber(), is(EXPORT_PACKAGE_SEQ_NO));
        assertThat(linePackage.getPackageKind(), is("EX002-21KIND"));
        assertThat(linePackage.getPackageCount(), is("EX002-21COUNT"));
        assertThat(linePackage.getPackageMarks(), is("EX002-21MARK"));
    }

//    @Test
//    public void getAllPackagesForLine() {
//
//    }

    private DeclarationLinePackage getLinePackage(String id, int itemNo, int packageSequenceNumber) {
        Dataset<DeclarationLinePackage> filter = linePackageDataset
                .where(column("joinId").isNotNull()
                        .and(column("itemNumber").isNotNull())
                        .and(column("packageSequenceNumber").isNotNull())
                )
                .filter((DeclarationLinePackage l) -> l.getJoinId().equals(id) &&
                                                            l.getItemNumber() == itemNo &&
                                                            l.getPackageSequenceNumber() == packageSequenceNumber
                );
        assertThat(filter.count(), is(1L));
        return filter.first();
    }
}
