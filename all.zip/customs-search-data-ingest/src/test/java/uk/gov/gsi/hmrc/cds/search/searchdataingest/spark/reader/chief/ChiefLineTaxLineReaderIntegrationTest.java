package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.chief;

import org.apache.spark.sql.Dataset;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLineTaxLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLineTaxLineReader;

import static org.apache.spark.sql.functions.column;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class ChiefLineTaxLineReaderIntegrationTest extends SparkTest {

    @Autowired
    private DeclarationLineTaxLineReader lineTaxLineReader;

    private static final String IMPORT_HEADER_ID = "IM002";
    private static final int IMPORT_ITEM_NO = 3;
    private static final int IMPORT_TAXLINE_SEQ_NO = 1;

    private static final String EXPORT_HEADER_ID = "EX002";
    private static final int EXPORT_ITEM_NO = 2;
    private static final int EXPORT_TAXLINE_SEQ_NO = 1;

    private Dataset<DeclarationLineTaxLine> lineTaxLineDataset;

    @Before
    public void setUp() {
        lineTaxLineDataset = lineTaxLineReader.declarationLineTaxLineDataset();
    }

    @Test
    public void loadingLines() {
        assertThat(lineTaxLineDataset.count(), is(equalTo(10L)));
    }

    @Test
    public void mappingImportLine() {
        DeclarationLineTaxLine lineTaxLine = getLineTaxLine(IMPORT_HEADER_ID, IMPORT_ITEM_NO, IMPORT_TAXLINE_SEQ_NO);
        assertThat(lineTaxLine.getJoinId(), is(equalTo(IMPORT_HEADER_ID)));
        assertThat(lineTaxLine.getSequenceId(), is(equalTo("1")));
        assertThat(lineTaxLine.getItemNumber(), is(IMPORT_ITEM_NO));
        assertThat(lineTaxLine.getTaxLineSequenceNumber(), is(IMPORT_TAXLINE_SEQ_NO));
        assertThat(lineTaxLine.getTaxTypeCode(), is("IM002-31TTYCODE"));
        assertThat(lineTaxLine.getTaxBaseAmount(), is("IM002-31TAXBASEAMT"));
        assertThat(lineTaxLine.getTaxBaseQuantity(), is("IM002-31TAXBASEQTY"));
        assertThat(lineTaxLine.getTaxRateIdentifier(), is("IM002-31TAXRATE"));
        assertThat(lineTaxLine.getTaxOverrideCode(), is("IM002-31TAXOVERRIDECODE"));
        assertThat(lineTaxLine.getTaxAmount(), is("IM002-31TAXAMT"));
        assertThat(lineTaxLine.getMethodOfPaymentCode(), is("IM002-31METHODOFPAYMENT"));
        assertThat(lineTaxLine.getTaxBaseAmountCalculated(), is("IM002-31TAXBASEAMTCALC"));
        assertThat(lineTaxLine.getTaxAmountCalculated(), is("IM002-31TAXAMTCALC"));
        assertThat(lineTaxLine.getTaxAmountIndicator(), is("IM002-31TAXAMTINDICATOR"));
    }

    @Test
    public void mappingExportLine() {
        DeclarationLineTaxLine lineTaxLine = getLineTaxLine(EXPORT_HEADER_ID, EXPORT_ITEM_NO, EXPORT_TAXLINE_SEQ_NO);
        assertThat(lineTaxLine.getJoinId(), is(equalTo(EXPORT_HEADER_ID)));
        assertThat(lineTaxLine.getSequenceId(), is(equalTo("1")));
        assertThat(lineTaxLine.getItemNumber(), is(EXPORT_ITEM_NO));
        assertThat(lineTaxLine.getTaxLineSequenceNumber(), is(EXPORT_TAXLINE_SEQ_NO));
        assertThat(lineTaxLine.getTaxTypeCode(), is("EX002-21TTYCODE"));
        assertThat(lineTaxLine.getTaxBaseAmount(), is("EX002-21TAXBASEAMT"));
        assertThat(lineTaxLine.getTaxBaseQuantity(), is("EX002-21TAXBASEQTY"));
        assertThat(lineTaxLine.getTaxRateIdentifier(), is("EX002-21TAXRATE"));
        assertThat(lineTaxLine.getTaxOverrideCode(), is("EX002-21TAXOVERRIDECODE"));
        assertThat(lineTaxLine.getTaxAmount(), is("EX002-21TAXAMT"));
        assertThat(lineTaxLine.getMethodOfPaymentCode(), is("EX002-21METHODOFPAYMENT"));
        assertThat(lineTaxLine.getTaxBaseAmountCalculated(), is("EX002-21TAXBASEAMTCALC"));
        assertThat(lineTaxLine.getTaxAmountCalculated(), is("EX002-21TAXAMTCALC"));
        assertThat(lineTaxLine.getTaxAmountIndicator(), is("EX002-21TAXAMTINDICATOR"));
    }

//    @Test
//    public void getAllContainersForLine() {
//
//    }

    private DeclarationLineTaxLine getLineTaxLine(String id, int itemNo, int taxLineSequenceNumber) {
        Dataset<DeclarationLineTaxLine> filter = lineTaxLineDataset
                .where(column("joinId").isNotNull()
                        .and(column("itemNumber").isNotNull())
                        .and(column("taxLineSequenceNumber").isNotNull())
                )
                .filter((DeclarationLineTaxLine l) -> l.getJoinId().equals(id) &&
                                                            l.getItemNumber() == itemNo &&
                                                            l.getTaxLineSequenceNumber() == taxLineSequenceNumber
                );
        assertThat(filter.count(), is(1L));
        return filter.first();
    }
}
