package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.group;

import com.google.common.collect.Iterables;
import lombok.NoArgsConstructor;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLineAdditionalInfoGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLinePreviousDocumentGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLineAdditionalInfo;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLinePreviousDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLinePreviousDocumentReader;

import static org.apache.spark.sql.functions.*;

@Component
@Profile("!cds")
public class DeclarationLinePreviousDocumentGroupDataset {

    private final DeclarationLinePreviousDocumentReader linePreviousDocumentReader;
    private static Column[] previousDocumentColumns = Iterables.toArray(DeclarationLinePreviousDocument.columns, Column.class);

    @Autowired
    public DeclarationLinePreviousDocumentGroupDataset(DeclarationLinePreviousDocumentReader linePreviousDocumentReader) {
        this.linePreviousDocumentReader = linePreviousDocumentReader;
    }

    public Dataset<DeclarationLinePreviousDocumentGroup> build() {
        Dataset<DeclarationLinePreviousDocument> previousDocumentDataset = linePreviousDocumentReader.declarationLinePreviousDocumentDataset();
        return previousDocumentDataset
                .groupBy(previousDocumentDataset.col(DeclarationLine.PRIMARY_COLUMN), previousDocumentDataset.col(DeclarationLine.ITEM_NUMBER_COLUMN), previousDocumentDataset.col(DeclarationLine.SEQUENCE_ID_COLUMN))
                .agg(
                    sort_array(
                            collect_list(
                                    struct(previousDocumentColumns)
                            )
                    )
                    .alias(DeclarationLinePreviousDocumentGroup.ALIAS)
                )
                .as(DeclarationLinePreviousDocumentGroup.declarationLinePreviousDocumentGroupEncoder);
    }
}
