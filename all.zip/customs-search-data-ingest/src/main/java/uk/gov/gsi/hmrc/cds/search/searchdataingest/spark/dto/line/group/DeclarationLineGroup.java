package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group;

import com.google.common.collect.Lists;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.*;

import java.io.Serializable;
import java.util.List;

@Data
public class DeclarationLineGroup implements Serializable {
    private static final long serialVersionUID = 1L;

    public static Encoder<DeclarationLineGroup> declarationLineGroupEncoder = Encoders.bean(DeclarationLineGroup.class);

    private String joinId;
    private String sequenceId;
    private Integer itemNumber;
    private List<DeclarationLineRoute> routes = Lists.newArrayList();
    private List<DeclarationLinePackage> packages = Lists.newArrayList();
    private List<DeclarationLineContainer> containers = Lists.newArrayList();
    private List<DeclarationLinePreviousDocument> previousDocuments = Lists.newArrayList();
    private List<DeclarationLineAdditionalInfo> additionalInfo = Lists.newArrayList();
    private List<DeclarationLineTaxLine> taxLines = Lists.newArrayList();
}
