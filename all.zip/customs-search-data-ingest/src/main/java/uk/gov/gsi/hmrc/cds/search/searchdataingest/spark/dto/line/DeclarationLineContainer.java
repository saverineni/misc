package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line;

import lombok.Data;

import java.io.Serializable;

@Data
public class DeclarationLineContainer implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer containerSequenceNumber;
    private String containerNumber;

}
