package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group;

import com.google.common.collect.Lists;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLineTaxLine;

import java.io.Serializable;
import java.util.List;

@Data
public class DeclarationLineTaxLineGroup implements Serializable {
    private static final long serialVersionUID = 1L;

    public static Encoder<DeclarationLineTaxLineGroup> declarationLineTaxLineGroupEncoder = Encoders.bean(DeclarationLineTaxLineGroup.class);

    private String joinId;
    private String sequenceId;
    private Integer itemNumber;
    private List<DeclarationLineTaxLine> taxLines = Lists.newArrayList();

    public static final String ALIAS = "taxLines";
}
