package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity;

import com.google.common.collect.ImmutableList;
import lombok.Data;
import org.apache.spark.sql.Column;

import java.io.Serializable;
import java.util.List;

import static org.apache.spark.sql.functions.column;

@Data
public class DeclarationLineTaxLine implements Serializable, BaseEntity {

    private static final long serialVersionUID = 1L;

    private String joinId;
    private String sequenceId;
    private Integer itemNumber;
    private Integer taxLineSequenceNumber;
    private String taxTypeCode;
    private String taxBaseAmount;
    private String taxBaseQuantity;
    private String taxRateIdentifier;
    private String taxOverrideCode;
    private String taxAmount;
    private String methodOfPaymentCode;
    private String taxBaseAmountCalculated;
    private String taxAmountCalculated;
    private String taxAmountIndicator;

    public static List<Column> columns = ImmutableList.of(
            column("taxLineSequenceNumber"),
            column("taxTypeCode"),
            column("taxBaseAmount"),
            column("taxBaseQuantity"),
            column("taxRateIdentifier"),
            column("taxOverrideCode"),
            column("taxAmount"),
            column("methodOfPaymentCode"),
            column("taxBaseAmountCalculated"),
            column("taxAmountCalculated"),
            column("taxAmountIndicator")
    );
}
