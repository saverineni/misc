package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.group;

import com.google.common.collect.Iterables;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLineAdditionalInfoGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLineTaxLineGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLineAdditionalInfo;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLineTaxLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLineAdditionalInfoReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLineTaxLineReader;

import static org.apache.spark.sql.functions.*;

@Component
@Profile("!cds")
public class DeclarationLineAdditionalInfoGroupDataset {

    private final DeclarationLineAdditionalInfoReader declarationLineAdditionalInfoReader;
    private static Column[] additionalInfoColumns = Iterables.toArray(DeclarationLineAdditionalInfo.columns, Column.class);

    @Autowired
    public DeclarationLineAdditionalInfoGroupDataset(DeclarationLineAdditionalInfoReader declarationLineAdditionalInfoReader) {
        this.declarationLineAdditionalInfoReader = declarationLineAdditionalInfoReader;
    }

    public Dataset<DeclarationLineAdditionalInfoGroup> build() {
        Dataset<DeclarationLineAdditionalInfo> additionalInfoDataset = declarationLineAdditionalInfoReader.declarationLineAdditionalInfoDataset();
        return additionalInfoDataset
                .groupBy(additionalInfoDataset.col(DeclarationLine.PRIMARY_COLUMN), additionalInfoDataset.col(DeclarationLine.ITEM_NUMBER_COLUMN), additionalInfoDataset.col(DeclarationLine.SEQUENCE_ID_COLUMN))
                .agg(
                    sort_array(
                            collect_list(
                                    struct(additionalInfoColumns)
                            )
                    )
                    .alias(DeclarationLineAdditionalInfoGroup.ALIAS)
                )
                .as(DeclarationLineAdditionalInfoGroup.declarationLineAdditionalInfoGroupEncoder);
    }
}
