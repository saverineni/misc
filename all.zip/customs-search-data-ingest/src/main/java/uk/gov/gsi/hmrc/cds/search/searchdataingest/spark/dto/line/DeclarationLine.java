package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line;

import com.google.common.collect.Lists;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.Country;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.Trader;

import java.io.Serializable;
import java.util.List;

@Data
public class DeclarationLine implements Serializable {
    private static final long serialVersionUID = 1L;

//    private String sequenceId;
    private int itemNumber;
    private String clearanceDate;
    private String cpc;
    private Country originCountry;
    private Country itemDispatchCountry;
    private Country itemDestinationCountry;
    private String commodityCode;
    private Trader itemConsignee;
    private Trader itemConsignor;
    private Trader itemDeclarant;
    private String goodsDescription;
    private String grossMass;
    private String preferenceNumber;
    private String netMass;
    private String quotaNumber;
    private String supplementaryUnits;
    private String invoiceCurrency;
    private String itemPrice;
    private String customsValue;
    private String valuationMethod;
    private String valuationAdjustmentCode;
    private String valuationAdjustmentAmount;
    private String valuationAdjustmentCurrency;
    private String declarationCurrency;
    private String statisticalValue;
    private String itemRoute;
    private List<DeclarationLineRoute> routes = Lists.newArrayList();
    private List<DeclarationLinePackage> packages = Lists.newArrayList();
    private List<DeclarationLineContainer> containers = Lists.newArrayList();
    private List<DeclarationLinePreviousDocument> previousDocuments = Lists.newArrayList();
    private List<DeclarationLineAdditionalInfo> additionalInfo = Lists.newArrayList();
    private List<DeclarationLineTaxLine> taxLines = Lists.newArrayList();

}
