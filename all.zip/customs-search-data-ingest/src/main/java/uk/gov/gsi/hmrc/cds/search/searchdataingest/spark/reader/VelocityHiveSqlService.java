package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader;

import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.context.Context;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import static java.util.stream.Collectors.joining;
import static java.util.stream.Stream.of;

import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.HiveSqlService;

@Component
public class VelocityHiveSqlService implements HiveSqlService {

    private String databaseName;
    private VelocityEngine velocity;

    VelocityHiveSqlService(@Value("${hive.database.name}") String databaseName,
                           VelocityEngine velocity) {
        this.databaseName = databaseName;
        this.velocity = velocity;
    }

    @Override
    public String replaceSqlPlaceholders(String sqlTemplate) {
        Map<String, Object> properties = new HashMap<>();

        properties.put("databaseName", databaseName);

        return evaluateSqlTemplate(sqlTemplate, properties);
    }

    private String evaluateSqlTemplate(String sqlTemplate, Map<String, Object> properties) {
        Context context = new VelocityContext(properties);
        Writer writer = new StringWriter();
        velocity.evaluate(context, writer, "sql", sqlTemplate);

        return writer.toString();
    }

    @Override
    public String replaceSqlPlaceholders(String sqlTemplate, String... sequenceIds) {
        Map<String, Object> properties = new HashMap<>();
        properties.put("databaseName", databaseName);
        properties.put("sequenceIds", whereClause(sequenceIds));

        return evaluateSqlTemplate(sqlTemplate, properties);

    }

    private String whereClause(String... sequenceIds) {
        return of(sequenceIds)
                .map(it -> "\"" + it + "\"")
                .collect(joining(","));
    }
}
