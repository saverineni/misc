package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.group;

import com.google.common.collect.Iterables;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLineContainerGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLineContainer;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLineContainerReader;

import static org.apache.spark.sql.functions.*;

@Component
@Profile("!cds")
public class DeclarationLineContainerGroupDataset {

    private final DeclarationLineContainerReader lineContainerReader;
    private static Column[] containerColumns = Iterables.toArray(DeclarationLineContainer.columns, Column.class);

    @Autowired
    public DeclarationLineContainerGroupDataset(DeclarationLineContainerReader lineContainerReader) {
        this.lineContainerReader = lineContainerReader;
    }

    public Dataset<DeclarationLineContainerGroup> build() {
        Dataset<DeclarationLineContainer> lineContainerDataset = lineContainerReader.declarationLineContainerDataset();
        return lineContainerDataset
                .groupBy(lineContainerDataset.col(DeclarationLine.PRIMARY_COLUMN), lineContainerDataset.col(DeclarationLine.ITEM_NUMBER_COLUMN), lineContainerDataset.col(DeclarationLine.SEQUENCE_ID_COLUMN))
                .agg(
                    sort_array(
                            collect_list(
                                    struct(containerColumns)
                            )
                    )
                    .alias(DeclarationLineContainerGroup.ALIAS)
                )
                .as(DeclarationLineContainerGroup.declarationLineContainerGroupEncoder);
    }
}
