package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class DeclarationLinePackage implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer packageSequenceNumber;
    private String packageCount;
    private String packageKind;
    private String packageMarks;

}
