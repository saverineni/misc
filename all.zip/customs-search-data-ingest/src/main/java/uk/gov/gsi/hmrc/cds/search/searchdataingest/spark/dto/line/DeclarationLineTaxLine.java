package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line;

import lombok.Data;

import java.io.Serializable;

@Data
public class DeclarationLineTaxLine implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer taxLineSequenceNumber;
    private String taxTypeCode;
    private String taxBaseAmount;
    private String taxBaseQuantity;
    private String taxRateIdentifier;
    private String taxOverrideCode;
    private String taxAmount;
    private String methodOfPaymentCode;
    private String taxBaseAmountCalculated;
    private String taxAmountCalculated;
    private String taxAmountIndicator;

}
