package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset;

import com.google.common.collect.Iterables;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.group.DeclarationLineGroupDataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.DeclarationLineDeclarationGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLineGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationHeader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLineReader;

import java.util.Objects;

import static org.apache.spark.sql.functions.*;

@Component
public class DeclarationLineDeclarationGroupDataset {

    private static final String LEFT_OUTER_JOIN = "left_outer";

    private final DeclarationLineReader declarationLineReader;

    private final DeclarationLineGroupDataset lineGroupDataset;

    private static Column[] lineColumns = Iterables.toArray(
            Iterables.concat(
                    DeclarationLine.columns,
                    DeclarationLine.derivedColumns
            ),
            Column.class);

    public DeclarationLineDeclarationGroupDataset(@Autowired DeclarationLineReader declarationLineReader, @Autowired(required = false) DeclarationLineGroupDataset lineGroupDataset) {
        this.declarationLineReader = declarationLineReader;
        this.lineGroupDataset = lineGroupDataset;
    }

    public Dataset<DeclarationLineDeclarationGroup> build() {
        Objects.requireNonNull(this.declarationLineReader, "DeclarationLineReader cannot be null. Check spring context");
        if (Objects.isNull(this.lineGroupDataset)) {
            Dataset<DeclarationLine> declarationLineDataset = declarationLineReader.declarationLineDataset();
            return declarationLineDataset
                    .groupBy(declarationLineDataset.col(DeclarationHeader.PRIMARY_COLUMN), declarationLineDataset.col(DeclarationHeader.SECONDARY_COLUMN))
                    .agg(
                            sort_array(
                                    collect_list(
                                            struct(lineColumns)
                                    )
                            )
                                    .alias(DeclarationLineDeclarationGroup.ALIAS)
                    )
                    .as(DeclarationLineDeclarationGroup.declarationLineDeclarationGroupEncoder);

        } else {
            Dataset<DeclarationLine> declarationLineDataset = declarationLineReader.declarationLineDataset();
            Dataset<DeclarationLineGroup> declarationLineGroupDataset = lineGroupDataset.build();
            return declarationLineDataset
                    .join(declarationLineGroupDataset, DeclarationLine.joinColumns, LEFT_OUTER_JOIN)
                    .groupBy(declarationLineDataset.col(DeclarationHeader.PRIMARY_COLUMN), declarationLineDataset.col(DeclarationHeader.SECONDARY_COLUMN))
                    .agg(
                            sort_array(
                                    collect_list(
                                            struct(lineColumns)
                                    )
                            )
                                    .alias(DeclarationLineDeclarationGroup.ALIAS)
                    )
                    .as(DeclarationLineDeclarationGroup.declarationLineDeclarationGroupEncoder);
        }
    }
}
