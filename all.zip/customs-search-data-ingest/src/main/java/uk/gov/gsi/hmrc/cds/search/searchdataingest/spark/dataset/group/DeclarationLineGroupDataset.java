package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.group;

import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.*;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLineReader;

import static org.apache.spark.sql.functions.column;

@Component
@Profile("!cds")
public class DeclarationLineGroupDataset {

    private static final String LEFT_OUTER_JOIN = "left_outer";

    private final DeclarationLineReader declarationLineReader;
    private final DeclarationLineRouteGroupDataset lineRouteGroupDataset;
    private final DeclarationLinePackageGroupDataset linePackageGroupDataset;
    private final DeclarationLineContainerGroupDataset lineContainerGroupDataset;
    private final DeclarationLinePreviousDocumentGroupDataset linePreviousDocumentGroupDataset;
    private final DeclarationLineAdditionalInfoGroupDataset lineAdditionalInfoGroupDataset;
    private final DeclarationLineTaxLineGroupDataset lineTaxLineGroupDataset;

    @Autowired
    public DeclarationLineGroupDataset(DeclarationLineReader declarationLineReader,
                                       DeclarationLineRouteGroupDataset lineRouteGroupDataset,
                                       DeclarationLinePackageGroupDataset linePackageGroupDataset,
                                       DeclarationLineContainerGroupDataset lineContainerGroupDataset,
                                       DeclarationLinePreviousDocumentGroupDataset linePreviousDocumentGroupDataset,
                                       DeclarationLineAdditionalInfoGroupDataset lineAdditionalInfoGroupDataset,
                                       DeclarationLineTaxLineGroupDataset lineTaxLineGroupDataset) {
        this.declarationLineReader = declarationLineReader;
        this.lineRouteGroupDataset = lineRouteGroupDataset;
        this.linePackageGroupDataset = linePackageGroupDataset;
        this.lineContainerGroupDataset = lineContainerGroupDataset;
        this.linePreviousDocumentGroupDataset = linePreviousDocumentGroupDataset;
        this.lineAdditionalInfoGroupDataset = lineAdditionalInfoGroupDataset;
        this.lineTaxLineGroupDataset = lineTaxLineGroupDataset;
    }

    public Dataset<DeclarationLineGroup> build() {
        Dataset<DeclarationLine> declarationLineDataset = declarationLineReader.declarationLineDataset();
        Dataset<DeclarationLineRouteGroup> routeGroupDataset = lineRouteGroupDataset.build();
        Dataset<DeclarationLinePackageGroup> packageGroupDataset = linePackageGroupDataset.build();
        Dataset<DeclarationLineContainerGroup> containerGroupDataset = lineContainerGroupDataset.build();
        Dataset<DeclarationLinePreviousDocumentGroup> previousDocumentGroupDataset = linePreviousDocumentGroupDataset.build();
        Dataset<DeclarationLineAdditionalInfoGroup> additionalInfoGroupDataset = lineAdditionalInfoGroupDataset.build();
        Dataset<DeclarationLineTaxLineGroup> taxLineGroupDataset = lineTaxLineGroupDataset.build();

        return declarationLineDataset.select(column(DeclarationLine.PRIMARY_COLUMN), column(DeclarationLine.ITEM_NUMBER_COLUMN), column(DeclarationLine.SEQUENCE_ID_COLUMN))
                .join(routeGroupDataset, DeclarationLine.joinColumns, LEFT_OUTER_JOIN)
                .join(packageGroupDataset, DeclarationLine.joinColumns, LEFT_OUTER_JOIN)
                .join(containerGroupDataset, DeclarationLine.joinColumns, LEFT_OUTER_JOIN)
                .join(previousDocumentGroupDataset, DeclarationLine.joinColumns, LEFT_OUTER_JOIN)
                .join(additionalInfoGroupDataset, DeclarationLine.joinColumns, LEFT_OUTER_JOIN)
                .join(taxLineGroupDataset, DeclarationLine.joinColumns, LEFT_OUTER_JOIN)
                .as(DeclarationLineGroup.declarationLineGroupEncoder);
    }

}
