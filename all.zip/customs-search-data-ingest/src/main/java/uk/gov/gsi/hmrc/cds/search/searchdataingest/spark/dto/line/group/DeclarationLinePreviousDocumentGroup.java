package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group;

import com.google.common.collect.Lists;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLineAdditionalInfo;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLinePreviousDocument;

import java.io.Serializable;
import java.util.List;

@Data
public class DeclarationLinePreviousDocumentGroup implements Serializable {
    private static final long serialVersionUID = 1L;

    public static Encoder<DeclarationLinePreviousDocumentGroup> declarationLinePreviousDocumentGroupEncoder = Encoders.bean(DeclarationLinePreviousDocumentGroup.class);

    private String joinId;
    private String sequenceId;
    private Integer itemNumber;
    private List<DeclarationLinePreviousDocument> previousDocuments = Lists.newArrayList();

    public static final String ALIAS = "previousDocuments";
}
