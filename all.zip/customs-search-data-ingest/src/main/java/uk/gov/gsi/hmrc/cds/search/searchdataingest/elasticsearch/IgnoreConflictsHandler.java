package uk.gov.gsi.hmrc.cds.search.searchdataingest.elasticsearch;

import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.hadoop.handler.HandlerResult;
import org.elasticsearch.hadoop.rest.bulk.handler.BulkWriteErrorHandler;
import org.elasticsearch.hadoop.rest.bulk.handler.BulkWriteFailure;
import org.elasticsearch.hadoop.rest.bulk.handler.DelayableErrorCollector;

@Slf4j
public class IgnoreConflictsHandler extends BulkWriteErrorHandler {

    @Override
    public HandlerResult onError(BulkWriteFailure entry, DelayableErrorCollector<byte[]> collector) throws Exception {
        if (entry.getResponseCode() == 409) {
            log.warn(String.format("Encountered conflict response. Ignoring old data: %s", entry.getException().getMessage()));
            return HandlerResult.HANDLED;
        }
        return collector.pass("Not a conflict response code.");
    }

}
