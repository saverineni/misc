package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark;

import lombok.Data;

@Data
public class Trader {
    private String eori;
    private String name;
    private String postcode;
}
