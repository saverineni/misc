package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader;

import org.apache.spark.sql.Dataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLinePackage;

/**
 * Bean created in SparkReaderConfig.
 */
public class DeclarationLinePackageReader {

    private SqlReader<DeclarationLinePackage> sqlReader;
    private final String hiveSql;

    public DeclarationLinePackageReader(SqlReader<DeclarationLinePackage> sqlReader, String hiveSql) {
        this.sqlReader = sqlReader;
        this.hiveSql = hiveSql;
    }

    public Dataset<DeclarationLinePackage> declarationLinePackageDataset() {
        return sqlReader.buildDataset(hiveSql);
    }

}
