package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.group;

import com.google.common.collect.Iterables;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLineRouteGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLineRoute;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLineRouteReader;

import static org.apache.spark.sql.functions.*;

@Component
@Profile("!cds")
public class DeclarationLineRouteGroupDataset {

    private final DeclarationLineRouteReader lineRouteReader;
    private static Column[] routeColumns = Iterables.toArray(DeclarationLineRoute.columns, Column.class);

    @Autowired
    public DeclarationLineRouteGroupDataset(DeclarationLineRouteReader lineRouteReader) {
        this.lineRouteReader = lineRouteReader;
    }

    public Dataset<DeclarationLineRouteGroup> build() {
        Dataset<DeclarationLineRoute> lineRouteDataset = lineRouteReader.declarationLineRouteDataset();
        return lineRouteDataset
                .groupBy(lineRouteDataset.col(DeclarationLine.PRIMARY_COLUMN), lineRouteDataset.col(DeclarationLine.ITEM_NUMBER_COLUMN), lineRouteDataset.col(DeclarationLine.SEQUENCE_ID_COLUMN))
                .agg(
                    sort_array(
                            collect_list(
                                    struct(routeColumns)
                            )
                    )
                    .alias(DeclarationLineRouteGroup.ALIAS)
                )
                .as(DeclarationLineRouteGroup.declarationLineRouteGroupEncoder);
    }
}
