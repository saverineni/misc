package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader;

import org.apache.spark.sql.Dataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLineTaxLine;

/**
 * Bean created in SparkReaderConfig.
 */
public class DeclarationLineTaxLineReader {

    private SqlReader<DeclarationLineTaxLine> sqlReader;
    private final String hiveSql;

    public DeclarationLineTaxLineReader(SqlReader<DeclarationLineTaxLine> sqlReader, String hiveSql) {
        this.sqlReader = sqlReader;
        this.hiveSql = hiveSql;
    }

    public Dataset<DeclarationLineTaxLine> declarationLineTaxLineDataset() {
        return sqlReader.buildDataset(hiveSql);
    }

}
