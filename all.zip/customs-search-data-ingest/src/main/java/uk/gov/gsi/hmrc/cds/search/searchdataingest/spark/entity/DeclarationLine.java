package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity;

import com.google.common.collect.ImmutableList;
import lombok.Data;
import org.apache.spark.sql.Column;
import scala.collection.mutable.Seq;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.Country;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.Trader;

import java.io.Serializable;
import java.util.List;

import static org.apache.spark.sql.functions.column;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.BaseEntity.joinExpression;

@Data
public class DeclarationLine implements Serializable, BaseEntity {

    private static final long serialVersionUID = 1L;

    public static final String PRIMARY_COLUMN = "joinId";
    public static final String ITEM_NUMBER_COLUMN = "itemNumber";
    public static final String SEQUENCE_ID_COLUMN = "sequenceId";

    private String joinId; // iekey
    private String sequenceId;
    private int itemNumber;
    private Country itemDispatchCountry;
    private Country itemDestinationCountry;
    private String clearanceDate;
    private String cpc;
    private Country originCountry;
    private String commodityCode;
    private Trader itemConsignee;
    private Trader itemConsignor;
    private Trader itemDeclarant;
    private String goodsDescription;
    private String grossMass;
    private String preferenceNumber;
    private String netMass;
    private String quotaNumber;
    private String supplementaryUnits;
    private String invoiceCurrency;
    private String itemPrice;
    private String customsValue;
    private String valuationMethod;
    private String valuationAdjustmentCode;
    private String valuationAdjustmentAmount;
    private String valuationAdjustmentCurrency;
    private String declarationCurrency;
    private String statisticalValue;
    private String itemRoute;

    public static List<Column> columns = ImmutableList.of(
            column("itemNumber"),
            column("itemDispatchCountry"),
            column("itemDestinationCountry"),
            column("clearanceDate"),
            column("cpc"),
            column("originCountry"),
            column("commodityCode"),
            column("itemConsignee"),
            column("itemConsignor"),
            column("itemDeclarant"),
            column("goodsDescription"),
            column("grossMass"),
            column("preferenceNumber"),
            column("netMass"),
            column("quotaNumber"),
            column("supplementaryUnits"),
            column("invoiceCurrency"),
            column("itemPrice"),
            column("customsValue"),
            column("valuationMethod"),
            column("valuationAdjustmentCode"),
            column("valuationAdjustmentAmount"),
            column("valuationAdjustmentCurrency"),
            column("declarationCurrency"),
            column("statisticalValue"),
            column("itemRoute")
    );

    public static List<Column> derivedColumns = ImmutableList.of(
            column("routes"),
            column("packages"),
            column("containers"),
            column("previousDocuments"),
            column("additionalInfo"),
            column("taxLines")
    );

    public static Seq<String> joinColumns = joinExpression(PRIMARY_COLUMN, ITEM_NUMBER_COLUMN, SEQUENCE_ID_COLUMN);
}
