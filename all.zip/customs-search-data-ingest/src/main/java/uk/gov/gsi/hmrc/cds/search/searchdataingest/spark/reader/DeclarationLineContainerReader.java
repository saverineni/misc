package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader;

import org.apache.spark.sql.Dataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLineContainer;

/**
 * Bean created in SparkReaderConfig.
 */
public class DeclarationLineContainerReader {

    private SqlReader<DeclarationLineContainer> sqlReader;
    private final String hiveSql;

    public DeclarationLineContainerReader(SqlReader<DeclarationLineContainer> sqlReader, String hiveSql) {
        this.sqlReader = sqlReader;
        this.hiveSql = hiveSql;
    }

    public Dataset<DeclarationLineContainer> declarationLineContainerDataset() {
        return sqlReader.buildDataset(hiveSql);
    }

}
