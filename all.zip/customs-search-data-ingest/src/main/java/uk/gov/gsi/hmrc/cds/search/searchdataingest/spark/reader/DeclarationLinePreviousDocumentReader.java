package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader;

import org.apache.spark.sql.Dataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLinePreviousDocument;

/**
 * Bean created in SparkReaderConfig.
 */
public class DeclarationLinePreviousDocumentReader {

    private SqlReader<DeclarationLinePreviousDocument> sqlReader;
    private final String hiveSql;

    public DeclarationLinePreviousDocumentReader(SqlReader<DeclarationLinePreviousDocument> sqlReader, String hiveSql) {
        this.sqlReader = sqlReader;
        this.hiveSql = hiveSql;
    }

    public Dataset<DeclarationLinePreviousDocument> declarationLinePreviousDocumentDataset() {
        return sqlReader.buildDataset(hiveSql);
    }

}
