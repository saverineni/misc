package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group;

import com.google.common.collect.Lists;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLineContainer;

import java.io.Serializable;
import java.util.List;

@Data
public class DeclarationLineContainerGroup implements Serializable {
    private static final long serialVersionUID = 1L;
    public static Encoder<DeclarationLineContainerGroup> declarationLineContainerGroupEncoder = Encoders.bean(DeclarationLineContainerGroup.class);

    private String joinId;
    private String sequenceId;
    private Integer itemNumber;
    private List<DeclarationLineContainer> containers = Lists.newArrayList();

    public static final String ALIAS = "containers";
}
