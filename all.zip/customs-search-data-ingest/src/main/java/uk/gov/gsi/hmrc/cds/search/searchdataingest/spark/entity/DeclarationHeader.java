package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity;

import lombok.Data;
import scala.collection.mutable.Seq;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.Country;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.Trader;

import java.io.Serializable;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.BaseEntity.joinExpression;

@Data
public class DeclarationHeader implements Serializable, BaseEntity {
    private static final long serialVersionUID = 1L;

    public static final String PRIMARY_COLUMN = "joinId";
    public static final String SECONDARY_COLUMN = "sequenceId";

    private String joinId;
    private String declarationSource;
    private String importExportIndicator;
    private String declarationId;
    private String sequenceId;
    private String epuNumber;
    private String entryNumber;
    private String entryDate;
    private String acceptanceDate;
    private String route;
    private Country dispatchCountry;
    private Country destinationCountry;
    private Trader consignee;
    private Trader consignor;
    private Trader declarant;
    private String declarationType;
    private String declarantRepresentation;
    private String goodsLocation;
    private String transportModeCode;
    private String totalPackages;
    private String invoiceCurrency;
    private String invoiceTotal;
    private String inlandTransportMode;
    private String placeOfLoading;
    private String transportId;
    private String grossMass;
    private String premisesId;
    private String communicationId;
    private String processingStatus;
    private String declarationCurrency;
    private String totalDuty;

    public static Seq<String> joinColumns = joinExpression(PRIMARY_COLUMN, SECONDARY_COLUMN);
}
