package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader;

import org.apache.spark.sql.Dataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLineRoute;

/**
 * Bean created in SparkReaderConfig.
 */
public class DeclarationLineRouteReader {

    private SqlReader<DeclarationLineRoute> sqlReader;
    private final String hiveSql;

    public DeclarationLineRouteReader(SqlReader<DeclarationLineRoute> sqlReader, String hiveSql) {
        this.sqlReader = sqlReader;
        this.hiveSql = hiveSql;
    }

    public Dataset<DeclarationLineRoute> declarationLineRouteDataset() {
        return sqlReader.buildDataset(hiveSql);
    }

}
