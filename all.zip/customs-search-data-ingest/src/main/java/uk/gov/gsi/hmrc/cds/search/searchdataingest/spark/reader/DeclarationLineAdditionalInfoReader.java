package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader;

import org.apache.spark.sql.Dataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLineAdditionalInfo;

/**
 * Bean created in SparkReaderConfig.
 */
public class DeclarationLineAdditionalInfoReader {

    private SqlReader<DeclarationLineAdditionalInfo> sqlReader;
    private final String hiveSql;

    public DeclarationLineAdditionalInfoReader(SqlReader<DeclarationLineAdditionalInfo> sqlReader, String hiveSql) {
        this.sqlReader = sqlReader;
        this.hiveSql = hiveSql;
    }

    public Dataset<DeclarationLineAdditionalInfo> declarationLineAdditionalInfoDataset() {
        return sqlReader.buildDataset(hiveSql);
    }

}
