package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader;

import org.apache.spark.sql.Dataset;

import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationHeader;

/**
 * Bean created in SparkReaderConfig.
 */
public class DeclarationHeaderReader{

    private final SqlReader<DeclarationHeader> sqlReader;
    private final String hiveSql;

    public DeclarationHeaderReader(SqlReader<DeclarationHeader> sqlReader, String hiveSql) {
        this.sqlReader = sqlReader;
        this.hiveSql = hiveSql;
    }

    public Dataset<DeclarationHeader> declarationHeaderDataset() {
        return sqlReader.buildDataset(hiveSql);
    }
}
