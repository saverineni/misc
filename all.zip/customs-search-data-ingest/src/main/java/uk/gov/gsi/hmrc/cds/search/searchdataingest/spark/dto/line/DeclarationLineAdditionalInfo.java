package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line;

import lombok.Data;

import java.io.Serializable;

@Data
public class DeclarationLineAdditionalInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer additionalInfoSequenceNumber;
    private String additionalInfoStatement;
    private String additionalInfoStatementDescription;

}
