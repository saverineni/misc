package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity;

import com.google.common.collect.Lists;
import scala.collection.JavaConversions;
import scala.collection.mutable.Seq;

public interface BaseEntity {
    static Seq<String> joinExpression(String... joinColumns) {
        return JavaConversions
                .asScalaBuffer(Lists.newArrayList(joinColumns));
    }
}
