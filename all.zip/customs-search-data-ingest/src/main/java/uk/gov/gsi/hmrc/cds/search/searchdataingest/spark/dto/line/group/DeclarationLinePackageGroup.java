package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group;

import com.google.common.collect.Lists;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLinePackage;

import java.io.Serializable;
import java.util.List;

@Data
@NoArgsConstructor
public class DeclarationLinePackageGroup implements Serializable {
    private static final long serialVersionUID = 1L;

    public static Encoder<DeclarationLinePackageGroup> declarationLinePackageGroupEncoder = Encoders.bean(DeclarationLinePackageGroup.class);

    private String joinId;
    private String sequenceId;
    private Integer itemNumber;
    private List<DeclarationLinePackage> packages = Lists.newArrayList();

    public static final String ALIAS = "packages";
}
