package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.group;

import com.google.common.collect.Iterables;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLineTaxLineGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.entity.DeclarationLineTaxLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader.DeclarationLineTaxLineReader;

import static org.apache.spark.sql.functions.collect_list;
import static org.apache.spark.sql.functions.sort_array;
import static org.apache.spark.sql.functions.struct;

@Component
@Profile("!cds")
public class DeclarationLineTaxLineGroupDataset {

    private final DeclarationLineTaxLineReader declarationLineTaxLineReader;
    private static Column[] taxLineColumns = Iterables.toArray(DeclarationLineTaxLine.columns, Column.class);

    @Autowired
    public DeclarationLineTaxLineGroupDataset(DeclarationLineTaxLineReader declarationLineTaxLineReader) {
        this.declarationLineTaxLineReader = declarationLineTaxLineReader;
    }

    public Dataset<DeclarationLineTaxLineGroup> build() {
        Dataset<DeclarationLineTaxLine> taxLineDataset = declarationLineTaxLineReader.declarationLineTaxLineDataset();
        return taxLineDataset
                .groupBy(taxLineDataset.col(DeclarationLine.PRIMARY_COLUMN), taxLineDataset.col(DeclarationLine.ITEM_NUMBER_COLUMN), taxLineDataset.col(DeclarationLine.SEQUENCE_ID_COLUMN))
                .agg(
                    sort_array(
                            collect_list(
                                    struct(taxLineColumns)
                            )
                    )
                    .alias(DeclarationLineTaxLineGroup.ALIAS)
                )
                .as(DeclarationLineTaxLineGroup.declarationLineTaxLineGroupEncoder);
    }
}
