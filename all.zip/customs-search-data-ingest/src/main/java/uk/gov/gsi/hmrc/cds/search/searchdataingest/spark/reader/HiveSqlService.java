package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.reader;

public interface HiveSqlService {

    String replaceSqlPlaceholders(String sqlTemplate);

    String replaceSqlPlaceholders(String sqlTemplate, String... sequenceIds);

}