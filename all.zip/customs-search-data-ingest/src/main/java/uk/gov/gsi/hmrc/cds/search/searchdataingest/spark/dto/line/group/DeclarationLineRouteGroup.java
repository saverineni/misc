package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group;

import com.google.common.collect.Lists;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLineRoute;

import java.io.Serializable;
import java.util.List;

@Data
public class DeclarationLineRouteGroup implements Serializable {
    private static final long serialVersionUID = 1L;

    public static Encoder<DeclarationLineRouteGroup> declarationLineRouteGroupEncoder = Encoders.bean(DeclarationLineRouteGroup.class);

    private String joinId;
    private String sequenceId;
    private Integer itemNumber;
    private List<DeclarationLineRoute> routes = Lists.newArrayList();

    public static final String ALIAS = "routes";
}
