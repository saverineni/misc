#!/usr/bin/env bash

# test/resources/chief/random directory has been populated with data using data population tool
# DATABASE_NAME=generated_data (data population tool data)
# DATABASE_NAME=search (hand crafted data)

DATABASE_NAME=search
DIR=$(cd `dirname $0` && pwd)
DDL_FILE_BASE_PATH="src/test/resources/chief/$DATABASE_NAME/ddl"
DATA_FILE_BASE_PATH="src/test/resources/chief/$DATABASE_NAME/data"
DATA_FILE_ABSOLUTE_PATH=$DIR/$DATA_FILE_BASE_PATH

# cds
CDS_DDL_FILE_BASE_PATH="src/test/resources/cds/$DATABASE_NAME/ddl"
CDS_DATA_FILE_BASE_PATH="src/test/resources/cds/$DATABASE_NAME/data"
CDS_DATA_FILE_ABSOLUTE_PATH=$DIR/$CDS_DATA_FILE_BASE_PATH

GREEN=`tput setaf 2`
RED=`tput setaf 1`
NC=`tput sgr0` # No Color

function log() {
    echo "${GREEN}$1${NC}"
}

function error() {
    echo "${RED}$1${NC}"
}

function ddlFor() {
    cat $DDL_FILE_BASE_PATH/$1.sql | sed -e "s/DATABASE_NAME/$DATABASE_NAME/g"
}

function ddlForCds() {
    cat $CDS_DDL_FILE_BASE_PATH/$1.sql | sed -e "s/DATABASE_NAME/$DATABASE_NAME/g"
}

log "creating database '$DATABASE_NAME'"
hive -e "DROP DATABASE IF EXISTS $DATABASE_NAME CASCADE;
CREATE DATABASE IF NOT EXISTS $DATABASE_NAME;"

log ''
log "creating import tables imenselect, imendetail, imeiselect, imeidetail, inad, iica, iina, iirt, iipk, iict, iipd, iiai, iitl..."
log "creating export tables nxenselect, nxendetail, nxeiselect, nxeidetail, nxnad, nxica, nxina, nxirt, nxipk, nxict, nxipd, nxiai, nxitl ..."
hive -e "
$(ddlFor 'imenselect');
$(ddlFor 'imendetail');
$(ddlFor 'imeiselect');
$(ddlFor 'imeidetail');
$(ddlFor 'inad');
$(ddlFor 'iica');
$(ddlFor 'iina');
$(ddlFor 'iirt');
$(ddlFor 'iipk');
$(ddlFor 'iict');
$(ddlFor 'iipd');
$(ddlFor 'iiai');
$(ddlFor 'iitl');
$(ddlFor 'nxenselect');
$(ddlFor 'nxendetail');
$(ddlFor 'nxeiselect');
$(ddlFor 'nxeidetail');
$(ddlFor 'nxnad');
$(ddlFor 'nxica');
$(ddlFor 'nxina');
$(ddlFor 'nxirt');
$(ddlFor 'nxipk');
$(ddlFor 'nxict');
$(ddlFor 'nxipd');
$(ddlFor 'nxiai');
$(ddlFor 'nxitl');
$(ddlForCds 'cdap_goodsitems_consolidated');
$(ddlForCds 'cdap_declaration_process_consolidated');
"

log ''
log "loading test data into hive tables..."
hive -e "
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/imenselect/part-00000' overwrite into table $DATABASE_NAME.imenselect;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/imendetail/part-00000' overwrite into table $DATABASE_NAME.imendetail;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/imeiselect/part-00000' overwrite into table $DATABASE_NAME.imeiselect;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/imeidetail/part-00000' overwrite into table $DATABASE_NAME.imeidetail;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/inad/part-00000' overwrite into table $DATABASE_NAME.inad;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/iica/part-00000' overwrite into table $DATABASE_NAME.iica;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/iina/part-00000' overwrite into table $DATABASE_NAME.iina;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/iirt/part-00000' overwrite into table $DATABASE_NAME.iirt;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/iipk/part-00000' overwrite into table $DATABASE_NAME.iipk;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/iict/part-00000' overwrite into table $DATABASE_NAME.iict;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/iipd/part-00000' overwrite into table $DATABASE_NAME.iipd;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/iiai/part-00000' overwrite into table $DATABASE_NAME.iiai;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/iitl/part-00000' overwrite into table $DATABASE_NAME.iitl;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxenselect/part-00000' overwrite into table $DATABASE_NAME.nxenselect;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxendetail/part-00000' overwrite into table $DATABASE_NAME.nxendetail;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxeiselect/part-00000' overwrite into table $DATABASE_NAME.nxeiselect;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxeidetail/part-00000' overwrite into table $DATABASE_NAME.nxeidetail;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxnad/part-00000' overwrite into table $DATABASE_NAME.nxnad;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxica/part-00000' overwrite into table $DATABASE_NAME.nxica;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxina/part-00000' overwrite into table $DATABASE_NAME.nxina;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxirt/part-00000' overwrite into table $DATABASE_NAME.nxirt;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxipk/part-00000' overwrite into table $DATABASE_NAME.nxipk;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxict/part-00000' overwrite into table $DATABASE_NAME.nxict;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxipd/part-00000' overwrite into table $DATABASE_NAME.nxipd;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxiai/part-00000' overwrite into table $DATABASE_NAME.nxiai;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxitl/part-00000' overwrite into table $DATABASE_NAME.nxitl;
load data local inpath '$CDS_DATA_FILE_ABSOLUTE_PATH/cdap_goodsitems_consolidated/part-00000' overwrite into table $DATABASE_NAME.cdap_goodsitems_consolidated;
load data local inpath '$CDS_DATA_FILE_ABSOLUTE_PATH/cdap_declaration_process_consolidated/part-00000' overwrite into table $DATABASE_NAME.cdap_declaration_process_consolidated;
"

log ""
log 'done'