# Customs Data Spark Job


## Testing
Run `./data-setup.sh` before running unit tests.

###### More info ```test/resources/mss/README.md``` 
