package uk.gov.gsi.hmrc.cds.search.utils;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.apache.commons.io.FileUtils.readFileToString;

public class FileLoaderUtils {

    public static final String EXPECTED_VALID_MAPPINGS_FILE ="expected/valid_mappings.json";
    public static final String EXPECTED_INVALID_SETTINGS_FILE ="expected/settings/invalid_settings.json";
    public static final String EXPECTED_INVALID_MAPPINGS_FILE ="expected/mappings/invalid_mappings.json";
    public static final String ACTUAL_SETTINGS_FILE = "actual/settings.json";
    public static final String ACTUAL_MAPPINGS_FILE = "actual/mappings.json";

    // local resources folder
    public static String getResourcesFileContent(String file) {
        String response = "";
        try {
            Path path = Paths.get(FileLoaderUtils.class.getClassLoader().getResource(file).toURI());
            response = readFileToString(path.toFile(), "UTF-8");
        } catch (IOException  | URISyntaxException e) {
            e.printStackTrace();
        }
        return response;
    }

    // from absolute filePath
    public static String getFileContent(String filePath) {
        String response = "";
        try {
            File file = new File(filePath);
            response = FileUtils.readFileToString(file, StandardCharsets.UTF_8.name());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return response;
    }


}