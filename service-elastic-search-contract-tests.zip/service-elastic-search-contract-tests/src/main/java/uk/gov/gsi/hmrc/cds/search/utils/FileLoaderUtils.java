package uk.gov.gsi.hmrc.cds.search.utils;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.apache.commons.io.FileUtils.readFileToString;

public class FileLoaderUtils {

    public static final String API_ES_EXPECTED_VALID_MAPPING_FILE = "api_es/expected/valid_mapping.json";
    public static final String API_ES_EXPECTED_INVALID_SETTING_FILE = "api_es/expected/settings/invalid_setting.json";
    public static final String API_ES_EXPECTED_INVALID_MAPPING_FILE = "api_es/expected/mappings/invalid_mapping.json";
    public static final String API_ES_ACTUAL_SETTING_FILE = "api_es/actual/setting.json";
    public static final String API_ES_ACTUAL_MAPPING_FILE = "api_es/actual/mapping.json";

    public static final String INGESTION_API_EXPECTED_DECLARATION_FILE = "ingestion_api/expected/declaration.json";
    public static final String INGESTION_API_EXPECTED_DECLARATION_EXTRA_FIELD_FILE = "ingestion_api/expected/declaration_extra_field.json";

    public static final String INGESTION_API_ACTUAL_DECLARATION_FILE = "ingestion_api/actual/declaration.json";

    // local resources folder
    public static String getResourcesFileContent(String filePath) throws IOException, URISyntaxException {
            Path path = Paths.get(FileLoaderUtils.class.getClassLoader().getResource(filePath).toURI());
            return  readFileToString(path.toFile(), "UTF-8");
    }

    // from absolute filePath
    public static String getFileContent(String filePath) throws IOException, URISyntaxException {
        String response;
        try {
            File file = new File(filePath);
            response = readFileToString(file, StandardCharsets.UTF_8.name());
        } catch (IOException e) {
            response = getResourcesFileContent(filePath);
        }
        return response;
    }


}