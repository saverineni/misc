package uk.gov.gsi.hmrc.cds.search;

import com.google.api.client.util.Lists;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.skyscreamer.jsonassert.JSONCompareResult;

import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;

import static org.skyscreamer.jsonassert.JSONCompare.compareJSON;

@Slf4j
public class ContractCheckingService {

    private static Gson gson = new GsonBuilder().create();

    public boolean verifyContract(String jsonES, String jsonService, String actualJsonPath, String expectedJsonPath) {
        String actualJson = loadActualJsonByPath(jsonES, actualJsonPath);
        String expectedJson = loadExpectedJsonByPath(jsonService, expectedJsonPath);

        try {
            JSONObject actualSettingsJsonObject = new JSONObject(actualJson);
            JSONObject expectedSettingsJsonObject = new JSONObject(expectedJson);

            if (expectedSettingsJsonObject.length() > actualSettingsJsonObject.length()) {
                JSONCompareResult jsonCompareResult = compareJSON(expectedJson, actualJson, JSONCompareMode.LENIENT);
                logErrors(new ErrorMessage(actualJson, expectedJson, jsonCompareResult.getMessage()));
                return !jsonCompareResult.failed();
            } else {
                List<String> expectedKeysList = Lists.newArrayList(expectedSettingsJsonObject.keys());
                for (String expectedKey : expectedKeysList) {
                    JSONObject expectedJsonObject = (JSONObject) expectedSettingsJsonObject.get(expectedKey);
                    JSONObject actualJsonObject = (JSONObject) actualSettingsJsonObject.get(expectedKey);
                    JSONCompareResult jsonCompareResult = compareJSON(expectedJsonObject, actualJsonObject, JSONCompareMode.LENIENT);
                    if (jsonCompareResult.failed()) {
                        logErrors(new ErrorMessage(actualJson, expectedJson, jsonCompareResult.getMessage()));
                        return false;
                    }
                }
                return true;
            }
        } catch (JSONException ex) {
            logErrors(new ErrorMessage(actualJson, expectedJson, ex.toString()));
            return false;
        }
    }

    private void logErrors(ErrorMessage errorMessage) {
        log.error(errorMessage.toString());
    }

    private String loadActualJsonByPath(String jsonContent, String jsonPath) {
        Type type = new TypeToken<Map<String, Object>>() {
        }.getType();
        Map<String, Object> mappingsMap = gson.fromJson(jsonContent, type);

        String indexNameKey = (String) mappingsMap.keySet().toArray()[0];
        Map<String, Object> indexNameMap = (Map<String, Object>) mappingsMap.get(indexNameKey);
        String json = gson.toJson(indexNameMap);
        return loadExpectedJsonByPath(json, jsonPath);
    }

    private String loadExpectedJsonByPath(String jsonContent, String path) {
        DocumentContext jsonContext = JsonPath.parse(jsonContent);
        Map<String, Object> ObjectMap = jsonContext.read(path);
        return gson.toJson(ObjectMap);
    }

    class ErrorMessage {
        private String actualJSON;
        private final String expectedJSON;
        private final String error;

        ErrorMessage(String  actualJSON, String expectedJSON, String error) {
            this.actualJSON = actualJSON;
            this.expectedJSON = expectedJSON;
            this.error = error;
        }

        @Override
        public String toString() {
            return  "\n\nElasticsearch Json : \n"+this.actualJSON + "\n\n" +
            "Search service  Json : \n "+this.expectedJSON  + "\n\n" +
                    "Error :\n "+this.error + "\n\n";
        }
    }
}
