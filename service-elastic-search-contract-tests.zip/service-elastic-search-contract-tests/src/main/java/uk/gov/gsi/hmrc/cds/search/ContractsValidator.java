package uk.gov.gsi.hmrc.cds.search;

import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.javanet.NetHttpTransport;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;

import static net.logstash.logback.encoder.org.apache.commons.lang.StringUtils.isBlank;
import static net.logstash.logback.encoder.org.apache.commons.lang.StringUtils.isNotBlank;
import static uk.gov.gsi.hmrc.cds.search.utils.FileLoaderUtils.getFileContent;

@Slf4j
public class ContractsValidator {

    public static final String MAPPINGS_JSON_PATH = "$.mappings";
    public static final String ACTUAL_SETTINGS_ANALYSIS_JSON_PATH = "$.settings.index.analysis";
    public static final String EXPECTED_SETTINGS_ANALYSIS_JSON_PATH = "$.settings.analysis";
    public static final String SETTINGS_URI = "/customs_search_service/_settings";
    public static final String MAPPINGS_URI = "/customs_search_service/_mappings";
    private static String mappingsESUrl;
    private static String settingsESUrl;
    private static HttpRequestFactory requestFactory = new NetHttpTransport().createRequestFactory();
    private ContractCheckingService contractCheckingService = new ContractCheckingService();
    private static String serviceMappingsResponse;

    public static void main(String args[]) throws IOException {
        String elasticSearchUrl = args[0];
        String serviceMappingsFilePath = "/Users/suresh.averineni/workspace/service-elastic-search-contract-tests/src/test/resources/expected/valid_mappings.json";//args[1];

        if(isBlank(elasticSearchUrl) || isBlank(serviceMappingsFilePath)) {
            System.exit(1);
        }

        settingsESUrl = elasticSearchUrl + SETTINGS_URI;
        mappingsESUrl = elasticSearchUrl + MAPPINGS_URI;
        serviceMappingsResponse = getFileContent(serviceMappingsFilePath);

        if(new ContractsValidator().areContractsValid(settingsESUrl, mappingsESUrl, serviceMappingsResponse)) {
            System.exit(0);
        }
        System.exit(1);
    }

    public boolean areContractsValid(String settingsUrl, String mappingsUrl, String serviceMappingsResponse) throws IOException {
        String settingsESResponse = requestJson(settingsUrl);
        String mappingsESResponse = requestJson(mappingsUrl);
        if (isNotBlank(settingsESResponse) && isNotBlank(mappingsESResponse) && isNotBlank(serviceMappingsResponse)) {
            boolean settings = contractCheckingService.verifyContract(settingsESResponse, serviceMappingsResponse, ACTUAL_SETTINGS_ANALYSIS_JSON_PATH, EXPECTED_SETTINGS_ANALYSIS_JSON_PATH);
            boolean mappings = contractCheckingService.verifyContract(mappingsESResponse, serviceMappingsResponse, MAPPINGS_JSON_PATH, MAPPINGS_JSON_PATH);
            return settings && mappings;
        }
        return false;
    }

    private String requestJson(String url) throws IOException {
        HttpRequest settingsRequest = requestFactory.buildGetRequest(new GenericUrl(url));
        return settingsRequest.execute().parseAsString();
    }
}