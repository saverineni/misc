package uk.gov.gsi.hmrc.cds.search;

import org.json.JSONException;
import org.junit.Assert;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.utils.FileLoaderUtils;

import static uk.gov.gsi.hmrc.cds.search.ContractsValidator.*;

public class ContractsValidatorTest {
    private static String serviceFileContents = FileLoaderUtils.getResourcesFileContent(FileLoaderUtils.EXPECTED_VALID_MAPPINGS_FILE);

    @Test
    public void validateSettings() throws JSONException {
        String settingsESContents = FileLoaderUtils.getResourcesFileContent(FileLoaderUtils.ACTUAL_SETTINGS_FILE);
        Assert.assertTrue( new ContractCheckingService().verifyContract(settingsESContents,
                serviceFileContents,
                ACTUAL_SETTINGS_ANALYSIS_JSON_PATH,
                EXPECTED_SETTINGS_ANALYSIS_JSON_PATH));
    }

    @Test
    public void validateMappings() throws JSONException {
        String fileContent = FileLoaderUtils.getResourcesFileContent(FileLoaderUtils.ACTUAL_MAPPINGS_FILE);
        Assert.assertTrue( new ContractCheckingService().verifyContract(fileContent,
                serviceFileContents,
                MAPPINGS_JSON_PATH,
                MAPPINGS_JSON_PATH));
    }

}