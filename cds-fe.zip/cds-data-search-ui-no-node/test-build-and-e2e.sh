#!/bin/bash

set +e

./angular-cli.sh "
echo 'Running tests in docker...'
ng test --single-run true
echo 'Building distribution in docker...'
ng build -prod --skip-app-shell true --aot true --build-optimizer true
"

docker build -t cdsdar/customs-search-ui .

./run-e2e-tests.sh
