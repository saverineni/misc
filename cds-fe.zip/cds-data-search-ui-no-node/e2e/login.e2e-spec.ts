import { LoginPage } from './login.po';
import {DeclarationSearchPage} from "./declarationsearch.po";
import {Wiremock} from "./wiremock";
import {browser} from "protractor";

describe('Login', () => {
  let page: LoginPage;

  beforeEach(() => {
    page = new LoginPage();
    page.navigateTo();
  });

  it('should be the current page', () => {
    expect(page.isCurrentPage()).toBeTruthy();
  });

  describe('entering incorrect details', () => {
    beforeEach(() => {
      page.enterPid('123456');
      page.enterPassword('invalid')
    });

    it('on click login should display an error message', () => {
      page.signIn();
      expect(page.errorMessage()).toContain('invalid login');
    });
  });

  describe('entering correct details', () => {
    let searchPage: DeclarationSearchPage;

    beforeEach((done) => {
      Wiremock.reset().then(() =>
        Wiremock.stubRequest({
          "priority": 1,
          "request": {
            "method": "POST",
            "url": "/authentication/token",
            "bodyPatterns": [{
              "equalToJson": {
                "pid": "7654321",
                "password": "Pa55word"
              }
            }]
          },
          "response": {
            "status": 200,
            "bodyFileName": "authentication/authentication-successful.json"
          }
        }).then(done)
      );
    });

    beforeEach(() => {
      searchPage = new DeclarationSearchPage();
      page.enterPid('7654321');
      page.enterPassword('Pa55word')
    });

    it('on click login should display the search page', () => {
      page.signIn();

      expect(searchPage.isCurrentPage()).toBeTruthy();
    });
  });
});
