import { browser, by, element, ExpectedConditions } from 'protractor';

export class LoginPage {
  navigateTo() {
    return browser.get('/login');
  }

  isCurrentPage() {
    return element(by.css('.login-form')).isPresent();
  }

  enterPid(pid: string) {
    element(by.css('.login-form__pid-input')).sendKeys(pid);
  }

  enterPassword(password: string) {
    element(by.css('.login-form__password-input')).sendKeys(password);
  }

  signIn() {
    element(by.css('.login-form__button')).click();
    browser.waitForAngular();
  }

  errorMessage() {
    return element(by.css('.login-form__error-message')).getText();
  }
}
