import { DeclarationSearchPage } from './declarationsearch.po';
import { browser } from 'protractor';
import { AppPage } from './app.po';
const fs = require('fs');

const fetch = require('node-fetch');

describe('Declaration search page', () => {
  let page: DeclarationSearchPage;
  beforeEach((done) => {
    fetch(browser.baseUrl + '/api/__admin/mappings/reset', { method: 'POST' })
      .then(response => console.debug('reset:' + response.statusText))
      .then(done);

    page = new DeclarationSearchPage();
    page.navigateTo();
  });

  it('should be the current page', () => {
    expect(page.isCurrentPage()).toBeTruthy();
  });

  it('the page title should be set', () => {
    expect(browser.getTitle()).toEqual("Customs Declaration Search");
  });

  describe('perform search', () => {

    describe('no matching declaration found', () => {
      it('display no results found message', (done) => {
        whenISearchFor(page, 'made up')
          .then(() => expect(page.isNoResultsFound()).toEqual(true))
          .then(done);
      });

    });

    describe('declaration found', () => {
      it('displays declaration', (done) => {
        const declarationId = '670-954107X-2017-08-22';

        givenADeclarationWithId(declarationId)
          .then(() => whenISearchFor(page, declarationId))
          .then(() => expect(page.isResultsDisplayed()).toEqual(true))
          .then(() => expect(page.getResult(0).getDeclarationId()).toEqual(declarationId))
          .then(done);

      });

      it('displays declaration lines on clicking the header row', (done) => {
        const declarationId = '670-954107X-2017-08-22';

        givenADeclarationWithId(declarationId)
          .then(() => whenISearchFor(page, declarationId))
          .then(() => whenIClickOnAHeaderRow(page))
          .then(() => expect(page.areHeaderLinesDisplayed()).toEqual(true))
          .then(done);
      });
    });


    describe('server errors', () => {
      it('displays global error message', (done) => {
        givenSearchServiceIsOffline()
          .then(() => whenISearchFor(page, 'made up'))
          .then(() => expect(new AppPage().getGlobalError()).toEqual('Server error. Please contact support if this problem persits.\nOK'))
          .then(done);
      });

      it('does not display search results', (done) => {
        givenSearchServiceIsOffline()
          .then(() => whenISearchFor(page, 'made up'))
          .then(() => expect(page.isNoResultsFound()).toEqual(false))
          .then(done);
      });
    });
  });
});

function whenISearchFor(page: DeclarationSearchPage, declarationId: string) {
  return page.search(declarationId);
}

function whenIClickOnAHeaderRow(page: DeclarationSearchPage) {
  return page.clickHeaderRow();
}


function givenADeclarationWithId(declarationId: string) {
  const declaration = JSON.parse(fs.readFileSync('e2e/wiremock/__files/declaration-id-found-response-body.json'));
  declaration.header.entry_number = declarationId;

  return fetch(browser.baseUrl + '/api/__admin/mappings', {
    method: 'POST',
    body: JSON.stringify({
      "priority": 1,
      "request": {
        "method": "GET",
        "url": "/api/declaration?declarationId=" + declarationId
      },
      "response": {
        "status": 200,
        "body": JSON.stringify(declaration)
      }
    })
  })
    .then(response => console.debug('wiremock:' + response.statusText));
}

function givenSearchServiceIsOffline() {

  return fetch(browser.baseUrl + '/api/__admin/mappings', {
    method: 'POST',
    body: JSON.stringify({
      "priority": 1,
      "request": {
        "method": "GET",
        "urlPath": "/api/declaration"
      },
      "response": {
        "status": 503,
      }
    })
  })
    .then(response => console.debug('wiremock:' + response.statusText));
}
