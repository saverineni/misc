import { browser } from "protractor";
const fetch = require('node-fetch');

export class Wiremock {
  static reset() {
    return fetch(browser.baseUrl + '/api/__admin/mappings/reset', {method: 'POST'});
  }

  static stubRequest(body) {
    return fetch(browser.baseUrl + '/api/__admin/mappings', {
      method: 'POST',
      body: JSON.stringify(body)
    });

  }
}
