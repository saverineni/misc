import { browser, by, element } from 'protractor';
import { ElementFinder } from 'protractor';

export class DeclarationSearchPage {
  navigateTo() {
    return browser.get('/');
  }

  isCurrentPage() {
    return element(by.css('.search-section')).isPresent();
  }

  search(freeText: string) {
    element(by.css('.search-form__freetext-input')).sendKeys(freeText);
    return element(by.css(".search-form__button")).click();
  }

  clickHeaderRow() {
    return element(by.css('.search-results-table__declaration-header-row')).click();

  }

  isNoResultsFound() {
    return element(by.css('.no-search-results')).isPresent();
  }

  isResultsDisplayed() {
    return element(by.css('.search-results-table')).isPresent();
  }

  areHeaderLinesDisplayed() {
    return element(by.css('.declaration-lines__row')).isPresent();
  }

  getResult(index: number): DeclarationRow {
    return new DeclarationRow(element.all(by.css('.search-results-table__declaration-header-row')).get(index));
  }
}

export class DeclarationRow {

  constructor(private rowElement: ElementFinder) { }

  getDeclarationId() {
    return this.rowElement.element(by.css('.search-results-table__entryReference')).getText();
  }
}
