import { async, ComponentFixture, TestBed, getTestBed, inject } from '@angular/core/testing';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { MatSnackBar } from '@angular/material';
import { HttpErrorInterceptor } from './http-error-interceptor';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';

class MockMatSnackBar {
    open() {
    }
}

describe('HttpErrorInterceptor', () => {
    let interceptor: HttpErrorInterceptor;
    let matSnackBar: MatSnackBar;
    let matSnackBarSpy: jasmine.Spy;
    let mock: HttpTestingController;
    let http: HttpClient;

    beforeEach(async(() => {

        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [
                { provide: MatSnackBar, useClass: MockMatSnackBar },
                {
                    provide: HTTP_INTERCEPTORS,
                    useClass: HttpErrorInterceptor,
                    multi: true
                },

            ]
        })
        .compileComponents();
    }));

    beforeEach(() => {
        mock = TestBed.get(HttpTestingController);
        http = TestBed.get(HttpClient);
        matSnackBar = TestBed.get(MatSnackBar);
        matSnackBarSpy = spyOn(matSnackBar, 'open');
    });

    [500, 502, 503, 504].forEach(statusCode => {
        describe('${statusCode} server error', () => {
            it('displays snack bar', (done) => {
                    http.get('/').subscribe(
                        success => done.fail('expect error'),
                        error => done());
                    const request = mock.expectOne('/');
                    request.request.headers
                    request.error(new ErrorEvent(''), { status: statusCode });
                    expect(matSnackBar.open).
                        toHaveBeenCalledWith('Server error. Please contact support if this problem persits.', 'OK', { panelClass: 'global-error' });
            });
        });
    });

    [400, 401, 403, 404, 405].forEach(statusCode => {
        describe('${statusCode} client error', () => {
            it('doe not display snack bar', (done) => {
                    http.get('/').subscribe(
                        success => done.fail('expect error'),
                        error => done());
                    const request = mock.expectOne('/');
                    request.request.headers
                    request.error(new ErrorEvent(''), { status: statusCode });
                    expect(matSnackBar.open).not.toHaveBeenCalled();
            });
        });
    });
});



