import { Injectable } from '@angular/core';
import {
    HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpErrorResponse
} from '@angular/common/http';
import { MatSnackBar } from '@angular/material';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';

@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {

    constructor(public snackBar: MatSnackBar) { }

    intercept(req: HttpRequest<any>, next: HttpHandler):
        Observable<HttpEvent<any>> {
        return next.handle(req).catch((err: any, caught) => {
            if (err instanceof HttpErrorResponse) {
                if (err.status >= 500) {
                    this.snackBar.open('Server error. Please contact support if this problem persits.', 'OK', { panelClass: 'global-error' });
                }                
            }
            return new ErrorObservable(err);
        });
    }
}
