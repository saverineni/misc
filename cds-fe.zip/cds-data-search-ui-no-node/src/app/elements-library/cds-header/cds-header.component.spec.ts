import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { CdsHeaderComponent } from './cds-header.component';

describe('CdsHeaderComponent', () => {
  let component: CdsHeaderComponent;
  let fixture: ComponentFixture<CdsHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CdsHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CdsHeaderComponent);
    component = fixture.componentInstance;
  });

  it('should add the title', () => {
    component.title = 'the title'
    fixture.detectChanges();

    const title = fixture.debugElement.query(By.css('h1')).nativeElement
    expect(title.textContent).toBe('the title');
  });
});
