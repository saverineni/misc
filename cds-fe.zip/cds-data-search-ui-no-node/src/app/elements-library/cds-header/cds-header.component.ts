import { Component, Input } from '@angular/core';

@Component({
  selector: 'cds-header',
  templateUrl: './cds-header.component.html',
  styleUrls: ['./cds-header.component.scss']
})
export class CdsHeaderComponent {
  @Input() title: string;
}
