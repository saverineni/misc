import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CdsHeaderComponent } from './cds-header/cds-header.component';
import { CdsNavbarComponent } from './cds-navbar/cds-navbar.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [CdsHeaderComponent, CdsNavbarComponent],
  exports: [CdsHeaderComponent, CdsNavbarComponent]
})
export class ElementsLibraryModule { }
