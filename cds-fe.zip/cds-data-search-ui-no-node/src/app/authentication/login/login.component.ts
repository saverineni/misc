import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import {Router} from "@angular/router";

@Component({
  selector: 'cds-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  private unauthorised: boolean = false;

  constructor(private authenticationService: AuthenticationService, private router: Router) {}

  login(pid: string, password: string) {
    this.authenticationService
        .login(pid, password)
        .subscribe(
          body => this.router.navigateByUrl(''),
          error => this.unauthorised = true
        );
  }

  isUnauthorised() {
    return this.unauthorised;
  }
}
