import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { LoginComponent } from './login.component';

import { FlexLayoutModule } from '@angular/flex-layout';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DebugElement } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import {RouterTestingModule} from "@angular/router/testing";
import {Router} from "@angular/router";

class MockAuthenticationService {
  login(pid: string, password: string) {}
}

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let authenticationService: AuthenticationService;
  let authenticationServiceSpy: jasmine.Spy;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginComponent ],
      imports: [
        FlexLayoutModule,
        MatButtonModule,
        MatInputModule,
        BrowserAnimationsModule,
        FormsModule,
        RouterTestingModule.withRoutes([]),
      ],
      providers: [
        { provide: AuthenticationService, useClass: MockAuthenticationService }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    authenticationService = TestBed.get(AuthenticationService);
    authenticationServiceSpy = spyOn(authenticationService, 'login');
    authenticationServiceSpy.and.returnValue(Observable.of({}));

    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('login form', () => {
    let form: DebugElement;
    let pidInput: DebugElement;
    let passwordInput: DebugElement;
    let loginFormButton: DebugElement;
    const getErrorMessageElement = () => fixture.debugElement.query(By.css('.login-form__error-message'));

    beforeEach(async(() => {
      form = fixture.debugElement.query(By.css('.login-form'));
      pidInput = form.query(By.css('.login-form__pid-input'));
      passwordInput = form.query(By.css('.login-form__password-input'));
      loginFormButton = form.query(By.css('.login-form__button'));

      fixture.detectChanges();
    }));

    it('should be displayed', () => {
      expect(form).toBeTruthy();
    });

    it('should have a username field', () => {
      expect(pidInput).toBeTruthy();
    });

    it('should have a password field', () => {
      expect(passwordInput).toBeTruthy();
    });

    it('should have a button', () => {
      expect(loginFormButton).toBeTruthy();
    });

    it('should not display error section', () => {
      expect(getErrorMessageElement() == null).toBeTruthy()
    });

    describe('login credentials', () => {
      describe('entered', () => {
        const pid: any = 'pid';
        const password: any = 'password';

        beforeEach(() => {
          pidInput.nativeElement.value = pid;
          passwordInput.nativeElement.value = password;
        });

        it('should be submitted for authentication on button click', () => {
          loginFormButton.nativeElement.click();

          expect(authenticationService.login).toHaveBeenCalledWith(pid, password);
        });

        it('should be submitted for authentication on form submit', () => {
          form.nativeElement.dispatchEvent(new Event('submit'));

          expect(authenticationService.login).toHaveBeenCalledWith(pid, password);
        });

        describe('authentication fails', () => {
          beforeEach(() => {
            authenticationServiceSpy.and.returnValue(new Observable(observer => observer.error('Unauthorized')));
            form.nativeElement.dispatchEvent(new Event('submit'));
          });

          it('should display error message', () => {
            fixture.detectChanges();
            expect(getErrorMessageElement().nativeElement.innerText).toBe('You have entered invalid login credentials');
          });
        });

        describe('authentication success', () => {
          let routerNavigateByUrlSpy;
          beforeEach(() => {
            authenticationServiceSpy.and.returnValue(Observable.of({}));
            routerNavigateByUrlSpy = spyOn(TestBed.get(Router), 'navigateByUrl');
            form.nativeElement.dispatchEvent(new Event('submit'));
          });

          it('should invoke router' ,() => {
            expect(routerNavigateByUrlSpy).toHaveBeenCalledWith('');
          });
        });
      });

      describe('missing', () => {
        it('should disable the submit button', () => {
          fixture.detectChanges();

          expect(loginFormButton.nativeElement.disabled).toBe(true);
        });

        it('should not be submitted on form submit', () => {
          form.nativeElement.dispatchEvent(new Event('submit'));

          expect(authenticationService.login).not.toHaveBeenCalled;
        });
      });
    });
  });
});
