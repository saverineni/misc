import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing'
import { AuthenticationService } from './authentication.service';

describe('AuthenticationService', () => {
  let httpMock: HttpTestingController;
  let service: AuthenticationService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AuthenticationService],
      imports: [ HttpClientTestingModule ]
    });
    
    httpMock = TestBed.get(HttpTestingController);
    service = TestBed.get(AuthenticationService);
  });
  
  describe('login', () => {
    const pid = '12345'
    const password = 'password';

    const mockLoginRequest = () => httpMock.expectOne('/api/authentication/token');
    
    it('should send the login credentials to the api', () => {
      service.login(pid, password).subscribe(() => '');
      const loginRequest = mockLoginRequest();
      loginRequest.flush({});
      
      expect(loginRequest.request.body).toEqual({ pid: pid, password: password });
    });

    describe('unauthorised response', () => {
      it('should return an error observable with unauthorized value', (done) => {
        service.login(pid, password).subscribe(
          success => fail('should have given an error'),
          error => {
            expect(error).toBe('Unauthorized');
            done();
          }
        );
        
        mockLoginRequest().error(new ErrorEvent(''), { status: 401 });
      });
    });
  });
});
