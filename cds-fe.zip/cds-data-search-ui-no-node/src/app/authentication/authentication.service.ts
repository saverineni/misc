import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { catchError, retry } from 'rxjs/operators';

@Injectable()
export class AuthenticationService {
  constructor(private httpClient: HttpClient) { }

  public login(pid: string, password: string): Observable<any> {

    return this.httpClient.post("/api/authentication/token", { pid: pid, password: password })
        .pipe(
          catchError((err, obs) => {
            return new ErrorObservable('Unauthorized');
          })
        );
  }
}
