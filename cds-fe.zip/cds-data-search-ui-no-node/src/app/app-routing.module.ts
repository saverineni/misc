import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './authentication/login/login.component';
import { SearchSectionComponent } from './declaration-search/search-section/search-section.component';

const routes: Routes = [
   { path: 'login', component: LoginComponent },
   { path: '', component: SearchSectionComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
