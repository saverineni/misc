import { TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { Directive, Input } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Directive({
  selector: 'cds-header',
})
export class MockCdsHeaderComponent {
  @Input() title;
}

@Directive({
  selector: 'cds-navbar',
})
export class MockCdsNavbarComponent {
  @Input() homeLabel;
}

@Directive({
  selector: 'router-outlet',
})
export class MockRouterOutlet {
}

describe('AppComponent', () => {
  let fixture;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent,
        MockCdsHeaderComponent,
        MockCdsNavbarComponent,
        MockRouterOutlet
      ],
    }).compileComponents();
    fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
  }));

  it('should create the app with the header', () => {
    const directive = fixture.debugElement.query(By.directive(MockCdsHeaderComponent));
    const header = directive.injector.get(MockCdsHeaderComponent);

    expect(header.title).toBe('Customs Declaration Search');
  });

  it('should create the app with the navbar', () => {
    const directive = fixture.debugElement.query(By.directive(MockCdsNavbarComponent));
    const navbar = directive.injector.get(MockCdsNavbarComponent);

    expect(navbar.homeLabel).toBe('Customs Declaration Search');
  });

  it('should route requests', () => {
    const directive = fixture.debugElement.query(By.directive(MockRouterOutlet));

    expect(directive).toBeTruthy();
  });
});
