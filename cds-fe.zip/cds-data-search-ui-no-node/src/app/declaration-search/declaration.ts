import { DeclarationHeader } from "./declaration-header";
import { DeclarationLine } from "./declaration-line";

export class Declaration {
    header: DeclarationHeader;
    lines: Array<DeclarationLine>;
}
