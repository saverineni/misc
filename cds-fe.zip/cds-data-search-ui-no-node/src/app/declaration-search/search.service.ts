import { Injectable } from '@angular/core';
import { DeclarationSearch } from './declaration-search';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { of } from 'rxjs/observable/of';
import { catchError } from 'rxjs/operators';
import 'rxjs/add/operator/map';
import { DeclarationSearchResult } from './declaration-search-result';
import { Declaration } from './declaration';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';

@Injectable()
export class SearchService {

  constructor(private http: HttpClient) { }

  search(search: DeclarationSearch): Observable<any> {
    return this.http.get<Declaration>("/api/api/declaration",
        { params: new HttpParams().set('declarationId', search.freeText) })
      .map(declaration => {
        const declarationSearchResult = new DeclarationSearchResult();
        declarationSearchResult.declarations.push(declaration);
        return declarationSearchResult;
      })
      .pipe(catchError(this.handleError));
  }

  private handleError = (error: any, caught): Observable<any> => {
    if (error instanceof HttpErrorResponse) {
      if (error.status === 404) {
        return of(new DeclarationSearchResult());
      } 
    }
    return new ErrorObservable(error);
  };

}
