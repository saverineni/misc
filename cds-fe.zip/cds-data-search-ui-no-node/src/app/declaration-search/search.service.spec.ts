import { TestBed, inject, getTestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { SearchService } from './search.service';
import { DeclarationSearch } from './declaration-search';
import { Observable } from 'rxjs/Observable';
import { DeclarationSearchResult } from './declaration-search-result';
import { Declaration } from './declaration';
import { DeclarationHeader } from './declaration-header';
import { fail } from 'assert';

describe('SearchService', () => {
  let httpMock: HttpTestingController;
  let service: SearchService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SearchService],
      imports: [HttpClientTestingModule]
    });
    httpMock = getTestBed().get(HttpTestingController);
    service = getTestBed().get(SearchService);
  });

  it('should submit search request', () => {
    const declarationID = "123-456";
    service.search(new DeclarationSearch(declarationID)).toPromise();
    const testRequest = httpMock.expectOne("/api/api/declaration?declarationId=" + declarationID);
    testRequest.flush({});
    expect(testRequest.request.method).toBe("GET");
  });

  it('should return empty result on 404', () => {
    const declarationID = "123-456";
    let actual: DeclarationSearchResult = null;
    service.search(new DeclarationSearch(declarationID)).subscribe(result => actual = result);
    const testRequest = httpMock.expectOne("/api/api/declaration?declarationId=" + declarationID);
    testRequest.flush('data', { status: 404, statusText: '' });

    expect(actual.declarations).toEqual([]);
  });

  it('should throw error on 500', (done) => {
    const declarationID = "123-456";
    const errorEvent = new ErrorEvent('');
    service.search(new DeclarationSearch(declarationID)).subscribe(
      result => done.fail('expect error'),
      error => { 
        expect(error.error).toBe(errorEvent); 
        done(); 
      });
    const testRequest = httpMock.expectOne("/api/api/declaration?declarationId=" + declarationID);
    testRequest.error(errorEvent, { status: 500 });
  });

  it('should return Declaration seach result', () => {
    const declarationID = "123-456";
    let actual: DeclarationSearchResult = null;
    service.search(new DeclarationSearch(declarationID)).subscribe(result => actual = result);
    const testRequest = httpMock.expectOne("/api/api/declaration?declarationId=" + declarationID);
    testRequest.flush(JSON.stringify(new Declaration()), { status: 200, statusText: '' });
    expect(actual.declarations.length).toEqual(1);
  });

  it('should parse the json response', () => {
    const declarationID = "123-456";
    const header = new DeclarationHeader();
    header.entry_reference = declarationID;

    const declaration = new Declaration();
    declaration.header = header;

    let actual: DeclarationSearchResult = null;
    service.search(new DeclarationSearch(declarationID)).subscribe(result => actual = result);
    const testRequest = httpMock.expectOne("/api/api/declaration?declarationId=" + declarationID);

    testRequest.flush(declaration, { status: 200, statusText: '' });
    expect(actual.declarations[0]).toEqual(declaration);
  });

  afterEach(() => {
    httpMock.verify();
  });
});
