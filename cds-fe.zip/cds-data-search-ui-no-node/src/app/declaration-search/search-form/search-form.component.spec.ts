import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { SearchFormComponent } from './search-form.component';

import { FormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DeclarationSearch } from '../declaration-search';

describe('SearchFormComponent', () => {
  let component: SearchFormComponent;
  let fixture: ComponentFixture<SearchFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SearchFormComponent],
      imports: [
        FlexLayoutModule,
        MatButtonModule,
        MatInputModule,
        BrowserAnimationsModule,
        FormsModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('search form', () => {
    let form;
    beforeEach(async(() => {
      form = fixture.debugElement.query(By.css('.search-form'));
    }));

    it('should be displayed', () => {
      expect(form).toBeTruthy();
    });

    describe('Free text search field', () => {
      let declarationId;
      beforeEach(() => {
        declarationId = form.query(By.css('.search-form__freetext-input'));
      });

      it('should have a free text search field', () => {
        expect(declarationId).toBeTruthy();
      });

      it('should have a label for free text search field', () => {
        expect(declarationId.nativeElement.labels[0].textContent).toEqual("Declaration ID");
      });

      it('should have help text for declaration ID', () => {
        const hint = form.query(By.css('.search-form__freetext-hint'));
        expect(hint.nativeElement.textContent).toEqual("e.g. 436-421316C-2015-04-20");
      });

      it('should be bound to the model', () => {
        const expected = '436-421316C-2015-04-20';
        const freeTextField = declarationId.nativeElement;
        freeTextField.value = expected;
        freeTextField.dispatchEvent(new Event("input"));
        fixture.detectChanges();

        expect(component.model.freeText).toEqual(expected);
      });

    });

    describe('search button', () => {

      let searchbutton;
      let freeTextField;
      beforeEach(() => {
        searchbutton = form.query(By.css('.search-form__button'));
        freeTextField = form.query(By.css('.search-form__freetext-input')).nativeElement;
        fixture.detectChanges();
      });

      it('should have a button', () => {
        expect(searchbutton).toBeTruthy();
      });

      it('disabled on page load', () => {
        expect(searchbutton.nativeElement.disabled).toEqual(true);
      });

      it('enabled on text enter', () => {
        freeTextField.value = '436-421316C-2015-04-20';
        freeTextField.dispatchEvent(new Event("input"));
        fixture.detectChanges();
        expect(searchbutton.nativeElement.disabled).toEqual(false);
      });

    });

    describe('submit form', () => {
      let published = null;

      function subscribeToSubmit() {
        component.submitSearch.subscribe(search => {
          published = search;
        });
      };

      const expectedSearch = new DeclarationSearch("free text");
      beforeEach(() => {
        subscribeToSubmit();
        component.model = expectedSearch;
      });

      it('should emit event when i click search button', () => {
        form.query(By.css('.search-form__button')).nativeElement.click();
        expect(published).toBe(expectedSearch);
      });

      it('should emit event on submit event', () => {
        form.nativeElement.dispatchEvent(new Event("submit"));      
        expect(published).toBe(expectedSearch);
      });

    });

  });
});
