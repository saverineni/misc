import { Component, Output, EventEmitter } from '@angular/core';
import {DeclarationSearch} from '../declaration-search';

@Component({
  selector: 'cds-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.scss']
})
export class SearchFormComponent {

  @Output() submitSearch = new EventEmitter<DeclarationSearch>();
  
  model = new DeclarationSearch("");

  onSubmitSearch() {
    this.submitSearch.emit(this.model);
  }
}
