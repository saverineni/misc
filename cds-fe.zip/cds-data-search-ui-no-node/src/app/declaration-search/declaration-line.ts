import { Country } from './country';
import { Commodity } from './commodity';

export class DeclarationLine {
    clearance_datetime: string;
    customs_procedure_code: string;
    origin_country: Country;
    commodity: Commodity;
}
