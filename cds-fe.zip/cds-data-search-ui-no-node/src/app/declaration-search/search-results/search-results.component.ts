import { Component, Input, ViewChild, TemplateRef } from '@angular/core';
import { DeclarationSearchResult } from '../declaration-search-result';
import { Declaration } from '../declaration';
import { DataSource } from '@angular/cdk/table';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';

@Component({
  selector: 'cds-search-results',
  templateUrl: './search-results.component.html',
  styleUrls: ['./search-results.component.scss']
})
export class SearchResultsComponent {

  @Input() result: DeclarationSearchResult;
  @ViewChild("entryReference") entryReference: TemplateRef<any>;
  @ViewChild("epuNumber") epuNumber: TemplateRef<any>;
  @ViewChild("entryNumber") entryNumber: TemplateRef<any>;
  @ViewChild("entryDate") entryDate: TemplateRef<any>;
  @ViewChild("goodsLocation") goodsLocation: TemplateRef<any>;
  @ViewChild("modeOfTransport") modeOfTransport: TemplateRef<any>;
  @ViewChild("route") route: TemplateRef<any>;
  @ViewChild("dispatchCountry") dispatchCountry: TemplateRef<any>;
  @ViewChild("destinationCountry") destinationCountry: TemplateRef<any>;
  @ViewChild("consignee") consignee: TemplateRef<any>;
  @ViewChild("consignor") consignor: TemplateRef<any>;

  declarationHeaderColumns = [
    { id: 'entryReference', label: 'Declaration ID' },
    { id: 'epuNumber', label: 'EPU' },
    { id: 'entryNumber', label: 'Entry Number' },
    { id: 'entryDate', label: 'Entry Date' },
    { id: 'goodsLocation', label: 'Goods Location' },
    { id: 'modeOfTransport', label: 'Mode of Transport' },
    { id: 'route', label: 'Route of Entry' },
    { id: 'dispatchCountry', label: 'Country of Dispatch' },
    { id: 'destinationCountry', label: 'Destination Country'},
    { id: 'consignee', label: 'Consignee' },
    { id: 'consignor', label: 'Consignor'}
  ];

  declarationHeaderColumnRefs = this.declarationHeaderColumns.map(column => column.id);

  dataSource() {
    return new DeclarationDataSource(this.result);
  }

  ngAfterContentInit() {
    this.declarationHeaderColumns.forEach(column => column['template'] = this[column.id]);
  }

  isDeclarationLineRow = (i: number, row: any) => row.hasOwnProperty('isDeclarationLineRow');

  isDeclarationLineRowCollapsed(declarationLineRow) {
    return !declarationLineRow.declaration.expanded;
  }

  expandCollapse(declaration) {
    declaration.expanded = declaration.hasOwnProperty('expanded') ? !declaration.expanded : true;
  }
}

class DeclarationDataSource extends DataSource<any> {
  constructor(private result: DeclarationSearchResult) {
    super();
  }

  connect(): Observable<Declaration[]> {
    const rows = [];
    this.result.declarations.forEach(declaration => rows.push(declaration, { isDeclarationLineRow: true, declaration }));
    return of(rows);
  }

  disconnect() { }

}