import { Component, Input, ViewChild, TemplateRef } from '@angular/core';
import { Declaration } from '../../declaration';
import { DataSource } from '@angular/cdk/table';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { DeclarationLine } from '../../declaration-line';

@Component({
  selector: 'cds-declaration-lines',
  templateUrl: './declaration-lines.component.html',
  styleUrls: ['./declaration-lines.component.scss']
})
export class DeclarationLinesComponent {

  @ViewChild("clearanceDate") clearanceDate: TemplateRef<any>;
  @ViewChild("cpc") cpc: TemplateRef<any>;
  @ViewChild("originCountry") originCountry: TemplateRef<any>;
  @ViewChild("commodityCode") commodityCode: TemplateRef<any>;

  @Input() declaration: Declaration;

  declarationLineColumns = [
    { id: 'clearanceDate', label: 'Clearance Date' },
    { id: 'cpc', label: 'CPC' },
    { id: 'originCountry', label: 'Country of Origin' },
    { id: 'commodityCode', label: 'Commodity Code' }
  ];

  declarationLineColumnRefs = this.declarationLineColumns.map(column => column.id);

  ngAfterContentInit() {
    this.declarationLineColumns.forEach(column => column['template'] = this[column.id]);
  }

  dataSource() {
    return new DeclarationLineDataSource(this.declaration);
  }
}

class DeclarationLineDataSource extends DataSource<any> {
  constructor(private declaration: Declaration) {
    super();
  }

  connect(): Observable<DeclarationLine[]> {
    return of(this.declaration.lines);
  }

  disconnect() { }

}
