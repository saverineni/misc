import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { MatTableModule } from '@angular/material/table';

import { DeclarationLinesComponent } from './declaration-lines.component';
import { Declaration } from '../../declaration';
import { DeclarationLine } from '../../declaration-line';
import { Country } from '../../country';
import { Commodity } from '../../commodity';

describe('DeclarationLinesComponent', () => {
  let component: DeclarationLinesComponent;
  let fixture: ComponentFixture<DeclarationLinesComponent>;

  function getNoLinesDebugElement() {
    return fixture.debugElement.query(By.css('.declaration-lines__no-lines-found'));
  }

  function getLinesTableDebugElement() {
    return fixture.debugElement.query(By.css('.declaration-lines__table'));
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ MatTableModule ],
      declarations: [ DeclarationLinesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeclarationLinesComponent);
    component = fixture.componentInstance;
    component.declaration = new Declaration();
    component.declaration.lines = [];
    fixture.detectChanges();
  });

  describe('null lines', () => {
    beforeEach(() => {
      component.declaration.lines = null;
      fixture.detectChanges();
    });

    it('should display no lines found message', () => {
      expect(getNoLinesDebugElement() === null).toEqual(false);
    });

    it('should not display the lines table', () => {
      expect(getLinesTableDebugElement() === null).toEqual(true);
    });
  });
  
  describe('Zero lines present', () => {
    it('should display no lines found element', () => {
      expect(getNoLinesDebugElement() === null).toEqual(false);
    });

    it('should display no lines found message', () => {
      expect(getNoLinesDebugElement().nativeElement.textContent).toEqual('No item level data is present');
    });

    it('should not display the lines table', () => {
      expect(getLinesTableDebugElement() === null).toEqual(true);
    });
  });

  const  declarationLine = new DeclarationLine();
  declarationLine.clearance_datetime = 'clearance_datetime';
  declarationLine.customs_procedure_code = 'customs_procedure_code';
  declarationLine.origin_country = new Country();
  declarationLine.origin_country.country_name = 'origin_country_name';
  declarationLine.commodity = new Commodity();
  declarationLine.commodity.commodity_code = 'commodity_code';

  const declarationLineSpecs = [
    { id:'clearanceDate', label: 'Clearance Date', value: declarationLine.clearance_datetime },
    { id:'cpc', label: 'CPC', value: declarationLine.customs_procedure_code },
    { id:'originCountry', label: 'Country of Origin', value: declarationLine.origin_country.country_name },
    { id:'commodityCode', label: 'Commodity Code', value: declarationLine.commodity.commodity_code },
  ];

  describe('lines present', () => {

    beforeEach(() => {
      component.declaration.lines.push(declarationLine);
      fixture.detectChanges();
    });

    it('should not display no lines found message', () => {
      expect(getNoLinesDebugElement() === null).toEqual(true);
    });

    it('should display the lines table', () => {
      expect(getLinesTableDebugElement() === null).toEqual(false);
    });

    describe('table columns', () => {
      declarationLineSpecs.forEach(spec => {
        describe(`the ${spec.label} table column`, () => {
          it(`should display the ${spec.label} table heading`, () => {
            expect(fixture.debugElement.query(By.css(`.declaration-lines__${spec.id}-column-header`)).nativeElement.innerText)
            .toEqual(spec.label);
          });

          it(`should display the ${spec.label} value`, () => {
            expect(fixture.debugElement.query(By.css(`.declaration-lines__${spec.id}`)).nativeElement.innerText)
              .toEqual(spec.value);
          });
        });
      });
    });
  });

  describe('line present with nulls', () => {
    const declarationLine = new DeclarationLine();

    beforeEach(() => {
      component.declaration.lines.push(declarationLine);
      fixture.detectChanges();
    });

    describe('table columns', () => {
      declarationLineSpecs.forEach(spec => {
        describe(`the ${spec.id} table column`, () => {
          it(`should display a blank`, () => {
            expect(fixture.debugElement.query(By.css(`.declaration-lines__${spec.id}`)).nativeElement.innerText)
              .toEqual('');
          });
        });
      });
    });
  });

});
