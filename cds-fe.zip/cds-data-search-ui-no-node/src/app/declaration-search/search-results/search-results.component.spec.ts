import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchResultsComponent } from './search-results.component';
import { By } from '@angular/platform-browser';
import { DeclarationSearchResult } from '../declaration-search-result';
import { Declaration } from '../declaration';
import { DeclarationHeader } from '../declaration-header';
import { MatTableModule } from '@angular/material/table';
import { Directive, Input } from '@angular/core';

@Directive({
  selector: 'cds-declaration-lines'
})
export class DeclarationLinesStub {
  @Input() declaration: Declaration;
}

describe('SearchResultsComponent', () => {
  let component: SearchResultsComponent;
  let fixture: ComponentFixture<SearchResultsComponent>;

  function getNoSearchResultsDebugElement() {
    return fixture.debugElement.query(By.css('.no-search-results'));
  }
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MatTableModule],
      declarations: [SearchResultsComponent, DeclarationLinesStub]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchResultsComponent);
    component = fixture.componentInstance;
    component.result = new DeclarationSearchResult();
    fixture.detectChanges();
  });

  describe('No results found', () => {
    it('should display no results found message', () => {
      const noSearchResultsElement = getNoSearchResultsDebugElement().nativeElement;
      expect(noSearchResultsElement.innerText).toBe("No results found");
    });
  });

  describe('Results found', () => {
    let declaration;

    beforeEach(() => {
      declaration = new Declaration();

      component.result.declarations.push(declaration);
      const header = new DeclarationHeader();
      header.entry_reference = 'entry_reference';
      header.epu_number = 'epu_number';
      header.entry_number = 'entry_number';
      header.entry_date = 'entry_date';
      header.goods_location = 'goods_location';
      header.transport_mode_code = 'transport_mode_code';
      header.route = 'route';
      header.dispatch_country = 'dispatch_country';
      header.importer_trader_turn = 'importer_trader_turn';
      header.consignee_nad_name = 'consignee_nad_name';
      header.consignee_nad_postcode = 'consignee_nad_postcode';
      header.consignor_nad_name = 'consignor_nad_name';
      header.consignor_nad_postcode = 'consignor_nad_postcode';
      header.consignor_trader_turn = 'consignor_trader_turn';
      header.destination_country_name = 'destination_country_name';
      declaration.header = header;

      fixture.detectChanges();
    });

    it('should not display no results found message', () => {
      const noSearchResultsElement = getNoSearchResultsDebugElement();
      expect(noSearchResultsElement === null).toEqual(true);
    });

    it('should display the declarations in a table', () => {
      expect(fixture.debugElement.query(By.css('.search-results-table')) === null).toEqual(false);
    });

    function getFirstDeclarationHeaderRow() {
      return fixture.debugElement.query(By.css('.search-results-table__declaration-header-row'));
    };

    describe('declaration header row', () => {
      it('the declaration header row should not be expanded', () => {
        expect(getFirstDeclarationHeaderRow().nativeElement.classList).not.toContain('search-results-table__declaration-header-row--expanded');
      });

      it('the declaration header row should be expanded after clicking the header', () => {
        getFirstDeclarationHeaderRow().nativeElement.click();
        fixture.detectChanges();
        expect(getFirstDeclarationHeaderRow().nativeElement.classList).toContain('search-results-table__declaration-header-row--expanded');
      });
    });

    describe('expansion indicator', () => {

      function getExpansionIndicator() {
        return fixture.debugElement.query(By.css('.cds-expansion-indicator'));
      };

      it('should be collapsed', () => {
        expect(getExpansionIndicator().nativeElement.classList).not.toContain('cds-expansion-indicator--expanded');
      });

      it('should be expanded after clicking the header', () => {
        getFirstDeclarationHeaderRow().nativeElement.click();
        fixture.detectChanges();
        expect(getExpansionIndicator().nativeElement.classList).toContain('cds-expansion-indicator--expanded');
      });
    });

    describe('table columns', () => {
      [
        { id: 'entryReference', value: declaration => declaration.header.entry_reference, headerLabel: 'Declaration ID' },
        { id: 'epuNumber', value: declaration => declaration.header.epu_number, headerLabel: 'EPU' },
        { id: 'entryNumber', value: declaration => declaration.header.entry_number, headerLabel: 'Entry Number' },
        { id: 'entryDate', value: declaration => declaration.header.entry_date, headerLabel: 'Entry Date' },
        { id: 'goodsLocation', value: declaration => declaration.header.goods_location, headerLabel: 'Goods Location' },
        { id: 'modeOfTransport', value: declaration => declaration.header.transport_mode_code, headerLabel: 'Mode of Transport' },
        { id: 'route', value: declaration => declaration.header.route, headerLabel: 'Route of Entry' },
        { id: 'dispatchCountry', value: declaration => declaration.header.dispatch_country, headerLabel: 'Country of Dispatch' },
        { 
          id: 'consignee', 
          value: declaration => declaration.header.importer_trader_turn + '\n' +
              declaration.header.consignee_nad_name + '\n' +
              declaration.header.consignee_nad_postcode, 
          headerLabel: 'Consignee' 
        },
        { 
          id: 'consignor', 
          value: declaration => declaration.header.consignor_trader_turn + '\n' +
              declaration.header.consignor_nad_name + '\n' +
              declaration.header.consignor_nad_postcode, 
          headerLabel: 'Consignor' 
        },
        { id: 'destinationCountry', value: declaration => declaration.header.destination_country_name, headerLabel: 'Destination Country'}
      ].forEach(spec => {
        describe(`the ${spec.headerLabel} table column`, () => {
          it(`should display the ${spec.headerLabel} table heading`, () => {
            expect(fixture.debugElement.query(By.css(`.search-results-table__${spec.id}-header`)).nativeElement.innerText)
              .toEqual(spec.headerLabel);
          });

          it(`should display the ${spec.headerLabel} value`, () => {
            expect(fixture.debugElement.query(By.css(`.search-results-table__${spec.id}`)).nativeElement.innerText)
              .toEqual(spec.value(declaration));
          });
        });
      });
    });

    describe('declaration lines row', () => {
      function getFirstDeclarationLineDebugElement() {
        return fixture.debugElement.query(By.css('.search-results-table__declaration-lines-row'));
      }

      it('should include the declaration line row', () => {
        expect(getFirstDeclarationLineDebugElement() === null).toEqual(false);
      });

      it('the declaration line row should be hidden', () => {
        expect(getFirstDeclarationLineDebugElement().nativeElement.classList).toContain('search-results-table__declaration-lines-row--collapsed');
      });

      it('the declaration line row should be visible after clicking the header', () => {
        getFirstDeclarationHeaderRow().nativeElement.click();
        fixture.detectChanges();
        expect(getFirstDeclarationLineDebugElement().nativeElement.classList).not.toContain('search-results-table__declaration-lines-row--collapsed');
      });

      it('the declaration line row should include the declaration-lines component', () => {
        const declarationLinesDebugElement = getFirstDeclarationLineDebugElement().query(By.directive(DeclarationLinesStub));
        const declarationLinesDirective = declarationLinesDebugElement.injector.get(DeclarationLinesStub);
        expect(declarationLinesDirective === null).toEqual(false);
      });
    });

  });

});
