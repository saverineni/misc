export class DeclarationHeader {
    
    epu_number: string;
    entry_reference: string;
    entry_number: string;
    entry_date: string;
    goods_location: string;
    transport_mode_code: string;
    route: string;
    dispatch_country: string;
    importer_trader_turn: string;
    consignee_nad_name: string;
    consignee_nad_postcode: string;
    consignor_nad_name: string;
    consignor_nad_postcode: string;
    consignor_trader_turn: string;
    destination_country_name: string;
    
}
