import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import {ElementsLibraryModule} from './elements-library/elements-library.module';
import {FlexLayoutModule} from '@angular/flex-layout';

import {AppComponent} from './app.component';
import {AppRoutingModule} from './app-routing.module';
import {AuthenticationModule} from './authentication/authentication.module';
import {DeclarationSearchModule} from './declaration-search/declaration-search.module';
import {ErrorHandlingModule} from './error-handling/error-handling.module';
import {HttpInterceptorsModule} from "./authentication/http-interceptors/http-interceptors.module";

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    AppRoutingModule,
    AuthenticationModule,
    HttpInterceptorsModule.forRoot(),
    BrowserModule,
    DeclarationSearchModule,
    ElementsLibraryModule,
    FlexLayoutModule,
    ErrorHandlingModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
