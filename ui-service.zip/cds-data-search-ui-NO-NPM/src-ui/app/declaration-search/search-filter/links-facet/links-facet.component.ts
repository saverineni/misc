import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { MatDialog } from '@angular/material';
import { Facet, Facets } from '../../facets';
import { FacetedSearchComponent } from '../faceted-search/faceted-search.component';

@Component({
  selector: 'cds-links-facet',
  templateUrl: './links-facet.component.html',
  styleUrls: ['./links-facet.component.scss']
})
export class LinksFacetComponent implements OnChanges{
  
  @Input() label: string;
  @Input() searchParam: string;
  @Input() facets: Array<Facet>;

  private WIDTH = "50vw";
  
  constructor(public dialog: MatDialog) {}  

  ngOnChanges(changes: SimpleChanges) {
    this.facets = changes['facets'].currentValue;
  }

  openDialog(){
    this.dialog.open(
      FacetedSearchComponent,
      {
        data: {
          facets: this.facets,
          searchParam: this.searchParam,
          facetType: this.label
        },
        width: this.WIDTH
      }
    );
  }

}
