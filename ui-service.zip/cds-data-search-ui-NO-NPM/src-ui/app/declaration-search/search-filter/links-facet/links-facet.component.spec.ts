import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LinksFacetComponent } from './links-facet.component';
import {DebugElement, SimpleChange} from "@angular/core";
import { By } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import {Facet, Facets} from '../../facets';
import { FormsModule } from "@angular/forms";
import { MatDialog , MatChipsModule, MatFormFieldModule, MatDialogModule, MatIconModule, MatInputModule, MAT_LABEL_GLOBAL_OPTIONS} from "@angular/material";
import { FlexLayoutModule } from "@angular/flex-layout";
import { FacetedSearchComponent } from '../faceted-search/faceted-search.component';
import { FacetNotMatchingPipe } from '../../facet-not-matching.pipe';
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import {CountryFacet} from "../../countries-facet";
import {Country} from "../../country";

const LABEL = 'links label';
const SEARCH_PARAM = 'searchParam';

describe('LinksFacetComponent', () => {
  let component: LinksFacetComponent;
  let fixture: ComponentFixture<LinksFacetComponent>;
  let filter: DebugElement;

  let dialog = {
    open(a, b) { }
  } as MatDialog;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MatDialogModule, MatChipsModule, MatIconModule , MatInputModule, BrowserAnimationsModule , FlexLayoutModule, FormsModule],
      declarations: [ LinksFacetComponent, FacetedSearchComponent , FacetNotMatchingPipe ],providers: [{
        provide: MatDialog,
        useValue: dialog
      }]
    }).overrideModule(BrowserDynamicTestingModule, {
      set: {
        entryComponents: [FacetedSearchComponent]
      }
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinksFacetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    filter = fixture.debugElement.query(By.css('.links'));
    component.label = LABEL;
    component.searchParam = SEARCH_PARAM;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('no or empty facets', () => {

    it('should contain the facet type as disabled', () => {
      let facetType = filter.query(By.css('.links__facet-disabled'));
      expect(facetType).toBeTruthy();

      component.facets = [];
      fixture.detectChanges();
      expect(facetType).toBeTruthy();
    });

  });

  describe('any changes to input properties', () => {
    let facets: Array<Facet>;

    beforeEach(() => {
      facets  = [{'id': 'GB', count: 1} as Facet];

      component.ngOnChanges({
        'facets': new SimpleChange(null, facets, true)
      });

      fixture.detectChanges();
    });

    it('should update the facets', () => {
      expect(component.facets).toBe(facets);
    });
  });

  describe('has facets', () => {
    let facets: Array<Facet> = [];
    beforeEach(() => {
      const facet = {} as Facet;
      facets.push(facet);

      component.facets = facets;
      fixture.detectChanges();

    });

    it('should display the facet container with the search param as id', () => {
      let facetId = filter.nativeElement.getAttribute('data-links-id');
      expect(facetId).toBe(SEARCH_PARAM);
    });

    it('should display the facet type',() => {
      let facetType = filter.query(By.css('.links__facet'));
      expect(facetType).toBeTruthy();
    });

    it('should display the facet label',() => {
      let facetLabel = filter.query(By.css('.links__facet')).nativeElement;
      expect(facetLabel.innerText).toBe(LABEL);
    });


    describe('click on the facet' , () => {
      beforeEach(() => {
        spyOn(component.dialog, 'open').and.callThrough();
      });

      it('opens the dialog window with the correct properties', () => {
        expect(component.dialog.open).toHaveBeenCalledTimes(0);

        let facet = filter.query(By.css('.links__facet')).nativeElement;
        facet.click();
        fixture.detectChanges();
        expect(component.dialog.open).toHaveBeenCalledWith(
          FacetedSearchComponent,
          {
            data: {
              facets: facets,
              searchParam: SEARCH_PARAM,
              facetType: LABEL
            },
            width: "50vw"
          });
      });
    });

  });

});
