import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'cds-chips',
  templateUrl: './chips.component.html',
  styleUrls: ['./chips.component.scss']
})
export class ChipsComponent {
  @Input() id: string;
  @Input() label: string;
  @Input() chips: Array<string>;
  @Output() onRemove: EventEmitter<string> = new EventEmitter();

  remove(chipId) {
    this.onRemove.emit(chipId);
  }
}
