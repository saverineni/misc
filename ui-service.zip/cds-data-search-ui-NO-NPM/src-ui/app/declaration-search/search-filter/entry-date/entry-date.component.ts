import { Component, OnInit, OnDestroy } from '@angular/core';
import { SearchCriteria } from '../../search-criteria';
import { MatDatepickerInputEvent } from '@angular/material';
import * as moment from 'moment';
import { SearchCriteriaService } from '../../search-criteria.service';

@Component({
  selector: 'cds-entry-date-filter',
  templateUrl: './entry-date.component.html',
  styleUrls: ['./entry-date.component.scss']
})
export class EntryDateComponent implements OnInit, OnDestroy {
  DATE_FORMAT = "YYYY-MM-DD";

  entryDateFrom: string;
  entryDateTo: string;
  private searchCriteria;
  private subscription;

  constructor(private searchCriteriaService: SearchCriteriaService) { }

  ngOnInit() {
    this.subscription = this.searchCriteriaService.searchCriteria.subscribe(
      data => {
        this.searchCriteria = data;
        if (this.searchCriteria.entryDateFrom !== null) {
          this.entryDateFrom = this.searchCriteria.entryDateFrom;
        }
        if (this.searchCriteria.entryDateTo !== null) {
          this.entryDateTo = this.searchCriteria.entryDateTo;
        }
      }
    );
  }

  maxDate() {
    return new Date();
  }

  fromDateValid(fromDate) {
    return !this.entryDateTo || (this.entryDateTo && moment(this.entryDateTo).isSameOrAfter(moment(fromDate)));
  }

  toDateValid(toDate) {
    return !this.entryDateFrom || (this.entryDateFrom && moment(this.entryDateFrom).isSameOrBefore(moment(toDate)));
  }

  datesInvalid() {
    return (!this.entryDateFrom && !this.entryDateTo) || (!this.fromDateValid(this.entryDateFrom) && !this.toDateValid(this.entryDateTo));
  }

  fromDateBeforeToDate() {
    return !this.fromDateValid(this.entryDateFrom) && !this.toDateValid(this.entryDateTo);
  }

  onCancel() {
    this.entryDateFrom = null;
    this.entryDateTo = null;
    this.onApplyFilters();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  onApplyFilters() {
    if (this.entryDateFrom !== null) {
      this.searchCriteria.entryDateFrom = moment(this.entryDateFrom).format(this.DATE_FORMAT);
    } else {
      this.searchCriteria.entryDateFrom = null;
    }
    if (this.entryDateTo !== null) {
      this.searchCriteria.entryDateTo = moment(this.entryDateTo).format(this.DATE_FORMAT);
    } else {
      this.searchCriteria.entryDateTo = null;
    }

    this.searchCriteriaService.update(this.searchCriteria);
  }

}
