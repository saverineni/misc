import { Component, OnInit, OnDestroy, ChangeDetectionStrategy } from '@angular/core';
import { SearchCriteria } from '../../search-criteria';
import { MatDatepickerInputEvent } from '@angular/material';
import * as moment from 'moment';
import { SearchCriteriaService } from '../../search-criteria.service';
import {ElementRef,Renderer2} from '@angular/core';
import { ViewChild } from '@angular/core';


@Component({
  selector: 'cds-entry-date-filter',
  templateUrl: './entry-date.component.html',
  styleUrls: ['./entry-date.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class EntryDateComponent implements OnInit, OnDestroy {
  DATE_FORMAT = "YYYY-MM-DD";
  entryDateFrom: string = null;
  entryDateTo: string = null;
  panelOpenState : boolean = false;
  private subscription;
  private searchCriteria : SearchCriteria = null;
  @ViewChild('entryDatePanel') entryDatePanel;

  constructor(private searchCriteriaService: SearchCriteriaService) { }

  ngOnInit() {
    this.subscription = this.searchCriteriaService.searchCriteria.subscribe(
      data  => {
        this.searchCriteria = data as SearchCriteria;
        this.entryDateFrom = this.searchCriteria.entryDateFrom;
        this.entryDateTo = this.searchCriteria.entryDateTo;
        this.toggleExpansionPanel();   
      }
    );  
  }

  toggleExpansionPanel() {
    if (this.searchCriteria.isEmpty() && this.panelOpenState){
      this.entryDatePanel.nativeElement.click();
    }
    if (this.entryDateFrom || this.entryDateTo){
      this.panelOpenState=true;
    }
  }

  dateIsSameOrAfter(firstDate, secondDate) {
    return moment(firstDate).isSameOrAfter(moment(secondDate));
  }

  dateIsAfterMaxDate(date) {
    return moment(date).isAfter(moment(this.maxDate()));
  }

  maxDate() {
    return new Date();
  }

  fromDateValid(fromDate) {
    return !this.entryDateTo || (this.entryDateTo && this.dateIsSameOrAfter(this.entryDateTo, fromDate));
  }

  toDateValid(toDate) {
    return !this.entryDateFrom || (this.entryDateFrom && this.dateIsSameOrAfter(toDate, this.entryDateFrom));
  }

  datesInvalid() {
    return (!this.entryDateFrom && !this.entryDateTo) || (this.dateIsAfterMaxDate(this.entryDateFrom) ||
    this.dateIsAfterMaxDate(this.entryDateTo)) || (!this.fromDateValid(this.entryDateFrom) && !this.toDateValid(this.entryDateTo));
  }

  fromDateBeforeToDate() {
    return !this.fromDateValid(this.entryDateFrom) && !this.toDateValid(this.entryDateTo);
  }

  onClear() {
    this.entryDateFrom = null;
    this.entryDateTo = null;
    this.panelOpenState = false;
    this.onApplyFilters();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  onApplyFilters() {
    let updates: any = {};
    if (this.entryDateFrom !== null) {
      updates.entryDateFrom = moment(this.entryDateFrom).format(this.DATE_FORMAT);
    } else {
      updates.entryDateFrom = null;
    }
    if (this.entryDateTo !== null) {
      updates.entryDateTo = moment(this.entryDateTo).format(this.DATE_FORMAT);
    } else {
      updates.entryDateTo = null;
    }

    this.searchCriteriaService.updatePartial(updates);
  }

}
