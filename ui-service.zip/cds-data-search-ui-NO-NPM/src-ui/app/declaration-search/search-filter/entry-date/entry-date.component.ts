import { Component, OnInit, OnDestroy } from '@angular/core';
import { SearchCriteria } from '../../search-criteria';
import { MatDatepickerInputEvent } from '@angular/material';
import * as moment from 'moment';
import { SearchCriteriaService } from '../../search-criteria.service';

@Component({
  selector: 'cds-entry-date-filter',
  templateUrl: './entry-date.component.html',
  styleUrls: ['./entry-date.component.scss']
})
export class EntryDateComponent implements OnInit, OnDestroy {
  DATE_FORMAT = "YYYY-MM-DD";

  entryDateFrom: string = null;
  entryDateTo: string = null;
  private subscription;

  constructor(private searchCriteriaService: SearchCriteriaService) { }

  ngOnInit() {
    this.subscription = this.searchCriteriaService.searchCriteria.subscribe(
      data => {
        if (data.entryDateFrom !== null) {
          this.entryDateFrom = data.entryDateFrom;
        }
        if (data.entryDateTo !== null) {
          this.entryDateTo = data.entryDateTo;
        }
      }
    );
  }

  maxDate() {
    return new Date();
  }

  fromDateValid(fromDate) {
    return !this.entryDateTo || (this.entryDateTo && moment(this.entryDateTo).isSameOrAfter(moment(fromDate)));
  }

  toDateValid(toDate) {
    return !this.entryDateFrom || (this.entryDateFrom && moment(this.entryDateFrom).isSameOrBefore(moment(toDate)));
  }

  datesInvalid() {
    return (!this.entryDateFrom && !this.entryDateTo) || (!this.fromDateValid(this.entryDateFrom) && !this.toDateValid(this.entryDateTo));
  }

  fromDateBeforeToDate() {
    return !this.fromDateValid(this.entryDateFrom) && !this.toDateValid(this.entryDateTo);
  }

  onCancel() {
    this.entryDateFrom = null;
    this.entryDateTo = null;
    this.onApplyFilters();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  onApplyFilters() {
    let updates: any = {};
    if (this.entryDateFrom !== null) {
      updates.entryDateFrom = moment(this.entryDateFrom).format(this.DATE_FORMAT);
    } else {
      updates.entryDateFrom = null;
    }
    if (this.entryDateTo !== null) {
      updates.entryDateTo = moment(this.entryDateTo).format(this.DATE_FORMAT);
    } else {
      updates.entryDateTo = null;
    }

    this.searchCriteriaService.updatePartial(updates);
  }

}
