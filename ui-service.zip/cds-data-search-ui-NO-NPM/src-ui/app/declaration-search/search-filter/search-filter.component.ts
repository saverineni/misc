import {Component, Input, OnChanges} from '@angular/core';
import {Facets, Facet} from "../facets";
import {MatDialog, MatDialogRef} from "@angular/material";
import {FacetedSearchComponent} from "./faceted-search/faceted-search.component";
import {SearchCriteria} from '../search-criteria';
import { SimpleChanges } from '@angular/core/src/metadata/lifecycle_hooks';


@Component({
  selector: 'cds-search-filter',
  templateUrl: './search-filter.component.html',
  styleUrls: ['./search-filter.component.scss']
})

export class SearchFilterComponent implements OnChanges {
  
  @Input() facets: Facets;
  originCountryFacets: Array<Facet>;
  dispatchCountryFacets: Array<Facet>;
  destinationCountryFacets: Array<Facet>;
  
  constructor(public dialog: MatDialog) {}
  
  ngOnChanges(changes: SimpleChanges) {
    if(changes['facets'].currentValue != null){
      this.facets = changes['facets'].currentValue;
      this.originCountryFacets = this.mapToFacets('originCountries');
      this.dispatchCountryFacets = this.mapToFacets('dispatchCountries');
      this.destinationCountryFacets = this.mapToFacets('destinationCountries');
    }    
  }


  private mapToFacets(facetType: string) : Array<Facet> {
    if(this.facets[facetType] === undefined) {
      return null;
    }
    
    return this.facets[facetType].map(countryFacet => ({
      id: countryFacet.country.code,
      count: countryFacet.count
    }) as Facet);
  }

}
