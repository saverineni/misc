import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {By} from "@angular/platform-browser";
import {Directive, EventEmitter, Input, Output} from "@angular/core";
import {SearchCriteria} from '../../search-criteria';
import {Observable, of, Subscription} from 'rxjs';
import {SearchCriteriaService} from '../../search-criteria.service';
import {SelectedFacetsComponent} from './selected-facets.component';

@Directive({
  selector: 'cds-chips'
})
class ChipsComponentStub {
  @Input() id: string;
  @Input() label: string;
  @Input() chips: Array<string>;
  @Output() onRemove: EventEmitter<string> = new EventEmitter();
}

describe('SelectedFacetsComponent', () => {
  let component: SelectedFacetsComponent;
  let fixture: ComponentFixture<SelectedFacetsComponent>;

  let searchCriteriaServiceStub;
  let testObservable: Observable<SearchCriteria>;
  let testSubscription: Subscription;
  let successHandler;

  beforeEach(async(() => {
    testObservable = of(new SearchCriteria());
    testSubscription = new Subscription();

    searchCriteriaServiceStub = {
      searchCriteria: testObservable,
      updatePartial: (searchCriteria) => {
      }
    } as SearchCriteriaService;

    spyOn(searchCriteriaServiceStub, 'updatePartial');
    spyOn(testObservable, 'subscribe')
      .and.callFake(success => {
      successHandler = success;
      return testSubscription;
    });

    spyOn(testSubscription, 'unsubscribe');

    TestBed.configureTestingModule({
      declarations: [SelectedFacetsComponent, ChipsComponentStub],
      providers: [
        {provide: SearchCriteriaService, useValue: searchCriteriaServiceStub}
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectedFacetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should not display when no filters set', () => {
    const parentElement = fixture.debugElement.query(By.css('.selected-facets'));

    expect(parentElement == null).toBeTruthy();
  });

  it('should subscribe to successful search criteria updates', () => {
    expect(successHandler).toBeTruthy();
  });

  [{
    id: 'originCountryCode',
    label: 'Country of Origin',
    index: 0
  },
  {
    id: 'dispatchCountryCode',
    label: 'Country of Dispatch',
    index: 1
  }].forEach(facetType => {
    describe(`has ${facetType.label} facets`, () => {
      let searchCriteria: SearchCriteria;
      beforeEach(() => {
        searchCriteria = new SearchCriteria();
        searchCriteria[facetType.id] = ['code1'];
        successHandler(searchCriteria);
        fixture.detectChanges();
      });

      it('should display when filters set', () => {
        const parentElement = fixture.debugElement.query(By.css('.selected-facets'));

        expect(parentElement != null).toBeTruthy();
      });

      describe('chips component', () => {
        let chipsComponent: ChipsComponentStub;
        beforeEach(() => {
          chipsComponent = fixture.debugElement.queryAll(By.directive(ChipsComponentStub))[facetType.index].injector.get(ChipsComponentStub);
        });

        it('should have the correct id set', () => {
          expect(chipsComponent.id).toBe(facetType.id);
        });

        it('should have the correct label set', () => {
          expect(chipsComponent.label).toBe(facetType.label);
        });

        it('should have the chips set', () => {
          expect(chipsComponent.chips).toBe(searchCriteria[facetType.id]);
        });

        it('should update the chips on criteria update', () => {
          searchCriteria[facetType.id] = ['new chip'];
          successHandler(searchCriteria);
          fixture.detectChanges();
          chipsComponent = fixture.debugElement.queryAll(By.directive(ChipsComponentStub))[facetType.index].injector.get(ChipsComponentStub);

          expect(chipsComponent.chips).toEqual(['new chip']);
        });

        it('should update search criteria on chip remove', () => {
          searchCriteria[facetType.id] = ['chip1', 'chip-remove', 'chip2'];
          successHandler(searchCriteria);
          chipsComponent = fixture.debugElement.queryAll(By.directive(ChipsComponentStub))[facetType.index].injector.get(ChipsComponentStub);
          chipsComponent.onRemove.emit('chip-remove');

          const expectedSearchCriteria = {};
          expectedSearchCriteria[facetType.id] = ['chip1', 'chip2'];
          expect(searchCriteriaServiceStub.updatePartial).toHaveBeenCalledWith(expectedSearchCriteria);
        });

        it('should update search criteria with null when no chip', () => {
          searchCriteria[facetType.id] = ['chip'];
          successHandler(searchCriteria);
          chipsComponent = fixture.debugElement.queryAll(By.directive(ChipsComponentStub))[facetType.index].injector.get(ChipsComponentStub);
          chipsComponent.onRemove.emit('chip');

          const expectedSearchCriteria = {};
          expectedSearchCriteria[facetType.id] = null;
          expect(searchCriteriaServiceStub.updatePartial).toHaveBeenCalledWith(expectedSearchCriteria);
        });
      });
    });
  });


  describe('on destroy', () => {
    it('should unsubscribe from criteria events', () => {
      fixture.destroy();
      expect(testSubscription.unsubscribe).toHaveBeenCalled();
    });
  });
});
