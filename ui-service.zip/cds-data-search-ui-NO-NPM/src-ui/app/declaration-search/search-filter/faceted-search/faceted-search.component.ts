import {Component, Inject, ViewEncapsulation, OnDestroy, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material";
import {FacetNotMatchingPipe} from "../../facet-not-matching.pipe";
import { SearchCriteriaService } from '../../search-criteria.service';
import { Subscription } from 'rxjs';
import { SearchCriteria } from '../../search-criteria';
import { Facet } from '../../facets';

export interface SelectableFacet extends Facet {
  selected: boolean
}

@Component({
  selector: 'cds-faceted-search',
  templateUrl: './faceted-search.component.html',
  styleUrls: ['./faceted-search.component.scss']
})
export class FacetedSearchComponent implements OnInit, OnDestroy {
  private criteriaUpdatesSubscription: Subscription;
  private searchParam: string;

  facetType: string;
  facets: Array<SelectableFacet>;
  filter: string = '';
  selectedFacetsOnInit: string;

  constructor(@Inject(MAT_DIALOG_DATA) data,
              private searchCriteriaService: SearchCriteriaService,
              private dialogRef: MatDialogRef<FacetedSearchComponent>) {
    this.facets = data.facets.map(facet => ({
      selected: false,
      id: facet.id,
      count: facet.count
    } as SelectableFacet));

    this.searchParam = data.searchParam;
    this.facetType = data.facetType;
  }

  ngOnInit() {
    this.criteriaUpdatesSubscription = this.searchCriteriaService.searchCriteria.subscribe(
      newCriteria => {
        const currentFacetCriteria = newCriteria[this.searchParam];
        if (currentFacetCriteria) {
          this.facets.forEach(facet => {
            if (currentFacetCriteria.find(it => facet.id == it)) {
              facet.selected = true;
            }
          });
        }
      }
    );

    this.selectedFacetsOnInit = JSON.stringify(this.selectedFacets().sort());
  }

  ngOnDestroy() {
    this.criteriaUpdatesSubscription.unsubscribe();
  }

  onDeselect(facet) {
    facet.selected = false;
  }

  onSelect(facet) {
    facet.selected = true;
  }

  selectedFacetsUpdated() {
    return this.selectedFacetsOnInit !== JSON.stringify(this.selectedFacets().sort());
  }

  selectedFacets() {
    return this.facets.filter(facet => facet.selected);
  }

  cancel() {
    this.facets.forEach(facet => facet.selected = false);
    this.dialogRef.close();
  }

  applyFilters() {
    const update = {};
    if (this.selectedFacets().length > 0) {
      update[this.searchParam] = this.selectedFacets().map(it => it.id);
    } else {
      update[this.searchParam] = null;
    }
    this.searchCriteriaService.updatePartial(update);
    this.dialogRef.close();
  }

  nonMatching(filter) {
    return this.facets.find(facet => FacetNotMatchingPipe.matching(facet, filter)) === undefined;
  }
}
