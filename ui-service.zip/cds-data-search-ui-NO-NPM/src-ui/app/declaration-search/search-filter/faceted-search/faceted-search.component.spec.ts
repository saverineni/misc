import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {FacetedSearchComponent, SelectableFacet} from './faceted-search.component';
import {MatDialogModule} from "@angular/material/dialog";
import {MAT_DIALOG_DATA, MatChipsModule, MatDialogRef, MatFormFieldModule, MatIconModule} from "@angular/material";
import {By} from "@angular/platform-browser";
import {DebugElement} from "@angular/core/src/debug/debug_node";
import {MatListModule} from "@angular/material/list";
import {FacetNotMatchingPipe} from '../../facet-not-matching.pipe';
import {FormsModule} from "@angular/forms";
import {FlexLayoutModule} from "@angular/flex-layout";
import {MatInputModule} from "@angular/material/input";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import { SearchCriteriaService } from '../../search-criteria.service';
import { SearchCriteria } from '../../search-criteria';
import { Observable, Subscription } from 'rxjs';

function newFacet(code, count) {
  return {
    id: code,
    count: count,
    selected: false
  };
}

const FACET1_NAME = 'facet1';
const FACET2_NAME = 'facet2';
const FACET3_NAME = 'AB_facet';
const FACET4_NAME = 'AD_facet';
const FACET5_NAME = 'facet5';

const facetLabels = [`${FACET1_NAME} (4)`, `${FACET2_NAME} (3)`,  `${FACET3_NAME} (1)`,  `${FACET4_NAME} (1)`,  `${FACET5_NAME} (1)`];
const searchParam = 'originCountryCode';
const facetType = 'FacetType';

describe('FacetedSearchComponent', () => {
  let component: FacetedSearchComponent;
  let fixture: ComponentFixture<FacetedSearchComponent>;
  let matDialogRef: MatDialogRef<any>;
  let facets: Array<SelectableFacet>;
  let searchCriteriaService: SearchCriteriaService;
  let testSubscription: Subscription;
  let testObservable: Observable<SearchCriteria>;
  let successHandler;

  beforeEach(async(() => {
    matDialogRef = {close: () => {}} as MatDialogRef<any>;
    spyOn(matDialogRef, 'close');

    facets = [
      newFacet(FACET1_NAME, 4),
      newFacet(FACET2_NAME, 3),
      newFacet(FACET3_NAME, 1),
      newFacet(FACET4_NAME, 1),
      newFacet(FACET5_NAME, 1)
    ];

    testObservable = Observable.of(null);
    testSubscription = new Subscription();

    spyOn(testObservable, 'subscribe').and.callFake(
      success => {
        successHandler = success;
        return testSubscription;
      }
    );
    spyOn(testSubscription, 'unsubscribe');

    searchCriteriaService = {
      searchCriteria: testObservable,
      update: (searchCriteria) => {}
    } as SearchCriteriaService;

    spyOn(searchCriteriaService,'update');

    TestBed.configureTestingModule({
      imports: [
        MatDialogModule,
        MatChipsModule,
        MatIconModule,
        MatListModule,
        MatInputModule,
        FlexLayoutModule,
        BrowserAnimationsModule,
        FormsModule
      ],
      declarations: [FacetedSearchComponent , FacetNotMatchingPipe],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: {
            facets: facets,
            searchParam: 'originCountryCode',
            facetType: facetType
          }
        },
        { provide: MatDialogRef, useValue: matDialogRef },
        { provide: SearchCriteriaService, useValue: searchCriteriaService }
      ]
    })
    .compileComponents();
  }));

  let displayedFacets;

  beforeEach(() => {
    fixture = TestBed.createComponent(FacetedSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    displayedFacets = () => {
      const facetElements = fixture.debugElement.queryAll(By.css('.faceted-search__link'));
      return facetElements.map(facetElement => facetElement.nativeElement.textContent);
    }
  });

  describe('on initialisation', () => {
    it('should subscribe to search criteria updates', () => {
      expect(successHandler).toBeTruthy();
    });
  });

  describe('on destroy', () => {
    beforeEach(() => {
      fixture.destroy();
    });

    it('should unsubscribe from search criteria updates', () => {
      expect(testSubscription.unsubscribe).toHaveBeenCalled();
    });
  });

  describe('given list of countries' , () => {

    function selectFacet(facetId) {
      let link = fixture.debugElement.query(By.css(`.faceted-search__link[data-facet-id="${facetId}"]`)).nativeElement;
      link.click();
      return link;
    }

    it('should display title',() => {
      const title: HTMLElement = fixture.debugElement.query(By.css('.faceted-search__title')).nativeElement;
      expect(title.textContent).toEqual(`Select ${facetType}`);
    });

    it('should display cancel button',() => {
      const cancelButton: DebugElement = fixture.debugElement.query(By.css('.faceted-search__cancel'));
      expect(cancelButton).toBeTruthy();
    });

    it('should display apply filters button',() => {
      const applyFiltersButton: DebugElement = fixture.debugElement.query(By.css('.faceted-search__apply-filters'));
      expect(applyFiltersButton).toBeTruthy();
    });

    it('should display data on load', () => {
      expect(displayedFacets()).toEqual(facetLabels);
    });

    it('should not contain any chips on load', () => {
      let chips: DebugElement[] = fixture.debugElement.queryAll(By.css('.faceted-search__selection'));
      expect(chips.length).toBe(0);
    });

    it('should have a label for free text search field', () => {
      const searchTerm = fixture.debugElement.query(By.css('.faceted-search__filter'));
      expect(searchTerm.nativeElement.labels[0].textContent).toEqual(`Search for a ${facetType}`);
    });

    describe('existing facet selection', () => {
      let chips: DebugElement[];
      beforeEach(() => {
        let newSearchCriteria = new SearchCriteria();
        newSearchCriteria[searchParam] = ['facet2', 'facet5'];
        successHandler(newSearchCriteria);
        fixture.detectChanges();
        chips = fixture.debugElement.queryAll(By.css('.faceted-search__selection-text'));
      });

      it('should be displayed as chips', () => {
        const chipTexts = chips.map(it => it.nativeElement.textContent.trim());
        expect(chipTexts).toEqual(['facet2', 'facet5']);
      });
    });

    describe('clicking cancel', () => {
      let cancelButton;

      beforeEach(() => {
        selectFacet('facet1');
        fixture.detectChanges();
        cancelButton = fixture.debugElement.query(By.css('.faceted-search__cancel')).nativeElement as HTMLInputElement;
        cancelButton.click();
        fixture.detectChanges();
      });

      it('unselects countries', () => {
        expect(component.selectedFacets().length).toBe(0);
      });

      it('closes dialog', () => {
        expect(matDialogRef.close).toHaveBeenCalled();
      });
    });

    describe('clicking the apply filters', () => {
      describe('with selection', () => {

        beforeEach(() => {
          let searchCriteria = new SearchCriteria();
          searchCriteria[searchParam] = [FACET5_NAME];
          successHandler(searchCriteria);
          selectFacet(FACET1_NAME);
          fixture.detectChanges();

          fixture.debugElement.query(By.css('.faceted-search__apply-filters'))
                 .nativeElement.click();
          fixture.detectChanges();
        });

        it('should call the update method of the criteria service with selected facets', () => {
          let searchCriteria = new SearchCriteria();
          searchCriteria[searchParam] = [FACET1_NAME, FACET5_NAME];

          expect(searchCriteriaService.update).toHaveBeenCalledWith(searchCriteria);
        });


        it('should close the dialog', () => {
          expect(matDialogRef.close).toHaveBeenCalled();
        });
      });

      describe('without selection', () => {
        beforeEach(() => {
          let searchCriteria = new SearchCriteria();
          searchCriteria[searchParam] = [];
          successHandler(searchCriteria);

          fixture.debugElement.query(By.css('.faceted-search__apply-filters'))
                 .nativeElement.click();
          fixture.detectChanges();
        });

        it('should set null value when nothing selected', () => {
          let searchCriteria = new SearchCriteria();
          searchCriteria[searchParam] = null;

          expect(searchCriteriaService.update).toHaveBeenCalledWith(searchCriteria);
        });
      });
    });

    describe('user selects facet in list',() => {

      let facet1Link : HTMLInputElement;

      beforeEach(() => {
        facet1Link = selectFacet(FACET1_NAME);
        fixture.detectChanges();
      });

      it('should disable facet link when selected', () => {
        let disabledLink = fixture.debugElement.query(By.css(`.faceted-search__link--selected[data-facet-id="${FACET1_NAME}"]`));

        expect(disabledLink).toBeTruthy();
      });

      describe('selected facet chip', () => {
        let chips: DebugElement[];
        beforeEach(() => {
          chips = fixture.debugElement.queryAll(By.css('.faceted-search__selection-text'));
        });

        it('should be displayed', () => {
          expect(chips.length).toBe(1);
        });

        it('should display the facet details', () => {
          const facet1Chip: HTMLElement = chips[0].nativeElement;
          expect(chips[0].nativeElement.textContent.trim()).toBe('facet1');
        });

        describe('user clicks chips',() => {
          beforeEach(() => {
            selectFacet(FACET2_NAME);
            fixture.detectChanges();

            let removefacet1Chip = fixture.debugElement.query(By.css(`.faceted-search__selection[data-facet-id="${FACET1_NAME}"] .faceted-search__selection-remove`)).nativeElement as HTMLInputElement;
            expect(removefacet1Chip).toBeTruthy();
            removefacet1Chip.click();

            fixture.detectChanges();
          });

          it('should remove the chip', () => {
            let chips = fixture.debugElement.queryAll(By.css('.faceted-search__selection'));

            expect(chips.length).toBe(1);
            expect(chips[0].nativeElement.getAttribute('data-facet-id')).toBe(FACET2_NAME);
          });

          it('should re-enable facet link when chip is removed' , () => {
            let gbLink = fixture.debugElement.query(By.css(`.faceted-search__link--selected[data-facet-id="${FACET1_NAME}"]`));

            expect(gbLink == null).toBeTruthy();
          });
        });
      });
    });

    describe('filter selection list', () => {
      let facetFilter;

      describe('no search results',() => {
        beforeEach(() => {
          fixture.detectChanges();

          facetFilter = fixture.debugElement.query(By.css('.faceted-search__filter')).nativeElement;
          facetFilter.value = 'zzz';
          facetFilter.dispatchEvent(new Event('input'));
          fixture.detectChanges();
        });

        it('displays the no results found message',() => {
          const noResults = fixture.debugElement.query(By.css('.faceted-search__no-results-found')).nativeElement;
          expect(noResults.textContent).toBe('No results found');
        });

        it('hides all the facets',() => {
          const hiddenFacetList = fixture.debugElement.queryAll(By.css('.faceted-search__link--hidden'));
          expect(hiddenFacetList.length).toEqual(5);
        });
      });

      describe('has search results',() => {
        beforeEach(() => {
          fixture.detectChanges();

          facetFilter = fixture.debugElement.query(By.css('.faceted-search__filter')).nativeElement;
          facetFilter.value = 'A';
          facetFilter.dispatchEvent(new Event('input'));
          fixture.detectChanges();
        });

        it('should only show items that start with the search term', () => {
          const hiddenFacetElements = fixture.debugElement.queryAll(By.css('.faceted-search__link--hidden'));
          const hiddenFacetNames = hiddenFacetElements.map(facetElement => facetElement.nativeElement.textContent);

          expect(hiddenFacetNames).toEqual([facetLabels[0], facetLabels[1], facetLabels[4]]);
        });

        it('should not display no results found message',() => {
          const noResults = fixture.debugElement.query(By.css('.faceted-search__no-results-found'));
          expect(noResults == null).toBeTruthy();
        });

        describe('and remove the term', () => {

          it('should display all the results', () => {
            facetFilter.value = '';
            facetFilter.dispatchEvent(new Event('keyup'));
            fixture.detectChanges();

            expect(displayedFacets()).toEqual(facetLabels);
          });
        });
      });
    });
  });
});
