import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {SearchFilterComponent} from './search-filter.component';
import {Facets, Facet} from "../facets";
import {FacetedSearchComponent} from "./faceted-search/faceted-search.component";
import {By} from "@angular/platform-browser";
import {DebugElement, Directive, Input, SimpleChange} from "@angular/core";
import {BrowserDynamicTestingModule} from "@angular/platform-browser-dynamic/testing";
import {MatDialog, MatDialogModule} from '@angular/material/dialog';
import {MatListModule} from "@angular/material/list";
import {MatChipsModule, MatFormFieldModule, MatIconModule} from "@angular/material";
import {FacetNotMatchingPipe} from '../facet-not-matching.pipe';
import {FormsModule} from "@angular/forms";
import {FlexLayoutModule} from "@angular/flex-layout";
import {MatInputModule} from "@angular/material/input";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import { SearchCriteria } from '../search-criteria';
import {CountryFacet} from "../countries-facet";
import { Country } from '../country';
import { TransportModeFacet} from "../transport-mode-facet";
import { TransportMode } from '../transport-mode';

@Directive({
  selector: 'cds-entry-date-filter'
})
export class EntryDateFilterStub {}

@Directive({
  selector: 'cds-links-facet'
})
export class LinksFacetStub {
  @Input() label: string;
  @Input() searchParam: string;
  @Input() facets: Array<Facet>;
}

describe('SearchFilterComponent', () => {
  let component: SearchFilterComponent;
  let fixture: ComponentFixture<SearchFilterComponent>;
  let filter: DebugElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MatDialogModule, MatListModule, MatChipsModule, MatIconModule , MatInputModule, BrowserAnimationsModule , FlexLayoutModule, FormsModule],
      declarations: [SearchFilterComponent, FacetedSearchComponent , FacetNotMatchingPipe, EntryDateFilterStub, LinksFacetStub]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    filter = fixture.debugElement.query(By.css('.search-filter'));
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should contain the filters label', () => {
    let label = filter.query(By.css('.search-filter__label')).nativeElement;
    expect(label.innerText).toBe('Filters')
  });

  describe('any changes to input properties should update', () => {
    let facets: Facets;
    const linkFacet = (code, count) => ({'id': code, 'count': count} as Facet);
    const countryFacet = (code, count) => ({ 'country': { 'code': code }, 'count': count} as CountryFacet);
    const transportModeFacet = (code, count) => ({ 'mode': { 'code': code }, 'count': count} as TransportModeFacet);

    beforeEach(() => {
      facets  = new Facets();
      facets.originCountries = [countryFacet('oc1', 3)];
      facets.dispatchCountries = [countryFacet('dis1', 1)];
      facets.destinationCountries = [countryFacet('des1', 5)];
      facets.transportModes = [transportModeFacet('tm1', 4)];
    });

    beforeEach(() => {
      component.ngOnChanges({
        'facets': new SimpleChange(null, facets, true)
      });

      fixture.detectChanges();
    });

    it('facets', () => {
      expect(component.facets).toBe(facets);
    });

    it('origin country facets', () => {
      const country = linkFacet(facets.originCountries[0].country.code, facets.originCountries[0].count);
      expect(component.linksFacets[0].facets).toEqual([country]);
    });

    it('dispatch country facets', () => {
      const country = linkFacet(facets.dispatchCountries[0].country.code, facets.dispatchCountries[0].count);
      expect(component.linksFacets[1].facets).toEqual([country]);
    });

    it('destination country facets', () => {
      const country = linkFacet(facets.destinationCountries[0].country.code, facets.destinationCountries[0].count);
      expect(component.linksFacets[2].facets).toEqual([country]);
    });

    it('destination country facets', () => {
      const country = linkFacet(facets.transportModes[0].mode.code, facets.transportModes[0].count);
      expect(component.linksFacets[3].facets).toEqual([country]);
    });
  });
});
