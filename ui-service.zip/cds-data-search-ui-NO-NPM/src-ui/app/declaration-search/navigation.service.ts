import { Injectable, OnDestroy } from '@angular/core';
import { OnInit } from '@angular/core/src/metadata/lifecycle_hooks';
import { SearchCriteriaService } from './search-criteria.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { SearchCriteria } from './search-criteria';

@Injectable()
export class NavigationService {

  constructor(private searchCriteriaService: SearchCriteriaService,
              private router: Router,
              private route: ActivatedRoute) {
    this.subscribeToSearchCriteria();
    this.subscribeToQueryParams();
  }

  subscribeToSearchCriteria() {
    this.searchCriteriaService.searchCriteria.subscribe(
      data => this.router.navigate(['/'], {
          queryParams: data
        })
    );
  }

  subscribeToQueryParams() {
    this.route.queryParamMap.subscribe(params => {
      const newSearchCriteria = new SearchCriteria();
      newSearchCriteria.searchTerm = params.get('searchTerm');

      ['originCountryCode', 'dispatchCountryCode', 'destinationCountryCode', 'transportModeCode']
        .forEach(param => {
          if (params.has(param)) {
            newSearchCriteria[param] = params.getAll(param);
          }
        });

      newSearchCriteria.entryDateFrom = params.get('entryDateFrom');
      newSearchCriteria.entryDateTo = params.get('entryDateTo');

      this.searchCriteriaService.update(newSearchCriteria);
    });
  }
}
