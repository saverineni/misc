import { TransportMode } from "./transport-mode";

export class TransportModeFacet {
  mode: TransportMode;
  count: number;
}
