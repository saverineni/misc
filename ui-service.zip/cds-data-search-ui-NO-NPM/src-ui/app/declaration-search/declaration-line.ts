import { Country } from './country';

export class DeclarationLine {
    itemNumber: number;
    dispatchCountryCode: string;
    destinationCountryCode: string;
    clearanceDate: string;
    cpc: string;
    originCountry: Country;
    commodityCode: string;
    itemConsigneeTurn: string;
    itemConsignorTurn: string;
    itemRoute: string;
    itemConsigneeName: string;
    itemConsigneePostcode: string;
    itemConsignorName: string;
    itemConsignorPostcode: string;
}
