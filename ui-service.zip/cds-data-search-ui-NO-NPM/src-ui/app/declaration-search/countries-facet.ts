import { Country } from "./country";
import { Facet } from "./facets";

export class CountryFacet {
  country: Country;
  count: number;
}
