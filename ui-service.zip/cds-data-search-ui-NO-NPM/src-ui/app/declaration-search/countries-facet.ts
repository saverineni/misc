import { Country } from "./country";

export class CountryFacet {
  country: Country;
  count: number;
}
