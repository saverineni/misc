import {getTestBed, TestBed} from '@angular/core/testing';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {SearchService} from './search.service';
import {SearchCriteria} from './search-criteria';
import {DeclarationSearchResult, Hits} from './declaration-search-result';
import {Declaration} from './declaration';


describe('SearchService', () => {
  let httpMock: HttpTestingController;
  let service: SearchService;
  let searchCriteria: SearchCriteria;

  beforeEach(() => {
    searchCriteria = new SearchCriteria();

    TestBed.configureTestingModule({
      providers: [SearchService],
      imports: [HttpClientTestingModule]
    });
    httpMock = getTestBed().get(HttpTestingController);
    service = getTestBed().get(SearchService);
  });

  function mockRequest(expectedParams = {}) {
    let url = Object.getOwnPropertyNames(expectedParams)
                    .reduce((url, key) => `${url}${key}=${expectedParams[key]}&`, '/api/declarations?')
    return httpMock.expectOne(url.substring(0, url.length - 1));
  }

  describe('facet population request', () => {

    it('should add the page size parameter', () => {
      service.facetPopulation().toPromise();
      const testRequest = mockRequest({ pageSize: "0" });
      testRequest.flush({});

      expect(testRequest.request.method).toBe("GET");
    });

    it('should return Declaration search result', () => {
      let actual: DeclarationSearchResult;
      service.search(searchCriteria).subscribe(result => actual = result);
      const testRequest = mockRequest();
      testRequest.flush({ hits: { total: 123 }, declarations: []}, {status: 200, statusText: ''});
      expect(actual.hits.total).toEqual(123);
    });
  });

  describe('submit search request', () => {
    let testRequest;

    it('should add the search term parameter', () => {
      searchCriteria.searchTerm = "123-456";
      service.search(searchCriteria).toPromise();
      testRequest = mockRequest({searchTerm: "123-456"});
    });

    it('should add the entry date from  parameter', () => {
      searchCriteria.entryDateFrom = "2018-01-01";
      service.search(searchCriteria).toPromise();
      testRequest = mockRequest({entryDateFrom: "2018-01-01"});
    });

    it('should add the entry date to parameter', () => {
      searchCriteria.entryDateTo = "2018-01-02";
      service.search(searchCriteria).toPromise();
      testRequest = mockRequest({entryDateTo: "2018-01-02"});
    });

    it('should add the origin country code parameters', () => {
      searchCriteria.originCountryCode = [ 'A', 'B', 'C' ];
      service.search(searchCriteria).toPromise();
      testRequest = mockRequest({originCountryCode: 'A&originCountryCode=B&originCountryCode=C'});
    });


    it('should add multiple params', () => {
      searchCriteria.searchTerm = "123-456";
      searchCriteria.entryDateTo = "2018-01-02";
      service.search(searchCriteria).toPromise();
      testRequest = mockRequest({searchTerm: "123-456", entryDateTo: "2018-01-02"});
    });


    afterEach(() => {
      testRequest.flush({});

      expect(testRequest.request.method).toBe("GET");
    });
  });

  it('should throw error on 500', (done) => {
    const errorEvent = new ErrorEvent('');
    service.search(searchCriteria).subscribe(
      result => done.fail('expect error'),
      error => {
        expect(error.error).toBe(errorEvent);
        done();
      });
    const testRequest = mockRequest();
    testRequest.error(errorEvent, {status: 500});
  });

  it('should return Declaration search result', () => {
    let actual: DeclarationSearchResult = null;
    service.search(searchCriteria).subscribe(result => actual = result);
    const testRequest = mockRequest();
    testRequest.flush({hits: new Hits(), declarations: [new Declaration()]}, {status: 200, statusText: ''});
    expect(actual.declarations.length).toEqual(1);
  });

  it('should parse the json response', () => {
    const declaration = new Declaration();
    declaration.declarationId = searchCriteria.searchTerm;
    const hits = new Hits();
    hits.total = 1;

    let actual: DeclarationSearchResult = null;
    service.search(searchCriteria).subscribe(result => actual = result);
    const testRequest = mockRequest();
    testRequest.flush({hits, declarations: [declaration]}, {status: 200, statusText: ''});
    expect(actual.declarations[0]).toEqual(declaration);
    expect(actual.hits).toEqual(hits);
  });

  afterEach(() => {
    httpMock.verify();
  });
});
