import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { SearchCriteria } from '../search-criteria';
import { SearchService } from '../search.service';
import { DeclarationSearchResult } from '../declaration-search-result';
import { ActivatedRoute, NavigationEnd } from '@angular/router';
import { Observable, Subscription, concat } from 'rxjs';
import { SearchCriteriaService } from '../search-criteria.service';
import { NavigationService } from '../navigation.service';

@Component({
  selector: 'cds-search-section',
  templateUrl: './search-section.component.html',
  styleUrls: ['./search-section.component.scss']
})
export class SearchSectionComponent implements OnInit, OnDestroy {

  result: DeclarationSearchResult = null;
  searchCriteriaSubscription: Subscription;
  searchCriteria: SearchCriteria;

  constructor(private searchService: SearchService,
     private searchCriteriaService: SearchCriteriaService,
     private navigationService: NavigationService) { }

  ngOnInit() {
    this.searchCriteriaSubscription =
      this.searchCriteriaService.searchCriteria.subscribe(
        newSearchCriteria => {
          this.searchCriteria = newSearchCriteria;
          if (newSearchCriteria.isEmpty()) {
            this.populateFacets();
          } else {
            this.performSearch();
          };
        }
      );
  }

  private populateFacets() {
    this.searchService.facetPopulation()
      .subscribe(
        result => this.result = result
      );
  }

  private performSearch() {
    this.searchService.search(this.searchCriteria)
      .subscribe(
        result => this.result = result
      );
  }

  ngOnDestroy() {
    this.searchCriteriaSubscription.unsubscribe();
  }

}
