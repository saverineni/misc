import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { SearchCriteria } from '../search-criteria';
import { SearchService } from '../search.service';
import { DeclarationSearchResult } from '../declaration-search-result';
import { ActivatedRoute, NavigationEnd } from '@angular/router';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import {concat} from 'rxjs/operators';
import { SearchCriteriaService } from '../search-criteria.service';
import { NavigationService } from '../navigation.service';

@Component({
  selector: 'cds-search-section',
  templateUrl: './search-section.component.html',
  styleUrls: ['./search-section.component.scss']
})
export class SearchSectionComponent implements OnInit, OnDestroy {

  result: DeclarationSearchResult = null;
  searchCriteriaSubscription: Subscription;
  searchCriteria: SearchCriteria;

  constructor(private searchService: SearchService,
     private searchCriteriaService: SearchCriteriaService,
     private navigationService: NavigationService) { }

  ngOnInit() {
    this.searchCriteriaSubscription =
      this.searchCriteriaService.searchCriteria.subscribe(
        newSearchCriteria => {
          this.searchCriteria = newSearchCriteria;
          if (newSearchCriteria.isEmpty()) {
            this.result = null;
          } else {
            this.searchService.search(newSearchCriteria)
              .subscribe(
                result => this.result = result
              );
          };
        }
      );
  }

  ngOnDestroy() {
    this.searchCriteriaSubscription.unsubscribe();
  }
}
