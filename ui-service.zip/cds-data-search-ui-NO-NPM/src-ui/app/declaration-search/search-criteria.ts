export class SearchCriteria {
  searchTerm: string;
  originCountryCode: string[];
  dispatchCountryCode: string[];
  destinationCountryCode: string[];
  entryDateFrom: string;
  entryDateTo: string;

  isEmpty(): boolean {
    return this.searchTerm == null &&
      this.originCountryCode == null &&
      this.dispatchCountryCode == null &&
      this.destinationCountryCode == null &&
      this.entryDateFrom == null &&
      this.entryDateTo == null;
  }
}
