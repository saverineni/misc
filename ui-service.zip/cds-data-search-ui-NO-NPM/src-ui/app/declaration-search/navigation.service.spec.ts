import { TestBed, inject } from '@angular/core/testing';
import { NavigationService } from './navigation.service';
import { SearchCriteria } from './search-criteria';
import { Observable, of, Subscription } from 'rxjs';
import { Router, ActivatedRoute, Params, ParamMap, convertToParamMap } from '@angular/router';
import { SearchCriteriaService } from './search-criteria.service';

describe('NavigationService', () => {
  let navigationService : NavigationService;
  let searchCriteriaServiceStub: SearchCriteriaService;
  let testSearchCriteriaObservable: Observable<SearchCriteria>;
  let testQueryParamsObservable: Observable<Params>;
  let testSearchCriteriaSubscription: Subscription;
  let testQueryParamsSubscription: Subscription;

  let testRouter = {
    navigate: (commands, extras) => {}
  } as Router;

  let testActivatedRoute;

  let successSearchCriteriaHandler;
  let successQueryParamsHandler;

  beforeEach(() => {
    testSearchCriteriaObservable = of(null);
    spyOn(testSearchCriteriaObservable, 'subscribe')
        .and.callFake(success => successSearchCriteriaHandler = success);

    searchCriteriaServiceStub = {
      searchCriteria: testSearchCriteriaObservable,
      update: (criteria) => {}
    } as SearchCriteriaService;
    spyOn(searchCriteriaServiceStub, 'update');

    testQueryParamsObservable = of(null);
    spyOn(testQueryParamsObservable, 'subscribe')
        .and.callFake(success => successQueryParamsHandler = success);

    testActivatedRoute = {
      queryParamMap: testQueryParamsObservable
    } as ActivatedRoute;

    spyOn(testRouter, 'navigate');

    navigationService = new NavigationService(searchCriteriaServiceStub, testRouter, testActivatedRoute);
  });

  describe('after creation', () => {
    describe('search criteria',() => {
      it('should subscribe to successful updates', () => {
        expect(successSearchCriteriaHandler).toBeTruthy();
      });

      it('should navigate for the params' , () => {
        let searchCriteria = new SearchCriteria();
        successSearchCriteriaHandler(searchCriteria);
        expect(testRouter.navigate).toHaveBeenCalledWith(['/'],{queryParams: searchCriteria});
      });
    });

    describe('query params',() => {
      let paramMap: ParamMap;

      it('should subscribe to successful updates', () => {
        expect(successQueryParamsHandler).toBeTruthy();
      });

      it('should update the search criteria' , () => {
        paramMap = convertToParamMap({searchTerm: 'term', originCountryCode: ['AB','CD'], dispatchCountryCode: ['EF'], destinationCountryCode: ['GH'] , entryDateFrom: '2018-01-01', entryDateTo: '2018-01-02'});
        let searchCriteria = new SearchCriteria();
        searchCriteria.searchTerm = 'term';
        searchCriteria.originCountryCode =  ['AB','CD'];
        searchCriteria.dispatchCountryCode =  ['EF'];
        searchCriteria.destinationCountryCode =  ['GH'];
        searchCriteria.entryDateFrom = '2018-01-01';
        searchCriteria.entryDateTo = '2018-01-02';

        successQueryParamsHandler(paramMap);
        expect(searchCriteriaServiceStub.update).toHaveBeenCalledWith(searchCriteria);
      });

      it('should update as null for an empty array' , () => {
        paramMap = convertToParamMap({searchTerm: 'term'});
        let searchCriteria = new SearchCriteria();
        searchCriteria.searchTerm = 'term';
        searchCriteria.entryDateFrom = null;
        searchCriteria.entryDateTo = null;

        successQueryParamsHandler(paramMap);
        expect(searchCriteriaServiceStub.update).toHaveBeenCalledWith(searchCriteria);
      });
    });
  });
});
