export class TransportMode {
  code: string;
}