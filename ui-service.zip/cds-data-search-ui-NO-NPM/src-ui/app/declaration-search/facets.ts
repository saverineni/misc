import { CountryFacet } from "./countries-facet";
import { TransportModeFacet } from "./transport-mode-facet";

export class Facets {
  originCountries: Array<CountryFacet>;
  dispatchCountries: Array<CountryFacet>;
  destinationCountries: Array<CountryFacet>;
  transportModes: Array<TransportModeFacet>;
}

export interface Facet {
  id: String
  count: number
}
