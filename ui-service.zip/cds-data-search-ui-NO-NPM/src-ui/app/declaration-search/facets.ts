import { CountryFacet } from "./countries-facet";

export class Facets {
  originCountries: Array<CountryFacet>;
  dispatchCountries: Array<CountryFacet>;
  destinationCountries: Array<CountryFacet>;
}

export interface Facet {
  id: String
  count: number
}
