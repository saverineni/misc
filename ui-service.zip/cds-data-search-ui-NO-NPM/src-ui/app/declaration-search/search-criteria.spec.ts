import { SearchCriteria } from './search-criteria';

describe('SearchCriteria', () => {
  describe('is empty', () => {
    it('should give true when no values set', () => {
      let criteria = new SearchCriteria();
      expect(criteria.isEmpty()).toBe(true);
    })
  });

  describe('is not empty', () => {
    let searchCriteria: SearchCriteria;

    beforeEach(() => {
      searchCriteria = new SearchCriteria();
    });

    it('should give false when searchTerm set', () => {
      searchCriteria.searchTerm = 'term';
      expect(searchCriteria.isEmpty()).toBe(false);
    });

    it('should give false when no origin country code is set', () => {
      searchCriteria.originCountryCode = [ 'code' ];
      expect(searchCriteria.isEmpty()).toBe(false);
    });

    it('should give false when no dispatch country code is set', () => {
      searchCriteria.dispatchCountryCode = [ 'code' ];
      expect(searchCriteria.isEmpty()).toBe(false);
    });

    it('should give false when no destination country code is set', () => {
      searchCriteria.destinationCountryCode = [ 'code' ];
      expect(searchCriteria.isEmpty()).toBe(false);
    });

    it('should give false when no entry date from is set', () => {
      searchCriteria.entryDateFrom = '2018-01-01';
      expect(searchCriteria.isEmpty()).toBe(false);
    });

    it('should give false when no entry date to is set', () => {
      searchCriteria.entryDateTo = '2018-01-01';
      expect(searchCriteria.isEmpty()).toBe(false);
    });
  });
});
