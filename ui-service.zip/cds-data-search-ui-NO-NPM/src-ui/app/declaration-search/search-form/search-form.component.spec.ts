import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {FlexLayoutModule} from '@angular/flex-layout';
import {FormsModule} from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import {By} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ActivatedRoute} from '@angular/router';
import {ReplaySubject} from 'rxjs';
import {SearchFormComponent} from './search-form.component';
import { SearchCriteria } from '../search-criteria';
import { SearchCriteriaService } from '../search-criteria.service';
import { Observable } from 'rxjs';
import { Subscription } from 'rxjs';

class ActivatedRouteStub {

  private subject = new ReplaySubject<any>();

  readonly queryParams = this.subject.asObservable();

  setQueryParams(queryParams?: any) {
    this.subject.next(queryParams);
  };
}

describe('SearchFormComponent', () => {
  let component: SearchFormComponent;
  let fixture: ComponentFixture<SearchFormComponent>;
  let newRoute;
  let searchCriteriaService;

  beforeEach(async(() => {
    newRoute = new ActivatedRouteStub();

    TestBed.configureTestingModule({
      declarations: [SearchFormComponent],
      providers: [
        SearchCriteriaService,
        {provide: ActivatedRoute, useValue: newRoute}
      ],
      imports: [
        FlexLayoutModule,
        MatButtonModule,
        MatInputModule,
        BrowserAnimationsModule,
        FormsModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFormComponent);
    component = fixture.componentInstance;
    searchCriteriaService = TestBed.get(SearchCriteriaService);

    fixture.detectChanges();
  });

  describe('search form', () => {
    let form;

    beforeEach(async(() => {
      form = fixture.debugElement.query(By.css('.search-form'));
    }));

    it('should be displayed', () => {
      expect(form).toBeTruthy();
    });

    describe('Free text search field', () => {
      const expected = 'expected-term';
      let searchTerm;
      beforeEach(() => {
        searchTerm = form.query(By.css('.search-form__searchterm-input'));
      });

      it('should have a free text search field', () => {
        expect(searchTerm).toBeTruthy();
      });

      it('should have focus', () => {
        const focusedElement = form.query(By.css(":focus")).nativeElement;
        expect(searchTerm.nativeElement).toBe(focusedElement);
      });

      it('should have a label for free text search field', () => {
        expect(searchTerm.nativeElement.labels[0].textContent).toEqual("Declaration Search");
      });

      it('should be bound to the model', () => {
        const searchTermField = searchTerm.nativeElement;
        searchTermField.value = expected;
        searchTermField.dispatchEvent(new Event("input"));
        fixture.detectChanges();

        expect(component.searchTerm).toEqual(expected);
      });

      it('should update declaration search term on new observable event', () => {
        const searchCriteria = new SearchCriteria();
        searchCriteria.searchTerm = expected;

        searchCriteriaService.update(searchCriteria);

        expect(component.searchTerm).toEqual(expected);
      })

      it('should have focus after angular router navigation back to home', () => {
        form.query(By.css('.search-form__button')).nativeElement.focus();

        newRoute.setQueryParams({});

        const focusedElement = form.query(By.css(":focus")).nativeElement;
        expect(searchTerm.nativeElement).toBe(focusedElement);
      });

      it('should not acquire focus after other angular router navigation', () => {
        const searchButton = form.query(By.css('.search-form__button')).nativeElement;
        searchButton.focus();

        newRoute.setQueryParams({searchTerm: ''});

        const focusedElement = form.query(By.css(":focus")).nativeElement;
        expect(searchButton).toBe(focusedElement);
      });
    });

    describe('search button', () => {

      let searchbutton;
      let searchTermField;
      beforeEach(() => {
        searchbutton = form.query(By.css('.search-form__button'));
        searchTermField = form.query(By.css('.search-form__searchterm-input')).nativeElement;
        fixture.detectChanges();
      });

      it('should have a button', () => {
        expect(searchbutton).toBeTruthy();
      });

      it('enabled on page load', () => {
        expect(searchbutton.nativeElement.disabled).toEqual(false);
      });

    });

    describe('submit form', () => {
      let searchTerm;

      beforeEach(() => {
        spyOn(searchCriteriaService, 'updatePartial');
      });

      afterEach(() => {
        expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith({searchTerm: searchTerm});
      });

      describe('with search term', () => {
        beforeEach(() => {
          searchTerm = 'search term';
          component.searchTerm = searchTerm;
        });

        it('should call update on service', () => {
          form.query(By.css('.search-form__button')).nativeElement.click();
        });

        it('should update on submit event', () => {
          form.nativeElement.dispatchEvent(new Event("submit"));
        });
      });

      describe('with null search term', () => {
        beforeEach(() => {
          component.searchTerm = null;
          form.nativeElement.dispatchEvent(new Event("submit"));
        });

        it('should submit empty string for null search term', () => {
          searchTerm = '';
        });
      });
    });
  });
});
