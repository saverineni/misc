import { Injectable } from '@angular/core';
import { SearchCriteria } from './search-criteria';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient, HttpParams } from '@angular/common/http';
import { DeclarationSearchResult } from './declaration-search-result';
import { Declaration } from './declaration';

@Injectable()
export class SearchService {

  constructor(private http: HttpClient) {}

  facetPopulation(): Observable<DeclarationSearchResult> {
    return this.http
      .get("/api/declarations", { params: { pageSize: "0"} })
      .pipe(
        map(searchResult => searchResult as DeclarationSearchResult)
      );
  }

  search(search: SearchCriteria): Observable<DeclarationSearchResult> {
    return this.http
      .get("/api/declarations", { params: this.buildParams(search) })
      .pipe(
        map(searchResult => searchResult as DeclarationSearchResult)
      );
  }

  private buildParams(search: SearchCriteria) {
    let extractedParams = Object.getOwnPropertyNames(search)
      .reduce((params, key) => this.applyNonNullParam(params, key, search[key]), {});

    return new HttpParams({ fromObject: extractedParams });
  }

  private applyNonNullParam(params, key, value) {
    if (value != null) {
      params[key] = value;
    }

    return params;
  }
}
