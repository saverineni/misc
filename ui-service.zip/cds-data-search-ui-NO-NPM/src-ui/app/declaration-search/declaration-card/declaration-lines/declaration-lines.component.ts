import { Component, Input, ViewChild, TemplateRef } from '@angular/core';
import { Declaration } from '../../declaration';
import { DataSource } from '@angular/cdk/table';
import { Observable, of } from 'rxjs';
import { DeclarationLine } from '../../declaration-line';
import { Trader } from '../../trader';
import { TrackBy } from '../../../track-by';
import { ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'cds-declaration-lines',
  templateUrl: './declaration-lines.component.html',
  styleUrls: ['./declaration-lines.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DeclarationLinesComponent {
  trackById = TrackBy.property('id');

  @ViewChild("itemNumber") itemNumber: TemplateRef<any>;
  @ViewChild("route") route: TemplateRef<any>;
  @ViewChild("itemDispatchCountry") itemDispatchCountry: TemplateRef<any>;
  @ViewChild("itemDestinationCountry") itemDestinationCountry: TemplateRef<any>;
  @ViewChild("clearanceDate") clearanceDate: TemplateRef<any>;
  @ViewChild("cpc") cpc: TemplateRef<any>;
  @ViewChild("originCountry") originCountry: TemplateRef<any>;
  @ViewChild("commodityCode") commodityCode: TemplateRef<any>;
  @ViewChild("consignee") consignee: TemplateRef<any>;
  @ViewChild("consignor") consignor: TemplateRef<any>;

  @Input() declaration: Declaration;

  declarationLineColumns = [
    { id: 'itemNumber', label: 'Item Number' },
    { id: 'route', label: 'Route of Entry' },
    { id: 'itemDispatchCountry', label: 'Country of Dispatch' },
    { id: 'itemDestinationCountry', label: 'Country of Destination' },
    { id: 'clearanceDate', label: 'Clearance Date' },
    { id: 'cpc', label: 'CPC' },
    { id: 'originCountry', label: 'Country of Origin' },
    { id: 'commodityCode', label: 'Commodity Code' },
    { id: 'consignee', label: 'Consignee' },
    { id: 'consignor', label: 'Consignor' }
  ];

  declarationLineColumnRefs = this.declarationLineColumns.map(column => column.id);

  ngAfterContentInit() {
    this.declarationLineColumns.forEach(column => column['template'] = this[column.id]);
  }

  dataSource() {
    return this.declaration.lines.map( line => this.decorate(line));
  }

  decorate(line: DeclarationLine): DeclarationLine {
    line['consignee'] = this.consigneeFrom(line);
    line['consignor'] = this.consignorFrom(line);
    return line;
  }

  consigneeFrom(line: DeclarationLine): Trader {
    return {
      number: line.itemConsigneeTurn,
      name: line.itemConsigneeName,
      postcode: line.itemConsigneePostcode
    };
  }

  consignorFrom(line: DeclarationLine): Trader {
    return {
      number: line.itemConsignorTurn,
      name: line.itemConsignorName,
      postcode: line.itemConsignorPostcode
    };
  }

}
