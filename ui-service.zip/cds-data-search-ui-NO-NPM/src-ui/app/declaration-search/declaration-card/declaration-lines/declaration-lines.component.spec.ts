import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {By} from '@angular/platform-browser';
import {MatTableModule} from '@angular/material/table';
import {DeclarationLinesComponent} from './declaration-lines.component';
import {Declaration} from '../../declaration';
import {DeclarationLine} from '../../declaration-line';
import {Component, Input} from '@angular/core';

@Component({
  selector: 'cds-trader',
  template: '{{ trader?.number }}{{trader?.name}}{{trader?.postcode}}'
})
export class TraderComponentStub {
  @Input() trader;
}

describe('DeclarationLinesComponent', () => {
  let component: DeclarationLinesComponent;
  let fixture: ComponentFixture<DeclarationLinesComponent>;

  function getNoLinesDebugElement() {
    return fixture.debugElement.query(By.css('.declaration-lines__no-lines-found'));
  }

  function getLinesTableDebugElement() {
    return fixture.debugElement.query(By.css('.declaration-lines__table'));
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MatTableModule],
      declarations: [DeclarationLinesComponent, TraderComponentStub]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeclarationLinesComponent);
    component = fixture.componentInstance;
  });

  describe('null lines', () => {
    beforeEach(() => {
      component.declaration = new Declaration();
      fixture.detectChanges();
    });

    it('compiles component successfully', () => {
      expect(fixture.componentInstance).toBeTruthy();
    });
  });

  const declarationLine = new DeclarationLine();
  declarationLine.itemNumber = 1;
  declarationLine.itemDispatchCountry = { code: 'dispatchCountryCode'};
  declarationLine.itemDestinationCountry = { code: 'destinationCountryCode'};
  declarationLine.clearanceDate = 'clearanceDate';
  declarationLine.cpc = 'cpc';
  declarationLine.originCountry = { code: 'originCountryCode' };
  declarationLine.commodityCode = 'commodityCode';
  declarationLine.itemConsigneeTurn = 'itemConsigneeTurn';
  declarationLine.itemConsignorTurn = 'itemConsignorTurn';
  declarationLine.itemRoute = 'itemRoute';
  declarationLine.itemConsigneeName = 'itemConsigneeName';
  declarationLine.itemConsigneePostcode = 'itemConsigneePostcode';
  declarationLine.itemConsignorName = 'itemConsignorName';
  declarationLine.itemConsignorPostcode = 'itemConsignorPostcode';

  const declarationLineSpecs = [
    { id: 'itemNumber', label: 'Item Number', value: declarationLine => declarationLine.itemNumber.toString() },
    { id: 'itemDispatchCountry', label: 'Country of Dispatch', value: declarationLine => declarationLine.itemDispatchCountry.code },
    { id: 'itemDestinationCountry', label: 'Country of Destination', value: declarationLine => declarationLine.itemDestinationCountry.code },
    { id: 'clearanceDate', label: 'Clearance Date', value: declarationLine => declarationLine.clearanceDate },
    { id: 'cpc', label: 'CPC', value: declarationLine => declarationLine.cpc },
    { id: 'originCountry', label: 'Country of Origin', value: declarationLine => declarationLine.originCountry.code },
    { id: 'commodityCode', label: 'Commodity Code', value: declarationLine => declarationLine.commodityCode },
    { id: 'route', label: 'Route of Entry', value: declarationLine => declarationLine.itemRoute },
    {
      id: 'consignee',
      label: 'Consignee',
      value: declarationLine =>
        `${declarationLine.itemConsigneeTurn}${declarationLine.itemConsigneeName}${declarationLine.itemConsigneePostcode}`
    },
    {
      id: 'consignor',
      label: 'Consignor',
      value: declarationLine =>
        `${declarationLine.itemConsignorTurn}${declarationLine.itemConsignorName}${declarationLine.itemConsignorPostcode}`
    }
  ];

  describe('lines present', () => {

    beforeEach(() => {
      const declaration = new Declaration();
      declaration.lines = [declarationLine];
      component.declaration = declaration;
      fixture.detectChanges();
    });

    it('should not display no lines found message', () => {
      expect(getNoLinesDebugElement() === null).toEqual(true);
    });

    it('should display the lines table', () => {
      expect(getLinesTableDebugElement() === null).toEqual(false);
    });

    describe('table columns', () => {
      declarationLineSpecs.forEach(spec => {
        describe(`the ${spec.label} table column`, () => {
          it(`should display the ${spec.label} table heading`, () => {
            expect(fixture.debugElement.query(By.css(`.declaration-lines__${spec.id}-column-header`)).nativeElement.innerText)
            .toEqual(spec.label);
          });

          it(`should display the ${spec.label} value`, () => {
            expect(fixture.debugElement.query(By.css(`.declaration-lines__${spec.id}`)).nativeElement.innerText.trim())
              .toEqual(spec.value(declarationLine));
          });
        });
      });
    });
  });

  describe('line present with NULL values', () => {
    beforeEach(() => {
      let dec = new Declaration()
      dec.lines = [new DeclarationLine()];
      component.declaration = dec;
      fixture.detectChanges();
    });

    describe('table columns', () => {
      declarationLineSpecs.forEach(spec => {
        describe(`the ${spec.id} table column`, () => {
          it(`should display a blank`, () => {
            expect(fixture.debugElement.query(By.css(`.declaration-lines__${spec.id}`)).nativeElement.innerText)
              .toEqual('');
          });
        });
      });
    });
  });
});
