import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { MatTableModule } from '@angular/material/table';

import { DeclarationLinesComponent } from './declaration-lines.component';
import { Declaration } from '../../declaration';
import { DeclarationLine } from '../../declaration-line';
import { by } from 'protractor';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'cds-trader',
  template: '{{ trader?.number }}{{trader?.name}}{{trader?.postcode}}'
})
export class TraderComponentStub {
  @Input() trader;
}

describe('DeclarationLinesComponent', () => {
  let component: DeclarationLinesComponent;
  let fixture: ComponentFixture<DeclarationLinesComponent>;

  function getNoLinesDebugElement() {
    return fixture.debugElement.query(By.css('.declaration-lines__no-lines-found'));
  }

  function getLinesTableDebugElement() {
    return fixture.debugElement.query(By.css('.declaration-lines__table'));
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MatTableModule],
      declarations: [DeclarationLinesComponent, TraderComponentStub]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeclarationLinesComponent);
    component = fixture.componentInstance;
    component.declaration = new Declaration();
    component.declaration.lines = [];
    fixture.detectChanges();
  });

  describe('null lines', () => {
    beforeEach(() => {
      component.declaration.lines = null;
      fixture.detectChanges();
    });

    it('compiles component successfully', () => {
      expect(fixture.componentInstance).toBeTruthy();
    });
  });

  const declarationLine = new DeclarationLine();
  declarationLine.itemNumber = 1;
  declarationLine.dispatchCountryCode = 'dispatchCountryCode';
  declarationLine.destinationCountryCode = 'destinationCountryCode';
  declarationLine.clearanceDate = 'clearanceDate';
  declarationLine.cpc = 'cpc';
  declarationLine.originCountry = { code: 'originCountryCode' };
  declarationLine.commodityCode = 'commodityCode';
  declarationLine.itemConsigneeTurn = 'itemConsigneeTurn';
  declarationLine.itemConsignorTurn = 'itemConsignorTurn';
  declarationLine.itemRoute = 'itemRoute';
  declarationLine.itemConsigneeName = 'itemConsigneeName';
  declarationLine.itemConsigneePostcode = 'itemConsigneePostcode';
  declarationLine.itemConsignorName = 'itemConsignorName';
  declarationLine.itemConsignorPostcode = 'itemConsignorPostcode';

  const declarationLineSpecs = [
    { id: 'itemNumber', label: 'Item Number', value: declarationLine => declarationLine.itemNumber.toString() },
    { id: 'dispatchCountry', label: 'Country of Dispatch', value: declarationLine => declarationLine.dispatchCountryCode },
    { id: 'destinationCountry', label: 'Country of Destination', value: declarationLine => declarationLine.destinationCountryCode },
    { id: 'clearanceDate', label: 'Clearance Date', value: declarationLine => declarationLine.clearanceDate },
    { id: 'cpc', label: 'CPC', value: declarationLine => declarationLine.cpc },
    { id: 'originCountry', label: 'Country of Origin', value: declarationLine => declarationLine.originCountry.code },
    { id: 'commodityCode', label: 'Commodity Code', value: declarationLine => declarationLine.commodityCode },
    { id: 'route', label: 'Route of Entry', value: declarationLine => declarationLine.itemRoute },
    {
      id: 'consignee',
      label: 'Consignee',
      value: declarationLine => `${declarationLine.itemConsigneeTurn}${declarationLine.itemConsigneeName}\
${declarationLine.itemConsigneePostcode}`
    },
    {
      id: 'consignor',
      label: 'Consignor',
      value: declarationLine => `${declarationLine.itemConsignorTurn}${declarationLine.itemConsignorName}\
${declarationLine.itemConsignorPostcode}`
    }
  ];

  describe('lines present', () => {

    beforeEach(() => {
      component.declaration.lines.push(declarationLine);
      fixture.detectChanges();
    });

    it('should not display no lines found message', () => {
      expect(getNoLinesDebugElement() === null).toEqual(true);
    });

    it('should display the lines table', () => {
      expect(getLinesTableDebugElement() === null).toEqual(false);
    });

    describe('table columns', () => {
      declarationLineSpecs.forEach(spec => {
        describe(`the ${spec.label} table column`, () => {
          it(`should display the ${spec.label} table heading`, () => {
            expect(fixture.debugElement.query(By.css(`.declaration-lines__${spec.id}-column-header`)).nativeElement.innerText)
            .toEqual(spec.label);
          });

          it(`should display the ${spec.label} value`, () => {
            expect(fixture.debugElement.query(By.css(`.declaration-lines__${spec.id}`)).nativeElement.innerText)
              .toEqual(spec.value(declarationLine));
          });
        });
      });
    });
  });

  describe('line present with NULL values', () => {
    const declarationLine = new DeclarationLine();

    beforeEach(() => {
      component.declaration.lines.push(declarationLine);
      fixture.detectChanges();
    });

    describe('table columns', () => {
      declarationLineSpecs.forEach(spec => {
        describe(`the ${spec.id} table column`, () => {
          it(`should display a blank`, () => {
            expect(fixture.debugElement.query(By.css(`.declaration-lines__${spec.id}`)).nativeElement.innerText)
              .toEqual('');
          });
        });
      });
    });
  });

});
