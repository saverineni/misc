import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'cds-trader',
  templateUrl: './trader.component.html',
  styleUrls: ['./trader.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TraderComponent {

  @Input() trader;

  populatedFields() {
    if (!this.trader) {
      return [];
    }

    return ['number', 'name', 'postcode']
      .filter(field => this.trader[field])
      .map(field => this.trader[field]);
  }

}
