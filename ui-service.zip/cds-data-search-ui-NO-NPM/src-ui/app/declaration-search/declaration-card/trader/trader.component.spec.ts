import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TraderComponent } from './trader.component';
import { Trader } from '../../trader';
import { By } from '@angular/platform-browser';

describe('TraderComponent', () => {
  let component: TraderComponent;
  let fixture: ComponentFixture<TraderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TraderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TraderComponent);
    component = fixture.componentInstance;
  });

  describe('trader undefined', () => {
    it('should render no text', () => {
      component.trader = null;
      fixture.detectChanges();

      expect(fixture.nativeElement.innerText).toEqual('');
    });
  });

  function Trader(number, name, postcode) {
      this.number = number;
      this.name = name;
      this.postcode = postcode;
  }

  [
    { src: new Trader('number', 'name', 'postcode'), expected: trader => `${trader.number}\n${trader.name}\n${trader.postcode}` },
    { src: new Trader(null, null, null), expected: trader => '' },
    { src: new Trader('number', null, null), expected: trader => trader.number },
    { src: new Trader(null, 'name', null), expected: trader => trader.name },
    { src: new Trader(null, null, 'postcode'), expected: trader => trader.postcode },
    { src: new Trader(null, 'name', 'postcode'), expected: trader => `${trader.name}\n${trader.postcode}`},
    { src: new Trader('number', null, 'postcode'), expected: trader => `${trader.number}\n${trader.postcode}`},    
    { src: new Trader('number', 'name', null), expected: trader => `${trader.number}\n${trader.name}`},    
  ].forEach(spec => {
    describe(JSON.stringify(spec.src), () => {
      it('should only render the fields provided', () => {
        component.trader = spec.src;
        fixture.detectChanges();
  
        expect(fixture.nativeElement.innerText).toEqual(spec.expected(component.trader));
      });
    });
  });
});
