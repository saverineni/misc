import { Component, OnInit, ViewEncapsulation, TemplateRef, ViewChild, Input } from '@angular/core';
import { Declaration } from '../../declaration';

@Component({
  selector: 'cds-declaration-header',
  templateUrl: './declaration-header.component.html',
  styleUrls: ['./declaration-header.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DeclarationHeaderComponent implements OnInit {

  constructor() { }

  @Input() declaration: Declaration;
  @ViewChild("declarationId") declarationId: TemplateRef<any>;
  @ViewChild("epuNumber") epuNumber: TemplateRef<any>;
  @ViewChild("entryNumber") entryNumber: TemplateRef<any>;
  @ViewChild("entryDate") entryDate: TemplateRef<any>;
  @ViewChild("route") route: TemplateRef<any>;
  @ViewChild("dispatchCountry") dispatchCountry: TemplateRef<any>;
  @ViewChild("destinationCountry") destinationCountry: TemplateRef<any>;
  @ViewChild("consigneeTurn") consigneeTurn: TemplateRef<any>;
  @ViewChild("consigneeName") consigneeName: TemplateRef<any>;
  @ViewChild("consigneePostcode") consigneePostcode: TemplateRef<any>;
  @ViewChild("consignorTurn") consignorTurn: TemplateRef<any>;
  @ViewChild("consignorName") consignorName: TemplateRef<any>;
  @ViewChild("consignorPostcode") consignorPostcode: TemplateRef<any>;
  @ViewChild("goodsLocation") goodsLocation: TemplateRef<any>;
  @ViewChild("modeOfTransport") modeOfTransport: TemplateRef<any>;

  declarationHeaderColumns = [
    { id: 'declarationId', label: 'Declaration ID', colspan: 3 },
    { id: 'epuNumber', label: 'EPU', colspan: 1 },
    { id: 'entryNumber', label: 'Entry Number', colspan: 1 },
    { id: 'entryDate', label: 'Entry Date', colspan: 1 },
    { id: 'route', label: 'Route of Entry', colspan: 1 },
    { id: 'dispatchCountry', label: 'Country of Dispatch', colspan: 1 },
    { id: 'destinationCountry', label: 'Country of Destination', colspan: 1 },
    { id: 'consigneeTurn', label: 'Consignee Number', colspan: 1 },
    { id: 'consigneeName', label: 'Consignee Name', colspan: 1 },
    { id: 'consigneePostcode', label: 'Consignee Postcode', colspan: 1 },
    { id: 'consignorTurn', label: 'Consignor Number', colspan: 1 },
    { id: 'consignorName', label: 'Consignor Name', colspan: 1 },
    { id: 'consignorPostcode', label: 'Consignor Postcode', colspan: 1 },
    { id: 'goodsLocation', label: 'Goods Location', colspan: 1 },
    { id: 'modeOfTransport', label: 'Mode of Transport', colspan: 1 }
  ];

  declarationHeaderColumnRefs = this.declarationHeaderColumns.map(column => column.id);

  ngOnInit() {
  }

  ngAfterContentInit() {
    this.declarationHeaderColumns.forEach(column => column['template'] = this[column.id]);
  }

}
