import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeclarationHeaderComponent } from './declaration-header.component';
import { By } from '@angular/platform-browser';
import { Declaration } from '../../declaration';
import { DeclarationLine } from '../../declaration-line';
import { MatGridListModule } from '@angular/material';

describe('DeclarationHeaderComponent', () => {
  let component: DeclarationHeaderComponent;
  let fixture: ComponentFixture<DeclarationHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ MatGridListModule ],
      declarations: [ DeclarationHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeclarationHeaderComponent);
    component = fixture.componentInstance;
  });

  describe('Results found', () => {
    let declaration;

    beforeEach(() => {
      declaration = new Declaration();
      declaration.declarationId = 'declarationId';
      declaration.epuNumber = 'epuNumber';
      declaration.entryNumber = 'entryNumber';
      declaration.entryDate = 'entryDate';
      declaration.route = 'route';
      declaration.dispatchCountry = { code: 'dispatchCountry' };
      declaration.destinationCountry = { code: 'destinationCountry'};
      declaration.consigneeTurn = 'consigneeTurn';
      declaration.consignorTurn = 'consignorTurn';
      declaration.goodsLocation = 'goodsLocation';
      declaration.transportModeCode = 'transportModeCode';
      declaration.consigneeName = 'consigneeName';
      declaration.consigneePostcode = 'consigneePostcode';
      declaration.consignorName = 'consignorName';
      declaration.consignorPostcode = 'consignorPostcode';
      declaration.lines = [ new DeclarationLine() ];

      component.declaration = declaration;

      fixture.detectChanges();
    });

    describe('table columns', () => {
      [
        { id: 'declarationId', value: declaration => declaration.declarationId, headerLabel: 'Declaration ID' },
        { id: 'epuNumber', value: declaration => declaration.epuNumber, headerLabel: 'EPU' },
        { id: 'entryNumber', value: declaration => declaration.entryNumber, headerLabel: 'Entry Number' },
        { id: 'entryDate', value: declaration => declaration.entryDate, headerLabel: 'Entry Date' },
        { id: 'route', value: declaration => declaration.route, headerLabel: 'Route of Entry' },
        { id: 'dispatchCountry', value: declaration => declaration.dispatchCountry.code , headerLabel: 'Country of Dispatch' },
        { id: 'destinationCountry', value: declaration => declaration.destinationCountry.code, headerLabel: 'Country of Destination' },
        { id: 'goodsLocation', value: declaration => declaration.goodsLocation, headerLabel: 'Goods Location' },
        { id: 'modeOfTransport', value: declaration => declaration.transportModeCode, headerLabel: 'Mode of Transport' },
        { id: 'consigneeTurn', value: declaration => declaration.consigneeTurn, headerLabel: 'Consignee Number'},
        { id: 'consigneeName', value: declaration => declaration.consigneeName, headerLabel: 'Consignee Name'},
        { id: 'consigneePostcode', value: declaration => declaration.consigneePostcode, headerLabel: 'Consignee Postcode'},
        { id: 'consignorTurn', value: declaration => declaration.consignorTurn, headerLabel: 'Consignor Number'},
        { id: 'consignorName', value: declaration => declaration.consignorName, headerLabel: 'Consignor Name'},
        { id: 'consignorPostcode', value: declaration => declaration.consignorPostcode, headerLabel: 'Consignor Postcode'}
      ].forEach(spec => {
        describe(`the ${spec.headerLabel} table column`, () => {
          it(`should display the ${spec.headerLabel} label`, () => {
            expect(fixture.debugElement.query(By.css(`.declaration-header-label[data-declaration-header-field="${spec.id}"]`)).nativeElement.innerText.trim())
              .toEqual(spec.headerLabel);
          });

          it(`should display the ${spec.headerLabel} value`, () => {
            expect(fixture.debugElement.query(By.css(`.declaration-header-value[data-declaration-header-field="${spec.id}"]`)).nativeElement.innerText.trim())
              .toEqual(spec.value(declaration));
          });
        });
      });
    });
  });
});
