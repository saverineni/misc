import { Component, Input, OnInit } from '@angular/core';
import { DeclarationSearchResult } from '../declaration-search-result';
import { Declaration } from '../declaration';
import { SearchCriteria } from '../search-criteria';
import { ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'cds-declaration-card',
  templateUrl: './declaration-card.component.html',
  styleUrls: ['./declaration-card.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DeclarationCardComponent {

  @Input() declaration: Declaration;

  panelAction: string  = 'Show';
}
