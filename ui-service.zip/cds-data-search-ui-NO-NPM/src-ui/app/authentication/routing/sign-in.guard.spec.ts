import { TestBed, async, inject } from '@angular/core/testing';

import { SignInGuard } from './sign-in.guard';
import { AuthenticationService } from '../authentication.service';
import { Router } from '@angular/router';

describe('SignInGuard', () => {
  let guard: SignInGuard;
  let authenticationService: AuthenticationService;
  let router: Router;

  beforeEach(() => {
    authenticationService = {
      isAuthenticated: () => false
    } as AuthenticationService;

    router = {
      navigateByUrl: url => {}
    } as Router;

    guard = new SignInGuard(authenticationService, router);
    spyOn(router, 'navigateByUrl');
  });

  describe('not authenticated', () => {
    it('can activate should return true',() => {
      expect(guard.canActivate(null, null)).toBe(true);
    });

    it('should not do any navigation',() => {
      expect(router.navigateByUrl).not.toHaveBeenCalled();
    });
  });

  describe('authenticated',  () => {
    beforeEach(() => {
      spyOn(authenticationService, 'isAuthenticated').and.returnValue(true);
    });

    it('can activate should return false',() => {
      expect(guard.canActivate(null, null)).toBe(false);
    });

    it('should route to the homepage', () => {
      guard.canActivate(null, null);

      expect(router.navigateByUrl).toHaveBeenCalledWith('');
    });
  });
});
