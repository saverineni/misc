import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SignInComponent } from '../sign-in/sign-in.component';
import { SignInGuard } from './sign-in.guard';
import { AuthenticationGuard } from './authentication.guard';

const routes: Routes = [
  {
     path: 'signin',
     component: SignInComponent,
     canActivate: [ SignInGuard ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [
    AuthenticationGuard,
    SignInGuard
  ]
})
export class AuthenticationRoutingModule { }
