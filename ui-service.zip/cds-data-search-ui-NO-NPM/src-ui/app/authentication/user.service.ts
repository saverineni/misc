import { Injectable } from '@angular/core';
import { CacheService } from './cache.service';
import { User } from './user';

@Injectable()
export class UserService {

  constructor(private cacheService: CacheService) { }

  isSignedIn(): boolean {
    return this.cacheService.getUser() !== null;
  }

  getUser(): User {
    return this.cacheService.getUser();
  }
}
