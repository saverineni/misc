import {inject, TestBed} from '@angular/core/testing';

import {CacheService} from './cache.service';
import { User } from './user';

describe('CacheService', () => {
  const tokenKey = 'currentUser';
  let service: CacheService;

  beforeEach(() => {
    service = new CacheService();
    spyOn(localStorage , 'setItem');
  });

  describe('token cache', () => {
    const token = '123';

    beforeEach(() => {
      spyOn(localStorage , 'getItem').and.returnValue(token);
    });

    it('returns token',() => {
      expect(service.getToken()).toBe(token);
      expect(localStorage.getItem).toHaveBeenCalledWith(CacheService.TOKEN_KEY)
    });

    it('saves token',() => {
      service.setToken(token);
      expect(localStorage.setItem).toHaveBeenCalledWith(CacheService.TOKEN_KEY,token)
    });
  });

  describe('user cache', () => {
    const testUser = new User('123');
    const userJson = '{"pid":"123"}';

    it('returns null if not present',() => {
      spyOn(localStorage, 'getItem').and.returnValue(null);
      expect(service.getUser()).toBeNull();
    });

    it('returns user if present',() => {
      spyOn(localStorage, 'getItem').and.returnValue(userJson);
      expect(service.getUser()).toEqual(testUser);
      expect(localStorage.getItem).toHaveBeenCalledWith(CacheService.USER_KEY);
    });

    it('saves user',() => {
      service.setUser(testUser);
      expect(localStorage.setItem).toHaveBeenCalledWith(CacheService.USER_KEY, userJson);
    });
  });

  describe('clear', () => {
    beforeEach(() => {
      spyOn(localStorage , 'clear');
    });

    it('should clear the cached values', () => {
      service.clear();

      expect(localStorage.clear).toHaveBeenCalled();
    });
  });
});
