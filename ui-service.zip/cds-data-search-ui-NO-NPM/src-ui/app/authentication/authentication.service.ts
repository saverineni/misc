import { User } from './user';
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { catchError, tap } from 'rxjs/operators';
import { Observable } from "rxjs/Observable";
import { CacheService } from "./cache.service";
import { AuthenticationResult } from './authentication-result';
import 'rxjs/add/operator/map';
import { of } from 'rxjs/observable/of';

interface AuthenticationToken {
  token: string;
}

@Injectable()
export class AuthenticationService {
  constructor(private httpClient: HttpClient, private cacheService: CacheService) { }

  public signIn(pid: string, password: string): Observable<any> {

    return this.httpClient.post("/api/authentication/token", { pid: pid, password: password })
      .pipe(
        tap((response:AuthenticationToken) => {
          this.cacheService.setToken(response.token);
          this.cacheService.setUser(new User(pid));
        })
      ).map(response => new AuthenticationResult(true))
      .pipe(catchError(this.handleError));
  }

  public signOut() {
    this.cacheService.clear();
  }

  public isAuthenticated(): boolean {
    return this.cacheService.getToken() !== null;
  }

  private handleError = (error): Observable<any> => {
    if (error instanceof HttpErrorResponse) {
      if (error.status === 401) {
        return of(new AuthenticationResult(false));
      }
    }
    return new ErrorObservable(error);
  };
}
