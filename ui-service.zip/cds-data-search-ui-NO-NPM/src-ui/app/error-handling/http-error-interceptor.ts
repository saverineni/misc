import { Injectable } from '@angular/core';
import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { OperationErrorNotifier } from './operation-error-notifier';
import { CacheService } from "../authentication/cache.service";
import { SignInRouterService } from "../authentication/sign-in/sign-in-router.service";


@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {

  constructor(private operationErrorNotifier: OperationErrorNotifier,
    private cacheService: CacheService,
    private signInRouterService: SignInRouterService) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(
      catchError(err => {
        if (err instanceof HttpErrorResponse) {
          if (err.status === 0) {
            this.operationErrorNotifier.notifyUser('Connection error');
          } else if (err.status === 401) {
            this.cacheService.clear();
            this.signInRouterService.navigateToSignIn();
          } else if (err.status >= 500) {
            this.operationErrorNotifier.notifyUser('Server error');
          }
        }
        return throwError(err);
      })
    );
  }
}
