import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { CdsNavbarComponent } from './cds-navbar.component';

describe('CdsNavbarComponent', () => {
  let component: CdsNavbarComponent;
  let fixture: ComponentFixture<CdsNavbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CdsNavbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CdsNavbarComponent);
    component = fixture.componentInstance;
  });

  it('should have one menu item labelled with homeLabel', () => {
    component.homeLabel = 'home label';
    fixture.detectChanges();

    const homeLabels = fixture.debugElement.queryAll(By.css(".nav__item-label"))
      .map(navItemLabelElement => navItemLabelElement.nativeElement.textContent);
    expect(homeLabels).toEqual(['home label']);
  });
});
