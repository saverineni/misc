import { DeclarationSearchPage } from '../declaration/search/declarationsearch.po';
import { declarationMatchers } from '../declaration/declarationMatchers';
import { Wiremock } from '../wiremock';
import { browser } from 'protractor';
import { AppPage } from '../app.po';
import { NavigationBar } from '../navigation-bar.po';
import { SignInPage } from '../sign-in/sign-in.po';
import { SignInScenario } from '../sign-in/sign-in-scenario';
import { UserDetails } from '../user-details.po';
import { QueryEncoder } from '@angular/http';

const fs = require('fs');

describe('Declaration search sign-in', () => {
  let signInPage: SignInPage;
  let searchPage: DeclarationSearchPage;

  describe(`given I am on the search results page
      and I bookmark the url
      and I sign out
      and I returned to the bookmarked url`, () => {
    let bookmarkedUrl;

    beforeAll((done) => {
      Wiremock.reset().then(done, done.fail);

      searchPage = new DeclarationSearchPage();
      signInPage = new SignInPage();

      new SignInScenario().givenUserIsSignedIn()
        .then(() => searchPage.navigateTo())
        .then(() => searchPage.whenISearchFor("something"))
        .then(() => browser.getCurrentUrl())
        .then(url => {
          bookmarkedUrl = url;
          return Promise.resolve(url);
        })
        .then(() => new UserDetails().signOut())
        .then(() => browser.get(bookmarkedUrl))
        .then(done, done.fail);
    });

    it('should redirect you to the sign in page', () => {
      expect(signInPage.isCurrentPage()).toBe(true);
    });

    it('should redirect you back to the bookmarked url after sign in', (done) => {
      signInPage.completeSignInFormWithValidUser()
        .then(() => expect(browser.getCurrentUrl()).toBe(bookmarkedUrl))
        .then(() => expect(searchPage.getNoResultsFoundMessage()).toEqual('No results found for search criteria.'))
        .then(done, done.fail);
    });

  });

});

