import { AppPage } from './app.po';
import { NavigationBar } from './navigation-bar.po';
import { browser } from 'protractor';

describe('cds-data-search-ui App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should have the correct heading', () => {
    page.navigateTo();
    expect(page.pageHeading()).toEqual('Customs Declaration Search');
  });

  it('should have nav bar with a home label', () => {
    page.navigateTo();
    expect(new NavigationBar().navbarLabels()).toEqual(['Customs Declaration Search']);
  });
});
