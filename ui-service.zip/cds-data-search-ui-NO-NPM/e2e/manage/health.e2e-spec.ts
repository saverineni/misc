describe('health endpoint', () => {
  const fetch = require('node-fetch');
  let response;

  beforeAll(() => {
    response = fetch('http://localhost:56101/manage/health', {
      method: 'GET'
    })
    .then(res => res.text())
    .then(body => JSON.parse(body))
  });

  it('should give the health status', (done) => {
    response.then(resp => expect(resp.status).toBe('UP'))
            .then(done, done.fail);
  });
});