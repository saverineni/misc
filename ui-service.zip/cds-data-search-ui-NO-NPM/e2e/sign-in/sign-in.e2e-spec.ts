import { SignInPage } from './sign-in.po';
import { DeclarationSearchPage } from "../declaration/search/declarationsearch.po";
import { Wiremock } from "../wiremock";
import { browser } from "protractor";
import { AppPage } from '../app.po';
import { UserDetails } from '../user-details.po';

describe('Sign In', () => {
  let signInPage: SignInPage;

  beforeEach((done) => {
    const userDetails = new UserDetails();
    signInPage = new SignInPage();
    userDetails.isDisplayed()
      .then(isDisplayed => {
        if (isDisplayed) {
          // should route to sign in
          return userDetails.signOut();
        } else {
          return signInPage.navigateTo();
        }
      })
      .then(Wiremock.reset)
      .then(done, done.fail);
  });

  it('should be the current page', () => {
    expect(signInPage.isCurrentPage()).toBeTruthy();
  });

  describe('entering incorrect details', () => {
    beforeEach(() => {
      signInPage.enterPid('123456');
      signInPage.enterPassword('invalid')
    });

    it('on click sign in should display an error message', (done) => {
      signInPage.signIn().then(() =>
        expect(signInPage.errorMessage()).toContain('invalid credentials')
      ).then(done, done.fail);
    });
  });

  describe('signing in with correct details', () => {
    let searchPage: DeclarationSearchPage;

    beforeEach((done) => {
      Wiremock.stubRequest({
          "priority": 1,
          "request": {
            "method": "POST",
            "url": "/authentication/token",
            "bodyPatterns": [{
              "equalToJson": {
                "pid": "7654321",
                "password": "Pa55word"
              }
            }]
          },
          "response": {
            "status": 200,
            "bodyFileName": "authentication/authentication-successful.json"
          }
        })
        .then(done, done.fail);
    });

    beforeEach((done) => {
      searchPage = new DeclarationSearchPage();
      signInPage.enterPid('7654321')
        .then(() => signInPage.enterPassword('Pa55word'))
        .then(signInPage.signIn)
        .then(done, done.fail);
    });

    it('should display the search page', () => {
      expect(searchPage.isCurrentPage()).toBe(true);
    });

    it('and then navigating to the sign in page should route back to the search page', (done) => {
      signInPage.navigateTo()
        .then(() => expect(searchPage.isCurrentPage()).toBe(true))
        .then(done, done.fail);
    });
  });

  describe('server error', () => {
    beforeEach((done) => {
      Wiremock.givenSearchServiceIsOffline()
        .then(done, done.fail);
    });

    beforeEach((done) => {
      signInPage.enterPid('123456')
        .then(() => signInPage.enterPassword('invalid'))
        .then(() => signInPage.signIn())
        .then(done, done.fail);
    });

    it('should display an operation error message', () => {
      expect(new AppPage().getOperationError()).toEqual('Server error. Please contact support if this problem persists.\nOK');
    });

    it('should not display a sign in error message', () => {
      expect(signInPage.errorMessagePresent()).toEqual(false);
    });
  });
});
