import { browser, by, element, ExpectedConditions } from 'protractor';

export class SignInPage {
  public static DEFAULT_PID = 'search';
  public static DEFAULT_PASSWORD = 'search';
  public static DEFAULT_AUTH_TOKEN = 'a12a.b23b.c34c';

  navigateTo() {
    return browser.get('/signin');
  }

  isCurrentPage() {
    return element(by.css('.sign-in-form')).isPresent();
  }

  enterPid(pid: string) {
    return element(by.css('.sign-in-form__pid-input')).sendKeys(pid);
  }

  enterPassword(password: string) {
    return element(by.css('.sign-in-form__password-input')).sendKeys(password);
  }

  signIn() {
    return element(by.css('.sign-in-form__button')).click().then(() => browser.waitForAngular());
  }

  errorMessage() {
    return this.errorMessageElement().getText();
  }

  errorMessagePresent() {
    return this.errorMessageElement().isPresent();
  }

  private errorMessageElement() {
    return element(by.css('.sign-in-form__error-message'));
  }

  completeSignInFormWithValidUser() {
    return this.enterPid(SignInPage.DEFAULT_PID)
      .then(() => this.enterPassword(SignInPage.DEFAULT_PASSWORD))
      .then(() => this.signIn());
  }
}
