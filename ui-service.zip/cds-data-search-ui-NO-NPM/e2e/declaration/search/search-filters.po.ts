import { browser, by, element, ElementFinder } from 'protractor';
import { until } from 'selenium-webdriver';

export class SearchFilters {

  private linksFacetFilter(dataLinkId) {
    return element(by.css(`.links[data-links-id="${dataLinkId}"]`)).element(by.css('.links__facet'));
  }

  clickLinksFacetFilter(dataLinkId) {
    // sleep after click due to animation of dialog open
    return this.linksFacetFilter(dataLinkId)
               .click()
               .then(() => browser.driver.sleep(500));
  }
}
