/// <reference path="../declarationMatchers.d.ts"/>

import {DeclarationSearchPage} from './declarationsearch.po';
import {DeclarationDetailPage} from '../detail/declarationdetail.po';
import {declarationMatchers} from '../declarationMatchers';
import {DeclarationSearchScenario} from './declaration-search-scenario';
import {AppPage} from '../../app.po';
import {NavigationBar} from '../../navigation-bar.po';
import {SignInScenario} from '../../sign-in/sign-in-scenario';
import {Wiremock} from '../../wiremock';
import {DeclarationDetailScenario} from '../detail/declarationdetail-scenario';

describe('Declaration search', () => {
  let searchPage: DeclarationSearchPage = new DeclarationSearchPage();

  beforeAll((done) => {
    new SignInScenario().givenUserIsSignedIn()
      .then(done, done.fail);
  });

  beforeAll((done) => {
    Wiremock.reset()
      .then(() => DeclarationSearchScenario.stubPerformSearch())
      .then(() => searchPage.navigateTo())
      .then(done, done.fail);
  });

  it('should be the current page', () => {
    expect(searchPage.isCurrentPage()).toBeTruthy();
  });

  it('the page title should be set', () => {
    expect(searchPage.getTitle()).toEqual("Customs Declaration Search");
  });

  [
    'originCountryCode',
    'dispatchCountryCode',
    'destinationCountryCode',
    'transportModeCode',
    'goodsLocation',
    'commodityCode'
  ].forEach(facetType => {
    it(`the page should display the enabled ${facetType} filter`, () => {
      expect(searchPage.linksFacetFilterEnabled(facetType)).toBeTruthy();
    });
  });

  it('should focus the search field', (done) => {
    expect(searchPage.isDeclarationSearchFieldFocused()).toBeTruthy()
      .then(done, done.fail);
  });

  describe('perform search', () => {
    describe('with not found search term', () => {

      beforeAll((done) => {
        searchPage.whenISearchFor('made-up')
          .then(done, done.fail);
      });

      it('should display the filters section', () => {
        expect(searchPage.isFiltersSectionDisplayed()).toBeTruthy();
      });

      it('display no results found message', (done) => {
        expect(searchPage.isNoResultsFound()).toEqual(true)
          .then(() => expect(searchPage.getNoResultsFoundMessage()).toEqual('No results found for search criteria.'))
          .then(done, done.fail);
      });

      [
        'originCountryCode',
        'dispatchCountryCode',
        'destinationCountryCode',
        'transportModeCode',
        'goodsLocation'
      ].forEach(facetType => {
        it(`filters section is display the enabled ${facetType} filter`, () => {
          expect(searchPage.linksFacetFilterEnabled(facetType)).toBeTruthy();
        });
      });

      it(`filters section is display the commodity code filter`, () => {
        expect(searchPage.linksFacetFilterEnabled('commodityCode')).toBeTruthy();
      });

      it('updates the url in the browser', (done) => {
        expect(new AppPage().getCurrentUrl()).toMatch(/\/\?searchTerm=made-up$/)
          .then(done, done.fail);
      });

      describe('and click the home link', () => {
        beforeAll((done) => {
          new NavigationBar().clickHome()
            .then(done, done.fail);
        });

        it('clears the results', (done) => {
          expect(searchPage.isResultsDisplayed()).toEqual(false)
            .then(() => expect(searchPage.isNoResultsFound()).toEqual(false))
            .then(done, done.fail);
        });

        it('clears the declaration search field', (done) => {
          expect(searchPage.getDeclarationSearchFieldText()).toEqual('')
            .then(done, done.fail);
        });

        it('should focus the search field', (done) => {
          expect(searchPage.isDeclarationSearchFieldFocused()).toBeTruthy()
            .then(done, done.fail);
        });
      });
    });

    describe('with empty search term', () => {
      it('displays declarations with no search term', (done) => {
        DeclarationSearchScenario.stubAuthenticatedSearchForTerm('')
          .then(() => searchPage.clickSearchButton())
          .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
          .then(done, done.fail);
      });

      it('displays declarations when browser is refreshed ', (done) => {
        DeclarationSearchScenario.stubAuthenticatedSearchForTerm('')
          .then(() => searchPage.refresh())
          .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
          .then(done, done.fail);
      });
    });

    describe('declaration', () => {

      let declarationSearchResult;
      const DECLARATION_ID = '670-954107X-2017-08-22';
      const DECLARATION_WITH_LINES_INDEX = 0;

      beforeAll((done) => {
        declarationSearchResult = DeclarationSearchScenario.defaultSearchResponse();
        DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found')
          .then(() => searchPage.whenISearchFor('found'))
          .then(done, done.fail);

        jasmine.addMatchers(declarationMatchers)
      });

      it('updates the url in the browser', (done) => {
        expect(new AppPage().getCurrentUrl()).toMatch(/\/\?searchTerm=found$/)
          .then(done, done.fail);
      });

      it('displays first declaration if found', () => {
        expect(searchPage.isResultsDisplayed()).toEqual(true);
        expect(searchPage.getDataGridElement(DECLARATION_WITH_LINES_INDEX))
          .isDeclarationPreviewWithData(declarationSearchResult.declarations.find(declaration => declaration.declarationId == DECLARATION_ID));
        expect(searchPage.getResultsFoundMessage()).toEqual('Showing 1-2 of 2')
      });

      it('filters section is displayed', () => {
        expect(searchPage.isFiltersSectionDisplayed()).toBeTruthy()
      });

      it('routes you to the declaration detail page when the button is clicked', (done) => {
        let detailPage = new DeclarationDetailPage();
        DeclarationDetailScenario.stubDeclaration(DECLARATION_ID)
          .then(() => searchPage.clickDeclarationDetail(DECLARATION_WITH_LINES_INDEX))
          .then(() => expect(detailPage.isCurrentPage()).toBe(true))
          .then(() => expect(detailPage.getDeclarationId()).toEqual(DECLARATION_ID))
          .then(() => searchPage.navigateTo())
          .then(done, done.fail);
      });

    });

    describe('when backend is offline', () => {
      beforeAll((done) => {
        Wiremock.reset()
          .then(() => DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found'))
          .then(() => Wiremock.givenSearchServiceIsOffline())
          .then(() => searchPage.whenISearchFor('found'))
          .then(done, done.fail);
      });

      it('displays global error message', () => {
        expect(new AppPage().getOperationError()).toEqual('Server error. Please contact support if this problem persists.\nOK');
      });

      it('does not display search results', () => {
        expect(searchPage.isNoResultsFound()).toEqual(false);
      });

      describe('then back online', () => {
        beforeAll((done) => {
          Wiremock.reset().then(done, done.fail);
        });

        it('retries the search on clicking the search button a second time', (done) => {
          searchPage.clickSearchButton()
            .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
            .then(done, done.fail);
        });
      });
    });
  });

  describe('bookmark search', () => {
    const bookmarkSpecialChars = ';/:@&?=<>#%{}|\^~[]` шеллы';
    const url = '?searchTerm=' + encodeURIComponent(bookmarkSpecialChars);

    beforeAll((done) => {
      DeclarationSearchScenario.stubAuthenticatedSearchForTerm(bookmarkSpecialChars)
        .then(() => searchPage.navigateTo(url))
        .then(done, done.fail)
    });

    it('populates the declaration search field', () => {
      expect(searchPage.getDeclarationSearchFieldText()).toEqual(bookmarkSpecialChars);
    });

    it('display results', () => {
      expect(searchPage.isResultsDisplayed()).toEqual(true);
    });
  });
});

