import {browser, by, element, ElementFinder} from "protractor";

export class Chips {
  constructor(private chipsId: string) {}

  static getNumberOfChipsIn(parentClass: string) {
    return element.all(by.css(`.${parentClass} .chips__chip`)).count();
  }

  getTexts() {
    return this.getChips().all(by.css('.chips__chip-text')).getText();
  }

  removeChip(chip) {
    return this.getChipIcon(chip).click();
  }

  getChipIcon(chip) {
    return this.getChips().element(by.css(`.chips__chip-remove[data-chip-id="${chip}"]`));
  }

  private getChips() {
    return element(by.css(`.chips[data-chips-id="${this.chipsId}"]`));
  }
}