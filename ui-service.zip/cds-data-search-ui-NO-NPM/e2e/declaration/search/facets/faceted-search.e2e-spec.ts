import { DeclarationSearchPage } from '../declarationsearch.po';
import { SearchFilters } from '../search-filters.po';
import { Wiremock } from '../../../wiremock';
import { SignInScenario } from '../../../sign-in/sign-in-scenario';
import { FacetedSearchDialog } from "./faceted-search-dialog.po";
import { FacetedSearchScenario } from "./faceted-search-scenario";
import { DeclarationSearchScenario } from '../declaration-search-scenario';
import { Chips } from './chips.po'
import { browser } from 'protractor';
import { SignInPage } from '../../../sign-in/sign-in.po';

describe('Faceted Search for', () => {
  let searchPage: DeclarationSearchPage = new DeclarationSearchPage();
  let facetedSearchDialog: FacetedSearchDialog = new FacetedSearchDialog();
  const searchFilters: SearchFilters = new SearchFilters();

  beforeAll((done) =>
    Wiremock.reset().then(done, done.fail)
  );

  beforeAll((done) =>
    new SignInScenario().givenUserIsSignedIn().then(done, done.fail)
  );

  [
    {
      name: 'Country of Origin',
      openDialog: () => searchFilters.clickLinksFacetFilter('originCountryCode'),
      facets: ["AFacet (1)", "BFacet (2)", "CFacet (3)", "Unknown (4)"],
      filterText: 'A',
      testFacetIds: ['AFacet', 'BFacet'],
      searchParam: 'originCountryCode'
    },
    {
      name: 'Country of Dispatch',
      openDialog: () => searchFilters.clickLinksFacetFilter('dispatchCountryCode'),
      facets: ["AFacet (1)", "BFacet (2)", "CFacet (3)", "Unknown (4)"],
      filterText: 'B',
      testFacetIds: ['BFacet', 'CFacet'],
      searchParam: 'dispatchCountryCode'
    },
    {
      name: 'Country of Destination',
      openDialog: () => searchFilters.clickLinksFacetFilter('destinationCountryCode'),
      facets: ["AFacet (1)", "BFacet (2)", "CFacet (3)", "Unknown (4)"],
      filterText: 'C',
      testFacetIds: ['BFacet', 'CFacet'],
      searchParam: 'destinationCountryCode'
    },
    {
      name: 'Mode of Transport',
      openDialog: () => searchFilters.clickLinksFacetFilter('transportModeCode'),
      facets: ["AFacet (1)", "BFacet (2)", "CFacet (3)", "Unknown (4)"],
      filterText: 'A',
      testFacetIds: ['AFacet', 'BFacet'],
      searchParam: 'transportModeCode'
    },
    {
      name: 'Goods Location',
      openDialog: () => searchFilters.clickLinksFacetFilter('goodsLocation'),
      facets: ["AFacet (1)", "BFacet (2)", "CFacet (3)", "Unknown (4)"],
      filterText: 'B',
      testFacetIds: ['AFacet', 'BFacet'],
      searchParam: 'goodsLocation'
    },
    {
      name: 'Commodity Code',
      openDialog: () => searchFilters.clickLinksFacetFilter('commodityCode'),
      facets: ["1234com1 (2)", "12347890 (20)"],
      filterText: '1234c',
      filterPrefix: '1234',
      testFacetIds: ['1234com1', '12347890'],
      searchParam: 'commodityCode'
    }
  ].forEach((test: any) => {
    const testFacetId = test.testFacetIds[0];
    const chips = new Chips(test.searchParam);
    describe(test.name, () => {

      beforeAll((done) => {
        DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found')
          .then(() => searchPage.navigateTo('?searchTerm=found'))
          .then(() => test.openDialog())
          .then(done, done.fail);
      });

      if (test.filterPrefix) {
        beforeAll((done) => {
          FacetedSearchScenario.stubFacetRequest(test.searchParam, test.filterPrefix)
            .then(done, done.fail);
        });
      }

      it('should focus on the search filter field', (done) => {
        expect(facetedSearchDialog.isSearchFilterFieldFocused()).toBeTruthy()
          .then(done, done.fail);
      });

      it(`should open ${test.name} filter dialog`, () => {
        expect(facetedSearchDialog.isDisplayed()).toBeTruthy();
      });

      it('should display dialog title', () =>
        expect(facetedSearchDialog.getDialogTitle()).toBe(`Select ${test.name}`)
      );

      it('should have cancel button', (done) => {
        expect(facetedSearchDialog.getCancelButton()).toBeTruthy();
        facetedSearchDialog.getCancelButton().getCssValue('border')
          .then(border => expect(border).toBe('2px solid rgb(16, 134, 110)'))
          .then(done,done.fail)
      });

      describe('dialog content', () => {
        let filteredFacets;
        beforeAll(() => {
          filteredFacets = test.facets.filter(facet => facet.startsWith(test.filterText));
        });

        if (test.filterPrefix) {
          beforeAll((done) => {
            facetedSearchDialog.searchFacet(test.filterPrefix)
              .then(done, done.fail);
          });
        }
        afterEach((done) => {
          facetedSearchDialog.clearFilter().then(done, done.fail);
        });
        it('displays facets', () => {
          expect(facetedSearchDialog.facetList()).toEqual(test.facets);
        });

        it('displays facets that match the search text - upper case', (done) => {
          facetedSearchDialog.searchFacet(test.filterText.toUpperCase())
            .then(() => facetedSearchDialog.facetList())
            .then(() => expect(facetedSearchDialog.facetList()).toEqual(filteredFacets))
            .then(done, done.fail);
        });

        it('displays facets that match the search text - lower case', (done) => {
          facetedSearchDialog.searchFacet(test.filterText.toLowerCase())
            .then(() => expect(facetedSearchDialog.facetList()).toEqual(filteredFacets))
            .then(done, done.fail);
        });

        it('display facet count in black color', () => {
          expect(facetedSearchDialog.getFacetCountColor()).toBe('rgba(11, 12, 12, 1)');
        });

        it('displays no results found for unmatched search text', () => {
          if (test.filterPrefix) {
            facetedSearchDialog.searchFacet(`${test.filterPrefix}zzz`);
          } else {
            facetedSearchDialog.searchFacet("zzz");
          }
          expect(facetedSearchDialog.noResultsFoundMessage()).toEqual("No results found");
        });
      });

      describe('close dialog', () => {
        beforeAll((done) =>
          facetedSearchDialog.clickCancel().then(done, done.fail)
        );

        it('close dialog when cancel button is clicked', () => {
          expect(facetedSearchDialog.isDisplayed()).toBeFalsy();
        });

        afterAll((done) =>
          test.openDialog().then(done, done.fail)
        );
      });

      describe('facet selection', () => {
        if (test.filterPrefix) {
          beforeAll((done) => {
            facetedSearchDialog.searchFacet(test.filterPrefix)
              .then(done, done.fail);
          });
        }

        beforeAll((done) => {
          browser.driver.sleep(500);
          facetedSearchDialog.selectFacet(testFacetId)
            .then(() => browser.driver.sleep(500))
            .then(done, done.fail);
        });        

        it('should show link as selected', () =>
          expect(facetedSearchDialog.isFacetSelected(testFacetId)).toBeTruthy()
        );

        it('should add selection to list', () =>
          expect(facetedSearchDialog.isSelectionDisplayedInList(testFacetId)).toBeTruthy()
        );

        it('display facet in bold font', (done) => {
          facetedSearchDialog.getLink(testFacetId).getCssValue('font-weight')
          .then(font => expect(font).toBe('500'))
          .then(done,done.fail);  
        });

        it('display selected chip icon in light green color', (done) => {
          facetedSearchDialog.getSelectedFacet(testFacetId).getCssValue('color')
          .then(color => expect(color).toBe('rgba(16, 134, 110, 1)'))
          .then(done,done.fail);
        });

        it('removing selection chip should enable link', (done) => {
          facetedSearchDialog.removeSelection(testFacetId)
            .then(() => expect(facetedSearchDialog.isSelectionDisplayedInList(testFacetId)).toBeFalsy())
            .then(() => expect(facetedSearchDialog.isFacetSelected(testFacetId)).toBeFalsy())
            .then(done, done.fail);
        });
      });

      describe('apply filters', () => {
        const queryString = `searchTerm=found&${test.searchParam}=${testFacetId}`;

        beforeAll((done) => {
          facetedSearchDialog.selectFacet(testFacetId)
            .then(() => facetedSearchDialog.clickApplyFilters())
            .then(done, done.fail);
        });

        it('should close the dialog', () =>
          expect(facetedSearchDialog.isDisplayed()).toBeFalsy()
        );

        it('should add the selected facet breadcrumbs', (done) => {
          chips.getTexts().then(texts =>
            expect(texts).toEqual([testFacetId])
          ).then(done, done.fail);
        });

        it('should request search results for selected facets', (done) => {
          Wiremock.requestCountForGet(`/declarations?${queryString}`)
            .then(count => expect(count).toBe(1))
            .then(done, done.fail);
        });

        it('update the url with the selected facets', () =>
          expect(searchPage.urlQueryString()).toBe(queryString)
        );
      });

      describe('facets already selected', () => {
        beforeAll((done) => {
          searchPage.navigateTo(`?searchTerm=found&${test.searchParam}=${test.testFacetIds[1]}`)
            .then(() => test.openDialog())
            .then(done, done.fail);
        });

        it('should focus on the search filter field', (done) => {
          expect(facetedSearchDialog.isSearchFilterFieldFocused()).toBeTruthy()
            .then(done, done.fail);
        });

        it('should add already selected facets to list', () =>
          expect(facetedSearchDialog.isSelectionDisplayedInList(test.testFacetIds[1])).toBeTruthy()
        );

        if (!test.filterPrefix) {
          it('display selected facet in bold font', (done) => {
            facetedSearchDialog.getLink(test.testFacetIds[1]).getCssValue('font-weight')
            .then(font => expect(font).toBe('500'))
            .then(done,done.fail);  
          });

          it('should disable already selected facets', () =>
            expect(facetedSearchDialog.isFacetSelected(test.testFacetIds[1])).toBeTruthy()
          );
        }
      });
    });
  });

  describe('dynamic facet', () => {
    const searchTerm = 'found';

    beforeAll((done) => {
      Wiremock.reset()
        .then(() => DeclarationSearchScenario.stubAuthenticatedSearchForParams({ searchTerm: 'found', commodityCode: '12345'} ))
        .then(() => searchPage.navigateTo('?searchTerm=found&commodityCode=12345'))
        .then(() => searchFilters.clickLinksFacetFilter('commodityCode'))
        .then(done, done.fail);
    });

    describe('enter filter term', () => {
      const filterText = '1234';

      beforeAll((done) => {
        FacetedSearchScenario.stubFacetRequest('commodityCode', filterText)
          .then(() => facetedSearchDialog.searchFacet(filterText))
          .then(done, done.fail);
      })

      it('should not request facets with current selected filters of the same type', () =>
        expect(Wiremock.requestCountForGet(`/facets/commodityCode/${filterText}?searchTerm=found`)).toBe(1)
      );
    });

    describe('enter filter term invalid token', () => {
      const filterText = '4321';
      beforeAll((done) => {
        FacetedSearchScenario.stubUnauthorizeFacetRequest('commodityCode', filterText)
          .then(() => facetedSearchDialog.searchFacet(filterText))
          .then(() => browser.driver.sleep(500))
          .then(done, done.fail);
      })

      it('should close dialog', () =>
        expect(facetedSearchDialog.isDisplayed()).toBe(false)
      );
    });
  });
});
