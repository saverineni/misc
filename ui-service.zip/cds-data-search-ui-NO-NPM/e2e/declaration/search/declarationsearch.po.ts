import { browser, by, element } from 'protractor';
import { DataGridElement } from '../DataGridElement';

export class DeclarationSearchPage {
  navigateTo(queryString = '') {
    return browser.get(`/${queryString}`)
      .then(() => browser.waitForAngular());
  }

  getTitle() {
    return browser.getTitle();
  }

  refresh() {
    return browser.refresh();
  }

  urlQueryString() {
    return browser.waitForAngular()
      .then(() => browser.getCurrentUrl())
      .then(url => url.replace(/^http:\/\/\w+:\d+\/\?(.+)$/, '$1'));
  }

  isCurrentPage() {
    return element(by.css('.search-section')).isPresent();
  }

  search(searchTerm: string) {
    return this.typeIntoSearchTermField(searchTerm)
      .then(() => this.clickSearchButton());
  }

  typeIntoSearchTermField(searchTerm: string) {
    return this.getDeclarationField().sendKeys(searchTerm);
  }

  getDeclarationSearchFieldText() {
    return this.getDeclarationField().getAttribute('value');
  }

  isDeclarationSearchFieldFocused() {
    return browser.driver.switchTo().activeElement().getAttribute('name')
      .then((fieldname) => fieldname === 'searchTerm');
  }

  private getDeclarationField() {
    return element(by.css('.search-form__searchterm-input'));
  }

  clickSearchButton() {
    return element(by.css(".search-form__button")).click();
  }

  isNoResultsFound() {
    return element(by.css('.no-search-results')).isPresent();
  }

  getResultsFoundMessage() {
    return element(by.css('.search-results-message')).getText();
  }

  getNoResultsFoundMessage() {
    return element(by.css('.no-search-results')).getText();
  }

  isResultsDisplayed() {
    return element(by.css('.search-results-cards')).isPresent();
  }

  isFiltersSectionDisplayed() {
    return element(by.css('.search-filter-section')).isPresent();
  }

  linksFacetFilterEnabled(dataLinkId) {
    return this.linksFacetFilter(dataLinkId).isDisplayed();
  }

  private linksFacetFilter(dataLinkId) {
    return element(by.css(`.links[data-links-id="${dataLinkId}"]`));
  }

  getDataGridElement(row: number): DataGridElement {
    return new DataGridElement(element.all(by.css('.search-results-cards__declarations')).get(row));
  }

  clickDeclarationDetail(row: number) {
    return element.all(by.css('.search-results-cards__declaration-details-button')).get(row).click();
  }

  whenISearchFor(searchTerm: string) {
    return this.search(searchTerm);
  }

}
