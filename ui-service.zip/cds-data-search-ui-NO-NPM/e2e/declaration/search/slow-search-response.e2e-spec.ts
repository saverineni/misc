
import { DeclarationSearchPage } from './declarationsearch.po';
import { DeclarationSearchScenario } from './declaration-search-scenario';
import { AppPage } from '../../app.po';
import { SignInScenario } from '../../sign-in/sign-in-scenario';
import { Wiremock } from '../../wiremock';
import { WaitingOverlay } from '../../waiting-overlay';
import { browser } from 'protractor';

describe('Slow declaration search', () => {
  let searchPage: DeclarationSearchPage = new DeclarationSearchPage();
  let waitingOverlay = new WaitingOverlay();

  beforeAll((done) => {
    new SignInScenario().givenUserIsSignedIn()
      .then(done, done.fail);
  });

  describe('Before connection timeout', () => {
    beforeAll(() => {
      Wiremock.reset()
        .then(() => browser.waitForAngularEnabled(false))
        .then(() => DeclarationSearchScenario.stubPerformSearchWithDelayMillis(3000))
        .then(() => searchPage.navigateTo("?searchTerm=found"))
    });
  
    afterAll((done) => browser.waitForAngularEnabled(true).then(done, done.fail));
  
    it('should display the spinner', () => {
      expect(waitingOverlay.spinnerIsDisplayed()).toBe(true);
    });
  });

  describe('After connection timeout', () => {
    beforeAll((done) => {
      Wiremock.reset()
        .then(() => browser.waitForAngularEnabled(true))
        .then(() => DeclarationSearchScenario.stubPerformSearchWithDelayMillis(6000))
        .then(() => searchPage.navigateTo("?searchTerm=found"))
        .then(done, done.fail)
    });

    it('should display the connection error message', () => {
      expect(new AppPage().getOperationError()).toEqual('Connection error. Please contact support if this problem persists.\nOK');
    });

    it('should not be displaying the spinner', () => {
      expect(waitingOverlay.spinnerIsDisplayed()).toBe(false);
    });
  });
  
});
