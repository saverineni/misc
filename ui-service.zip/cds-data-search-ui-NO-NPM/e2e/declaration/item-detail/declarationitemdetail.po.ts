import { browser, by, element } from 'protractor';
import { DataGridElement } from '../DataGridElement';

export class DeclarationItemDetailPage {

  navigateTo(id, itemNumber) {
    return browser.get(`/declarations/${id}/items/${itemNumber}`).then(() => browser.waitForAngular());
  }

  isCurrentPage() {
    return element(by.css('.declaration-item-detail')).isPresent();
  }

  getDeclarationId() {
    return element(by.css('.declaration-item-detail__declarations')).getAttribute('data-declaration-id');
  }

  clickBackToSearchResults() {
    return element(by.css('.declaration-item-detail__back-to-search-button')).click();
  }

  getSelectedItemNumber() {
    return element(by.css('.declaration-item-detail__declarations')).getAttribute('data-declaration-item-number');
  }

  getItemResultsCount() {
    return element(by.css('.declaration-item-detail__results-count')).getText();
  }

  getItemTabNumbers() {
    return element.all(by.css('.declaration-item-detail__tab-label')).map(e => e.getText());
  }

  // Sleep after click due to waiting for tab animation
  clickItemTab(number) {
    return element(by.css(`.declaration-item-detail__tab-label[data-declaration-item-number="${number}"]`)).click()
      .then(() => browser.driver.sleep(500));
  }

  filterBy(text) {
    let filterInput = element(by.css('.declaration-item-detail__item-filter-input'));
    return filterInput.clear().then(() => filterInput.sendKeys(text)).then(() => browser.driver.sleep(500));
  }

  hasNoResults() {
    return element(by.css('.declaration-item-detail__no-results-message')).isPresent();
  }

  getDataGridElement(): DataGridElement {
    return new DataGridElement(element(by.css('.declaration-item-detail__declarations')));
  }

}
