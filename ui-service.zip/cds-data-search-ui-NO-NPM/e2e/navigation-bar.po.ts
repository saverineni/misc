import { browser, by, element } from 'protractor';

export class NavigationBar {

  navbarLabels() {
    return element.all(by.css('.nav__item-label')).map(item => item.getText());
  }

  clickHome() {
    return element(by.className('nav')).element(by.linkText('Customs Declaration Search')).click();
  }
}
