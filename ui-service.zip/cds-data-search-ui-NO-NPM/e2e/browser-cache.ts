import { browser } from 'protractor';

export class BrowserCache {

  clearLocalStorage() {
    return browser.executeScript('localStorage.clear();');
  }

  makeTokenInvalid() {
    return browser.executeScript("localStorage.setItem('currentUser', 'invalid token');");
  }

}
