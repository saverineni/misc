#!/bin/bash

green=$(tput setaf 2)
red=$(tput setaf 1)
normal=$(tput sgr0)

./test-build-and-e2e.sh
RESULT=$?

echo ""
echo "-----------------------------"
echo "Pre checking script finished"
echo ""

if [ $RESULT == 0 ]; then
    printf "${green}Build SUCCESSFUL${normal}\n"
else
    printf "${red}Build FAILED${normal}\n"
fi