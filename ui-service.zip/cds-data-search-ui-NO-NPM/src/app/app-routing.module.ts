import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SearchSectionComponent } from './declaration/search/search-section/search-section.component';
import { AuthenticationGuard } from './authentication/routing/authentication.guard';
import { DeclarationDetailComponent } from './declaration/detail/declaration-detail.component';
import { DeclarationItemDetailComponent } from './declaration/detail/items/declaration-item-detail.component';

const routes: Routes = [
  {
    path: '',
    canActivate: [ AuthenticationGuard ],
    component: SearchSectionComponent,
    runGuardsAndResolvers: 'always'
  },
  {
    path: 'declarations/:id',
    canActivate: [ AuthenticationGuard ],
    component: DeclarationDetailComponent,
    runGuardsAndResolvers: 'always'
  },
  {
    path: 'declarations/:id/items/:number',
    canActivate: [ AuthenticationGuard ],
    component: DeclarationItemDetailComponent,
    runGuardsAndResolvers: 'always'
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {onSameUrlNavigation: 'reload'}),
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
