export class ColumnDefinition {
  readonly id: string;
  readonly label: string;
  readonly colspan: number = 1;
  readonly strong: boolean = false;
  getValue: (any) => (string) = (data) => data[this.id];

  constructor(definition: {
    id: string,
    label: string,
    colspan?: number,
    strong?: boolean,
    getValue?: (any) => string
  }) {
    this.id = definition.id;
    this.label = definition.label;
    this.colspan = definition.colspan || this.colspan;
    this.strong = definition.strong || this.strong;
    this.getValue = definition.getValue || this.getValue;
  }

  toColumn(data) {
    return new Column(
      this.id,
      this.label,
      this.getValue(data),
      this.colspan,
      this.strong
    )
  }
}

export class Column {
  constructor(
    readonly id: string,
    readonly label: string,
    readonly value: any,
    readonly colspan: number,
    readonly strong: boolean
  ) {}
}