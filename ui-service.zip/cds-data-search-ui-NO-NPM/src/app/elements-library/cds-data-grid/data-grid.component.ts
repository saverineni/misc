import { Component, OnInit, ViewEncapsulation, TemplateRef, ViewChild, Input } from '@angular/core';
import { ChangeDetectionStrategy } from '@angular/core';
import { ColumnDefinition } from './column-definition';
import { Column } from './column-definition';
import { TrackBy } from '../../track-by';
import { Observable } from 'rxjs/internal/Observable';
import { of } from 'rxjs';

@Component({
  selector: 'cds-data-grid',
  templateUrl: './data-grid.component.html',
  styleUrls: ['./data-grid.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DataGridComponent {
  trackById = TrackBy.property('id');

  @Input() columnCount: number;
  @Input() columns: Observable<Column[]>;
}
