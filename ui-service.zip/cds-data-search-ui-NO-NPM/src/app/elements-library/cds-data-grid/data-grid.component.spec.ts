import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DataGridComponent } from './data-grid.component';
import { By } from '@angular/platform-browser';
import { MatGridListModule } from '@angular/material';
import { ColumnDefinition, Column } from './column-definition';
import { of } from 'rxjs';

describe('DataGridComponent', () => {
  let component: DataGridComponent;
  let fixture: ComponentFixture<DataGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MatGridListModule],
      declarations: [DataGridComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataGridComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Column list observable', () => {
    const columns = [
      new Column('dataId', 'data ID', 'dataId', 1, true),
      new Column('value1', 'Value 1', 'value1', 3, false),
      new Column('value2', 'Value 2', 'value2', 2, false),
    ];

    beforeEach(() => {
      component.columnCount = 3;
      component.columns = of(columns);

      fixture.detectChanges();
    });

    describe('table columns', () => {
      columns.forEach(column => {
        describe(`the ${column.label} table column`, () => {
          it(`should display the ${column.label} label`, () => {
            expect(fixture.debugElement.query(By.css(`.data-grid__header[data-grid-field="${column.id}"]`)).nativeElement.innerText.trim())
              .toEqual(column.label);
          });

          it(`should display the ${column.label} value`, () => {
            expect(fixture.debugElement.query(By.css(`.data-grid__value[data-grid-field="${column.id}"]`)).nativeElement.innerText.trim())
              .toEqual(column.value);
          });
        });

        it(`should apply the strong styling when defined for ${column.label}`, () => {
          expect(fixture.debugElement.query(By.css(`.data-grid__value[data-grid-field="${column.id}"].strong`)) !== null)
            .toEqual(column.strong);
        });
      });
    });
  });
});
