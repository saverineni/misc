import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { CdsNavbarComponent } from './cds-navbar.component';
import { NavigationService } from '../../declaration/search/navigation.service';
import { SearchCriteriaService } from '../../declaration/search/search-criteria.service';
import { Router } from '@angular/router';
import { RouterModule } from '@angular/router';

describe('CdsNavbarComponent', () => {
  let component: CdsNavbarComponent;
  let fixture: ComponentFixture<CdsNavbarComponent>;
  let navigationService = {
    navigateToSearch: (bool) => {}
  } as NavigationService

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CdsNavbarComponent ],
      providers: [ { provide: NavigationService, useValue: navigationService } ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CdsNavbarComponent);
    component = fixture.componentInstance;
    component.homeLabel = 'home label';
    fixture.detectChanges();

    navigationService = TestBed.get(NavigationService);
    spyOn(navigationService, 'navigateToSearch');
  });

  it('should have one menu item labelled with homeLabel', () => {
    const homeLabels = fixture.debugElement.queryAll(By.css(".nav__item-label"))
      .map(navItemLabelElement => navItemLabelElement.nativeElement.textContent);
    expect(homeLabels).toEqual(['home label']);
  });

  it('should call navigation service when nav button is clicked', () => {
    fixture.debugElement.query(By.css('.nav__item-link')).nativeElement.click();
    fixture.detectChanges();
    expect(navigationService.navigateToSearch).toHaveBeenCalledWith(true);
  });

});
