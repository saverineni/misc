import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'cds-navbar',
  templateUrl: './cds-navbar.component.html',
  styleUrls: ['./cds-navbar.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CdsNavbarComponent {
  @Input() homeLabel;
}
