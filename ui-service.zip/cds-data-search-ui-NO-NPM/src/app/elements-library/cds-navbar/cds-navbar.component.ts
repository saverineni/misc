import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { Router } from '@angular/router';
import { NavigationService } from '../../declaration/search/navigation.service';

@Component({
  selector: 'cds-navbar',
  templateUrl: './cds-navbar.component.html',
  styleUrls: ['./cds-navbar.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CdsNavbarComponent {

  @Input() homeLabel;

  constructor(private navigationService: NavigationService) {}

  navigateToSearch() {
    this.navigationService.navigateToSearch(true);
  }

}
