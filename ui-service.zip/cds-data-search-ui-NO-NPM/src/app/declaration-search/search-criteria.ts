export class SearchCriteria {
  searchTerm: string;
  originCountryCode: string[];
  dispatchCountryCode: string[];
  destinationCountryCode: string[];
  transportModeCode: string[];
  goodsLocation: string[];
  entryDateFrom: string;
  entryDateTo: string;

  isEmpty(): boolean {
    return Object.getOwnPropertyNames(this)
                 .find(property => this[property] != null) == null;
  }
}
