export class Facets {  
  originCountries: Array<Facet>;
  dispatchCountries: Array<Facet>;
  destinationCountries: Array<Facet>;
  transportModes: Array<Facet>;
  goodsLocations: Array<Facet>;
}

export interface Facet {
  id: String
  count: number
}
