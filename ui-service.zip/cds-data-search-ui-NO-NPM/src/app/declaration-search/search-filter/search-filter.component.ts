import {Component, Input, OnChanges} from '@angular/core';
import {Facets, Facet} from "../facets";
import {MatDialog, MatDialogRef} from "@angular/material";
import {FacetedSearchComponent} from "./faceted-search/faceted-search.component";
import {SearchCriteria} from '../search-criteria';
import { SimpleChanges } from '@angular/core/src/metadata/lifecycle_hooks';
import { TrackBy } from '../../track-by';
import { ChangeDetectionStrategy } from '@angular/core';


@Component({
  selector: 'cds-search-filter',
  templateUrl: './search-filter.component.html',
  styleUrls: ['./search-filter.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class SearchFilterComponent implements OnChanges {
  trackByIndex = TrackBy.index;

  @Input() facets: Facets;
  linksFacets: Array<any>;

  constructor(public dialog: MatDialog) {}

  ngOnChanges(changes: SimpleChanges) {
    if(changes['facets'].currentValue != null){
      this.facets = changes['facets'].currentValue;
      this.linksFacets = [
        {
          label: 'Country of Origin',
          searchParam: 'originCountryCode',
          facets: this.checkFacetExists('originCountries')          
        },{
          label: 'Country of Dispatch',
          searchParam: 'dispatchCountryCode',
          facets: this.checkFacetExists('dispatchCountries')          
        },{
          label: 'Country of Destination',
          searchParam: 'destinationCountryCode',
          facets: this.checkFacetExists('destinationCountries')          
        },{
          label: 'Mode of Transport',
          searchParam: 'transportModeCode',
          facets: this.checkFacetExists('transportModes')          
        },
        {
          label: 'Goods location',
          searchParam: 'goodsLocation',
          facets: this.checkFacetExists('goodsLocations')
        }
      ]
    }
  }

  private checkFacetExists(facetType: string) : Array<Facet> {
    if(this.facets[facetType] === undefined) {
      return null;
    }
    return this.facets[facetType];
  }

}
