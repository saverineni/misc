import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {SearchFilterComponent} from './search-filter.component';
import {Facets, Facet} from "../facets";
import {FacetedSearchComponent} from "./faceted-search/faceted-search.component";
import {By} from "@angular/platform-browser";
import {DebugElement, Directive, Input, SimpleChange} from "@angular/core";
import {BrowserDynamicTestingModule} from "@angular/platform-browser-dynamic/testing";
import {MatDialog, MatDialogModule} from '@angular/material/dialog';
import {MatListModule} from "@angular/material/list";
import {MatChipsModule, MatFormFieldModule, MatIconModule} from "@angular/material";
import {FacetNotMatchingPipe} from '../facet-not-matching.pipe';
import {FormsModule} from "@angular/forms";
import {FlexLayoutModule} from "@angular/flex-layout";
import {MatInputModule} from "@angular/material/input";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import { SearchCriteria } from '../search-criteria';
import { Country } from "../country";

@Directive({
  selector: 'cds-entry-date-filter'
})
export class EntryDateFilterStub {}

@Directive({
  selector: 'cds-links-facet'
})
export class LinksFacetStub {
  @Input() label: string;
  @Input() searchParam: string;
  @Input() facets: Array<Facet>;
}

describe('SearchFilterComponent', () => {
  let component: SearchFilterComponent;
  let fixture: ComponentFixture<SearchFilterComponent>;
  let filter: DebugElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MatDialogModule, MatListModule, MatChipsModule, MatIconModule , MatInputModule, BrowserAnimationsModule , FlexLayoutModule, FormsModule],
      declarations: [SearchFilterComponent, FacetedSearchComponent , FacetNotMatchingPipe, EntryDateFilterStub, LinksFacetStub]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    filter = fixture.debugElement.query(By.css('.search-filter'));
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should contain the filters label', () => {
    let label = filter.query(By.css('.search-filter__label')).nativeElement;
    expect(label.innerText).toBe('Filters')
  });

  describe('any changes to input properties should update', () => {
    let facets: Facets;
    const facet = (id, count) => ({'id': id, 'count': count} as Facet);

    beforeEach(() => {
      facets  = new Facets();
      facets.originCountries = [facet('oc1', 3)];
      facets.dispatchCountries = [facet('dis1', 1)];
      facets.destinationCountries = [facet('des1', 5)];
      facets.transportModes = [facet('tm1', 4)];
      facets.goodsLocations = [facet('gl1', 4)];
    });

    beforeEach(() => {
      component.ngOnChanges({
        'facets': new SimpleChange(null, facets, true)
      });

      fixture.detectChanges();
    });

    it('facets', () => {
      expect(component.facets).toBe(facets);
    });
  });
});
