import { Pipe, PipeTransform } from '@angular/core';
import { Facet } from './facets';

@Pipe({
  name: 'facetNotMatching'
})
export class FacetNotMatchingPipe implements PipeTransform {
  static matching(facet: Facet, filter: string): boolean {
    return this.nullSafeFacetData(facet).startsWith(filter.toUpperCase());
  }

  transform(facet: Facet, filter: string): boolean {
    const isFiltered = filter != null && filter != '';
    return isFiltered && !FacetNotMatchingPipe.matching(facet, filter);
  }

  private static nullSafeFacetData(facet: Facet) : string {
    return facet.id == null ? '' : facet.id.toUpperCase();
  }
}
