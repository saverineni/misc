import { Component, ChangeDetectionStrategy } from '@angular/core';
import { HttpNotificationService } from './http-notification.service';
import { OnInit } from '@angular/core/src/metadata/lifecycle_hooks';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  readonly title = 'Customs Declaration Search';

  httpRequest: HttpNotificationService;

  constructor(private httpNotification: HttpNotificationService) {}

  ngOnInit(): void {
    this.httpRequest = this.httpNotification;
  }
}
