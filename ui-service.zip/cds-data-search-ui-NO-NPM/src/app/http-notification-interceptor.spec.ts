import { HttpNotificationService } from "./http-notification.service";
import { HttpNotificationInterceptor } from "./http-notification-interceptor";
import { HttpRequest } from "@angular/common/http";
import { of, Observable } from "rxjs";

describe('HttpNotificationInterceptor', () => {
  let httpNotificationService: HttpNotificationService;
  let httpNotificationInterceptor: HttpNotificationInterceptor;

  beforeEach(() => {
    httpNotificationService = {
      requesting: () => {},
      complete: () => {}
    } as HttpNotificationService;

    spyOn(httpNotificationService, 'requesting');
    spyOn(httpNotificationService, 'complete');

    httpNotificationInterceptor = new HttpNotificationInterceptor(httpNotificationService);
  });

  describe('intercept', () => {
    const req = {} as HttpRequest<any>;
    let observable: Observable<any>;
    let next;

    beforeEach(() => {
      observable = of({});
      next = { handle: req => observable}
    });

    it('call requesting on the service', ()  => {
      httpNotificationInterceptor.intercept(req, next);

      expect(httpNotificationService.requesting).toHaveBeenCalled();
    });

    it('should handle the given request', () => {
      spyOn(next, 'handle').and.callThrough();
      httpNotificationInterceptor.intercept(req, next);

      expect(next.handle).toHaveBeenCalledWith(req);
    });

    describe('on completing the request', () => {
      beforeEach((done) => {
        observable.subscribe(done);
      });

      it('should call complete on the service', ()  => {
        httpNotificationInterceptor.intercept(req, next);

        expect(httpNotificationService.requesting).toHaveBeenCalled();
      });
    });
  });
});
