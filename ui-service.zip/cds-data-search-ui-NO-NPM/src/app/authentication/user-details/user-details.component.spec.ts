import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {UserDetailsComponent} from './user-details.component';
import {By} from '@angular/platform-browser';
import {UserService} from '../user.service';
import {User} from '../user';
import {AuthenticationService} from '../authentication.service';
import {SignInRouterService} from "../sign-in/sign-in-router.service";
import {NavigationService} from "../../declaration/search/navigation.service";

describe('UserDetailsComponent', () => {
  let component: UserDetailsComponent;
  let fixture: ComponentFixture<UserDetailsComponent>;

  beforeEach(async(() => {
    let testUserService = {
      isSignedIn: () => false,
      getUser: (): User => null
    } as UserService;

    let signInRouterService = {
      navigateToSignIn: () => { }
    } as SignInRouterService;


    let testAuthenticationService = {
      signOut: () => { }
    } as AuthenticationService;

    let testNavigationService = {
      navigateToSearch: (x) => {}
    } as NavigationService;

    TestBed.configureTestingModule({
      declarations: [UserDetailsComponent],
      providers: [
        { provide: UserService, useValue: testUserService },
        { provide: AuthenticationService, useValue: testAuthenticationService },
        { provide: SignInRouterService, useValue: signInRouterService },
        { provide: NavigationService, useValue: testNavigationService }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('user is not signed in', () => {
    it('should not display the user details', () => {
      const userDetails = fixture.debugElement.query(By.css('.user-details'));

      expect(userDetails == null).toBeTruthy();
    });
  });

  describe('user signed in', () => {
    const pid = 'the-pid';
    const user = new User(pid);

    beforeEach(() => {
      fixture = TestBed.createComponent(UserDetailsComponent);
      component = fixture.componentInstance;
      const userService = TestBed.get(UserService);
      spyOn(userService, 'isSignedIn').and.returnValue(true);
      spyOn(userService, 'getUser').and.returnValue(user);
      fixture.detectChanges();
    });

    it('should display the user details', () => {
      const userDetails = fixture.debugElement.query(By.css('.user-details'));
      expect(userDetails != null).toBeTruthy();
    });

    it("should display the user's pid", () => {
      const pidElement: HTMLElement = fixture.debugElement.query(By.css('.user-details__pid')).nativeElement;
      expect(pidElement.textContent).toEqual(pid);
    });

    describe('sign out', () => {
      let authenticationService;
      let signInRouterService;
      let navigationService;
      let signOutLink;

      beforeEach(() => {
        authenticationService = TestBed.get(AuthenticationService);
        signInRouterService = TestBed.get(SignInRouterService);
        navigationService = TestBed.get(NavigationService);
        spyOn(authenticationService, 'signOut');
        spyOn(signInRouterService, 'navigateToSignIn');
        spyOn(navigationService, 'navigateToSearch');
        signOutLink = fixture.debugElement.query(By.css('.user-details__sign-out'));
      });

      it('should display the sign out link', () => {
        expect(signOutLink != null).toBeTruthy();
      });

      describe('click', () => {

        beforeEach(() => {
          signOutLink.nativeElement.click();
        });

        it('should signOut with the authentication service on click', () => {
          expect(authenticationService.signOut).toHaveBeenCalled();
        });

        it('should clear the search criteria and params using navigation service on click', () => {
          expect(navigationService.navigateToSearch).toHaveBeenCalled();
        });

        it('should route to the sign in page', () => {
          expect(signInRouterService.navigateToSignIn).toHaveBeenCalled();
        });
      });
    });
  });
});
