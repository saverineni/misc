import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { SignInComponent } from './sign-in.component';

import { FlexLayoutModule } from '@angular/flex-layout';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DebugElement, ErrorHandler } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { AuthenticationResult } from '../authentication-result';
import { FormsModule } from '@angular/forms';
import { Observable, throwError, empty, of } from 'rxjs';
import { ActivatedRoute } from "@angular/router";
import { SignInRouterService } from "./sign-in-router.service";

class MockAuthenticationService {
  signIn(pid: string, password: string) { }
}

describe('SignInComponent', () => {
  let component: SignInComponent;
  let fixture: ComponentFixture<SignInComponent>;
  let authenticationService: AuthenticationService;
  let authenticationServiceSpy: jasmine.Spy;
  let signInRouterService;
  let activatedRouteSnapshot;

  beforeEach(async(() => {
    let mockSignInRouterService = {
      navigateToReturnUrl: (activatedRouteSnapshot) => {}
    } as SignInRouterService;

    activatedRouteSnapshot = { queryParams:{} };
    let mockActivatedRoute = {
      snapshot: activatedRouteSnapshot
    } as ActivatedRoute;

    TestBed.configureTestingModule({
      declarations: [SignInComponent],
      imports: [
        FlexLayoutModule,
        MatButtonModule,
        MatInputModule,
        BrowserAnimationsModule,
        FormsModule
      ],
      providers: [
        { provide: AuthenticationService, useClass: MockAuthenticationService },
        { provide: SignInRouterService, useValue: mockSignInRouterService },
        { provide: ActivatedRoute, useValue: mockActivatedRoute }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    authenticationService = TestBed.get(AuthenticationService);
    authenticationServiceSpy = spyOn(authenticationService, 'signIn');
    authenticationServiceSpy.and.returnValue(empty());

    signInRouterService = TestBed.get(SignInRouterService);
    spyOn(signInRouterService, 'navigateToReturnUrl');

    fixture = TestBed.createComponent(SignInComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  describe('sign in form', () => {
    let form: DebugElement;
    let pidInput: DebugElement;
    let passwordInput: DebugElement;
    let signInFormButton: DebugElement;
    const getErrorMessageElement = () => fixture.debugElement.query(By.css('.sign-in-form__error-message'));

    beforeEach(async(() => {
      form = fixture.debugElement.query(By.css('.sign-in-form'));
      pidInput = form.query(By.css('.sign-in-form__pid-input'));
      passwordInput = form.query(By.css('.sign-in-form__password-input'));
      signInFormButton = form.query(By.css('.sign-in-form__button'));
      fixture.detectChanges();
    }));

    it('should be displayed', () => {
      expect(form).toBeTruthy();
    });

    it('should have a username field', () => {
      expect(pidInput).toBeTruthy();
    });

    it('should have a password field', () => {
      expect(passwordInput).toBeTruthy();
    });

    it('should have a button', () => {
      expect(signInFormButton).toBeTruthy();
    });

    it('should not display error section', () => {
      expect(getErrorMessageElement() == null).toBeTruthy()
    });

    describe('sign in credentials', () => {
      xdescribe('not entered', () => {
        it('should not be able to submit the form', () => {
          form.nativeElement.dispatchEvent(new Event('submit'));
          expect(authenticationService.signIn).not.toHaveBeenCalled;
        });

        it('should disable the submit button', () => {
          expect(signInFormButton.nativeElement.disabled).toBeTruthy();
        });
      });

      describe('entered', () => {
        const pid = 'pid';
        const password = 'password';

        beforeEach(() => {
          pidInput.nativeElement.value = pid;
          passwordInput.nativeElement.value = password;
        });

        it('should be submitted for authentication on button click', () => {
          signInFormButton.nativeElement.click();

          expect(authenticationService.signIn).toHaveBeenCalledWith(pid, password);
        });

        it('should be submitted for authentication on form submit', () => {
          form.nativeElement.dispatchEvent(new Event('submit'));

          expect(authenticationService.signIn).toHaveBeenCalledWith(pid, password);
        });

        describe('authentication fails', () => {
          beforeEach(() => {
            authenticationServiceSpy.and.returnValue(of(new AuthenticationResult(false)));
            form.nativeElement.dispatchEvent(new Event('submit'));
          });

          it('should display error message', () => {
            fixture.detectChanges();
            expect(getErrorMessageElement().nativeElement.innerText).toBe('You have entered invalid credentials');
          });
        });

        describe('authentication success', () => {

          beforeEach(() => {
            authenticationServiceSpy.and.returnValue(of(new AuthenticationResult(true)));
            form.nativeElement.dispatchEvent(new Event('submit'));
          });

          it('should invoke router', () => {
            expect(signInRouterService.navigateToReturnUrl).toHaveBeenCalledWith(activatedRouteSnapshot);
          });
        });

        describe('unexpected error', () => {
          beforeEach(() => {
            authenticationServiceSpy.and.returnValue(throwError('unexpected error'));
            form.nativeElement.dispatchEvent(new Event('submit'));
          });

          it('should not display a form error', () => {
            fixture.detectChanges();
            expect(getErrorMessageElement() === null).toBe(true);
          });
        });
      });
    });
  });
});
