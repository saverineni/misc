import { Component, OnInit, OnDestroy, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { ActivatedRoute, ActivatedRouteSnapshot, Router } from "@angular/router";
import { SignInRouterService } from "./sign-in-router.service";
import { catchError } from 'rxjs/operators';
import { AuthenticationResult } from '../authentication-result';
import { of, throwError } from 'rxjs';

@Component({
  selector: 'cds-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SignInComponent implements OnInit {
  private unauthorised: boolean = false;
  private routeSnapshot: ActivatedRouteSnapshot;

  constructor(
    private authenticationService: AuthenticationService,
    private route: ActivatedRoute,
    private signInRouterService: SignInRouterService,
    private changeDetectorRef: ChangeDetectorRef) { }

  ngOnInit() {
    this.routeSnapshot = this.route.snapshot;
  }

  signIn(pid: string, password: string) {
    this.authenticationService
      .signIn(pid, password)
      .subscribe(authenticationResult => {
        if (authenticationResult.authorised) {
          this.signInRouterService.navigateToReturnUrl(this.routeSnapshot);
        } else {
          this.unauthorised = true;
          this.changeDetectorRef.detectChanges();
        }
      });
  }

  isUnauthorised() {
    return this.unauthorised;
  }
}
