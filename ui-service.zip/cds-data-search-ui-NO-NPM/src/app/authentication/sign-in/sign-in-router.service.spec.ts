import {SignInRouterService} from './sign-in-router.service';
import {Router} from "@angular/router";

describe('SignInRouterService', () => {
  let service;
  let newRouter = {
    navigate(command): Promise<boolean> {
      return Promise.resolve(true);
    },
    navigateByUrl(url): Promise<boolean> {
      return Promise.resolve(true);
    }
  } as Router;

  beforeEach(() => {
    service = new SignInRouterService(newRouter);
    spyOn(newRouter , 'navigate');
    spyOn(newRouter , 'navigateByUrl');
  });

  describe('navigateToSignIn', () => {

    it('navigates to signin', () => {
        service.navigateToSignIn();
        expect(newRouter.navigate).toHaveBeenCalledWith(['signin'], {});
      });

    describe('given router state',() => {
      it('navigates to signin with current url as a query param', () => {

        let routerStateSnapshot = {url: '/current-url'};

        service.navigateToSignIn(routerStateSnapshot);
        expect(newRouter.navigate).toHaveBeenCalledWith(['signin'], {queryParams: {returnUrl: routerStateSnapshot.url}});
      });

    });
  });

  describe('navigateToReturnUrl', () => {

    describe('given no return url' , () => {
      it('should navigate to home page', () => {
        service.navigateToReturnUrl({queryParams:{}});
        expect(newRouter.navigateByUrl).toHaveBeenCalledWith('/');
      });
    });

    describe('given return url',() => {
      it('should navigate to return url', () => {

        let url = '/current-url';

        service.navigateToReturnUrl({queryParams:{returnUrl: url}});
        expect(newRouter.navigateByUrl).toHaveBeenCalledWith(url);
      });

    });
  });

});
