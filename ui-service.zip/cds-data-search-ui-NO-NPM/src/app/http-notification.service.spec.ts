import {HttpNotificationService} from './http-notification.service';

describe('HttpNotificationService', () => {
  let httpNotificationService: HttpNotificationService;
  beforeEach(() => {
    httpNotificationService = new HttpNotificationService();
  });

  it('should not be waiting by default', () =>
    expect(httpNotificationService.waiting()).toBeFalsy()
  );

  describe('when requesting', () => {
    beforeEach(() =>
      httpNotificationService.requesting()
    );

    it('should be waiting', () =>
      expect(httpNotificationService.waiting()).toBeTruthy()
    );

    describe('and then complete', () => {
      beforeEach(() =>
        httpNotificationService.complete()
      );

      it('should not be waiting', () =>
        expect(httpNotificationService.waiting()).toBeFalsy()
      );
    });
  });
});
