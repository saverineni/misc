import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { ElementsLibraryModule } from './elements-library/elements-library.module';
import { FlexLayoutModule } from '@angular/flex-layout';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { AuthenticationModule } from './authentication/authentication.module';
import { DeclarationSearchModule } from './declaration/search/declaration-search.module';
import { ErrorHandlingModule } from './error-handling/error-handling.module';
import { HttpInterceptorsModule } from "./authentication/http-interceptors/http-interceptors.module";
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpNotificationInterceptor } from './http-notification-interceptor';
import { HttpNotificationService } from './http-notification.service';
import { MatProgressSpinnerModule } from '@angular/material';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    AppRoutingModule,
    AuthenticationModule,
    HttpInterceptorsModule.forRoot(),
    BrowserModule,
    DeclarationSearchModule,
    ElementsLibraryModule,
    FlexLayoutModule,
    ErrorHandlingModule.forRoot(),
    MatProgressSpinnerModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: HttpNotificationInterceptor, multi: true },
    HttpNotificationService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
