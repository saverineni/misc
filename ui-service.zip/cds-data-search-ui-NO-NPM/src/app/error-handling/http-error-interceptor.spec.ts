import { Observable, of, throwError } from 'rxjs';
import { HttpErrorInterceptor } from './http-error-interceptor';
import { OperationErrorNotifier } from './operation-error-notifier';
import { HttpErrorResponse, HttpHandler, HttpRequest } from '@angular/common/http';
import { CacheService } from "../authentication/cache.service";
import { SignInRouterService } from "../authentication/sign-in/sign-in-router.service";

describe('HttpErrorInterceptor', () => {
  let interceptor: HttpErrorInterceptor;
  let errorNotifier: OperationErrorNotifier;
  let req: HttpRequest<any>;
  let next: HttpHandler;
  let testObservable: Observable<any>;
  let cacheService: CacheService;
  let signInRouterService: SignInRouterService;

  function setUpForObservable(observable) {
    next = {
      handle: (reqParam) => {
        if (reqParam === req) return observable;
        else fail('not given correct response');
      }
    } as HttpHandler;
  }

  beforeEach(() => {
    req = new HttpRequest('GET', 'url');
    cacheService = {
      clear: () => {}
    } as CacheService;
    spyOn(cacheService, 'clear');

    signInRouterService = {
      navigateToSignIn: () => {}
    } as SignInRouterService;
    spyOn(signInRouterService, 'navigateToSignIn');

    errorNotifier = {
      notifyUser(message) {
      }
    } as OperationErrorNotifier;
    spyOn(errorNotifier, 'notifyUser');

    interceptor = new HttpErrorInterceptor(errorNotifier, cacheService, signInRouterService);
  });

  describe('intercept connection errors', () => {
    beforeEach((done) => {
      const err = new HttpErrorResponse({ status: 0 });
      setUpForObservable(throwError(err));
      interceptor.intercept(req, next).subscribe(
        success => done.fail(),
        err => done()
      );
    });

    it('notifies user', () => {
      expect(errorNotifier.notifyUser).toHaveBeenCalledWith('Connection error');
    });
  });

  describe('handle connection timeout', () => {
    beforeEach((done) => {
      const err = new Error();
      setUpForObservable(throwError(err));
      interceptor.intercept(req, next).subscribe(
        success => done.fail(),
        err => done()
      );
    });

    it('notifies user', () => {
      expect(errorNotifier.notifyUser).toHaveBeenCalledWith('Connection error');
    });
  });

  describe('not an error', () => {
    beforeEach(() => {
      setUpForObservable(of({}));
    });

    it('notifies user', (done) => {
      interceptor.intercept(req, next).subscribe(
        success => {
          expect(errorNotifier.notifyUser).not.toHaveBeenCalled();
          expect(cacheService.clear).not.toHaveBeenCalled();
          expect(signInRouterService.navigateToSignIn).not.toHaveBeenCalled();
          done();
        },
        err => done.fail(err)
      );
    });
  });

  [500, 502, 503, 504].forEach(statusCode => {
    describe('intercept ${statusCode} server error', () => {
      beforeEach((done) => {
        const err = new HttpErrorResponse({ status: statusCode });
        setUpForObservable(throwError(err));
        interceptor.intercept(req, next).subscribe(
          success => done.fail(),
          err => done()
        );
      });

      it('notifies user', () => {
        expect(errorNotifier.notifyUser).toHaveBeenCalledWith('Server error');
      });
    });
  });

  [400, 403, 404, 405].forEach(statusCode => {
    describe('intercept ${statusCode} client error', () => {
      beforeEach((done) => {
        const err = new HttpErrorResponse({ status: statusCode });
        setUpForObservable(throwError(err));
        interceptor.intercept(req, next).subscribe(
          success => done.fail(),
          err => done()
        );
      });

      it('does not notifies user', () => {
        expect(errorNotifier.notifyUser).not.toHaveBeenCalled();
      });
    });
  });

  describe('intercept 401 client error', () => {
    beforeEach((done) => {
      const err = new HttpErrorResponse({ status: 401 });
      setUpForObservable(throwError(err));
      interceptor.intercept(req, next).subscribe(
        success => done.fail(),
        err => done()
      )
    });

    it('clears cache and redirects to sigin page', () => {
      expect(errorNotifier.notifyUser).not.toHaveBeenCalled();
      expect(cacheService.clear).toHaveBeenCalled();
      expect(signInRouterService.navigateToSignIn).toHaveBeenCalled();
    });
  });
});
