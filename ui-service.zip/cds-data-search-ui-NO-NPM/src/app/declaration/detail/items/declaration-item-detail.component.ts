import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ChangeDetectorRef } from '@angular/core';
import { OnDestroy } from '@angular/core';
import { ChangeDetectionStrategy } from '@angular/core';
import { Declaration } from '../declaration';
import { ColumnDefinition } from '../../../elements-library/cds-data-grid/column-definition';
import { NavigationService } from '../../search/navigation.service';
import { DeclarationService } from '../declaration.service';
import { map } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { ViewEncapsulation } from '@angular/core';
import { Location } from '@angular/common';
import { TrackBy } from '../../../track-by';
import { ViewChild } from '@angular/core';

@Component({
  selector: 'cds-declaration-item-detail',
  templateUrl: './declaration-item-detail.component.html',
  styleUrls: ['./declaration-item-detail.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class DeclarationItemDetailComponent implements OnInit {
  trackByItemNumber = TrackBy.property('itemNumber');

  @ViewChild("tabs") tabs;

  items$: Observable<Array<any>>;
  itemNumber$: Observable<number>;
  declarationId: string;

  noResults: boolean;

  constructor(private route: ActivatedRoute,
              private navigationService: NavigationService,
              private declarationService: DeclarationService,
              private location: Location) { }

  ngOnInit() {
    this.items$ = this.declarationService.declarationForRoute(this.route)
      .pipe(
        map(declaration => {
          this.declarationId = declaration.declarationId;
          return declaration.lines.map((line: any) => {
              line.declarationId = declaration.declarationId;
              return line;
            })
            .sort((a, b) => a.itemNumber > b.itemNumber ? 1 : -1);
          })
        );

    this.itemNumber$ = this.route.params
      .pipe(
        map((params) => +params['number'])
      );
  }

  onIndexChange(number) {
    this.location.replaceState(`/declarations/${this.declarationId}/items/${number + 1}`);
  }

  onFilterInput(itemFilter, items) {
    let itemNumber = +itemFilter;
    if (!itemFilter || itemFilter === '') {
      this.noResults = false;
    } else if (!isNaN(itemNumber) && itemNumber > 0 && itemNumber <= items.length) {
      this.noResults = false;
      this.tabs.selectedIndex = itemNumber - 1;
    } else  {
      this.noResults = true;
    }
  }

  declarationItemColumnDefinitions = [
    new ColumnDefinition({ id: 'declarationId', label: 'Declaration ID', colspan: 4, strong: true }),
    new ColumnDefinition({ id: 'itemRoute', label: 'Route of Entry' }),
    new ColumnDefinition({ id: 'itemDispatchCountry', label: 'Country of Dispatch',
      getValue: (item) => item.itemDispatchCountry && item.itemDispatchCountry.code }),
    new ColumnDefinition({ id: 'itemDestinationCountry', label: 'Country of Destination',
      getValue: (item) => item.itemDestinationCountry && item.itemDestinationCountry.code }),
    new ColumnDefinition({ id: 'clearanceDate', label: 'Clearance Date' }),
    new ColumnDefinition({ id: 'cpc', label: 'CPC' }),
    new ColumnDefinition({ id: 'originCountry', label: 'Country of Origin',
      getValue: (item) => item.originCountry && item.originCountry.code }),
    new ColumnDefinition({ id: 'commodityCode', label: 'Commodity Code' }),
    new ColumnDefinition({ id: 'itemConsigneeTurn', label: 'Consignee Number' }),
    new ColumnDefinition({ id: 'itemConsigneeName', label: 'Consignee Name' }),
    new ColumnDefinition({ id: 'itemConsigneePostcode', label: 'Consignee Postcode' }),
    new ColumnDefinition({ id: 'itemConsignorTurn', label: 'Consignor Number' }),
    new ColumnDefinition({ id: 'itemConsignorName', label: 'Consignor Name' }),
    new ColumnDefinition({ id: 'itemConsignorPostcode', label: 'Consignor Postcode' })
  ];

  itemColumns(item) {
    return of(this.declarationItemColumnDefinitions.map(it => it.toColumn(item)))
  }

  backToSearchResults() {
    this.navigationService.navigateToSearch(false);
  }
}
