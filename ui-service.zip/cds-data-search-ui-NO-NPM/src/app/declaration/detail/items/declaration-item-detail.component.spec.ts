import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeclarationItemDetailComponent } from './declaration-item-detail.component';
import { MatCardModule, MatDividerModule, MatTabsModule, MatFormFieldModule, MatInputModule } from '@angular/material';
import { Directive, Input } from '@angular/core';
import { Declaration } from '../declaration';
import { ColumnDefinition, Column } from '../../../elements-library/cds-data-grid/column-definition';
import { of, Observable } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { Location, LocationStrategy } from '@angular/common';
import { DeclarationLine } from '../declaration-line';
import { By } from '@angular/platform-browser';
import { NavigationService } from '../../search/navigation.service';
import { DeclarationService } from '../declaration.service';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { fakeAsync } from '@angular/core/testing';
import { tick } from '@angular/core/testing';
import { map } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { FormsModule } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { DebugElement } from '@angular/core/src/debug/debug_node';

@Directive({
  selector: 'cds-data-grid'
})
export class DeclarationDataGridStub {
  @Input() columnCount: number;
  @Input() columns: Observable<Column[]>;
}

describe('DeclarationItemDetailComponent', () => {
  let component: DeclarationItemDetailComponent;
  let fixture: ComponentFixture<DeclarationItemDetailComponent>;
  let declaration: Declaration;
  let itemNumberParam: any;
  let declarationService: DeclarationService;
  let paramsBehaviour: BehaviorSubject<any>;
  let location: Location;

  beforeEach(async(() => {
    declaration = new Declaration();
    declaration.declarationId = 'id';
    declaration.lines = [
      { itemNumber: 1, itemRoute: 'one' } as DeclarationLine,
      { itemNumber: 3, itemRoute: 'three' } as DeclarationLine,
      { itemNumber: 2, itemRoute: 'two' } as DeclarationLine
    ];

    let obs: any = of(declaration);
    declarationService = {
      declarationForRoute: (route) => obs
    } as DeclarationService;

    itemNumberParam = { number: 2 };
    paramsBehaviour = new BehaviorSubject(itemNumberParam)

    let mockActivatedRoute = {
      params: paramsBehaviour.asObservable()
    } as ActivatedRoute;

    const navigationService = {
      navigateToSearch: (x) => {}
    } as NavigationService;

    TestBed.configureTestingModule({
      imports: [MatCardModule, MatDividerModule, MatTabsModule, RouterTestingModule, NoopAnimationsModule, FormsModule, MatInputModule],
      declarations: [ DeclarationItemDetailComponent, DeclarationDataGridStub ],
      providers: [
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: DeclarationService, useValue: declarationService },
        { provide: NavigationService, useValue: navigationService }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeclarationItemDetailComponent);
    component = fixture.componentInstance;
    location = TestBed.get(Location);
    spyOn(location, 'replaceState');
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  describe('data grid', () => {
    let dataGrid: DeclarationDataGridStub;

    describe('with items', () => {
      beforeEach(() => {
        dataGrid = fixture.debugElement.query(By.directive(DeclarationDataGridStub)).injector.get(DeclarationDataGridStub);
      });

      it('should be given the correct column count', () => {
        expect(dataGrid.columnCount).toEqual(4);
      });

      it('should be given the correct columns for the item', (done) => {
        const expectedItem = { declarationId: 'id', itemNumber: 2, itemRoute: 'two' };
        dataGrid.columns.subscribe(
          columns => {
            expect(columns).toEqual(component.declarationItemColumnDefinitions.map(it => it.toColumn(expectedItem)));
            done();
          },
          done.fail
        );
      });
    });
  });

  function getActiveItemNumber() {
    return fixture.debugElement.query(By.css('.declaration-item-detail__declarations'))
    .nativeElement.getAttribute('data-declaration-item-number');
  }

  function getItemTabLabels() {
    return fixture.debugElement.queryAll(By.css('.declaration-item-detail__tab-label'))
      .map(e => e.nativeElement.innerText.trim());
  }

  describe('declaration item search filter', () => {
    function filterBy(text) {
      const filterElement = fixture.debugElement.query(By.css(".declaration-item-detail__item-filter-input")).nativeElement;
      filterElement.value = text;
      filterElement.dispatchEvent(new Event('input'));
      filterElement.dispatchEvent(new Event('keyup'));

      fixture.detectChanges();
    }

    it('should select the tab for the given item number',() => {
      filterBy('3');

      // need to query tabs directly as mat-tab-group value doesn't seem to get updated
      // due to an unknown...?
      expect(component.tabs.selectedIndex).toEqual(2);
    });

    describe('no matches', () => {
      beforeEach(() => {
        filterBy('99');
      });

      it('should display message', () => {
        const messageElement = fixture.debugElement.query(By.css(".declaration-item-detail__no-results-message"));

        expect(messageElement != null).toBeTruthy();
      });

      it('should not display the tabs', () => {
        expect(getItemTabLabels()).toEqual([]);
      })

      describe('then cleared', () => {
        beforeEach(() => {
          filterBy('');
        });

        it('should display all tabs again', () => {
          expect(getItemTabLabels()).toEqual(['1', '2', '3']);
        });
      });
    });
  });

  describe('declaration item selection tabs', () => {

    it('should have the correct tab selected on load', () => {
      expect(getActiveItemNumber()).toEqual('2');
    });

    it('should have the item numbers for tab labels', () => {
      expect(getItemTabLabels()).toEqual(['1', '2', '3']);
    });

    it('should update the browser url when clicked', async(() => {
      let item3Tab = fixture.debugElement.query(By.css('.declaration-item-detail__tab-label[data-declaration-item-number="3"]'))
      item3Tab.nativeElement.click();
      fixture.detectChanges();

      fixture.whenStable().then(() => {
        expect(location.replaceState).toHaveBeenCalledWith('/declarations/id/items/3');
      });
    }));
  });

  describe('declaration item resolution', () => {
    it('should map declaration ids onto the item objects', (done) => {
      component.items$.subscribe(items => {
        expect(items.map(it => it.declarationId)).toEqual(['id', 'id', 'id']);
        done();
      });
    });

    it('should sort the items by their item number', (done) => {
      component.items$.subscribe(items => {
        expect(items.map(it => it.itemNumber)).toEqual([1, 2, 3]);
        done();
      });
    });
  });

  describe('result count', () => {
    it('should display the correct number of total items', () => {
      const itemCount = fixture.debugElement.query(By.css('.declaration-item-detail__results-count')).nativeElement.innerText.trim();
      expect(itemCount).toEqual('3');
    });
  });

  describe('back to search button', () => {
    let navigationService: NavigationService;
    beforeEach(() => {
      navigationService = TestBed.get(NavigationService);
      spyOn(navigationService, 'navigateToSearch');
    });

    it('should call the navigation service when clicked', () => {
      fixture.detectChanges();
      fixture.debugElement.query(By.css('.declaration-item-detail__back-to-search-button')).nativeElement.click();
      expect(navigationService.navigateToSearch).toHaveBeenCalledWith(false);
    });
  });
});
