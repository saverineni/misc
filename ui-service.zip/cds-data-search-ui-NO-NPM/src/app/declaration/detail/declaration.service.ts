import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Declaration } from './declaration';
import { ResourceService } from '../../resource/resource.service';
import { ActivatedRoute } from '@angular/router/src/router_state';
import { ParamMap } from '@angular/router';

@Injectable()
export class DeclarationService {

  constructor(private http: HttpClient,
              private resourceService: ResourceService) {}

  declarationForRoute(route: ActivatedRoute): Observable<Declaration> {
    return this.resourceService.handleNotFound(
        route,
        (params: ParamMap) => this.getDeclaration(params.get('id'))
      );
  }

  private getDeclaration(id: string): Observable<Declaration> {
    return this.http
      .get(`/api/declarations/${id}`)
      .pipe(
        map(searchResult => searchResult as Declaration)
      );
  }
}
