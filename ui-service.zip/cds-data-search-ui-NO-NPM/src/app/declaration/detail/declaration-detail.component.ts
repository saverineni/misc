import { Component, OnInit } from '@angular/core';
import { OnDestroy } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { ChangeDetectionStrategy } from '@angular/core';
import { Declaration } from './declaration';
import { ChangeDetectorRef } from '@angular/core';
import { NavigationService } from '../search/navigation.service';
import { ColumnDefinition, Column } from '../../elements-library/cds-data-grid/column-definition';
import { DeclarationService } from './declaration.service';
import { Observable } from 'rxjs/internal/Observable';
import { map, shareReplay } from 'rxjs/operators';

@Component({
  selector: 'cds-declaration-detail',
  templateUrl: './declaration-detail.component.html',
  styleUrls: ['./declaration-detail.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DeclarationDetailComponent implements OnInit {
  declarationHeaderColumnDefinitions = [
    new ColumnDefinition({ id: 'declarationId', label: 'Declaration ID', colspan: 4, strong: true }),
    new ColumnDefinition({ id: 'epuNumber', label: 'EPU' }),
    new ColumnDefinition({ id: 'entryNumber', label: 'Entry Number' }),
    new ColumnDefinition({ id: 'entryDate', label: 'Entry Date' }),
    new ColumnDefinition({ id: 'route', label: 'Route of Entry' }),
    new ColumnDefinition({ id: 'dispatchCountry', label: 'Country of Dispatch',
      getValue: (dec) => dec.dispatchCountry && dec.dispatchCountry.code }),
    new ColumnDefinition({ id: 'destinationCountry', label: 'Country of Destination',
      getValue: (dec) => dec.destinationCountry && dec.destinationCountry.code }),
    new ColumnDefinition({ id: 'consigneeTurn', label: 'Consignee Number' }),
    new ColumnDefinition({ id: 'consigneeName', label: 'Consignee Name' }),
    new ColumnDefinition({ id: 'consigneePostcode', label: 'Consignee Postcode' }),
    new ColumnDefinition({ id: 'consignorTurn', label: 'Consignor Number' }),
    new ColumnDefinition({ id: 'consignorName', label: 'Consignor Name' }),
    new ColumnDefinition({ id: 'consignorPostcode', label: 'Consignor Postcode' }),
    new ColumnDefinition({ id: 'goodsLocation', label: 'Goods Location' }),
    new ColumnDefinition({ id: 'transportModeCode', label: 'Mode of Transport' })
  ];

  declaration$: Observable<Declaration>;
  gridColumns$: Observable<Column[]>;

  constructor(private route: ActivatedRoute,
              private navigationService: NavigationService,
              private declarationService: DeclarationService) { }

  ngOnInit() {
    this.declaration$ = this.declarationService.declarationForRoute(this.route).pipe(shareReplay(1));
    this.gridColumns$ = this.declaration$.pipe(
      map(declaration => this.declarationHeaderColumnDefinitions.map(it => it.toColumn(declaration)))
    );
  }

  backToSearchResults() {
    this.navigationService.navigateToSearch(false);
  }
}
