import { DeclarationLine } from "./declaration-line";
import {Country} from "../country";

export class Declaration {
    declarationId: string;
    epuNumber: string;
    entryNumber: string;
    entryDate: string;
    route: string;
    dispatchCountry: Country;
    destinationCountry: Country;
    consigneeTurn: string;
    consignorTurn: string;
    goodsLocation: string;
    transportModeCode: string;
    consigneeName: string;
    consigneePostcode: string;
    consignorName: string;
    consignorPostcode: string;
    lines: Array<DeclarationLine>;
}
