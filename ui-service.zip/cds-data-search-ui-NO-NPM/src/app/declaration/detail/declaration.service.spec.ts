import { TestBed, inject, getTestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { DeclarationService } from './declaration.service';
import { HttpClient } from '@angular/common/http/src/client';
import { Declaration } from './declaration';
import { ResourceService } from '../../resource/resource.service';
import { ActivatedRoute } from '@angular/router';
import { ParamMap } from '@angular/router/src/shared';
import { of } from 'rxjs/internal/observable/of';
import { Observable } from 'rxjs';

describe('DeclarationService', () => {
  let declarationService: DeclarationService;
  let http: HttpClient;
  let httpMock: HttpTestingController;
  let resourceService: ResourceService;

  const ID = 'dec-id';

  let handledRoute;
  let paramHandler: (params: ParamMap) => Observable<any>;
  let expectedResult;

  beforeEach(() => {
    expectedResult = new Declaration();
    resourceService = {
      handleNotFound: (route, handler) => {
        handledRoute = route;
        paramHandler = handler;

        return of(expectedResult);
      }
    } as ResourceService;

    TestBed.configureTestingModule({
      providers: [
        DeclarationService,
        { provide: ResourceService, useValue: resourceService }],
      imports: [HttpClientTestingModule]
    });
    httpMock = getTestBed().get(HttpTestingController);
    declarationService = getTestBed().get(DeclarationService);
  });

  describe('declaration for route request', () => {
    let activatedRoute: ActivatedRoute;
    let serviceResult: Observable<Declaration>;

    beforeEach(() => {
      activatedRoute = {} as ActivatedRoute;

      serviceResult = declarationService.declarationForRoute(activatedRoute);
    });

    it('should call resource service with the given route', () => {
      serviceResult.toPromise();
      expect(handledRoute).toBe(activatedRoute);
    });

    it('should return the result of the resource service', (done) => {
      serviceResult.subscribe(
        success => {
          expect(success).toBe(expectedResult);
          done();
        },
        done.fail
      );
    });

    describe('param handler', () => {
      let testRequest;
      let paramMap: ParamMap;
      let handlerResult: Declaration;

      beforeEach((done) => {
        paramMap = { get: (param) => ID } as ParamMap
        spyOn(paramMap, 'get').and.callThrough();
        paramHandler(paramMap).subscribe(
          success => {
            handlerResult = success;
            done();
          },
          done.fail
        );

        testRequest = httpMock.expectOne(`/api/declarations/${ID}`);
        testRequest.flush({
          declarationId: ID,
          destinationCountry: {
            code: 'country-code'
          },
          lines: [ { itemNumber: 1 }]
        });
      });

      it('should get the id param from the param map', () => {
        expect(paramMap.get).toHaveBeenCalledWith('id');
      });

      it('should get the declaration by id', () => {
        expect(testRequest.request.method).toBe("GET");
      });

      it('should return the declaration', () => {
        expect(handlerResult.declarationId).toEqual(ID);
        expect(handlerResult.destinationCountry.code).toEqual('country-code');
        expect(handlerResult.lines.length).toEqual(1);
        expect(handlerResult.lines[0].itemNumber).toEqual(1);
      });
    });
  });
});
