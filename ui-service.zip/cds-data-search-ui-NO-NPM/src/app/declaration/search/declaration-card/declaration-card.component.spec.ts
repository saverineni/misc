import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeclarationCardComponent } from './declaration-card.component';
import { By } from '@angular/platform-browser';
import { Declaration } from '../../detail/declaration';
import { Directive, Input } from '@angular/core';
import { MatCardModule, MatDividerModule, MatExpansionModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { RouterTestingModule } from '@angular/router/testing';
import { ColumnDefinition, Column } from '../../../elements-library/cds-data-grid/column-definition';
import { DeclarationPreview } from '../declaration-preview';
import { DeclarationLine } from '../../detail/declaration-line';
import { Observable } from 'rxjs';
import { defineComponent } from '@angular/core/src/render3';

@Directive({
  selector: 'cds-data-grid'
})
export class DataGridStub {
  @Input() columnCount: number;
  @Input() columns: Observable<Column[]>;
}

describe('DeclarationCardComponent', () => {
  let component: DeclarationCardComponent;
  let fixture: ComponentFixture<DeclarationCardComponent>;
  let declaration: DeclarationPreview;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MatCardModule, MatDividerModule, MatExpansionModule, BrowserAnimationsModule, RouterTestingModule],
      declarations: [
        DeclarationCardComponent, DataGridStub
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeclarationCardComponent);
    component = fixture.componentInstance;
    declaration = new DeclarationPreview();
    declaration.declarationId = 'id';
    declaration.lines = [new DeclarationLine(), new DeclarationLine()]
    component.declaration = declaration;
  });

  it('should display', () => {
    fixture.detectChanges();
    expect(fixture.debugElement.query(By.css('.search-results-cards__declarations')) === null).toEqual(false);
  });

  describe('declaration details button', () => {
    it('should have the correct link for the declaration details', () => {
      fixture.detectChanges();
      let href = fixture.debugElement.query(By.css('.search-results-cards__declaration-details-button'))
      .nativeElement.getAttribute('ng-reflect-router-link');
      expect(href).toEqual('/declarations/id');
    });
  });

  describe('data grid', () => {
    let dataGrid: DataGridStub;

    beforeEach(() => {
      fixture.detectChanges();
      dataGrid = fixture.debugElement.query(By.directive(DataGridStub)).injector.get(DataGridStub);
    });

    it('should be created with the correct column count', () => {
      expect(dataGrid.columnCount).toBe(3);
    });

    it('should be created with the correct column count', (done) => {
      dataGrid.columns.subscribe(
        success => {
          expect(success).toEqual(
            component.declarationHeaderColumnDefinitions.map(it => it.toColumn(declaration))
          );
          done();
        },
        done.fail
      );
    });
  })

  describe('item details button', () => {

    function getItemDetailDisabledButton() {
      return fixture.debugElement.query(By.css('button.search-results-cards__item-details-button'));
    }

    function getItemDetailLink() {
      return fixture.debugElement.query(By.css('a.search-results-cards__item-details-button'));
    }

    it('should have the correct link for the first items details', () => {
      fixture.detectChanges();
      let href = getItemDetailLink().nativeElement.getAttribute('ng-reflect-router-link');
      expect(href).toEqual('/declarations/id/items/1');
    });

    it('should report the correct number of items', () => {
      fixture.detectChanges();
      expect(getItemDetailLink().nativeElement.innerText).toEqual('ITEM DETAILS (2)');
    });

    it('should not be disabled when there are items', () => {
      fixture.detectChanges();
      expect(getItemDetailLink() === null).toBe(false);
      expect(getItemDetailDisabledButton() === null).toBe(true);
    });

    it('should report zero items correctly', () => {
      declaration.lines = [];
      fixture.detectChanges();
      expect(getItemDetailDisabledButton().nativeElement.innerText).toEqual('ITEM DETAILS (0)');
    });

    it('should be disabled when there are zero items', () => {
      declaration.lines = [];
      fixture.detectChanges();
      expect(getItemDetailDisabledButton().nativeElement.disabled).toBe(true);
    });
  });
});
