import {TestBed} from '@angular/core/testing';
import {SearchCriteriaService} from './search-criteria.service';
import {SearchCriteria} from './search-criteria';

describe('SearchCriteriaService', () => {
  let service: SearchCriteriaService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SearchCriteriaService]
    });

    service = TestBed.get(SearchCriteriaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should give the search criteria observable',(done) => {
    service.searchCriteria.subscribe(
      data => {
        expect(data).toEqual(new SearchCriteria());
        done();
      },
      done.fail
    );
  });

  describe('update', () => {
    let updatedCriteria;
    let criteriaSentToSubscribers;
    let newDataSent = false;

    beforeEach(() => {
      updatedCriteria = new SearchCriteria();
      updatedCriteria.searchTerm = 'term';
      service.update(updatedCriteria);
    });

    beforeEach((done) => {
      service.searchCriteria.subscribe(
        data => {
          criteriaSentToSubscribers = data;
          newDataSent = true;
          done();
        },
        done.fail
      );
    });

    it('should send updated criteria to subscribers', () => {
      expect(criteriaSentToSubscribers).toEqual(updatedCriteria);
    });

    describe('should send a copy of the new search criteria, not the the updated original', () => {

      it('for a non empty search criteria object', () => {
        expect(criteriaSentToSubscribers).not.toBe(updatedCriteria);
      });
  
      it('for an empty search criteria object', () => {
        updatedCriteria = new SearchCriteria();
        service.update(updatedCriteria);
  
        expect(criteriaSentToSubscribers).not.toBe(updatedCriteria);
        expect(criteriaSentToSubscribers).toEqual(new SearchCriteria());
      });
    });    

    describe('without property change', () => {
      beforeEach(() => {
        newDataSent = false;
        service.update(criteriaSentToSubscribers);
      });

      it('should not send the same criteria to subscribers', () => {
        expect(newDataSent).toBeFalsy();
      });
    });
  });

  describe('update partial', () => {
    let updatedCriteria;
    let criteriaSentToSubscribers;
    let newDataSent = false;

    beforeEach((done) => {
      service.searchCriteria.subscribe(
        data => {
          criteriaSentToSubscribers = data;
          newDataSent = true;
          done();
        },
        done.fail
      );
    });

    describe('single parameter', () => {
      beforeEach(() => {
        const searchTerm = 'new search term';
        service.updatePartial({searchTerm: searchTerm});

        updatedCriteria = new SearchCriteria();
        updatedCriteria.searchTerm = searchTerm;
      })

      it('should send updated criteria to subscribers', () => {
        expect(criteriaSentToSubscribers).toEqual(updatedCriteria);
      });

      it('should send a copy of the new search criteria, not the the updated original', () => {
        expect(criteriaSentToSubscribers).not.toBe(updatedCriteria);
      });
    });

    describe('multiple parameters', () => {
      beforeEach(() => {
        const from = 'from';
        const to = 'to';
        service.updatePartial({
          entryDateFrom: from,
          entryDateTo: to
        });

        updatedCriteria = new SearchCriteria();
        updatedCriteria.entryDateFrom = from;
        updatedCriteria.entryDateTo = to;
      });

      it('should send updated criteria to subscribers', () => {
        expect(criteriaSentToSubscribers).toEqual(updatedCriteria);
      });

      it('should send a copy of the new search criteria, not the the updated original', () => {
        expect(criteriaSentToSubscribers).not.toBe(updatedCriteria);
      });
    });

    describe('remembers previous updates', () => {
      beforeEach(() => {
        const from = 'from';
        const to = 'to';
        service.updatePartial({
          entryDateFrom: from
        });
        service.updatePartial({
          entryDateTo: to
        });

        updatedCriteria = new SearchCriteria();
        updatedCriteria.entryDateFrom = from;
        updatedCriteria.entryDateTo = to;
      });

      it('should send updated criteria to subscribers', () => {
        expect(criteriaSentToSubscribers).toEqual(updatedCriteria);
      });

      it('should send a copy of the new search criteria, not the the updated original', () => {
        expect(criteriaSentToSubscribers).not.toBe(updatedCriteria);
      });
    });
  });
});

