import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { Facet } from './facets';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { SearchCriteria } from './search-criteria';
import { SearchParamsBuilder } from './search-params-builder';

@Injectable()
export class FacetService {

  constructor(private http: HttpClient) { }

  getFacets(facetType: string, filterBy: string, searchCriteria: SearchCriteria): Observable<Array<Facet>> {
    const queryParams = SearchParamsBuilder.toHttpParams(searchCriteria).delete(facetType);
    let url = (filterBy) ? `/api/facets/${facetType}/${filterBy}`: `/api/facets/${facetType}`;

    return this.http
      .get(url, { params: queryParams })
      .pipe(
        map((result: any) => result.facets as Array<Facet>)
      );
  }
}
