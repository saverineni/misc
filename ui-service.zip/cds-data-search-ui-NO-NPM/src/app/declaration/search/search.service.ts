import {Injectable} from '@angular/core';
import {SearchCriteria} from './search-criteria';
import {SearchParamsBuilder} from './search-params-builder';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {HttpClient} from '@angular/common/http';
import {DeclarationSearchResult} from './declaration-search-result';

@Injectable()
export class SearchService {

  constructor(private http: HttpClient) {}

  search(search: SearchCriteria): Observable<DeclarationSearchResult> {
    return this.http
      .get("/api/declarations", { params: SearchParamsBuilder.toHttpParams(search) })
      .pipe(
        map(searchResult => searchResult as DeclarationSearchResult)
      );
  }
}
