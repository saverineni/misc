import {ChangeDetectionStrategy, Component} from '@angular/core';
import {TrackBy} from "../../../track-by";


@Component({
  selector: 'cds-search-filter',
  templateUrl: './search-filter.component.html',
  styleUrls: ['./search-filter.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class SearchFilterComponent {
  trackByIndex = TrackBy.index;

  linksFacets: Array<any> = [
    {
      label: 'Country of Origin',
      searchParam: 'originCountryCode'
    },{
      label: 'Country of Dispatch',
      searchParam: 'dispatchCountryCode'
    },{
      label: 'Country of Destination',
      searchParam: 'destinationCountryCode'
    },{
      label: 'Mode of Transport',
      searchParam: 'transportModeCode'
    },{
      label: 'Goods Location',
      searchParam: 'goodsLocation'
    },{
      label: 'Commodity Code',
      searchParam: 'commodityCode',
      facetSearch: {
        length: 4,
        type: 'numbers'
      }
    }
  ];
}
