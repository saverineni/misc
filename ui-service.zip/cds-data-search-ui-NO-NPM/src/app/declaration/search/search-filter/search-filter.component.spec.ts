import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {SearchFilterComponent} from './search-filter.component';
import {By} from "@angular/platform-browser";
import {DebugElement, Directive, Input} from "@angular/core";
import {FlexLayoutModule} from "@angular/flex-layout";

@Directive({
  selector: 'cds-date-range-filter'
})
export class DateRangeFilterStub {
  @Input() label: string;
  @Input() fromField: string;
  @Input() toField: string;
}

@Directive({
  selector: 'cds-links-facet'
})
class LinksFacetStub {
  @Input() label: string;
  @Input() searchParam: string;
  @Input() facetSearch: any;
}

describe('SearchFilterComponent', () => {
  let component: SearchFilterComponent;
  let fixture: ComponentFixture<SearchFilterComponent>;
  let filter: DebugElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FlexLayoutModule ],
      declarations: [SearchFilterComponent, DateRangeFilterStub, LinksFacetStub]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFilterComponent);
    component = fixture.componentInstance;

    filter = fixture.debugElement.query(By.css('.search-filter'));
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should contain the filters label', () => {
    let label = filter.query(By.css('.search-filter__label')).nativeElement;
    expect(label.innerText).toBe('Filters')
  });

  describe('any changes to input properties should update', () => {
    let links: DebugElement[];

    beforeEach(() => {
      fixture.detectChanges();
      links = fixture.debugElement.queryAll(By.directive(LinksFacetStub));
    });

    [{
      label: 'Country of Origin',
      searchParam: 'originCountryCode'
    },
    {
      label: 'Country of Dispatch',
      searchParam: 'dispatchCountryCode'
    },
    {
      label: 'Country of Destination',
      searchParam: 'destinationCountryCode'
    },
    {
      label: 'Mode of Transport',
      searchParam: 'transportModeCode'
    },
    {
      label: 'Goods Location',
      searchParam: 'goodsLocation'
    },
    {
      label: 'Commodity Code',
      searchParam: 'commodityCode',
      facetSearch: {
        length: 4,
        type: 'numbers'
      }
    }].forEach((expectedLinkFacet: any, index) => {
      let linkFacet: LinksFacetStub;
      describe(`${expectedLinkFacet.label} link gets added`, () => {

        beforeEach(() => {
          linkFacet = links[index].injector.get(LinksFacetStub);
        });

        it('with the correct label', () => {
          expect(linkFacet.label).toBe(expectedLinkFacet.label);
        });

        it('with correct searchParam', () => {
          expect(linkFacet.searchParam).toBe(expectedLinkFacet.searchParam);
        });

        it('with correct facet search info', () => {
          expect(linkFacet.facetSearch).toEqual(expectedLinkFacet.facetSearch);
        });
      });
    });
  });
});
