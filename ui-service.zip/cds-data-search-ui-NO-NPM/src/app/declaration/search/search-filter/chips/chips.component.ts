import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'cds-chips',
  templateUrl: './chips.component.html',
  styleUrls: ['./chips.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChipsComponent {
  @Input() id: string;
  @Input() label: string;
  @Input() chips: Array<string>;
  @Output() onRemove: EventEmitter<string> = new EventEmitter();

  remove(chipId) {
    this.onRemove.emit(chipId);
  }
}
