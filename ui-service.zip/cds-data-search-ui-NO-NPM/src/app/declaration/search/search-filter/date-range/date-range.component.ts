import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  Input,
  OnDestroy,
  OnInit,
  ViewChild
} from '@angular/core';
import {SearchCriteria} from '../../search-criteria';
import * as moment from 'moment';
import {SearchCriteriaService} from '../../search-criteria.service';

@Component({
  selector: 'cds-date-range-filter',
  templateUrl: './date-range.component.html',
  styleUrls: ['./date-range.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DateRangeComponent implements OnInit, OnDestroy {
  DATE_FORMAT = "YYYY-MM-DD";
  dateFrom: string = null;
  dateTo: string = null;
  panelOpenState: boolean = false;

  private subscription;
  private searchCriteria: SearchCriteria = null;

  @Input('label') label: string;
  @Input('fromField') fromField: string;
  @Input('toField') toField: string;
  @ViewChild('datePanel') datePanel;

  constructor(private searchCriteriaService: SearchCriteriaService,
              private changeDetectorRef: ChangeDetectorRef) { }

  ngOnInit() {
    this.subscription = this.searchCriteriaService.searchCriteria.subscribe(
      data  => {
        this.searchCriteria = data as SearchCriteria;
        this.dateFrom = this.searchCriteria[this.fromField];
        this.dateTo = this.searchCriteria[this.toField];
        this.toggleExpansionPanel();
        this.changeDetectorRef.detectChanges();
      }
    );
  }

  toggleExpansionPanel() {
    if (this.searchCriteria.isEmpty() && this.panelOpenState){
      this.datePanel.nativeElement.click();
    }
    if (this.dateFrom || this.dateTo){
      this.panelOpenState=true;
    }
  }

  fromMaxDate(): Date {
    if (!this.dateTo) {
      return new Date();
    } else {
      return moment(this.dateTo).toDate();
    }
  }

  toMinDate(): Date {
    if (!this.dateFrom) {
      return null;
    } else {
      return moment(this.dateFrom).toDate();
    }
  }

  toMaxDate(): Date {
    return new Date();
  }

  onClear() {
    this.dateFrom = null;
    this.dateTo = null;
    this.panelOpenState = false;
    this.onApplyFilters();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  onApplyFilters() {
    let updates: any = {};
    if (this.dateFrom !== null) {
      updates[this.fromField] = moment(this.dateFrom).format(this.DATE_FORMAT);
    } else {
      updates[this.fromField] = null;
    }
    if (this.dateTo !== null) {
      updates[this.toField] = moment(this.dateTo).format(this.DATE_FORMAT);
    } else {
      updates[this.toField] = null;
    }

    this.searchCriteriaService.updatePartial(updates);
  }

}
