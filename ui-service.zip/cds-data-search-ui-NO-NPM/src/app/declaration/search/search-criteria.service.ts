import { Injectable } from '@angular/core';
import { SearchCriteria } from './search-criteria';
import { BehaviorSubject, Observable } from 'rxjs';
import { isMatch , omitBy, isNil } from 'lodash';

@Injectable()
export class SearchCriteriaService {

  private _currentCriteria: SearchCriteria = new SearchCriteria();
  private searchCriteriaSource = new BehaviorSubject(this._currentCriteria);
  private _searchCriteriaUpdates = this.searchCriteriaSource.asObservable();

  get searchCriteria(): Observable<any> {
    return this._searchCriteriaUpdates;
  }

  update(searchCriteria: SearchCriteria) {
    // First condition is used when user clicks the home link after search
    // Second condition is used for all other updates
    if (searchCriteria.isEmpty() || !isMatch(omitBy(this._currentCriteria,isNil), omitBy(searchCriteria,isNil))) {
      this._currentCriteria = searchCriteria;
      this.searchCriteriaSource.next(Object.assign(new SearchCriteria(), searchCriteria));
    }
  }

  updatePartial(toUpdate: any) {
    Object.assign(this._currentCriteria, toUpdate);
    this.searchCriteriaSource.next(Object.assign(new SearchCriteria(), this._currentCriteria));
  }

}


  
