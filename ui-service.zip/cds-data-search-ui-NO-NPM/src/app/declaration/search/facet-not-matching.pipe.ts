import { Pipe, PipeTransform } from '@angular/core';
import { SelectableFacet } from './search-filter/faceted-search/faceted-search.component';

@Pipe({
  name: 'facetNotMatching'
})
export class FacetNotMatchingPipe implements PipeTransform {
  static matching(facet: SelectableFacet, filter: string): boolean {
    return this.nullSafeFacetData(facet).startsWith(filter.toUpperCase());
  }

  transform(facet: SelectableFacet, filter: string): boolean {
    const isFiltered = filter != null && filter != '';
    return isFiltered && !FacetNotMatchingPipe.matching(facet, filter);
  }

  private static nullSafeFacetData(facet: SelectableFacet) : string {
    return facet.label == null ? '' : facet.label.toUpperCase();
  }
}
