import {ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {SearchCriteriaService} from '../search-criteria.service';
import {filter} from 'rxjs/operators'

@Component({
  selector: 'cds-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SearchFormComponent implements OnInit, OnDestroy {
  @ViewChild('searchInput') searchInput;
  searchTerm;
  private subscription;

  constructor(
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef,
    private searchCriteriaService: SearchCriteriaService) { }

  ngOnInit() {
    this.subscription = this.searchCriteriaService.searchCriteria.subscribe(
      data => {
        this.searchTerm = data.searchTerm;
        this.cdr.detectChanges();
      }
    );
    this.route.queryParams.pipe(
        filter(queryParams => !queryParams.hasOwnProperty('searchTerm'))
      )
      .subscribe(queryParams => this.focusDeclarationSearchField());
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  ngAfterViewInit() {
    this.focusDeclarationSearchField();
  }

  private focusDeclarationSearchField() {
    this.searchInput.nativeElement.focus();
    this.cdr.detectChanges();
  }

  onSubmitSearch() {
    if (this.searchTerm == null) {
      this.searchTerm = '';
    }
    this.searchCriteriaService.updatePartial({ searchTerm: this.searchTerm });
  }
}
