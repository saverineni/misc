import {ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit} from '@angular/core';
import {SearchCriteria} from '../search-criteria';
import {SearchService} from '../search.service';
import {DeclarationSearchResult} from '../declaration-search-result';
import {Subscription} from 'rxjs';
import {SearchCriteriaService} from '../search-criteria.service';
import {NavigationService} from '../navigation.service';
import {TrackBy} from '../../../track-by';

@Component({
  selector: 'cds-search-section',
  templateUrl: './search-section.component.html',
  styleUrls: ['./search-section.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SearchSectionComponent implements OnInit, OnDestroy {
  trackByDeclarationId = TrackBy.property('declarationId');

  result: DeclarationSearchResult = null;
  searchCriteriaSubscription: Subscription;
  searchCriteria: SearchCriteria;

  constructor(private searchService: SearchService,
     private searchCriteriaService: SearchCriteriaService,
     private navigationService: NavigationService,
     private changeDetectorRef: ChangeDetectorRef) { }

  ngOnInit() {
    this.searchCriteriaSubscription =
      this.searchCriteriaService.searchCriteria.subscribe(
        newSearchCriteria => {
          this.searchCriteria = newSearchCriteria;
          if (newSearchCriteria.isEmpty()) {
            this.result = undefined;
          } else {
            this.performSearch();
          }
        }
      );
    }

    private performSearch() {
      this.searchService.search(this.searchCriteria).subscribe(
        result => {
          this.result = result;
          this.changeDetectorRef.detectChanges();
        }
      );
  }

  ngOnDestroy() {
    this.searchCriteriaSubscription.unsubscribe();
  }
}
