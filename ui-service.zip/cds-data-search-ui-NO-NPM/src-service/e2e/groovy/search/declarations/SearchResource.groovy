package search.declarations

import org.apache.http.HttpResponse
import org.apache.http.client.fluent.Request
import org.apache.http.entity.ContentType
import org.apache.http.impl.client.BasicResponseHandler

import groovy.json.JsonSlurper

class SearchResource {
    static authToken = new search.Authenticator().authenticate()

    static HttpResponse unauthenticatedGet(params) {
        getDeclarationsWith(params, false)
    }

    static HttpResponse authenticatedGet(params) {
        getDeclarationsWith(params, true)
    }

    private static getDeclarationsWith(params, authenticated) {
        def queryString = params.collect { name, values ->
            values.collect { "${name}=${it}" }.join("&")
        }.join('&')
        if (queryString.length() > 0) {
            queryString = '?' + queryString
        }
        def uri = new URI("http://localhost:18000/declarations$queryString")
        def request = Request.Get(uri).addHeader("Accept", ContentType.APPLICATION_JSON.toString())
        if (authenticated) {
            request.addHeader("Authorization", "Bearer $authToken")
        }
        request.execute().returnResponse()
    }

    static Map asJsonMap(HttpResponse response) {
        def responseString = new BasicResponseHandler().handleResponse(response)
        new JsonSlurper().parseText(responseString)
    }

    static List asDeclarationIds(HttpResponse response) {
        asJsonMap(response).declarations.collect { declaration -> declaration.declarationId }
    }
}
