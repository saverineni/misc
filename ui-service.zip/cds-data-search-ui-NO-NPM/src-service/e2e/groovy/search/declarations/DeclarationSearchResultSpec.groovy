package search.declarations

import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

class DeclarationSearchResultSpec extends Specification {

	@Shared expectedDeclaration

	def setupSpec() {
		def index = new DeclarationsIndex()
		index.recreateAndPopulateIndex()
		expectedDeclaration = index.getApiFormatDeclaration('/declarations/2000000000000001.json')
	}

	def 'Response status should be OK'() {
	    when:
	    def response = SearchResource.authenticatedGet(['searchTerm': [expectedDeclaration.declarationId]])

	    then:
	    response.statusLine.statusCode == 200
	}
	
	def 'should not accept unknown parameters'() {
		when:
		def response = SearchResource.authenticatedGet(['unknown': [expectedDeclaration.declarationId]])

		then:
		response.statusLine.statusCode == 400
	}

	def 'unauthenticated request should give unauthorized'() {
        when:
        def response = SearchResource.unauthenticatedGet(['searchTerm': ['']])

		then:
		response.statusLine.statusCode == 401
	}

	def 'declaration without lines should be formatted correctly'() {
		when:
		def response = SearchResource.authenticatedGet(['searchTerm': ['2000000000000004']])
		def result = SearchResource.asJsonMap(response)

		then:
		result.declarations[0].lines == []
	}

    @Unroll
    def 'valid search term for #field gives the correct declaration response'(String searchTerm, String field) {
		given:
        def response = SearchResource.authenticatedGet(['searchTerm': [searchTerm]])
		def result = SearchResource.asJsonMap(response)

		expect:
		result.declarations == [ expectedDeclaration ]

        where:
        searchTerm                  | field
        '2000000000000001'          | 'declarationId'
        '219'                       | 'epuNumber'
        '249099x'                   | 'entryNumber'
        '976072558688'              | 'consigneeTurn'
        'Header%20NAD%20name'       | 'consigneeName'
        'HN4%200PC'                 | 'consigneePostcode'
        '582109443894367'           | 'consignorTurn'
        'Header%20Consignor%20name' | 'consignorName'
        'AB4%206CD'                 | 'consignorPostcode'
        '551030'                    | 'line.commodityCode'
        'PG'                        | 'line.originCountry.code'
        '4000C36'                   | 'line.cpc'
        '731411813911'              | 'line.itemConsigneeTurn'
        'Item%20NAD%20name'         | 'line.itemConsigneeName'
        'IN4%200PC'                 | 'line.itemConsigneePostcode'
        'item-consignor-turn'       | 'line.itemConsignorTurn'
        'item-consignor-name'       | 'line.itemConsignorName'
        'item-consignor-postcode'   | 'line.itemConsignorPostcode'
	}

    def 'first page of results should be returned for no search term'() {
        given:
        def response = SearchResource.authenticatedGet()
        def result = SearchResource.asJsonMap(response)

        expect:
        result.hits.total == 4
    }

    def 'first page of results should be returned for empty search term'() {
        given:
        def response = SearchResource.authenticatedGet(['searchTerm': ['']])
        def result = SearchResource.asJsonMap(response)

        expect:
        result.hits.total == 4
    }

    def 'no matching declarations returns an empty result'() {
        given: 'user signed in successfully'

        when:
        def response = SearchResource.authenticatedGet(['searchTerm': ['INVALID_DEC_ID']])

        then:
        response.statusLine.statusCode == 200
        SearchResource.asJsonMap(response) == [
            hits: [
                total: 0
            ],
            declarations: [],
			facets: [
				originCountries: [],
				dispatchCountries: []
			]
        ]
    }

	@Unroll
	def 'search for #params returns matching declarations'(params, expectedDeclarationIds) {
		given:
		def response = SearchResource.authenticatedGet(params)

		expect:
		response.statusLine.statusCode == 200
		SearchResource.asDeclarationIds(response).sort() == expectedDeclarationIds

		where:
		params 																| expectedDeclarationIds
		['originCountryCode': ['PG']]										| [ '2000000000000001' ]
		['originCountryCode': ['PI', 'PH']]							  		| [ '2000000000000003' ]
		['entryDateFrom': ['2018-01-03']]									| [ '2000000000000003', '2000000000000004' ]
		['entryDateTo': ['2018-01-02']]										| [ '2000000000000001', '2000000000000002' ]
		['entryDateFrom': ['2018-01-02'], 'entryDateTo': ['2018-01-03']]	| [ '2000000000000002', '2000000000000003' ]
		['entryDateFrom': ['2018-01-02'], 'entryDateTo': ['2018-01-02']]	| [ '2000000000000002' ]
		['searchTerm': ['220'], 'originCountryCode': ['PH'],
		 'entryDateFrom': ['2018-01-02'], 'entryDateTo': ['2018-01-02']]	| [ '2000000000000002' ]
		['dispatchCountryCode': ['dispatch-country-code2']] | [ '2000000000000002' ]
		['searchTerm': ['220'], 'dispatchCountryCode': ['dispatch-country-code2']] | [ '2000000000000002' ]
	}

	def 'origin country facets should be returned'() {
		given:
		def response = SearchResource.authenticatedGet(['searchTerm': ['']])
		def result = SearchResource.asJsonMap(response)

		expect:
		result.facets.originCountries.size == 3
	}

    def 'origin country facets should reflect the current search'() {
        given:
        def response = SearchResource.authenticatedGet(['searchTerm': ['PH']])
        def result = SearchResource.asJsonMap(response)

        expect:
        result.facets.originCountries == [
                [
                        country: [
                                code: "PH"
                        ],
                        count: 2
                ],
				[
						country: [
								code: "PI"
						],
						count: 1
				]
        ]
    }

	def 'dispatch country facets should be returned'() {
		given:
			def response = SearchResource.authenticatedGet(['searchTerm': ['']])
			def result = SearchResource.asJsonMap(response)

		expect:
			result.facets.dispatchCountries.size == 3
	}

	def 'dispatch country facets should reflect the current search'() {
		given:
			def response = SearchResource.authenticatedGet(['searchTerm': ['2000000000000003']])
			def result = SearchResource.asJsonMap(response)

		expect:
			result.facets.dispatchCountries == [
					[
							country: [
									code: "dispatch-country-code3"
							],
							count: 1
					]
			]
	}

	String getFileContent(String fileName) {
		new File(getClass().getResource(fileName).toURI()).text
	}
}
