package search.actuator.health

import org.apache.http.client.fluent.Request
import spock.lang.Specification

class HealthSpec extends Specification {


    def 'the health resource should be available'() {
        when:
        def response = Request.Get('http://localhost:18000/actuator/health').execute().returnResponse()

        then:
        response.statusLine.statusCode == 200
    }
}
