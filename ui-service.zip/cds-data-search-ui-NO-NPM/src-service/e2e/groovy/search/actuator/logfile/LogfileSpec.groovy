package search.actuator.logfile

import org.apache.http.client.fluent.Request
import spock.lang.Specification

class LogfileSpec extends Specification {


    def 'the logfile should be available'() {
        when:
        def response = Request.Get('http://localhost:18000/actuator/logfile').execute().returnResponse()

        then:
        response.statusLine.statusCode == 200
    }
}
