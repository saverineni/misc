# E2E Tests

## Docker Compose

The elastic search container needs the following to be run (at least in the development VM):
```
sudo sysctl -w vm.max_map_count=262144
```

## To debug tests from IDE
Build a latest application docker image
```
mvn clean install -Dmaven.test.skip=true -Pdev
```

Copy test resources to classpath
```
mvn test-compile
```

Start docker containers
```
docker-compose --file src/e2e/docker-compose.yml up -d --build
```