package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;

import java.util.List;

import static java.util.Collections.emptyList;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Declaration {
    private String declarationId;
    private String epuNumber;
    private String entryNumber;
    private String entryDate;
    private String route;
    private Country dispatchCountry;
    private Country destinationCountry;
    private String consigneeTurn;
    private String consignorTurn;
    private String goodsLocation;
    private String transportModeCode;
    private String consigneeName;
    private String consigneePostcode;
    private String consignorName;
    private String consignorPostcode;
    private List<DeclarationLine> lines;

    public List<DeclarationLine> getLines() {
        return lines == null ? emptyList() : lines;
    }

}
