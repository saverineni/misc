package uk.gov.gsi.hmrc.cds.search.api.dto.response.facets;

import lombok.Builder;
import lombok.Data;
import sun.rmi.transport.Transport;

import java.util.List;

@Data
@Builder
public class Facets {
    private List<CountryFacet> originCountries;
    private List<CountryFacet> dispatchCountries;
    private List<CountryFacet> destinationCountries;
    private List<TransportModeFacet> transportModes;
}
