package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import lombok.RequiredArgsConstructor;
import org.elasticsearch.action.search.SearchResponse;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Hits;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.Facets;

import java.util.stream.Stream;

import static java.util.stream.Collectors.toList;

@Component
@RequiredArgsConstructor
public class SearchResponseMapperService {

    private final ConversionService conversionService;
    
	public DeclarationSearchResult mapResponse(SearchResponse searchResponse) {
        return DeclarationSearchResult.builder()
                .declarations(Stream.of(searchResponse.getHits().getHits())
                        .map(searchHit -> conversionService.convert(searchHit, Declaration.class))
                        .collect(toList()))
                .hits(new Hits(searchResponse.getHits().getTotalHits()))
                .facets(conversionService.convert(searchResponse.getAggregations(), Facets.class))
                .build();
    }
}
