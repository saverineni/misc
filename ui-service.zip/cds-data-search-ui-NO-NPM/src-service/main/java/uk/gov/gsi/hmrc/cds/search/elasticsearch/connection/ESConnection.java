package uk.gov.gsi.hmrc.cds.search.elasticsearch.connection;

import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ESConnection {

    private String elasticSearchHost;
    private int elasticSearchPort;

    @Autowired
    public ESConnection(@Value("${elasticsearch.host}") String elasticSearchHost, @Value("${elasticsearch.port}") int elasticSearchPort) {
        this.elasticSearchHost = elasticSearchHost;
        this.elasticSearchPort = elasticSearchPort;
    }

    public RestHighLevelClient getRestClientInstance() {
        RestHighLevelClient client = new RestHighLevelClient(
                RestClient.builder(
                        new HttpHost(elasticSearchHost, elasticSearchPort))
        );
        return client;
    }
}
