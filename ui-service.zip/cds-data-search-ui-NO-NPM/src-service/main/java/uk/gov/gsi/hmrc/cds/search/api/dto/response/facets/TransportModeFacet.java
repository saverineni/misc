package uk.gov.gsi.hmrc.cds.search.api.dto.response.facets;

import lombok.Builder;
import lombok.Value;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.TransportMode;

@Value
@Builder
public class TransportModeFacet {
    TransportMode mode;
    long count;
}
