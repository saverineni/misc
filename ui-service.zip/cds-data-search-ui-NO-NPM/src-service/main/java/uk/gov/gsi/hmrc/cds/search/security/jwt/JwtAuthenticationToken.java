package uk.gov.gsi.hmrc.cds.search.security.jwt;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

public class JwtAuthenticationToken extends AbstractAuthenticationToken {

    private String jwtToken;
    private String principal;
    private Collection<? extends GrantedAuthority> authorities;

    public JwtAuthenticationToken(String token){
        super(null);
        this.jwtToken = token;
        this.setAuthenticated(false);
    }

    public JwtAuthenticationToken(String principal, Collection<? extends GrantedAuthority> authorities ) {
        super(authorities);
        this.principal = principal;
        this.authorities = authorities;
        this.setAuthenticated(true);
    }

    @Override
    public Object getCredentials() {
        return jwtToken;
    }

    @Override
    public Object getPrincipal() {
        return principal;
    }
}
