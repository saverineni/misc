package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import lombok.RequiredArgsConstructor;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.CountryFacet;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.Facet;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.Facets;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.TransportModeFacet;

import java.util.List;

import static java.util.stream.Collectors.toList;

@Component
@RequiredArgsConstructor
public class AggregationsToFacetsConverter implements Converter<Aggregations, Facets> {

    private final BucketToCountryFacetConverter countryConverter;
    private final BucketToTransportModeFacetConverter transportModeConverter;
    private final BucketToFacetConverter facetConverter;

    @Override
    public Facets convert(Aggregations aggregations) {
        List<CountryFacet> originCountryFacets = parseCountryFacets(aggregations, "originCountry");
        List<CountryFacet> dispatchCountryFacets = parseCountryFacets(aggregations, "dispatchCountry");
        List<CountryFacet> destinationCountryFacets = parseCountryFacets(aggregations, "destinationCountry");
        List<TransportModeFacet> transportModeFacets = parseTransportModeFacet(aggregations, "transportMode");

        List<Facet> originCountryFacets1 = parseFacets(aggregations, "originCountry");
        List<Facet> dispatchCountryFacets1 = parseFacets(aggregations, "dispatchCountry");
        List<Facet> destinationCountryFacets1 = parseFacets(aggregations, "destinationCountry");
        List<Facet> transportModeFacets1 = parseFacets(aggregations, "transportMode");
        List<Facet> goodsLocationFacets = parseFacets(aggregations, "goodsLocation");

        return Facets.builder()
                .originCountries(originCountryFacets)
                .dispatchCountries(dispatchCountryFacets)
                .destinationCountries(destinationCountryFacets)
                .transportModes(transportModeFacets)
                .originCountries1(originCountryFacets1)
                .dispatchCountries1(dispatchCountryFacets1)
                .destinationCountries1(destinationCountryFacets1)
                .transportModes1(transportModeFacets1)
                .goodsLocations(goodsLocationFacets)
                .build();
    }

    private List<TransportModeFacet> parseTransportModeFacet(Aggregations aggregations, String transportModeName) {
        Terms termsAggregation = aggregations.get(transportModeName);
        return termsAggregation.getBuckets().stream()
                .map(transportModeConverter::convert)
                .collect(toList());

    }

    private List<CountryFacet> parseCountryFacets(Aggregations aggregations, String countryFacetName) {
        Terms termsAggregation = aggregations.get(countryFacetName);
        return termsAggregation.getBuckets().stream()
                .map(countryConverter::convert)
                .collect(toList());

    }

    private List<Facet> parseFacets(Aggregations aggregations, String facetType) {
        Terms termsAggregation = aggregations.get(facetType);
        return termsAggregation.getBuckets().stream()
                .map(facetConverter::convert)
                .collect(toList());
    }
}
