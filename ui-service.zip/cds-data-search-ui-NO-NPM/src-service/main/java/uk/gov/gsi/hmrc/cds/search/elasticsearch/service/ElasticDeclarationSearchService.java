package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import lombok.RequiredArgsConstructor;
import org.elasticsearch.action.search.SearchResponse;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;


@Component
@RequiredArgsConstructor
public class ElasticDeclarationSearchService {

    private final SearchResponseMapperService searchResponseMapperService;

    private final SearchClient searchClient;

    public DeclarationSearchResult fetchDeclarationSearchResult(SearchCriteria searchCriteria) {
        SearchResponse searchResponse = searchClient.declarationSearch(searchCriteria);
        return searchResponseMapperService.mapResponse(searchResponse);
    }
}
