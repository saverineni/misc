package uk.gov.gsi.hmrc.cds.search.api.dto.response.facets;

import lombok.Builder;
import lombok.Data;
import lombok.Value;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;

@Value
@Builder
public class CountryFacet{
    Country country;
    long count;
}
