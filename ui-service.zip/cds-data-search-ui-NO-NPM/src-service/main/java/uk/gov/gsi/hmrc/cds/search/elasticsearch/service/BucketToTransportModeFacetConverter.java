package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.TransportMode;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.TransportModeFacet;

@Component
public class BucketToTransportModeFacetConverter implements Converter<Terms.Bucket, TransportModeFacet> {

    @Override
    public TransportModeFacet convert(Terms.Bucket bucket) {
        return TransportModeFacet.builder()
                .mode(TransportMode.builder().code(bucket.getKeyAsString()).build())
                .count(bucket.getDocCount())
                .build();
    }

}
