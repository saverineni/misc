package uk.gov.gsi.hmrc.cds.search.api.resources;

import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.ElasticDeclarationSearchService;

@RestController
@RequiredArgsConstructor
public class DeclarationResource {

    private final ElasticDeclarationSearchService elasticDeclarationSearchService;
    
    @InitBinder("searchCriteria")
    protected void initBinder(WebDataBinder binder) {
        binder.setAllowedFields("searchTerm", "originCountryCode", "entryDateFrom", "entryDateTo", "dispatchCountryCode");
    }

    @GetMapping(value = "/declarations")
    public DeclarationSearchResult getDeclarationSearchResult(SearchCriteria searchCriteria,
    		BindingResult errors) {
    	if (errors.getSuppressedFields().length > 0) {
    		throw new UnsupportedRequestParameterException(errors.getSuppressedFields());
    	}
    	
        return elasticDeclarationSearchService.fetchDeclarationSearchResult(searchCriteria);
    }
    
    @SuppressWarnings("serial")
	@ResponseStatus(code=HttpStatus.BAD_REQUEST)
    static class UnsupportedRequestParameterException extends RuntimeException {
		public UnsupportedRequestParameterException(String[] suppressedFields) {
			super("Unsupported request parameters: " + String.join(",", suppressedFields));
		}
    }
}
