package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import static org.elasticsearch.index.query.QueryBuilders.multiMatchQuery;
import static org.elasticsearch.index.query.QueryBuilders.rangeQuery;
import static org.elasticsearch.index.query.QueryBuilders.termQuery;
import static org.elasticsearch.search.aggregations.AggregationBuilders.terms;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.connection.ESConnection;

@Slf4j
@Service
public class SearchClient {

    private static final String[] SEARCH_FIELDS = {
            "declarationId",
            "epuNumber",
            "entryNumber",
            "consigneeTurn",
            "consigneeName",
            "consigneePostcode",
            "consignorTurn",
            "consignorName",
            "consignorPostcode",
            "lines.commodityCode",
            "lines.originCountry.code",
            "lines.cpc",
            "lines.itemConsigneeTurn",
            "lines.itemConsigneeName",
            "lines.itemConsigneePostcode",
            "lines.itemConsignorTurn",
            "lines.itemConsignorName",
            "lines.itemConsignorPostcode",
    };

    /**
     * This is necessary to ensure we retrieve all countries from the aggregation, if the total number of possible
     * countries exceeds this number there will be some entries missing from the resulting aggregation.
     */
    private static final int COUNTRY_CARDINALITY = 400;

    private static final DateTimeFormatter esDateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    private final ESConnection connection;

    private final String searchAlias;

    public SearchClient(ESConnection connection,
                        @Value("${elasticsearch.alias}") String searchAlias) {
        this.connection = connection;
        this.searchAlias = searchAlias;
    }

    public SearchResponse declarationSearch(SearchCriteria searchCriteria) {
        return searchES(getQueryBuilder(searchCriteria));
    }

    private QueryBuilder getQueryBuilder(SearchCriteria searchCriteria) {
        BoolQueryBuilder query = QueryBuilders.boolQuery().must(QueryBuilders.matchAllQuery());
        BoolQueryBuilder queryWithSearchTerm = buildSearchTermQuery(query, searchCriteria);
        BoolQueryBuilder queryWithOriginCountryFacets = buildOriginCountryQuery(queryWithSearchTerm, searchCriteria);
        BoolQueryBuilder queryWithDispatchCountryFacets = buildDispatchCountryQuery(queryWithOriginCountryFacets, searchCriteria);
        return buildEntryDateQuery(queryWithDispatchCountryFacets, searchCriteria);
    }

    private BoolQueryBuilder buildSearchTermQuery(BoolQueryBuilder query, SearchCriteria searchCriteria) {
        return searchCriteria.optionalSearchTerm()
                .map(it -> query.must(multiMatchQuery(it, SEARCH_FIELDS)))
                .orElse(query);
    }

    private BoolQueryBuilder buildOriginCountryQuery(BoolQueryBuilder queryWithSearchTerm, SearchCriteria searchCriteria) {
        return searchCriteria.getOriginCountryCode().stream().map(countryCode ->
                queryWithSearchTerm.must(QueryBuilders.boolQuery().should(termQuery("lines.originCountry.code", countryCode)))
        ).reduce((first, second) -> second).orElse(queryWithSearchTerm);
    }

    private BoolQueryBuilder buildDispatchCountryQuery(BoolQueryBuilder queryWithOriginCountryFacets, SearchCriteria searchCriteria) {
        return searchCriteria.getDispatchCountryCode().stream().map(countryCode ->
                queryWithOriginCountryFacets.must(termQuery("lines.itemDispatchCountry.code", countryCode)
        )).reduce((first, second) -> second).orElse(queryWithOriginCountryFacets);
    }

    private QueryBuilder buildEntryDateQuery(BoolQueryBuilder queryWithDispatchCountryFacets, SearchCriteria searchCriteria) {
        Optional<LocalDateTime> from = searchCriteria.optionalEntryDateTimeFrom();
        Optional<LocalDateTime> to = searchCriteria.optionalEntryDateTimeTo();

        if (from.isPresent() || to.isPresent()) {
            RangeQueryBuilder rangeQuery = rangeQuery("entryDate");
            RangeQueryBuilder rangeWithFrom = from.map(dateTime ->
                    rangeQuery.gte(dateTime.format(esDateTimeFormatter))
            ).orElse(rangeQuery);
            RangeQueryBuilder rangeWithTo = to.map(dateTime ->
                    rangeWithFrom.lte(dateTime.format(esDateTimeFormatter))
            ).orElse(rangeWithFrom);
            return queryWithDispatchCountryFacets.must(rangeWithTo);
        } else {
            return queryWithDispatchCountryFacets;
        }
    }

    private SearchResponse searchES(QueryBuilder queryBuilder) {
        try (RestHighLevelClient client = connection.getRestClientInstance()) {

            SearchRequest searchRequest = new SearchRequest(searchAlias);
            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(queryBuilder);
            searchSourceBuilder
                    .aggregation(
                            terms("originCountry").field("lines.originCountry.code").size(COUNTRY_CARDINALITY)
                    )
                    .aggregation(
                            terms("dispatchCountry").field("lines.itemDispatchCountry.code").size(COUNTRY_CARDINALITY)
                    );
            searchRequest.source(searchSourceBuilder);
            return client.search(searchRequest);
        } catch (IOException e) {
            log.error(String.format("Exception occurred: %s", e));
            throw new RuntimeException(e.getMessage());
        }
    }
}
