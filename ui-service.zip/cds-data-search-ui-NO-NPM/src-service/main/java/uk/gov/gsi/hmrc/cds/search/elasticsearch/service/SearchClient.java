package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.connection.ESConnection;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.stream.Stream;

import static org.elasticsearch.index.query.QueryBuilders.multiMatchQuery;
import static org.elasticsearch.index.query.QueryBuilders.rangeQuery;
import static org.elasticsearch.search.aggregations.AggregationBuilders.terms;

@Slf4j
@Service
public class SearchClient {

    private static final String LINES_ORIGIN_COUNTRY_CODE = "lines.originCountry.code";
    private static final String DISPATCH_COUNTRY_CODE = "dispatchCountry.code";
    private static final String DESTINATION_COUNTRY_CODE = "destinationCountry.code";
    private static final String TRANSPORT_MODE_CODE = "transportModeCode";
    private static final String GOODS_LOCATION = "goodsLocation";

    private static final String[] SEARCH_FIELDS = {
            "declarationId",
            "epuNumber",
            "entryNumber",
            "consigneeTurn",
            "consigneeName",
            "consigneePostcode",
            "consignorTurn",
            "consignorName",
            "consignorPostcode",
            "lines.commodityCode",
            LINES_ORIGIN_COUNTRY_CODE,
            "lines.cpc",
            "lines.itemConsigneeTurn",
            "lines.itemConsigneeName",
            "lines.itemConsigneePostcode",
            "lines.itemConsignorTurn",
            "lines.itemConsignorName",
            "lines.itemConsignorPostcode",
    };

    /**
     * This is necessary to ensure we retrieve all countries from the aggregation, if the total number of possible
     * countries exceeds this number there will be some entries missing from the resulting aggregation.
     */
    private static final int COUNTRY_CARDINALITY = 400;

    private static final int TRANSPORT_MODE_CARDINALITY = 10;

    private static final int GOODS_LOCATION_CARDINALITY = 400;

    private static final DateTimeFormatter esDateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    private final ESConnection connection;

    private final String searchAlias;

    private final int defaultPageSize;

    public SearchClient(ESConnection connection,
                        @Value("${elasticsearch.alias}") String searchAlias,
                        @Value("${elasticsearch.page-size.default}") int defaultPageSize) {
        this.connection = connection;
        this.searchAlias = searchAlias;
        this.defaultPageSize = defaultPageSize;
    }

    public SearchResponse declarationSearch(SearchCriteria searchCriteria) {
        return searchES(getQueryBuilder(searchCriteria), searchCriteria.pageSize(defaultPageSize));
    }

    private QueryBuilder getQueryBuilder(SearchCriteria searchCriteria) {
        BoolQueryBuilder query = QueryBuilders.boolQuery().must(QueryBuilders.matchAllQuery());
        buildSearchTermQuery(query, searchCriteria);
        buildFacets(searchCriteria, query);
        return buildEntryDateQuery(query, searchCriteria);
    }

    private void buildFacets(SearchCriteria searchCriteria, BoolQueryBuilder query) {
        buildQueryFacets(query, searchCriteria.getOriginCountryCode().stream(), LINES_ORIGIN_COUNTRY_CODE);
        buildQueryFacets(query, searchCriteria.getDispatchCountryCode().stream(), DISPATCH_COUNTRY_CODE);
        buildQueryFacets(query, searchCriteria.getDestinationCountryCode().stream(), DESTINATION_COUNTRY_CODE);
        buildQueryFacets(query, searchCriteria.getTransportModeCode().stream(), TRANSPORT_MODE_CODE);
    }

    private BoolQueryBuilder buildSearchTermQuery(BoolQueryBuilder query, SearchCriteria searchCriteria) {
        return searchCriteria.optionalSearchTerm()
                .map(it -> query.must(multiMatchQuery(it, SEARCH_FIELDS)))
                .orElse(query);
    }

    private BoolQueryBuilder buildQueryFacets(BoolQueryBuilder query, Stream<String> stream, String facetType) {
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
        return stream.map(facetId -> shouldArray(queryBuilder, facetId, facetType)
        ).reduce(query, BoolQueryBuilder::must);
    }

    private BoolQueryBuilder shouldArray(BoolQueryBuilder query, String value, String term) {
        return query.should(QueryBuilders.termQuery(term, value));
    }

    private QueryBuilder buildEntryDateQuery(BoolQueryBuilder query, SearchCriteria searchCriteria) {
        Optional<LocalDateTime> from = searchCriteria.optionalEntryDateTimeFrom();
        Optional<LocalDateTime> to = searchCriteria.optionalEntryDateTimeTo();

        if (from.isPresent() || to.isPresent()) {
            RangeQueryBuilder rangeQuery = rangeQuery("entryDate");
            RangeQueryBuilder rangeWithFrom = from.map(dateTime ->
                    rangeQuery.gte(dateTime.format(esDateTimeFormatter))
            ).orElse(rangeQuery);
            RangeQueryBuilder rangeWithTo = to.map(dateTime ->
                    rangeWithFrom.lte(dateTime.format(esDateTimeFormatter))
            ).orElse(rangeWithFrom);
            return query.must(rangeWithTo);
        } else {
            return query;
        }
    }

    private SearchResponse searchES(QueryBuilder queryBuilder, int pageSize) {
        try (RestHighLevelClient client = connection.getRestClientInstance()) {

            SearchRequest searchRequest = new SearchRequest(searchAlias);
            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(queryBuilder).size(pageSize);
            searchSourceBuilder
                    .aggregation(
                            terms("originCountry").field(LINES_ORIGIN_COUNTRY_CODE).size(COUNTRY_CARDINALITY)
                    )
                    .aggregation(
                            terms("dispatchCountry").field(DISPATCH_COUNTRY_CODE).size(COUNTRY_CARDINALITY)
                    )
                    .aggregation(
                            terms("destinationCountry").field(DESTINATION_COUNTRY_CODE).size(COUNTRY_CARDINALITY)
                    )
                    .aggregation(
                            terms("transportMode").field(TRANSPORT_MODE_CODE).size(TRANSPORT_MODE_CARDINALITY)
                    )
                    .aggregation(
                            terms("goodsLocations").field(GOODS_LOCATION).size(GOODS_LOCATION_CARDINALITY)
                    );
            searchRequest.source(searchSourceBuilder);
            return client.search(searchRequest);
        } catch (IOException e) {
            log.error(String.format("Exception occurred: %s", e));
            throw new RuntimeException(e.getMessage());
        }
    }
}
