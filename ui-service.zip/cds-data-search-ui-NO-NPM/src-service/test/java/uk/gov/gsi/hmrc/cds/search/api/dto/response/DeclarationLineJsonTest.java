package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.*;

@RunWith(SpringRunner.class)
@JsonTest
public class DeclarationLineJsonTest {

    @Autowired
    private JacksonTester<DeclarationLine> json;

    @Test
    public void deserializeEmptyDeclarationLine() throws Exception {
        String content = "{}";

        assertThat(this.json.parse(content))
                .isEqualTo(DeclarationLine.builder().build());
    }

}