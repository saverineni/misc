package uk.gov.gsi.hmrc.cds.search.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;

import static org.junit.Assert.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class JsonResponseAuthenticationFailureHandlerTest {

    public static final BadCredentialsException EXCEPTION = new BadCredentialsException("auth failed");
    @Mock
    private HttpServletResponse response;

    @Mock
    private PrintWriter writer;

    private ObjectMapper mapper = new ObjectMapper();

    private JsonResponseAuthenticationFailureHandler handler = new JsonResponseAuthenticationFailureHandler(mapper);

    @Before
    public void setup() throws Exception {
        handler = new JsonResponseAuthenticationFailureHandler(mapper);
        when(response.getWriter()).thenReturn(writer);
    }

    @Test
    public void onAuthenticationFailureSetsResponseStatusAsUnauthorised() throws Exception {
        handler.onAuthenticationFailure(null, response, EXCEPTION);

        verify(response).setStatus(401);
    }

    @Test
    public void onAuthenticationFailureWritesJsonResponse() throws Exception {
        handler.onAuthenticationFailure(null, response, EXCEPTION);

        verify(writer).write("{\"message\":\"auth failed\"}");
        verify(response).setContentType("application/json");
        verify(response).setCharacterEncoding("UTF-8");
    }

    @Test
    public void onAuthenticationFailureHandlesQuotesInResponse() throws Exception {
        handler.onAuthenticationFailure(null, response, new BadCredentialsException("\"quoted\" message"));

        verify(writer).write("{\"message\":\"\\\"quoted\\\" message\"}");
    }
}