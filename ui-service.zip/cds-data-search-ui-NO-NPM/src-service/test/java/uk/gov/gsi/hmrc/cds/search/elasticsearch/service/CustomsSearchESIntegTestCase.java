package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicHeader;
import org.elasticsearch.client.RestHighLevelClient;
import org.junit.After;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.connection.ESConnection;
import uk.gov.gsi.hmrc.cds.search.utils.TestHelper;

import static java.lang.String.format;
import static java.util.Collections.emptyMap;
import static org.apache.http.entity.ContentType.APPLICATION_JSON;
import static uk.gov.gsi.hmrc.cds.search.utils.TestHelper.SEARCH_MAPPINGS_FILE;

public abstract class CustomsSearchESIntegTestCase {

    private final static BasicHeader CONTENT_TYPE_HEADER =
            new BasicHeader("Content-Type", APPLICATION_JSON.toString());

    static final String DECLARATION_TYPE = "declaration";

    static final String ES_HOST = "localhost";

    static final int ES_PORT = 19200;

    RestHighLevelClient client;

    public void setUp() throws Exception {
        ESConnection connection = new ESConnection(ES_HOST, ES_PORT);
        this.client = connection.getRestClientInstance();
    }

    void createIndex(String indexName) throws Exception {
        try {
            client.getLowLevelClient().performRequest("DELETE", indexName);
        } catch (Exception e) {
            e.printStackTrace();
            // expect index not to be there most of the time
        }
        client.getLowLevelClient()
                .performRequest(
                        "PUT",
                        indexName,
                        emptyMap(),
                        new StringEntity(TestHelper.getFileContent(SEARCH_MAPPINGS_FILE)),
                        CONTENT_TYPE_HEADER);
    }

    void refresh(String indexName) throws Exception {
        client.getLowLevelClient().performRequest("POST", format("/%s/_refresh", indexName), CONTENT_TYPE_HEADER);
    }

    @After
    public void cleanUp() throws Exception {
        this.client.close();
    }

}
