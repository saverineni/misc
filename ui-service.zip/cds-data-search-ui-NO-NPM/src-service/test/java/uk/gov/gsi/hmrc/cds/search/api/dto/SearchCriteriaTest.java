package uk.gov.gsi.hmrc.cds.search.api.dto;

import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Optional;

import org.hamcrest.Matchers;
import org.junit.Test;

public class SearchCriteriaTest {

    private SearchCriteria criteria = new SearchCriteria();

    @Test
    public void optionalSearchTermShouldGiveNoneWhenSearchTermEmpty() {
        criteria.setSearchTerm(" ");
        assertThat(criteria.optionalSearchTerm(), is(Optional.empty()));
    }

    @Test
    public void optionalSearchTermShouldGiveSomeSearchTermWhenPresent() {
        criteria.setSearchTerm("a-term");
        assertThat(criteria.optionalSearchTerm(), is(Optional.of("a-term")));
    }

    @Test
    public void optionalSearchTermShouldGiveNoneWhenSearchTermNull() {
        assertThat(criteria.optionalSearchTerm(), is(Optional.empty()));
    }

    @Test
    public void optionalSearchTermShouldGiveSomeTrimmedSearchTermWhenPresent() {
        criteria.setSearchTerm("  a-term  ");
        assertThat(criteria.optionalSearchTerm(), is(Optional.of("a-term")));
    }

    @Test
    public void getOriginCountryCodeShouldGiveEmptyListIfNull() {
        criteria.setOriginCountryCode(null);
        assertThat(criteria.getOriginCountryCode(), is(empty()));
    }

    @Test
    public void getOriginCountryCodeShouldGiveListOfOneEmptyStringIfEmpty() {
        criteria.setOriginCountryCode(emptyList());
        assertThat(criteria.getOriginCountryCode(), contains(""));
    }

    @Test
    public void getOriginCountryCodeShouldGiveFieldIfNotEmpty() {
        criteria.setOriginCountryCode(singletonList("code"));
        assertThat(criteria.getOriginCountryCode(), contains("code"));
    }

    @Test
    public void optionalEntryDateTimeFromShouldGiveNoneWhenEntryDateFromIsNull() {
        criteria.setEntryDateFrom(null);
        assertThat(criteria.optionalEntryDateTimeFrom(), is(Optional.empty()));
    }

    @Test
    public void optionalEntryDateTimeToShouldGiveNoneWhenEntryDateToIsNull() {
        criteria.setEntryDateTo(null);
        assertThat(criteria.optionalEntryDateTimeTo(), is(Optional.empty()));
    }

    @Test
    public void optionalEntryDateTimeFromShouldGiveEntryDateWithTimeWhenPresent() {
        criteria.setEntryDateFrom(LocalDate.of(2018, 1, 1));
        assertThat(criteria.optionalEntryDateTimeFrom(), is(Optional.of(LocalDateTime.of(2018, 1, 1, 0, 0, 0, 0))));
    }

    @Test
    public void optionalEntryDateTimeToShouldGiveEntryDateWithTimeWhenPresent() {
        criteria.setEntryDateTo(LocalDate.of(2018, 1, 1));
        assertThat(criteria.optionalEntryDateTimeTo(), is(Optional.of(LocalDateTime.of(2018, 1, 1, 23, 59, 59, 999_999_999))));
    }

}
