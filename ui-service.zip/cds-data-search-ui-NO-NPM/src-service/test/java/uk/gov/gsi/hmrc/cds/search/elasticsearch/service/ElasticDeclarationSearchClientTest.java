package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.action.search.SearchResponse;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.ElasticDeclarationSearchService;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchResponseMapperService;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchClient;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ElasticDeclarationSearchClientTest {


    private static final SearchCriteria SEARCH_TERM = new SearchCriteria();
    static {
        SEARCH_TERM.setSearchTerm("SEARCH_TERM");
    }

    @Mock
    private SearchResponseMapperService searchResponseMapperService;

    @Mock
    private SearchClient searchClient;

    @Mock
    private SearchResponse searchResponse;

    private DeclarationSearchResult declarationSearchResult = DeclarationSearchResult.builder().build();

    @InjectMocks
    private ElasticDeclarationSearchService elasticDeclarationSearchService;

    private Declaration declaration = Declaration.builder().build();

    @Before
    public void setup() {
        when(searchClient.declarationSearch(SEARCH_TERM)).thenReturn(searchResponse);
        when(searchResponseMapperService.mapResponse(searchResponse)).thenReturn(declarationSearchResult);
    }

    @Test
    public void returnsDeclarationSearchResult() {
        DeclarationSearchResult actual = elasticDeclarationSearchService.fetchDeclarationSearchResult(SEARCH_TERM);
        assertThat(actual, is(declarationSearchResult));
    }

}