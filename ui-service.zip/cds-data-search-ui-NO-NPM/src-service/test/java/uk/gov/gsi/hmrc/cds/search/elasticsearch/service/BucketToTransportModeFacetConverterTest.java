package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.TransportModeFacet;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

public class BucketToTransportModeFacetConverterTest {

    @Mock
    private Terms.Bucket bucket;

    private BucketToTransportModeFacetConverter converter = new BucketToTransportModeFacetConverter();

    @Before
    public void setUp() {
        initMocks(this);
        when(bucket.getKeyAsString()).thenReturn("01");
        when(bucket.getDocCount()).thenReturn(3L);
    }

    @Test
    public void convertsCountryCode() {
        TransportModeFacet actual = converter.convert(bucket);
        assertThat(actual.getMode().getCode(), is("01"));
    }

    @Test
    public void convertsCount() {
        TransportModeFacet actual = converter.convert(bucket);
        assertThat(actual.getCount(), is(3L));
    }

    @Test
    public void convertsBlankCountry() {
        when(bucket.getKeyAsString()).thenReturn("");
        TransportModeFacet actual = converter.convert(bucket);
        assertThat(actual.getMode().getCode(), is(""));
    }
}
