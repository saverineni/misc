package uk.gov.gsi.hmrc.cds.search.api.resources;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Hits;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.ElasticDeclarationSearchService;

import java.time.LocalDate;
import java.util.List;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.*;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@WebMvcTest(value = DeclarationResource.class, secure = false)
@ActiveProfiles("test")
public class DeclarationResourceIntegrationTest {

    private static final String EPU_NUMBER = "EPU_NUMBER";
    private static final String DECLARATION_ID_1 = "DECLARATION_ID_1";
    private static final String DECLARATION_ID_2 = "DECLARATION_ID_2";

    @MockBean
    private ElasticDeclarationSearchService elasticDeclarationSearchService;

    @Autowired
    private MockMvc mockMvc;

    private ResultActions resultActions;

    @Test
    public void searchForMultipleDeclarationsWithResponseTypeObject() throws Exception {
        givenDeclarationSearchResult(asList(getDeclarationResponse(DECLARATION_ID_1), getDeclarationResponse(DECLARATION_ID_2)));
        whenISearchForDeclarationSearchResult(EPU_NUMBER);
        thenTheDeclarationSearchResponseIsAppropriate(2, DECLARATION_ID_1, EPU_NUMBER);
    }

    @Test
    public void searchWithAnEmptySearchTermOk() throws Exception {
        whenISearchForDeclarationSearchResult("");
        resultActions.andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setSearchTerm("");
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithNoParametersOk() throws Exception {
        resultActions = this.mockMvc
                .perform(buildGetRequest());
        resultActions.andExpect(status().isOk());
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(new SearchCriteria());
    }

    @Test
    public void searchWithAllParametersOk() throws Exception {
        this.mockMvc.perform(buildGetRequest()
                .param("searchTerm", "term")
                .param("originCountryCode", "GB")
                .param("dispatchCountryCode", "GB")
                .param("destinationCountryCode", "GB")
                .param("entryDateFrom", "2018-01-01")
                .param("entryDateTo", "2018-12-31"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setSearchTerm("term");
        searchCriteria.setOriginCountryCode(asList("GB"));
        searchCriteria.setDispatchCountryCode(asList("GB"));
        searchCriteria.setDestinationCountryCode(asList("GB"));
        searchCriteria.setEntryDateFrom(LocalDate.of(2018, 1, 1));
        searchCriteria.setEntryDateTo(LocalDate.of(2018, 12, 31));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithAnOriginCountryCodeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("originCountryCode", "GB"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setOriginCountryCode(asList("GB"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithMultipleOriginCountryCodesOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest()
                        .param("originCountryCode", "")
                        .param("originCountryCode", "GB")
                        .param("originCountryCode", "FR")
                        )
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setOriginCountryCode(asList("", "GB", "FR"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithEmptyOriginCountryCodeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("originCountryCode", ""))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setOriginCountryCode(asList(""));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithADispatchCountryCodeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("dispatchCountryCode", "GB"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDispatchCountryCode(asList("GB"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithMultipleDispatchCountryCodesOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest()
                        .param("dispatchCountryCode", "")
                        .param("dispatchCountryCode", "GB")
                        .param("dispatchCountryCode", "FR")
                )
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDispatchCountryCode(asList("", "GB", "FR"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithEmptyDispatchCountryCodeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("dispatchCountryCode", ""))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDispatchCountryCode(asList(""));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithADestinationCountryCodeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("destinationCountryCode", "GB"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDestinationCountryCode(asList("GB"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithMultipleDestinationCountryCodesOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest()
                        .param("destinationCountryCode", "")
                        .param("destinationCountryCode", "GB")
                        .param("destinationCountryCode", "FR")
                )
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDestinationCountryCode(asList("", "GB", "FR"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithEmptyDestinationCountryCodeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("destinationCountryCode", ""))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDestinationCountryCode(asList(""));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithATransportModeCodeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("transportModeCode", "01"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setTransportModeCode(asList("01"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithMultipleTransportModeCodesOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest()
                        .param("transportModeCode", "")
                        .param("transportModeCode", "01")
                        .param("transportModeCode", "02")
                )
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setTransportModeCode(asList("", "01", "02"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithEmptyTransportModeCodeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("transportModeCode", ""))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setTransportModeCode(asList(""));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithAnEntryDateFromOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("entryDateFrom", "2018-01-01"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setEntryDateFrom(LocalDate.of(2018, 1, 1));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithAnEntryDateToOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("entryDateTo", "2018-12-31"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setEntryDateTo(LocalDate.of(2018, 12, 31));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchForZeroResults() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("pageSize", "0"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setPageSize(0);
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithUnrecognisedParameter() throws Exception {
    	resultActions = this.mockMvc
    			.perform(get("/declarations")
    					.param("unrecognised", "true")
    					.accept(APPLICATION_JSON));
    	resultActions.andExpect(status().isBadRequest());
    	verifyZeroInteractions(elasticDeclarationSearchService);
    }
    
    @Test
    public void noMatchingDeclarations() throws Exception {
        givenDeclarationSearchResult(emptyList());
        whenISearchForDeclarationSearchResult(EPU_NUMBER);
        resultActions
                .andExpect(status().isOk())
                .andExpect(content().json("{ \"hits\": {\"total\": 0 },\"declarations\": []}"));
    }

    private void thenTheDeclarationSearchResponseIsAppropriate(int size, String entryReference, String epuNumber) throws Exception {
        resultActions
                .andExpect(jsonPath("$.declarations", hasSize(size)))
                .andExpect(jsonPath("$.declarations[0].declarationId", is(entryReference)))
                .andExpect(jsonPath("$.declarations[0].epuNumber", is(epuNumber)))
                .andExpect(jsonPath("$.declarations[1].declarationId", is(DECLARATION_ID_2)))
                .andExpect(jsonPath("$.declarations[1].epuNumber", is(EPU_NUMBER)))
                .andExpect(jsonPath("$.hits.total", is(size)));
    }

    private void whenISearchForDeclarationSearchResult(String searchTerm) throws Exception {
        resultActions = this.mockMvc
                .perform(buildGetRequest()
                        .param("searchTerm", searchTerm)
                );
    }

    private MockHttpServletRequestBuilder buildGetRequest() {
        return get("/declarations")
                .accept(APPLICATION_JSON);
    }

    private void givenDeclarationSearchResult(List<Declaration> declarationResponses) {
        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setSearchTerm(EPU_NUMBER);
        when(elasticDeclarationSearchService.fetchDeclarationSearchResult(searchCriteria)).thenReturn(
                DeclarationSearchResult.builder()
                        .hits(new Hits(declarationResponses.size()))
                        .declarations(declarationResponses)
                        .build()
        );
    }

    private Declaration getDeclarationResponse(String declarationId) {
        return Declaration.builder()
                .declarationId(declarationId)
                .epuNumber(EPU_NUMBER)
                .build();
    }


}
