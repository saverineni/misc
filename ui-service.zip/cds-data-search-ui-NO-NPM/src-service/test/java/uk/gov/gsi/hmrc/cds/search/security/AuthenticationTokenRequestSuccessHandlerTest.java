package uk.gov.gsi.hmrc.cds.search.security;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.security.core.Authentication;
import uk.gov.gsi.hmrc.cds.search.security.AuthenticationTokenRequestSuccessHandler;
import uk.gov.gsi.hmrc.cds.search.security.jwt.JwtTokenService;

import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

public class AuthenticationTokenRequestSuccessHandlerTest {
    private static final String TOKEN = "TEST#TOKEN";
    private ObjectMapper objectMapper = new ObjectMapper();
    private PrintWriter printWriter = Mockito.mock(PrintWriter.class);

    private JwtTokenService tokenGenerator = Mockito.mock(JwtTokenService.class);
    private AuthenticationTokenRequestSuccessHandler handler = new AuthenticationTokenRequestSuccessHandler(objectMapper, tokenGenerator);
    private Authentication authentication = Mockito.mock(Authentication.class);
    private HttpServletResponse response = Mockito.mock(HttpServletResponse.class);

    @Before
    public void setUp() throws IOException {
        Mockito.when(response.getWriter()).thenReturn(printWriter);
    }

    @Test
    public void shouldSetAnOkStatusToTheResponse() throws Exception {
        handler.onAuthenticationSuccess(null, response, authentication);
        Mockito.verify(response).setStatus(200);
    }

    @Test
    public void shouldSetResponseContentType() throws Exception {
        handler.onAuthenticationSuccess(null, response, authentication);
        Mockito.verify(response).setContentType("application/json");
    }

    @Test
    public void shouldSetTheResponseBodyJsonContainingTheJwtToken() throws IOException {
        Mockito.when(tokenGenerator.createToken(authentication)).thenReturn(TOKEN);

        handler.onAuthenticationSuccess(null, response, authentication);

        Mockito.verify(printWriter).write(expectedResponseContent());
    }

    private String expectedResponseContent() throws JsonProcessingException {
        Map<String, String> responseData = new HashMap<>();
        responseData.put("token", TOKEN);
        return objectMapper.writeValueAsString(responseData);
    }

    @Test
    public void shouldCommitTheResponse() throws IOException {
        handler.onAuthenticationSuccess(null, response, authentication);
        Mockito.verify(printWriter).flush();
    }
}