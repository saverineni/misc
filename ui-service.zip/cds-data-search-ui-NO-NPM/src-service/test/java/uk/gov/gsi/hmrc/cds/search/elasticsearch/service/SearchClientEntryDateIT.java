package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.junit.Before;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.connection.ESConnection;

import java.time.LocalDate;
import java.util.Arrays;

import static java.util.Collections.emptyList;
import static org.elasticsearch.common.xcontent.XContentType.JSON;
import static org.junit.Assert.assertEquals;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchHitMatchers.declarationId;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchResponseAssert.assertSearchHits;

public class SearchClientEntryDateIT extends CustomsSearchESIntegTestCase {

    private static final String CUSTOMS_INDEX = "SearchServiceEntryDateIntegrationTest".toLowerCase();
    private static final String EPU = "EPU";

    private SearchClient service;

    private ObjectMapper objectMapper = new ObjectMapper();

    @Before
    public void setUp() throws Exception {
        super.setUp();
        this.service = new SearchClient(new ESConnection(ES_HOST, ES_PORT), CUSTOMS_INDEX, 10);
        createCustomsIndexWithDocuments();
    }

    @Test
    public void searchWithEntryDateFrom() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(
                LocalDate.of(2018, 1, 3), null
        ));
        assertSearchHits(searchResponse,
                declarationId("dec-id-3"),
                declarationId("dec-id-4"));
    }

    @Test
    public void searchWithEntryDateTo() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(
                null, LocalDate.of(2018, 1, 2)
        ));

        assertSearchHits(searchResponse,
                declarationId("dec-id-1"),
                declarationId("dec-id-2"));
    }

    @Test
    public void searchWithEntryDateFromAndTo() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(
                LocalDate.of(2018, 1, 2),
                LocalDate.of(2018, 1, 3)
        ));

        assertSearchHits(searchResponse,
                declarationId("dec-id-2"),
                declarationId("dec-id-3"));
    }

    @Test
    public void searchWithEntryDateWithFromAfterTo() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(
                LocalDate.of(2018, 1, 4),
                LocalDate.of(2018, 1, 3)
        ));

        assertEquals(searchResponse.getHits().totalHits, 0);
    }

    @Test
    public void searchWithEntryDateWithSearchTerm() {
        SearchCriteria searchCriteria = newSearchCriteria(
                LocalDate.of(2018, 1, 2),
                LocalDate.of(2018, 1, 2)
        );
        searchCriteria.setSearchTerm(EPU);
        SearchResponse searchResponse = this.service.declarationSearch(searchCriteria);

        assertSearchHits(searchResponse,
                declarationId("dec-id-2"));
    }

    @Test
    public void searchWithoutEntryDates() {
        SearchCriteria searchCriteria = newSearchCriteria(null, null);
        SearchResponse searchResponse = this.service.declarationSearch(searchCriteria);

        assertSearchHits(searchResponse,
                declarationId("dec-id-1"),
                declarationId("dec-id-2"),
                declarationId("dec-id-3"),
                declarationId("dec-id-4"),
                declarationId("dec-id-5"));
    }

    private SearchCriteria newSearchCriteria(LocalDate entryDateFrom, LocalDate entryDateTo) {
        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setEntryDateFrom(entryDateFrom);
        searchCriteria.setEntryDateTo(entryDateTo);
        return searchCriteria;
    }

    private void createCustomsIndexWithDocuments() throws Exception {
        createIndex(CUSTOMS_INDEX);

        BulkRequest request = new BulkRequest();
        addDeclaration(request, newDeclaration("dec-id-1", "2018-01-01 00:00:00.000"));
        addDeclaration(request, newDeclaration("dec-id-2", "2018-01-02 00:00:00.000"));
        addDeclaration(request, newDeclaration("dec-id-3", "2018-01-03 00:00:00.000"));
        addDeclaration(request, newDeclaration("dec-id-4", "2018-01-04 00:00:00.000"));
        addDeclaration(request, newDeclaration("dec-id-5", null));

        client.bulk(request);

        refresh(CUSTOMS_INDEX);
    }

    private void addDeclaration(BulkRequest request, Declaration declaration) throws JsonProcessingException {
        request.add(new IndexRequest(CUSTOMS_INDEX, DECLARATION_TYPE, declaration.getDeclarationId())
                .source(objectMapper.writer().writeValueAsString(declaration), JSON));
    }


    private Declaration newDeclaration(String id, String entryDate) {
        return Declaration.builder()
                .declarationId(id)
                .epuNumber(EPU)
                .entryDate(entryDate)
                .build();
    }

}
