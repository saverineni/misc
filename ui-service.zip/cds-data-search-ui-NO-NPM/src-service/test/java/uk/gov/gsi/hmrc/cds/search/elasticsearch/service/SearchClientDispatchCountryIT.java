package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.junit.Before;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.connection.ESConnection;

import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.elasticsearch.common.xcontent.XContentType.JSON;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchHitMatchers.declarationId;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchResponseAssert.assertSearchHits;

public class SearchClientDispatchCountryIT extends CustomsSearchESIntegTestCase {

    private static final String CUSTOMS_INDEX = "SearchServiceDispatchCountryIntegrationTest".toLowerCase();
    private static final String IN_CODE = "IN"; // dispatchCountry
    private static final String NZ_CODE = "NZ"; // dispatchCountry
    private static final String MX_CODE = "MX"; // dispatchCountry
    private static final String CA_CODE = "CA"; // originCountry
    private static final String CH_CODE = "CH"; // originCountry
    private static final String EPU = "EPU";

    private SearchClient service;

    private ObjectMapper objectMapper = new ObjectMapper();

    @Before
    public void setUp() throws Exception {
        super.setUp();
        this.service = new SearchClient(new ESConnection(ES_HOST, ES_PORT), CUSTOMS_INDEX);
        createCustomsIndexWithDocuments();
    }

    @Test
    public void searchWithBlankDispatchCountryFacet() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(""));
        assertSearchHits(searchResponse, declarationId("dec-id-5"));
    }

    @Test
    public void searchWithOneDispatchCountryFacet() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(IN_CODE));
        assertSearchHits(searchResponse,
                declarationId("dec-id-1"),
                declarationId("dec-id-2"),
                declarationId("dec-id-3"));
    }

    @Test
    public void searchWithTwoDispatchCountryFacets() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(IN_CODE, NZ_CODE));

        assertSearchHits(searchResponse,
                declarationId("dec-id-3"));
    }

    @Test
    public void searchWithOneDispatchCountryFacetWithSearchTerm() {
        SearchCriteria searchCriteria = newSearchCriteria(NZ_CODE);
        searchCriteria.setSearchTerm(EPU);
        SearchResponse searchResponse = this.service.declarationSearch(searchCriteria);

        assertSearchHits(searchResponse,
                declarationId("dec-id-3"),
                declarationId("dec-id-4"));
    }

    @Test
    public void searchWithOneDispatchCountryFacetOneOriginCountryFacetWithSearchTerm() {
        SearchCriteria searchCriteria = newSearchCriteria(IN_CODE, NZ_CODE);
        searchCriteria.setSearchTerm(EPU);
        searchCriteria.setOriginCountryCode(Arrays.asList(IN_CODE, CA_CODE));

        SearchResponse searchResponse = this.service.declarationSearch(searchCriteria);

        assertSearchHits(searchResponse,
                declarationId("dec-id-7"));

    }

    @Test
    public void searchWithOneDispatchCountryFacetAndOneOriginCountryFacet() {
        SearchCriteria searchCriteria = newSearchCriteria(MX_CODE);
        searchCriteria.setOriginCountryCode(Arrays.asList(CH_CODE));

        SearchResponse searchResponse = this.service.declarationSearch(searchCriteria);

        assertSearchHits(searchResponse,
                declarationId("dec-id-8"));

    }

    private SearchCriteria newSearchCriteria(String... distpachCountryCodes) {
        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDispatchCountryCode(Arrays.asList(distpachCountryCodes));
        return searchCriteria;
    }

    private void createCustomsIndexWithDocuments() throws Exception {
        createIndex(CUSTOMS_INDEX);

        BulkRequest request = new BulkRequest();
        addDeclaration(request, newDeclaration("dec-id-1", IN_CODE));
        addDeclaration(request, newDeclaration("dec-id-2", IN_CODE));
        addDeclaration(request, newDeclaration("dec-id-3", IN_CODE, NZ_CODE));
        addDeclaration(request, newDeclaration("dec-id-4", NZ_CODE));
        addDeclaration(request, newDeclaration("dec-id-5", ""));
        addDeclaration(request, newDeclaration("dec-id-6"));
        addDeclaration(request, newDeclarationWithOriginCountryDispatchCountry("dec-id-7", CA_CODE, MX_CODE));
        addDeclaration(request, newDeclarationWithOriginCountryDispatchCountry("dec-id-8", CH_CODE, MX_CODE));

        client.bulk(request);

        refresh(CUSTOMS_INDEX);
    }

    private void addDeclaration(BulkRequest request, Declaration declaration) throws JsonProcessingException {
        request.add(new IndexRequest(CUSTOMS_INDEX, DECLARATION_TYPE, declaration.getDeclarationId())
                .source(objectMapper.writer().writeValueAsString(declaration), JSON));
    }


    private Declaration newDeclaration(String id, String ... dispatchCountryCodes) {
        return Declaration.builder()
                .declarationId(id)
                .epuNumber(EPU)
                .lines(
                        Stream.of(dispatchCountryCodes)
                                .map(code -> DeclarationLine.builder()
                                        .itemDispatchCountry(Country.builder()
                                                .code(code)
                                                .build())
                                        .build())
                                .collect(Collectors.toList()))
                .build();
    }

    private Declaration newDeclarationWithOriginCountryDispatchCountry(String id, String originCountryCode, String dispatchCountryCode) {
        return Declaration.builder()
                .declarationId(id)
                .epuNumber(EPU)
                .lines(
                        Lists.newArrayList(
                                DeclarationLine.builder()
                                        .itemDispatchCountry(Country.builder().code(dispatchCountryCode).build())
                                        .originCountry(Country.builder().code(originCountryCode).build())
                                        .build()
                        )
                )
                .build();
    }

}
