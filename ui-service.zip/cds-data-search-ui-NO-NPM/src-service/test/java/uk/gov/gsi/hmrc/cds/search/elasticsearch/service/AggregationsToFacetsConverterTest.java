package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.CountryFacet;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.Facets;

import java.util.List;

import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

public class AggregationsToFacetsConverterTest {

    @Mock
    private BucketToCountryFacetConverter countryFacetConverter;

    @Mock
    private BucketToTransportModeFacetConverter transportModeFacetConverter;

    private AggregationsToFacetsConverter converter;

    private Aggregations aggregations;

    @Mock
    private Terms originCountryTerms;

    @Mock
    private Terms dispatchCountryTerms;

    @Mock
    private Terms destinationCountryTerms;

    @Mock
    private Terms transportModeTerms;


    @Before
    public void setUp() {
        initMocks(this);
        when(originCountryTerms.getName()).thenReturn("originCountry");
        when(dispatchCountryTerms.getName()).thenReturn("dispatchCountry");
        when(destinationCountryTerms.getName()).thenReturn("destinationCountry");
        when(transportModeTerms.getName()).thenReturn("transportMode");

        aggregations = new Aggregations(asList(originCountryTerms, dispatchCountryTerms, destinationCountryTerms, transportModeTerms));
        converter = new AggregationsToFacetsConverter(countryFacetConverter, transportModeFacetConverter);
    }

    @Test
    public void convertOne() {
        Terms.Bucket bucket = givenBucket();
        givenBuckets(bucket);
        CountryFacet expected = givenCanConvertBucket(bucket);
        Facets actual = converter.convert(aggregations);
        assertThat(actual.getOriginCountries(), contains(expected));
    }

    @Test
    public void convertMany() {
        Terms.Bucket bucket1 = givenBucket();
        Terms.Bucket bucket2 = givenBucket();

        givenBuckets(bucket1, bucket2);

        CountryFacet expected1 = givenCanConvertBucket(bucket1);
        CountryFacet expected2 = givenCanConvertBucket(bucket2);

        Facets actual = converter.convert(aggregations);
        assertThat(actual.getOriginCountries(), contains(expected1, expected2));
    }

    @Test
    public void convertsEmptyBuckets() {
        givenBuckets();
        Facets actual = converter.convert(aggregations);
        assertThat(actual.getOriginCountries(), is(empty()));
    }

    private Terms.Bucket givenBucket() {
        return mock(Terms.Bucket.class);
    }

    private void givenBuckets(Terms.Bucket... buckets) {
        @SuppressWarnings("unchecked")
        List bucketList = asList(buckets);
        when(originCountryTerms.getBuckets()).thenReturn(bucketList);
    }

    private CountryFacet givenCanConvertBucket(Terms.Bucket bucket) {
        CountryFacet countryFacet = CountryFacet.builder().build();
        when(countryFacetConverter.convert(bucket)).thenReturn(countryFacet).thenReturn(countryFacet);
        return countryFacet;
    }

}