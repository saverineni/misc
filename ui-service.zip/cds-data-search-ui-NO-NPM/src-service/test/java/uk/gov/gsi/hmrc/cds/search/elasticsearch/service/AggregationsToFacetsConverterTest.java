package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.CountryFacet;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.Facet;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.Facets;

import java.util.List;

import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

public class AggregationsToFacetsConverterTest {

    @Mock
    private BucketToCountryFacetConverter countryFacetConverter;

    @Mock
    private BucketToTransportModeFacetConverter transportModeFacetConverter;

    @Mock
    private BucketToFacetConverter facetConverter;


    private AggregationsToFacetsConverter converter;

    private Aggregations aggregations;

    @Mock
    private Terms originCountryTerms;

    @Mock
    private Terms dispatchCountryTerms;

    @Mock
    private Terms destinationCountryTerms;

    @Mock
    private Terms transportModeTerms;

    @Mock
    private Terms goodsLocationTerms;


    @Before
    public void setUp() {
        initMocks(this);
        when(originCountryTerms.getName()).thenReturn("originCountry");
        when(dispatchCountryTerms.getName()).thenReturn("dispatchCountry");
        when(destinationCountryTerms.getName()).thenReturn("destinationCountry");
        when(transportModeTerms.getName()).thenReturn("transportMode");
        when(goodsLocationTerms.getName()).thenReturn("goodsLocation");

        aggregations = new Aggregations(asList(originCountryTerms, dispatchCountryTerms, destinationCountryTerms, transportModeTerms,goodsLocationTerms));
        converter = new AggregationsToFacetsConverter(countryFacetConverter, transportModeFacetConverter, facetConverter);
    }

    @Test
    public void convertOne() {
        Terms.Bucket bucket = givenBucket();
        givenBuckets(bucket);
        CountryFacet expected = givenCanConvertBucket(bucket);
        Facet expected1 = givenCanConvertBucketToFacet(bucket);

        Facets actual = converter.convert(aggregations);
        assertThat(actual.getOriginCountries(), contains(expected));
        assertThat(actual.getOriginCountries1(), contains(expected1));
    }

    @Test
    public void convertMany() {
        Terms.Bucket bucket1 = givenBucket();
        Terms.Bucket bucket2 = givenBucket();

        givenBuckets(bucket1, bucket2);

        CountryFacet expected1 = givenCanConvertBucket(bucket1);
        CountryFacet expected2 = givenCanConvertBucket(bucket2);

        Facet expected3 = givenCanConvertBucketToFacet(bucket1);
        Facet expected4 = givenCanConvertBucketToFacet(bucket2);

        Facets actual = converter.convert(aggregations);
        assertThat(actual.getOriginCountries(), contains(expected1, expected2));
        assertThat(actual.getOriginCountries1(), contains(expected3, expected4));

    }

    @Test
    public void convertsEmptyBuckets() {
        givenBuckets();
        Facets actual = converter.convert(aggregations);
        assertThat(actual.getOriginCountries(), is(empty()));
        assertThat(actual.getOriginCountries1(), is(empty()));
    }

    private Terms.Bucket givenBucket() {
        return mock(Terms.Bucket.class);
    }

    private void givenBuckets(Terms.Bucket... buckets) {
        @SuppressWarnings("unchecked")
        List bucketList = asList(buckets);
        when(originCountryTerms.getBuckets()).thenReturn(bucketList);
    }

    private CountryFacet givenCanConvertBucket(Terms.Bucket bucket) {
        CountryFacet countryFacet = CountryFacet.builder().build();
        when(countryFacetConverter.convert(bucket)).thenReturn(countryFacet).thenReturn(countryFacet);
        return countryFacet;
    }

    private Facet givenCanConvertBucketToFacet(Terms.Bucket bucket) {
        Facet facet = Facet.builder().build();
        when(facetConverter.convert(bucket)).thenReturn(facet);
        return facet;
    }

}