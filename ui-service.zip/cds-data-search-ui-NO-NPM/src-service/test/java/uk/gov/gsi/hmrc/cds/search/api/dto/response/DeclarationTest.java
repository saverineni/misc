package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import org.junit.Test;

import static java.util.Collections.singletonList;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

public class DeclarationTest {

    Declaration declaration = Declaration.builder().build();

    @Test
    public void getLinesShouldGiveEmptyListIfNull() {
        declaration.setLines(null);
        assertThat(declaration.getLines(), is(empty()));
    }

    @Test
    public void getLinesShouldGiveLineIfNotEmpty() {
        DeclarationLine line = DeclarationLine.builder().build();
        declaration.setLines(singletonList(line));
        assertThat(declaration.getLines(), contains(line));
    }

}