package uk.gov.gsi.hmrc.cds.search.security.jwt;

import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.util.matcher.RequestMatcher;
import uk.gov.gsi.hmrc.cds.search.security.jwt.JwtAuthenticationProcessingFilter;
import uk.gov.gsi.hmrc.cds.search.security.jwt.JwtAuthenticationToken;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class JwtAuthenticationProcessingFilterTest {

    private final String AUTHORIZATION_HEADER = "Authorization";
    private HttpServletRequest request = mock(HttpServletRequest.class);
    private AuthenticationManager authenticationManager = mock(AuthenticationManager.class);
    private Authentication authentication = mock(Authentication.class);
    RequestMatcher requestMatcher = mock(RequestMatcher.class);
    JwtAuthenticationProcessingFilter filter = new JwtAuthenticationProcessingFilter(requestMatcher, authenticationManager);
    private ArgumentCaptor<JwtAuthenticationToken> argumentCaptor = ArgumentCaptor.forClass(JwtAuthenticationToken.class);

    @Test
    public void attemptAuthenticationShouldGiveAuthenticationForAValidJwtToken() throws IOException, ServletException {
        when(request.getHeader(AUTHORIZATION_HEADER)).thenReturn("Bearer abc.abc.abc");
        when(authenticationManager.authenticate(Mockito.any(JwtAuthenticationToken.class))).thenReturn(authentication);
        Authentication result = filter.attemptAuthentication(request, null);

        assertThat(result, is(authentication));
        verify(authenticationManager).authenticate(argumentCaptor.capture());
        assertThat(argumentCaptor.getValue(), instanceOf(JwtAuthenticationToken.class));

    }

    @Test(expected = AuthenticationCredentialsNotFoundException.class)
    public void attemptAuthenticationShouldThrowsExceptionForMissingAuthHeader() throws IOException, ServletException {
        when(authenticationManager.authenticate(Mockito.any(JwtAuthenticationToken.class))).thenReturn(authentication);
        filter.attemptAuthentication(request, null);
    }

    @Test(expected = AuthenticationCredentialsNotFoundException.class)
    public void attemptAuthenticationShouldThrowsExceptionForInvalidAuthHeader() throws IOException, ServletException {
        when(request.getHeader(AUTHORIZATION_HEADER)).thenReturn("Basic abc.abc.abc");
        when(authenticationManager.authenticate(Mockito.any(JwtAuthenticationToken.class))).thenReturn(authentication);
        filter.attemptAuthentication(request, null);
    }

    @Test(expected = AuthenticationCredentialsNotFoundException.class)
    public void attemptAuthenticationShouldThrowsExceptionForInvalidBearerToken() throws IOException, ServletException {
        when(request.getHeader(AUTHORIZATION_HEADER)).thenReturn("Bearer null");
        when(authenticationManager.authenticate(Mockito.any(JwtAuthenticationToken.class))).thenReturn(authentication);
        filter.attemptAuthentication(request, null);
    }

    @Test(expected = AuthenticationCredentialsNotFoundException.class)
    public void attemptAuthenticationShouldThrowsExceptionForInvalidAuthHeaderNull() throws IOException, ServletException {
        when(request.getHeader(AUTHORIZATION_HEADER)).thenReturn(null);
        when(authenticationManager.authenticate(Mockito.any(JwtAuthenticationToken.class))).thenReturn(authentication);
        filter.attemptAuthentication(request, null);
    }
}
