package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.hamcrest.FeatureMatcher;
import org.hamcrest.Matcher;
import org.hamcrest.Matchers;

import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.is;

public class TermsBucketMatchers {

    public static Matcher<Terms.Bucket> termsBucket(String key, int count) {
        return allOf(key(key), count(count));
    }

    public static FeatureMatcher<Terms.Bucket, Object> key(String key) {
        return new FeatureMatcher<Terms.Bucket, Object>(is(key), "key", "key") {
            @Override
            protected Object featureValueOf(Terms.Bucket actual) {
                return actual.getKey();
            }
        };
    }

    public static FeatureMatcher<Terms.Bucket, Integer> count(int count) {
        return new FeatureMatcher<Terms.Bucket, Integer>(is(count), "count", "count") {
            @Override
            protected Integer featureValueOf(Terms.Bucket actual) {
                return (int) actual.getDocCount();
            }
        };
    }

}
