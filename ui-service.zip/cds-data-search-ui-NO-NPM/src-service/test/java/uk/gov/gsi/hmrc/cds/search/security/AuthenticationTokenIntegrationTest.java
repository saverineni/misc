package uk.gov.gsi.hmrc.cds.search.security;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;

import uk.gov.gsi.hmrc.cds.search.CustomsSearchServiceApplication;

import org.apache.http.HttpStatus;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static com.jayway.restassured.http.ContentType.JSON;
import static org.apache.http.HttpStatus.SC_FORBIDDEN;
import static org.apache.http.HttpStatus.SC_OK;
import static org.apache.http.HttpStatus.SC_UNAUTHORIZED;
import static org.junit.Assert.assertTrue;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;


@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest(
        classes = CustomsSearchServiceApplication.class,
        webEnvironment = RANDOM_PORT
)
public class AuthenticationTokenIntegrationTest {

    @Value("${local.server.port}")
    private int port;

    @Before
    public void setup() {
        RestAssured.port = this.port;
    }

    @Test
    public void shouldGetJwtTokenResponse_forValidLoginCredentials() throws Exception {

        String token = RestAssured.
                given()
                .contentType(JSON)
                .accept("application/json")
                .body("{\"pid\": \"dev\",\"password\": \"dev\"}")
                .when()
                .post("/authentication/token")
                .then()
                .statusCode(SC_OK)
                .contentType("application/json")
                .extract()
                .path("token");

        assertTrue(token.matches("^([\\w\\-=]+)\\.([\\w\\-=]+)\\.([\\w\\-=]+)$"));
    }

    @Test
    public void throwsAuthenticationException_whenGetJwtTokenRequestBodyEmpty() {
        RestAssured.
                given()
                .accept("application/json")
                .when()
                .get("/authentication/token")
                .then()
                .statusCode(SC_FORBIDDEN);

    }

    @Test
    public void invalidCredendials_returnsUnauthorizedStatus() {
        RestAssured.
                given()
                .accept("application/json")
                .when()
                .post("/authentication/token")
                .then()
                .statusCode(SC_UNAUTHORIZED);

    }
}