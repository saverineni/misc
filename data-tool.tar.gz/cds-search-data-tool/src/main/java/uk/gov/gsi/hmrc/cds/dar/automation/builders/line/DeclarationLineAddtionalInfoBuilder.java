package uk.gov.gsi.hmrc.cds.dar.automation.builders.line;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.line.DeclarationLineAdditionalInfo;


public class DeclarationLineAddtionalInfoBuilder {

    private static final String DEFAULT_ENTRY_REFERENCE = "670-IM001A-2016-12-01";
    private static final String DEFAULT_SEQUENCE_NUMBER = "1";
    private static final String DEFAULT_GENERATION_NUMBER = "1";
    private static final String DEFAULT_STATEMENT = "Add Info Statement 1 for 1500/3";
    private static final String DEFAULT_STATEMENT_TYPE = "123";
    private static final String DEFAULT_ITEM_STATEMMENT = "Item Add Info Statement 1 for 1500/3";

    public static Builder builder() {
        return new DeclarationLineAddtionalInfoBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private DeclarationLineAdditionalInfo additionalInfo = new DeclarationLineAdditionalInfo();

        public DeclarationLineAddtionalInfoBuilder.Builder withAdditionalInfoEntryReference(String entryReference) {
            additionalInfo.setEntry_reference(entryReference);
            return this;
        }

        public DeclarationLineAddtionalInfoBuilder.Builder withAdditionalInfoSequenceNumber(String sequenceNumber) {
            additionalInfo.setAdditional_information_sequence_number(sequenceNumber);
            return this;
        }

        public DeclarationLineAddtionalInfoBuilder.Builder withAdditionalInfoGenerationNumber(String generationNumber) {
            additionalInfo.setSat_additional_info_generation_number(generationNumber);
            return this;
        }

        public DeclarationLineAddtionalInfoBuilder.Builder withAdditionalInfoStatement(String statement) {
            additionalInfo.setAdditional_information_statement(statement);
            return this;
        }

        public DeclarationLineAddtionalInfoBuilder.Builder withAdditionalInfoStatementtype(String statementType) {
            additionalInfo.setAdditional_information_statement_type(statementType);
            return this;
        }

        public DeclarationLineAddtionalInfoBuilder.Builder withAdditionalInfoItemStatement(String itemStatement) {
            additionalInfo.setItem_additional_information_statement(itemStatement);
            return this;
        }

        public DeclarationLineAdditionalInfo build() {
            return additionalInfo;
        }
    }

    public static DeclarationLineAdditionalInfo getDefault() {
        return defaultBuilder().build();
    }

    private static Builder defaultBuilder() {
        return builder()
                .withAdditionalInfoEntryReference(DEFAULT_ENTRY_REFERENCE)
                .withAdditionalInfoSequenceNumber(DEFAULT_SEQUENCE_NUMBER)
                .withAdditionalInfoGenerationNumber(DEFAULT_GENERATION_NUMBER)
                .withAdditionalInfoStatement(DEFAULT_STATEMENT)
                .withAdditionalInfoStatementtype(DEFAULT_STATEMENT_TYPE)
                .withAdditionalInfoItemStatement(DEFAULT_ITEM_STATEMMENT);
    }
}