package uk.gov.gsi.hmrc.cds.dar.automation.builders.line;

import javafx.util.Pair;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.line.DeclarationLineOriginCountry;
import uk.gov.gsi.hmrc.cds.dar.automation.data.Faker;

public class DeclarationLineOriginCountryBuilder {

    private static final String DEFAULT_COUNTRY_CODE = "ZD";
    private static Faker faker = new Faker();

    public static Builder builder() {
        return new DeclarationLineOriginCountryBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private DeclarationLineOriginCountry declarationLineOriginCountry = new DeclarationLineOriginCountry();

        public DeclarationLineOriginCountryBuilder.Builder withOriginCountryCode(String countryCode) {
            declarationLineOriginCountry.setCode(countryCode);
            return this;
        }

        public DeclarationLineOriginCountry build() {
            return declarationLineOriginCountry;
        }
    }

    public static DeclarationLineOriginCountry getDefault() {
        return defaultBuilder().build();
    }

    public static Builder defaultBuilder() {
        return builder()
                .withOriginCountryCode(DEFAULT_COUNTRY_CODE);
    }

    public static DeclarationLineOriginCountry getRandom() {
        Pair<String, String> randomCountryPair = faker.getRandomOriginCountry();

        return builder()
                .withOriginCountryCode(randomCountryPair.getKey())
                .build();
    }

    public static DeclarationLineOriginCountry getTurkey() {
        return builder()
                .withOriginCountryCode("TR")
                .build();
    }

    public static DeclarationLineOriginCountry getEuropeanCommunuity() {
        return builder()
                .withOriginCountryCode("EU")
                .build();
    }

    public static DeclarationLineOriginCountry getCornIslands() {
        return builder()
                .withOriginCountryCode("XT")
                .build();
    }

    public static DeclarationLineOriginCountry getEmptyCountry() {
        return builder()
                .withOriginCountryCode("")
                .build();
    }

    public static DeclarationLineOriginCountry getCountryFor(String countryCode) {
        Pair<String, String> countryPair = faker.getCountry(countryCode);

        return builder()
                .withOriginCountryCode(countryPair.getKey())
                .build();
    }
}