package uk.gov.gsi.hmrc.cds.dar.automation.builders.header;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.trader.ExporterTrader;

public class DeclarationExporterTraderBuilder {

    private static final String DEFAULT_EXPORTER_TRADER_TURN = "210098765123";
    private static final String DEFAULT_EXPORTER_TRADER_CURRENT_IND = "Y";
    private static final String DEFAULT_EXPORTER_TRADER_NAME = "6 Group";
    private static final String DEFAULT_EXPORTER_TRADER_SIMPLIFIED_PROCEDURE_AUTHORISATIONS = "JKS";
    private static final String DEFAULT_EXPORTER_TRADER_NAME_ABBREVIATED = "Exporter Turn 6 Ltd";

    public static Builder builder() {
        return new DeclarationExporterTraderBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private ExporterTrader exporterTrader = new ExporterTrader();

        public DeclarationExporterTraderBuilder.Builder withExporterTraderTurn(String turn) {
            exporterTrader.setExporter_trader_turn(turn);
            return this;
        }

        public DeclarationExporterTraderBuilder.Builder withExporterCurrentInd(String currentInd) {
            exporterTrader.setCurrent_ind(currentInd);
            return this;
        }

        public DeclarationExporterTraderBuilder.Builder withExporterName(String name) {
            exporterTrader.setName(name);
            return this;
        }

        public DeclarationExporterTraderBuilder.Builder withExporterSimplifiedProcedureAuthorisations(String simplifiedProcedureAuthorisations) {
            exporterTrader.setSimplified_procedure_authorisations(simplifiedProcedureAuthorisations);
            return this;
        }

        public DeclarationExporterTraderBuilder.Builder withExporterNameAbbreviated(String nameAbbreviated) {
            exporterTrader.setTrader_name_abbreviated(nameAbbreviated);
            return this;
        }

        public ExporterTrader build(){
            return exporterTrader;
        }
    }

    public static ExporterTrader getDefault() {
        return defaultBuilder().build();
    }

    public static DeclarationExporterTraderBuilder.Builder defaultBuilder() {
        return builder()
                .withExporterTraderTurn(DEFAULT_EXPORTER_TRADER_TURN)
                .withExporterCurrentInd(DEFAULT_EXPORTER_TRADER_CURRENT_IND)
                .withExporterName(DEFAULT_EXPORTER_TRADER_NAME)
                .withExporterSimplifiedProcedureAuthorisations(DEFAULT_EXPORTER_TRADER_SIMPLIFIED_PROCEDURE_AUTHORISATIONS)
                .withExporterNameAbbreviated(DEFAULT_EXPORTER_TRADER_NAME_ABBREVIATED);
    }
}