package uk.gov.gsi.hmrc.cds.dar.automation.entities.line;

import lombok.Data;

@Data
public class DeclarationLinesImporterTrader {

    private String itemConsigneeTurn;
    private String name;
    private String simplified_procedure_authorisations;
    private String trader_name_abbreviated;
    private String current_ind;
}
