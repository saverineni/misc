package uk.gov.gsi.hmrc.cds.dar.automation.entities;

import com.google.common.collect.Lists;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.DeclarationDestinationCountry;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.DeclarationDispatchCountry;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.line.DeclarationLine;
import uk.gov.gsi.hmrc.cds.dar.automation.json.EqualsHashCodeToString;

import java.util.List;

@Data
public class Declaration extends EqualsHashCodeToString {

    String declarationId;
    String declarationSource;
    String importExportIndicator;
    String epuNumber;
    String entryNumber;
    String entryDate;
    String goodsLocation;
    int transportModeCode;
    String route;
    String consigneeTurn;
    String consigneeEori;
    String consigneeName;
    String consigneePostcode;
    String consignorTurn;
    String consignorName;
    String consignorPostcode;
    DeclarationDispatchCountry dispatchCountry;
    DeclarationDestinationCountry destinationCountry;
    List<DeclarationLine> lines = Lists.newArrayList();

//    String entry_type;
//    String declaration_method;
//    String total_excise;
//    String declarant_representative_turn;
//    String consignee_aeo_certificate_type_code;
//    String declarant_aeo_certificate_type_code;
//    String declaration_import_export_indicator;
//    String generation_number;
//    String import_clearance_status;
//    String consignor_aeo_certificate_type_code;
//    String header_statistical_value;
//    String goods_departure_datetime;
//    String customs_value;
//    String total_duty;
//    String total_vat;
//    String net_mass_total;
//    String acceptance_date;
//    String importer_turn_country_code;
//    String place_of_unloading_code;
//    String first_deferment_approval_num;
//    String first_deferment_approval_num_prefix;
//    String declaration_ucr;
//    String item_count;
//    String master_ucr;
//    String paying_agent_turn;
//    String place_of_loading_code;
//    String session_num;
//    String session_role_name;
//    String status_of_entry;
//    String transport_country;
//    String transport_id;
//    String consignor_turn_country_code;
//    String declarant_nad_name;
//    String customs_check_code;
//    String profile_id;
//    String invoice_total_declared;
//    DeclarationCurrency declarationCurrency;
//    DeclarationTrader declarationTrader;
//    DeclarationCountry declarationCountry;
}
