package uk.gov.gsi.hmrc.cds.dar.automation.entities.header.trader;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.json.EqualsHashCodeToString;

@Data
public class PayingAgentTrader extends EqualsHashCodeToString {

    private String paying_agent_trader_turn;
    private String current_ind;
    private String name;
    private String simplified_procedure_authorisations;
    private String trader_name_abbreviated;
}
