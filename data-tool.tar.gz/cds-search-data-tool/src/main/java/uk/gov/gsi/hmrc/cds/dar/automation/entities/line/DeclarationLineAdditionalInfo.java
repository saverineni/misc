package uk.gov.gsi.hmrc.cds.dar.automation.entities.line;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.json.EqualsHashCodeToString;

@Data
public class DeclarationLineAdditionalInfo extends EqualsHashCodeToString {

    @JsonIgnore
    String entry_reference;
    @JsonIgnore
    String item_number;

    String additional_information_sequence_number;
    String sat_additional_info_generation_number;
    String additional_information_statement;
    String additional_information_statement_type;
    String item_additional_information_statement;
}
