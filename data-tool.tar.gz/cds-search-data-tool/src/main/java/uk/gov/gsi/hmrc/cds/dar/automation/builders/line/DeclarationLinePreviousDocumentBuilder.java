package uk.gov.gsi.hmrc.cds.dar.automation.builders.line;

import uk.gov.gsi.hmrc.cds.dar.automation.entities.line.DeclarationLinePreviousDocument;

public class DeclarationLinePreviousDocumentBuilder {

    private static final String DEFAULT_ENTRY_REFERENCE = "670-IM001A-2016-12-01";
    private static final String DEFAULT_SEQUENCE_NUMBER = "1";
    private static final String DEFAULT_DOCUMENT_REFERENCE = "20141015-071-014998E";

    public static Builder builder() {
        return new DeclarationLinePreviousDocumentBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private DeclarationLinePreviousDocument previousDocument = new DeclarationLinePreviousDocument();

        public DeclarationLinePreviousDocumentBuilder.Builder withPreviousDocumentEntryReference(String entryReference) {
            previousDocument.setEntry_reference(entryReference);
            return this;
        }

        public DeclarationLinePreviousDocumentBuilder.Builder withPreviousDocumentSequenceNumber(String sequenceNumber) {
            previousDocument.setPrevious_document_sequence_number(sequenceNumber);
            return this;
        }

        public DeclarationLinePreviousDocumentBuilder.Builder withPreviousDocumentDocumentReference(String documentReference) {
            previousDocument.setPrevious_document_reference(documentReference);
            return this;
        }

        public DeclarationLinePreviousDocument build() {
            return previousDocument;
        }
    }

    public static DeclarationLinePreviousDocument getDefault() {
        return defaultBuilder().build();
    }

    private static Builder defaultBuilder() {
        return builder()
                .withPreviousDocumentEntryReference(DEFAULT_ENTRY_REFERENCE)
                .withPreviousDocumentSequenceNumber(DEFAULT_SEQUENCE_NUMBER)
                .withPreviousDocumentDocumentReference(DEFAULT_DOCUMENT_REFERENCE);
    }
}
