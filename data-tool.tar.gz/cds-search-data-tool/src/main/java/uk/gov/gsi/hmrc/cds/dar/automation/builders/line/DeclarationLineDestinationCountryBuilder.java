package uk.gov.gsi.hmrc.cds.dar.automation.builders.line;

import javafx.util.Pair;
import uk.gov.gsi.hmrc.cds.dar.automation.data.Faker;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.line.DeclarationLineDestinationCountry;

public class DeclarationLineDestinationCountryBuilder {
    private static final String DEFAULT_COUNTRY_CODE = "GB";
    private static Faker faker = new Faker();

    public static DeclarationLineDestinationCountryBuilder.Builder builder() {
        return new DeclarationLineDestinationCountryBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private DeclarationLineDestinationCountry declarationLineDestinationCountry = new DeclarationLineDestinationCountry();

        public DeclarationLineDestinationCountryBuilder.Builder withDestinationCountryCode(String countryCode) {
            declarationLineDestinationCountry.setCode(countryCode);
            return this;
        }

        public DeclarationLineDestinationCountry build() {
            return declarationLineDestinationCountry;
        }
    }

    public static DeclarationLineDestinationCountry getDefault() {
        return defaultBuilder().build();
    }

    public static DeclarationLineDestinationCountryBuilder.Builder defaultBuilder() {
        return builder()
                .withDestinationCountryCode(DEFAULT_COUNTRY_CODE);
    }

    public static DeclarationLineDestinationCountry getRandom() {
        Pair<String, String> randomCountryPair = faker.getRandomOriginCountry();

        return builder()
                .withDestinationCountryCode(randomCountryPair.getKey())
                .build();
    }
}
