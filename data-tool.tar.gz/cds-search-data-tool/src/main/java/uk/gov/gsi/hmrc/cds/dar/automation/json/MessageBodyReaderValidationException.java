package uk.gov.gsi.hmrc.cds.dar.automation.json;

public class MessageBodyReaderValidationException extends RuntimeException {
    public MessageBodyReaderValidationException(String s) {
        super(s);
    }

    public MessageBodyReaderValidationException(String s, Exception e) {
        super(s, e);
    }
}