package uk.gov.gsi.hmrc.cds.dar.automation.data;

import javafx.util.Pair;

import java.math.BigInteger;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Random;

public class Faker extends DataLists {

    private static final int DEFAULT_BIT_LENGTH_DECLARATION_ID = 68;
    private double minValue = 1.00;
    private double maxValue = 9999.99;
    DecimalFormat decimalFormat = new DecimalFormat("#.##");

    public String getRandomDeclarationId() {
        Random rnd = new Random();
        BigInteger no = BigInteger.probablePrime(DEFAULT_BIT_LENGTH_DECLARATION_ID, rnd);
        return no.toString();
    }

    public String getRandomEpu() {
        return epuList.get(new Random().nextInt(epuList.size()));
    }

    public String getRandomEntryNumber() {
        return entryNumberList.get(new Random().nextInt(entryNumberList.size()));
    }

    public String getRandomEntryDate() {
        return entryDateList.get(new Random().nextInt(entryDateList.size()));
    }

    public String getRandomClearanceDate() {
        return clearanceDateList.get(new Random().nextInt(clearanceDateList.size()));
    }

    public String getRandomGoodsLocation() {
        return goodsLocationList.get(new Random().nextInt(goodsLocationList.size()));
    }

    public int getRandomModeOfTransport() {
        return modeOfTransportList.get(new Random().nextInt(modeOfTransportList.size()));
    }

    public String getRandomCPC() {
        return customsProcedureCodeList.get(new Random().nextInt(customsProcedureCodeList.size()));
    }

    public String getRandomCommodityCode() {
        return commodityCodeList.get(new Random().nextInt(commodityCodeList.size()));
    }

    public String getRandomCommodityChapterDescription() {
        return commodityCodeChapterDescription.get(new Random().nextInt(commodityCodeChapterDescription.size()));
    }

    public String getRandomCommodityHeadingDescription() {
        return commodityCodeHeadingDescription.get(new Random().nextInt(commodityCodeHeadingDescription.size()));
    }

    public String getRandomCommoditySubheadingDescription() {
        return commodityCodeSubheadingDescription.get(new Random().nextInt(commodityCodeSubheadingDescription.size()));
    }

    public String getRandomCommodityCodeCotton() {
        return commodityCodeCottonList.get(new Random().nextInt(commodityCodeCottonList.size()));
    }

    public String getRandomCommodityCottonChapterDescription() {
        return commodityCodeCottonChapterDescription.get(new Random().nextInt(commodityCodeCottonChapterDescription.size()));
    }

    public String getRandomCommodityCottonHeadingDescription() {
        return commodityCodeCottonHeadingDescription.get(new Random().nextInt(commodityCodeCottonHeadingDescription.size()));
    }

    public String getRandomCommodityCottonSubheadingDescription() {
        return commodityCodeCottonSubheadingDescription.get(new Random().nextInt(commodityCodeCottonSubheadingDescription.size()));
    }

    public String getRandomCommodityCodeTurkey() {
        return commodityCodeTurkeyList.get(new Random().nextInt(commodityCodeTurkeyList.size()));
    }

    public String getRandomCommodityTurkeyChapterDescription() {
        return commodityCodeTurkeyChapterDescription.get(new Random().nextInt(commodityCodeTurkeyChapterDescription.size()));
    }

    public String getRandomCommodityTurkeyHeadingDescription() {
        return commodityCodeTurkeyHeadingDescription.get(new Random().nextInt(commodityCodeTurkeyHeadingDescription.size()));
    }

    public String getRandomCommodityTurkeySubheadingDescription() {
        return commodityCodeTurkeySubheadingDescription.get(new Random().nextInt(commodityCodeTurkeySubheadingDescription.size()));
    }

    public String getRandomRouteOfEntry() {
        return routeOfEntryList.get(new Random().nextInt(routeOfEntryList.size()));
    }

    public String getRandomCountry() {
        return countryCodeList.get(new Random().nextInt(countryCodeList.size()));
    }

    public String getRandomImporterTurn() {
        return importerTurn.get(new Random().nextInt(importerTurn.size()));
    }

    public String getRandomConsignorTurn() {
        return consignorTurn.get(new Random().nextInt(consignorTurn.size()));
    }

    public String getRandomConsigneeName() {
        return consigneeNameList.get(new Random().nextInt(consigneeNameList.size()));
    }

    public String getRandomConsigneePostcode() {
        return consigneePostcodeList.get(new Random().nextInt(consigneePostcodeList.size()));
    }

    public String getRandomConsignorName() {
        return consignorNameList.get(new Random().nextInt(consignorNameList.size()));
    }

    public String getRandomConsignorPostcode() {
        return consignorPostcodeList.get(new Random().nextInt(consignorPostcodeList.size()));
    }

    public List<String> getAllCottonCommodityCodes() {
        return commodityCodeCottonList;
    }

    public List<String> getAllTurkeyCommodityCodes() {
        return commodityCodeTurkeyList;
    }

    public Pair<String, String> getRandomOriginCountry() {
        Object[] originCountryPairs = originCountries.keySet().toArray();
        Object randomCountryCode = originCountryPairs[new Random().nextInt(originCountryPairs.length)];

        Pair<String, String> randomCountryPair = new Pair<>(randomCountryCode.toString(), originCountries.get(randomCountryCode));
        return randomCountryPair;
    }

    public Pair<String, String> getCountry(String countryCode) {
        Pair<String, String> countryPair = new Pair<>(countryCode, originCountries.get(countryCode));
        return countryPair;
    }

    public String getRandomDouble() {
        double min = Math.min(minValue, maxValue);
        double max = Math.max(minValue, maxValue);

        return Double.valueOf(decimalFormat.format(min + (Math.random() * (max - min)))).toString();
    }

    public String getNonSpecialCharHeaderConsignorName() {
        return nonSpecialCharHeaderConsigneeName;
    }

    public String getSpecialCharHeaderConsignorPostcode() {
        return specialCharHeaderConsigneePostcode;
    }

    public String getSpecialCharLineConsignorName() {
        return specialCharLineConsigneeName;
    }

    public String getNonSpecialCharLineConsignorPostcode() {
        return specialCharLineConsigneePostcode;
    }
}
