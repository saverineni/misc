package uk.gov.gsi.hmrc.cds.dar.automation.builders.header;

import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.currency.DeclarationInvoiceCurrency;

public class DeclarationInvoiceCurrencyBuilder {

    private static final String DEFAULT_INVOICE_CURRENCY_CODE = "XPF";
    private static final String DEFAULT_INVOICE_CURRENCY_NAME = "Comptoirs Français du Pacifique (CFP) Franc";

    public static Builder builder() {
        return new DeclarationInvoiceCurrencyBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private DeclarationInvoiceCurrency declarationInvoiceCurrency = new DeclarationInvoiceCurrency();

        public DeclarationInvoiceCurrencyBuilder.Builder withInvoiceCurrencyCode(String currencyCode) {
            declarationInvoiceCurrency.setCurrency_iso_code(currencyCode);
            return this;
        }

        public DeclarationInvoiceCurrencyBuilder.Builder withInvoiceCurrencyName(String currencyName) {
            declarationInvoiceCurrency.setCurrency_name(currencyName);
            return this;
        }



        public DeclarationInvoiceCurrency build() {
            return declarationInvoiceCurrency;
        }
    }

    public static DeclarationInvoiceCurrency getDefault() {
        return defaultBuilder().build();
    }

    private static DeclarationInvoiceCurrencyBuilder.Builder defaultBuilder() {
        return builder()
                .withInvoiceCurrencyCode(DEFAULT_INVOICE_CURRENCY_CODE)
                .withInvoiceCurrencyName(DEFAULT_INVOICE_CURRENCY_NAME);
    }


}
