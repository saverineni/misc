package uk.gov.gsi.hmrc.cds.dar.automation.ingestor;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;

import java.io.IOException;
import static uk.gov.gsi.hmrc.cds.dar.automation.helper.PropertyConfiguration.config;

@Slf4j
public class IngestDataset {

    public static String environment = config().getString("execution.env");
    public static String index = config().getString("index");
    private static String declarationId;
    public static String response;

    public static String createSingleDeclaration(String requestBody) {
        try {
            declarationId = getDeclarationFromRequestBody(requestBody);
            response =  Request.Post(environment + index + declarationId)
                    .addHeader("Content-Type", "application/json")
                    .bodyString(requestBody, ContentType.APPLICATION_JSON)
                    .execute().returnContent().asString();
        }
        catch (IOException ex) {
            log.error("", ex);
            System.out.println(ex.getMessage());
        }
        return response;
    }

    public static String createMultipleDeclarations(StringBuilder bodyString) {
        try {
            String declarationsAsString = bodyString.toString();
            response =  Request.Post(environment + index + "_bulk")
                    .addHeader("Content-Type", "application/json")
                    .bodyString(declarationsAsString, ContentType.APPLICATION_JSON)
                    .execute().returnContent().asString();
        }
        catch (IOException ex) {
            log.error("Unable to create declarations in Elastic Search", ex.getMessage());
        }
        return response;
    }

    //TODO pass decID into this method when required at a later stage
    public static String getDeclaration() {
        try {
            response =  Request.Get(environment + index + declarationId)
                    .addHeader("Content-Type", "application/json")
                    .execute().returnContent().asString();
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return response;
    }

    private static String getDeclarationFromRequestBody(String requestBody) {
        return requestBody.substring(18,39);
    }
}
