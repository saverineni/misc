package uk.gov.gsi.hmrc.cds.dar.automation.ingestor;

import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;

import java.io.IOException;

public class DeleteDataset extends IngestDataset{

    public static String deleteAllDeclarations() {
        try {
            response =  Request.Post(environment + index + "_delete_by_query?conflicts=proceed")
                    .addHeader("Content-Type", "application/json")
                    .bodyString("{\"query\": {\"match_all\": {}}}", ContentType.APPLICATION_JSON)
                    .execute().returnContent().asString();
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return response;
    }
}
