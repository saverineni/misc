package uk.gov.gsi.hmrc.cds.dar.automation.entities.header.currency;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.json.EqualsHashCodeToString;

@Data
public class DeclarationFreightCurrency extends EqualsHashCodeToString {

    String currency_iso_code;
    String currency_name;
}
