package uk.gov.gsi.hmrc.cds.dar.automation.entities.line;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.json.EqualsHashCodeToString;

@Data
public class DeclarationLineCommodity extends EqualsHashCodeToString {

    String commodityCode;
    String cc_year;
    String cc_month;
    String hs_chapter;
    String hs_heading;
    String hs_chapter_heading;
    String hs_subheading;
    String chapter_description;
    String heading_description;
    String subheading_description;
}
