package uk.gov.gsi.hmrc.cds.dar.automation.json;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectWriter;

public interface JsonPrintable {

    default String toJSON() {
        return toJSON(false);
    }

    default String toJSON(Class<?> jsonViewClass) {
        return toJSON(false, jsonViewClass);
    }

    default String toJSON(boolean pretty) {
        ObjectWriter writer = SystemObjectMapper.getInstance().writer();
        if (pretty) {
            writer = writer.withDefaultPrettyPrinter();
        }
        try {
            return writer.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            String className = getClass().getName();
            return String.format("{ error : \"%s.toString()\", message : \"%s\" }", className, e.getMessage());
        }

    }

    default String toJSON(boolean pretty, Class<?> jsonViewClass) {
        ObjectWriter writer = SystemObjectMapper.getInstance().writerWithView(jsonViewClass);
        writer.withView(jsonViewClass);
        if (pretty) {
            writer = writer.withDefaultPrettyPrinter();
        }
        try {
            return writer.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            String className = getClass().getName();
            return String.format("{ error : \"%s.toString()\", message : \"%s\" }", className, e.getMessage());
        }

    }
}