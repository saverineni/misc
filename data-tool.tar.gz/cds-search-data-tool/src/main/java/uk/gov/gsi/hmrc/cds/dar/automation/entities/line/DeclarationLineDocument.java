package uk.gov.gsi.hmrc.cds.dar.automation.entities.line;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.json.EqualsHashCodeToString;

@Data
public class DeclarationLineDocument extends EqualsHashCodeToString {

    @JsonIgnore
    String entry_reference;
    @JsonIgnore
    String item_number;

    String document_sequence_number;
    String sat_document_generation_number;
    String item_document_code;
    String item_document_status;
    String item_document_reference;
}
