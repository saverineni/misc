package uk.gov.gsi.hmrc.cds.dar.automation.data;

import java.util.*;

public class DataLists extends CommodityCodes {

    //TODO find out if any attributes below can contain NULL
    List<String> epuList = new ArrayList<>(Arrays.asList("101","102","103","104","105","106","107","108","109","110","111","112","113","014","115","116","117","118","119","120"));
    List<String> entryNumberList = new ArrayList<>(Arrays.asList("009957A","009957B","009957C","009957D","009957E","009957F","009957G","009957H","009957I","009957J","009957K","009957L","009957M","009957N","009957O","009957P","009957Q","009957R","009957S","009957T"));
    List<String> entryDateList = new ArrayList<>(Arrays.asList("2016-01-05 10:00:00.00","2016-02-05 11:00:00.00","2016-03-05 12:00:00.00","2016-04-05 13:00:00.00","2016-05-05 14:00:00.00","2016-06-05 15:00:00.00"));
    List<String> clearanceDateList = new ArrayList<>(Arrays.asList("2017-01-01 00:00:00.00","2017-04-01 00:00:00.00","2017-07-01 12:00:00.00","2017-10-01 00:00:00.00"));
    List<String> goodsLocationList = new ArrayList<>(Arrays.asList("LHR","LEJ","BAD","FOY","LAH","HPT","KLN","LTN","MOD","BEL"));
    List<Integer> modeOfTransportList = new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,9));
    List<String> customsProcedureCodeList = new ArrayList<>(Arrays.asList("0000010","0610040","0753000","4000007","4000C21","0740000","0634078","0620040","0009035","0000042"));
    List<String> routeOfEntryList =  new ArrayList<>(Arrays.asList("1","15","2","25","3","5","6","F","0","E","H"));
    List<String> countryCodeList =  new ArrayList<>(Arrays.asList("ZM", "UZ", "TH", "SY", "QS", "SH", "GS", "FM", "LA", "KP", "IR", "VA", "TF", "MK", "FK", "CD", "IO"));
    List<String> importerTurn =  new ArrayList<>(Arrays.asList("111198765123","121198765123","131198765123","141198765123","151198765123","161198765123","171198765123","181198765123","191198765123"));
    List<String> consignorTurn =  new ArrayList<>(Arrays.asList("500098765123","510098765123","520098765123","530098765123","540098765123","550098765123","560098765123","570098765123","580098765123","590098765123"));
    List<String> consigneeNameList =  new ArrayList<>(Arrays.asList("A1 goods","A2 goods","A3 goods","A4 goods","A5 goods","A6 goods","A7 goods","A8 goods","A9 goods","A10 goods"));
    List<String> consigneePostcodeList =  new ArrayList<>(Arrays.asList("M1 1AG","M1 2AG","M1 3AG","M1 4AG","M1 5AG","M1 6AG","M1 7AG","M1 8AG","M1 9AG"));
    List<String> consignorNameList =  new ArrayList<>(Arrays.asList("B1 goods","B2 goods","B3 goods","B4 goods","B5 goods","B6 goods","B7 goods","B8 goods","B9 goods","B10 goods"));
    List<String> consignorPostcodeList =  new ArrayList<>(Arrays.asList("M2 1AG","M2 2AG","M2 3AG","M2 4AG","M2 5AG","M2 6AG","M2 7AG","M2 8AG","M2 9AG"));

    String nonSpecialCharHeaderConsigneeName = "Dennis";
    String specialCharHeaderConsigneePostcode = "<RM10> 9'M/";
    String specialCharLineConsigneeName = ";/:@&?=<>#%{}|^~[]";
    String specialCharLineConsigneePostcode = "RM109TT";

    Map<String, String> originCountries = new HashMap<String, String>() {{
        put("AF", "Afghanistan");
        put("AU", "Australia");
        put("BR", "Brazil");
        put("IN", "India");
        put("JP", "Japan");
        put("RU", "Russian Federation");
        put("US", "United States");
        put("GB", "United Kingdom");
        put("BM", "Bermuda");
        put("CY", "Cyprus");
        put("IE", "Ireland");
        put("LB", "Lebanon");
        put("MA", "Morocco");
        put("QA", "Qatar");
        put("ES", "Spain");
        put("NL", "Netherlands");
        put("GR", "Greece");
        put("CA", "Canada");
        put("CN", "China");
        put("YE", "Yemen");
        put("SE", "Sweden");
        put("SG", "Singapore");
        put("PL", "Poland");
        put("NO", "Norway");
        put("LV", "Latvia");
        put("MX", "Mexico");
        put("IT", "Italy");
    }};
}
