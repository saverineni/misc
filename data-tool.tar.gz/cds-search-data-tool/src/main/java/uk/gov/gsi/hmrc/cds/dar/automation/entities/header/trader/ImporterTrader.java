package uk.gov.gsi.hmrc.cds.dar.automation.entities.header.trader;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.json.EqualsHashCodeToString;

@Data
public class ImporterTrader extends EqualsHashCodeToString{

    private String consigneeTurn;
    private String current_ind;
    private String name;
    private String simplified_procedure_authorisations;
    private String trader_name_abbreviated;
}
