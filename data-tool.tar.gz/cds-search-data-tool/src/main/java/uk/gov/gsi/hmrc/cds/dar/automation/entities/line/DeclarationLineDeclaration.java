package uk.gov.gsi.hmrc.cds.dar.automation.entities.line;

import lombok.Data;

@Data
public class DeclarationLineDeclaration {

    String entry_reference;
    String item_number;
}
