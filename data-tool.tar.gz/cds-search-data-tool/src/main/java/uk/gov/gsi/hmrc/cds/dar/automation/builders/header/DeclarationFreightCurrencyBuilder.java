package uk.gov.gsi.hmrc.cds.dar.automation.builders.header;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.currency.DeclarationFreightCurrency;

public class DeclarationFreightCurrencyBuilder {

    private static final String DEFAULT_FREIGHT_CURRENCY_CODE_DEFAULT = "DOP";
    private static final String DEFAULT_FREIGHT_CURRENCY_NAME_DEFAULT = "Dominican Republic Peso";

    public static Builder builder() {
        return new DeclarationFreightCurrencyBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private DeclarationFreightCurrency declarationFreightCurrency = new DeclarationFreightCurrency();

        public DeclarationFreightCurrencyBuilder.Builder withFreightCurrencyCode(String currencyCode) {
            declarationFreightCurrency.setCurrency_iso_code(currencyCode);
            return this;
        }

        public DeclarationFreightCurrencyBuilder.Builder withFreightCurrencyName(String currencyName) {
            declarationFreightCurrency.setCurrency_name(currencyName);
            return this;
        }

        public DeclarationFreightCurrency build() {
            return declarationFreightCurrency;
        }
    }

    public static DeclarationFreightCurrency getDefault() {
        return defaultBuilder().build();
    }

    public static DeclarationFreightCurrencyBuilder.Builder defaultBuilder() {
        return builder()
                .withFreightCurrencyCode(DEFAULT_FREIGHT_CURRENCY_CODE_DEFAULT)
                .withFreightCurrencyName(DEFAULT_FREIGHT_CURRENCY_NAME_DEFAULT);
    }
}