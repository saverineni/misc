package uk.gov.gsi.hmrc.cds.dar.automation.entities.line;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.json.EqualsHashCodeToString;

@Data
public class DeclarationLinePreviousDocument extends EqualsHashCodeToString {

    @JsonIgnore
    String entry_reference;
    @JsonIgnore
    String item_number;

    String previous_document_sequence_number;
    String previous_document_reference;
}
