package uk.gov.gsi.hmrc.cds.dar.automation.builders.header;

import uk.gov.gsi.hmrc.cds.dar.automation.data.Faker;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.DeclarationDestinationCountry;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.DeclarationDispatchCountry;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.DeclarationHeader;

public class DeclarationHeaderBuilder {

    private static final String DEFAULT_IMPORT_DECLARATION_ID = "100000000000000007786";
    private static final String DEFAULT_EXPORT_DECLARATION_ID = "200000000000000007786";
    private static final String IMPORT_TYPE = "Import";
    private static final String EXPORT_TYPE = "Export";
    private static final String SOURCE_MSS = "MSS";
    private static final String DEFAULT_ENTRY_NUMBER = "IM001A";
    private static final String DEFAULT_ENTRY_DATE = "2017-12-01 13:30:19.85";
    private static final String DEFAULT_EPU_NUMBER = "786";
    private static final String DEFAULT_ROUTE = "1";
    private static final String DEFAULT_GOODS_LOCATION = "DOV";
    private static final int DEFAULT_TRANSPORT_MODE_CODE = 2;
    private static final String DEFAULT_CONSIGNEE_TURN = "110098765123";
    private static final String DEFAULT_CONSIGNOR_EORI = "222222222222";
    private static final String DEFAULT_CONSIGNEE_NAD_NAME = "Consignee Name";
    private static final String DEFAULT_CONSIGNEE_NAD_POSTCODE = "RM10 9IM";
    //private static final String DEFAULT_CONSIGNOR_TURN = "210098765123";
    private static final String DEFAULT_CONSIGNOR_TURN = "222222222222";
    private static final String DEFAULT_CONSIGNOR_NAD_NAME = "Consignor Name";
    private static final String DEFAULT_CONSIGNOR_NAD_POSTCODE = "RM10 9EX";
    private static Faker faker = new Faker();

    public static Builder builder() {

        return new DeclarationHeaderBuilder.Builder();
    }

    public static class Builder {
        private Builder() {}
        private DeclarationHeader declarationHeader = new DeclarationHeader();

        public Builder withDeclarationId(String entryReference) {
            declarationHeader.setDeclarationId(entryReference);
            return this;
        }

        public Builder withDeclarationSource(String declarationSource) {
            declarationHeader.setDeclarationSource(declarationSource);
            return this;
        }

        public Builder withImportExportIndicator(String importExportIndicator) {
            declarationHeader.setImportExportIndicator(importExportIndicator);
            return this;
        }

        public Builder withEntryNumber(String entryNumber) {
            declarationHeader.setEntryNumber(entryNumber);
            return this;
        }

        public Builder withEntryDate(String entryDate) {
            declarationHeader.setEntryDate(entryDate);
            return this;
        }

        public Builder withEpuNumber(String epuNumber) {
            declarationHeader.setEpuNumber(epuNumber);
            return this;
        }

        public Builder withRoute(String route) {
            declarationHeader.setRoute(route);
            return this;
        }

        public Builder withGoodsLocation(String goodsLocation) {
            declarationHeader.setGoodsLocation(goodsLocation);
            return this;
        }

        public Builder withTransportModeCode(int transportModeCode) {
            declarationHeader.setTransportModeCode(transportModeCode);
            return this;
        }

        public Builder withConsigneeTurn(String consigneeTurn) {
            declarationHeader.setConsigneeTurn(consigneeTurn);
            return this;
        }

        public Builder withConsigneeEori(String consigneeEori) {
            declarationHeader.setConsigneeTurn(consigneeEori);
            return this;
        }

        public Builder withConsignorTurn(String consignorTurn) {
            declarationHeader.setConsignorTurn(consignorTurn);
            return this;
        }

        public Builder withConsignorEori(String consignorEori) {
            declarationHeader.setConsignorTurn(consignorEori);
            return this;
        }

        public Builder withConsignorNadName(String consignorNadName) {
            declarationHeader.setConsignorName(consignorNadName);
            return this;
        }

        public Builder withConsigneeNadName(String consigneeNadName) {
            declarationHeader.setConsigneeName(consigneeNadName);
            return this;
        }

        public Builder withConsigneeNadPostcode(String consigneeNadPostcode) {
            declarationHeader.setConsigneePostcode(consigneeNadPostcode);
            return this;
        }

        public Builder withConsignorNadPostcode(String consignorNadPostcode) {
            declarationHeader.setConsignorPostcode(consignorNadPostcode);
            return this;
        }

        public Builder withDispatchCountry(DeclarationDispatchCountry dispatchCountry) {
            declarationHeader.setDispatchCountry(dispatchCountry);
            return this;
        }

        public Builder withDestinationCountry(DeclarationDestinationCountry destinationCountry) {
            declarationHeader.setDestinationCountry(destinationCountry);
            return this;
        }

        public DeclarationHeader build() {
            return declarationHeader;
        }
    }

    public static DeclarationHeader getDefaultImport() {
        return getDefaultImportBuilder().build();
    }

    public static Builder getDefaultImportBuilder() {
        return builder()
                .withDeclarationId(DEFAULT_IMPORT_DECLARATION_ID)
                .withDeclarationSource(SOURCE_MSS)
                .withImportExportIndicator(IMPORT_TYPE)
                .withEpuNumber(DEFAULT_EPU_NUMBER)
                .withEntryNumber(DEFAULT_ENTRY_NUMBER)
                .withEntryDate(DEFAULT_ENTRY_DATE)
                .withGoodsLocation(DEFAULT_GOODS_LOCATION)
                .withTransportModeCode(DEFAULT_TRANSPORT_MODE_CODE)
                .withRoute(DEFAULT_ROUTE)
                .withDispatchCountry(DeclarationDispatchCountryBuilder.getDefault())
                .withDestinationCountry(DeclarationDestinationCountryBuilder.getDefault())
                .withConsigneeTurn(DEFAULT_CONSIGNEE_TURN)
                .withConsigneeNadName(DEFAULT_CONSIGNEE_NAD_NAME)
                .withConsigneeNadPostcode(DEFAULT_CONSIGNEE_NAD_POSTCODE)
                .withConsignorTurn(DEFAULT_CONSIGNOR_TURN)
                .withConsignorEori(DEFAULT_CONSIGNOR_EORI);

    }

    public static DeclarationHeader getDefaultExport() {
        return getDefaultExportBuilder().build();
    }

    public static Builder getDefaultExportBuilder() {
        return builder()
                .withDeclarationId(DEFAULT_EXPORT_DECLARATION_ID)
                .withDeclarationSource(SOURCE_MSS)
                .withImportExportIndicator(EXPORT_TYPE)
                .withEpuNumber(DEFAULT_EPU_NUMBER)
                .withEntryNumber(DEFAULT_ENTRY_NUMBER)
                .withEntryDate(DEFAULT_ENTRY_DATE)
                .withGoodsLocation(DEFAULT_GOODS_LOCATION)
                .withTransportModeCode(DEFAULT_TRANSPORT_MODE_CODE)
                .withRoute(DEFAULT_ROUTE)
                .withDispatchCountry(DeclarationDispatchCountryBuilder.getDefault())
                .withDestinationCountry(DeclarationDestinationCountryBuilder.getDefault())
                .withConsignorTurn(DEFAULT_CONSIGNOR_TURN)
                .withConsignorNadName(DEFAULT_CONSIGNOR_NAD_NAME)
                .withConsignorNadPostcode(DEFAULT_CONSIGNOR_NAD_POSTCODE);
    }

    public static DeclarationHeader getRandomImport() {
        return getRandomImportBuilder().build();
    }

    public static DeclarationHeaderBuilder.Builder getRandomImportBuilder() {
        return builder()
                .withDeclarationId(faker.getRandomDeclarationId())
                .withDeclarationSource(SOURCE_MSS)
                .withImportExportIndicator(IMPORT_TYPE)
                .withEpuNumber(faker.getRandomEpu())
                .withEntryNumber(faker.getRandomEntryNumber())
                .withEntryDate(faker.getRandomEntryDate())
                .withGoodsLocation(faker.getRandomGoodsLocation())
                .withTransportModeCode(faker.getRandomModeOfTransport())
                .withRoute(faker.getRandomRouteOfEntry())
                .withDispatchCountry(DeclarationDispatchCountryBuilder.getRandom())
                .withDestinationCountry(DeclarationDestinationCountryBuilder.getRandom())
                .withConsigneeTurn(faker.getRandomImporterTurn())
                .withConsigneeNadName(faker.getRandomConsigneeName())
                .withConsigneeNadPostcode(faker.getRandomConsigneePostcode());
    }
}