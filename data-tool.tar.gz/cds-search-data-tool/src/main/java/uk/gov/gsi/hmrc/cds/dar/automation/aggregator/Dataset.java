package uk.gov.gsi.hmrc.cds.dar.automation.aggregator;

import uk.gov.gsi.hmrc.cds.dar.automation.entities.Declaration;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class Dataset {

    private static StringBuilder jsonDeclarations = new StringBuilder();
    private static List<Declaration> declarations = new ArrayList<>();

    public static StringBuilder buildJsonDatasetForFreeTextSearch() {
        declarations.add(DeclarationAggregator.buildDefaultImportDeclaration());
        declarations.add(DeclarationAggregator.buildDefaultExportDeclaration());
        declarations.add(DeclarationAggregator.buildDefaultHeaderOnlyDeclaration());
        declarations.add(DeclarationAggregator.buildDefaultWithSequentialLines(20));
        declarations.add(DeclarationAggregator.buildRandomDeclarationWithSpecialChars(1));
        declarations.add(DeclarationAggregator.buildOriginCountryDeclarations(2));
        declarations.add(DeclarationAggregator.buildOriginCountryDeclarations(3));
        declarations.add(DeclarationAggregator.buildEmptyOriginCountryDeclarations(1));
        declarations.add(DeclarationAggregator.buildEmptyOriginCountryDeclarations(2));
        return buildJsonBody(declarations);
    }

    public static StringBuilder buildJsonDatasetForEntryDateFilter() {
        declarations.addAll(DeclarationAggregator.buildEntryDateDataForDate(20, "2016-01-01 00:00:00.00"));
        declarations.addAll(DeclarationAggregator.buildEntryDateDataForDate(15, "2016-04-01 00:00:00.0"));
        declarations.addAll(DeclarationAggregator.buildEntryDateDataForDate(10, "2016-08-01 00:00:00.0"));
        declarations.addAll(DeclarationAggregator.buildEntryDateDataForDate(5, "2016-12-01 00:00:00.0"));
        return buildJsonBody(declarations);
    }

    public static StringBuilder buildJsonDatasetForClearanceDateFilter() {
        declarations.addAll(DeclarationAggregator.buildClearanceDateDataForDate(20, "2016-01-01 00:00:00.00"));
        declarations.addAll(DeclarationAggregator.buildClearanceDateDataForDate(25, "2016-04-01 00:00:00.0"));
        declarations.addAll(DeclarationAggregator.buildClearanceDateDataForDate(30, "2016-08-01 00:00:00.0"));
        declarations.addAll(DeclarationAggregator.buildClearanceDateDataForDate(8, "2016-12-01 00:00:00.0"));
        return buildJsonBody(declarations);
    }

    public static StringBuilder buildJsonDatasetForOriginCountryFacet() {
        declarations.addAll(DeclarationAggregator.buildOriginCountryDataForCountryCode(100, "NL"));
        declarations.addAll(DeclarationAggregator.buildOriginCountryDataForCountryCode(50, "BR"));
        declarations.addAll(DeclarationAggregator.buildOriginCountryDataForCountryCode(25, "GR"));
        declarations.addAll(DeclarationAggregator.buildOriginCountryDataForCountryCode(25, "CA"));
        declarations.addAll(DeclarationAggregator.buildOriginCountryDataForCountryCode(15, "CN"));
        declarations.addAll(DeclarationAggregator.buildOriginCountryDataForCountryCode(15, "US"));
        declarations.addAll(DeclarationAggregator.buildOriginCountryDataForCountryCode(15, "YE"));
        declarations.addAll(DeclarationAggregator.buildOriginCountryDataForCountryCode(10, "SE"));
        declarations.addAll(DeclarationAggregator.buildOriginCountryDataForCountryCode(10, "SG"));
        declarations.addAll(DeclarationAggregator.buildOriginCountryDataForCountryCode(10, "PL"));
        declarations.addAll(DeclarationAggregator.buildOriginCountryDataForCountryCode(10, "NO"));
        declarations.addAll(DeclarationAggregator.buildOriginCountryDataForCountryCode(8, ""));
        declarations.addAll(DeclarationAggregator.buildOriginCountryDataForCountryCode(5, "LV"));
        declarations.addAll(DeclarationAggregator.buildOriginCountryDataForCountryCode(2, "MX"));
        return buildJsonBody(declarations);
    }

    public static StringBuilder buildJsonDatasetForDispatchCountryFacet() {
        declarations.addAll(DeclarationAggregator.buildDispatchCountryDataForCountryCode(100, "NL"));
        declarations.addAll(DeclarationAggregator.buildDispatchCountryDataForCountryCode(50, "BR"));
        declarations.addAll(DeclarationAggregator.buildDispatchCountryDataForCountryCode(25, "GR"));
        declarations.addAll(DeclarationAggregator.buildDispatchCountryDataForCountryCode(25, "CA"));
        declarations.addAll(DeclarationAggregator.buildDispatchCountryDataForCountryCode(15, "CN"));
        declarations.addAll(DeclarationAggregator.buildDispatchCountryDataForCountryCode(15, "US"));
        declarations.addAll(DeclarationAggregator.buildDispatchCountryDataForCountryCode(15, "YE"));
        declarations.addAll(DeclarationAggregator.buildDispatchCountryDataForCountryCode(10, "SE"));
        declarations.addAll(DeclarationAggregator.buildDispatchCountryDataForCountryCode(10, "SG"));
        declarations.addAll(DeclarationAggregator.buildDispatchCountryDataForCountryCode(10, "PL"));
        declarations.addAll(DeclarationAggregator.buildDispatchCountryDataForCountryCode(10, "NO"));
        declarations.addAll(DeclarationAggregator.buildDispatchCountryDataForCountryCode(8, ""));
        declarations.addAll(DeclarationAggregator.buildDispatchCountryDataForCountryCode(5, "LV"));
        declarations.addAll(DeclarationAggregator.buildDispatchCountryDataForCountryCode(2, "MX"));
        return buildJsonBody(declarations);
    }

    public static StringBuilder buildJsonDatasetForDestinationCountryFacet() {
        declarations.addAll(DeclarationAggregator.buildDestinationCountryDataForCountryCode(100, "NL"));
        declarations.addAll(DeclarationAggregator.buildDestinationCountryDataForCountryCode(50, "BR"));
        declarations.addAll(DeclarationAggregator.buildDestinationCountryDataForCountryCode(25, "GR"));
        declarations.addAll(DeclarationAggregator.buildDestinationCountryDataForCountryCode(25, "CA"));
        declarations.addAll(DeclarationAggregator.buildDestinationCountryDataForCountryCode(15, "CN"));
        declarations.addAll(DeclarationAggregator.buildDestinationCountryDataForCountryCode(15, "US"));
        declarations.addAll(DeclarationAggregator.buildDestinationCountryDataForCountryCode(15, "YE"));
        declarations.addAll(DeclarationAggregator.buildDestinationCountryDataForCountryCode(10, "SE"));
        declarations.addAll(DeclarationAggregator.buildDestinationCountryDataForCountryCode(10, "SG"));
        declarations.addAll(DeclarationAggregator.buildDestinationCountryDataForCountryCode(10, "PL"));
        declarations.addAll(DeclarationAggregator.buildDestinationCountryDataForCountryCode(10, "NO"));
        declarations.addAll(DeclarationAggregator.buildDestinationCountryDataForCountryCode(8, ""));
        declarations.addAll(DeclarationAggregator.buildDestinationCountryDataForCountryCode(5, "LV"));
        declarations.addAll(DeclarationAggregator.buildDestinationCountryDataForCountryCode(2, "MX"));
        return buildJsonBody(declarations);
    }

    public static StringBuilder buildJsonDatasetForModeOfTransport() {
        declarations.addAll(DeclarationAggregator.buildModeOfTransport(50, 0));
        declarations.addAll(DeclarationAggregator.buildModeOfTransport(45, 1));
        declarations.addAll(DeclarationAggregator.buildModeOfTransport(42, 2));
        declarations.addAll(DeclarationAggregator.buildModeOfTransport(40, 3));
        declarations.addAll(DeclarationAggregator.buildModeOfTransport(37, 4));
        declarations.addAll(DeclarationAggregator.buildModeOfTransport(35, 5));
        declarations.addAll(DeclarationAggregator.buildModeOfTransport(27, 7));
        declarations.addAll(DeclarationAggregator.buildModeOfTransport(15, 8));
        declarations.addAll(DeclarationAggregator.buildModeOfTransport(8, 9));
        return buildJsonBody(declarations);
    }

    public static StringBuilder buildJsonDatasetForConsigneeEORI() {
        declarations.addAll(DeclarationAggregator.buildconsigneeEORI(50, "111111111111"));
        declarations.addAll(DeclarationAggregator.buildconsigneeEORI(45, "111122221122"));
        return buildJsonBody(declarations);
    }

    public static StringBuilder buildJsonDatasetForConsignorEORI() {
        declarations.addAll(DeclarationAggregator.buildconsignorEORI(25, "111133331111"));
        declarations.addAll(DeclarationAggregator.buildconsignorEORI(55, "444444444444"));
        return buildJsonBody(declarations);
    }

    public static StringBuilder buildJsonDatasetForGoodsLocation() {
        declarations.addAll(DeclarationAggregator.buildGoodsLocation(100, "BOS"));
        declarations.addAll(DeclarationAggregator.buildGoodsLocation(50, "EXE"));
        declarations.addAll(DeclarationAggregator.buildGoodsLocation(25, "HEY"));
        declarations.addAll(DeclarationAggregator.buildGoodsLocation(25, "ELF"));
        declarations.addAll(DeclarationAggregator.buildGoodsLocation(15, "GOO"));
        declarations.addAll(DeclarationAggregator.buildGoodsLocation(15, "PEN"));
        declarations.addAll(DeclarationAggregator.buildGoodsLocation(15, "COW"));
        declarations.addAll(DeclarationAggregator.buildGoodsLocation(10, "PHD"));
        declarations.addAll(DeclarationAggregator.buildGoodsLocation(10, "MON"));
        declarations.addAll(DeclarationAggregator.buildGoodsLocation(10, "PAR"));
        declarations.addAll(DeclarationAggregator.buildGoodsLocation(10, "MED"));
        declarations.addAll(DeclarationAggregator.buildGoodsLocation(5, "GLA"));
        declarations.addAll(DeclarationAggregator.buildGoodsLocation(3, "LOW"));
        declarations.addAll(DeclarationAggregator.buildGoodsLocation(2, ""));
        return buildJsonBody(declarations);
    }

    public static StringBuilder buildJsonDatasetForCommodityCode() {
        declarations.addAll(DeclarationAggregator.buildDeclarationsWithIncrementalCommodityCodes(100, new BigInteger("8542000000")));
        declarations.addAll(DeclarationAggregator.buildDeclarationsWithIncrementalCommodityCodes(75, new BigInteger("0805000000")));
        declarations.addAll(DeclarationAggregator.buildDeclarationsWithIncrementalCommodityCodes(50, new BigInteger("2008000000")));
        declarations.addAll(DeclarationAggregator.buildDeclarationsWithIncrementalCommodityCodes(30, new BigInteger("2204000000")));
        declarations.addAll(DeclarationAggregator.buildDeclarationsWithIncrementalCommodityCodes(20, new BigInteger("0304000000")));
        declarations.addAll(DeclarationAggregator.buildDeclarationsWithIncrementalCommodityCodes(10, new BigInteger("0809000000")));
        declarations.addAll(DeclarationAggregator.buildDeclarationsWithIncrementalCommodityCodes(5, new BigInteger("2009000000")));
        declarations.addAll(DeclarationAggregator.buildDeclarationsWithIncrementalCommodityCodes(1, new BigInteger("2009100000")));
        declarations.addAll(DeclarationAggregator.buildDeclarationsWithIncrementalCommodityCodes(1, new BigInteger("2009200000")));
        declarations.addAll(DeclarationAggregator.buildDeclarationsWithIncrementalCommodityCodes(1, new BigInteger("2009300000")));
        declarations.addAll(DeclarationAggregator.buildDeclarationsWithIncrementalCommodityCodes(1, new BigInteger("2009400000")));
        declarations.add(DeclarationAggregator.buildTwoLinesWithFixedCommodityCodes("3009400000", "3009400000"));
        declarations.add(DeclarationAggregator.buildTwoLinesWithFixedCommodityCodes("3009400000", "3009400001"));
        declarations.add(DeclarationAggregator.buildTwoLinesWithFixedCommodityCodes("3009400000", "9999400000"));
        return buildJsonBody(declarations);
    }

    public static StringBuilder buildJsonDatasetForAllFilters() {
        declarations.addAll(DeclarationAggregator.buildDataForAllFilters(12, "PK", "ES", "AF"));
        declarations.addAll(DeclarationAggregator.buildDataForAllFilters(12, "PK", "ES", "AU"));
        declarations.addAll(DeclarationAggregator.buildDataForAllFilters(12, "PK", "QA", "LV"));
        declarations.addAll(DeclarationAggregator.buildDataForAllFilters(12, "PK", "QA", "SG"));
        declarations.addAll(DeclarationAggregator.buildDataForAllFilters(12, "PK", "CA", "BR"));
        declarations.addAll(DeclarationAggregator.buildDataForAllFilters(12, "PK", "CA", "IN"));
        declarations.addAll(DeclarationAggregator.buildDataForAllFilters(12, "NL", "GR", "MA"));
        declarations.addAll(DeclarationAggregator.buildDataForAllFilters(12, "NL", "GR", "LB"));
        declarations.addAll(DeclarationAggregator.buildDataForAllFilters(12, "NL", "JP", "RU"));
        declarations.addAll(DeclarationAggregator.buildDataForAllFilters(12, "NL", "JP", "US"));
        declarations.addAll(DeclarationAggregator.buildDataForAllFilters(12, "NL", "PL", "GB"));
        declarations.addAll(DeclarationAggregator.buildDataForAllFilters(12, "NL", "PL", "IE"));
        return buildJsonBody(declarations);
    }

    public static StringBuilder buildJsonDeclarationWithMaxLines() {
        declarations.add(DeclarationAggregator.buildRandomDeclarationWithSpecialChars(99));
        declarations.add(DeclarationAggregator.buildRandomDeclarationWithSpecialChars(999));
        return buildJsonBody(declarations);
    }

    public static StringBuilder buildMultipleDefaultJsonDataset() {
        List<Declaration> declarations = DeclarationAggregator.buildDefaultWithSequentialDeclarationId(250);
        return buildJsonBody(declarations);
    }

    private static StringBuilder buildJsonBody(List<Declaration> declarations) {
        declarations.forEach(
                declaration ->
                        jsonDeclarations.append("{ \"index\":{ \"_id\": \"" + declaration.getDeclarationId() + "\" } }\n" + declaration.toJSON() + "\n")
        );
        return jsonDeclarations;
    }
}
