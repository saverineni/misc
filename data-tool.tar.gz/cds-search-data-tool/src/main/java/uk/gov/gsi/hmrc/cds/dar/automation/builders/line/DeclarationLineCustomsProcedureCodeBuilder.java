package uk.gov.gsi.hmrc.cds.dar.automation.builders.line;

import uk.gov.gsi.hmrc.cds.dar.automation.entities.line.DeclarationLineCustomsProcedureCode;
import uk.gov.gsi.hmrc.cds.dar.automation.data.Faker;

public class DeclarationLineCustomsProcedureCodeBuilder {

    private static final String DEFAULT_CPC = "0611000";
    private static Faker faker = new Faker();

    public static Builder builder() {
        return new DeclarationLineCustomsProcedureCodeBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private DeclarationLineCustomsProcedureCode declarationLineCustomsProcedureCode = new DeclarationLineCustomsProcedureCode();

        public DeclarationLineCustomsProcedureCodeBuilder.Builder withCustomsProcedureCode(String cpc) {
            declarationLineCustomsProcedureCode.setCpc(cpc);
            return this;
        }

        public DeclarationLineCustomsProcedureCode build() {
            return declarationLineCustomsProcedureCode;
        }
    }

    public static DeclarationLineCustomsProcedureCode getDefault() {
        return defaultBuilder().build();
    }

    private static Builder defaultBuilder() {
        return builder()
                .withCustomsProcedureCode(DEFAULT_CPC);
    }
}