package uk.gov.gsi.hmrc.cds.dar.automation.builders.header;

import javafx.util.Pair;
import uk.gov.gsi.hmrc.cds.dar.automation.data.Faker;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.DeclarationDispatchCountry;

public class DeclarationDispatchCountryBuilder {
    private static final String DEFAULT_COUNTRY_CODE = "PK";
    private static Faker faker = new Faker();

    public static DeclarationDispatchCountryBuilder.Builder builder() {
        return new DeclarationDispatchCountryBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private DeclarationDispatchCountry declarationDispatchCountry = new DeclarationDispatchCountry();

        public DeclarationDispatchCountryBuilder.Builder withDispatchCountryCode(String countryCode) {
            declarationDispatchCountry.setCode(countryCode);
            return this;
        }

        public DeclarationDispatchCountry build() {
            return declarationDispatchCountry;
        }
    }

    public static DeclarationDispatchCountry getDefault() {
        return defaultBuilder().build();
    }

    public static DeclarationDispatchCountryBuilder.Builder defaultBuilder() {
        return builder()
                .withDispatchCountryCode(DEFAULT_COUNTRY_CODE);
    }

    public static DeclarationDispatchCountry getRandom() {
        Pair<String, String> randomCountryPair = faker.getRandomOriginCountry();

        return builder()
                .withDispatchCountryCode(randomCountryPair.getKey())
                .build();
    }

    public static DeclarationDispatchCountry getCountryFor(String countryCode) {
        Pair<String, String> countryPair = faker.getCountry(countryCode);

        return builder()
                .withDispatchCountryCode(countryCode)
                .build();
    }
}
