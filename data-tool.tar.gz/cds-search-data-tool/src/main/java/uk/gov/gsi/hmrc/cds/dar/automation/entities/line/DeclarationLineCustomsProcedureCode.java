package uk.gov.gsi.hmrc.cds.dar.automation.entities.line;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.json.EqualsHashCodeToString;

@Data
public class DeclarationLineCustomsProcedureCode extends EqualsHashCodeToString {

    String cpc;
}
