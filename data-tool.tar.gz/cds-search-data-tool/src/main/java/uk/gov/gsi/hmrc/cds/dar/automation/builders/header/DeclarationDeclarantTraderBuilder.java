package uk.gov.gsi.hmrc.cds.dar.automation.builders.header;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.trader.DeclarantTrader;

public class DeclarationDeclarantTraderBuilder {

    private static final String DEFAULT_DECLARANT_TRADER_TURN = "310098765123";
    private static final String DEFAULT_DECLARANT_TRADER_CURRENT_IND = "Y";
    private static final String DEFAULT_DECLARANT_TRADER_NAME = "12 Group";
    private static final String DEFAULT_DECLARANT_TRADER_SIMPLIFIED_PROCEDURE_AUTHORISATIONS = "JKS";
    private static final String DEFAULT_DECLARANT_TRADER_NAME_ABBREVIATED = "Declarant Turn 12 Ltd";


    public static Builder builder() {
        return new DeclarationDeclarantTraderBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private DeclarantTrader declarantTrader = new DeclarantTrader();

        public DeclarationDeclarantTraderBuilder.Builder withDeclarantTurn(String turn) {
            declarantTrader.setDeclarant_trader_turn(turn);
            return this;
        }

        public DeclarationDeclarantTraderBuilder.Builder withDeclarantCurrentInd(String currentInd) {
            declarantTrader.setCurrent_ind(currentInd);
            return this;
        }

        public DeclarationDeclarantTraderBuilder.Builder withDeclarantName(String name) {
            declarantTrader.setName(name);
            return this;
        }

        public DeclarationDeclarantTraderBuilder.Builder withDeclarantSimplifiedProcedureAuthorisations(String simplifiedProcedureAuthorisations) {
            declarantTrader.setSimplified_procedure_authorisations(simplifiedProcedureAuthorisations);
            return this;
        }

        public DeclarationDeclarantTraderBuilder.Builder withDeclarantNameAbbreviated(String nameAbbreviated) {
            declarantTrader.setTrader_name_abbreviated(nameAbbreviated);
            return this;
        }

        public DeclarantTrader build(){
            return declarantTrader;
        }
    }

    public static DeclarantTrader getDefault() {
        return defaultBuilder().build();
    }

    public static DeclarationDeclarantTraderBuilder.Builder defaultBuilder() {
        return builder()
                .withDeclarantTurn(DEFAULT_DECLARANT_TRADER_TURN)
                .withDeclarantCurrentInd(DEFAULT_DECLARANT_TRADER_CURRENT_IND)
                .withDeclarantName(DEFAULT_DECLARANT_TRADER_NAME)
                .withDeclarantSimplifiedProcedureAuthorisations(DEFAULT_DECLARANT_TRADER_SIMPLIFIED_PROCEDURE_AUTHORISATIONS)
                .withDeclarantNameAbbreviated(DEFAULT_DECLARANT_TRADER_NAME_ABBREVIATED);
    }
}
