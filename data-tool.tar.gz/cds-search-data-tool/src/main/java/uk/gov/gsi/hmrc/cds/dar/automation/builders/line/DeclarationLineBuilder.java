package uk.gov.gsi.hmrc.cds.dar.automation.builders.line;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.line.*;
import uk.gov.gsi.hmrc.cds.dar.automation.data.Faker;

import java.util.ArrayList;
import java.util.List;

public class DeclarationLineBuilder {

    private static final String DEFAULT_DECLARATION_ID = "100000000000000007786";
    private static final int DEFAULT_ITEM_NUMBER = 1;
    private static final String DEFAULT_CLEARANCE_DATETIME = "2017-12-10 08:10:49.33";
    private static final String DEFAULT_ITEM_ROUTE = "3";
    private static final String DEFAULT_DISPATCH_COUNTRY_CODE = "PK";
    private static final String DEFAULT_DESTINATION_COUNTRY_CODE = "GB";
    private static final String DEFAULT_CPC = "0611786";
    private static final String DEFAULT_COMMODITY_CODE = "8542199999";
    private static final String DEFAULT_CONSIGNEE_TURN = "110098765321";
    private static final String DEFAULT_ITEM_CONSIGNEE_NAD_NAME = "Item Consignee Name";
    private static final String DEFAULT_CONSIGNEE_NAD_POSTCODE = "OL16 2JU";
    private static final String DEFAULT_CONSIGNOR_TURN = "210098765321";
    private static final String DEFAULT_CONSIGNEE_EORI = "210025765321";
    private static final String DEFAULT_CONSIGNOR_EORI = "212131314141";
    private static final String DEFAULT_ITEM_CONSIGNOR_NAD_NAME = "Item Consignor Name";
    private static final String DEFAULT_CONSIGNOR_NAD_POSTCODE = "M6 5RY";

    private static final String DEFAULT_ITEM_STATISTICAL_VALUE = "686.58";
    private static final String DEFAULT_CUSTOMS_DUTY_PAID = "22.22";
    private static final String DEFAULT_VAT_PAID = "22.22";
    private static final String DEFAULT_EC_SUPPLEMENTARY_1 = "A118";
    private static final String DEFAULT_ITEM_CUSTOMS_VALUE = "258.56";
    private static final String DEFAULT_ITEM_NET_MASS = "558.66";
    private static final String DEFAULT_ITEM_SUPPLEMENTARY_UNITS = "50.65";
    private static final String DEFAULT_GOODS_DESCRIPTION = "1200 2 DESC";
    private static final String DEFAULT_ITEM_CUSTOMS_CHECK_CODE = "ABPR";
    private static final String DEFAULT_ITEM_MIC_CODE = "AAEE";
    private static final String DEFAULT_ITEM_PROFILE_ID = "AC";
    private static final String DEFAULT_VAT_VALUE = "100.00";
    private static final String DEFAULT_ITEM_PRICE_DECLARED = "700.30";
    private static Faker faker = new Faker();

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        public Builder() {}

        private DeclarationLine declarationLine = new DeclarationLine();
        private List<DeclarationLineAdditionalInfo> additionalInfoList = new ArrayList<>();
        private List<DeclarationLineDocument> documentList = new ArrayList<>();
        private List<DeclarationLinePreviousDocument> previousDocumentList = new ArrayList<>();
        private List<DeclarationLineTaxLine> taxLineList = new ArrayList<>();

//        public Builder withDeclarationId(String entryReference) {
//            declarationLine.setDeclarationId(entryReference);
//            return this;
//        }

        public Builder withItemNumber(int itemNumber) {
            declarationLine.setItemNumber(itemNumber);
            return this;
        }

        public Builder withItemRoute(String itemRoute) {
            declarationLine.setItemRoute(itemRoute);
            return this;
        }

        public Builder withClearanceDatetime(String clearanceDatetime) {
            declarationLine.setClearanceDate(clearanceDatetime);
            return this;
        }

        public Builder withCpc(String cpc) {
            declarationLine.setCpc(cpc);
            return this;
        }

        public Builder withCommodityCode(String commodityCode) {
            declarationLine.setCommodityCode(commodityCode);
            return this;
        }

//        public Builder withItemStatisticalValue(String itemStatisticalValue) {
//            declarationLine.setItem_statistical_value(itemStatisticalValue);
//            return this;
//        }
//
//        public Builder withCustomsDutyPaid(String customsDutyPaid) {
//            declarationLine.setCustoms_duty_paid(customsDutyPaid);
//            return this;
//        }
//
//        public Builder withVatValue(String vatValue) {
//            declarationLine.setVat_value(vatValue);
//            return this;
//        }
//
//        public Builder withVatPaid(String vatPaid) {
//            declarationLine.setVat_paid(vatPaid);
//            return this;
//        }
//
//        public Builder withEcSupplementary1(String ecSupplementary1) {
//            declarationLine.setEc_supplementary_1(ecSupplementary1);
//            return this;
//        }
//
//        public Builder withItemCustomsValue(String itemCustomsValue) {
//            declarationLine.setItem_customs_value(itemCustomsValue);
//            return this;
//        }
//
//        public Builder withItemNetMass(String itemNetMass) {
//            declarationLine.setItem_net_mass(itemNetMass);
//            return this;
//        }
//
//        public Builder withItemSupplementaryUnits(String itemSupplementaryUnits) {
//            declarationLine.setItem_supplementary_units(itemSupplementaryUnits);
//            return this;
//        }
//
//        public Builder withGoodsDecription(String goodsDecription) {
//            declarationLine.setGoods_description(goodsDecription);
//            return this;
//        }
//
//        public Builder withItemCustomsCheckCode(String itemCustomsCheckCode) {
//            declarationLine.setItem_customs_check_code(itemCustomsCheckCode);
//            return this;
//        }
//
//        public Builder withItemMicCode(String itemMicCode) {
//            declarationLine.setItem_mic_code(itemMicCode);
//            return this;
//        }
//
//        public Builder withItemProfileId(String itemProfileId) {
//            declarationLine.setItem_profile_id(itemProfileId);
//            return this;
//        }

        public Builder withItemConsignorTurn(String itemConsignorTurn) {
            declarationLine.setItemConsignorTurn(itemConsignorTurn);
            return this;
        }

        public Builder withItemConsignorNadName(String itemConsignorNadName) {
            declarationLine.setItemConsignorName(itemConsignorNadName);
            return this;
        }

        public Builder withItemConsignorNadPostCode(String itemConsignorNadPostCode) {
            declarationLine.setItemConsignorPostcode(itemConsignorNadPostCode);
            return this;
        }

        public Builder withItemConsigneeTurn(String itemConsigneeTurn) {
            declarationLine.setItemConsigneeTurn(itemConsigneeTurn);
            return this;
        }

        public Builder withItemConsigneeEori(String itemConsigneeEori) {
            declarationLine.setItemConsigneeTurn(itemConsigneeEori);
            return this;
        }

        public Builder withItemConsignorEori(String itemConsignorEori) {
            declarationLine.setItemConsignorTurn(itemConsignorEori);
            return this;
        }

        public Builder withItemConsigneeNadName(String itemConsigneeNadName) {
            declarationLine.setItemConsigneeName(itemConsigneeNadName);
            return this;
        }

        public Builder withItemConsigneeNadPostCode(String itemConsigneeNadPostCode) {
            declarationLine.setItemConsigneePostcode(itemConsigneeNadPostCode);
            return this;
        }

        public Builder withOriginCountry(DeclarationLineOriginCountry originCountry) {
            declarationLine.setOriginCountry(originCountry);
            return this;
        }

        public Builder withItemDispatchCountry(DeclarationLineDispatchCountry dispatchCountry) {
            declarationLine.setItemDispatchCountry(dispatchCountry);
            return this;
        }

        public Builder withItemDestinationCountry(DeclarationLineDestinationCountry destinationCountry) {
            declarationLine.setItemDestinationCountry(destinationCountry);
            return this;
        }

//        public Builder withItemPriceDeclared(String itemPriceDeclared) {
//            declarationLine.setItem_price_declared(itemPriceDeclared);
//            return this;
//        }
//
//        public Builder addAdditionalInfo(DeclarationLineAdditionalInfo declarationLineAdditionalInfo) {
//            if (declarationLine.getAdditionalInfo() == null) {
//                declarationLine.setAdditionalInfo(additionalInfoList);
//            }
//            declarationLine.getAdditionalInfo().add(declarationLineAdditionalInfo);
//            return this;
//        }
//
//        public Builder addDocument(DeclarationLineDocument declarationLineDocument) {
//            if (declarationLine.getDocuments() == null) {
//                declarationLine.setDocuments(documentList);
//            }
//            declarationLine.getDocuments().add(declarationLineDocument);
//            return this;
//        }
//
//        public Builder addPreviousDocument(DeclarationLinePreviousDocument declarationLinePreviousDocument) {
//            if (declarationLine.getPreviousDocuments() == null) {
//                declarationLine.setPreviousDocuments(previousDocumentList);
//            }
//            declarationLine.getPreviousDocuments().add(declarationLinePreviousDocument);
//            return this;
//        }
//
//        // TODO Collections should always have AddAll, Remove and RemoveAll
//        public Builder addAddTaxLine(DeclarationLineTaxLine declarationLineTaxLine) {
//            if (declarationLine.getTaxLines() == null) {
//                declarationLine.setTaxLines(taxLineList);
//            }
//            declarationLine.getTaxLines().add(declarationLineTaxLine);
//            return this;
//        }
//
//        public Builder withCustomsProcedureCode(DeclarationLineCustomsProcedureCode customsProcedureCode) {
//            declarationLine.setCustomsProcedureCode(customsProcedureCode);
//            return this;
//        }
//
//        public Builder withCommodity(DeclarationLineCommodity commodity) {
//            declarationLine.setCommodity(commodity);
//            return this;
//        }
//

//
//        public Builder withImporterTrader(DeclarationLinesImporterTrader importerTrader) {
//            declarationLine.setImporterTrader(importerTrader);
//            return this;
//        }

        public DeclarationLine build() {
            return declarationLine;
        }
    }

    public static DeclarationLine getDefaultImport(){
        return getDefaultImportBuilder().build();
    }

    public static Builder getDefaultImportBuilder() {
        return builder()
//                .withDeclarationId(DEFAULT_DECLARATION_ID)
                .withItemNumber(DEFAULT_ITEM_NUMBER)
                .withItemRoute(DEFAULT_ITEM_ROUTE)
                .withItemDispatchCountry(DeclarationLineDispatchCountryBuilder.getDefault())
                .withItemDestinationCountry(DeclarationLineDestinationCountryBuilder.getDefault())
                .withClearanceDatetime(DEFAULT_CLEARANCE_DATETIME)
                .withCpc(DEFAULT_CPC)
                .withCommodityCode(DEFAULT_COMMODITY_CODE)
                .withItemConsigneeTurn(DEFAULT_CONSIGNEE_TURN)
                .withItemConsigneeEori(DEFAULT_CONSIGNEE_EORI)
                .withItemConsignorEori(DEFAULT_CONSIGNOR_EORI)
                .withItemConsigneeNadName(DEFAULT_ITEM_CONSIGNEE_NAD_NAME)
                .withItemConsigneeNadPostCode(DEFAULT_CONSIGNEE_NAD_POSTCODE)
                .withOriginCountry(DeclarationLineOriginCountryBuilder.getDefault());

//                .withItemStatisticalValue(DEFAULT_ITEM_STATISTICAL_VALUE)
//                .withCustomsDutyPaid(DEFAULT_CUSTOMS_DUTY_PAID)
//                .withVatPaid(DEFAULT_VAT_PAID)
//                .withEcSupplementary1(DEFAULT_EC_SUPPLEMENTARY_1)
//                .withItemCustomsValue(DEFAULT_ITEM_CUSTOMS_VALUE)
//                .withItemNetMass(DEFAULT_ITEM_NET_MASS)
//                .withItemSupplementaryUnits(DEFAULT_ITEM_SUPPLEMENTARY_UNITS)
//                .withGoodsDecription(DEFAULT_GOODS_DESCRIPTION)
//                .withItemCustomsCheckCode(DEFAULT_ITEM_CUSTOMS_CHECK_CODE)
//                .withItemMicCode(DEFAULT_ITEM_MIC_CODE)
//                .withItemProfileId(DEFAULT_ITEM_PROFILE_ID)
//                  .withVatValue(DEFAULT_VAT_VALUE)
//                .withItemPriceDeclared(DEFAULT_ITEM_PRICE_DECLARED);
//                .withCustomsProcedureCode(DeclarationLineCustomsProcedureCodeBuilder.getDefault())
//                .withCommodity(DeclarationLineCommodityBuilder.getDefault())
//                .withImporterTrader(DeclarationLineImporterTraderBuilder.getDefault())
//                .addDocument(DeclarationLineDocumentBuilder.getDefault())
//                .addAddTaxLine(DeclarationLineTaxLineBuilder.getDefault())
//                .addAdditionalInfo(DeclarationLineAddtionalInfoBuilder.getDefault())
//                .addPreviousDocument(DeclarationLinePreviousDocumentBuilder.getDefault());
    }

    public static DeclarationLine getDefaultExport(){
        return getDefaultExportBuilder().build();
    }

    public static Builder getDefaultExportBuilder() {
        return builder()
//                .withDeclarationId(DEFAULT_DECLARATION_ID)
                .withItemNumber(DEFAULT_ITEM_NUMBER)
                .withItemRoute(DEFAULT_ITEM_ROUTE)
                .withItemDispatchCountry(DeclarationLineDispatchCountryBuilder.getDefault())
                .withItemDestinationCountry(DeclarationLineDestinationCountryBuilder.getDefault())
                .withClearanceDatetime(DEFAULT_CLEARANCE_DATETIME)
                .withCpc(DEFAULT_CPC)
                .withCommodityCode(DEFAULT_COMMODITY_CODE)
                .withItemConsignorTurn(DEFAULT_CONSIGNOR_TURN)
                .withItemConsignorNadName(DEFAULT_ITEM_CONSIGNOR_NAD_NAME)
                .withItemConsignorNadPostCode(DEFAULT_CONSIGNOR_NAD_POSTCODE)
                .withOriginCountry(DeclarationLineOriginCountryBuilder.getDefault());

    }

    public static DeclarationLine getRandomImport(){
        return getRandomImportBuilder().build();
    }

    public static DeclarationLineBuilder.Builder getRandomImportBuilder() {
        return builder()
//                .withDeclarationId(faker.getRandomEntryReference())
                .withItemNumber(1)
                .withItemRoute(faker.getRandomRouteOfEntry())
                .withItemDispatchCountry(DeclarationLineDispatchCountryBuilder.getRandom())
                .withItemDestinationCountry(DeclarationLineDestinationCountryBuilder.getRandom())
                .withClearanceDatetime(faker.getRandomClearanceDate())
                .withCpc(faker.getRandomCPC())
                .withCommodityCode(faker.getRandomCommodityCode())
                .withItemConsigneeTurn(faker.getRandomImporterTurn())
                .withItemConsigneeNadName(faker.getRandomConsigneeName())
                .withItemConsigneeNadPostCode(faker.getRandomConsigneePostcode())
                .withOriginCountry(DeclarationLineOriginCountryBuilder.getRandom());


//                .withItemStatisticalValue(faker.getRandomDouble())
//                .withCustomsDutyPaid(faker.getRandomDouble())
//                .withVatPaid(faker.getRandomDouble())
//                .withEcSupplementary1(DEFAULT_EC_SUPPLEMENTARY_1)
//                .withItemCustomsValue(faker.getRandomDouble())
//                .withItemNetMass(faker.getRandomDouble())
//                .withItemSupplementaryUnits(faker.getRandomDouble())
//                .withGoodsDecription(DEFAULT_GOODS_DESCRIPTION)
//                .withItemCustomsCheckCode(DEFAULT_ITEM_CUSTOMS_CHECK_CODE)
//                .withItemMicCode(DEFAULT_ITEM_MIC_CODE)
//                .withItemProfileId(DEFAULT_ITEM_PROFILE_ID)
//                .withVatValue(faker.getRandomDouble())
//                .withItemPriceDeclared(faker.getRandomDouble())
//                .withCustomsProcedureCode(DeclarationLineCustomsProcedureCodeBuilder.getDefault())
//                .withCommodity(DeclarationLineCommodityBuilder.getDefault())
//                .withImporterTrader(DeclarationLineImporterTraderBuilder.getDefault())
//                .addDocument(DeclarationLineDocumentBuilder.getDefault())
//                .addAddTaxLine(DeclarationLineTaxLineBuilder.getDefault())
//                .addAdditionalInfo(DeclarationLineAddtionalInfoBuilder.getDefault())
//                .addPreviousDocument(DeclarationLinePreviousDocumentBuilder.getDefault());
    }
}