package uk.gov.gsi.hmrc.cds.dar.automation.builders.line;

import uk.gov.gsi.hmrc.cds.dar.automation.entities.line.DeclarationLineTaxLine;

public class DeclarationLineTaxLineBuilder {

    private static final String DEFAULT_ENTRY_REFERENCE = "670-IM001A-2016-12-01";
    private static final String DEFAULT_SEQUENCE_NUMBER = "1";
    private static final String DEFAULT_GENERATION_NUMBER = "1";
    private static final String DEFAULT_WAIVED_TAX = "2.01";
    private static final String DEFAULT_METHOD_OF_PAYMENT = "P";
    private static final String DEFAULT_TAX_AMOUNT = "446.20";
    private static final String DEFAULT_TAX_TYPE_CODE = "425.00";

    public static Builder builder() {
        return new DeclarationLineTaxLineBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private DeclarationLineTaxLine taxLine = new DeclarationLineTaxLine();

        public DeclarationLineTaxLineBuilder.Builder withTaxLineEntryReference(String entryReference) {
            taxLine.setEntry_reference(entryReference);
            return this;
        }

        public DeclarationLineTaxLineBuilder.Builder withTaxLineSequenceNumber(String sequenceNumber) {
            taxLine.setTax_line_sequence_number(sequenceNumber);
            return this;
        }

        public DeclarationLineTaxLineBuilder.Builder withTaxLineGenerationNumber(String generationNumber) {
            taxLine.setSat_tax_line_generation_number(generationNumber);
            return this;
        }

        public DeclarationLineTaxLineBuilder.Builder withTaxLineWaivedTax(String waivedTax) {
            taxLine.setWaived_tax(waivedTax);
            return this;
        }

        public DeclarationLineTaxLineBuilder.Builder withTaxLineMethodOfPayment(String methodOfPayment) {
            taxLine.setMethod_of_payment_code(methodOfPayment);
            return this;
        }

        public DeclarationLineTaxLineBuilder.Builder withTaxLineTaxAmount(String taxAmount) {
            taxLine.setTax_amount(taxAmount);
            return this;
        }

        public DeclarationLineTaxLineBuilder.Builder withTaxLineTaxTypeCode(String taxTypeCode) {
            taxLine.setTax_type_code(taxTypeCode);
            return this;
        }

        public DeclarationLineTaxLine build() {
            return taxLine;
        }
    }

    public static DeclarationLineTaxLine getDefault() {
        return defaultBuilder().build();
    }

    private static Builder defaultBuilder() {
        return builder()
                .withTaxLineEntryReference(DEFAULT_ENTRY_REFERENCE)
                .withTaxLineSequenceNumber(DEFAULT_SEQUENCE_NUMBER)
                .withTaxLineGenerationNumber(DEFAULT_GENERATION_NUMBER)
                .withTaxLineWaivedTax(DEFAULT_WAIVED_TAX)
                .withTaxLineMethodOfPayment(DEFAULT_METHOD_OF_PAYMENT)
                .withTaxLineTaxAmount(DEFAULT_TAX_AMOUNT)
                .withTaxLineTaxTypeCode(DEFAULT_TAX_TYPE_CODE);
    }
}