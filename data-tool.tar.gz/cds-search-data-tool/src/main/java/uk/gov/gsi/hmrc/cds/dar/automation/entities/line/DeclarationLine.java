package uk.gov.gsi.hmrc.cds.dar.automation.entities.line;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.json.EqualsHashCodeToString;

@Data
public class DeclarationLine extends EqualsHashCodeToString {

    int itemNumber;
    String itemRoute;
    String clearanceDate;
    String cpc;
    String commodityCode;
    String itemConsigneeTurn;
    String itemConsigneeName;
    String itemConsigneePostcode;
    String itemConsignorTurn;
    String itemConsignorName;
    String itemConsignorPostcode;
    DeclarationLineOriginCountry originCountry;
    DeclarationLineDispatchCountry itemDispatchCountry;
    DeclarationLineDestinationCountry itemDestinationCountry;

//    String entryNumber;
//    String entryDate;
//    String declarationId;
//    String item_statistical_value;
//    String customs_duty_paid;
//    String vat_paid;
//    String ec_supplementary_1;
//    String item_customs_value;
//    String item_net_mass;
//    String item_supplementary_units;
//    String goods_description;
//    String item_customs_check_code;
//    String item_mic_code;
//    String item_profile_id;
//    String vat_value;
//    String item_price_declared;
//    DeclarationLineCustomsProcedureCode customsProcedureCode;
//    DeclarationLineCommodity commodity;
//    DeclarationLinesImporterTrader importerTrader;
//    List<DeclarationLineDocument> documents = Lists.newArrayList();
//    List<DeclarationLineTaxLine> taxLines = Lists.newArrayList();
//    List<DeclarationLineAdditionalInfo> additionalInfo = Lists.newArrayList();
//    List<DeclarationLinePreviousDocument> previousDocuments = Lists.newArrayList();
}
