package uk.gov.gsi.hmrc.cds.dar.automation.builders.line;


import uk.gov.gsi.hmrc.cds.dar.automation.entities.line.DeclarationLineCommodity;
import uk.gov.gsi.hmrc.cds.dar.automation.data.Faker;

public class DeclarationLineCommodityBuilder {

    private static final String DEFAULT_COMMODITY_CODE = "020230";
    private static final String DEFAULT_CC_YEAR = "2010";
    private static final String DEFAULT_CC_MONTH = "12";
    private static final String DEFAULT_HS_CHAPTER = "22";
    private static final String DEFAULT_HS_HEADING = "04";
    private static final String DEFAULT_HS_CHAPTER_HEADING = "2204";
    private static final String DEFAULT_HS_SUBHEADING = "21";
    private static final String DEFAULT_CHAPTER_DESCRIPTION = "MEAT AND EDIBLE MEAT OFFAL";
    private static final String DEFAULT_HEADING_DESCRIPTION = "Meat of bovine animals, frozen.";
    private static final String DEFAULT_SUBHEADING_DESCRIPTION = "Frozen, boneless meat of bovine animals";

    private static Faker faker = new Faker();

    public static Builder builder() {
        return new DeclarationLineCommodityBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private DeclarationLineCommodity declarationLineCommodity = new DeclarationLineCommodity();

        public DeclarationLineCommodityBuilder.Builder withCommodityCode(String commodityCode) {
            declarationLineCommodity.setCommodityCode(commodityCode);
            return this;
        }

        public DeclarationLineCommodityBuilder.Builder withCcYear(String ccYear) {
            declarationLineCommodity.setCc_year(ccYear);
            return this;
        }

        public DeclarationLineCommodityBuilder.Builder withCcMonth(String ccMonth) {
            declarationLineCommodity.setCc_month(ccMonth);
            return this;
        }

        public DeclarationLineCommodityBuilder.Builder withHsChapter(String hsChapter) {
            declarationLineCommodity.setHs_chapter(hsChapter);
            return this;
        }

        public DeclarationLineCommodityBuilder.Builder withHsHeading(String hsHeading) {
            declarationLineCommodity.setHs_heading(hsHeading);
            return this;
        }

        public DeclarationLineCommodityBuilder.Builder withHsChapterHeading(String hsChapterHeading) {
            declarationLineCommodity.setHs_chapter_heading(hsChapterHeading);
            return this;
        }

        public DeclarationLineCommodityBuilder.Builder withHsSubHeading(String hsSubHeading) {
            declarationLineCommodity.setHs_subheading(hsSubHeading);
            return this;
        }

        public DeclarationLineCommodityBuilder.Builder withChapterDescription(String chapterDescription) {
            declarationLineCommodity.setChapter_description(chapterDescription);
            return this;
        }

        public DeclarationLineCommodityBuilder.Builder withHeadingDescription(String headerDescription) {
            declarationLineCommodity.setHeading_description(headerDescription);
            return this;
        }

        public DeclarationLineCommodityBuilder.Builder withSubHeadingDescription(String subHeadingDescription) {
            declarationLineCommodity.setSubheading_description(subHeadingDescription);
            return this;
        }

        public DeclarationLineCommodity build() {
            return declarationLineCommodity;
        }
    }

    public static DeclarationLineCommodity getDefault() {
        return defaultBuilder().build();
    }

    public static Builder defaultBuilder() {
        return builder()
                .withCommodityCode(DEFAULT_COMMODITY_CODE)
                .withCcYear(DEFAULT_CC_YEAR)
                .withCcMonth(DEFAULT_CC_MONTH)
                .withHsChapter(DEFAULT_HS_CHAPTER)
                .withHsHeading(DEFAULT_HS_HEADING)
                .withHsChapterHeading(DEFAULT_HS_CHAPTER_HEADING)
                .withHsSubHeading(DEFAULT_HS_SUBHEADING)
                .withChapterDescription(DEFAULT_CHAPTER_DESCRIPTION)
                .withHeadingDescription(DEFAULT_HEADING_DESCRIPTION)
                .withSubHeadingDescription(DEFAULT_SUBHEADING_DESCRIPTION);
    }

    public static DeclarationLineCommodity getRandomCotton() {
        Builder defaultBuilder = defaultBuilder();
        return defaultBuilder
                .withCommodityCode(faker.getRandomCommodityCodeCotton())
                .withChapterDescription(faker.getRandomCommodityCottonChapterDescription())
                .withHeadingDescription(faker.getRandomCommodityCottonHeadingDescription())
                .withSubHeadingDescription(faker.getRandomCommodityCottonSubheadingDescription())
                .build();
    }

    public static DeclarationLineCommodity getRandomTurkey() {
        Builder defaultBuilder = defaultBuilder();
        return defaultBuilder
                .withCommodityCode(faker.getRandomCommodityCodeTurkey())
                .withChapterDescription(faker.getRandomCommodityTurkeyChapterDescription())
                .withHeadingDescription(faker.getRandomCommodityTurkeyHeadingDescription())
                .withSubHeadingDescription(faker.getRandomCommodityTurkeySubheadingDescription())
                .build();
    }
}
