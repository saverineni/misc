package uk.gov.gsi.hmrc.cds.dar.automation.builders;

import uk.gov.gsi.hmrc.cds.dar.automation.builders.header.DeclarationHeaderBuilder;
import uk.gov.gsi.hmrc.cds.dar.automation.builders.line.DeclarationLineBuilder;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.Declaration;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.DeclarationHeader;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.line.DeclarationLine;

import java.util.ArrayList;
import java.util.List;

public class DeclarationBuilder {

    public static Builder builder() {
        return new DeclarationBuilder.Builder();
    }

    public static class Builder {
        public Builder() {
        }

        private Declaration declaration = new Declaration();
        private List<DeclarationLine> declarationLineList = new ArrayList<>();

        public Builder withHeader(DeclarationHeader header) {
            declaration.setDeclarationSource(header.getDeclarationSource());
            declaration.setImportExportIndicator(header.getImportExportIndicator());
            declaration.setDeclarationId(header.getDeclarationId());
            declaration.setEpuNumber(header.getEpuNumber());
            declaration.setEntryNumber(header.getEntryNumber());
            declaration.setEntryDate(header.getEntryDate());
            declaration.setGoodsLocation(header.getGoodsLocation());
            declaration.setTransportModeCode(header.getTransportModeCode());
            declaration.setRoute(header.getRoute());
            declaration.setDispatchCountry(header.getDispatchCountry());
            declaration.setDestinationCountry(header.getDestinationCountry());
            declaration.setConsigneeTurn(header.getConsigneeTurn());
            //declaration.setConsigneeEori(header.getConsigneeEori());
            declaration.setConsigneeName(header.getConsigneeName());
            declaration.setConsigneePostcode(header.getConsigneePostcode());
            declaration.setConsignorTurn(header.getConsignorTurn());
            declaration.setConsignorName(header.getConsignorName());
            declaration.setConsignorPostcode(header.getConsignorPostcode());
            declaration.setDispatchCountry(header.getDispatchCountry());


            return this;
        }

        public DeclarationBuilder.Builder withLine(DeclarationLine declarationLine) {
            if (declaration.getLines() == null) {
                declaration.setLines(declarationLineList);
            }
            declaration.getLines().add(declarationLine);
            return this;
        }

        public DeclarationBuilder.Builder addLines(List<DeclarationLine> declarationLines) {
            if (declaration.getLines() == null) {
                declaration.setLines(declarationLineList);
            }
            declaration.getLines().addAll(declarationLines);
            return this;
        }

        public Declaration build() {
            return declaration;
        }
    }

    public static Declaration getDefaultImport() {
        return getDefaultImportBuilder().build();
    }

    public static Builder getDefaultImportBuilder() {
        return builder()
                .withHeader(DeclarationHeaderBuilder.getDefaultImport())
                .withLine(DeclarationLineBuilder.getDefaultImport());
    }

    public static Declaration getDefaultExport() {
        return getDefaultExportBuilder().build();
    }

    public static Builder getDefaultExportBuilder() {
        return builder()
                .withHeader(DeclarationHeaderBuilder.getDefaultExport())
                .withLine(DeclarationLineBuilder.getDefaultExport());
    }
}