package uk.gov.gsi.hmrc.cds.dar.automation.builders.line;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.line.DeclarationLinesImporterTrader;

public class DeclarationLineImporterTraderBuilder {

    private static final String DEFAULT_IMPORTER_TRADER_TURN = "PR";
    private static final String DEFAULT_IMPORTER_TRADER_CURRENT_IND = "Y";
    private static final String DEFAULT_IMPORTER_TRADER_NAME = "2 Group";
    private static final String DEFAULT_IMPORTER_TRADER_SIMPLIFIED_PROCEDURE_AUTHORISATIONS = "JKSWYZ";
    private static final String DEFAULT_IMPORTER_TRADER_NAME_ABBREVIATED = "Importer Turn 2 Ltd";

    public static Builder builder() {
        return new DeclarationLineImporterTraderBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private DeclarationLinesImporterTrader declarationLinesImporterTrader = new DeclarationLinesImporterTrader();

        public DeclarationLineImporterTraderBuilder.Builder withImporterTraderTurn(String turn) {
            declarationLinesImporterTrader.setItemConsigneeTurn(turn);
            return this;
        }

        public DeclarationLineImporterTraderBuilder.Builder withImporterCurrentInd(String currentInd) {
            declarationLinesImporterTrader.setCurrent_ind(currentInd);
            return this;
        }

        public DeclarationLineImporterTraderBuilder.Builder withImporterName(String name) {
            declarationLinesImporterTrader.setName(name);
            return this;
        }

        public DeclarationLineImporterTraderBuilder.Builder withImporterSimplifiedProcedureAuthorisations(String simplifiedProcedureAuthorisations) {
            declarationLinesImporterTrader.setSimplified_procedure_authorisations(simplifiedProcedureAuthorisations);
            return this;
        }

        public DeclarationLineImporterTraderBuilder.Builder withImporterNameAbbreviated(String nameAbbreviated) {
            declarationLinesImporterTrader.setTrader_name_abbreviated(nameAbbreviated);
            return this;
        }

        public DeclarationLinesImporterTrader build() {
            return declarationLinesImporterTrader;
        }
    }

    public static DeclarationLinesImporterTrader getDefault() {
        return defaultBuilder().build();
    }

    private static Builder defaultBuilder() {
        return builder()
                .withImporterTraderTurn(DEFAULT_IMPORTER_TRADER_TURN)
                .withImporterCurrentInd(DEFAULT_IMPORTER_TRADER_CURRENT_IND)
                .withImporterName(DEFAULT_IMPORTER_TRADER_NAME)
                .withImporterSimplifiedProcedureAuthorisations(DEFAULT_IMPORTER_TRADER_SIMPLIFIED_PROCEDURE_AUTHORISATIONS)
                .withImporterNameAbbreviated(DEFAULT_IMPORTER_TRADER_NAME_ABBREVIATED);
    }
}
