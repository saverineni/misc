package uk.gov.gsi.hmrc.cds.dar.automation.entities.line;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.json.EqualsHashCodeToString;

@Data
public class DeclarationLineDispatchCountry extends EqualsHashCodeToString {
    String code;
}
