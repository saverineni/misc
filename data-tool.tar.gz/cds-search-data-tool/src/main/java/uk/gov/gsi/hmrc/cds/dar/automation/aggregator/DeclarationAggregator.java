package uk.gov.gsi.hmrc.cds.dar.automation.aggregator;

import uk.gov.gsi.hmrc.cds.dar.automation.builders.DeclarationBuilder;
import uk.gov.gsi.hmrc.cds.dar.automation.builders.line.DeclarationLineBuilder;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.Declaration;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.DeclarationHeader;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.line.DeclarationLine;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.dar.automation.aggregator.DeclarationHeaderAggregator.*;
import static uk.gov.gsi.hmrc.cds.dar.automation.aggregator.DeclarationLineAggregator.*;
import static uk.gov.gsi.hmrc.cds.dar.automation.builders.DeclarationBuilder.builder;

public class DeclarationAggregator {

    private static final String DEFAULT_DECLARATION_ID = "400000000000000007786";
    private static final String DEFAULT_HEADER_ONLY_DECLARATION_ID = "300000000000000007786";
    private static final String MULTIPLE_LINES_DECLARATION_ID = "400000000000000007786";
    private static List<Declaration> declarations = new ArrayList<>();


    public static Declaration buildDefaultImportDeclaration() {
        return DeclarationBuilder.getDefaultImport();
    }

    public static Declaration buildDefaultExportDeclaration() {
        return DeclarationBuilder.getDefaultExport();
    }

    public static Declaration buildDefaultHeaderOnlyDeclaration() {
        return builder()
                .withHeader(getDefaultHeaderWithSetDeclarationId(DEFAULT_HEADER_ONLY_DECLARATION_ID))
                .build();
    }

    public static List<Declaration> buildDefaultWithSequentialDeclarationId(int totalDeclarations) {
        for (int count = 1; count <= totalDeclarations; count++) {
            declarations.add(builder()
                    .withHeader(getDefaultHeaderWithRandomDeclarationId())
                    .addLines(getDefaultLinesSeqentially(totalDeclarations))
                    .build());
        }
        return declarations;
    }
    
    public static Declaration buildDefaultWithSequentialLines(int totalLines) {
        return builder()
                .withHeader(getDefaultHeaderWithSetDeclarationId(MULTIPLE_LINES_DECLARATION_ID))
                .addLines(getDefaultLinesSeqentially(totalLines))
                .build();
    }
    
    

    public static Declaration buildRandomDeclarationWithSpecialChars(int totalLines) {
        return builder()
                .withHeader(getRandomHeaderWithSpecialChars())
                .addLines(getRandomLinesWithSpecialChars(totalLines))
                .build();
    }

    public static Declaration buildOriginCountryDeclarations(int totalLines) {
        return builder()
                .withHeader(getDefaultHeaderWithRandomDeclarationId())
                .addLines(getRandomLinesWithOriginCountry(totalLines))
                .build();
    }

    public static Declaration buildEmptyOriginCountryDeclarations(int totalLines) {
        return builder()
                .withHeader(getDefaultHeaderWithRandomDeclarationId())
                .addLines(getRandomLinesWithEmptyOriginCountry(totalLines))
                .build();
    }

    public static List<Declaration> buildEntryDateDataForDate(int totalDeclarations, String date) {

        DeclarationHeader defaultHeaderWithEntryDate = getDefaultHeaderWithEntryDate(date);
        DeclarationLine defaultImport = DeclarationLineBuilder.getDefaultImport();

        for (int count = 1; count <= totalDeclarations; count++) {
            declarations.add(builder()
                    .withHeader(defaultHeaderWithEntryDate)
                    .withLine(defaultImport)
                    .build());
        }
        return declarations;
    }

    public static List<Declaration> buildClearanceDateDataForDate(int totalDeclarations, String date) {
        for (int count = 1; count <= totalDeclarations; count++) {
            declarations.add(builder()
                    .withHeader(getDefaultHeaderWithRandomDeclarationId())
                    .withLine(getRandomLineWithClearanceDate(date))
                    .build());
        }
        return declarations;
    }

    public static List<Declaration> buildOriginCountryDataForCountryCode(int totalDeclarations, String countryCode) {
        for (int count = 1; count <= totalDeclarations; count++) {
            declarations.add(builder()
                    .withHeader(getDefaultHeaderWithRandomDeclarationId())
                    .withLine(getRandomLineWithCountryCode(countryCode))
                    .build());
        }
        return declarations;
    }

    public static List<Declaration> buildDispatchCountryDataForCountryCode(int totalDeclarations, String countryCode) {
        for (int count = 1; count <= totalDeclarations; count++) {
            declarations.add(builder()
                    .withHeader(getRandomHeaderWithDispatchCountry(countryCode))
                    .withLine(DeclarationLineBuilder.getDefaultImport())
                    .build());
        }
        return declarations;
    }

    public static List<Declaration> buildDestinationCountryDataForCountryCode(int totalDeclarations, String countryCode) {
        for (int count = 1; count <= totalDeclarations; count++) {
            declarations.add(builder()
                    .withHeader(getRandomHeaderWithDestinationCountry(countryCode))
                    .withLine(DeclarationLineBuilder.getDefaultImport())
                    .build());
        }
        return declarations;
    }

    public static List<Declaration> buildDataForAllFilters(int totalDeclarations, String originCountry, String dispatchCountry, String destinationCountry) {
        for (int count = 1; count <= totalDeclarations; count++) {
            declarations.add(builder()
                    .withHeader(getDefaultHeaderWithAllFiltersData(count, dispatchCountry, destinationCountry))
                    .withLine(getRandomLineWithAllFiltersData(count, originCountry))
                    .build());
        }
        return declarations;
    }

    public static Declaration buildDefaultWithRandomDeclarationId(int totalLines) {
        return builder()
                .withHeader(getDefaultHeaderWithRandomDeclarationId())
                .addLines(getDefaultLinesSeqentially(totalLines))
                .build();
    }

    public static List<Declaration> buildModeOfTransport(int totalDeclarations, int transportCode) {
        for (int count = 1; count <= totalDeclarations; count++) {
            declarations.add(builder()
                    .withHeader(getRandomHeaderWithModeOfTransport(transportCode))
                    .withLine(DeclarationLineBuilder.getDefaultImport())
                    .build());
        }
        return declarations;
    }

    public static List<Declaration> buildconsigneeEORI(int totalDeclarations, String consigneeEORI) {
        for (int count = 1; count <= totalDeclarations; count++) {
            declarations.add(builder()
                    .withHeader(getRandomHeaderWithConsigneeEori(consigneeEORI))
                    .withLine(DeclarationLineBuilder.getDefaultImport())
                    .build());
        }
        return declarations;
    }

    public static List<Declaration> buildconsignorEORI(int totalDeclarations, String consignorEORI) {
        for (int count = 1; count <= totalDeclarations; count++) {
            declarations.add(builder()
                    .withHeader(getRandomHeaderWithConsignorEori(consignorEORI))
                    .withLine(DeclarationLineBuilder.getDefaultImport())
                    .build());
        }
        return declarations;
    }

    public static List<Declaration> buildGoodsLocation(int totalDeclarations, String goodsLocationCode) {
        for (int count = 1; count <= totalDeclarations; count++) {
            declarations.add(builder()
                    .withHeader(getRandomHeaderWithGoodsLocation(goodsLocationCode))
                    .withLine(DeclarationLineBuilder.getDefaultImport())
                    .build());
        }
        return declarations;
    }

    public static List<Declaration> buildDeclarationsWithIncrementalCommodityCodes(int totalDeclarations, BigInteger commodityCode) {
        for (int count = 1; count <= totalDeclarations; count++) {
            declarations.add(builder()
                    .withHeader(getDefaultHeaderWithRandomDeclarationId())
                    .withLine(getRandomLineWithCommodityCode(commodityCode.add(BigInteger.valueOf(count))))
                    .build());
        }
        return declarations;
    }

    public static Declaration buildTwoLinesWithFixedCommodityCodes(String firstLineCommodityCode, String secondLineCommodityCode) {
        return builder()
                .withHeader(getDefaultHeaderWithRandomDeclarationId())
                .addLines(getRandomLinesWithCommodityCode(firstLineCommodityCode, secondLineCommodityCode))
                .build();
    }

    private static String IncrementDeclarationId(int counter) {
        BigInteger i = new BigInteger(DEFAULT_DECLARATION_ID);
        return i.add(BigInteger.valueOf(counter)).toString();
        //return DEFAULT_DECLARATION_ID.replace("IM000A", "IM" + String.format("%03d",counter) + "A");
    }
}