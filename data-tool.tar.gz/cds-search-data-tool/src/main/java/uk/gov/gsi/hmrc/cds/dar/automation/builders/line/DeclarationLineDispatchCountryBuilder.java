package uk.gov.gsi.hmrc.cds.dar.automation.builders.line;

import javafx.util.Pair;
import uk.gov.gsi.hmrc.cds.dar.automation.data.Faker;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.line.DeclarationLineDispatchCountry;

public class DeclarationLineDispatchCountryBuilder {
    private static final String DEFAULT_COUNTRY_CODE = "PK";
    private static Faker faker = new Faker();


    public static DeclarationLineDispatchCountryBuilder.Builder builder() {
        return new DeclarationLineDispatchCountryBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private DeclarationLineDispatchCountry declarationLineDispatchCountry = new DeclarationLineDispatchCountry();

        public DeclarationLineDispatchCountryBuilder.Builder withDispatchCountryCode(String countryCode) {
            declarationLineDispatchCountry.setCode(countryCode);
            return this;
        }

        public DeclarationLineDispatchCountry build() {
            return declarationLineDispatchCountry;
        }
    }

    public static DeclarationLineDispatchCountry getDefault() {
        return defaultBuilder().build();
    }

    public static DeclarationLineDispatchCountryBuilder.Builder defaultBuilder() {
        return builder()
                .withDispatchCountryCode(DEFAULT_COUNTRY_CODE);
    }

    public static DeclarationLineDispatchCountry getRandom() {
        Pair<String, String> randomCountryPair = faker.getRandomOriginCountry();

        return builder()
                .withDispatchCountryCode(randomCountryPair.getKey())
                .build();
    }
}
