package uk.gov.gsi.hmrc.cds.dar.automation.aggregator;

import uk.gov.gsi.hmrc.cds.dar.automation.builders.header.DeclarationDestinationCountryBuilder;
import uk.gov.gsi.hmrc.cds.dar.automation.builders.header.DeclarationDispatchCountryBuilder;
import uk.gov.gsi.hmrc.cds.dar.automation.builders.header.DeclarationHeaderBuilder;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.DeclarationHeader;
import uk.gov.gsi.hmrc.cds.dar.automation.data.Faker;

public class DeclarationHeaderAggregator {

    private static Faker faker = new Faker();
    private static int EPU = 100;

    public static DeclarationHeader getDefaultHeaderWithSetDeclarationId(String declarationId) {
        DeclarationHeader header = DeclarationHeaderBuilder
                .getDefaultImportBuilder()
                .withDeclarationId(declarationId)
                .build();

        return header;
    }

    public static DeclarationHeader getDefaultHeaderWithRandomDeclarationId() {
        DeclarationHeader header = DeclarationHeaderBuilder
                .getDefaultImportBuilder()
                .withDeclarationId(faker.getRandomDeclarationId())
                .build();

        return header;
    }

    public static DeclarationHeader getRandomHeaderWithSpecialChars() {
        DeclarationHeader header = DeclarationHeaderBuilder
                .getRandomImportBuilder()
                .withConsigneeNadName(faker.getNonSpecialCharHeaderConsignorName())
                .withConsigneeNadPostcode(faker.getSpecialCharHeaderConsignorPostcode())
                .build();

        return header;
    }

    public static DeclarationHeader getDefaultHeaderWithEntryDate(String date) {
        DeclarationHeader header = DeclarationHeaderBuilder
                .getDefaultImportBuilder()
                .withDeclarationId(faker.getRandomDeclarationId())
                .withEntryDate(date)
                .build();
        return header;
    }

    public static DeclarationHeader getDefaultHeaderWithAllFiltersData(int declarationCounter, String dispatchCountry, String destinationCountry) {
        DeclarationHeaderBuilder.Builder header = DeclarationHeaderBuilder.getDefaultImportBuilder();
        header.withDeclarationId(faker.getRandomDeclarationId());
        header.withEpuNumber(String.valueOf(EPU++));
        header.withEntryDate(generateEntryDate(declarationCounter));
        header.withDispatchCountry(DeclarationDispatchCountryBuilder.getCountryFor(dispatchCountry));
        header.withDestinationCountry(DeclarationDestinationCountryBuilder.getCountryFor(destinationCountry));
        header.withTransportModeCode(generateTransportModeCode(declarationCounter));
        header.withGoodsLocation(generateGoodsLocation(declarationCounter));
        return header.build();
    }

    public static DeclarationHeader getRandomHeaderWithDispatchCountry(String countryCode) {
        DeclarationHeader header = DeclarationHeaderBuilder
                .getRandomImportBuilder()
                .withDeclarationId(faker.getRandomDeclarationId())
                .withDispatchCountry(DeclarationDispatchCountryBuilder.getCountryFor(countryCode))
                .build();
        return header;
    }

    public static DeclarationHeader getRandomHeaderWithDestinationCountry(String countryCode) {
        DeclarationHeader header = DeclarationHeaderBuilder
                .getRandomImportBuilder()
                .withDeclarationId(faker.getRandomDeclarationId())
                .withDestinationCountry(DeclarationDestinationCountryBuilder.getCountryFor(countryCode))
                .build();
        return header;
    }

    public static DeclarationHeader getRandomHeaderWithModeOfTransport(int transportCode) {
        DeclarationHeader header = DeclarationHeaderBuilder
                .getRandomImportBuilder()
                .withDeclarationId(faker.getRandomDeclarationId())
                .withTransportModeCode(transportCode)
                .build();
        return header;
    }

    public static DeclarationHeader getRandomHeaderWithConsigneeEori(String consigneeEori) {
        DeclarationHeader header = DeclarationHeaderBuilder
                .getDefaultImportBuilder()
                .withDeclarationId(faker.getRandomDeclarationId())
                .withConsigneeEori(consigneeEori)
                .build();
        return header;
    }

    public static DeclarationHeader getRandomHeaderWithConsignorEori(String consignorEori) {
        DeclarationHeader header = DeclarationHeaderBuilder
                .getRandomImportBuilder()
                .withDeclarationId(faker.getRandomDeclarationId())
                .withConsignorEori(consignorEori)
                .build();
        return header;
    }

    public static DeclarationHeader getRandomHeaderWithGoodsLocation(String goodsLocation) {
        DeclarationHeader header = DeclarationHeaderBuilder
                .getRandomImportBuilder()
                .withDeclarationId(faker.getRandomDeclarationId())
                .withGoodsLocation(goodsLocation)
                .build();
        return header;
    }

    private static String generateEntryDate(int declarationCounter) {
        if ((declarationCounter % 2) == 1) {
            return "2017-01-01 00:00:00.00";
        } else {
            return "2017-07-01 00:00:00.00";
        }
    }

    private static String generateGoodsLocation(int declarationCounter) {
        if (declarationCounter >=1 && declarationCounter <=2) { return "BOS"; }
        if (declarationCounter >=3 && declarationCounter <=4) { return "EXE"; }
        if (declarationCounter >=5 && declarationCounter <=6) { return "GOO"; }
        if (declarationCounter >=7 && declarationCounter <=8) { return "MLS"; }
        if (declarationCounter >=9 && declarationCounter <=10) { return "POO"; }
        return "";
    }

    private static int generateTransportModeCode(int declarationCounter) {
        if (declarationCounter >=1 && declarationCounter <10) {
            if (declarationCounter == 6) {
                return 0;
            } else {
                return declarationCounter;
            }
        }
        return 0;
    }
}