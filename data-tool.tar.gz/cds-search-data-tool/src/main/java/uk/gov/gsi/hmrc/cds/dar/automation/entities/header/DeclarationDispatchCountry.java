package uk.gov.gsi.hmrc.cds.dar.automation.entities.header;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.json.EqualsHashCodeToString;

@Data
public class DeclarationDispatchCountry extends EqualsHashCodeToString {
    String code;
}
