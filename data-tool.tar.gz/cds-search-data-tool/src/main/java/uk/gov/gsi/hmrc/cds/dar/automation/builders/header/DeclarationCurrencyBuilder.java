package uk.gov.gsi.hmrc.cds.dar.automation.builders.header;

import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.currency.DeclarationCurrency;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.currency.DeclarationFreightCurrency;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.currency.DeclarationInvoiceCurrency;

public class DeclarationCurrencyBuilder {

    public static Builder builder() {
        return new DeclarationCurrencyBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private DeclarationCurrency declarationCurrency = new DeclarationCurrency();

        public DeclarationCurrencyBuilder.Builder addFreightCurrency(DeclarationFreightCurrency declarationFreightCurrency) {
            declarationCurrency.setFreightCurrency(declarationFreightCurrency);
            return this;
        }

        public DeclarationCurrencyBuilder.Builder addInvoiceCurrency(DeclarationInvoiceCurrency declarationInvoiceCurrency) {
            declarationCurrency.setInvoiceCurrency(declarationInvoiceCurrency);
            return this;
        }

        public DeclarationCurrency build() {
            return declarationCurrency;
        }
    }

    public static DeclarationCurrency getDefault() {
        return defaultBuilder().build();
    }

    private static Builder defaultBuilder() {
        return builder()
                .addFreightCurrency(DeclarationFreightCurrencyBuilder.getDefault())
                .addInvoiceCurrency(DeclarationInvoiceCurrencyBuilder.getDefault());
    }
}