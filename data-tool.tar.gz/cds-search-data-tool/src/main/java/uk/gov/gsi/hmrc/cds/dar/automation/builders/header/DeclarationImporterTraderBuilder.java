package uk.gov.gsi.hmrc.cds.dar.automation.builders.header;

import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.trader.ImporterTrader;

public class DeclarationImporterTraderBuilder {

    private static final String DEFAULT_IMPORTER_TRADER_TURN = "120098765123";
    private static final String DEFAULT_IMPORTER_TRADER_CURRENT_IND = "Y";
    private static final String DEFAULT_IMPORTER_TRADER_NAME = "2 Group";
    private static final String DEFAULT_IMPORTER_TRADER_SIMPLIFIED_PROCEDURE_AUTHORISATIONS = "JKSWYZ";
    private static final String DEFAULT_IMPORTER_TRADER_NAME_ABBREVIATED = "Importer Turn 2 Ltd";

    public static Builder builder(){
        return new DeclarationImporterTraderBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private ImporterTrader importerTrader = new ImporterTrader();

        public DeclarationImporterTraderBuilder.Builder withImporterTraderTurn(String turn) {
            importerTrader.setConsigneeTurn(turn);
            return this;
        }

        public DeclarationImporterTraderBuilder.Builder withImporterCurrentInd(String currentInd) {
            importerTrader.setCurrent_ind(currentInd);
            return this;
        }

        public DeclarationImporterTraderBuilder.Builder withImporterName(String name) {
            importerTrader.setName(name);
            return this;
        }

        public DeclarationImporterTraderBuilder.Builder withImporterSimplifiedProcedureAuthorisations(String simplifiedProcedureAuthorisations) {
            importerTrader.setSimplified_procedure_authorisations(simplifiedProcedureAuthorisations);
            return this;
        }

        public DeclarationImporterTraderBuilder.Builder withImporterNameAbbreviated(String nameAbbreviated) {
            importerTrader.setTrader_name_abbreviated(nameAbbreviated);
            return this;
        }

        public ImporterTrader build() {
            return importerTrader;
        }
    }

    public static ImporterTrader getDefault() {
        return defaultBuilder().build();
    }

    public static DeclarationImporterTraderBuilder.Builder defaultBuilder() {
        return builder()
                .withImporterTraderTurn(DEFAULT_IMPORTER_TRADER_TURN)
                .withImporterCurrentInd(DEFAULT_IMPORTER_TRADER_CURRENT_IND)
                .withImporterName(DEFAULT_IMPORTER_TRADER_NAME)
                .withImporterSimplifiedProcedureAuthorisations(DEFAULT_IMPORTER_TRADER_SIMPLIFIED_PROCEDURE_AUTHORISATIONS)
                .withImporterNameAbbreviated(DEFAULT_IMPORTER_TRADER_NAME_ABBREVIATED);
    }
}