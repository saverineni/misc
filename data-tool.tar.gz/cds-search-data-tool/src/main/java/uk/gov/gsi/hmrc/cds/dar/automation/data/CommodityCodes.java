package uk.gov.gsi.hmrc.cds.dar.automation.data;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CommodityCodes {

    //Random Commodity Codes and Descriptions
    List<String> commodityCodeList = new ArrayList<>(Arrays.asList("0101109999","0203129999","0301949999","0406309999","0508009999","0602409999","0703209999","0802119999","0910209999","1005909999"));
    List<String> commodityCodeChapterDescription = new ArrayList<>(Arrays.asList(
            "LIVE ANIMALS", "MEAT AND EDIBLE MEAT OFFAL", "FISH AND CRUSTACEANS, MOLLUSCS AND OTHER AQUATIC INVERTEBRATES",
            "DAIRY PRODUCE; BIRDS' EGGS; NATURAL HONEY; EDIBLE PRODUCTS OF ANIMAL ORIGIN, NOT ELSEWHERE SPECIFIED OR INCLUDED",
            "PRODUCTS OF ANIMAL ORIGIN, NOT ELSEWHERE SPECIFIED OR INCLUDED",
            "LIVE TREES AND OTHER PLANTS; BULBS, ROOTS AND THE LIKE; CUT FLOWERS AND ORNAMENTAL FOLIAGE",
            "EDIBLE VEGETABLES AND CERTAIN ROOTS AND TUBERS",
            "EDIBLE FRUIT AND NUTS; PEEL OF CITRUS FRUIT OR MELONS", "Coffee, tea, mate and spices", "CEREALS"));
    List<String> commodityCodeHeadingDescription = new ArrayList<>(Arrays.asList(
            "Live horses, asses, mules and hinnies.",
            "Meat of swine, fresh, chilled or frozen.",
            "Live fish.",
            "Cheese and curd.",
            "Coral and similar materials, unworked or simply prepared but not otherwise worked; shells of molluscs, crustaceans or echinoderms and cuttle-bone, unworked or simply prepared but not cut to shape, powder and waste thereof",
            "Other live plants (including their roots), cuttings and slips; mushroom spawn.",
            "Onions, shallots, garlic, leeks and other alliaceous vegetables, fresh or chilled",
            "Other nuts, fresh or dried, whether or not shelled or peeled.",
            "Ginger, saffron, turmeric (curcuma), thyme, bay leaves, curry and other spices",
            "Maize (corn)."));
    List<String> commodityCodeSubheadingDescription = new ArrayList<>(Arrays.asList(
            "Fresh or chilled hams, shoulders and cuts thereof of swine.",
            "Live Atlantic and Pacific bluefin tuna (Thunnus thynnus, Thunnus orientalis)",
            "Processed cheese, not grated or powdered",
            "Coral and similar materials, shells of molluscs, crustaceans or echinoderms, cuttle-bone, powder and waste thereof, unworked or simply prepared but not otherwise worked or cut to shape",
            "Roses, whether or not grafted",
            "Garlic, fresh or chilled",
            "Fresh or dried almonds in shell",
            "Saffron", "Maize (excl. seed for sowing)"));

    //Cotton related Commodity Codes and Descriptions
    List<String> commodityCodeCottonList = new ArrayList<>(Arrays.asList("5201009999","5205149999","5205269999","5206129999","5207109999","5208419999","5208439999","5208529999","5209129999","5209299999"));
    List<String> commodityCodeCottonChapterDescription = new ArrayList<>(Arrays.asList("COTTON"));
    List<String> commodityCodeCottonHeadingDescription = new ArrayList<>(Arrays.asList(
            "Cotton, not carded or combed.",
            "Cotton yarn (other than sewing thread), containing 85 % or more by weight of cotton, not put up for retail sale.",
            "Cotton yarn (other than sewing thread) put up for retail sale.",
            "Woven fabrics of cotton, containing 85 % or more by weight of cotton, weighing not more than 200 g/m2."));
    List<String> commodityCodeCottonSubheadingDescription = new ArrayList<>(Arrays.asList(
            "Cotton, neither carded nor combed",
            "Single cotton yarn, of uncombed fibres, containing >= 85% cotton by weight and with a linear density of 125 decitex to < 192,31 decitex",
            "Cotton yarn containing >= 85% cotton by weight, put up for retail sale (excl. sewing thread)",
            "Plain woven fabrics of cotton, containing >= 85% cotton by weight and weighing <= 100 g/m?, made from yarn of different colours"));

    //Turkey (bird) related Commodity Codes and Descriptions
    List<String> commodityCodeTurkeyList = new ArrayList<>(Arrays.asList("0105119999","0105129999","0105199999","0105949999","0105999999","0207249999","0207259999","0207269999","0207279999","1602319999"));
    List<String> commodityCodeTurkeyChapterDescription = new ArrayList<>(Arrays.asList(
            "LIVE ANIMALS",
            "MEAT AND EDIBLE MEAT OFFAL",
            "PREPARATIONS OF MEAT, OF FISH OR OF CRUSTACEANS, MOLLUSCS OR OTHER AQUATIC INVERTEBRATES"));
    List<String> commodityCodeTurkeyHeadingDescription = new ArrayList<>(Arrays.asList(
            "Live poultry, that is to say, fowls of the species Gallus domesticus, ducks, geese, turkeys and guinea fowls.",
            "Meat and edible offal, of the poultry of heading 01.05, fresh, chilled or frozen.",
            "Other prepared or preserved meat, meat offal or blood."));
    List<String> commodityCodeTurkeySubheadingDescription = new ArrayList<>(Arrays.asList(
            "Live fowls of the species Gallus domesticus, weighing <= 185 g (excl. turkeys and guinea fowls)", "Live domestic turkeys, weighing <= 185 g",
            "Live domestic turkeys, weighing <= 185 g",
            "Live fowls of the species Gallus domesticus, weighing > 185",
            "Live domestic ducks, geese, turkeys and guinea fowls, weighing > 185 g",
            "Fresh or chilled turkeys of the species domesticus, not cut in pieces",
            "Frozen turkeys of the species domesticus, not cut into pieces",
            "Fresh or chilled cuts and edible offal of turkeys of the species domesticus",
            "Frozen cuts and edible offal of turkeys of the species domesticus",
            "Meat or offal of turkeys"));
}