package uk.gov.gsi.hmrc.cds.dar.automation.json;

import com.fasterxml.jackson.databind.JsonNode;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchemaFactory;
import com.github.fge.jsonschema.main.JsonValidator;

import java.io.IOException;

public class JsonSchemaValidator {

    public static void validateJsonData(final String jsonSchema, final String jsonData) throws MessageBodyReaderValidationException {
        try {
            final JsonNode jsonDataNode = JsonLoader.fromString(jsonData);
            final JsonNode jsonSchemaNode = JsonLoader.fromString(jsonSchema);

            final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
            JsonValidator jsonValidator = factory.getValidator();

            ProcessingReport report = jsonValidator.validate(jsonSchemaNode, jsonDataNode);
            if (!report.toString().contains("success")) {
                throw new MessageBodyReaderValidationException("Request payload fails json schema validation");
            }

        } catch (IOException | ProcessingException e) {
            throw new MessageBodyReaderValidationException("Failed to validate json data", e);
        }
    }

}
