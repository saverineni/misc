package uk.gov.gsi.hmrc.cds.dar.automation.entities.header.currency;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.json.EqualsHashCodeToString;

@Data
public class DeclarationCurrency extends EqualsHashCodeToString {

    DeclarationFreightCurrency freightCurrency;
    DeclarationInvoiceCurrency invoiceCurrency;
}
