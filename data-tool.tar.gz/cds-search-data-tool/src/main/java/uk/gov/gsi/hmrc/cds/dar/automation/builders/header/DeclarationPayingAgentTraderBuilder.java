package uk.gov.gsi.hmrc.cds.dar.automation.builders.header;

import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.trader.PayingAgentTrader;

public class DeclarationPayingAgentTraderBuilder {

    private static final String DEFAULT_PAYING_AGENT_TRADER_TURN = "410098765123";
    private static final String DEFAULT_PAYING_AGENT_TRADER_CURRENT_IND = "Y";
    private static final String DEFAULT_PAYING_AGENT_TRADER_NAME = "22 Group";
    private static final String DEFAULT_PAYING_AGENT_TRADER_SIMPLIFIED_PROCEDURE_AUTHORISATIONS = "JKS";
    private static final String DEFAULT_PAYING_AGENT_TRADER_NAME_ABBREVIATED = "Paying Agent Turn 22 Ltd";


    public static Builder builder() {
        return new DeclarationPayingAgentTraderBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private PayingAgentTrader payingAgentTrader = new PayingAgentTrader();

        public DeclarationPayingAgentTraderBuilder.Builder withPayingAgentTraderTurn(String turn) {
            payingAgentTrader.setPaying_agent_trader_turn(turn);
            return this;
        }

        public DeclarationPayingAgentTraderBuilder.Builder withPayingAgentCurrentInd(String currentInd) {
            payingAgentTrader.setCurrent_ind(currentInd);
            return this;
        }

        public DeclarationPayingAgentTraderBuilder.Builder withPayingAgentName(String name) {
            payingAgentTrader.setName(name);
            return this;
        }

        public DeclarationPayingAgentTraderBuilder.Builder withPayingAgentSimplifiedProcedureAuthorisations(String simplifiedProcedureAuthorisations) {
            payingAgentTrader.setSimplified_procedure_authorisations(simplifiedProcedureAuthorisations);
            return this;
        }

        public DeclarationPayingAgentTraderBuilder.Builder withPayingAgentNameAbbreviated(String nameAbbreviated) {
            payingAgentTrader.setTrader_name_abbreviated(nameAbbreviated);
            return this;
        }

        public PayingAgentTrader build() {
            return payingAgentTrader;
        }
    }

    public static PayingAgentTrader getDefault() {
        return defaultBuilder().build();
    }

    private static DeclarationPayingAgentTraderBuilder.Builder defaultBuilder() {
        return builder()
                .withPayingAgentTraderTurn(DEFAULT_PAYING_AGENT_TRADER_TURN)
                .withPayingAgentCurrentInd(DEFAULT_PAYING_AGENT_TRADER_CURRENT_IND)
                .withPayingAgentName(DEFAULT_PAYING_AGENT_TRADER_NAME)
                .withPayingAgentSimplifiedProcedureAuthorisations(DEFAULT_PAYING_AGENT_TRADER_SIMPLIFIED_PROCEDURE_AUTHORISATIONS)
                .withPayingAgentNameAbbreviated(DEFAULT_PAYING_AGENT_TRADER_NAME_ABBREVIATED);
    }
}