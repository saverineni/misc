package uk.gov.gsi.hmrc.cds.dar.automation.entities.line;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.json.EqualsHashCodeToString;

@Data
public class DeclarationLineTaxLine extends EqualsHashCodeToString {

    @JsonIgnore
    String entry_reference;
    @JsonIgnore
    String item_number;

    String tax_line_sequence_number;
    String sat_tax_line_generation_number;
    String waived_tax;
    String method_of_payment_code;
    String tax_amount;
    String tax_type_code;
}
