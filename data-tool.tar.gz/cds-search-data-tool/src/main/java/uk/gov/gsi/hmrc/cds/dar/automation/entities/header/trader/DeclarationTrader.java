package uk.gov.gsi.hmrc.cds.dar.automation.entities.header.trader;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.json.EqualsHashCodeToString;

@Data
public class DeclarationTrader extends EqualsHashCodeToString {

    private ConsignorTrader consignorTrader;
    private DeclarantTrader declarantTrader;
    private ExporterTrader exporterTrader;
    private ImporterTrader importerTrader;
    private PayingAgentTrader payingAgentTrader;
}
