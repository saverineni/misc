package uk.gov.gsi.hmrc.cds.dar.automation.entities.header;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.json.EqualsHashCodeToString;

@Data
public class DeclarationHeader extends EqualsHashCodeToString {

    String declarationId;
    String declarationSource;
    String importExportIndicator;
    String epuNumber;
    String entryNumber;
    String entryDate;
    String goodsLocation;
    int transportModeCode;
    String route;
    String consigneeTurn;
    String consigneeEori;
    String consigneeName;
    String consigneePostcode;
    String consignorTurn;
    String consignorEori;
    String consignorName;
    String consignorPostcode;
    DeclarationDispatchCountry dispatchCountry;
    DeclarationDestinationCountry destinationCountry;
}
