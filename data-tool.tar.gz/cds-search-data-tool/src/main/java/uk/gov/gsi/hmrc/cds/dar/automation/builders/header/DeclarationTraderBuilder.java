package uk.gov.gsi.hmrc.cds.dar.automation.builders.header;

import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.trader.*;

public class DeclarationTraderBuilder {

    public static Builder builder() {
        return new DeclarationTraderBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        DeclarationTrader declarationTrader = new DeclarationTrader();

        public DeclarationTraderBuilder.Builder addConsignorTrader(ConsignorTrader consignorTrader) {
            declarationTrader.setConsignorTrader(consignorTrader);
            return this;
        }

        public DeclarationTraderBuilder.Builder addDeclarantTrader(DeclarantTrader declarantTrader) {
            declarationTrader.setDeclarantTrader(declarantTrader);
            return this;
        }

        public DeclarationTraderBuilder.Builder addExporterTrader(ExporterTrader exporterTrader) {
            declarationTrader.setExporterTrader(exporterTrader);
            return this;
        }

        public DeclarationTraderBuilder.Builder addImporterTrader(ImporterTrader importerTrader) {
            declarationTrader.setImporterTrader(importerTrader);
            return this;
        }

        public DeclarationTraderBuilder.Builder addPayingAgentTrader(PayingAgentTrader payingAgentTrader) {
            declarationTrader.setPayingAgentTrader(payingAgentTrader);
            return this;
        }

        public DeclarationTrader build() {
            return declarationTrader;
        }
    }

    public static DeclarationTrader getDefault() {
        return defaultBuilder().build();
    }

    private static Builder defaultBuilder() {
        return builder()
                .addConsignorTrader(DeclarationConsignorTraderBuilder.getDefault())
                .addDeclarantTrader(DeclarationDeclarantTraderBuilder.getDefault())
                .addExporterTrader(DeclarationExporterTraderBuilder.getDefault())
                .addImporterTrader(DeclarationImporterTraderBuilder.getDefault())
                .addPayingAgentTrader(DeclarationPayingAgentTraderBuilder.getDefault());
    }
}
