package uk.gov.gsi.hmrc.cds.dar.automation.builders.header;
import javafx.util.Pair;
import uk.gov.gsi.hmrc.cds.dar.automation.data.Faker;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.DeclarationDestinationCountry;

public class DeclarationDestinationCountryBuilder {
    private static final String DEFAULT_DESTINATION_COUNTRY_CODE = "GB";
    private static Faker faker = new Faker();

    public static Builder builder() {
        return new DeclarationDestinationCountryBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private DeclarationDestinationCountry declarationDestinationCountry = new DeclarationDestinationCountry();

        public DeclarationDestinationCountryBuilder.Builder withDestinationCountryCode(String countryCode) {
            declarationDestinationCountry.setCode(countryCode);
            return this;
        }

        public DeclarationDestinationCountry build(){
            return declarationDestinationCountry;
        }
    }

    public static DeclarationDestinationCountry getDefault() {
        return defaultBuilder().build();
    }

    public static DeclarationDestinationCountryBuilder.Builder defaultBuilder() {
        return builder()
                .withDestinationCountryCode(DEFAULT_DESTINATION_COUNTRY_CODE);
    }

    public static DeclarationDestinationCountry getRandom() {
        Pair<String, String> randomCountryPair = faker.getRandomOriginCountry();

        return builder()
                .withDestinationCountryCode(randomCountryPair.getKey())
                .build();
    }

    public static DeclarationDestinationCountry getCountryFor(String countryCode) {
        Pair<String, String> countryPair = faker.getCountry(countryCode);

        return builder()
                .withDestinationCountryCode(countryCode)
                .build();
    }
}
