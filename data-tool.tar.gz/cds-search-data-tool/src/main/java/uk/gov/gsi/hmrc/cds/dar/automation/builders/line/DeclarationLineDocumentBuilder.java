package uk.gov.gsi.hmrc.cds.dar.automation.builders.line;

import uk.gov.gsi.hmrc.cds.dar.automation.entities.line.DeclarationLineDocument;

public class DeclarationLineDocumentBuilder {

    private static final String DEFAULT_ENTRY_REFERENCE = "670-IM001A-2016-12-01";
    private static final String DEFAULT_SEQUENCE_NUMBER = "1";
    private static final String DEFAULT_GENERATION_NUMBER = "1";
    private static final String DEFAULT_ITEM_DOCUMENT_CODE = "C019";
    private static final String DEFAULT_ITEM_DOCUMENT_STATUS = "XB";
    private static final String DEFAULT_ITEM_DOCUMENT_REFERENCE = "IVGHusKSIZ";

    public static Builder builder() {
        return new DeclarationLineDocumentBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private DeclarationLineDocument document = new DeclarationLineDocument();

        public DeclarationLineDocumentBuilder.Builder withDocumentEntryReference(String entryReference) {
            document.setEntry_reference(entryReference);
            return this;
        }

        public DeclarationLineDocumentBuilder.Builder withDocumentSequenceNumber(String sequenceNumber) {
            document.setDocument_sequence_number(sequenceNumber);
            return this;
        }

        public DeclarationLineDocumentBuilder.Builder withDocumentGenerationNumber(String generationNumber) {
            document.setSat_document_generation_number(generationNumber);
            return this;
        }

        public DeclarationLineDocumentBuilder.Builder withItemDocumentCode(String documentCode) {
            document.setItem_document_code(documentCode);
            return this;
        }

        public DeclarationLineDocumentBuilder.Builder withItemDocumentStatus(String documentStatus) {
            document.setItem_document_status(documentStatus);
            return this;
        }

        public DeclarationLineDocumentBuilder.Builder withItemDocumentReference(String documentReference) {
            document.setItem_document_reference(documentReference);
            return this;
        }

        public DeclarationLineDocument build() {
            return document;
        }
    }

    public static DeclarationLineDocument getDefault() {
        return defaultBuilder().build();
    }

    private static Builder defaultBuilder() {
        return builder()
                .withDocumentEntryReference(DEFAULT_ENTRY_REFERENCE)
                .withDocumentSequenceNumber(DEFAULT_SEQUENCE_NUMBER)
                .withDocumentGenerationNumber(DEFAULT_GENERATION_NUMBER)
                .withItemDocumentCode(DEFAULT_ITEM_DOCUMENT_CODE)
                .withItemDocumentStatus(DEFAULT_ITEM_DOCUMENT_STATUS)
                .withItemDocumentReference(DEFAULT_ITEM_DOCUMENT_REFERENCE);
    }
}
