package uk.gov.gsi.hmrc.cds.dar.automation.builders.header;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.header.trader.ConsignorTrader;

public class DeclarationConsignorTraderBuilder {

    private static final String DEFAULT_CONSIGNOR_TRADER_TURN = "";
    private static final String DEFAULT_CONSIGNOR_TRADER_CURRENT_IND = "Y";
    private static final String DEFAULT_CONSIGNOR_TRADER_NAME = "32 Group";
    private static final String DEFAULT_CONSIGNOR_TRADER_SIMPLIFIED_PROCEDURE_AUTHORISATIONS = "JKS";
    private static final String DEFAULT_CONSIGNOR_TRADER_NAME_ABBREVIATED = "Consignor Turn 32 Ltd";

    public static Builder builder() {
        return new DeclarationConsignorTraderBuilder.Builder();
    }

    public static class Builder {
        public Builder() {}

        private ConsignorTrader consignorTrader = new ConsignorTrader();

        public DeclarationConsignorTraderBuilder.Builder withConsignorTurn(String turn) {
            consignorTrader.setConsignorTurn(turn);
            return this;
        }

        public DeclarationConsignorTraderBuilder.Builder withConsignorCurrentInd(String currentInd) {
            consignorTrader.setCurrent_ind(currentInd);
            return this;
        }

        public DeclarationConsignorTraderBuilder.Builder withConsignorName(String name) {
            consignorTrader.setName(name);
            return this;
        }

        public DeclarationConsignorTraderBuilder.Builder withConsignorSimplifiedProcedureAuthorisations(String simplifiedProcedureAuthorisations) {
            consignorTrader.setSimplified_procedure_authorisations(simplifiedProcedureAuthorisations);
            return this;
        }

        public DeclarationConsignorTraderBuilder.Builder withConsignorNameAbbreviated(String nameAbbreviated) {
            consignorTrader.setTrader_name_abbreviated(nameAbbreviated);
            return this;
        }

        public ConsignorTrader build(){
            return consignorTrader;
        }
    }

    public static ConsignorTrader getDefault() {
        return defaultBuilder().build();
    }

    public static Builder defaultBuilder() {
        return builder()
                .withConsignorTurn(DEFAULT_CONSIGNOR_TRADER_TURN)
                .withConsignorCurrentInd(DEFAULT_CONSIGNOR_TRADER_CURRENT_IND)
                .withConsignorName(DEFAULT_CONSIGNOR_TRADER_NAME)
                .withConsignorSimplifiedProcedureAuthorisations(DEFAULT_CONSIGNOR_TRADER_SIMPLIFIED_PROCEDURE_AUTHORISATIONS)
                .withConsignorNameAbbreviated(DEFAULT_CONSIGNOR_TRADER_NAME_ABBREVIATED);
    }
}