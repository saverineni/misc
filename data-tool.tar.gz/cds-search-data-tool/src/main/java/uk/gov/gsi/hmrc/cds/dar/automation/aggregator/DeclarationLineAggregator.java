package uk.gov.gsi.hmrc.cds.dar.automation.aggregator;

import uk.gov.gsi.hmrc.cds.dar.automation.builders.line.*;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.line.DeclarationLine;
import uk.gov.gsi.hmrc.cds.dar.automation.data.Faker;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

import static java.util.stream.Collectors.toList;

public class DeclarationLineAggregator {

    private static Faker faker = new Faker();
    private static final int COMMODITY_CODE = 1212000000;

    public static List<DeclarationLine> getDefaultLinesSeqentially(int totalLines) {
        List<DeclarationLine> lines = IntStream.rangeClosed(1, totalLines)
                .mapToObj(itemNumber ->
                        DeclarationLineBuilder
                                .getDefaultImportBuilder()
                                .withItemNumber(itemNumber)
                                .withItemRoute(String.valueOf(itemNumber)) //TODO temporarily use this until we show ItemNumber in UI
                                .build())
                .collect(toList());
        return lines;
    }

    public static DeclarationLine getRandomLineWithClearanceDate(String clearanceDatetime) {
        DeclarationLineBuilder.Builder lineBuilder = DeclarationLineBuilder.getRandomImportBuilder();
        lineBuilder.withClearanceDatetime(clearanceDatetime);
        return lineBuilder.build();
    }

    public static List<DeclarationLine> getRandomLinesWithSpecialChars(int totalLines) {
        List<DeclarationLine> lines = IntStream.rangeClosed(1, totalLines)
                .mapToObj(itemNumber ->
                        DeclarationLineBuilder
                                .getRandomImportBuilder()
                                .withItemNumber(itemNumber)
                                .withItemConsigneeTurn(faker.getRandomImporterTurn())
                                .withItemConsigneeNadName(faker.getSpecialCharLineConsignorName())
                                .withItemConsigneeNadPostCode(faker.getNonSpecialCharLineConsignorPostcode())
                                .build())
                .collect(toList());
        return lines;
    }

    public static List<DeclarationLine> getRandomLinesWithOriginCountry(int totalLines) {
        List<DeclarationLine> lines = new ArrayList<>();

        for (int noOfLines = 1; noOfLines <= totalLines; noOfLines++) {
            DeclarationLineBuilder.Builder lineBuilder = DeclarationLineBuilder.getRandomImportBuilder();
            lineBuilder.withItemNumber(noOfLines);
            switch (noOfLines) {
                case 1:
                    lineBuilder.withOriginCountry(DeclarationLineOriginCountryBuilder.getDefault());
                    break;
                case 2:
                    lineBuilder.withOriginCountry(DeclarationLineOriginCountryBuilder.getEuropeanCommunuity());
                    break;
                case 3:
                    lineBuilder.withOriginCountry(DeclarationLineOriginCountryBuilder.getCornIslands());
                    break;
            }
            lines.add(lineBuilder.build());
        }
        return lines;
    }

    public static List<DeclarationLine> getRandomLinesWithEmptyOriginCountry(int totalLines) {
        List<DeclarationLine> lines = new ArrayList<>();

        for (int noOfLines = 1; noOfLines <= totalLines; noOfLines++) {
            DeclarationLineBuilder.Builder lineBuilder = DeclarationLineBuilder.getRandomImportBuilder();
            lineBuilder.withItemNumber(noOfLines);
            if ((noOfLines % 2)==1){
                lineBuilder.withOriginCountry(DeclarationLineOriginCountryBuilder.getDefault());
            } else {
                lineBuilder.withOriginCountry(DeclarationLineOriginCountryBuilder.getEmptyCountry());
            }
            lines.add(lineBuilder.build());
        }
        return lines;
    }

    public static DeclarationLine getRandomLineWithCommodityCode(BigInteger commodityCode) {
        DeclarationLineBuilder.Builder lineBuilder = DeclarationLineBuilder.getRandomImportBuilder();
        if (commodityCode.toString().length() == 9) {
            lineBuilder.withCommodityCode("0" + commodityCode.toString());
        } else {
            lineBuilder.withCommodityCode(commodityCode.toString());
        }
        return lineBuilder.build();
    }

    public static List<DeclarationLine> getRandomLinesWithCommodityCode(String firstLineCommodityCode, String secondLineCommodityCode) {
        List<DeclarationLine> lines = new ArrayList<>();
        for (int noOfLines = 1; noOfLines <= 2; noOfLines++) {
            DeclarationLineBuilder.Builder lineBuilder = DeclarationLineBuilder.getRandomImportBuilder();
            lineBuilder.withItemNumber(noOfLines);
            String commodityToUse = (noOfLines==1) ? firstLineCommodityCode : secondLineCommodityCode;
            lineBuilder.withCommodityCode(commodityToUse);
            lines.add(lineBuilder.build());
        }
        return lines;
    }

    public static DeclarationLine getRandomLineWithAllFiltersData(int declarationCounter, String countryCode) {
        DeclarationLineBuilder.Builder line = DeclarationLineBuilder.getRandomImportBuilder();
        line.withOriginCountry(DeclarationLineOriginCountryBuilder.getCountryFor(countryCode));
        line.withClearanceDatetime(generateClearanceDate(declarationCounter));
        line.withCommodityCode(generateCommodityCode(declarationCounter));
        return line.build();
    }

    private static String generateCommodityCode(int declarationCounter) {
        int commodityCode = declarationCounter + COMMODITY_CODE;
        return String.valueOf(commodityCode);
    }

    private static String generateClearanceDate(int declarationCounter) {
        if (declarationCounter >=1 && declarationCounter <=2) { return "2017-01-01 00:00:00.00"; }
        if (declarationCounter >=3 && declarationCounter <=4) { return "2017-04-01 00:00:00.00"; }
        if (declarationCounter >=5 && declarationCounter <=6) { return "2017-06-01 00:00:00.00"; }
        if (declarationCounter >=7 && declarationCounter <=8) { return "2017-09-01 00:00:00.00"; }
        return "2017-12-01 00:00:00.00";
    }

    public static DeclarationLine getRandomLineWithCountryCode(String countryCode) {
        DeclarationLineBuilder.Builder line = DeclarationLineBuilder.getRandomImportBuilder();
        line.withOriginCountry(DeclarationLineOriginCountryBuilder.getCountryFor(countryCode));
        return line.build();
    }
}