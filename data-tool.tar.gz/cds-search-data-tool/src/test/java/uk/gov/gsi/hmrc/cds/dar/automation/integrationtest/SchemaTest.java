package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest;

import com.google.common.base.Charsets;
import com.google.common.io.Resources;
import org.junit.Test;
import java.io.IOException;
import java.net.URL;
import static uk.gov.gsi.hmrc.cds.dar.automation.json.JsonSchemaValidator.validateJsonData;

public class SchemaTest {

    private String jsonSchemaFileName = "CountrySchema.json";

//    @Test
//    public void validateCountrySchema() {
//        DeclarationCountry declarationCountry = DeclarationCountryBuilder.getDefault();
//
//        System.out.println(declarationCountry.toJSON());
//
//        try {
//            URL url = Resources.getResource(jsonSchemaFileName);
//            String jsonSchema = Resources.toString(url, Charsets.UTF_8);
//            validateJsonData(jsonSchema, declarationCountry.toJSON());
//        }
//        catch (IOException ex) {
//            System.out.println(ex.getMessage());
//        }
//    }
}
