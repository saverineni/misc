package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest;

import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.aggregator.Dataset;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.Declaration;
import uk.gov.gsi.hmrc.cds.dar.automation.json.JsonSchemaValidator;
import uk.gov.gsi.hmrc.cds.dar.automation.data.Faker;
import java.util.List;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static uk.gov.gsi.hmrc.cds.dar.automation.aggregator.DeclarationAggregator.*;

public class DefaultBuilderTest extends JsonSchemaValidator {
    private static final int ONE_LINE = 1;
    private static final int TWO_LINES = 2;
    private static final String ORIGIN_COUNTRY_TURKEY = "Turkey";
    private static String Q1_CLEARANCE_DATE = "01/01/2017 00:00:00";
    private Faker faker = new Faker();

    @Test
    public void checkDeclarationHasOneLine() {
        Declaration declaration = buildDefaultWithRandomDeclarationId(ONE_LINE);
        assertEquals(declaration.getLines().size(), ONE_LINE);
    }

    @Test
    public void checkDeclarationHasTwoLines() {
        Declaration declaration = buildDefaultWithRandomDeclarationId(TWO_LINES);
        assertEquals(declaration.getLines().size(), TWO_LINES);
    }

//    @Test
//    public void checkDeclarationHasQ1ClearanceDateAtLineLevel() {
//        Declaration declaration = buildDeclarationWithQ1ClearanceDate(ONE_LINE);
//        assertEquals(declaration.getLines().get(0).getClearanceDate(), Q1_CLEARANCE_DATE);
//    }

//    @Test
//    public void checkDeclarationContainsCommodityCottonAtLineLevel() {
//        Declaration declaration = buildDeclarationWithCommodityCottonLines(ONE_LINE);
//
//        assertTrue(faker.getAllCottonCommodityCodes().stream().anyMatch(str -> str.trim().equals(
//                declaration.getLines().get(0).getCommodity().getCommodityCode())));
//    }
//
//    @Test
//    public void checkDeclarationContainsCommodityTurkeyAtLineLevel() {
//        Declaration declaration = buildDeclarationWithCommodityTurkeyLines(ONE_LINE);
//
//        assertTrue(faker.getAllTurkeyCommodityCodes().stream().anyMatch(str -> str.trim().equals(
//                declaration.getLines().get(0).getCommodity().getCommodityCode())));
//    }
//
//    @Test
//    public void checkDeclarationHasOriginCountryTurkeyAtLineLevel() {
//        Declaration declaration = buildDeclarationWithOriginCountryTurkeyLines(ONE_LINE);
//        assertEquals(declaration.getLines().get(0).getOriginCountry().getCountry_name(), ORIGIN_COUNTRY_TURKEY);
//    }

}
