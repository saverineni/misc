package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest;

import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.entities.Declaration;
import static org.junit.Assert.assertEquals;
import static uk.gov.gsi.hmrc.cds.dar.automation.aggregator.DeclarationAggregator.buildRandomDeclarationWithSpecialChars;

public class RandomBuilderTest {

    private static final int ONE_LINE = 1;
    private static final int TWO_LINES = 2;

    @Test
    public void checkDeclarationHasOneLine() {
        Declaration declaration = buildRandomDeclarationWithSpecialChars(ONE_LINE);
        assertEquals(declaration.getLines().size(), ONE_LINE);
    }

    @Test
    public void checkDeclarationHasTwoLines() {
        Declaration declaration = buildRandomDeclarationWithSpecialChars(TWO_LINES);
        assertEquals(declaration.getLines().size(), TWO_LINES);
    }
}
