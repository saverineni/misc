package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest;

import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.aggregator.Dataset;
import uk.gov.gsi.hmrc.cds.dar.automation.ingestor.DeleteDataset;
import uk.gov.gsi.hmrc.cds.dar.automation.ingestor.IngestDataset;

import static org.junit.Assert.assertTrue;

public class ElasticSearchIngestorTest {

    @Test
    public void createFreeTextSearchDeclarations() {
        IngestDataset.createMultipleDeclarations(Dataset.buildJsonDatasetForFreeTextSearch());
        assertTrue("Failed to create declarations in ES - " + IngestDataset.response, IngestDataset.response.contains("\"errors\":false"));
    }

    @Test
    public void createEntryDateFilterDeclarations() {
        IngestDataset.createMultipleDeclarations(Dataset.buildJsonDatasetForEntryDateFilter());
        assertTrue("Failed to create declarations in ES - " + IngestDataset.response, IngestDataset.response.contains("\"errors\":false"));
    }

    @Test
    public void createClearanceDateFacetDeclarations() {
        IngestDataset.createMultipleDeclarations(Dataset.buildJsonDatasetForClearanceDateFilter());
        assertTrue("Failed to create declarations in ES - " + IngestDataset.response, IngestDataset.response.contains("\"errors\":false"));
    }

    @Test
    public void createOriginCountryFacetDeclarations() {
        IngestDataset.createMultipleDeclarations(Dataset.buildJsonDatasetForOriginCountryFacet());
        assertTrue("Failed to create declarations in ES - " + IngestDataset.response, IngestDataset.response.contains("\"errors\":false"));
    }

    @Test
    public void createDispatchCountryFacetDeclarations() {
        IngestDataset.createMultipleDeclarations(Dataset.buildJsonDatasetForDispatchCountryFacet());
        assertTrue("Failed to create declarations in ES - " + IngestDataset.response, IngestDataset.response.contains("\"errors\":false"));
    }

    @Test
    public void createDestinationCountryFacetDeclarations() {
        IngestDataset.createMultipleDeclarations(Dataset.buildJsonDatasetForDestinationCountryFacet());
        assertTrue("Failed to create declarations in ES - " + IngestDataset.response, IngestDataset.response.contains("\"errors\":false"));
    }

    @Test
    public void createModeOfTransportFacetDeclarations() {
        IngestDataset.createMultipleDeclarations(Dataset.buildJsonDatasetForModeOfTransport());
        assertTrue("Failed to create declarations in ES - " + IngestDataset.response, IngestDataset.response.contains("\"errors\":false"));
    }

    @Test
    public void createConsigneeEORIDeclarations() {
        IngestDataset.createMultipleDeclarations(Dataset.buildJsonDatasetForConsigneeEORI());
        assertTrue("Failed to create declarations in ES - " + IngestDataset.response, IngestDataset.response.contains("\"errors\":false"));
    }

    @Test
    public void createConsignorEORIDeclarations() {
        IngestDataset.createMultipleDeclarations(Dataset.buildJsonDatasetForConsignorEORI());
        assertTrue("Failed to create declarations in ES - " + IngestDataset.response, IngestDataset.response.contains("\"errors\":false"));
    }

    @Test
    public void createGoodsLocationFacetDeclarations() {
        IngestDataset.createMultipleDeclarations(Dataset.buildJsonDatasetForGoodsLocation());
        assertTrue("Failed to create declarations in ES - " + IngestDataset.response, IngestDataset.response.contains("\"errors\":false"));
    }

    @Test
    public void createCommodityCodeFacetDeclarations() {
        IngestDataset.createMultipleDeclarations(Dataset.buildJsonDatasetForCommodityCode());
        assertTrue("Failed to create declarations in ES - " + IngestDataset.response, IngestDataset.response.contains("\"errors\":false"));
    }

    @Test
    public void createMultipleFilterDeclarations() {
        IngestDataset.createMultipleDeclarations(Dataset.buildJsonDatasetForAllFilters());
        assertTrue("Failed to create declarations in ES - " + IngestDataset.response, IngestDataset.response.contains("\"errors\":false"));
    }

    @Test
    public void createDeclarationsWithMaxLines() {
        IngestDataset.createMultipleDeclarations(Dataset.buildJsonDeclarationWithMaxLines());
        assertTrue("Failed to create declarations in ES - " + IngestDataset.response, IngestDataset.response.contains("\"errors\":false"));
    }

    @Test
    public void createHighVolumeDeclarationsInElasticSearch() {
        IngestDataset.createMultipleDeclarations(Dataset.buildMultipleDefaultJsonDataset());
        assertTrue("Failed to create declarations in ES - " + IngestDataset.response, IngestDataset.response.contains("\"errors\":false"));
    }

    @Test
    public void deleteAllDeclarations() {
        DeleteDataset.deleteAllDeclarations();
        assertTrue("Failed to delete declaration in ES", DeleteDataset.response.contains("\"failures\":[]"));
    }
}