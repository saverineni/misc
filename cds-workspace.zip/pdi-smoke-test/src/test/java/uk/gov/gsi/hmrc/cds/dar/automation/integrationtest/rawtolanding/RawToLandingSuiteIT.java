package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.rawtolanding;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        CreateLandingPDIJobSuiteIT.class,
        LandingPopulationSuiteIT.class
})
public class RawToLandingSuiteIT extends BaseIntegrationTest {

    @BeforeClass
    public static void initialise() {
        init();
    }
}
