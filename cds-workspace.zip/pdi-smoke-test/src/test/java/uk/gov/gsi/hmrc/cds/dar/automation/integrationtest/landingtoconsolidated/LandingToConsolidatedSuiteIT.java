package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        CreateDimensionPDIJobIT.class,
        DataVaultHashCreationSuiteIT.class,
        DataVaultPopulationSuiteIT.class
})
public class LandingToConsolidatedSuiteIT extends BaseIntegrationTest {

    @BeforeClass
    public static void initialise() {
        init();
    }
}
