package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.rawtolanding.createlanding;

import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.TestHelper;

import java.util.List;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion.JobExecutor.getHiveColumnsFor;

public class MssImportHeaderTests extends BaseIntegrationTest implements TestHelper {

    @BeforeClass
    public static void testSetUp() throws Exception {
        init();
    }

    @Test
    public void checkImportHeaderColumnsInIevc() {
        String mssEntity = "Ievc";
        List<String> expectedMssDbColumns = getHiveColumnsFor(mssEntity);
        List<String> actualAutoFrameworkColumns = getConfiguredColumnsInFrameworkFor(mssEntity);

        assertThat(expectedMssDbColumns.size(), is(equalTo(actualAutoFrameworkColumns.size())));
        expectedMssDbColumns.stream().peek(expectedColumnName -> assertTrue(actualAutoFrameworkColumns.contains(expectedColumnName)));
    }

    @Test
    public void checkImportHeaderColumnsInImendetail() {
        String mssEntity = "Imendetail";
        List<String> expectedMssDbColumns = getHiveColumnsFor(mssEntity);
        List<String> actualAutoFrameworkColumns = getConfiguredColumnsInFrameworkFor(mssEntity);

        assertThat(expectedMssDbColumns.size(), is(equalTo(actualAutoFrameworkColumns.size())));
        expectedMssDbColumns.stream().peek(expectedColumnName -> assertTrue(actualAutoFrameworkColumns.contains(expectedColumnName)));
    }

    @Test
    public void checkImportHeaderColumnsInImenselect() {
        String mssEntity = "Imenselect";
        List<String> expectedMssDbColumns = getHiveColumnsFor(mssEntity);
        List<String> actualAutoFrameworkColumns = getConfiguredColumnsInFrameworkFor(mssEntity);

        assertThat(expectedMssDbColumns.size(), is(equalTo(actualAutoFrameworkColumns.size())));
        expectedMssDbColumns.stream().peek(expectedColumnName -> assertTrue(actualAutoFrameworkColumns.contains(expectedColumnName)));
    }

    @Test
    public void checkImportHeaderColumnsInInad() {
        String mssEntity = "Inad";
        List<String> expectedMssDbColumns = getHiveColumnsFor(mssEntity);
        List<String> actualAutoFrameworkColumns = getConfiguredColumnsInFrameworkFor(mssEntity);

        assertThat(expectedMssDbColumns.size(), is(equalTo(actualAutoFrameworkColumns.size())));
        expectedMssDbColumns.stream().peek(expectedColumnName -> assertTrue(actualAutoFrameworkColumns.contains(expectedColumnName)));
    }
}