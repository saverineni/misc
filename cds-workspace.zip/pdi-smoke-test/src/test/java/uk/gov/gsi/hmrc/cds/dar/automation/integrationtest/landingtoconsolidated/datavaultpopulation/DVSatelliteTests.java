package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.datavaultpopulation;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.satellites.*;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault.DimCommodityCodeHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault.DimCountryHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault.DimCurrencyHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed.*;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveDataVaultTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveDimensionHashedTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingHashedTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.TestHelper;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

public class DVSatelliteTests extends BaseIntegrationTest implements TestHelper {

    private static final String IMPORT_ENTRY_NUMBER_2B = "IM002B";
    private static final String IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_1 = "1";
    private static final String IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_1_SEQ_NO_1 = "1";
    private static final String COMMODITY_CODE = "020641";
    private static final String COUNTRY_CODE = "PK";
    private static final String CURRENCY_CODE = "PKR";
    private String entryReference;
    private LandingHeadersDeclarationHashed landingHeadersDeclarationHashed;

    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
    }

    @Before
    public void dataReaderSetup() throws Exception {
        Optional<LandingHeadersDeclarationHashed> landingHeadersDeclarationHashedOptional = HiveLandingHashedTableReader.landingHeadersDeclarationHashedForEntryNo(hive, IMPORT_ENTRY_NUMBER_2B);
        landingHeadersDeclarationHashed = landingHeadersDeclarationHashedOptional.orElse(null);
        entryReference = buildEntryReferenceForDeclaration(landingHeadersDeclarationHashed);
    }

    @Test
    public void verifySatDeclaration() {
        String satDeclarationKey = landingHeadersDeclarationHashed.getSat_declaration();

        Optional<SatDeclaration> satDeclarationOptional = HiveDataVaultTableReader.satDeclarationForSatHashDiff(hive, satDeclarationKey);
        SatDeclaration satDeclaration = satDeclarationOptional.orElse(null);

        assertThat(satDeclaration.getHub_declaration_key(), is(equalTo(landingHeadersDeclarationHashed.getHub_declaration())));
        assertThat(satDeclaration.getSat_hash_diff(), is(equalTo(landingHeadersDeclarationHashed.getSat_declaration())));
        assertThat(satDeclaration.getSat_load_datetime(), is(notNullValue()));
        assertThat(satDeclaration.getSat_load_end_datetime(), is(equalTo(null)));
        assertThat(satDeclaration.getSat_record_source(), is(equalTo(landingHeadersDeclarationHashed.getSource())));
        assertThat(satDeclaration.getEntry_number(), is(equalTo(landingHeadersDeclarationHashed.getEntry_number())));
        assertThat(satDeclaration.getEntry_date(), is(equalTo(landingHeadersDeclarationHashed.getEntry_date())));
        assertThat(satDeclaration.getEpu_number(), is(equalTo(landingHeadersDeclarationHashed.getEpu_number())));
        assertThat(satDeclaration.getEntry_type(), is(equalTo(landingHeadersDeclarationHashed.getEntry_type())));
        assertThat(satDeclaration.getDeclaration_method(), is(equalTo(landingHeadersDeclarationHashed.getDeclaration_method())));
        assertThat(satDeclaration.getTotal_excise(), is(equalTo(landingHeadersDeclarationHashed.getTotal_excise())));
        assertThat(satDeclaration.getDeclarant_representative_turn(), is(equalTo(landingHeadersDeclarationHashed.getDeclarant_representative_turn())));
        assertThat(satDeclaration.getConsignee_aeo_certificate_type_code(), is(equalTo(landingHeadersDeclarationHashed.getConsignee_aeo_certificate_type_code())));
        assertThat(satDeclaration.getConsignor_aeo_certificate_type_code(), is(equalTo(landingHeadersDeclarationHashed.getConsignor_aeo_certificate_type_code())));
        assertThat(satDeclaration.getRoute(), is(equalTo(landingHeadersDeclarationHashed.getRoute())));
        assertThat(satDeclaration.getDeclaration_import_export_indicator(), is(equalTo(landingHeadersDeclarationHashed.getDeclaration_import_export_indicator())));
        assertThat(satDeclaration.getGeneration_number(), is(equalTo(landingHeadersDeclarationHashed.getGeneration_number())));
        assertThat(satDeclaration.getImport_clearance_status(), is(equalTo(landingHeadersDeclarationHashed.getImport_clearance_status())));
        assertThat(satDeclaration.getDeclarant_aeo_certificate_type_code(), is(equalTo(landingHeadersDeclarationHashed.getDeclarant_aeo_certificate_type_code())));
        assertThat(satDeclaration.getHeader_statistical_value(), is(equalTo(landingHeadersDeclarationHashed.getHeader_statistical_value())));
        assertThat(satDeclaration.getGoods_departure_datetime(), is(equalTo(landingHeadersDeclarationHashed.getGoods_departure_datetime())));
        assertThat(satDeclaration.getCustoms_value(), is(equalTo(landingHeadersDeclarationHashed.getCustoms_value())));
        assertThat(satDeclaration.getTotal_duty(), is(equalTo(landingHeadersDeclarationHashed.getTotal_duty())));
        assertThat(satDeclaration.getTotal_vat(), is(equalTo(landingHeadersDeclarationHashed.getTotal_vat())));
        assertThat(satDeclaration.getNet_mass_total(), is(equalTo(landingHeadersDeclarationHashed.getNet_mass_total())));
        assertThat(satDeclaration.getGoods_location(), is(equalTo(landingHeadersDeclarationHashed.getGoods_location())));
        assertThat(satDeclaration.getAcceptance_date(), is(equalTo(landingHeadersDeclarationHashed.getAcceptance_date())));
        assertThat(satDeclaration.getImporter_turn_country_code(), is(equalTo(landingHeadersDeclarationHashed.getImporter_turn_country_code())));
        assertThat(satDeclaration.getPlace_of_unloading_code(), is(equalTo(landingHeadersDeclarationHashed.getPlace_of_unloading_code())));
        assertThat(satDeclaration.getFirst_deferment_approval_num(), is(equalTo(landingHeadersDeclarationHashed.getFirst_deferment_approval_num())));
        assertThat(satDeclaration.getFirst_deferment_approval_num_prefix(), is(equalTo(landingHeadersDeclarationHashed.getFirst_deferment_approval_num_prefix())));
        assertThat(satDeclaration.getDeclaration_ucr(), is(equalTo(landingHeadersDeclarationHashed.getDeclaration_ucr())));
        assertThat(satDeclaration.getItem_count(), is(equalTo(landingHeadersDeclarationHashed.getItem_count())));
        assertThat(satDeclaration.getMaster_ucr(), is(equalTo(landingHeadersDeclarationHashed.getMaster_ucr())));
        assertThat(satDeclaration.getPaying_agent_turn(), is(equalTo(landingHeadersDeclarationHashed.getPaying_agent_turn())));
        assertThat(satDeclaration.getPlace_of_loading_code(), is(equalTo(landingHeadersDeclarationHashed.getPlace_of_loading_code())));
        assertThat(satDeclaration.getSession_num(), is(equalTo(landingHeadersDeclarationHashed.getSession_num())));
        assertThat(satDeclaration.getSession_role_name(), is(equalTo(landingHeadersDeclarationHashed.getSession_role_name())));
        assertThat(satDeclaration.getStatus_of_entry(), is(equalTo(landingHeadersDeclarationHashed.getStatus_of_entry())));
        assertThat(satDeclaration.getTransport_country(), is(equalTo(landingHeadersDeclarationHashed.getTransport_country())));
        assertThat(satDeclaration.getTransport_id(), is(equalTo(landingHeadersDeclarationHashed.getTransport_id())));
        assertThat(satDeclaration.getTransport_mode_code(), is(equalTo(landingHeadersDeclarationHashed.getTransport_mode_code())));
        assertThat(satDeclaration.getDispatch_country(), is(equalTo(landingHeadersDeclarationHashed.getDispatch_country())));
        assertThat(satDeclaration.getConsignor_turn_country_code(), is(equalTo(landingHeadersDeclarationHashed.getConsignor_turn_country_code())));
        assertThat(satDeclaration.getConsignor_nad_name(), is(equalTo(landingHeadersDeclarationHashed.getConsignor_nad_name())));
        assertThat(satDeclaration.getConsignee_nad_name(), is(equalTo(landingHeadersDeclarationHashed.getConsignee_nad_name())));
        assertThat(satDeclaration.getConsignee_nad_postcode(), is(equalTo(landingHeadersDeclarationHashed.getConsignee_nad_postcode())));
        assertThat(satDeclaration.getDeclarant_nad_name(), is(equalTo(landingHeadersDeclarationHashed.getDeclarant_nad_name())));
        assertThat(satDeclaration.getCustoms_check_code(), is(equalTo(landingHeadersDeclarationHashed.getCustoms_check_code())));
        assertThat(satDeclaration.getProfile_id(), is(equalTo(landingHeadersDeclarationHashed.getProfile_id())));
        assertThat(satDeclaration.getInvoice_total_declared(), is(equalTo(landingHeadersDeclarationHashed.getInvoice_total_declared())));
    }

    @Test
    public void verifySatDeclarationLine() {
        Optional<LandingLinesDeclarationHashed> declarationLinesHashedOptional
                = HiveLandingHashedTableReader.landingLinesDeclarationHashedForEntryNoItemNo(hive, IMPORT_ENTRY_NUMBER_2B, IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_1);
        LandingLinesDeclarationHashed landingLinesDeclarationHashed = declarationLinesHashedOptional.orElse(null);
        String satDeclarationLineKey = landingLinesDeclarationHashed.getSat_declaration_line();

        Optional<SatDeclarationLine> satDeclarationLineOptional = HiveDataVaultTableReader.satDeclarationLineForSatHashDiff(hive, satDeclarationLineKey);
        SatDeclarationLine satDeclarationLine = satDeclarationLineOptional.orElse(null);

        assertThat(satDeclarationLine.getHub_declaration_line_key(), is(landingLinesDeclarationHashed.getHub_declaration_line()));
        assertThat(satDeclarationLine.getSat_hash_diff(), is(landingLinesDeclarationHashed.getSat_declaration_line()));
        assertThat(satDeclarationLine.getSat_load_datetime(), is(notNullValue()));
        assertThat(satDeclarationLine.getSat_load_end_datetime(), is(equalTo(null)));
        assertThat(satDeclarationLine.getSat_record_source(), is(equalTo(landingLinesDeclarationHashed.getSource())));
        assertThat(satDeclarationLine.getClearance_datetime(), is(equalTo(landingLinesDeclarationHashed.getClearance_datetime())));
        assertThat(satDeclarationLine.getItem_statistical_value(), is(equalTo(landingLinesDeclarationHashed.getItem_statistical_value())));
        assertThat(satDeclarationLine.getCustoms_duty_paid(), is(equalTo(landingLinesDeclarationHashed.getCustoms_duty_paid())));
        assertThat(satDeclarationLine.getVat_paid(), is(equalTo(landingLinesDeclarationHashed.getVat_paid())));
        assertThat(satDeclarationLine.getEc_supplementary_1(), is(equalTo(landingLinesDeclarationHashed.getEc_supplementary_1())));
        assertThat(satDeclarationLine.getItem_customs_value(), is(equalTo(landingLinesDeclarationHashed.getItem_customs_value())));
        assertThat(satDeclarationLine.getItem_net_mass(), is(equalTo(landingLinesDeclarationHashed.getItem_net_mass())));
        assertThat(satDeclarationLine.getItem_supplementary_units(), is(equalTo(landingLinesDeclarationHashed.getItem_supplementary_units())));
        assertThat(satDeclarationLine.getGoods_description(), is(equalTo(landingLinesDeclarationHashed.getGoods_description())));
        assertThat(satDeclarationLine.getItem_customs_check_code(), is(equalTo(landingLinesDeclarationHashed.getItem_customs_check_code())));
        assertThat(satDeclarationLine.getItem_mic_code(), is(equalTo(landingLinesDeclarationHashed.getItem_mic_code())));
        assertThat(satDeclarationLine.getItem_profile_id(), is(equalTo(landingLinesDeclarationHashed.getItem_profile_id())));
        assertThat(satDeclarationLine.getItem_consignor_nad_name(), is(equalTo(landingLinesDeclarationHashed.getItem_consignor_nad_name())));
        assertThat(satDeclarationLine.getItem_consignee_nad_name(), is(equalTo(landingLinesDeclarationHashed.getItem_consignee_nad_name())));
        assertThat(satDeclarationLine.getItem_consignee_nad_postcode(), is(equalTo(landingLinesDeclarationHashed.getItem_consignee_nad_postcode())));
        assertThat(satDeclarationLine.getVat_value(), is(equalTo(landingLinesDeclarationHashed.getVat_value())));
        assertThat(satDeclarationLine.getItem_price_declared(), is(equalTo(landingLinesDeclarationHashed.getItem_price_declared())));
    }

    @Test
    public void verifySatAdditionalInfo() {
        Optional<LandingLineAdditionalInformationHashed> landingLineAdditionalInformationHashedOptional =
                HiveLandingHashedTableReader.landingLineAdditionalInformationHashedForEntryReferenceItemNoSeqNo(
                        hive,
                        entryReference,
                        IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_1,
                        IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_1_SEQ_NO_1);
        LandingLineAdditionalInformationHashed landingLineAdditionalInformationHashed = landingLineAdditionalInformationHashedOptional.orElse(null);
        String satAdditionalInfoKey = landingLineAdditionalInformationHashed.getSat_additional_info();

        Optional<SatAdditionalInfo> satAdditionalInfoOptional = HiveDataVaultTableReader.satAdditionalInfoForSatHashDiff(hive, satAdditionalInfoKey);
        SatAdditionalInfo satAdditionalInfo= satAdditionalInfoOptional.orElse(null);

        assertThat(satAdditionalInfo.getHub_additional_info_key(), is(equalTo(landingLineAdditionalInformationHashed.getHub_additional_info())));
        assertThat(satAdditionalInfo.getSat_hash_diff(), is(equalTo(landingLineAdditionalInformationHashed.getSat_additional_info())));
        assertThat(satAdditionalInfo.getSat_load_datetime(), is(notNullValue()));
        assertThat(satAdditionalInfo.getSat_load_end_datetime(), is(equalTo(null)));
        assertThat(satAdditionalInfo.getSat_record_source(), is(equalTo(landingLineAdditionalInformationHashed.getSource())));
        assertThat(satAdditionalInfo.getGeneration_number(), is(equalTo(landingLineAdditionalInformationHashed.getGeneration_number())));
        assertThat(satAdditionalInfo.getAdditional_information_statement(), is(equalTo(landingLineAdditionalInformationHashed.getAdditional_information_statement())));
        assertThat(satAdditionalInfo.getAdditional_information_statement_type(), is(equalTo(landingLineAdditionalInformationHashed.getAdditional_information_statement_type())));
        assertThat(satAdditionalInfo.getAdditional_information_statement(), is(equalTo(landingLineAdditionalInformationHashed.getAdditional_information_statement())));
    }

    @Test
    public void verifySatCommodity() {
        Optional<DimCommodityCodeHashed> dimCommodityCodeHashedOptional =
                HiveDimensionHashedTableReader.readAllDimCommodityCodeHashedCommodityCode(hive, COMMODITY_CODE);
        DimCommodityCodeHashed dimCommodityCodeHashed = dimCommodityCodeHashedOptional.orElse(null);
        String satCommodityKey = dimCommodityCodeHashed.getSat_commodity();

        Optional<SatCommodity> satCommodityOptional = HiveDataVaultTableReader.satCommodityForSatHashDiff(hive, satCommodityKey);
        SatCommodity satCommodity = satCommodityOptional.orElse(null);

        assertThat(satCommodity.getHub_commodity_key(), is(equalTo(dimCommodityCodeHashed.getHub_commodity())));
        assertThat(satCommodity.getSat_hash_diff(), is(equalTo(dimCommodityCodeHashed.getSat_commodity())));
        assertThat(satCommodity.getSat_load_datetime(), is(notNullValue()));
        assertThat(satCommodity.getSat_load_end_datetime(), is(equalTo(null)));
        assertThat(satCommodity.getSat_record_source(), is(equalTo(SOURCE_DIM_COMMODITY_CODE)));
        assertThat(satCommodity.getCc_year(), is(equalTo(dimCommodityCodeHashed.getCc_year())));
        assertThat(satCommodity.getCc_month(), is(equalTo(dimCommodityCodeHashed.getCc_month())));
        assertThat(satCommodity.getHs_chapter(), is(equalTo(dimCommodityCodeHashed.getHs_chapter())));
        assertThat(satCommodity.getHs_chapter_heading(), is(equalTo(dimCommodityCodeHashed.getHs_chapter_heading())));
        assertThat(satCommodity.getHs_subheading(), is(equalTo(dimCommodityCodeHashed.getHs_subheading())));
        assertThat(satCommodity.getChapter_description(), is(equalTo(dimCommodityCodeHashed.getChapter_description())));
        assertThat(satCommodity.getHeading_description(), is(equalTo(dimCommodityCodeHashed.getHeading_description())));
        assertThat(satCommodity.getSubheading_description(), is(equalTo(dimCommodityCodeHashed.getSubheading_description())));
    }

    @Test
    public void verifySatCountry() {
        Optional<DimCountryHashed> dimCountryHashedOptional = HiveDimensionHashedTableReader.readAllDimCountryHashedCountryCode(hive, COUNTRY_CODE);
        DimCountryHashed dimCountryHashed = dimCountryHashedOptional.orElse(null);
        String satCountryKey = dimCountryHashed.getSat_country();

        Optional<SatCountry> satCountryOptional = HiveDataVaultTableReader.satCountryForSatHashDiff(hive, satCountryKey);
        SatCountry satCountry = satCountryOptional.orElse(null);

        assertThat(satCountry.getHub_country_key(), is(equalTo(dimCountryHashed.getHub_country())));
        assertThat(satCountry.getSat_hash_diff(), is(equalTo(dimCountryHashed.getSat_country())));
        assertThat(satCountry.getSat_load_datetime(), is(notNullValue()));
        assertThat(satCountry.getSat_load_end_datetime(), is(equalTo(null)));
        assertThat(satCountry.getSat_record_source(), is(equalTo(SOURCE_DIM_COUNTRY)));
        assertThat(satCountry.getCountry_name(), is(equalTo(dimCountryHashed.getCountry_name())));
        assertThat(satCountry.getCountry_sequence_number(), is(equalTo(dimCountryHashed.getCountry_sequence_number())));
        assertThat(satCountry.getCountry_comments(), is(equalTo(dimCountryHashed.getCountry_comments())));
    }

    @Test
    public void verifySatCurrency() {
        Optional<DimCurrencyHashed> dimCurrencyHashedOptional = HiveDimensionHashedTableReader.readAllDimCurrencyHashedCurrencyCode(hive, CURRENCY_CODE);
        DimCurrencyHashed dimCurrencyHashed = dimCurrencyHashedOptional.orElse(null);
        String satCurrencyKey = dimCurrencyHashed.getSat_currency();

        Optional<SatCurrency> satCurrencyOptional = HiveDataVaultTableReader.satCurrencyForSatHashDiff(hive, satCurrencyKey);
        SatCurrency satCurrency = satCurrencyOptional.orElse(null);

        assertThat(satCurrency.getHub_currency_key(), is(equalTo(dimCurrencyHashed.getHub_currency())));
        assertThat(satCurrency.getSat_hash_diff(), is(equalTo(dimCurrencyHashed.getSat_currency())));
        assertThat(satCurrency.getSat_load_datetime(), is(notNullValue()));
        assertThat(satCurrency.getSat_load_end_datetime(), is(equalTo(null)));
        assertThat(satCurrency.getSat_record_source(), is(equalTo(SOURCE_DIM_CURRENCY)));
        assertThat(satCurrency.getCurrency_name(), is(equalTo(dimCurrencyHashed.getCurrency_name())));
    }

    @Test
    public void verifySatDocument() {
        Optional<LandingLineDocumentHashed> landingLineDocumentHashedOptional = HiveLandingHashedTableReader.landingLineDocumentHashedForEntryReferenceItemNoSeqNo( hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_1,
                IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_1_SEQ_NO_1);
        LandingLineDocumentHashed landingLineDocumentHashed = landingLineDocumentHashedOptional.orElse(null);
        String satDocumentKey = landingLineDocumentHashed.getSat_document();

        Optional<SatDocument> satDocumentOptional = HiveDataVaultTableReader.satDocumentForSatHashDiff(hive, satDocumentKey);
        SatDocument satDocument = satDocumentOptional.orElse(null);

        assertThat(satDocument.getHub_document_key(), is(equalTo(landingLineDocumentHashed.getHub_document())));
        assertThat(satDocument.getSat_hash_diff(), is(equalTo(landingLineDocumentHashed.getSat_document())));
        assertThat(satDocument.getSat_load_datetime(), is(notNullValue()));
        assertThat(satDocument.getSat_load_end_datetime(), is(equalTo(null)));
        assertThat(satDocument.getSat_record_source(), is(equalTo(landingLineDocumentHashed.getSource())));
        assertThat(satDocument.getGeneration_number(), is(equalTo(landingLineDocumentHashed.getGeneration_number())));
        assertThat(satDocument.getItem_document_code(), is(equalTo(landingLineDocumentHashed.getItem_document_code())));
        assertThat(satDocument.getItem_document_status(), is(equalTo(landingLineDocumentHashed.getItem_document_status())));
        assertThat(satDocument.getItem_document_reference(), is(equalTo(landingLineDocumentHashed.getItem_document_reference())));
    }

    @Test
    public void verifySatPreviousDocument() {
        Optional<LandingLinePreviousDocumentHashed> landingLinePreviousDocumentHashedOptional = HiveLandingHashedTableReader.landingLinePreviousDocumentHashedForEntryReferenceItemNoSeqNo( hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_1,
                IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_1_SEQ_NO_1);
        LandingLinePreviousDocumentHashed landingLinePreviousDocumentHashed = landingLinePreviousDocumentHashedOptional.orElse(null);
        String satPreviousDocumentKey = landingLinePreviousDocumentHashed.getSat_previous_document();

        Optional<SatPreviousDocument> satPreviousDocumentOptional = HiveDataVaultTableReader.satPreviousDocumentForSatHashDiff(hive, satPreviousDocumentKey);
        SatPreviousDocument satPreviousDocument = satPreviousDocumentOptional.orElse(null);

        assertThat(satPreviousDocument.getHub_previous_document_key(), is(equalTo(landingLinePreviousDocumentHashed.getHub_previous_document())));
        assertThat(satPreviousDocument.getSat_hash_diff(), is(equalTo(landingLinePreviousDocumentHashed.getSat_previous_document())));
        assertThat(satPreviousDocument.getSat_load_datetime(), is(notNullValue()));
        assertThat(satPreviousDocument.getSat_load_end_datetime(), is(equalTo(null)));
        assertThat(satPreviousDocument.getSat_record_source(), is(equalTo(landingLinePreviousDocumentHashed.getSource())));
        assertThat(satPreviousDocument.getPrevious_document_reference(), is(equalTo(landingLinePreviousDocumentHashed.getPrevious_document_reference())));
    }

    @Test
    public void verifySatTaxLine() {
        Optional<LandingLineTaxLineHashed> landingLineTaxLineHashedOptional = HiveLandingHashedTableReader.landingLineTaxLineHashedForEntryReferenceItemNoSeqNo( hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_1,
                IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_1_SEQ_NO_1);
        LandingLineTaxLineHashed landingLineTaxLineHashed = landingLineTaxLineHashedOptional.orElse(null);
        String satTaxLineKey = landingLineTaxLineHashed.getSat_tax_line();

        Optional<SatTaxLine> satTaxLineOptional = HiveDataVaultTableReader.satTaxLineForSatHashDiff(hive, satTaxLineKey);
        SatTaxLine satTaxLine = satTaxLineOptional.orElse(null);

        assertThat(satTaxLine.getHub_tax_line_key(), is(equalTo(landingLineTaxLineHashed.getHub_tax_line())));
        assertThat(satTaxLine.getSat_hash_diff(), is(equalTo(landingLineTaxLineHashed.getSat_tax_line())));
        assertThat(satTaxLine.getSat_load_datetime(), is(notNullValue()));
        assertThat(satTaxLine.getSat_load_end_datetime(), is(equalTo(null)));
        assertThat(satTaxLine.getSat_record_source(), is(equalTo(landingLineTaxLineHashed.getSource())));
        assertThat(satTaxLine.getGeneration_number(), is(equalTo(landingLineTaxLineHashed.getGeneration_number())));
        assertThat(satTaxLine.getWaived_tax(), is(equalTo(landingLineTaxLineHashed.getWaived_tax())));
        assertThat(satTaxLine.getMethod_of_payment_code(), is(equalTo(landingLineTaxLineHashed.getMethod_of_payment_code())));
        assertThat(satTaxLine.getTax_amount(), is(equalTo(landingLineTaxLineHashed.getTax_amount())));
        assertThat(satTaxLine.getTax_type_code(), is(equalTo(landingLineTaxLineHashed.getTax_type_code())));
    }

    @Test
    public void verifySatTrader() {
        String importerTurn = landingHeadersDeclarationHashed.getImporter_turn();
        Optional<LandingTraderHashed> landingTraderHashedOptional = HiveLandingHashedTableReader.landingTraderHashedForTurn(hive, importerTurn);
        LandingTraderHashed landingTraderHashed = landingTraderHashedOptional.orElse(null);
        String satTraderKey = landingTraderHashed.getSat_trader();

        Optional<SatTrader> satTraderOptional = HiveDataVaultTableReader.satTraderForSatHashDiff(hive, satTraderKey);
        SatTrader satTrader = satTraderOptional.orElse(null);

        assertThat(satTrader.getHub_trader_key(), is(equalTo(landingTraderHashed.getHub_trader())));
        assertThat(satTrader.getSat_hash_diff(), is(equalTo(landingTraderHashed.getSat_trader())));
        assertThat(satTrader.getSat_load_datetime(), is(notNullValue()));
        assertThat(satTrader.getSat_load_end_datetime(), is(equalTo(null)));
        assertThat(satTrader.getSat_record_source(), is(equalTo(landingTraderHashed.getSource())));
        assertThat(satTrader.getName(), is(equalTo(landingTraderHashed.getName())));
        assertThat(satTrader.getSimplified_procedure_authorisations(), is(equalTo(landingTraderHashed.getSimplified_procedure_authorisations())));
        assertThat(satTrader.getTrader_name_abbreviated(), is(equalTo(landingTraderHashed.getTrader_name_abbreviated())));
        assertThat(satTrader.getCurrentind(), is(equalTo(landingTraderHashed.getCurrentind())));
    }
}
