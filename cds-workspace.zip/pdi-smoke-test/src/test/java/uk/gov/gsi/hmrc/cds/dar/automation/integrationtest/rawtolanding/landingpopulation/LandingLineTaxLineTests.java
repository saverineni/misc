package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.rawtolanding.landingpopulation;

import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveMSSTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed.LandingLineTaxLine;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.Iitl;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.Imenselect;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports.Nxenselect;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports.Nxitl;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.TestHelper;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

public class LandingLineTaxLineTests extends BaseIntegrationTest implements TestHelper {

    private static final String IMPORT_ENTRY_NUMBER_1A = "IM001A";
    private static final String IMPORT_ENTRY_NUMBER_1A_LINE_ITEM_NO = "1";
    private static final String EXPORT_ENTRY_NUMBER_2B = "EX002B";
    private static final String EXPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO = "2";

    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
    }

    @Test
    public void checkImportLandingLineTaxLines() {
        Optional<LandingLineTaxLine> landinglinetaxline = HiveLandingTableReader.readAllLandingLineTaxLineForEntryRefNo(hive, IMPORT_ENTRY_NUMBER_1A, IMPORT_ENTRY_NUMBER_1A_LINE_ITEM_NO);
        LandingLineTaxLine landingLineTaxLine = landinglinetaxline.orElse(null);
        assertThat(landingLineTaxLine, is(notNullValue(LandingLineTaxLine.class)));

        Optional<Imenselect> imenselectOptional = HiveMSSTableReader.imenselectForImportEntryNo(hive, IMPORT_ENTRY_NUMBER_1A);
        Imenselect imenselect = imenselectOptional.orElse(null);
        assertThat(imenselect, is(notNullValue(Imenselect.class)));

        Optional<Iitl> iitlByIekeyItemno = HiveMSSTableReader.iitlForIekeyIeitno(hive, imenselect.getIekey(), IMPORT_ENTRY_NUMBER_1A_LINE_ITEM_NO);
        Iitl iitl = iitlByIekeyItemno.orElse(null);
        assertThat(iitl, is(notNullValue(Iitl.class)));

        assertThat(landingLineTaxLine.getSource(), is(equalTo(SOURCE_MSS)));
        assertThat(landingLineTaxLine.getIngestion_date(), is(notNullValue()));
        assertThat(landingLineTaxLine.getItem_number(), is(equalTo(iitl.getIeitno())));
        assertThat(landingLineTaxLine.getTax_line_sequence_number(), is(equalTo(iitl.getItlnsno())));
        assertThat(landingLineTaxLine.getGeneration_number(), is(equalTo(GENERATION_NO)));
        assertThat(landingLineTaxLine.getWaived_tax(), is(equalTo(iitl.getItlnwvdtax())));
        assertThat(landingLineTaxLine.getMethod_of_payment_code(), is(equalTo(iitl.getMopcode())));
        assertThat(landingLineTaxLine.getTax_amount(), is(equalTo(iitl.getTaxamt())));
        assertThat(landingLineTaxLine.getTax_type_code(), is(equalTo(iitl.getTtycode())));
        assertThat(landingLineTaxLine.getEntry_reference(), is(imenselect.getEpuno() + "-" +
                imenselect.getImpentno() + "-" + imenselect.getStandard_dtofent().substring(0,10)));
    }

    @Test
    public void checkExportLandingLineTaxLines() {
        Optional<LandingLineTaxLine> landinglinetaxline = HiveLandingTableReader.readAllLandingLineTaxLineForEntryRefNo(hive, EXPORT_ENTRY_NUMBER_2B, EXPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO);
        LandingLineTaxLine landingLineTaxLine = landinglinetaxline.orElse(null);
        assertThat(landingLineTaxLine, is(notNullValue(LandingLineTaxLine.class)));

        Optional<Nxenselect> nxenselectOptional = HiveMSSTableReader.nxenselectForImportEntryNo(hive, EXPORT_ENTRY_NUMBER_2B);
        Nxenselect nxenselect = nxenselectOptional.orElse(null);
        assertThat(nxenselect, is(notNullValue(Nxenselect.class)));

        Optional<Nxitl> nxitlForIekeyIeitno = HiveMSSTableReader.nxitlForIekeyIeitno(hive, nxenselect.getIekey(), EXPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO);
        Nxitl nxitl = nxitlForIekeyIeitno.orElse(null);
        assertThat(nxitl, is(notNullValue(Nxitl.class)));

        assertThat(landingLineTaxLine.getSource(), is(equalTo(SOURCE_MSS)));
        assertThat(landingLineTaxLine.getIngestion_date(), is(notNullValue()));
        assertThat(landingLineTaxLine.getItem_number(), is(equalTo(nxitl.getIeitno())));
        assertThat(landingLineTaxLine.getTax_line_sequence_number(), is(equalTo(nxitl.getItlnsno())));
        assertThat(landingLineTaxLine.getGeneration_number(), is(equalTo(nxenselect.getGenerationno())));
        assertThat(landingLineTaxLine.getWaived_tax(), is(equalTo(nxitl.getItlnwvdtax())));
        assertThat(landingLineTaxLine.getMethod_of_payment_code(), is(equalTo(nxitl.getMopcode())));
        assertThat(landingLineTaxLine.getTax_amount(), is(equalTo(nxitl.getTaxamt())));
        assertThat(landingLineTaxLine.getTax_type_code(), is(equalTo(nxitl.getTtycode())));
        assertThat(landingLineTaxLine.getEntry_reference(), is(nxenselect.getEpuno() + "-" +
                nxenselect.getImpentno() + "-" + nxenselect.getStandard_dtofent().substring(0,10)));
    }
}
