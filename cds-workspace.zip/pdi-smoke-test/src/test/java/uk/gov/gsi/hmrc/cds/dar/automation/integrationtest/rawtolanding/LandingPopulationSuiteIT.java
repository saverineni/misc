package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.rawtolanding;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.rawtolanding.landingpopulation.*;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        LandingTableCountsTests.class,
        LandingHeadersDeclarationTests.class,
        LandingLinesDeclarationTests.class,
        LandingLineAdditionalInfoTests.class,
        LandingLineDocumentTests.class,
        LandingLinePreviousDocumentTests.class,
        LandingLineTaxLineTests.class,
        LandingTraderTests.class
})

public class LandingPopulationSuiteIT extends BaseIntegrationTest {

    @BeforeClass
    public static void initialise() {
        init();
    }
}
