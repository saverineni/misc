package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion.JobExecutor;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.consolidatedtoexploitationreport.ConsolidatedToExploitationSuiteIT;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.LandingToConsolidatedSuiteIT;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.rawtolanding.RawToLandingSuiteIT;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        RawToLandingSuiteIT.class,
        LandingToConsolidatedSuiteIT.class,
        ConsolidatedToExploitationSuiteIT.class
})
public class PDISuiteIntegrationTest extends BaseIntegrationTest{
    private static Logger logger = LoggerFactory.getLogger(PDISuiteIntegrationTest.class);

    @BeforeClass
    public static void invalidateCache() throws Exception {
        init();

        logger.info("Invalidating metadata cache");
        JobExecutor.invalidateAllMetadataCache();
        JobExecutor.invalidateTestDB();
    }
}
