package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.rawtolanding.landingpopulation;

import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed.*;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;

import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

public class LandingTableCountsTests extends BaseIntegrationTest {

    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
    }

    @Test
    public void checkLandingTablesCount() throws Exception {
        List<LandingHeadersDeclaration> landingHeadersDeclaration = HiveLandingTableReader.readAllLandingHeadersDeclaration(hive);
        List<LandingLinesDeclaration> landingLinesDeclaration = HiveLandingTableReader.readAllLandingLinesDeclaration(hive);
        List<LandingLineAdditionalInformation> landingLinesAdditionalInformation = HiveLandingTableReader.readAllLandingLineAdditionalInformation(hive);
        List<LandingLineDocument> landingLinesDocument = HiveLandingTableReader.readAllLandingLineDocument(hive);
        List<LandingLinePreviousDocument> landingLinesPreviousDocument = HiveLandingTableReader.readAllLandingLinePreviousDocument(hive);
        List<LandingLineTaxLine> landingLinesTaxLine = HiveLandingTableReader.readAllLandingLineTaxLine(hive);
        List<LandingTrader> landingTrader = HiveLandingTableReader.readAllLandingTrader(hive);

        assertThat(landingHeadersDeclaration, is(notNullValue()));
        assertThat(landingLinesDeclaration, is(notNullValue()));
        assertThat(landingHeadersDeclaration.size(), is(equalTo(IMPORT_DECLARATION_HEADERS_COUNT + EXPORT_DECLARATION_HEADERS_COUNT)));
        assertThat(landingLinesDeclaration.size(), is(equalTo(IMPORT_DECLARATION_LINES_COUNT + EXPORT_DECLARATION_LINES_COUNT)));
        assertThat(landingLinesAdditionalInformation, is(notNullValue()));
        assertThat(landingLinesAdditionalInformation.size(), is(equalTo(IMPORT_LINES_ADDTIONAL_INFO_COUNT + EXPORT_LINES_ADDTIONAL_INFO_COUNT)));
        assertThat(landingLinesDocument, is(notNullValue()));
        assertThat(landingLinesDocument.size(), is(equalTo(IMPORT_LINES_DOCUMENT + EXPORT_LINES_DOCUMENT)));
        assertThat(landingLinesPreviousDocument, is(notNullValue()));
        assertThat(landingLinesPreviousDocument.size(), is(equalTo(IMPORT_LINES_PREV_DOCUMENT + EXPORT_LINES_PREV_DOCUMENT)));
        assertThat(landingLinesTaxLine, is(notNullValue()));
        assertThat(landingLinesTaxLine.size(), is(equalTo(IMPORT_LINES_TAX_LINES + EXPORT_LINES_TAX_LINES)));
        assertThat(landingTrader, is(notNullValue()));
        assertThat(landingTrader.size(), is(equalTo(TRADER_COUNT)));
    }
}
