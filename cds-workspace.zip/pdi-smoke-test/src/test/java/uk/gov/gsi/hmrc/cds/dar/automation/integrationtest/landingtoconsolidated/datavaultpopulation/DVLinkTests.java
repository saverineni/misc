package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.datavaultpopulation;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.links.*;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed.*;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveDataVaultTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingHashedTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import java.util.List;
import java.util.Optional;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

public class DVLinkTests extends BaseIntegrationTest {

    private static final String IMPORT_ENTRY_NUMBER_4D = "IM004D";
    private static final String IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1 = "1";
    private static final String IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1_SEQ_NO_1 = "1";
    private static final String COMMODITY_CODE = "640391";
    private static final String CUSTOMS_PROCEDURE_CODE = "5351002";
    private String entryReference;
    private LandingHeadersDeclarationHashed landingHeadersDeclarationHashed;
    private LandingLinesDeclarationHashed landingLinesDeclarationHashed;

    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
    }

    @Before
    public void dataReaderSetup() throws Exception {
        Optional<LandingHeadersDeclarationHashed> landingHeadersDeclarationHashedOptional = HiveLandingHashedTableReader.landingHeadersDeclarationHashedForEntryNo(hive, IMPORT_ENTRY_NUMBER_4D);
        landingHeadersDeclarationHashed = landingHeadersDeclarationHashedOptional.orElse(null);
        entryReference = buildEntryReferenceForDeclaration(landingHeadersDeclarationHashed);

        Optional<LandingLinesDeclarationHashed> declarationLinesHashedOptional
                = HiveLandingHashedTableReader.landingLinesDeclarationHashedForEntryNoItemNo(hive, IMPORT_ENTRY_NUMBER_4D, IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1);
        landingLinesDeclarationHashed = declarationLinesHashedOptional.orElse(null);
    }

    @Test
    public void verifyLinkDeclarationLineDeclaration() {
        Optional<LinkDeclarationLineDeclaration> linkDeclarationLineDeclarationOptional = HiveDataVaultTableReader.linkDeclarationLineDeclarationForEntryReferenceAndItemNo(
                hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1);
        LinkDeclarationLineDeclaration linkDeclarationLineDeclaration = linkDeclarationLineDeclarationOptional.orElse(null);

        assertThat(linkDeclarationLineDeclaration.getLink_declaration_line_declaration_key(), is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_declaration())));
        assertThat(linkDeclarationLineDeclaration.getHub_declaration_line_key(), is(equalTo(landingLinesDeclarationHashed.getHub_declaration_line())));
        assertThat(linkDeclarationLineDeclaration.getHub_declaration_key(), is(equalTo(landingHeadersDeclarationHashed.getHub_declaration())));
        assertThat(linkDeclarationLineDeclaration.getEntry_reference(), is(equalTo(landingLinesDeclarationHashed.getEntry_reference())));
        assertThat(linkDeclarationLineDeclaration.getItem_number(), is(equalTo(landingLinesDeclarationHashed.getItem_number())));
        assertThat(linkDeclarationLineDeclaration.getLink_load_datetime(), is(notNullValue()));
        assertThat(linkDeclarationLineDeclaration.getLink_record_source(), is(equalTo(landingLinesDeclarationHashed.getSource())));
    }

    @Test
    public void verifyLinkDeclarationConsignorTrader(){
        Optional<LinkDeclarationConsignorTrader> linkDeclarationConsignorTraderOptional = HiveDataVaultTableReader.linkDeclarationConsignorTraderForEntryReference(hive,entryReference);
        LinkDeclarationConsignorTrader linkDeclarationConsignorTrader = linkDeclarationConsignorTraderOptional.orElse(null);

        assertThat(linkDeclarationConsignorTrader.getLink_declaration_consignor_trader_key(), is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_consignor_trader())));
        assertThat(linkDeclarationConsignorTrader.getHub_declaration_key(), is(equalTo(landingHeadersDeclarationHashed.getHub_declaration())));
        assertThat(linkDeclarationConsignorTrader.getHub_trader_key(), is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_consignor_trader_hub_trader())));
        assertThat(linkDeclarationConsignorTrader.getEntry_reference(), is(equalTo(landingHeadersDeclarationHashed.getEntry_reference())));
        assertThat(linkDeclarationConsignorTrader.getTurn(), is(equalTo(landingHeadersDeclarationHashed.getConsignor_turn())));
        assertThat(linkDeclarationConsignorTrader.getLink_load_datetime(), is(notNullValue()));
        assertThat(linkDeclarationConsignorTrader.getLink_record_source(), is(equalTo(landingHeadersDeclarationHashed.getSource())));
    }

    @Test
    public void verifyLinkDeclarationDeclarantTrader() {
        Optional<LinkDeclarationDeclarantTrader> linkDeclarationDeclarantTraderOptional = HiveDataVaultTableReader.linkDeclarationDeclarantTraderForEntryRef(hive, entryReference);
        LinkDeclarationDeclarantTrader linkDeclarationDeclarantTrader = linkDeclarationDeclarantTraderOptional.orElse(null);

        assertThat(linkDeclarationDeclarantTrader.getLink_declaration_declarant_trader_key(), is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_declarant_trader())));
        assertThat(linkDeclarationDeclarantTrader.getHub_declaration_key(), is(equalTo(landingHeadersDeclarationHashed.getHub_declaration())));
        assertThat(linkDeclarationDeclarantTrader.getHub_trader_key(), is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_declarant_trader_hub_trader())));
        assertThat(linkDeclarationDeclarantTrader.getEntry_reference(), is(equalTo(landingHeadersDeclarationHashed.getEntry_reference())));
        assertThat(linkDeclarationDeclarantTrader.getTurn(), is(equalTo(landingHeadersDeclarationHashed.getDeclarant_turn())));
        assertThat(linkDeclarationDeclarantTrader.getLink_load_datetime(), is(notNullValue()));
        assertThat(linkDeclarationDeclarantTrader.getLink_record_source(), is(equalTo(landingHeadersDeclarationHashed.getSource())));
    }

    @Test
    public void verifyLinkDeclarationDestinationCountry() {
        Optional<LinkDeclarationDestinationCountry> linkDeclarationDestinationCountryOptional = HiveDataVaultTableReader.linkDeclarationDestinationCountryForEntryRef(hive, entryReference);
        LinkDeclarationDestinationCountry linkDeclarationDestinationCountry = linkDeclarationDestinationCountryOptional.orElse(null);

        assertThat(linkDeclarationDestinationCountry.getLink_declaration_destination_country_key(), is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_destination_country())));
        assertThat(linkDeclarationDestinationCountry.getHub_declaration_key(), is(equalTo(landingHeadersDeclarationHashed.getHub_declaration())));
        assertThat(linkDeclarationDestinationCountry.getHub_country_key(), is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_destination_country_hub_country())));
        assertThat(linkDeclarationDestinationCountry.getEntry_reference(), is(equalTo(landingHeadersDeclarationHashed.getEntry_reference())));
        assertThat(linkDeclarationDestinationCountry.getIso_country_code_alpha_2(), is(equalTo(landingHeadersDeclarationHashed.getDestination_country_code())));
        assertThat(linkDeclarationDestinationCountry.getLink_load_datetime(), is(notNullValue()));
        assertThat(linkDeclarationDestinationCountry.getLink_record_source(), is(equalTo(landingHeadersDeclarationHashed.getSource())));
    }

    @Test
    public void verifyLinkDeclarationExporterTrader() {
        Optional<LinkDeclarationExporterTrader> linkDeclarationExporterTraderOptional = HiveDataVaultTableReader.linkDeclarationExporterTraderForEntryRef(hive, entryReference);
        LinkDeclarationExporterTrader linkDeclarationExporterTrader = linkDeclarationExporterTraderOptional.orElse(null);

        assertThat(linkDeclarationExporterTrader.getLink_declaration_exporter_trader_key(), is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_exporter_trader())));
        assertThat(linkDeclarationExporterTrader.getHub_declaration_key(), is(equalTo(landingHeadersDeclarationHashed.getHub_declaration())));
        assertThat(linkDeclarationExporterTrader.getHub_trader_key(), is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_exporter_trader_hub_trader())));
        assertThat(linkDeclarationExporterTrader.getEntry_reference(), is(equalTo(landingHeadersDeclarationHashed.getEntry_reference())));
        assertThat(linkDeclarationExporterTrader.getTurn(), is(equalTo(landingHeadersDeclarationHashed.getExporter_turn())));
        assertThat(linkDeclarationExporterTrader.getLink_load_datetime(), is(notNullValue()));
        assertThat(linkDeclarationExporterTrader.getLink_record_source(), is(equalTo(landingHeadersDeclarationHashed.getSource())));
    }

    @Test
    public void verifyLinkDeclarationFreightCurrency() {
        Optional<LinkDeclarationFreightCurrency> linkDeclarationFreightCurrencyOptional = HiveDataVaultTableReader.linkDeclarationFreightCurrencyForEntryRef(hive, entryReference);
        LinkDeclarationFreightCurrency linkDeclarationFreightCurrency = linkDeclarationFreightCurrencyOptional.orElse(null);

        assertThat(linkDeclarationFreightCurrency.getLink_declaration_freight_currency_key(), is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_freight_currency())));
        assertThat(linkDeclarationFreightCurrency.getHub_declaration_key(), is(equalTo(landingHeadersDeclarationHashed.getHub_declaration())));
        assertThat(linkDeclarationFreightCurrency.getHub_currency_key(), is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_freight_currency_hub_currency())));
        assertThat(linkDeclarationFreightCurrency.getEntry_reference(), is(equalTo(landingHeadersDeclarationHashed.getEntry_reference())));
        assertThat(linkDeclarationFreightCurrency.getCurrency_iso_code(), is(equalTo(landingHeadersDeclarationHashed.getFreight_currency())));
        assertThat(linkDeclarationFreightCurrency.getLink_load_datetime(), is(notNullValue()));
        assertThat(linkDeclarationFreightCurrency.getLink_record_source(), is(equalTo(landingHeadersDeclarationHashed.getSource())));
    }

    @Test
    public void verifyLinkDeclarationImporterTrader() {
        Optional<LinkDeclarationImporterTrader> linkDeclarationImporterTraderOptional = HiveDataVaultTableReader.linkDeclarationImporterTraderForEntryRef(hive, entryReference);
        LinkDeclarationImporterTrader linkDeclarationImporterTrader = linkDeclarationImporterTraderOptional.orElse(null);

        assertThat(linkDeclarationImporterTrader.getLink_declaration_importer_trader_key(), is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_importer_trader())));
        assertThat(linkDeclarationImporterTrader.getHub_declaration_key(), is(equalTo(landingHeadersDeclarationHashed.getHub_declaration())));
        assertThat(linkDeclarationImporterTrader.getHub_trader_key(), is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_importer_trader_hub_trader())));
        assertThat(linkDeclarationImporterTrader.getEntry_reference(), is(equalTo(landingHeadersDeclarationHashed.getEntry_reference())));
        assertThat(linkDeclarationImporterTrader.getTurn(), is(equalTo(landingHeadersDeclarationHashed.getImporter_turn())));
        assertThat(linkDeclarationImporterTrader.getLink_load_datetime(), is(notNullValue()));
        assertThat(linkDeclarationImporterTrader.getLink_record_source(), is(equalTo(landingHeadersDeclarationHashed.getSource())));
    }

    @Test
    public void verifyLinkDeclarationInvoiceCurrency() {
        Optional<LinkDeclarationInvoiceCurrency> linkDeclarationInvoiceCurrencyOptional = HiveDataVaultTableReader.linkDeclarationInvoiceCurrencyForEntryRef(hive, entryReference);
        LinkDeclarationInvoiceCurrency linkDeclarationInvoiceCurrency = linkDeclarationInvoiceCurrencyOptional.orElse(null);

        assertThat(linkDeclarationInvoiceCurrency.getLink_declaration_invoice_currency_key(), is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_invoice_currency())));
        assertThat(linkDeclarationInvoiceCurrency.getHub_declaration_key(), is(equalTo(landingHeadersDeclarationHashed.getHub_declaration())));
        assertThat(linkDeclarationInvoiceCurrency.getHub_currency_key(), is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_invoice_currency_hub_currency())));
        assertThat(linkDeclarationInvoiceCurrency.getEntry_reference(), is(equalTo(landingHeadersDeclarationHashed.getEntry_reference())));
        assertThat(linkDeclarationInvoiceCurrency.getCurrency_iso_code(), is(equalTo(landingHeadersDeclarationHashed.getInvoice_currency())));
        assertThat(linkDeclarationInvoiceCurrency.getLink_load_datetime(), is(notNullValue()));
        assertThat(linkDeclarationInvoiceCurrency.getLink_record_source(), is(equalTo(landingHeadersDeclarationHashed.getSource())));
    }

    @Test
    public void verifyLinkDeclarationLineAdditionalInfo() {
        Optional<LinkDeclarationLineAdditionalInfo> linkDeclarationLineAdditionalInfoOptional = HiveDataVaultTableReader.linkDeclarationLineAdditionalInfoForEntryRefAndItemNoAndSeqNo(
                hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1_SEQ_NO_1);
        LinkDeclarationLineAdditionalInfo linkDeclarationLineAdditionalInfo = linkDeclarationLineAdditionalInfoOptional.orElse(null);

        Optional<LandingLineAdditionalInformationHashed> landingLineAdditionalInfoHashedOptional = HiveLandingHashedTableReader.landingLineAdditionalInformationHashedForEntryReferenceItemNoSeqNo(
                hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1_SEQ_NO_1);
        LandingLineAdditionalInformationHashed landingLineAdditionalInfoHashed = landingLineAdditionalInfoHashedOptional.orElse(null);

        assertThat(linkDeclarationLineAdditionalInfo.getLink_declaration_line_additional_info_key(), is(equalTo(landingLineAdditionalInfoHashed.getLink_declaration_line_additional_info())));
        assertThat(linkDeclarationLineAdditionalInfo.getHub_additional_info_key(), is(equalTo(landingLineAdditionalInfoHashed.getHub_additional_info())));
        assertThat(linkDeclarationLineAdditionalInfo.getHub_declaration_line_key(), is(equalTo(landingLineAdditionalInfoHashed.getLink_declaration_line_additional_info_hub_declaration_line())));
        assertThat(linkDeclarationLineAdditionalInfo.getEntry_reference(), is(equalTo(landingLineAdditionalInfoHashed.getEntry_reference())));
        assertThat(linkDeclarationLineAdditionalInfo.getItem_number(), is(equalTo(landingLineAdditionalInfoHashed.getItem_number())));
        assertThat(linkDeclarationLineAdditionalInfo.getAdditional_information_sequence_number(), is(equalTo(landingLineAdditionalInfoHashed.getAdditional_information_sequence_number())));
        assertThat(linkDeclarationLineAdditionalInfo.getLink_load_datetime(), is(notNullValue()));
        assertThat(linkDeclarationLineAdditionalInfo.getLink_record_source(), is(equalTo(landingLineAdditionalInfoHashed.getSource())));
    }

    @Test
    public void verifyLinkDeclarationLineCommodity() {
        Optional<LinkDeclarationLineCommodity> linkDeclarationLineCommodityOptional = HiveDataVaultTableReader.linkDeclarationLineCommodityForEntryRefItemNoAndCommodityCode(
                hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1,
                COMMODITY_CODE);
        LinkDeclarationLineCommodity linkDeclarationLineCommodity = linkDeclarationLineCommodityOptional.orElse(null);

        assertThat(linkDeclarationLineCommodity.getLink_declaration_line_commodity_key(), is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_commodity())));
        assertThat(linkDeclarationLineCommodity.getHub_declaration_line_key(), is(equalTo(landingLinesDeclarationHashed.getHub_declaration_line())));
        assertThat(linkDeclarationLineCommodity.getHub_commodity_key(), is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_commodity_hub_commodity())));
        assertThat(linkDeclarationLineCommodity.getEntry_reference(), is(equalTo(landingLinesDeclarationHashed.getEntry_reference())));
        assertThat(linkDeclarationLineCommodity.getItem_number(), is(equalTo(landingLinesDeclarationHashed.getItem_number())));
        assertThat(linkDeclarationLineCommodity.getCommodity_code(), is(equalTo(landingLinesDeclarationHashed.getHs_code())));
        assertThat(linkDeclarationLineCommodity.getLink_load_datetime(), is(notNullValue()));
        assertThat(linkDeclarationLineCommodity.getLink_record_source(), is(equalTo(landingLinesDeclarationHashed.getSource())));
    }

    @Test
    public void verifyLinkDeclarationLineCustomsProcedureCode() {
        Optional<LinkDeclarationLineCustomsProcedureCode> linkDeclarationLineCustomsProcedureCodeOptional = HiveDataVaultTableReader.
                linkDeclarationLineCustomsProceduceCodeForEntryReferenceItemNoAndCPC(hive, entryReference, IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1, CUSTOMS_PROCEDURE_CODE);
        LinkDeclarationLineCustomsProcedureCode linkDeclarationLineCustomsProcedureCode = linkDeclarationLineCustomsProcedureCodeOptional.orElse(null);

        assertThat(linkDeclarationLineCustomsProcedureCode.getLink_declaration_line_customs_procedure_code_key(),
                is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_customs_procedure_code())));
        assertThat(linkDeclarationLineCustomsProcedureCode.getHub_declaration_line_key(), is(equalTo(landingLinesDeclarationHashed.getHub_declaration_line())));
        assertThat(linkDeclarationLineCustomsProcedureCode.getHub_customs_procedure_code_key(),
                is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_customs_procedure_code_hub_customs_procedure_code())));
        assertThat(linkDeclarationLineCustomsProcedureCode.getEntry_reference(), is(equalTo(landingLinesDeclarationHashed.getEntry_reference())));
        assertThat(linkDeclarationLineCustomsProcedureCode.getItem_number(), is(equalTo(landingLinesDeclarationHashed.getItem_number())));
        assertThat(linkDeclarationLineCustomsProcedureCode.getCustoms_procedure_code(), is(equalTo(landingLinesDeclarationHashed.getCustoms_procedure_code())));
        assertThat(linkDeclarationLineCustomsProcedureCode.getLink_load_datetime(), is(notNullValue()));
        assertThat(linkDeclarationLineCustomsProcedureCode.getLink_record_source(), is(equalTo(landingLinesDeclarationHashed.getSource())));
    }

    @Test
    public void verifyLinkDeclarationLineDocument() {
        Optional<LinkDeclarationLineDocument> linkDeclarationLineDocumentOptional = HiveDataVaultTableReader.linkDeclarationLineDocumentForEntryRefAndItemNoAndSeqNo(
                hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1_SEQ_NO_1);
        LinkDeclarationLineDocument linkDeclarationLineDocument = linkDeclarationLineDocumentOptional.orElse(null);

                Optional<LandingLineDocumentHashed> landingLineDocumentHashedOptional = HiveLandingHashedTableReader.landingLineDocumentHashedForEntryReferenceItemNoSeqNo(
                hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1_SEQ_NO_1);
        LandingLineDocumentHashed landingLineDocumentHashed = landingLineDocumentHashedOptional.orElse(null);

        assertThat(linkDeclarationLineDocument.getLink_declaration_line_document_key(), is(equalTo(landingLineDocumentHashed.getLink_declaration_line_document())));
        assertThat(linkDeclarationLineDocument.getHub_document_key(), is(equalTo(landingLineDocumentHashed.getHub_document())));
        assertThat(linkDeclarationLineDocument.getHub_declaration_line_key(), is(equalTo(landingLineDocumentHashed.getLink_declaration_line_document_hub_declaration_line())));
        assertThat(linkDeclarationLineDocument.getEntry_reference(), is(equalTo(landingLineDocumentHashed.getEntry_reference())));
        assertThat(linkDeclarationLineDocument.getItem_number(), is(equalTo(landingLineDocumentHashed.getItem_number())));
        assertThat(linkDeclarationLineDocument.getDocument_sequence_number(), is(equalTo(landingLineDocumentHashed.getDocument_sequence_number())));
        assertThat(linkDeclarationLineDocument.getLink_load_datetime(), is(notNullValue()));
        assertThat(linkDeclarationLineDocument.getLink_record_source(), is(equalTo(landingLineDocumentHashed.getSource())));
    }

    @Test
    public void verifyLinkDeclarationLineImporterTrader() {
        Optional<LinkDeclarationLineImporterTrader> linkDeclarationLineImporterTraderOptional = HiveDataVaultTableReader.linkDeclarationLineImporterTraderForEntryRefAndItemNo(
                hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1);
        LinkDeclarationLineImporterTrader linkDeclarationLineImporterTrader = linkDeclarationLineImporterTraderOptional.orElse(null);

        assertThat(linkDeclarationLineImporterTrader.getLink_declaration_line_importer_trader_key(), is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_importer_trader())));
        assertThat(linkDeclarationLineImporterTrader.getHub_declaration_line_key(), is(equalTo(landingLinesDeclarationHashed.getHub_declaration_line())));
        assertThat(linkDeclarationLineImporterTrader.getHub_trader_key(), is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_importer_trader_hub_trader())));
        assertThat(linkDeclarationLineImporterTrader.getEntry_reference(), is(equalTo(landingLinesDeclarationHashed.getEntry_reference())));
        assertThat(linkDeclarationLineImporterTrader.getItem_number(), is(equalTo(landingLinesDeclarationHashed.getItem_number())));
        assertThat(linkDeclarationLineImporterTrader.getTurn(), is(equalTo(landingLinesDeclarationHashed.getItem_importer_turn())));
        assertThat(linkDeclarationLineImporterTrader.getLink_load_datetime(), is(notNullValue()));
        assertThat(linkDeclarationLineImporterTrader.getLink_record_source(), is(equalTo(landingLinesDeclarationHashed.getSource())));
    }

    @Test
    public void verifyLinkDeclarationLineOriginCountry() {
        Optional<LinkDeclarationLineOriginCountry> linkDeclarationLineOriginCountryOptional = HiveDataVaultTableReader.linkDeclarationLineOriginCountryForEntryRefAndItemNo(
                hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1);
        LinkDeclarationLineOriginCountry linkDeclarationLineOriginCountry = linkDeclarationLineOriginCountryOptional.orElse(null);

        assertThat(linkDeclarationLineOriginCountry.getLink_declaration_line_origin_country_key(), is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_origin_country())));
        assertThat(linkDeclarationLineOriginCountry.getHub_declaration_line_key(), is(equalTo(landingLinesDeclarationHashed.getHub_declaration_line())));
        assertThat(linkDeclarationLineOriginCountry.getHub_country_key(), is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_origin_country_hub_country())));
        assertThat(linkDeclarationLineOriginCountry.getEntry_reference(), is(equalTo(landingLinesDeclarationHashed.getEntry_reference())));
        assertThat(linkDeclarationLineOriginCountry.getItem_number(), is(equalTo(landingLinesDeclarationHashed.getItem_number())));
        assertThat(linkDeclarationLineOriginCountry.getIso_country_code_alpha_2(), is(equalTo(landingLinesDeclarationHashed.getOrigin_country_code())));
        assertThat(linkDeclarationLineOriginCountry.getLink_load_datetime(), is(notNullValue()));
        assertThat(linkDeclarationLineOriginCountry.getLink_record_source(), is(equalTo(landingLinesDeclarationHashed.getSource())));
    }

    @Test
    public void verifyLinkDeclarationLinePreviousDocument() {
        Optional<LinkDeclarationLinePreviousDocument> linkDeclarationLinePreviousDocumentOptional = HiveDataVaultTableReader.linkDeclarationLinePreviousDocumentForEntryRefAndItemNoAndSeqNo(
                hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1_SEQ_NO_1);
        LinkDeclarationLinePreviousDocument LinkDeclarationLinePreviousDocument = linkDeclarationLinePreviousDocumentOptional.orElse(null);

        Optional<LandingLinePreviousDocumentHashed> landingLinePreviousDocumentHashedOptional = HiveLandingHashedTableReader.landingLinePreviousDocumentHashedForEntryReferenceItemNoSeqNo(
                hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1_SEQ_NO_1);
        LandingLinePreviousDocumentHashed landingLinePreviousDocumentHashed = landingLinePreviousDocumentHashedOptional.orElse(null);

        assertThat(LinkDeclarationLinePreviousDocument.getLink_declaration_line_previous_document_key(), is(equalTo(landingLinePreviousDocumentHashed.getLink_declaration_line_previous_document())));
        assertThat(LinkDeclarationLinePreviousDocument.getHub_previous_document_key(), is(equalTo(landingLinePreviousDocumentHashed.getHub_previous_document())));
        assertThat(LinkDeclarationLinePreviousDocument.getHub_declaration_line_key(), is(equalTo(landingLinePreviousDocumentHashed.getLink_declaration_line_previous_document_hub_declaration_line())));
        assertThat(LinkDeclarationLinePreviousDocument.getEntry_reference(), is(equalTo(landingLinePreviousDocumentHashed.getEntry_reference())));
        assertThat(LinkDeclarationLinePreviousDocument.getItem_number(), is(equalTo(landingLinePreviousDocumentHashed.getItem_number())));
        assertThat(LinkDeclarationLinePreviousDocument.getPrevious_document_sequence_number(), is(equalTo(landingLinePreviousDocumentHashed.getPrevious_document_sequence_number())));
        assertThat(LinkDeclarationLinePreviousDocument.getLink_load_datetime(), is(notNullValue()));
        assertThat(LinkDeclarationLinePreviousDocument.getLink_record_source(), is(equalTo(landingLinePreviousDocumentHashed.getSource())));
    }

    @Test
    public void verifyLinkDeclarationLineTaxLine() {
        Optional<LinkDeclarationLineTaxLine> linkDeclarationLineTaxLineOptional = HiveDataVaultTableReader.linkDeclarationLineTaxLineForEntryRefAndItemNoAndSeqNo(
                hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1_SEQ_NO_1);
        LinkDeclarationLineTaxLine linkDeclarationLineTaxLine = linkDeclarationLineTaxLineOptional.orElse(null);

        Optional<LandingLineTaxLineHashed> landingLineTaxLineHashedOptional = HiveLandingHashedTableReader.landingLineTaxLineHashedForEntryReferenceItemNoSeqNo(
                hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1,
                IMPORT_ENTRY_NUMBER_4D_LINE_ITEM_NO_1_SEQ_NO_1);
        LandingLineTaxLineHashed landingLineTaxLineHashed = landingLineTaxLineHashedOptional.orElse(null);

        assertThat(linkDeclarationLineTaxLine.getLink_declaration_line_tax_line_key(), is(equalTo(landingLineTaxLineHashed.getLink_declaration_line_tax_line())));
        assertThat(linkDeclarationLineTaxLine.getHub_tax_line_key(), is(equalTo(landingLineTaxLineHashed.getHub_tax_line())));
        assertThat(linkDeclarationLineTaxLine.getHub_declaration_line_key(), is(equalTo(landingLineTaxLineHashed.getLink_declaration_line_tax_line_hub_declaration_line())));
        assertThat(linkDeclarationLineTaxLine.getEntry_reference(), is(equalTo(landingLineTaxLineHashed.getEntry_reference())));
        assertThat(linkDeclarationLineTaxLine.getItem_number(), is(equalTo(landingLineTaxLineHashed.getItem_number())));
        assertThat(linkDeclarationLineTaxLine.getTax_line_sequence_number(), is(equalTo(landingLineTaxLineHashed.getTax_line_sequence_number())));
        assertThat(linkDeclarationLineTaxLine.getLink_load_datetime(), is(notNullValue()));
        assertThat(linkDeclarationLineTaxLine.getLink_record_source(), is(equalTo(landingLineTaxLineHashed.getSource())));
    }

    @Test
    public void verifyLinkDeclarationPayingAgentTrader() {
        Optional<LinkDeclarationPayingAgentTrader> linkDeclarationPayingAgentTraderOptional = HiveDataVaultTableReader.linkDeclarationPayingAgentTraderForEntryRef(hive, entryReference);
        LinkDeclarationPayingAgentTrader linkDeclarationPayingAgentTrader = linkDeclarationPayingAgentTraderOptional.orElse(null);

        assertThat(linkDeclarationPayingAgentTrader.getLink_declaration_paying_agent_trader_key(), is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_paying_agent_trader())));
        assertThat(linkDeclarationPayingAgentTrader.getHub_declaration_key(), is(equalTo(landingHeadersDeclarationHashed.getHub_declaration())));
        assertThat(linkDeclarationPayingAgentTrader.getHub_trader_key(), is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_paying_agent_trader_hub_trader())));
        assertThat(linkDeclarationPayingAgentTrader.getEntry_reference(), is(equalTo(landingHeadersDeclarationHashed.getEntry_reference())));
        assertThat(linkDeclarationPayingAgentTrader.getTurn(), is(equalTo(landingHeadersDeclarationHashed.getPaying_agent_turn())));
        assertThat(linkDeclarationPayingAgentTrader.getLink_load_datetime(), is(notNullValue()));
        assertThat(linkDeclarationPayingAgentTrader.getLink_record_source(), is(equalTo(landingHeadersDeclarationHashed.getSource())));
    }

    @Test
    public void verifyLinkDeclarationTransportCountry() {
        Optional<LinkDeclarationTransportCountry> linkDeclarationTransportCountryOptional = HiveDataVaultTableReader.linkDeclarationTransportCountryForEntryRef(hive, entryReference);
        LinkDeclarationTransportCountry linkDeclarationTransportCountry = linkDeclarationTransportCountryOptional.orElse(null);

        assertThat(linkDeclarationTransportCountry.getLink_declaration_transport_country_key(), is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_transport_country())));
        assertThat(linkDeclarationTransportCountry.getHub_declaration_key(), is(equalTo(landingHeadersDeclarationHashed.getHub_declaration())));
        assertThat(linkDeclarationTransportCountry.getHub_country_key(), is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_transport_country_hub_country())));
        assertThat(linkDeclarationTransportCountry.getEntry_reference(), is(equalTo(landingHeadersDeclarationHashed.getEntry_reference())));
        assertThat(linkDeclarationTransportCountry.getIso_country_code_alpha_2(), is(equalTo(landingHeadersDeclarationHashed.getTransport_country())));
        assertThat(linkDeclarationTransportCountry.getLink_load_datetime(), is(notNullValue()));
        assertThat(linkDeclarationTransportCountry.getLink_record_source(), is(equalTo(landingHeadersDeclarationHashed.getSource())));
    }


        private String buildEntryReferenceForDeclaration(LandingHeadersDeclarationHashed declarationHeadersHashed) {
        List<String> declarationHeaderBusinessKeys = Lists.newArrayList(
                declarationHeadersHashed.getEpu_number(),
                declarationHeadersHashed.getEntry_number().toUpperCase(),
                declarationHeadersHashed.getEntry_date().substring(0,10)
        );
        return Joiner.on("-").join(declarationHeaderBusinessKeys);
    }
}
