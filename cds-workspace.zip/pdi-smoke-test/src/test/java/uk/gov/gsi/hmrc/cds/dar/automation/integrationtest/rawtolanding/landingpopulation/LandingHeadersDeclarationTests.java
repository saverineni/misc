package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.rawtolanding.landingpopulation;

import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.standingdata.Sess;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveMSSTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed.LandingHeadersDeclaration;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports.Nxendetail;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports.Nxenselect;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports.Nxnad;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.Ievc;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.Imendetail;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.Imenselect;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.Inad;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.TestHelper;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class LandingHeadersDeclarationTests extends BaseIntegrationTest implements TestHelper {

    private static final String IMPORT_ENTRY_NUMBER_1A = "IM001A";
    private static final String EXPORT_ENTRY_NUMBER_2B = "EX002B";

    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
    }

    @Test
    public void checkImportLandingHeadersDeclarations() {
        Optional<LandingHeadersDeclaration> landingheadersdeclaration = HiveLandingTableReader.readAlllandingHeadersDeclarationForEntryNo(hive, IMPORT_ENTRY_NUMBER_1A);
        LandingHeadersDeclaration landingHeadersDeclaration = landingheadersdeclaration.orElse(null);
        assertThat(landingHeadersDeclaration, is(notNullValue(LandingHeadersDeclaration.class)));

        Optional<Imenselect> imenselectOptional = HiveMSSTableReader.imenselectForImportEntryNo(hive, IMPORT_ENTRY_NUMBER_1A);
        Imenselect imenselect = imenselectOptional.orElse(null);
        assertThat(imenselect, is(notNullValue(Imenselect.class)));

        Optional<Imendetail> imendetailOptional = HiveMSSTableReader.imendetailForIeKey(hive, imenselect.getIekey());
        Imendetail imendetail = imendetailOptional.orElse(null);
        assertThat(imendetail, is(notNullValue(Imendetail.class)));

        Optional<Inad> inadOptional = HiveMSSTableReader.inadForIeKey(hive, imenselect.getIekey());
        Inad inad = inadOptional.orElse(null);
        assertThat(inad, is(notNullValue(Inad.class)));

        Optional<Ievc> ievcOptional = HiveMSSTableReader.ievcForIeKey(hive, imenselect.getIekey());
        Ievc ievc = ievcOptional.orElse(null);
        assertThat(ievc, is(notNullValue(Ievc.class)));

        Optional<Sess> session = HiveMSSTableReader.sessForSessNo(hive, landingHeadersDeclaration.getSession_num());
        Sess sess = session.orElse(null);
        assertThat(sess, is(notNullValue(Sess.class)));

        //keep assert order of columns in landing_headers_declaration table
        assertThat(landingHeadersDeclaration.getSource(), is(equalTo(SOURCE_MSS)));
        assertThat(landingHeadersDeclaration.getIngestion_date(), is(notNullValue()));
        assertThat(landingHeadersDeclaration.getEntry_number(), is(equalTo(IMPORT_ENTRY_NUMBER_1A)));
        assertThat(landingHeadersDeclaration.getEntry_date(), is(equalTo(imenselect.getDtofent())));
        assertThat(landingHeadersDeclaration.getEpu_number(), is(equalTo(imenselect.getEpuno())));
        assertThat(landingHeadersDeclaration.getEntry_type(), is(equalTo(imenselect.getIetype())));
        assertThat(landingHeadersDeclaration.getDeclaration_method(), is(equalTo(imenselect.getDeclnmthd())));
        assertThat(landingHeadersDeclaration.getTotal_excise(), is(equalTo(imendetail.getTotexcise())));
        assertThat(landingHeadersDeclaration.getImporter_turn(), is(equalTo(imenselect.getImptrturn())));
        assertThat(landingHeadersDeclaration.getDeclarant_turn(), is(equalTo(imenselect.getDecltturn())));
        assertThat(landingHeadersDeclaration.getDeclarant_representative_turn(), is(imenselect.getDecltrep()));
        assertThat(landingHeadersDeclaration.getConsignee_aeo_certificate_type_code(), is(equalTo(imendetail.getCnsgeaeocerttycd())));
        assertThat(landingHeadersDeclaration.getDeclarant_aeo_certificate_type_code(), is(equalTo(imendetail.getDecltaeocerttycd())));
        assertThat(landingHeadersDeclaration.getRoute(), is(equalTo(imenselect.getRoe())));
        assertThat(landingHeadersDeclaration.getDeclaration_import_export_indicator(), is("I"));
        assertThat(landingHeadersDeclaration.getGeneration_number(), is(equalTo("1")));
        assertThat(landingHeadersDeclaration.getExporter_turn(), is(equalTo(null)));
        assertThat(landingHeadersDeclaration.getDestination_country_code(), is(equalTo(null)));
        assertThat(landingHeadersDeclaration.getImport_clearance_status(), is(equalTo(imendetail.getIcs())));
        assertThat(landingHeadersDeclaration.getConsignor_aeo_certificate_type_code(), is(equalTo(null)));
        assertThat(landingHeadersDeclaration.getHeader_statistical_value(), is(imendetail.getStatvalue()));
        assertThat(landingHeadersDeclaration.getGoods_departure_datetime(), is(equalTo(null)));
        assertThat(landingHeadersDeclaration.getCustoms_value(), is(imenselect.getCstmsvalue()));
        assertThat(landingHeadersDeclaration.getTotal_duty(), is(imenselect.getIetotduty()));
        assertThat(landingHeadersDeclaration.getTotal_vat(), is(equalTo(imenselect.getIetotvat())));
        assertThat(landingHeadersDeclaration.getNet_mass_total(), is(imendetail.getIenetmasstot()));
        assertThat(landingHeadersDeclaration.getGoods_location(), is(imendetail.getGdslocn()));
        assertThat(landingHeadersDeclaration.getAcceptance_date(), is(equalTo(imenselect.getAcptncdate())));
        assertThat(landingHeadersDeclaration.getImporter_turn_country_code(), is(imenselect.getImptrturncc()));
        assertThat(landingHeadersDeclaration.getPlace_of_unloading_code(), is(imenselect.getPlauldg()));
        assertThat(landingHeadersDeclaration.getFirst_deferment_approval_num(), containsString(imendetail.getFirdan()));
        assertThat(landingHeadersDeclaration.getFirst_deferment_approval_num_prefix(), is(imendetail.getFirdanpfx()));
        assertThat(landingHeadersDeclaration.getDeclaration_ucr(), is(imenselect.getDeclnucr()));
        assertThat(landingHeadersDeclaration.getItem_count(), is(imenselect.getItemcnt()));
        assertThat(landingHeadersDeclaration.getMaster_ucr(), is(equalTo(imenselect.getMasterucr())));
        assertThat(landingHeadersDeclaration.getPaying_agent_turn(), is(imenselect.getPayagntturn()));
        assertThat(landingHeadersDeclaration.getPlace_of_loading_code(), is(equalTo(null)));
        assertThat(landingHeadersDeclaration.getSession_num(), is(imenselect.getSessno()));
        assertThat(landingHeadersDeclaration.getSession_role_name(), is(sess.getRolenm()));
        assertThat(landingHeadersDeclaration.getStatus_of_entry(), is(equalTo(null)));
        assertThat(landingHeadersDeclaration.getTransport_country(), is(imendetail.getTrptcntry()));
        assertThat(landingHeadersDeclaration.getTransport_id(), is(imendetail.getTrptid()));
        assertThat(landingHeadersDeclaration.getTransport_mode_code(), is(imendetail.getTrptmodecode()));
        assertThat(landingHeadersDeclaration.getDispatch_country(), is(imenselect.getDispcntry()));
        assertThat(landingHeadersDeclaration.getConsignor_turn(), is(imenselect.getCnsgrturn()));
        assertThat(landingHeadersDeclaration.getConsignor_turn_country_code(), is(imenselect.getCnsgrturncc()));
        if (inad.getHdrnadtype().equals("1")) {
            assertThat(landingHeadersDeclaration.getConsignor_nad_name(), is(inad.getHdrnadname()));
        } else if (inad.getHdrnadtype().equals("2")) {
            assertThat(landingHeadersDeclaration.getConsignee_nad_name(), is(inad.getHdrnadname()));
        }  else if (inad.getHdrnadtype().equals("3"))  {
            assertThat(landingHeadersDeclaration.getDeclarant_nad_name(), is(inad.getHdrnadname()));
        }
        assertThat(landingHeadersDeclaration.getConsignee_nad_postocde(),  is(equalTo(null))); //TODO implement when INAD related stories are played
        assertThat(landingHeadersDeclaration.getCustoms_check_code(), is(ievc.getCccode()));
        assertThat(landingHeadersDeclaration.getProfile_id(), is(ievc.getProfid()));
        assertThat(landingHeadersDeclaration.getFreight_currency(), is(imendetail.getFrgtcrrn()));
        assertThat(landingHeadersDeclaration.getInvoice_currency(), is(imendetail.getInvcrrn()));
        assertThat(landingHeadersDeclaration.getInvoice_total_declared(), is(imendetail.getInvtotac()));
        assertThat(landingHeadersDeclaration.getEntry_reference(), is(landingHeadersDeclaration.getEpu_number() + "-" +
                landingHeadersDeclaration.getEntry_number() + "-" + landingHeadersDeclaration.getEntry_date().substring(0,10)));
    }

    @Test
    public void checkExportLandingHeadersDeclarations() {
        Optional<LandingHeadersDeclaration> landingheadersdeclaration = HiveLandingTableReader.readAlllandingHeadersDeclarationForEntryNo(hive, EXPORT_ENTRY_NUMBER_2B);
        LandingHeadersDeclaration landingHeadersDeclaration = landingheadersdeclaration.orElse(null);
        assertThat(landingHeadersDeclaration, is(notNullValue(LandingHeadersDeclaration.class)));

        Optional<Nxenselect> nxenselectOptional = HiveMSSTableReader.nxenselectForImportEntryNo(hive, EXPORT_ENTRY_NUMBER_2B);
        Nxenselect nxenselect = nxenselectOptional.orElse(null);
        assertThat(nxenselect, is(notNullValue(Nxenselect.class)));

        Optional<Nxendetail> nxendetailOptional = HiveMSSTableReader.nxendetailForIeKey(hive, nxenselect.getIekey());
        Nxendetail nxendetail = nxendetailOptional.orElse(null);
        assertThat(nxendetail, is(notNullValue(Nxendetail.class)));

        Optional<Nxnad> nxnadOptional = HiveMSSTableReader.nxnadForIeKey(hive, nxenselect.getIekey());
        Nxnad nxnad = nxnadOptional.orElse(null);
        assertThat(nxnad, is(notNullValue(Nxnad.class)));

        Optional<Sess> sessOptional = HiveMSSTableReader.sessForSessNo(hive, nxenselect.getSessno());
        Sess sess = sessOptional.orElse(null);
        assertThat(sess, is(notNullValue(Sess.class)));

        //keep assert order of columns in landing_headers_declaration table
        assertThat(landingHeadersDeclaration.getSource(), is(equalTo(SOURCE_MSS)));
        assertThat(landingHeadersDeclaration.getIngestion_date(), is(notNullValue()));
        assertThat(landingHeadersDeclaration.getEntry_number(), is(equalTo(EXPORT_ENTRY_NUMBER_2B)));
        assertThat(landingHeadersDeclaration.getEntry_date(), is(equalTo(nxenselect.getDtofent())));
        assertThat(landingHeadersDeclaration.getEpu_number(), is(equalTo(nxenselect.getEpuno())));
        assertThat(landingHeadersDeclaration.getEntry_type(), is(equalTo(nxenselect.getIetype())));
        assertThat(landingHeadersDeclaration.getDeclaration_method(), is(equalTo(nxenselect.getDeclnmthd())));
        assertThat(landingHeadersDeclaration.getTotal_excise(), is(equalTo(nxendetail.getTotexcise())));
        assertThat(landingHeadersDeclaration.getImporter_turn(), is(equalTo(null)));
        assertThat(landingHeadersDeclaration.getDeclarant_turn(), is(equalTo(nxenselect.getDecltturn())));
        assertThat(landingHeadersDeclaration.getDeclarant_representative_turn(), is(equalTo(nxendetail.getDecltrep())));
        assertThat(landingHeadersDeclaration.getConsignee_aeo_certificate_type_code(), is(equalTo(null)));
        assertThat(landingHeadersDeclaration.getDeclarant_aeo_certificate_type_code(), is(equalTo(nxendetail.getDecltaeocerttycd())));
        assertThat(landingHeadersDeclaration.getRoute(), is(equalTo(nxenselect.getRoe())));
        assertThat(landingHeadersDeclaration.getDeclaration_import_export_indicator(), is("E"));
        assertThat(landingHeadersDeclaration.getGeneration_number(), is(equalTo("1")));
        assertThat(landingHeadersDeclaration.getExporter_turn(), is(equalTo(nxenselect.getCnsgrturn())));
        assertThat(landingHeadersDeclaration.getDestination_country_code(), is(nxenselect.getDestcntry()));
        assertThat(landingHeadersDeclaration.getImport_clearance_status(), is(equalTo(nxenselect.getIcs())));
        assertThat(landingHeadersDeclaration.getConsignor_aeo_certificate_type_code(), is(equalTo(nxendetail.getCnsgraeocerttycd())));
        assertThat(landingHeadersDeclaration.getHeader_statistical_value(), is(nxendetail.getStatvalue()));
        assertThat(landingHeadersDeclaration.getGoods_departure_datetime(), is(equalTo(nxenselect.getStandard_gdsdepdt())));
        assertThat(landingHeadersDeclaration.getCustoms_value(), is(nxenselect.getCstmsvalue()));
        assertThat(landingHeadersDeclaration.getTotal_duty(), is(nxenselect.getIetotduty()));
        assertThat(landingHeadersDeclaration.getTotal_vat(), is(equalTo(nxenselect.getIetotvat())));
        assertThat(landingHeadersDeclaration.getNet_mass_total(), is(nxendetail.getIenetmasstot()));
        assertThat(landingHeadersDeclaration.getGoods_location(), is(nxenselect.getGdslocn()));
        assertThat(landingHeadersDeclaration.getAcceptance_date(), is(equalTo(nxenselect.getAcptncdate())));
        assertThat(landingHeadersDeclaration.getImporter_turn_country_code(), is(nxenselect.getImptrturncc()));
        assertThat(landingHeadersDeclaration.getPlace_of_unloading_code(), is(equalTo(null)));
        assertThat(landingHeadersDeclaration.getFirst_deferment_approval_num(), is(nxendetail.getFirdan()));
        assertThat(landingHeadersDeclaration.getFirst_deferment_approval_num_prefix(), is(nxendetail.getFirdanpfx()));
        assertThat(landingHeadersDeclaration.getDeclaration_ucr(), is(equalTo(nxenselect.getDeclnucr())));
        assertThat(landingHeadersDeclaration.getItem_count(), is(nxenselect.getItemcnt()));
        assertThat(landingHeadersDeclaration.getMaster_ucr(), is(equalTo(nxenselect.getMasterucr())));
        assertThat(landingHeadersDeclaration.getPaying_agent_turn(), is(nxenselect.getPayagntturn()));
        assertThat(landingHeadersDeclaration.getPlace_of_loading_code(), is(nxenselect.getPlaldg()));
        assertThat(landingHeadersDeclaration.getSession_num(), is(nxenselect.getSessno()));
        assertThat(landingHeadersDeclaration.getSession_role_name(), is(sess.getRolenm()));
        assertThat(landingHeadersDeclaration.getStatus_of_entry(), is(nxenselect.getSoe()));
        assertThat(landingHeadersDeclaration.getTransport_country(), is(nxendetail.getTrptcntry()));
        assertThat(landingHeadersDeclaration.getTransport_id(), is(nxendetail.getTrptid()));
        assertThat(landingHeadersDeclaration.getTransport_mode_code(), is(nxendetail.getTrptmodecode()));
        assertThat(landingHeadersDeclaration.getDispatch_country(), is(equalTo(null)));
        assertThat(landingHeadersDeclaration.getConsignor_turn(), is(nxenselect.getCnsgrturn()));
        assertThat(landingHeadersDeclaration.getConsignor_turn_country_code(), is(nxenselect.getCnsgrturncc()));
        if (nxnad.getHdrnadtype().equals("1")) {
            assertThat(landingHeadersDeclaration.getConsignor_nad_name(), is(equalTo(null)));
        } else if (nxnad.getHdrnadtype().equals("2")) {
            assertThat(landingHeadersDeclaration.getConsignee_nad_name(), is(equalTo(null)));
        }  else if (nxnad.getHdrnadtype().equals("3"))  {
            assertThat(landingHeadersDeclaration.getDeclarant_nad_name(), is(equalTo(null)));
        }
        assertThat(landingHeadersDeclaration.getConsignee_nad_postocde(),  is(equalTo(null)));
        assertThat(landingHeadersDeclaration.getCustoms_check_code(), is(equalTo(null)));
        assertThat(landingHeadersDeclaration.getProfile_id(), is(equalTo(null)));
        assertThat(landingHeadersDeclaration.getFreight_currency(), is(nxendetail.getFrgtcrrn()));
        assertThat(landingHeadersDeclaration.getInvoice_currency(), is(nxendetail.getInvcrrn()));
        assertThat(landingHeadersDeclaration.getInvoice_total_declared(), is(nxendetail.getInvtotac()));
        assertThat(landingHeadersDeclaration.getEntry_reference(), is(landingHeadersDeclaration.getEpu_number() + "-" +
                landingHeadersDeclaration.getEntry_number() + "-" + landingHeadersDeclaration.getEntry_date().substring(0,10)));
    }
}
