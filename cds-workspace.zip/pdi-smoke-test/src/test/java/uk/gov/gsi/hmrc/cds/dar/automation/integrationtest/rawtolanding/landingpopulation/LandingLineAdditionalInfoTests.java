package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.rawtolanding.landingpopulation;

import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveMSSTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed.LandingLineAdditionalInformation;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.Iiai;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.Imenselect;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports.Nxenselect;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports.Nxiai;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.TestHelper;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

public class LandingLineAdditionalInfoTests extends BaseIntegrationTest implements TestHelper {

    private static final String IMPORT_ENTRY_NUMBER_1A = "IM001A";
    private static final String IMPORT_ENTRY_NUMBER_1A_LINE_ITEM_NO = "1";
    private static final String EXPORT_ENTRY_NUMBER_2B = "EX002B";
    private static final String EXPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO = "2";

    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
    }

    @Test
    public void checkImportLandingLineAdditionalInfo() {
        Optional<LandingLineAdditionalInformation> landinglineaddtionalinfomation =
                HiveLandingTableReader.readAllLandingLineAdditionalInformationForEntryRefNo(hive, IMPORT_ENTRY_NUMBER_1A, IMPORT_ENTRY_NUMBER_1A_LINE_ITEM_NO);
        LandingLineAdditionalInformation landingLineAdditionalInformation = landinglineaddtionalinfomation.orElse(null);
        assertThat(landingLineAdditionalInformation, is(notNullValue(LandingLineAdditionalInformation.class)));

        Optional<Imenselect> imenselectOptional = HiveMSSTableReader.imenselectForImportEntryNo(hive, IMPORT_ENTRY_NUMBER_1A);
        Imenselect imenselect = imenselectOptional.orElse(null);
        assertThat(imenselect, is(notNullValue(Imenselect.class)));

        Optional<Iiai> iiaiByIekeyItemno = HiveMSSTableReader.iiaiForIekeyIeitno(hive, imenselect.getIekey(), IMPORT_ENTRY_NUMBER_1A_LINE_ITEM_NO);
        Iiai iiai = iiaiByIekeyItemno.orElse(null);
        assertThat(iiai, is(notNullValue(Iiai.class)));

        assertThat(landingLineAdditionalInformation.getSource(), is(equalTo(SOURCE_MSS)));
        assertThat(landingLineAdditionalInformation.getIngestion_date(), is(notNullValue()));
        assertThat(landingLineAdditionalInformation.getItem_number(), is(equalTo(iiai.getIeitno())));
        assertThat(landingLineAdditionalInformation.getAdditional_information_sequence_number(), is(equalTo(iiai.getAistmtsno())));
        assertThat(landingLineAdditionalInformation.getGeneration_number(), is(equalTo(GENERATION_NO)));
        assertThat(landingLineAdditionalInformation.getAdditional_information_statement(), is(equalTo(iiai.getAistmt())));
        assertThat(landingLineAdditionalInformation.getAdditional_information_statement_type(), is(equalTo(iiai.getAistmttype())));
        assertThat(landingLineAdditionalInformation.getItem_additional_information_statement(), is(equalTo(iiai.getItemaistmt())));
        assertThat(landingLineAdditionalInformation.getEntry_reference(), is(imenselect.getEpuno() + "-" +
                imenselect.getImpentno() + "-" + imenselect.getStandard_dtofent().substring(0,10)));
    }

    @Test
    public void checkExportLandingLineAdditionalInfo() {
        Optional<LandingLineAdditionalInformation> landinglineaddtionalinfomation =
                HiveLandingTableReader.readAllLandingLineAdditionalInformationForEntryRefNo(hive, EXPORT_ENTRY_NUMBER_2B, EXPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO);
        LandingLineAdditionalInformation landingLineAdditionalInformation = landinglineaddtionalinfomation.orElse(null);
        assertThat(landingLineAdditionalInformation, is(notNullValue(LandingLineAdditionalInformation.class)));

        Optional<Nxenselect> nxenselectOptional = HiveMSSTableReader.nxenselectForImportEntryNo(hive, EXPORT_ENTRY_NUMBER_2B);
        Nxenselect nxenselect = nxenselectOptional.orElse(null);
        assertThat(nxenselect, is(notNullValue(Nxenselect.class)));

        Optional<Nxiai> nxiaiForIekeyIeitno = HiveMSSTableReader.nxiaiForIekeyIeitno(hive, nxenselect.getIekey(), EXPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO);
        Nxiai nxiai = nxiaiForIekeyIeitno.orElse(null);
        assertThat(nxiai, is(notNullValue(Nxiai.class)));

        assertThat(landingLineAdditionalInformation.getSource(), is(equalTo(SOURCE_MSS)));
        assertThat(landingLineAdditionalInformation.getIngestion_date(), is(notNullValue()));
        assertThat(landingLineAdditionalInformation.getItem_number(), is(equalTo(nxiai.getIeitno())));
        assertThat(landingLineAdditionalInformation.getAdditional_information_sequence_number(), is(equalTo(nxiai.getAistmtsno())));
        assertThat(landingLineAdditionalInformation.getGeneration_number(), is(equalTo(nxenselect.getGenerationno())));
        assertThat(landingLineAdditionalInformation.getAdditional_information_statement(), is(equalTo(nxiai.getAistmt())));
        assertThat(landingLineAdditionalInformation.getAdditional_information_statement_type(), is(equalTo(nxiai.getAistmttype())));
        assertThat(landingLineAdditionalInformation.getItem_additional_information_statement(), is(equalTo(nxiai.getItemaistmt())));
        assertThat(landingLineAdditionalInformation.getEntry_reference(), is(nxenselect.getEpuno() + "-" +
                nxenselect.getImpentno() + "-" + nxenselect.getStandard_dtofent().substring(0,10)));
    }
}
