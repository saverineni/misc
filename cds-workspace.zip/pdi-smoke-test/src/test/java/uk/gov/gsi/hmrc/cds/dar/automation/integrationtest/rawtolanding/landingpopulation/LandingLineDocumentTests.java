package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.rawtolanding.landingpopulation;

import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveMSSTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed.LandingLineDocument;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.Iidc;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.Imenselect;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports.Nxenselect;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports.Nxidc;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.TestHelper;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

public class LandingLineDocumentTests extends BaseIntegrationTest implements TestHelper {

    private static final String IMPORT_ENTRY_NUMBER_1A = "IM001A";
    private static final String IMPORT_ENTRY_NUMBER_1A_LINE_ITEM_NO = "1";
    private static final String EXPORT_ENTRY_NUMBER_2B = "EX002B";
    private static final String EXPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO = "2";

    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
    }

    @Test
    public void checkImportLandingLineDocument() {
        Optional<LandingLineDocument> landinglinedocument = HiveLandingTableReader.readAllLandingLineDocumentForEntryRefNo(hive, IMPORT_ENTRY_NUMBER_1A, IMPORT_ENTRY_NUMBER_1A_LINE_ITEM_NO);
        LandingLineDocument landingLineDocument = landinglinedocument.orElse(null);
        assertThat(landingLineDocument, is(notNullValue(LandingLineDocument.class)));

        Optional<Imenselect> imenselectOptional = HiveMSSTableReader.imenselectForImportEntryNo(hive, IMPORT_ENTRY_NUMBER_1A);
        Imenselect imenselect = imenselectOptional.orElse(null);
        assertThat(imenselect, is(notNullValue(Imenselect.class)));

        Optional<Iidc> iidcByIekeyItemno = HiveMSSTableReader.iidcForIekeyIeitno(hive, imenselect.getIekey(), IMPORT_ENTRY_NUMBER_1A_LINE_ITEM_NO);
        Iidc iidc = iidcByIekeyItemno.orElse(null);
        assertThat(iidc, is(notNullValue(Iidc.class)));

        assertThat(landingLineDocument.getSource(), is(equalTo(SOURCE_MSS)));
        assertThat(landingLineDocument.getIngestion_date(), is(notNullValue()));
        assertThat(landingLineDocument.getItem_number(), is(equalTo(iidc.getIeitno())));
        assertThat(landingLineDocument.getDocument_sequence_number(), is(equalTo(iidc.getIidcdataseqno())));
        assertThat(landingLineDocument.getGeneration_number(), is(equalTo(GENERATION_NO)));
        assertThat(landingLineDocument.getItem_document_code(), is(equalTo(iidc.getItemdoccode())));
        assertThat(landingLineDocument.getItem_document_status(), is(equalTo(iidc.getItemdocstatus())));
        assertThat(landingLineDocument.getItem_document_reference(), is(equalTo(iidc.getItemdocref())));
        assertThat(landingLineDocument.getEntry_reference(), is(imenselect.getEpuno() + "-" +
                imenselect.getImpentno() + "-" + imenselect.getStandard_dtofent().substring(0,10)));
    }

    @Test
    public void checkExportLandingLineDocument() {
        Optional<LandingLineDocument> landinglinedocument = HiveLandingTableReader.readAllLandingLineDocumentForEntryRefNo(hive, EXPORT_ENTRY_NUMBER_2B, EXPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO);
        LandingLineDocument landingLineDocument = landinglinedocument.orElse(null);
        assertThat(landingLineDocument, is(notNullValue(LandingLineDocument.class)));

        Optional<Nxenselect> nxenselectOptional = HiveMSSTableReader.nxenselectForImportEntryNo(hive, EXPORT_ENTRY_NUMBER_2B);
        Nxenselect nxenselect = nxenselectOptional.orElse(null);
        assertThat(nxenselect, is(notNullValue(Nxenselect.class)));

        Optional<Nxidc> nxidcForIekeyIeitno = HiveMSSTableReader.nxidcForIekeyIeitno(hive, nxenselect.getIekey(), EXPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO);
        Nxidc nxidc = nxidcForIekeyIeitno.orElse(null);
        assertThat(nxidc, is(notNullValue(Nxidc.class)));

        assertThat(landingLineDocument.getSource(), is(equalTo(SOURCE_MSS)));
        assertThat(landingLineDocument.getIngestion_date(), is(notNullValue()));
        assertThat(landingLineDocument.getItem_number(), is(equalTo(nxidc.getIeitno())));
        assertThat(landingLineDocument.getDocument_sequence_number(), is(equalTo(nxidc.getNxidcdataseqno())));
        assertThat(landingLineDocument.getGeneration_number(), is(equalTo(nxenselect.getGenerationno())));
        assertThat(landingLineDocument.getItem_document_code(), is(equalTo(nxidc.getItemdoccode())));
        assertThat(landingLineDocument.getItem_document_status(), is(equalTo(nxidc.getItemdocstatus())));
        assertThat(landingLineDocument.getItem_document_reference(), is(equalTo(nxidc.getItemdocref())));
        assertThat(landingLineDocument.getEntry_reference(), is(nxenselect.getEpuno() + "-" +
                nxenselect.getImpentno() + "-" + nxenselect.getStandard_dtofent().substring(0,10)));
    }
}
