package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed.LandingHeadersDeclarationHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.rawtolanding.createlanding.MssImportHeaderTests;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public interface TestHelper {

    String SOURCE_MSS = "mss";
    String GENERATION_NO = "1";
    String SOURCE_DIM_COUNTRY = "dim_country";
    String SOURCE_DIM_COMMODITY_CODE = "dim_commodity_code";
    String SOURCE_DIM_CURRENCY = "dim_currency";
    String SOURCE_DIM_CUSTOMS_PROCEDURE_CODE = "dim_customs_procedure_code";
    String MSS_EXPORTS_CLASS_PATH = "uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports.";
    String MSS_IMPORTS_CLASS_PATH = "uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.";
    String MSS_STANDING_DATA_CLASS_PATH = "uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.standingdata.";

    Logger logger = LoggerFactory.getLogger(MssImportHeaderTests.class);


    default String buildEntryReferenceForDeclaration(LandingHeadersDeclarationHashed declarationHeadersHashed) {
        List<String> declarationHeaderBusinessKeys = Lists.newArrayList(
                declarationHeadersHashed.getEpu_number(),
                declarationHeadersHashed.getEntry_number().toUpperCase(),
                declarationHeadersHashed.getEntry_date().substring(0,10)
        );
        return Joiner.on("-").join(declarationHeaderBusinessKeys);
    }

    default List<String> getConfiguredColumnsInFrameworkFor(String mssEntity) {
        Object obj = findEntityInClassPath(mssEntity);
        Field[] fields = obj.getClass().getDeclaredFields();
        List<String> columns = unpackFieldsIntoList(fields);
        return columns;
    }

    default Object findEntityInClassPath(String mssEntity) {
        Object obj = new Object();
        try {
            if (mssEntity.startsWith("Nx")) {
                obj = Class.forName(MSS_EXPORTS_CLASS_PATH + mssEntity).newInstance();
            }
            else if (mssEntity.startsWith("I"))
            {
                obj = Class.forName(MSS_IMPORTS_CLASS_PATH + mssEntity).newInstance();
            }
            else
            {
                obj = Class.forName(MSS_STANDING_DATA_CLASS_PATH + mssEntity).newInstance();
            }
        }
        catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
            logger.error(e.getMessage());
        }
        return obj;
    }

    default List<String> unpackFieldsIntoList (Field[] fields){
        List<String> listOfColumns = new ArrayList<>();
        for (int i = 0; i < fields.length; i++) {
            if (i != 0) {
                listOfColumns.add(fields[i].getName());
            }
        }
        return listOfColumns;
    }
}
