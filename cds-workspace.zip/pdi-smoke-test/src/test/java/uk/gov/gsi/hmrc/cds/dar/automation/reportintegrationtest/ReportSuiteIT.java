package uk.gov.gsi.hmrc.cds.dar.automation.reportintegrationtest;

import com.google.common.base.Stopwatch;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveExploitationTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.exploitation.FactDeclarationLinesWide;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.exploitation.FactDeclarationLinesWideAll;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.exploitation.FactDeclarationLinesWideExport;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion.JobExecutor;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi.PDIStage;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;

import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class ReportSuiteIT  extends BaseIntegrationTest {
    private static Logger logger = LoggerFactory.getLogger(ReportSuiteIT.class);
    private final static Stopwatch stopwatch = Stopwatch.createStarted();

    @BeforeClass
    public static void invalidateCache() throws Exception {
        init();

        logger.info("Invalidating metadata cache");
        JobExecutor.invalidateAllMetadataCache();
        JobExecutor.invalidateTestDB();
    }

    @AfterClass
    public static void executionTime() throws Exception{
        logger.info("Total PDI Execution time: {} seconds", stopwatch.elapsed(TimeUnit.SECONDS));
    }

    @Test
    public void triggerEndToEndPDIJobs() throws Exception {
        boolean createLandingJobStatus = PDIStage.CREATE_ALL_LANDING.triggerPDIJob();
        assertTrue(createLandingJobStatus);

        boolean createDimensionsJobStatus = PDIStage.CREATE_DIMENSIONS.triggerPDIJob();
        assertTrue(createDimensionsJobStatus);

        boolean createLandingHashesJobStatus = PDIStage.CREATE_LANDING_HASHED_TABLES.triggerPDIJob();
        assertTrue(createLandingHashesJobStatus);

        boolean populateDVJobStatus = PDIStage.POPULATE_DATA_VAULT.triggerPDIJob();
        assertTrue(populateDVJobStatus);

        boolean createExploitationReportJobStatus = PDIStage.CREATE_EXPLOITATION.triggerPDIJob();
        assertTrue(createExploitationReportJobStatus);

        // check table count
        List<FactDeclarationLinesWide> factDeclarationLinesWides = HiveExploitationTableReader.readAllFactDeclarationLinesWide(hive);
        assertThat(factDeclarationLinesWides, is(notNullValue()));

        List<FactDeclarationLinesWideExport> factDeclarationLinesWideExports = HiveExploitationTableReader.readAllFactDeclarationLinesWideExport(hive);
        assertThat(factDeclarationLinesWideExports, is(notNullValue()));

        List<FactDeclarationLinesWideAll> factDeclarationLinesWideAll = HiveExploitationTableReader.readAllFactDeclarationLinesWideAll(hive);
        assertThat(factDeclarationLinesWideAll, is(notNullValue()));
    }
}
