package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated;

import com.google.common.base.Stopwatch;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault.*;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveDimensionTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi.PDIStage;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;

import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.greaterThan;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class CreateDimensionPDIJobIT extends BaseIntegrationTest {

    private static Logger logger = LoggerFactory.getLogger(CreateDimensionPDIJobIT.class);
    private final static Stopwatch stopwatch = Stopwatch.createStarted();

    @BeforeClass
    public static void testSetUp() throws Exception {
        init();
        PDIStage.CREATE_ALL_LANDING.dropAllLockTables(hive); //TODO - provide clean solution.
        PDIStage.CREATE_DIMENSIONS.dropTablesInStage(hive);
        boolean jobStatus = PDIStage.CREATE_DIMENSIONS.triggerPDIJob();
        assertTrue(jobStatus);
    }

    @AfterClass
    public static void cacheSourceTables() throws Exception {
        PDIStage.CREATE_ALL_LANDING.cacheSourceTables();
        PDIStage.CREATE_DIMENSIONS.cacheSourceTables();
        logger.info("Total Execution time: {} seconds", stopwatch.elapsed(TimeUnit.SECONDS));
    }

    @Test
    public void buildDimensionTables() throws Exception {

        List<DimCommodityCode> dimCommodityCode = HiveDimensionTableReader.readAllDimCommodityCode(hive);
        List<DimCountry> dimCountry = HiveDimensionTableReader.readAllDimCountry(hive);
        List<DimCurrency> dimCurrency = HiveDimensionTableReader.readAllDimCurrency(hive);
        List<DimCustomsProcedureCode> dimCustomsProcedureCode = HiveDimensionTableReader.readAllDimCustomsProcedureCode(hive);
        List<DimCustomsRoute> dimCustomsRoute = HiveDimensionTableReader.readAllDimCustomsRoute(hive);
        List<DimDate> dimDate = HiveDimensionTableReader.readAllDimDate(hive);
        List<DimEpu> dimEpu = HiveDimensionTableReader.readAllDimEpu(hive);
        List<DimImportClearanceStatus> dimImportClearanceStatus = HiveDimensionTableReader.readAllDimImportClearanceStatus(hive);

        assertThat(dimCommodityCode, is(notNullValue()));
        assertThat(dimCommodityCode.size(), is(greaterThan(0)));
        assertThat(dimCountry, is(notNullValue()));
        assertThat(dimCountry.size(), is(greaterThan(0)));
        assertThat(dimCurrency, is(notNullValue()));
        assertThat(dimCurrency.size(), is(greaterThan(0)));
        assertThat(dimCustomsProcedureCode, is(notNullValue()));
        assertThat(dimCustomsProcedureCode.size(), is(greaterThan(0)));
        assertThat(dimCustomsRoute, is(notNullValue()));
        assertThat(dimCustomsRoute.size(), is(greaterThan(0)));
        assertThat(dimDate, is(notNullValue()));
        assertThat(dimDate.size(), is(greaterThan(0)));
        assertThat(dimEpu, is(notNullValue()));
        assertThat(dimEpu.size(), is(greaterThan(0)));
        assertThat(dimImportClearanceStatus, is(notNullValue()));
        assertThat(dimImportClearanceStatus.size(), is(greaterThan(0)));
    }
}