package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.datavaultpopulation.DVHubTests;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.datavaultpopulation.DVLinkTests;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.datavaultpopulation.DVSatelliteTests;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.datavaultpopulation.PopulateDVTablesPDIJobTests;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        PopulateDVTablesPDIJobTests.class,
        DVHubTests.class,
        DVSatelliteTests.class,
        DVLinkTests.class})

public class DataVaultPopulationSuiteIT extends BaseIntegrationTest {
    @BeforeClass
    public static void initialise() {
        init();
    }
}
