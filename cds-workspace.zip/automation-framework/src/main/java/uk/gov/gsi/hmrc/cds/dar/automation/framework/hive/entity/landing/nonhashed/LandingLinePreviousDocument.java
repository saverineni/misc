package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by developer on 08/08/17.
 */
@Data
public class LandingLinePreviousDocument implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select source, ingestion_date, item_number, previous_document_sequence_number, " +
                                                    "previous_document_reference, entry_reference " +
                                                    "from landing_line_previous_document";

    private String source;
    private String ingestion_date;
    private String item_number;
    private String previous_document_sequence_number;
    private String previous_document_reference;
    private String entry_reference;

}
