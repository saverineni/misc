package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports;


import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;
/**
 * Created by smalavalli on 22/12/16.
 */
@Data
public class Imendetail implements HiveEntity {
    public static final String SELECT_ALL_QUERY = "select iekey, ievrno, ics, gdslocn, firdan, firdanpfx, euarrlocncode, trptmodeinld, totexcise, cnsgeaeocerttycd, decltaeocerttycd, statvalue, ienetmasstot, trptcntry, trptid, trptmodecode, frgtcrrn, invcrrn, invtotac from imendetail";

    private String iekey;
    private String ievrno;
    private String ics;
    private String gdslocn;
    private String firdan;
    private String firdanpfx;
    private String euarrlocncode;
    private String trptmodeinld;
    private String totexcise;
    private String cnsgeaeocerttycd;
    private String decltaeocerttycd;
    private String statvalue;
    private String ienetmasstot;
    private String trptcntry;
    private String trptid;
    private String trptmodecode;
    private String frgtcrrn;
    private String invcrrn;
    private String invtotac;
}