package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class DimCurrencyHashed implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select currency_id, currency_iso_code, currency_name, hub_currency, sat_currency from dim_currency_hashed";

    private String currency_id;
    private String currency_iso_code;
    private String currency_name;
    private String hub_currency;
    private String sat_currency;
}
