package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.satellites;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class SatTaxLine implements HiveEntity {

    public static final String SELECT_ALL_QUERY ="select hub_tax_line_key, sat_hash_diff, sat_load_datetime, sat_load_end_datetime, sat_record_source, generation_number, waived_tax, method_of_payment_code, tax_amount, tax_type_code from sat_tax_line ";

    private String hub_tax_line_key;
    private String sat_hash_diff;
    private String sat_load_datetime;
    private String sat_load_end_datetime;
    private String sat_record_source;
    private String generation_number;
    private String waived_tax;
    private String method_of_payment_code;
    private String tax_amount;
    private String tax_type_code;
}
