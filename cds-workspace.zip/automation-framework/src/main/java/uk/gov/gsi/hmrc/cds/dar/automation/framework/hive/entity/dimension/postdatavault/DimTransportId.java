package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.postdatavault;

import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

import javax.jdo.annotations.DatastoreIdentity;

@DatastoreIdentity
public class DimTransportId implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select transport_id from dim_transport_id";

    private String transport_id;
}
