package uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion.DataExtractor;

import java.util.List;

/**
 * Created by smalavalli on 24/01/17.
 */
public interface PostTestJob {
    Logger logger = LoggerFactory.getLogger(PostTestJob.class);
    DataExtractor dataExtractor = new DataExtractor();

    List<String> tablesToCache();

    /**
     * extracts data into hdfs automation cache
     */
    default void cacheSourceTables() {
        dataExtractor.extractDataFromTableUsingHive(tablesToCache());
    }
}
