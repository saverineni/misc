package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by smalavalli on 22/12/16.
 */
@Data
public class Iina implements HiveEntity{
    public static final String SELECT_ALL_QUERY = "select iekey, ieitno, itemnadtype, itemnadname, itemnadstreet, itemnadcity, itemnadpostcode, itemnadcntry from iina";

    private String iekey;
    private String ieitno;
    private String itemnadtype;
    private String itemnadname;
    private String itemnadstreet;
    private String itemnadcity;
    private String itemnadpostcode;
    private String itemnadcntry;

}
