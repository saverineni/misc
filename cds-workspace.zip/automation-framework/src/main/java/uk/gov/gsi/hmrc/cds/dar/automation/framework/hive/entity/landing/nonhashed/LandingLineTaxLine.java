package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by developer on 08/08/17.
 */
@Data
public class LandingLineTaxLine implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select source, ingestion_date, item_number, tax_line_sequence_number, generation_number, " +
                                                    "waived_tax, method_of_payment_code, tax_amount, tax_type_code, entry_reference " +
                                                    "from landing_line_tax_line";

    private String source;
    private String ingestion_date;
    private String item_number;
    private String tax_line_sequence_number;
    private String generation_number;
    private String waived_tax;
    private String method_of_payment_code;
    private String tax_amount;
    private String tax_type_code;
    private String entry_reference;

}
