package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class Inad implements HiveEntity{
    public static final String SELECT_ALL_QUERY = "select iekey, hdrnadtype, hdrnadname, hdrnadstreet, hdrnadcity, hdrnadpostcode, hdrnadcntry from inad";

    private String iekey;
    private String hdrnadtype;
    private String hdrnadname;
    private String hdrnadstreet;
    private String hdrnadcity;
    private String hdrnadpostcode;
    private String hdrnadcntry;

}
