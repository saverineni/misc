package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.satellites;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by smalavalli on 19/01/17.
 */
@Data
public class SatCountry implements HiveEntity{

    public static final String SELECT_ALL_QUERY ="select hub_country_key, sat_hash_diff, sat_load_datetime, sat_load_end_datetime, sat_record_source, country_name, country_sequence_number, country_comments from sat_country";

    private String hub_country_key;
    private String sat_hash_diff;
    private String sat_load_datetime;
    private String sat_load_end_datetime;
    private String sat_record_source;
    private String country_name;
    private String country_sequence_number;
    private String country_comments;
}
