package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.hubs;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by smalavalli on 17/01/17.
 */
@Data
public class HubDeclarationLine implements HiveEntity {
    public static final String SELECT_ALL_QUERY = "select hub_declaration_line_key, entry_reference, item_number, hub_load_datetime, hub_record_source from hub_declaration_line";

    private String hub_declaration_line_key;
    private String entry_reference;
    private String item_number;
    private String hub_load_datetime;
    private String hub_record_source;

}
