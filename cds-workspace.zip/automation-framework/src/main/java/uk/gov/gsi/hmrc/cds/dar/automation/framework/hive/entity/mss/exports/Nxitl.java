package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by developer on 08/08/17.
 */
@Data
public class Nxitl implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select iekey, ieitno, generationno, itlnsno, itlnwvdtax, mopcode, taxamt, ttycode from nxitl";

    private String iekey;
    private String ieitno;
    private String generationno;
    private String itlnsno;
    private String itlnwvdtax;
    private String mopcode;
    private String taxamt;
    private String ttycode;

}
