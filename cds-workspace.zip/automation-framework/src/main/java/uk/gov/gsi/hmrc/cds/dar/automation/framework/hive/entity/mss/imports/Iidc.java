package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class Iidc implements HiveEntity{
    public static final String SELECT_ALL_QUERY = "select iekey, ieitno, da_iv_id, edh_da_file_date, standard_edh_da_file_date, edh_da_sequence_number, edh_da_load_date, edh_da_health_warning, edh_da_purge_date, clrncdate, standard_clrncdate, itemdoccode, itemdoclng, itemdocreason, itemdocstatus, itemdocpart, itemdocqty, itemdocref, iidcdataseqno from iidc";

    private String iekey;
    private String ieitno;
    private String da_iv_id;
    private String edh_da_file_date;
    private String standard_edh_da_file_date;
    private String edh_da_sequence_number;
    private String edh_da_load_date;
    private String edh_da_health_warning;
    private String edh_da_purge_date;
    private String clrncdate;
    private String standard_clrncdate;
    private String itemdoccode;
    private String itemdoclng;
    private String itemdocreason;
    private String itemdocstatus;
    private String itemdocpart;
    private String itemdocqty;
    private String itemdocref;
    private String iidcdataseqno;
}
