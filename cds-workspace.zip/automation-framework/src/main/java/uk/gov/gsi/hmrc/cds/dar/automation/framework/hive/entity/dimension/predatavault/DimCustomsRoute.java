package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class DimCustomsRoute implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select customs_route_id, customs_route_code, description from dim_customs_route";

    private String customs_route_id;
    private String customs_route_code;
    private String description;

}