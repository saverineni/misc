package uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion.mss;

import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.util.List;
import java.util.Objects;

import static java.util.stream.Collectors.toList;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.ResourceManager.readResource;

/**
 * Created by smalavalli on 09/12/16.
 */
public class QueryBuilder {
    private static Logger logger = LoggerFactory.getLogger(QueryBuilder.class);

    public String buildHiveInsertSql(String tableName, String csvDataPath, String dbName) {

        logger.info("Tablename: {} ", tableName);
        logger.info("CSVDataPath: {} ", csvDataPath);
        BufferedReader bufferedReader = readResource(csvDataPath);

        Objects.requireNonNull(bufferedReader, "BufferedReader cannot be null. Check CSV path");
        List<String> insertQueries = bufferedReader.lines()
                .skip(1)
                .map(csvRow -> QueryBuilder.buildInsertSql(tableName, csvRow))
                .collect(toList());

        List<String> values = insertQueries.stream()
                .map(sql -> sql.split("values")[1])
                .collect(toList());

        String joinedValues = Joiner.on(",").join(values);
        String hiveInsertSql = String.format("INSERT INTO %s.%s VALUES %s", dbName, tableName, joinedValues);

        logger.info(hiveInsertSql);
        return hiveInsertSql;
    }

    private static String buildInsertSql(String tableName, String csvRow) {
        return insertSqlUsingSplitAndJoin(tableName, csvRow);
    }

    private static String insertSqlUsingSplitAndJoin(String table, String csvRow) {
        List<String> valuesList = Splitter.on(",").trimResults().splitToList(csvRow);
        String values = Joiner.on("\",\"").join(valuesList);
        return String.format("INSERT INTO %s values (\"%s\")", table, values);
    }

}
