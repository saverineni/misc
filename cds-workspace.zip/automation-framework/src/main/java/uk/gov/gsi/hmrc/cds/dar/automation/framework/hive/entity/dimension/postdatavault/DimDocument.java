package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.postdatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class DimDocument implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select declaration_line_reference, entry_reference, item_number, document_sequence_number, generation_number, item_document_code, item_document_status, item_document_reference, item_document_actioned from dim_document";

    private String declaration_line_reference;
    private String entry_reference;
    private String item_number;
    private String document_sequence_number;
    private String generation_number;
    private String item_document_code;
    private String item_document_status;
    private String item_document_reference;
    private String item_document_actioned;
}
