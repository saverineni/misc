package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by developer on 08/08/17.
 */
@Data
public class Iiai implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select iekey, ieitno, aistmtsno, aistmt, aistmttype, itemaistmt from iiai";

    private String iekey;
    private String ieitno;
    private String aistmtsno;
    private String aistmt;
    private String aistmttype;
    private String itemaistmt;

}
