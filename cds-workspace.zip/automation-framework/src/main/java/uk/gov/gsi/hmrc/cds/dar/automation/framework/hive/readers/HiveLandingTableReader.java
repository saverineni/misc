package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers;

import org.codejargon.fluentjdbc.api.FluentJdbc;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed.*;

import java.util.List;
import java.util.Optional;

/**
 * Created by smalavalli on 22/12/16.
 */
public class HiveLandingTableReader {

    private static Logger logger = LoggerFactory.getLogger(HiveLandingTableReader.class);

    public static List<LandingHeadersDeclaration> readAllLandingHeadersDeclaration(FluentJdbc hive) {
        logger.info("Reading all data from table landing_headers_declaration");
        return HiveTableReader.readTable(hive, LandingHeadersDeclaration.SELECT_ALL_QUERY, LandingHeadersDeclaration.class);
    }

    public static Optional<LandingHeadersDeclaration> readAlllandingHeadersDeclarationForEntryNo(FluentJdbc hive, String entryNo) {
        logger.info("Reading all data from table landing_headers_declaration for entry_number {}", entryNo);
        List<LandingHeadersDeclaration> landingHeadersDeclarations = readAllLandingHeadersDeclaration(hive);
        return landingHeadersDeclarations
                .stream()
                .filter(row ->  row.getEntry_number().equals(entryNo))
                .findFirst();
    }

    public static List<LandingLineAdditionalInformation> readAllLandingLineAdditionalInformation(FluentJdbc hive) {
        logger.info("Reading all data from table landing_line_additional_information");
        return HiveTableReader.readTable(hive, LandingLineAdditionalInformation.SELECT_ALL_QUERY, LandingLineAdditionalInformation.class);
    }

    public static Optional<LandingLineAdditionalInformation> readAllLandingLineAdditionalInformationForEntryRefNo(FluentJdbc hive, String entryRefNo, String itemNo) {
        logger.info("Reading all data from table landing_line_additional_information for entry_reference no {} and item_number {}", entryRefNo, itemNo);
        List<LandingLineAdditionalInformation> landingLineAdditionalInformation = readAllLandingLineAdditionalInformation(hive);
        return landingLineAdditionalInformation
                .stream()
                .filter(row ->  row.getEntry_reference().contains(entryRefNo) && row.getItem_number().equals(itemNo))
                .findFirst();
    }

    public static Optional<LandingLineAdditionalInformation> readAllLandingLineAdditionalInformationForEntryRefNoAndSeqNo(FluentJdbc hive, String entryRefNo, String itemNo, String SeqNo) {
        logger.info("Reading all data from table landing_line_additional_information for entry_reference no {} and item_number {} and additional_information_sequence_number", entryRefNo, itemNo, SeqNo);
        List<LandingLineAdditionalInformation> landingLineAdditionalInformation = readAllLandingLineAdditionalInformation(hive);
        return landingLineAdditionalInformation
                .stream()
                .filter(row ->  row.getEntry_reference().contains(entryRefNo) && row.getItem_number().equals(itemNo) && row.getAdditional_information_sequence_number().equals(SeqNo))
                .findFirst();
    }

    public static List<LandingLineDocument> readAllLandingLineDocument(FluentJdbc hive) {
        logger.info("Reading all data from table landing_line_document");
        return HiveTableReader.readTable(hive, LandingLineDocument.SELECT_ALL_QUERY, LandingLineDocument.class);
    }

    public static Optional<LandingLineDocument> readAllLandingLineDocumentForEntryRefNo(FluentJdbc hive, String entryRefNo, String itemNo) {
        logger.info("Reading all data from table landing_line_document for entry_reference {} and item_number {}", entryRefNo, itemNo);
        List<LandingLineDocument> landingLineDocument = readAllLandingLineDocument(hive);
        return landingLineDocument
                .stream()
                .filter(row ->  row.getEntry_reference().contains(entryRefNo) && row.getItem_number().equals(itemNo))
                .findFirst();
    }

    public static Optional<LandingLineDocument> readAllLandingLineDocumentForEntryRefNoAndSeqNo(FluentJdbc hive, String entryRefNo, String itemNo, String SeqNo) {
        logger.info("Reading all data from table landing_line_document for entry_reference {} and item_number {} and document_sequence_number {}", entryRefNo, itemNo, SeqNo);
        List<LandingLineDocument> landingLineDocument = readAllLandingLineDocument(hive);
        return landingLineDocument
                .stream()
                .filter(row ->  row.getEntry_reference().contains(entryRefNo) && row.getItem_number().equals(itemNo) && row.getDocument_sequence_number().equals(SeqNo))
                .findFirst();
    }

    public static List<LandingLinePreviousDocument> readAllLandingLinePreviousDocument(FluentJdbc hive) {
        logger.info("Reading all data from table landing_line_previous_document");
        return HiveTableReader.readTable(hive, LandingLinePreviousDocument.SELECT_ALL_QUERY, LandingLinePreviousDocument.class);
    }

    public static Optional<LandingLinePreviousDocument> readAllLandingLinePreviousDocumentForEntryRefNo(FluentJdbc hive, String entryRefNo, String itemNo) {
        logger.info("Reading all data from table landing_line_previous_document for entry_reference {} and item_number {}", entryRefNo, itemNo);
        List<LandingLinePreviousDocument> landingLinePreviousDocument = readAllLandingLinePreviousDocument(hive);
        return landingLinePreviousDocument
                .stream()
                .filter(row ->  row.getEntry_reference().contains(entryRefNo) && row.getItem_number().equals(itemNo))
                .findFirst();
    }

    public static Optional<LandingLinePreviousDocument> readAllLandingLinePreviousDocumentForEntryRefNoAndSeqNo(FluentJdbc hive, String entryRefNo, String itemNo, String SeqNo) {
        logger.info("Reading all data from table landing_line_previous_document for entry_reference {} and item_number {} and previous_document_sequence_number", entryRefNo, itemNo, SeqNo);
        List<LandingLinePreviousDocument> landingLinePreviousDocument = readAllLandingLinePreviousDocument(hive);
        return landingLinePreviousDocument
                .stream()
                .filter(row ->  row.getEntry_reference().contains(entryRefNo) && row.getItem_number().equals(itemNo) && row.getPrevious_document_sequence_number().equals(SeqNo))
                .findFirst();
    }

    public static List<LandingLineTaxLine> readAllLandingLineTaxLine(FluentJdbc hive) {
        logger.info("Reading all data from table landing_line_tax_line");
        return HiveTableReader.readTable(hive, LandingLineTaxLine.SELECT_ALL_QUERY, LandingLineTaxLine.class);
    }

    public static Optional<LandingLineTaxLine> readAllLandingLineTaxLineForEntryRefNo(FluentJdbc hive, String entryRefNo, String itemNo) {
        logger.info("Reading all data from table landing_line_tax_line for entry_reference {} and item_number {}", entryRefNo, itemNo);
        List<LandingLineTaxLine> landingLineTaxLine = readAllLandingLineTaxLine(hive);
        return landingLineTaxLine
                .stream()
                .filter(row ->  row.getEntry_reference().contains(entryRefNo) && row.getItem_number().equals(itemNo))
                .findFirst();
    }

    public static Optional<LandingLineTaxLine> readAllLandingLineTaxLineForEntryRefNoAndSeqNo(FluentJdbc hive, String entryRefNo, String itemNo, String SeqNo) {
        logger.info("Reading all data from table landing_line_tax_line for entry_reference {} and item_number {} and tax_line_sequence_number", entryRefNo, itemNo, SeqNo);
        List<LandingLineTaxLine> landingLineTaxLine = readAllLandingLineTaxLine(hive);
        return landingLineTaxLine
                .stream()
                .filter(row ->  row.getEntry_reference().contains(entryRefNo) && row.getItem_number().equals(itemNo) && row.getTax_line_sequence_number().equals(SeqNo))
                .findFirst();
    }

    public static List<LandingLinesDeclaration> readAllLandingLinesDeclaration(FluentJdbc hive) {
        logger.info("Reading all data from table landing_lines_declaration");
        return HiveTableReader.readTable(hive, LandingLinesDeclaration.SELECT_ALL_QUERY, LandingLinesDeclaration.class);
    }

    public static Optional<LandingLinesDeclaration> readAllLandingLinesDeclarationForEntryNo(FluentJdbc hive, String entryNo, String itemNo) {
        logger.info("Reading all data from table landing_lines_declaration for entry_reference {} and item_number {}", entryNo, itemNo);
        List<LandingLinesDeclaration> landingLinesDeclarations = readAllLandingLinesDeclaration(hive);
        return landingLinesDeclarations
                .stream()
                .filter(row ->  row.getEntry_number().equals(entryNo) && row.getItem_number().equals(itemNo))
                .findFirst();
    }

    public static List<LandingTrader> readAllLandingTrader(FluentJdbc hive) {
        logger.info("Reading all data from table landing_trader");
        return HiveTableReader.readTable(hive, LandingTrader.SELECT_ALL_QUERY, LandingTrader.class);
    }

    public static Optional<LandingTrader> readAllLandingTraderForTurn(FluentJdbc hive, String turn) {
        logger.info("Reading all data from table landing_trader for turn {}", turn);
        List<LandingTrader> landingTrader = readAllLandingTrader(hive);
        return landingTrader
                .stream()
                .filter(row ->  row.getTurn().equals(turn))
                .findFirst();
    }
}
