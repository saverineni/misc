package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by smalavalli on 22/12/16.
 */
@Data
public class Nxenselect implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select iekey, generationno, impentno, ietype, ics, mrn, epuno, dtofent, standard_dtofent, acptncdate, standard_acptncdate, roe, masterucr, declnucr, gdslocn, declnmthd, decltturn, cnsgrturn, cnsgrturncc, destcntry, clrncdate, standard_clrncdate, origcntry, cmdtycode, cpc, standard_gdsdepdt, cstmsvalue, ietotduty, ietotvat, imptrturncc, itemcnt, payagntturn, plaldg, sessno, soe from nxenselect";

    private String iekey;
    private String generationno;
    private String impentno;
    private String ietype;
    private String ics;
    private String mrn;
    private String epuno;
    private String dtofent;
    private String standard_dtofent;
    private String acptncdate;
    private String standard_acptncdate;
    private String roe;
    private String masterucr;
    private String declnucr;
    private String gdslocn;
    private String declnmthd;
    private String decltturn;
    private String cnsgrturn;
    private String cnsgrturncc;
    private String destcntry;
    private String clrncdate;
    private String standard_clrncdate;
    private String origcntry;
    private String cmdtycode;
    private String cpc;
    private String standard_gdsdepdt;
    private String cstmsvalue;
    private String ietotduty;
    private String ietotvat;
    private String imptrturncc;
    private String itemcnt;
    private String payagntturn;
    private String plaldg;
    private String sessno;
    private String soe;

}
