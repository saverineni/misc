package uk.gov.gsi.hmrc.cds.dar.automation.framework.connection;

import org.apache.commons.dbcp2.BasicDataSource;
import org.codejargon.fluentjdbc.api.FluentJdbc;
import org.codejargon.fluentjdbc.api.FluentJdbcBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.HiveDBManager;

import javax.sql.DataSource;

import static uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.HIVE.HIVE_SERVER_2;

public final class HiveConnector {
    private static Logger logger = LoggerFactory.getLogger(HiveConnector.class);

    public static final String MSS_TEST_DB = "mss_test";
    public static final String MSS_SM_DB = "mss_sm";
    public static final String QA_DB = "qa";

    public static FluentJdbc connectTo_MSS_Test_DB() {
        return connectToDataBase(MSS_TEST_DB);
    }

    public static FluentJdbc connectTo_MSS_SM_DB() {
        return connectToDataBase(MSS_SM_DB);
    }

    public static FluentJdbc connectTo_QA_DB() {
        return connectToDataBase(QA_DB);
    }

    public static FluentJdbc connectToDataBase() {
        String dbName = HiveDBManager.DEFAULT_TEST_DB;
        return connectToDataSource(dataSource(dbName));
    }

    public static FluentJdbc connectToDataBase(String dbName) {
        logger.info("Connecting to '{}' db", dbName);
        return connectToDataSource(dataSource(dbName));
    }

    private static FluentJdbc connectToDataSource(DataSource dataSource) {
        return new FluentJdbcBuilder()
                .connectionProvider(dataSource)
                .build();
    }

    private static DataSource dataSource(String dbName) {
        String connectionUrl = defaultConnectionUrl(dbName);
        return getBasicDataSource(connectionUrl);
    }

    private static String defaultConnectionUrl(String db) {
        return String.format("jdbc:hive2://%s:%s/%s", HIVE_SERVER_2.host(), HIVE_SERVER_2.port(), db);
    }

    private static BasicDataSource getBasicDataSource(String connectionUrl) {
        String driverName = "org.apache.hive.jdbc.HiveDriver";
        BasicDataSource dataSource = new BasicDataSource();
        dataSource.setDriverClassName(driverName);
        dataSource.setUrl(connectionUrl);
        dataSource.setUsername(HIVE_SERVER_2.username());
        dataSource.setPassword(HIVE_SERVER_2.password());
        dataSource.setValidationQuery("select 1+1");
        return dataSource;
    }
}