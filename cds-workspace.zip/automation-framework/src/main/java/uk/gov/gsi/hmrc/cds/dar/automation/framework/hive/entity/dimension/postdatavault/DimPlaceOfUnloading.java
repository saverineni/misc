package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.postdatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class DimPlaceOfUnloading implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select place_of_unloading_code from dim_place_of_unloading";

    private String place_of_unloading_code;
}
