package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.postdatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class DimPlaceOfLoading implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select place_of_loading_code from dim_place_of_loading";

    private String place_of_loading_code;
}
