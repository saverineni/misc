package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.satellites;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by smalavalli on 17/01/17.
 */
@Data
public class SatDeclarationLine implements HiveEntity {

    public static final String SELECT_ALL_QUERY ="select hub_declaration_line_key, sat_hash_diff, sat_load_datetime, sat_load_end_datetime, sat_record_source, clearance_datetime, item_statistical_value, customs_duty_paid, vat_paid, ec_supplementary_1, item_customs_value, item_net_mass, item_supplementary_units, goods_description, item_customs_check_code, item_mic_code, item_profile_id, item_consignor_nad_name, item_consignee_nad_name, item_consignee_nad_postcode, vat_value, item_price_declared from sat_declaration_line";

    private String hub_declaration_line_key;
    private String sat_hash_diff;
    private String sat_load_datetime;
    private String sat_load_end_datetime;
    private String sat_record_source;
    private String clearance_datetime;
    private String item_statistical_value;
    private String customs_duty_paid;
    private String vat_paid;
    private String ec_supplementary_1;
    private String item_customs_value;
    private String item_net_mass;
    private String item_supplementary_units;
    private String goods_description;
    private String item_customs_check_code;
    private String item_mic_code;
    private String item_profile_id;
    private String item_consignor_nad_name;
    private String item_consignee_nad_name;
    private String item_consignee_nad_postcode;
    private String vat_value;
    private String item_price_declared;
}
