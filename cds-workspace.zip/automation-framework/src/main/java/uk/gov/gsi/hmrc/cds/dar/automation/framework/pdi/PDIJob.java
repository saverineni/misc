package uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.PDIConnector;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.HiveDBManager;

import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.PropertyConfiguration.config;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.HiveDBManager.DEFAULT_TEST_DB;

/**
 * Created by smalavalli on 23/01/17.
 */
public interface PDIJob {
    Logger logger = LoggerFactory.getLogger(PDIJob.class);
    String LANDING_PDI_REPOSITORY = "CDSDATA ETL : Landing";
    String LANDING_JOB_KETTLE_LOCATION = "/landing-pdi/kettle/ingestion";
    String DIMENSION_KETTLE_LOCATION = "/customs-pipeline-common/kettle/build_dimensions";
    String GENERIC_DATA_MODEL_PDI_REPOSITORY = "CDSDATA ETL : Generic Data Model";
    String GENERIC_DATA_MODEL_KETTLE_LOCATION = "/generic-data-model-pdi/kettle/populate_data_vault";
    String EXPLOITATION_REPORT_PDI_REPOSITORY = "CDSDATA ETL : Exploitation - Reporting";
    String EXPLOITATION_REPORT_JOB_KETTLE_LOCATION = "/exploitation-report-pdi/kettle/build_exploitation";

    String CSV_REPORT_JOB_KETTLE_LOCATION = "/customs-pipeline-helper-tools/build";
    String pdiJobName();
    String pdiJobLocation();
    String pentahoRepository();

    default boolean triggerPDIJob() {
        logger.info("Triggering PDI job '{}' ", pdiJobName());
        String dbName = HiveDBManager.DEFAULT_TEST_DB;
        String mssDBName = config().getString("test.mss.db.name", dbName);
        return PDIConnector
                .triggerPDIJob(pdiJobName())
                .withPentahoRepository(pentahoRepository())
                .withKettleFileLocationPath(pdiJobLocation())
                .withJobParams("MSS_DB", mssDBName)
                .withJobParams("CDS_DATA_ENVIRONMENT_PARAM", dbName)
                .trigger();
    }

    default boolean triggerPDIJob(String mssDBName) {
        logger.info("Triggering PDI job '{}' ", pdiJobName());
        String dbName = HiveDBManager.DEFAULT_TEST_DB;
        return PDIConnector
                .triggerPDIJob(pdiJobName())
                .withPentahoRepository(pentahoRepository())
                .withKettleFileLocationPath(pdiJobLocation())
                .withJobParams("MSS_DB", mssDBName)
                .withJobParams("CDS_DATA_ENVIRONMENT_PARAM", dbName)
                .trigger();
    }

    default boolean triggerPDIJob(String mssDBName, PDIEnv pdiEnv, PDIUser pdiUser) {
        logger.info("Triggering PDI job '{}' ", pdiJobName());
        String dbName = HiveDBManager.DEFAULT_TEST_DB;
        return PDIConnector
                .triggerPDIJob(pdiJobName())
                .withPentahoRepository(pentahoRepository())
                .withKettleFileLocationPath(pdiJobLocation())
                .withJobParams("MSS_DB", mssDBName)
                .withJobParams("CDS_DATA_ENVIRONMENT_PARAM", dbName)
                .asUser(pdiUser)
                .inEnv(pdiEnv)
                .trigger();
    }

}
