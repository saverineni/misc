package uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi;

import com.google.common.collect.Lists;
import org.codejargon.fluentjdbc.api.FluentJdbc;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs.HDFSFileSystemUtil;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.HiveDBManager;

import java.util.List;

import static uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs.HDFSFileSystemUtil.AUTOMATION_TEST_CACHE_PATH;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs.HDFSFileSystemUtil.HADOOP_USER_CDSDATA;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs.HDFSFileSystemUtil.TEST_DB_PATH;

/**
 * Created by smalavalli on 23/01/17.
 */
public interface PDIManagedTables {
    Logger logger = LoggerFactory.getLogger(PDIManagedTables.class);

    //region Landing tables
    String LANDING_CDP_HEADERS_DECLARATION = "landing_cdp_headers_declaration";
    String LANDING_CDP_LINES_DECLARATION = "landing_cdp_lines_declaration";
    String LANDING_CDP_TRADER = "landing_cdp_trader";
    String LANDING_MSS_HEADERS_DECLARATION = "landing_mss_headers_declaration";
    String LANDING_MSS_LINE_ADDITIONAL_INFORMATION = "landing_mss_line_additional_information";
    String LANDING_MSS_LINE_DOCUMENT = "landing_mss_line_document";
    String LANDING_MSS_LINE_PREVIOUS_DOCUMENT = "landing_mss_line_previous_document";
    String LANDING_MSS_LINE_TAX_LINE = "landing_mss_line_tax_line";
    String LANDING_MSS_LINES_DECLARATION = "landing_mss_lines_declaration";
    String LANDING_MSS_TRADER = "landing_mss_trader";
    String LANDING_HEADERS_DECLARATION = "landing_headers_declaration";
    String LANDING_LINE_ADDITIONAL_INFORMATION = "landing_line_additional_information";
    String LANDING_LINE_DOCUMENT = "landing_line_document";
    String LANDING_LINE_PREVIOUS_DOCUMENT = "landing_line_previous_document";
    String LANDING_LINE_TAX_LINE = "landing_line_tax_line";
    String LANDING_LINES_DECLARATION = "landing_lines_declaration";
    String LANDING_TRADER = "landing_trader";
    String LANDING_HEADERS_DECLARATION_HASHED = "landing_headers_declaration_hashed";
    String LANDING_LINE_ADDITIONAL_INFORMATION_HASHED = "landing_line_additional_information_hashed";
    String LANDING_LINE_DOCUMENT_HASHED = "landing_line_document_hashed";
    String LANDING_LINE_PREVIOUS_DOCUMENT_HASHED = "landing_line_previous_document_hashed";
    String LANDING_LINE_TAX_LINE_HASHED = "landing_line_tax_line_hashed";
    String LANDING_LINES_DECLARATION_HASHED = "landing_lines_declaration_hashed";
    String LANDING_TRADER_HASHED = "landing_trader_hashed";
    //endregion

    //region Dimension tables
    String DIM_COMMODITY_CODE = "dim_commodity_code";
    String DIM_COMMODITY_CODE_HASHED = "dim_commodity_code_hashed";
    String DIM_COUNTRY = "dim_country";
    String DIM_COUNTRY_HASHED = "dim_country_hashed";
    String DIM_CURRENCY = "dim_currency";
    String DIM_CURRENCY_HASHED = "dim_currency_hashed";
    String DIM_CUSTOMS_PROCEDURE_CODE = "dim_customs_procedure_code";
    String DIM_CUSTOMS_PROCEDURE_CODE_HASHED = "dim_customs_procedure_code_hashed";
    String DIM_CUSTOMS_ROUTE = "dim_customs_route";
    String DIM_DATE = "dim_date";
    String DIM_EPU = "dim_epu";
    String DIM_IMPORT_CLEARANCE_STATUS = "dim_import_clearance_status";
    //end region Dimension tables

    //region DataVault tables
    String HUB_ADDITIONAL_INFO = "hub_additional_info";
    String HUB_COMMODITY = "hub_commodity";
    String HUB_COUNTRY = "hub_country";
    String HUB_CURRENCY = "hub_currency";
    String HUB_CUSTOMS_PROCEDURE_CODE = "hub_customs_procedure_code";
    String HUB_DECLARATION = "hub_declaration";
    String HUB_DECLARATION_LINE = "hub_declaration_line";
    String HUB_DOCUMENT = "hub_document";
    String HUB_PREVIOUS_DOCUMENT = "hub_previous_document";
    String HUB_TAX_LINE = "hub_tax_line";
    String HUB_TRADER = "hub_trader";

    String SAT_ADDITIONAL_INFO = "sat_additional_info";
    String SAT_COMMODITY = "sat_commodity";
    String SAT_COUNTRY = "sat_country";
    String SAT_CURRENCY = "sat_currency";
    String SAT_DECLARATION = "sat_declaration";
    String SAT_DECLARATION_LINE = "sat_declaration_line";
    String SAT_DOCUMENT = "sat_document";
    String SAT_PREVIOUS_DOCUMENT = "sat_previous_document";
    String SAT_TAX_LINE = "sat_tax_line";
    String SAT_TRADER = "sat_trader";


    String LINK_DECLARATION_CONSIGNOR_TRADER = "link_declaration_consignor_trader";
    String LINK_DECLARATION_DECLARANT_TRADER = "link_declaration_declarant_trader";
    String LINK_DECLARATION_DESTINATION_COUNTRY = "link_declaration_destination_country";
    String LINK_DECLARATION_EXPORTER_TRADER = "link_declaration_exporter_trader";
    String LINK_DECLARATION_FREIGHT_CURRENCY= "link_declaration_freight_currency";
    String LINK_DECLARATION_IMPORTER_TRADER = "link_declaration_importer_trader";
    String LINK_DECLARATION_INVOICE_CURRENCY= "link_declaration_invoice_currency";
    String LINK_DECLARATION_PAYING_AGENT_TRADER = "link_declaration_paying_agent_trader";
    String LINK_DECLARATION_TRANSPORT_COUNTRY = "link_declaration_transport_country";

    String LINK_DECLARATION_LINE_ADDITIONAL_INFO = "link_declaration_line_additional_info";
    String LINK_DECLARATION_LINE_COMMODITY = "link_declaration_line_commodity";
    String LINK_DECLARATION_LINE_CUSTOM_PROCEDURE_CODE = "link_declaration_line_customs_procedure_code";
    String LINK_DECLARATION_LINE_DECLARATION = "link_declaration_line_declaration";
    String LINK_DECLARATION_LINE_DOCUMENT = "link_declaration_line_document";
    String LINK_DECLARATION_LINE_IMPORTER_TRADER = "link_declaration_line_importer_trader";
    String LINK_DECLARATION_LINE_ORIGIN_COUNTRY = "link_declaration_line_origin_country";
    String LINK_DECLARATION_LINE_PREVIOUS_DOCUMENT = "link_declaration_line_previous_document";
    String LINK_DECLARATION_LINE_TAX_LINE = "link_declaration_line_tax_line";
    //endregion

    //region Fact tables
    String FACT_CONSOLIDATED_CONSIGNMENTS_WIDE = "fact_consolidated_consignments_wide";
    String FACT_DECLARATION_LINES_WIDE = "fact_declaration_lines_wide";
    String FACT_DECLARATION_LINES_WIDE_ALL = "fact_declaration_lines_wide_all";
    String FACT_DECLARATION_LINES_WIDE_EXPORT = "fact_declaration_lines_wide_export";
    String FACT_DECLARATION_TAX_LINES_WIDE_EXPORT = "fact_declaration_tax_lines_wide_export";
    String FACT_DECLARATION_TAX_LINES_WIDE_IMPORT = "fact_declaration_tax_lines_wide_import";
    String FACT_DECLARATION_WIDE = "fact_declarations_wide";
    String FACT_DECLARATION_WIDE_EXPORT = "fact_declarations_wide_export";
    //endregion

    //    lock tables
    String BUILD_DIMENSIONS_LOCK_TABLE = "_pdi_lock_build_dimensions";
    String CREATE_ALL_LANDING_STAGE__LOCK_TABLE = "_pdi_lock_landing";
    String CREATE_LANDING_HASHED_TABLES_STAGE_LOCK_TABLE = "_pdi_lock_create_dv_hashes";
    String POPULATE_DATA_VAULT_STAGE_LOCK_TABLE = "_pdi_lock_dv_pop_hub_sat";
    String CREATE_EXPLOITATION_STAGE_LOCK_TABLE = "_pdi_lock_exploitation";

    List<String> tablesInStage();

    List<String> sourceTablesInStage();

    List<String> lockTables = Lists.newArrayList(
            BUILD_DIMENSIONS_LOCK_TABLE,
            CREATE_ALL_LANDING_STAGE__LOCK_TABLE,
            CREATE_LANDING_HASHED_TABLES_STAGE_LOCK_TABLE,
            POPULATE_DATA_VAULT_STAGE_LOCK_TABLE,
            CREATE_EXPLOITATION_STAGE_LOCK_TABLE);

    default void dropAllLockTables(FluentJdbc hive) {
        lockTables.forEach(tableName -> dropTable(hive, tableName)
        );
    }

    default void dropTable(FluentJdbc hive, String tableName) {
        String dropTableSql = String.format("DROP TABLE IF EXISTS  `%s`.`%s` PURGE", HiveDBManager.DEFAULT_TEST_DB, tableName);
        logger.info(dropTableSql);
        HiveDBManager
                .connect(hive)
                .executeQuery(dropTableSql);
    }

    default void dropTablesInStage(FluentJdbc hive) {
        tablesInStage().forEach(tableName -> dropTable(hive, tableName)
        );
    }

    default void truncateTablesInStage(FluentJdbc hive) {
        tablesInStage().forEach(tableName -> {
                    String hdfsTablePath = String.format("%s/%s", TEST_DB_PATH, tableName);
                    boolean dataFileExists = HDFSFileSystemUtil.directoryContainFiles(hdfsTablePath);
                    if (dataFileExists) {
                        String trauncateSql = String.format("TRUNCATE TABLE %s.%s", HiveDBManager.DEFAULT_TEST_DB, tableName);
                        logger.info(trauncateSql);
                        HiveDBManager
                                .connect(hive)
                                .executeQuery(trauncateSql);
                    }
                }
        );
    }

    default void invalidateSourceTableCache() {
        sourceTablesInStage().forEach(tableName -> {
            HDFSFileSystemUtil
                    .removeDirectoryAsUser(HADOOP_USER_CDSDATA)
                    .withPath(String.format("%s/%s", AUTOMATION_TEST_CACHE_PATH, tableName))
                    .remove();
            logger.info("Invalidate {} table cache.", tableName);
        });
    }


}
