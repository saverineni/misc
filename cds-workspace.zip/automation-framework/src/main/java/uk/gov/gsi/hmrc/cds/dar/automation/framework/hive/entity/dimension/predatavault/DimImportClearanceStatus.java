package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class DimImportClearanceStatus implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select ics_code, description, update_method, import_event, export_event, state from dim_import_clearance_status";

    private String ics_code;
    private String description;
    private String update_method;
    private String import_event;
    private String export_event;
    private String state;
}
