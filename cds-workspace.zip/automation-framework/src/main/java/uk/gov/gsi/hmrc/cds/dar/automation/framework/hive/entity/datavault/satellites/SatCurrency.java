package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.satellites;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class SatCurrency implements HiveEntity {

    public static final String SELECT_ALL_QUERY ="select hub_currency_key, sat_hash_diff, sat_load_datetime, sat_load_end_datetime, sat_record_source, currency_name from sat_currency";

    private String hub_currency_key;
    private String sat_hash_diff;
    private String sat_load_datetime;
    private String sat_load_end_datetime;
    private String sat_record_source;
    private String currency_name;
}
