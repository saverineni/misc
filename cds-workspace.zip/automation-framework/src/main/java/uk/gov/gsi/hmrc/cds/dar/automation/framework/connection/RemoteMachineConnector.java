package uk.gov.gsi.hmrc.cds.dar.automation.framework.connection;

import com.google.common.base.Joiner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.SFTPHelper;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.SSHAccessHelper;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.FASTP.FASTP_2;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.PropertyConfiguration.config;

/**
 * Created by smalavalli on 10/01/17.
 */
public class RemoteMachineConnector {
    private static Logger logger = LoggerFactory.getLogger(RemoteMachineConnector.class);

    public static RemoteMachine connectToRemoteMachine(String hostMachine, String userName) {
        logger.info("Accessing remote machine.... {}", hostMachine);
        return new RemoteMachine(hostMachine, userName);
    }

    public static RemoteMachine connectToFASTP2() {
        String hostMachine = FASTP_2.host();
        String userName = config().getString("fastp.username");

        logger.info("Accessing remote machine.... {}", hostMachine);
        return new RemoteMachine(hostMachine, userName);
    }

    public static RemoteMachine connectToDockerClouderaServer() {
        DOCKER_MACHINE dockerMachine = DOCKER_ENV.getInstance();
        String hostMachine = dockerMachine.host();
        int sshPortClouderaServer = dockerMachine.sshPortClouderaServer();
        String userName = config().getString("fastp.username");

        logger.info("Accessing remote machine {} on port {}", hostMachine, sshPortClouderaServer);
        return new RemoteMachine(hostMachine, userName, sshPortClouderaServer);
    }

    public static RemoteMachine connectToDockerDataNodeAgent1() {
        DOCKER_MACHINE dockerMachine = DOCKER_ENV.getInstance();
        String hostMachine = dockerMachine.host();
        int sshPortAgent1 = 2025;
        String userName = config().getString("fastp.username");

        logger.info("Accessing remote machine {} on port {}", hostMachine, sshPortAgent1);
        return new RemoteMachine(hostMachine, userName, sshPortAgent1);
    }

    public static RemoteMachine connectToDockerPDIServer() {
        DOCKER_MACHINE dockerMachine = DOCKER_ENV.getInstance();
        String hostMachine = dockerMachine.host();
        int sshPortPDIServer = dockerMachine.sshPortPDIServer();
        String userName = config().getString("fastp.username");

        logger.info("Accessing remote machine {} on port {}", hostMachine, sshPortPDIServer);
        return new RemoteMachine(hostMachine, userName, sshPortPDIServer);
    }

    public static class RemoteMachine {
        private SSHAccessHelper sshAccessHelper = new SSHAccessHelper();
        private SFTPHelper sftpHelper = new SFTPHelper();
        private String hostMachine;
        private String userName;
        private int sshPort = 22;

        RemoteMachine(String hostMachine, String userName) {
            this.hostMachine = hostMachine;
            this.userName = userName;
        }

        RemoteMachine(String hostMachine, String userName, int sshPort) {
            this.hostMachine = hostMachine;
            this.userName = userName;
            this.sshPort = sshPort;
        }

        public void executeScript(String script) {
            sshAccessHelper.accessRemoteMachineUsingSSHKeyWithPassPhrase(hostMachine, userName, sshPort, script);
        }   

        public void executeScriptAsSudo(String script) {
            sshAccessHelper.sudoAccessRemoteMachineUsingSSHKeyWithPassPhrase(hostMachine, userName, sshPort,  script);
        }

        public String executeCommandsInShell(List<String> commands) {
            return sshAccessHelper.accessRemoteMachineUsingSSHKeyWithPassPhrase(hostMachine, userName, sshPort,  commands);
        }

        public boolean fileExists(String filePath) {
            return sftpHelper.fileExists(hostMachine, userName, sshPort, filePath);
        }

        public void remoteFileTransfer(List<File> filesToTransfer, String ftpPath) {
            sftpHelper.remoteFileTransferUsingSSHKeyWithPassPhrase(hostMachine, userName, sshPort, filesToTransfer, ftpPath);
        }

        public void deleteFiles(List<String> filePaths) {
            logger.info("Removing metadata files {}", filePaths.toString());
            String removeFilesCommand = String.format("rm -rf %s", Joiner.on(" ").join(filePaths));
            executeScript(removeFilesCommand);
        }

        public void removeAndMakeDirectory(String directoryPath) {
            logger.info("Remove and make directory {}", directoryPath);
            String removeDirectory = String.format("rm -rf %s", directoryPath);
            String makeDirectory = String.format("mkdir -p %s", directoryPath);
            List<String> commandList = Arrays.asList(removeDirectory, makeDirectory);
            String removeAndMakeDirCommand = Joiner.on(";").join(commandList);
            executeScript(removeAndMakeDirCommand);
        }

        public void makeDirectory(String directoryPath) {
            logger.info("Make directory {}", directoryPath);
            String makeDirectory = String.format("mkdir -p %s", directoryPath);
            executeScript(makeDirectory);
        }
    }
}
