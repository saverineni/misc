package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.postdatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class DimTaxLine implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select declaration_line_reference, entry_reference, item_number, tax_line_sequence_number, generation_number, method_of_payment_code, tax_type_code from dim_tax_line";

    private String declaration_line_reference;
    private String entry_reference;
    private String item_number;
    private String tax_line_sequence_number;
    private String generation_number;
    private String method_of_payment_code;
    private String tax_type_code;
}
