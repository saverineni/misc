package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by smalavalli on 31/01/17.
 */
@Data
public class DimCommodityCode implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select cc_year, cc_month, hs_chapter, hs_heading, hs_chapter_heading, hs_subheading, hs_code, chapter_description, heading_description, subheading_description from dim_commodity_code";

    private String cc_year;
    private String cc_month;
    private String hs_chapter;
    private String hs_heading;
    private String hs_chapter_heading;
    private String hs_subheading;
    private String hs_code;
    private String chapter_description;
    private String heading_description;
    private String subheading_description;
}
