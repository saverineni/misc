package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.satellites;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by smalavalli on 22/03/17.
 */
@Data
public class SatTrader implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select hub_trader_key, sat_hash_diff, sat_load_datetime, sat_load_end_datetime, sat_record_source, name, simplified_procedure_authorisations, trader_name_abbreviated, currentind from sat_trader";

    private String hub_trader_key;
    private String sat_hash_diff;
    private String sat_load_datetime;
    private String sat_load_end_datetime;
    private String sat_record_source;
    private String name;
    private String simplified_procedure_authorisations;
    private String trader_name_abbreviated;
    private String currentind;
}
