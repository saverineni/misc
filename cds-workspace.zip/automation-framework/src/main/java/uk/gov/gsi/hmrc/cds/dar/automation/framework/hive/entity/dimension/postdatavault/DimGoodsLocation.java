package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.postdatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class DimGoodsLocation implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select goods_location from dim_goods_location";

    private String goods_location;
}
