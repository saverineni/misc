package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class Imeiselect implements HiveEntity {
    public static final String SELECT_ALL_QUERY = "select iekey, ieitno, cmdtycode, clrncdate, standard_clrncdate, origcntry, cpc, itemcnsgrturn, itemimptrturn from imeiselect";

    private String iekey;
    private String ieitno;
    private String cmdtycode;
    private String clrncdate;
    private String standard_clrncdate;
    private String origcntry;
    private String cpc;
    private String itemcnsgrturn;
    private String itemimptrturn;

}
