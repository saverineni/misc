package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.postdatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class DimSession implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select session_num from dim_session";

    private String session_num;
}
