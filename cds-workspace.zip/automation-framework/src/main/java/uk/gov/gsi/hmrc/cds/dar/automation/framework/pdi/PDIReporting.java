package uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi;

import uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.PDIConnector;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.HiveDBManager.*;

public enum PDIReporting implements PDIJob {

    RETREIVE_CSV_RESULTS() {
        @Override
        public String pdiJobName() {
            return "Get_report_CSV_by_report_name";
        }

        @Override
        public String pdiJobLocation() {
            return CSV_REPORT_JOB_KETTLE_LOCATION;
        }

        @Override
        public String pentahoRepository() {
            return LANDING_PDI_REPOSITORY;
        }
    };

    public boolean triggerPDIJob(String outputPath, String reportName) {
        logger.info("Triggering PDI job '{}' ", pdiJobName());
        return PDIConnector
                .triggerPDIJob(pdiJobName())
                .withPentahoRepository(RETREIVE_CSV_RESULTS.pentahoRepository())
                .withKettleFileLocationPath(RETREIVE_CSV_RESULTS.pdiJobLocation())
                .withJobParams("OUTPUT_FILE", outputPath)
                .withJobParams("REPORT_NAME", reportName)
                .withJobParams("CDS_DATA_ENVIRONMENT_PARAM", DEFAULT_TEST_DB)
                .trigger();
    }


}
