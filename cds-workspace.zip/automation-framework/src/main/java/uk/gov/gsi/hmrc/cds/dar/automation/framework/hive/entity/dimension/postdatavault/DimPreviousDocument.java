package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.postdatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class DimPreviousDocument implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select declaration_line_reference, entry_reference, item_number, previous_document_sequence_number, previous_document_reference from dim_previous_document";

    private String declaration_line_reference;
    private String entry_reference;
    private String item_number;
    private String previous_document_sequence_number;
    private String previous_document_reference;
}
