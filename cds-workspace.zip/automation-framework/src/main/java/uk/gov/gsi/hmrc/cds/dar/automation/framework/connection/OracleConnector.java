package uk.gov.gsi.hmrc.cds.dar.automation.framework.connection;

import org.apache.commons.dbcp2.BasicDataSource;

import javax.sql.DataSource;

import static uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.HIVE.HIVE_SERVER_2;

/**
 * Created by smalavalli on 09/12/16.
 */
public class OracleConnector {

    public static DataSource mssDataSource() {
        return dataSource("MSSAT");
    }

    private static DataSource dataSource(String sid) {
        String connectionUrl = defaultConnectionUrl(sid);
        return getBasicDataSource(connectionUrl);
    }

    private static String defaultConnectionUrl(String sid) {
        return String.format("jdbc:oracle:thin:@%s:%s:%s", "10.24.73.39", "1521", sid);
    }

    private static BasicDataSource getBasicDataSource(String connectionUrl) {
        String driverName = "oracle.jdbc.driver.OracleDriver";
        BasicDataSource dataSource = new BasicDataSource();
        dataSource.setDriverClassName(driverName);
        dataSource.setUrl(connectionUrl);
        dataSource.setUsername("mssread");
        dataSource.setPassword("realm3");
        dataSource.setValidationQuery("select 1 from dual");
        return dataSource;
    }

}
