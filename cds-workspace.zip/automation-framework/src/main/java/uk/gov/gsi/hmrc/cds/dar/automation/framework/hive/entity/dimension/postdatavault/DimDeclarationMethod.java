package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.postdatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class DimDeclarationMethod implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select declaration_method from dim_declaration_method";

    private String declaration_method;
}
