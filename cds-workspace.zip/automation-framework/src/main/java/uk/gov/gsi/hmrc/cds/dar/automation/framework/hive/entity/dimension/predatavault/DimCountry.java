package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by smalavalli on 31/01/17.
 */
@Data
public class DimCountry implements HiveEntity {
    public static final String SELECT_ALL_QUERY = "select country_id,country_iso_code,country_name,country_sequence_number,country_comments from dim_country";

    private String country_id;
    private String country_iso_code;
    private String country_name;
    private String country_sequence_number;
    private String country_comments;
}
