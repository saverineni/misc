package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class DimCurrency implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select currency_id, currency_iso_code, currency_name from dim_currency";

    private String currency_id;
    private String currency_iso_code;
    private String currency_name;
}
