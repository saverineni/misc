package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers;


import org.codejargon.fluentjdbc.api.FluentJdbc;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.hubs.HubCountry;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault.DimCommodityCodeHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault.DimCountryHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault.DimCurrencyHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault.DimCustomsProcedureCodeHashed;

import java.util.List;
import java.util.Optional;

public class HiveDimensionHashedTableReader {
    private static Logger logger = LoggerFactory.getLogger(HiveDimensionTableReader.class);

    public static List<DimCommodityCodeHashed> readAllDimCommodityCodeHashed(FluentJdbc hive) {
        logger.info("Reading all data from table dim_commodity_code_hashed");
        return HiveTableReader.readTable(hive, DimCommodityCodeHashed.SELECT_ALL_QUERY, DimCommodityCodeHashed.class);
    }

    public static Optional<DimCommodityCodeHashed> readAllDimCommodityCodeHashedCommodityCode(FluentJdbc hive, String commodityCode) {
        logger.info("Reading all data from table dim_commodity_code_hashed for hs_code '{}'", commodityCode);
        List<DimCommodityCodeHashed> dimCommodityCodeHashed = readAllDimCommodityCodeHashed(hive);
        return dimCommodityCodeHashed
                .stream()
                .filter(row -> row.getHs_code().trim().equals(commodityCode))
                .findFirst();
    }

    public static List<DimCountryHashed> readAllDimCountryHashed(FluentJdbc hive) {
        logger.info("Reading all data from table dim_country_hashed");
        return HiveTableReader.readTable(hive, DimCountryHashed.SELECT_ALL_QUERY, DimCountryHashed.class);
    }

    public static Optional<DimCountryHashed> readAllDimCountryHashedCountryCode(FluentJdbc hive, String countryCode) {
        logger.info("Reading all data from table dim_country_hashed for country_iso_code '{}'", countryCode);
        List<DimCountryHashed> dimCountryHashed = readAllDimCountryHashed(hive);
        return dimCountryHashed
                .stream()
                .filter(row -> row.getCountry_iso_code().trim().equals(countryCode))
                .findFirst();
    }

    public static List<DimCurrencyHashed> readAllDimCurrencyHashed(FluentJdbc hive) {
        logger.info("Reading all data from table dim_currency_hashed");
        return HiveTableReader.readTable(hive, DimCurrencyHashed.SELECT_ALL_QUERY, DimCurrencyHashed.class);
    }

    public static Optional<DimCurrencyHashed> readAllDimCurrencyHashedCurrencyCode(FluentJdbc hive, String currencyCode) {
        logger.info("Reading all data from table dim_country_hashed for country_iso_code '{}'", currencyCode);
        List<DimCurrencyHashed> dimCurrencyHashed = readAllDimCurrencyHashed(hive);
        return dimCurrencyHashed
                .stream()
                .filter(row -> row.getCurrency_iso_code().trim().equals(currencyCode))
                .findFirst();
    }

    public static List<DimCustomsProcedureCodeHashed> readAllDimCustomsProcedureCodeHashed(FluentJdbc hive) {
        logger.info("Reading all data from table dim_customs_procedure_code_hashed");
        return HiveTableReader.readTable(hive, DimCustomsProcedureCodeHashed.SELECT_ALL_QUERY, DimCustomsProcedureCodeHashed.class);
    }

    public static Optional<DimCustomsProcedureCodeHashed> readAllDimCustomsProcedureCodeHashedCPC(FluentJdbc hive, String customsProcedureCode) {
        logger.info("Reading all data from table dim_customs_procedure_code_hashed for customs_procedure_code '{}'", customsProcedureCode);
        List<DimCustomsProcedureCodeHashed> dimCustomsProcedureCodeHashed = readAllDimCustomsProcedureCodeHashed(hive);
        return dimCustomsProcedureCodeHashed
                .stream()
                .filter(row -> row.getCustoms_procedure_code().trim().equals(customsProcedureCode))
                .findFirst();
    }
}
