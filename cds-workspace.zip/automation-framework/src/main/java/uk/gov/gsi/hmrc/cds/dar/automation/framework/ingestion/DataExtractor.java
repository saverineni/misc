package uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion;

import com.google.common.base.Joiner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.RemoteMachineConnector;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs.HDFSFileSystemUtil;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.RemoteMachineConnector.connectToDockerClouderaServer;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs.HDFSFileSystemUtil.*;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.PropertyConfiguration.config;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.HiveDBManager.DEFAULT_TEST_DB;

/**
 * Created by smalavalli on 10/01/17.
 */
public class DataExtractor {
    private static Logger logger = LoggerFactory.getLogger(DataExtractor.class);

    public void extractDataFromTableUsingHDFS(String tableName) {
        String sourceDataPath = String.format("%s/%s", TEST_DB_PATH, tableName);
        String targetDataPath = String.format("%s/%s", AUTOMATION_TEST_CACHE_PATH, tableName);

        HDFSFileSystemUtil
                .copyDataAsUser(HADOOP_USER_CDSDATA)
                .fromHDFSPath(sourceDataPath)
                .toHDFSPath(targetDataPath)
                .copy();
    }

    public void extractDataFromTableUsingHive(String tableName) {
        String ftpPath = config().getString("data.file.ftp.path");
        String metadataDirectoryPath = String.format("%s/%s", ftpPath, tableName);
        RemoteMachineConnector.RemoteMachine remoteMachine = RemoteMachineConnector.connectToFASTP2();
        remoteMachine.removeAndMakeDirectory(metadataDirectoryPath);
        String makeMetadataDirectoryScript = makeMetadataDirectoryScript(metadataDirectoryPath);
        remoteMachine.executeScript(makeMetadataDirectoryScript);

        String hiveExtractDataAsCSVCommandTemplate = String.format("insert overwrite local directory \"%s\" select * from %s.%s", metadataDirectoryPath, DEFAULT_TEST_DB, tableName);
        String scriptToExtractDataAsCSV = String.format("hive -e '%s;'", hiveExtractDataAsCSVCommandTemplate);
        logger.info(scriptToExtractDataAsCSV);
        remoteMachine.executeScript(scriptToExtractDataAsCSV);

        String scriptToRenameDataDumpFile = renameDataDumpFileScript(tableName, metadataDirectoryPath);
        remoteMachine.executeScript(scriptToRenameDataDumpFile);

        String sudoScriptToChangeDirectoryPermission = String.format("sudo su - root -c \"chmod -R 777 %s;chown root:datausers %s\"", metadataDirectoryPath, metadataDirectoryPath);
        remoteMachine.executeScriptAsSudo(sudoScriptToChangeDirectoryPermission);

        logger.info("Extracted {} table data as csv to location {} on FASTP2 ", tableName, metadataDirectoryPath);
    }

    private String renameDataDumpFileScript(String tableName, String metadataDirectoryPath) {
        String changeDirectoryCommand = String.format("cd %s", metadataDirectoryPath);
        String renameFileAsCSVCommand = String.format("mv `(ls)` %s.csv", tableName);
        List<String> commands = Arrays.asList(changeDirectoryCommand, renameFileAsCSVCommand);
        return Joiner.on(";").join(commands);
    }

    private String makeMetadataDirectoryScript(String metadataDirectoryPath) {
        String removeDirectoryByTableName = String.format("rm -rf %s", metadataDirectoryPath);
        String makeDirectoryByTableName = String.format("mkdir -p %s", metadataDirectoryPath);
        List<String> commandList = Arrays.asList(removeDirectoryByTableName, makeDirectoryByTableName);
        return Joiner.on(";").join(commandList);
    }

    public void extractDataFromTableUsingHive(List<String> tablesToCache) {

        List<String> cacheTableScripts = tablesToCache.stream().map(tableName -> {
            String targetDataPath = String.format("%s/%s", AUTOMATION_TEST_CACHE_PATH, tableName);
            HDFSFileSystemUtil.removeDirectoryAsUser(HADOOP_USER_CDSDATA).withPath(targetDataPath).remove();
            HDFSFileSystemUtil.createDirectoryAsUser(HADOOP_USER_CDSDATA).withPath(targetDataPath).create();
            return String.format("EXPORT TABLE %s.%s TO '%s'", DEFAULT_TEST_DB, tableName, targetDataPath);
        }).collect(Collectors.toList());


        String cacheTableScript = String.format("sudo su - hdfs -c \"hive -e \\\"%s\\\"\"", Joiner.on(";").join(cacheTableScripts));
        connectToDockerClouderaServer().executeScriptAsSudo(cacheTableScript);

    }
}
