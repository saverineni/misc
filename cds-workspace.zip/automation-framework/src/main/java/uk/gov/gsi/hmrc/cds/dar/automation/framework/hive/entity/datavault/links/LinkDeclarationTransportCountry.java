package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.links;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class LinkDeclarationTransportCountry implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select link_declaration_transport_country_key, hub_declaration_key, hub_country_key, entry_reference, iso_country_code_alpha_2, link_load_datetime, link_record_source from link_declaration_transport_country";

    private String link_declaration_transport_country_key;
    private String hub_declaration_key;
    private String hub_country_key;
    private String entry_reference;
    private String iso_country_code_alpha_2;
    private String link_load_datetime;
    private String link_record_source;
}
