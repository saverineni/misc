package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers;

import org.codejargon.fluentjdbc.api.FluentJdbc;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.hubs.*;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.links.*;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.satellites.*;

import java.util.List;
import java.util.Optional;

/**
 * Created by smalavalli on 19/01/17.
 */
public class HiveDataVaultTableReader {
    private static Logger logger = LoggerFactory.getLogger(HiveDataVaultTableReader.class);

    //region hubs

    public static List<HubAdditionalInfo> readAllHubAdditionalInfo (FluentJdbc hive) {
        logger.info("Reading all data from table hub_additional_info");
        return HiveTableReader.readTable(hive, HubAdditionalInfo.SELECT_ALL_QUERY, HubAdditionalInfo.class);
    }

    public static Optional<HubAdditionalInfo> hubAdditionalInfoForEntryReferenceItemNoSeqNo(FluentJdbc hive, String entryReference, String itemNo, String seqNo) {
        logger.info("Reading all data from table hub_additional_info for entry_reference '{}' and item_number '{}' and additional_information_sequence_number '{}'", entryReference, itemNo, seqNo);
        List<HubAdditionalInfo> hubAdditionalInfo = readAllHubAdditionalInfo(hive);
        return hubAdditionalInfo
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryReference) && row.getItem_number().equals(itemNo) && row.getAdditional_information_sequence_number().equals(seqNo))
                .findFirst();
    }

    public static List<HubCommodity> readAllHubCommodity(FluentJdbc hive) {
        logger.info("Reading all data from table hub_commodity");
        return HiveTableReader.readTable(hive, HubCommodity.SELECT_ALL_QUERY, HubCommodity.class);
    }

    public static Optional<HubCommodity> hubCommodityForCommodityCode(FluentJdbc hive, String commodityCode) {
        logger.info("Reading all data from table hub_commodity for commodity_code '{}'", commodityCode);
        List<HubCommodity> hubCommodities = readAllHubCommodity(hive);
        return hubCommodities
                .stream()
                .filter(row -> row.getCommodity_code().trim().equals(commodityCode))
                .findFirst();
    }

    public static List<HubCountry> readAllHubCountry(FluentJdbc hive) {
        logger.info("Reading all data from table hub_country");
        return HiveTableReader.readTable(hive, HubCountry.SELECT_ALL_QUERY, HubCountry.class);
    }

    public static Optional<HubCountry> hubCountryForCountryCode(FluentJdbc hive, String hubCountryISOCode) {
        logger.info("Reading all data from table hub_country for iso_country_code_alpha_2 '{}'", hubCountryISOCode);
        List<HubCountry> hubCountries = readAllHubCountry(hive);
        return hubCountries
                .stream()
                .filter(row -> row.getIso_country_code_alpha_2().trim().equals(hubCountryISOCode))
                .findFirst();
    }

    public static List<HubCurrency> readAllHubCurrency(FluentJdbc hive) {
        logger.info("Reading all data from table hub_currency");
        return HiveTableReader.readTable(hive, HubCurrency.SELECT_ALL_QUERY, HubCurrency.class);
    }

    public static Optional<HubCurrency> hubCurrencyForCurrencyCode(FluentJdbc hive, String currencyCode) {
        logger.info("Reading all data from table hub_currency for currency_iso_code '{}'", currencyCode);
        List<HubCurrency> hubCurrency = readAllHubCurrency(hive);
        return hubCurrency
                .stream()
                .filter(row -> row.getCurrency_iso_code().trim().equals(currencyCode))
                .findFirst();
    }

    public static List<HubCustomsProceduceCode> readAllHubCustomsProceduceCode(FluentJdbc hive) {
        logger.info("Reading all data from table hub_customs_procedure_code");
        return HiveTableReader.readTable(hive, HubCustomsProceduceCode.SELECT_ALL_QUERY, HubCustomsProceduceCode.class);
    }

    public static Optional<HubCustomsProceduceCode> hubCustomsProceduceCodeForCPC(FluentJdbc hive, String customsProcedureCode) {
        logger.info("Reading all data from table hub_customs_procedure_code for customs_procedure_code '{}'", customsProcedureCode);
        List<HubCustomsProceduceCode> hubCustomsProceduceCode = readAllHubCustomsProceduceCode(hive);
        return hubCustomsProceduceCode
                .stream()
                .filter(row -> row.getCustoms_procedure_code().trim().equals(customsProcedureCode))
                .findFirst();
    }

    public static List<HubDeclaration> readAllHubDeclaration(FluentJdbc hive) {
        logger.info("Reading all data from table hub_declaration");
        return HiveTableReader.readTable(hive, HubDeclaration.SELECT_ALL_QUERY, HubDeclaration.class);
    }

    public static Optional<HubDeclaration> hubDeclarationForEntryReference(FluentJdbc hive, String entryReference) {
        logger.info("Reading all data from table hub_declaration for entry_reference {}", entryReference);
        List<HubDeclaration> hubDeclarations = readAllHubDeclaration(hive);
        return hubDeclarations
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryReference))
                .findFirst();
    }

    public static List<HubDeclarationLine> readAllHubDeclarationLine(FluentJdbc hive) {
        logger.info("Reading all data from table hub_declaration_line");
        return HiveTableReader.readTable(hive, HubDeclarationLine.SELECT_ALL_QUERY, HubDeclarationLine.class);
    }

    public static Optional<HubDeclarationLine> hubDeclarationLineForEntryReferenceItemNo(FluentJdbc hive, String entryReference, String itemNo) {
        logger.info("Reading all data from table hub_declaration_line for entry_reference '{}' and item_number '{}'", entryReference, itemNo);
        List<HubDeclarationLine> hubDeclarationLines = readAllHubDeclarationLine(hive);
        return hubDeclarationLines
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryReference) && row.getItem_number().equals(itemNo))
                .findFirst();
    }

    public static Optional<HubDeclarationLine> hubDeclarationLineForEntryNumberItemNo(FluentJdbc hive, String entryNumber, String itemNo) {
        logger.info("Reading all data from table HubDeclarationLine for entry number '{}' and item no '{}'", entryNumber, itemNo);
        List<HubDeclarationLine> hubDeclarationLines = readAllHubDeclarationLine(hive);
        return hubDeclarationLines
                .stream()
                .filter(row -> row.getEntry_reference().contains(entryNumber) && row.getItem_number().equals(itemNo))
                .findFirst();
    }

    public static List<HubDocument> readAllHubDocument(FluentJdbc hive) {
        logger.info("Reading all data from table hub_document");
        return HiveTableReader.readTable(hive, HubDocument.SELECT_ALL_QUERY, HubDocument.class);
    }

    public static Optional<HubDocument> hubDocumentForEntryReferenceItemNoSeqNo(FluentJdbc hive, String entryReference, String itemNo, String seqNo) {
        logger.info("Reading all data from table hub_document for entry_reference '{}' and item_number '{}' and document_sequence_number '{}'", entryReference, itemNo, seqNo);
        List<HubDocument> hubDocument = readAllHubDocument(hive);
        return hubDocument
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryReference) && row.getItem_number().equals(itemNo) && row.getDocument_sequence_number().equals(seqNo))
                .findFirst();
    }


    public static List<HubPreviousDocument> readAllHubPreviousDocument(FluentJdbc hive) {
        logger.info("Reading all data from table hub_previous_document");
        return HiveTableReader.readTable(hive, HubPreviousDocument.SELECT_ALL_QUERY, HubPreviousDocument.class);
    }

    public static Optional<HubPreviousDocument> hubPreviousDocumentForEntryReferenceItemNoSeqNo(FluentJdbc hive, String entryReference, String itemNo, String seqNo) {
        logger.info("Reading all data from table hub_previous_document for entry_reference '{}' and item_number '{}' and document_sequence_number", entryReference, itemNo, seqNo);
        List<HubPreviousDocument> hubPreviousDocument = readAllHubPreviousDocument(hive);
        return hubPreviousDocument
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryReference) && row.getItem_number().equals(itemNo) && row.getPrevious_document_sequence_number().equals(seqNo))
                .findFirst();
    }

    public static List<HubTaxLine> readAllHubTaxLine(FluentJdbc hive) {
        logger.info("Reading all data from table hub_tax_line");
        return HiveTableReader.readTable(hive, HubTaxLine.SELECT_ALL_QUERY, HubTaxLine.class);
    }

    public static Optional<HubTaxLine> hubTaxLineForEntryReferenceItemNoSeqNo(FluentJdbc hive, String entryReference, String itemNo, String seqNo) {
        logger.info("Reading all data from table hub_tax_line for entry_reference '{}' and item_number '{}' and tax_line_sequence_number '{}'", entryReference, itemNo, seqNo);
        List<HubTaxLine> hubTaxLine = readAllHubTaxLine(hive);
        return hubTaxLine
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryReference) && row.getItem_number().equals(itemNo) && row.getTax_line_sequence_number().equals(seqNo))
                .findFirst();
    }

    public static List<HubTrader> readAllHubTrader(FluentJdbc hive) {
        logger.info("Reading all data from table hub_trader");
        return HiveTableReader.readTable(hive, HubTrader.SELECT_ALL_QUERY, HubTrader.class);
    }

    public static Optional<HubTrader> hubTraderForImporterTurn(FluentJdbc hive, String importerTurn) {
        logger.info("Reading all data from table hub_trader for turn '{}'", importerTurn);
        List<HubTrader> hubTrader = readAllHubTrader(hive);
        return hubTrader
                .stream()
                .filter(row -> row.getTurn().equals(importerTurn))
                .findFirst();
    }
    //endregion

    //region satellites
    public static List<SatAdditionalInfo> readAllSatAdditionalInfo(FluentJdbc hive) {
        logger.info("Reading all data from table sat_additional_info");
        return HiveTableReader.readTable(hive, SatAdditionalInfo.SELECT_ALL_QUERY, SatAdditionalInfo.class);
    }

    public static Optional<SatAdditionalInfo> satAdditionalInfoForSatHashDiff (FluentJdbc hive, String satHashDiff) {
        logger.info("Reading all data from table sat_additional_info for sat_hash_diff '{}'", satHashDiff);
        List<SatAdditionalInfo> satAdditionalInfo = readAllSatAdditionalInfo(hive);
        return satAdditionalInfo
                .stream()
                .filter(row -> row.getSat_hash_diff().equals(satHashDiff))
                .findFirst();
    }

    public static List<SatCommodity> readAllSatCommodity(FluentJdbc hive) {
        logger.info("Reading all data from table sat_commodity");
        return HiveTableReader.readTable(hive, SatCommodity.SELECT_ALL_QUERY, SatCommodity.class);
    }

    public static Optional<SatCommodity> satCommodityForSatHashDiff(FluentJdbc hive, String satHashDiff) {
        logger.info("Reading all data from table sat_commodity for sat_hash_diff '{}'", satHashDiff);
        List<SatCommodity> satCommodity = readAllSatCommodity(hive);
        return satCommodity
                .stream()
                .filter(row -> row.getSat_hash_diff().equals(satHashDiff))
                .findFirst();
    }

    public static List<SatCountry> readAllSatCountry(FluentJdbc hive) {
        logger.info("Reading all data from table sat_country");
        return HiveTableReader.readTable(hive, SatCountry.SELECT_ALL_QUERY, SatCountry.class);
    }

    public static Optional<SatCountry> satCountryForSatHashDiff(FluentJdbc hive, String satHashDiff) {
        logger.info("Reading all data from table sat_country for sat_hash_diff '{}'", satHashDiff);
        List<SatCountry> satCountry = readAllSatCountry(hive);
        return satCountry
                .stream()
                .filter(row -> row.getSat_hash_diff().equals(satHashDiff))
                .findFirst();
    }

    public static List<SatCurrency> readAllSatCurrency(FluentJdbc hive) {
        logger.info("Reading all data from table sat_currency");
        return HiveTableReader.readTable(hive, SatCurrency.SELECT_ALL_QUERY, SatCurrency.class);
    }

    public static Optional<SatCurrency> satCurrencyForSatHashDiff(FluentJdbc hive, String satHashDiff) {
        logger.info("Reading all data from table sat_currency for sat_hash_diff '{}'", satHashDiff);
        List<SatCurrency> satCurrency = readAllSatCurrency(hive);
        return satCurrency
                .stream()
                .filter(row -> row.getSat_hash_diff().equals(satHashDiff))
                .findFirst();
    }

    public static Optional<SatCurrency> satCurrencyForHubTraderKey(FluentJdbc hive, String hubTraderKey) {
        logger.info("Reading all data from table sat_currency for hub_trader_key '{}'", hubTraderKey);
        List<SatCurrency> satCurrency = readAllSatCurrency(hive);
        return satCurrency
                .stream()
                .filter(row -> row.getHub_currency_key().equals(hubTraderKey))
                .findFirst();
    }

    public static List<SatDeclaration> readAllSatDeclaration(FluentJdbc hive) {
        logger.info("Reading all data from table sat_declaration");
        return HiveTableReader.readTable(hive, SatDeclaration.SELECT_ALL_QUERY, SatDeclaration.class);
    }

    public static Optional<SatDeclaration> satDeclarationForHubDeclarationKey(FluentJdbc hive, String hubDeclarationKey) {
        logger.info("Reading all data from table sat_declaration for hub_declaration_key '{}'", hubDeclarationKey);
        List<SatDeclaration> satDeclaration = readAllSatDeclaration(hive);
        return satDeclaration
                .stream()
                .filter(row -> row.getHub_declaration_key().equals(hubDeclarationKey))
                .findFirst();
    }

    public static Optional<SatDeclaration> satDeclarationForSatHashDiff(FluentJdbc hive, String satHashDiff) {
        logger.info("Reading all data from table sat_declaration for sat_hash_diff '{}'", satHashDiff);
        List<SatDeclaration> satDeclaration = readAllSatDeclaration(hive);
        return satDeclaration
                .stream()
                .filter(row -> row.getSat_hash_diff().equals(satHashDiff))
                .findFirst();
    }

    public static Optional<SatDeclaration> satDeclarationForEntryNumber(FluentJdbc hive, String entryNo) {
        logger.info("Reading all data from table sat_declaration for entry_number '{}'", entryNo);
        List<SatDeclaration> satDeclaration = readAllSatDeclaration(hive);
        return satDeclaration
                .stream()
                .filter(row -> row.getEntry_number().equals(entryNo))
                .findFirst();
    }

    public static List<SatDeclarationLine> readAllSatDeclarationLine(FluentJdbc hive) {
        logger.info("Reading all data from table sat_declaration_line");
        return HiveTableReader.readTable(hive, SatDeclarationLine.SELECT_ALL_QUERY, SatDeclarationLine.class);
    }

    public static Optional<SatDeclarationLine> satDeclarationLineForHubDeclarationKey(FluentJdbc hive, String hubDeclarationLineKey) {
        logger.info("Reading all data from table sat_declaration_line for hub_declaration_line_key '{}'", hubDeclarationLineKey);
        List<SatDeclarationLine> satDeclarationLines = readAllSatDeclarationLine(hive);
        return satDeclarationLines
                .stream()
                .filter(row -> row.getHub_declaration_line_key().equals(hubDeclarationLineKey))
                .findFirst();
    }

    public static Optional<SatDeclarationLine> satDeclarationLineForSatHashDiff(FluentJdbc hive, String satHashDiff) {
        logger.info("Reading all data from table sat_declaration_line for sat_hash_diff '{}'", satHashDiff);
        List<SatDeclarationLine> satDeclarationLines = readAllSatDeclarationLine(hive);
        return satDeclarationLines
                .stream()
                .filter(row -> row.getSat_hash_diff().equals(satHashDiff))
                .findFirst();
    }

    public static List<SatDocument> readAllSatDocument(FluentJdbc hive) {
        logger.info("Reading all data from table sat_document");
        return HiveTableReader.readTable(hive, SatDocument.SELECT_ALL_QUERY, SatDocument.class);
    }

    public static Optional<SatDocument> satDocumentForSatHashDiff(FluentJdbc hive, String satHashDiff) {
        logger.info("Reading all data from table sat_document for sat_hash_diff '{}'", satHashDiff);
        List<SatDocument> satDocument = readAllSatDocument(hive);
        return satDocument
                .stream()
                .filter(row -> row.getSat_hash_diff().equals(satHashDiff))
                .findFirst();
    }

    public static List<SatPreviousDocument> readAllSatPreviousDocument(FluentJdbc hive) {
        logger.info("Reading all data from table sat_previous_document");
        return HiveTableReader.readTable(hive, SatPreviousDocument.SELECT_ALL_QUERY, SatPreviousDocument.class);
    }

    public static Optional<SatPreviousDocument> satPreviousDocumentForSatHashDiff(FluentJdbc hive, String satHashDiff) {
        logger.info("Reading all data from table sat_previous_document for sat_hash_diff '{}'", satHashDiff);
        List<SatPreviousDocument> satPreviousDocument = readAllSatPreviousDocument(hive);
        return satPreviousDocument
                .stream()
                .filter(row -> row.getSat_hash_diff().equals(satHashDiff))
                .findFirst();
    }

    public static List<SatTaxLine> readAllSatTaxLine(FluentJdbc hive) {
        logger.info("Reading all data from table sat_tax_line");
        return HiveTableReader.readTable(hive, SatTaxLine.SELECT_ALL_QUERY, SatTaxLine.class);
    }

    public static Optional<SatTaxLine> satTaxLineForSatHashDiff(FluentJdbc hive, String satHashDiff) {
        logger.info("Reading all data from table sat_tax_line for sat_hash_diff '{}'", satHashDiff);
        List<SatTaxLine> satTaxLine = readAllSatTaxLine(hive);
        return satTaxLine
                .stream()
                .filter(row -> row.getSat_hash_diff().equals(satHashDiff))
                .findFirst();
    }

    public static List<SatTrader> readAllSatTrader(FluentJdbc hive) {
        logger.info("Reading all data from table sat_trader");
        return HiveTableReader.readTable(hive, SatTrader.SELECT_ALL_QUERY, SatTrader.class);
    }

    public static Optional<SatTrader> satTraderForSatHashDiff(FluentJdbc hive, String satHashDiff) {
        logger.info("Reading all data from table sat_trader for sat_hash_diff '{}'", satHashDiff);
        List<SatTrader> satTrader = readAllSatTrader(hive);
        return satTrader
                .stream()
                .filter(row -> row.getSat_hash_diff().equals(satHashDiff))
                .findFirst();
    }

    public static Optional<SatTrader> satTraderForHubTraderKey(FluentJdbc hive, String hubTraderKey) {
        logger.info("Reading all data from table sat_trader for hub_trader_key '{}'", hubTraderKey);
        List<SatTrader> satTrader = readAllSatTrader(hive);
        return satTrader
                .stream()
                .filter(row -> row.getHub_trader_key().equals(hubTraderKey))
                .findFirst();
    }
    //endregion

    //region links
    public static List<LinkDeclarationConsignorTrader> readAllLinkDeclarationConsignorTrader(FluentJdbc hive) {
        logger.info("Reading all data from table link_declaration_consignor_trader");
        return HiveTableReader.readTable(hive, LinkDeclarationConsignorTrader.SELECT_ALL_QUERY, LinkDeclarationConsignorTrader.class);
    }

    public static Optional<LinkDeclarationConsignorTrader> linkDeclarationConsignorTraderForEntryReference(FluentJdbc hive, String entryReference) {
        logger.info("Reading all data from table link_declaration_consignor_trader for entry_reference '{}'", entryReference);
        List<LinkDeclarationConsignorTrader> linkDeclarationConsignorTrader = readAllLinkDeclarationConsignorTrader(hive);
        return linkDeclarationConsignorTrader
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryReference))
                .findFirst();
    }

    public static List<LinkDeclarationDeclarantTrader> readAllLinkDeclarationDeclarantTrader(FluentJdbc hive) {
        logger.info("Reading all data from table link_declaration_declarant_trader");
        return HiveTableReader.readTable(hive, LinkDeclarationDeclarantTrader.SELECT_ALL_QUERY, LinkDeclarationDeclarantTrader.class);
    }

    public static Optional<LinkDeclarationDeclarantTrader> linkDeclarationDeclarantTraderForEntryRef(FluentJdbc hive, String entryRef) {
        logger.info("Reading all data from table link_declaration_declarant_trader for entry_reference '{}'", entryRef);
        List<LinkDeclarationDeclarantTrader> linkDeclarationDeclarantTrader = readAllLinkDeclarationDeclarantTrader(hive);
        return linkDeclarationDeclarantTrader
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryRef))
                .findFirst();
    }

    public static List<LinkDeclarationDestinationCountry> readAllLinkDeclarationDestinationCountry(FluentJdbc hive) {
        logger.info("Reading all data from table link_declaration_destination_country");
        return HiveTableReader.readTable(hive, LinkDeclarationDestinationCountry.SELECT_ALL_QUERY, LinkDeclarationDestinationCountry.class);
    }

    public static Optional<LinkDeclarationDestinationCountry> linkDeclarationDestinationCountryForEntryRef(FluentJdbc hive, String entryRef) {
        logger.info("Reading all data from table link_declaration_destination_country for entry_reference '{}'", entryRef);
        List<LinkDeclarationDestinationCountry> linkDeclarationDestinationCountry = readAllLinkDeclarationDestinationCountry(hive);
        return linkDeclarationDestinationCountry
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryRef))
                .findFirst();
    }

    public static List<LinkDeclarationExporterTrader> readAllLinkDeclarationExporterTrader(FluentJdbc hive) {
        logger.info("Reading all data from table link_declaration_exporter_trader");
        return HiveTableReader.readTable(hive, LinkDeclarationExporterTrader.SELECT_ALL_QUERY, LinkDeclarationExporterTrader.class);
    }

    public static Optional<LinkDeclarationExporterTrader> linkDeclarationExporterTraderForEntryRef(FluentJdbc hive, String entryRef) {
        logger.info("Reading all data from table link_declaration_exporter_trader for entry_reference '{}'", entryRef);
        List<LinkDeclarationExporterTrader> linkDeclarationExporterTrader = readAllLinkDeclarationExporterTrader(hive);
        return linkDeclarationExporterTrader
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryRef))
                .findFirst();
    }

    public static List<LinkDeclarationFreightCurrency> readAllLinkDeclarationFreightCurrency(FluentJdbc hive) {
        logger.info("Reading all data from table link_declaration_freight_currency");
        return HiveTableReader.readTable(hive, LinkDeclarationFreightCurrency.SELECT_ALL_QUERY, LinkDeclarationFreightCurrency.class);
    }

    public static Optional<LinkDeclarationFreightCurrency> linkDeclarationFreightCurrencyForEntryRef(FluentJdbc hive, String entryRef) {
        logger.info("Reading all data from table link_declaration_freight_currency for entry_reference '{}'", entryRef);
        List<LinkDeclarationFreightCurrency> linkDeclarationFreightCurrency = readAllLinkDeclarationFreightCurrency(hive);
        return linkDeclarationFreightCurrency
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryRef))
                .findFirst();
    }

    public static List<LinkDeclarationImporterTrader> readAllLinkDeclarationImporterTrader(FluentJdbc hive) {
        logger.info("Reading all data from table link_declaration_importer_trader");
        return HiveTableReader.readTable(hive, LinkDeclarationImporterTrader.SELECT_ALL_QUERY, LinkDeclarationImporterTrader.class);
    }

    public static Optional<LinkDeclarationImporterTrader> linkDeclarationImporterTraderForEntryRef(FluentJdbc hive, String entryRef) {
        logger.info("Reading all data from table link_declaration_importer_trader for entry_reference '{}'", entryRef);
        List<LinkDeclarationImporterTrader> linkDeclarationImporterTrader = readAllLinkDeclarationImporterTrader(hive);
        return linkDeclarationImporterTrader
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryRef))
                .findFirst();
    }

    public static List<LinkDeclarationInvoiceCurrency> readAllLinkDeclarationInvoiceCurrency(FluentJdbc hive) {
        logger.info("Reading all data from table link_declaration_invoice_currency");
        return HiveTableReader.readTable(hive, LinkDeclarationInvoiceCurrency.SELECT_ALL_QUERY, LinkDeclarationInvoiceCurrency.class);
    }

    public static Optional<LinkDeclarationInvoiceCurrency> linkDeclarationInvoiceCurrencyForEntryRef(FluentJdbc hive, String entryRef) {
        logger.info("Reading all data from table link_declaration_invoice_currency for entry_reference '{}'", entryRef);
        List<LinkDeclarationInvoiceCurrency> linkDeclarationInvoiceCurrency = readAllLinkDeclarationInvoiceCurrency(hive);
        return linkDeclarationInvoiceCurrency
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryRef))
                .findFirst();
    }

    public static List<LinkDeclarationLineAdditionalInfo> readAllLinkDeclarationLineAdditonalInfo(FluentJdbc hive) {
        logger.info("Reading all data from table link_declaration_line_additional_info");
        return HiveTableReader.readTable(hive, LinkDeclarationLineAdditionalInfo.SELECT_ALL_QUERY, LinkDeclarationLineAdditionalInfo.class);
    }

    public static Optional<LinkDeclarationLineAdditionalInfo> linkDeclarationLineAdditionalInfoForEntryRefAndItemNoAndSeqNo(FluentJdbc hive, String entryRef, String itemNumber, String seqNo) {
        logger.info("Reading all data from table link_declaration_line_additional_info for entry_reference '{}' and item_number '{}' and addtional_information_sequence_number '{}'",
                entryRef, itemNumber, seqNo);
        List<LinkDeclarationLineAdditionalInfo> linkDeclarationLineAdditionalInfo = readAllLinkDeclarationLineAdditonalInfo(hive);
        return linkDeclarationLineAdditionalInfo
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryRef) && row.getItem_number().equals(itemNumber) && row.getAdditional_information_sequence_number().equals(seqNo))
                .findFirst();
    }

    public static List<LinkDeclarationLineCommodity> readAllLinkDeclarationLineCommodity(FluentJdbc hive) {
        logger.info("Reading all data from table link_declaration_line_commodity");
        return HiveTableReader.readTable(hive, LinkDeclarationLineCommodity.SELECT_ALL_QUERY, LinkDeclarationLineCommodity.class);
    }

    public static Optional<LinkDeclarationLineCommodity> linkDeclarationLineCommodityForEntryRefItemNoAndCommodityCode(FluentJdbc hive, String entryRef, String itemNumber, String commodityCode) {
        logger.info("Reading all data from table link_declaration_line_commodity for entry_reference '{}', item_number '{}' and commodity_code '{}'", entryRef, itemNumber, commodityCode);
        List<LinkDeclarationLineCommodity> linkDeclarationLineCommodities = readAllLinkDeclarationLineCommodity(hive);
        return linkDeclarationLineCommodities
                .stream()
                .filter(row ->
                        row.getEntry_reference().equals(entryRef) &&
                                row.getItem_number().equals(itemNumber) &&
                                row.getCommodity_code().equals(commodityCode)
                ).findFirst();
    }

    public static List<LinkDeclarationLineCustomsProcedureCode> readAllLinkDeclarationLineCustomsProcedureCode(FluentJdbc hive) {
        logger.info("Reading all data from table link_declaration_line_customs_procedure_code");
        return HiveTableReader.readTable(hive, LinkDeclarationLineCustomsProcedureCode.SELECT_ALL_QUERY, LinkDeclarationLineCustomsProcedureCode.class);
    }

    public static Optional<LinkDeclarationLineCustomsProcedureCode> linkDeclarationLineCustomsProceduceCodeForEntryReferenceItemNoAndCPC(FluentJdbc hive, String entryReference, String itemNumber, String cpc) {
        logger.info("Reading all data from table link_declaration_line_customs_procedure_code for entry_reference '{}', item_number '{}' and customs_procedure_code '{}'",
                entryReference, itemNumber, cpc);
        List<LinkDeclarationLineCustomsProcedureCode> linkDeclarationLineCPC = readAllLinkDeclarationLineCustomsProcedureCode(hive);
        return linkDeclarationLineCPC
                .stream()
                .filter(row ->
                        row.getEntry_reference().equals(entryReference) &&
                                row.getItem_number().equals(itemNumber) &&
                                row.getCustoms_procedure_code().equals(cpc)
                ).findFirst();
    }

    public static List<LinkDeclarationLineDeclaration> readAllLinkDeclarationLineDeclaration(FluentJdbc hive) {
        logger.info("Reading all data from table link_declaration_line_declaration");
        return HiveTableReader.readTable(hive, LinkDeclarationLineDeclaration.SELECT_ALL_QUERY, LinkDeclarationLineDeclaration.class);
    }

    public static Optional<LinkDeclarationLineDeclaration> linkDeclarationLineDeclarationForEntryReferenceAndItemNo(FluentJdbc hive, String entryReference, String itemNumber) {
        logger.info("Reading all data from table link_declaration_line_declaration for entry_reference '{}' and item_number '{}'", entryReference, itemNumber);
        List<LinkDeclarationLineDeclaration> linkDeclarationLineDeclarations = readAllLinkDeclarationLineDeclaration(hive);
        return linkDeclarationLineDeclarations
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryReference) && row.getItem_number().equals(itemNumber))
                .findFirst();
    }

    public static List<LinkDeclarationLineDocument> readAllLinkDeclarationLineDocument(FluentJdbc hive) {
        logger.info("Reading all data from table link_declaration_line_document");
        return HiveTableReader.readTable(hive, LinkDeclarationLineDocument.SELECT_ALL_QUERY, LinkDeclarationLineDocument.class);
    }

    public static Optional<LinkDeclarationLineDocument> linkDeclarationLineDocumentForEntryRefAndItemNoAndSeqNo(FluentJdbc hive, String entryRef, String itemNumber, String seqNo) {
        logger.info("Reading all data from table link_declaration_line_document for entry_reference '{}' and item_number '{}' and document_sequence_number '{}'",
                entryRef, itemNumber, seqNo);
        List<LinkDeclarationLineDocument> linkDeclarationLineDocument = readAllLinkDeclarationLineDocument(hive);
        return linkDeclarationLineDocument
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryRef) && row.getItem_number().equals(itemNumber) && row.getDocument_sequence_number().equals(seqNo))
                .findFirst();
    }

    public static List<LinkDeclarationLineImporterTrader> readAllLinkDeclarationLineImporterTrader(FluentJdbc hive) {
        logger.info("Reading all data from table link_declaration_line_importer_trader");
        return HiveTableReader.readTable(hive, LinkDeclarationLineImporterTrader.SELECT_ALL_QUERY, LinkDeclarationLineImporterTrader.class);
    }

    public static Optional<LinkDeclarationLineImporterTrader> linkDeclarationLineImporterTraderForEntryRefAndItemNo(FluentJdbc hive, String entryRef, String itemNo) {
        logger.info("Reading all data from table link_declaration_line_importer_trader for entry_reference '{}' and item_number '{}'", entryRef, itemNo);
        List<LinkDeclarationLineImporterTrader> linkDeclarationLineImporterTrader = readAllLinkDeclarationLineImporterTrader(hive);
        return linkDeclarationLineImporterTrader
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryRef) && row.getItem_number().equals(itemNo))
                .findFirst();
    }

    public static List<LinkDeclarationLineOriginCountry> readAllLinkDeclarationLineOriginCountry(FluentJdbc hive) {
        logger.info("Reading all data from table link_declaration_line_origin_country");
        return HiveTableReader.readTable(hive, LinkDeclarationLineOriginCountry.SELECT_ALL_QUERY, LinkDeclarationLineOriginCountry.class);
    }

    public static Optional<LinkDeclarationLineOriginCountry> linkDeclarationLineOriginCountryForLineAndCountry(FluentJdbc hive, String hubDeclarationLineKey, String hubCountryISOCode) {
        logger.info("Reading all data from table link_declaration_line_origin_country for hub_declaration_line_key '{}' and iso_country_code_alpha_2 '{}'", hubDeclarationLineKey, hubCountryISOCode);
        List<LinkDeclarationLineOriginCountry> linkDeclarationLineOriginCountry = readAllLinkDeclarationLineOriginCountry(hive);
        return linkDeclarationLineOriginCountry
                .stream()
                .filter(row -> row.getHub_declaration_line_key().equals(hubDeclarationLineKey) && row.getIso_country_code_alpha_2().trim().equals(hubCountryISOCode))
                .findFirst();
    }

    public static Optional<LinkDeclarationLineOriginCountry> linkDeclarationLineOriginCountryForEntryRefAndItemNo(FluentJdbc hive, String entryRef, String itemNo) {
        logger.info("Reading all data from table link_declaration_line_origin_country for entry_reference '{}' and item_number '{}'", entryRef, itemNo);
        List<LinkDeclarationLineOriginCountry> linkDeclarationLineOriginCountry = readAllLinkDeclarationLineOriginCountry(hive);
        return linkDeclarationLineOriginCountry
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryRef) && row.getItem_number().trim().equals(itemNo))
                .findFirst();
    }

    public static List<LinkDeclarationLinePreviousDocument> readAllLinkDeclarationLinePreviousDocument(FluentJdbc hive) {
        logger.info("Reading all data from table link_declaration_line_previous_document");
        return HiveTableReader.readTable(hive, LinkDeclarationLinePreviousDocument.SELECT_ALL_QUERY, LinkDeclarationLinePreviousDocument.class);
    }

    public static Optional<LinkDeclarationLinePreviousDocument> linkDeclarationLinePreviousDocumentForEntryRefAndItemNoAndSeqNo(FluentJdbc hive, String entryRef, String itemNumber, String seqNo) {
        logger.info("Reading all data from table link_declaration_line_previous_document for entry_reference '{}' and item_number '{}' and document_sequence_number '{}'",
                entryRef, itemNumber, seqNo);
        List<LinkDeclarationLinePreviousDocument> linkDeclarationLinePreviousDocument = readAllLinkDeclarationLinePreviousDocument(hive);
        return linkDeclarationLinePreviousDocument
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryRef) && row.getItem_number().equals(itemNumber) && row.getPrevious_document_sequence_number().equals(seqNo))
                .findFirst();
    }

    public static List<LinkDeclarationLineTaxLine> readAllLinkDeclarationLineTaxLine(FluentJdbc hive) {
        logger.info("Reading all data from table link_declaration_line_tax_line");
        return HiveTableReader.readTable(hive, LinkDeclarationLineTaxLine.SELECT_ALL_QUERY, LinkDeclarationLineTaxLine.class);
    }

    public static Optional<LinkDeclarationLineTaxLine> linkDeclarationLineTaxLineForEntryRefAndItemNoAndSeqNo(FluentJdbc hive, String entryRef, String itemNumber, String seqNo) {
        logger.info("Reading all data from table link_declaration_line_tax_line for entry_reference '{}' and item_number '{}' and document_sequence_number '{}'",
                entryRef, itemNumber, seqNo);
        List<LinkDeclarationLineTaxLine> linkDeclarationLineTaxLine = readAllLinkDeclarationLineTaxLine(hive);
        return linkDeclarationLineTaxLine
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryRef) && row.getItem_number().equals(itemNumber) && row.getTax_line_sequence_number().equals(seqNo))
                .findFirst();
    }

    public static List<LinkDeclarationPayingAgentTrader> readAllLinkDeclarationPayingAgentTrader(FluentJdbc hive) {
        logger.info("Reading all data from table link_declaration_paying_agent_trader");
        return HiveTableReader.readTable(hive, LinkDeclarationPayingAgentTrader.SELECT_ALL_QUERY, LinkDeclarationPayingAgentTrader.class);
    }

    public static Optional<LinkDeclarationPayingAgentTrader> linkDeclarationPayingAgentTraderForEntryRef(FluentJdbc hive, String entryRef) {
        logger.info("Reading all data from table link_declaration_paying_agent_trader for entry_reference '{}'", entryRef);
        List<LinkDeclarationPayingAgentTrader> readAllLinkDeclarationPayingAgentTrader = readAllLinkDeclarationPayingAgentTrader(hive);
        return readAllLinkDeclarationPayingAgentTrader
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryRef))
                .findFirst();
    }

    public static List<LinkDeclarationTransportCountry> readAllLinkDeclarationTransportCountry(FluentJdbc hive) {
        logger.info("Reading all data from table link_declaration_transport_country");
        return HiveTableReader.readTable(hive, LinkDeclarationTransportCountry.SELECT_ALL_QUERY, LinkDeclarationTransportCountry.class);
    }

    public static Optional<LinkDeclarationTransportCountry> linkDeclarationTransportCountryForEntryRef(FluentJdbc hive, String entryRef) {
        logger.info("Reading all data from table link_declaration_transport_country for entry_reference '{}'", entryRef);
        List<LinkDeclarationTransportCountry> linkDeclarationTransportCountry = readAllLinkDeclarationTransportCountry(hive);
        return linkDeclarationTransportCountry
                .stream()
                .filter(row -> row.getEntry_reference().equals(entryRef))
                .findFirst();
    }
    //endregion
}
