package uk.gov.gsi.hmrc.cds.dar.automation.framework.connection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.util.Optional;

/**
 * Created by smalavalli on 06/06/17.
 */
public enum DOCKER_ENV {
    STAGE;

    private static Logger logger = LoggerFactory.getLogger(DOCKER_ENV.class);
    private static final String DEV = "DEV";
    private static final String MDC_DOCKER_ENV = "docker_env"; // This constant is set in BaseIntegrationTest.java

    public static DOCKER_MACHINE getInstance() {
        return DOCKER_MACHINE.valueOf(Optional.ofNullable(MDC.get(MDC_DOCKER_ENV)).orElse(DEV));
    }

}
