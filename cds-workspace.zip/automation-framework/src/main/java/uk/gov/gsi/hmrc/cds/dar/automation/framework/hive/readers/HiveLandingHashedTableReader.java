package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers;

import org.codejargon.fluentjdbc.api.FluentJdbc;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed.*;

import java.util.List;
import java.util.Optional;

public class HiveLandingHashedTableReader {

    private static Logger logger = LoggerFactory.getLogger(HiveLandingHashedTableReader.class);

    public static List<LandingHeadersDeclarationHashed> readAllLandingHeadersDeclarationHashed(FluentJdbc hive) {
        logger.info("Reading all data from table landing_headers_declaration_hashed");
        return HiveTableReader.readTable(hive, LandingHeadersDeclarationHashed.SELECT_ALL_QUERY, LandingHeadersDeclarationHashed.class);
    }

    public static Optional<LandingHeadersDeclarationHashed> landingHeadersDeclarationHashedForEntryNo(FluentJdbc hive, String entryNo) {
        logger.info("Reading all data from table landing_headers_declaration_hashed for entry_number {}", entryNo);
        List<LandingHeadersDeclarationHashed> landingHeadersDeclarationHashedList = readAllLandingHeadersDeclarationHashed(hive);
        return landingHeadersDeclarationHashedList
                .stream()
                .filter(row ->  row.getEntry_number().equals(entryNo))
                .findFirst();
    }

    public static List<LandingLineAdditionalInformationHashed> readAllLandingLineAdditionalInformationHashed(FluentJdbc hive) {
        logger.info("Reading all data from table landing_line_additional_information_hashed");
        return HiveTableReader.readTable(hive, LandingLineAdditionalInformationHashed.SELECT_ALL_QUERY, LandingLineAdditionalInformationHashed.class);
    }

    public static Optional<LandingLineAdditionalInformationHashed> landingLineAdditionalInformationHashedForEntryReferenceItemNoSeqNo(FluentJdbc hive, String entryReference, String itemNo, String seqNo) {
        logger.info("Reading all data from table landing_line_additional_information_hashed for entry_reference '{}', item_number '{}' and seq no '{}'", entryReference, itemNo, seqNo);
        List<LandingLineAdditionalInformationHashed> lineAdditionalInformationHashedList = readAllLandingLineAdditionalInformationHashed(hive);
        return lineAdditionalInformationHashedList
                .stream()
                .filter(row ->  row.getEntry_reference().equals(entryReference) && row.getItem_number().equals(itemNo) && row.getAdditional_information_sequence_number().equals(seqNo))
                .findFirst();
    }

    public static List<LandingLineDocumentHashed> readAllLandingLineDocumentHashed(FluentJdbc hive) {
        logger.info("Reading all data from table landing_line_document_hashed");
        return HiveTableReader.readTable(hive, LandingLineDocumentHashed.SELECT_ALL_QUERY, LandingLineDocumentHashed.class);
    }

    public static Optional<LandingLineDocumentHashed> landingLineDocumentHashedForEntryReferenceItemNoSeqNo(FluentJdbc hive, String entryReference, String itemNo, String seqNo) {
        logger.info("Reading all data from table landing_line_document_hashed for entry_reference '{}', item_number '{}' and document_sequence_number '{}'", entryReference, itemNo, seqNo);
        List<LandingLineDocumentHashed> lineDocumentHashedList = readAllLandingLineDocumentHashed(hive);
        return lineDocumentHashedList
                .stream()
                .filter(row ->  row.getEntry_reference().equals(entryReference) && row.getItem_number().equals(itemNo) && row.getDocument_sequence_number().equals(seqNo))
                .findFirst();
    }

    public static List<LandingLinePreviousDocumentHashed> readAllLandingPreviousDocumentHashed(FluentJdbc hive) {
        logger.info("Reading all data from table landing_line_previous_document_hashed");
        return HiveTableReader.readTable(hive, LandingLinePreviousDocumentHashed.SELECT_ALL_QUERY, LandingLinePreviousDocumentHashed.class);
    }

    public static Optional<LandingLinePreviousDocumentHashed> landingLinePreviousDocumentHashedForEntryReferenceItemNoSeqNo(FluentJdbc hive, String entryReference, String itemNo, String seqNo) {
        logger.info("Reading all data from table landing_line_previous_document_hashed for entry_reference '{}', item_number '{}' and previous_document_sequence_number '{}'", entryReference, itemNo, seqNo);
        List<LandingLinePreviousDocumentHashed> linePreviousDocumentHashedList = readAllLandingPreviousDocumentHashed(hive);
        return linePreviousDocumentHashedList
                .stream()
                .filter(row ->  row.getEntry_reference().equals(entryReference) && row.getItem_number().equals(itemNo) && row.getPrevious_document_sequence_number().equals(seqNo))
                .findFirst();
    }

    public static List<LandingLineTaxLineHashed> readAllLandingLineTaxLineHashed(FluentJdbc hive) {
        logger.info("Reading all data from table landing_line_tax_line_hashed");
        return HiveTableReader.readTable(hive, LandingLineTaxLineHashed.SELECT_ALL_QUERY, LandingLineTaxLineHashed.class);
    }

    public static Optional<LandingLineTaxLineHashed> landingLineTaxLineHashedForEntryReferenceItemNoSeqNo(FluentJdbc hive, String entryReference, String itemNo, String seqNo) {
        logger.info("Reading all data from table landing_line_tax_line_hashed for entry_reference '{}', item_number '{}' and tax_line_sequence_number '{}'", entryReference, itemNo, seqNo);
        List<LandingLineTaxLineHashed> lineTaxLineHashedList = readAllLandingLineTaxLineHashed(hive);
        return lineTaxLineHashedList
                .stream()
                .filter(row ->  row.getEntry_reference().equals(entryReference) && row.getItem_number().equals(itemNo) && row.getTax_line_sequence_number().equals(seqNo))
                .findFirst();
    }

    public static List<LandingLinesDeclarationHashed> readAllLandingLinesDeclarationHashed(FluentJdbc hive) {
        logger.info("Reading all data from table landing_lines_declaration_hashed");
        return HiveTableReader.readTable(hive, LandingLinesDeclarationHashed.SELECT_ALL_QUERY, LandingLinesDeclarationHashed.class);
    }

    public static Optional<LandingLinesDeclarationHashed> landingLinesDeclarationHashedForEntryReferenceItemNo(FluentJdbc hive, String entryReference, String itemNo) {
        logger.info("Reading all data from table landing_lines_declaration_hashed for entry_reference '{}' and item_number '{}'", entryReference, itemNo);
        List<LandingLinesDeclarationHashed> declarationHeadersHashedList = readAllLandingLinesDeclarationHashed(hive);
        return declarationHeadersHashedList
                .stream()
                .filter(row ->  row.getEntry_reference().equals(entryReference) && row.getItem_number().equals(itemNo))
                .findFirst();
    }

    public static Optional<LandingLinesDeclarationHashed> landingLinesDeclarationHashedForEntryNoItemNo(FluentJdbc hive, String entryNo, String itemNo) {
        logger.info("Reading all data from table landing_lines_declaration_hashed for entry_number '{}' and item_number '{}'", entryNo, itemNo);
        List<LandingLinesDeclarationHashed> declarationHeadersHashedList = readAllLandingLinesDeclarationHashed(hive);
        return declarationHeadersHashedList
                .stream()
                .filter(row ->  row.getEntry_number().equals(entryNo) && row.getItem_number().equals(itemNo))
                .findFirst();
    }

    public static List<LandingTraderHashed> readAllLandingTraderHashed(FluentJdbc hive) {
        logger.info("Reading all data from table landing_trader_hashed");
        return HiveTableReader.readTable(hive, LandingTraderHashed.SELECT_ALL_QUERY, LandingTraderHashed.class);
    }

    public static Optional<LandingTraderHashed> landingTraderHashedForTurn(FluentJdbc hive, String turn) {
        logger.info("Reading all data from table landing_trader_hashed for turn '{}'", turn);
        List<LandingTraderHashed> landingTraderHasheds = readAllLandingTraderHashed(hive);
        return landingTraderHasheds
                .stream()
                .filter(row ->  row.getTurn().equals(turn))
                .findFirst();
    }
}