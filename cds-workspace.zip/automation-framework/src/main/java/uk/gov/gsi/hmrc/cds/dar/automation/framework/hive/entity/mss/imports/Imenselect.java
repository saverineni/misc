package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by smalavalli on 21/12/16.
 */
@Data
public class Imenselect implements HiveEntity {
    public static final String SELECT_ALL_QUERY = "select iekey, impentno, decltturn, ietype, epuno, dtofent, standard_dtofent, acptncdate, standard_acptncdate, roe, masterucr, declnucr, decltrep, declnmthd, imptrturn, fedate, cstmsvalue, ietotduty, ietotvat, imptrturncc, plauldg, itemcnt, payagntturn, sessno, dispcntry, cnsgrturn, cnsgrturncc from imenselect";

    private String iekey;
    private String impentno;
    private String decltturn;
    private String ietype;
    private String epuno;
    private String dtofent;
    private String standard_dtofent;
    private String acptncdate;
    private String standard_acptncdate;
    private String roe;
    private String masterucr;
    private String declnucr;
    private String decltrep;
    private String declnmthd;
    private String imptrturn;
    private String fedate;
    private String cstmsvalue;
    private String ietotduty;
    private String ietotvat;
    private String imptrturncc;
    private String plauldg;
    private String itemcnt;
    private String payagntturn;
    private String sessno;
    private String dispcntry;
    private String cnsgrturn;
    private String cnsgrturncc;

}
