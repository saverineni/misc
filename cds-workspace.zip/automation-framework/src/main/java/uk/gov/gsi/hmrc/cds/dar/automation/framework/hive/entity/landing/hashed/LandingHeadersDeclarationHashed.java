package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class LandingHeadersDeclarationHashed implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select " +
                                                    "source, ingestion_date, entry_number, entry_date, epu_number, entry_type, declaration_method, total_excise, " +
                                                    "importer_turn, declarant_turn, declarant_representative_turn, consignee_aeo_certificate_type_code, " +
                                                    "declarant_aeo_certificate_type_code, route, declaration_import_export_indicator, generation_number, exporter_turn, " +
                                                    "destination_country_code, import_clearance_status, consignor_aeo_certificate_type_code, header_statistical_value, " +
                                                    "goods_departure_datetime, customs_value, total_duty, total_vat, net_mass_total, goods_location, acceptance_date, " +
                                                    "importer_turn_country_code, place_of_unloading_code, first_deferment_approval_num, first_deferment_approval_num_prefix, " +
                                                    "declaration_ucr, item_count, master_ucr, paying_agent_turn, place_of_loading_code, session_num, session_role_name, " +
                                                    "status_of_entry, transport_country, transport_id, transport_mode_code, dispatch_country, consignor_turn, consignor_turn_country_code, " +
                                                    "consignor_nad_name, consignee_nad_name, consignee_nad_postcode, declarant_nad_name, customs_check_code, profile_id, freight_currency, " +
                                                    "invoice_currency, invoice_total_declared, entry_reference, hub_declaration, sat_declaration, link_declaration_consignor_trader, " +
                                                    "link_declaration_consignor_trader_hub_trader, link_declaration_declarant_trader, link_declaration_declarant_trader_hub_trader, " +
                                                    "link_declaration_destination_country, link_declaration_destination_country_hub_country, link_declaration_exporter_trader, " +
                                                    "link_declaration_exporter_trader_hub_trader, link_declaration_freight_currency, link_declaration_freight_currency_hub_currency, " +
                                                    "link_declaration_importer_trader, link_declaration_importer_trader_hub_trader, link_declaration_invoice_currency, " +
                                                    "link_declaration_invoice_currency_hub_currency, link_declaration_paying_agent_trader, link_declaration_paying_agent_trader_hub_trader, " +
                                                    "link_declaration_transport_country, link_declaration_transport_country_hub_country " +
                                                    "from landing_headers_declaration_hashed";

        private String source;
        private String ingestion_date;
        private String entry_number;
        private String entry_date;
        private String epu_number;
        private String entry_type;
        private String declaration_method;
        private String total_excise;
        private String importer_turn;
        private String declarant_turn;
        private String declarant_representative_turn;
        private String consignee_aeo_certificate_type_code;
        private String declarant_aeo_certificate_type_code;
        private String route;
        private String declaration_import_export_indicator;
        private String generation_number;
        private String exporter_turn;
        private String destination_country_code;
        private String import_clearance_status;
        private String consignor_aeo_certificate_type_code;
        private String header_statistical_value;
        private String goods_departure_datetime;
        private String customs_value;
        private String total_duty;
        private String total_vat;
        private String net_mass_total;
        private String goods_location;
        private String acceptance_date;
        private String importer_turn_country_code;
        private String place_of_unloading_code;
        private String first_deferment_approval_num;
        private String first_deferment_approval_num_prefix;
        private String declaration_ucr;
        private String item_count;
        private String master_ucr;
        private String paying_agent_turn;
        private String place_of_loading_code;
        private String session_num;
        private String session_role_name;
        private String status_of_entry;
        private String transport_country;
        private String transport_id;
        private String transport_mode_code;
        private String dispatch_country;
        private String consignor_turn;
        private String consignor_turn_country_code;
        private String consignor_nad_name;
        private String consignee_nad_name;
        private String consignee_nad_postcode;
        private String declarant_nad_name;
        private String customs_check_code;
        private String profile_id;
        private String freight_currency;
        private String invoice_currency;
        private String invoice_total_declared;
        private String entry_reference;
        private String hub_declaration;
        private String sat_declaration;
        private String link_declaration_consignor_trader;
        private String link_declaration_consignor_trader_hub_trader;
        private String link_declaration_declarant_trader;
        private String link_declaration_declarant_trader_hub_trader;
        private String link_declaration_destination_country;
        private String link_declaration_destination_country_hub_country;
        private String link_declaration_exporter_trader;
        private String link_declaration_exporter_trader_hub_trader;
        private String link_declaration_freight_currency;
        private String link_declaration_freight_currency_hub_currency;
        private String link_declaration_importer_trader;
        private String link_declaration_importer_trader_hub_trader;
        private String link_declaration_invoice_currency;
        private String link_declaration_invoice_currency_hub_currency;
        private String link_declaration_paying_agent_trader;
        private String link_declaration_paying_agent_trader_hub_trader;
        private String link_declaration_transport_country;
        private String link_declaration_transport_country_hub_country;

}
