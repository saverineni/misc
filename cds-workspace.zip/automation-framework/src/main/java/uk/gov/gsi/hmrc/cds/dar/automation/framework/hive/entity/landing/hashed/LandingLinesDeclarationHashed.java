package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by smalavalli on 16/01/17.
 */
@Data
public class LandingLinesDeclarationHashed implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select source, ingestion_date, entry_number, entry_date, epu_number, item_number, clearance_datetime, origin_country_code, " +
                                                    "item_statistical_value, commodity_code, customs_procedure_code, customs_duty_paid, vat_paid, vat_value, ec_supplementary_1, " +
                                                    "item_customs_value, item_net_mass, item_supplementary_units, goods_description, item_importer_turn, item_customs_check_code, " +
                                                    "item_mic_code, item_profile_id, item_consignor_nad_name, item_consignee_nad_name, item_consignee_nad_postcode, item_price_declared, " +
                                                    "entry_reference, hs_code, hub_declaration_line, sat_declaration_line, link_declaration_line_commodity, link_declaration_line_commodity_hub_commodity, " +
                                                    "link_declaration_line_customs_procedure_code, link_declaration_line_customs_procedure_code_hub_customs_procedure_code, link_declaration_line_declaration, " +
                                                    "link_declaration_line_declaration_hub_declaration, link_declaration_line_importer_trader, link_declaration_line_importer_trader_hub_trader, " +
                                                    "link_declaration_line_origin_country, link_declaration_line_origin_country_hub_country " +
                                                    "from landing_lines_declaration_hashed";

        private String source;
        private String ingestion_date;
        private String entry_number;
        private String entry_date;
        private String epu_number;
        private String item_number;
        private String clearance_datetime;
        private String origin_country_code;
        private String item_statistical_value;
        private String commodity_code;
        private String customs_procedure_code;
        private String customs_duty_paid;
        private String vat_paid;
        private String vat_value;
        private String ec_supplementary_1;
        private String item_customs_value;
        private String item_net_mass;
        private String item_supplementary_units;
        private String goods_description;
        private String item_importer_turn;
        private String item_customs_check_code;
        private String item_mic_code;
        private String item_profile_id;
        private String item_consignor_nad_name;
        private String item_consignee_nad_name;
        private String item_consignee_nad_postcode;
        private String item_price_declared;
        private String entry_reference;
        private String hs_code;
        private String hub_declaration_line;
        private String sat_declaration_line;
        private String link_declaration_line_commodity;
        private String link_declaration_line_commodity_hub_commodity;
        private String link_declaration_line_customs_procedure_code;
        private String link_declaration_line_customs_procedure_code_hub_customs_procedure_code; //TODO long field names
        private String link_declaration_line_declaration;
        private String link_declaration_line_declaration_hub_declaration;
        private String link_declaration_line_importer_trader;
        private String link_declaration_line_importer_trader_hub_trader;
        private String link_declaration_line_origin_country;
        private String link_declaration_line_origin_country_hub_country;

}
