package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.postdatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class DimRoute implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select route from dim_route";

    private String route;
}
