package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.links;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by smalavalli on 17/01/17.
 */
@Data
public class LinkDeclarationLineOriginCountry implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select link_declaration_line_origin_country_key, hub_declaration_line_key, hub_country_key, entry_reference, item_number, iso_country_code_alpha_2, link_load_datetime, link_record_source from link_declaration_line_origin_country";
    private String link_declaration_line_origin_country_key;
    private String hub_declaration_line_key;
    private String hub_country_key;
    private String entry_reference;
    private String item_number;
    private String iso_country_code_alpha_2;
    private String link_load_datetime;
    private String link_record_source;
}
