package uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion;

import org.codejargon.fluentjdbc.api.FluentJdbc;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi.PDIStage;

import java.util.List;

import static org.junit.Assert.assertTrue;

/**
 * Created by smalavalli on 17/01/17.
 */
public class LandingHashedTableDataIngester {
    public static final List<String> LANDING_HASH_TABLES_TO_INGEST = PDIStage.CREATE_LANDING_HASHED_TABLES.sourceTablesInStage();

    public static Ingest connectToDB(FluentJdbc hive) {
        return new Ingest(hive);
    }

    public static class Ingest implements DataIngester{
        FluentJdbc hive;

        public Ingest(FluentJdbc hive) {
            this.hive = hive;
        }

        @Override
        public void verboseIngestData() {
            LandingTableDataIngester
                    .connectToDB(hive)
                    .ingestData(LandingTableDataIngester.LANDING_TABLES_TO_INGEST);

            boolean jobStatus = PDIStage.CREATE_LANDING_HASHED_TABLES.triggerPDIJob();
            assertTrue(jobStatus);
        }

    }
}
