package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers;

import org.codejargon.fluentjdbc.api.FluentJdbc;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.*;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports.*;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.*;

import java.util.List;
import java.util.Optional;

/**
 * Created by smalavalli on 22/12/16.
 */
public class HiveMSSTableReader{

    private static Logger logger = LoggerFactory.getLogger(HiveMSSTableReader.class);

    //region Imports - Headers

    public static List<Imenselect> readAllImenselect(FluentJdbc hive) {
        logger.info("Reading all data from table Imenselect");
        return HiveTableReader.readTable(hive, Imenselect.SELECT_ALL_QUERY, Imenselect.class);
    }

    public static Optional<Imenselect> imenselectForImportEntryNo(FluentJdbc hive, String importEntryNo) {
        logger.info("Reading all data from table imenselect for given impentno {}", importEntryNo);
        List<Imenselect> imenselectRows = readAllImenselect(hive);
        return imenselectRows.stream()
                .filter(row -> row.getImpentno().equals(importEntryNo))
                .findFirst();
    }

    public static List<Imendetail> readAllImendetail(FluentJdbc hive) {
        logger.info("Reading all data from table Imendetail");
        return HiveTableReader.readTable(hive, Imendetail.SELECT_ALL_QUERY, Imendetail.class);
    }

    public static Optional<Imendetail> imendetailForIeKey(FluentJdbc hive, String iekey) {
        logger.info("Reading all data from table Imendetail for given iekey {}", iekey);
        List<Imendetail> imendetailRows = readAllImendetail(hive);
        return imendetailRows.stream()
                .filter(row -> row.getIekey().equals(iekey))
                .findFirst();
    }
    //endregion

    //region Imports - Lines

    public static List<Ievc> readAllIevc(FluentJdbc hive) {
        logger.info("Reading all data from table Ievc");
        return HiveTableReader.readTable(hive, Ievc.SELECT_ALL_QUERY, Ievc.class);
    }

    public static Optional<Ievc> ievcForIeKey(FluentJdbc hive, String iekey) {
        logger.info("Reading all data from table Ievc for given iekey {}", iekey);
        List<Ievc> ievcRows = readAllIevc(hive);
        return ievcRows.stream()
                .filter(row -> row.getIekey().equals(iekey))
                .findFirst();
    }

    public static List<Iiai> readAllIiai(FluentJdbc hive) {
        logger.info("Reading all data from table Iiai");
        return HiveTableReader.readTable(hive, Iiai.SELECT_ALL_QUERY, Iiai.class);
    }

    public static Optional<Iiai> iiaiForIekeyIeitno(FluentJdbc hive, String iekey, String ieitno) {
        logger.info("Reading all data from table Iiai for given iekey {} and ieitno {}", iekey, ieitno);
        List<Iiai> iiaiRows = readAllIiai(hive);
        return iiaiRows.stream()
                .filter(row -> row.getIekey().equals(iekey) && row.getIeitno().equals(ieitno))
                .findFirst();
    }

    public static List<Iica> readAllIica(FluentJdbc hive) {
        logger.info("Reading all data from table Iica");
        return HiveTableReader.readTable(hive, Iica.SELECT_ALL_QUERY, Iica.class);
    }

    public static Optional<Iica> iicaForIekeyIeitno(FluentJdbc hive, String iekey, String ieitno) {
        logger.info("Reading all data from table Iica for given iekey {}, ieitno {}", iekey, ieitno);
        List<Iica>iicaRows = readAllIica(hive);
        return iicaRows.stream()
                .filter(row -> row.getIekey().equals(iekey) && row.getIeitno().equals(ieitno))
                .findFirst();
    }

    public static List<Iidc> readAllIidc(FluentJdbc hive) {
        logger.info("Reading all data from table Iidc");
        return HiveTableReader.readTable(hive, Iidc.SELECT_ALL_QUERY, Iidc.class);
    }

    public static Optional<Iidc> iidcForIekeyIeitno(FluentJdbc hive, String iekey, String ieitno) {
        logger.info("Reading all data from table Iidc for given iekey {} and ieitno {}", iekey, ieitno);
        List<Iidc> iidcRows = readAllIidc(hive);
        return iidcRows.stream()
                .filter(row -> row.getIekey().equals(iekey) && row.getIeitno().equals(ieitno))
                .findFirst();
    }

    public static List<Iina> readAllIina(FluentJdbc hive) {
        logger.info("Reading all data from table Iina");
        return HiveTableReader.readTable(hive, Iina.SELECT_ALL_QUERY, Iina.class);
    }

    public static Optional<Iina> iinaForIekeyIeitno(FluentJdbc hive, String iekey, String ieitno) {
        logger.info("Reading all data from table Iina for given iekey {}, ieitno {}", iekey, ieitno);
        List<Iina>iinaRows = readAllIina(hive);
        return iinaRows.stream()
                .filter(row -> row.getIekey().equals(iekey) && row.getIeitno().equals(ieitno))
                .findFirst();
    }

    public static Optional<Iina> iinaForIekeyIeitnoItemnadtype(FluentJdbc hive, String iekey, String ieitno, String itemnadtype) {
        logger.info("Reading all data from table Iina for given iekey {}, ieitno {} and itemnadtype {}", iekey, ieitno, itemnadtype);
        List<Iina> iinaRows = readAllIina(hive);
        return iinaRows.stream()
                .filter(row -> row.getIekey().equals(iekey) && row.getIeitno().equals(ieitno) && row.getItemnadtype().equals(itemnadtype))
                .findFirst();
    }

    public static List<Iipd> readAllIipd(FluentJdbc hive) {
        logger.info("Reading all data from table Iipd");
        return HiveTableReader.readTable(hive, Iipd.SELECT_ALL_QUERY, Iipd.class);
    }

    public static Optional<Iipd> iipdForIekeyIeitno(FluentJdbc hive, String iekey, String ieitno) {
        logger.info("Reading all data from table Iina for given iekey {}, ieitno {}", iekey, ieitno);
        List<Iipd> iipdRows = readAllIipd(hive);
        return iipdRows.stream()
                .filter(row -> row.getIekey().equals(iekey) && row.getIeitno().equals(ieitno))
                .findFirst();
    }

    public static List<Iipk> readAllIipk(FluentJdbc hive) {
        logger.info("Reading all data from table iipk");
        return HiveTableReader.readTable(hive, Iipk.SELECT_ALL_QUERY, Iipk.class);
    }

    public static List<Iitl> readAllIitl(FluentJdbc hive) {
        logger.info("Reading all data from table Iitl");
        return HiveTableReader.readTable(hive, Iitl.SELECT_ALL_QUERY, Iitl.class);
    }

    public static Optional<Iitl> iitlForIekeyIeitno(FluentJdbc hive, String iekey, String ieitno) {
        logger.info("Reading all data from table Iitl for given iekey {} and ieitno {}", iekey, ieitno);
        List<Iitl> iitlRows = readAllIitl(hive);
        return iitlRows.stream()
                .filter(row -> row.getIekey().equals(iekey) && row.getIeitno().equals(ieitno))
                .findFirst();
    }

    public static List<Imeidetail> readAllImeidetail(FluentJdbc hive) {
        logger.info("Reading all data from table Imeidetail");
        return HiveTableReader.readTable(hive, Imeidetail.SELECT_ALL_QUERY, Imeidetail.class);
    }

    public static Optional<Imeidetail> imeidetailForIekeyIeitno(FluentJdbc hive, String iekey, String ieitno) {
        logger.info("Reading all data from table Imeidetail for given iekey {} and ieitno {}", iekey, ieitno);
        List<Imeidetail> imeidetailRows = readAllImeidetail(hive);
        return imeidetailRows.stream()
                .filter(row -> row.getIekey().equals(iekey) && row.getIeitno().equals(ieitno))
                .findFirst();
    }

    public static List<Imeiselect> readAllImeiselect(FluentJdbc hive) {
        logger.info("Reading all data from table Imeiselect");
        return HiveTableReader.readTable(hive, Imeiselect.SELECT_ALL_QUERY, Imeiselect.class);
    }

    public static Optional<Imeiselect> imeiselectForIekeyIeitno(FluentJdbc hive, String iekey, String ieitno) {
        logger.info("Reading all data from table Imeiselect for given iekey {} and ieitno {}", iekey, ieitno);
        List<Imeiselect> imeiselectRows = readAllImeiselect(hive);
        return imeiselectRows.stream()
                .filter(row -> row.getIekey().equals(iekey) && row.getIeitno().equals(ieitno))
                .findFirst();
    }

    public static List<Inad> readAllInad(FluentJdbc hive) {
        logger.info("Reading all data from table Inad");
        return HiveTableReader.readTable(hive, Inad.SELECT_ALL_QUERY, Inad.class);
    }

    public static Optional<Inad> inadForIeKey(FluentJdbc hive, String iekey) {
        logger.info("Reading all data from table Inad for given iekey {}", iekey);
        List<Inad> inadRows = readAllInad(hive);
        return inadRows.stream()
                .filter(row -> row.getIekey().equals(iekey))
                .findFirst();
    }
    //endregion

    //region Exports - Headers

    public static List<Nxenselect> readAllNxenselect(FluentJdbc hive) {
        logger.info("Reading all data from table Nxenselect");
        return HiveTableReader.readTable(hive, Nxenselect.SELECT_ALL_QUERY, Nxenselect.class);
    }

    public static Optional<Nxenselect> nxenselectForImportEntryNo(FluentJdbc hive, String importEntryNo) {
        logger.info("Reading all data from table nxenselect for given impentno {}", importEntryNo);
        List<Nxenselect> nxenselectRows = readAllNxenselect(hive);
        return nxenselectRows.stream()
                .filter(row -> row.getImpentno().equals(importEntryNo))
                .findFirst();
    }

    public static List<Nxendetail> readAllNxendetail(FluentJdbc hive) {
        logger.info("Reading all data from table Nxendetail");
        return HiveTableReader.readTable(hive, Nxendetail.SELECT_ALL_QUERY, Nxendetail.class);
    }

    public static Optional<Nxendetail> nxendetailForIeKey(FluentJdbc hive, String iekey) {
        logger.info("Reading all data from table Nxendetail for given iekey {}", iekey);
        List<Nxendetail> nxendetailRows = readAllNxendetail(hive);
        return nxendetailRows.stream()
                .filter(row -> row.getIekey().equals(iekey))
                .findFirst();
    }
    //endregion

    //region Exports - Lines

    public static List<Nxeidetail> readAllNxeidetail(FluentJdbc hive) {
        logger.info("Reading all data from table Nxeidetail");
        return HiveTableReader.readTable(hive, Nxeidetail.SELECT_ALL_QUERY, Nxeidetail.class);
    }

    public static Optional<Nxeidetail> nxeidetailForIekeyIeitno(FluentJdbc hive, String iekey, String ieitno) {
        logger.info("Reading all data from table Nxeidetail for given iekey {} and ieitno {}", iekey, ieitno);
        List<Nxeidetail> nxeidetailRows = readAllNxeidetail(hive);
        return nxeidetailRows.stream()
                .filter(row -> row.getIekey().equals(iekey) && row.getIeitno().equals(ieitno))
                .findFirst();
    }

    public static List<Nxeiselect> readAllNxeiselect(FluentJdbc hive) {
        logger.info("Reading all data from table Nxeiselect");
        return HiveTableReader.readTable(hive, Nxeiselect.SELECT_ALL_QUERY, Nxeiselect.class);
    }

    public static Optional<Nxeiselect> nxeiselectForIekeyIeitno(FluentJdbc hive, String iekey, String ieitno) {
        logger.info("Reading all data from table Nxeiselect for given iekey {} and ieitno {}", iekey, ieitno);
        List<Nxeiselect> nxeiselectRows = readAllNxeiselect(hive);
        return nxeiselectRows.stream()
                .filter(row -> row.getIekey().equals(iekey) && row.getIeitno().equals(ieitno))
                .findFirst();
    }

    public static List<Nxevc> readAllNxevc(FluentJdbc hive) {
        logger.info("Reading all data from table nxevc");
        return HiveTableReader.readTable(hive, Nxevc.SELECT_ALL_QUERY, Nxevc.class);
    }

    public static List<Nxiai> readAllNxiai(FluentJdbc hive) {
        logger.info("Reading all data from table Nxiai");
        return HiveTableReader.readTable(hive, Nxiai.SELECT_ALL_QUERY, Nxiai.class);
    }

    public static Optional<Nxiai> nxiaiForIekeyIeitno(FluentJdbc hive, String iekey, String ieitno) {
        logger.info("Reading all data from table Nxiai for given iekey {}, ieitno {}", iekey, ieitno);
        List<Nxiai> nxiaiRows = readAllNxiai(hive);
        return nxiaiRows.stream()
                .filter(row -> row.getIekey().equals(iekey) && row.getIeitno().equals(ieitno))
                .findFirst();
    }

    public static List<Nxidc> readAllNxidc(FluentJdbc hive) {
        logger.info("Reading all data from table Nxidc");
        return HiveTableReader.readTable(hive, Nxidc.SELECT_ALL_QUERY, Nxidc.class);
    }

    public static Optional<Nxidc> nxidcForIekeyIeitno(FluentJdbc hive, String iekey, String ieitno) {
        logger.info("Reading all data from table Nxidc for given iekey {}, ieitno {}", iekey, ieitno);
        List<Nxidc> nxidcRows = readAllNxidc(hive);
        return nxidcRows.stream()
                .filter(row -> row.getIekey().equals(iekey) && row.getIeitno().equals(ieitno))
                .findFirst();
    }

    public static List<Nxina> readAllNxina(FluentJdbc hive) {
        logger.info("Reading all data from table Nxina");
        return HiveTableReader.readTable(hive, Nxina.SELECT_ALL_QUERY, Nxina.class);
    }

    public static Optional<Nxina> nxinaForIekeyIeitno(FluentJdbc hive, String iekey, String ieitno) {
        logger.info("Reading all data from table Nxina for given iekey {}, ieitno {}", iekey, ieitno);
        List<Nxina> nxinaRows = readAllNxina(hive);
        return nxinaRows.stream()
                .filter(row -> row.getIekey().equals(iekey) && row.getIeitno().equals(ieitno))
                .findFirst();
    }

    public static List<Nxipd> readAllNxipd(FluentJdbc hive) {
        logger.info("Reading all data from table nxipd");
        return HiveTableReader.readTable(hive, Nxipd.SELECT_ALL_QUERY, Nxipd.class);
    }

    public static Optional<Nxipd> nxipdForIekeyIeitno(FluentJdbc hive, String iekey, String ieitno) {
        logger.info("Reading all data from table nxipd for given iekey {}, ieitno {}", iekey, ieitno);
        List<Nxipd> nxipdRows = readAllNxipd(hive);
        return nxipdRows.stream()
                .filter(row -> row.getIekey().equals(iekey) && row.getIeitno().equals(ieitno))
                .findFirst();
    }

    public static List<Nxipk> readAllNxipk(FluentJdbc hive) {
        logger.info("Reading all data from table nxipk");
        return HiveTableReader.readTable(hive, Nxipk.SELECT_ALL_QUERY, Nxipk.class);
    }

    public static List<Nxitl> readAllNxitl(FluentJdbc hive) {
        logger.info("Reading all data from table Nxitl");
        return HiveTableReader.readTable(hive, Nxitl.SELECT_ALL_QUERY, Nxitl.class);
    }

    public static Optional<Nxitl> nxitlForIekeyIeitno(FluentJdbc hive, String iekey, String ieitno) {
        logger.info("Reading all data from table Nxitl for given iekey {}, ieitno {}", iekey, ieitno);
        List<Nxitl> nxitlRows = readAllNxitl(hive);
        return nxitlRows.stream()
                .filter(row -> row.getIekey().equals(iekey) && row.getIeitno().equals(ieitno))
                .findFirst();
    }

    public static List<Nxnad> readAllNxnad(FluentJdbc hive) {
        logger.info("Reading all data from table nxnad");
        return HiveTableReader.readTable(hive, Nxnad.SELECT_ALL_QUERY, Nxnad.class);
    }

    public static Optional<Nxnad> nxnadForIeKey(FluentJdbc hive, String iekey) {
        logger.info("Reading all data from table nxnad for given iekey {}", iekey);
        List<Nxnad> nxadRows = readAllNxnad(hive);
        return nxadRows.stream()
                .filter(row -> row.getIekey().equals(iekey))
                .findFirst();
    }
    //endregion


    public static List<Sess> readAllSess(FluentJdbc hive) {
        logger.info("Reading all data from table Sess");
        return HiveTableReader.readTable(hive, Sess.SELECT_ALL_QUERY, Sess.class);
    }

    public static Optional<Sess> sessForSessNo(FluentJdbc hive, String sessNo) {
        logger.info("Reading all data from table Sess for given sessNo {}", sessNo);
        List<Sess> sessRows = readAllSess(hive);
        return sessRows.stream()
                .filter(row -> row.getSessno().equals(sessNo))
                .findFirst();
    }

    public static List<Tder> readAllTder(FluentJdbc hive) {
        logger.info("Reading all data from table tder");
        return HiveTableReader.readTable(hive, Tder.SELECT_ALL_QUERY, Tder.class);
    }

    public static Optional<Tder> tderForTraderTurn(FluentJdbc hive, String traderTurn) {
        logger.info("Reading all data from table tder for given turn {}", traderTurn);
        List<Tder> tderRows = readAllTder(hive);
        return tderRows.stream()
                .filter(row -> row.getTurn().equals(traderTurn))
                .findFirst();
    }
}
