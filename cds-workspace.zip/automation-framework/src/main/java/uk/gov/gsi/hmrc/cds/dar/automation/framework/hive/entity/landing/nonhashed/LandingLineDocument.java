package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by developer on 08/08/17.
 */
@Data
public class LandingLineDocument implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select source, ingestion_date, item_number, document_sequence_number, generation_number, " +
                                                    "item_document_code, item_document_status, item_document_reference, entry_reference " +
                                                    "from landing_line_document";

    private String source;
    private String ingestion_date;
    private String item_number;
    private String document_sequence_number;
    private String generation_number;
    private String item_document_code;
    private String item_document_status;
    private String item_document_reference;
    private String entry_reference;

}
