package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.satellites;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class SatCommodity implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select hub_commodity_key, sat_hash_diff, sat_load_datetime, sat_load_end_datetime, sat_record_source, cc_year, cc_month, hs_chapter, hs_heading, hs_chapter_heading, hs_subheading, chapter_description, heading_description, subheading_description from sat_commodity";

    private String hub_commodity_key;
    private String sat_hash_diff;
    private String sat_load_datetime;
    private String sat_load_end_datetime;
    private String sat_record_source;
    private String cc_year;
    private String cc_month;
    private String hs_chapter;
    private String hs_heading;
    private String hs_chapter_heading;
    private String hs_subheading;
    private String chapter_description;
    private String heading_description;
    private String subheading_description;
}
