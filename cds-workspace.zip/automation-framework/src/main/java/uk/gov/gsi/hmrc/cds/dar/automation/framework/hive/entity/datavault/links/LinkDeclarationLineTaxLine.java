package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.links;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class LinkDeclarationLineTaxLine implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select link_declaration_line_tax_line_key, hub_tax_line_key, hub_declaration_line_key, entry_reference, item_number, tax_line_sequence_number, link_load_datetime, link_record_source from link_declaration_line_tax_line";

    private String link_declaration_line_tax_line_key;
    private String hub_tax_line_key;
    private String hub_declaration_line_key;
    private String entry_reference;
    private String item_number;
    private String tax_line_sequence_number;
    private String link_load_datetime;
    private String link_record_source;
}
