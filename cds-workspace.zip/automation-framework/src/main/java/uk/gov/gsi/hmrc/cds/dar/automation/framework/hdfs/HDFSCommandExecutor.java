package uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.security.UserGroupInformation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.security.PrivilegedExceptionAction;

/**
 * Created by smalavalli on 20/01/17.
 */
public interface HDFSCommandExecutor {

    Logger logger = LoggerFactory.getLogger(HDFSCommandExecutor.class);

    void hdfsActions(Configuration configuration) throws IOException;

    /**
     * Execute hdfs command as a particular user.
     *
     * @param hadoopUser
     * @param configuration
     */
    default void executeHDFSCommandAsUser(String hadoopUser, Configuration configuration) {
        configuration.set("hadoop.job.ugi", hadoopUser);
       try {
            UserGroupInformation userGroupInformation = UserGroupInformation.createRemoteUser(hadoopUser);
            userGroupInformation.doAs(new PrivilegedExceptionAction<Void>() {
                public Void run() throws Exception {
                    hdfsActions(configuration);
                    return null;
                }
            });
        } catch (Exception e) {
            logger.error("Error executing HDFS commands as user {} ", hadoopUser + e);
        }
    }

}
