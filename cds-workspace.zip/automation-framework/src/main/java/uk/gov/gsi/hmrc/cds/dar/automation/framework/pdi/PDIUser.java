package uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi;

/**
 * Created by smalavalli on 07/02/17.
 */
public enum PDIUser {
    CDSDATA("cdsdata"),
    CDSDATAQA("cdsdataqa");

    private String username;

    PDIUser(String username) {
        this.username = username;
    }

    public String username() {
        return username;
    }
}
