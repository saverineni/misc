package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by smalavalli on 22/03/17.
 */
@Data
public class LandingTrader implements HiveEntity {
    public static final String SELECT_ALL_QUERY = "select source, ingestion_date, turn, fedate, name, simplified_procedure_authorisations, trader_name_abbreviated, currentind from landing_trader";

    private String source;
    private String ingestion_date;
    private String turn;
    private String fedate;
    private String name;
    private String simplified_procedure_authorisations;
    private String trader_name_abbreviated;
    private String currentind;

}
