package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by smalavalli on 28/02/17.
 */
@Data
public class DimCustomsProcedureCode implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select customs_procedure_code, series, page, procedure, procedure_description, previous_procedure, previous_procedure_description, national_coding, type_of_goods, type_of_goods_description, release_mechanism, release_mechanism_description, regime_entered_to,regime_entered_to_description from dim_customs_procedure_code";

    private String customs_procedure_code;
    private String series;
    private String page;
    private String procedure;
    private String procedure_description;
    private String previous_procedure;
    private String previous_procedure_description;
    private String national_coding;
    private String type_of_goods;
    private String type_of_goods_description;
    private String release_mechanism;
    private String release_mechanism_description;
    private String regime_entered_to;
    private String regime_entered_to_description;

}