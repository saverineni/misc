package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.postdatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class DimDan implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select first_deferment_approval_num from dim_dan";

    private String first_deferment_approval_num;
}
