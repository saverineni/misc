package uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion;

import org.codejargon.fluentjdbc.api.FluentJdbc;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion.mss.MSSTablesDataIngester;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi.PDIStage;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.HiveDBManager;
import java.util.List;

import static org.junit.Assert.assertTrue;

/**
 * Created by smalavalli on 11/01/17.
 */
public class LandingTableDataIngester {
    public final static List<String> LANDING_TABLES_TO_INGEST = PDIStage.CREATE_ALL_LANDING.sourceTablesInStage();

    public static Ingest connectToDB(FluentJdbc hive) {
        return new Ingest(hive);
    }

    public static class Ingest implements DataIngester{
        FluentJdbc hive;

        public Ingest(FluentJdbc hive) {
            this.hive = hive;
        }

        @Override
        public void verboseIngestData() {
            HiveDBManager
                    .connect(hive)
                    .dropMSSTables();

            HiveDBManager
                    .connect(hive)
                    .createMSSTables();

            MSSTablesDataIngester
                    .connectToDB(hive)
                    .quickIngestData();

            boolean jobStatus = PDIStage.CREATE_ALL_LANDING.triggerPDIJob();
            assertTrue(jobStatus);
        }
    }
}
