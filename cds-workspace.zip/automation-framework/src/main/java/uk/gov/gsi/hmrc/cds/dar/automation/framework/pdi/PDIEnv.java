package uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi;

import uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.DOCKER_MACHINE;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.DOCKER_ENV;

/**
 * Created by smalavalli on 07/02/17.
 */
public enum PDIEnv {
    DEV(DOCKER_ENV.getInstance()),
    QA(DOCKER_ENV.getInstance()),
    JENKINS(DOCKER_ENV.getInstance());

    private DOCKER_MACHINE dockerInstance;

    PDIEnv(DOCKER_MACHINE dockerInstance) {
        this.dockerInstance = dockerInstance;
    }

    public String pdiHostMachine() {
        return dockerInstance.host();
    }

    public int sshPortPDIHostMachine() {
        return dockerInstance.sshPortPDIServer();
    }
}
