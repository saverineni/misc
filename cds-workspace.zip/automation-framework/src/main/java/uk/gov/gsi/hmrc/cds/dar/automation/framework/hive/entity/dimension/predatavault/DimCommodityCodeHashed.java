package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class DimCommodityCodeHashed implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select cc_year, cc_month, hs_chapter, hs_heading, hs_chapter_heading, hs_subheading, hs_code, chapter_description, heading_description, subheading_description, hub_commodity, sat_commodity from dim_commodity_code_hashed";

    private String cc_year;
    private String cc_month;
    private String hs_chapter;
    private String hs_heading;
    private String hs_chapter_heading;
    private String hs_subheading;
    private String hs_code;
    private String chapter_description;
    private String heading_description;
    private String subheading_description;
    private String hub_commodity;
    private String sat_commodity;
}
