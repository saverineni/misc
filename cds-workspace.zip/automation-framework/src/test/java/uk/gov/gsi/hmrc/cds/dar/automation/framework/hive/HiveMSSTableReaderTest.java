package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive;

import org.codejargon.fluentjdbc.api.FluentJdbc;
import org.junit.Ignore;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.HiveConnector;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports.Nxeiselect;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports.Nxenselect;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.Iina;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.Imeiselect;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.Imendetail;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.Imenselect;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveMSSTableReader;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

/**
 * Created by smalavalli on 21/02/17.
 */
@Ignore
public class HiveMSSTableReaderTest {
    private static final String IMPORT_ENTRY_NUMBER_1A = "IM001A";
    private static final String IMPORT_ENTRY_VERSION_NUMBER_1 = "1";
    private static final String EXPORT_ENTRY_NUMBER_1A = "EX001A";
    private static final String EXPORT_ENTRY_VERSION_NUMBER_2 = "2";

    private final static FluentJdbc hive = HiveConnector.connectTo_MSS_Test_DB();

    @Test
    public void readAllMSSTableRows() throws Exception {
        List<Imenselect> imenselectRows = HiveMSSTableReader.readAllImenselect(hive);
        List<Imendetail> imendetailRows = HiveMSSTableReader.readAllImendetail(hive);
        List<Nxenselect> nxenselectRows = HiveMSSTableReader.readAllNxenselect(hive);
        List<Imeiselect> imeiselectRows = HiveMSSTableReader.readAllImeiselect(hive);
        List<Nxeiselect> nxeiselectRows = HiveMSSTableReader.readAllNxeiselect(hive);
        List<Iina> iinaRows = HiveMSSTableReader.readAllIina(hive);


        assertThat(imenselectRows, is(notNullValue()));
        assertThat(imendetailRows, is(notNullValue()));
        assertThat(nxenselectRows, is(notNullValue()));
        assertThat(imeiselectRows, is(notNullValue()));
        assertThat(nxeiselectRows, is(notNullValue()));
        assertThat(iinaRows, is(notNullValue()));
    }

}