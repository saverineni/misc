package uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion;

import org.junit.Ignore;
import org.junit.Test;

/**
 * Created by smalavalli on 21/02/17.
 */
@Ignore
public class DataExtractorTest {
    @Ignore
    @Test
    public void extractDataUsingHive() throws Exception {
        String tableLines = "landing_mss_lines_declaration";
        String tableHeader = "landing_mss_headers_declaration";

        DataExtractor dataExtractor = new DataExtractor();
        dataExtractor.extractDataFromTableUsingHive(tableLines);
    }

    @Test
    public void extractDataUsingHDFS() throws Exception {
        String tableLines = "landing_mss_lines_declaration";
        String tableHeader = "landing_mss_headers_declaration";

        DataExtractor dataExtractor = new DataExtractor();
        dataExtractor.extractDataFromTableUsingHDFS(tableLines);
    }
}