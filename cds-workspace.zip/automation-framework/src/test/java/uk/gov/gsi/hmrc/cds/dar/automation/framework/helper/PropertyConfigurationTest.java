package uk.gov.gsi.hmrc.cds.dar.automation.framework.helper;

import org.apache.commons.configuration.Configuration;
import org.junit.Ignore;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;

/**
 * Created by smalavalli on 21/02/17.
 */
public class PropertyConfigurationTest {
    @Test
    public void readConfigProperty() throws Exception {
        Configuration config = PropertyConfiguration.config();
        String username = config.getString("test.mss.db.name");
        assertThat(username, is(notNullValue()));
    }
}