package uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion.mss;

import org.codejargon.fluentjdbc.api.FluentJdbc;
import org.junit.Ignore;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.HiveConnector;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.HiveDBManager;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingHashedTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed.LandingHeadersDeclarationHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed.LandingLinesDeclarationHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion.LandingHashedTableDataIngester;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi.PDIStage;

import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;

/**
 * Created by smalavalli on 21/02/17.
 */
@Ignore
public class MSSTablesDataIngesterTest {
    @Ignore
    @Test
    public void verboseIngestAllData() throws Exception {
        FluentJdbc hive = HiveConnector.connectTo_MSS_SM_DB();
        MSSTablesDataIngester
                .connectToDB(hive)
                .verboseIngestData();

        MSSDataIngestHelper
                .fetchHeaderTableList()
                .forEach(table -> {
                    String rowCount = HiveDBManager.connect(hive).rowCount(String.format("select count(*) from %s count", table));
                    assertThat(rowCount, is(equalTo("5")));
                });

        MSSDataIngestHelper
                .fetchImportLineTableList()
                .forEach(table -> {
                    String rowCount = HiveDBManager.connect(hive).rowCount(String.format("select count(*) from %s count", table));
                    switch (table) {
                        case "IINA":
                            assertThat(rowCount, is(equalTo("30")));
                            break;
                        default:
                            assertThat(rowCount, is(equalTo("15")));
                    }
                });

        MSSDataIngestHelper
                .fetchExportLineTableList()
                .forEach(table -> {
                    String rowCount = HiveDBManager.connect(hive).rowCount(String.format("select count(*) from %s count", table));
                    switch (table) {
                        case "NXINA":
                            assertThat(rowCount, is(equalTo("10")));
                            break;
                        default:
                            assertThat(rowCount, is(equalTo("5")));
                    }
                });

    }

    @Test
    public void quickIngestAllData() throws Exception {
        FluentJdbc hive = HiveConnector.connectTo_MSS_Test_DB();
        HiveDBManager
                .connect(hive)
                .dropMSSTables();

        HiveDBManager
                .connect(hive)
                .createMSSTables();

        MSSTablesDataIngester
                .connectToDB(hive)
                .quickIngestData();
    }

    @Test
    public void ingestLandingHashedTablesTest() throws Exception {
        FluentJdbc hive = HiveConnector.connectTo_MSS_Test_DB();
        PDIStage.CREATE_LANDING_HASHED_TABLES.dropTablesInStage(hive);

        LandingHashedTableDataIngester
                .connectToDB(hive)
                .ingestData(LandingHashedTableDataIngester.LANDING_HASH_TABLES_TO_INGEST);

        List<LandingHeadersDeclarationHashed> landingHeadersDeclarationHasheds = HiveLandingHashedTableReader.readAllLandingHeadersDeclarationHashed(hive);
        List<LandingLinesDeclarationHashed> landingLinesDeclarationHasheds = HiveLandingHashedTableReader.readAllLandingLinesDeclarationHashed(hive);
        assertThat(landingHeadersDeclarationHasheds, is(notNullValue()));
        assertThat(landingLinesDeclarationHasheds, is(notNullValue()));
    }

}