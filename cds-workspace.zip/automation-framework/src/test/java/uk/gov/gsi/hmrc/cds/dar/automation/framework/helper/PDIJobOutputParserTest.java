package uk.gov.gsi.hmrc.cds.dar.automation.framework.helper;

import com.google.common.io.CharStreams;
import org.junit.Ignore;
import org.junit.Test;

import java.io.InputStream;
import java.io.InputStreamReader;

import static org.junit.Assert.*;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.PDIJobOutputParser.isJobSuccessful;

/**
 * Created by smalavalli on 21/02/17.
 */
public class PDIJobOutputParserTest {

    @Test
    public void parseJobOutput() throws Exception {
        InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream("sample-kjob-output.txt");
        String jobOutput = CharStreams.toString(new InputStreamReader(inputStream));
        boolean jobSuccessful = isJobSuccessful(jobOutput);

        assertTrue(jobSuccessful);
    }

}