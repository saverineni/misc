package uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion;

import org.junit.Ignore;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.RemoteMachineConnector;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi.PDIStage;

import static org.junit.Assert.*;

/**
 * Created by smalavalli on 21/02/17.
 */
@Ignore
public class JobExecutorTest {
    @Test
    public void extractDataForLandingTables() throws Exception {
        PDIStage.CREATE_ALL_LANDING.cacheSourceTables();

        assertTrue(JobExecutor.ingestionFilesExistsInCache(PDIStage.CREATE_ALL_LANDING.sourceTablesInStage()));
    }

    @Test
    public void extractDataForLandingHashedTables() throws Exception {
        PDIStage.CREATE_LANDING_HASHED_TABLES.cacheSourceTables();

        assertTrue(JobExecutor.ingestionFilesExistsInCache(PDIStage.CREATE_LANDING_HASHED_TABLES.sourceTablesInStage()));
    }

    @Test
    public void extractDataForDataVaultTables() throws Exception {
        PDIStage.CREATE_EXPLOITATION.cacheSourceTables();

        assertTrue(JobExecutor.ingestionFilesExistsInCache(PDIStage.CREATE_EXPLOITATION.sourceTablesInStage()));
    }

    @Ignore
    @Test
    public void invalidateCache() throws Exception {
        JobExecutor.invalidateAllMetadataCache();

        boolean cacheExists = RemoteMachineConnector.connectToFASTP2().fileExists("/data/drop/mss_test_db/IMENSELECT.csv");
        assertFalse(cacheExists);
    }

}