package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive;

import org.codejargon.fluentjdbc.api.FluentJdbc;
import org.junit.Ignore;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.HiveConnector;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed.LandingHeadersDeclaration;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed.LandingLinesDeclaration;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingTableReader;

import java.util.List;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

/**
 * Created by smalavalli on 21/02/17.
 */
@Ignore
public class HiveLandingTableReaderTest {

    private static final String IMPORT_ENTRY_NUMBER_1A = "IM001A";
    private static final String IMPORT_ENTRY_VERSION_NUMBER_1 = "1.0";
    private static final String EXPORT_ENTRY_NUMBER_1A = "EX001A";
    private static final String EXPORT_ENTRY_VERSION_NUMBER_2 = "2.0";

    private final static FluentJdbc hive = HiveConnector.connectTo_MSS_Test_DB();

    @Test
    public void readAllLandingHeaderTableRows() throws Exception {
        List<LandingHeadersDeclaration> landingHeaderDeclarationRows =
                HiveLandingTableReader.readAllLandingHeadersDeclaration(hive);

        assertThat(landingHeaderDeclarationRows, is(notNullValue()));
    }

    @Test
    public void readOneHeaderRow() throws Exception {
        Optional<LandingHeadersDeclaration> headerByEntry =
                HiveLandingTableReader.readAlllandingHeadersDeclarationForEntryNo(hive, IMPORT_ENTRY_NUMBER_1A);

        assertTrue(headerByEntry.isPresent());
        assertThat(headerByEntry.get().getEntry_number(), is(equalTo(IMPORT_ENTRY_NUMBER_1A)));

    }

    @Test
    public void readAllLandingLineTableRows() throws Exception {
        List<LandingLinesDeclaration> landingLinesDeclarations = HiveLandingTableReader.readAllLandingLinesDeclaration(hive);

        assertThat(landingLinesDeclarations, is(notNullValue()));
    }

    @Test
    public void readOneLineRow() throws Exception {
        Optional<LandingLinesDeclaration> lineByEntry =
                HiveLandingTableReader.readAllLandingLinesDeclarationForEntryNo(hive, EXPORT_ENTRY_NUMBER_1A, "1");

        assertTrue(lineByEntry.isPresent());
        assertThat(lineByEntry.get().getEntry_number(), is(equalTo(EXPORT_ENTRY_NUMBER_1A)));

    }

}