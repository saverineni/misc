package uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion.mss;

import org.junit.Ignore;
import org.junit.Test;

import java.util.stream.Stream;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;

/**
 * Created by smalavalli on 21/02/17.
 */
@Ignore
public class MSSDataIngestHelperTest {

    @Test
    public void headerTableList() throws Exception {
        long totalHeaderTableCount = 8l;

        Stream<String> headerTableList = MSSDataIngestHelper.fetchHeaderTableList();

        assertThat(headerTableList, is(notNullValue()));
        assertThat(headerTableList.count(), is(equalTo(totalHeaderTableCount)));
    }

    @Test
    public void ingestTableList() throws Exception {
        long totalTableCount = 20l;

        Stream<String> headerTableList = MSSDataIngestHelper.fetchIngestTableList();

        assertThat(headerTableList, is(notNullValue()));
        assertThat(headerTableList.count(), is(equalTo(totalTableCount)));
    }
}