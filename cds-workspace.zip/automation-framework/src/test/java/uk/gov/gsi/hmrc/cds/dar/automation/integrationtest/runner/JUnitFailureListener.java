package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.runner;

import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;
import org.junit.runner.notification.RunNotifier;

public class JUnitFailureListener extends RunListener {

    private RunNotifier runNotifier;

    public JUnitFailureListener(RunNotifier runNotifier) {
        super();
        this.runNotifier=runNotifier;
    }

    public void testFailure(Failure failure) throws Exception {
        this.runNotifier.pleaseStop();
    }

}
