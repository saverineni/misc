package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive;

import org.codejargon.fluentjdbc.api.FluentJdbc;
import org.codejargon.fluentjdbc.api.FluentJdbcBuilder;
import org.codejargon.fluentjdbc.api.mapper.Mappers;
import org.codejargon.fluentjdbc.api.query.UpdateResult;
import org.junit.Ignore;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.HiveConnector;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.OracleConnector;

import java.util.List;

import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;

/**
 * Created by smalavalli on 21/02/17.
 */
@Ignore
public class HiveQueryTest {
    @Test
    public void query_mss_data() throws Exception {
        FluentJdbc hive = HiveConnector.connectTo_MSS_SM_DB();

        String result = hive
                .query()
                .select("select count(*) as aa from IMENSELECT")
                .singleResult(Mappers.singleString());

        assertThat(result, is(notNullValue()));
    }

    @Test
    public void ddl_mss_data() throws Exception {
        FluentJdbc hive = HiveConnector.connectTo_MSS_SM_DB();

        UpdateResult result = hive
                .query()
                .update("CREATE TABLE IF NOT EXISTS `mss_sm.IMENSELECT`(\n" +
                        "`iekey` string,\n" +
                        "`impentno` string,\n" +
                        "`ietype` string,\n" +
                        "`epuno` string,\n" +
                        "`dtofent` string,\n" +
                        "`acptncdate` string,\n" +
                        "`roe` string,\n" +
                        "`masterucr` string,\n" +
                        "`declnucr` string,\n" +
                        "`decltrep` string\n" +
                        ")"
                )
                .run();

        System.err.println(result.affectedRows());
        assertThat(result.affectedRows(), is(notNullValue()));
    }

    @Test
    public void query_oracle() throws Exception {
        FluentJdbc fluentJdbc = new FluentJdbcBuilder()
                .connectionProvider(OracleConnector.mssDataSource())
                .build();

        String result = fluentJdbc
                .query()
                .select("select count(*) as aa from IMENSELECT")
                .singleResult(Mappers.singleString());

        System.err.println(result);
        assertThat(result, is(notNullValue()));
    }

    @Test
    public void checkCustomRouteValues() throws Exception {
        FluentJdbc hive = HiveConnector.connectTo_QA_DB();

        String query = "select distinct dcr.customs_route_code " +
                "from dim_customs_route dcr " +
                "inner join landing_cdp_headers_declaration idl " +
                "on idl.customs_route_id = dcr.customs_route_id " +
                "and idl.customs_route_id not like '' and idl.customs_route_id not like '%customs%'" ;

        List<String> result = hive
                .query()
                .select(query)
                .listResult(resultSet -> resultSet.getString("dcr.customs_route_code"));

        System.err.println(result);
        assertThat(result, is(notNullValue()));
        assertThat(result.size(), is(greaterThan(0)));
    }
}
