package uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs.builder;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.HDFS;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs.HDFSExplorer;

import java.io.IOException;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs.HDFSExplorer.fileContent;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs.HDFSExplorer.getMd5Hash;

/**
 * Created by smalavalli on 21/02/17.
 */
@Ignore
public class HDFSFileSystemBuilderTest {
    Configuration configuration;
    FileSystem hdfs;

    @Before
    public void setUp() throws Exception {
        configuration = HDFSConfigurationBuilder.builder()
                .withNameNodeHost(HDFS.NAMENODE.host())
                .withNameNodePort(HDFS.NAMENODE.port())
                .build();

        hdfs = HDFSFileSystemBuilder.builder(configuration).getHDFSInstance();
    }

    // POC to build the test framework builders. No assert statements.
    @Test
    public void listFiles() throws Exception {
        String parentPath = "/user/flume/qa/events/declaration/simple/2016-11-09";
        Path path = PathBuilder.builder(configuration).withPath(parentPath).build();

        FileStatus[] fileStatuses = HDFSFileSystemBuilder.builder(configuration)
                .withHDFSPath(path)
                .listFileStatus();
        List<String> listOfFiles = HDFSExplorer.listOfFiles(fileStatuses);

        listOfFiles.forEach(System.err::println);
    }

    @Test
    public void readFileContents() throws Exception {
        String parentPath = "/user/flume/qa/events/declaration/simple/2016-11-09";
        Path path = PathBuilder.builder(configuration).withPath(parentPath).build();

        FileStatus[] fileStatuses = HDFSFileSystemBuilder.builder(configuration)
                .withHDFSPath(path)
                .listFileStatus();
        List<String> listOfFiles = HDFSExplorer.listOfFiles(fileStatuses);

        listOfFiles.parallelStream()
                .map(filename -> {
                    String filePathString = String.format("%s/%s", parentPath, filename);
                    System.err.println(filePathString);
                    return PathBuilder.builder(configuration).withPath(filePathString).build();
                })
                .forEach(filePath -> {
                    try {
                        FileSystem fileSystem = filePath.getFileSystem(configuration);
                        FSDataInputStream inputStream = fileSystem.open(filePath);
                        String fileContent = fileContent(inputStream);
                        System.out.println(getMd5Hash(fileContent));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });
    }

}