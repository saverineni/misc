package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.runner;

import org.junit.runner.notification.RunNotifier;
import org.junit.runners.BlockJUnit4ClassRunner;
import org.junit.runners.model.InitializationError;

public class TestRunner extends BlockJUnit4ClassRunner {
    public TestRunner(Class<?> klass) throws InitializationError {
        super(klass);
    }

    @Override public void run(RunNotifier runNotifier){
        runNotifier.addListener(new JUnitFailureListener(runNotifier));
        super.run(runNotifier);
    }
}
