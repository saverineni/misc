package uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;

import static org.junit.Assert.*;

/**
 * Created by smalavalli on 27/06/17.
 */
@Ignore
public class DDLBuilderTest extends BaseIntegrationTest {

    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
    }

    @Test
    public void name() throws Exception {
        DDLBuilder ddlBuilder = new DDLBuilder();
        ddlBuilder.buildCreateTableScript("caps");

    }
}