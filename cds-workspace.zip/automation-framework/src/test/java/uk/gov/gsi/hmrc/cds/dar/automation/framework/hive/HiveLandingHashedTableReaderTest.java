package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive;

import org.codejargon.fluentjdbc.api.FluentJdbc;
import org.junit.Ignore;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.HiveConnector;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed.LandingHeadersDeclarationHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingHashedTableReader;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

/**
 * Created by smalavalli on 21/02/17.
 */
@Ignore
public class HiveLandingHashedTableReaderTest {
    private static final String IMPORT_ENTRY_NUMBER_1A = "IM001A";
    private final static FluentJdbc hive = HiveConnector.connectTo_MSS_Test_DB();

    @Test
    public void readAllLandingHeaderTableRows() throws Exception {
        Optional<LandingHeadersDeclarationHashed> declarationHeadersHashedOptional = HiveLandingHashedTableReader.landingHeadersDeclarationHashedForEntryNo(hive, IMPORT_ENTRY_NUMBER_1A);
        assertThat(declarationHeadersHashedOptional.get(), is(notNullValue()));
    }

}