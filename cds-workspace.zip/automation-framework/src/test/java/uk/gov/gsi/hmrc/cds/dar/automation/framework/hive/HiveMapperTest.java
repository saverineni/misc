package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive;

import org.codejargon.fluentjdbc.api.query.Mapper;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.Imenselect;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveMapper;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

/**
 * Created by smalavalli on 21/02/17.
 */
public class HiveMapperTest {

    @Test
    public void getInstanceOfMapper() throws Exception {
        Mapper<Imenselect> imenselectMapper = HiveMapper.of(Imenselect.class);

        assertThat(imenselectMapper, is(notNullValue(Mapper.class)));
    }
}