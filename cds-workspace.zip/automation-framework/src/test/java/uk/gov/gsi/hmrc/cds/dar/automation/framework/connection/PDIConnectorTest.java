package uk.gov.gsi.hmrc.cds.dar.automation.framework.connection;

import org.junit.Ignore;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by smalavalli on 21/02/17.
 */
@Ignore
public class PDIConnectorTest {

    @Test
    public void triggerDummyPDIJob() throws Exception {
        String kettleJobName = "AnythingYouWant.kjb";
        boolean jobStatus = PDIConnector
                .triggerPDIJob(kettleJobName)
                .withKettleFileLocationPath("/data/apps/cdsdata/customs-pipeline/dev/kettle/")
                .withJobParams("MSS_DB", "MSS_TEST")
                .withJobParams("Key", "Value")
                .trigger();

        assertTrue(jobStatus);
    }




}