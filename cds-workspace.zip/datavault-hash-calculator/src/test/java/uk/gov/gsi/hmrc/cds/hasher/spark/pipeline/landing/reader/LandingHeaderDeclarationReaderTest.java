package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.hasher.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingHeaderDeclaration;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.toArray;

public class LandingHeaderDeclarationReaderTest extends SparkTest {
    @Autowired
    LandingHeaderDeclarationReader landingHeaderDeclarationReader;

    @Test
    public void buildsLandingHeaderDeclarationDataframe() throws Exception {
        Dataset<LandingHeaderDeclaration> landingHeaderDeclarationDataset = landingHeaderDeclarationReader.landingHeaderDeclarationDataset();
        assertThat(landingHeaderDeclarationDataset.count(), is(greaterThan(0l)));

        landingHeaderDeclarationDataset.printSchema();
        String[] fieldNames = landingHeaderDeclarationDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(landingHeaderDeclarationStructFields));
    }

    private static String[] landingHeaderDeclarationStructFields = toArray(
            Lists.newArrayList(
                    "acceptance_date",
                    "consignee_aeo_certificate_type_code",
                    "consignee_nad_name",
                    "consignee_nad_postcode",
                    "consignor_aeo_certificate_type_code",
                    "consignor_nad_name",
                    "consignor_turn",
                    "consignor_turn_country_code",
                    "customs_check_code",
                    "customs_value",
                    "declarant_aeo_certificate_type_code",
                    "declarant_nad_name",
                    "declarant_representative_turn",
                    "declarant_turn",
                    "declaration_import_export_indicator",
                    "declaration_method",
                    "declaration_ucr",
                    "destination_country_code",
                    "dispatch_country",
                    "entry_date",
                    "entry_number",
                    "entry_reference",
                    "entry_type",
                    "epu_number",
                    "exporter_turn",
                    "first_deferment_approval_num",
                    "first_deferment_approval_num_prefix",
                    "freight_currency",
                    "generation_number",
                    "goods_departure_datetime",
                    "goods_location",
                    "header_statistical_value",
                    "import_clearance_status",
                    "importer_turn",
                    "importer_turn_country_code",
                    "ingestion_date",
                    "invoice_currency",
                    "invoice_total_declared",
                    "item_count",
                    "master_ucr",
                    "net_mass_total",
                    "paying_agent_turn",
                    "place_of_loading_code",
                    "place_of_unloading_code",
                    "profile_id",
                    "route",
                    "session_num",
                    "session_role_name",
                    "source",
                    "status_of_entry",
                    "total_duty",
                    "total_excise",
                    "total_vat",
                    "transport_country",
                    "transport_id",
                    "transport_mode_code"            )
    );

}