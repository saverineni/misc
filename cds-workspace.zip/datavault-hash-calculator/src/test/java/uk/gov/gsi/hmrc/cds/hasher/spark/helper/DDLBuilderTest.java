package uk.gov.gsi.hmrc.cds.hasher.spark.helper;

import org.junit.Assert;
import org.junit.Test;

public class DDLBuilderTest {


    public static final String EXPECTED_SCRIPT = "CREATE EXTERNAL TABLE IF NOT EXISTS test_db.test_table (`field_1` string,`field_2` string,`field_3` string)\n" +
            "        ROW FORMAT DELIMITED\n" +
            "        FIELDS TERMINATED BY '\\u0001'\n" +
            "        STORED AS TEXTFILE\n" +
            "        LOCATION '/user/hive/test/test_db/test_table/'";
    public static final String TEST_DB = "test_db";
    public static final String TABLE_NAME = "test_table";


    @Test
    public void buildExternalTableScript() {
        DDLBuilder builder = new DDLBuilder();
        String[] fieldNames = {"field_1", "field_2", "field_3"};
        String buildExternalTableScript = builder.buildExternalTableScript(TEST_DB, TABLE_NAME, fieldNames, "/user/hive/test/test_db/test_table/");
        Assert.assertEquals(EXPECTED_SCRIPT, buildExternalTableScript);
    }

    @Test
    public void buildTableDropScript() {
        DDLBuilder builder = new DDLBuilder();
        String buildTableDropScript = builder.dropTableScript(TEST_DB, TABLE_NAME);
        Assert.assertEquals(String.format("DROP TABLE IF EXISTS %s.%s", TEST_DB, TABLE_NAME), buildTableDropScript);
    }

}