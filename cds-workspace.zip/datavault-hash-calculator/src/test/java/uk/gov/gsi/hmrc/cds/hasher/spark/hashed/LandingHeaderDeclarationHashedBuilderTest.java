package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.hasher.spark.SparkMockTest;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingHeaderDeclarationHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.readers.LandingHeaderDeclarationHashedReader;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.toArray;

public class LandingHeaderDeclarationHashedBuilderTest extends SparkMockTest implements Serializable {

    @Autowired
    LandingHeaderDeclarationHashedBuilder landingHeaderDeclarationHashedBuilder;

    @Autowired
    LandingHeaderDeclarationHashedReader landingHeaderDeclarationHashedReader;

    @Test
    public void buildLandingHeaderDeclarationHashedDataset() throws Exception {
        Dataset<LandingHeaderDeclarationHashed> dataset = landingHeaderDeclarationHashedBuilder.build();
        assertThat(dataset.count(), is(greaterThan(0l)));

        String[] fieldNames = dataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(landingHeaderDeclarationHashedStructFields));

        Dataset<LandingHeaderDeclarationHashed> pdiHashedDataset = landingHeaderDeclarationHashedReader.landingHeaderDeclarationHashedDataset();

        List<LandingHeaderDeclarationHashed> actualHashed = dataset.toJavaRDD().collect();
        List<LandingHeaderDeclarationHashed> exceptedHashed = pdiHashedDataset.toJavaRDD().collect();

        // TODO - prehaps we don't need to assert this horrible way. This is for the initial verification of all rows and columns.
        // TODO - To be cleaned up to assert one row.
        actualHashed.forEach(landingHeaderDeclarationHashed -> {

            LandingHeaderDeclarationHashed expectedLandingHeaderHashed = exceptedHashed
                    .stream()
                    .filter(v1 -> v1.getEntry_reference().equals(landingHeaderDeclarationHashed.getEntry_reference()))
                    .findFirst()
                    .get();

            assertThat(landingHeaderDeclarationHashed.getSource(), is(equalTo(expectedLandingHeaderHashed.getSource())));
            assertThat(landingHeaderDeclarationHashed.getIngestion_date(), is(equalTo(expectedLandingHeaderHashed.getIngestion_date())));
            assertThat(landingHeaderDeclarationHashed.getEntry_number(), is(equalTo(expectedLandingHeaderHashed.getEntry_number())));
            assertThat(landingHeaderDeclarationHashed.getEntry_date(), is(equalTo(expectedLandingHeaderHashed.getEntry_date())));
            assertThat(landingHeaderDeclarationHashed.getEpu_number(), is(equalTo(expectedLandingHeaderHashed.getEpu_number())));
            assertThat(landingHeaderDeclarationHashed.getEntry_type(), is(equalTo(expectedLandingHeaderHashed.getEntry_type())));
            assertThat(landingHeaderDeclarationHashed.getDeclaration_method(), is(equalTo(expectedLandingHeaderHashed.getDeclaration_method())));
            assertThat(landingHeaderDeclarationHashed.getTotal_excise(), is(equalTo(expectedLandingHeaderHashed.getTotal_excise())));
            assertThat(landingHeaderDeclarationHashed.getImporter_turn(), is(equalTo(expectedLandingHeaderHashed.getImporter_turn())));
            assertThat(landingHeaderDeclarationHashed.getDeclarant_turn(), is(equalTo(expectedLandingHeaderHashed.getDeclarant_turn())));
            assertThat(landingHeaderDeclarationHashed.getDeclarant_representative_turn(), is(equalTo(expectedLandingHeaderHashed.getDeclarant_representative_turn())));
            assertThat(landingHeaderDeclarationHashed.getConsignee_aeo_certificate_type_code(), is(equalTo(expectedLandingHeaderHashed.getConsignee_aeo_certificate_type_code())));
            assertThat(landingHeaderDeclarationHashed.getDeclarant_aeo_certificate_type_code(), is(equalTo(expectedLandingHeaderHashed.getDeclarant_aeo_certificate_type_code())));
            assertThat(landingHeaderDeclarationHashed.getRoute(), is(equalTo(expectedLandingHeaderHashed.getRoute())));
            assertThat(landingHeaderDeclarationHashed.getDeclaration_import_export_indicator(), is(equalTo(expectedLandingHeaderHashed.getDeclaration_import_export_indicator())));
            assertThat(landingHeaderDeclarationHashed.getGeneration_number(), is(equalTo(expectedLandingHeaderHashed.getGeneration_number())));
            assertThat(landingHeaderDeclarationHashed.getExporter_turn(), is(equalTo(expectedLandingHeaderHashed.getExporter_turn())));
            assertThat(landingHeaderDeclarationHashed.getDestination_country_code(), is(equalTo(expectedLandingHeaderHashed.getDestination_country_code())));
            assertThat(landingHeaderDeclarationHashed.getImport_clearance_status(), is(equalTo(expectedLandingHeaderHashed.getImport_clearance_status())));
            assertThat(landingHeaderDeclarationHashed.getConsignor_aeo_certificate_type_code(), is(equalTo(expectedLandingHeaderHashed.getConsignor_aeo_certificate_type_code())));
            assertThat(landingHeaderDeclarationHashed.getHeader_statistical_value(), is(equalTo(expectedLandingHeaderHashed.getHeader_statistical_value())));
            assertThat(landingHeaderDeclarationHashed.getGoods_departure_datetime(), is(equalTo(expectedLandingHeaderHashed.getGoods_departure_datetime())));
            assertThat(landingHeaderDeclarationHashed.getCustoms_value(), is(equalTo(expectedLandingHeaderHashed.getCustoms_value())));
            assertThat(landingHeaderDeclarationHashed.getTotal_duty(), is(equalTo(expectedLandingHeaderHashed.getTotal_duty())));
            assertThat(landingHeaderDeclarationHashed.getTotal_vat(), is(equalTo(expectedLandingHeaderHashed.getTotal_vat())));
            assertThat(landingHeaderDeclarationHashed.getNet_mass_total(), is(equalTo(expectedLandingHeaderHashed.getNet_mass_total())));
            assertThat(landingHeaderDeclarationHashed.getGoods_location(), is(equalTo(expectedLandingHeaderHashed.getGoods_location())));
            assertThat(landingHeaderDeclarationHashed.getAcceptance_date(), is(equalTo(expectedLandingHeaderHashed.getAcceptance_date())));
            assertThat(landingHeaderDeclarationHashed.getImporter_turn_country_code(), is(equalTo(expectedLandingHeaderHashed.getImporter_turn_country_code())));
            assertThat(landingHeaderDeclarationHashed.getPlace_of_unloading_code(), is(equalTo(expectedLandingHeaderHashed.getPlace_of_unloading_code())));
            assertThat(landingHeaderDeclarationHashed.getFirst_deferment_approval_num(), is(equalTo(expectedLandingHeaderHashed.getFirst_deferment_approval_num())));
            assertThat(landingHeaderDeclarationHashed.getFirst_deferment_approval_num_prefix(), is(equalTo(expectedLandingHeaderHashed.getFirst_deferment_approval_num_prefix())));
            assertThat(landingHeaderDeclarationHashed.getDeclaration_ucr(), is(equalTo(expectedLandingHeaderHashed.getDeclaration_ucr())));
            assertThat(landingHeaderDeclarationHashed.getItem_count(), is(equalTo(expectedLandingHeaderHashed.getItem_count())));
            assertThat(landingHeaderDeclarationHashed.getMaster_ucr(), is(equalTo(expectedLandingHeaderHashed.getMaster_ucr())));
            assertThat(landingHeaderDeclarationHashed.getPaying_agent_turn(), is(equalTo(expectedLandingHeaderHashed.getPaying_agent_turn())));
            assertThat(landingHeaderDeclarationHashed.getPlace_of_loading_code(), is(equalTo(expectedLandingHeaderHashed.getPlace_of_loading_code())));
            assertThat(landingHeaderDeclarationHashed.getSession_num(), is(equalTo(expectedLandingHeaderHashed.getSession_num())));
            assertThat(landingHeaderDeclarationHashed.getSession_role_name(), is(equalTo(expectedLandingHeaderHashed.getSession_role_name())));
            assertThat(landingHeaderDeclarationHashed.getStatus_of_entry(), is(equalTo(expectedLandingHeaderHashed.getStatus_of_entry())));
            assertThat(landingHeaderDeclarationHashed.getTransport_country(), is(equalTo(expectedLandingHeaderHashed.getTransport_country())));
            assertThat(landingHeaderDeclarationHashed.getTransport_id(), is(equalTo(expectedLandingHeaderHashed.getTransport_id())));
            assertThat(landingHeaderDeclarationHashed.getTransport_mode_code(), is(equalTo(expectedLandingHeaderHashed.getTransport_mode_code())));
            assertThat(landingHeaderDeclarationHashed.getDispatch_country(), is(equalTo(expectedLandingHeaderHashed.getDispatch_country())));
            assertThat(landingHeaderDeclarationHashed.getConsignor_turn(), is(equalTo(expectedLandingHeaderHashed.getConsignor_turn())));
            assertThat(landingHeaderDeclarationHashed.getConsignor_turn_country_code(), is(equalTo(expectedLandingHeaderHashed.getConsignor_turn_country_code())));
            assertThat(landingHeaderDeclarationHashed.getConsignor_nad_name(), is(equalTo(expectedLandingHeaderHashed.getConsignor_nad_name())));
            assertThat(landingHeaderDeclarationHashed.getConsignee_nad_name(), is(equalTo(expectedLandingHeaderHashed.getConsignee_nad_name())));
            assertThat(landingHeaderDeclarationHashed.getConsignee_nad_postcode(), is(equalTo(expectedLandingHeaderHashed.getConsignee_nad_postcode())));
            assertThat(landingHeaderDeclarationHashed.getDeclarant_nad_name(), is(equalTo(expectedLandingHeaderHashed.getDeclarant_nad_name())));
            assertThat(landingHeaderDeclarationHashed.getCustoms_check_code(), is(equalTo(expectedLandingHeaderHashed.getCustoms_check_code())));
            assertThat(landingHeaderDeclarationHashed.getProfile_id(), is(equalTo(expectedLandingHeaderHashed.getProfile_id())));
            assertThat(landingHeaderDeclarationHashed.getFreight_currency(), is(equalTo(expectedLandingHeaderHashed.getFreight_currency())));
            assertThat(landingHeaderDeclarationHashed.getInvoice_currency(), is(equalTo(expectedLandingHeaderHashed.getInvoice_currency())));
            assertThat(landingHeaderDeclarationHashed.getInvoice_total_declared(), is(equalTo(expectedLandingHeaderHashed.getInvoice_total_declared())));
            assertThat(landingHeaderDeclarationHashed.getEntry_reference(), is(equalTo(expectedLandingHeaderHashed.getEntry_reference())));
            assertThat(landingHeaderDeclarationHashed.getHub_declaration(), is(equalTo(expectedLandingHeaderHashed.getHub_declaration())));
            assertThat(landingHeaderDeclarationHashed.getSat_declaration(), is(equalTo(expectedLandingHeaderHashed.getSat_declaration())));
            assertThat(landingHeaderDeclarationHashed.getLink_declaration_consignor_trader(), is(equalTo(expectedLandingHeaderHashed.getLink_declaration_consignor_trader())));
            assertThat(landingHeaderDeclarationHashed.getLink_declaration_consignor_trader_hub_trader(), is(equalTo(expectedLandingHeaderHashed.getLink_declaration_consignor_trader_hub_trader())));
            assertThat(landingHeaderDeclarationHashed.getLink_declaration_declarant_trader(), is(equalTo(expectedLandingHeaderHashed.getLink_declaration_declarant_trader())));
            assertThat(landingHeaderDeclarationHashed.getLink_declaration_declarant_trader_hub_trader(), is(equalTo(expectedLandingHeaderHashed.getLink_declaration_declarant_trader_hub_trader())));
            assertThat(landingHeaderDeclarationHashed.getLink_declaration_destination_country(), is(equalTo(expectedLandingHeaderHashed.getLink_declaration_destination_country())));
            assertThat(landingHeaderDeclarationHashed.getLink_declaration_destination_country_hub_country(), is(equalTo(expectedLandingHeaderHashed.getLink_declaration_destination_country_hub_country())));
            assertThat(landingHeaderDeclarationHashed.getLink_declaration_exporter_trader(), is(equalTo(expectedLandingHeaderHashed.getLink_declaration_exporter_trader())));
            assertThat(landingHeaderDeclarationHashed.getLink_declaration_exporter_trader_hub_trader(), is(equalTo(expectedLandingHeaderHashed.getLink_declaration_exporter_trader_hub_trader())));
            assertThat(landingHeaderDeclarationHashed.getLink_declaration_freight_currency(), is(equalTo(expectedLandingHeaderHashed.getLink_declaration_freight_currency())));
            assertThat(landingHeaderDeclarationHashed.getLink_declaration_freight_currency_hub_currency(), is(equalTo(expectedLandingHeaderHashed.getLink_declaration_freight_currency_hub_currency())));
            assertThat(landingHeaderDeclarationHashed.getLink_declaration_importer_trader(), is(equalTo(expectedLandingHeaderHashed.getLink_declaration_importer_trader())));
            assertThat(landingHeaderDeclarationHashed.getLink_declaration_importer_trader_hub_trader(), is(equalTo(expectedLandingHeaderHashed.getLink_declaration_importer_trader_hub_trader())));
            assertThat(landingHeaderDeclarationHashed.getLink_declaration_invoice_currency(), is(equalTo(expectedLandingHeaderHashed.getLink_declaration_invoice_currency())));
            assertThat(landingHeaderDeclarationHashed.getLink_declaration_invoice_currency_hub_currency(), is(equalTo(expectedLandingHeaderHashed.getLink_declaration_invoice_currency_hub_currency())));
            assertThat(landingHeaderDeclarationHashed.getLink_declaration_paying_agent_trader(), is(equalTo(expectedLandingHeaderHashed.getLink_declaration_paying_agent_trader())));
            assertThat(landingHeaderDeclarationHashed.getLink_declaration_paying_agent_trader_hub_trader(), is(equalTo(expectedLandingHeaderHashed.getLink_declaration_paying_agent_trader_hub_trader())));
            assertThat(landingHeaderDeclarationHashed.getLink_declaration_transport_country(), is(equalTo(expectedLandingHeaderHashed.getLink_declaration_transport_country())));
            assertThat(landingHeaderDeclarationHashed.getLink_declaration_transport_country_hub_country(), is(equalTo(expectedLandingHeaderHashed.getLink_declaration_transport_country_hub_country())));
        });


//        dataset.createOrReplaceTempView("landingHeaderDeclarationHashed");
//
//        dataset.sqlContext().sql("select * from landingHeaderDeclarationHashed where entry_reference='060-EX001A-2016-12-01'").show();
//
//        dataset.sqlContext().sql("select entry_number, entry_reference, link_declaration_freight_currency, link_declaration_freight_currency_hub_currency, link_declaration_invoice_currency, link_declaration_invoice_currency_hub_currency, hub_declaration, sat_declaration from landingHeaderDeclarationHashed where entry_reference='060-EX001A-2016-12-01'").show(false);

    }

    private static String[] landingHeaderDeclarationHashedStructFields = toArray(
            Lists.newArrayList(
                    "acceptance_date",
                    "consignee_aeo_certificate_type_code",
                    "consignee_nad_name",
                    "consignee_nad_postcode",
                    "consignor_aeo_certificate_type_code",
                    "consignor_nad_name",
                    "consignor_turn",
                    "consignor_turn_country_code",
                    "customs_check_code",
                    "customs_value",
                    "declarant_aeo_certificate_type_code",
                    "declarant_nad_name",
                    "declarant_representative_turn",
                    "declarant_turn",
                    "declaration_import_export_indicator",
                    "declaration_method",
                    "declaration_ucr",
                    "destination_country_code",
                    "dispatch_country",
                    "entry_date",
                    "entry_number",
                    "entry_reference",
                    "entry_type",
                    "epu_number",
                    "exporter_turn",
                    "first_deferment_approval_num",
                    "first_deferment_approval_num_prefix",
                    "freight_currency",
                    "generation_number",
                    "goods_departure_datetime",
                    "goods_location",
                    "header_statistical_value",
                    "hub_declaration",
                    "import_clearance_status",
                    "importer_turn",
                    "importer_turn_country_code",
                    "ingestion_date",
                    "invoice_currency",
                    "invoice_total_declared",
                    "item_count",
                    "link_declaration_consignor_trader",
                    "link_declaration_consignor_trader_hub_trader",
                    "link_declaration_declarant_trader",
                    "link_declaration_declarant_trader_hub_trader",
                    "link_declaration_destination_country",
                    "link_declaration_destination_country_hub_country",
                    "link_declaration_exporter_trader",
                    "link_declaration_exporter_trader_hub_trader",
                    "link_declaration_freight_currency",
                    "link_declaration_freight_currency_hub_currency",
                    "link_declaration_importer_trader",
                    "link_declaration_importer_trader_hub_trader",
                    "link_declaration_invoice_currency",
                    "link_declaration_invoice_currency_hub_currency",
                    "link_declaration_paying_agent_trader",
                    "link_declaration_paying_agent_trader_hub_trader",
                    "link_declaration_transport_country",
                    "link_declaration_transport_country_hub_country",
                    "master_ucr",
                    "net_mass_total",
                    "paying_agent_turn",
                    "place_of_loading_code",
                    "place_of_unloading_code",
                    "profile_id",
                    "route",
                    "sat_declaration",
                    "session_num",
                    "session_role_name",
                    "source",
                    "status_of_entry",
                    "total_duty",
                    "total_excise",
                    "total_vat",
                    "transport_country",
                    "transport_id",
                    "transport_mode_code"
            )
    );

}