package uk.gov.gsi.hmrc.cds.hasher.spark.hdfs.builder;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Objects;

/**
 * Created by smalavalli on 01/11/16.
 */
public class HDFSFileSystemBuilder {

    public static Builder builder(Configuration configuration) {
        return new Builder(configuration);
    }

    /**
     * Configuration built using @class HDFSConfigurationBuilder
     */
    public static class Builder {
        Configuration configuration;
        FileSystem fileSystem;
        Path path;

        public Builder(Configuration configuration) {
            this.configuration = configuration;
            fileSystem = getHDFSInstance();
        }

        public Builder withHDFSPath(Path hdfsPath) {
            Objects.requireNonNull(hdfsPath, "Path cannot be null");
            Objects.requireNonNull(fileSystem, "Initialse HDFSInstance... call getHDFSInstance()");
            path = hdfsPath;
            return this;
        }

        public FileStatus getFileStatus() throws IOException {
            Objects.requireNonNull(path, "Path cannot be null");
            return fileSystem.getFileStatus(path);
        }

        public FileStatus[] listFileStatus() throws IOException {
            Objects.requireNonNull(path, "Path cannot be null");
            return fileSystem.listStatus(path);
        }


        public InputStream openFile() throws IOException {
            Objects.requireNonNull(path, "Path cannot be null");
            return fileSystem.open(path);
        }

        public FileSystem getHDFSInstance() {
            String fileSystemUrlString = configuration.get(HDFSConfigurationBuilder.DEFAULT_URL_STRING);
            try {
                fileSystem = FileSystem.get(new URI(fileSystemUrlString), configuration);
            } catch (IOException | URISyntaxException e) {
                e.printStackTrace();
            }
            return fileSystem;
        }
    }
}
