package uk.gov.gsi.hmrc.cds.hasher.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({
        SparkConfig.class,
        ReaderConfig.class
})
public class TestRealConfig {
}
