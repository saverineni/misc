package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.hasher.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCountryHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.reader.DimCountryReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.toArray;

public class DimCountryHashedBuilderTest extends SparkTest {

    @Autowired
    DimCountryHashedBuilder dimCountryHashedBuilder;
    @Autowired
    DimCountryReader dimCountryReader;

    public static String[] dimCountryHashedStructFields = toArray(
            Lists.newArrayList(
                    "country_comments",
                    "country_id",
                    "country_iso_code",
                    "country_name",
                    "country_sequence_number",
                    "hub_country",
                    "sat_country"
            )
    );

    @Test
    public void buildsDimCountryHashedDataset() throws Exception {
        Dataset<DimCountryHashed> dimCountryHashedDataset = dimCountryHashedBuilder.build();
        assertThat(dimCountryHashedDataset.count(), is(greaterThan(0l)));

        dimCountryHashedDataset.show(false);
        String[] fieldNames = dimCountryHashedDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(dimCountryHashedStructFields));

//        TODO - assert hashes
//        DimCountryHashed head = dimCountryHashedDataset.first();
//        DimCountry dimCountry = dimCountryReader.dimCountryDataset().first();
//        assertThat(head.getHub_country(), is(equalTo(DimCountryHashed.hubCountryHashed(dimCountry))));
//        assertThat(head.getSat_country(), is(equalTo(DimCountryHashed.satCountryHashDifference(dimCountry))));

    }
}