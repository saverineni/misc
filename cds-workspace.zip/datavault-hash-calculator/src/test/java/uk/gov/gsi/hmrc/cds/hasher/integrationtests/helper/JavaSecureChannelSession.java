package uk.gov.gsi.hmrc.cds.hasher.integrationtests.helper;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

import static uk.gov.gsi.hmrc.cds.hasher.integrationtests.helper.PropertyConfiguration.config;

/**
 * Created by smalavalli on 02/12/16.
 */
public class JavaSecureChannelSession {
    private static Logger logger = LoggerFactory.getLogger(JavaSecureChannelSession.class);

    public static SSHSession newInstance(String hostMachine, String userName) throws JSchException {
        return new SSHSession(hostMachine, userName);
    }

    public static SSHSession newInstance(String hostMachine, String userName, int sshPort) throws JSchException {
        return new SSHSession(hostMachine, userName, sshPort);
    }

    public static class SSHSession {
        private Session session;
        private JSch jSch = new JSch();

        public SSHSession(String hostMachine, String userName) throws JSchException {
            session = jSch.getSession(userName, hostMachine);
        }

        public SSHSession(String hostMachine, String userName, int sshPort) throws JSchException {
            session = jSch.getSession(userName, hostMachine, sshPort);
        }

        public SSHSession withSSHKeyAndPassPhrase(String privateKey, String passPhrase) throws JSchException {
            jSch.addIdentity(privateKey, passPhrase);
            return this;
        }

        public SSHSession withSSHKey(String privateKey) throws JSchException {
            jSch.addIdentity(privateKey);
            return this;
        }

        public SSHSession withUserNamePassword(String password) throws JSchException {
            session.setPassword(password);
            return this;
        }

        public Session connect() throws JSchException {
            Properties config = new Properties();
            config.put("StrictHostKeyChecking", "no");

            session.setConfig(config);
            session.setTimeout(config().getInt("ssh.connection.timeout"));
            session.connect();
            return session;
        }
    }
}
