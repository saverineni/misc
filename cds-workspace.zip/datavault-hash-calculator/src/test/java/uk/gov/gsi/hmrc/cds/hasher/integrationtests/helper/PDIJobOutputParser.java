package uk.gov.gsi.hmrc.cds.hasher.integrationtests.helper;

import com.google.common.collect.Maps;

import java.io.BufferedReader;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by smalavalli on 30/11/16.
 */
public final class PDIJobOutputParser {

    private static final String KETTLE_JOB_SUCCESS_MESSAGE = "Kitchen - Finished!";
    private static final String KETTLE_ERROR = "Kitchen - ERROR";
    private static final String EXIT_STATUS_COMMAND = "echo $?";

    public static boolean isJobSuccessful(String jobOutput) {
        boolean hasSuccessMessage = getBufferedReader(jobOutput).lines()
                .filter(s -> s.contains(KETTLE_JOB_SUCCESS_MESSAGE))
                .findFirst().isPresent();

        boolean hasErrorMessage = getBufferedReader(jobOutput).lines()
                .filter(s -> s.contains(KETTLE_ERROR))
                .findFirst().isPresent();

        String exitCodeStatus = getExitCode(jobOutput);
        return hasSuccessMessage && !hasErrorMessage && exitCodeStatus.equals("0");
    }

    private static String getExitCode(String jobOutput) {
        HashMap<Integer, String> lineNumberJobOutputMap = buildLineNumberJobOutputMap(jobOutput);
        Optional<Integer> exitCodeLineNumber = lineNumberJobOutputMap.entrySet().stream()
                .filter(integerStringEntry -> integerStringEntry.getValue().contains(EXIT_STATUS_COMMAND))
                .map(Map.Entry::getKey)
                .findFirst();

        return exitCodeLineNumber
                    .map(exitCodeCommandLineNumber -> lineNumberJobOutputMap.get(exitCodeCommandLineNumber + 1))
                    .orElse("exit code could not be determined");
    }

    public static HashMap<Integer, String> buildLineNumberJobOutputMap(String jobOutput) {
        HashMap<Integer, String> lineNumberJobOutputMap = Maps.newHashMap();
        AtomicInteger linenumber = new AtomicInteger(0);
        getBufferedReader(jobOutput).lines()
                .peek(line -> lineNumberJobOutputMap.put(linenumber.getAndAdd(1), line))
                .count();
        return lineNumberJobOutputMap;
    }

    private static BufferedReader getBufferedReader(String consoleOutput) {
        return new BufferedReader(new StringReader(consoleOutput));
    }
}
