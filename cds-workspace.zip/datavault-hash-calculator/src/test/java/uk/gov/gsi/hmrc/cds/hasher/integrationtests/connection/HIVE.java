package uk.gov.gsi.hmrc.cds.hasher.integrationtests.connection;


import static uk.gov.gsi.hmrc.cds.hasher.integrationtests.helper.PropertyConfiguration.config;

/**
 * Created by smalavalli on 28/11/16.
 */
public enum HIVE {
    HIVE_SERVER_2(
            DOCKER_ENV.getInstance().host(),
            config().getString("hive.server2.port"),
            config().getString("hive.server2.username"),
            config().getString("hive.server2.password")
    );

    private String host;
    private String port;
    private String username;
    private String password;

    HIVE(String host, String port, String username, String password) {
        this.host = host;
        this.port = port;
        this.username = username;
        this.password = password;
    }

    public String host() {
        return host;
    }

    public String port() {
        return port;
    }

    public String username() {
        return username;
    }

    public String password() {
        return password;
    }
}
