package uk.gov.gsi.hmrc.cds.hasher.integrationtests.helper;

import com.jcraft.jsch.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.hasher.integrationtests.helper.PropertyConfiguration.config;

/**
 * Created by smalavalli on 29/12/16.
 */
public class SFTPHelper {
    private static Logger logger = LoggerFactory.getLogger(SFTPHelper.class);

    public void remoteFileTransferUsingSSHKeyWithPassPhrase(String host, String userName, int sshPort, List<File> files, String destinationPath) {
        Session session = null;
        ChannelSftp sftpChannel = null;

        logger.info("SFTP csv files to remote machine {}", host);
        try {
            session = getSession(host, userName, sshPort);
            sftpChannel = getSftpChannel(session);
            ftpFiles(destinationPath, files, sftpChannel);
        } catch (JSchException e) {
            logger.error("Error connecting to remote machine {} as {}" + host, userName, e);
        } finally {
            if (sftpChannel != null && session != null) {
                sftpChannel.disconnect();
                session.disconnect();
            }
        }
    }


    public void getRemoteFile(String host, String userName, String fileName, String destinationPath, String sourcePath) {
        Session session = null;
        ChannelSftp sftpChannel = null;
        List<String> fileNames = new ArrayList<>();
        fileNames.add(fileName);

        logger.info("SFTP GET csv files to remote machine {}", host);
        try {
            session = getSession(host, userName, 2028);
            sftpChannel = getSftpChannel(session);
            ftpGetFiles(destinationPath, fileNames, sftpChannel, sourcePath);
        } catch (JSchException e) {
            logger.error("Error connecting to remote machine {} as {}" + host, userName, e);
        } finally {
            if (sftpChannel != null && session != null) {
                sftpChannel.disconnect();
                session.disconnect();
            }
        }
    }

    public boolean fileExists(String host, String userName, int sshPort, String filePath) {
        Session session = null;
        ChannelSftp sftpChannel = null;
        boolean fileExists = false;
        logger.info("Checking if file {} exists", filePath);
        try {
            session = getSession(host, userName, sshPort);
            sftpChannel = getSftpChannel(session);
            try {
                sftpChannel.lstat(filePath);
                fileExists = true;
            } catch (SftpException e) {
                logger.info("File {} does not exists", filePath);
            }
        } catch (JSchException e) {
            logger.error("Error connecting to remote machine {} on port {} as {}" + host, sshPort, userName, e);
        } finally {
            if (sftpChannel != null && session != null) {
                sftpChannel.disconnect();
                session.disconnect();
            }
        }
        return fileExists;
    }

    private Session getSession(String host, String userName, int sshPort) throws JSchException {
        String privateKey = config().getString("ssh.private.key");
        String passPhrase = config().getString("ssh.pass.phrase");

        return JavaSecureChannelSession
                .newInstance(host, userName, sshPort)
                .withSSHKeyAndPassPhrase(privateKey, passPhrase)
                .connect();
    }

    private void ftpFiles(String destinationPath, List<File> files, ChannelSftp channelSftp) {
        files.forEach(file -> {
            try {
                channelSftp.put(
                        new FileInputStream(file),
                        String.format(destinationPath + "/%s", file.getName()), // <destinationPath>/filename
                        Math.toIntExact(file.length()));
            } catch (FileNotFoundException | SftpException e) {
                logger.error("Error transferring file {}", file, e);
            }
        });
        logger.info("SFTP of data files complete");
    }

    private void ftpGetFiles(String destinationPath, List<String> fileNames, ChannelSftp channelSftp, String sourcePath) {
        fileNames.forEach(file -> {
            try {
                channelSftp.cd(sourcePath);
                channelSftp.get(file, String.format(destinationPath + "/%s", file));
            } catch (SftpException e) {
                logger.error("Error transferring file {}", file, e);
            }
        });
        logger.info("SFTP GET of data files complete");
    }

    private ChannelSftp getSftpChannel(Session session) throws JSchException {
        ChannelSftp channelSftp = null;
        if (session.isConnected()) {
            channelSftp = (ChannelSftp) session.openChannel("sftp");
            channelSftp.connect();
        }
        return channelSftp;
    }
}
