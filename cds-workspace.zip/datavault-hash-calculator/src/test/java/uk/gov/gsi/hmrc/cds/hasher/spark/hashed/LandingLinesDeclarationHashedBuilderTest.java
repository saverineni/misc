package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.hasher.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLinesDeclarationHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader.LandingLinesDeclarationHashedReader;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.toArray;

public class LandingLinesDeclarationHashedBuilderTest extends SparkTest {

    @Autowired
    LandingLinesDeclarationHashedBuilder landingLinesDeclarationHashedBuilder;

    @Autowired
    LandingLinesDeclarationHashedReader landingLinesDeclarationHashedReader;

    @Test
    public void buildLandingLinesDeclarationHashedDataset() throws Exception {
        Dataset<LandingLinesDeclarationHashed> dataset = landingLinesDeclarationHashedBuilder.build();
        assertThat(dataset.count(), is(greaterThan(0l)));
        // TODO assert hashes

        String[] fieldNames = dataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(landingLinesDeclarationStructFields));

        Dataset<LandingLinesDeclarationHashed> pdiHashedDataset = landingLinesDeclarationHashedReader.landingLinesDeclarationDataset();

        List<LandingLinesDeclarationHashed> actualHashed = dataset.toJavaRDD().collect();
        List<LandingLinesDeclarationHashed> expectedHashed = pdiHashedDataset.toJavaRDD().collect();

        // TODO - prehaps we don't need to assert this horrible way. This is for the initial verification of all rows and columns.
        // TODO - To be cleaned up to assert one row.
        actualHashed.forEach(landingLinesDeclarationHashed -> {
            LandingLinesDeclarationHashed expectedLandingLinesDeclarationHashed = expectedHashed.stream()
                    .filter(v1 -> (v1.getEntry_reference().equals(landingLinesDeclarationHashed.getEntry_reference()) && (v1.getItem_number().equals(landingLinesDeclarationHashed.getItem_number()))))
                    .findFirst()
                    .get();

            assertThat(landingLinesDeclarationHashed.getClearance_datetime(), is(equalTo(expectedLandingLinesDeclarationHashed.getClearance_datetime())));
            assertThat(landingLinesDeclarationHashed.getItem_statistical_value(), is(equalTo(expectedLandingLinesDeclarationHashed.getItem_statistical_value())));
            assertThat(landingLinesDeclarationHashed.getCustoms_duty_paid(), is(equalTo(expectedLandingLinesDeclarationHashed.getCustoms_duty_paid())));
            assertThat(landingLinesDeclarationHashed.getVat_paid(), is(equalTo(expectedLandingLinesDeclarationHashed.getVat_paid())));
            assertThat(landingLinesDeclarationHashed.getEc_supplementary_1(), is(equalTo(expectedLandingLinesDeclarationHashed.getEc_supplementary_1())));
            assertThat(landingLinesDeclarationHashed.getItem_customs_value(), is(equalTo(expectedLandingLinesDeclarationHashed.getItem_customs_value())));
            assertThat(landingLinesDeclarationHashed.getItem_net_mass(), is(equalTo(expectedLandingLinesDeclarationHashed.getItem_net_mass())));
            assertThat(landingLinesDeclarationHashed.getItem_supplementary_units(), is(equalTo(expectedLandingLinesDeclarationHashed.getItem_supplementary_units())));
            assertThat(landingLinesDeclarationHashed.getGoods_description(), is(equalTo(expectedLandingLinesDeclarationHashed.getGoods_description())));
            assertThat(landingLinesDeclarationHashed.getItem_customs_check_code(), is(equalTo(expectedLandingLinesDeclarationHashed.getItem_customs_check_code())));
            assertThat(landingLinesDeclarationHashed.getItem_mic_code(), is(equalTo(expectedLandingLinesDeclarationHashed.getItem_mic_code())));
            assertThat(landingLinesDeclarationHashed.getItem_profile_id(), is(equalTo(expectedLandingLinesDeclarationHashed.getItem_profile_id())));
            assertThat(landingLinesDeclarationHashed.getItem_consignor_nad_name(), is(equalTo(expectedLandingLinesDeclarationHashed.getItem_consignor_nad_name())));
            assertThat(landingLinesDeclarationHashed.getItem_consignee_nad_name(), is(equalTo(expectedLandingLinesDeclarationHashed.getItem_consignee_nad_name())));
            assertThat(landingLinesDeclarationHashed.getItem_consignee_nad_postcode(), is(equalTo(expectedLandingLinesDeclarationHashed.getItem_consignee_nad_postcode())));
            assertThat(landingLinesDeclarationHashed.getVat_value(), is(equalTo(expectedLandingLinesDeclarationHashed.getVat_value())));
            assertThat(landingLinesDeclarationHashed.getItem_price_declared(), is(equalTo(expectedLandingLinesDeclarationHashed.getItem_price_declared())));
            assertThat(landingLinesDeclarationHashed.getOrigin_country_code(), is(equalTo(expectedLandingLinesDeclarationHashed.getOrigin_country_code())));
            assertThat(landingLinesDeclarationHashed.getItem_importer_turn(), is(equalTo(expectedLandingLinesDeclarationHashed.getItem_importer_turn())));
            assertThat(landingLinesDeclarationHashed.getEntry_reference(), is(equalTo(expectedLandingLinesDeclarationHashed.getEntry_reference())));
            assertThat(landingLinesDeclarationHashed.getItem_number(), is(equalTo(expectedLandingLinesDeclarationHashed.getItem_number())));
            assertThat(landingLinesDeclarationHashed.getCustoms_procedure_code(), is(equalTo(expectedLandingLinesDeclarationHashed.getCustoms_procedure_code())));
            assertThat(landingLinesDeclarationHashed.getHs_code(), is(equalTo(expectedLandingLinesDeclarationHashed.getHs_code())));
            assertThat(landingLinesDeclarationHashed.getHub_declaration_line(), is(equalTo(expectedLandingLinesDeclarationHashed.getHub_declaration_line())));
            assertThat(landingLinesDeclarationHashed.getSat_declaration_line(), is(equalTo(expectedLandingLinesDeclarationHashed.getSat_declaration_line())));
            assertThat(landingLinesDeclarationHashed.getLink_declaration_line_commodity(), is(equalTo(expectedLandingLinesDeclarationHashed.getLink_declaration_line_commodity())));
            assertThat(landingLinesDeclarationHashed.getLink_declaration_line_commodity_hub_commodity(), is(equalTo(expectedLandingLinesDeclarationHashed.getLink_declaration_line_commodity_hub_commodity())));
            assertThat(landingLinesDeclarationHashed.getLink_declaration_line_customs_procedure_code(), is(equalTo(expectedLandingLinesDeclarationHashed.getLink_declaration_line_customs_procedure_code())));
            assertThat(landingLinesDeclarationHashed.getLink_declaration_line_customs_procedure_code_hub_customs_procedure_code(), is(equalTo(expectedLandingLinesDeclarationHashed.getLink_declaration_line_customs_procedure_code_hub_customs_procedure_code())));
            assertThat(landingLinesDeclarationHashed.getLink_declaration_line_declaration(), is(equalTo(expectedLandingLinesDeclarationHashed.getLink_declaration_line_declaration())));
            assertThat(landingLinesDeclarationHashed.getLink_declaration_line_declaration_hub_declaration(), is(equalTo(expectedLandingLinesDeclarationHashed.getLink_declaration_line_declaration_hub_declaration())));
            assertThat(landingLinesDeclarationHashed.getLink_declaration_line_importer_trader(), is(equalTo(expectedLandingLinesDeclarationHashed.getLink_declaration_line_importer_trader())));
            assertThat(landingLinesDeclarationHashed.getLink_declaration_line_importer_trader_hub_trader(), is(equalTo(expectedLandingLinesDeclarationHashed.getLink_declaration_line_importer_trader_hub_trader())));
            assertThat(landingLinesDeclarationHashed.getLink_declaration_line_origin_country(), is(equalTo(expectedLandingLinesDeclarationHashed.getLink_declaration_line_origin_country())));
            assertThat(landingLinesDeclarationHashed.getLink_declaration_line_origin_country_hub_country(), is(equalTo(expectedLandingLinesDeclarationHashed.getLink_declaration_line_origin_country_hub_country())));
            
        });

    }


    public static String[] landingLinesDeclarationStructFields = toArray(
            Lists.newArrayList(
                    "clearance_datetime",
                    "commodity_code",
                    "customs_duty_paid",
                    "customs_procedure_code",
                    "ec_supplementary_1",
                    "entry_date",
                    "entry_number",
                    "entry_reference",
                    "epu_number",
                    "goods_description",
                    "hs_code",
                    "hub_declaration_line",
                    "ingestion_date",
                    "item_consignee_nad_name",
                    "item_consignee_nad_postcode",
                    "item_consignor_nad_name",
                    "item_customs_check_code",
                    "item_customs_value",
                    "item_importer_turn",
                    "item_mic_code",
                    "item_net_mass",
                    "item_number",
                    "item_price_declared",
                    "item_profile_id",
                    "item_statistical_value",
                    "item_supplementary_units",
                    "link_declaration_line_commodity",
                    "link_declaration_line_commodity_hub_commodity",
                    "link_declaration_line_customs_procedure_code",
                    "link_declaration_line_customs_procedure_code_hub_customs_procedure_code",
                    "link_declaration_line_declaration",
                    "link_declaration_line_declaration_hub_declaration",
                    "link_declaration_line_importer_trader",
                    "link_declaration_line_importer_trader_hub_trader",
                    "link_declaration_line_origin_country",
                    "link_declaration_line_origin_country_hub_country",
                    "origin_country_code",
                    "sat_declaration_line",
                    "source",
                    "vat_paid",
                    "vat_value"
            )
    );

}