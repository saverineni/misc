package uk.gov.gsi.hmrc.cds.hasher.spark;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.hasher.spark.hdfs.builder.HDFSConfigurationBuilder;
import uk.gov.gsi.hmrc.cds.hasher.spark.hdfs.builder.HDFSFileSystemBuilder;

import java.io.IOException;
import java.util.Objects;

public class SparkIntegrationTest extends SparkRealTest {

    private String fromLocalPath = "dimensions/";
    private String HDFS_PATH = "/user/osboxes/spark/test_dev";

    @Autowired
    HashCalculatorJob hashCalculatorJob;

    private static Configuration configuration = HDFSConfigurationBuilder.builder()
            .withNameNodeHost("localhost")
            .withNameNodePort("8020")
            .build();
    FileSystem hdfs = HDFSFileSystemBuilder.builder(configuration).getHDFSInstance();

    @Before
    public void setup() throws IOException {
        Path hdfsToPath = new Path(HDFS_PATH);
        hdfs.create(hdfsToPath);
       // hdfsActions(configuration);
    }

    @Test
    public void sparkIntegration() throws Exception {
       // hashCalculatorJob.persistHashedTables();
    }

    public void hdfsActions(Configuration configuration) throws IOException {
        Objects.requireNonNull(fromLocalPath, "From local path cannot be null");
        Objects.requireNonNull(HDFS_PATH, "To path cannot be null");

        Path localFromPath = new Path(fromLocalPath);

      //  hdfs.copyFromLocalFile(localFromPath, hdfsToPath);
    }
}