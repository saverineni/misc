package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.hasher.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCommodityCodeHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.reader.DimCommodityCodeHashedReader;

import java.util.Arrays;
import java.util.List;

import static com.google.common.base.Strings.isNullOrEmpty;
import static java.util.Objects.isNull;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertTrue;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.toArray;

public class DimCommodityCodeHashedBuilderTest extends SparkTest {

    @Autowired
    DimCommodityCodeHashedBuilder dimCommodityCodeHashedBuilder;

    @Autowired
    DimCommodityCodeHashedReader dimCommodityCodeHashedReader;

    @Test
    public void buildDimCommodityCodeHashedDataset() throws Exception {
        Dataset<DimCommodityCodeHashed> dataset = dimCommodityCodeHashedBuilder.build();
        assertThat(dataset.count(), is(greaterThan(0l)));

        dataset.show(false);
        String[] fieldNames = dataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(dimCommodityCodeHashedStructFields));

        Dataset<DimCommodityCodeHashed> pdiHashedDataset = dimCommodityCodeHashedReader.dimCommodityCodeHashedDataset();
        List<DimCommodityCodeHashed> actualHashed = dataset.toJavaRDD().collect();
        List<DimCommodityCodeHashed> expectedHashed = pdiHashedDataset.toJavaRDD().collect();

        // TODO - prehaps we don't need to assert this horrible way. This is for the initial verification of all rows and columns.
        // TODO - To be cleaned up to assert one row.
        actualHashed.forEach(dimCommodityCodeHashed -> {

            DimCommodityCodeHashed expectedDimCommodityCodeHashed = expectedHashed.stream()
                    .filter(v1 -> (v1.getHs_code().equals(dimCommodityCodeHashed.getHs_code())))
                    .findFirst()
                    .get();

            System.out.println(dimCommodityCodeHashed.toString());
            System.out.println(expectedDimCommodityCodeHashed.toString());

            if (isNull(dimCommodityCodeHashed.getCc_month())) {
                assertTrue(isNullOrEmpty(expectedDimCommodityCodeHashed.getCc_month()));
            } else {
                assertThat(dimCommodityCodeHashed.getCc_month(), is(equalTo(expectedDimCommodityCodeHashed.getCc_month())));
            }
            if (isNull(dimCommodityCodeHashed.getCc_year())) {
                assertTrue(isNullOrEmpty(expectedDimCommodityCodeHashed.getCc_year()));
            } else {
                assertThat(dimCommodityCodeHashed.getCc_year(), is(equalTo(expectedDimCommodityCodeHashed.getCc_year())));
            }
            if (isNull(dimCommodityCodeHashed.getChapter_description())) {
                assertTrue(isNullOrEmpty(expectedDimCommodityCodeHashed.getChapter_description()));
            } else {
                assertThat(dimCommodityCodeHashed.getChapter_description(), is(equalTo(expectedDimCommodityCodeHashed.getChapter_description())));
            }
            if (isNull(dimCommodityCodeHashed.getHeading_description())) {
                assertTrue(isNullOrEmpty(expectedDimCommodityCodeHashed.getHeading_description()));
            } else {
                assertThat(dimCommodityCodeHashed.getHeading_description(), is(equalTo(expectedDimCommodityCodeHashed.getHeading_description())));
            }
            if (isNull(dimCommodityCodeHashed.getHs_chapter())) {
                assertTrue(isNullOrEmpty(expectedDimCommodityCodeHashed.getHs_chapter()));
            } else {
                assertThat(dimCommodityCodeHashed.getHs_chapter(), is(equalTo(expectedDimCommodityCodeHashed.getHs_chapter())));
            }
            if (isNull(dimCommodityCodeHashed.getHs_chapter_heading())) {
                assertTrue(isNullOrEmpty(expectedDimCommodityCodeHashed.getHs_chapter_heading()));
            } else {
                assertThat(dimCommodityCodeHashed.getHs_chapter_heading(), is(equalTo(expectedDimCommodityCodeHashed.getHs_chapter_heading())));
            }

            assertThat(dimCommodityCodeHashed.getHs_code(), is(equalTo(expectedDimCommodityCodeHashed.getHs_code())));

            if (isNull(dimCommodityCodeHashed.getHs_heading())) {
                assertTrue(isNullOrEmpty(expectedDimCommodityCodeHashed.getHs_heading()));
            } else {
                assertThat(dimCommodityCodeHashed.getHs_heading(), is(equalTo(expectedDimCommodityCodeHashed.getHs_heading())));
            }

            if (isNullOrEmpty(dimCommodityCodeHashed.getHs_subheading())) {
                assertTrue(isNullOrEmpty(expectedDimCommodityCodeHashed.getHs_subheading()));
            } else {
                assertThat(dimCommodityCodeHashed.getHs_subheading(), is(equalTo(expectedDimCommodityCodeHashed.getHs_subheading())));
            }


            assertThat(dimCommodityCodeHashed.getHub_commodity(), is(equalTo(expectedDimCommodityCodeHashed.getHub_commodity())));
            assertThat(dimCommodityCodeHashed.getSat_commodity(), is(equalTo(expectedDimCommodityCodeHashed.getSat_commodity())));

            if (isNull(dimCommodityCodeHashed.getSubheading_description())) {
                assertTrue(isNullOrEmpty(expectedDimCommodityCodeHashed.getSubheading_description()));
            } else {
                assertThat(dimCommodityCodeHashed.getSubheading_description(), is(equalTo(expectedDimCommodityCodeHashed.getSubheading_description())));
            }

        });
    }

    public static String[] dimCommodityCodeHashedStructFields = toArray(
            Lists.newArrayList(
                    "cc_month",
                    "cc_year",
                    "chapter_description",
                    "heading_description",
                    "hs_chapter",
                    "hs_chapter_heading",
                    "hs_code",
                    "hs_heading",
                    "hs_subheading",
                    "hub_commodity",
                    "sat_commodity",
                    "subheading_description"
            )
    );

}