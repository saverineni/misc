package uk.gov.gsi.hmrc.cds.hasher.spark.perfomancemetrics;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.util.ReflectionTestUtils;
import uk.gov.gsi.hmrc.cds.hasher.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.hasher.spark.helper.HiveContextAwareExecutor;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingTraderHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.performance.entity.PerformanceMetric;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Optional;

import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingTraderHashed.landingTraderHashedEncoder;


public class PerformanceMetricsCreatorTest extends SparkTest {

    public static final String APP_NAME = "TestApp";
    public static final String RELEASE_VERSION = "1.2.3";
    public static final String TABLE_NAME = "TestTable";
    private static final Timestamp START_TIMESTAMP = Timestamp.valueOf("2007-09-23 10:10:10.0");
    private static final Timestamp END_TIMESTAMP = Timestamp.valueOf("2007-09-23 11:11:11.0");
    public static final String TEST_DB = "testDb";
    public static final int ZERO_BATCH_ID = 0;
    public static final int BATCH_ID = 10;

    @Mock
    private PerformanceMetricsWriter performanceMetricsWriter;

    @Mock
    private HiveContextAwareExecutor executor;

    @InjectMocks
    private PerformanceMetricsCreator creator = new PerformanceMetricsCreator();

    @Autowired
    public SparkSession sparkSession;

    @Captor
    private ArgumentCaptor<PerformanceMetric> argumentCaptor;

    @Before
    public void setup() {
        ReflectionTestUtils.setField(creator, "landingHashedDatabaseName", TEST_DB);
    }

    @Test
    public void createMetrics() {
        creator.createMetrics(APP_NAME, createLAndingTraderHashed(), START_TIMESTAMP, END_TIMESTAMP, ZERO_BATCH_ID, RELEASE_VERSION, TABLE_NAME);
        Mockito.verify(performanceMetricsWriter).logMetrics(argumentCaptor.capture(), anyString(), anyObject());
        PerformanceMetric actualPerformanceMetric = argumentCaptor.getValue();
        Assert.assertEquals(expectedResult(), actualPerformanceMetric);
    }

    @Test
    public void retrieveBatchIdZero() {
        Mockito.when(executor.sql(anyString())).thenReturn(Optional.empty());
        int actualBatchId = creator.retrieveBatchId(APP_NAME);
        Assert.assertEquals(ZERO_BATCH_ID, actualBatchId);
    }

    @Test
    public void retrieveBatchIdNonZero() {
        Mockito.when(executor.sql(anyString())).thenReturn(createBatchIdDataSet());
        int actualBatchId = creator.retrieveBatchId(APP_NAME);
        Assert.assertEquals(BATCH_ID, actualBatchId);
    }

    private PerformanceMetric expectedResult() {
        return PerformanceMetric.builder()
                .app_name(APP_NAME)
                .release_version(RELEASE_VERSION)
                .batch_id(ZERO_BATCH_ID + 1)
                .start_time(START_TIMESTAMP)
                .end_time(END_TIMESTAMP)
                .table_name(TABLE_NAME)
                .number_of_cols(10)
                .number_of_rows(1)
                .build();
    }

    private Dataset<LandingTraderHashed> createLAndingTraderHashed() {
        LandingTraderHashed hashed = LandingTraderHashed.builder()
                .source("")
                .ingestion_date("")
                .turn("")
                .fedate("")
                .name("")
                .simplified_procedure_authorisations("")
                .trader_name_abbreviated("")
                .currentind("")
                .hub_trader("")
                .sat_trader("")
                .build();

        return sparkSession.createDataset(Arrays.asList(hashed), landingTraderHashedEncoder);
    }

    private Optional<Dataset<Row>> createBatchIdDataSet() {
        return Optional.of(sparkSession.createDataset(Arrays.asList(BATCH_ID), Encoders.INT()).toDF());
    }

}
