package uk.gov.gsi.hmrc.cds.hasher.spark.readers;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingHeaderDeclarationHashed;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables.LANDING_HEADER_DECLARATION_HASHED;

// TODO - remove this class once the hash validation is complete in test.
@Component
public class LandingHeaderDeclarationHashedReader extends TableReader {

    public Dataset<LandingHeaderDeclarationHashed> landingHeaderDeclarationHashedDataset() {
        String dataFilePath = String.format("%s/%s", LANDING_HEADER_DECLARATION_HASHED.tableName(), datafileRelativePath);
        String landingHeaderDeclarationHashedFilePath = String.format("%s/%s", landingHDFSAbsoluteBasePath, dataFilePath);

        JavaRDD<LandingHeaderDeclarationHashed> landingHeaderDeclarationHashedJavaRDD = javaSparkContext
                .textFile(landingHeaderDeclarationHashedFilePath)
                .map(LandingHeaderDeclarationHashed::parse);
        return sparkSession.createDataset(landingHeaderDeclarationHashedJavaRDD.rdd(), LandingHeaderDeclarationHashed.landingHeaderDeclarationHashedEncoder);
    }
}
