-- --
-- Customs Route dimension
-- --
-- DROP TABLE IF EXISTS `${EXPLOIT_DB}`.customs_route_dimension_csv_file PURGE;
-- DROP TABLE IF EXISTS `${EXPLOIT_DB}`.${DIMENSION_NAME} PURGE;

-- External table from data CSV

CREATE EXTERNAL TABLE IF NOT EXISTS `${EXPLOIT_DB}`.customs_route_dimension_csv_file
(
  customs_route_id INT,
  customs_route_code STRING,
  description STRING
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
LOCATION '${HDFS_DIM_DATA_PATH}/customs_routes/';


-- Create dimension
CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.${TABLE_NAME} AS
SELECT
  *
FROM `${EXPLOIT_DB}`.customs_route_dimension_csv_file;
