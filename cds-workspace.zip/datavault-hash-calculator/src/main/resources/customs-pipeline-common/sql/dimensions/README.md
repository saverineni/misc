Convention for .sql files in this directory is that PDI will use the filename to determine the dimension name.

The ${DIMENSION_NAME} variable is then used to:
+ Automatically set the name of the dimension table in the SQL
+ Set the name of the table to invalidate impala metadata.

This aids consistency and means that if the convention is followed then a dimension could be renamed simply by renaming the file.
