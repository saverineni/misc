-- --
-- Customs Procedure dimension
-- --
-- DROP TABLE IF EXISTS `${EXPLOIT_DB}`.customs_procedure_code_dimension_csv_file PURGE;
-- DROP TABLE IF EXISTS `${EXPLOIT_DB}`.${DIMENSION_NAME} PURGE;

-- External table from data CSV
CREATE EXTERNAL TABLE IF NOT EXISTS `${EXPLOIT_DB}`.customs_procedure_code_dimension_csv_file
(
  customs_procedure_code STRING,
  series STRING,
  page STRING,
  `procedure` STRING,
  procedure_description STRING,
  previous_procedure STRING,
  previous_procedure_description STRING,
  national_coding STRING,
  type_of_goods STRING,
  type_of_goods_description STRING,
  release_mechanism STRING,
  release_mechanism_description STRING,
  regime_entered_to STRING,
  regime_entered_to_description STRING
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001'
LOCATION '${HDFS_DIM_DATA_PATH}/customs_procedure_codes/';

-- Create dimension
CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.${TABLE_NAME} as
SELECT
  *
FROM `${EXPLOIT_DB}`.customs_procedure_code_dimension_csv_file;
