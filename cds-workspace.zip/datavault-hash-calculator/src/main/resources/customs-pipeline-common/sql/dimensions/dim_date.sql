-- --
-- Date dimension
-- --

-- DROP TABLE IF EXISTS `${EXPLOIT_DB}`.${DIMENSION_NAME} PURGE;

-- Maybe we need a few more entries in here.
-- It maybe useful to know if this is a national/local holiday
CREATE EXTERNAL TABLE IF NOT EXISTS `${EXPLOIT_DB}`.${TABLE_NAME}
(
  date_id INT,
  date_month_short VARCHAR(3),
  date_day_of_month INT,
  date_day_of_week INT,
  date_day_of_week_long VARCHAR(20),
  date_day_of_week_short VARCHAR(3),
  date_day_of_year INT,
  date_formatted_iso CHAR (10),
  date_month INT,
  date_month_format_yyyy_mm VARCHAR(7),
  date_month_long VARCHAR (20),
  date_quarter INT,
  date_quarter_name VARCHAR(2),
  date_quarter_name_full VARCHAR(7),
  date_value CHAR(10),
  date_week_of_year INT,
  date_year INT,
  date_is_weekend CHAR(1),
  date_week_start_date CHAR(10),
  date_year_of_week INT
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
LOCATION '${HDFS_DIM_DATA_PATH}/dates/';
