package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLineTaxLine;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLineTaxLineHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader.LandingLineTaxLineReader;

@Component
public class LandingLineTaxLineHashedBuilder extends BaseHashedBuilder {

    @Autowired
    private LandingLineTaxLineReader landingLineTaxLineReader;

    public Dataset<LandingLineTaxLineHashed> build() {
        Dataset<LandingLineTaxLine> landingLineTaxLineDataset = landingLineTaxLineReader.landingLineTaxLineDataset();

        return landingLineTaxLineDataset.map((MapFunction<LandingLineTaxLine, LandingLineTaxLineHashed>) LandingLineTaxLineHashed::mapper, LandingLineTaxLineHashed.landingLineTaxLineHashedEncoder);
    }
    public void saveAndCreateExternalTable(Dataset<LandingLineTaxLineHashed> landingLineTaxLineHashedDataset) {
        String tableName = LandingTables.LANDING_LINE_TAX_LINE_HASHED.tableName();
        saveLandingDatasetAsTable(landingLineTaxLineHashedDataset, tableName);
    }
}
