package uk.gov.gsi.hmrc.cds.hasher.spark;

import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.hashed.DimCommodityCodeHashedBuilder;
import uk.gov.gsi.hmrc.cds.hasher.spark.hashed.DimCountryHashedBuilder;
import uk.gov.gsi.hmrc.cds.hasher.spark.hashed.DimCurrencyHashedBuilder;
import uk.gov.gsi.hmrc.cds.hasher.spark.hashed.DimCustomsProcedureCodeHashedBuilder;
import uk.gov.gsi.hmrc.cds.hasher.spark.perfomancemetrics.PerformanceMetricsCreator;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCommodityCodeHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCountryHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCurrencyHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCustomsProcedureCodeHashed;

import java.sql.Timestamp;

import static uk.gov.gsi.hmrc.cds.hasher.spark.HashCalculatorJob.APP_NAME;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.DimensionTables.*;

@Component
public class DimensionHashTableGenerator {

    @Autowired
    private DimCountryHashedBuilder dimCountryHashedBuilder;

    @Autowired
    private DimCurrencyHashedBuilder dimCurrencyHashedBuilder;

    @Autowired
    private DimCommodityCodeHashedBuilder dimCommodityCodeHashedBuilder;

    @Autowired
    DimCustomsProcedureCodeHashedBuilder dimCustomsProcedureCodeHashedBuilder;

    @Autowired
    private PerformanceMetricsCreator performanceMetricsCreator;

    public void persistDimensionHashTable(int batchId, String releaseVersion) {

        Timestamp startDCountryTimestamp = new Timestamp(System.currentTimeMillis());
        Dataset<DimCountryHashed> dimCountryHashedDataset = dimCountryHashedBuilder.build();
        dimCountryHashedBuilder.saveAndCreateExternalTable(dimCountryHashedDataset);
        Timestamp endDCountryTimestamp = new Timestamp(System.currentTimeMillis());
        performanceMetricsCreator.createMetrics(APP_NAME, dimCountryHashedDataset, startDCountryTimestamp, endDCountryTimestamp, batchId, releaseVersion, DIM_COUNTRY_HASHED.tableName());

        Timestamp startDCurrencyTimestamp = new Timestamp(System.currentTimeMillis());
        Dataset<DimCurrencyHashed> dimCurrencyHashedDataset = dimCurrencyHashedBuilder.build();
        dimCurrencyHashedBuilder.saveAndCreateExternalTable(dimCurrencyHashedDataset);
        Timestamp endDCurrencyTimestamp = new Timestamp(System.currentTimeMillis());
        performanceMetricsCreator.createMetrics(APP_NAME, dimCurrencyHashedDataset, startDCurrencyTimestamp, endDCurrencyTimestamp, batchId, releaseVersion, DIM_CURRENCY_HASHED.tableName());

        Timestamp startDCommodityTimestamp = new Timestamp(System.currentTimeMillis());
        Dataset<DimCommodityCodeHashed> dimCommodityCodeHashedDataset = dimCommodityCodeHashedBuilder.build();
        dimCommodityCodeHashedBuilder.saveAndCreateExternalTable(dimCommodityCodeHashedDataset);
        Timestamp endDCommodityTimestamp = new Timestamp(System.currentTimeMillis());
        performanceMetricsCreator.createMetrics(APP_NAME, dimCommodityCodeHashedDataset, startDCommodityTimestamp, endDCommodityTimestamp, batchId, releaseVersion, DIM_COMMODITY_CODE_HASHED.tableName());

        Timestamp startDCustomsProcedureTimestamp = new Timestamp(System.currentTimeMillis());
        Dataset<DimCustomsProcedureCodeHashed> dimCustomsProcedureCodeHashedDataset = dimCustomsProcedureCodeHashedBuilder.build();
        dimCustomsProcedureCodeHashedBuilder.saveAndCreateExternalTable(dimCustomsProcedureCodeHashedDataset);
        Timestamp endDCustomsProcedureTimestamp = new Timestamp(System.currentTimeMillis());
        performanceMetricsCreator.createMetrics(APP_NAME, dimCustomsProcedureCodeHashedDataset, startDCustomsProcedureTimestamp, endDCustomsProcedureTimestamp, batchId, releaseVersion, DIM_CUSTOMS_PROCEDURE_CODE_HASHED.tableName());
    }
}
