package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLineAdditionalInformation;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLineAdditionalInformationHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader.LandingLineAdditionalInformationReader;

@Component
public class LandingLineAdditionalInformationHashedBuilder extends BaseHashedBuilder {

    @Autowired
    private LandingLineAdditionalInformationReader landingLineAdditionalInformationReader;

    public Dataset<LandingLineAdditionalInformationHashed> build() {
        Dataset<LandingLineAdditionalInformation> landingLinesDeclarationDataset = landingLineAdditionalInformationReader.landingLineAdditionalInformationDataset();

        return landingLinesDeclarationDataset.map((MapFunction<LandingLineAdditionalInformation, LandingLineAdditionalInformationHashed>) LandingLineAdditionalInformationHashed::mapper, LandingLineAdditionalInformationHashed.landingLineAdditionalInformationHashedEncoder);
    }

    public void saveAndCreateExternalTable(Dataset<LandingLineAdditionalInformationHashed> landingLineAdditionalInformationHashedDataset) {
        String tableName = LandingTables.LANDING_LINE_ADDITIONAL_INFORMATION_HASHED.tableName();
        saveLandingDatasetAsTable(landingLineAdditionalInformationHashedDataset, tableName);
    }
}
