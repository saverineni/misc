package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity;

import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.*;

@Data
@Builder
@AllArgsConstructor
public class LandingLineDocument implements Serializable, BaseEntity {

    private String source;
    private String ingestion_date;
    private String item_number;
    private String document_sequence_number;
    private String generation_number;
    private String item_document_code;
    private String item_document_status;
    private String item_document_reference;
    private String entry_reference;

    public static final Encoder<LandingLineDocument> landingLineDocumentEncoder = Encoders.bean(LandingLineDocument.class);

    public static String[] structFields = toArray(
            Lists.newArrayList(
                    "source",
                    "ingestion_date",
                    "item_number",
                    "document_sequence_number",
                    "generation_number",
                    "item_document_code",
                    "item_document_status",
                    "item_document_reference",
                    "entry_reference"
            )
    );

    public static LandingLineDocument parse(String line) {
        List<String> columns = parseLine(line);

        return LandingLineDocument.builder()
                .source(valueAt(columns, 0))
                .ingestion_date(valueAt(columns, 1))
                .item_number(valueAt(columns, 2))
                .document_sequence_number(valueAt(columns, 3))
                .generation_number(valueAt(columns, 4))
                .item_document_code(valueAt(columns, 5))
                .item_document_status(valueAt(columns, 6))
                .item_document_reference(valueAt(columns, 7))
                .entry_reference(valueAt(columns, 8))
                .build();
    }
}
