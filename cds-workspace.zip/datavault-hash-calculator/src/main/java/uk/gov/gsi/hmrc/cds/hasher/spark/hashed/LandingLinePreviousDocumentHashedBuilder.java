package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLinePreviousDocument;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLinePreviousDocumentHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader.LandingLinePreviousDocumentReader;

@Component
public class LandingLinePreviousDocumentHashedBuilder extends BaseHashedBuilder{

    @Autowired
    private LandingLinePreviousDocumentReader landingLinePreviousDocumentReader;

    public Dataset<LandingLinePreviousDocumentHashed> build() {
        Dataset<LandingLinePreviousDocument> landingLinePreviousDocumentDataset = landingLinePreviousDocumentReader.landingLinePreviousDocumentDataset();

        return landingLinePreviousDocumentDataset.map((MapFunction<LandingLinePreviousDocument, LandingLinePreviousDocumentHashed>) LandingLinePreviousDocumentHashed::mapper, LandingLinePreviousDocumentHashed.landingLinePreviousDocumentHashedEncoder);
    }

    public void saveAndCreateExternalTable(Dataset<LandingLinePreviousDocumentHashed> landingLinePreviousDocumentHashedDataset) {
        String tableName = LandingTables.LANDING_LINE_PREVIOUS_DOCUMENT_HASHED.tableName();
        saveLandingDatasetAsTable(landingLinePreviousDocumentHashedDataset, tableName);
    }
}
