package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity;

import com.google.common.collect.Lists;
import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.hasher.spark.helper.MD5Hasher.md5HashOf;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.*;

@Data
@Builder
public class LandingLineDocumentHashed implements Serializable, BaseEntity {

    private String source;
    private String ingestion_date;
    private String item_number;
    private String document_sequence_number;
    private String generation_number;
    private String item_document_code;
    private String item_document_status;
    private String item_document_reference;
    private String entry_reference;
    private String hub_document;
    private String sat_document;
    private String link_declaration_line_document;
    private String link_declaration_line_document_hub_declaration_line;

    public static final Encoder<LandingLineDocumentHashed> landingLineDocumentHashedEncoder = Encoders.bean(LandingLineDocumentHashed.class);

    public static LandingLineDocumentHashed mapper(LandingLineDocument landingLineDocument) {
        return LandingLineDocumentHashed.builder()
                .source(landingLineDocument.getSource())
                .ingestion_date(landingLineDocument.getIngestion_date())
                .item_number(landingLineDocument.getItem_number())
                .document_sequence_number(landingLineDocument.getDocument_sequence_number())
                .generation_number(landingLineDocument.getGeneration_number())
                .item_document_code(landingLineDocument.getItem_document_code())
                .item_document_status(landingLineDocument.getItem_document_status())
                .item_document_reference(landingLineDocument.getItem_document_reference())
                .entry_reference(landingLineDocument.getEntry_reference())
                .hub_document(hubDocumentHashed(landingLineDocument))
                .sat_document(satDocumentHashDifference(landingLineDocument))
                .link_declaration_line_document(linkDeclarationLineDocumentHashed(landingLineDocument))
                .link_declaration_line_document_hub_declaration_line(hubDeclarationLineHashed(landingLineDocument))
                .build();
    }

    private static String hubDeclarationLineHashed(LandingLineDocument landingLineDocument) {
        return md5HashOf(Arrays.asList(
                landingLineDocument.getEntry_reference(),
                landingLineDocument.getItem_number()
        ));
    }

    private static String linkDeclarationLineDocumentHashed(LandingLineDocument landingLineDocument) {
        return md5HashOf(Arrays.asList(
                landingLineDocument.getEntry_reference(),
                landingLineDocument.getItem_number(),
                landingLineDocument.getDocument_sequence_number()
        ));
    }

    private static String satDocumentHashDifference(LandingLineDocument landingLineDocument) {
        return md5HashOf(Arrays.asList(
                landingLineDocument.getGeneration_number(),
                landingLineDocument.getItem_document_code(),
                landingLineDocument.getItem_document_status(),
                landingLineDocument.getItem_document_reference()
        ));
    }

    private static String hubDocumentHashed(LandingLineDocument landingLineDocument) {
        return md5HashOf(Arrays.asList(
                landingLineDocument.getEntry_reference(),
                landingLineDocument.getItem_number(),
                landingLineDocument.getDocument_sequence_number()
        ));
    }



    public static LandingLineDocumentHashed parse(String line) {
        List<String> columns = parseLine(line);

        return LandingLineDocumentHashed.builder()
                .source(valueAt(columns, 0))
                .ingestion_date(valueAt(columns, 1))
                .item_number(valueAt(columns, 2))
                .document_sequence_number(valueAt(columns, 3))
                .generation_number(valueAt(columns, 4))
                .item_document_code(valueAt(columns, 5))
                .item_document_status(valueAt(columns, 6))
                .item_document_reference(valueAt(columns, 7))
                .entry_reference(valueAt(columns, 8))
                .hub_document(valueAt(columns, 9))
                .sat_document(valueAt(columns, 10))
                .link_declaration_line_document(valueAt(columns, 11))
                .link_declaration_line_document_hub_declaration_line(valueAt(columns, 12))
                .build();
    }
}
