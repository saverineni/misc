package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.performance.entity;

import lombok.*;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.sql.Timestamp;

@Data
@Builder
@EqualsAndHashCode
@ToString
public class PerformanceMetric implements Serializable {

    public static final Encoder<PerformanceMetric> performanceMetricEncoder = Encoders.bean(PerformanceMetric.class);

    private String app_name;
    private String release_version;
    private int batch_id;
    private Timestamp start_time;
    private Timestamp end_time;
    private String table_name;
    private int number_of_cols;
    private long number_of_rows;

}

