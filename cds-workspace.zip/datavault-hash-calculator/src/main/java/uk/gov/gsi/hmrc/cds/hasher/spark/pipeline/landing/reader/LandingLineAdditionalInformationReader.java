package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLineAdditionalInformation;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables.LANDING_LINE_ADDITIONAL_INFORMATION;

@Component
public class LandingLineAdditionalInformationReader extends TableReader {

    public Dataset<LandingLineAdditionalInformation> landingLineAdditionalInformationDataset() {
        String dataFilePath = String.format("%s/%s", LANDING_LINE_ADDITIONAL_INFORMATION.tableName(), datafileRelativePath);
        String landingLineAdditionalInformationFilePath = String.format("%s/%s", landingHDFSAbsoluteBasePath, dataFilePath);

        JavaRDD<LandingLineAdditionalInformation> landingLineAdditionalInformationJavaRDD = javaSparkContext
                .textFile(landingLineAdditionalInformationFilePath)
                .map(LandingLineAdditionalInformation::parse);

        return sparkSession.createDataset(landingLineAdditionalInformationJavaRDD.rdd(), LandingLineAdditionalInformation.landingLineAdditionalInformationEncoder);

    }
}
