package uk.gov.gsi.hmrc.cds.hasher.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

@Configuration
public class HdfsConfig {
    @Autowired
    Environment environment;

    @Value("${hdfs.namenode}")
    private String hdfsNamenode;

    @Value("${hdfs.namenode.port:8020}")
    private String hdfsNamenodePort;

    @Bean
    public String datafileRelativePath() {
        return environment.getProperty("hdfs.landing.datafile.relative.path", "");
    }

    @Bean
    public String hdfsLandingHashedBasePath() {
        return environment.getProperty("hdfs.landing.hashed.base.path");
    }

    @Bean
    public String hdfsDimensionHashedBasePath() {
        return environment.getProperty("hdfs.dimension.hashed.base.path");
    }

    @Bean
    public String hdfsLandingBasePath() {
        return environment.getProperty("hdfs.landing.base.path");
    }

    @Bean
    public String hdfsDimensionBasePath() {
        return environment.getProperty("hdfs.dimension.base.path");
    }

    @Bean
    public String landingHashedHDFSAbsoluteBasePath() {
        return String.format("hdfs://%s:%s/%s", hdfsNamenode, hdfsNamenodePort, hdfsLandingHashedBasePath());
    }

    @Bean
    public String dimensionHashedHDFSAbsoluteBasePath() {
        return String.format("hdfs://%s:%s/%s", hdfsNamenode, hdfsNamenodePort, hdfsDimensionHashedBasePath());
    }

    @Bean
    public String landingHDFSAbsoluteBasePath() {
        return String.format("hdfs://%s:%s/%s", hdfsNamenode, hdfsNamenodePort, hdfsLandingBasePath());
    }


    @Bean
    public String dimensionHDFSAbsoluteBasePath() {
        return String.format("hdfs://%s:%s/%s", hdfsNamenode, hdfsNamenodePort, hdfsDimensionBasePath());
    }

    @Bean
    public String landingHashedDatabaseName() {
        return environment.getProperty("hdfs.landing.hashed.database.name");
    }

    @Bean
    public String dimensionHashedDatabaseName() {
        return environment.getProperty("hdfs.dimension.hashed.database.name");
    }

    @Bean
    public Boolean hiveContextAware() {
        return environment.getProperty("hive.context.aware", Boolean.class, true);
    }
}
