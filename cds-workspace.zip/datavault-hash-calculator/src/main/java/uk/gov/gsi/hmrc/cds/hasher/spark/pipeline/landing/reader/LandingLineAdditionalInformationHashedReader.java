package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLineAdditionalInformationHashed;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables.LANDING_LINE_ADDITIONAL_INFORMATION_HASHED;

@Component
public class LandingLineAdditionalInformationHashedReader extends TableReader {

    public Dataset<LandingLineAdditionalInformationHashed> landingLineAdditionalInformationDataset() {
        String dataFilePath = String.format("%s/%s", LANDING_LINE_ADDITIONAL_INFORMATION_HASHED.tableName(), datafileRelativePath);
        String landingLineAdditionalInformationHashedFilePath = String.format("%s/%s", landingHDFSAbsoluteBasePath, dataFilePath);

        JavaRDD<LandingLineAdditionalInformationHashed> landingLineAdditionalInformationHashedJavaRDD = javaSparkContext
                .textFile(landingLineAdditionalInformationHashedFilePath)
                .map(LandingLineAdditionalInformationHashed::parse);

        return sparkSession.createDataset(landingLineAdditionalInformationHashedJavaRDD.rdd(), LandingLineAdditionalInformationHashed.landingLineAdditionalInformationHashedEncoder);

    }
}
