package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.parseLine;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.valueAt;

@Data
@Builder
@AllArgsConstructor
public class DimCountry implements Serializable, BaseEntity {

    private String country_id;
    private String country_iso_code;
    private String country_name;
    private String country_sequence_number;
    private String country_comments;

    public static final Encoder<DimCountry> dimCountryEncoder = Encoders.bean(DimCountry.class);

    public static DimCountry parse(String line) {
        List<String> columns = parseLine(line);

        return DimCountry.builder()
                .country_id(valueAt(columns, 0))
                .country_iso_code(valueAt(columns, 1))
                .country_name(valueAt(columns, 2))
                .country_sequence_number(valueAt(columns, 3))
                .country_comments(valueAt(columns, 4))
                .build();
    }
}
