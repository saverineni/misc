package uk.gov.gsi.hmrc.cds.hasher.spark;

import lombok.extern.slf4j.Slf4j;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.hashed.*;
import uk.gov.gsi.hmrc.cds.hasher.spark.perfomancemetrics.PerformanceMetricsCreator;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.*;

import java.sql.Timestamp;

import static uk.gov.gsi.hmrc.cds.hasher.spark.HashCalculatorJob.APP_NAME;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables.*;

@Component
public class LandingHashTableGenerator {

    @Autowired
    private LandingHeaderDeclarationHashedBuilder landingHeaderDeclarationHashedBuilder;
    @Autowired
    private LandingLinesDeclarationHashedBuilder landingLinesDeclarationHashedBuilder;
    @Autowired
    private LandingLineAdditionalInformationHashedBuilder landingLineAdditionalInformationHashedBuilder;
    @Autowired
    private LandingLineDocumentHashedBuilder landingLineDocumentHashedBuilder;
    @Autowired
    private LandingLinePreviousDocumentHashedBuilder landingLinePreviousDocumentHashedBuilder;
    @Autowired
    private LandingLineTaxLineHashedBuilder landingLineTaxLineHashedBuilder;
    @Autowired
    private LandingTraderHashedBuilder landingTraderHashedBuilder;
    @Autowired
    private PerformanceMetricsCreator performanceMetricsCreator;


    public void persistLandingHashTables(int batchId, String releaseVersion) {
        Timestamp startLHDTimestamp = new Timestamp(System.currentTimeMillis());
        Dataset<LandingHeaderDeclarationHashed> landingHeaderDeclarationHashedDataset = landingHeaderDeclarationHashedBuilder.build();
        landingHeaderDeclarationHashedBuilder.saveAndCreateExternalTable(landingHeaderDeclarationHashedDataset);
        Timestamp endLHDTimestamp = new Timestamp(System.currentTimeMillis());
        performanceMetricsCreator.createMetrics(APP_NAME, landingHeaderDeclarationHashedDataset, startLHDTimestamp, endLHDTimestamp, batchId, releaseVersion, LANDING_HEADER_DECLARATION_HASHED.tableName());

        Timestamp startLLDecTimestamp = new Timestamp(System.currentTimeMillis());
        Dataset<LandingLinesDeclarationHashed> landingLinesDeclarationHashedDataset = landingLinesDeclarationHashedBuilder.build();
        landingLinesDeclarationHashedBuilder.saveAndCreateExternalTable(landingLinesDeclarationHashedDataset);
        Timestamp endLLDecTimestamp = new Timestamp(System.currentTimeMillis());
        performanceMetricsCreator.createMetrics(APP_NAME, landingLinesDeclarationHashedDataset, startLLDecTimestamp, endLLDecTimestamp, batchId, releaseVersion, LANDING_LINES_DECLARATION_HASHED.tableName());

        Timestamp startLLAITimestamp = new Timestamp(System.currentTimeMillis());
        Dataset<LandingLineAdditionalInformationHashed> landingLineAdditionalInformationHashedDataset = landingLineAdditionalInformationHashedBuilder.build();
        landingLineAdditionalInformationHashedBuilder.saveAndCreateExternalTable(landingLineAdditionalInformationHashedDataset);
        Timestamp endLLAITimestamp = new Timestamp(System.currentTimeMillis());
        performanceMetricsCreator.createMetrics(APP_NAME, landingLineAdditionalInformationHashedDataset, startLLAITimestamp, endLLAITimestamp, batchId, releaseVersion, LANDING_LINE_ADDITIONAL_INFORMATION_HASHED.tableName());

        Timestamp startLLDocTimestamp = new Timestamp(System.currentTimeMillis());
        Dataset<LandingLineDocumentHashed> landingLineDocumentHashedDataset = landingLineDocumentHashedBuilder.build();
        landingLineDocumentHashedBuilder.saveAndCreateExternalTable(landingLineDocumentHashedDataset);
        Timestamp endLLDocTimestamp = new Timestamp(System.currentTimeMillis());
        performanceMetricsCreator.createMetrics(APP_NAME, landingLineDocumentHashedDataset, startLLDocTimestamp, endLLDocTimestamp, batchId, releaseVersion, LANDING_LINE_DOCUMENT_HASHED.tableName());

        Timestamp startLLPDocTimestamp = new Timestamp(System.currentTimeMillis());
        Dataset<LandingLinePreviousDocumentHashed> landingLinePreviousDocumentHashedDataset = landingLinePreviousDocumentHashedBuilder.build();
        landingLinePreviousDocumentHashedBuilder.saveAndCreateExternalTable(landingLinePreviousDocumentHashedDataset);
        Timestamp endLLPDocTimestamp = new Timestamp(System.currentTimeMillis());
        performanceMetricsCreator.createMetrics(APP_NAME, landingLinePreviousDocumentHashedDataset, startLLPDocTimestamp, endLLPDocTimestamp, batchId, releaseVersion, LANDING_LINE_PREVIOUS_DOCUMENT_HASHED.tableName());

        Timestamp startLLTLineTimestamp = new Timestamp(System.currentTimeMillis());
        Dataset<LandingLineTaxLineHashed> landingLineTaxLineHashedDataset = landingLineTaxLineHashedBuilder.build();
        landingLineTaxLineHashedBuilder.saveAndCreateExternalTable(landingLineTaxLineHashedDataset);
        Timestamp endLLTLineTimestamp = new Timestamp(System.currentTimeMillis());
        performanceMetricsCreator.createMetrics(APP_NAME, landingLineTaxLineHashedDataset, startLLTLineTimestamp, endLLTLineTimestamp, batchId, releaseVersion, LANDING_LINE_TAX_LINE_HASHED.tableName());

        Timestamp startLTraderimestamp = new Timestamp(System.currentTimeMillis());
        Dataset<LandingTraderHashed> landingTraderHashedDataset = landingTraderHashedBuilder.build();
        landingTraderHashedBuilder.saveAndCreateExternalTable(landingTraderHashedDataset);
        Timestamp endLTraderimestamp = new Timestamp(System.currentTimeMillis());
        performanceMetricsCreator.createMetrics(APP_NAME, landingTraderHashedDataset, startLTraderimestamp, endLTraderimestamp, batchId, releaseVersion, LANDING_TRADER_HASHED.tableName());
    }
}
