package uk.gov.gsi.hmrc.cds.hasher.spark.helper;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import java.util.Optional;

public class HiveContextAwareExecutor {

    private Boolean hiveContextAware;
    private SparkSession sparkSession;

    public HiveContextAwareExecutor(Boolean hiveContextAware, SparkSession sparkSession) {
        this.hiveContextAware = hiveContextAware;
        this.sparkSession = sparkSession;
    }

    public Optional<Dataset<Row>> sql(String sqlString) {
        if (hiveContextAware) {
            return Optional.of(sparkSession.sql(sqlString));
        }
        return Optional.empty();
    }
}
