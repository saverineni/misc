package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.reader;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCountry;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.DimensionTables.DIM_COUNTRY;

@Component
public class DimCountryReader extends TableReader {

    public Dataset<DimCountry> dimCountryDataset() {
        String dataFilePath = String.format("%s/%s", DIM_COUNTRY.tableName(), datafileRelativePath);
        String dimCountryFilePath = String.format("%s/%s", dimensionHDFSAbsoluteBasePath, dataFilePath);

        JavaRDD<DimCountry> dimCountryJavaRDD = javaSparkContext
                .textFile(dimCountryFilePath)
                .map(DimCountry::parse);

        return sparkSession.createDataset(dimCountryJavaRDD.rdd(), DimCountry.dimCountryEncoder);

    }
}
