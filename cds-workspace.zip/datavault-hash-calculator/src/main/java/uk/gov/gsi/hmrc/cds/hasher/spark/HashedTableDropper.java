package uk.gov.gsi.hmrc.cds.hasher.spark;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.helper.DDLBuilder;
import uk.gov.gsi.hmrc.cds.hasher.spark.helper.HiveContextAwareExecutor;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.DimensionTables;

import java.util.Arrays;


@Component
public class HashedTableDropper {

    @Autowired
    private String landingHashedDatabaseName;

    @Autowired
    private String dimensionHashedDatabaseName;

    @Autowired
    private HiveContextAwareExecutor hiveContextAwareExecutor;

    private static final String TABLE_SUFFIX = "_hashed";

    public void dropAllHashedTables(){
        dropExisitingDimensionTables();
        dropExisitingLandingTables();
    }

    private void dropExisitingLandingTables(){
        Arrays.asList(LandingTables.values()).stream()
                .filter(landingTables-> landingTables.tableName().contains(TABLE_SUFFIX))
                .forEach(landingTables->dropLandingHashedTables(landingTables.tableName()));
    }

    private void dropExisitingDimensionTables(){
        Arrays.asList(DimensionTables.values()).stream()
                .filter(dimensionTables-> dimensionTables.tableName().contains(TABLE_SUFFIX))
                .forEach(dimensionTables->dropDimensionHashedTables(dimensionTables.tableName()));
    }

    private <T> void dropDimensionHashedTables(String tableName) {
        dropHashedTables(
                dimensionHashedDatabaseName,
                tableName
        );
    }

    private <T> void dropLandingHashedTables(String tableName) {
        dropHashedTables(
                landingHashedDatabaseName,
                tableName
        );
    }

    private <T> void dropHashedTables(String databaseName, String tableName) {
        String dropTableScript = DDLBuilder.dropTableScript(databaseName, tableName);
        hiveContextAwareExecutor.sql(dropTableScript);
    }
}
