package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.reader;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCurrency;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.DimensionTables.DIM_CURRENCY;

@Component
public class DimCurrencyReader extends TableReader {

    public Dataset<DimCurrency> dimCurrencyDataset() {
        String dataFilePath = String.format("%s/%s", DIM_CURRENCY.tableName(), datafileRelativePath);
        String dimCurrencyFilePath = String.format("%s/%s", dimensionHDFSAbsoluteBasePath, dataFilePath);

        JavaRDD<DimCurrency> dimCurrencyJavaRDD = javaSparkContext
                .textFile(dimCurrencyFilePath)
                .map(DimCurrency::parse);
        return sparkSession.createDataset(dimCurrencyJavaRDD.rdd(), DimCurrency.dimCurrencyEncoder);
    }
}
