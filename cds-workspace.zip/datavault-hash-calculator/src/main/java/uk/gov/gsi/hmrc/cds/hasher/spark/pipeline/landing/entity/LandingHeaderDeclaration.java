package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.parseLine;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.valueAt;

@Data
@Builder
@AllArgsConstructor
public class LandingHeaderDeclaration implements Serializable, BaseEntity {

    private String source;
    private String ingestion_date;
    private String entry_number;
    private String entry_date;
    private String epu_number;
    private String entry_type;
    private String declaration_method;
    private String total_excise;
    private String importer_turn;
    private String declarant_turn;
    private String declarant_representative_turn;
    private String consignee_aeo_certificate_type_code;
    private String declarant_aeo_certificate_type_code;
    private String route;
    private String declaration_import_export_indicator;
    private String generation_number;
    private String exporter_turn;
    private String destination_country_code;
    private String import_clearance_status;
    private String consignor_aeo_certificate_type_code;
    private String header_statistical_value;
    private String goods_departure_datetime;
    private String customs_value;
    private String total_duty;
    private String total_vat;
    private String net_mass_total;
    private String goods_location;
    private String acceptance_date;
    private String importer_turn_country_code;
    private String place_of_unloading_code;
    private String first_deferment_approval_num;
    private String first_deferment_approval_num_prefix;
    private String declaration_ucr;
    private String item_count;
    private String master_ucr;
    private String paying_agent_turn;
    private String place_of_loading_code;
    private String session_num;
    private String session_role_name;
    private String status_of_entry;
    private String transport_country;
    private String transport_id;
    private String transport_mode_code;
    private String dispatch_country;
    private String consignor_turn;
    private String consignor_turn_country_code;
    private String consignor_nad_name;
    private String consignee_nad_name;
    private String consignee_nad_postcode;
    private String declarant_nad_name;
    private String customs_check_code;
    private String profile_id;
    private String freight_currency;
    private String invoice_currency;
    private String invoice_total_declared;
    private String entry_reference;

    public static final Encoder<LandingHeaderDeclaration> landingHeaderDeclarationEncoder = Encoders.bean(LandingHeaderDeclaration.class);

    public LandingHeaderDeclaration() {
    }

    public static LandingHeaderDeclaration parse(String line) {
        List<String> columns = parseLine(line);

        return LandingHeaderDeclaration.builder()
                .source(valueAt(columns, 0))
                .ingestion_date(valueAt(columns, 1))
                .entry_number(valueAt(columns, 2))
                .entry_date(valueAt(columns, 3))
                .epu_number(valueAt(columns, 4))
                .entry_type(valueAt(columns, 5))
                .declaration_method(valueAt(columns, 6))
                .total_excise(valueAt(columns, 7))
                .importer_turn(valueAt(columns, 8))
                .declarant_turn(valueAt(columns, 9))
                .declarant_representative_turn(valueAt(columns, 10))
                .consignee_aeo_certificate_type_code(valueAt(columns, 11))
                .declarant_aeo_certificate_type_code(valueAt(columns, 12))
                .route(valueAt(columns, 13))
                .declaration_import_export_indicator(valueAt(columns, 14))
                .generation_number(valueAt(columns, 15))
                .exporter_turn(valueAt(columns, 16))
                .destination_country_code(valueAt(columns, 17))
                .import_clearance_status(valueAt(columns, 18))
                .consignor_aeo_certificate_type_code(valueAt(columns, 19))
                .header_statistical_value(valueAt(columns, 20))
                .goods_departure_datetime(valueAt(columns, 21))
                .customs_value(valueAt(columns, 22))
                .total_duty(valueAt(columns, 23))
                .total_vat(valueAt(columns, 24))
                .net_mass_total(valueAt(columns, 25))
                .goods_location(valueAt(columns, 26))
                .acceptance_date(valueAt(columns, 27))
                .importer_turn_country_code(valueAt(columns, 28))
                .place_of_unloading_code(valueAt(columns, 29))
                .first_deferment_approval_num(valueAt(columns, 30))
                .first_deferment_approval_num_prefix(valueAt(columns, 31))
                .declaration_ucr(valueAt(columns, 32))
                .item_count(valueAt(columns, 33))
                .master_ucr(valueAt(columns, 34))
                .paying_agent_turn(valueAt(columns, 35))
                .place_of_loading_code(valueAt(columns, 36))
                .session_num(valueAt(columns, 37))
                .session_role_name(valueAt(columns, 38))
                .status_of_entry(valueAt(columns, 39))
                .transport_country(valueAt(columns, 40))
                .transport_id(valueAt(columns, 41))
                .transport_mode_code(valueAt(columns, 42))
                .dispatch_country(valueAt(columns, 43))
                .consignor_turn(valueAt(columns, 44))
                .consignor_turn_country_code(valueAt(columns, 45))
                .consignor_nad_name(valueAt(columns, 46))
                .consignee_nad_name(valueAt(columns, 47))
                .consignee_nad_postcode(valueAt(columns, 48))
                .declarant_nad_name(valueAt(columns, 49))
                .customs_check_code(valueAt(columns, 50))
                .profile_id(valueAt(columns, 51))
                .freight_currency(valueAt(columns, 52))
                .invoice_currency(valueAt(columns, 53))
                .invoice_total_declared(valueAt(columns, 54))
                .entry_reference(valueAt(columns, 55))
                .build();
    }
}
