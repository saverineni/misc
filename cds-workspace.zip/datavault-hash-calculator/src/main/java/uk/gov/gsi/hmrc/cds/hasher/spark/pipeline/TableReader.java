package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline;

import com.google.common.collect.Iterables;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class TableReader {
    @Autowired
    public JavaSparkContext javaSparkContext;

    @Autowired
    public SparkSession sparkSession;

    @Autowired
    public SQLContext sqlContext;

    @Autowired
    public String landingHDFSAbsoluteBasePath;

    @Autowired
    public String dimensionHDFSAbsoluteBasePath;

    @Autowired
    public String datafileRelativePath;

    public String[] toArray(List<String> columns) {
        return Iterables.toArray(columns, String.class);
    }

}
