package uk.gov.gsi.hmrc.cds.hasher.spark.perfomancemetrics;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.helper.HiveContextAwareExecutor;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.performance.entity.PerformanceMetric;

import java.sql.Timestamp;
import java.util.Optional;

@Component
public class PerformanceMetricsCreator {

    @Autowired
    private PerformanceMetricsWriter performanceMetricsWriter;

    @Autowired
    private String landingHashedDatabaseName;

    @Autowired
    private HiveContextAwareExecutor executor;

    public static final String PERFORMANCE_METRICS_TABLE = "performance_metrics";
    public static final String FIELD_NAMES[] = new String[]{"app_name", "release_version", "batch_id", "start_time", "end_time", "table_name", "number_of_cols", "number_of_rows"};
    public static final String SELECT_TEMPLATE = "select COALESCE(max(batch_id),0) as batch_id from %s where app_name='%s'";

    public <T> void createMetrics(String appName, Dataset<T> hashedDataset, Timestamp startTimestamp, Timestamp endTimestamp, int batchId, String releaseVersion, String tableName) {
        final String performanceMetricsDBTable = String.format("%s.%s", landingHashedDatabaseName, PERFORMANCE_METRICS_TABLE);
        final int  numberOfColumns = hashedDataset.schema().fieldNames().length;
        final long numberOfRows = hashedDataset.count();

        PerformanceMetric performanceMetric = PerformanceMetric.builder()
                .app_name(appName)
                .release_version(releaseVersion)
                .batch_id(batchId + 1)
                .start_time(startTimestamp)
                .end_time(endTimestamp)
                .table_name(tableName)
                .number_of_cols(numberOfColumns)
                .number_of_rows(numberOfRows)
                .build();

        performanceMetricsWriter.logMetrics(performanceMetric, performanceMetricsDBTable, FIELD_NAMES);
    }

    public int retrieveBatchId(String appName) {
        int batchId = 0;
        final String performanceMetrics = String.format("%s.%s", landingHashedDatabaseName, PERFORMANCE_METRICS_TABLE);
        String query = String.format(SELECT_TEMPLATE, performanceMetrics, appName);
        Optional<Dataset<Row>> rowDataset = executor.sql(query);
        if (rowDataset.isPresent()) {
            Dataset<Row> appdataSet = rowDataset.get();
            batchId = appdataSet.as(Encoders.INT()).first();
        }
        return batchId;
    }

}
