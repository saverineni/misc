package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLineTaxLineHashed;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables.LANDING_LINE_TAX_LINE_HASHED;

@Component
public class LandingLineTaxLineHashedReader extends TableReader {

    public Dataset<LandingLineTaxLineHashed> landingLineTaxLineHashedDataset() {
        String dataFilePath = String.format("%s/%s", LANDING_LINE_TAX_LINE_HASHED.tableName(), datafileRelativePath);
        String landingLineTaxLineHashedFilePath = String.format("%s/%s", landingHDFSAbsoluteBasePath, dataFilePath);

        JavaRDD<LandingLineTaxLineHashed> landingLineTaxLineHashedJavaRDD = javaSparkContext
                .textFile(landingLineTaxLineHashedFilePath)
                .map(LandingLineTaxLineHashed::parse);
        return sparkSession.createDataset(landingLineTaxLineHashedJavaRDD.rdd(), LandingLineTaxLineHashed.landingLineTaxLineHashedEncoder);

    }
}
