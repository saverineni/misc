#!/bin/bash
set -e

ENVIRONMENT="$CDS_DATA_ENVIRONMENT"
SPARK_JAR_PATH=""

if [ -z "$ENVIRONMENT" ];
then
    echo "ENVIRONMENT variable 'CDS_DATA_ENVIRONMENT' not set"
    exit 1
else
    APPLICATION_VERSION=$(grep -m1 '<version>' pom.xml | cut -c11- | rev | cut -d"<" -f2  | rev)

    if [ "$ENVIRONMENT" == "local" ]; then
      SPARK_JAR_PATH="/home/osboxes/cds-workspace/datavault-hash-calculator/target/datavault-hash-calculator-"${APPLICATION_VERSION}".jar"
    elif [ "$ENVIRONMENT" == "pre_prod" OR "$ENVIRONMENT" == "prod" ]; then
      SPARK_JAR_PATH="/opt/hmrc/exp/datavault-hash-calculator/datavault-hash-calculator-"${APPLICATION_VERSION}".jar"
    else
      SPARK_JAR_PATH="/data/apps/cdsdata/pentaho-scripts/${CDS_DATA_ENVIRONMENT}/datavault-hash-calculator/datavault-hash-calculator-"${APPLICATION_VERSION}".jar"
    fi

    echo "Environment : $ENVIRONMENT"
    echo "Application version : $APPLICATION_VERSION"
    echo "Spark jar file path : $SPARK_JAR_PATH"

    sed -i "s@REPLACEABLE_SPARK_JAR_PATH@${SPARK_JAR_PATH}@g" kettle/MAIN_populate_Landing_Hashes.kjb
    exit 0

fi