Notes:
 This project creates Datavault hashes.

Usage:
    Make sure you don't run hive locally while executing the below script.
    Locally execute the command 'sh run.sh'

 kettle job - how it works:

 kettle checks the KETTLE_HOME environment property and finds the appropriate kettle.properties and respository.xml

 It reads kettle.properties and sets the properties in .kjb file, then reads all the repository snippets from the repository.xml and applies the appropriate repository to the one we mention when running the kettle job.
 In the below example its -rep="CDSDATA ETL : Datavault Data Model Schema" and reads the base_directory from the repository and appends -dir folder to check for the .kjb file mentioned, in this example
 MAIN_populate_Landing_Hashes

 sh kitchen.sh -rep="CDSDATA ETL : Datavault Data Model Schema" -dir=/kettle -job=MAIN_populate_Landing_Hashes -param:CDS_DATA_ENVIRONMENT_PARAM=sa_dev
