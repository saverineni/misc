#!/usr/bin/env groovy
import groovy.json.JsonSlurperClassic
import static groovy.json.JsonOutput.*

def call(String environmentName, String variableHost, String artifactVersionJson = '', String sparkJobSparkParameters = '', String sparkJobJavaParameters = '') {
    echo "Getting version/artifactId/groupId from passed JSON map"

    parsedJson = parseArtifactVersionJson(artifactVersionJson)
    if (parsedJson instanceof ArrayList) {
        echo prettyPrint(toJson(parsedJson))
        echo "This looks like a list, flattening JSON"
        jsonVersions = flattenListOfMaps(parsedJson)
    } else if (parsedJson instanceof Map) {
        jsonVersions = parsedJson
    }
    echo prettyPrint(toJson(jsonVersions))

    script {
        sparkJobArtifactId = jsonVersions.get('spark_job_artifact_id')
        sparkJobGroupId = jsonVersions.get('spark_job_group_id')
        sparkJobClassifier = jsonVersions.get('spark_job_classifier')
        sparkJobMavenExtension = jsonVersions.get('spark_job_maven_extension')
        sparkJobVersion = jsonVersions.get('spark_job_version')
    }

    // pass blank values to Ansible if they're not set in the JSON
    if (sparkJobClassifier == null) {
        sparkJobClassifier = ''
    }

    if (sparkJobMavenExtension == null) {
        sparkJobMavenExtension = ''
    }

    echo "Final values:"
    echo "sparkJobArtifactId = ${sparkJobArtifactId}"
    echo "sparkJobClassifier = ${sparkJobClassifier}"
    echo "sparkJobGroupId = ${sparkJobGroupId}"
    echo "sparkJobMavenExtension = ${sparkJobMavenExtension}"
    echo "sparkJobVersion = ${sparkJobVersion}"
    echo ""
    echo "sparkJobJavaParameters = ${sparkJobJavaParameters}"
    echo "sparkJobSparkParameters = ${sparkJobSparkParameters}"

    dir(env.workspaceDir + '/ansible/docker-deploy') {
        wrap([$class: 'AnsiColorBuildWrapper', colorMapName: "xterm"]) {
            ansiblePlaybook(
                colorized: true,
                credentialsId: getJenkinsDeployCredentialId(),
                extraVars: [
                        environment_name: environmentName,
                        variable_host: variableHost,
                        spark_job_artifact_id: sparkJobArtifactId,
                        spark_job_classifier: sparkJobClassifier,
                        spark_job_group_id: sparkJobGroupId,
                        spark_job_maven_extension: sparkJobMavenExtension,
                        spark_job_java_parameters: sparkJobJavaParameters,
                        spark_job_spark_parameters: sparkJobSparkParameters,
                        spark_job_version: sparkJobVersion,
                ],
                extras: getDebugExtras(environmentName, variableHost),
                installation: 'Default',
                inventoryContent: ansibleInventory(variableHost),
                playbook: 'run_spark_job.yml',
                sudoUser: null,
            )
        }
    }
}

@NonCPS
def flattenListOfMaps(ArrayList jsonList) {
    def flattenedMap = [:]
    jsonList.each {
        flattenedMap << it
    }
    return flattenedMap
}

@NonCPS
def parseArtifactVersionJson(String json) {
    return new JsonSlurperClassic().parseText(json)
}