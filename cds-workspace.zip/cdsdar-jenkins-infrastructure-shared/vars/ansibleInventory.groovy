#!/usr/bin/env groovy

def call(String variableHost) {
    return """
[cdsdar]
${variableHost}

[cdsdar_application]
127.0.20.22 ansible_port=2022 ansible_host=${variableHost} ansible_user=cdsdata

[pentaho]
127.0.20.23 ansible_port=2023 ansible_host=${variableHost} ansible_user=pentaho

[cloudera_server]
127.0.20.24 ansible_port=2024 ansible_host=${variableHost} ansible_user=root

[agent1]
127.0.20.25 ansible_port=2025 ansible_host=${variableHost} ansible_user=root

[agent2]
127.0.20.26 ansible_port=2026 ansible_host=${variableHost} ansible_user=root

[agent3]
127.0.20.27 ansible_port=2027 ansible_host=${variableHost} ansible_user=root

[customs_pipeline]
127.0.20.28 ansible_port=2028 ansible_host=${variableHost} ansible_user=cdsdata
"""
}