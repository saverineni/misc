#!/usr/bin/env groovy

def call(String repository, String groupID, String artifactID) {
    def returnValue = sh(script: 'curl -H "Accept: application/json" -s "' + nexusUrlBase() + '&r=' + repository + '&g=' + groupID + '&a='+ artifactID + '" | jq -r .version', returnStdout: true).trim()
    echo "Version from Nexus '${repository}' for ${groupID}:${artifactID} = '${returnValue}'"
    return returnValue
}