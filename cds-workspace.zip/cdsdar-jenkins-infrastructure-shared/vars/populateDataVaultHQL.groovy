#!/usr/bin/env groovy
import groovy.json.JsonSlurperClassic
import static groovy.json.JsonOutput.*

def call(String environmentName, String variableHost, String cdsDataEnvironmentParam = '') {
    if (cdsDataEnvironmentParam.length() == 0) {
        cdsDataEnvironmentParam = environmentName
    }
    echo "CDS_DATA_ENVIRONMENT_PARAM set to ${cdsDataEnvironmentParam}"

    dir(env.workspaceDir + '/ansible/docker-deploy') {
        wrap([$class: 'AnsiColorBuildWrapper', colorMapName: "xterm"]) {
            ansiblePlaybook(
                colorized: true,
                credentialsId: getJenkinsDeployCredentialId(),
                extraVars: [
                    cds_data_environment_param: cdsDataEnvironmentParam,
                    environment_name: environmentName,
                    variable_host: variableHost,
                ],
                extras: '-vv',
                installation: 'Default',
                inventoryContent: ansibleInventory(variableHost),
                playbook: 'deploy.yml',
                sudoUser: null,
                tags: 'populate_data_vault_hql'
            )
        }
    }
}