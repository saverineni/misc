#!/usr/bin/env groovy

def call(String environmentName, String variableHost) {
    echo "Configuring Pentaho Mondrian Cube for '${environmentName}' database"

    dir(env.workspaceDir + '/ansible/docker-deploy') {
        wrap([$class: 'AnsiColorBuildWrapper', colorMapName: "xterm"]) {
            ansiblePlaybook(
                colorized: true,
                credentialsId: getJenkinsDeployCredentialId(),
                extraVars: [
                    environment_name: environmentName,
                    variable_host   : variableHost,
                ],
                extras: '-vv',
                installation: 'Default',
                inventoryContent: ansibleInventory(variableHost),
                playbook: 'deploy.yml',
                sudoUser: null,
                tags: 'pentaho_mondrian_cube'
            )
        }
    }
}
