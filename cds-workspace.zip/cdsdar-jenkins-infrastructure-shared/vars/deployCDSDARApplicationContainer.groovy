#!/usr/bin/env groovy

def call(String environmentName, String variableHost, String useIngestionPipelineMSSData) {
    echo "useIngestionPipelineMSSData: ${useIngestionPipelineMSSData}"
    def repositoryToUse = 'releases'

    devEnvironments = ['automationdev', 'dev', 'test']
    if (devEnvironments.contains(environmentName)) {
        repositoryToUse = 'snapshots'
    }

    echo "Environment: ${environmentName}"
    echo "Selected Nexus repository: ${repositoryToUse}"

    dir(env.workspaceDir + '/ansible/docker-deploy') {
        script {
            cdsDataCaptureServiceVersion = getLatestArtifactVersion('releases', 'uk.gov.gsi.hmrc.cds.data', 'cds-data-capture-service')
            cdsDataFlumeComponentsVersion = '1.0.15'
            cdsDataPopulationToolVersion = sh(script: 'curl -s http://10.102.104.50:9080/job/CDSDAR/job/OldPipeline/job/cds-data-population-tool-release/lastSuccessfulBuild/api/json?tree=displayName | jq -r .displayName', returnStdout: true).trim()
            customsDeclarationSearchVersion = getLatestArtifactVersion('releases', 'uk.gov.cds.dar', 'customs-declaration-search')
            declarationIngestionServiceVersion = getLatestArtifactVersion('releases', 'uk.gov.gsi.hmrc.cds.data', 'declaration-ingestion-service')
            webHarnessVersion = getLatestArtifactVersion('releases', 'uk.gov.gsi.hmrc.cds.data', 'web-harness')
        }

        wrap([$class: 'AnsiColorBuildWrapper', colorMapName: "xterm"]) {
            ansiblePlaybook(
                colorized: true,
                credentialsId: getJenkinsDeployCredentialId(),
                extraVars: [
                    cds_data_capture_service_version: cdsDataCaptureServiceVersion,
                    cds_data_flume_components_version: cdsDataFlumeComponentsVersion,
                    cds_data_population_tool_version: cdsDataPopulationToolVersion,
                    customs_declaration_search_version: customsDeclarationSearchVersion,
                    declaration_ingestion_service_version: declarationIngestionServiceVersion,
                    environment_name: environmentName,
                    use_ingestion_pipeline_mss_data: useIngestionPipelineMSSData,
                    variable_host: variableHost,
                    web_harness_version: webHarnessVersion,
                ],
                extras: getDebugExtras(environmentName, variableHost),
                installation: 'Default',
                inventoryContent: ansibleInventory(variableHost),
                playbook: 'deploy.yml',
                sudoUser: null,
                tags: 'cdsdar_application_container_infrastructure,cdsdar_application_deploy'
            )
        }
    }
}