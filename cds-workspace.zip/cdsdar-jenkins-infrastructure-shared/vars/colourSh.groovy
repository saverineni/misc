#!/usr/bin/env groovy

//def call(String cmd) {
//    ansiColor('xterm') {
//        sh "${cmd}"
//    }
//}

def call = { cmd ->
    ansiColor('xterm') {
        sh cmd
    }
}