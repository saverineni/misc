Usage:

Application Endpoint:
    http://localhost:8000/api/declaration?declarationId=670-954107X-2017-08-22

ElasticSearch Endpoint:
    http://localhost:9200/customs/declaration/_search?q=_id:670-954107X-2017-08-22