package uk.gov.gsi.hmrc.cds.search.api.resources;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.authentication.FormAuthConfig;
import com.jayway.restassured.http.ContentType;
import org.apache.http.HttpStatus;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import uk.gov.gsi.hmrc.cds.search.common.json.JsonSchemaValidator;
import uk.gov.gsi.hmrc.cds.search.run.CustomsSearchServiceApplication;
import uk.gov.gsi.hmrc.cds.search.utils.TestHelper;

import java.io.IOException;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.jayway.restassured.RestAssured.form;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertTrue;
import static uk.gov.gsi.hmrc.cds.search.utils.TestHelper.*;


@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest(
        classes = CustomsSearchServiceApplication.class,
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT
)
public class DeclarationResourceIntegrationTest {

    private WireMockServer wireMockServer;

    @Value("${local.server.port}")
    private int port;

    @Value("${elasticsearch.host}")
    private String elasticSearchHost;

    @Value("${elasticsearch.port}")
    private int elasticSearchPort;

    @Value("${elasticsearch.query.id}")
    private String elasticIdQuery;


    @Before
    public void setup() {
        RestAssured.port = this.port;
        RestAssured.authentication = form ( SUPER_USER, SUPER_USER_PASSWORD, new FormAuthConfig ( LOGIN_URL, USERNAME, PASSWORD ) );
        wireMockServer = new WireMockServer ( elasticSearchPort );
        wireMockServer.start ();

        configureFor ( elasticSearchHost, elasticSearchPort );
    }

    @After
    public void destroy() {
        wireMockServer.stop ();
    }

    @Test
    public void shouldGetErrorResponse_whenDeclarationNotFoundExceptionThrown() throws Exception {

        // BDD style , otherwise we can use stubFor
        givenThat ( get
                ( urlEqualTo
                        ( elasticIdQuery ) )
                .withHeader ( CONTENT_TYPE_FIELD, com.github.tomakehurst.wiremock.client.WireMock.equalTo ( ContentType.JSON.toString () ) )
                .withRequestBody ( equalToJson ( formatIdQuery ( INVALID_DECALARATION_ID ) ) )
                .willReturn ( aResponse ().withStatus ( 200 )
                        .withHeader ( HttpHeaders.CONTENT_TYPE, ContentType.JSON.toString () )
                        .withBody ( TestHelper.getFileContent ( INVALID_DECLARATION_FILE ) ) ) );

        RestAssured.
                given ()
                .contentType ( ContentType.JSON )
                .queryParam ( DECLARATION_ID, INVALID_DECALARATION_ID )
                .accept ( V1_DECLARATION_MEDIA_TYPE )
                .expect ()
                .body ( equalTo ( getInvalidDeclarationMessage ( INVALID_DECALARATION_ID ) ) )
                .when ()
                .get ( String.format ( "%s/declaration", API_PATH ) )
                .then ()
                .statusCode ( HttpStatus.SC_NOT_FOUND );
    }

    @Test
    public void shouldGetErrorResponseWithStatus_BAD_REQUEST_whenDeclarationIdIsMissing() throws Exception {
        RestAssured.
                given ()
                .contentType ( ContentType.JSON )
                .accept ( V1_DECLARATION_MEDIA_TYPE )
                .queryParam ( DECLARATION_ID, "" )
                .expect ()
                .body ( equalTo ( BAD_REQUEST_MESSAGE ) )
                .when ()
                .get ( String.format ( "%s/declaration", API_PATH ) )
                .then ()
                .statusCode ( HttpStatus.SC_BAD_REQUEST );
    }

    @Test
    public void givenValidDeclarationId_shouldGetV1DeclarationDataWithStatusOK() throws Exception {

        String jsonContent = TestHelper.getFileContent ( VALID_STUB_DECLARATION_FILE );
        String schemaContent = TestHelper.getFileContent ( JSON_DECLARATION_SCHEMA_FILE );

        // BDD style , otherwise we can use stubFor
        givenThat ( get
                ( urlEqualTo
                        ( elasticIdQuery ) )
                .withHeader ( CONTENT_TYPE_FIELD, com.github.tomakehurst.wiremock.client.WireMock.equalTo ( ContentType.JSON.toString () ) )
                .withRequestBody ( equalToJson ( formatIdQuery ( VALID_DECALARATION_ID ) ) )
                .willReturn ( aResponse ().withStatus ( 200 )
                        .withHeader ( HttpHeaders.CONTENT_TYPE, ContentType.JSON.toString () )
                        .withBody ( TestHelper.getFileContent ( VALID_SEARCH_DECLARATION_FILE ) ) ) );

        RestAssured
                .given ()
                .contentType ( ContentType.JSON )
                .queryParam ( DECLARATION_ID, VALID_DECALARATION_ID )
                .accept ( V1_DECLARATION_MEDIA_TYPE )
                .when ()
                .get ( String.format ( "%s/declaration", API_PATH ) )
                .then ()
                .statusCode ( HttpStatus.SC_OK )
                .body ( equalTo ( jsonContent ) );

        assertTrue ("Json declaration schema validation failed ", JsonSchemaValidator.validateJsonData ( schemaContent, jsonContent ));

    }

    @Test
    public void givenValidDeclarationId_shouldGetForbiddenStatus() throws Exception {

        RestAssured
                .given ()
                .contentType ( ContentType.JSON )
                .queryParam ( DECLARATION_ID, VALID_DECALARATION_ID )
                .accept ( V1_DECLARATION_MEDIA_TYPE )
                .when ()
                .with ()
                .auth ()
                .form ( DEV_USER, DEV_USER_PASSWORD, new FormAuthConfig ( LOGIN_URL, USERNAME, PASSWORD ) )
                .get ( String.format ( "%s/declaration", API_PATH ) )
                .then ()
                .statusCode ( HttpStatus.SC_FORBIDDEN );
    }

    @Test
    public void givenValidDeclarationId_whenESisDown_shouldGetConnectionException() throws Exception {

        final String jsonContent = TestHelper.getFileContent ( IO_EXCEPTION_FILE );
        final String schemaContent = TestHelper.getFileContent ( JSON_ERROR_SCHEMA_FILE );

        wireMockServer.stop ();

        RestAssured
                .given ()
                .contentType ( ContentType.JSON )
                .queryParam ( DECLARATION_ID, VALID_DECALARATION_ID )
                .accept ( V1_DECLARATION_MEDIA_TYPE )
                .when ()
                .get ( String.format ( "%s/declaration", API_PATH ) )
                .then ()
                .statusCode ( HttpStatus.SC_SERVICE_UNAVAILABLE )
                .body ( equalTo ( jsonContent ) );

        assertTrue ("Json error schema validation failed ", JsonSchemaValidator.validateJsonData ( schemaContent, jsonContent ));

    }

    @Test(expected = IOException.class)
    public void givenInvalidJsonSchema_shouldThrowIOException()  throws IOException , ProcessingException{
        final String jsonContent = TestHelper.getFileContent ( IO_EXCEPTION_FILE );
        JsonSchemaValidator.validateJsonData ( " ", jsonContent );
    }

    @Test(expected = ProcessingException.class)
    public void givenInvalidJsonSchema_shouldThrowProcessingException()  throws ProcessingException , IOException{
        final String jsonContent = TestHelper.getFileContent ( IO_EXCEPTION_FILE );
        final String schemaContent = TestHelper.getFileContent ( JSON_INVALID_ERROR_SCHEMA_FILE );
        JsonSchemaValidator.validateJsonData ( schemaContent, jsonContent );
    }
}