package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import com.google.common.collect.Lists;
import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.header.DeclarationHeaderResponse;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.line.DeclarationLineResponse;
import uk.gov.gsi.hmrc.cds.search.common.domain.EqualsHashCodeToString;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.Declaration;

import java.util.List;
import java.util.stream.Collectors;

@Data
@Builder
public class DeclarationResponse extends EqualsHashCodeToString {
    private DeclarationHeaderResponse header;
    private List<DeclarationLineResponse> lines = Lists.newArrayList();

    public static DeclarationResponse of(Declaration declaration) {
        // TODO null check may be
        List<DeclarationLineResponse> declarationLineResponses =
                declaration.getLines().stream().map(DeclarationLineResponse::of).collect(Collectors.toList());
        return DeclarationResponse.builder()
                .header(DeclarationHeaderResponse.of(declaration))
                .lines(declarationLineResponses)
                .build();
    }
}
