package uk.gov.gsi.hmrc.cds.search.api.dto.response.line;

import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.common.domain.EqualsHashCodeToString;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.Commodity;

@Data
@Builder
public class CommodityResponse extends EqualsHashCodeToString {
    private String commodity_code;
    private String chapter_description;
    private String heading_description;

    public static CommodityResponse of(Commodity commodity) {
        return CommodityResponse.builder()
                .commodity_code(commodity.getCommodity_code())
                .chapter_description(commodity.getChapter_description())
                .heading_description(commodity.getHeading_description())
                .build();
    }
}
