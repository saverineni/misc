package uk.gov.gsi.hmrc.cds.search.elasticsearch.domain;

import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.common.domain.EqualsHashCodeToString;

@Data
@Builder
public class Commodity  extends EqualsHashCodeToString {
    private String commodity_code;
    private String chapter_description;
    private String heading_description;
}
