package uk.gov.gsi.hmrc.cds.search.elasticsearch.domain;

import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.common.domain.EqualsHashCodeToString;

@Data
@Builder
public class OriginCountry extends EqualsHashCodeToString {
    private String iso_country_code_alpha_2;
    private String country_name;
}
