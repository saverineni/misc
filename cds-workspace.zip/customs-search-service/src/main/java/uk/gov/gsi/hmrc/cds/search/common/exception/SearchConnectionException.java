package uk.gov.gsi.hmrc.cds.search.common.exception;

public class SearchConnectionException extends RuntimeException{

    public SearchConnectionException() {
        super();
    }

    public SearchConnectionException(String message) {
        super(message);
    }

    public SearchConnectionException(String message, Throwable cause) {
        super(message, cause);
    }
}
