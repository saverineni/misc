package uk.gov.gsi.hmrc.cds.search.common.json;

import com.fasterxml.jackson.databind.JsonNode;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchemaFactory;
import com.github.fge.jsonschema.main.JsonValidator;

import java.io.IOException;

public final class JsonSchemaValidator {

    public static boolean validateJsonData(final String jsonSchema, final String jsonData) throws  IOException, ProcessingException {
            final JsonNode jsonDataNode = JsonLoader.fromString(jsonData);
            final JsonNode jsonSchemaNode = JsonLoader.fromString(jsonSchema);

            final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
            JsonValidator jsonValidator = factory.getValidator();

            ProcessingReport report = jsonValidator.validate(jsonSchemaNode, jsonDataNode);
            return report.isSuccess ();

    }

}
