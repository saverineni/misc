package uk.gov.gsi.hmrc.cds.search.api.dto.response.line;

import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.common.domain.EqualsHashCodeToString;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.OriginCountry;

@Data
@Builder
public class OriginCountryResponse extends EqualsHashCodeToString {
    private String iso_country_code_alpha_2;
    private String country_name;

    public static OriginCountryResponse of(OriginCountry originCountry) {
        return OriginCountryResponse.builder()
                .iso_country_code_alpha_2(originCountry.getIso_country_code_alpha_2 ())
                .country_name(originCountry.getCountry_name ())
                .build();
    }
}
