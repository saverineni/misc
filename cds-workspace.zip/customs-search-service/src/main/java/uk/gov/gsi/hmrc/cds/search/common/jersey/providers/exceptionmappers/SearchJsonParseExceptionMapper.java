package uk.gov.gsi.hmrc.cds.search.common.jersey.providers.exceptionmappers;

import lombok.extern.slf4j.Slf4j;
import uk.gov.gsi.hmrc.cds.search.common.domain.ErrorResponse;
import uk.gov.gsi.hmrc.cds.search.common.exception.SearchJsonParseException;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Provider
@Slf4j
public class SearchJsonParseExceptionMapper implements ExceptionMapper<SearchJsonParseException>{

    @Override
    public Response toResponse(SearchJsonParseException exception) {
        log.error(String.format("Exception occurred: %s" , exception));
        return Response.
                status(Response.Status.INTERNAL_SERVER_ERROR).
                entity(ErrorResponse.of(null, exception.getMessage())).
                build();
    }
}
