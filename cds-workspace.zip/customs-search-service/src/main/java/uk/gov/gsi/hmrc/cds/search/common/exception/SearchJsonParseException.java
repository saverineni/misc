package uk.gov.gsi.hmrc.cds.search.common.exception;

public class SearchJsonParseException extends RuntimeException {
    public SearchJsonParseException(String s) {
        super(s);
    }

    public SearchJsonParseException(String s, Exception e) {
        super(s, e);
    }
}
