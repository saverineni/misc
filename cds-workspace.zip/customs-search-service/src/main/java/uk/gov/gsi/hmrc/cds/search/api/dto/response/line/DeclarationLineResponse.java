package uk.gov.gsi.hmrc.cds.search.api.dto.response.line;

import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.common.domain.EqualsHashCodeToString;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.DeclarationLine;

@Data
@Builder
public class DeclarationLineResponse extends EqualsHashCodeToString {
    private String entry_reference;
    private String item_number;
    private String clearance_datetime;
    private OriginCountryResponse origin_country;
    private String customs_procedure_code;
    private CommodityResponse commodity;

    public static DeclarationLineResponse of(DeclarationLine declarationLine) {
        return DeclarationLineResponse.builder()
                .entry_reference(declarationLine.getEntry_reference())
                .item_number(declarationLine.getItem_number())
                .clearance_datetime(declarationLine.getClearance_datetime())
                .origin_country(OriginCountryResponse.of(declarationLine.getOriginCountry ()))
                .customs_procedure_code(declarationLine.getCustomsProcedureCode ().getCustoms_procedure_code ())
                .commodity(CommodityResponse.of(declarationLine.getCommodity()))
                .build();
    }
}
