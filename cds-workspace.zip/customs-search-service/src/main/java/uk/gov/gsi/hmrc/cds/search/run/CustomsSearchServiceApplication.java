package uk.gov.gsi.hmrc.cds.search.run;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;

@SpringBootApplication(
		scanBasePackages = {
				"uk.gov.gsi.hmrc.cds.search.config",
				"uk.gov.gsi.hmrc.cds.search.security",
				"uk.gov.gsi.hmrc.cds.search.common.jersey.providers",
				"uk.gov.gsi.hmrc.cds.search.api.resources",
				"uk.gov.gsi.hmrc.cds.search.api.services",
				"uk.gov.gsi.hmrc.cds.search.elasticsearch.connection",
				"uk.gov.gsi.hmrc.cds.search.elasticsearch.service"
		}
)
public class CustomsSearchServiceApplication extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		return builder.sources(CustomsSearchServiceApplication.class);
	}

	public static void main(String[] args) {
		SpringApplication.run(CustomsSearchServiceApplication.class, args);
	}
}
