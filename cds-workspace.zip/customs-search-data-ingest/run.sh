#!/usr/bin/env bash

clear

printf '********Deleting any existing data********\n'
hdfs dfs -rmr /user/osboxes/spark/dv_v3/dv

printf '\n\n********Creating folder (/user/osboxes/spark/dv_v3/dv)********\n'
hdfs dfs -mkdir -p /user/osboxes/spark/dv_v3/dv

APPLICATION_VERSION=$(grep -m1 '<version>' ${WORKSPACE}/customs-search-data-ingest/pom.xml | cut -c11- | rev | cut -d"<" -f2  | rev)

printf '\n\n********Copying test data********\n'
hdfs dfs -copyFromLocal ${WORKSPACE}/customs-search-data-ingest/src/test/resources/dv/* /user/osboxes/spark/dv_v3/dv

printf '\n\n********Maven packaging the aplication********\n'
mvn clean package -DskipTests=true

printf '\n\n********Running spark submit process********\n'
spark-submit ${WORKSPACE}/customs-search-data-ingest/target/customs-search-data-ingest-$APPLICATION_VERSION.jar