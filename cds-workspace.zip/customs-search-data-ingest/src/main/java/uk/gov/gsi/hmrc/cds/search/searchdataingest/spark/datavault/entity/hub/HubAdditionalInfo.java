package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import scala.collection.mutable.Seq;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;

@Data
@Builder
public class HubAdditionalInfo implements Serializable, BaseEntity {

    private String hub_additional_info_key;
    private String entry_reference;
    private String item_number;
    private String additional_information_sequence_number;
    private String hub_load_datetime;
    private String hub_record_source;

    public static HubAdditionalInfo mapper(String line) {
        List<String> columns = parseLine(line);

        return HubAdditionalInfo.builder()
                .hub_additional_info_key(columns.get(0))
                .entry_reference(columns.get(1))
                .item_number(columns.get(2))
                .additional_information_sequence_number(columns.get(3))
                .hub_load_datetime(columns.get(4))
                .hub_record_source(columns.get(5))
                .build();
    }

    public static final String PRIMARY_COLUMN = "hub_additional_info_key";
    public static final String INFO_SEQUENCE_NUMBER_COLUMN = "additional_information_sequence_number";

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            INFO_SEQUENCE_NUMBER_COLUMN
    );

    public static Seq<String> joinColumns = joinExpression(PRIMARY_COLUMN);

}
