package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;

@Data
@Builder
public class LinkDeclarationTransportCountry implements Serializable, BaseEntity {

    private String link_declaration_transport_country_key;
    private String hub_declaration_key;
    private String hub_country_key;
    private String entry_reference;
    private String iso_country_code_alpha_2;
    private String link_load_datetime;
    private String link_record_source;

    public static LinkDeclarationTransportCountry mapper(String line) {
        List<String> columns = parseLine(line);

        return LinkDeclarationTransportCountry.builder()
                .link_declaration_transport_country_key(columns.get(0))
                .hub_declaration_key(columns.get(1))
                .hub_country_key(columns.get(2))
                .entry_reference(columns.get(3))
                .iso_country_code_alpha_2(columns.get(4))
                .link_load_datetime(columns.get(5))
                .link_record_source(columns.get(6))
                .build();
    }

    public static final String PRIMARY_COLUMN = "link_declaration_transport_country_key";
    public static final String COUNTRY_ISO_CODE = "iso_country_code_alpha_2";

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            "hub_country_key",
            "hub_declaration_key"
    );
}
