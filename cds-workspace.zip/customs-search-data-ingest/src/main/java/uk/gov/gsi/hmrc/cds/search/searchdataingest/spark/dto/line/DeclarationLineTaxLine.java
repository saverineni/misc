package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;


@Data
public class DeclarationLineTaxLine implements Serializable {

    public static final Encoder<DeclarationLineTaxLine> declarationLineTaxLineEncoder = Encoders.bean(DeclarationLineTaxLine.class);

    private String hub_tax_line_key;
    private String tax_line_sequence_number;
    private String sat_tax_line_generation_number;
    private String waived_tax;
    private String method_of_payment_code;
    private String tax_amount;
    private String tax_type_code;

    public static final String GENERATION_NUMBER = "sat_tax_line_generation_number";
}
