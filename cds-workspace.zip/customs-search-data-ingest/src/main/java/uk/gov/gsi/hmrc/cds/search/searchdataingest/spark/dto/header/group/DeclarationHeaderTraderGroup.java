package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.consignor.ConsignorTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.declarant.DeclarantTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.exporter.ExporterTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.importer.ImporterTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.payingagent.PayingAgentTrader;

import java.io.Serializable;

@Data
public class DeclarationHeaderTraderGroup  implements Serializable {
    public static Encoder<DeclarationHeaderTraderGroup> declarationHeaderTraderGroupEncoder = Encoders.bean(DeclarationHeaderTraderGroup.class);

    private String hub_declaration_key;
    private ImporterTrader importerTrader;
    private ExporterTrader exporterTrader;
    private DeclarantTrader declarantTrader;
    private PayingAgentTrader payingAgentTrader;
    private ConsignorTrader consignorTrader;
}
