package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationTransportCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.LINK_DECLARATION_TRANSPORT_COUNTRY;

@Component
public class LinkDeclarationTransportCountryReader extends DataVaultReader {
    private static final Encoder<LinkDeclarationTransportCountry> linkDeclarationTransportCountryEncoder = Encoders.bean(LinkDeclarationTransportCountry.class);

    public Dataset<LinkDeclarationTransportCountry> linkDeclarationTransportCountryDataset() {
        String dataFilePath = String.format("%s/%s", LINK_DECLARATION_TRANSPORT_COUNTRY.tableName(), datafileRelativePath);
        String linkDeclarationTransportCountryFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<LinkDeclarationTransportCountry> linkDeclarationTransportCountryJavaRDD = sparkSession
                .read()
                .textFile(linkDeclarationTransportCountryFilePath)
                .javaRDD()
                .map((Function<String, LinkDeclarationTransportCountry>) LinkDeclarationTransportCountry::mapper)
                .cache();

        return sparkSession
                .createDataFrame(linkDeclarationTransportCountryJavaRDD, LinkDeclarationTransportCountry.class)
                .as(linkDeclarationTransportCountryEncoder)
                .cache();
    }

}
