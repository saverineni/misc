package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineOriginCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.LINK_DECLARATION_LINE_ORIGIN_COUNTRY;

@Component
public class LinkDeclarationLineOriginCountryReader extends DataVaultReader {
    private static final Encoder<LinkDeclarationLineOriginCountry> linkDeclarationLineOriginCountryEncoder = Encoders.bean(LinkDeclarationLineOriginCountry.class);

    public Dataset linkDeclarationLineOriginCountryDataset() {
        String dataFilePath = String.format("%s/%s", LINK_DECLARATION_LINE_ORIGIN_COUNTRY.tableName(), datafileRelativePath);
        String linkDeclarationLineOriginCountryFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<LinkDeclarationLineOriginCountry> linkDeclarationLineOriginCountryJavaRDD = sparkSession
                .read()
                .textFile(linkDeclarationLineOriginCountryFilePath)
                .javaRDD()
                .map((Function<String, LinkDeclarationLineOriginCountry>) LinkDeclarationLineOriginCountry::mapper)
                .cache();

        return sparkSession
                .createDataFrame(linkDeclarationLineOriginCountryJavaRDD, LinkDeclarationLineOriginCountry.class)
                .as(linkDeclarationLineOriginCountryEncoder)
                .cache();
    }

}
