package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatDeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.SAT_DECLARATION_LINE;

@Component
public class SatDeclarationLineReader extends DataVaultReader {
    private static final Encoder<SatDeclarationLine> satDeclarationLineEncoder = Encoders.bean(SatDeclarationLine.class);

    public Dataset<SatDeclarationLine> satDeclarationLineDataset() {
        String dataFilePath = String.format("%s/%s", SAT_DECLARATION_LINE.tableName(), datafileRelativePath);
        String satDeclarationLineFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<SatDeclarationLine> satDeclarationLineJavaRDD = sparkSession
                .read()
                .textFile(satDeclarationLineFilePath)
                .javaRDD()
                .map((Function<String, SatDeclarationLine>) SatDeclarationLine::mapper)
                .cache();

        return sparkSession
                .createDataFrame(satDeclarationLineJavaRDD, SatDeclarationLine.class)
                .as(satDeclarationLineEncoder)
                .cache();
    }

}
