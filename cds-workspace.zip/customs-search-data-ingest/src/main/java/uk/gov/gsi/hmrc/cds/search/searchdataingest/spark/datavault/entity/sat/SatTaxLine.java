package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;

@Data
@Builder
public class SatTaxLine implements Serializable, BaseEntity {

    private String hub_tax_line_key;
    private String sat_hash_diff;
    private String sat_load_datetime;
    private String sat_load_end_datetime;
    private String sat_record_source;
    private String generation_number;
    private String waived_tax;
    private String method_of_payment_code;
    private String tax_amount;
    private String tax_type_code;

    public static SatTaxLine mapper(String line) {
        List<String> columns = parseLine(line);

        return SatTaxLine.builder()
                .hub_tax_line_key(columns.get(0))
                .sat_hash_diff(columns.get(1))
                .sat_load_datetime(columns.get(2))
                .sat_load_end_datetime(columns.get(3))
                .sat_record_source(columns.get(4))
                .generation_number(columns.get(5))
                .waived_tax(columns.get(6))
                .method_of_payment_code(columns.get(7))
                .tax_amount(columns.get(8))
                .tax_type_code(columns.get(9))
                .build();
    }

    public static final String GENERATION_NUMBER_COLUMN = "generation_number";
    public static final String WAIVED_TAX_COLUMN = "waived_tax";
    public static final String PAYMENT_METHOD_CODE_COLUMN = "method_of_payment_code";
    public static final String TAX_AMOUNT_COLUMN = "tax_amount";
    public static final String TAX_TYPE_CODE_COLUMN = "tax_type_code";

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            WAIVED_TAX_COLUMN,
            PAYMENT_METHOD_CODE_COLUMN,
            TAX_AMOUNT_COLUMN,
            TAX_TYPE_CODE_COLUMN
    );
}
