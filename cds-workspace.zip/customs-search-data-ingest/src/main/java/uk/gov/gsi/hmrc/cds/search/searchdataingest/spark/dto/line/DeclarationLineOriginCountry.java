package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line;

import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;

@Data
@Builder
public class DeclarationLineOriginCountry implements Serializable {

    public static final Encoder<DeclarationLineOriginCountryBuilderGroup> declarationLineOriginCountryBuilderGroupEncoder = Encoders.bean(DeclarationLineOriginCountryBuilderGroup.class);

    private String iso_country_code_alpha_2;
    private String country_name;

    public static final String ISO_COUNTRY_CODE = "origin_iso_country_code_alpha_2";

    @Data
    public static class DeclarationLineOriginCountryBuilderGroup implements Serializable {
        private String hub_declaration_line_key;
        private String origin_iso_country_code_alpha_2;
    }

}
