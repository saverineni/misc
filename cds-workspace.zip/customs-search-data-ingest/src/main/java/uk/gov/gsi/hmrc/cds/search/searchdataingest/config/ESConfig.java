package uk.gov.gsi.hmrc.cds.search.searchdataingest.config;

public interface ESConfig {
    String MAPPING_ID_KEY = "es.mapping.id";
}
