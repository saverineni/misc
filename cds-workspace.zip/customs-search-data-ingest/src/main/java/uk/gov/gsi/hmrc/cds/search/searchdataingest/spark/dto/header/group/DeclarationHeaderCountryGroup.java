package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;

@Data
public class DeclarationHeaderCountryGroup implements Serializable {

    public static Encoder<DeclarationHeaderCountryGroup> declarationHeaderCountryGroupEncoder = Encoders.bean(DeclarationHeaderCountryGroup.class);
    private String hub_declaration_key;
    private String destination_iso_country_code_alpha_2;
    private String transport_iso_country_code_alpha_2;

}
