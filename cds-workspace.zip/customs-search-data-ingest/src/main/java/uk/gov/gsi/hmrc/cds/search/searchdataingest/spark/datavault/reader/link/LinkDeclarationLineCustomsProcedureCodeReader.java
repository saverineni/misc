package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineCustomsProcedureCode;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.LINK_DECLARATION_LINE_CUSTOMS_PROCEDURE_CODE;

@Component
public class LinkDeclarationLineCustomsProcedureCodeReader extends DataVaultReader {
    private static final Encoder<LinkDeclarationLineCustomsProcedureCode> linkDeclarationLineCustomsProcedureCodeEncoder = Encoders.bean(LinkDeclarationLineCustomsProcedureCode.class);

    public Dataset linkDeclarationLineCustomsProcedureCodeDataset() {
        String dataFilePath = String.format("%s/%s", LINK_DECLARATION_LINE_CUSTOMS_PROCEDURE_CODE.tableName(), datafileRelativePath);
        String linkDeclarationLineCustomsProcedureCodeFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<LinkDeclarationLineCustomsProcedureCode> linkDeclarationLineCustomsProcedureCodeJavaRDD = sparkSession
                .read()
                .textFile(linkDeclarationLineCustomsProcedureCodeFilePath)
                .javaRDD()
                .map((Function<String, LinkDeclarationLineCustomsProcedureCode>) LinkDeclarationLineCustomsProcedureCode::mapper)
                .cache();

        return sparkSession
                .createDataFrame(linkDeclarationLineCustomsProcedureCodeJavaRDD, LinkDeclarationLineCustomsProcedureCode.class)
                .as(linkDeclarationLineCustomsProcedureCodeEncoder)
                .cache();
    }

}
