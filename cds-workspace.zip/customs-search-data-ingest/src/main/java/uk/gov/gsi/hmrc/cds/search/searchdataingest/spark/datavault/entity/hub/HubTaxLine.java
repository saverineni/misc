package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import scala.collection.mutable.Seq;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;

@Data
@Builder
public class HubTaxLine implements Serializable, BaseEntity {

    private String hub_tax_line_key;
    private String entry_reference;
    private String item_number;
    private String tax_line_sequence_number;
    private String hub_load_datetime;
    private String hub_record_source;

    public static HubTaxLine mapper(String line) {
        List<String> columns = parseLine(line);

        return HubTaxLine.builder()
                .hub_tax_line_key(columns.get(0))
                .entry_reference(columns.get(1))
                .item_number(columns.get(2))
                .tax_line_sequence_number(columns.get(3))
                .hub_load_datetime(columns.get(4))
                .hub_record_source(columns.get(5))
                .build();
    }

    public static final String PRIMARY_COLUMN = "hub_tax_line_key";
    public static final String TAX_LINE_SEQUENCE_NUMBER = "tax_line_sequence_number";

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            TAX_LINE_SEQUENCE_NUMBER
    );

    public static Seq<String> joinColumns = joinExpression(PRIMARY_COLUMN);

}
