package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line.group;

import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line.DeclarationLineCPCDataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line.DeclarationLineCommodityDataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line.DeclarationLineImporterTraderDataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line.DeclarationLineOriginCountryDataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatDeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatDeclarationLineReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.importer.ImporterTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.*;

import static org.apache.spark.sql.functions.broadcast;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationCustomsProcedureCode.DeclarationCustomsProcedureCodeGroup;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLineCommodity.DeclarationLineCommodityGroup;

@Component
public class DeclarationLineGroupDataset {

    private static final String LEFT_OUTER_JOIN = "left_outer";

    private final DeclarationLineDocumentGroupDataset lineDocumentGroupDataset;
    private final DeclarationLineTaxLineGroupDataset lineTaxLineGroupDataset;
    private final DeclarationLineAdditionalInfoGroupDataset lineAdditionalInfoGroupDataset;
    private final DeclarationLinePreviousDocumentGroupDataset linePreviousDocumentGroupDataset;
    private final DeclarationLineCommodityDataset declarationLineCommodityDataset;
    private final DeclarationLineCPCDataset declarationLineCPCDataset;
    private final DeclarationLineOriginCountryDataset declarationLineOriginCountryDataset;
    private final DeclarationLineImporterTraderDataset declarationLineImporterTraderDataset;
    private final SatDeclarationLineReader satDeclarationLineReader;

    @Autowired
    public DeclarationLineGroupDataset(SatDeclarationLineReader satDeclarationLineReader,DeclarationLineImporterTraderDataset declarationLineImporterTraderDataset,DeclarationLineOriginCountryDataset declarationLineOriginCountryDataset,
                                       DeclarationLineCPCDataset declarationLineCPCDataset,DeclarationLineCommodityDataset declarationLineCommodityDataset,DeclarationLinePreviousDocumentGroupDataset linePreviousDocumentGroupDataset,
                                       DeclarationLineAdditionalInfoGroupDataset lineAdditionalInfoGroupDataset,DeclarationLineTaxLineGroupDataset lineTaxLineGroupDataset,DeclarationLineDocumentGroupDataset lineDocumentGroupDataset) {

        this.satDeclarationLineReader = satDeclarationLineReader;
        this.declarationLineImporterTraderDataset = declarationLineImporterTraderDataset;
        this.declarationLineOriginCountryDataset = declarationLineOriginCountryDataset;
        this.declarationLineCPCDataset = declarationLineCPCDataset;
        this.declarationLineCommodityDataset = declarationLineCommodityDataset;
        this.linePreviousDocumentGroupDataset = linePreviousDocumentGroupDataset;
        this.lineAdditionalInfoGroupDataset = lineAdditionalInfoGroupDataset;
        this.lineTaxLineGroupDataset = lineTaxLineGroupDataset;
        this.lineDocumentGroupDataset = lineDocumentGroupDataset;

    }

    public Dataset<DeclarationLineGroup> build() {
        Dataset<DeclarationLineDocumentGroup> declarationLineDocumentGroupDataset = lineDocumentGroupDataset.build();
        Dataset<DeclarationLineTaxLineGroup> declarationLineTaxLineGroupDataset = lineTaxLineGroupDataset.build();
        Dataset<DeclarationLineAdditionalInfoGroup> declarationLineAdditionalInfoGroupDataset = lineAdditionalInfoGroupDataset.build();
        Dataset<DeclarationLinePreviousDocumentGroup> declarationLinePreviousDocumentGroupDataset = linePreviousDocumentGroupDataset.build();

        Dataset<SatDeclarationLine> satDeclarationLineDataset = satDeclarationLineReader.satDeclarationLineDataset();
        Dataset<DeclarationLineCommodityGroup> declarationLineCommodityGroupDataset = declarationLineCommodityDataset.build();
        Dataset<DeclarationCustomsProcedureCodeGroup> declarationCustomsProcedureCodeGroupDataset = declarationLineCPCDataset.build();
        Dataset<DeclarationLineOriginCountryGroup> declarationLineOriginCountryGroupDataset = declarationLineOriginCountryDataset.build();
        Dataset<ImporterTrader.LineImporterTrader> declarationLineImporterTraderGroupDataset = declarationLineImporterTraderDataset.build();

        Dataset<DeclarationLineGroup> declarationLineGroupDataset = satDeclarationLineDataset
                .join(declarationLineDocumentGroupDataset, HubDeclarationLine.joinColumns, LEFT_OUTER_JOIN)
                .join(declarationLineTaxLineGroupDataset, HubDeclarationLine.joinColumns, LEFT_OUTER_JOIN)
                .join(declarationLineAdditionalInfoGroupDataset, HubDeclarationLine.joinColumns, LEFT_OUTER_JOIN)
                .join(declarationLinePreviousDocumentGroupDataset, HubDeclarationLine.joinColumns, LEFT_OUTER_JOIN)
                .join(broadcast(declarationLineCommodityGroupDataset), HubDeclarationLine.joinColumns, LEFT_OUTER_JOIN)
                .join(broadcast(declarationCustomsProcedureCodeGroupDataset), HubDeclarationLine.joinColumns, LEFT_OUTER_JOIN)
                .join(broadcast(declarationLineOriginCountryGroupDataset), HubDeclarationLine.joinColumns, LEFT_OUTER_JOIN)
                .join(broadcast(declarationLineImporterTraderGroupDataset), HubDeclarationLine.joinColumns, LEFT_OUTER_JOIN)
                .as(DeclarationLineGroup.declarationLineGroupEncoder);

        declarationLineDocumentGroupDataset.unpersist();
        declarationLineTaxLineGroupDataset.unpersist();
        declarationLineAdditionalInfoGroupDataset.unpersist();
        declarationLinePreviousDocumentGroupDataset.unpersist();
        declarationLineCommodityGroupDataset.unpersist();
        declarationCustomsProcedureCodeGroupDataset.unpersist();
        declarationLineOriginCountryGroupDataset.unpersist();
        declarationLineImporterTraderGroupDataset.unpersist();

        return declarationLineGroupDataset;
    }
}
