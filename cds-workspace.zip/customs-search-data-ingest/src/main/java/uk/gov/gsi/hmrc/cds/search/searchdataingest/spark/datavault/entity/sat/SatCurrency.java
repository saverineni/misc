package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.valueAt;

@Data
@Builder
public class SatCurrency implements Serializable, BaseEntity {
    private String hub_currency_key;
    private String sat_hash_diff;
    private String sat_load_datetime;
    private String sat_load_end_datetime;
    private String sat_record_source;
    private String currency_name;

    public static SatCurrency mapper(String line) {
        List<String> columns = parseLine(line);
        return SatCurrency.builder()
                .hub_currency_key(valueAt(columns,0))
                .sat_hash_diff(columns.get(1))
                .sat_load_datetime(columns.get(2))
                .sat_load_end_datetime(columns.get(3))
                .sat_record_source(columns.get(4))
                .currency_name(columns.get(5))
                .build();
    }

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            "currency_name"
    );
}
