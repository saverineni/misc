package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;

@Data
public class DeclarationHeaderTrader implements Serializable {
    public static Encoder<DeclarationHeaderTrader> headerTraderEncoder = Encoders.bean(DeclarationHeaderTrader.class);
    private String hub_declaration_key;
    private String hub_trader_key;
    private String turn;

}
