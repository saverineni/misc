package uk.gov.gsi.hmrc.cds.search.searchdataingest.run;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.elasticsearch.ESIngester;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SearchDocumentJob;

import javax.annotation.PostConstruct;

// 5AL8iuJwWj

@SpringBootApplication
@ComponentScan(basePackages = {
		"uk.gov.gsi.hmrc.cds.search.searchdataingest"
})
@EnableScheduling
public class SearchDataIngestApplication {

	@Autowired
	private SearchDocumentJob searchDocumentJob;

	@Autowired
	private ESIngester esIngester;

	public static void main(String[] args) {
		SpringApplication.run(SearchDataIngestApplication.class, args).close();
	}

	@PostConstruct
	public void triggerDVReader() {
//		searchDocumentJob.declarationDocument();
		esIngester.ingest();
	}
}
