package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;

@Data
public class DeclarationLineCommodity implements Serializable {

    public static final Encoder<DeclarationLineCommodityGroup> declarationLineCommodityEncoder = Encoders.bean(DeclarationLineCommodityGroup.class);

    private String hub_commodity_key;
    private String commodity_code;
    private String cc_year;
    private String cc_month;
    private String hs_chapter;
    private String hs_heading;
    private String hs_chapter_heading;
    private String hs_subheading;
    private String chapter_description;
    private String heading_description;
    private String subheading_description;

    public static final String ALIAS = "commodity";

    @Data
    public static class DeclarationLineCommodityGroup implements Serializable{
        private String hub_declaration_line_key;
        private DeclarationLineCommodity commodity;
    }

}
