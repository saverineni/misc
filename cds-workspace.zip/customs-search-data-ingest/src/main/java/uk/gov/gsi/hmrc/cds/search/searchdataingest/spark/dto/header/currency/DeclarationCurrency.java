package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.currency;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;


@Data
@Builder
public class DeclarationCurrency implements Serializable {
    private DeclarationFreightCurrency freightCurrency;
    private DeclarationInvoiceCurrency invoiceCurrency;

    public static final String DECLARATION_CURRENCY_COLUMN = "declarationCurrency";

}
