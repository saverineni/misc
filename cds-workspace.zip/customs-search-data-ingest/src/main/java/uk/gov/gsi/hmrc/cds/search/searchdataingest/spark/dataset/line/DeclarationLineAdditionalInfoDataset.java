package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubAdditionalInfo;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatAdditionalInfo;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationLineAdditionalInfoReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatAdditionalInfoReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLineAdditionalInfo;

@Component
public class DeclarationLineAdditionalInfoDataset {
    private static final String DECLARATION_LINE_KEY = HubDeclarationLine.PRIMARY_COLUMN;

    private static String[] datasetColumns = Iterables.toArray(
            Iterables.concat(
                    Lists.newArrayList(HubAdditionalInfo.PRIMARY_COLUMN),
                    HubAdditionalInfo.SELECT_COLUMNS,
                    Lists.newArrayList(
                            DeclarationLineAdditionalInfo.GENERATION_NUMBER,
                            SatAdditionalInfo.INFO_STATEMENT_COLUMN,
                            SatAdditionalInfo.INFO_STATEMENT_TYPE_COLUMN,
                            SatAdditionalInfo.ITEM_INFO_STATEMENT_COLUMN
                    )
            )
            , String.class);


    private final SatAdditionalInfoReader satAdditionalInfoReader;
    private final LinkDeclarationLineAdditionalInfoReader linkDeclarationLineAdditionalInfoReader;

    @Autowired
    public DeclarationLineAdditionalInfoDataset(SatAdditionalInfoReader satAdditionalInfoReader,LinkDeclarationLineAdditionalInfoReader linkDeclarationLineAdditionalInfoReader) {
        this.satAdditionalInfoReader = satAdditionalInfoReader;
        this.linkDeclarationLineAdditionalInfoReader = linkDeclarationLineAdditionalInfoReader;
    }

    public Dataset<DeclarationLineAdditionalInfo> build() {

        Dataset linkDeclarationLineAdditionalInfoDataset = linkDeclarationLineAdditionalInfoReader.linkDeclarationLineAdditionalInfoDataset();
        Dataset<SatAdditionalInfo> satAdditionalInfoDataset = satAdditionalInfoReader.satAdditionalInfoDataset();
        Dataset<DeclarationLineAdditionalInfo> declarationLineAdditionalInfo = linkDeclarationLineAdditionalInfoDataset
                .join(satAdditionalInfoDataset, HubAdditionalInfo.joinColumns)
                .withColumnRenamed(SatAdditionalInfo.GENERATION_NUMBER_COLUMN, DeclarationLineAdditionalInfo.GENERATION_NUMBER)
                .select(DECLARATION_LINE_KEY, datasetColumns)
                .as(DeclarationLineAdditionalInfo.declarationLineAdditionalInfoEncoder)
                .cache();

        linkDeclarationLineAdditionalInfoDataset.unpersist();
        satAdditionalInfoDataset.unpersist();

        return declarationLineAdditionalInfo;
    }
}
