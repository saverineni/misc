package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group;

import com.google.common.collect.Lists;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLineTaxLine;

import java.io.Serializable;
import java.util.List;


@Data
public class DeclarationLineTaxLineGroup implements Serializable {

    public static final Encoder<DeclarationLineTaxLineGroup> declarationLineTaxLineGroupEncoder = Encoders.bean(DeclarationLineTaxLineGroup.class);

    private String hub_declaration_line_key;
    private List<DeclarationLineTaxLine> taxLines = Lists.newArrayList();

    public static final String ALIAS = "taxLines";
}
