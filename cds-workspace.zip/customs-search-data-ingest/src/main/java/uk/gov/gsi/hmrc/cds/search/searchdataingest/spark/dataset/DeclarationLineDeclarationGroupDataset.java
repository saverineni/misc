package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.functions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line.group.DeclarationLineGroupDataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineDeclaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationLineDeclarationReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.DeclarationLineDeclarationGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLineGroup;

@Component
public class DeclarationLineDeclarationGroupDataset {

    private static final String LEFT_OUTER_JOIN = "left_outer";

    private static String[] selectColumns = Iterables.toArray(
            Iterables.concat(
                    Lists.newArrayList(HubDeclarationLine.PRIMARY_COLUMN),
                    HubDeclarationLine.SELECT_COLUMNS,
                    DeclarationLine.columnNames
            )
            , String.class);
    private static Column[] lineColumns= Iterables.toArray(
            Iterables.concat(
                    Lists.newArrayList(
                            functions.column(HubDeclarationLine.PRIMARY_COLUMN)
                    ),
                    DeclarationLine.columns
            )
            , Column.class);


    private final LinkDeclarationLineDeclarationReader linkDeclarationLineDeclarationReader;
    private final DeclarationLineGroupDataset declarationLineGroupDataset;

    @Autowired
    public DeclarationLineDeclarationGroupDataset(LinkDeclarationLineDeclarationReader linkDeclarationLineDeclarationReader,DeclarationLineGroupDataset declarationLineGroupDataset){
        this.linkDeclarationLineDeclarationReader = linkDeclarationLineDeclarationReader;
        this.declarationLineGroupDataset = declarationLineGroupDataset;
    }

    public Dataset<DeclarationLineDeclarationGroup> build() {
        Dataset<LinkDeclarationLineDeclaration> linkDeclarationLineDeclarationDataset = linkDeclarationLineDeclarationReader.linkDeclarationLineDeclarationDataset();
        Dataset<DeclarationLineGroup> declarationLineGroupDataset = this.declarationLineGroupDataset.build();

        Dataset<DeclarationLineDeclarationGroup> declarationLineDeclarationGroupDataset = linkDeclarationLineDeclarationDataset
                .join(declarationLineGroupDataset, HubDeclarationLine.joinColumns, LEFT_OUTER_JOIN)
                .select(
                        HubDeclaration.PRIMARY_COLUMN,
                        selectColumns
                )
                .groupBy(HubDeclaration.PRIMARY_COLUMN, HubDeclaration.ENTRY_REFERENCE)
                .agg(
                        functions.collect_list(
                                functions.struct(
                                        lineColumns
                                )
                        ).alias(DeclarationLineDeclarationGroup.ALIAS)
                )
                .as(DeclarationLineDeclarationGroup.declarationLineDeclarationGroupEncoder);

        linkDeclarationLineDeclarationDataset.unpersist();
        declarationLineGroupDataset.unpersist();

        return declarationLineDeclarationGroupDataset;
    }
}
