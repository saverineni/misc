package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatTaxLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.SAT_TAX_LINE;

@Component
public class SatTaxLineReader extends DataVaultReader {
    private static final Encoder<SatTaxLine> satTaxLineEncoder = Encoders.bean(SatTaxLine.class);

    public Dataset<SatTaxLine> satTaxLineDataset() {
        String dataFilePath = String.format("%s/%s", SAT_TAX_LINE.tableName(), datafileRelativePath);
        String satTaxLineFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<SatTaxLine> satTaxLineJavaRDD = sparkSession
                .read()
                .textFile(satTaxLineFilePath)
                .javaRDD()
                .map((Function<String, SatTaxLine>) SatTaxLine::mapper)
                .cache();

        return sparkSession
                .createDataFrame(satTaxLineJavaRDD, SatTaxLine.class)
                .as(satTaxLineEncoder)
                .cache();
    }

}
