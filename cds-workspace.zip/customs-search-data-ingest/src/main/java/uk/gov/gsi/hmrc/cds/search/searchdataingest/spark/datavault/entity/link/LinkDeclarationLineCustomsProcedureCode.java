package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;

@Data
@Builder
public class LinkDeclarationLineCustomsProcedureCode implements Serializable, BaseEntity {

    private String link_declaration_line_customs_procedure_code_key;
    private String hub_declaration_line_key;
    private String hub_customs_procedure_code_key;
    private String entry_reference;
    private String item_number;
    private String customs_procedure_code;
    private String link_load_datetime;
    private String link_record_source;

    public static LinkDeclarationLineCustomsProcedureCode mapper(String line) {
        List<String> columns = parseLine(line);

        return LinkDeclarationLineCustomsProcedureCode.builder()
                .link_declaration_line_customs_procedure_code_key(columns.get(0))
                .hub_declaration_line_key(columns.get(1))
                .hub_customs_procedure_code_key(columns.get(2))
                .entry_reference(columns.get(3))
                .item_number(columns.get(4))
                .customs_procedure_code(columns.get(5))
                .link_load_datetime(columns.get(6))
                .link_record_source(columns.get(7))
                .build();
    }

    public static final String PRIMARY_COLUMN = "link_declaration_line_customs_procedure_code_key";

    public static final String CPC_COLUMN = "customs_procedure_code";

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            "hub_customs_procedure_code_key",
            "hub_declaration_line_key"
    );


}
