package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.country.DeclarationCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.currency.DeclarationCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.DeclarationTrader;

import java.io.Serializable;

@Data
public class DeclarationHeader implements Serializable {
    public static Encoder<DeclarationHeader> declarationHeaderEncoder = Encoders.bean(DeclarationHeader.class);

    private String hub_declaration_key;
    private String entry_number;
    private String entry_date;
    private String epu_number;
    private String entry_type;
    private String declaration_method;
    private String total_excise;
    private String declarant_representative_turn;
    private String consignee_aeo_certificate_type_code;
    private String declarant_aeo_certificate_type_code;
    private String route;
    private String declaration_import_export_indicator;
    private String generation_number;
    private String import_clearance_status;
    private String consignor_aeo_certificate_type_code;
    private String header_statistical_value;
    private String goods_departure_datetime;
    private String customs_value;
    private String total_duty;
    private String total_vat;
    private String net_mass_total;
    private String goods_location;
    private String acceptance_date;
    private String importer_turn_country_code;
    private String place_of_unloading_code;
    private String first_deferment_approval_num;
    private String first_deferment_approval_num_prefix;
    private String declaration_ucr;
    private String item_count;
    private String master_ucr;
    private String paying_agent_turn;
    private String place_of_loading_code;
    private String session_num;
    private String session_role_name;
    private String status_of_entry;
    private String transport_country;
    private String transport_id;
    private String transport_mode_code;
    private String dispatch_country;
    private String consignor_turn_country_code;
    private String consignor_nad_name;
    private String consignee_nad_name;
    private String consignee_nad_postcode;
    private String declarant_nad_name;
    private String customs_check_code;
    private String profile_id;
    private String invoice_total_declared;
    private DeclarationCurrency declarationCurrency;
    private DeclarationTrader declarationTrader;
    private DeclarationCountry declarationCountry;
}
