package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Column;
import scala.collection.mutable.Seq;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static org.apache.spark.sql.functions.column;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;

@Data
@Builder
public class HubCommodity implements Serializable, BaseEntity {

    private String hub_commodity_key;
    private String commodity_code;
    private String hub_load_datetime;
    private String hub_record_source;

    public static HubCommodity mapper(String line) {
        List<String> columns = parseLine(line);

        return HubCommodity.builder()
                .hub_commodity_key(columns.get(0))
                .commodity_code(columns.get(1))
                .hub_load_datetime(columns.get(2))
                .hub_record_source(columns.get(3))
                .build();
    }

    public static final String PRIMARY_COLUMN = "hub_commodity_key";

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            "commodity_code"
    );

    public static List<Column> columns = ImmutableList.of(
            column("commodity_code")
    );


    public static Seq<String> joinColumns = joinExpression(PRIMARY_COLUMN);

}
