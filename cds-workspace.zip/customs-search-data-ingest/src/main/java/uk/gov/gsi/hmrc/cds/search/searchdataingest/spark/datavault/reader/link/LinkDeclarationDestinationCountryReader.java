package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationDestinationCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.LINK_DECLARATION_DESTINATION_COUNTRY;

@Component
public class LinkDeclarationDestinationCountryReader extends DataVaultReader {
    private static final Encoder<LinkDeclarationDestinationCountry> linkDeclarationDestinationCountryEncoder = Encoders.bean(LinkDeclarationDestinationCountry.class);

    public Dataset<LinkDeclarationDestinationCountry> linkDeclarationDestinationCountryDataset() {
        String dataFilePath = String.format("%s/%s", LINK_DECLARATION_DESTINATION_COUNTRY.tableName(), datafileRelativePath);
        String linkDeclarationDestinationCountryFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<LinkDeclarationDestinationCountry> linkDeclarationDestinationCountryJavaRDD = sparkSession
                .read()
                .textFile(linkDeclarationDestinationCountryFilePath)
                .javaRDD()
                .map((Function<String, LinkDeclarationDestinationCountry>) LinkDeclarationDestinationCountry::mapper)
                .cache();

        return sparkSession
                .createDataFrame(linkDeclarationDestinationCountryJavaRDD, LinkDeclarationDestinationCountry.class)
                .as(linkDeclarationDestinationCountryEncoder)
                .cache();
    }

}
