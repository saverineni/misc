package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.currency;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;


@Data
@Builder
public class DeclarationFreightCurrency implements Serializable {

    private String currency_iso_code;
    private String currency_name;

    public static final String FREIGHT_CURRENCY_ISO_CODE = "freight_currency_iso_code";


}
