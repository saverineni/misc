package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.HUB_DECLARATION_LINE;

@Component
public class HubDeclarationLineReader extends DataVaultReader {
    private static final Encoder<HubDeclarationLine> hubDeclarationLineEncoder = Encoders.bean(HubDeclarationLine.class);

    public Dataset hubDeclarationLineDataset() {
        String dataFilePath = String.format("%s/%s", HUB_DECLARATION_LINE.tableName(), datafileRelativePath);
        String hubDeclarationLineFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<HubDeclarationLine> hubDeclarationLineJavaRDD = sparkSession
                .read()
                .textFile(hubDeclarationLineFilePath)
                .javaRDD()
                .map((Function<String, HubDeclarationLine>) HubDeclarationLine::mapper)
                .cache();

        return sparkSession
                .createDataFrame(hubDeclarationLineJavaRDD, HubDeclarationLine.class)
                .as(hubDeclarationLineEncoder)
                .cache();
    }

}
