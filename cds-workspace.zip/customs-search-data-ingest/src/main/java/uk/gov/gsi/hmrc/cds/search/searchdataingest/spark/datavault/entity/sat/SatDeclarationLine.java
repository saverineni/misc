package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.valueAt;

@Data
@Builder
public class SatDeclarationLine implements Serializable, BaseEntity {

    private String hub_declaration_line_key;
    private String sat_hash_diff;
    private String sat_load_datetime;
    private String sat_load_end_datetime;
    private String sat_record_source;
    private String clearance_datetime;
    private String item_statistical_value;
    private String customs_duty_paid;
    private String vat_paid;
    private String ec_supplementary_1;
    private String item_customs_value;
    private String item_net_mass;
    private String item_supplementary_units;
    private String goods_description;
    private String item_customs_check_code;
    private String item_mic_code;
    private String item_profile_id;
    private String item_consignor_nad_name;
    private String item_consignee_nad_name;
    private String item_consignee_nad_postcode;
    private String vat_value;
    private String item_price_declared;

    public static SatDeclarationLine mapper(String line) {
        List<String> columns = parseLine(line);

        return SatDeclarationLine.builder()
                .hub_declaration_line_key(valueAt(columns, 0))
                .sat_hash_diff(valueAt(columns, 1))
                .sat_load_datetime(valueAt(columns, 2))
                .sat_load_end_datetime(valueAt(columns, 3))
                .sat_record_source(valueAt(columns, 4))
                .clearance_datetime(valueAt(columns, 5))
                .item_statistical_value(valueAt(columns, 6))
                .customs_duty_paid(valueAt(columns, 7))
                .vat_paid(valueAt(columns, 8))
                .ec_supplementary_1(valueAt(columns, 9))
                .item_customs_value(valueAt(columns, 10))
                .item_net_mass(valueAt(columns, 11))
                .item_supplementary_units(valueAt(columns, 12))
                .goods_description(valueAt(columns, 13))
                .item_customs_check_code(valueAt(columns, 14))
                .item_mic_code(valueAt(columns, 15))
                .item_profile_id(valueAt(columns, 16))
                .item_consignor_nad_name(valueAt(columns, 17))
                .item_consignee_nad_name(valueAt(columns, 18))
                .item_consignee_nad_postcode(valueAt(columns, 19))
                .vat_value(valueAt(columns, 20))
                .item_price_declared(valueAt(columns, 21))
                .build();
    }
    
    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            "clearance_datetime",
            "item_statistical_value",
            "customs_duty_paid",
            "vat_paid",
            "ec_supplementary_1",
            "item_customs_value",
            "item_net_mass",
            "item_supplementary_units",
            "goods_description",
            "item_customs_check_code",
            "item_mic_code",
            "item_profile_id",
            "item_consignor_nad_name",
            "item_consignee_nad_name",
            "item_consignee_nad_postcode",
            "vat_value",
            "item_price_declared"
    );
}
