package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLinePreviousDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.LINK_DECLARATION_LINE_PREVIOUS_DOCUMENT;

@Component
public class LinkDeclarationLinePreviousDocumentReader extends DataVaultReader {
    private static final Encoder<LinkDeclarationLinePreviousDocument> linkDeclarationLinePreviousDocumentEncoder = Encoders.bean(LinkDeclarationLinePreviousDocument.class);

    public Dataset<LinkDeclarationLinePreviousDocument> linkDeclarationLinePreviousDocumentDataset() {
        String dataFilePath = String.format("%s/%s", LINK_DECLARATION_LINE_PREVIOUS_DOCUMENT.tableName(), datafileRelativePath);
        String linkDeclarationLinePreviousDocumentFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<LinkDeclarationLinePreviousDocument> linkDeclarationLinePreviousDocumentJavaRDD = sparkSession
                .read()
                .textFile(linkDeclarationLinePreviousDocumentFilePath)
                .javaRDD()
                .map((Function<String, LinkDeclarationLinePreviousDocument>) LinkDeclarationLinePreviousDocument::mapper)
                .cache();

        return sparkSession
                .createDataFrame(linkDeclarationLinePreviousDocumentJavaRDD, LinkDeclarationLinePreviousDocument.class)
                .as(linkDeclarationLinePreviousDocumentEncoder)
                .cache();
    }

}
