package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationImporterTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationImporterTraderReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class LinkDeclarationImporterTraderReaderTest extends SparkTest {

    @Autowired
    LinkDeclarationImporterTraderReader linkDeclarationImporterTraderReader;

    @Test
    public void buildsLinkDeclarationImporterTraderDataset() throws Exception {
        final Dataset<LinkDeclarationImporterTrader> linkDeclarationImporterTraderDataset = linkDeclarationImporterTraderReader.linkDeclarationImporterTraderDataset();
        assertThat(linkDeclarationImporterTraderDataset.count(), is(greaterThan(0l)));

        linkDeclarationImporterTraderDataset.printSchema();
        final String[] fieldNames = linkDeclarationImporterTraderDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(linkDeclarationImporterTraderStructFields));

        final String[] selectedFieldNames = linkDeclarationImporterTraderDataset.select(LinkDeclarationImporterTrader.PRIMARY_COLUMN , joinExpression(LinkDeclarationImporterTrader.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(linkDeclarationImporterTraderSelectedStructFields));
    }

    private String[] linkDeclarationImporterTraderStructFields = toArray(
            Lists.newArrayList("entry_reference",
                    "hub_declaration_key",
                    "hub_trader_key",
                    "link_declaration_importer_trader_key",
                    "link_load_datetime",
                    "link_record_source",
                    "turn")
    );

    private String[] linkDeclarationImporterTraderSelectedStructFields = toArray(
            Lists.newArrayList("link_declaration_importer_trader_key",
                    "hub_declaration_key",
                    "hub_trader_key")
    );
}

