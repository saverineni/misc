package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationTransportCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationTransportCountryReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class LinkDeclarationTransportCountryReaderTest extends SparkTest {

    @Autowired
    LinkDeclarationTransportCountryReader linkDeclarationTransportCountryReader;

    @Test
    public void buildsLinkDeclarationTransportCountryDataset() throws Exception {
        final Dataset<LinkDeclarationTransportCountry> linkDeclarationTransportCountryDataset = linkDeclarationTransportCountryReader.linkDeclarationTransportCountryDataset();
        assertThat(linkDeclarationTransportCountryDataset.count(), is(greaterThan(0l)));

        linkDeclarationTransportCountryDataset.printSchema();
        final String[] fieldNames = linkDeclarationTransportCountryDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(linkDeclarationTransportCountryStructFields));

        final String[] selectedFieldNames = linkDeclarationTransportCountryDataset.select(LinkDeclarationTransportCountry.PRIMARY_COLUMN , joinExpression(LinkDeclarationTransportCountry.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(linkDeclarationTransportCountrySelectedStructFields));
    }

    private String[] linkDeclarationTransportCountryStructFields = toArray(
            Lists.newArrayList("entry_reference",
                    "hub_country_key",
                    "hub_declaration_key",
                    "iso_country_code_alpha_2",
                    "link_declaration_transport_country_key",
                    "link_load_datetime",
                    "link_record_source")
    );

    private String[] linkDeclarationTransportCountrySelectedStructFields = toArray(
            Lists.newArrayList("link_declaration_transport_country_key",
                    "hub_country_key",
                    "hub_declaration_key")
    );
}




