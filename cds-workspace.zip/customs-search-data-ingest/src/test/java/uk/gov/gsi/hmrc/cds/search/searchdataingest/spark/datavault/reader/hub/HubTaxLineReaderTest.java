package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubTaxLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub.HubTaxLineReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;

public class HubTaxLineReaderTest extends SparkTest {

    @Autowired
    HubTaxLineReader hubTaxLineReader;

    @Test
    public void buildsHubTaxLineDataset() throws Exception {
        final Dataset<HubTaxLine> hubTaxLineDataset = hubTaxLineReader.hubTaxLineDataset();
        assertThat(hubTaxLineDataset.count(), is(greaterThan(0l)));

        hubTaxLineDataset.printSchema();
        final String[] fieldNames = hubTaxLineDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(hubTaxLineStructFields));

        final String[] selectedFieldNames = hubTaxLineDataset.select(HubTaxLine.PRIMARY_COLUMN , joinExpression(HubTaxLine.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(hubTaxLineSelectedStructFields));
    }

    private static String[] hubTaxLineStructFields = toArray(
            Lists.newArrayList("entry_reference",
                    "hub_load_datetime",
                    "hub_record_source",
                    "hub_tax_line_key",
                    "item_number",
                    "tax_line_sequence_number")
    );

    private static String[] hubTaxLineSelectedStructFields = toArray(
            Lists.newArrayList("hub_tax_line_key",
                    "tax_line_sequence_number")
    );
}
