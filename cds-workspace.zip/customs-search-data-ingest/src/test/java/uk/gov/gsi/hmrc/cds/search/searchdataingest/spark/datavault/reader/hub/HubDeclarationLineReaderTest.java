package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub.HubDeclarationLineReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class HubDeclarationLineReaderTest extends SparkTest {

    @Autowired
    HubDeclarationLineReader hubDeclarationLineReader;

    @Test
    public void buildsHubDeclarationLineDataset() throws Exception {
        final Dataset<HubDeclarationLine> hubDeclarationLineDataset = hubDeclarationLineReader.hubDeclarationLineDataset();
        assertThat(hubDeclarationLineDataset.count(), is(greaterThan(0l)));

        hubDeclarationLineDataset.printSchema();
        final String[] fieldNames = hubDeclarationLineDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(hubDeclarationLineStructFields));

        final String[] selectedFieldNames = hubDeclarationLineDataset.select(HubDeclarationLine.PRIMARY_COLUMN , joinExpression(HubDeclarationLine.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(hubDeclarationLineSelectedStructFields));
    }

    private static String[] hubDeclarationLineStructFields = toArray(
            Lists.newArrayList("entry_reference",
                    "hub_declaration_line_key",
                    "hub_load_datetime",
                    "hub_record_source",
                    "item_number")
    );

    private static String[] hubDeclarationLineSelectedStructFields = toArray(
            Lists.newArrayList("hub_declaration_line_key",
                    "entry_reference",
                    "item_number")
    );
}