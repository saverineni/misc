package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubCustomsProcedureCode;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub.HubCustomsProcedureCodeReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class HubCustomsProcedureCodeReaderTest extends SparkTest {

    @Autowired
    HubCustomsProcedureCodeReader hubCustomsProcedureCodeReader;

    @Test
    public void buildsHubCustomsProcedureCodeDataset() throws Exception {
        final Dataset<HubCustomsProcedureCode> hubCustomsProcedureCodeDataset = hubCustomsProcedureCodeReader.hubCustomsProcedureCodeDataset();
        assertThat(hubCustomsProcedureCodeDataset.count(), is(greaterThan(0l)));

        hubCustomsProcedureCodeDataset.printSchema();
        final String[] fieldNames = hubCustomsProcedureCodeDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(hubCustomsProcedureCodeStructFields));

        final String[] selectedFieldNames = hubCustomsProcedureCodeDataset.select(HubCustomsProcedureCode.PRIMARY_COLUMN , joinExpression(HubCustomsProcedureCode.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(hubCustomsProcedureCodeSelectedStructFields));
    }

    private static String[] hubCustomsProcedureCodeStructFields = toArray(
            Lists.newArrayList("customs_procedure_code",
                    "hub_customs_procedure_code_key",
                    "hub_load_datetime",
                    "hub_record_source")
    );

    private static String[] hubCustomsProcedureCodeSelectedStructFields = toArray(
            Lists.newArrayList("hub_customs_procedure_code_key",
                    "customs_procedure_code")
    );
}
