package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset;

import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;

import java.util.ArrayList;
import java.util.List;

import static java.util.Comparator.comparing;

public interface DeclarationStructure extends DeclarationConstants{

    /*
     Declaration Header Structure Types
    */

    default List<StructField> declarationHeaderCurrencyGroupStructType() {

        final List<StructField> declarationHeaderCurrencyStructFields = new ArrayList<>();
        final List<StructField> freightCurrencyStructFields = new ArrayList<>();
        final List<StructField> invoiceCurrencyStructFields = new ArrayList<>();

        freightCurrencyStructFields.add(DataTypes.createStructField(CURRENCY_ISO_CODE_FIELD_NAME,DataTypes.StringType,TRUE));
        freightCurrencyStructFields.add(DataTypes.createStructField(CURRENCY_FIELD_NAME,DataTypes.StringType,TRUE));

        invoiceCurrencyStructFields.add(DataTypes.createStructField(CURRENCY_ISO_CODE_FIELD_NAME,DataTypes.StringType,TRUE));
        invoiceCurrencyStructFields.add(DataTypes.createStructField(CURRENCY_FIELD_NAME,DataTypes.StringType,TRUE));

        declarationHeaderCurrencyStructFields.add(DataTypes.createStructField(FREIGHT_CURRENCY_FIELD_NAME,DataTypes.createStructType(freightCurrencyStructFields),TRUE));
        declarationHeaderCurrencyStructFields.add(DataTypes.createStructField(INVOICE_CURRENCY_FIELD_NAME,DataTypes.createStructType(invoiceCurrencyStructFields),TRUE));

        return declarationHeaderCurrencyStructFields;
    }

    default List<StructField> declarationHeaderCountryGroupStructType() {

        final List<StructField> declarationHeaderCountryStructFields = new ArrayList<>();
        final List<StructField> declarationStructType = declarationCountryStructType();

        declarationHeaderCountryStructFields.add(DataTypes.createStructField(DESTINATION_COUNTRY_FIELD_NAME,DataTypes.createStructType(declarationStructType),TRUE));
        declarationHeaderCountryStructFields.add(DataTypes.createStructField(TRANSPORT_COUNTRY_FIELD_NAME,DataTypes.createStructType(declarationStructType),TRUE));

        return declarationHeaderCountryStructFields;
    }

    default List<StructField> declarationHeaderTraderGroupStructType() {

        final List<StructField> declarationHeaderTraderStructFields = new ArrayList<>();

        declarationHeaderTraderStructFields.add(DataTypes.createStructField(TRADER_CONSIGNOR_FIELD_NAME,DataTypes.createStructType(declarationTraderStructType(CONSIGNOR_TRADER_TURN)),TRUE));
        declarationHeaderTraderStructFields.add(DataTypes.createStructField(TRADER_DECLARANT_FIELD_NAME,DataTypes.createStructType(declarationTraderStructType(DECLARANT_TRADER_TURN)),TRUE));
        declarationHeaderTraderStructFields.add(DataTypes.createStructField(TRADER_EXPORTER_FIELD_NAME,DataTypes.createStructType(declarationTraderStructType(EXPORTER_TRADER_TURN)),TRUE));
        declarationHeaderTraderStructFields.add(DataTypes.createStructField(TRADER_IMPORTER_FIELD_NAME,DataTypes.createStructType(declarationTraderStructType(IMPORTER_TRADER_TURN)),TRUE));
        declarationHeaderTraderStructFields.add(DataTypes.createStructField(TRADER_PAYING_AGENT_FIELD_NAME,DataTypes.createStructType(declarationTraderStructType(PAYING_AGENT_TRADER_TURN)),TRUE));

        return declarationHeaderTraderStructFields;
    }

    default List<StructField> declarationCountryStructType() {

        final List<StructField> declarationCountryStructFields = new ArrayList<>();

        declarationCountryStructFields.add(DataTypes.createStructField(COUNTRY_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationCountryStructFields.add(DataTypes.createStructField(COUNTRY_ISO_CODE_FIELD_NAME,DataTypes.StringType,TRUE));

        return declarationCountryStructFields;
    }

    default List<StructField> declarationTraderStructType(String traderTurn) {

        final List<StructField> declarationTraderStructFields = new ArrayList<>();

        declarationTraderStructFields.add(DataTypes.createStructField(traderTurn,DataTypes.StringType,TRUE));
        declarationTraderStructFields.add(DataTypes.createStructField(TRADER_CURRENT_IND,DataTypes.StringType,TRUE));
        declarationTraderStructFields.add(DataTypes.createStructField(TRADER_NAME,DataTypes.StringType,TRUE));
        declarationTraderStructFields.add(DataTypes.createStructField(TRADER_PROCEDURE_AUTHORISATIONS,DataTypes.StringType,TRUE));
        declarationTraderStructFields.add(DataTypes.createStructField(TRADER_NAME_ABBREVIATED,DataTypes.StringType,TRUE));

        declarationTraderStructFields.sort(comparing(StructField::name));

        return declarationTraderStructFields;
    }


    /*
     Declaration Line Structure Types
    */

    default List<StructField> declarationLineDocumentStructType() {

        final List<StructField> declarationLineDocumentStructFields = new ArrayList<>();

        declarationLineDocumentStructFields.add(DataTypes.createStructField(HUB_DOCUMENT_KEY_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineDocumentStructFields.add(DataTypes.createStructField(DOCUMENT_SEQ_NUMBER_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineDocumentStructFields.add(DataTypes.createStructField(SAT_DOCUMENT_GEN_NUMBER_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineDocumentStructFields.add(DataTypes.createStructField(ITEM_DOCUMENT_CODE_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineDocumentStructFields.add(DataTypes.createStructField(ITEM_DOCUMENT_STATUS_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineDocumentStructFields.add(DataTypes.createStructField(ITEM_DOCUMENT_REF_FIELD_NAME,DataTypes.StringType,TRUE));

        return declarationLineDocumentStructFields;
    }

    default List<StructField> declarationLineAdditionalInfoStructType() {

        final List<StructField> declarationLineAdditionalInfoStructFields = new ArrayList<>();

        declarationLineAdditionalInfoStructFields.add(DataTypes.createStructField(HUB_ADDITONAL_INFO_KEY_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineAdditionalInfoStructFields.add(DataTypes.createStructField(ADDITIONAL_INFO_SEQ_NUMBER_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineAdditionalInfoStructFields.add(DataTypes.createStructField(SAT_ADDITIONAL_INFO_GEN_NUMBER_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineAdditionalInfoStructFields.add(DataTypes.createStructField(ADDITIONAL_INFO_STATEMENT_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineAdditionalInfoStructFields.add(DataTypes.createStructField(ADDITIONAL_INFO_STATEMENT_TYPE_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineAdditionalInfoStructFields.add(DataTypes.createStructField(ITEM_ADDITIONAL_INFO_STATEMENT_FIELD_NAME,DataTypes.StringType,TRUE));

        return declarationLineAdditionalInfoStructFields;
    }

    default List<StructField> declarationLineTaxLineStructType() {

        final List<StructField> declarationLineTaxLineStructFields = new ArrayList<>();

        declarationLineTaxLineStructFields.add(DataTypes.createStructField(HUB_TAX_LINE_KEY_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineTaxLineStructFields.add(DataTypes.createStructField(TAX_LINE_SEQ_NUMBER_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineTaxLineStructFields.add(DataTypes.createStructField(SAT_TAX_LINE_GEN_NUMBER_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineTaxLineStructFields.add(DataTypes.createStructField(WAIVED_TAX_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineTaxLineStructFields.add(DataTypes.createStructField(PAYMENT_METHOD_CODE_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineTaxLineStructFields.add(DataTypes.createStructField(TAX_AMOUNT_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineTaxLineStructFields.add(DataTypes.createStructField(TAX_TYPE_CODE_FIELD_NAME,DataTypes.StringType,TRUE));

        return declarationLineTaxLineStructFields;
    }

    default List<StructField> declarationLinePreviousDocumentsStructType() {

        final List<StructField> declarationLinePreviousDocumentsStructFields = new ArrayList<>();

        declarationLinePreviousDocumentsStructFields.add(DataTypes.createStructField(HUB_PREVIOUS_DOCUMENT_KEY_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLinePreviousDocumentsStructFields.add(DataTypes.createStructField(PREVIOUS_DOCUMENT_SEQ_NUMBER_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLinePreviousDocumentsStructFields.add(DataTypes.createStructField(PREVIOUS_DOCUMENT_REF_FIELD_NAME,DataTypes.StringType,TRUE));

        return declarationLinePreviousDocumentsStructFields;
    }

    default List<StructField> declarationLineCommodityStructType() {

        final List<StructField> declarationLineCommodityStructFields = new ArrayList<>();

        declarationLineCommodityStructFields.add(DataTypes.createStructField(HUB_COMMODITY_KEY_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineCommodityStructFields.add(DataTypes.createStructField(COMMODITY_CODE_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineCommodityStructFields.add(DataTypes.createStructField(CC_YEAR_FIELD_NAME,DataTypes.StringType,TRUE));

        declarationLineCommodityStructFields.add(DataTypes.createStructField(CC_MONTH_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineCommodityStructFields.add(DataTypes.createStructField(HS_CHAPTER_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineCommodityStructFields.add(DataTypes.createStructField(HS_HEADING_FIELD_NAME,DataTypes.StringType,TRUE));

        declarationLineCommodityStructFields.add(DataTypes.createStructField(HS_CHAPTER_HEADING_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineCommodityStructFields.add(DataTypes.createStructField(HS_SUBHEADING_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineCommodityStructFields.add(DataTypes.createStructField(CHAPTER_DESCRIPTION_FIELD_NAME,DataTypes.StringType,TRUE));

        declarationLineCommodityStructFields.add(DataTypes.createStructField(HEADING_DESCRIPTION_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineCommodityStructFields.add(DataTypes.createStructField(SUBHEADING_DESCRIPTION_FIELD_NAME,DataTypes.StringType,TRUE));

        return declarationLineCommodityStructFields;
    }


    default List<StructField> declarationLineOriginCountryStructType() {

        final List<StructField> declarationLineOriginCountryStructFields = new ArrayList<>();

        declarationLineOriginCountryStructFields.add(DataTypes.createStructField(COUNTRY_FIELD_NAME,DataTypes.StringType,TRUE));
        declarationLineOriginCountryStructFields.add(DataTypes.createStructField(COUNTRY_ISO_CODE_FIELD_NAME,DataTypes.StringType,TRUE));

        return declarationLineOriginCountryStructFields;
    }

    default List<StructField> declarationLineImporterTraderGroupStructType() {

        final List<StructField> declarationLineImporterTraderStructFields = new ArrayList<>();

        declarationLineImporterTraderStructFields.add(DataTypes.createStructField(IMPORTER_TRADER_TURN,DataTypes.StringType,TRUE));
        declarationLineImporterTraderStructFields.add(DataTypes.createStructField(TRADER_NAME,DataTypes.StringType,TRUE));
        declarationLineImporterTraderStructFields.add(DataTypes.createStructField(TRADER_PROCEDURE_AUTHORISATIONS,DataTypes.StringType,TRUE));
        declarationLineImporterTraderStructFields.add(DataTypes.createStructField(TRADER_NAME_ABBREVIATED,DataTypes.StringType,TRUE));
        declarationLineImporterTraderStructFields.add(DataTypes.createStructField(TRADER_CURRENT_IND,DataTypes.StringType,TRUE));

        return declarationLineImporterTraderStructFields;
    }



}
