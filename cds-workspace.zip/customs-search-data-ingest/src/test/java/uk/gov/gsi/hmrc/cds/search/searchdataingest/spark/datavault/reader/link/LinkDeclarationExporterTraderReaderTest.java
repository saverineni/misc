package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationExporterTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationExporterTraderReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;

public class LinkDeclarationExporterTraderReaderTest extends SparkTest {

    @Autowired
    LinkDeclarationExporterTraderReader linkDeclarationExporterTraderReader;

    @Test
    public void buildsLinkDeclarationExporterTraderDataset() throws Exception {
        final Dataset<LinkDeclarationExporterTrader> linkDeclarationExporterTraderDataset = linkDeclarationExporterTraderReader.linkDeclarationExporterTraderDataset();
        assertThat(linkDeclarationExporterTraderDataset.count(), is(greaterThan(0l)));

        linkDeclarationExporterTraderDataset.printSchema();
        final String[] fieldNames = linkDeclarationExporterTraderDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(linkDeclarationExporterTraderStructFields));

        final String[] selectedFieldNames = linkDeclarationExporterTraderDataset.select(LinkDeclarationExporterTrader.PRIMARY_COLUMN , joinExpression(LinkDeclarationExporterTrader.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(linkDeclarationExporterTraderSelectedStructFields));
    }

    private String[] linkDeclarationExporterTraderStructFields = toArray(
            Lists.newArrayList("entry_reference",
                    "hub_declaration_key",
                    "hub_trader_key",
                    "link_declaration_exporter_trader_key",
                    "link_load_datetime",
                    "link_record_source",
                    "turn")
    );

    private String[] linkDeclarationExporterTraderSelectedStructFields = toArray(
            Lists.newArrayList("link_declaration_exporter_trader_key",
                    "hub_declaration_key",
                    "hub_trader_key")
    );
}

