package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatTraderReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class SatTraderReaderTest extends SparkTest {

    @Autowired
    SatTraderReader satTraderReader;

    @Test
    public void buildsSatTraderDataset() throws Exception {
        final Dataset<SatTrader> satTraderDataset = satTraderReader.satTraderDataset();
        assertThat(satTraderDataset.count(), is(greaterThan(0l)));

        satTraderDataset.printSchema();
        final String[] fieldNames = satTraderDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(satTraderStructFields));

        final String[] selectedFieldNames = satTraderDataset.selectExpr(joinExpression(SatTrader.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(satTraderSelectedStructFields));
    }

    private String[] satTraderStructFields = toArray(
            Lists.newArrayList("current_ind",
                    "hub_trader_key",
                    "name",
                    "sat_hash_diff",
                    "sat_load_datetime",
                    "sat_load_end_datetime",
                    "sat_record_source",
                    "simplified_procedure_authorisations",
                    "trader_name_abbreviated")
    );

    private String[] satTraderSelectedStructFields = toArray(
            Lists.newArrayList("name",
                    "simplified_procedure_authorisations",
                    "trader_name_abbreviated",
                    "current_ind")
    );
}
