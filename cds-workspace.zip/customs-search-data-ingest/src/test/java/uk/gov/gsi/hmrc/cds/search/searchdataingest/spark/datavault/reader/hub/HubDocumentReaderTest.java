package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub.HubDocumentReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class HubDocumentReaderTest extends SparkTest {

    @Autowired
    HubDocumentReader hubDocumentReader;

    @Test
    public void buildsHubDocumentDataset() throws Exception {
        final Dataset<HubDocument> hubDocumentDataset = hubDocumentReader.hubDocumentDataset();
        assertThat(hubDocumentDataset.count(), is(greaterThan(0l)));

        hubDocumentDataset.printSchema();
        final String[] fieldNames = hubDocumentDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(hubDocumentStructFields));

        final String[] selectedFieldNames = hubDocumentDataset.select(HubDocument.PRIMARY_COLUMN , joinExpression(HubDocument.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(hubDocumentSelectedStructFields));
    }

    private static String[] hubDocumentStructFields = toArray(
            Lists.newArrayList("document_sequence_number",
                    "entry_reference",
                    "hub_document_key",
                    "hub_load_datetime",
                    "hub_record_source",
                    "item_number")
    );

    private static String[] hubDocumentSelectedStructFields = toArray(
            Lists.newArrayList("hub_document_key",
                    "document_sequence_number")
    );
}

