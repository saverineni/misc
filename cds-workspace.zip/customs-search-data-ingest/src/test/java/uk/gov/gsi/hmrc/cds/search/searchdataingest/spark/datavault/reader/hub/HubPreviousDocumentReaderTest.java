package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubPreviousDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub.HubPreviousDocumentReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;

public class HubPreviousDocumentReaderTest extends SparkTest {

    @Autowired
    HubPreviousDocumentReader hubPreviousDocumentReader;

    @Test
    public void buildsHubPreviousDocumentDataset() throws Exception {
        final Dataset<HubPreviousDocument> hubPreviousDocumentDataset = hubPreviousDocumentReader.hubPreviousDocumentDataset();
        assertThat(hubPreviousDocumentDataset.count(), is(greaterThan(0l)));

        hubPreviousDocumentDataset.printSchema();
        final String[] fieldNames = hubPreviousDocumentDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(hubPreviousDocumentStructFields));

        final String[] selectedFieldNames = hubPreviousDocumentDataset.select(HubPreviousDocument.PRIMARY_COLUMN , joinExpression(HubPreviousDocument.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(hubPreviousDocumentSelectedStructFields));
    }

    private static String[] hubPreviousDocumentStructFields = toArray(
            Lists.newArrayList("entry_reference",
                    "hub_load_datetime",
                    "hub_previous_document_key",
                    "hub_record_source",
                    "item_number",
                    "previous_document_sequence_number")
    );

    private static String[] hubPreviousDocumentSelectedStructFields = toArray(
            Lists.newArrayList("hub_previous_document_key",
                    "previous_document_sequence_number")
    );
}

