package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationLineDocumentReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class LinkDeclarationLineDocumentReaderTest extends SparkTest {

    @Autowired
    LinkDeclarationLineDocumentReader linkDeclarationLineDocumentReader;

    @Test
    public void buildsLinkDeclarationLineDocumentDataset() throws Exception {
        final Dataset<LinkDeclarationLineDocument> linkDeclarationLineDocumentDataset = linkDeclarationLineDocumentReader.linkDeclarationLineDocumentDataset();
        assertThat(linkDeclarationLineDocumentDataset.count(), is(greaterThan(0l)));

        linkDeclarationLineDocumentDataset.printSchema();
        final String[] fieldNames = linkDeclarationLineDocumentDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(linkDeclarationLineDocumentStructFields));

        final String[] selectedFieldNames = linkDeclarationLineDocumentDataset.select(LinkDeclarationLineDocument.PRIMARY_COLUMN , joinExpression(LinkDeclarationLineDocument.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(linkDeclarationLineDocumentSelectedStructFields));
    }

    private String[] linkDeclarationLineDocumentStructFields = toArray(
            Lists.newArrayList("document_sequence_number",
                    "entry_reference",
                    "hub_declaration_line_key",
                    "hub_document_key",
                    "item_number",
                    "link_declaration_line_document_key",
                    "link_load_datetime",
                    "link_record_source")
    );

    private String[] linkDeclarationLineDocumentSelectedStructFields = toArray(
            Lists.newArrayList("link_declaration_line_document_key",
                    "hub_document_key",
                    "hub_declaration_line_key")
    );
}


