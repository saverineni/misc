package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubAdditionalInfo;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub.HubAdditionalInfoReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;


public class HubAdditionalInfoReaderTest extends SparkTest {

    @Autowired
    HubAdditionalInfoReader hubAdditionalInfoReader;

    @Test
    public void buildsHubAdditionalInfoDataset() throws Exception {
        final Dataset<HubAdditionalInfo> hubAdditionalInfoDataset = hubAdditionalInfoReader.hubAdditionalInfoDataset();
        assertThat(hubAdditionalInfoDataset.count(), is(greaterThan(0l)));

        hubAdditionalInfoDataset.printSchema();
        final String[] fieldNames = hubAdditionalInfoDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(hubAdditionalInfoStructFields));

        final String[] selectedFieldNames = hubAdditionalInfoDataset.select(HubAdditionalInfo.PRIMARY_COLUMN , joinExpression(HubAdditionalInfo.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(hubAdditionalInfoSelectedStructFields));
    }

    private static String[] hubAdditionalInfoStructFields = toArray(
            Lists.newArrayList(
                    "additional_information_sequence_number",
                    "entry_reference",
                    "hub_additional_info_key",
                    "hub_load_datetime",
                    "hub_record_source",
                    "item_number")
    );

    private static String[] hubAdditionalInfoSelectedStructFields = toArray(
            Lists.newArrayList("hub_additional_info_key",
                    "additional_information_sequence_number")
    );

}