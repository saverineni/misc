#!/usr/bin/env groovy

// Release Candidate Version Format 1.2.3-RC1-SNAPSHOT
// Release Version Format 1.2.3
def call(String version) {
    validateReleaseCandidateVersionFormat(version)

    def matcher = (version =~ regExReleaseCandidateVersion())
    String releaseVersion = matcher[0][1]

    return "${releaseVersion}"
}