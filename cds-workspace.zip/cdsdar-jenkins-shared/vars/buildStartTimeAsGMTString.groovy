#!/usr/bin/env groovy

def call(def buildStartTimeInMillis) {
    Date buildStartDate = new Date(buildStartTimeInMillis)
    return buildStartDate.toGMTString()
}
