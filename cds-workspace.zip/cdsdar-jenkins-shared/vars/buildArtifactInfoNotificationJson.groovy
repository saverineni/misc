#!/usr/bin/env groovy

def call(String artifactVersion) {
    return groovy.json.JsonOutput.toJson([
            "auth_token" : "YOUR_AUTH_TOKEN",
            "version" : artifactVersion,
            "jenkins-build" : "${currentBuild.number}",
            "jenkins-build-status" : (currentBuild.result == null) ? "SUCCESS" : currentBuild.result,
            "lastUpdatedAt" : buildStartTimeAsGMTString(currentBuild.startTimeInMillis)

    ]);
}