#!/usr/bin/env groovy

def call(String version) {
    sshagent([jenkinsCredentialCdsdataBitbucket()]) {
        script {
            def SNAPSHOT = "-SNAPSHOT"
            def versionNumber = version.replace(SNAPSHOT, "")
            def releaseBranch = "release/${versionNumber}"
            sh "git checkout -b ${releaseBranch}"

            def releaseCandidateVersion = "${versionNumber}-RC1${SNAPSHOT}"
            sh "mvn versions:set -DnewVersion=${releaseCandidateVersion} -DoldVersion=${version} -DgenerateBackupPoms=false"
            sh "git commit -am 'JENKINS: Create release branch ${releaseBranch}' || true"
            sh "git push origin ${releaseBranch}"

        }
    }
}