#!/usr/bin/env groovy

def call() {
    def pom = null
    script {
        if (fileExists('pom.xml')) {
            pom = readMavenPom(file: 'pom.xml')
        }
    }
    return pom
}