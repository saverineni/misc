#!/usr/bin/env groovy

def call(String gitURL, String releaseVersion, String moduleName) {
    sshagent([jenkinsCredentialCdsdataBitbucket()]) {
        script {
            gitCheckoutRecursive(gitURL, 'master')
            refreshGitSubmodules('master')
            sh "git push origin --delete release/${releaseVersion}"

            sh "git checkout -b \"release/${releaseVersion}\" `git tag --list \"${moduleName}-release-*-v${releaseVersion}-*-SNAPSHOT\"`"
            refreshGitSubmodules("release/${releaseVersion}")
        }
    }
}