#!/usr/bin/env groovy

def call(String customs_pipeline_landing_release_branch, String releaseVersion) {

    for (String submodule : customsPipelineLandingSubmodules()){
        log("Merging ${submodule} branch ${customs_pipeline_landing_release_branch} into master")
        mergeSubModuleReleaseBranch(customs_pipeline_landing_release_branch, submodule, releaseVersion)
    }
}
