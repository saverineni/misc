#!/usr/bin/env groovy

def call(String rcVersion) {
    def matcher = (rcVersion =~ regExReleaseCandidateVersion())

    if(!matcher.matches()) {
        throw new Exception("Invalid release candidate version format, FORMAT -> 1.2.3-RC1-SNAPSHOT")
    }
    return matcher.matches()
}