#!/usr/bin/env groovy

// Release Candidate Version Format 1.2.3-RC1-SNAPSHOT
def call(String version) {
    validateReleaseCandidateVersionFormat(version)

    def matcher = (version =~ regExReleaseCandidateVersion())
    String artifactVersion = matcher[0][1]
    String rcVersion = matcher[0][2]
    String snapshot = matcher[0][3]

    def newRcVersion = "-RC" + (Integer.parseInt(rcVersion.substring(3, rcVersion.length())) + 1)
    return "${artifactVersion}${newRcVersion}${snapshot}"
}