#!/usr/bin/env groovy

def call(String gitRepository, String gitBranch, String version) {
    String tag = buildGitTagValue(version)
    sshagent([jenkinsCredentialCdsdataBitbucket()]) {
        script {
            sh "git tag -a ${tag} -m 'JENKINS: version ${version}' || true"
            sh "git push origin tag ${tag}"
        }
    }

}