#!/usr/bin/env groovy

def call(String datavault_hash_calculator_release_branch, String commonModuleBranch = '') {

    def customs_pipeline_submodule_common = 'customs-pipeline-common'

    def customs_pipeline_common_release_branch = (commonModuleBranch != '') ? commonModuleBranch : determineCustomsPipelineCommonReleaseBranch()
    echo "customs_pipeline_common_release_branch --> ${customs_pipeline_common_release_branch}"

    updateSubModuleBranch(datavault_hash_calculator_release_branch, customs_pipeline_submodule_common, customs_pipeline_common_release_branch)

}