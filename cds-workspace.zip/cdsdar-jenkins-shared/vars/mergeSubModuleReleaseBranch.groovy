#!/usr/bin/env groovy

def call(String releaseBranch, String submoduleName, String releaseVersion) {
    dir(env.WORKSPACE + "/${submoduleName}") {
        sshagent([jenkinsCredentialCdsdataBitbucket()]) {
            script {
                gitCheckoutRecursive("ssh://git@10.102.81.191:7999/cdsd/${submoduleName}.git", releaseBranch)
                gitAnnotatedTag("ssh://git@10.102.81.191:7999/cdsd/${submoduleName}.git", releaseBranch, releaseVersion)
                mergeReleaseToMaster(releaseBranch)
            }
        }
    }
}