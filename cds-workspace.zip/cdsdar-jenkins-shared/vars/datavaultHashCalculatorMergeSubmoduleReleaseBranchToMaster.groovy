#!/usr/bin/env groovy

def call(String customs_pipeline_submodule_common_release, String customs_pipeline_submodule_helper_tools_release, String releaseVersion) {

    def customs_pipeline_submodule_common = 'customs-pipeline-common'
    def customs_pipeline_submodule_helper_tools = 'customs-pipeline-helper-tools'

    mergeSubModuleReleaseBranch(customs_pipeline_submodule_common_release, customs_pipeline_submodule_common, releaseVersion)
    mergeSubModuleReleaseBranch(customs_pipeline_submodule_helper_tools_release, customs_pipeline_submodule_helper_tools, releaseVersion)


/*    for (String submodule : datavaultHashCalculatorSubmodules()){
        log("Merging ${submodule} branch ${datavault_hash_calculator_release_branch} into master")
        mergeSubModuleReleaseBranch(datavault_hash_calculator_release_branch, submodule, releaseVersion)
    }*/


}
