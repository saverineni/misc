#!/usr/bin/env groovy

def call(String releaseBranch, String version) {
    if(validateReleaseCandidateVersionFormat(version)) {
        sshagent([jenkinsCredentialCdsdataBitbucket()]) {
            script {
                updateGitBranch(releaseBranch)
                def releaseVersion = releaseVersionFromReleaseCandidate(version)
                validateReleaseVersionFormat(releaseVersion)
                sh "mvn versions:set -DnewVersion=${releaseVersion} -DoldVersion=${version} -DgenerateBackupPoms=false"
                sh "git commit -am 'JENKINS: Release version - ${releaseVersion}' || true"
                sh "git push origin ${releaseBranch}"
            }
        }
    }
}