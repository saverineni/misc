#!/usr/bin/env groovy

def call(String gitRepository, String gitBranch, String version) {
    String tag = buildGitTagValue(version)
    sshagent([jenkinsCredentialCdsdataBitbucket()]) {
        script {
            sh "git tag -l ${tag}' || true"
            sh "git push origin tag ${tag}"
        }
    }

}