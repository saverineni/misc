#!/usr/bin/env groovy

def call(String customs_pipeline_generic_data_model_release_branch, String releaseVersion) {
    def customs_pipeline_submodule_generic_data_model_pdi = 'generic-data-model-pdi'

    log("Merging ${customs_pipeline_submodule_generic_data_model_pdi} branch ${customs_pipeline_generic_data_model_release_branch} into master")
    mergeSubModuleReleaseBranch(customs_pipeline_generic_data_model_release_branch, customs_pipeline_submodule_generic_data_model_pdi, releaseVersion)
}
