#!/usr/bin/env groovy

def call(String artifactVersion) {
    log("${artifactVersion}")

    def genericDataModelArtifactURL = "http://10.102.81.194:8081/nexus/service/local/repositories/releases/content/uk/gov/gsi/hmrc/cds/data/customs-pipeline-generic-data-model/${artifactVersion}/customs-pipeline-generic-data-model-${artifactVersion}-generic-data-model.tar.gz"
    def fileName = "customs-pipeline-generic-data-model.tar.gz"

    downloadArtifact(genericDataModelArtifactURL, fileName)
}