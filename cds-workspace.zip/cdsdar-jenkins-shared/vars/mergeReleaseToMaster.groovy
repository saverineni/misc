#!/usr/bin/env groovy

def call(String releaseBranch) {
    sshagent([jenkinsCredentialCdsdataBitbucket()]) {
        script {
            updateGitBranch(releaseBranch)
            updateGitBranch('master')
            sh "git checkout ${releaseBranch}"
            sh "git merge -s ours --no-edit master"
            sh "git push origin ${releaseBranch}"
            sh "git checkout master"
            sh "git merge --no-ff --no-commit ${releaseBranch}"
            sh "git status"
            sh "git commit -m 'JENKINS: Merged release branch ${releaseBranch} into master' || true"
            sh "git push origin master"
        }
    }

}