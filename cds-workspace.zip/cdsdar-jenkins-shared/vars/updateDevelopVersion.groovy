#!/usr/bin/env groovy

def call(String version, String versionLevel = 'patch') {
    script {
        def newDevelopVersion = incrementSnapshotVersion(version, versionLevel)
        def oldDevelopVersion = version
        sh "git checkout develop"
        sh "mvn versions:set -DnewVersion=${newDevelopVersion} -DoldVersion=${oldDevelopVersion} -DgenerateBackupPoms=false"

        sshagent([jenkinsCredentialCdsdataBitbucket()]) {
            script {
                sh "git commit -am 'JENKINS: Git Branch version update' || true"
                sh "git push origin develop"
            }
        }
    }

}
