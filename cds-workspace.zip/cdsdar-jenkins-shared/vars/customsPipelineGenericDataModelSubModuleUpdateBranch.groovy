#!/usr/bin/env groovy

def call(String customs_pipeline_generic_data_model_release_branch, String commonModuleBranch = '') {

    def customs_pipeline_submodule_common = 'customs-pipeline-common'
    def customs_pipeline_submodule_helper_tools = 'customs-pipeline-helper-tools'
    def customs_pipeline_submodule_generic_data_model_pdi = 'generic-data-model-pdi'

    def customs_pipeline_common_release_branch = (commonModuleBranch != '') ? commonModuleBranch : determineCustomsPipelineCommonReleaseBranch()
    echo "customs_pipeline_common_release_branch --> ${customs_pipeline_common_release_branch}"
    echo "customs_pipeline_generic_data_model_release_branch --> ${customs_pipeline_generic_data_model_release_branch}"

    updateSubModuleBranch(customs_pipeline_generic_data_model_release_branch, customs_pipeline_submodule_common, customs_pipeline_common_release_branch)
    updateSubModuleBranch(customs_pipeline_generic_data_model_release_branch, customs_pipeline_submodule_helper_tools, customs_pipeline_common_release_branch)
    updateSubModuleBranch(customs_pipeline_generic_data_model_release_branch, customs_pipeline_submodule_generic_data_model_pdi, commonModuleBranch)
}
