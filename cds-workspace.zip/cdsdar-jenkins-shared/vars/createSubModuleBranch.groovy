#!/usr/bin/env groovy

def call(String gitBranch, String submoduleName) {
    dir(env.WORKSPACE + "/${submoduleName}") {
        sshagent([jenkinsCredentialCdsdataBitbucket()]) {
            script {
                gitCheckoutRecursive("ssh://git@10.102.81.191:7999/cdsd/${submoduleName}.git")
                sh "git checkout -b ${gitBranch}"
                sh "git push origin ${gitBranch}"
            }
        }
    }
}