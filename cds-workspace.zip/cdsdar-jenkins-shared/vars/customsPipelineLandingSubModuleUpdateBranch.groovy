#!/usr/bin/env groovy

def call(String customs_pipeline_landing_branch, String commonModuleBranch = '') {

    for (String submodule : customsPipelineLandingSubmodules()) {
        updateSubModuleBranch(customs_pipeline_landing_branch, submodule, commonModuleBranch)
    }
}
