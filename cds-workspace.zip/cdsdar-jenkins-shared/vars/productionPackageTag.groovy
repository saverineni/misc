#!/usr/bin/env groovy

def call(String packageEnv) {
    def packageDate = new Date().format('dd-MM-yyyy')
    String tag = "${packageEnv}-${packageDate}"
    return tag
}