#!/usr/bin/env groovy

def call(String packageEnv, String landingVersion, String genericDataModelVersion, String exploitationReportVersion, String customsReportVersion, String standingDataVersion) {
    sshagent([jenkinsCredentialCdsdataBitbucket()]) {
        script {
            sh "git add --all"
            sh "git commit -am 'JENKINS: ${packageEnv} package - landing: ${landingVersion} generic-data-model: ${genericDataModelVersion} exploitation-report: ${exploitationReportVersion} report: ${customsReportVersion} standing-data: ${standingDataVersion} ' || true"
            sh "git push -u origin master"

            def tag = productionPackageTag("${packageEnv}")
            sh "git tag -a ${tag} -m 'JENKINS: ${packageEnv} package' || true"
            sh "git push origin tag ${tag}"
        }
    }

}