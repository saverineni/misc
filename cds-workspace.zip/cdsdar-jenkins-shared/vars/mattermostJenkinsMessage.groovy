#!/usr/bin/env groovy

def call(String jenkinsJobStatus) {
    return "${jenkinsJobStatus}: ${env.JOB_NAME} [#${env.BUILD_NUMBER}]\n${env.BUILD_URL}consoleFull"
}