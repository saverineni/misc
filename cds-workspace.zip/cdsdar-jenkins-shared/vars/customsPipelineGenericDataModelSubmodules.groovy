#!/usr/bin/env groovy

def call() {
    def customs_pipeline_submodule_common = 'customs-pipeline-common'
    def customs_pipeline_submodule_helper_tools = 'customs-pipeline-helper-tools'
    def customs_pipeline_submodule_generic_data_model_pdi = 'generic-data-model-pdi'

    def genericDataModelSubmodules = [customs_pipeline_submodule_common,
                             customs_pipeline_submodule_helper_tools,
                             customs_pipeline_submodule_generic_data_model_pdi]

    return genericDataModelSubmodules
}