#!/usr/bin/env groovy

def call(String version) {
    def matcher = (version =~ regExSnapshotVersion())

    if(!matcher.matches()) {
        throw new Exception("Invalid snapshot version format, FORMAT -> 1.2.3-SNAPSHOT")
    }
    return matcher.matches()
}