#!/usr/bin/env groovy

def call(String packageEnv, String moduleName) {
    def packageTag = productionPackageTag("${packageEnv}")

    artifactInfoPostNotification(packageTag, moduleName, packageEnv)
}