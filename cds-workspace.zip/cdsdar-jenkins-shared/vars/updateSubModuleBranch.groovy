#!/usr/bin/env groovy

def call(String gitBranch, String submoduleName, String commonModuleBranch = '') {
    dir('src/main/resources') {
        sshagent([jenkinsCredentialCdsdataBitbucket()]) {
            script {
                def submoduleBranch = (commonModuleBranch != '') ? commonModuleBranch : gitBranch
                def submoduleAlias = buildSubmoduleName(submoduleBranch, submoduleName)
                sh "git remote update"
                sh "git checkout ${gitBranch}"
                sh "git submodule deinit -- ${submoduleName}"
                sh "rm -rf ../../../.git/modules/${submoduleAlias}"
                sh "git rm ${submoduleName}"
                sh "git commit -am 'JENKINS: git removed submodule ${submoduleName} from branch ${gitBranch}'"
                sh "git push origin ${gitBranch}"

                sh "git submodule add -b ${submoduleBranch} --name ${submoduleAlias} ssh://git@10.102.81.191:7999/cdsd/${submoduleName}.git"
                sh "git commit -am 'JENKINS: git add submodule ${submoduleName} and realign branch to ${submoduleBranch}'"
                sh "git push origin ${gitBranch}"
            }
        }
    }
}