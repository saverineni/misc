#!/usr/bin/env groovy

def call() {
    def customs_pipeline_submodule_common = 'customs-pipeline-common'
    def customs_pipeline_submodule_helper_tools = 'customs-pipeline-helper-tools'
    def customs_pipeline_submodule_landing_pdi = 'landing-pdi'

    def landingSubmodules = [customs_pipeline_submodule_common,
                             customs_pipeline_submodule_helper_tools,
                             customs_pipeline_submodule_landing_pdi]

    return landingSubmodules
}