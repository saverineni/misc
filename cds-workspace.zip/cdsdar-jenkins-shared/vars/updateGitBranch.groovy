#!/usr/bin/env groovy

def call(String gitBranch) {
    sshagent([jenkinsCredentialCdsdataBitbucket()]) {
        script {
            sh "git remote update"
            sh "git checkout ${gitBranch}"
            sh "git pull origin ${gitBranch} || true"
            sh "git submodule update --remote"
        }
    }
}