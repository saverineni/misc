#!/usr/bin/env groovy

def call() {
    return readPom().version
}