#!/usr/bin/env groovy

def call(String artifactDownloadUrl, String fileName) {
    log(artifactDownloadUrl)
    log(fileName)

    script {
        sh "wget -O ${fileName} ${artifactDownloadUrl}"
    }

}