#!/usr/bin/env groovy

def call() {
    return "^(release/)(\\d{1,}+\\.\\d{1,}+\\.\\d{1,})"
}