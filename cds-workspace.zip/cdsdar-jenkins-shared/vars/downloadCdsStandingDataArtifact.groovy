#!/usr/bin/env groovy

def call(String artifactVersion) {
    log("${artifactVersion}")

    def standingDataArtifactURL = "http://10.102.81.194:8081/nexus/service/local/repositories/releases/content/uk/gov/gsi/hmrc/cds/data/cds-standing-data/${artifactVersion}/cds-standing-data-${artifactVersion}-standing-data.tar.gz"
    def fileName = "cdsdar_standing_data.tar.gz"

    downloadArtifact(standingDataArtifactURL, fileName)
}