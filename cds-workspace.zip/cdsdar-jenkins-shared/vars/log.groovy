#!/usr/bin/env groovy

def call(String message) {
    def ANSI_GREEN = "\\u001B[32m"
    println(message)
}