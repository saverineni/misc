#!/usr/bin/env groovy

def call(String version) {
    def matcher = (version =~ regExReleaseVersion())

    if(!matcher.matches()) {
        throw new Exception("Invalid release version format, FORMAT -> 1.2.3")
    }
    return matcher.matches()
}