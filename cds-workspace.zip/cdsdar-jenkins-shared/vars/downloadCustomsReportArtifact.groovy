#!/usr/bin/env groovy

def call(String artifactVersion) {
    log("${artifactVersion}")

    def customsReportArtifactURL = "http://10.102.81.194:8081/nexus/service/local/repositories/releases/content/uk/gov/gsi/hmrc/cds/data/customs-report/${artifactVersion}/customs-report-${artifactVersion}-report.tar.gz"
    def fileName = "customs-report.tar.gz"

    downloadArtifact(customsReportArtifactURL, fileName)
}