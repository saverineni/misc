#!/usr/bin/env groovy

def call(String gitBranch = 'develop') {
    sshagent([jenkinsCredentialCdsdataBitbucket()]) {
        script {
            sh "git remote update"
            sh "git submodule update --remote"
            sh "git commit -am 'JENKINS: submodule update' || true"
            sh "git push origin ${gitBranch}"
        }
    }

}