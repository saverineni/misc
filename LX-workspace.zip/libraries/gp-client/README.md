GP Client
=========

Generated and client code for interacting with GPs SOAP web services

Instructions
------------

1. Generate code by running JAXB_WSDL.bat

_Note: The WSDL file is included in this repository as it is large and it's regular uri might move_

