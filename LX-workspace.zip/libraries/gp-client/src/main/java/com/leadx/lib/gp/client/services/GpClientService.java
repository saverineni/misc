package com.leadx.lib.gp.client.services;

import org.apache.http.auth.NTCredentials;

import com.leadx.lib.gp.client.exceptions.GpClientException;
import com.microsoft.schemas.dynamics.gp._2006._01.Customer;
import com.microsoft.schemas.dynamics.gp._2006._01.SalesInvoice;

public interface GpClientService {

	void createCustomer(Customer customer, NTCredentials credentials) throws GpClientException;

	void createSalesInvoice(SalesInvoice salesInvoice, NTCredentials credentials) throws GpClientException;

	void getCustomerByKey(String key, NTCredentials credentials) throws GpClientException;

	void getCompanyByKey(int companyKey, NTCredentials credentials) throws GpClientException;

	void getSalesInvoiceByKey(final String key, NTCredentials credentials) throws GpClientException;

}
