package com.leadx.lib.gp.client.services;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;

import org.apache.http.auth.NTCredentials;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceOperations;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.core.SoapActionCallback;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;

import com.leadx.lib.gp.client.exceptions.GpClientException;
import com.leadx.lib.spring.AutowiredProperty;
import com.microsoft.schemas.dynamics._2006._01.CompanyKey;
import com.microsoft.schemas.dynamics._2006._01.Context;
import com.microsoft.schemas.dynamics.gp._2006._01.CreateCustomer;
import com.microsoft.schemas.dynamics.gp._2006._01.CreateSalesInvoice;
import com.microsoft.schemas.dynamics.gp._2006._01.Customer;
import com.microsoft.schemas.dynamics.gp._2006._01.CustomerKey;
import com.microsoft.schemas.dynamics.gp._2006._01.GetCompanyByKey;
import com.microsoft.schemas.dynamics.gp._2006._01.GetCustomerByKey;
import com.microsoft.schemas.dynamics.gp._2006._01.GetSalesInvoiceByKey;
import com.microsoft.schemas.dynamics.gp._2006._01.SalesDocumentKey;
import com.microsoft.schemas.dynamics.gp._2006._01.SalesInvoice;

@Service
public class GpClientServiceImpl implements GpClientService {

	private static final Logger LOG = LoggerFactory.getLogger(GpClientServiceImpl.class);

	private static final String GP_ENDPOINT_STRING = "http://%s:%s/DynamicsGPWebServices/DynamicsGPService.asmx";

	@Autowired
	private WebServiceOperations webServiceOperations;

	@AutowiredProperty("gp.client.gp.server.host")
	private String gpHost;

	@AutowiredProperty("gp.client.gp.server.port")
	private Integer gpPort;

	@AutowiredProperty("gp.client.gp.server.companyId")
	private Integer companyId;

	private final WebServiceMessageCallback createCustomerSoapAction =
			new SoapActionCallback("http://schemas.microsoft.com/dynamics/gp/2006/01/CreateCustomer");

	private final WebServiceMessageCallback createSalesInvoiceSoapAction = new SoapActionCallback(
			"http://schemas.microsoft.com/dynamics/gp/2006/01/CreateSalesInvoice");

	private final WebServiceMessageCallback getSalesInvoiceByKeySoapAction = new SoapActionCallback(
			"http://schemas.microsoft.com/dynamics/gp/2006/01/GetSalesInvoiceByKey");

	private final WebServiceMessageCallback getCustomerByKeySoapAction = new SoapActionCallback(
			"http://schemas.microsoft.com/dynamics/gp/2006/01/GetCustomerByKey");

	private final WebServiceMessageCallback getCompanyByKeySoapAction = new SoapActionCallback(
			"http://schemas.microsoft.com/dynamics/gp/2006/01/GetCompanyByKey");

	@Override
	public void createCustomer(final Customer customer, final NTCredentials credentials) {
		final CreateCustomer createCustomer = new CreateCustomer();
		createCustomer.setCustomer(customer);
		createCustomer.setContext(createContext());

		sendRequest(createCustomer, this.createCustomerSoapAction, credentials);
	}

	@Override
	public void createSalesInvoice(final SalesInvoice invoice, final NTCredentials credentials) throws GpClientException {
		final CreateSalesInvoice createSalesInvoice = new CreateSalesInvoice();
		createSalesInvoice.setSalesInvoice(invoice);
		createSalesInvoice.setContext(createContext());

		sendRequest(createSalesInvoice, this.createSalesInvoiceSoapAction, credentials);
	}

	@Override
	public void getCustomerByKey(final String key, final NTCredentials credentials) throws GpClientException {
		final GetCustomerByKey getCustomerByKey = new GetCustomerByKey();
		getCustomerByKey.setContext(createContext());
		final CustomerKey customerKey = new CustomerKey();
		customerKey.setId(key);
		getCustomerByKey.setKey(customerKey);

		sendRequest(getCustomerByKey, this.getCustomerByKeySoapAction, credentials);
	}

	@Override
	public void getCompanyByKey(final int key, final NTCredentials credentials) throws GpClientException {
		final GetCompanyByKey getCompanyByKey = new GetCompanyByKey();
		// empty context required by GetCompanyByKey
		getCompanyByKey.setContext(new Context());
		final CompanyKey companyKey = new CompanyKey();
		companyKey.setId(key);
		getCompanyByKey.setKey(companyKey);

		sendRequest(getCompanyByKey, this.getCompanyByKeySoapAction, credentials);
	}

	@Override
	public void getSalesInvoiceByKey(final String key, final NTCredentials credentials) throws GpClientException {
		final GetSalesInvoiceByKey getSalesInvoiceByKey = new GetSalesInvoiceByKey();
		getSalesInvoiceByKey.setContext(createContext());
		final SalesDocumentKey sdk = new SalesDocumentKey();
		sdk.setId(key);
		getSalesInvoiceByKey.setKey(sdk);

		sendRequest(getSalesInvoiceByKey, this.getSalesInvoiceByKeySoapAction, credentials);
	}

	private Context createContext() {
		final Context context = new Context();
		final CompanyKey companyKey = new CompanyKey();
		companyKey.setId(this.companyId);
		context.setOrganizationKey(companyKey);
		return context;
	}

	private void sendRequest(final Object request, final WebServiceMessageCallback soapAction, final NTCredentials credentials) {
		try {
			final String gpEndpoint = String.format(GP_ENDPOINT_STRING, this.gpHost, this.gpPort);
			if (LOG.isDebugEnabled()) {
				LOG.debug("Sending request to GP: " + request);
				debugJAXBObject(request);
			}
			final HttpComponentsMessageSender messageSender = new HttpComponentsMessageSender();
			messageSender.setCredentials(credentials);
			try {
				messageSender.afterPropertiesSet();
			}
			catch (final Exception e) {
				throw new GpClientException("Failed to set-up credentials", e);
			}
			((WebServiceTemplate) this.webServiceOperations).setMessageSender(messageSender);
			final Object result = this.webServiceOperations.marshalSendAndReceive(gpEndpoint, request, soapAction);
			if (LOG.isDebugEnabled()) {
				LOG.debug("GP request successful, result: " + result);
				debugJAXBObject(result);
			}
		}
		catch (final WebServiceClientException exp) {
			LOG.error("Exception making GP request", exp);
			throw new GpClientException("Exception making GP request", exp);
		}
		catch (final JAXBException e) {
			LOG.debug("Exception logging result xml debug", e);
			// no need to rethrow
		}
		catch (final RuntimeException e) {
			LOG.error("Exception making GP request", e);
			throw e;
		}
	}

	private static void debugJAXBObject(final Object result) throws JAXBException, PropertyException {
		final JAXBContext jaxbContext = JAXBContext.newInstance(result.getClass());
		final Marshaller m = jaxbContext.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		final StringWriter writer = new StringWriter();
		m.marshal(result, writer);
		LOG.debug(writer.toString());
	}
}
