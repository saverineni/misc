package com.leadx.lib.gp.client.exceptions;

/**
 * @author gareth.evans
 */
public class GpClientException extends RuntimeException {

	private static final long serialVersionUID = -9080231068436875922L;

	public GpClientException(final String message) {
		super(message);
	}

	public GpClientException(final String message, final Throwable cause) {
		super(message, cause);
	}

}
