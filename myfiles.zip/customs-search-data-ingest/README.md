# Customs Data Spark Job


## Testing
Run `./data-setup.sh` before running unit tests.
