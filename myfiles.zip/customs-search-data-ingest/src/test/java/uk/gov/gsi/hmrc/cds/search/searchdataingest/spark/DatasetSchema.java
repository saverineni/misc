package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark;

import com.google.common.collect.Lists;

import java.util.List;

public interface DatasetSchema {
    List<String> expectedDeclarationFieldNames = Lists.newArrayList(
            "declarationId",
            "epuNumber",
            "entryNumber",
            "entryDate",
            "route",
            "dispatchCountry",
            "destinationCountry",
            "consigneeTurn",
            "consignorTurn",
            "goodsLocation",
            "transportModeCode",
            "consigneeName",
            "consigneePostcode",
            "consignorName",
            "consignorPostcode",
            "lines"
    );

    List<String> expectedDeclarationLine = Lists.newArrayList(
            "itemNumber",
            "dispatchCountryCode",
            "destinationCountryCode",
            "clearanceDate",
            "cpc",
            "originCountryCode",
            "commodityCode",
            "itemConsigneeTurn",
            "itemConsignorTurn",
            "itemRoute",
            "itemConsigneeName",
            "itemConsigneePostcode",
            "itemConsignorName",
            "itemConsignorPostcode"
    );
}
