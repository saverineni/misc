package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark;

import java.io.File;

import org.apache.spark.sql.SparkSession;

import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader.ResourceService;

public class HiveDatabaseSetup {

    private SparkSession sparkSession;
    private ResourceService resourceService;

    public HiveDatabaseSetup(SparkSession sparkSession, ResourceService resourceService) {
        this.sparkSession = sparkSession;
        this.resourceService = resourceService;
    }

    private File mssSourceFilePath = new File("src/test/resources/mss/ingestion-pipeline-output");

    public void setUp() {

        String mssSourceFilePathAbsolutePath = mssSourceFilePath.getAbsolutePath();

        sparkSession.sql(String.format("DROP DATABASE IF EXISTS search CASCADE"));
        sparkSession.sql(String.format("CREATE DATABASE IF NOT EXISTS search"));
        sparkSession.sql(getDdlFor("imenselect"));
        sparkSession.sql(getDdlFor("imendetail"));
        sparkSession.sql(getDdlFor("imeiselect"));
        sparkSession.sql(getDdlFor("inad"));
        sparkSession.sql(getDdlFor("iica"));
        sparkSession.sql(getDdlFor("iina"));
        sparkSession.sql(getDdlFor("nxenselect"));
        sparkSession.sql(getDdlFor("nxendetail"));
        sparkSession.sql(getDdlFor("nxeiselect"));
        sparkSession.sql(getDdlFor("nxeidetail"));
        sparkSession.sql(getDdlFor("nxnad"));
        sparkSession.sql(getDdlFor("nxica"));
        sparkSession.sql(getDdlFor("nxina"));

        loadDataFor(mssSourceFilePathAbsolutePath, "imenselect");
        loadDataFor(mssSourceFilePathAbsolutePath, "imendetail");
        loadDataFor(mssSourceFilePathAbsolutePath, "imeiselect");
        loadDataFor(mssSourceFilePathAbsolutePath, "inad");
        loadDataFor(mssSourceFilePathAbsolutePath, "iica");
        loadDataFor(mssSourceFilePathAbsolutePath, "iina");
        loadDataFor(mssSourceFilePathAbsolutePath, "nxenselect");
        loadDataFor(mssSourceFilePathAbsolutePath, "nxendetail");
        loadDataFor(mssSourceFilePathAbsolutePath, "nxeiselect");
        loadDataFor(mssSourceFilePathAbsolutePath, "nxeidetail");
        loadDataFor(mssSourceFilePathAbsolutePath, "nxnad");
        loadDataFor(mssSourceFilePathAbsolutePath, "nxica");
        loadDataFor(mssSourceFilePathAbsolutePath, "nxina");
    }

    private String getDdlFor(String tableName) {
        return resourceService.getResourceAsString(String.format("mss/ddl/%s.sql", tableName));
    }

    private void loadDataFor(String sourceFilePath, String tableName) {
        String loadfileTemplate = "load data local inpath '%s/%s/part-00000' overwrite into table search.%s";
        sparkSession.sql(String.format(loadfileTemplate, sourceFilePath, tableName, tableName));
    }
}
