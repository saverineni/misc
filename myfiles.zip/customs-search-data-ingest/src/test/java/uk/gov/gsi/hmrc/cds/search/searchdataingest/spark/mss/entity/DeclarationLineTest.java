package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.entity;

import static org.apache.spark.sql.functions.column;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.Assert.assertThat;

import java.lang.reflect.Modifier;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.spark.sql.Column;
import org.junit.Test;

public class DeclarationLineTest {
    @Test
    public void columnsShouldGiveColumnsForClassFieldsWithoutDeclarationId() {
        List<Column> expectedColumns = Stream.of(DeclarationLine.class.getDeclaredFields())
                .filter(it -> Modifier.isPrivate(it.getModifiers()))
                .filter(it -> !Modifier.isStatic(it.getModifiers()))
                .map(it -> it.getName())
                .filter(it -> !it.equals("declarationId"))
                .map(it -> column(it))
                .collect(Collectors.toList());


        assertThat(DeclarationLine.columns, containsInAnyOrder(expectedColumns.toArray()));
    }
}
