#!/bin/bash

echo "starting spark submit data setup job"

/spark/bin/spark-submit \
  --master local \
  --conf spark.sql.warehouse.dir=/hive-data/spark-warehouse \
  /setup.jar

result=$?

echo "finished spark submit job with status $result"

echo $result > /hive-data/setup-result

cat /hive-data/setup-result

exit $result
