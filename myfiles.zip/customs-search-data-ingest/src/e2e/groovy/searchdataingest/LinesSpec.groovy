package searchdataingest

import spock.lang.IgnoreRest
import spock.lang.Shared
import spock.lang.Specification

class LinesSpec extends Specification {
    @Shared List documents

    def setupSpec() {
        documents = new ESClient().documents()
    }

    def 'the correct number of lines should be added'(declarationId, size) {
        given:
        def lines = documents.find {
            it.declarationId == declarationId
        }.lines

        expect:
        lines.size() == size

        where:
        declarationId | size
        'IM001'       | 1
        'IM002'       | 4
        'EX001'       | 1
        'EX002'       | 2
    }

    def 'export lines should data should be correct'() {
        when:
        def line = declarationLine('EX002', 2)

        then:
        line == [
            clearanceDate: '2018-02-02 00:00:00.00',
            commodityCode: 'COMMODITY03',
            cpc: 'CPC03',
            destinationCountryCode: 'ITEMDESTCOUNTRY03',
            dispatchCountryCode: 'ITEMDISPATCHCOUNTRY03',
            itemConsigneeName: 'ITEMCONSIGNEENAME-EX002-02',
            itemConsigneePostcode: 'ITEMCONSIGNEEPOSTCODE-EX002-02',
            itemConsigneeTurn: 'ITEMCONSIGNEE03',
            itemConsignorName: 'ITEMCONSIGNORNAME-EX002-02',
            itemConsignorPostcode: 'ITEMCONSIGNORPOSTCODE-EX002-02',
            itemConsignorTurn: 'ITEMCONSIGNOR03',
            itemNumber: 2,
            itemRoute: 'ITEMROE-EX002-02',
            originCountryCode: 'COUNTRY97'
        ]
    }

    def 'import lines should data should be correct'() {
        when:
        def line = declarationLine('IM001', 1)

        then:
        line == [
                clearanceDate: '2018-02-01 00:00:00.00',
                commodityCode: 'COMMODITY01',
                cpc: 'CPC01',
                dispatchCountryCode: 'COUNTRY01',
                itemConsigneeName: 'ITEMCONSIGNEENAME-IM001-01',
                itemConsigneePostcode: 'ITEMCONSIGNEEPOSTCODE-IM001-01',
                itemConsigneeTurn: 'ITEMCONSIGNEE01',
                itemConsignorName: 'ITEMCONSIGNORNAME-IM001-01',
                itemConsignorPostcode: 'ITEMCONSIGNORPOSTCODE-IM001-01',
                itemConsignorTurn: 'ITEMCONSIGNOR01',
                itemNumber: 1,
                itemRoute: 'ITEMROE-IM001-01',
                originCountryCode: 'COUNTRY99'
        ]
    }

    def 'import lines should be sorted on item number'() {
        when:
        def lines = declarationLines('IM002')

        then:
        lines*.itemNumber == [1,2,3,4]
    }

    private declarationLine(declarationId, lineNumber) {
        declarationLines(declarationId).find {
            it.itemNumber == lineNumber
        }
    }

    private declarationLines(declarationId) {
        documents.find {
            it.declarationId == declarationId
        }.lines
    }
}
