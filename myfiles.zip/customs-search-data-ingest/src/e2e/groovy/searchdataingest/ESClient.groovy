package searchdataingest

import org.apache.http.client.fluent.Request

import groovy.json.JsonSlurper

class ESClient {
    final String esUrl = 'http://localhost:19201/customs'

    Map searchResponse() {
        getJson('_search')
    }

    List documents() {
        searchResponse().hits.hits*._source
    }

    Map countResponse() {
        getJson('_count')
    }

    private getJson(resource) {
        new JsonSlurper().parseText(get(resource).asString())

    }

    private get(resource) {
        Request.Get("$esUrl/$resource").execute().returnContent()
    }
}
