package searchdataingest

import org.apache.http.client.fluent.Request

import groovy.json.JsonSlurper
import spock.lang.Shared
import spock.lang.Specification

class HeaderSpec extends Specification {
    @Shared List headers

    def setupSpec() {
        headers = new ESClient().documents().collect {
            it.remove('lines')
            return it
        }
    }

    def 'export header data should be populated'() {
        expect:
        headers.find { it.declarationId == 'EX001' } == [
            consigneeName: 'CONSIGNEENAME01',
            consigneePostcode: 'CONSIGNEEPOSTCODE01',
            consigneeTurn: 'CONSIGNEE01',
            consignorName: 'CONSIGNORNAME01',
            consignorPostcode: 'CONSIGNORPOSTCODE01',
            consignorTurn: 'CONSIGNOR01',
            declarationId: 'EX001',
            destinationCountry: 'DESTCOUNTRY01',
            dispatchCountry: 'COUNTRY01',
            entryDate: '2018-01-01 00:00:00.00',
            entryNumber: 'ENTRY001',
            epuNumber: 'EPU01',
            goodsLocation: 'GOODSLOC01',
            route: 'ROE01',
            transportModeCode: 'TRANSPORTMODE01'
        ]
    }

    def 'import header data should be populated'() {
        expect:
        headers.find { it.declarationId == 'IM002' } == [
            consigneeName: 'CONSIGNEENAME02',
            consigneePostcode: 'CONSIGNEEPOSTCODE02',
            consigneeTurn: 'CONSIGNEE02',
            consignorName: 'CONSIGNORNAME02',
            consignorPostcode: 'CONSIGNORPOSTCODE02',
            consignorTurn: 'CONSIGNOR02',
            declarationId: 'IM002',
            dispatchCountry: 'COUNTRY02',
            entryDate: '2018-01-02 00:00:00.00',
            entryNumber: 'ENTRY002',
            epuNumber: 'EPU02',
            goodsLocation: 'GOODSLOC02',
            route: 'ROE02',
            transportModeCode: 'TRANSPORTMODE02'
        ]
    }
}
