#!/bin/bash

echo "starting spark submit elasticsearch data generation job"

/wait-for-elasticsearch-and-datasetup.sh /spark/bin/spark-submit \
  --master local \
  --conf spark.driver.extraJavaOptions='-Dspring.profiles.active=e2e' \
  --conf spark.executor.extraJavaOptions='-Dspring.profiles.active=e2e' \
  /app.jar | tee /var/log/e2e/spark-submit.log