package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;

@Data
public class DeclarationLine implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final Encoder<DeclarationLine> declarationLineEncoder = Encoders.bean(DeclarationLine.class);

    private String declarationId;
    private int    itemNumber;
    private String dispatchCountryCode;
    private String destinationCountryCode;
    private String clearanceDate;
    private String cpc;
    private String originCountryCode;
    private String commodityCode;
    private String itemConsigneeTurn;
    private String itemConsignorTurn;
    private String itemRoute;
    private String itemConsigneeName;
    private String itemConsigneePostcode;
    private String itemConsignorName;
    private String itemConsignorPostcode;

}
