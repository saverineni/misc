package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import lombok.Data;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLine;

import java.io.Serializable;
import java.util.List;

import static org.apache.spark.sql.functions.column;

@Data
public class Declaration implements Serializable {

    private static final long serialVersionUID = 1L;

    public static String DECLARATION_ID_FIELD = "declarationId";

    public static Encoder<Declaration> declarationEncoder = Encoders.bean(Declaration.class);

    private String declarationId;
    private String epuNumber;
    private String entryNumber;
    private String entryDate;
    private String route;
    private String dispatchCountry;
    private String destinationCountry;
    private String consigneeTurn;
    private String consignorTurn;
    private String goodsLocation;
    private String transportModeCode;
    private String consigneeName;
    private String consigneePostcode;
    private String consignorName;
    private String consignorPostcode;
    private List<DeclarationLine> lines = Lists.newArrayList();

    public static List<Column> selectColumns = ImmutableList.of(
            column("declarationId"),
            column("epuNumber"),
            column("entryNumber"),
            column("entryDate"),
            column("route"),
            column("dispatchCountry"),
            column("destinationCountry"),
            column("consigneeTurn"),
            column("consignorTurn"),
            column("goodsLocation"),
            column("transportModeCode"),
            column("consigneeName"),
            column("consigneePostcode"),
            column("consignorName"),
            column("consignorPostcode"),
            column("lines")
    );

}
