package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader;

import org.apache.spark.sql.Dataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.entity.DeclarationHeader;

/**
 * Bean created in SparkReaderConfig.
 */
public class DeclarationHeaderReader{

    private final SqlReader<DeclarationHeader> sqlReader;
    private final String hiveSql;

    public DeclarationHeaderReader(SqlReader<DeclarationHeader> sqlReader, String hiveSql) {
        this.sqlReader = sqlReader;
        this.hiveSql = hiveSql;
    }

    public Dataset<DeclarationHeader> declarationHeaderDataset() {
        return sqlReader.buildDataset(hiveSql);
    }
}
