package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.entity;

import com.google.common.collect.ImmutableList;
import lombok.Data;
import org.apache.spark.sql.Column;

import java.io.Serializable;
import java.util.List;

import static org.apache.spark.sql.functions.column;

@Data
public class DeclarationLine implements Serializable, BaseEntity {

    private static final long serialVersionUID = 1L;

    private String declarationId;
    private int itemNumber;
    private String dispatchCountryCode;
    private String destinationCountryCode;
    private String clearanceDate;
    private String cpc;
    private String originCountryCode;
    private String commodityCode;
    private String itemConsigneeTurn;
    private String itemConsignorTurn;
    private String itemRoute;
    private String itemConsigneeName;
    private String itemConsigneePostcode;
    private String itemConsignorName;
    private String itemConsignorPostcode;

    public static List<Column> columns = ImmutableList.of(
            column("itemNumber"),
            column("dispatchCountryCode"),
            column("destinationCountryCode"),
            column("clearanceDate"),
            column("cpc"),
            column("originCountryCode"),
            column("commodityCode"),
            column("itemConsigneeTurn"),
            column("itemConsignorTurn"),
            column("itemRoute"),
            column("itemConsigneeName"),
            column("itemConsigneePostcode"),
            column("itemConsignorName"),
            column("itemConsignorPostcode")
    );
}
