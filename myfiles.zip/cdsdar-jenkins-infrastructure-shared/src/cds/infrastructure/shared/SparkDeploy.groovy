package cds.infrastructure.shared

import groovy.json.JsonSlurperClassic

class SparkDeploy {
    private final pipeline

    SparkDeploy(pipeline) {
        this.pipeline = pipeline
    }

    private static final jsonFormat = '''
    {
      "spark_job_version":"maven-groupId",
      "spark_job_artifact_id":"maven-artifactId",
      "spark_job_group_id":"1.0.0",
      "maven_repository_url":"maven_repository_url"
    }
    '''

    private static final jsonValidationMessage = "required JSON format: $jsonFormat"

    def validate(String json) {
        def params = new JsonSlurperClassic().parseText(json)

        assert params.spark_job_version != null : jsonValidationMessage
        assert params.spark_job_artifact_id != null : jsonValidationMessage
        assert params.spark_job_group_id != null : jsonValidationMessage
        assert params.maven_repository_url != null : jsonValidationMessage
    }

    def deploy(env, json) {
        pipeline.deploySparkJob(env, pipeline."getDockerHost_$env"(), json)
    }
}
