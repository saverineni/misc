package cds.infrastructure.shared

import groovy.json.JsonSlurperClassic

class DockerDeploy {
    private final pipeline

    DockerDeploy(pipeline) {
        this.pipeline = pipeline
    }

    private static final jsonFormat = '''
    {
      "docker_image":"image-name",
      "docker_container_name":"deployed-container-name",
      "docker_ports":[ "to:from", ... ]
    }
    '''

    private static final jsonValidationMessage = "required JSON format: $jsonFormat"

    def validate(String json) {
        def params = new JsonSlurperClassic().parseText(json)

        assert params.docker_image != null : jsonValidationMessage
        assert params.docker_container_name != null : jsonValidationMessage

        assert params.docker_ports.size() > 0 : jsonValidationMessage
        params.docker_ports.each { assert it ==~ /\d+:\d+/ : jsonValidationMessage }

        if (params.docker_environment) {
            assert params.docker_environment in Map : 'Optional docker_environment property should be key value pairs'
        }
    }

    def startContainer(env, json) {
        pipeline.startDockerContainer(env, pipeline."getDockerHost_$env"(), json)
    }
}
