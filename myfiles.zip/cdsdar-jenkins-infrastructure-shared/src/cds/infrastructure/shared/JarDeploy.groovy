package cds.infrastructure.shared

import groovy.json.JsonSlurperClassic

class JarDeploy {
    private final pipeline

    JarDeploy(pipeline) {
        this.pipeline = pipeline
    }

    private static final jsonFormat = '''
    {
      "groupId":"maven-groupId",
      "artifactId":"maven-artifactId",
      "version":"1.0.0"
    }
    '''

    private static final jsonValidationMessage = "required JSON format: $jsonFormat"

    def validate(String json) {
        def params = new JsonSlurperClassic().parseText(json)

        assert params.groupId != null : jsonValidationMessage
        assert params.artifactId != null : jsonValidationMessage
        assert params.version != null : jsonValidationMessage
    }

    def deploy(env, maven_repo_url, json) {
        def params = new JsonSlurperClassic().parseText(json)
        pipeline.deployCustomsSearchIndexManager(env, pipeline."getDockerHost_$env"(), params.version, maven_repo_url)
    }
}
