#!/usr/bin/env groovy

def call(String environmentName, String variableHost) {
    dir(env.workspaceDir) {
        wrap([$class: 'AnsiColorBuildWrapper', colorMapName: "xterm"]) {
            ansiblePlaybook(
                colorized: true,
                credentialsId: getJenkinsDeployCredentialId(),
                extraVars: [
                    environment_name: environmentName,
                    variable_host   : variableHost,
                ],
                extras: getDebugExtras(environmentName, variableHost),
                installation: 'Default',
                inventoryContent: ansibleInventory(variableHost),
                playbook: 'ansible/rhel7-cloudera/docker_cloudera.yml',
                sudoUser: null,
                tags: 'deploy_cloudera'
            )
        }
    }
}