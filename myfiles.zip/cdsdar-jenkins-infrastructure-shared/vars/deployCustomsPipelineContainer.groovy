#!/usr/bin/env groovy
import groovy.json.JsonSlurperClassic
import static groovy.json.JsonOutput.*

def call(String environmentName, String variableHost, String artifactVersionJson = '') {
    if (artifactVersionJson.length() > 0) {
        echo "JSON version map passed, getting versions from there"

        parsedJson = parseArtifactVersionJson(artifactVersionJson)
        if (parsedJson instanceof ArrayList) {
            echo prettyPrint(toJson(parsedJson))
            echo "This looks like a list, flattening JSON"
            jsonVersions = flattenListOfMaps(parsedJson)
        } else if (parsedJson instanceof Map) {
            jsonVersions = parsedJson
        }
        echo prettyPrint(toJson(jsonVersions))

        script {
            customsPipelineDvHashCalculatorVersion = jsonVersions.get('customs_pipeline_dv_hash_calculator_version', '')
            customsPipelineExploitationReportVersion = jsonVersions.get('customs_pipeline_exploitation_report_version', '')
            customsPipelineGenericDataModelVersion = jsonVersions.get('customs_pipeline_generic_data_model_version', '')
            customsPipelineLandingVersion = jsonVersions.get('customs_pipeline_landing_version', '')
            pentahoScriptsVersion = jsonVersions.get('customs_pipeline_version', '')
        }
    } else {
        echo "No JSON version map passed"

        def repositoryToUse = 'releases'
        def devEnvironments = ['automationdev', 'dev', 'test']
        if (devEnvironments.contains(environmentName)) {
            repositoryToUse = 'snapshots'
        }

        echo "Environment: ${environmentName}"
        echo "Selected Nexus repository: ${repositoryToUse}"

        script {
            customsPipelineDvHashCalculatorVersion = getLatestArtifactVersion(repositoryToUse, 'uk.gov.gsi.hmrc.cds.datavault', 'datavault-hash-calculator')
            customsPipelineExploitationReportVersion = getLatestArtifactVersion(repositoryToUse, 'uk.gov.gsi.hmrc.cds.data', 'customs-pipeline-exploitation-report')
            customsPipelineGenericDataModelVersion = getLatestArtifactVersion(repositoryToUse, 'uk.gov.gsi.hmrc.cds.data', 'customs-pipeline-generic-data-model')
            customsPipelineLandingVersion = getLatestArtifactVersion(repositoryToUse, 'uk.gov.gsi.hmrc.cds.data', 'customs-pipeline-landing')
            if (repositoryToUse == 'releases') {
                pentahoScriptsVersion = '' // we never deploy pentaho-scripts as a release, it's a snapshot used only for dev purposes
            } else {
                pentahoScriptsVersion = getLatestArtifactVersion(repositoryToUse, 'uk.gov.gsi.hmrc.cds.data', 'customs-pipeline')
            }
        }
    }

    echo "Final values:"
    echo "customsPipelineDvHashCalculatorVersion = ${customsPipelineDvHashCalculatorVersion}"
    echo "customsPipelineExploitationReportVersion = ${customsPipelineExploitationReportVersion}"
    echo "customsPipelineGenericDataModelVersion = ${customsPipelineGenericDataModelVersion}"
    echo "customsPipelineLandingVersion = ${customsPipelineLandingVersion}"
    echo "pentahoScriptsVersion = ${pentahoScriptsVersion}"

    dir(env.workspaceDir + '/ansible/docker-deploy') {
        wrap([$class: 'AnsiColorBuildWrapper', colorMapName: "xterm"]) {
            ansiblePlaybook(
                colorized: true,
                credentialsId: getJenkinsDeployCredentialId(),
                extraVars: [
                    customs_pipeline_dv_hash_calculator_version: customsPipelineDvHashCalculatorVersion,
                    customs_pipeline_exploitation_report_version: customsPipelineExploitationReportVersion,
                    customs_pipeline_generic_data_model_version: customsPipelineGenericDataModelVersion,
                    customs_pipeline_landing_version: customsPipelineLandingVersion,
                    environment_name: environmentName,
                    pentaho_scripts_version: pentahoScriptsVersion,
                    variable_host: variableHost,
                ],
                extras: getDebugExtras(environmentName, variableHost),
                installation: 'Default',
                inventoryContent: ansibleInventory(variableHost),
                playbook: 'deploy.yml',
                sudoUser: null,
                tags: 'ssh_key_config_cdsdar,customs_pipeline_deploy'
            )
        }
    }
}

@NonCPS
def flattenListOfMaps(ArrayList jsonList) {
    def flattenedMap = [:]
    jsonList.each {
        flattenedMap << it
    }
    return flattenedMap
}

@NonCPS
def parseArtifactVersionJson(String json) {
    return new JsonSlurperClassic().parseText(json)
}