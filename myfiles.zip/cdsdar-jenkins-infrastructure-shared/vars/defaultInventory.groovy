#!/usr/bin/env groovy

def call(String variableHost) {
    return """
[cdsdar]
${variableHost}
"""
}