#!/usr/bin/env groovy

def call(String variableHost) {
    dir(env.workspaceDir) {
        script {
            def buildName = sh(script: 'curl -s http://10.102.81.196:9080/job/CDSDAR/job/Infrastructure/job/Core/job/Cloudera_Build/job/2_Create_Image/lastSuccessfulBuild/api/json?tree=displayName | jq -r .displayName', returnStdout: true).trim()
        }

        wrap([$class: 'AnsiColorBuildWrapper', colorMapName: "xterm"]) {
            ansiblePlaybook(
                colorized: true,
                credentialsId: getJenkinsDeployCredentialId(),
                extraVars: [
                    variable_host: variableHost,
                ],
                installation: 'Default',
                inventoryContent: ansibleInventory(variableHost),
                playbook: 'ansible/rhel7-cloudera/docker_cloudera.yml',
                sudoUser: null,
                tags: 'docker_cloudera_image_build'
            )
        }
    }
    return buildName
}