#!/usr/bin/env groovy
import groovy.json.JsonSlurperClassic
import static groovy.json.JsonOutput.*

def call(String environmentName, String variableHost) {
    def repositoryToUse = 'releases'

    def devEnvironments = ['automationdev', 'dev', 'test']
    if (devEnvironments.contains(environmentName)) {
        repositoryToUse = 'snapshots'
    }

    echo "Environment: ${environmentName}"
    echo "Selected Nexus repository: ${repositoryToUse}"

    script {
        customsGenericDataModelSchemaVersion = getLatestArtifactVersion(repositoryToUse, 'uk.gov.gsi.hmrc.cds.data', 'customs-generic-data-model-schema')
    }

    echo "Final values:"
    echo "customsGenericDataModelSchemaVersion = ${customsGenericDataModelSchemaVersion}"

    dir(env.workspaceDir + '/ansible/docker-deploy') {
        wrap([$class: 'AnsiColorBuildWrapper', colorMapName: "xterm"]) {
            ansiblePlaybook(
                colorized: true,
                credentialsId: getJenkinsDeployCredentialId(),
                extraVars: [
                    customs_generic_data_model_schema_version: customsGenericDataModelSchemaVersion,
                    environment_name: environmentName,
                    variable_host: variableHost,
                ],
                extras: getDebugExtras(environmentName, variableHost),
                installation: 'Default',
                inventoryContent: ansibleInventory(variableHost),
                playbook: 'deploy.yml',
                sudoUser: null,
                tags: 'ssh_key_config_cdsdar,customs_generic_data_model_schema'
            )
        }
    }
}