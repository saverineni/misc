#!/usr/bin/env groovy
import groovy.json.JsonSlurperClassic
import static groovy.json.JsonOutput.*

def call(String environmentName, String variableHost, String dockerJson) {
    parsedJson = parseDockerJson(dockerJson)

    echo prettyPrint(toJson(parsedJson))

    script {
        dockerContainerName = parsedJson.get('docker_container_name')
    }

    echo "Final values:"
    echo "dockerContainerName = ${dockerContainerName}"

    dir(env.workspaceDir + '/ansible/docker-deploy') {
        wrap([$class: 'AnsiColorBuildWrapper', colorMapName: "xterm"]) {
            ansiblePlaybook(
                colorized: true,
                credentialsId: getJenkinsDeployCredentialId(),
                extraVars: [
                    docker_container_name: dockerContainerName,
                ],
                extras: getDebugExtras(environmentName, variableHost),
                installation: 'Default',
                inventoryContent: ansibleInventory(variableHost),
                playbook: 'docker_container_operations.yml',
                sudoUser: null,
                tags: 'stop_docker_container',
            )
        }
    }
}

@NonCPS
def parseDockerJson(String json) {
    return new JsonSlurperClassic().parseText(json)
}