#!/usr/bin/env groovy

def call(String environmentName, String variableHost, Boolean preserveExistingData = false) {
    if (preserveExistingData == true) {
        echo "Preserving existing customs_pipeline container data as requested"
    }

    dir(env.workspaceDir + '/ansible/docker-deploy') {
        wrap([$class: 'AnsiColorBuildWrapper', colorMapName: "xterm"]) {
            ansiblePlaybook(
                colorized: true,
                credentialsId: getJenkinsDeployCredentialId(),
                extraVars: [
                    environment_name: environmentName,
                    variable_host: variableHost,
                    preserve_existing_data: String.valueOf(preserveExistingData), // true = ansible won't delete host data directory
                ],
                extras: getDebugExtras(environmentName, variableHost),
                installation: 'Default',
                inventoryContent: ansibleInventory(variableHost),
                playbook: 'deploy.yml',
                sudoUser: null,
                tags: 'host_infrastructure,customs_pipeline_host_infrastructure,customs_pipeline_container_base_infrastructure,customs_pipeline_container_infrastructure'
            )
        }
    }
}