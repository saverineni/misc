#!/usr/bin/env groovy

def call() {
    dir(env.workspaceDir + '/ansible') {
        wrap([$class: 'AnsiColorBuildWrapper', colorMapName: "xterm"]) {
            sh('find . -maxdepth 2 -name "*.yml" | grep -v vars | grep -v vault | xargs ansible-playbook -i hosts -e \'variable_host=test\' --syntax-check')
        }
    }
}