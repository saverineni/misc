#!/usr/bin/env groovy

def call() {
    return "#jenkins"
}