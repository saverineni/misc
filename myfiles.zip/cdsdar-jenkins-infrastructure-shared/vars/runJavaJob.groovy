#!/usr/bin/env groovy

def call(String environmentName, String variableHost, String artifactId = '', String arguments = '') {

    dir(env.workspaceDir + '/ansible/docker-deploy') {
        wrap([$class: 'AnsiColorBuildWrapper', colorMapName: "xterm"]) {
            ansiblePlaybook(
                colorized: true,
                credentialsId: getJenkinsDeployCredentialId(),
                extraVars: [
                        environment_name: environmentName,
                        variable_host: variableHost,
                        artifact_id: artifactId,
                        command_arguments: arguments
                ],
                extras: getDebugExtras(environmentName, variableHost),
                installation: 'Default',
                inventoryContent: ansibleInventory(variableHost),
                playbook: 'run_java_job.yml',
                sudoUser: null
            )
        }
    }
}