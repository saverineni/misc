#!/usr/bin/env groovy

def call(String clouderaImageBuildName, String variableHost) {
    dir(env.workspaceDir) {
        wrap([$class: 'AnsiColorBuildWrapper', colorMapName: "xterm"]) {
            ansiblePlaybook(
                colorized: true,
                credentialsId: getJenkinsDeployCredentialId(),
                extraVars: [
                    backup_details: clouderaImageBuildName,
                    variable_host: variableHost,
                ],
                extras: getDebugExtras(environmentName, variableHost),
                installation: 'Default',
                inventoryContent: ansibleInventory(variableHost),
                playbook: 'ansible/rhel7-cloudera/docker_cloudera_start_prebuilt_image.yml',
                sudoUser: null,
                tags: null
            )
        }
    }
}