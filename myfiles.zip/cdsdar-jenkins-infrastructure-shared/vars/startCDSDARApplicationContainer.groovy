#!/usr/bin/env groovy

def call(String environmentName, String variableHost) {
    dir(env.workspaceDir + '/ansible/docker-deploy') {
        wrap([$class: 'AnsiColorBuildWrapper', colorMapName: "xterm"]) {
            ansiblePlaybook(
                colorized: true,
                credentialsId: getJenkinsDeployCredentialId(),
                extraVars: [
                    environment_name: environmentName,
                    variable_host: variableHost,
                ],
                extras: getDebugExtras(environmentName, variableHost),
                installation: 'Default',
                inventoryContent: ansibleInventory(variableHost),
                playbook: 'deploy.yml',
                sudoUser: null,
                tags: 'host_infrastructure,cdsdar_application_host_infrastructure,cdsdar_application_container_base_infrastructure'
            )
        }
    }
}