#!/usr/bin/env groovy

def call(String type, String messageToSend) {
    endpointString = getCDSDARMattermostEndpoint();
    messagePrefix = ""

    if (type == "success") {
        colourString = "good"
    } else if (type == "failure") {
        colourString = "danger"
        messagePrefix = "@channel "
    } else if (type == "aborted") {
        colourString = "warn"
    }

    mattermostSend (
            endpoint: endpointString,
            channel: getCDSDARMattermostJenkinsChannel(),
            color: colourString,
            message: messagePrefix + messageToSend,
    )
}