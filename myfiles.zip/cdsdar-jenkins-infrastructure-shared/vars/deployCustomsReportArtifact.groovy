#!/usr/bin/env groovy
import groovy.json.JsonSlurperClassic
import static groovy.json.JsonOutput.*

def call(String environmentName, String variableHost, String artifactVersionJson = '') {
    if (artifactVersionJson.length() > 0) {
        echo "JSON version map passed, getting versions from there"

        parsedJson = parseArtifactVersionJson(artifactVersionJson)
        if (parsedJson instanceof ArrayList) {
            echo prettyPrint(toJson(parsedJson))
            echo "This looks like a list, flattening JSON"
            jsonVersions = flattenListOfMaps(parsedJson)
        } else if (parsedJson instanceof Map) {
            jsonVersions = parsedJson
        }
        echo prettyPrint(toJson(jsonVersions))

        script {
            customsReportVersion = jsonVersions.get('customs_report_version')
        }
    } else {
        echo "No JSON version map passed"

        def repositoryToUse = 'releases'
        def devEnvironments = ['automationdev', 'dev', 'test']
        if (devEnvironments.contains(environmentName)) {
            repositoryToUse = 'snapshots'
        }

        echo "Environment: ${environmentName}"
        echo "Selected Nexus repository: ${repositoryToUse}"

        script {
            customsReportVersion = getLatestArtifactVersion(repositoryToUse, 'uk.gov.gsi.hmrc.cds.data', 'customs-report')
        }
    }

    echo "Final values:"
    echo "customsReportVersion = ${customsReportVersion}"

    dir(env.workspaceDir + '/ansible/docker-deploy') {
        wrap([$class: 'AnsiColorBuildWrapper', colorMapName: "xterm"]) {
            ansiblePlaybook(
                colorized: true,
                credentialsId: getJenkinsDeployCredentialId(),
                extraVars: [
                    customs_report_version: customsReportVersion,
                    environment_name: environmentName,
                    variable_host: variableHost,
                ],
                extras: getDebugExtras(environmentName, variableHost),
                installation: 'Default',
                inventoryContent: ansibleInventory(variableHost),
                playbook: 'deploy.yml',
                sudoUser: null,
                tags: 'ssh_key_config_cdsdar,customs_report'
            )
        }
    }
}

@NonCPS
def flattenListOfMaps(ArrayList jsonList) {
    def flattenedMap = [:]
    jsonList.each {
        flattenedMap << it
    }
    return flattenedMap
}

@NonCPS
def parseArtifactVersionJson(String json) {
    return new JsonSlurperClassic().parseText(json)
}