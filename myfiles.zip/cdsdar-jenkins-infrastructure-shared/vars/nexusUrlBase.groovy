#!/usr/bin/env groovy

def call() {
    return 'http://10.102.81.194:8081/nexus/service/local/artifact/maven?v=LATEST'
}