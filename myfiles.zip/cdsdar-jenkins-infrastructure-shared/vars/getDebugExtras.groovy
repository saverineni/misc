#!/usr/bin/env groovy

def call(String environmentName, String variableHost) {
    def debugExtras = ""
    def verboseEnvironments = ['test', 'aws']

    if (verboseEnvironments.contains(environmentName)) {
        debugExtras = "-vv"
    }

    return debugExtras
}