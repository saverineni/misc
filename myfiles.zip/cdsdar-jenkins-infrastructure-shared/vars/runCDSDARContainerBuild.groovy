#!/usr/bin/env groovy

def call(String environmentName, String variableHost) {
    dir(env.workspaceDir + '/ansible/docker-deploy') {
        wrap([$class: 'AnsiColorBuildWrapper', colorMapName: "xterm"]) {
            ansiblePlaybook(
                colorized: true,
                credentialsId: getJenkinsDeployCredentialId(),
                extraVars: [
                    environment_name: environmentName,
                    variable_host: variableHost,
                ],
                extras: '-vv',
                installation: 'Default',
                inventoryContent: defaultInventory(variableHost),
                playbook: 'build_containers.yml',
                sudoUser: null,
                tags: null,
            )
        }
    }
}