#!/usr/bin/env groovy
import groovy.json.JsonSlurperClassic
import static groovy.json.JsonOutput.*

def call(String environmentName, String variableHost, String dockerJson) {
    parsedJson = parseDockerJson(dockerJson)
    echo prettyPrint(toJson(parsedJson))

    script {
        dockerCommand = parsedJson.get('docker_command', '')
        dockerContainerName = parsedJson.get('docker_container_name')
        dockerEnvironment = parsedJson.get('docker_environment', '')
        dockerImage = parsedJson.get('docker_image')
        dockerPorts = parsedJson.get('docker_ports', '')
        dockerVolumes = parsedJson.get('docker_volumes', '')
    }

    echo "Parsed values:"
    echo "dockerCommand = ${dockerCommand}"
    echo "dockerContainerName = ${dockerContainerName}"
    echo "dockerEnvironment = ${dockerEnvironment}"
    echo "dockerImage = ${dockerImage}"
    echo "dockerPorts = ${dockerPorts}"
    echo "dockerVolumes = ${dockerVolumes}"

    def rebuildMap = [
        docker_container_name: dockerContainerName,
        docker_image: dockerImage,
    ]
    if (dockerCommand != "") {
        rebuildMap.put('docker_command', dockerCommand)
    }
    if (dockerEnvironment != "") {
        rebuildMap.put('docker_environment', dockerEnvironment)
    }
    if (dockerPorts != "") {
        rebuildMap.put('docker_ports', dockerPorts)
    }
    if (dockerVolumes != "") {
        rebuildMap.put('docker_volumes', dockerVolumes)
    }

    rebuiltJson = groovy.json.JsonOutput.toJson(rebuildMap)

    dir(env.workspaceDir + '/ansible/docker-deploy') {
        script {
            sh """
cat << EOF > extra-vars-file
${rebuiltJson}
EOF
"""
            sh 'cat extra-vars-file'
        }

        wrap([$class: 'AnsiColorBuildWrapper', colorMapName: "xterm"]) {
            ansiblePlaybook(
                colorized: true,
                credentialsId: getJenkinsDeployCredentialId(),
                extraVars: [
                    environment_name: environmentName,
                    variable_host: variableHost,
                ],
                extras: "-vv --extra-vars @extra-vars-file",
                installation: 'Default',
                inventoryContent: ansibleInventory(variableHost),
                playbook: 'docker_container_operations.yml',
                sudoUser: null,
                tags: 'start_docker_container',
            )
        }
    }
}

@NonCPS
def parseDockerJson(String json) {
    return new JsonSlurperClassic().parseText(json)
}