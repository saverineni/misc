#!/usr/bin/env groovy

def call() {
    return '10.179.59.208' // aws
}