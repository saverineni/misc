#!/usr/bin/env groovy

def call() {
    deleteDir()

    script {
        sh "mkdir -p ${env.workspaceDir}"
    }

    dir(env.workspaceDir) {
        checkout([
            $class: 'GitSCM',
            branches: scm.branches,
            browser:  [$class: 'Stash', url: 'http://10.102.81.191:7990/bitbucket/projects/CDSD/repos/dev-tools/'],
            doGenerateSubmoduleConfigurations: false,
            extensions: [
                [
                        $class: 'UserExclusion',
                        excludedUsers: 'Jenkins Continuous Integration Server\nJenkins'
                ], [
                        $class: 'LocalBranch',
                        localBranch: 'master'
                ]
            ],
            submoduleCfg: [],
            userRemoteConfigs: [[
                credentialsId: 'd5a619ec-0584-4830-9efa-05473c2c91bf', url: 'ssh://git@10.102.81.191:7999/cdsd/dev-tools.git'
            ]]
        ])
    }
}