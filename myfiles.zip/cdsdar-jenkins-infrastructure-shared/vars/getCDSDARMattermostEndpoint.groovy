#!/usr/bin/env groovy

def call() {
    return "http://10.102.83.154/hooks/fqtjpqeob3fotcx919f471d6xo"
}