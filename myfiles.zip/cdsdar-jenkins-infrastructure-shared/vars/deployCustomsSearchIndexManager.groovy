#!/usr/bin/env groovy

def call(String environmentName, String variableHost, String version , String mavenRepositoryUrl) {
    echo "running deploy customs search index manager: ${version}"

    echo "Environment: ${environmentName}"
    echo "Selected maven repository: ${mavenRepositoryUrl}"

    dir(env.workspaceDir + '/ansible/docker-deploy') {
        
        wrap([$class: 'AnsiColorBuildWrapper', colorMapName: "xterm"]) {
            ansiblePlaybook(
                colorized: true,
                credentialsId: getJenkinsDeployCredentialId(),
                extraVars: [
                    environment_name: environmentName,
                    variable_host: variableHost,
                    customs_search_index_manager_version: version,
                    maven_repository_url: mavenRepositoryUrl
                ],
                extras: getDebugExtras(environmentName, variableHost),
                installation: 'Default',
                inventoryContent: ansibleInventory(variableHost),
                playbook: 'deploy.yml',
                sudoUser: null,
                tags: 'customs_search_index_manager'
            )
        }
    }
}