package uk.gov.gsi.hmrc.cds.search.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import uk.gov.gsi.hmrc.cds.search.security.jwt.JwtAuthenticationProvider;

@Configuration
@Profile({"test","dev"})
@EnableWebSecurity
public class InMemorySecurityConfig extends SecurityConfig {

    @Autowired
    private JwtAuthenticationProvider jwtAuthenticationProvider;

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) {
        // DaoAuthenticationProvider is included by spring by default and is dependent on userDetailsService
         auth.authenticationProvider(jwtAuthenticationProvider);
    }

    @Bean
    @Profile({"test","dev"})
    public DaoAuthenticationProvider authenticationProvider(){
        final DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider();
        daoAuthenticationProvider.setUserDetailsService(userDetailsService());
        return daoAuthenticationProvider;
    }

}