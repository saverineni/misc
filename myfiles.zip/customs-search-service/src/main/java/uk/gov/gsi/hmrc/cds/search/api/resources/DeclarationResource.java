package uk.gov.gsi.hmrc.cds.search.api.resources;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;
import uk.gov.gsi.hmrc.cds.search.api.services.SearchOrchestratorService;

import javax.validation.Valid;

@RestController
@RequiredArgsConstructor
public class DeclarationResource {

    private final SearchOrchestratorService searchOrchestratorService;

    @GetMapping(value = "/declarations")
    public DeclarationSearchResult getDeclarationSearchResult(@Valid GetDeclarationsRequest request) {
        return searchOrchestratorService.fetchDeclarationSearchResult(request.getSearchTerm());
    }
}