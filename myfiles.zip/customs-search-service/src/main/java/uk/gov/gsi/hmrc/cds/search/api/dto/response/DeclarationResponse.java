package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import com.google.common.collect.Lists;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class DeclarationResponse {
    private String declarationId;
    private String epuNumber;
    private String entryNumber;
    private String entryDate;
    private String route;
    private String dispatchCountry;
    private String destinationCountry;
    private String consigneeTurn;
    private String consignorTurn;
    private String goodsLocation;
    private String transportModeCode;
    private String consigneeName;
    private String consigneePostcode;
    private String consignorName;
    private String consignorPostcode;
    private List<DeclarationLineResponse> lines = Lists.newArrayList();
}
