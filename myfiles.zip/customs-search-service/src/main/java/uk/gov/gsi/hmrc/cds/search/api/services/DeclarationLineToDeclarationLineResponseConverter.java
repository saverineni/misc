package uk.gov.gsi.hmrc.cds.search.api.services;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLineResponse;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.DeclarationLine;

@Component
public class DeclarationLineToDeclarationLineResponseConverter implements Converter<DeclarationLine, DeclarationLineResponse> {

    @Override
    public DeclarationLineResponse convert(DeclarationLine declarationLine) {
        return DeclarationLineResponse.builder()
                .itemNumber(declarationLine.getItemNumber())
                .dispatchCountryCode(declarationLine.getDispatchCountryCode())
                .destinationCountryCode(declarationLine.getDestinationCountryCode())
                .clearanceDate(declarationLine.getClearanceDate())
                .cpc(declarationLine.getCpc())
                .originCountryCode(declarationLine.getOriginCountryCode())
                .commodityCode(declarationLine.getCommodityCode())
                .itemConsigneeTurn(declarationLine.getItemConsigneeTurn())
                .itemConsignorTurn(declarationLine.getItemConsignorTurn())
                .itemRoute(declarationLine.getItemRoute())
                .itemConsigneeName(declarationLine.getItemConsigneeName())
                .itemConsigneePostcode(declarationLine.getItemConsigneePostcode())
                .itemConsignorName(declarationLine.getItemConsignorName())
                .itemConsignorPostcode(declarationLine.getItemConsignorPostcode())
                .build();
    }
}
