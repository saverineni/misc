package uk.gov.gsi.hmrc.cds.search.elasticsearch.domain;

import com.google.common.collect.Lists;
import lombok.Data;

import java.util.List;

@Data
public class SearchResult {
    private long totalHits = 0;
    private List<SearchHit> hits = Lists.newArrayList();

    public void addSearchHits(List<SearchHit> hits) {
        this.hits.addAll(hits);
    }
}
