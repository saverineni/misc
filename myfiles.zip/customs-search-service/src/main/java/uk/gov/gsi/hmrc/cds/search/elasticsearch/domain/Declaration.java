package uk.gov.gsi.hmrc.cds.search.elasticsearch.domain;

import java.util.List;

import com.google.common.collect.Lists;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Declaration {
    private String declarationId;
    private String epuNumber;
    private String entryNumber;
    private String entryDate;
    private String route;
    private String dispatchCountry;
    private String destinationCountry;
    private String consigneeTurn;
    private String consignorTurn;
    private String goodsLocation;
    private String transportModeCode;
    private String consigneeName;
    private String consigneePostcode;
    private String consignorName;
    private String consignorPostcode;
    private List<DeclarationLine> lines = Lists.newArrayList();

}
