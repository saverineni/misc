package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import static org.elasticsearch.index.query.QueryBuilders.multiMatchQuery;

import java.io.IOException;

import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.MultiMatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.connection.ESConnection;

@Slf4j
@Service
public class SearchService {

    private static final String[] SEARCH_FIELDS = {
            "declarationId",
            "epuNumber",
            "entryNumber",
            "consigneeTurn",
            "consigneeName",
            "consigneePostcode",
            "consignorTurn",
            "consignorName",
            "consignorPostcode",
            "lines.commodityCode",
            "lines.originCountryCode",
            "lines.cpc",
            "lines.itemConsigneeTurn",
            "lines.itemConsigneeName",
            "lines.itemConsigneePostcode",
            "lines.itemConsignorTurn",
            "lines.itemConsignorName",
            "lines.itemConsignorPostcode",
    };

    private final ESConnection connection;

    private final String searchAlias;

    @Autowired
    public SearchService(ESConnection connection,
                         @Value("${elasticsearch.alias}") String searchAlias) {
        this.connection = connection;
        this.searchAlias = searchAlias;
    }

    public SearchResponse declarationSearch(String searchTerm) {
        MultiMatchQueryBuilder builders = multiMatchQuery(searchTerm.trim(), SEARCH_FIELDS);
        return searchES(builders);
    }

    private SearchResponse searchES(QueryBuilder queryBuilder) {
        try (RestHighLevelClient client = connection.getRestClientInstance()) {

            SearchRequest searchRequest = new SearchRequest(searchAlias);
            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(queryBuilder);
            searchRequest.source(searchSourceBuilder);
            return client.search(searchRequest);
        } catch (IOException e) {
            log.error(String.format("Exception occurred: %s", e));
            throw new RuntimeException(e.getMessage());
        }
    }
}
