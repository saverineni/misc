package uk.gov.gsi.hmrc.cds.search.elasticsearch.domain;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DeclarationLine {
    private int itemNumber;
    private String dispatchCountryCode;
    private String destinationCountryCode;
    private String clearanceDate;
    private String cpc;
    private String originCountryCode;
    private String commodityCode;
    private String itemConsigneeTurn;
    private String itemConsignorTurn;
    private String itemRoute;
    private String itemConsigneeName;
    private String itemConsigneePostcode;
    private String itemConsignorName;
    private String itemConsignorPostcode;
}
