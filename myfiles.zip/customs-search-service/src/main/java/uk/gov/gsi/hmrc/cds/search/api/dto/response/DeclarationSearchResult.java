package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import lombok.Value;

import java.util.List;

@Value
public class DeclarationSearchResult {
    Hits hits;
    List<DeclarationResponse> declarations;
}


