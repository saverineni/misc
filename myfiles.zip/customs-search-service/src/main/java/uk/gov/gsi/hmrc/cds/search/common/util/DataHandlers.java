package uk.gov.gsi.hmrc.cds.search.common.util;

import java.util.function.Supplier;

public class DataHandlers {
    public static <T> T getNestedNullable(Supplier<T> supplier) {
        try {
            return supplier.get();
        } catch (NullPointerException e) {
            return null;
        }
    }
}
