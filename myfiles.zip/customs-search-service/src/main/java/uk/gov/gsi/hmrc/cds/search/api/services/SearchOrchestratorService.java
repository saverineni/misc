package uk.gov.gsi.hmrc.cds.search.api.services;

import lombok.RequiredArgsConstructor;
import org.elasticsearch.action.search.SearchResponse;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationResponse;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Hits;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.SearchHit;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.SearchResult;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchService;

import java.util.List;

import static java.util.stream.Collectors.toList;


@Component
@RequiredArgsConstructor
public class SearchOrchestratorService {

    private final SearchResponseMapperService searchResponseMapperService;

    private final SearchService searchService;

    private final ConversionService conversionService;

    public List<DeclarationResponse> fetchDeclarations(String searchTerm) {
        SearchResponse searchResponse = searchService.declarationSearch(searchTerm);
        SearchResult searchResult = searchResponseMapperService.mapResponse(searchResponse);

        return searchResult.getHits().stream()
                .map(SearchHit::getDeclaration)
                .map(declaration -> conversionService.convert(declaration, DeclarationResponse.class))
                .collect(toList());
    }

    public DeclarationSearchResult fetchDeclarationSearchResult(String searchTerm) {
        SearchResponse searchResponse = searchService.declarationSearch(searchTerm);
        SearchResult searchResult = searchResponseMapperService.mapResponse(searchResponse);

        List<DeclarationResponse> responses = searchResult.getHits().stream()
                .map(SearchHit::getDeclaration)
                .map(declaration -> conversionService.convert(declaration, DeclarationResponse.class))
                .collect(toList());
        return new DeclarationSearchResult(new Hits(searchResult.getTotalHits()), responses);
    }
}
