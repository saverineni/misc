package uk.gov.gsi.hmrc.cds.search.api.services;

import lombok.RequiredArgsConstructor;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationResponse;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLineResponse;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.Declaration;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.DeclarationLine;

import java.util.List;

import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;

@Component
@RequiredArgsConstructor
public class DeclarationToDeclarationResponseConverter implements Converter<Declaration, DeclarationResponse> {

    private final DeclarationLineToDeclarationLineResponseConverter lineConverter;

    @Override
    public DeclarationResponse convert(Declaration declaration) {
        if (declaration == null) {
            return null;
        }

        return DeclarationResponse.builder()
                .declarationId(declaration.getDeclarationId())
                .epuNumber(declaration.getEpuNumber())
                .entryNumber(declaration.getEntryNumber())
                .entryDate(declaration.getEntryDate())
                .route(declaration.getRoute())
                .dispatchCountry(declaration.getDispatchCountry())
                .destinationCountry(declaration.getDestinationCountry())
                .consigneeTurn(declaration.getConsigneeTurn())
                .consignorTurn(declaration.getConsignorTurn())
                .goodsLocation(declaration.getGoodsLocation())
                .transportModeCode(declaration.getTransportModeCode())
                .consigneeName(declaration.getConsigneeName())
                .consigneePostcode(declaration.getConsigneePostcode())
                .consignorName(declaration.getConsignorName())
                .consignorPostcode(declaration.getConsignorPostcode())
                .lines(linesFrom(declaration.getLines()))
                .build();
    }

    private List<DeclarationLineResponse> linesFrom(List<DeclarationLine> lines) {
        if (lines == null) {
            return emptyList();
        }
        return lines.stream()
                .map(lineConverter::convert)
                .collect(toList());
    }
}
