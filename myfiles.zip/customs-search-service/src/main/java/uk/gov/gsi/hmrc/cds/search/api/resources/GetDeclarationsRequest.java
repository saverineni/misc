package uk.gov.gsi.hmrc.cds.search.api.resources;

import lombok.Data;
import org.hibernate.validator.constraints.NotEmpty;

@Data
public class GetDeclarationsRequest {
    @NotEmpty private String searchTerm;
}
