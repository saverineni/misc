package uk.gov.gsi.hmrc.cds.search.elasticsearch.domain;


public class SearchHit {
    private Declaration declaration;

    public Declaration getDeclaration() {
        return declaration;
    }

    public void setDeclaration(Declaration declaration) {
        this.declaration = declaration;
    }
}
