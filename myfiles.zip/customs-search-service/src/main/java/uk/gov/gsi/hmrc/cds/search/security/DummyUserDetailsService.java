package uk.gov.gsi.hmrc.cds.search.security;

import static java.lang.String.format;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Profile;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

@Component
@Qualifier("userDetailsService")
@Profile({"test","dev"})
public class DummyUserDetailsService implements UserDetailsService {
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        switch(username) {
            case "dev":
                return new User("dev","dev",true,true,true,true, AuthorityUtils.createAuthorityList("DEV"));
            case "superdev":
                return new User("superdev","superdev",true,true,true,true, AuthorityUtils.createAuthorityList("SUPERDEV", "DEV"));
            case "tony":
                return new User("tony","cdsd@t@",true,true,true,true, AuthorityUtils.createAuthorityList("DEV"));
            case "mandy":
                return new User("mandy","cdsd@t@",true,true,true,true, AuthorityUtils.createAuthorityList("DEV"));
        }
        throw new UsernameNotFoundException(format("No such user %s", username));
    }
}
