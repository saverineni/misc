package uk.gov.gsi.hmrc.cds.search.security.jwt;

import io.jsonwebtoken.SignatureAlgorithm;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import uk.gov.gsi.hmrc.cds.search.security.jwt.JwtTokenService;
import uk.gov.gsi.hmrc.cds.search.security.jwt.JwtAuthenticationProvider;

import java.time.Clock;

@Configuration
@RequiredArgsConstructor
public class JwtConfig {


    private final Environment environment;

    @Bean
    public JwtTokenService jwtTokenService() {
        return new JwtTokenService(
                environment.getProperty("jwt.expiration.seconds", Integer.class),
                environment.getProperty("jwt.secret"),
                jwtHashingAlgorithm(),
                clock());
    }

    @Bean
    protected JwtAuthenticationProvider jwtAuthenticationProvider() {
        return new JwtAuthenticationProvider(jwtTokenService());
    }

    protected SignatureAlgorithm jwtHashingAlgorithm() {
        return SignatureAlgorithm.HS512;
    }

    protected Clock clock() {
        return Clock.systemUTC();
    }

}
