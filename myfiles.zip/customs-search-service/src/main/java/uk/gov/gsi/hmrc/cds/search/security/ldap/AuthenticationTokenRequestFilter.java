package uk.gov.gsi.hmrc.cds.search.security.ldap;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class AuthenticationTokenRequestFilter extends AbstractAuthenticationProcessingFilter {

    private ObjectMapper objectMapper;

    public AuthenticationTokenRequestFilter(String url, AuthenticationManager authenticationManager, ObjectMapper objectMapper) {
        super(new AntPathRequestMatcher(url, "POST"));
        this.objectMapper = objectMapper;
        setAuthenticationManager(authenticationManager);
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException, IOException, ServletException {
        UserDetails userDetails = getUserDetails(request);
        return getAuthenticationManager().authenticate(
                new UsernamePasswordAuthenticationToken(userDetails.getPid(), userDetails.getPassword())
        );
    }

    private UserDetails getUserDetails(HttpServletRequest request) throws IOException {
        try {
            return objectMapper.readValue(request.getInputStream(), UserDetails.class);
        } catch (JsonProcessingException e ) {
            throw new BadCredentialsException("credentials not found", e);
        }
    }

    @Value
    private static class UserDetails {
        String pid;
        String password;
    }

}
