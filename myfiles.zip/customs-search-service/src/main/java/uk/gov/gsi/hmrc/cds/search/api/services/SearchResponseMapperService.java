package uk.gov.gsi.hmrc.cds.search.api.services;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHits;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.Declaration;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.SearchHit;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.SearchResult;


@Component
@Slf4j
public class SearchResponseMapperService {

    private ObjectMapper objectMapper;
    
	public SearchResponseMapperService(ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
	}

	public SearchResult mapResponse(SearchResponse searchResponse) {
        return parseSearchResponse(searchResponse);
    }

    private SearchResult parseSearchResponse(SearchResponse searchResponse) {
        SearchResult searchResult = new SearchResult();

        SearchHits hits = searchResponse.getHits();

        List<SearchHit> searchHits = parseSearchHits(hits);
        searchResult.addSearchHits(searchHits);
        searchResult.setTotalHits(searchResponse.getHits().getTotalHits());

        return searchResult;
    }

    private List<SearchHit> parseSearchHits(SearchHits hits) {
        return Stream.of(hits.getHits())
                .map(searchHitFields -> {
                    SearchHit searchHit = new SearchHit();

                    String sourceAsString = searchHitFields.getSourceAsString();
                    try {
                        Declaration declaration = objectMapper.readValue(sourceAsString, Declaration.class);
                        searchHit.setDeclaration(declaration);
                    } catch (IOException e) {
                        log.error(String.format("Exception occurred: %s" , e));
                        throw new RuntimeException (e.getMessage ());
                    }
                    return searchHit;
                })
                .collect(Collectors.toList());
    }


}
