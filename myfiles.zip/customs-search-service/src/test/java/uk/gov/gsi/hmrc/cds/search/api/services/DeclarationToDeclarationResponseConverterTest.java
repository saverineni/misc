package uk.gov.gsi.hmrc.cds.search.api.services;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationResponse;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLineResponse;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.Declaration;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.DeclarationLine;

import static java.util.Collections.emptyList;
import static org.codehaus.groovy.runtime.InvokerHelper.asList;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DeclarationToDeclarationResponseConverterTest {

    @Mock
    private DeclarationLineToDeclarationLineResponseConverter lineConverter;

    private DeclarationToDeclarationResponseConverter converter;

    private Declaration declaration = givenADeclaration();

    @Before
    public void setup() {
        converter = new DeclarationToDeclarationResponseConverter(lineConverter);
    }

    @Test
    public void declarationId() {
        DeclarationResponse actual = whenIConvertADeclaration(declaration);
        assertThat(actual.getDeclarationId(), is(declaration.getDeclarationId()));
    }

    @Test
    public void epuNumber() {
        DeclarationResponse actual = whenIConvertADeclaration(declaration);
        assertThat(actual.getEpuNumber(), is(declaration.getEpuNumber()));
    }

    @Test
    public void entryNumber() {
        DeclarationResponse actual = whenIConvertADeclaration(declaration);
        assertThat(actual.getEntryNumber(), is(declaration.getEntryNumber()));
    }

    @Test
    public void entryDate() {
        DeclarationResponse actual = whenIConvertADeclaration(declaration);
        assertThat(actual.getEntryDate(), is(declaration.getEntryDate()));
    }

    @Test
    public void route() {
        DeclarationResponse actual = whenIConvertADeclaration(declaration);
        assertThat(actual.getRoute(), is(declaration.getRoute()));
    }

    @Test
    public void dispatchCountry() {
        DeclarationResponse actual = whenIConvertADeclaration(declaration);
        assertThat(actual.getDispatchCountry(), is(declaration.getDispatchCountry()));
    }

    @Test
    public void destinationCountry() {
        DeclarationResponse actual = whenIConvertADeclaration(declaration);
        assertThat(actual.getDestinationCountry(), is(declaration.getDestinationCountry()));
    }

    @Test
    public void consigneeTurn() {
        DeclarationResponse actual = whenIConvertADeclaration(declaration);
        assertThat(actual.getConsigneeTurn(), is(declaration.getConsigneeTurn()));
    }


    @Test
    public void consignorTurn() {
        DeclarationResponse actual = whenIConvertADeclaration(declaration);
        assertThat(actual.getConsignorTurn(), is(declaration.getConsignorTurn()));
    }

    @Test
    public void goodsLocation() {
        DeclarationResponse actual = whenIConvertADeclaration(declaration);
        assertThat(actual.getGoodsLocation(), is(declaration.getGoodsLocation()));
    }

    @Test
    public void transportModeCode() {
        DeclarationResponse actual = whenIConvertADeclaration(declaration);
        assertThat(actual.getTransportModeCode(), is(declaration.getTransportModeCode()));
    }

    @Test
    public void consigneeName() {
        DeclarationResponse actual = whenIConvertADeclaration(declaration);
        assertThat(actual.getConsigneeName(), is(declaration.getConsigneeName()));
    }

    @Test
    public void consigneePostcode() {
        DeclarationResponse actual = whenIConvertADeclaration(declaration);
        assertThat(actual.getConsigneePostcode(), is(declaration.getConsigneePostcode()));
    }

    @Test
    public void consignorName() {
        DeclarationResponse actual = whenIConvertADeclaration(declaration);
        assertThat(actual.getConsignorName(), is(declaration.getConsignorName()));
    }

    @Test
    public void consignorPostcode() {
        DeclarationResponse actual = whenIConvertADeclaration(declaration);
        assertThat(actual.getConsignorPostcode(), is(declaration.getConsignorPostcode()));
    }

    @Test
    public void givenDeclarationisNullThenReturnsNull() {
        DeclarationResponse actual = whenIConvertADeclaration(null);
        assertThat(actual, is(nullValue()));
    }

    @Test
    public void convertsDeclarationWithOneLine() {
        DeclarationLine declarationLine = givenADeclarationLine();
        declaration.setLines(asList(declarationLine));

        DeclarationLineResponse declarationLineResponse = givenLineConvertsFrom(declarationLine);

        DeclarationResponse actual = whenIConvertADeclaration(declaration);

        assertThat(actual.getLines(), contains(declarationLineResponse));
    }

    @Test
    public void convertsDeclarationWithNullLines() {
        declaration.setLines(null);

        DeclarationResponse actual = whenIConvertADeclaration(declaration);

        assertThat(actual.getLines(), is(empty()));
    }

    @Test
    public void convertsDeclarationWithEmptyLines() {
        declaration.setLines(emptyList());

        DeclarationResponse actual = whenIConvertADeclaration(declaration);

        assertThat(actual.getLines(), is(empty()));
    }

    private DeclarationResponse whenIConvertADeclaration(Declaration declaration) {
        return converter.convert(declaration);
    }

    private Declaration givenADeclaration() {
        return Declaration.builder()
                .declarationId("declaration-id")
                .epuNumber("epuNumber")
                .entryNumber("entryNumber")
                .entryDate("entryDate")
                .route("route")
                .dispatchCountry("dispatchCountry")
                .destinationCountry("destinationCountry")
                .consigneeTurn("consigneeTurn")
                .consignorTurn("consignorTurn")
                .goodsLocation("goodsLocation")
                .transportModeCode("transportModeCode")
                .consigneeName("consigneeName")
                .consigneePostcode("consigneePostcode")
                .consignorName("consignorName")
                .consignorPostcode("consignorPostcode")
                .build();
    }

    private DeclarationLine givenADeclarationLine() {
        return mock(DeclarationLine.class);
    }

    private DeclarationLineResponse givenLineConvertsFrom(DeclarationLine declarationLine) {
        DeclarationLineResponse declarationLineResponse = mock(DeclarationLineResponse.class);
        when(lineConverter.convert(declarationLine)).thenReturn(declarationLineResponse);
        return declarationLineResponse;
    }
}