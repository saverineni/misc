package uk.gov.gsi.hmrc.cds.search.common.util;

import lombok.Data;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest(classes = DataHandlers.class)
public class DataHandlersTest {

    @Data
    class TestObjectA {
        private TestObjectB b;

        private TestObjectA(TestObjectB b) {
            this.b = b;
        }
    }

    @Data
    class TestObjectB {
        private String string;

        private TestObjectB(String string) {
            this.string = string;
        }
    }

    @Test
    public void getNestedNullableShouldCatchAndReturnNulls() {
        TestObjectA valid = new TestObjectA((new TestObjectB("string")));
        TestObjectA nulled = new TestObjectA(null);

        assertEquals(DataHandlers.getNestedNullable(() -> valid.b.string), "string");
        assertNull(DataHandlers.getNestedNullable(() -> nulled.b.string));
    }

}
