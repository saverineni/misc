package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import com.carrotsearch.randomizedtesting.annotations.ThreadLeakScope;
import com.jayway.jsonpath.JsonPath;
import org.elasticsearch.action.bulk.BulkRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.document.DocumentField;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.plugins.Plugin;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.test.ESIntegTestCase;
import org.elasticsearch.test.ESIntegTestCase.ClusterScope;
import org.elasticsearch.test.ESIntegTestCase.Scope;
import org.elasticsearch.transport.Netty4Plugin;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.skyscreamer.jsonassert.JSONAssert;
import uk.gov.gsi.hmrc.cds.search.api.services.SearchResponseMapperService;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.connection.ESConnection;
import uk.gov.gsi.hmrc.cds.search.utils.TestHelper;

import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.stream.Collectors;

import static uk.gov.gsi.hmrc.cds.search.utils.TestHelper.*;

@ClusterScope(scope = Scope.SUITE, maxNumDataNodes = 0, minNumDataNodes = 0, numClientNodes = 0)
@ThreadLeakScope(ThreadLeakScope.Scope.NONE)
@RunWith(com.carrotsearch.randomizedtesting.RandomizedRunner.class)
public class SearchServiceIntegrationTest extends ESIntegTestCase {

    private static final String DECLARATION_TYPE = "declaration";

    private static final String CUSTOMS_INDEX = "customs";

    private static final String VALID_DECLARATION_ID_1 = "219-249099X-2013-07-14";
    private static final String VALID_DECLARATION_ID_2 = "219-249099X-2013-07-15";
    private static final String VALID_DECLARATION_ID_3 = "219-249099X-2013-07-16";

    private static final String EPU_NUMBER_219 = "219";
    private static final String EPU_NUMBER_220 = "220";
    private static final String DECLARATION_ID_AND_EPU = VALID_DECLARATION_ID_2 + " " + EPU_NUMBER_219;


    private static final String ES_HOST = "localhost";
    private static final int ES_PORT = 9600;

    private Client client;

    private SearchService service;

    @Override
    protected Collection<Class<? extends Plugin>> nodePlugins() {
        return Arrays.asList(Netty4Plugin.class);
    }

    @Override
    protected Settings nodeSettings(int nodeOrdinal) {
        Settings.Builder builder = Settings.builder();
        builder.put("transport.type", Netty4Plugin.NETTY_HTTP_TRANSPORT_NAME)
                .put("http.type", Netty4Plugin.NETTY_TRANSPORT_NAME)
                .put("http.enabled", "true")
                .put("http.port", String.valueOf(ES_PORT))
                .put("discovery.type", "single-node")
                .put("processors", "1");
        return builder.build();
    }

    @Before
    public void setUp() throws Exception {
        super.setUp();
        this.client = client();
        createCustomsIndexWithDocuments();
        this.service = new SearchService(new ESConnection(ES_HOST, ES_PORT), CUSTOMS_INDEX);
    }

    @Test
    public void searchByDeclarationId() {
        SearchResponse searchResponse = this.service.declarationSearch(VALID_DECLARATION_ID_1);
        assertEquals(1, searchResponse.getHits().totalHits);
        assertEquals(VALID_DECLARATION_ID_1, getFieldValue(searchResponse, 0, "$.declarationId"));
    }


    @Test
    public void searchByEPU() {
        SearchResponse searchResponse = this.service.declarationSearch(EPU_NUMBER_219);
        assertEquals(1, searchResponse.getHits().totalHits);
        assertEquals(EPU_NUMBER_219, getFieldValue(searchResponse, 0, "$.epuNumber"));
    }

    private Object getFieldValue(SearchResponse searchResponse, int hitIndex, String path) {
        SearchHit[] hits = searchResponse.getHits().getHits();
        String source = hits[hitIndex].getSourceAsString();
        return JsonPath.read(source, path);
    }

    @Test
    public void searchByEPUReturnsMultipleDeclarations() {
        SearchResponse searchResponse = this.service.declarationSearch(EPU_NUMBER_220);
        assertEquals(2, searchResponse.getHits().totalHits);
        assertEquals(EPU_NUMBER_220, getFieldValue(searchResponse, 0, "$.epuNumber"));
        assertEquals(EPU_NUMBER_220, getFieldValue(searchResponse, 1, "$.epuNumber"));
    }

    @Test
    public void searchByEPUAndDeclarationId() {
        SearchResponse searchResponse = this.service.declarationSearch(DECLARATION_ID_AND_EPU);
        assertEquals(0, searchResponse.getHits().totalHits);
    }

    @Test
    public void searchByEPUWithSpaces() {
        SearchResponse searchResponse = this.service.declarationSearch(" " + EPU_NUMBER_219);
        assertEquals(1, searchResponse.getHits().totalHits);
        assertEquals(EPU_NUMBER_219, getFieldValue(searchResponse, 0, "$.epuNumber"));
    }

    @Test
    public void searchByInvalidDeclarationId() {
        SearchResponse searchResponse = this.service.declarationSearch("unknown");
        assertEquals(0, searchResponse.getHits().totalHits);
    }

    @Test
    public void searchByEntryNumber() {
        SearchResponse searchResponse = this.service.declarationSearch("249099x");
        assertEquals(3, searchResponse.getHits().totalHits);
        assertEquals("249099x", getFieldValue(searchResponse, 0, "$.entryNumber"));
    }

    @Test
    public void searchByCommodityCode() {
        SearchResponse searchResponse = this.service.declarationSearch("551030");
        assertEquals(1, searchResponse.getHits().totalHits);
        assertEquals("551030", getFieldValue(searchResponse, 0, "$.lines[0].commodityCode"));
    }

    @Test
    public void searchByOriginCountry() {
        SearchResponse searchResponse = this.service.declarationSearch("PG");
        assertEquals(1, searchResponse.getHits().totalHits);
        assertEquals("PG", getFieldValue(searchResponse, 0, "$.lines[0].originCountryCode"));
    }

    @Test
    public void searchByCPC() {
        SearchResponse searchResponse = this.service.declarationSearch("4000C36");
        assertEquals(1, searchResponse.getHits().totalHits);
        assertEquals("4000C36", getFieldValue(searchResponse, 0, "$.lines[0].cpc"));
    }

    @Test
    public void searchByConsigneeNumberAtHeaderLevel() {
        SearchResponse searchResponse = this.service.declarationSearch("976072558688");
        assertEquals(1, searchResponse.getHits().totalHits);
        assertEquals("976072558688", getFieldValue(searchResponse, 0, "$.consigneeTurn"));
    }

    @Test
    public void searchByConsigneeNameAtHeaderLevel() {
        SearchResponse searchResponse = this.service.declarationSearch("Header NAD name");
        assertEquals(1, searchResponse.getHits().totalHits);
        assertEquals("Header NAD name", getFieldValue(searchResponse, 0, "$.consigneeName"));
    }

    @Test
    public void searchByConsigneePostcodeAtHeaderLevel() {
        SearchResponse searchResponse = this.service.declarationSearch("HN4 0PC");
        assertEquals(1, searchResponse.getHits().totalHits);
        assertEquals("HN4 0PC", getFieldValue(searchResponse, 0, "$.consigneePostcode"));
    }

    @Test
    public void searchByConsigneeNumberAtLineLevel() {
        SearchResponse searchResponse = this.service.declarationSearch("731411813911");
        assertEquals(1, searchResponse.getHits().totalHits);
        assertEquals("731411813911", getFieldValue(searchResponse, 0, "$.lines[0].itemConsigneeTurn"));
    }

    @Test
    public void searchByConsigneeNameAtLineLevel() {
        SearchResponse searchResponse = this.service.declarationSearch("Item NAD name");
        assertEquals(1, searchResponse.getHits().totalHits);
        assertEquals("Item NAD name", getFieldValue(searchResponse, 0, "$.lines[0].itemConsigneeName"));
    }

    @Test
    public void searchByConsigneePostcodeAtLineLevel() {
        SearchResponse searchResponse = this.service.declarationSearch("IN4 0PC");
        assertEquals(1, searchResponse.getHits().totalHits);
        assertEquals("IN4 0PC", getFieldValue(searchResponse, 0, "$.lines[0].itemConsigneePostcode"));
    }

    @Test
    public void searchByConsignorNumberAtHeaderLevel() {
        SearchResponse searchResponse = this.service.declarationSearch("1261170936");
        assertEquals(1, searchResponse.getHits().totalHits);
        assertEquals("1261170936", getFieldValue(searchResponse, 0, "$.consignorTurn"));
    }

    @Test
    public void searchByConsignorNameAtHeaderLevel() {
        SearchResponse searchResponse = this.service.declarationSearch("Header Consignor name");
        assertEquals(1, searchResponse.getHits().totalHits);
        assertEquals("Header Consignor name", getFieldValue(searchResponse, 0, "$.consignorName"));
    }

    @Test
    public void searchByConsignorPostcodeAtHeaderLevel() {
        SearchResponse searchResponse = this.service.declarationSearch("AB4 6CD");
        assertEquals(1, searchResponse.getHits().totalHits);
        assertEquals("AB4 6CD", getFieldValue(searchResponse, 0, "$.consignorPostcode"));
    }

    @Test
    public void searchByConsignorNumberAtLineLevel() {
        SearchResponse searchResponse = this.service.declarationSearch("1933705");
        assertEquals(1, searchResponse.getHits().totalHits);
        assertEquals("1933705", getFieldValue(searchResponse, 0, "$.lines[0].itemConsignorTurn"));
    }

    @Test
    public void searchByConsignorNameAtLineLevel() {
        SearchResponse searchResponse = this.service.declarationSearch("Item Consignor name");
        assertEquals(1, searchResponse.getHits().totalHits);
        assertEquals("Item Consignor name", getFieldValue(searchResponse, 0, "$.lines[0].itemConsignorName"));
    }

    @Test
    public void searchByConsignorPostcodeAtLineLevel() {
        SearchResponse searchResponse = this.service.declarationSearch("IB4 6CD");
        assertEquals(1, searchResponse.getHits().totalHits);
        assertEquals("IB4 6CD", getFieldValue(searchResponse, 0, "$.lines[0].itemConsignorPostcode"));
    }

    private void createCustomsIndexWithDocuments() throws Exception {

        client.admin().indices().prepareCreate(CUSTOMS_INDEX).addMapping(DECLARATION_TYPE,
                TestHelper.getFileContent(SEARCH_MAPPINGS_FILE), XContentType.JSON).execute().get();

        BulkRequestBuilder builder = client.prepareBulk();
        getBulkRequestBuilder(builder, VALID_SEARCH_INGEST_DECLARATION_FILE_1, VALID_DECLARATION_ID_1);
        getBulkRequestBuilder(builder, VALID_SEARCH_INGEST_DECLARATION_FILE_2, VALID_DECLARATION_ID_2);
        getBulkRequestBuilder(builder, VALID_SEARCH_INGEST_DECLARATION_FILE_3, VALID_DECLARATION_ID_3);

        builder.get();
        refresh();

    }

    private void getBulkRequestBuilder(BulkRequestBuilder builder, String validSearchIngestDeclarationFile, String validDeclarationId) {
        builder.add(this.client.prepareIndex(CUSTOMS_INDEX, DECLARATION_TYPE, validDeclarationId)
                .setSource(TestHelper.getFileContent(validSearchIngestDeclarationFile), XContentType.JSON));
    }

}
