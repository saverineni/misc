package uk.gov.gsi.hmrc.cds.search.api.resources;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationResponse;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Hits;
import uk.gov.gsi.hmrc.cds.search.api.services.SearchOrchestratorService;

import java.util.List;

import static java.util.Arrays.asList;
import static java.util.Collections.*;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(value = DeclarationResource.class, secure = false)
@ActiveProfiles("test")
public class DeclarationResourceIntegrationTest {

    private static final String EPU_NUMBER = "EPU_NUMBER";
    private static final String DECLARATION_ID_1 = "DECLARATION_ID_1";
    private static final String DECLARATION_ID_2 = "DECLARATION_ID_2";

    @MockBean
    private SearchOrchestratorService searchOrchestratorService;

    @Autowired
    private MockMvc mockMvc;

    private ResultActions resultActions;

    @Test
    public void searchForMultipleDeclarationsWithResponseTypeObject() throws Exception {
        givenDeclarationSearchResult(asList(getDeclarationResponse(DECLARATION_ID_1), getDeclarationResponse(DECLARATION_ID_2)));
        whenISearchForDeclarationSearchResult(EPU_NUMBER);
        thenTheDeclarationSearchResponseIsAppropriate(2, DECLARATION_ID_1, EPU_NUMBER);
    }

    @Test
    public void badRequestForAnEmptySearchTerm() throws Exception {
        whenISearchForDeclarationSearchResult("");
        resultActions.andExpect(status().isBadRequest());
    }

    @Test
    public void badRequestForNoParameters() throws Exception {
        resultActions = this.mockMvc
                .perform(get("/declarations")
                        .accept(APPLICATION_JSON));
        resultActions.andExpect(status().isBadRequest());
    }

    @Test
    public void noMatchingDeclarations() throws Exception {
        givenDeclarationSearchResult(emptyList());
        whenISearchForDeclarationSearchResult(EPU_NUMBER);
        resultActions
                .andExpect(status().isOk())
                .andExpect(content().json("{ \"hits\": {\"total\": 0 },\"declarations\": []}"));
    }

    private void thenTheDeclarationSearchResponseIsAppropriate(int size, String entryReference, String epuNumber) throws Exception {
        resultActions
                .andExpect(jsonPath("$.declarations", hasSize(size)))
                .andExpect(jsonPath("$.declarations[0].declarationId", is(entryReference)))
                .andExpect(jsonPath("$.declarations[0].epuNumber", is(epuNumber)))
                .andExpect(jsonPath("$.declarations[1].declarationId", is(DECLARATION_ID_2)))
                .andExpect(jsonPath("$.declarations[1].epuNumber", is(EPU_NUMBER)))
                .andExpect(jsonPath("$.hits.total", is(size)));
    }

    private void whenISearchForDeclarationSearchResult(String searchTerm) throws Exception {
        resultActions = this.mockMvc
                .perform(get("/declarations")
                        .param("searchTerm", searchTerm).accept(APPLICATION_JSON));
    }

    private void givenDeclarationSearchResult(List<DeclarationResponse> declarationResponses) {
        when(searchOrchestratorService.fetchDeclarationSearchResult(EPU_NUMBER)).thenReturn(new DeclarationSearchResult(new Hits(declarationResponses.size()), declarationResponses));
    }

    private DeclarationResponse getDeclarationResponse(String declarationId) {
        return DeclarationResponse.builder()
                .declarationId(declarationId)
                .epuNumber(EPU_NUMBER)
                .build();
    }


}
