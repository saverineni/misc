package uk.gov.gsi.hmrc.cds.search.api.services;

import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLineResponse;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.DeclarationLine;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;

public class DeclarationLineToDeclarationLineResponseConverterTest {

    private DeclarationLineToDeclarationLineResponseConverter converter = new DeclarationLineToDeclarationLineResponseConverter();

    private DeclarationLine declarationLine = givenADeclarationLine();

    @Test
    public void itemNumber() {
        DeclarationLineResponse actual = whenIConvertADeclarationLine(declarationLine);
        assertThat(actual.getItemNumber(), is(declarationLine.getItemNumber()));
    }

    @Test
    public void dispatchCountryCode() {
        DeclarationLineResponse actual = whenIConvertADeclarationLine(declarationLine);
        assertThat(actual.getDispatchCountryCode(), is(declarationLine.getDispatchCountryCode()));
    }

    @Test
    public void destinationCountryCode() {
        DeclarationLineResponse actual = whenIConvertADeclarationLine(declarationLine);
        assertThat(actual.getDestinationCountryCode(), is(declarationLine.getDestinationCountryCode()));
    }

    @Test
    public void clearanceDate() {
        DeclarationLineResponse actual = whenIConvertADeclarationLine(declarationLine);
        assertThat(actual.getClearanceDate(), is(declarationLine.getClearanceDate()));
    }

    @Test
    public void cpc() {
        DeclarationLineResponse actual = whenIConvertADeclarationLine(declarationLine);
        assertThat(actual.getCpc(), is(declarationLine.getCpc()));
    }

    @Test
    public void originCountryCode() {
        DeclarationLineResponse actual = whenIConvertADeclarationLine(declarationLine);
        assertThat(actual.getOriginCountryCode(), is(declarationLine.getOriginCountryCode()));
    }

    @Test
    public void commodityCode() {
        DeclarationLineResponse actual = whenIConvertADeclarationLine(declarationLine);
        assertThat(actual.getCommodityCode(), is(declarationLine.getCommodityCode()));
    }

    @Test
    public void itemConsigneeTurn() {
        DeclarationLineResponse actual = whenIConvertADeclarationLine(declarationLine);
        assertThat(actual.getItemConsigneeTurn(), is(declarationLine.getItemConsigneeTurn()));
    }

    @Test
    public void itemConsignorTurn() {
        DeclarationLineResponse actual = whenIConvertADeclarationLine(declarationLine);
        assertThat(actual.getItemConsignorTurn(), is(declarationLine.getItemConsignorTurn()));
    }

    @Test
    public void itemRoute() {
        DeclarationLineResponse actual = whenIConvertADeclarationLine(declarationLine);
        assertThat(actual.getItemRoute(), is(declarationLine.getItemRoute()));
    }

    @Test
    public void itemConsigneeName() {
        DeclarationLineResponse actual = whenIConvertADeclarationLine(declarationLine);
        assertThat(actual.getItemConsigneeName(), is(declarationLine.getItemConsigneeName()));
    }

    @Test
    public void itemConsigneePostcode() {
        DeclarationLineResponse actual = whenIConvertADeclarationLine(declarationLine);
        assertThat(actual.getItemConsigneePostcode(), is(declarationLine.getItemConsigneePostcode()));
    }

    @Test
    public void itemConsignorName() {
        DeclarationLineResponse actual = whenIConvertADeclarationLine(declarationLine);
        assertThat(actual.getItemConsignorName(), is(declarationLine.getItemConsignorName()));
    }

    @Test
    public void itemConsignorPostcode() {
        DeclarationLineResponse actual = whenIConvertADeclarationLine(declarationLine);
        assertThat(actual.getItemConsignorPostcode(), is(declarationLine.getItemConsignorPostcode()));
    }

    private DeclarationLineResponse whenIConvertADeclarationLine(DeclarationLine declaration) {
        return converter.convert(declaration);
    }

    private DeclarationLine givenADeclarationLine() {
        return DeclarationLine.builder()
                .itemNumber(1)
                .dispatchCountryCode("dispatchCountryCode")
                .destinationCountryCode("destinationCountryCode")
                .clearanceDate("clearanceDate")
                .cpc("cpc")
                .originCountryCode("originCountryCode")
                .commodityCode("commodityCode")
                .itemConsigneeTurn("itemConsigneeTurn")
                .itemConsignorTurn("itemConsignorTurn")
                .itemRoute("itemRoute")
                .itemConsigneeName("itemConsigneeName")
                .itemConsigneePostcode("itemConsigneePostcode")
                .itemConsignorName("itemConsignorName")
                .itemConsignorPostcode("itemConsignorPostcode")
                .build();

    }

}