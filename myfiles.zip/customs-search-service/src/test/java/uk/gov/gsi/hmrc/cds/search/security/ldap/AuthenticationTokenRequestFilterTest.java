package uk.gov.gsi.hmrc.cds.search.security.ldap;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.IOUtils;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.mock.web.DelegatingServletInputStream;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import uk.gov.gsi.hmrc.cds.search.security.ldap.AuthenticationTokenRequestFilter;

import javax.servlet.http.HttpServletRequest;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;

public class AuthenticationTokenRequestFilterTest {
    private static final String INPUT_JSON = "{\"pid\":\"my-pid\",\"password\":\"pword\"}";
    private ObjectMapper objectMapper = new ObjectMapper();
    private AuthenticationManager authenticationManager = mock(AuthenticationManager.class);
    private AuthenticationTokenRequestFilter filter = new AuthenticationTokenRequestFilter("url", authenticationManager, objectMapper);
    private HttpServletRequest request = mock(HttpServletRequest.class);
    private Authentication authentication = mock(Authentication.class);
    private ArgumentCaptor<UsernamePasswordAuthenticationToken> argumentCaptor = ArgumentCaptor.forClass(UsernamePasswordAuthenticationToken.class);

    @Test
    public void attemptAuthenticationShouldGiveAuthenticationWithGivenUsernameAndPassword() throws Exception {
        when(request.getInputStream()).thenReturn(new DelegatingServletInputStream(IOUtils.toInputStream(INPUT_JSON, "UTF-8")));
        when(authenticationManager.authenticate(Mockito.any(UsernamePasswordAuthenticationToken.class))).thenReturn(authentication);

        Authentication result = filter.attemptAuthentication(request, null);

        assertThat(result, is(authentication));
        verify(authenticationManager).authenticate(argumentCaptor.capture());
        assertThat(argumentCaptor.getValue().getPrincipal(), is("my-pid"));
        assertThat(argumentCaptor.getValue().getCredentials(), is("pword"));
        assertFalse(argumentCaptor.getValue().isAuthenticated());

    }
}