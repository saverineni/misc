package uk.gov.gsi.hmrc.cds.search.api.services;

import org.elasticsearch.action.search.SearchResponse;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.convert.ConversionService;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationResponse;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.Declaration;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.SearchHit;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.SearchResult;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchService;

import java.util.List;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SearchOrchestratorServiceTest {


    private static final String SEARCH_TERM = "SEARCH_TERM";

    @Mock
    private SearchResponseMapperService searchResponseMapperService;

    @Mock
    private SearchService searchService;

    @Mock
    private SearchResponse searchResponse;

    @Mock
    private SearchResult searchResult;

    @Mock
    private ConversionService conversionService;

    @InjectMocks
    private SearchOrchestratorService searchOrchestratorService;

    private SearchHit searchHit = new SearchHit();

    private Declaration declaration = Declaration.builder().build();

    private DeclarationResponse declarationResponse = DeclarationResponse.builder().build();

    @Before
    public void setup() {
        when(searchService.declarationSearch(SEARCH_TERM)).thenReturn(searchResponse);
        when(searchResult.getTotalHits()).thenReturn(1L);
        when(searchResponseMapperService.mapResponse(searchResponse)).thenReturn(searchResult);
        searchHit.setDeclaration(declaration);
        when(conversionService.convert(declaration, DeclarationResponse.class)).thenReturn(declarationResponse);
    }

    @Test
    public void fetchForMultipleDeclarations() {
        givenSearchHits(asList(searchHit, searchHit));
        List<DeclarationResponse> actual = whenIFetchDeclarations();
        assertThat(actual, hasSize(2));
    }

    @Test
    public void fetchDeclarationsConvertsDeclarationsToDeclarationResponse() {
        givenSearchHits(asList(searchHit));
        List<DeclarationResponse> actual = whenIFetchDeclarations();
        assertThat(actual, contains(declarationResponse));
    }

    @Test
    public void returnsDeclarationSearchResultWithDeclarations() {
        givenSearchHits(asList(searchHit));
        DeclarationSearchResult actual = searchOrchestratorService.fetchDeclarationSearchResult(SEARCH_TERM);
        assertThat(actual.getDeclarations(), contains(declarationResponse));
    }

    @Test
    public void returnsDeclarationSearchResultWithTotalHits() {
        givenSearchHits(asList(searchHit));
        DeclarationSearchResult actual = searchOrchestratorService.fetchDeclarationSearchResult(SEARCH_TERM);
        assertThat(actual.getHits().getTotal(), is(1L));
    }

    @Test
    public void exceptionWhenNoSearchHits() {
        givenSearchHits(emptyList());
        List<DeclarationResponse> actual = whenIFetchDeclarations();
        assertThat(actual, is(empty()));
    }

    private List<DeclarationResponse> whenIFetchDeclarations() {
        return searchOrchestratorService.fetchDeclarations(SEARCH_TERM);
    }

    private void givenSearchHits(List<SearchHit> searchHits) {
        when(searchResult.getHits()).thenReturn(searchHits);
    }


}