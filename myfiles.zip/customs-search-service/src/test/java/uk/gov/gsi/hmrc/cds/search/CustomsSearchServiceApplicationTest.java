package uk.gov.gsi.hmrc.cds.search;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import uk.gov.gsi.hmrc.cds.search.CustomsSearchServiceApplication;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = CustomsSearchServiceApplication.class)
public class CustomsSearchServiceApplicationTest {

	@Test
	public void contextLoads() {
	}

}
