package search.logfile

import org.apache.http.client.fluent.Request
import org.apache.http.client.fluent.Response
import org.junit.Test

import spock.lang.Specification

class LogfileSpec extends Specification {


    def 'the logfile should be available'() {
        when:
        def response = Request.Get('http://localhost:18000/logfile').execute().returnResponse()

        then:
        response.statusLine.statusCode == 200
    }
}
