package search

import groovy.json.JsonSlurper

import static org.apache.http.entity.ContentType.APPLICATION_JSON

import org.apache.http.HttpResponse
import org.apache.http.client.fluent.Request
import org.apache.http.impl.client.BasicResponseHandler

class Authenticator {
	
	String authenticate() {
		HttpResponse response = postAuthenticationToken('dev', 'dev')

		def responseString = new BasicResponseHandler().handleResponse(response)
		Map jsonResponse = new JsonSlurper().parseText(responseString)

		jsonResponse.get("token")
	}

	HttpResponse postAuthenticationToken(String username, String password) {
		HttpResponse response = Request.Post('http://localhost:18000/authentication/token')
				.bodyString("{\"pid\":\"${username}\",\"password\":\"${password}\"}", APPLICATION_JSON)
				.execute()
				.returnResponse()
		return response
	}
	
}
