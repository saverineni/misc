package search.declarations

import groovy.json.JsonSlurper
import org.apache.http.HttpResponse
import org.apache.http.client.fluent.Request
import org.apache.http.entity.ContentType
import org.apache.http.impl.client.BasicResponseHandler
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

class DeclarationsSearchSpec extends Specification {

    @Shared
    String authToken
    @Shared
    HttpResponse response

    static final INVALID_DECLARATION_ID = "INVALID_DEC_ID"

    def setupSpec() {
        authToken = new search.Authenticator().authenticate();
        new DeclarationsIndex().recreateAndPopulateIndex()
    }

    @Unroll
    def 'valid search term for #field returns 200 and verifies the header declaration response'(String searchTerm, String field, String expectedValue) {

        given: 'user signed in successfully'

        when:
        response = getResponse(searchTerm)

        then:
        response.statusLine.statusCode == 200
        def responseString = new BasicResponseHandler().handleResponse(response)
        def result = new JsonSlurper().parseText(responseString)
        def headerDeclaration = result.declarations[0]

        field.split("\\.").each {
            headerDeclaration = headerDeclaration[it]
        }

        headerDeclaration == expectedValue

        where:
        searchTerm                  | field               | expectedValue
        "2000000000000001"          | 'declarationId'     | "2000000000000001"
        "219"                       | 'epuNumber'         | "219"
        "249099x"                   | 'entryNumber'       | "249099x"
        "976072558688"              | 'consigneeTurn'     | "976072558688"
        "Header%20NAD%20name"       | 'consigneeName'     | "Header NAD name"
        "HN4%200PC"                 | 'consigneePostcode' | "HN4 0PC"
        "582109443894367"           | 'consignorTurn'     | "582109443894367"
        "Header%20Consignor%20name" | 'consignorName'     | "Header Consignor name"
        "AB4%206CD"                 | 'consignorPostcode' | "AB4 6CD"
    }

    @Unroll
    def 'valid search term for #field returns 200 and verifies the lines declaration response'(String searchTerm, String field, String expectedValue) {

        given: 'user signed in successfully'

        when:
        response = getResponse(searchTerm)

        then:
        response.statusLine.statusCode == 200
        def responseString = new BasicResponseHandler().handleResponse(response)
        def result = new JsonSlurper().parseText(responseString)
        def linesDeclaration = result.declarations[0].lines[0]

        field.split("\\.").each {
            linesDeclaration = linesDeclaration[it]
        }

        linesDeclaration == expectedValue

        where:
        searchTerm                | field                   | expectedValue
        "551030"                  | "commodityCode"         | "551030"
        "PG"                      | "originCountryCode"     | "PG"
        "4000C36"                 | "cpc"                   | "4000C36"
        "731411813911"            | "itemConsigneeTurn"     | "731411813911"
        "Item%20NAD%20name"       | "itemConsigneeName"     | "Item NAD name"
        "IN4%200PC"               | "itemConsigneePostcode" | "IN4 0PC"
        "item-consignor-turn"     | "itemConsignorTurn"     | "item-consignor-turn"
        "item-consignor-name"     | "itemConsignorName"     | "item-consignor-name"
        "item-consignor-postcode" | "itemConsignorPostcode" | "item-consignor-postcode"
    }


    def 'no matching declarations returns an empty result'() {
        given: 'user signed in successfully'
        when:
        response = getResponse(INVALID_DECLARATION_ID)
        then:
        response.statusLine.statusCode == 200
        new BasicResponseHandler().handleResponse(response) == "{\"hits\":{\"total\":0},\"declarations\":[]}"
    }

    HttpResponse getResponse(def searchTerm) {
        def uri = new URI("http://localhost:18000/declarations?searchTerm=${searchTerm}")
        response = Request.Get(uri)
                .addHeader("Authorization", String.format("Bearer %s", authToken))
                .addHeader("Accept", ContentType.APPLICATION_JSON.toString())
                .execute().returnResponse()
        response
    }

}