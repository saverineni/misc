package search.declarations

import static java.util.Collections.emptyMap
import static org.apache.http.entity.ContentType.APPLICATION_JSON
import static org.apache.http.HttpHeaders.CONTENT_TYPE

import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import org.apache.http.HttpHost
import org.apache.http.entity.StringEntity
import org.apache.http.message.BasicHeader
import org.elasticsearch.client.RestClient
import org.elasticsearch.client.RestHighLevelClient

class DeclarationsIndex {
	static final MAPPINGS_FILE = "/searchingestion/mapping.json"
	static final VALID_JSON_FILE = "/declarations/valid-declaration.json"
	static final CONTENT_TYPE_HEADER = new BasicHeader(CONTENT_TYPE, "application/json")

	def recreateAndPopulateIndex() {
		def client = new RestHighLevelClient(
				RestClient.builder(new HttpHost("localhost", 19200)))

		def lowLevelClient = client.getLowLevelClient()

		try {
			lowLevelClient.performRequest("DELETE", "customs_search_service")
		} catch (Exception e) {
			// will throw exception if index not present
		}
		
		lowLevelClient.performRequest("PUT",
				"customs_search_service",
				emptyMap(),
				new StringEntity(getMappingsJson(), APPLICATION_JSON),
				CONTENT_TYPE_HEADER)

		lowLevelClient.performRequest("PUT",
				"/customs_search_service/declaration/219-249099X-2013-07-14",
				emptyMap(),
				new StringEntity(getFileContent(VALID_JSON_FILE), APPLICATION_JSON),
				CONTENT_TYPE_HEADER)

		lowLevelClient.performRequest("POST",
				"/customs_search_service/_refresh", CONTENT_TYPE_HEADER)
	}

	String getFileContent(String fileName) {
		def file = new File(getClass().getResource(fileName).toURI())
		file.text
	}
	
	String getMappingsJson() {
		Map jsonResponse = new JsonSlurper().parseText(getFileContent(MAPPINGS_FILE))
		def map = [:]
		map.put("mappings", jsonResponse)
		JsonOutput.toJson(map)
	}
}
