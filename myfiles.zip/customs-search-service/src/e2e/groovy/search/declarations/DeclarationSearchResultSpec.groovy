package search.declarations

import groovy.json.JsonSlurper
import org.apache.http.HttpResponse
import org.apache.http.client.fluent.Request
import org.apache.http.entity.ContentType
import org.apache.http.impl.client.BasicResponseHandler
import search.Authenticator
import spock.lang.Shared
import spock.lang.Specification

class DeclarationSearchResultSpec extends Specification {

	@Shared expectedDeclaration
	@Shared response

	def setupSpec() {
		String authToken = new Authenticator().authenticate()
		new DeclarationsIndex().recreateAndPopulateIndex()
		expectedDeclaration = new JsonSlurper().parseText(getFileContent(DeclarationsIndex.VALID_JSON_FILE))
		response = getResponse(authToken, expectedDeclaration.declarationId)
	}

	def 'Response status should be OK'() {
		expect:
		response.statusLine.statusCode == 200
	}

	def 'declaration response should be as expected'() {
		given:
			def responseString = new BasicResponseHandler().handleResponse(response)
			def result = new JsonSlurper().parseText(responseString)

		expect:
			result.declarations[0] == expectedDeclaration
            result.hits.total == 1
	}

	HttpResponse getResponse(def authToken, def searchTerm) {
		def uri = new URI("http://localhost:18000/declarations?searchTerm=${searchTerm}")
		Request.Get(uri)
				.addHeader("Authorization", String.format("Bearer %s", authToken))
				.addHeader("Accept", ContentType.APPLICATION_JSON.toString())
				.execute().returnResponse()
	}

	String getFileContent(String fileName) {
		new File(getClass().getResource(fileName).toURI()).text
	}

}
