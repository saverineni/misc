package search.authentication.token

import groovy.json.JsonSlurper
import org.apache.http.HttpResponse
import org.apache.http.util.EntityUtils
import search.Authenticator
import spock.lang.Shared
import spock.lang.Specification

class AuthenticationTokenSpec extends Specification {

	@Shared
	HttpResponse response
	
	def 'unknown username results in 401 with appropriate message.'() {
		given: 'I am a consumer of the service'
			

        when: 'I attempt to sign in with an unknown user'
        	response = new Authenticator().postAuthenticationToken('unknown', 'password')
			
        then: 'I get an appropriate response'
		    response.statusLine.statusCode == 401
		
			def responseString = EntityUtils.toString(response.getEntity())
			Map jsonResponse = new JsonSlurper().parseText(responseString)
			jsonResponse.message == 'Authentication Failed: Bad credentials'
    }

}
