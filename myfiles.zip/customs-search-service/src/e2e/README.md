# E2E Tests

## Docker Compose

The elastic search container needs the following to be run (at least in the development VM):
```
sudo sysctl -w vm.max_map_count=262144
```
