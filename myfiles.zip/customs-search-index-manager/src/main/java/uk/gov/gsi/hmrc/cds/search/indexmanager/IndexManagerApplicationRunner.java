package uk.gov.gsi.hmrc.cds.search.indexmanager;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
@Profile("!test")
public class IndexManagerApplicationRunner implements ApplicationRunner{

    private final IndexManager indexManager;

    private final AliasManager aliasManager;

    @Override
    public void run(ApplicationArguments args) {
        List<String> nonOptionArgs = args.getNonOptionArgs();
        if (nonOptionArgs.size() == 0) {
            failRun();
        }
        String command = nonOptionArgs.get(0);
        List<String> commandArgs = nonOptionArgs.subList(1, nonOptionArgs.size());

        switch (command) {
            case "create-index":
                if (commandArgs.size() != 1) {
                    failRun();
                }

                indexManager.create(commandArgs.get(0));
                break;

            case "switch-alias":
                if (commandArgs.size() != 1) {
                    failRun();
                }

                aliasManager.switchAlias(commandArgs.get(0));
                break;

            default:
                failRun();
        }

    }

    private void failRun() {
        throw new IllegalArgumentException("Usage: create-index <index-name> \n switch-alias <index-name>");
    }
}
