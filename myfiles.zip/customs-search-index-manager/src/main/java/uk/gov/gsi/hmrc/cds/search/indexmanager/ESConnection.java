package uk.gov.gsi.hmrc.cds.search.indexmanager;

import lombok.RequiredArgsConstructor;
import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class ESConnection {

    private final ElasticsearchConfigurationProperties properties;

    public RestHighLevelClient getRestClientInstance() {
        RestHighLevelClient client = new RestHighLevelClient(
                RestClient.builder(
                        new HttpHost(properties.getHost(), properties.getPort()))
        );
        return client;
    }
}
