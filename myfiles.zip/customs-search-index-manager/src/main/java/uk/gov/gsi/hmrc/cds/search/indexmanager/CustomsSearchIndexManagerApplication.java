package uk.gov.gsi.hmrc.cds.search.indexmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class CustomsSearchIndexManagerApplication {

	public static void main(String[] args) {
		log.info("Starting Customs Search Index Manager {}",
				CustomsSearchIndexManagerApplication.class.getPackage().getImplementationVersion());
		SpringApplication.run(CustomsSearchIndexManagerApplication.class, args);
	}
}
