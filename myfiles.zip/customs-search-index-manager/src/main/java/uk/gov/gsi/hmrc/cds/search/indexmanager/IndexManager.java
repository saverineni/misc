package uk.gov.gsi.hmrc.cds.search.indexmanager;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.message.BasicHeader;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Repository;

import java.io.IOException;

import static java.util.Collections.emptyMap;
import static org.apache.http.entity.ContentType.APPLICATION_JSON;

@Repository
@Slf4j
public class IndexManager {

    private final static BasicHeader CONTENT_TYPE_HEADER = new BasicHeader("Content-Type", APPLICATION_JSON.toString());

    private final ESConnection connection;

    private final Resource declarationMapping;

    public IndexManager(ESConnection connection, @Value("classpath:elasticsearch-mappings/declarationMappings.json") Resource declarationMapping) {
        this.connection = connection;
        this.declarationMapping = declarationMapping;
    }

    public void create(String index) {
        try (RestHighLevelClient client = connection.getRestClientInstance()) {

            client.getLowLevelClient()
                    .performRequest(
                            "PUT",
                            index,
                            emptyMap(),
                            new InputStreamEntity(declarationMapping.getInputStream()),
                            CONTENT_TYPE_HEADER);

            log.warn("Created index {}" , index);
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }

    }

}
