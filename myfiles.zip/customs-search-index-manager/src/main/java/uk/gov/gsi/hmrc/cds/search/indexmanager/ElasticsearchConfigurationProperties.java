package uk.gov.gsi.hmrc.cds.search.indexmanager;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotNull;

@Component
@ConfigurationProperties(prefix = "elasticsearch")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ElasticsearchConfigurationProperties {

    @NotNull
    private String host;

    @NotNull
    private int port;

}
