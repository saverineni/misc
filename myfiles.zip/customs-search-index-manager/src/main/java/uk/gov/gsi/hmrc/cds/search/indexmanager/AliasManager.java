package uk.gov.gsi.hmrc.cds.search.indexmanager;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicHeader;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.io.IOException;

import static java.util.Collections.emptyMap;
import static org.apache.http.entity.ContentType.APPLICATION_JSON;

@Repository
@Slf4j
public class AliasManager {
    private final static BasicHeader CONTENT_TYPE_HEADER = new BasicHeader("Content-Type", APPLICATION_JSON.toString());

    private final ESConnection connection;
    private final String aliasName;

    public AliasManager(ESConnection connection , @Value("${es.alias-name:customs_search_service}") String aliasName) {
        this.connection = connection;
        this.aliasName = aliasName;
    }

    public void switchAlias(String indexName) {
        try (RestHighLevelClient client = connection.getRestClientInstance()) {

            client.getLowLevelClient()
                    .performRequest(
                            "POST",
                            "/_aliases",
                            emptyMap(),
                            new StringEntity(switchAliasRequestBody(indexName, aliasName)),
                            CONTENT_TYPE_HEADER);
            log.warn("Switched alias {} to index {}" , aliasName , indexName);
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
    }
    
    private String switchAliasRequestBody(String index, String alias) {
        return String.format("{" +
                "    \"actions\": [" +
                "        { \"remove\": { \"index\": \"*\", \"alias\": \"%s\" }}," +
                "        { \"add\":    { \"index\": \"%s\", \"alias\": \"%s\" }}" +
                "    ]" +
                "}", alias, index, alias);
    }

}
