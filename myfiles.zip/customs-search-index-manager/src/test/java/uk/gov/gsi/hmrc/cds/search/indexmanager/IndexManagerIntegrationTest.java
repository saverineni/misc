package uk.gov.gsi.hmrc.cds.search.indexmanager;

import org.elasticsearch.client.IndicesAdminClient;
import org.elasticsearch.cluster.metadata.MappingMetaData;
import org.elasticsearch.common.collect.ImmutableOpenMap;
import org.junit.Before;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;

import java.util.concurrent.ExecutionException;

import static org.hamcrest.Matchers.is;

public class IndexManagerIntegrationTest extends CustomsESIntegTestCase {

    private static final String ES_INDEX = "IndexManagerIntegrationTest".toLowerCase();
    private IndexManager indexManager;

    @Before
    public void setUp() throws Exception {
        super.setUp();
        this.indexManager = new IndexManager(new ESConnection(new ElasticsearchConfigurationProperties(ES_HOST, ES_PORT)) , new ClassPathResource("testMappings.json"));
    }

	@Test
	public void create() throws InterruptedException, ExecutionException {
		indexManager.create(ES_INDEX);
				
		final IndicesAdminClient indices = client.admin().indices();
		
		assertThat(indices.exists(indices.prepareExists(ES_INDEX).request()).get().isExists(),is(true));
        ImmutableOpenMap<String, MappingMetaData> mappingsType = indices.prepareGetMappings(ES_INDEX).get().getMappings().get(ES_INDEX);

        assertTrue(mappingsType.containsKey("test-mappings"));
        final MappingMetaData actual = mappingsType.get("test-mappings");

        assertNotNull(actual);
        assertThat(actual.getSourceAsMap().get("dynamic"), is("false"));

    }

}
