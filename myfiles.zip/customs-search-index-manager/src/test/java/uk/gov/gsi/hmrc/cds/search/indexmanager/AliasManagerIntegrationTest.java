package uk.gov.gsi.hmrc.cds.search.indexmanager;

import org.elasticsearch.action.admin.indices.alias.get.GetAliasesRequest;
import org.elasticsearch.action.admin.indices.alias.get.GetAliasesResponse;
import org.elasticsearch.action.admin.indices.delete.DeleteIndexRequest;
import org.elasticsearch.cluster.metadata.AliasMetaData;
import org.junit.Before;
import org.junit.Test;

import java.util.List;
import java.util.concurrent.ExecutionException;

import static org.hamcrest.Matchers.is;

public class AliasManagerIntegrationTest extends CustomsESIntegTestCase {

    private static final String ES_INDEX = "AliasManagerIntegrationTest".toLowerCase();
    public static final String ALIAS_NAME = ES_INDEX + "_alias";
    private AliasManager aliasManager;

    @Before
    public void setUp() throws Exception {
        super.setUp();
        this.aliasManager = new AliasManager(new ESConnection(new ElasticsearchConfigurationProperties(ES_HOST, ES_PORT)), ALIAS_NAME);
        client.admin().indices().prepareCreate(ES_INDEX).execute().get();
        client.admin().indices().prepareCreate("temp").execute().get();
        client.admin().indices().delete(new DeleteIndexRequest(ALIAS_NAME));
    }

	@Test
	public void switchAliasGivenAliasNotExists() {
        aliasManager.switchAlias(ES_INDEX);
        assertAliasToNewIndex();
    }

    @Test
    public void switchAliasGivenAliasForAnExistingIndexPointsAliasAtNewIndex() {
        client.admin().indices().prepareAliases().addAlias("temp", ALIAS_NAME).execute().actionGet();

        aliasManager.switchAlias(ES_INDEX);

        assertAliasToNewIndex();
    }

    private void assertAliasToNewIndex() {
        final GetAliasesResponse aliasesResponse = client.admin().indices().getAliases(new GetAliasesRequest(ALIAS_NAME)).actionGet();
        final List<AliasMetaData> aliasMetaData = aliasesResponse.getAliases().get(ES_INDEX);
        assertThat(aliasMetaData.size() , is(1));
        assertThat(aliasMetaData.get(0).alias() , is(ALIAS_NAME));
    }

    @Test
    public void switchAliasGivenAliasForAnExistingIndexRemovesOldIndexFromAlias() {
        client.admin().indices().prepareAliases().addAlias("temp", ALIAS_NAME).execute().actionGet();

        aliasManager.switchAlias(ES_INDEX);

        final GetAliasesResponse aliasesResponse = client.admin().indices().getAliases(new GetAliasesRequest(ALIAS_NAME)).actionGet();

        final List<AliasMetaData> oldIndexAliasMetaData = aliasesResponse.getAliases().get("temp");
        assertThat(oldIndexAliasMetaData.size() , is(0));
    }

    @Test(expected = RuntimeException.class)
    public void switchAliasGivenAliasForAnNonExistingIndex() {
        aliasManager.switchAlias("unknown");
    }

}
