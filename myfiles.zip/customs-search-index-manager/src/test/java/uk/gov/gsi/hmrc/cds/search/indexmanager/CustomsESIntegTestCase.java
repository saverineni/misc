package uk.gov.gsi.hmrc.cds.search.indexmanager;

import com.carrotsearch.randomizedtesting.annotations.ThreadLeakScope;
import org.elasticsearch.client.Client;
import org.elasticsearch.client.IndicesAdminClient;
import org.elasticsearch.cluster.metadata.MappingMetaData;
import org.elasticsearch.common.collect.ImmutableOpenMap;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.plugins.Plugin;
import org.elasticsearch.test.ESIntegTestCase;
import org.elasticsearch.test.ESIntegTestCase.ClusterScope;
import org.elasticsearch.test.ESIntegTestCase.Scope;
import org.elasticsearch.transport.Netty4Plugin;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.core.io.ClassPathResource;

import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.ExecutionException;

import static org.hamcrest.Matchers.is;

@ClusterScope(scope = Scope.SUITE, maxNumDataNodes = 0, minNumDataNodes = 0, numClientNodes = 0)
@ThreadLeakScope(ThreadLeakScope.Scope.NONE)
@RunWith(com.carrotsearch.randomizedtesting.RandomizedRunner.class)
public abstract class CustomsESIntegTestCase extends ESIntegTestCase {
	
	protected static final String ES_HOST = "localhost";
    protected static final int ES_PORT = 19601;
    protected Client client;

    @Before
    public void setUp() throws Exception {
        super.setUp();
        this.client = client();
    }
	
	@Override
    protected Collection<Class<? extends Plugin>> nodePlugins() {
        return Arrays.asList(Netty4Plugin.class);
    }

    @Override
    protected Settings nodeSettings(int nodeOrdinal) {
        Settings.Builder builder = Settings.builder();
        builder.put("transport.type", Netty4Plugin.NETTY_HTTP_TRANSPORT_NAME)
                .put("http.type", Netty4Plugin.NETTY_TRANSPORT_NAME)
                .put("http.enabled", "true")
                .put("http.port", String.valueOf(ES_PORT))
                .put("discovery.type", "single-node")
                .put("processors", "1");
        return builder.build();
    }

}
