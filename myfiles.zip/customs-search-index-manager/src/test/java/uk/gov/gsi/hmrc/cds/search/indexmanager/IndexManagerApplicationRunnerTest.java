package uk.gov.gsi.hmrc.cds.search.indexmanager;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.ApplicationArguments;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class IndexManagerApplicationRunnerTest {

    private static final String INDEX_NAME = "index";

    @Mock
    private ApplicationArguments arguments;

    @Mock
    private IndexManager indexManager;

    @Mock
    private AliasManager aliasManager;

    private IndexManagerApplicationRunner indexManagerApplicationRunner;

    @Before
    public void setUp() {
        this.indexManagerApplicationRunner = new IndexManagerApplicationRunner(indexManager , aliasManager);
    }

    @Test
    public void createIndex(){
        when(arguments.getNonOptionArgs()).thenReturn(asList("create-index",INDEX_NAME));
        indexManagerApplicationRunner.run(arguments);
        verify(indexManager).create(INDEX_NAME);
    }

    @Test
    public void createIndexWithNoIndexName() {
        when(arguments.getNonOptionArgs()).thenReturn(asList("create-index"));
        assertCommandFails();
    }

    @Test
    public void switchAlias() {
        when(arguments.getNonOptionArgs()).thenReturn(asList("switch-alias",INDEX_NAME));
        indexManagerApplicationRunner.run(arguments);
        verify(aliasManager).switchAlias(INDEX_NAME);
    }

    @Test
    public void switchAliasWithNoIndexName() {
        when(arguments.getNonOptionArgs()).thenReturn(asList("switch-alias"));
        assertCommandFails();
    }

    @Test
    public void unrecognisedCommand() {
        when(arguments.getNonOptionArgs()).thenReturn(asList("unrecognisedCommand"));
        assertCommandFails();
    }

    @Test
    public void noCommand() {
        when(arguments.getNonOptionArgs()).thenReturn(emptyList());
        assertCommandFails();
    }

    private void assertCommandFails() {
        try {
            indexManagerApplicationRunner.run(arguments);
            Assert.fail("expected IllegalArgumentException");
        } catch(IllegalArgumentException e) {
            //pass
        } finally {
            verifyZeroInteractions(indexManager);
        }
    }
}