package e2e

import groovy.json.JsonSlurper
import org.apache.http.HttpResponse
import org.apache.http.impl.client.BasicResponseHandler
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

class CreateIndexWithMappingSpec extends Specification {

    @Shared
    String indexName

    def setupSpec() {
        indexName = System.currentTimeMillis().toString()
        def exitValue = new CommandRunner().run("create-index $indexName").waitFor()
        exitValue == 0
    }

    def 'creates index with dynamic field mapping disabled'() {

        given: 'index created with a mapping file'

        when: 'I read the mapping'
        HttpResponse response = new ESClient().getMapping(indexName)

        then:
        response.statusLine.statusCode == 200
        def responseString = new BasicResponseHandler().handleResponse(response)
        def json = new JsonSlurper().parseText(responseString)
        json[indexName].mappings.declaration.dynamic == "false"
    }

    @Unroll
    def 'creates index with #fieldName field mapping'(String fieldName, String expectedType) {

        given: 'index created with a mapping file'

        when: 'I read the mapping'
        HttpResponse response = new ESClient().getMapping(indexName)

        then:
        response.statusLine.statusCode == 200
        def responseString = new BasicResponseHandler().handleResponse(response)
        def json = new JsonSlurper().parseText(responseString)

        def fieldMapping = getFieldMapping(json[indexName].mappings.declaration, fieldName)

        fieldMapping.type == expectedType

        where:
        fieldName                     | expectedType
        'consigneeName'               | 'keyword'
        'consigneePostcode'           | 'keyword'
        'consigneeTurn'               | 'keyword'
        'declarationId'               | 'keyword'
        'entryNumber'                 | 'keyword'
        'epuNumber'                   | 'keyword'
        'consignorName'               | 'keyword'
        'consignorPostcode'           | 'keyword'
        'consignorTurn'               | 'keyword'
        'lines.commodityCode'         | 'keyword'
        'lines.cpc'                   | 'keyword'
        'lines.itemConsigneeName'     | 'keyword'
        'lines.itemConsigneePostcode' | 'keyword'
        'lines.itemConsigneeTurn'     | 'keyword'
        'lines.itemConsignorName'     | 'keyword'
        'lines.itemConsignorPostcode' | 'keyword'
        'lines.itemConsignorTurn'     | 'keyword'
        'lines.originCountryCode'     | 'keyword'
    }

    Object getFieldMapping(Object mapping, String field) {
        Object value = mapping
        field.split("\\.").each {
            value = value.properties[it]
        }
        value
    }


}


