package e2e

class CommandRunner {
	final String baseCommand = 'java -Delasticsearch.host=localhost -Delasticsearch.port=19202 -jar ./target/e2e.jar'
	
	Process run(String arguments) {
		"$baseCommand $arguments".execute()
	}

}
