package e2e

import spock.lang.Shared
import spock.lang.Specification

class CreateIndexSpec extends Specification {

    @Shared
    def indexName
    
    def 'creates an index'() {
        given: 'an index name'
            indexName = System.currentTimeMillis().toString()

        when: 'create index command of the jar with the index name is called'
            def exitValue = new CommandRunner().run("create-index $indexName").waitFor()

        then: 'new index is created with that name'
            exitValue == 0
            new ESClient().headRequestForIndex(indexName).statusLine.statusCode == 200

    }

    def 'invalid arguments'() {
        given:

        when: 'create index command of the jar without index name is called'
        def exitValue = new CommandRunner().run("create-index").waitFor()

        then: 'non zero exit code'
        exitValue > 0
    }

}


