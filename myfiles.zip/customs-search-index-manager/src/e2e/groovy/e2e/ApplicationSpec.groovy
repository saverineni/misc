package e2e


import groovy.json.JsonSlurper
import org.apache.http.HttpResponse
import org.apache.http.client.fluent.Request
import org.apache.http.entity.ContentType
import org.apache.http.impl.client.BasicResponseHandler
import spock.lang.Shared
import spock.lang.Specification

class ApplicationSpec extends Specification {

	@Shared
    Process process
	
	def setupSpec() {
		process = new CommandRunner().run("")
	}

    def 'no arguments'() {
        given:

        when: 'run the jar with no arguments'
        def exitValue = process.waitFor()

        then: 'non zero exit code'
        exitValue > 0
    }

    def 'outputs the version to standard out'() {
        given:

        when: 'the jar is run'
        def output = process.in.text

        then: 'the application version is logged'
        output =~ /Starting Customs Search Index Manager 1\.0\.\d*/
    }

}


