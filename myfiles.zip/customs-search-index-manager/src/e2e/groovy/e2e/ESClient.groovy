package e2e

import org.apache.http.client.fluent.Request
import org.apache.http.HttpResponse
import org.apache.http.entity.ContentType

class ESClient {

    final String esUrl = 'http://localhost:19202'

    HttpResponse headRequestForIndex(String index){
        Request.Head("$esUrl/$index").execute().returnResponse()
    }

    HttpResponse getMapping(String index) {
        def uri = new URI("$esUrl/$index/_mapping")
        Request.Get(uri)
                .addHeader("Accept", ContentType.APPLICATION_JSON.toString())
                .execute().returnResponse()
    }

    HttpResponse createIndex(String index) {
        def uri = new URI("$esUrl/$index")
        Request.Put(uri)
                .execute().returnResponse()
    }

    HttpResponse createAliasWithAnIndex(String index , String alias) {
        def uri = new URI("$esUrl/$index/_alias/$alias")
        Request.Put(uri)
                .execute().returnResponse()
    }

    HttpResponse getAliasForAnIndex(String index) {
        def uri = new URI("$esUrl/$index/_alias")
        Request.Get(uri)
                .execute().returnResponse()
    }
}