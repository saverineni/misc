package e2e

import groovy.json.JsonSlurper
import org.apache.http.HttpResponse
import org.apache.http.impl.client.BasicResponseHandler
import spock.lang.Shared
import spock.lang.Specification

class SwitchAliasSpec extends Specification {

    @Shared
    String alias = 'customs_search_service'
    
    def 'switches an alias'() {
        given: 'an old index, an alias and a new index'
            def oldIndexName = System.currentTimeMillis() + "old"
            def newIndexName = System.currentTimeMillis() + "new"
            def client = new ESClient()

            client.createIndex(oldIndexName).statusLine.statusCode == 200
            client.createAliasWithAnIndex(oldIndexName,alias).statusLine.statusCode == 200
            client.createIndex(newIndexName).statusLine.statusCode == 200

        when: 'switch alias command of the jar with the index name is called'
            def exitValue = new CommandRunner().run("switch-alias $newIndexName").waitFor()

        then: 'alias is only pointing at the new index'
            exitValue == 0
            parseAliasNames(client.getAliasForAnIndex(oldIndexName), oldIndexName) == [] as Set
            parseAliasNames(client.getAliasForAnIndex(newIndexName), newIndexName) == [alias] as Set
    }

    def parseAliasNames(HttpResponse response, String indexName) {
        def responseString = new BasicResponseHandler().handleResponse(response)
        def json = new JsonSlurper().parseText(responseString)
        json[indexName].aliases.keySet()
    }

    def 'invalid arguments'() {
        given:

        when: 'switch index command of the jar without index name is called'
        def exitValue = new CommandRunner().run("switch-index").waitFor()

        then: 'non zero exit code'
        exitValue > 0
    }

}


