# Customs Search Service

## Pre-requisites

* Customs Search VM image or JDK 8 + maven + access to DEC artifactory

## Build / pre-check-in

To build the fat jar, run all the tests and build a Docker image in your local Docker registry
    
    mvn clean verify -Pdev

## Start the e2e testing docker compose network

The e2e tests are run against a service / elasticsearch / logstash stack.  To start this run

    mvn -Pe2e pre-integration-test

## Running build using docker image Jenkins uses

This is what Jenkins does.  Image built from docker-dind-maven project.

Start your docker daemon listening on a tcp port and a linux socket

	sudo dockerd -H 0.0.0.0:2375 -H unix:///var/run/docker.sock
	
Start a docker container in the project home directory

	docker run --network=host -e DOCKER_HOST=tcp://127.0.0.1:2375 -v "$(pwd):/root" -v "$HOME/.m2:/root/.m2" -w /root -v /var/run/docker.sock:/var/run/docker.sock -it artifactory.dataengineering.apps.hmrci:8001/cdsdar/dind-maven:3 sh
	
Than cd to root and off you go

	cd /root
	mvn -Pdev clean verify

## Testing locally against a local Elasticsearch

* [VM Docker setup](http://10.102.81.196:8090/display/CDS/Docker+setup+to+pull+image+from+Artifactory)
* Pre-requisite: [Make sure you have a valid docker instance with name es-6 is running locally. You can download the docker es image from the artifactory]

### Access application in docker container
> No basic auth (default profile)

    docker run -d -p 8000:8000 --name search --link es-6:eshost artifactory.dataengineering.apps.hmrci:8001/customs-search-service:1.0.0-SNAPSHOT

> Basic auth enabled (localsecurity profile)

    docker run -d -p 8000:8000 --name search --link es-6:eshost -e "spring.profiles.active=localsecurity" --add-host IRD60016.userdomain01.domroot.internal:10.21.194.23 artifactory.dataengineering.apps.hmrci:8001/customs-search-service:1.0.0-SNAPSHOT
