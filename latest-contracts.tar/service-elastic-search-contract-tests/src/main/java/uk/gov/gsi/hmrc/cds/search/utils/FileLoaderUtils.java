package uk.gov.gsi.hmrc.cds.search.utils;

import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.apache.commons.io.FileUtils.readFileToString;

public class FileLoaderUtils {

    public static final String EXPECTED_MAPPINGS_FILE ="/BOOT-INF/classes/elasticsearch-mappings/declarationMappings.json";
    public static final String INVALID_EXPECTED_MAPPINGS_FILE = "expected/invalid_mappings.json";
    public static final String INVALID_EXPECTED_SETTINGS_FILE = "expected/invalid_settings.json";
    public static final String ACTUAL_SETTINGS_FILE = "actual/settings.json";
    public static final String ACTUAL_MAPPINGS_FILE = "actual/mappings.json";

    public static String getFileContent(String file) {
        String response = "";
        try {
            Path path = Paths.get(FileLoaderUtils.class.getClassLoader().getResource(file).toURI());
            response = readFileToString(path.toFile(), "UTF-8");
        } catch (IOException  | URISyntaxException e) {
            e.printStackTrace();
        }
        return response;
    }

    public static String getMappingsFileContent(String file) {
        String response = "";
        try {
            InputStream inputStream = FileLoaderUtils.class.getResourceAsStream(file);
            response = IOUtils.toString(inputStream, StandardCharsets.UTF_8.name());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return response;
    }


}