package uk.gov.gsi.hmrc.cds.search;

import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.util.Lists;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONCompare;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.skyscreamer.jsonassert.JSONCompareResult;
import uk.gov.gsi.hmrc.cds.search.utils.FileLoaderUtils;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import static org.apache.commons.lang.StringUtils.isNotBlank;
import static org.skyscreamer.jsonassert.JSONCompare.compareJSON;

@Slf4j
public class ContractsValidator {

    public static final String MAPPINGS_JSON_PATH = "$.mappings";
    public static final String ACTUAL_SETTINGS_ANALYSIS_JSON_PATH = "$.settings.index.analysis";
    public static final String EXPECTED_SETTINGS_ANALYSIS_JSON_PATH = "$.settings.analysis";
    public static final String SETTINGS_URI = "/customs_search_service/_settings";
    public static final String MAPPINGS_URI = "/customs_search_service/_mappings";
    private static String mappingsUrl;
    private static String settingsUrl;
    private static HttpRequestFactory requestFactory = new NetHttpTransport().createRequestFactory();
    private ContractCheckingService contractCheckingService = new ContractCheckingService();

    public ContractsValidator(){}
    public ContractsValidator(ContractCheckingService contractCheckingService){
        this.contractCheckingService = contractCheckingService;
    }

    public static void main(String args[]) throws IOException {
        String elasticSearchUrl = args[0];
        settingsUrl = elasticSearchUrl + SETTINGS_URI;
        mappingsUrl = elasticSearchUrl + MAPPINGS_URI;
        if(new ContractsValidator().areContractsValid(settingsUrl, mappingsUrl)) {
            System.exit(0);
        }
        System.exit(1);
    }

    public boolean areContractsValid(String settingsUrl, String mappingsUrl) throws IOException {
        if(isNotBlank(settingsUrl) && isNotBlank(mappingsUrl)) {
            String settingsResponse = requestJson(settingsUrl);
            String mappingsResponse = requestJson(mappingsUrl);

            boolean settings = contractCheckingService.verifyContract(settingsResponse, ACTUAL_SETTINGS_ANALYSIS_JSON_PATH, EXPECTED_SETTINGS_ANALYSIS_JSON_PATH);
            boolean mappings = contractCheckingService.verifyContract(mappingsResponse, MAPPINGS_JSON_PATH, MAPPINGS_JSON_PATH);
            return settings && mappings;
        }
        return false;
    }

    private String requestJson(String url) throws IOException {
        HttpRequest settingsRequest = requestFactory.buildGetRequest(new GenericUrl(url));
        return settingsRequest.execute().parseAsString();
    }


}