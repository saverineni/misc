package uk.gov.gsi.hmrc.cds.search;

import org.json.JSONException;
import org.junit.Assert;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.utils.FileLoaderUtils;

import static uk.gov.gsi.hmrc.cds.search.ContractsValidator.ACTUAL_SETTINGS_ANALYSIS_JSON_PATH;
import static uk.gov.gsi.hmrc.cds.search.ContractsValidator.EXPECTED_SETTINGS_ANALYSIS_JSON_PATH;
import static uk.gov.gsi.hmrc.cds.search.ContractsValidator.MAPPINGS_JSON_PATH;

public class ContractsValidatorTest {


    @Test
    public void validateSettings() throws JSONException {
        String fileContent = FileLoaderUtils.getFileContent(FileLoaderUtils.ACTUAL_SETTINGS_FILE);
        Assert.assertTrue( new ContractCheckingService().verifyContract(fileContent, ACTUAL_SETTINGS_ANALYSIS_JSON_PATH, EXPECTED_SETTINGS_ANALYSIS_JSON_PATH));
    }

    @Test
    public void validateMappings() throws JSONException {
        String fileContent = FileLoaderUtils.getFileContent(FileLoaderUtils.ACTUAL_MAPPINGS_FILE);
        Assert.assertTrue( new ContractCheckingService().verifyContract(fileContent, MAPPINGS_JSON_PATH, MAPPINGS_JSON_PATH));
    }

}