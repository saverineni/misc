package uk.gov.gsi.hmrc.cds.search;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import org.json.JSONException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.utils.FileLoaderUtils;

import java.io.IOException;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static uk.gov.gsi.hmrc.cds.search.ContractsValidator.MAPPINGS_URI;
import static uk.gov.gsi.hmrc.cds.search.ContractsValidator.SETTINGS_URI;

public class ContractValidationIntegrationTest {

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(8080);
    private String settingsUrl;
    private String mappingsUrl;
    private ContractsValidator contractsValidator = new ContractsValidator();
    private ContractCheckingService contractCheckingService = new ContractCheckingService();

    @Before
    public void setUp() {
        wireMockRule.resetAll();

        wireMockRule.stubFor(get(urlEqualTo(SETTINGS_URI)).willReturn(aResponse().withBody(FileLoaderUtils.getFileContent(FileLoaderUtils.ACTUAL_SETTINGS_FILE))));
        wireMockRule.stubFor(get(urlEqualTo(MAPPINGS_URI)).willReturn(aResponse().withBody(FileLoaderUtils.getFileContent(FileLoaderUtils.ACTUAL_MAPPINGS_FILE))));

        settingsUrl = wireMockRule.url(SETTINGS_URI);
        mappingsUrl = wireMockRule.url(MAPPINGS_URI);
    }

    @Test
    public void contractValid() throws IOException, JSONException {
        Assert.assertTrue( contractsValidator.areContractsValid(settingsUrl,mappingsUrl));
    }

    @Test
    public void contractsSettingsInvalid() throws IOException, JSONException {
        contractCheckingService.setExpectedESMappingsFileContent(FileLoaderUtils.getFileContent(FileLoaderUtils.INVALID_EXPECTED_SETTINGS_FILE));
        contractsValidator =  new ContractsValidator(contractCheckingService);
        Assert.assertFalse(contractsValidator.areContractsValid("",mappingsUrl));
    }

    @Test
    public void contractsMappingsInvalid() throws IOException, JSONException {
        contractCheckingService.setExpectedESMappingsFileContent(FileLoaderUtils.getFileContent(FileLoaderUtils.INVALID_EXPECTED_MAPPINGS_FILE));
        contractsValidator =  new ContractsValidator(contractCheckingService);
        Assert.assertFalse(contractsValidator.areContractsValid(settingsUrl,mappingsUrl));
    }
}
