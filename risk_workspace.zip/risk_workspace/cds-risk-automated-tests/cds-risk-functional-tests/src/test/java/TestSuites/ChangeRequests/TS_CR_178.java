package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.TestCase_RM_MetaDataService;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_178.class)
//@Suite.SuiteClasses({TestCase_RM_MetaDataService.class})

public class TS_CR_178 {
    //    CR-178	Extend the Metadata Service API to include additional fields
}
