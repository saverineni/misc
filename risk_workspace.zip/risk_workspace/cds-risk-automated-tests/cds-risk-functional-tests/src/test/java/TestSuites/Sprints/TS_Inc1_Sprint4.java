package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_RulesManagement;
import TestCases.TestCase_RM_MetaDataService;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)

//@Categories.IncludeCategory({ChangeRequest.CR_107.class, ChangeRequest.CR_178.class})

//@Suite.SuiteClasses({TestCase_RulesManagement.class, TestCase_RM_MetaDataService.class})

public class TS_Inc1_Sprint4 {

//    Increment 1 Sprint 4

    //    CR-107	Write tests to ensure cross-domain security headers are served
    //    CR-178	Extend the Metadata Service API to include additional fields

//    CR-48	Rename execution server to risking service
//    CR-75	Change pipeline to build from development branch
//    CR-101	Measure code quality with Sonar
//    CR-102	Add unit test coverage results into Jenkins

//    CR-107	Write tests to ensure cross-domain security headers are served
//    CR-138	Upgrade Risking Service to Play 2.5
//    CR-169	Convert Rules Management to Play 2.5
//    CR-170	Convert rules service to Play 2.5
//    CR-177	Hook UI up to Metadata Service API

//    CR-179	Code quality tooling for Junit code for QA tests
//    CR-180	Rebuild Jenkins	Story
//    CR-181	Backup Bitbucket
//    CR-187 *	Run all applications in Fast-P
//    CR-200 *	Prototype Create with real data

}
