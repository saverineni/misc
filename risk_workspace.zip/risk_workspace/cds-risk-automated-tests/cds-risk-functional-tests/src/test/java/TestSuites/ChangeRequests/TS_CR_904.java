package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.DataService.TestCase_DataTableService;
import TestCases.RiskingService.TestCase_Risking_RuleLifeCycle;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_904.class)
//@Suite.SuiteClasses({TestCase_Risking_RuleLifeCycle.class, TestCase_DataTableService.class})

public class TS_CR_904 {
    //CR_904 - Load and execute rule that includes a data table value
}
