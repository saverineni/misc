package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_Login;
import TestCases.RulesManagementService.TestCase_LoginRuleManager;
import TestCases.RulesManagementService.TestCase_LoginRuleViewer;
import TestCases.UserService.TestCase_UserService;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

//@RunWith(Categories.class)
//@Categories.IncludeCategory({ChangeRequest.CR_494.class, ChangeRequest.CR_553.class, ChangeRequest.CR_554.class,
//                        ChangeRequest.CR_597.class, ChangeRequest.CR_598.class})
//
//@Suite.SuiteClasses({TestCase_Login.class, TestCase_UserService.class, TestCase_LoginRuleManager.class,
//                    TestCase_LoginRuleViewer.class})

public class TS_Inc3_Sprint3 {

//        CR-494	Login as a user

//        CR-553	Assign Admin role to user
//        CR-554	Assign SuperAdmin role to user

//        CR-559	Add ability to logout as a user

//        CR-597 *	Assign Rule Manager permissions to a user
//        CR-598 *	Assign Rule Viewer permissions to a user

//        CR-497	Deploy the test harness into the different environments as part of the build pipeline.
//        CR-506	Formalize release notes
//        CR-531	Add ability to release user service

}
