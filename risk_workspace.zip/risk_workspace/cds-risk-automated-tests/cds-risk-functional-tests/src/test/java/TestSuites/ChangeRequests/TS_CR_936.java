package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_DataTable_Ammend;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_936.class)
//@Suite.SuiteClasses({TestCase_DataTable_Ammend.class})

public class TS_CR_936 {
    //CR_936 - Add a single value to a data table
}
