package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_AmendActiveRule;
import TestCases.RulesManagementService.TestCase_ArchiveRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_349.class)
//@Suite.SuiteClasses({
//        TestCase_AmendActiveRule.class,
//        TestCase_ArchiveRule.class
//})

public class TS_CR_349 {
//        CR-349	Archive the original version of an amended Live rule
}
