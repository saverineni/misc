package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RiskingService.TestCase_Risking_RuleLifeCycle;
import TestCases.RulesManagementService.TestCase_CreateDraftRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)

//@Categories.IncludeCategory({ChangeRequest.CR_116.class, ChangeRequest.CR_117.class})

//@Suite.SuiteClasses({TestCase_CreateDraftRule.class, TestCase_Risking_RuleLifeCycle.class})

public class TS_Inc1_Sprint3 {

//    Increment 1 Sprint 3

    //    CR-116	Create a rule with nested conditions
//    CR-117	Create a rule that searches for a given consignorID at both header and item level

//    CR-95	Break build on maven test failures
//    CR-96	CI should be configured to automatically build on commit

//    CR-119	Document proposed test approach
//    CR-120	Spike service to supply the UI with domain model
//    CR-136 *	Drive Condition attributes via Data
//    CR-151 *	Create project for prototype work

}
