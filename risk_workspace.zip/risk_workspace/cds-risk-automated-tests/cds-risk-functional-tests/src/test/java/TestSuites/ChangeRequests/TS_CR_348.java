package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_AmendActiveRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_348.class)
//@Suite.SuiteClasses({TestCase_AmendActiveRule.class})

public class TS_CR_348 {
//        CR-348	Commit an amended version of an active rule
}
