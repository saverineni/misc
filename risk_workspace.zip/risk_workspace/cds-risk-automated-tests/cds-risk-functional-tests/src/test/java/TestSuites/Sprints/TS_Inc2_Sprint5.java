package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RiskingService.TestCase_Risking_RuleLifeCycle;
import TestCases.RulesManagementService.TestCase_AmendActiveRule;
import TestCases.RulesManagementService.TestCase_PendingRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)

//@Categories.IncludeCategory({ChangeRequest.CR_260.class, ChangeRequest.CR_339.class, ChangeRequest.CR_340.class,
//                            ChangeRequest.CR_356.class})

//@Suite.SuiteClasses({TestCase_Risking_RuleLifeCycle.class, TestCase_AmendActiveRule.class, TestCase_PendingRule.class})

public class TS_Inc2_Sprint5 {

//    CR-260	Create health check endpoint in risking service
//    CR-339	Amend and save active version of a rule
//    CR-340	Create & commit pending rule
//    CR-356	Commit pending rule

//    CR-358 *	Upgrade Angular to latest RC
//    CR-362	Create Selenium grid in Fast-P
//    CR-414	Enable UI to build in Fast-P by storing dependencies in project
//    CR-415	Fix issues with Jenkins deployments into Fast-P
//    CR-416	Add Jenkins jobs in Fast-P to promote the build
//    CR-417	Move Bitbucket in Fast-P from 191 to 196
//    CR-450 *	POC for Gatling Performance Test Tool

}
