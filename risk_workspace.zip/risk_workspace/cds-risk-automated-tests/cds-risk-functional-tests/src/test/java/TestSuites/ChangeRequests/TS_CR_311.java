package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_RulesManagement;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_311.class)
//@Suite.SuiteClasses({TestCase_RulesManagement.class})

public class TS_CR_311 {
//    CR-311 *	Amend rule management UI to include CPC code
}
