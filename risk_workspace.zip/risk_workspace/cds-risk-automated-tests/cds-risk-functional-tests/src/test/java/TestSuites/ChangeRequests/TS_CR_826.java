package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_CreateRuleWithDataTable;
import TestCases.TestCase_RM_MetaDataService;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_826.class)
//@Suite.SuiteClasses({TestCase_CreateRuleWithDataTable.class, TestCase_RM_MetaDataService.class})

public class TS_CR_826 {
    //Include a data table in a rule
}
