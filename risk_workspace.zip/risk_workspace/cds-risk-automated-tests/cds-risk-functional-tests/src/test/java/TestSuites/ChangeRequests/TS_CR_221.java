package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_CreateDraftRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_221.class)
//@Suite.SuiteClasses({TestCase_CreateDraftRule.class})

public class TS_CR_221 {
//    CR-221	Access and view previous versions of a rule
}
