package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_Login;
import TestCases.UserService.TestCase_UserService;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_557.class)
//@Suite.SuiteClasses({
//        TestCase_Login.class,
//        TestCase_UserService.class
//})

public class TS_CR_557 {

//    ChangeRequest-557	Assign a single location to a single user role
}
