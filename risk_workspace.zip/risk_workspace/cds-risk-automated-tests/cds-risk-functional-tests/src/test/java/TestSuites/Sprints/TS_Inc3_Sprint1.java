package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_AmendActiveRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory({ChangeRequest.CR_348.class, ChangeRequest.CR_349.class})
//
//@Suite.SuiteClasses({
//        TestCase_AmendActiveRule.class
//        })

public class TS_Inc3_Sprint1 {

//        CR-348	Commit an amended version of an active rule
//        CR-349	Archive the original version of an amended Live rule

//        CR-292 *	Document Rules-Service API
//        CR-471	Create simplified API definition
//        CR-472	Fix UI tests following Angular upgrade
//        CR-485 *	Setup FastP Environment for Test Automation

}
