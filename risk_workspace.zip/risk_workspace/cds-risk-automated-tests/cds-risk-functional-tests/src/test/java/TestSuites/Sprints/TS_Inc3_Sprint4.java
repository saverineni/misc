package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_CreateDraftRule;
import TestCases.RulesManagementService.TestCase_CreateNationalRule;
import TestCases.RulesManagementService.TestCase_Login;
import TestCases.RulesManagementService.TestCase_StoreUserDateDetails;
import TestCases.UserService.TestCase_UserService;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory({ChangeRequest.CR_557.class, ChangeRequest.CR_578.class, ChangeRequest.CR_585.class})
//@Suite.SuiteClasses({
//        TestCase_CreateDraftRule.class,
//        TestCase_CreateNationalRule.class,
//        TestCase_StoreUserDateDetails.class,
//        TestCase_Login.class,
//        TestCase_UserService.class
//        })

public class TS_Inc3_Sprint4 {

//    ChangeRequest-557	Assign a single location to a single user role
//    ChangeRequest-578	Store user and date details when creating a rule

//    ChangeRequest-581 *	Restrict user creation by location assigned to a SuperAdmin/Admin role
    //TODO: Note their are no restrictions in place for backend, this functionality is controlled by UI at the moment.

//    ChangeRequest-585	Create National Rule as a National Rule Manager

//    ChangeRequest-604	Implement Rule Management Navigation


//    ChangeRequest-569	Integrate Gatling Performance Tests with Jenkins
//    ChangeRequest-640 *	Add Jenkins Build Jobs for Regression Tests in QA Environment
//    ChangeRequest-642 *	Investigate why UI Tests are not being executed on Jenkins

}
