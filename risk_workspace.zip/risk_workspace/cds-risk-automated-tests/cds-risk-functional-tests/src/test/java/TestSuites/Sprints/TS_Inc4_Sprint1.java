package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_RM_UserMetaCreate;
import TestCases.UserService.TestCase_UserService;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//
//@Categories.IncludeCategory({ChangeRequest.CR_655.class})
//
//@Suite.SuiteClasses({TestCase_RM_UserMetaCreate.class, TestCase_UserService.class})

public class TS_Inc4_Sprint1 {

//    CR-655	Assign multiple roles and locations couplets to a user

//    CR-776	Upgrade Angular (v2)	Story	Low	DONE	8
//    CR-786	Tech Spike - Execute a Rule that uses a Data Table Lookup	Story	Low	DONE	8
//    CR-788	CDP Test Harness Planning	Story	Low	DONE	3
//    CR-789	CDP Test Harness Meeting Southend	Story	Low	DONE	3
//    CR-792 *	Agree pipeline deployments	Story	Low	DONE	1
//    CR-806 *	API Test Automation Coverage	Story	Low	DONE	3
//    CR-838 *	Security Workshop

}
