package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_CreateNationalRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_620.class)
//@Suite.SuiteClasses({TestCase_CreateNationalRule.class})

public class TS_CR_620 {
    //TS_CR_620 Indicate rule is a National rule on the List Rules page
}
