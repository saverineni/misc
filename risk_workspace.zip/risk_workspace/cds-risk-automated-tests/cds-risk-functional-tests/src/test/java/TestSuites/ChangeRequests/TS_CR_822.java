package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.DataService.TestCase_DataTableService;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_822.class)
//@Suite.SuiteClasses({TestCase_DataTableService.class})

public class TS_CR_822 {
    //CR-822 View 'List Data Tables' page
}
