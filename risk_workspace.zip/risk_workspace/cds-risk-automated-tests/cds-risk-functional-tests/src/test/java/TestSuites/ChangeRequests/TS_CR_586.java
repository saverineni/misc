package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_CommitRule;
import TestCases.RulesManagementService.TestCase_CreateLocalRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_586.class)
//@Suite.SuiteClasses({TestCase_CreateLocalRule.class, TestCase_CommitRule.class})

public class TS_CR_586 {

//    CR-586 Create Local Rule as a Local or National Rule Manager
}
