package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.DataService.TestCase_DataTableService;
import TestCases.RuleService.TestCase_RuleService;
import TestCases.RulesManagementService.TestCase_CreateDraftRule;
import TestCases.RulesManagementService.TestCase_DataTable_Ammend;
import TestCases.RulesManagementService.TestCase_DataTable_Create;
import TestCases.UserService.TestCase_UserService;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

//@RunWith(Categories.class)
//
//@Categories.IncludeCategory({ChangeRequest.CR_836.class, ChangeRequest.CR_947.class, ChangeRequest.CR_609.class})
//
//@Suite.SuiteClasses({TestCase_UserService.class, TestCase_RuleService.class, TestCase_CreateDraftRule.class,
//        TestCase_DataTableService.class, TestCase_DataTable_Create.class, TestCase_DataTable_Ammend.class})

public class TS_Inc4_Sprint4 {

//CR-836 - User service change locationId to locationUuid

//CR-947 - Create a data table for a location

//CR-609 - Add 'Regime' field to National rule creation
}
