package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RiskingService.TestCase_Risking_RuleLifeCycle;
import TestCases.RulesManagementService.TestCase_CreateDraftRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)

//@Categories.IncludeCategory({ChangeRequest.CR_175.class, ChangeRequest.CR_220.class})

//@Suite.SuiteClasses({TestCase_Risking_RuleLifeCycle.class, TestCase_CreateDraftRule.class})

public class TS_Inc1_Sprint5 {

//    Increment 1 Sprint 5
//
//    CR-175	(PI2): Process simple Increment 2 incoming message
    //    CR-220 *	List current created rules

//    CR-176	Amend rule management UI to write rules for Increment 2 message
    //    CR-184	Prove Docker in Fast-P
//    CR-213	Drools NullPointerException
//    CR-216 *	Update ui project top angular 2 release candidate

}
