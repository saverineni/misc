package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RiskingService.TestCase_Risking_RuleLifeCycle;
import TestCases.RulesManagementService.TestCase_PendingRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_356.class)
//@Suite.SuiteClasses({TestCase_PendingRule.class, TestCase_Risking_RuleLifeCycle.class})

public class TS_CR_356 {
//    CR-356	Commit pending rule
}
