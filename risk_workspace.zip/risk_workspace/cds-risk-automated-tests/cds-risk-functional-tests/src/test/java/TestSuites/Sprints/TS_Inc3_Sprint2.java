package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.UserService.TestCase_UserService;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory({ChangeRequest.CR_475.class, ChangeRequest.CR_495.class, ChangeRequest.CR_496.class})
//
//@Suite.SuiteClasses({
//        TestCase_UserService.class
//        })

public class TS_Inc3_Sprint2 {

//        CR-475	Create API to add a user
//        CR-495	View user
//        CR-496	View User List

//        CR-478	Implement System Admin navigation UI
//        CR-493	Implement 'Create User' UI

//        CR-501 *	Performance Test - Risking Service
//        CR-509 *	Define issue tracking process
//        CR-521 *	Fix publishing to Nexus from Jenkins when PUBLISH_SNAPSHOT is true
//        CR-534 *	Fix risking service deployment issue

}
