package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RiskingService.TestCase_Risking_RuleLifeCycle;
import TestCases.RuleService.TestCase_RuleService;
import TestCases.RulesManagementService.TestCase_CreateDraftRule;
import TestCases.RulesManagementService.TestCase_RulesManagement;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)

//@Categories.IncludeCategory({ChangeRequest.CR_1.class, ChangeRequest.CR_28.class})

//@Suite.SuiteClasses({TestCase_RuleService.class, TestCase_RulesManagement.class,
//                        TestCase_CreateDraftRule.class, TestCase_Risking_RuleLifeCycle.class})

public class TS_Inc1_Sprint1 {

//    CR-1	Run Very Basic Risk assessment
//    CR-28 *	Create very basic rule

}
