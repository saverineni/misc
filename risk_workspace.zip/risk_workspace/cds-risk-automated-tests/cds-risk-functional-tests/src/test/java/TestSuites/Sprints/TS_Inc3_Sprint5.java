package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_CreateDraftRule;
import TestCases.RulesManagementService.TestCase_CreateLocalRule;
import TestCases.RulesManagementService.TestCase_CreateNationalRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//
//@Categories.IncludeCategory({ChangeRequest.CR_619.class, ChangeRequest.CR_620.class, ChangeRequest.CR_621.class,
//                            ChangeRequest.CR_624.class, ChangeRequest.CR_625.class})
//
//@Suite.SuiteClasses({TestCase_CreateDraftRule.class, TestCase_CreateLocalRule.class, TestCase_CreateNationalRule.class})

public class TS_Inc3_Sprint5 {

//    ChangeRequest-619 *	Indicate rule is a National rule on the Rule Summary, Detail & Edit pages
//    ChangeRequest-620 *	Indicate rule is a National rule on the List Rules page
//    ChangeRequest-621 *	Apply filters to List Rules based on user's role and location
//    ChangeRequest-624 *	Indicate the rule is a Local rule on the Rule Summary, Detail & Edit pages
//    ChangeRequest-625 *	Indicate rule is a Local rule on the List Rules page	Story

//    ChangeRequest-704 *	Add some realistic users to user-service
//    ChangeRequest-709 *	Configure UI Smoke test pack to run via jenkins
//    ChangeRequest-722 *	Update Performance Tests to reflect changes made to Rules Management API in Inc3 Sprint4

}
