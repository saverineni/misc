package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_DataTable_Ammend;
import TestCases.RulesManagementService.TestCase_StoreUserDateDetails;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_825.class)
//@Suite.SuiteClasses({TestCase_DataTable_Ammend.class, TestCase_StoreUserDateDetails.class})

public class TS_CR_825 {
    //Edit the data held within the data table
}
