package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_CreateDraftRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)

//@Categories.IncludeCategory({ChangeRequest.CR_221.class, ChangeRequest.CR_222.class})

//@Suite.SuiteClasses({TestCase_CreateDraftRule.class})

public class TS_Inc2_Sprint1 {

//    CR-221	Access and view previous versions of a rule
//    CR-222	Amend and save a draft version of a rule


//    CR-210	Improve code coverage of back end services
//    CR-218	Prototype Rule Versions UI
//
//    CR-282	Document APIs using Blueprint
//    CR-285 *Deploy Increment 1 Sprint 5 into Fast-P
}
