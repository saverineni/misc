package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RuleService.TestCase_RuleService;
import TestCases.RulesManagementService.TestCase_CreateNationalRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_609.class)
//@Suite.SuiteClasses({TestCase_RuleService.class, TestCase_CreateNationalRule.class})

public class TS_CR_609 {

//CR-609 - Add 'Regime' field to National rule creation
}
