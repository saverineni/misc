package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RiskingService.TestCase_Risking_RuleLifeCycle;
import TestCases.RulesManagementService.TestCase_CommitRule;
import TestCases.RulesManagementService.TestCase_CreateDraftRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)

//@Categories.IncludeCategory({ChangeRequest.CR_267.class, ChangeRequest.CR_281.class})

//@Suite.SuiteClasses({TestCase_CreateDraftRule.class, TestCase_CommitRule.class, TestCase_Risking_RuleLifeCycle.class})

public class TS_Inc2_Sprint2 {

//    Increment 2 Sprint 2
//    CR-231	Bring UI project in line with angular style guide
//    CR-267	Create and Save rule as a draft
//    CR-281	Save draft rule as Live
}
