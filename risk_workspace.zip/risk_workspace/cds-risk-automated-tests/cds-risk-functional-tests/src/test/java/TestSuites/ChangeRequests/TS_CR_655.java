package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_RM_UserMetaCreate;
import TestCases.UserService.TestCase_UserService;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_655.class)
//@Suite.SuiteClasses({TestCase_RM_UserMetaCreate.class, TestCase_UserService.class})

public class TS_CR_655 {
    //CR_655 Assign multiple roles and locations couplets to a user
}
