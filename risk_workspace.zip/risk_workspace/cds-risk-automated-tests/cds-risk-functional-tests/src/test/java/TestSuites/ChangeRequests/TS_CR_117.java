package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_CreateDraftRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_117.class)
//@Suite.SuiteClasses({TestCase_CreateDraftRule.class})

public class TS_CR_117 {
//    CR-117	Create a rule that searches for a given consignorID at both header and item level
}
