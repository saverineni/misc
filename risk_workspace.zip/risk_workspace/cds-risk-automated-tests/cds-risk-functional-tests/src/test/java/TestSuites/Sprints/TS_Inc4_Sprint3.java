package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.DataService.TestCase_DataTableService;
import TestCases.RiskingService.TestCase_Risking_RuleLifeCycle;
import TestCases.RulesManagementService.TestCase_CreateRuleWithDataTable;
import TestCases.RulesManagementService.TestCase_DataTable_Ammend;
import TestCases.RulesManagementService.TestCase_DataTable_Create;
import TestCases.RulesManagementService.TestCase_StoreUserDateDetails;
import TestCases.TestCase_RM_MetaDataService;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//
//@Categories.IncludeCategory({ChangeRequest.CR_823.class, ChangeRequest.CR_825.class, ChangeRequest.CR_826.class, ChangeRequest.CR_927.class,
//        ChangeRequest.CR_936.class, ChangeRequest.CR_938.class, ChangeRequest.CR_939.class, ChangeRequest.CR_904.class})
//
//@Suite.SuiteClasses({TestCase_DataTableService.class, TestCase_DataTable_Create.class, TestCase_DataTable_Ammend.class,
//            TestCase_StoreUserDateDetails.class, TestCase_CreateRuleWithDataTable.class, TestCase_Risking_RuleLifeCycle.class,
//        TestCase_RM_MetaDataService.class})

public class TS_Inc4_Sprint3 {

    //CR-823 View data table summary page (UI)
    //CR-825 Edit the data held within the data table

    //CR-927 View data table details page (UI)

    //CR_936 - Add a single value to a data table
    //CR_938 - Remove a single value from a data table
    //CR_939 Add multiple values to a data table

    //CR-826 Include a data table in a rule

    //CR_904 - Load and execute rule that includes a data table value
}
