package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.UserService.TestCase_UserService;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_475.class)
//@Suite.SuiteClasses({TestCase_UserService.class})

public class TS_CR_475 {
//        CR-475	Create API to add a user
}
