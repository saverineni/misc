package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.DataService.TestCase_DataTableService;
import TestCases.TestCase_RM_MetaDataService;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_1015.class)
//@Suite.SuiteClasses({TestCase_DataTableService.class, TestCase_RM_MetaDataService.class})

public class TS_CR_1015 {
//CR-1015 - Filter Data Tables by Data Type
}
