package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_CreateRuleWithDataTable;
import TestCases.TestCase_RM_MetaDataService;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_947.class)
//@Suite.SuiteClasses({TestCase_CreateRuleWithDataTable.class, TestCase_RM_MetaDataService.class})

public class TS_CR_947 {
//CR-947 - Create a data table for a location
}
