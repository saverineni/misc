package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.DataService.TestCase_DataTableService;
import TestCases.RuleService.TestCase_RuleService;
import TestCases.RulesManagementService.TestCase_CreateNationalRule;
import TestCases.TestCase_RM_MetaDataService;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

//@RunWith(Categories.class)
//
//@Categories.IncludeCategory({ChangeRequest.CR_609.class, ChangeRequest.CR_1015.class, ChangeRequest.CR_983.class})
//
//@Suite.SuiteClasses({TestCase_RuleService.class, TestCase_CreateNationalRule.class, TestCase_DataTableService.class,
//    TestCase_RM_MetaDataService.class})

public class TS_Inc4_Sprint5 {

//CR-609 - Add 'Regime' field to National rule creation

//CR-1015 - Filter Data Tables by Data Type

//CR-983 -Share a Data Table for Usage at another Location
}
