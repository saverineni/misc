package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RiskingService.TestCase_Risking_RuleLifeCycle;
import TestCases.RulesManagementService.TestCase_DeleteRule;
import TestCases.RulesManagementService.TestCase_RulesManagement;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)

//@Categories.IncludeCategory({ChangeRequest.CR_271.class, ChangeRequest.CR_311.class, ChangeRequest.CR_312.class})

//@Suite.SuiteClasses({TestCase_Risking_RuleLifeCycle.class, TestCase_DeleteRule.class, TestCase_RulesManagement.class})

public class TS_Inc2_Sprint3 {

//    CR-271 *	Delete draft
//    CR-311 *	Amend rule management UI to include CPC code
//    CR-312 *	Process incoming message to include CPC code

//    CR-83 *	Prove can develop front end on Stride machine
//    CR-214 *	QA Document Fast-P requirements

}
