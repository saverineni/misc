package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RiskingService.TestCase_Risking_RuleLifeCycle;
import TestCases.RulesManagementService.TestCase_CreateDraftRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_267.class)
//@Suite.SuiteClasses({TestCase_CreateDraftRule.class, TestCase_Risking_RuleLifeCycle.class})

public class TS_CR_267 {
    //    CR-267	Create and Save rule as a draft
}
