package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RiskingService.TestCase_Risking_RuleLifeCycle;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

//
//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_175.class)
//@Suite.SuiteClasses({TestCase_Risking_RuleLifeCycle.class})

public class TS_CR_175 {
//    CR-175	(PI2): Process simple Increment 2 incoming message
}
