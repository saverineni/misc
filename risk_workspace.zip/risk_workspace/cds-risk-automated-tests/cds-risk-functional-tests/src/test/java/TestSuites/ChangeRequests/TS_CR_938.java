package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_DataTable_Ammend;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_938.class)
//@Suite.SuiteClasses({TestCase_DataTable_Ammend.class})

public class TS_CR_938 {
    //CR_938 - Remove a single value from a data table
}
