package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RiskingService.TestCase_Risking_RuleLifeCycle;
import TestCases.RulesManagementService.TestCase_CommitRule;
import TestCases.RulesManagementService.TestCase_CreateDraftRule;
import TestCases.RulesManagementService.TestCase_ReinstateRule;
import TestCases.RulesManagementService.TestCase_SuspendRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)

//@Categories.IncludeCategory({ChangeRequest.CR_279.class, ChangeRequest.CR_325.class, ChangeRequest.CR_345.class,
//        ChangeRequest.CR_351.class, ChangeRequest.CR_380.class})

//@Suite.SuiteClasses({TestCase_Risking_RuleLifeCycle.class, TestCase_SuspendRule.class, TestCase_CreateDraftRule.class,
//                    TestCase_ReinstateRule.class, TestCase_CommitRule.class})

public class TS_Inc2_Sprint4 {

//    CR-279	Archive a single Live rule
//    CR-325	Suspend Live rule
//    CR-345	Populate 'valid' flag correctly on JSON response
//    CR-351	Reinstate suspended live rule
//    CR-380 *	Introduce 'Active' state

//    CR-357	Setup Synopia Fast-P
//    CR-359	Parametise UI docker image
//    CR-361	Investigate how to clone Nexus into Fast-P
//    CR-363	Clone Bitbucket in Fast-P
//    CR-364	Clone Nexus into Fast-P

//    CR-385 *	Update wireframes
//    CR-283	Automate deployment into Fast-P
}
