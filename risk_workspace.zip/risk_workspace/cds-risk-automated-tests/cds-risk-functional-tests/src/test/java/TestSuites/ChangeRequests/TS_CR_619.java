package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_CreateNationalRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_619.class)
//@Suite.SuiteClasses({TestCase_CreateNationalRule.class})

public class TS_CR_619 {

    //CR_619 Indicate rule is a National rule on the Rule Summary, Detail & Edit pages
}
