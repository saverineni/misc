package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RuleService.TestCase_RuleService;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)

//@Categories.IncludeCategory({ChangeRequest.CR_38.class})

//@Suite.SuiteClasses({TestCase_RuleService.class})

public class TS_Inc1_Sprint2 {

//    Increment 1 Sprint 2
//    CR-38 *	Introduce Rules Service

//    CR-45 *	Modify Rules Management Service to use Rules Service
//    CR-46 *	Modify Execution Service to use Rules Service
//    CR-47 *	Fix intermittent issue loading rules in risking service
//    CR-73 *	Rationalise JSON format to support logical groupings

}
