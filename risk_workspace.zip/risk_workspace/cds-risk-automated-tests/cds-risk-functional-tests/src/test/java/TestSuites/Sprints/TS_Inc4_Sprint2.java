package TestSuites.Sprints;

import Categories_CDSRisk.ChangeRequest;
import TestCases.DataService.TestCase_DataTableService;
import TestCases.RulesManagementService.TestCase_CommitRule;
import TestCases.RulesManagementService.TestCase_CreateLocalRule;
import TestCases.RulesManagementService.TestCase_RM_UserMetaCreate;
import TestCases.UserService.TestCase_UserService;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

//@RunWith(Categories.class)
//
//@Categories.IncludeCategory({ChangeRequest.CR_655.class, ChangeRequest.CR_848.class, ChangeRequest.CR_586.class, ChangeRequest.CR_594.class,
//        ChangeRequest.CR_622.class, ChangeRequest.CR_787.class, ChangeRequest.CR_822.class})
//
//@Suite.SuiteClasses({TestCase_RM_UserMetaCreate.class, TestCase_UserService.class, TestCase_CreateLocalRule.class,
//        TestCase_CommitRule.class, TestCase_DataTableService.class})

public class TS_Inc4_Sprint2 {

//CR-586 Create Local Rule as a Local or National Rule Manager
//CR-594 Create local rules for different single locations
//CR_787 Create, save & publish data table structure (UI)

//CR-622 Add 'Base Location' field to user creation

//CR-822 View 'List Data Tables' page
//CR-848 Create local rules for multiple locations

}
