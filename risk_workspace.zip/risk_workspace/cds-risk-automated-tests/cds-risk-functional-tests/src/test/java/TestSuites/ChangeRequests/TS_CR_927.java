package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_CreateLocalRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_848.class)
//@Suite.SuiteClasses({TestCase_CreateLocalRule.class})

public class TS_CR_927 {
    //CR_927 - View data table detail page (UI)
}
