package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_RulesManagement;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_107.class)
//@Suite.SuiteClasses({TestCase_RulesManagement.class})

public class TS_CR_107 {
    //    CR-107	Write tests to ensure cross-domain security headers are served
}
