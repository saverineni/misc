package TestSuites.ChangeRequests;

import Categories_CDSRisk.ChangeRequest;
import TestCases.RulesManagementService.TestCase_CreateLocalRule;
import TestCases.RulesManagementService.TestCase_CreateNationalRule;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//@RunWith(Categories.class)
//@Categories.IncludeCategory(ChangeRequest.CR_621.class)
//@Suite.SuiteClasses({TestCase_CreateLocalRule.class, TestCase_CreateNationalRule.class})

public class TS_CR_621 {
    //TS_CR_621 Apply filters to List Rules based on user's role and location
}
