package Categories_CDSRisk;

public interface SmokeTests {}
