package Categories_CDSRisk;

public interface Slow_Tests
{

}
