package Categories_CDSRisk;

public class ChangeRequest_RiskingService
{
    public interface CREP_99 {}
    public interface CREP_116 {}
    public interface CREP_119 {}
    public interface CREP_120 {}
    public interface CREP_121 {}

    public interface CREP_133 {}
    public interface CREP_142 {}
    public interface CREP_145 {}
    public interface CREP_229 {}
    public interface CREP_233 {}
    public interface CREP_255 {}
    public interface CREP_258 {}
    public interface CREP_261 {}
    public interface CREP_281 {}
    public interface CREP_285 {}
    public interface CREP_287 {}
    public interface CREP_290 {}
    public interface CREP_294 {}
    public interface CREP_295 {}
    public interface CREP_299 {}

    public interface CREP_302 {}
    public interface CREP_305 {}
    public interface CREP_322 {}
    public interface CREP_333 {}
    public interface CREP_378 {}
    public interface CREP_382 {}
    public interface CREP_383 {}

    public interface CREP_403 {}
    public interface CREP_406 {}
    public interface CREP_410 {}
    public interface CREP_439 {}
    public interface CREP_440 {}
    public interface CREP_482 {}

    public interface CREP_611 {}

    public interface CREP_650 {}

    public interface CREP_729 {}
    public interface CREP_730 {}
    public interface CREP_731 {}
}