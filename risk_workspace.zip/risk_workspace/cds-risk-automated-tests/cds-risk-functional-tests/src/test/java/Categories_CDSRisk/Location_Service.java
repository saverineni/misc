package Categories_CDSRisk;

public interface Location_Service
{

}
