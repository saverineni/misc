package Categories_CDSRisk;

public interface CDS_Connectivity
{

}
