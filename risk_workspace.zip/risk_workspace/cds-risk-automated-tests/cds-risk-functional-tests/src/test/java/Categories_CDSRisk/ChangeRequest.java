package Categories_CDSRisk;

public class ChangeRequest
{
    public interface CR_1 {}
    public interface CR_28 {}

    public interface CR_38 {}

    public interface CR_107 {}
    public interface CR_116 {}
    public interface CR_117 {}

    public interface CR_175 {}
    public interface CR_178 {}

    public interface CR_220 {}
    public interface CR_221 {}
    public interface CR_222 {}

    public interface CR_259 {}
    public interface CR_260 {}
    public interface CR_261 {}

    public interface CR_267 {}
    public interface CR_281 {}

    public interface CR_271 {}


    public interface CR_279 {}

    public interface CR_311 {}
    public interface CR_312 {}
    public interface CR_325 {}

    public interface CR_339 {}
    public interface CR_340 {}

    public interface CR_345 {}
    public interface CR_348 {}
    public interface CR_349 {}

    public interface CR_351 {}

    public interface CR_356 {}

    public interface CR_380 {}

    public interface CR_475 {}

    public interface CR_494 {}
    public interface CR_495 {}
    public interface CR_496 {}

    public interface CR_553 {}
    public interface CR_554 {}

    public interface CR_557 {}
    public interface CR_578 {}

    public interface CR_585 {}
    public interface CR_586 {}
    public interface CR_582 {}

    public interface CR_594 {}
    public interface CR_597 {}
    public interface CR_598 {}

    public interface CR_609 {}
    public interface CR_619 {}
    public interface CR_620 {}
    public interface CR_621 {}
    public interface CR_622 {}
    public interface CR_624 {}
    public interface CR_625 {}
    public interface CR_633 {}

    public interface CR_655 {}
    public interface CR_775 {}
    public interface CR_787 {}

    public interface CR_822 {}
    public interface CR_823 {}
    public interface CR_825 {}
    public interface CR_826 {}
    public interface CR_836 {}
    public interface CR_848 {}


    public interface CR_904 {}
    public interface CR_927 {}
    public interface CR_928 {}

    public interface CR_936 {}
    public interface CR_938 {}
    public interface CR_939 {}
    public interface CR_947 {}
    public interface CR_983 {}

    public interface CR_1015 {}
    public interface CR_1016 {}
    public interface CR_1027 {}

    public interface CR_1029 {}

    public interface CR_1091 {}
    public interface CR_1104 {}
    public interface CR_1133 {}

    public interface CR_1134 {}
    public interface CR_1135 {}

    public interface CR_1145 {}

    public interface CR_1147 {}
    public interface CR_1149 {}

    public interface CR_1151 {}
    public interface CR_1152 {}
    public interface CR_1057 {}

    public interface CR_1186 {}
    public interface CR_1188 {}
    public interface CR_1190 {}

    public interface CR_1204 {}
    public interface CR_1205 {}
    public interface CR_1211 {}
    public interface CR_1213 {}
    public interface CR_1214 {}
    public interface CR_1216 {}
    public interface CR_1217 {}
    public interface CR_1218 {}
    public interface CR_1222 {}

    public interface CR_1235 {}
    public interface CR_1236 {}
    public interface CR_1237 {}

    public interface CR_1366 {}
    public interface CR_1398 {}

    public interface CR_1403 {}
    public interface CR_1404 {}
    public interface CR_1421 {}
    public interface CR_1422 {}
    public interface CR_1426 {}
    public interface CR_1442 {}
    public interface CR_1445 {}

    public interface CR_1478 {}

    public interface CR_1480 {}
    public interface CR_1481 {}
    public interface CR_1487 {}

    public interface CR_1510 {}

    public interface CR_1566 {}
    public interface CR_1567 {}
    public interface CR_1574 {}
    public interface CR_1575 {}
    public interface CR_1576 {}
    public interface CR_1577 {}
    public interface CR_1582 {}

    public interface CR_1605 {}
    public interface CR_1624 {}
    public interface CR_1625 {}
    public interface CR_1628 {}
    public interface CR_1636 {}
    public interface CR_1637 {}
    public interface CR_1643 {}

    public interface CR_1674 {}

    public interface CR_1680 {}
    public interface CR_1695 {}

    public interface CR_1711 {}
    public interface CR_1712 {}
    public interface CR_1714 {}

    public interface CR_1750 {}
    public interface CR_1752 {}
    public interface CR_1753 {}

    public interface CR_1761 {}
    public interface CR_1762 {}
    public interface CR_1764 {}
    public interface CR_1771 {}
    public interface CR_1783 {}
    public interface CR_1792 {}

    public interface CR_1815 {}
    public interface CR_1882 {}
    public interface CR_1837 {}
    public interface CR_1847 {}
    public interface CR_1850 {}

    public interface CR_1866 {}
    public interface CR_1869 {}
    public interface CR_1870 {}
    public interface CR_1871 {}
    public interface CR_1872 {}

    public interface CR_1875 {}
    public interface CR_1879 {}
    public interface CR_1880 {}
    public interface CR_1883 {}

    public interface CR_1908 {}
    public interface CR_1966 {}
    public interface CR_1978 {}
    public interface CR_1982 {}
    public interface CR_1903 {}
    public interface CR_1905{}
    public interface CR_1909 {}

    public interface CR_2004 {}
    public interface CR_2066 {}
    public interface CR_2094 {}
    public interface CR_2097 {}
    public interface CR_2109 {}
    public interface CR_2127 {}
    public interface CR_2135 {}
    public interface CR_2148 {}
    public interface CR_2149 {}
    public interface CR_2116 {}
    public interface CR_2191 {}

    public interface CR_2203 {}
    public interface CR_2213 {}
    public interface CR_2217 {}

    public interface CR_2211 {}
    public interface CR_2224 {}
    public interface CR_2225 {}
    public interface CR_2226 {}
    public interface CR_2236 {}
    public interface CR_2239 {}
    public interface CR_2244 {}
    public interface CR_2245 {}
    public interface CR_2247 {}
    public interface CR_2253 {}
    public interface CR_2269 {}

    public interface CR_2274 {}
    public interface CR_2280 {}

    public interface CR_2350 {}
    public interface CR_2353 {}
    public interface CR_2354 {}
    public interface CR_2362 {}

    public interface CR_2429 {}
    public interface CR_2430 {}
    public interface CR_2436 {}
    public interface CR_2456 {}
    public interface CR_2462 {}
    public interface CR_2465 {}
    public interface CR_2487 {}

    public interface CR_2557 {}
    public interface CR_2558 {}
    public interface CR_2559 {}
    public interface CR_2560 {}
    public interface CR_2566 {}
    public interface CR_2589 {}
    public interface CR_2593 {}
    public interface CR_2594 {}
    public interface CR_2599 {}
    public interface CR_2601 {}
    public interface CR_2602 {}


    public interface CR_2604 {}
    public interface CR_2610 {}
    public interface CR_2611 {}
    public interface CR_2614 {}
    public interface CR_2615 {}
    public interface CR_2621 {}
    public interface CR_2622 {}
    public interface CR_2623 {}
    public interface CR_2625 {}
    public interface CR_2627 {}
    public interface CR_2628 {}
    public interface CR_2638 {}
    public interface CR_2640 {}
    public interface CR_2645 {}
    public interface CR_2676 {}
    public interface CR_2673 {}
    public interface CR_2680 {}
    public interface CR_2693 {}
    public interface CR_2694 {}
    public interface CR_2698 {}

    public interface CR_2724 {}
    public interface CR_2739 {}
    public interface CR_2740 {}
    public interface CR_2741 {}
    public interface CR_2742 {}
    public interface CR_2743 {}
    public interface CR_2763 {}
    public interface CR_2769 {}

    public interface CR_2770 {}

    public interface CR_2782 {}
    public interface CR_2783 {}
    public interface CR_2784 {}

    public interface CR_2808 {}
    public interface CR_2822 {}
    public interface CR_2849 {}
    public interface CR_2858 {}
    public interface CR_2861 {}
    public interface CR_2862 {}

    public interface CR_2908 {}
    public interface CR_2949 {}
    public interface CR_2950 {}
    public interface CR_2951 {}
    public interface CR_2952 {}
    public interface CR_2954 {}
    public interface CR_2955 {}
    public interface CR_2982 {}
    public interface CR_2863 {}
    public interface CR_2925 {}
    public interface CR_2974 {}
    public interface CR_2975 {}
    public interface CR_2976 {}
    public interface CR_2977 {}
    public interface CR_2978 {}
    public interface CR_2985 {}
    public interface CR_3002 {}
    public interface CR_3009 {}
    public interface CR_3026 {}
    public interface CR_3057 {}
    public interface CR_3061 {}
    public interface CR_3063 {}
    public interface CR_3027 {}
    public interface CR_3077 {}
    public interface CR_3100 {}
    public interface CR_3086 {}
    public interface CR_3095 {}
    public interface CR_3067 {}
    public interface CR_3115 {}
    public interface CR_3076 {}
    public interface CR_3110 {}
    public interface CR_3105 {}
    public interface CR_3121 {}
    public interface CR_3184 {}
    public interface CR_3190 {}
    public interface CR_3203 {}
    public interface CR_3242 {}
    public interface CR_3243 {}
    public interface CR_3212 {}
    public interface CR_3264 {}
    public interface CR_3275 {}
    public interface CR_3276 {}
    public interface CR_3228 {}
    public interface CR_3278 {}
    public interface CR_3315 {}
    public interface CR_3314 {}
    public interface CR_3319 {}
    public interface CR_3317 {}
    public interface CR_3318 {}
    public interface CR_3321 {}
    public interface CR_3330 {}
    public interface CR_3331 {}
    public interface CR_3128 {}
    public interface CR_3322 {}
    public interface CR_3377 {}
    public interface CR_3378 {}
    public interface CR_3397 {}
    public interface CR_3329 {}
    public interface CR_3393 {}
    public interface CR_3394 {}
    public interface CR_3395 {}
    public interface CR_3396 {}
    public interface CR_3381 {}
    public interface CR_3383 {}
    public interface CR_3386 {}
    public interface CR_3406 {}
    public interface CR_3408 {}

    public interface CR_3414 {}
    public interface CR_3417 {}
    public interface CR_3419 {}
    public interface CR_3418 {}
    public interface CR_3423 {}
    public interface CR_3424 {}
    public interface CR_3425 {}
    public interface CR_3433 {}
    public interface CR_3435 {}
    public interface CR_3464 {}
    public interface CR_3521 {}
    public interface CR_3462 {}



    public interface CRX_2 {}
    public interface CRX_4 {}
    public interface CRX_6 {}
    public interface CRX_104 {}
    public interface CRX_140 {}
    public interface CRX_141 {}
    public interface CRX_193 {}
    public interface CRX_203 {}
    public interface CRX_205 {}
    public interface CRX_248 {}
    public interface CRX_249 {}
    public interface CRX_313 {}
    public interface CRX_150 {}
    public interface CRX_288 {}
    public interface CRX_310 {}
}