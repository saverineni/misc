package Categories_CDSRisk;

public interface Rule_Service
{

}
