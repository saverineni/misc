package Categories_CDSRisk;

public interface CDS_RM_CreateRules
{

}
