package Categories_CDSRisk;


public interface HealthCheck {

}
