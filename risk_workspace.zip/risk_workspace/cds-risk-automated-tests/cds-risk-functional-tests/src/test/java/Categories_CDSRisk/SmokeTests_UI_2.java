package Categories_CDSRisk;

public interface SmokeTests_UI_2
{

}
