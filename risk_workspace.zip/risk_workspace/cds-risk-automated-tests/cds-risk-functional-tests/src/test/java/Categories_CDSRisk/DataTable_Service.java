package Categories_CDSRisk;

public interface DataTable_Service
{

}
