package Categories_CDSRisk;


public interface Assignee_Service {
}
