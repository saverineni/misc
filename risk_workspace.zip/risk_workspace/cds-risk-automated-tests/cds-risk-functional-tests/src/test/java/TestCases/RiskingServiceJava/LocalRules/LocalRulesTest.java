package TestCases.RiskingServiceJava.LocalRules;

import API.DataForTests.TestRuleModel;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import Categories_CDSRisk.DebugFailingTests;
import Categories_CDSRisk.Risking_JavaService;
import TestCases.RiskingServiceJava.BaseRiskingServiceJava;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.DeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.GoodsItemDeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.HeaderDeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;
import uk.gov.hmrc.risk.test.common.enums.TransportMode;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Slf4j
@Category({Risking_JavaService.class})
public class LocalRulesTest extends BaseRiskingServiceJava {

    private CreateRuleModel model;
    private Map<DeclarationParam, String> conditions = new HashMap<>();
    private String declarationId;
    String ruleId;
    String responseId;

    @Before
    public void addConditionToRule() {
        super.before();

        declarationId = UUID.randomUUID().toString();
        conditions.put(HeaderDeclarationParam.ID, declarationId);
        conditions.put(HeaderDeclarationParam.DISPATCH_COUNTRY, "SP");
        conditions.put(HeaderDeclarationParam.TRANSPORT_MODE, "4");
        conditions.put(HeaderDeclarationParam.DECLARATION_TYPE, "EX");
        conditions.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "C");
        conditions.put(HeaderDeclarationParam.DISPATCH_COUNTRY, "SP");
        conditions.put(HeaderDeclarationParam.GOODSlOCATION_ID, "GBBYMNCPOONASInfo");
        conditions.put(GoodsItemDeclarationParam.SEQUENCE_NUMBER, "2001");
        conditions.put(GoodsItemDeclarationParam.Second.SEQUENCE_NUMBER, "2002");
        conditions.put(GoodsItemDeclarationParam.Third.SEQUENCE_NUMBER, "2003");
        conditions.put(GoodsItemDeclarationParam.Fourth.SEQUENCE_NUMBER, "2004");
    }

    @Test
    //TODO use testing common rule creation, doesn't seem to work for local rules currently
    public void whenLocalRuleIsCreated_publishIsSuccessful_ruleIsLoadedToRiskingService() {

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails,
                appStateSupport.getPOOLocalRuleManagerToken());
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit, appStateSupport.getPOOLocalRuleManagerToken());

        publishAndWait();

        DeclarationResponse response = createAndSendDeclaration(conditions, false);

        Assertions.assertThat(response.getControlType()).isEqualTo("2");
    }

}
