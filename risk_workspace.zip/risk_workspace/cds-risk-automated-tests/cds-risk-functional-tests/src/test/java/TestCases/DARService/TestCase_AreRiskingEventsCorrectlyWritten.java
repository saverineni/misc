package TestCases.DARService;

import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.DAR_Client;
import TestCases.RiskingServiceJava.BaseRiskingServiceJava;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.ConditionType;
import uk.gov.hmrc.risk.test.common.enums.DarEventType;
import uk.gov.hmrc.risk.test.common.enums.DeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.HeaderDeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.Operator;
import uk.gov.hmrc.risk.test.common.model.darService.DarDeclarationRiskedEventModel;
import uk.gov.hmrc.risk.test.common.model.darService.DarDeclarationRiskedModel;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import static API.DataForTests.TestEnumerators.RuleOutputs.PHYSICAL_CHECK;

@Slf4j
@Category({ChangeRequest_RiskingService.CREP_295.class, DAR_Client.class})
public class TestCase_AreRiskingEventsCorrectlyWritten extends BaseRiskingServiceJava{

    private String declarationID;
    private String rulePackage;
    private String ruleId;
    private CreateRuleModel createRuleModel;

    @Before
    public void setup() {
        createRuleModel = createRuleModel();
        createRuleModel.setRatDefinition(CreateRuleModel.RatDefinition.builder()
            .firstCountLimitEnabled(true)
            .hitRate(CreateRuleModel.HitRate.builder()
                .frequency("daily")
                .limit(1)
                .build())
            .build()
        );
        createRuleModel.getQuery().get(0).setQuery(
                Arrays.asList(
                        CreateRuleModel.Query.builder()
                                .attribute(HeaderDeclarationParam.DISPATCH_COUNTRY.toString())
                                .operator(Operator.eq.toString())
                                .conditionType(ConditionType.normal.toString())
                                .value("DE")
                                .build()
                )
        );
        ruleId = createAndRefreshRule(createRuleModel);
        publishAndWait();
        rulePackage = null;
    }

    @Test
    @Category({ChangeRequest.CR_3408.class})
    public void WhenSilentRuleIsRisked_RuleFireLoggedInTodaysFile() {
        createSilentRule(ruleId);
        publishAndWait();
        DeclarationResponse declarationResponse = sendDeclarationAndAssertDefaultHit("DE");
        Assertions.assertThat(declarationResponse.getNarrativeText()).isEqualTo("");

        DarDeclarationRiskedModel expectedRiskedModel = DarDeclarationRiskedModel.builder()
                .type(DarEventType.DECLARATION_RISKED.toString())
                .responseId(declarationResponse.getResponseId())
                .declarationId(declarationID)
                .declarationVersion("")
                .rulesPackage(rulePackage)
                .numberOfResults("1")
                .build();

        DarDeclarationRiskedEventModel expectedRiskedEventModel = DarDeclarationRiskedEventModel.builder()
                .type(DarEventType.DECLARATION_RISK_RESULT.toString())
                .responseId(declarationResponse.getResponseId())
                .ruleId(ruleId)
                .actionControlType(PHYSICAL_CHECK.toString())
                .reportBackElement("/declaration")
                .narrative(HOLD_NARRATIVE)
                .matchReason("Declaration field: 'Dispatch Country' was equal to DE. The value was: 'DE'")
                .workBasket("NCH Open General Export Licence")
                .email("")
                .blockingRelease("true")
                .isSecret("false")
                .notifyDeclarant("false")
                .isSuppressedByRats("false")
                .ruleControlType(PHYSICAL_CHECK.toString())
                .build();

        assertDeclarationRisked(expectedRiskedModel);
        assertDeclarationRiskedEvent(expectedRiskedEventModel);
    }


    @Test
    public void WhenDeclarationHitsRule_RuleFireLoggedInTodaysFile() {
        DeclarationResponse declarationResponse = sendDeclarationAndAssertDefaultHit("DE");
        Assertions.assertThat(declarationResponse.getNarrativeText()).isEqualTo(HOLD_NARRATIVE);

        DarDeclarationRiskedModel expectedRiskedModel = DarDeclarationRiskedModel.builder()
                .type(DarEventType.DECLARATION_RISKED.toString())
                .responseId(declarationResponse.getResponseId())
                .declarationId(declarationID)
                .declarationVersion("")
                .rulesPackage(rulePackage)
                .numberOfResults("1")
                .build();

        DarDeclarationRiskedEventModel expectedRiskedEventModel = DarDeclarationRiskedEventModel.builder()
                .type(DarEventType.DECLARATION_RISK_RESULT.toString())
                .responseId(declarationResponse.getResponseId())
                .ruleId(ruleId)
                .actionControlType(PHYSICAL_CHECK.toString())
                .reportBackElement("/declaration")
                .narrative(HOLD_NARRATIVE)
                .matchReason("Declaration field: 'Dispatch Country' was equal to DE. The value was: 'DE'")
                .workBasket("NCH Open General Export Licence")
                .email("")
                .blockingRelease("true")
                .isSecret("false")
                .notifyDeclarant("false")
                .isSuppressedByRats("false")
                .ruleControlType(PHYSICAL_CHECK.toString())
                .build();

        assertDeclarationRisked(expectedRiskedModel);
        assertDeclarationRiskedEvent(expectedRiskedEventModel);
    }

    @Test
    public void WhenDeclarationDoesntHitRule_RuleFireWritten() {
        DeclarationResponse declarationResponse = sendDeclarationAndAssertDefaultHit("PL");
        Assertions.assertThat(declarationResponse.getNarrativeText()).isEmpty();

        DarDeclarationRiskedModel expectedRiskedModel = DarDeclarationRiskedModel.builder()
                .type(DarEventType.DECLARATION_RISKED.toString())
                .responseId(declarationResponse.getResponseId())
                .declarationId(declarationID)
                .declarationVersion("")
                .rulesPackage(rulePackage)
                .numberOfResults("0")
                .build();

        assertDeclarationRisked(expectedRiskedModel);

        List<DarDeclarationRiskedEventModel> filtered = darServiceAuditSupport.parseDeclarationRiskedEvent()
                .stream().filter(log -> log.getResponseId().equals(declarationResponse.getResponseId()))
                .collect(Collectors.toList());
        Assertions.assertThat(filtered).isEmpty();
    }

    @Test
    public void WhenRATSSupressRuleHit_CorrectResultLogged() {
        sendDeclarationAndAssertDefaultHit("DE");
//        declarationID = UUID.randomUUID().toString();
        DeclarationResponse nonHitDeclarationResponse = sendDeclarationAndAssertDefaultHit("DE");

        DarDeclarationRiskedModel expectedRiskedModel = DarDeclarationRiskedModel.builder()
                .type(DarEventType.DECLARATION_RISKED.toString())
                .responseId(nonHitDeclarationResponse.getResponseId())
                .declarationId(declarationID)
                .declarationVersion("")
                .rulesPackage(rulePackage)
                .numberOfResults("1")
                .build();

        DarDeclarationRiskedEventModel expectedRiskedEventModel = DarDeclarationRiskedEventModel.builder()
                .type(DarEventType.DECLARATION_RISK_RESULT.toString())
                .responseId(nonHitDeclarationResponse.getResponseId())
                .ruleId(ruleId)
                .actionControlType(PHYSICAL_CHECK.toString())
                .reportBackElement("/declaration")
                .narrative(HOLD_NARRATIVE)
                .matchReason("Declaration field: 'Dispatch Country' was equal to DE. The value was: 'DE'")
                .workBasket("NCH Open General Export Licence")
                .email("")
                .blockingRelease("true")
                .isSecret("false")
                .notifyDeclarant("false")
                .isSuppressedByRats("true")
                .ruleControlType(PHYSICAL_CHECK.toString())
                .build();

        assertDeclarationRisked(expectedRiskedModel);
        assertDeclarationRiskedEvent(expectedRiskedEventModel);
    }

    private DeclarationResponse sendDeclarationAndAssertDefaultHit(String dispatchCountry) {
        declarationID = UUID.randomUUID().toString();

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_REFERENCE, declarationID);
        declarationFieldValues.put(HeaderDeclarationParam.DISPATCH_COUNTRY, dispatchCountry);

        return createAndSendDeclaration(declarationFieldValues);
    }

    private void assertDeclarationRiskedEvent(DarDeclarationRiskedEventModel expectedBody) {
        List<DarDeclarationRiskedEventModel> filtered = darServiceAuditSupport.parseDeclarationRiskedEvent()
                .stream()
                .filter(log -> log.getResponseId().equals(expectedBody.getResponseId()))
                .collect(Collectors.toList());
        Assertions.assertThat(filtered.size()).isNotZero();

        filtered.forEach(log ->
        {
            Assertions.assertThat(log.getType()).isEqualTo(DarEventType.DECLARATION_RISK_RESULT.toString());
            Assertions.assertThat(log.getRuleId()).contains(expectedBody.getRuleId());
            Assertions.assertThat(log.getActionControlType()).isEqualTo(expectedBody.getActionControlType());
            Assertions.assertThat(log.getReportBackElement()).isEqualTo(expectedBody.getReportBackElement());
            Assertions.assertThat(log.getNarrative()).isEqualTo(expectedBody.getNarrative());
            Assertions.assertThat(log.getMatchReason()).contains(expectedBody.getMatchReason());
            Assertions.assertThat(log.getWorkBasket()).isEqualToIgnoringCase(expectedBody.getWorkBasket());
            Assertions.assertThat(log.getEmail()).isEqualTo(expectedBody.getEmail());
            Assertions.assertThat(log.getBlockingRelease()).isEqualTo(expectedBody.getBlockingRelease());
            Assertions.assertThat(log.getIsSecret()).isEqualTo(expectedBody.getIsSecret());
            Assertions.assertThat(log.getNotifyDeclarant()).isEqualTo(expectedBody.getNotifyDeclarant());
            Assertions.assertThat(log.getIsSuppressedByRats()).isEqualTo(expectedBody.getIsSuppressedByRats());
            Assertions.assertThat(log.getRuleControlType()).isEqualTo(expectedBody.getRuleControlType());
        });
    }

    private void assertDeclarationRisked(DarDeclarationRiskedModel expectedBody) {

        List<DarDeclarationRiskedModel> logs = darServiceAuditSupport.parseDeclarationRisk();

        List<DarDeclarationRiskedModel> filtered = new ArrayList<>();
        logs.stream().filter(log -> log.getDeclarationId().equals(declarationID))
                .forEach(filtered::add);
        Assertions.assertThat(filtered.size()).isNotZero();

        filtered.forEach(log ->
        {
            ZonedDateTime time = darServiceAuditSupport.getFormattedTimestamp(log.getEventTime());
            Assertions.assertThat(time).isBeforeOrEqualTo(ZonedDateTime.now().plusHours(2));
            Assertions.assertThat(log.getType()).isEqualTo(DarEventType.DECLARATION_RISKED.toString());
            Assertions.assertThat(log.getResponseId()).isEqualTo(expectedBody.getResponseId());
            Assertions.assertThat(log.getRulesPackage()).isNotEmpty();
            Assertions.assertThat(log.getNumberOfResults()).isEqualTo(expectedBody.getNumberOfResults());
        });

    }
}
