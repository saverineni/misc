package TestCases.UI.Rules;


import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.RuleAction.RuleActionResponse;
import Categories_CDSRisk.*;
import FunctionsLibrary.DateTime;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.Pages.RulesManagement.CreateNationalRule_Page;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleDetails_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static API.RulesManagementService.Utils.RuleAtStatus.CreateSuspendedRule;
import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_1.class})
public class TestCase_CreatePendingRule extends BaseUIWebDriverTestCase {

    @Before
    public void Setup() {
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);
    }

    public void CreateDraftRuleAndNavigateToRuleSummary() {

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse ruleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.description = ruleResponse.description;

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);
    }


    @Category({SmokeTests_UI.class, ChangeRequest.CR_1879.class})
    @Test
    public void WhenRuleManagerLoggedIn_CanCreatePendingRuleVersionFromDraftRuleVersion() {
        //Arrange
        CreateDraftRuleAndNavigateToRuleSummary();

        //Act
        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        boolean nNewPending = ruleSummary_page.amend.isEnabled();
        assertEquals("Expect New Pending button to be enabled", true, nNewPending);

        ruleSummary_page.amend.click();

        CreateNationalRule_Page createNationalRule_page = new CreateNationalRule_Page(driver);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetailsV2 = UI.DataForTests.Rules.DraftNATRuleVersion2();
        ruleDetailsV2.startRuleImmediately = false;
        ruleDetailsV2.startDate = DateTime.AdjustLocalDateTimeNowByXDays(1);
        ruleDetailsV2.startTime = DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.systemDefault(), 5, "HH:mm");

        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalRuleSingleCondition(ruleDetailsV2);

        createNationalRule_page.clickSaveAndCommitWithDefaultReason();

        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        assertEquals("Expect Rule Status to be Committed", "Committed", listRuleSummaryTableObjects.get(0).status);
        assertEquals("Expect Rule Version to be 2", 2, listRuleSummaryTableObjects.get(0).version);
        assertEquals("Expect Rule Name to be " + ruleDetailsV2.description, ruleDetailsV2.description, listRuleSummaryTableObjects.get(0).description);

        List<RuleSummary_Page.RuleVersionsTableObject> listRuleVersionsTableObjects = ruleSummary_page.getListOfRuleVersions();
        assertEquals("Expect Rule Version Status to be Draft", "Draft", listRuleVersionsTableObjects.get(1).status);
        assertEquals("Expect Rule Version to be 1", 1, listRuleVersionsTableObjects.get(1).version);

        //TODO IGNORE for now until Bug: CR-1365 is Fixed. When rule is saved, the rule name is capitalized in Rule Version Table
        //assertEquals("Expect Rule Name to be " + ruleDetails.description, ruleDetails.description, listRuleVersionsTableObjects.get(0).name);
    }


    @Category(ChangeRequest.CR_1879.class)
    @Test
    public void WhenRuleManagerLoggedIn_CanCreatePendingRuleVersionFromCommittedRuleVersion() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);
        ruleDetails.description = committedRuleResponse.description;
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        //Act
        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        boolean bPending = ruleSummary_page.isElementDisplayed(ruleSummary_page.newPending, 1, false);
        boolean bAmend = ruleSummary_page.isElementDisplayed(ruleSummary_page.amend, 1, false);

        //Assert
        assertEquals("Expect New Pending button not to be present", false, bPending);
        assertEquals("Expect Amend button to be present", true, bAmend);
    }


    @Category(ChangeRequest.CR_1879.class)
    @Test
    public void AttemptToCreatePendingRuleOrAmendRuleFromCommittedRule_PendingRuleAndAmendButtonArePresent() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);
        ruleDetails.description = committedRuleResponse.description;
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        //Act
        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        boolean bPending = ruleSummary_page.isElementDisplayed(ruleSummary_page.newPending, 1, false);
        boolean bAmend = ruleSummary_page.isElementDisplayed(ruleSummary_page.amend, 1, false);

        //Assert
        assertEquals("Expect New Pending button not to be present", false, bPending);
        assertEquals("Expect Amend button to be present", true, bAmend);
    }


    @Category(ChangeRequest.CR_1879.class)
    @Test
    public void AttemptToCreatePendingRuleOrAmendRuleFromActiveRule_PendingRuleAndAmendButtonArePresent() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();

        publishAndWait();

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);
        ruleDetails.description = committedRuleResponse.description;
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        //Act
        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        boolean bPending = ruleSummary_page.isElementDisplayed(ruleSummary_page.newPending, 1, false);
        boolean bAmend = ruleSummary_page.isElementDisplayed(ruleSummary_page.amend, 1, false);

        //Assert
        assertEquals("Expect New Pending button not to be present", false, bPending);
        assertEquals("Expect Amend button to be present", true, bAmend);
    }


    @Category(ChangeRequest.CR_1879.class)
    @Test
    public void AttemptToCreateNewPendingRuleWithoutStartDate_SaveCommitButtonsDisabled() {
        //Arrange
        CreateDraftRuleAndNavigateToRuleSummary();

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);
        ruleSummary_page.amend.click();

        //Act
        CreateNationalRule_Page createNationalRule_page = new CreateNationalRule_Page(driver);
        createNationalRule_page.holdNarrative.sendKeys("Updated Hold Narrative");

        boolean bSave = createNationalRule_page.save.isEnabled();
        boolean bSaveCommit = createNationalRule_page.saveAndCommit.isEnabled();

        //Assert
        assertEquals("Expect Save Draft button to be enabled", true, bSave);
        assertEquals("Expect Save & Commit button to be enabled", true, bSaveCommit);
    }


    @Category(ChangeRequest.CR_1879.class)
    @Test
    public void AttemptToCreatePendingRuleFromActiveRule_SaveButtonIsDisabled() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();

        publishAndWait();

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);
        ruleDetails.description = committedRuleResponse.description;
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        //Act
        UI.DataForTests.TestRuleModel.RuleDetails ruleDetailsV2 = UI.DataForTests.Rules.DraftNATRuleVersion2();
        ruleDetailsV2.startRuleImmediately = false;
        ruleDetailsV2.startDate = DateTime.AdjustLocalDateTimeNowByXDays(1);
        ruleDetailsV2.startTime = DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.systemDefault(), 5, "HH:mm");

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);
        ruleSummary_page.amend.click();
        ruleSummary_page.waitForAngularRequestsToFinish();

        CreateNationalRule_Page createNationalRule_page = new CreateNationalRule_Page(driver);
        createNationalRule_page.selectIncludeStartDateTime();
        createNationalRule_page.startDateTime.clear();
        createNationalRule_page.startDateTime.sendKeys(ruleDetailsV2.startDate + ", " + ruleDetailsV2.startTime);

        boolean bSaveCommit = createNationalRule_page.saveAndCommit.isEnabled();
        boolean bSave = createNationalRule_page.isElementDisplayed(createNationalRule_page.save);

        //Assert
        assertEquals("Expect Save button to be Not displayed", false, bSave);
        assertEquals("Expect Save & Commit button to be enabled", true, bSaveCommit);
    }


    @Category(ChangeRequest.CR_1879.class)
    @Test
    public void AttemptToCreatePendingRuleOrAmendRuleFromSuspendedRule_PendingRuleButtonIsNotPresent() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse ruleResponse = CreateSuspendedRule(ruleDetails);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);
        ruleDetails.description = ruleResponse.description;
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);
        listRules_page.waitForAngularRequestsToFinish();

        //Act
        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        boolean bPending = ruleSummary_page.isElementDisplayed(ruleSummary_page.newPending, 1, false);
        boolean bAmend = ruleSummary_page.isElementDisplayed(ruleSummary_page.amend, 1, false);

        //Assert
        assertEquals("Expect New Pending button to be Not present", false, bPending);
        assertEquals("Expect Amend button to be Not present", true, bAmend);
    }


    @Category(ChangeRequest.CR_1879.class)
    @Test
    public void WhenNewPendingRuleVersionDatesOverlap_CorrectDatesDisplayed() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsV1 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsV1.startDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(0, DateTime.DateTimeUTCZ);
        ruleDetailsV1.endDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(10, DateTime.DateTimeUTCZ);
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetailsV1);

        publishAndWait();

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetailsV2 = UI.DataForTests.Rules.DraftNATRuleVersion2();
        ruleDetailsV2.startRuleImmediately = false;
        ruleDetailsV2.startDate = DateTime.AdjustLocalDateTimeNowByXDays(0);
        ruleDetailsV2.startTime = DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.systemDefault(), 2, "HH:mm");

        ruleDetailsV2.endDate = DateTime.AdjustLocalDateTimeNowByXDays(0);
        ruleDetailsV2.endTime = DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.systemDefault(), 8, "HH:mm");

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        ruleDetailsV2.description = commitResponse.description;
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetailsV2.description);

        //Act
        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);
        ruleSummary_page.amend.click();

        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalRuleSingleCondition(ruleDetailsV2);

        CreateNationalRule_Page createNationalRule_page = new CreateNationalRule_Page(driver);
        createNationalRule_page.clickSaveAndCommitWithDefaultReason();


        //Act
        List<RuleSummary_Page.RuleSummaryTableObject> listOfRuleSummary = ruleSummary_page.getListOfRuleSummaryDetails();
        listOfRuleSummary.get(0).versionDetailAction.click();

        RuleDetails_Page ruleDetails_page = new RuleDetails_Page(driver);
        String startDateV1 = ruleDetails_page.startDateTime.getText();
        String endDateV1 = ruleDetails_page.endDateTime.getText();

        listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetailsV2.description);
        ruleSummary_page.ruleVersionsTab.click();

        List<RuleSummary_Page.RuleVersionsTableObject> listOfRuleVersionDetails = ruleSummary_page.getListOfRuleVersions();
        listOfRuleVersionDetails.get(0).ruleDetailAction.click();

        ruleDetails_page = new RuleDetails_Page(driver);
        String startDateV3 = ruleDetails_page.startDateTime.getText();
        String endDateV3 = ruleDetails_page.endDateTime.getText();

        driver.navigate().back();
        ruleSummary_page = new RuleSummary_Page(driver);
        ruleSummary_page.ruleVersionsTab.click();
        listOfRuleVersionDetails = ruleSummary_page.getListOfRuleVersions();
        listOfRuleVersionDetails.get(1).ruleDetailAction.click();
        ruleDetails_page = new RuleDetails_Page(driver);
        String startDateV2 = ruleDetails_page.startDateTime.getText();
        String endDateV2 = ruleDetails_page.endDateTime.getText();

        String expStartDateV1 = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm z")
                .withZone(ZoneId.of("Europe/London"))
                .format(ruleDetailsV1.startDate());

        String expEndDateV1 = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm z")
                .withZone(ZoneId.of("Europe/London"))
                .format(ruleDetailsV1.endDate());

        //assert
        assertEquals("Rule V1 Start Time should not have changed", expStartDateV1, startDateV1);
        assertEquals("Rule V1 End Time should not have changed", expEndDateV1, endDateV1);
        //assertEquals("Rule V3 End Time = Rule V2 Start Time", endDateV3, startDateV2); //Issue when doing remote test, Should be invetigated
        //assertEquals("Rule V2 Start Time = Rule V1 End Time", startDateV2, endDateV3);/Issue when doing remote test, Should be invetigated

        ruleDetailsV2.endDate = DateTime.AdjustLocalDateTimeNowByXDays(0, "dd/MM/yyyy");
        Assertions.assertThat(endDateV2)
                .contains(ruleDetailsV2.endDate);
    }
}
