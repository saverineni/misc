package TestCases.RiskingServiceJava.RATS;

import Categories_CDSRisk.ChangeRequest_RiskingService.CREP_142;
import Categories_CDSRisk.Risking_JavaService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel.MetadataDefinition;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel.RuleDefinition;
import uk.gov.hmrc.risk.rulesengine.rules.RuleMetadata;
import uk.gov.hmrc.risk.test.common.enums.DeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.HeaderAttribute;
import uk.gov.hmrc.risk.test.common.enums.HeaderDeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.MatcherType;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleCreationModel;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static org.junit.Assert.assertTrue;
import static uk.gov.hmrc.risk.test.common.enums.Matcher.equalTo;
import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.*;

@Slf4j
@Category({CREP_142.class, Risking_JavaService.class})
@Ignore("Percentage RATs in not handled by UI and the tests are randomly failing. Investigation in CREP-665")
public class TestCase_VerifyRatsPercentageDailyHitLimit extends BaseRatsTests {

    String description = "ta_RATS_Rule";

    @Test
    public void WhenVariableRatsLimitIsSetTo100PercentagePerDay_RulesAreAlwaysHit() {

        int ratsLimit = 100;
        int decCount =  5;

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();
        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNOR_EORI, "AE123456789ABCDE");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_TYPE, "IM");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "C");

        String model = createRuleDefinitionModel("AE123456789ABCDE", ratsLimit).toString();

        RuleCreationModel rule = baseRuleCreationModelBuilder()
                .description(description)
                .definition(model)
                .build();

        int routesFired = createRuleAndSendDeclarations(rule, declarationFieldValues, decCount);
        assertTrue(routesFired==decCount);

    }

    //consigness eori - new way of creating rules using the check method - "check(consigneeEori(),equalTo("NL000111222"))"
    @Test
    public void WhenVariableRatsLimitIsSetTo50PercentagePerDay_AtLeastOneRuleIsFired() {

        int ratsLimit = 50;
        int decCount = 10;

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();
        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNOR_EORI, "NL000111222");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_TYPE, "IM");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "C");

        String model = createRuleDefinitionModel("NL000111222", ratsLimit).toString();

        RuleCreationModel rule = baseRuleCreationModelBuilder()
                .description(description)
                .definition(model)
                .build();

        int routesFired = createRuleAndSendDeclarations(rule, declarationFieldValues, decCount );
        assertTrue("The routes fired is not greater than one for 50% rats hit limit ", routesFired>=1 && routesFired<9);
    }

    @Test
    public void WhenVariableRatsLimitIsSetToZeroPercentagePerDay_RulesAreNeverHit() {

        int ratsLimit = 0;
        int decCount = 10;

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();
        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNOR_EORI, "NL000111222");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_TYPE, "IM");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "C");

        String model = createRuleDefinitionModel("NL000111222", ratsLimit).toString();

        RuleCreationModel rule = baseRuleCreationModelBuilder()
                .description(description)
                .definition(model)
                .build();

        int routesFired = createRuleAndSendDeclarations(rule, declarationFieldValues, decCount );

      //assert
        assertTrue(routesFired==0);
    }

    private RuleDefinitionModel createRuleDefinitionModel(String EORI, int ratsLimit) {
        RuleDefinitionModel model = defaultModel();
        model.getRuleDefinitions().clear();
        RuleDefinition ruleDefinition = RuleDefinition.builder().build();
        ruleDefinition.addMetadata(new MetadataDefinition(RuleMetadata.UNIQUE_ID, Optional.of("#UniqueId#")));
        ruleDefinition.addMetadata(new MetadataDefinition(RuleMetadata.RAT_PERCENTAGE_DAILY, Optional.of(ratsLimit)));
        ruleDefinition.setName(description);

        Condition consigneeEori = Condition.builder()
                .attribute(HeaderAttribute.CONSIGNOR_EORI)
                .matcherType(MatcherType.EQUAL)
                .matcherClass(MatcherClass.Matchers)
                .matcher(equalTo)
                .value(EORI)
                .source(Source.declaration)
                .build();

        String declaration = strCheck( consigneeEori );
        ruleDefinition.setWhenDef( declarationWrapper(declaration) );
        ruleDefinition.setThenDef(thenCreator(Source.declaration, conditions( consigneeEori )));
        model.getRuleDefinitions().add(ruleDefinition);
        return model;
    }
}
