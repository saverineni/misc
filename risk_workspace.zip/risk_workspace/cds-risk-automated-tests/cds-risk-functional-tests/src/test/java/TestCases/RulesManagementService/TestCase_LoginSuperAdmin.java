package TestCases.RulesManagementService;


import API.DataForTests.TestEnumerators;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.EnvDetails.EnvDetails;
import API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse;
import Categories_CDSRisk.CDS_RM_Login;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static API.DataForTests.TestEnumerators.MetaDataActions.*;
import static API.RulesManagementService.Utils.Users.GetUserDetails;
import static API.RulesManagementService.Utils.Users.UpdateStatusOfUser;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_Login.class})
public class TestCase_LoginSuperAdmin extends BaseWebAPITestCase{

    private TestUserModel.UserDetails userDetails2;

    @Before
    public void Setup(){

        TestUserModel.UserDetails userDetails = Users_API.DefaultSuperAdminUser();
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        userDetails2 = Users_API.SuperAdminNational("1234540");
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);

    }



    //----------------------------------------------
    //National Super Admin
    //----------------------------------------------

    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenNationalSuperAdminLoggedIn_NoMetaDataActionsAvailableForLoggedInUser() {

        //Arrange

        //Act
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(EnvDetails.sCurrentLoggedInUserPID);

        //Assert
        assertEquals("Http status code: ", HttpStatus.SC_OK, userDetailsResponse.httpStatusCode);

        //user can not perform actions on themselves
        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(0);
    }

    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenNationalSuperAdminLogged_CorrectMetaDataActionsShownForDifferentNationalSuperAdmin() {

        //Arrange

        //Act
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(3)
                .contains(USER_ARCHIVE.toString(),
                        USER_SUSPEND.toString(),
                        USER_EDIT.toString());
    }

    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenNationalSuperAdminLogged_CorrectMetaDataActionsShownForLocalSuperAdmin() {

        //Arrange

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(3)
                .contains(USER_ARCHIVE.toString(),
                        USER_SUSPEND.toString(),
                        USER_EDIT.toString());
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenNationalSuperAdminLogged_CorrectMetaDataActionsShownForNationalAdmin() {

        //Arrange

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(3)
                .contains(USER_ARCHIVE.toString(),
                        USER_SUSPEND.toString(),
                        USER_EDIT.toString());
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenNationalSuperAdminLogged_CorrectMetaDataActionsShownForLocalAdmin() {

        //Arrange

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(3)
                .contains(USER_ARCHIVE.toString(),
                        USER_SUSPEND.toString(),
                        USER_EDIT.toString());
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenNationalSuperAdminLoggedIn_NoMetaDataActionsAvailableForRuleManager() {

        //Arrange

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(0);
    }

    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenNationalSuperAdminLoggedIn_NoMetaDataActionsAvailableForRuleViewer() {

        //Arrange

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(0);
    }


    //----------------------------------------------
    //Local Super Admin
    //----------------------------------------------

    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenLocalSuperAdminLoggedIn_NoMetaDataActionsAvailableForNationalSuperAdmin() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.SuperAdminNational("1234520");
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(0);
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenLocalSuperAdminLoggedIn_CorrectMetaDataActionsAvailableForLocalSuperAdmin() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.SuperAdminLocal_POO("1234562");
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(3)
                .contains(USER_ARCHIVE.toString(),
                        USER_SUSPEND.toString(),
                        USER_EDIT.toString());
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenLocalSuperAdminLoggedIn_NoMetaDataActionsAvailableForNationalAdmin() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(0);
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenLocalSuperAdminLoggedIn_CorrectMetaDataActionsAvailableForLocalAdmin() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.AdminLocal_POO("1234562");
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(3)
                .contains(USER_ARCHIVE.toString(),
                        USER_SUSPEND.toString(),
                        USER_EDIT.toString());
    }



    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenUserArchivesUser_UserArchivedSuccessfullyNoFurtherActionsAvailable() {

        //Arrange

        //Act
        Response userResponse = UpdateStatusOfUser(userDetails2.pid, TestEnumerators.MetaDataActions.USER_ARCHIVE.apiAction);

        //Assert
        assertEquals(HttpStatus.SC_NO_CONTENT, userResponse.statusCode());

        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = GetUserDetails(userDetails2.pid);

        Assertions.assertThat(userDetailsResponse.status).isEqualTo(TestEnumerators.MetaDataActions.USER_ARCHIVE.apiResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(0);
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenUserSuspendsUser_UserSuspendedSuccessfullyAndReinstateActionAvailable() {

        //Arrange

        //Act
        Response userResponse = UpdateStatusOfUser(userDetails2.pid, USER_SUSPEND.apiAction);

        //Assert
        assertEquals(HttpStatus.SC_NO_CONTENT, userResponse.statusCode());

        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = GetUserDetails(userDetails2.pid);

        Assertions.assertThat(userDetailsResponse.status).isEqualTo(USER_SUSPEND.apiResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(1)
                .contains(USER_REINSTATE.apiMetaResponse);
    }

    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenUserReinstatesUser_UserReinstatedSuccessfullyAndActionsAvailable() {

        //Arrange

        //Act
        UpdateStatusOfUser(userDetails2.pid, USER_SUSPEND.apiAction);
        Response userResponse = UpdateStatusOfUser(userDetails2.pid, USER_REINSTATE.apiAction);


        //Assert
        assertEquals(HttpStatus.SC_NO_CONTENT, userResponse.statusCode());

        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = GetUserDetails(userDetails2.pid);

        Assertions.assertThat(userDetailsResponse.status).isEqualTo(USER_REINSTATE.apiResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(3)
                .contains(USER_ARCHIVE.toString(),
                        USER_SUSPEND.toString());
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void AttemptToArchiveArchivedUser_BadRequestResponseReceived() {

        //Arrange
        UpdateStatusOfUser(userDetails2.pid, TestEnumerators.MetaDataActions.USER_ARCHIVE.apiAction);

        //Act
        Response userResponse = UpdateStatusOfUser(userDetails2.pid, TestEnumerators.MetaDataActions.USER_ARCHIVE.apiAction);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, userResponse.statusCode());
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void AttemptToSuspendSuspendedUser_BadRequestResponseReceived() {

        //Arrange
        UpdateStatusOfUser(userDetails2.pid, TestEnumerators.MetaDataActions.USER_SUSPEND.apiAction);

        //Act
        Response userResponse = UpdateStatusOfUser(userDetails2.pid, TestEnumerators.MetaDataActions.USER_SUSPEND.apiAction);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, userResponse.statusCode());
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void AttemptToReinstateReinstatedUser_BadRequestResponseReceived() {

        //Arrange
        UpdateStatusOfUser(userDetails2.pid, TestEnumerators.MetaDataActions.USER_REINSTATE.apiAction);

        //Act
        Response userResponse = UpdateStatusOfUser(userDetails2.pid, TestEnumerators.MetaDataActions.USER_REINSTATE.apiAction);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, userResponse.statusCode());
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void AttemptToReinstateArchivedUser_BadRequestResponseReceived() {

        //Arrange
        UpdateStatusOfUser(userDetails2.pid, TestEnumerators.MetaDataActions.USER_ARCHIVE.apiAction);

        //Act
        Response userResponse = UpdateStatusOfUser(userDetails2.pid, TestEnumerators.MetaDataActions.USER_REINSTATE.apiAction);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, userResponse.statusCode());
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void AttemptToArchiveRuleManager_ForbiddenResponseReceived() {

        //Arrange
        userDetails2 = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);

        //Act
        Response userResponse = UpdateStatusOfUser(userDetails2.pid, TestEnumerators.MetaDataActions.USER_ARCHIVE.apiAction);

        //Assert
        assertEquals(HttpStatus.SC_FORBIDDEN, userResponse.statusCode());
    }

    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void AttemptToArchiveRuleViewer_ForbiddenResponseReceived() {

        //Arrange
        userDetails2 = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);

        //Act
        Response userResponse = UpdateStatusOfUser(userDetails2.pid, TestEnumerators.MetaDataActions.USER_ARCHIVE.apiAction);

        //Assert
        assertEquals(HttpStatus.SC_FORBIDDEN, userResponse.statusCode());
    }
}
