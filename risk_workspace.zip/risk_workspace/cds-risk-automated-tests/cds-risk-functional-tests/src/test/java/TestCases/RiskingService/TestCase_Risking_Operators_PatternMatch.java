package TestCases.RiskingService;

import API.DataForTests.Conditions;
import API.DataForTests.Rules;
import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestRuleModel.RuleDetails;
import API.DataForTests.TestRuleModel.RuleDetails.Condition;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service_Operators;
import TestCases.BaseWebAPITestCase;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

@Slf4j
@Category(Risking_Service_Operators.class)
public class TestCase_Risking_Operators_PatternMatch extends BaseWebAPITestCase {

    @Before
    public void setup() throws IOException, TimeoutException {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
    }

    @Test
    @Category({ChangeRequest.CR_1213.class})
    public void WhenDeclarationSubmittedForRuleWithFirstCharMatchingOnContains_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.consigneeEori();

        condition.operator = "con";
        condition.value = "0";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeEori = "01113";  //"0101210000";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());


        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_1213.class})
    public void WhenDeclarationSubmittedForRuleWithOneCharMatchingOnContains_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition  condition = Conditions.consigneeEori();

        condition.operator = "con";
        condition.value = "2";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeEori = "0101210000";  //"0101210000";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_1213.class})
    public void WhenDeclarationSubmittedForRuleWithMultipleCharsMatchingOnContains_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition  condition = Conditions.goodsDescription();

        condition.operator = "con";
        condition.value = "Goods";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsDescription = "gOOds";  //"0101210000";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_1213.class})
    public void WhenDeclarationSubmittedForRuleWithNoCharsMatchingOnContains_RouteNotReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition  condition = Conditions.taxAmount();

        condition.operator = "con";
        condition.value = "999";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.taxAmount = "99912345";  //"0101210000";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isNotEqualTo(ruleDetails.ruleOutputs.actionType);
    }


    @Test
    @Category({ChangeRequest.CR_1213.class})
    public void WhenDeclarationSubmittedForRuleWithNoCharsMatchingOnDoesNotContain_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition  condition = Conditions.consigneeAddress();

        condition.operator = "nco";
        condition.value = "119";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeAddress = "55666";  //"0101210000";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_1213.class})
    public void WhenDeclarationSubmittedForRuleWithOneCharMatchingOnDoesNotContain_RouteNotReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition  condition = Conditions.commodityCode();

        condition.operator = "nco";
        condition.value = "1";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.commodity = Conditions.commodityCode().value;  //"0101210000";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isNotEqualTo(ruleDetails.ruleOutputs.actionType);
    }


    @Test
    @Category({ChangeRequest.CR_1213.class})
    public void WhenDeclarationSubmittedForRuleWithMultipleCharsMatchingOnDoesNotContain_RouteNotReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition  condition = Conditions.commodityCode();

        condition.operator = "nco";
        condition.value = "01210";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.commodity = Conditions.commodityCode().value;  //"0101210000";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isNotEqualTo(ruleDetails.ruleOutputs.actionType);
    }


    //-------------

    @Test
    @Category({ChangeRequest.CR_1481.class})
    public void WhenDeclarationSubmittedForRuleWithFirstCharMatchingOnStartsWith_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();

        condition.operator = "st";
        condition.value = "0";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.commodity = Conditions.commodityCode().value;  //"0101210000";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_1481.class})
    public void WhenDeclarationSubmittedForRuleWithMultipleCharsMatchingOnStartsWith_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();

        condition.operator = "st";
        condition.value = "01012";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.commodity = Conditions.commodityCode().value;  //"0101210000";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_1481.class})
    public void WhenDeclarationSubmittedForRuleWithFirstCharNotMatchingOnStartsWith_RouteNotReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();

        condition.operator = "st";
        condition.value = "910";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.commodity = Conditions.commodityCode().value;  //"0101210000";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isNotEqualTo(ruleDetails.ruleOutputs.actionType);
    }


    @Test
    @Category({ChangeRequest.CR_1481.class})
    public void WhenDeclarationSubmittedForRuleWithCharsMatchingButNotAtStartOnStartsWith_RouteNotReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();

        condition.operator = "st";
        condition.value = "121";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.commodity = Conditions.commodityCode().value;  //"0101210000";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isNotEqualTo(ruleDetails.ruleOutputs.actionType);
    }


    @Test
    @Category({ChangeRequest.CR_1481.class})
    public void WhenDeclarationSubmittedForRuleWithFirstCharMatchingOnNotStartsWith_RouteNotReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();

        condition.operator = "nst";
        condition.value = "0";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.commodity = Conditions.commodityCode().value;  //"0101210000";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isNotEqualTo(ruleDetails.ruleOutputs.actionType);
    }


    @Test
    @Category({ChangeRequest.CR_1481.class})
    public void WhenDeclarationSubmittedForRuleWithMultipleStartingCharMatchingOnNotStartsWith_RouteNotReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();

        condition.operator = "nst";
        condition.value = "0101";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.commodity = Conditions.commodityCode().value;  //"0101210000";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isNotEqualTo(ruleDetails.ruleOutputs.actionType);
    }


    @Test
    @Category({ChangeRequest.CR_1481.class})
    public void WhenDeclarationSubmittedForRuleWithFirstCharNotMatchingOnNotStartsWith_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();

        condition.operator = "nst";
        condition.value = "9";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.commodity = Conditions.commodityCode().value;  //"0101210000";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_1605.class})
    public void WhenDeclarationSubmittedForRuleWithSingleCharMatchingOnMatchingPattern_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.consigneeName();

        condition.operator = "matchesPattern";
        condition.value = "R?binsons";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeName = "Robinsons";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());


        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_1605.class})
    public void WhenDeclarationSubmittedForRuleWithSingleCharMatchingOnNotMatchingPattern_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.consigneeName();

        condition.operator = "notMatchesPattern";
        condition.value = "R?binsons";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeName = "Ro binsons";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_1605.class})
    public void WhenDeclarationSubmittedForRuleWithExclamationCharMatchingOnMatchingPattern_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.consigneeName();

        condition.operator = "matchesPattern";
        condition.value = "Robinson!Crusoes";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeName = "Robinson&amp;Crusoes";  //note & is an escape character in xml need to use &amp;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3242.class})
    public void WhenDeclarationSubmittedForRuleWithExclamationConsigneeAddressCharMatchingOnMatchingPattern_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.consigneeAddress();

        condition.operator = "matchesPattern";
        condition.value = "king!s lynn";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeAddress = "king's lynn";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3242.class})
    public void WhenDeclarationSubmittedForRuleWithExclamationConsigneeAddressCharMatchingOnNotMatchingPattern_NoRouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.consigneeAddress();

        condition.operator = "notMatchesPattern";
        condition.value = "king!s lynn";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeAddress = "king s lynn";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isNotEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_1605.class})
    public void WhenDeclarationSubmittedForRuleWithExclamationCharMatchingOnNotMatchingPattern_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.consigneeName();

        condition.operator = "notMatchesPattern";
        condition.value = "Robinson!Crusoes";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeName = "Robinson and Crusoes";  //note & is an escape character in xml need to use &amp;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_1605.class})
    public void WhenDeclarationSubmittedForRuleWithStarCharMatchingOnMatchingPattern_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.consigneeName();

        condition.operator = "matchesPattern";
        condition.value = "Rob*Cru*";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeName = "Robinson &amp; Crusoes";  //note & is an escape character in xml need to use &amp;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_1605.class})
    public void WhenDeclarationSubmittedForRuleWithStarCharMatchingOnNotMatchingPattern_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.consigneeName();

        condition.operator = "notMatchesPattern";
        condition.value = "mi*iles";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeName = "miles";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3243.class})
    public void WhenDeclarationSubmittedForRuleWithStarCharOnNotMatchingPattern_NoRouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.exporterCountry_Header("M??chester");

        condition.operator = "notMatchesPattern";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.exporterCountry_Header = "Manchester";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isNotEqualTo(ruleDetails.ruleOutputs.actionType);
    }

    @Test
    @Category({ChangeRequest.CR_3243.class})
    public void WhenDeclarationSubmittedForRuleWithStarCharMatchingPattern_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.exporterCountry_Header("G*");

        condition.operator = "matchesPattern";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.exporterCountry_Header = "GB";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3243.class})
    public void WhenDeclarationSubmittedForRuleWithContainsOperator_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.exporterCity_Header("man");

        condition.operator = "con";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.exporterCity_Header = "MaNchEstEr";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3243.class})
    public void WhenDeclarationSubmittedForRuleWithNotContainsOperator_NoRouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.exporterCity_Header("lon");

        condition.operator = "nco";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.exporterCity_Header = "lOnDON";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isNotEqualTo(ruleDetails.ruleOutputs.actionType);
    }

    @Test
    @Category({ChangeRequest.CR_3243.class})
    public void WhenDeclarationSubmittedForRuleWithStartsOperator_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.exporterId_Header("GB");

        condition.operator = "st";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.exporterId_Header = "gb98769404";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());
        log.debug(declarationResponse.getRiskAssessmentResults_Expression());
        //Assert
        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3243.class})
    public void WhenDeclarationSubmittedForRuleWithNotStartsOperator_NoRouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.exporterId_Header("GB");

        condition.operator = "nst";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.exporterId_Header = "gb98769404";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isNotEqualTo(ruleDetails.ruleOutputs.actionType);
    }

    @Test
    @Category({ChangeRequest.CR_3243.class})
    public void WhenDeclarationSubmittedForRuleWithContainsOperatorUsingExporterPostcodeHeader_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.exporterPostcode_Header("2aY");

        condition.operator = "con";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.exporterZipCode_Header = "M1 2AY";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3243.class})
    public void WhenDeclarationSubmittedForRuleWithNotContainsOperatorUsingExporterPostcodeHeader_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.exporterPostcode_Header("2AY");

        condition.operator = "nco";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.exporterZipCode_Header = "M1 4rt";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3243.class})
    public void WhenDeclarationSubmittedForRuleWithStarCharOnNotMatchingPatternUsingExporterNameHeader_NoRouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.exporterName_Header("T??TAgency");

        condition.operator = "notMatchesPattern";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.exporterName_Header = "TesTAgency";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isNotEqualTo(ruleDetails.ruleOutputs.actionType);
    }


    @Test
    @Category({ChangeRequest.CR_3243.class})
    public void WhenDeclarationSubmittedForRuleWithContainsOperatorUsingImporterAddressHeader_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.importerAddress_Header("northern");

        condition.operator = "con";
        ruleDetails.queryOptions.declarationType = "IM";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Actd
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.declarationType = "IM";
        declaration.importerAddress_Header = "Great northern Street";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());
        log.debug(declarationResponse.getRiskAssessmentResults_Expression());
        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3243.class})
    public void WhenDeclarationSubmittedForRuleWithNotContainsOperatorUsingImporterAddressHeader_NoRouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.importerAddress_Header("Singleton");

        condition.operator = "nco";
        ruleDetails.queryOptions.declarationType = "IM";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.declarationType = "IM";
        declaration.importerAddress_Header = "Great SiNGLleTOn Street";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isNotEqualTo(ruleDetails.ruleOutputs.actionType);
    }

    @Test
    @Category({ChangeRequest.CR_3243.class})
    public void WhenDeclarationSubmittedForRuleWithNotStartsOperatorUsingImporterCityHeader_NoRouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.importerCity_Header("man");

        condition.operator = "nst";
        ruleDetails.queryOptions.declarationType = "IM";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.declarationType = "IM";
        declaration.importerCity_Header = "manchester";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert

        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isNotEqualTo(ruleDetails.ruleOutputs.actionType);
    }

    @Test
    @Category({ChangeRequest.CR_3243.class})
    public void WhenDeclarationSubmittedForRuleWithStartsOperatorUsingImporterNameHeader_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.importerName_Header("T??T Agency");

        condition.operator = "notMatchesPattern";
        ruleDetails.queryOptions.declarationType = "IM";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.declarationType = "IM";
        declaration.importerName_Header = "hydera";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
    }
}
