package TestCases.UI.Rules;

import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.RuleAction.RuleActionResponse;
import Categories_CDSRisk.*;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static API.RulesManagementService.Utils.Publish.setPublishAutomaticEventTime;
import static API.RulesManagementService.Utils.RuleAtStatus.CreateSuspendedRule;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_1.class})
public class TestCase_ArchiveRule extends BaseUIWebDriverTestCase{

    @Test
    @Category({SmokeTests_UI_2.class, ChangeRequest.CR_1576.class})
    public void WhenNationalRuleManagerLoggedIn_CanArchiveCommittedRule()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse  committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();
        ruleDetails.description = committedRuleResponse.description;

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        boolean bArchiveEnabled = ruleSummary_page.archiveRule.isEnabled();
        assertEquals("Expect archived button to be enabled", true, bArchiveEnabled);

        Dialog_Confirm dialog_confirm = ruleSummary_page.clickArchiveButton();  //takes you to list rules page at the moment.
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");
        dialog_confirm.waitForAngularRequestsToFinish();
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        ruleSummary_page.waitForAngularRequestsToFinish();
        publishAndWait(5000);
        ruleSummary_page.refreshPage();

        //Assert
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetailsForLocalRuleViewer();

        assertEquals(ruleDetails.description, listRuleSummaryTableObjects.get(0).description);
        assertEquals("Expect Rule Version to be 1", ruleDetails.version, listRuleSummaryTableObjects.get(0).version);
        assertEquals("Expect Rule Status to be Archived", "Archived", listRuleSummaryTableObjects.get(0).status);
        assertEquals("View\n" +"Rule Revision 1", listRuleSummaryTableObjects.get(0).versionDetailAction.getText());

        //TO DO Check locations
        //need to store location name for checks in UI
        assertEquals("ABZ - Aberdeen Airport", ruleSummary_page.locations.getText().trim());
    }


    @Test
    public void WhenLocalRuleManagerLoggedIn_CanArchiveCommittedRule()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        ruleDetails.description = committedRuleResponse.description;

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        Dialog_Confirm dialog_confirm = ruleSummary_page.clickArchiveButton();  //takes you to list rules page at the moment.
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        ruleSummary_page.waitForAngularRequestsToFinish();
        publishAndWait(5000);
        ruleSummary_page.refreshPage();

        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);



        //Assert
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetailsForLocalRuleViewer();
        String sRuleStatus = listRuleSummaryTableObjects.get(0).status;

        assertEquals("Expect Rule Status to be Archived", "Archived", sRuleStatus);
    }


    @Test
    public void WhenNationalRuleViewerLoggedIn_CanNOTArchiveCommittedRule()
    {
        //Arrange
        TestUserModel.UserDetails userDetails_RM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RM);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_RM.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();
        ruleDetails.description = committedRuleResponse.description;

        TestUserModel.UserDetails UserDetails_RV = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Assert
        boolean bArchivePresent= ruleSummary_page.isActionButtonPresent("Archive Rule");
        assertEquals("Expect Archive button to be not present", false, bArchivePresent);
    }


    @Test
    public void WhenLocalRuleViewerLoggedIn_CanNOTCArchiveCommittedRule()
    {
        //Arrange
        TestUserModel.UserDetails userDetails_RM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RM);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_RM.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        ruleDetails.description = committedRuleResponse.description;

        TestUserModel.UserDetails UserDetails_RV = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Assert
        boolean bArchivePresent= ruleSummary_page.isActionButtonPresent("Archive Rule");
        assertEquals("Expect Archive button to be not present", false, bArchivePresent);
    }


    @Test
    public void WhenNationalRuleManagerLoggedIn_CanArchiveSuspendedRule()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse committedRuleResponse = CreateSuspendedRule(ruleDetails);
        ruleDetails.description = committedRuleResponse.description;

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);
        listRules_page.waitForAngularRequestsToFinish();

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        boolean bArchiveEnabled = ruleSummary_page.archiveRule.isEnabled();
        assertEquals("Expect archived button to be enabled", true, bArchiveEnabled);

        Dialog_Confirm dialog_confirm = ruleSummary_page.clickArchiveButton();  //takes you to list rules page at the moment.
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");
        ruleSummary_page.waitForAngularRequestsToFinish();

        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);
        ruleSummary_page.waitForAngularRequestsToFinish();
        publishAndWait(5000);
        ruleSummary_page.refreshPage();

        //Assert
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetailsForLocalRuleViewer();

        assertEquals(ruleDetails.description, listRuleSummaryTableObjects.get(0).description);
        assertEquals("Expect Rule Version to be 1", ruleDetails.version, listRuleSummaryTableObjects.get(0).version);
        assertEquals("Expect Rule Status to be Archived", "Archived", listRuleSummaryTableObjects.get(0).status);
        assertEquals("View\n" +
                "Rule Revision 1", listRuleSummaryTableObjects.get(0).versionDetailAction.getText());
    }


    @Test
    @Category(ChangeRequest.CR_1576.class)
    public void WhenRuleManagerArchivesRule_ConfirmationMessageAppears()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse  committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();
        ruleDetails.description = committedRuleResponse.description;

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Act
        Dialog_Confirm dialog_confirm = ruleSummary_page.clickArchiveButton();  //takes you to list rules page at the moment.
        String actText = dialog_confirm.getMessageText();

        //Assert
        assertEquals("Please enter a reason for archiving this rule", actText);
        assertTrue("Expect OK button to be present", dialog_confirm.ok.isDisplayed());
        assertTrue("Expect Cancel button to be present", dialog_confirm.cancel.isDisplayed());
    }


    @Test
    @Category(ChangeRequest.CR_1576.class)
    public void WhenRuleManagerCancelsArchiveRule_ConfirmationMessageClosed()
    {
        //Arrange
        TestUserModel.UserDetails superAdminUser = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(superAdminUser);

        String timeInSeconds = "500";
        setPublishAutomaticEventTime(timeInSeconds, superAdminUser.pid);

        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse  committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();
        ruleDetails.description = committedRuleResponse.description;

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);
        listRules_page.waitForAngularRequestsToFinish();

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Act
        Dialog_Confirm dialog_confirm = ruleSummary_page.clickArchiveButton();  //takes you to list rules page at the moment.
        ruleSummary_page.waitForAngularRequestsToFinish();

        dialog_confirm.clickCancelButton();
        ruleSummary_page.waitForAngularRequestsToFinish();


        //Assert
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();

        assertEquals("Expect Rule Status to be Committed", "Committed", listRuleSummaryTableObjects.get(0).status);
    }

}