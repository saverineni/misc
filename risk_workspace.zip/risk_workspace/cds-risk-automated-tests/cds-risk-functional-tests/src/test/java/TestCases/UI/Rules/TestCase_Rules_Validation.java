package TestCases.UI.Rules;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Rules;
import Categories_CDSRisk.CDS_Risk_UI_Rules_2;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.DataForTests.Conditions;
import UI.Pages.RulesManagement.CreateLocalRule_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static FunctionsLibrary.Utils.SleepForMilliSeconds;
import static UI.DataForTests.TestRuleModel.RuleDetails.Condition.AttributeType.HEADER;
import static UI.DataForTests.TestRuleModel.RuleDetails.Condition.AttributeType.HEADER_COLLECTION;
import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_2.class})
public class TestCase_Rules_Validation extends BaseUIWebDriverTestCase{

    @Category(ChangeRequest.CR_3115.class)
    @Test
    public void WhenAmendingExistingRule_validationShouldBeCorrect()
    {
        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();
        ruleDetails.conditionGroups.get(0).conditions.clear();

        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.destinationCountry_TypeHeader("Equal","FR"));
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = HEADER;

        ruleDetails.conditionGroups.get(0).conditions.add(    new UI.DataForTests.TestRuleModel.RuleDetails.Condition(
                UI.DataForTests.TestRuleModel.RuleDetails.Condition.Attribute.ADDITIONAL_INFO_CODE_HEADER_COLLECTION, "Not Equal", "4455"));
        ruleDetails.conditionGroups.get(0).conditions.get(1).attributeType = HEADER_COLLECTION;



        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleMultipleConditions(ruleDetails);
        createLocalRule_page.clickSaveAndCommitWithDefaultReason();
        SleepForMilliSeconds(500);
        RuleSummary_Page ruleSummary_page = createLocalRule_page.clickViewRule();
        ruleSummary_page.amend.click();
        SleepForMilliSeconds(500);
        createLocalRule_page.removeTheCondtion("destinationCountry_Header");

        //Assert
        assertEquals("",createLocalRule_page.getErrorMessage());

    }
}
