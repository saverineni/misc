package TestCases.UI.Rules;

import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.EditRule.EditRuleResponse;
import Categories_CDSRisk.*;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.Pages.RulesManagement.CreateLocalRule_Page;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleDetails_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static API.RulesManagementService.Utils.Publish.setPublishAutomaticEventTime;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_1.class})
public class TestCase_CommitRule extends BaseUIWebDriverTestCase{

    @Category(SmokeTests_UI_2.class)
    @Test
    public void WhenNationalRuleManagerLoggedIn_CanCommitDraftRule()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(createRuleResponse.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        boolean bCommitEnabled = ruleSummary_page.commitRule.isEnabled();
        assertEquals("Expect commit button to be enabled", true, bCommitEnabled);

        ruleSummary_page.commitAndConfirm();

        //Assert
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();

        assertEquals(ruleDetails.description, listRuleSummaryTableObjects.get(0).description);
        assertEquals("Expect Rule Version to be 1", ruleDetails.version, listRuleSummaryTableObjects.get(0).version);
        assertEquals("Expect Rule Status to be Committed", "Committed", listRuleSummaryTableObjects.get(0).status);
        assertEquals("View\n" + "Rule Revision 1", listRuleSummaryTableObjects.get(0).versionDetailAction.getText());

        //TO DO Check locations
        //need to store location name for checks in UI
        assertEquals("ABZ - Aberdeen Airport", ruleSummary_page.locations.getText().trim());
    }


    @Test
    public void WhenLocalRuleManagerLoggedIn_CanCommitDraftRule()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(createRuleResponse.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        ruleSummary_page.commitAndConfirm();

        //Assert
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        String sRuleStatus = listRuleSummaryTableObjects.get(0).status;

        assertEquals("Expect Rule Status to be Committed", "Committed", sRuleStatus);
    }


    @Test
    public void WhenNationalRuleViewerLoggedIn_CanNOTCommitDraftRule()
    {
        //Arrange
        TestUserModel.UserDetails userDetails_RM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RM);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_RM.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        TestUserModel.UserDetails UserDetails_RV = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(createRuleResponse.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Assert
        boolean bCommitEnabled = ruleSummary_page.isActionButtonPresent("Commit Rule");
        assertEquals("Expect commit button to be not present", false, bCommitEnabled);
    }


    @Test
    public void WhenLocalRuleViewerLoggedIn_CanNOTCommitDraftRule()
    {
        //Arrange
        TestUserModel.UserDetails userDetails_RM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RM);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_RM.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        TestUserModel.UserDetails UserDetails_RV = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(createRuleResponse.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Assert
        boolean bCommitEnabled = ruleSummary_page.isActionButtonPresent("Commit Rule");
        assertEquals("Expect commit button to be not present", false, bCommitEnabled);
    }


    @Test
    public void WhenDraftVersionOfRuleCommitted_NewVersionIsCommittedOldVersionIsDraft()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateDraftRuleVersion2Rule();
        ruleDetails.description = ruleResponse.description;

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        ruleSummary_page.commitAndConfirm();

        //Assert
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();

        assertEquals("Expect Rule Status to be Committed", "Committed", listRuleSummaryTableObjects.get(0).status);
        assertEquals("Expect Rule Version to be 2", 2, listRuleSummaryTableObjects.get(0).version);
        assertEquals("Expect Rule Name to be " + ruleDetails.description, ruleDetails.description, listRuleSummaryTableObjects.get(0).description);

        List<RuleSummary_Page.RuleVersionsTableObject> listRuleVersionsTableObjects = ruleSummary_page.getListOfRuleVersions();
        assertEquals("Expect Rule Version Status to be Draft", "Draft", listRuleVersionsTableObjects.get(1).status);
        assertEquals("Expect Rule Version to be 1", 1, listRuleVersionsTableObjects.get(1).version);

        //TODO IGNORE for now until Bug: CR-1365 is Fixed. When rule is saved, the rule name is capitalized in Rule Version Table
        //assertEquals("Expect Rule Name to be " + ruleDetails.description, ruleDetails.description, listRuleVersionsTableObjects.get(0).name);
    }


    @Ignore("Note: No actions are available via UI for Rule Versions at the moment. Only Lead Version")
    @Test
    public void WhenDraftVersionOfCommittedRuleCommitted_NewVersionIsCommittedOldVersionIsArchived()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateDraftRuleFromCommittedRule();
        ruleDetails.description = ruleResponse.description;

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        ruleSummary_page.commitAndConfirm();

        //Assert
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();

        assertEquals("Expect Rule Status to be Committed", "Committed", listRuleSummaryTableObjects.get(0).status);
        assertEquals("Expect Rule Version to be 2", 2, listRuleSummaryTableObjects.get(0).version);
        assertEquals("Expect Rule Name to be " + ruleDetails.description, ruleDetails.description, listRuleSummaryTableObjects.get(0).description);


        boolean ruleVersionTableDisplayed = ruleSummary_page.isElementDisplayed(ruleSummary_page.ruleVersionsTable,1,false);
        assertTrue("Expect rule Version Table to be NOT Displayed", ruleVersionTableDisplayed == false);
    }


    @Category(ChangeRequest.CR_1510.class)
    @Test
    public void WhenRuleManagerCommitsRule_ConfirmationMessageAppears()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page =  utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(createRuleResponse.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Act
        ruleSummary_page.clickCommitButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        String actText = dialog_confirm.getMessageText();

        //Assert
        assertEquals("Please enter a reason for committing this rule", actText);
        assertTrue("Expect OK button to be present", dialog_confirm.ok.isDisplayed());
        assertTrue("Expect Cancel button to be present", dialog_confirm.cancel.isDisplayed());
    }

    @Category(ChangeRequest.CR_1510.class)
    @Test
    public void WhenRuleManagerCancelsCommitsRule_ConfirmationMessageClosed()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page =  utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(createRuleResponse.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Act
        ruleSummary_page.clickCommitButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.clickCancelButton();

        //Assert
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();

        assertEquals("Expect Rule Status to be Draft", "Draft", listRuleSummaryTableObjects.get(0).status);
    }


    @Category({ChangeRequest.CR_1636.class})
    @Test
    public void WhenNationalRuleManagerLoggedIn_CanCommitDraftRatsRule()
    {
        //Arrange
        TestUserModel.UserDetails superAdminUser = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(superAdminUser);

        String timeInSeconds = "500";
        setPublishAutomaticEventTime(timeInSeconds, superAdminUser.pid);

        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleWithRatsNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(createRuleResponse.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        ruleSummary_page.commitAndConfirm();

        //Assert
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        String sRuleStatus = listRuleSummaryTableObjects.get(0).status;

        assertEquals("Expect Rule Status to be Committed", "Committed", sRuleStatus);
    }


    @Category(ChangeRequest.CR_1866.class)
    @Test
    public void WhenLocalRuleWithDeclarationTypeBothAndNoDeclarationSubTypeCommitted_RuleCommittedSuccessfully(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();
        ruleDetails.declarationType = UI.DataForTests.TestRuleModel.RuleDetails.DeclarationType.BOTH;
        ruleDetails.declarationSubType = null;

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }

    @Category(ChangeRequest.CR_1908.class)
    @Test
    public void WhenLocalRuleManagerCreatesRuleAndNationalManagerCommitsRule_CorrectUserDetailsStored()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        utilUsers.Logout(driver);

        TestUserModel.UserDetails UserDetails2 = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails2);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails2);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(createRuleResponse.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        ruleSummary_page.commitAndConfirm();

        List<RuleSummary_Page.RuleSummaryTableObject> ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        ruleSummaryTableObjects.get(0).versionDetailAction.click();

        //Assert
        RuleDetails_Page ruleDetails_page = new RuleDetails_Page(driver);

        assertEquals(UserDetails.firstname +  " " + UserDetails.lastname, ruleDetails_page.createdBy.getText());
        assertEquals(UserDetails2.firstname +  " " + UserDetails2.lastname, ruleDetails_page.updatedBy.getText());
    }

    @Category(ChangeRequest.CR_3100.class)
    @Test
    public void WhenCommittedRuleIsAmended_CorrectDetailsAreDisplayedInUpcomingChanges()
    {
        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();
        ruleDetails.declarationType = UI.DataForTests.TestRuleModel.RuleDetails.DeclarationType.BOTH;
        ruleDetails.declarationSubType = null;

        //Act
        //Create a rule
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);
        createLocalRule_page.clickSaveAndCommitWithDefaultReason();
        createLocalRule_page.waitForAngularRequestsToFinish();

        RuleSummary_Page ruleSummary_page = createLocalRule_page.clickViewRule();
        ruleSummary_page.getListOfUpcomingChanges().get(0).versionDetailActionAmend.click();
        //Amend the rule
        ruleDetails.holdNarrative= "This is test for upcoming changes";
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);
        createLocalRule_page.clickSaveAndCommitWithDefaultReason();
        createLocalRule_page.waitForAngularRequestsToFinish();

        List<RuleSummary_Page.RuleUpcomingChangesTableObject> ruleSummaryTableObjectsUpcomingChanges = ruleSummary_page.getListOfUpcomingChanges();
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        ruleSummaryTableObjectsUpcomingChanges.get(0).versionDetailAction.click();//click verion details
        ruleSummary_page.waitForAngularRequestsToFinish();

        //assert the changes are shonw in rule details
        assertEquals("This is test for upcoming changes",ruleDetails.holdNarrative);
        //assert the upcoming changes has comiited abnd version is 2
        assertEquals(TestEnumerators.RuleStatus.committed.toString(),ruleSummaryTableObjectsUpcomingChanges.get(0).status.toLowerCase());
        assertEquals(2,ruleSummaryTableObjectsUpcomingChanges.get(0).version);
        //assert the lead version is cancelling and version is 1
        assertEquals(TestEnumerators.RuleStatus.committed.toString(),listRuleSummaryTableObjects.get(0).status.toLowerCase());
        assertEquals(2,listRuleSummaryTableObjects.get(0).version);

    }

}
