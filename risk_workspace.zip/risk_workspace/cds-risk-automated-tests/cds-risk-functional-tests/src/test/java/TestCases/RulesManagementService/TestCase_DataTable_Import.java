package TestCases.RulesManagementService;


import API.DataForTests.DataTables;
import API.DataForTests.TestDataTableModel;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.Validate.ValidateDataTableResponse.ValidateDataTableResponseObject;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import API.RulesManagementService.Data.ViewDataTableData.ViewDataTableDataResponse;
import Categories_CDSRisk.CDS_RM_DataTable;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import io.restassured.response.Response;
import org.apache.commons.httpclient.HttpStatus;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static API.RulesManagementService.Utils.DataTables.*;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_DataTable.class})
public class TestCase_DataTable_Import extends WebAPITestCaseWithDatatablesCleanup {


    @Test
    @Category(ChangeRequest.CR_2211.class)
    public void WhenValidDataImportedViaCSV_DataImportedSuccessfully()
    {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        ValidateDataTableResponseObject validateResponse = ValidateUploadCSVFileRequestResponseObject(tableDetails, "uploadValidData.csv");
        Response uploadResponse = UploadCSVFileRequest(tableDetails, "uploadValidData.csv");

        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableDataResponseObject = GetDataTableDataItems(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, validateResponse.httpStatusCode);
        assertEquals("valid count", 4, validateResponse.validCount);
        assertEquals("HTTP Status Code: ", HttpStatus.SC_NO_CONTENT, uploadResponse.statusCode());
        assertEquals("Expect 4 data items: ", 4, viewDataTableDataResponseObject.dataItems.size());
    }


    @Test
    @Category(ChangeRequest.CR_2211.class)
    public void WhenCSVWithValidAndInvalidDataImportedViaCSV_ValidDataImportedSuccessfully()
    {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        ValidateDataTableResponseObject validateResponse = ValidateUploadCSVFileRequestResponseObject(tableDetails, "uploadValidInvalidData.csv");
        Response uploadResponse = UploadCSVFileRequest(tableDetails, "uploadValidInvalidData.csv");

        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableDataResponseObject = GetDataTableDataItems(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, validateResponse.httpStatusCode);
        assertEquals("valid count", 3, validateResponse.validCount);
        assertEquals("invalid count", 3, validateResponse.invalidCount);

        Assertions.assertThat(validateResponse.validElements)
                    .hasSize(3)
                    .contains("1234567891", "1234567892", "1234567893");

        Assertions.assertThat(validateResponse.invalidElements)
                .hasSize(3)
                .contains("12345679999999", "12345678888888", "12345678887777");

        assertEquals("HTTP Status Code: ", HttpStatus.SC_NO_CONTENT, uploadResponse.statusCode());
        assertEquals("Expect 3 data items: ", 3, viewDataTableDataResponseObject.dataItems.size());
    }


    @Test
    @Category(ChangeRequest.CR_2211.class)
    public void WhenCSVWithInvalidDataImportedViaCSV_NoDataImported()
    {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        ValidateDataTableResponseObject validateResponse = ValidateUploadCSVFileRequestResponseObject(tableDetails, "uploadInvalidData.csv");
        Response uploadResponse = UploadCSVFileRequest(tableDetails, "uploadInvalidData.csv");

        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableDataResponseObject = GetDataTableDataItems(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, validateResponse.httpStatusCode);
        assertEquals("valid count", 0, validateResponse.validCount);
        assertEquals("invalid count", 4, validateResponse.invalidCount);

        Assertions.assertThat(validateResponse.validElements).hasSize(0);
        Assertions.assertThat(validateResponse.invalidElements).hasSize(4);

        assertEquals("HTTP Status Code: ", HttpStatus.SC_NO_CONTENT, uploadResponse.statusCode());
        assertEquals("Expect 0 data items: ", 0, viewDataTableDataResponseObject.dataItems.size());
    }


    @Test
    @Category(ChangeRequest.CR_2211.class)
    public void WhenValidData64KRowsImportedViaCSV_DataImportedSuccessfully()
    {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        ValidateDataTableResponseObject validateResponse = ValidateUploadCSVFileRequestResponseObject(tableDetails, "uploadValidData64K.csv");
        Response uploadResponse = UploadCSVFileRequest(tableDetails, "uploadValidData64K.csv");

        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableDataResponseObject = GetDataTableDataItems(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, validateResponse.httpStatusCode);
        assertEquals("valid count", 64000, validateResponse.validCount);

        Assertions.assertThat(validateResponse.validElements)
                .hasSize(64000)
                .contains("0000064000");

        assertEquals("HTTP Status Code: ", HttpStatus.SC_NO_CONTENT, uploadResponse.statusCode());
        assertEquals("Expect 64000 data items: ", 64000, viewDataTableDataResponseObject.dataItems.size());
    }


    @Test
    @Category(ChangeRequest.CR_2211.class)
    public void WhenMoreThan64KRowsImportedViaCSV_NoDataImported()
    {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        ValidateDataTableResponseObject validateResponse = API.RulesManagementService.Utils.DataTables.ValidateUploadCSVFileRequestResponseObject(tableDetails, "upload64Kplus.csv");
        Response uploadResponse = UploadCSVFileRequest(tableDetails, "upload64Kplus.csv");

        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableDataResponseObject = GetDataTableDataItems(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, validateResponse.httpStatusCode);
        assertEquals("tooManyRows: ", true, validateResponse.tooManyRows);

        assertEquals("HTTP Status Code: ", HttpStatus.SC_BAD_REQUEST, uploadResponse.statusCode());
        assertEquals("Expect 0 data items: ", 0, viewDataTableDataResponseObject.dataItems.size());
    }


    @Test
    @Category(ChangeRequest.CR_2211.class)
    public void WhenValidDataImportedIn2TransactionsViaCSV_DataImportedSuccessfully()
    {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        UploadCSVFileRequest(tableDetails, "uploadValidData.csv");

        //Act
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail2 = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail2.opLockVersion;

        //contains 4 new data items, 2 existing data items
        Response uploadResponse2 = UploadCSVFileRequest(tableDetails, "uploadValidData2.csv");

        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableDataResponseObject = GetDataTableDataItems(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_NO_CONTENT, uploadResponse2.statusCode());
        assertEquals("Expect 8 data items: ", 8, viewDataTableDataResponseObject.dataItems.size());
    }



}
