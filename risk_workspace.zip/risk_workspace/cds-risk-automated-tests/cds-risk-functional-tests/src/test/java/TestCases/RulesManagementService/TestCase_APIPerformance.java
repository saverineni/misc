package TestCases.RulesManagementService;

import API.DataForTests.TestRuleModel;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.ViewRule.ViewRuleResponse;
import Categories_CDSRisk.CDS_RM_RuleLifeCycle;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import static API.RulesManagementService.Utils.Rules.getRuleVersionsAssertingTimeLessThan;
import static org.assertj.core.api.Assertions.assertThat;

@Category({Rules_Management.class, CDS_RM_RuleLifeCycle.class})
public class TestCase_APIPerformance extends BaseWebAPITestCase {

    @Test
    @Category(ChangeRequest.CR_3264.class)
    public void ruleWithMultiplePublishedVersionsMeetsPerformanceTarget()
    {
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();
        String ruleUuid = committedRuleResponse.uniqueId;

        for (int i = 2; i <= 20; i++) {
            TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
            ruleDetails.description = "ta_updatedRule" + i;
            ruleDetails.uniqueID = ruleUuid;
            ruleDetails.version = i;
            API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetails);
            API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails, RuleVersionActions.commit);
        }

        publishAndWait(5000);

        ViewRuleResponse.ViewRuleResponseObject ruleVersions = getRuleVersionsAssertingTimeLessThan(ruleUuid, 3000L);
        assertThat(ruleVersions.versions).hasSize(20);
    }

}
