package TestCases.RulesManagementService;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse;
import API.RulesManagementService.Utils.Users;
import Categories_CDSRisk.CDS_RM_UserManagement;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import com.google.common.collect.ImmutableList;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static org.assertj.core.api.Assertions.assertThat;

@Category({Rules_Management.class, CDS_RM_UserManagement.class})
public class TestCase_UserManagement_BulkActions extends BaseWebAPITestCase {

    @Test
    @Category(ChangeRequest.CR_1905.class)
    public void WhenSuperAdminSuspendsAdmin_UserIsSuccessfullySuspended()
    {
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        createUser("1234510");

        Users.BulkSuspendUsers(ImmutableList.of("1234510"))
                .then()
                .statusCode(204);

        verifyStatusOfUser("1234510", "suspended");
    }

    @Test
    @Category(ChangeRequest.CR_1905.class)
    public void WhenSuperAdminSuspendsMultipleAdmins_AllSelectedUsersAreSuspended_OthersAreNotAffected()
    {
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        createUser("1234510");
        createUser("1234511");
        createUser("1234520");
        createUser("1234521");
        createUser("1234530");

        Users.BulkSuspendUsers(ImmutableList.of("1234510", "1234511", "1234520", "1234521"))
                .then()
                .statusCode(204);


        verifyStatusOfUser("1234510", "suspended");
        verifyStatusOfUser("1234511", "suspended");
        verifyStatusOfUser("1234520", "suspended");
        verifyStatusOfUser("1234521", "suspended");
        verifyStatusOfUser("1234530", "active");
    }

    @Test
    @Category(ChangeRequest.CR_1905.class)
    public void WhenSuperAdminSuspendsMultipleUser_WhereOneIsAlreadySuspended_BadRequestReturned()
    {
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        createUser("1234510");
        createUser("1234511");

        // Suspend one user
        Users.BulkSuspendUsers(ImmutableList.of("1234510"));

        Users.BulkSuspendUsers(ImmutableList.of(
                "1234510", // this s the suspended user
                "1234511"
        ))
                .then()
                .statusCode(400);


        verifyStatusOfUser("1234510", "suspended");
        verifyStatusOfUser("1234511", "active");
    }

    @Test
    @Category(ChangeRequest.CR_1905.class)
    public void WhenSuperAdminSuspendsMultipleUser_WhereMayNotBeSuspendedByCurrentUser_ForbiddenResponseReturned()
    {
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        createUser("1234510");
        String forbiddenUser = Users_API.NationalRulesManagerDefaultTestAutomationUser().pid;

        Users.BulkSuspendUsers(ImmutableList.of(
                "1234510",
                forbiddenUser
        ))
                .then()
                .statusCode(403);

        verifyStatusOfUser("1234510", "active");
        verifyStatusOfUser(forbiddenUser, "active");
    }

    private void verifyStatusOfUser(String pid, String status) {
        UserMeDetailsResponse.UsersMeResponseObject userDetail = Users.GetUserDetails(pid);

        assertThat(userDetail.status)
                .isEqualTo(status);
    }

    private void createUser(String pid) {
        TestUserModel.UserDetails userDetails = Users_API.AdminNational(pid);
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
    }

}

