package TestCases.RiskingService;


import API.DataForTests.Conditions;
import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestRuleModel;
import API.RiskingService.Declaration.SubmitDeclarationRequestFromFile;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Slow_Tests;
import TestCases.BaseWebAPITestCase;
import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeoutException;

import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
@Category(Slow_Tests.class)
@RunWith(JUnitParamsRunner.class)
public class TestCase_RiskingService_Attributes extends BaseWebAPITestCase {

    @Before
    public void setup() throws IOException, TimeoutException
    {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
    }


    //-------------------------------------------------------------------------------------------------
    //Data Driven Tests
    //-------------------------------------------------------------------------------------------------
    @Test
    @Category({ChangeRequest.CR_1.class, ChangeRequest.CR_175.class,ChangeRequest.CR_2782.class,ChangeRequest.CR_2769.class})
    @Parameters(method  = "singleConditionWithExpectedRouteForDeclarationTestData")
    public void WhenDeclarationSubmittedForMatchingAttribute_RouteReturned(String testName, SingleConditionWithExpectedRouteForDeclaration testData) throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryOptions.declarationType = testData.expectedDeclaration.declarationType;
        ruleDetails.ruleOutputs.actionType = testData.expectedRoute;

        createCommittedRuleWithSingleCondition(ruleDetails, testData.condition);

        publishAndWait(8000);

        //Act
        TestDeclarationModel.Declaration declaration = testData.expectedDeclaration;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        String sOverallInstructionExpectedValue = testData.expectedDeclaration.overallInstructionExpectedValue;
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        //TODO DOES NOT WORK with BIG DECIMAL need to identify type
        //modelSupport.checkDeclarationFieldValue(declarationRequest, testData.condition.attribute, testData.condition.value);

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        if (!testName.equals("dummyFirstTest"))
        {
        String returnedControlType = declarationResponse.getControlType();
        assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();

        //Debugging purposes only note slows down tests and log gets large...
//        riskingServiceSupport.getRiskingServiceLogBasedOnDescription(ruleDetails.description);

        //Note the first field that is risked is slow and results in false failure sometimes
        //therefore submitting dummy risking as 1st field

            if (testData.condition.isItemCondition == false) {
                Assertions.assertThat(reportBackElements).hasSize(1)
                        .contains("/declaration");
            } else {
                Assertions.assertThat(reportBackElements).hasSize(1)
                        .contains(declaration.reportBackElementsExpectedValue);
            }
        }
    }


    public void createCommittedRuleWithSingleCondition(TestRuleModel.RuleDetails.Condition condition){

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        createCommittedRuleWithSingleCondition(ruleDetails, condition);

    }

    public void createCommittedRuleWithSingleCondition(TestRuleModel.RuleDetails ruleDetails, TestRuleModel.RuleDetails.Condition condition){

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
    }

    public class SingleConditionWithExpectedRouteForDeclaration{

        public TestRuleModel.RuleDetails.Condition condition;
        public String expectedRoute;
        public TestDeclarationModel.Declaration expectedDeclaration;

        public SingleConditionWithExpectedRouteForDeclaration(TestRuleModel.RuleDetails.Condition condition,
                  String expectedRoute,  TestDeclarationModel.Declaration expectedDeclaration)
        {
            this.condition = condition;
            this.expectedRoute = expectedRoute;
            this.expectedDeclaration = expectedDeclaration;
        }

    }

    public Object[] singleConditionWithExpectedRouteForDeclarationTestData()
    {

        return new Object[]{


               new Object[]{"dummyFirstTest", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consigneeAddress(), "1", TestDeclarationModel.consigneeAddress())},
//
//                //NEW Header
//                //Ignoring this as we have test for locationID/PremiseseID. Both of them maps to to same
//                new Object[]{"arrivalLocationCode", new SingleConditionWithExpectedRouteForDeclaration(Conditions.arrivalLocationCode(), "1", TestDeclarationModel.arrivalLocationCode())},
//
                new Object[]{"dummyFirstTest", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consigneeAddress(), "1", TestDeclarationModel.consigneeAddress())},

                //NEW Header
                //Ignoring this as we have test for locationID/PremiseseID. D of them maps to to same
                //new Object[]{"arrivalLocationCode", new SingleConditionWithExpectedRouteForDeclaration(Conditions.arrivalLocationCode(), "1", TestDeclarationModel.arrivalLocationCode())},

                new Object[]{"supervisingOfficeEori", new SingleConditionWithExpectedRouteForDeclaration(Conditions.supervisingOfficeEori(), "1", TestDeclarationModel.supervisingOfficeEori())},
//
//                //special case scenarios ???
                new Object[]{"goodsArrivalIndicator", new SingleConditionWithExpectedRouteForDeclaration(Conditions.goodsArrivalIndicator(), "1", TestDeclarationModel.goodsArrivalIndicator())},
//
//
//                ////NEW ITEM
               new Object[]{"preferentialOriginCountry", new SingleConditionWithExpectedRouteForDeclaration(Conditions.preferentialOriginCountry(), "1", TestDeclarationModel.preferentialOriginCountry())},
//
//
//                //Header Collection fields
                new Object[]{"additionalInformation_CodeHeader", new SingleConditionWithExpectedRouteForDeclaration(Conditions.additionalInfoCode_HeaderCollections(), "1", TestDeclarationModel.additionalInfoCode_HeaderCollections())},
                new Object[]{"additionalInformation_TextHeader", new SingleConditionWithExpectedRouteForDeclaration(Conditions.additionalInfoText_HeaderCollections(), "1", TestDeclarationModel.additionalInfoText_HeaderCollections())},
                new Object[]{"additionalDocuments_TypeHeader", new SingleConditionWithExpectedRouteForDeclaration(Conditions.additionalDocumentsType_HeaderCollections(), "1", TestDeclarationModel.additionalDocumentsType_HeaderCollections())},

                //Header Level fields
                new Object[]{"consigneeCountry", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consigneeCountry(), "1", TestDeclarationModel.consigneeCountry())},
                new Object[]{"consigneeCity", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consigneeCity(), "1", TestDeclarationModel.consigneeCity())},
                new Object[]{"consigneeEori", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consigneeEori(), "1", TestDeclarationModel.consigneeEori())},
                new Object[]{"consigneeName", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consigneeName(), "1", TestDeclarationModel.consigneeName())},
                new Object[]{"consigneePostcode", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consigneePostcode(), "1", TestDeclarationModel.consigneePostcode())},
                new Object[]{"consigneeAddress", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consigneeAddress(), "1", TestDeclarationModel.consigneeAddress())},

                new Object[]{"consignorAddress_Header", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consignorAddress_Header(), "1", TestDeclarationModel.consignorAddress_Header())},
                new Object[]{"consignorCountry_Header", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consignorCountry_Header(), "1", TestDeclarationModel.consignorCountry_Header())},
                new Object[]{"consignorCity_Header", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consignorCity_Header(), "1", TestDeclarationModel.consignorCity_Header())},
                new Object[]{"consignorEori_Header", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consignorEori_Header(), "1", TestDeclarationModel.consignorEori_Header())},
                new Object[]{"consignorName_Header", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consignorName_Header(), "1", TestDeclarationModel.consignorName_Header())},
                new Object[]{"consignorPostcode_Header", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consignorPostcode_Header(), "1", TestDeclarationModel.consignorPostcode_Header())},
//
                new Object[]{"consignmentReference", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consignmentReference(), "1", TestDeclarationModel.consignmentReference())},

                new Object[]{"dispatchCountry_Header", new SingleConditionWithExpectedRouteForDeclaration(Conditions.dispatchCountry(), "1", TestDeclarationModel.dispatchCountry_Header())},
                new Object[]{"destinationCountry", new SingleConditionWithExpectedRouteForDeclaration(Conditions.destinationCountry_Header(), "1", TestDeclarationModel.destinationCountry_Header())},

                new Object[]{"declarantEori", new SingleConditionWithExpectedRouteForDeclaration(Conditions.declarantEori(), "1", TestDeclarationModel.declarantEori())},
                new Object[]{"declarantCountry", new SingleConditionWithExpectedRouteForDeclaration(Conditions.declarantCountry(), "1", TestDeclarationModel.declarantCountry())},
                new Object[]{"declarantName", new SingleConditionWithExpectedRouteForDeclaration(Conditions.declarantName(), "1", TestDeclarationModel.declarantName())},
                new Object[]{"declarantPostcode", new SingleConditionWithExpectedRouteForDeclaration(Conditions.declarantPostcode(), "1", TestDeclarationModel.declarantPostcode())},
                new Object[]{"declarantAddress", new SingleConditionWithExpectedRouteForDeclaration(Conditions.declarantAddress(), "1", TestDeclarationModel.declarantAddress())},
                new Object[]{"declarantCity", new SingleConditionWithExpectedRouteForDeclaration(Conditions.declarantCity(), "1", TestDeclarationModel.declarantCity())},

                new Object[]{"freightCharge", new SingleConditionWithExpectedRouteForDeclaration(Conditions.freightCharge(), "1", TestDeclarationModel.freightCharge())},
                new Object[]{"freightChargeCurrency", new SingleConditionWithExpectedRouteForDeclaration(Conditions.freightChargeCurrency(), "1", TestDeclarationModel.freightChargeCurrency())},

                new Object[]{"invoiceCurrency_Header", new SingleConditionWithExpectedRouteForDeclaration(Conditions.invoiceCurrency_Header(), "1", TestDeclarationModel.invoiceCurrency_Header())},
                new Object[]{"invoiceTotal_Header", new SingleConditionWithExpectedRouteForDeclaration(Conditions.invoiceTotal_Header(), "1", TestDeclarationModel.invoiceTotal_Header())},
                new Object[]{"itemCount", new SingleConditionWithExpectedRouteForDeclaration(Conditions.itemCount(), "1", TestDeclarationModel.itemCount())},

                new Object[]{"modeOfEntry", new SingleConditionWithExpectedRouteForDeclaration(Conditions.modeOfEntry(), "1", TestDeclarationModel.modeOfEntry())},

                new Object[]{"officeOfExit", new SingleConditionWithExpectedRouteForDeclaration(Conditions.officeOfExit(), "1", TestDeclarationModel.officeOfExit())},

                new Object[]{"packageCount_Header", new SingleConditionWithExpectedRouteForDeclaration(Conditions.packageCount_Header(), "1", TestDeclarationModel.packageCount_Header())},

                new Object[]{"representativeCity", new SingleConditionWithExpectedRouteForDeclaration(Conditions.representativeCity(), "1", TestDeclarationModel.representativeCity())},
                new Object[]{"representativeCountry", new SingleConditionWithExpectedRouteForDeclaration(Conditions.representativeCountry(), "1", TestDeclarationModel.representativeCountry())},
                new Object[]{"representativeEori", new SingleConditionWithExpectedRouteForDeclaration(Conditions.representativeEori(), "1", TestDeclarationModel.representativeEori())},
                new Object[]{"representativeName", new SingleConditionWithExpectedRouteForDeclaration(Conditions.representativeName(), "1", TestDeclarationModel.representativeName())},
                new Object[]{"representativeAddress", new SingleConditionWithExpectedRouteForDeclaration(Conditions.representativeAddress(), "1", TestDeclarationModel.representativeAddress())},
                new Object[]{"representativePostcode", new SingleConditionWithExpectedRouteForDeclaration(Conditions.representativePostcode(), "1", TestDeclarationModel.representativePostcode())},
                new Object[]{"representativeFunction", new SingleConditionWithExpectedRouteForDeclaration(Conditions.representativeFunction(), "1", TestDeclarationModel.representativeFunction())},

                new Object[]{"specificCircumstance", new SingleConditionWithExpectedRouteForDeclaration(Conditions.specificCircumstance(), "1", TestDeclarationModel.specificCircumstance())},

                new Object[]{"totalGrossMass_Header", new SingleConditionWithExpectedRouteForDeclaration(Conditions.totalGrossMass_Header(), "1", TestDeclarationModel.totalGrossMass_Header())},
                new Object[]{"tradersOwnReference", new SingleConditionWithExpectedRouteForDeclaration(Conditions.tradersOwnReference(), "1", TestDeclarationModel.tradersOwnReference())},

                new Object[]{"transportMOP", new SingleConditionWithExpectedRouteForDeclaration(Conditions.transportMOP(), "1", TestDeclarationModel.transportMOP())},

                new Object[]{"uniqueConsignmentReference", new SingleConditionWithExpectedRouteForDeclaration(Conditions.uniqueConsignmentReference(), "1", TestDeclarationModel.uniqueConsignmentReference())},

                new Object[]{"exporterAddress_Header", new SingleConditionWithExpectedRouteForDeclaration(Conditions.exporterAddress_Header("1 Singleton street"), "1", TestDeclarationModel.exporterAddress_header("1 Singleton street"))},
                new Object[]{"exporterName_Header", new SingleConditionWithExpectedRouteForDeclaration(Conditions.exporterName_Header("Test Agency"), "1", TestDeclarationModel.exporterName_header("TeST AGEncy"))},

                new Object[]{"importerAddress_Header", new SingleConditionWithExpectedRouteForDeclaration(Conditions.importerAddress_Header("1 Great Northern Street"), "1", TestDeclarationModel.importerAddress_header("1 GREaT NoRTHerN sTReeT"))},
                new Object[]{"importerName_Header", new SingleConditionWithExpectedRouteForDeclaration(Conditions.importerName_Header("Test Agency"), "1", TestDeclarationModel.importerName_header("tesT aGencY"))},

//                //Not doing fields for now future story
//                ////TODO//   new Object[]{"modeOfTransport", new SingleConditionWithExpectedRouteForDeclaration(Conditions.modeOfTransport(), "1", TestDeclarationModel.modeOfTransport())},
 //               new Object[]{"supervisingOfficeName", new SingleConditionWithExpectedRouteForDeclaration(Conditions.supervisingOfficeName(), "1", TestDeclarationModel.supervisingOfficeName())},
//
//                //Premise Name and Goods Location maps to same field
 //               new Object[]{"premisesName", new SingleConditionWithExpectedRouteForDeclaration(Conditions.premisesName(), "1", TestDeclarationModel.premisesName())},
//
//                //Premises ID and Arrival location code are mapped to same thing, only one will work
//                new Object[]{"premisesID", new SingleConditionWithExpectedRouteForDeclaration(Conditions.premisesID(), "1", TestDeclarationModel.premisesID())},
//
//                //Item Level fields
                new Object[]{"commodityCode", new SingleConditionWithExpectedRouteForDeclaration(Conditions.commodityCode(), "1", TestDeclarationModel.commodityCode())},
//                ////TODO commodity grossMass and netMass are possible in the DMS schema, but currently there is no matcher to risk them
//                new Object[]{"commodityGrossMass", new SingleConditionWithExpectedRouteForDeclaration(Conditions.commodityGrossMass(), "1", TestDeclarationModel.commodityGrossMass())},
 //                new Object[]{"commodityNetMass", new SingleConditionWithExpectedRouteForDeclaration(Conditions.commodityNetMass(), "1", TestDeclarationModel.commodityNetMass())},
//
                new Object[]{"CPC", new SingleConditionWithExpectedRouteForDeclaration(Conditions.customsProcedureCode(), "1", TestDeclarationModel.cpc())},
                new Object[]{"customsValue", new SingleConditionWithExpectedRouteForDeclaration(Conditions.customsValue(), "1", TestDeclarationModel.customsValue())},

                new Object[]{"consigneeAddress_Item", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consigneeAddress_Item(), "1", TestDeclarationModel.consigneeAddress_Item())},
                new Object[]{"consigneeCity_Item", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consigneeCity_Item(), "1", TestDeclarationModel.consigneeCity_Item())},
                new Object[]{"consigneeCountry_Item", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consigneeCountry_Item(), "1", TestDeclarationModel.consigneeCountry_Item())},
                new Object[]{"consigneeEori_Item", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consigneeEori_Item(), "1", TestDeclarationModel.consigneeEori_Item())},
                new Object[]{"consigneeName_Item", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consigneeName_Item(), "1", TestDeclarationModel.consigneeName_Item())},
                new Object[]{"consigneePostcode_Item", new SingleConditionWithExpectedRouteForDeclaration(Conditions.consigneePostcode_Item(), "1", TestDeclarationModel.consigneePostcode_Item())},

                new Object[]{"consignorAddress_Item", new SingleConditionWithExpectedRouteForDeclaration(Conditions.exporterConsignorAddress_Item(), "1", TestDeclarationModel.exporterConsignorAddress_Item())},
                new Object[]{"consignorCountry_Item", new SingleConditionWithExpectedRouteForDeclaration(Conditions.exporterConsignorCountry_Item(), "1", TestDeclarationModel.exporterConsignorCountry_Item())},
                new Object[]{"consignorCity_Item", new SingleConditionWithExpectedRouteForDeclaration(Conditions.exporterConsignorCity_Item(), "1", TestDeclarationModel.exporterConsignorCity_Item())},
                new Object[]{"consignorEori_Item", new SingleConditionWithExpectedRouteForDeclaration(Conditions.exporterConsignorEori_Item(), "1", TestDeclarationModel.exporterConsignorEori_Item())},
                new Object[]{"consignorName_Item", new SingleConditionWithExpectedRouteForDeclaration(Conditions.exporterConsignorName_Item(), "1", TestDeclarationModel.exporterConsignorName_Item())},
                new Object[]{"consignorPostcode_Item", new SingleConditionWithExpectedRouteForDeclaration(Conditions.exporterConsignorPostcode_Item(), "1", TestDeclarationModel.exporterConsignorPostcode_Item())},

                new Object[]{"destinationCountry_Item", new SingleConditionWithExpectedRouteForDeclaration(Conditions.destinationCountry_Item(), "1", TestDeclarationModel.destinationCountry_Item())},
                new Object[]{"dispatchCountry_Item", new SingleConditionWithExpectedRouteForDeclaration(Conditions.dispatchCountry_Item(), "1", TestDeclarationModel.dispatchCountry_Item())},
                new Object[]{"declaredCustomsValue", new SingleConditionWithExpectedRouteForDeclaration(Conditions.declaredCustomsValue(), "1", TestDeclarationModel.declaredCustomsValue())},

                new Object[]{"goodsDescription", new SingleConditionWithExpectedRouteForDeclaration(Conditions.goodsDescription(), "1", TestDeclarationModel.goodsDescription())},

                new Object[]{"invoicePriceItem", new SingleConditionWithExpectedRouteForDeclaration(Conditions.invoicePrice(), "1", TestDeclarationModel.invoicePrice())},

                new Object[]{"originCountry_Item", new SingleConditionWithExpectedRouteForDeclaration(Conditions.originCountry_Item(), "1", TestDeclarationModel.originCountry_Item())},

                new Object[]{"payingAgentEori", new SingleConditionWithExpectedRouteForDeclaration(Conditions.payingAgentEori(), "1", TestDeclarationModel.payingAgentEori())},

                new Object[]{"statisticalValue", new SingleConditionWithExpectedRouteForDeclaration(Conditions.statisticalValue(), "1", TestDeclarationModel.statisticalValue())},

                new Object[]{"valuationMethodCode", new SingleConditionWithExpectedRouteForDeclaration(Conditions.valuationMethodCode(), "1", TestDeclarationModel.valuationMethodCode())},

                new Object[]{"unDangerousGoodsCode", new SingleConditionWithExpectedRouteForDeclaration(Conditions.unDangerousGoodsCode(), "1", TestDeclarationModel.unDangerousGoodsCode())},

        };
    }

}
