package TestCases.RiskingService;

import API.DataForTests.*;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeoutException;

import static API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody;
import static org.assertj.core.api.Assertions.assertThat;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.crossmatch;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.datatable;

@Slf4j
@Category(Risking_Service.class)
public class TestCase_Risking_Case_Insensitivity extends WebAPITestCaseWithDatatablesCleanup {

    @Before
    public void setup() throws IOException, TimeoutException
    {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
    }

    @Test
    @Category({ChangeRequest.CR_2976.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithEqualOperatorCaseInsensitive_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.consigneeAddress();
        condition.value = "10 Chapel Street";

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.consigneeAddress = "10 chapeL streeT";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CR_2976.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithStartsWithOperatorCaseInsensitive_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.consigneeAddress();
        condition.operator = "st";
        condition.value = "Chapel";

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.consigneeAddress = "chapeL streeT";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CR_2976.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithNotEqualOperatorCaseInsensitive_NoRouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.consigneeAddress();
        condition.operator = "neq";
        condition.value = "Chapel";

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeAddress = "CHAPEL";


        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        declaration.controlTypeExpectedValue = "";
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_2976.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithNotStartsWithOperatorCaseInsensitive_NoRouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.consigneeAddress();
        condition.operator = "nst";
        condition.value = "Chapel";

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeAddress = "CHAPEL Street";


        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        declaration.controlTypeExpectedValue = "";
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_2976.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithContainsOperatorCaseInsensitive_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.consigneeAddress();
        condition.operator = "con";
        condition.value = "Chapel";

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.consigneeAddress = "10 chapeL streeT";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CR_2976.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithNotContainsOperatorCaseInsensitive_NoRouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.consigneeAddress();
        condition.operator = "nco";
        condition.value = "Chapel";

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeAddress = "10 CHAPEL Street";


        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        declaration.controlTypeExpectedValue = "";
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_2976.class})
   // @Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenDeclarationSubmittedForMatchingRuleMatchingHeaderLevelCaseInsensitive_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.consigneeCountry();

        condition.value = Conditions.consignorCountry_Header().attribute;

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.consigneeCountry = "FR";
        declaration.consignorCountry_Header = "fr";


        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CR_2976.class})
    public void WhenDeclarationSubmittedForMatchingRuleMatchingDomainCaseInsensitive_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.country();

        condition.value = "UK";

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.destinationCountry_Header = "Uk";
        declaration.dispatchCountry_Item = "uk";
        declaration.countryRoute = "uK";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);

        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category(ChangeRequest.CR_2976.class)
    public void WhenDeclarationSubmittedWithValueInDataTableCaseInsensitive_RouteReturned() {

        //Arrange
        CreateCommittedRuleWithFreeTextDataTable(DataTables.DataTable_FreeText_Risking(), "eq");

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.goodsDescription = "nortH koreA";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    private TestRuleModel.RuleDetails CreateCommittedRuleWithFreeTextDataTable(TestDataTableModel.TableDetails tableDetails, String operator) {

        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(createDataTableResponse.uuid);
        //tableDetails.tableVersionUuid = responseDetail.tableVersionUuid;
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //add data items to data table
        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.goodsDescription().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).operator = operator;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = tableDetails.uuid;
        ruleDetails.queryConditions.get(0).conditions.get(0).isDataTable = true;
        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        return ruleDetails;
    }

}
