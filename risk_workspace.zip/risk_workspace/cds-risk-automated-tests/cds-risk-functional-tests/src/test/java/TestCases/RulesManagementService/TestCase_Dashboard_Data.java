package TestCases.RulesManagementService;


import API.DataForTests.*;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.Dashboard.ViewDashboarDataResponse;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionRequest;
import API.RulesManagementService.Utils.Dashboard;
import Categories_CDSRisk.CDS_RM_Dashboard;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.ConditionType;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import static API.RulesManagementService.Utils.DataTables.*;
import static API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject;
import static API.RulesManagementService.Utils.Rules.EditRuleVersionAndGetResponseObject;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@Category({Rules_Management.class, CDS_RM_Dashboard.class})
public class TestCase_Dashboard_Data extends WebAPITestCaseWithDatatablesCleanup {


    @Before
    public void Setup() {

        dataTablesUtils.CreateDefaultDataTable();
    }


    @Test
    @Category({ChangeRequest.CR_2604.class})
    public void WhenOpenDataTableCreated_DataDashboardHasCorrectData()
    {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        //Act
        CreateDataTableAndGetResponseObject(tableDetails);

        ViewDashboarDataResponse.ViewDataResponseObject viewDataResponseObject = Dashboard.GetDashboardData("");

        //Assert
        assertEquals("Expect Total Data Table", 2, viewDataResponseObject.total);
        assertEquals("Expect Total Item Status", 3, viewDataResponseObject.items.size());
        assertTrue( viewDataResponseObject.items.get(0).name.equalsIgnoreCase("OPEN"));
        assertEquals("Expect OPEN = 1", 1, viewDataResponseObject.items.get(0).value);
    }

    @Test
    @Category({ChangeRequest.CR_2604.class})
    public void WhenRestrictedDataTableCreated_DataDashboardHasCorrectData()
    {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        tableDetails.tableType = "Restricted";

        //Act
        CreateDataTableAndGetResponseObject(tableDetails);

        ViewDashboarDataResponse.ViewDataResponseObject viewDataResponseObject = Dashboard.GetDashboardData("");

        //Assert
        assertEquals("Expect Total Data Table", 2, viewDataResponseObject.total);
        assertTrue( viewDataResponseObject.items.get(1).name.equalsIgnoreCase("RESTRICTED"));
        assertEquals("Expect RESTRICTED = 2", 2, viewDataResponseObject.items.get(1).value);
    }

    @Test
    @Category({ChangeRequest.CR_2604.class})
    public void WhenSensitiveDataTableCreated_DataDashboardHasCorrectData()
    {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        tableDetails.tableType = "Sensitive";

        //Act
        CreateDataTableAndGetResponseObject(tableDetails);

        ViewDashboarDataResponse.ViewDataResponseObject viewDataResponseObject = Dashboard.GetDashboardData("");

        //Assert
        assertEquals("Expect Total Data Table", 2, viewDataResponseObject.total);
        assertTrue( viewDataResponseObject.items.get(2).name.equalsIgnoreCase("SENSITIVE"));
        assertEquals("Expect SENSITIVE = 1", 1, viewDataResponseObject.items.get(2).value);
    }


    @Test
    @Category({ChangeRequest.CR_2604.class})
    public void WhenMultipleDataTablesCreated_DataDashboardHasCorrectData()
    {
        //Arrange
        TestDataTableModel.TableDetails tableDetails_Open = DataTables.DataTable_NoData();
        CreateDataTableAndGetResponseObject(tableDetails_Open);

        TestDataTableModel.TableDetails tableDetails_Res = DataTables.DataTable_NoData();
        tableDetails_Res.tableName = "table_Restricted";
        tableDetails_Res.tableType = "Restricted";
        CreateDataTableAndGetResponseObject(tableDetails_Res);

        TestDataTableModel.TableDetails tableDetails_Sens = DataTables.DataTable_NoData();
        tableDetails_Sens.tableName = "table_Sensitive";
        tableDetails_Sens.tableType = "Sensitive";
        CreateDataTableAndGetResponseObject(tableDetails_Sens);

        //Act
        ViewDashboarDataResponse.ViewDataResponseObject viewDataResponseObject = Dashboard.GetDashboardData("");

        //Assert
        assertEquals("Expect Total Data Table", 4, viewDataResponseObject.total);

        assertTrue( viewDataResponseObject.items.get(0).name.equalsIgnoreCase("OPEN"));
        assertEquals("Expect OPEN = 1", 1, viewDataResponseObject.items.get(0).value);

        assertTrue( viewDataResponseObject.items.get(1).name.equalsIgnoreCase("RESTRICTED"));
        assertEquals("Expect RESTRICTED = 2", 2, viewDataResponseObject.items.get(1).value);

        assertTrue( viewDataResponseObject.items.get(2).name.equalsIgnoreCase("SENSITIVE"));
        assertEquals("Expect SENSITIVE = 1", 1, viewDataResponseObject.items.get(2).value);
    }

    @Test
    @Category({ChangeRequest.CR_2604.class})
    public void WhenDataTableSharedWithMe_DataDashboardHasCorrectData()
    {
        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_POO());

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();
        tableDetails.tableType = "sensitive";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        tableDetails.useTablesLocationUuids.clear();
        tableDetails.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        //Act
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_EXT());

        ViewDashboarDataResponse.ViewDataResponseObject viewDataResponseObject = Dashboard.GetDashboardData("OWNER,USE");

        //Assert
        assertEquals("Expect Total Data Table", 1, viewDataResponseObject.total);
        assertTrue( viewDataResponseObject.items.get(2).name.equalsIgnoreCase("SENSITIVE"));
        assertEquals("Expect SENSITIVE = 1", 1, viewDataResponseObject.items.get(2).value);
    }


    @Test
    @Category({ChangeRequest.CR_2604.class})
    public void WhenDataTableNotSharedWithMe_DataDashboardHasCorrectData()
    {
        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_POO());

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();
        tableDetails.tableType = "sensitive";
        CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_EXT());

        ViewDashboarDataResponse.ViewDataResponseObject viewDataResponseObject = Dashboard.GetDashboardData("NONE");

        //Assert
        assertEquals("Expect Total Data Table", 2, viewDataResponseObject.total);
        assertTrue( viewDataResponseObject.items.get(2).name.equalsIgnoreCase("SENSITIVE"));
        assertEquals("Expect SENSITIVE = 1", 1, viewDataResponseObject.items.get(2).value);
    }

    @Test
    @Category({ChangeRequest.CR_2638.class})
    @Ignore("Will be fixed as part of CR-3194")
    public void WhenOrphanedDataTablesAreSelected_DataDashboardHasCorrectData()
    {
        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_POO());

        //Create a datatable and dont associate with any rule
        TestDataTableModel.TableDetails orphanedDataTable = DataTables.DataTable_CommodityCodes_POO();
        orphanedDataTable.tableType = "sensitive";
        CreateDataTableAndGetResponseObject(orphanedDataTable);

        //Create a datatable and associate with any rule
        TestDataTableModel.TableDetails dataTableWithRule = DataTables.DataTable_CommodityCodes_POOEXT();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(dataTableWithRule);
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;
        CreateRuleResponse.PostResponse postResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = postResponse.uniqueId;
        EditRuleVersionRequest.PutRequest editRuleVersion  = new EditRuleVersionRequest.PutRequest();
        editRuleVersion.action = RuleVersionActions.commit.toString();
        EditRuleVersionAndGetResponseObject(ruleDetails, editRuleVersion);

        //Create a datatable and associate with any rule in version 1 and in version2 make it orphaned by disassociating from the rule
        TestDataTableModel.TableDetails dataTableWithRule2 = DataTables.DataTable_PartCommodityCodes_POO();
        createDataTableResponse = CreateDataTableAndGetResponseObject(dataTableWithRule2);
        TestRuleModel.RuleDetails ruleDetails1 = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        ruleDetails1.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails1.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;
        CreateRuleResponse.PostResponse createRuleResponse= CreateRuleAndGetResponseObject(ruleDetails1);
        ruleDetails1.uniqueID = createRuleResponse.uniqueId;
        EditRuleVersionRequest.PutRequest editRuleVersion1  = new EditRuleVersionRequest.PutRequest();
        editRuleVersion1.action = RuleVersionActions.commit.toString();
        EditRuleVersionAndGetResponseObject(ruleDetails1, editRuleVersion1);

        //get the data response object when there are 2 datatables are orphaned and 2 datatables are associated to rules
        ViewDashboarDataResponse.ViewDataResponseObject viewDataResponseObjectOrphanedDataTables = Dashboard.GetDashboardData("ORPHANED");

        //Edit datatable
        dataTableWithRule2.uuid = createDataTableResponse.uuid;
        GetDataTableDetailsByUID(createDataTableResponse.uuid);
        dataTableWithRule2.version=2;
        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(dataTableWithRule2);

        //Disassociate from the rule
        ruleDetails1.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.normal;
        ruleDetails1.queryConditions.get(0).conditions.get(0).value = "QQ";
        API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetails1);
        EditRuleVersionRequest.PutRequest editRuleVersion2  = new EditRuleVersionRequest.PutRequest();
        editRuleVersion2.action = RuleVersionActions.commit.toString();
        ruleDetails1.version = 2;
        EditRuleVersionAndGetResponseObject(ruleDetails1, editRuleVersion2);

        //get response object when 3 datatables are orphaned and one is associated to a rule
        ViewDashboarDataResponse.ViewDataResponseObject viewDataResponseObjectOrphanedDataTables1 = Dashboard.GetDashboardData("ORPHANED");

        //When 2 datatables are orphaned and 2 datatables are associated to rules
        assertEquals("Expect Orphaned Data Tables", 2, viewDataResponseObjectOrphanedDataTables.total);

        assertTrue( viewDataResponseObjectOrphanedDataTables.items.get(0).name.equalsIgnoreCase("OPEN"));
        assertEquals("Expect OPEN = 0", 0, viewDataResponseObjectOrphanedDataTables.items.get(0).value);

        assertTrue( viewDataResponseObjectOrphanedDataTables.items.get(1).name.equalsIgnoreCase("RESTRICTED"));
        assertEquals("Expect RESTRICTED = 1", 1, viewDataResponseObjectOrphanedDataTables.items.get(1).value);

        assertTrue( viewDataResponseObjectOrphanedDataTables.items.get(2).name.equalsIgnoreCase("SENSITIVE"));
        assertEquals("Expect SENSITIVE = 1", 1, viewDataResponseObjectOrphanedDataTables.items.get(1).value);

        //One datatable is disassociated from the rule. So totally 3 datatables are orphaned and one is associated to a rule
        assertEquals("Expect Orphaned Data Tables", 3, viewDataResponseObjectOrphanedDataTables1.total);

        assertTrue( viewDataResponseObjectOrphanedDataTables1.items.get(0).name.equalsIgnoreCase("OPEN"));
        assertEquals("Expect OPEN = 1", 1, viewDataResponseObjectOrphanedDataTables1.items.get(0).value);

        assertTrue( viewDataResponseObjectOrphanedDataTables1.items.get(1).name.equalsIgnoreCase("RESTRICTED"));
        assertEquals("Expect RESTRICTED = 1", 1, viewDataResponseObjectOrphanedDataTables1.items.get(1).value);

        assertTrue( viewDataResponseObjectOrphanedDataTables1.items.get(2).name.equalsIgnoreCase("SENSITIVE"));
        assertEquals("Expect SENSITIVE = 1", 1, viewDataResponseObjectOrphanedDataTables1.items.get(1).value);
    }


}
