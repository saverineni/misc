package TestCases.UI.Navigation;

import API.DataForTests.*;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Navigation;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.Pages.DataManagement.ListDataTable_Page;
import UI.Pages.Home_Page;
import UI.Utils.Navigation;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.ConditionType;

import java.util.List;

import static API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject;
import static API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject;
import static junit.framework.TestCase.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Navigation.class})
public class TestCase_Dashboard_Data extends BaseUIWebDriverTestCase {

    @Before
    public void LocalSetup()
    {
        TestDataTableModel.TableDetails tdDefaultTestDataTable = DataTables.DataTable_DefaultCommodityCodes();
        API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tdDefaultTestDataTable);
    }


    @Test
    @Category({ChangeRequest.CR_2604.class})
    public void WhenDataTabSelected_DataDashboardDetailsDisplayed() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);

        //Create a datatable
        TestDataTableModel.TableDetails tableDetails_Open = DataTables.DataTable_NoData();
        CreateDataTableAndGetResponseObject(tableDetails_Open);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        //Act
        Home_Page home_page = new Home_Page(driver);
        home_page.dataTab.click();
        home_page.waitForAngularRequestsToFinish();

        //Assert
        assertEquals("Default Total Data Tables", 2, home_page.getTotalDataTables());
        assertEquals("Default Data Table Filter Total", "Total Data Tables", home_page.dataType.getSelectedItem());
    }


    @Test
    @Category({ChangeRequest.CR_2604.class,ChangeRequest.CR_2638.class})
    @Ignore("Will be fixed as part of CR-3194")
    public void WhenDataTablesExist_DataDashboardDisplayCorrectDetails() {

        //Arrange
        //create 3 data tables
        TestDataTableModel.TableDetails tableDetails_Open = DataTables.DataTable_NoData();
        CreateDataTableAndGetResponseObject(tableDetails_Open);

        TestDataTableModel.TableDetails tableDetails_Res = DataTables.DataTable_NoData();
        tableDetails_Res.tableName = "table_Restricted";
        tableDetails_Res.tableType = "Restricted";
        CreateDataTableAndGetResponseObject(tableDetails_Res);

        TestDataTableModel.TableDetails tableDetails_Sens = DataTables.DataTable_NoData();
        tableDetails_Sens.tableName = "table_Sensitive";
        tableDetails_Sens.tableType = "Sensitive";
        CreateDataTableAndGetResponseObject(tableDetails_Sens);

        //create 1 data table not shared
        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetailsPOO);

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();
        tableDetails.tableType = "sensitive";
        CreateDataTableAndGetResponseObject(tableDetails);

        //Create a datatable and assign it to a rule
        TestDataTableModel.TableDetails dataTableWithRule = DataTables.DataTable_PartCommodityCodes_POO();
        dataTableWithRule.tableType = "Restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(dataTableWithRule);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        ruleDetails.queryConditions.get(0).conditions.get(0).isDataTable = true;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);


        //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetailsPOO);

        Home_Page home_page = new Home_Page(driver);
        home_page.dataTab.click();
        home_page.waitForAngularRequestsToFinish();
        home_page.dataType.select("Total Data Tables");
        home_page.waitForAngularRequestsToFinish();
        List<Home_Page.DashBoardItemObject> dashboardDataItems = home_page.getDashboardDataItems();
        int actTotalDataTables = home_page.getTotalDataTables();

        home_page.dataType.select("Shared With Me");
        home_page.waitForAngularRequestsToFinish();
        List<Home_Page.DashBoardItemObject> dashboardDataItemsShared = home_page.getDashboardDataItems();
        int actSharedDataTables = home_page.getTotalDataTables();

        home_page.dataType.select("Not Shared With Me");
        home_page.waitForAngularRequestsToFinish();
        List<Home_Page.DashBoardItemObject> dashboardDataItemsNotShared = home_page.getDashboardDataItems();
        int actNotSharedDataTables = home_page.getTotalDataTables();

        home_page.dataType.select("Orphaned");
        home_page.waitForAngularRequestsToFinish();
        List<Home_Page.DashBoardItemObject> dashboardDataItemsOrphaned = home_page.getDashboardDataItems();
        int actOrphanedDataTables = home_page.getTotalDataTables();


        //Assert
        assertEquals("Default Total Data Tables", 6, actTotalDataTables);

        assertEquals("OPEN", dashboardDataItems.get(0).status);
        assertEquals("RESTRICTED", dashboardDataItems.get(1).status);
        assertEquals("SENSITIVE", dashboardDataItems.get(2).status);

        assertEquals("OPEN count", 1, dashboardDataItems.get(0).count);
        assertEquals("RESTRICTED count", 3, dashboardDataItems.get(1).count);
        assertEquals("SENSITIVE count", 2, dashboardDataItems.get(2).count);

        assertEquals("OPEN percentage", 16.67, dashboardDataItems.get(0).percentage);
        assertEquals("RESTRICTED percentage", 50.00, dashboardDataItems.get(1).percentage);
        assertEquals("SENSITIVE percentage", 33.33, dashboardDataItems.get(2).percentage);


        //Shared
        assertEquals("Shared Total Data Tables", 3, actSharedDataTables);
        assertEquals("OPEN count", 1 ,dashboardDataItemsShared.get(0).count);
        assertEquals("RESTRICTED count",1, dashboardDataItemsShared.get(1).count);
        assertEquals("SENSITIVE count", 1, dashboardDataItemsShared.get(2).count);

        assertEquals("OPEN percentage", 33.33, dashboardDataItemsShared.get(0).percentage);
        assertEquals("RESTRICTED percentage", 33.33, dashboardDataItemsShared.get(1).percentage);
        assertEquals("SENSITIVE percentage", 33.33, dashboardDataItemsShared.get(2).percentage);

        //Not Shared
        assertEquals("Not Shared Total Data Tables", 3, actNotSharedDataTables);
        assertEquals("OPEN count", 0, dashboardDataItemsNotShared.get(0).count);
        assertEquals("RESTRICTED count",2, dashboardDataItemsNotShared.get(1).count);
        assertEquals("SENSITIVE count", 1, dashboardDataItemsNotShared.get(2).count);

        assertEquals("OPEN percentage", 00.00, dashboardDataItemsNotShared.get(0).percentage);
        assertEquals("RESTRICTED percentage", 66.67, dashboardDataItemsNotShared.get(1).percentage);
        assertEquals("SENSITIVE percentage", 33.33, dashboardDataItemsNotShared.get(2).percentage);


        //Orphaned
        // Dashboard - Orphaned count now fails - see CR-3049
        /*
        assertEquals("Orphaned Total Data Tables", 5, actOrphanedDataTables);
        assertEquals("OPEN count", 1, dashboardDataItemsOrphaned.get(0).count);
        assertEquals("RESTRICTED count", 2, dashboardDataItemsOrphaned.get(1).count);
        assertEquals("SENSITIVE count", 2, dashboardDataItemsOrphaned.get(2).count);

        assertEquals("OPEN percentage", 20.00, dashboardDataItemsOrphaned.get(0).percentage);
        assertEquals("RESTRICTED percentage", 40.00, dashboardDataItemsOrphaned.get(1).percentage);
        assertEquals("SENSITIVE percentage", 40.00, dashboardDataItemsOrphaned.get(2).percentage);
        */
    }


    @Test
    @Category({ChangeRequest.CR_2783.class})
    public void WhenDataTablesDashboardStatusDialSelected_DataTablesForSelectedDataTableStatusDisplayed() {

        //Arrange
        //create 3 data tables
        TestDataTableModel.TableDetails tableDetails_Open = DataTables.DataTable_NoData();
        CreateDataTableAndGetResponseObject(tableDetails_Open);

        TestDataTableModel.TableDetails tableDetails_Res = DataTables.DataTable_NoData();
        tableDetails_Res.tableName = "table_Restricted";
        tableDetails_Res.tableType = "Restricted";
        CreateDataTableAndGetResponseObject(tableDetails_Res);

        TestDataTableModel.TableDetails tableDetails_Sens = DataTables.DataTable_NoData();
        tableDetails_Sens.tableName = "table_Sensitive";
        tableDetails_Sens.tableType = "Sensitive";
        CreateDataTableAndGetResponseObject(tableDetails_Sens);

        //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        Users_API.NationalRulesManagerDefaultTestAutomationUser();
        utilUsers.LoginToCDSRiskUIAsUser(Users_API.NationalRulesManagerDefaultTestAutomationUser());

        Home_Page home_page = new Home_Page(driver);
        home_page.dataTab.click();
        home_page.waitForAngularRequestsToFinish();

        List<Home_Page.DashBoardItemObject> dataDashboard = home_page.getDashboardDataItems();
        dataDashboard.get(2).webElement.click();    //Sensitive
        home_page.waitForAngularRequestsToFinish();

        ListDataTable_Page listDataTable_page = new ListDataTable_Page(driver);
        List<ListDataTable_Page.DataTableListObject> dataTablesSensitive = listDataTable_page.getDataTableListDetails();

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        utilNavigation.NavigateToPage(Navigation.Pages.Dashboard);
        home_page.dataTab.click();
        home_page.waitForAngularRequestsToFinish();

        dataDashboard = home_page.getDashboardDataItems();
        dataDashboard.get(1).webElement.click();    //Restricted
        home_page.waitForAngularRequestsToFinish();
        List<ListDataTable_Page.DataTableListObject> dataTablesRestricted = listDataTable_page.getDataTableListDetails();

        utilNavigation.NavigateToPage(Navigation.Pages.Dashboard);
        home_page.dataTab.click();

        dataDashboard = home_page.getDashboardDataItems();
        dataDashboard.get(0).webElement.click();    //Open
        home_page.waitForAngularRequestsToFinish();
        List<ListDataTable_Page.DataTableListObject> dataTablesOpen = listDataTable_page.getDataTableListDetails();

        //Assert
        Assertions.assertThat(dataTablesSensitive).extracting("tableTitle").contains(tableDetails_Sens.tableName);
        Assertions.assertThat(dataTablesSensitive).extracting("tableTitle").doesNotContain(tableDetails_Open.tableName);
        Assertions.assertThat(dataTablesSensitive).extracting("tableTitle").doesNotContain(tableDetails_Res.tableName);

        Assertions.assertThat(dataTablesRestricted).extracting("tableTitle").contains(tableDetails_Res.tableName);
        Assertions.assertThat(dataTablesRestricted).extracting("tableTitle").doesNotContain(tableDetails_Open.tableName);
        Assertions.assertThat(dataTablesRestricted).extracting("tableTitle").doesNotContain(tableDetails_Sens.tableName);

        Assertions.assertThat(dataTablesOpen).extracting("tableTitle").contains(tableDetails_Open.tableName);
        Assertions.assertThat(dataTablesOpen).extracting("tableTitle").doesNotContain(tableDetails_Res.tableName);
        Assertions.assertThat(dataTablesOpen).extracting("tableTitle").doesNotContain(tableDetails_Sens.tableName);
    }

}
