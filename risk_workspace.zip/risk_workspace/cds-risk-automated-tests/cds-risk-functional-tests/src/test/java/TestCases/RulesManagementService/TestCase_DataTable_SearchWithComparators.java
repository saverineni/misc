package TestCases.RulesManagementService;


import API.DataForTests.TestDataTableModel;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.ViewDataTableList.ViewDataTableListResponse;
import Categories_CDSRisk.CDS_RM_DataTable;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.ArrayList;
import java.util.List;

import static API.DataForTests.DataTables.*;
import static API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject;

@Category({Rules_Management.class, CDS_RM_DataTable.class})
public class TestCase_DataTable_SearchWithComparators extends WebAPITestCaseWithDatatablesCleanup {

    @Before
    public void Setup() {

        dataTablesUtils.CreateDefaultDataTable();
    }

    @Test
    @Category(ChangeRequest.CR_1753.class)
    @Ignore("Will be fixed as part of CR-3194")
    public void WhenUsingEqualsOperatorWithCommodityCode_AllCommodityAndPartCommodityCodeTablesReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse1 = CreateDataTableAndGetResponseObject(tableDetails);
        String firstTableUuid = createDataTableResponse1.uuid;

        TestDataTableModel.TableDetails tableDetails1 = DataTable_CommodityCodes_Large();
        CreateDataTableResponse.PostResponse createDataTableResponse2 = CreateDataTableAndGetResponseObject(tableDetails1);
        String secondTableUuid = createDataTableResponse2.uuid;

        TestDataTableModel.TableDetails tableDetails3 = DataTable_PartCommodityCodes();
        CreateDataTableResponse.PostResponse createDataTableResponse3 = CreateDataTableAndGetResponseObject(tableDetails3);
        String thirdTableUuid = createDataTableResponse3.uuid;

        TestDataTableModel.TableDetails tableDetails4 = DataTable_FreeText_Valid();
        CreateDataTableAndGetResponseObject(tableDetails4);

        String dataTableSearchQuery = "?conditionField=commodityCode&conditionOperator=eq";

        //Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableResponse = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(dataTableSearchQuery);

        //Assert
        Assertions.assertThat(viewDataTableResponse.content).extracting("uuid")
                .contains(firstTableUuid, secondTableUuid, thirdTableUuid);
        Assertions.assertThat(viewDataTableResponse.totalElements)
                .isEqualTo(4);
    }

    @Test
    @Category(ChangeRequest.CR_1753.class)
    @Ignore("Will be fixed as part of CR-3194")
    public void WhenUsingNotEqualsOperatorWithCommodityCode_AllCommodityAndPartCommodityCodeTablesReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse1 = CreateDataTableAndGetResponseObject(tableDetails);
        String firstTableUuid = createDataTableResponse1.uuid;

        TestDataTableModel.TableDetails tableDetails1 = DataTable_CommodityCodes_Large();
        CreateDataTableResponse.PostResponse createDataTableResponse2 = CreateDataTableAndGetResponseObject(tableDetails1);
        String secondTableUuid = createDataTableResponse2.uuid;

        TestDataTableModel.TableDetails tableDetails3 = DataTable_PartCommodityCodes();
        CreateDataTableResponse.PostResponse createDataTableResponse3 = CreateDataTableAndGetResponseObject(tableDetails3);
        String thirdTableUuid = createDataTableResponse3.uuid;

        String dataTableSearchQuery = "?conditionField=commodityCode&conditionOperator=neq";

        //Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableResponse = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(dataTableSearchQuery);

        //Assert
        Assertions.assertThat(viewDataTableResponse.content).extracting("uuid")
                .contains(firstTableUuid, secondTableUuid, thirdTableUuid);
        Assertions.assertThat(viewDataTableResponse.totalElements)
                .isEqualTo(4);
    }

    @Test
    @Category(ChangeRequest.CR_1753.class)
    @Ignore("Will be fixed as part of CR-3194")
    public void WhenUsingOtherOperatorWithCommodityCode_OnlyPartCommodityAndPartCommodityCodeTablesReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_CommodityCodes_NAT();
        CreateDataTableAndGetResponseObject(tableDetails);

        TestDataTableModel.TableDetails tableDetails1 = DataTable_CommodityCodes_Large();
        CreateDataTableAndGetResponseObject(tableDetails1);

        TestDataTableModel.TableDetails tableDetails3 = DataTable_PartCommodityCodes();
        CreateDataTableResponse.PostResponse createDataTableResponse3 = CreateDataTableAndGetResponseObject(tableDetails3);
        String thirdTableUuid = createDataTableResponse3.uuid;

        List<String> dataTableQueries = new ArrayList<>();
        dataTableQueries.add("?conditionField=commodityCode&conditionOperator=con");
        dataTableQueries.add("?conditionField=commodityCode&conditionOperator=nco");
        dataTableQueries.add("?conditionField=commodityCode&conditionOperator=st");
        dataTableQueries.add("?conditionField=commodityCode&conditionOperator=nst");
        dataTableQueries.add("?conditionField=commodityCode&conditionOperator=matchesPattern");
        dataTableQueries.add("?conditionField=commodityCode&conditionOperator=notMatchesPattern");

        //Act
        for (String dataTableQuery : dataTableQueries) {
            ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableResponse = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(dataTableQuery);

            //Assert
            Assertions.assertThat(viewDataTableResponse.content).extracting("uuid").containsOnly(thirdTableUuid);
        }
    }

//Invalid Test
//    @Test
//    @Category(ChangeRequest.CR_1753.class)
//    public void WhenUsingDifferentComparatorsForDataTableSearch_OnlyFreeTextTablesAreReturned() throws Throwable {
//
//        log.info("\r\n" + "WhenUsingDifferentComparatorsForDataTableSearch_OnlyFreeTextTablesAreReturned" + "\r\n");
//
//        //Arrange
//        TestDataTableModel.TableDetails tableDetails1 = DataTable_FreeText_Valid();
//        CreateDataTableResponse.PostResponse createDataTableResponse1 = CreateDataTableAndGetResponseObject(tableDetails1);
//        String firstTableUuid = createDataTableResponse1.uuid;
//
//        TestDataTableModel.TableDetails tableDetails2 = DataTable_FreeText_Extra();
//        CreateDataTableResponse.PostResponse createDataTableResponse2 = CreateDataTableAndGetResponseObject(tableDetails2);
//        String secondTableUuid = createDataTableResponse2.uuid;
//
//        TestDataTableModel.TableDetails tableDetails3 = DataTable_PartCommodityCodes();
//        CreateDataTableAndGetResponseObject(tableDetails3);
//
//        //Use equals operator with ConsigneeAddress, ConsignorAddress, GoodsDescription
//        //currently these are the only ones supported - other may come in later
//        List<String> dataTableQueries = new ArrayList<>();
//        dataTableQueries.add("?conditionField=ConsigneeAddress&conditionOperator=st");
//        dataTableQueries.add("?conditionField=ConsignorAddress&conditionOperator=nst");
//        dataTableQueries.add("?conditionField=GoodsDescription&conditionOperator=matchesPattern");
//        dataTableQueries.add("?conditionField=GoodsDescription&conditionOperator=notMatchesPattern");
//        dataTableQueries.add("?conditionField=GoodsDescription&conditionOperator=con");
//        dataTableQueries.add("?conditionField=ConsignorAddress&conditionOperator=nco");
//        dataTableQueries.add("?conditionField=GoodsDescription&conditionOperator=neq");
//
//        //Assert
//        for (String dataTableQuery : dataTableQueries) {
//            ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableResponse = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(dataTableQuery);
//
//            Assertions.assertThat(viewDataTableResponse.content).extracting("uuid").contains(firstTableUuid, secondTableUuid);
//        }
//    }

    @Test
    @Category(ChangeRequest.CR_1753.class)
    public void WhenSearchingForDataTablesWithIncorrectParameters_ReturnsBadRequest() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_CommodityCodes_NAT();
        CreateDataTableAndGetResponseObject(tableDetails);

        TestDataTableModel.TableDetails tableDetails1 = DataTable_CommodityCodes_Large();
        CreateDataTableAndGetResponseObject(tableDetails1);

        List<String> dataTableQueries = new ArrayList<>();
        dataTableQueries.add("?conditionField=commodityCode&conditionOperator=");
        dataTableQueries.add("?conditionField=&conditionOperator=eq");


        for (String dataTableQuery : dataTableQueries) {
            ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableResponse = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(dataTableQuery);

            Assertions.assertThat(org.apache.http.HttpStatus.SC_BAD_REQUEST).isEqualTo(viewDataTableResponse.httpStatusCode);
        }

    }
}
