package TestCases.RiskingServiceJava.ActionType;


import TestCases.RiskingServiceJava.BaseRiskingServiceJava;
import lombok.Builder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel;
import uk.gov.hmrc.risk.test.common.enums.*;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleCreationModel;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleCreationModel.BehaviourContainer;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleCreationModel.JsonContainer;

import java.util.*;

@Slf4j
public class BaseActionTypeTest extends BaseRiskingServiceJava {
    protected static final String ASSIGNEE_ID = "nch_open_general_export_licence";

    protected Map<DeclarationParam, String> createDeclaration() {

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();
        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNEE_EORI, "NL000111222");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_TYPE, "EX");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "C");
        declarationFieldValues.put(HeaderDeclarationParam.TRANSPORT_MODE, TransportMode.All.toString());
        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNEE_TYPE, "EX");

        declarationFieldValues.put(GoodsItemDeclarationParam.SEQUENCE_NUMBER, "2001");
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.SEQUENCE_NUMBER, "2002");
        declarationFieldValues.put(GoodsItemDeclarationParam.Third.SEQUENCE_NUMBER, "2003");
        declarationFieldValues.put(GoodsItemDeclarationParam.Fourth.SEQUENCE_NUMBER, "2004");

        return declarationFieldValues;
    }

    protected void createRule(CreateRuleModel.RuleOutputs outputs) {
        CreateRuleModel model = createRuleModel();
        model.setRuleOutputs(outputs);

        model.setQueryOptions(CreateRuleModel.QueryOptions.builder()
                .declarationType(DeclarationType.EX.toString())
                .declarationSubTypes(Arrays.asList(DeclarationSubType.C.toString()))
                .transportMode(TransportMode.All.toString())
                .build());

        CreateRuleModel.Query query = CreateRuleModel.Query.builder()
                .attribute(HeaderDeclarationParam.CONSIGNEE_EORI.toString())
                .operator(Operator.eq.toString())
                .conditionType(ConditionType.normal.toString())
                .value("NL000111222")
                .build();

        model.getQuery().get(0).setQuery(Arrays.asList( query ));
        createAndRefreshRule(model);
    }

    protected ExpectedResult expectedPhysicalCheckHold() {
        return ExpectedResult.builder()
                .controlType(PHYSICAL_CHECK_CTRL_TYPE)
                .holdNarrative(HOLD_NARRATIVE)
                .blockRelease(true)
                .build();
    }

    protected ExpectedResult expectedDocCheckHold() {
        return ExpectedResult.builder()
                .controlType(DOCUMENT_CHECK_CTRL_TYPE)
                .holdNarrative(HOLD_NARRATIVE)
                .blockRelease(true)
                .build();
    }

    protected ExpectedResult expectedDocCheckRelease() {
        return ExpectedResult.builder()
                .controlType(DOCUMENT_CHECK_CTRL_TYPE)
                .releaseNarrative(RELEASE_NARRATIVE)
                .blockRelease(false)
                .build();
    }

    protected RuleCreationModel createARule(RuleDefinitionModel definitionModel, String description,
                                            String preClearanceCtrlType, String postClearanceCtrlType) {

        RuleCreationModel ruleCreationModel = baseRuleCreationModelBuilder().build();
        ruleCreationModel.setDefinition(definitionModel.toString());
        ruleCreationModel.setDescription(description);

        JsonContainer json = ruleCreationModel.getJson();
        json.setDescription(description);

        BehaviourContainer defaultBehaviour = BehaviourContainer.builder()
                .behaviourType(RuleBehaviourType.DEFAULT)
                .narrative(DEFAULT_NARRATIVE)
                .controlType(DEFAULT_CTRL_TYPE)
                .build();

        BehaviourContainer preBehaviour = BehaviourContainer.builder()
                .behaviourType(RuleBehaviourType.PRE_CLEARANCE)
                .narrative(PRE_CLEARANCE_NARRATIVE)
                .controlType(preClearanceCtrlType)
                .build();

        BehaviourContainer postBehaviour = BehaviourContainer.builder()
                .behaviourType(RuleBehaviourType.POST_CLEARANCE)
                .narrative(POST_CLEARANCE_NARRATIVE)
                .controlType(postClearanceCtrlType)
                .build();

        json.getBehaviours().set(0, defaultBehaviour);
        json.getBehaviours().set(1, preBehaviour);
        json.getBehaviours().set(2, postBehaviour);

        ruleCreationModel.setJson(json);

        return ruleCreationModel;
    }

    protected void assertDeclarationResponse( DeclarationResponse response, ExpectedResult expectedResult) {
        Assertions.assertThat( response.isBlockingRelease() ).isEqualTo(expectedResult.isBlockRelease());
        if (expectedResult.getHoldNarrative() != null)
        {
            Assertions.assertThat( response.getNarrativeText() ).isEqualTo(expectedResult.getHoldNarrative());
        }
        if (expectedResult.getReleaseNarrative() != null)
        {
            Assertions.assertThat( response.getNarrativeText() ).isEqualTo(expectedResult.getReleaseNarrative());
        }
        if (expectedResult.getInfoNarrative() != null)
        {
            Assertions.assertThat( response.getNarrativeText() ).isEqualTo(expectedResult.getInfoNarrative());
        }
        Assertions.assertThat( response.getControlType()).isEqualTo( expectedResult.getControlType());
    }

    @Builder
    @Data
    public static class ExpectedResult {
        private boolean blockRelease;
        private String holdNarrative, releaseNarrative, infoNarrative;
        private String controlType;
    }
}
