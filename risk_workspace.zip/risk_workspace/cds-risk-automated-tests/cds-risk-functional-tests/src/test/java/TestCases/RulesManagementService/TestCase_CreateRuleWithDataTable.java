package TestCases.RulesManagementService;


import API.DataForTests.*;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse.PostResponse;
import API.RulesManagementService.Data.ShareDataTable.ShareDataTableResponse;
import API.RulesManagementService.EditRule.EditRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.RuleAction.RuleActionResponse;
import API.RulesManagementService.Utils.RuleAtStatus;
import API.RulesManagementService.ViewRule.ViewRuleResponse;
import API.RulesManagementService.ViewRuleList.ViewRuleListResponse;
import API.RulesManagementService.ViewRuleVersion.ViewRuleVersionResponse.ViewRuleVersionResponseObject;
import Categories_CDSRisk.CDS_RM_CreateRules;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import FunctionsLibrary.DateTime;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import org.apache.http.HttpStatus;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.ConditionType;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import static API.DataForTests.DataTables.*;
import static API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject;
import static API.RulesManagementService.Utils.DataTables.archiveDataTable;
import static API.RulesManagementService.Utils.RuleAtStatus.CreateSuspendedRule;
import static API.RulesManagementService.Utils.Rules.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.datatable;

@Category({Rules_Management.class, CDS_RM_CreateRules.class})
public class TestCase_CreateRuleWithDataTable extends WebAPITestCaseWithDatatablesCleanup {

    @Test
    @Category(ChangeRequest.CR_826.class)
    public void whenRuleCreatedWithDataTable_RuleCreatedSuccessfully() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_CommodityCodes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "commodityCode";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = "0101210000";
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act
        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ViewRuleVersionResponseObject viewRuleVerResponse = GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, createRuleResponse.httpStatusCode);
        assertEquals("datatable", viewRuleVerResponse.query.get(0).query.get(0).conditionType);
    }

    @Test
    @Category(ChangeRequest.CR_826.class)
    public void whenRuleUpdatedToUseDataTable_NewRuleVersionCreatedSuccessfully() throws Throwable {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_CommodityCodes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "commodityCode";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = "0101210000";
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        EditRuleResponse.PutResponse editRule = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetails);

        ViewRuleVersionResponseObject viewRuleVerResponse = GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, 2);

        //Assert
        assertEquals(HttpStatus.SC_OK, editRule.httpStatusCode);
        assertEquals("datatable", "datatable", viewRuleVerResponse.query.get(0).query.get(0).conditionType);
    }


    @Test
    @Category(ChangeRequest.CR_826.class)
    public void whenRuleCreatedWith2DataTables_NewRuleVersionCreatedSuccessfully() throws Throwable {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_CommodityCodes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.Draft2ConditionsNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        ruleDetails.queryConditions.get(0).conditions.get(1).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(1).value = createDataTableResponse.uuid;

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleVersionResponseObject viewRuleVerResponse = GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, 1);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, createRuleResponse.httpStatusCode);
        assertEquals("datatable1", "datatable", viewRuleVerResponse.query.get(0).query.get(0).conditionType);
        assertEquals("datatable2", "datatable", viewRuleVerResponse.query.get(0).query.get(1).conditionType);
    }


    @Test
    @Category(ChangeRequest.CR_826.class)
    public void whenRuleCreatedWithDataTableAndValue_NewRuleVersionCreatedSuccessfully() throws Throwable {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_CommodityCodes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.Draft2ConditionsNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        ruleDetails.queryConditions.get(0).conditions.get(1).conditionType = ConditionType.normal;
        ruleDetails.queryConditions.get(0).conditions.get(1).value = "1234567890";
        ruleDetails.reason = "automated test";
        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleVersionResponseObject viewRuleVerResponse = GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, 1);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, createRuleResponse.httpStatusCode);
        assertEquals("datatable1", "datatable", viewRuleVerResponse.query.get(0).query.get(0).conditionType);
        assertEquals("normal", "normal", viewRuleVerResponse.query.get(0).query.get(1).conditionType);
    }


    @Test
    @Category(ChangeRequest.CR_1027.class)
    public void whenRuleCreatedWithLocalDataTable_RuleCreatedSuccessfully() throws Throwable {
        //Arrange
        TestUserModel.UserDetails udRuleManPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOO.pid);

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();

        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleVersionResponseObject viewRuleVerResponse = GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, 1);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, createRuleResponse.httpStatusCode);
        assertEquals("datatable", "datatable", viewRuleVerResponse.query.get(0).query.get(0).conditionType);
    }


    @Test
    @Category(ChangeRequest.CR_1027.class)
    public void whenRuleCreatedWithDataTableSharedForUsageWithSingleLocation_RuleCreatedSuccessfully() throws Throwable {
        //Arrange
        TestUserModel.UserDetails udRuleManPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOO.pid);

        TestDataTableModel.TableDetails tableSummary = DataTables.DataTable_CommodityCodes_POO();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableSummary);

        tableSummary.useTablesLocationUuids.clear();
        tableSummary.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableSummary.uuid = createDataTableResponse.uuid;

        tableSummary.creationShareType = TestEnumerators.ShareTypes.user.toString();
        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableSummary);

        TestUserModel.UserDetails udLOCRuleManagerEXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManagerEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManagerEXT.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_EXT();

        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleVersionResponseObject viewRuleVerResponse = GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, 1);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, createRuleResponse.httpStatusCode);
        assertEquals("datatable", "datatable", viewRuleVerResponse.query.get(0).query.get(0).conditionType);
    }


    @Test
    @Category(ChangeRequest.CR_1027.class)
    public void whenRuleCreatedWithDataTableSharedForUsageWithALLLocations_RuleCreatedSuccessfully() throws Throwable {
        //Arrange
        TestUserModel.UserDetails udRuleManPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOO.pid);

        TestDataTableModel.TableDetails tableSummary = DataTables.DataTable_CommodityCodes_POO();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableSummary);

        tableSummary.useTablesLocationUuids.clear();
        tableSummary.shareAllLocations = true;
        tableSummary.uuid = createDataTableResponse.uuid;

        tableSummary.creationShareType = TestEnumerators.ShareTypes.user.toString();
        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableSummary);

        TestUserModel.UserDetails udLOCRuleManagerEXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManagerEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManagerEXT.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_EXT();

        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleVersionResponseObject viewRuleVerResponse = GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, 1);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, createRuleResponse.httpStatusCode);
        assertEquals("datatable", "datatable", viewRuleVerResponse.query.get(0).query.get(0).conditionType);
    }


    @Test
    @Category(ChangeRequest.CR_1091.class)
    public void whenRuleCreatedWithDataTableSharedForOwnershipWithSingleLocation_RuleCreatedSuccessfully() throws Throwable {
        //Arrange
        TestUserModel.UserDetails udRuleManPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOO.pid);

        TestDataTableModel.TableDetails tableSummary = DataTables.DataTable_CommodityCodes_POO();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableSummary);

        tableSummary.useTablesLocationUuids.clear();
        tableSummary.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableSummary.uuid = createDataTableResponse.uuid;

        tableSummary.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableSummary);

        TestUserModel.UserDetails udLOCRuleManagerEXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManagerEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManagerEXT.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_EXT();

        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleVersionResponseObject viewRuleVerResponse = GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, 1);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, createRuleResponse.httpStatusCode);
        assertEquals("datatable", "datatable", viewRuleVerResponse.query.get(0).query.get(0).conditionType);
    }

    @Test
    @Category(ChangeRequest.CR_1091.class)
    public void whenRuleCreatedWithDataTableSharedForOwnershipWithALLLocations_RuleCreatedSuccessfully() throws Throwable {
        //Arrange
        TestUserModel.UserDetails udRuleManPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOO.pid);

        TestDataTableModel.TableDetails tableSummary = DataTables.DataTable_CommodityCodes_POO();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableSummary);

        tableSummary.useTablesLocationUuids.clear();
        tableSummary.shareAllLocations = true;
        tableSummary.uuid = createDataTableResponse.uuid;

        tableSummary.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        ShareDataTableResponse.ShareDataTableResponseObject shareDataTableResponseObject = API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableSummary);

        TestUserModel.UserDetails udLOCRuleManagerEXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManagerEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManagerEXT.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_EXT();

        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleVersionResponseObject viewRuleVerResponse = GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, 1);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, createRuleResponse.httpStatusCode);
        assertEquals("datatable", "datatable", viewRuleVerResponse.query.get(0).query.get(0).conditionType);
    }


    @Test
    @Category(ChangeRequest.CR_1714.class)
    public void whenRuleCreatedWithOperatorStartsWithUsingDataTable_RuleCreatedSuccessfully() throws Throwable {
        //Arrange
        TestDataTableModel.TableDetails tableSummary = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableSummary);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).operator = "st";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act
        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ViewRuleVersionResponseObject viewRuleVerResponse = GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, createRuleResponse.httpStatusCode);
        assertEquals("datatable", "datatable", viewRuleVerResponse.query.get(0).query.get(0).conditionType);
    }


    @Test
    @Category(ChangeRequest.CR_1714.class)
    public void whenRuleCreatedWithOperatorNotStartsWithUsingDataTable_RuleCreatedSuccessfully() throws Throwable {
        //Arrange
        TestDataTableModel.TableDetails tableSummary = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableSummary);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).operator = "nst";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act
        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ViewRuleVersionResponseObject viewRuleVerResponse = GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, createRuleResponse.httpStatusCode);
        assertEquals("datatable", "datatable", viewRuleVerResponse.query.get(0).query.get(0).conditionType);
    }

    @Test
    @Category(ChangeRequest.CR_1762.class)
    public void whenRuleCreatedWithOperatorContainsUsingDataTable_RuleCreatedSuccessfully() throws Throwable {
        //Arrange
        TestDataTableModel.TableDetails tableSummary = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableSummary);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).operator = "con";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act
        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ViewRuleVersionResponseObject viewRuleVerResponse = GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, createRuleResponse.httpStatusCode);
        assertEquals("datatable", "datatable", viewRuleVerResponse.query.get(0).query.get(0).conditionType);
    }

    @Test
    @Category(ChangeRequest.CR_1762.class)
    public void whenRuleCreatedWithOperatorNotContainsUsingDataTable_RuleCreatedSuccessfully() throws Throwable {
        //Arrange
        TestDataTableModel.TableDetails tableSummary = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableSummary);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).operator = "nco";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act
        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ViewRuleVersionResponseObject viewRuleVerResponse = GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, createRuleResponse.httpStatusCode);
        assertEquals("datatable", "datatable", viewRuleVerResponse.query.get(0).query.get(0).conditionType);
    }


    @Test
    @Category(ChangeRequest.CR_1847.class)
    public void whenRuleCreatedWithOperatorMatchesPatternUsingDataTable_RuleCreatedSuccessfully() throws Throwable {
        //Arrange
        TestDataTableModel.TableDetails tableSummary = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableSummary);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).operator = "matchesPattern";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act
        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ViewRuleVersionResponseObject viewRuleVerResponse = GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, createRuleResponse.httpStatusCode);
        assertEquals("datatable", "datatable", viewRuleVerResponse.query.get(0).query.get(0).conditionType);
    }

    @Test
    @Category(ChangeRequest.CR_1847.class)
    public void whenRuleCreatedWithOperatorNotMatchesPatternUsingDataTable_RuleCreatedSuccessfully() throws Throwable {
        //Arrange
        TestDataTableModel.TableDetails tableSummary = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableSummary);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).operator = "notMatchesPattern ";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act
        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ViewRuleVersionResponseObject viewRuleVerResponse = GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, createRuleResponse.httpStatusCode);
        assertEquals("datatable", "datatable", viewRuleVerResponse.query.get(0).query.get(0).conditionType);
    }

    @Test
    @Category(ChangeRequest.CR_1680.class)
    public void whenRuleListFilteredByDataTable_OnlyRuleWithMatchingDataTablePresentInRuleList() throws Throwable {
        //Arrange

        //Rule 1 - Table 1
        TestDataTableModel.TableDetails tableSummary = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableSummary);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Rule 2 - Table 2
        TestDataTableModel.TableDetails tableSummary2 = DataTable_FreeText_Valid();
        PostResponse createDataTableResponse2 = CreateDataTableAndGetResponseObject(tableSummary2);

        TestRuleModel.RuleDetails ruleDetails2 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails2.queryConditions.get(0).conditions.get(0).value = createDataTableResponse2.uuid;

        CreateRuleAndGetResponseObject(ruleDetails2);

        //Rule 3 - No Table
        TestRuleModel.RuleDetails ruleDetails3 = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleAndGetResponseObject(ruleDetails3);

        //Act
        //List Rules with Table 1
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = GetListOfRulesWithDataTableID(createDataTableResponse.uuid);

        //Assert
        ViewRuleListResponse.AssertViewRuleListResponse(ruleDetails, ruleList);
    }

    @Test
    @Category(ChangeRequest.CR_1680.class)
    public void whenRuleListFilteredByDataTable_AllRulesWithMatchingDataTablePresentInRuleList() throws Throwable {
        //Arrange

        //Rule 1 - Table 1
        TestDataTableModel.TableDetails tableSummary = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableSummary);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Rule 2 - Table 2
        TestRuleModel.RuleDetails ruleDetails2 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails2.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails2.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        CreateRuleResponse.PostResponse createRuleResponse2 = CreateRuleAndGetResponseObject(ruleDetails2);
        ruleDetails2.uniqueID = createRuleResponse2.uniqueId;

        //Act
        //List Rules with Table 1
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = GetListOfRulesWithDataTableID(createDataTableResponse.uuid);

        //Assert
        Assert.assertEquals("Expect 2 Rules with data table usage", 2, ruleList.content.size());
        ViewRuleListResponse.AssertViewRuleListResponse(ruleDetails, ruleList);
        ViewRuleListResponse.AssertViewRuleListResponse(ruleDetails2, ruleList);
    }


    @Test
    @Category(ChangeRequest.CR_2127.class)
    public void whenRuleCreatedWith2DataTables_RuleShowsLinkedDataTables() {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestDataTableModel.TableDetails tableDetails2 = DataTable_CommodityCodes_POO();
        PostResponse createDataTableResponse2 = CreateDataTableAndGetResponseObject(tableDetails2);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.Draft2ConditionsNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        ruleDetails.queryConditions.get(0).conditions.get(1).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(1).value = createDataTableResponse2.uuid;

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponseObject = GetRuleByUID(createRuleResponse.uniqueId);

        //Assert
        assertThat(viewRuleResponseObject.leadVersion.dataTableUuids)
                .containsOnly(createDataTableResponse.uuid, createDataTableResponse2.uuid);
    }


    @Test
    @Category(ChangeRequest.CR_2269.class)
    public void whenRuleUpdatedToNotUseDataTable_RuleDoesNotShowLinkedDataTable() throws Throwable {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = "0100000999";

        EditRuleResponse.PutResponse editRule = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponseObject = GetRuleByUID(createRuleResponse.uniqueId);

        ViewRuleListResponse.ViewRuleListResponseObject ruleList = GetListOfRulesWithDataTableID(createDataTableResponse.uuid);

        //Assert
        assertThat(viewRuleResponseObject.leadVersion.dataTableUuids)
                .doesNotContain(createDataTableResponse.uuid);

        assertThat(ruleList.content.get(0).dataTableUuids).isEmpty();
    }

    @Test
    @Category(ChangeRequest.CR_2127.class)
    public void whenPendingRuleCreatedWithDataTables_SearchContainsRulesLinkedToDatatable() {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(1, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(3, DateTime.DateTimeUTCZ);

        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        EditRuleVersionResponse.PutResponse createRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponseObject = GetRuleByUID(createRuleResponse.uniqueId);

        ViewRuleListResponse.ViewRuleListResponseObject ruleList = GetListOfRulesWithDataTableID(createDataTableResponse.uuid);

        //Assert
        assertThat(viewRuleResponseObject.leadVersion.dataTableUuids).containsOnly(createDataTableResponse.uuid);
        assertThat(ruleList.content).extracting("uniqueId").contains(ruleDetails.uniqueID);
    }


    @Ignore("Note this will be covered by a new story to be raised by Sarah")
    @Test
    @Category(ChangeRequest.CR_2127.class)
    public void whenPendingRuleHasDataTableAndLeadVersionDoesNot_RuleShowsLinkedDataTables() {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        //v1 pending with data table
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(10, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(12, DateTime.DateTimeUTCZ);

        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        EditRuleVersionResponse.PutResponse createRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        //v2 lead version no data table
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-1, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(5, DateTime.DateTimeUTCZ);

        ruleDetails.queryConditions.get(0).conditions.get(0).isDataTable = false;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = "UK";
        API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetails);

        ruleDetails.version = 2;
        API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails, RuleVersionActions.commit);

        publishAndWait(5000);

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponseObject = GetRuleByUID(createRuleResponse.uniqueId);

        ViewRuleListResponse.ViewRuleListResponseObject ruleList = GetListOfRulesWithDataTableID(createDataTableResponse.uuid);

        //Assert
        assertThat(viewRuleResponseObject.leadVersion.dataTableUuids).doesNotContain(createDataTableResponse.uuid);
        assertThat(ruleList.content).flatExtracting("dataTableUuids").contains(createDataTableResponse.uuid);
    }

    @Test
    @Category(ChangeRequest.CR_2127.class)
    public void whenActiveRuleCreatedWithDataTables_SearchContainsRulesLinkedToDatatable() {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        EditRuleVersionResponse.PutResponse createRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateActiveRule(ruleDetails);

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponseObject = GetRuleByUID(createRuleResponse.uniqueId);

        ViewRuleListResponse.ViewRuleListResponseObject ruleList = GetListOfRulesWithDataTableID(createDataTableResponse.uuid);

        //Assert
        assertThat(viewRuleResponseObject.leadVersion.dataTableUuids).containsOnly(createDataTableResponse.uuid);
        assertThat(ruleList.content).extracting("uniqueId").contains(ruleDetails.uniqueID);
    }

    @Test
    @Category(ChangeRequest.CR_2269.class)
    public void whenDraftRuleCreatedWithDataTables_SearchContainsRulesLinkedToDatatable() {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);


        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponseObject = GetRuleByUID(createRuleResponse.uniqueId);

        ViewRuleListResponse.ViewRuleListResponseObject ruleList = GetListOfRulesWithDataTableID(createDataTableResponse.uuid);

        //Assert
        assertThat(viewRuleResponseObject.leadVersion.dataTableUuids).containsOnly(createDataTableResponse.uuid);
        assertThat(ruleList.content).extracting("uniqueId").contains(ruleDetails.uniqueID);
    }


    @Test
    @Category(ChangeRequest.CR_2269.class)
    public void whenSuspendedRuleCreatedWithDataTables_SearchContainsRulesLinkedToDatatable() {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        RuleActionResponse.PostResponse createRuleResponse = CreateSuspendedRule(ruleDetails);

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponseObject = GetRuleByUID(createRuleResponse.uniqueId);

        ViewRuleListResponse.ViewRuleListResponseObject ruleList = GetListOfRulesWithDataTableID(createDataTableResponse.uuid);

        //Assert
        assertThat(viewRuleResponseObject.leadVersion.dataTableUuids).containsOnly(createDataTableResponse.uuid);
        assertThat(ruleList.content).extracting("uniqueId").contains(ruleDetails.uniqueID);
    }

    @Test
    @Category(ChangeRequest.CR_2269.class)
    public void whenExpiredRuleCreatedWithDataTables_RuleDoesNotShowsLinkedDataTables() {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        RuleAtStatus.CreatePendingExpiredRuleVersion(ruleDetails, -2, -1);
        publishAndWait(5000);

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = GetListOfRulesWithDataTableID(createDataTableResponse.uuid);

        //Assert
        assertThat(ruleList.content).isEmpty();
    }

    @Test
    @Category(ChangeRequest.CR_2269.class)
    public void whenRuleWithMultipleVersionsAndDataTablesExpired_RuleShowsLinkedDataTables() {
        //V1 Draft. V2 Expired. but potentially new version could be created in future hence data table is visible

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        //create draft rule with data table
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        CreateRuleResponse.PostResponse response1 = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response1.uniqueId;

        //create new pending expired version
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-2, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-1, DateTime.DateTimeUTCZ);

        API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetails);

        ruleDetails.version = 2;
        API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails, RuleVersionActions.commit);

        publishAndWait(5000);

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = GetListOfRulesWithDataTableID(createDataTableResponse.uuid);

        //Assert
        assertThat(ruleList.content).extracting("uniqueId").contains(ruleDetails.uniqueID);
    }

    @Test
    @Category(ChangeRequest.CR_2269.class)
    public void whenArchivedRuleCreatedWithDataTables_RuleDoesNotShowsLinkedDataTables() {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        RuleAtStatus.CreateArchivedRule(ruleDetails);

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = GetListOfRulesWithDataTableID(createDataTableResponse.uuid);

        //Assert
        assertThat(ruleList.content).isEmpty();
    }


    @Ignore("Note this will be covered by a new story to be raised by Sarah")
    @Test
    @Category(ChangeRequest.CR_2269.class)
    public void whenRuleWithMultipleVersionsAndDataTablesArchived_RuleDoesNotShowsLinkedDataTables() {
        //v1 Draft.  v2 Archived. Should not show data table in rule usage as rule can not be reinstated.

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response.uniqueId;

        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetails, 2);
        ruleDetails.version = 2;

        ArchiveRule(ruleDetails);

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = GetListOfRulesWithDataTableID(createDataTableResponse.uuid);

        //Assert
        assertThat(ruleList.content).isEmpty();
    }


    @Test
    @Category(ChangeRequest.CR_2269.class)
    public void whenDeletedRuleCreatedWithDataTables_RuleDoesNotShowsLinkedDataTables() {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        RuleAtStatus.CreateDeletedRule(ruleDetails);

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = GetListOfRulesWithDataTableID(createDataTableResponse.uuid);

        //Assert
        assertThat(ruleList.content).isEmpty();
    }

    @Test
    @Category(ChangeRequest.CR_3002.class)
    public void ruleCannotBeCreatedUsingArchivedDataTable() {
        TestDataTableModel.TableDetails tableDetails = DataTable_FreeTextCountryCddes_NAT();
        PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        String tableUuid = createDataTableResponse.uuid;
        archiveDataTable(tableUuid, tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        TestRuleModel.RuleDetails.Condition condition = ruleDetails.queryConditions.get(0).conditions.get(0);
        condition.conditionType = ConditionType.datatable;
        condition.value = tableUuid;

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);

        assertThat(createRuleResponse.httpStatusCode).isEqualTo(HttpStatus.SC_BAD_REQUEST);
    }

}
