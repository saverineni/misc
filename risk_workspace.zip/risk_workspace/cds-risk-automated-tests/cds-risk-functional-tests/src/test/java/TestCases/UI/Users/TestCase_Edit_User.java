package TestCases.UI.Users;


import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Users;
import Categories_CDSRisk.CDS_Risk_UI_Users_2;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.Pages.UserManagement.EditUserDetails_Page;
import UI.Pages.UserManagement.ListUsers_Page;
import UI.Pages.UserManagement.UserDetails_Page;
import UI.Utils.Navigation;
import org.assertj.core.api.Assertions;
import org.junit.Assert;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static FunctionsLibrary.DateTime.DateTimeUTCZ;
import static org.assertj.core.api.Assertions.tuple;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Users.class, CDS_Risk_UI_Users_2.class})
public class TestCase_Edit_User extends BaseUIWebDriverTestCase {

    @Category({ChangeRequest.CR_1903.class,ChangeRequest.CR_3329.class })
    @Test
    public void WhenNationalAdminUserRemovesLocalRuleManagerUserPermissions_UserPermissionsUpdatedSuccessfully(){

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        TestUserModel.UserDetails UserDetailsPooExt = Users_API.RulesManagerLocal_POO_EXT("1234532");
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetailsPooExt);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsAdmin);

        Navigation utilNavigation = new Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);

        UserDetails_Page userDetails_page = listUsers_page.clickUserByPID(UserDetailsPooExt.pid);

        EditUserDetails_Page editUserDetails_page = userDetails_page.clickEditUser();

        //Act
        List<EditUserDetails_Page.CustomRolesTableObject> customRolesAfter = editUserDetails_page.removePermissionFromCustomRolesTable("POO - Poole");

        //Assert
        assertEquals("Expect 1 Custom Role", 1, customRolesAfter.size());
        assertEquals("Expect Custom Location: EXT - Exeter Airport", "EXT - Exeter Airport", customRolesAfter.get(0).location.toString());
        assertEquals("Expect Custom Location: LocalRuleManager", "LocalRuleManager", customRolesAfter.get(0).customsRole.toString());
    }

    @Category({ChangeRequest.CR_1903.class, ChangeRequest.CR_3329.class})
    @Test
    public void WhenNationalAdminUserAddsLocalRuleManagerUserPermissions_UserPermissionsUpdatedSuccessfully(){

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        TestUserModel.UserDetails UserDetailsPooExt = Users_API.RulesManagerLocal_POO_EXT("1234532");
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetailsPooExt);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsAdmin);

        Navigation utilNavigation = new Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);

        UserDetails_Page userDetails_page = listUsers_page.clickUserByPID(UserDetailsPooExt.pid);

        EditUserDetails_Page editUserDetails_page = userDetails_page.clickEditUser();

        //Act
        List<EditUserDetails_Page.CustomRolesTableObject> customRolesAfter = editUserDetails_page.addCustomRoleLocationToCustomsRoleTable("POO - Poole", "LocalRuleViewer");

        //Assert
        Assertions.assertThat(customRolesAfter).extracting("location", "customsRole")
                .hasSize(3)
                .containsOnly(
                        tuple("EXT - Exeter Airport", "LocalRuleManager"),
                        tuple("POO - Poole", "LocalRuleManager"),
                        tuple("POO - Poole", "LocalRuleViewer")
                );
    }

    @Category({ChangeRequest.CR_1903.class,ChangeRequest.CR_3329.class})
    @Test
    public void AttemptToRemovePermissionWhenOnlyOnePermissionExistsForUser(){

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        TestUserModel.UserDetails UserDetailsPoo = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetailsPoo);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsAdmin);

        Navigation utilNavigation = new Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);
        listUsers_page.waitForAngularRequestsToFinish();
        UserDetails_Page userDetails_page = listUsers_page.clickUserByPID(UserDetailsPoo.pid);
        listUsers_page.waitForAngularRequestsToFinish();

        EditUserDetails_Page editUserDetails_page = userDetails_page.clickEditUser();

        //Act
        List<EditUserDetails_Page.CustomRolesTableObject> customRolesBefore = editUserDetails_page.getCustomRoles();
        customRolesBefore.get(0).removeLink.click();

        List<EditUserDetails_Page.CustomRolesTableObject> customRolesAfter = editUserDetails_page.getCustomRoles();

        //Assert
        assertEquals("Expect 1 Custom Role", 1, customRolesAfter.size());
        assertEquals("Expect Custom Location: POO - Poole", "POO - Poole", customRolesAfter.get(0).location.toString());
    }

    @Category({ChangeRequest.CR_1903.class,ChangeRequest.CR_3329.class})
    @Test
    public void WhenUserRemovesPermissionsAndCancels_ChangesNotSavedForUser(){

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        TestUserModel.UserDetails UserDetailsPooExt = Users_API.RulesManagerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetailsPooExt);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsAdmin);

        Navigation utilNavigation = new Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);

        UserDetails_Page userDetails_page = listUsers_page.clickUserByPID(UserDetailsPooExt.pid);

        EditUserDetails_Page editUserDetails_page = userDetails_page.clickEditUser();

        //Act
        List<EditUserDetails_Page.CustomRolesTableObject> customRolesBefore = editUserDetails_page.getCustomRoles();
        customRolesBefore.get(0).removeLink.click();

        List<EditUserDetails_Page.CustomRolesTableObject> customRolesAfterCancel = editUserDetails_page.getCustomRoles();

        //Assert
        assertEquals("Expect 2 Custom Role", 2, customRolesAfterCancel.size());
    }

    @Category({ChangeRequest.CR_2225.class, ChangeRequest.CR_2628.class, ChangeRequest.CR_2245.class, ChangeRequest.CR_1426.class,ChangeRequest.CR_2244.class,ChangeRequest.CR_3329.class})
    @Test
    public void WhenUserDetailsEdited_UserDetailsUpdatedSuccessfully(){

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(userDetailsAdmin);

        TestUserModel.UserDetails UserDetailsPooExt = Users_API.RulesManagerLocal_POO_EXT("1234532");
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetailsPooExt);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsAdmin);

        Navigation utilNavigation = new Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);

        UserDetails_Page userDetails_page = listUsers_page.clickUserByPID(UserDetailsPooExt.pid);
        listUsers_page.waitForAngularRequestsToFinish();

        EditUserDetails_Page editUserDetails_page = userDetails_page.clickEditUser();

        String redactedUserNotchecked = editUserDetails_page.redacted.getAttribute("checked");

        //Act
        UserDetailsPooExt.alternativeEmail = "Mark@hmrc.gsi.gov.uk";
        UserDetailsPooExt.alternativeEmailUserName = "mark.davis";
        UserDetailsPooExt.alternativeEmailDomain = "hmrc.gsi.gov.uk";
        UserDetailsPooExt.mobileNumber = "07912312312";
        UserDetailsPooExt.jobTitle = "Supervisor";
        UserDetailsPooExt.emailAddress = "mark.davis@hmrc.gsi.gov.uk";

        UserDetailsPooExt.scClearanceLevel = "SC - Security Check";
        UserDetailsPooExt.scClearanceExpiryDate = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(1, DateTimeUTCZ);;
        UserDetailsPooExt.scValidated = true;
        UserDetailsPooExt.redacted=true;

        utilUsers.EditCDSRiskUIUser(UserDetailsPooExt);

        editUserDetails_page.selectCustomRole("LocalRuleViewer");
        editUserDetails_page.selectCustomLocation("POO - Poole");
        editUserDetails_page.add.click();
        editUserDetails_page.waitForAngularRequestsToFinish();

        editUserDetails_page.update.click();
        editUserDetails_page.waitForAngularRequestsToFinish();
        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);

        String reasonText = "Editing User";
        dialog_confirm.EnterReasonAndCloseDialogBox(reasonText);
        dialog_confirm.waitForAngularRequestsToFinish();
        dialog_confirm.clickOKButton();
        dialog_confirm.waitForAngularRequestsToFinish();
        editUserDetails_page.backToUser.click();
        List<UserDetails_Page.CustomRolesTableObject> customRolesAfter = userDetails_page.getCustomRoles();

        Assertions.assertThat(customRolesAfter).extracting("location", "customsRole")
                .hasSize(3)
                .containsOnly(
                               tuple("EXT - Exeter Airport", "LocalRuleManager"),
                               tuple("POO - Poole", "LocalRuleManager"),
                               tuple("POO - Poole", "LocalRuleViewer")
                );
        UI.ElementControls.DropDown dropDown = new UI.ElementControls.DropDown(driver);

        userDetails_page = new UserDetails_Page(driver);
        userDetails_page.scrollToViewUserDetails();
        Assert.assertEquals(UserDetailsPooExt.jobTitle, userDetails_page.customsJobTitle.getText());
        Assert.assertEquals(UserDetailsPooExt.mobileNumber, userDetails_page.mobileNumber.getText());
        Assert.assertEquals(UserDetailsPooExt.emailAddress, userDetails_page.emailAddress.getText());
        assertNull(redactedUserNotchecked);
        Assert.assertEquals("Redacted", userDetails_page.redacted.getText());

        userDetails_page.waitForAngularRequestsToFinish();
        List<UserDetails_Page.HistoryTableObject> history = userDetails_page.getHistory();

        Assertions.assertThat(history).extracting("changeAuthor", "changeType", "reason")
                .hasSize(2)
                .contains(tuple(userDetailsAdmin.getFullName(), "Edit User", reasonText))
                .contains(tuple(Users_API.DefaultSuperAdminUser().getFullName(), "Creation", "User created"));
    }
}
