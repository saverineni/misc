package TestCases.RulesManagementService;


import API.DataForTests.Locations;
import API.DataForTests.TestEnumerators;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.UsersMeResponseObject;
import API.RulesManagementService.Users.UserHistory.UserHistoryResponse;
import API.RulesManagementService.Users.ViewUserDetails.ViewUserDetailsResponse;
import API.RulesManagementService.Utils.Users;
import Categories_CDSRisk.CDS_RM_UserManagement;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import FunctionsLibrary.DateTime;
import FunctionsLibrary.FileUtilities;
import TestCases.BaseWebAPITestCase;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.assertj.core.api.Assertions;
import org.assertj.core.groups.Tuple;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static org.assertj.core.api.Assertions.tuple;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_UserManagement.class})
public class TestCase_UserManagement_EditUser extends BaseWebAPITestCase {

    @Test
    @Category(ChangeRequest.CR_1903.class)
    public void WhenSuperAdminEditsAdminUserAndCustomRoleRemoved_UserEditedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails = Users_API.SuperAdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        TestUserModel.LocationRoles removedLocations = new TestUserModel.LocationRoles();
        removedLocations.locationNameUuid = Locations.Location_POO_UID;
        removedLocations.locationName = "POO";
        removedLocations.roleName = TestEnumerators.UserRoles.LocalSuperAdmin.name();
        userDetails.removeLocationRoles.add(removedLocations);

        UsersMeResponseObject usersMeResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = usersMeResponseObject1.opLockVersion;
        userDetails.reason = "Editing User";
        Response response = API.RulesManagementService.Utils.Users.EditUser(userDetails);

        UsersMeResponseObject usersMeResponseObject = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);

        //Assert
        assertEquals(HttpStatus.SC_NO_CONTENT, response.statusCode());

        Assertions.assertThat(usersMeResponseObject.roles).extracting("locationName")
                .containsOnly("EXT");
    }


    @Test
    @Category(ChangeRequest.CR_1903.class)
    public void WhenSuperAdminEditsSuperAdminUser_UserEditedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        TestUserModel.LocationRoles removedLocations = new TestUserModel.LocationRoles();
        removedLocations.locationNameUuid = Locations.Location_POO_UID;
        removedLocations.locationName = "POO";
        removedLocations.roleName = TestEnumerators.UserRoles.LocalSuperAdmin.name();
        userDetails.removeLocationRoles.add(removedLocations);

        UsersMeResponseObject usersMeResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = usersMeResponseObject1.opLockVersion;
        userDetails.reason = "Editing User";
        Response response = API.RulesManagementService.Utils.Users.EditUser(userDetails);

        UsersMeResponseObject usersMeResponseObject = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);

        //Assert
        assertEquals(HttpStatus.SC_NO_CONTENT, response.statusCode());

        Assertions.assertThat(usersMeResponseObject.roles).extracting("locationName")
                .hasSize(0);
    }


    @Test
    @Category(ChangeRequest.CR_1903.class)
    public void WhenAdminEditsAdminUser_UserEditedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminLocal_POO_EXT());

        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        TestUserModel.LocationRoles removedLocations = new TestUserModel.LocationRoles();
        removedLocations.locationNameUuid = Locations.Location_POO_UID;
        removedLocations.locationName = "POO";
        removedLocations.roleName = TestEnumerators.UserRoles.LocalAdmin.name();
        userDetails.removeLocationRoles.add(removedLocations);

        UsersMeResponseObject usersMeResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = usersMeResponseObject1.opLockVersion;
        userDetails.reason = "Editing User";
        Response response = API.RulesManagementService.Utils.Users.EditUser(userDetails);

        UsersMeResponseObject usersMeResponseObject = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);

        //Assert
        assertEquals(HttpStatus.SC_NO_CONTENT, response.statusCode());

        Assertions.assertThat(usersMeResponseObject.roles).extracting("locationName")
                .hasSize(0);
    }


    @Test
    @Category(ChangeRequest.CR_1903.class)
    public void WhenAdminEditsRulesManagerUser_UserEditedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminLocal_POO_EXT());

        TestUserModel.UserDetails userDetails = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        TestUserModel.LocationRoles removedLocations = new TestUserModel.LocationRoles();
        removedLocations.locationNameUuid = Locations.Location_POO_UID;
        removedLocations.locationName = "POO";
        removedLocations.roleName = TestEnumerators.UserRoles.LocalRuleManager.name();
        userDetails.removeLocationRoles.add(removedLocations);

        UsersMeResponseObject usersMeResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = usersMeResponseObject1.opLockVersion;
        userDetails.reason = "Editing User";
        Response response = API.RulesManagementService.Utils.Users.EditUser(userDetails);

        UsersMeResponseObject usersMeResponseObject = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);

        //Assert
        assertEquals(HttpStatus.SC_NO_CONTENT, response.statusCode());

        Assertions.assertThat(usersMeResponseObject.roles).extracting("locationName")
                .hasSize(0);
    }



    @Test
    @Category(ChangeRequest.CR_1903.class)
    public void WhenAdminEditsRulesViewerUser_UserEditedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminLocal_POO_EXT());

        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        TestUserModel.LocationRoles removedLocations = new TestUserModel.LocationRoles();
        removedLocations.locationNameUuid = Locations.Location_POO_UID;
        removedLocations.locationName = "POO";
        removedLocations.roleName = TestEnumerators.UserRoles.LocalRuleViewer.name();
        userDetails.removeLocationRoles.add(removedLocations);

        UsersMeResponseObject usersMeResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = usersMeResponseObject1.opLockVersion;
        userDetails.reason = "Editing User";
        Response response = API.RulesManagementService.Utils.Users.EditUser(userDetails);

        UsersMeResponseObject usersMeResponseObject = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);

        //Assert
        assertEquals(HttpStatus.SC_NO_CONTENT, response.statusCode());

        Assertions.assertThat(usersMeResponseObject.roles).extracting("locationName")
                .hasSize(0);
    }


    @Test
    @Category(ChangeRequest.CR_1903.class)
    public void WhenCustomRoleAddedToUser_UserEditedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails = Users_API.SuperAdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        TestUserModel.LocationRoles addLocation = new TestUserModel.LocationRoles();
        addLocation.locationNameUuid = Locations.Location_BOS_UID;
        addLocation.locationName = "BOS";
        addLocation.roleName = TestEnumerators.UserRoles.LocalSuperAdmin.name();
        userDetails.additionalLocationRoles.add(addLocation);

        UsersMeResponseObject usersMeResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = usersMeResponseObject1.opLockVersion;
        userDetails.reason = "Editing User";
        API.RulesManagementService.Utils.Users.EditUser(userDetails);

        UsersMeResponseObject usersMeResponseObject = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);

        //Assert
        Assertions.assertThat(usersMeResponseObject.roles).extracting("locationName")
                .hasSize(3)
                .containsOnly("POO", "EXT", "BOS");
    }


    @Test
    @Category(ChangeRequest.CR_1903.class)
    @Ignore("Will be fixed as part of CR-3392")
    public void WhenCustomRoleModifiedForUser_UserEditedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.SuperAdminLocal_POO_EXT());

        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminLocal_POO_EXT());

        TestUserModel.UserDetails userDetails = Users_API.RulesManagerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);


        //Act
        TestUserModel.LocationRoles removedLocations = new TestUserModel.LocationRoles();
        removedLocations.locationNameUuid = Locations.Location_POO_UID;
        removedLocations.locationName = "POO";
        removedLocations.roleName = TestEnumerators.UserRoles.LocalRuleManager.name();
        userDetails.removeLocationRoles.add(removedLocations);

        TestUserModel.LocationRoles addLocation = new TestUserModel.LocationRoles();
        addLocation.locationNameUuid = Locations.Location_POO_UID;
        addLocation.locationName = "POO";
        addLocation.roleName = TestEnumerators.UserRoles.LocalRuleViewer.name();
        userDetails.additionalLocationRoles.add(addLocation);

        UsersMeResponseObject usersMeResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = usersMeResponseObject1.opLockVersion;
        userDetails.reason = "Editing User";
        API.RulesManagementService.Utils.Users.EditUser(userDetails);

        UsersMeResponseObject usersMeResponseObject = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);

        //Assert
        Assertions.assertThat(usersMeResponseObject.roles).extracting("locationName")
                .hasSize(2)
                .containsOnly("POO", "EXT");

        Assertions.assertThat(usersMeResponseObject.roles).extracting("roleName")
                .hasSize(2)
                .containsOnly("LocalRuleManager", "LocalRuleViewer");
    }


    @Test
    @Category(ChangeRequest.CR_1903.class)
    public void WhenUserRemoves1CustomRoleLocation_Only1CustomRoleLocationRemovedFromUser() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
        TestUserModel.UserDetails userDetails = Users_API.SuperAdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        TestUserModel.LocationRoles removedLocations = new TestUserModel.LocationRoles();
        removedLocations.locationNameUuid = Locations.Location_POO_UID;
        removedLocations.locationName = "POO";
        removedLocations.roleName = TestEnumerators.UserRoles.LocalSuperAdmin.name();
        userDetails.removeLocationRoles.add(removedLocations);

        UsersMeResponseObject usersMeResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = usersMeResponseObject1.opLockVersion;
        userDetails.reason = "Editing User";
        Response response = API.RulesManagementService.Utils.Users.EditUser(userDetails);

        UsersMeResponseObject usersMeResponseObject = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);

        //Assert
        assertEquals(HttpStatus.SC_NO_CONTENT, response.statusCode());

        Assertions.assertThat(usersMeResponseObject.roles)
                .hasSize(1)
                .extracting("locationName", "roleName")
                .doesNotContain(tuple("POO", "LocalSuperAdmin"));
    }

    @Test
    @Category(ChangeRequest.CR_1903.class)
    public void AttemptToRemoveCustomRolePermissionWhichDoesNotExistForUser_NoChangesMadeToUser() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        TestUserModel.LocationRoles removedLocations = new TestUserModel.LocationRoles();
        removedLocations.locationNameUuid = Locations.Location_POO_UID;
        removedLocations.locationName = "POO";
        removedLocations.roleName = TestEnumerators.UserRoles.Admin.name(); //User is actually Local POO Admin, NOT national admin role
        userDetails.removeLocationRoles.add(removedLocations);

        UsersMeResponseObject usersMeResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = usersMeResponseObject1.opLockVersion;
        userDetails.reason = "Editing User";
        Response response = API.RulesManagementService.Utils.Users.EditUser(userDetails);

        UsersMeResponseObject usersMeResponseObject = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);

        //Assert
        assertEquals(HttpStatus.SC_NO_CONTENT, response.statusCode());

        Assertions.assertThat(usersMeResponseObject.roles).extracting("locationName")
                .containsOnly("EXT", "POO");
    }


    @Test
    @Category(ChangeRequest.CR_1903.class)
    public void AttemptToRemoveCustomRoleLocationWhichDoesNotExistForUser_NoChangesMadeToUser() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails = Users_API.SuperAdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        TestUserModel.LocationRoles removedLocations = new TestUserModel.LocationRoles();
        removedLocations.locationNameUuid = Locations.Location_BOS_UID;
        removedLocations.locationName = "BOS";
        removedLocations.roleName = TestEnumerators.UserRoles.LocalSuperAdmin.name();
        userDetails.removeLocationRoles.add(removedLocations);

        UsersMeResponseObject usersMeResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = usersMeResponseObject1.opLockVersion;
        userDetails.reason = "Editing User";
        Response response = API.RulesManagementService.Utils.Users.EditUser(userDetails);

        UsersMeResponseObject usersMeResponseObject = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);

        //Assert
        assertEquals(HttpStatus.SC_NO_CONTENT, response.statusCode());

        Assertions.assertThat(usersMeResponseObject.roles).extracting("locationName")
                .containsOnly("EXT", "POO");
    }


    @Test
    @Category(ChangeRequest.CR_1903.class)
    public void AttemptToModifyCustomRoleForRuleManagerAsSuperAdmin_NoChangesMadeToUser() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        TestUserModel.LocationRoles removedLocations = new TestUserModel.LocationRoles();
        removedLocations.locationNameUuid = Locations.Location_POO_UID;
        removedLocations.locationName = "POO";
        removedLocations.roleName = TestEnumerators.UserRoles.LocalRuleManager.name();
        userDetails.removeLocationRoles.add(removedLocations);

        UsersMeResponseObject usersMeResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = usersMeResponseObject1.opLockVersion;
        userDetails.reason = "Editing User";
        Response response = API.RulesManagementService.Utils.Users.EditUser(userDetails);

        UsersMeResponseObject usersMeResponseObject = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);

        //Assert
        assertEquals(HttpStatus.SC_FORBIDDEN, response.statusCode());

        Assertions.assertThat(usersMeResponseObject.roles).extracting("locationName")
                .containsOnly("POO");
    }


    @Test
    @Category(ChangeRequest.CR_1903.class)
    public void AttemptToModifyCustomRoleForRuleViewerAsSuperAdmin_NoChangesMadeToUser() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        TestUserModel.LocationRoles removedLocations = new TestUserModel.LocationRoles();
        removedLocations.locationNameUuid = Locations.Location_POO_UID;
        removedLocations.locationName = "POO";
        removedLocations.roleName = TestEnumerators.UserRoles.LocalRuleViewer.name();
        userDetails.removeLocationRoles.add(removedLocations);

        UsersMeResponseObject usersMeResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = usersMeResponseObject1.opLockVersion;
        userDetails.reason = "Editing User";
        Response response = API.RulesManagementService.Utils.Users.EditUser(userDetails);

        UsersMeResponseObject usersMeResponseObject = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);

        //Assert
        assertEquals(HttpStatus.SC_FORBIDDEN, response.statusCode());

        Assertions.assertThat(usersMeResponseObject.roles).extracting("locationName")
                .containsOnly("POO");
    }


    @Test
    @Category(ChangeRequest.CR_1903.class)
    public void AttemptToModifyCustomRoleForSuperAdminAsAdmin_NoChangesMadeToUser() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());

        //Act
        TestUserModel.LocationRoles removedLocations = new TestUserModel.LocationRoles();
        removedLocations.locationNameUuid = Locations.Location_POO_UID;
        removedLocations.locationName = "POO";
        removedLocations.roleName = TestEnumerators.UserRoles.LocalSuperAdmin.name();
        userDetails.removeLocationRoles.add(removedLocations);

        UsersMeResponseObject usersMeResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = usersMeResponseObject1.opLockVersion;
        userDetails.reason = "Editing User";
        Response response = API.RulesManagementService.Utils.Users.EditUser(userDetails);

        UsersMeResponseObject usersMeResponseObject = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);

        //Assert
        assertEquals(HttpStatus.SC_FORBIDDEN, response.statusCode());

        Assertions.assertThat(usersMeResponseObject.roles).extracting("locationName")
                .containsOnly("POO");
    }


    @Test
    @Category({ChangeRequest.CR_2225.class, ChangeRequest.CR_1422.class, ChangeRequest.CR_2628.class})
    public void WhenUserDetailsEdited_UserEditedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        userDetails.mobileNumber = "07832165478";
        userDetails.alternativeEmail = "John@digital.hmrc.gov.uk";
        userDetails.baseLocationUuid = Locations.Location_EXT_UID;
        userDetails.baseLocation = "EXT";
        userDetails.jobTitle = "new job title";

        UsersMeResponseObject userResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = userResponseObject1.opLockVersion;
        userDetails.reason = "Editing a User. The Maximum Reason Length is 60 Characters..";
        Response response = API.RulesManagementService.Utils.Users.EditUser(userDetails);

        UsersMeResponseObject userResponseObject = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);

        //Assert
        assertEquals(HttpStatus.SC_NO_CONTENT, response.statusCode());

        assertEquals(userDetails.mobileNumber, userResponseObject.mobileNumber);
        assertEquals(userDetails.alternativeEmail, userResponseObject.alternativeEmail);

        assertEquals(userDetails.baseLocation, userResponseObject.baseLocation.locationName);
        assertEquals(userDetails.jobTitle, userResponseObject.jobTitle);
    }


    @Test
    @Category({ChangeRequest.CR_2225.class, ChangeRequest.CR_1422.class, ChangeRequest.CR_2628.class})
    public void AttemptToEditUserWithInvalidLengthReasonReason_BadRequest() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        userDetails.mobileNumber = "07832165478";
        userDetails.alternativeEmail = "John@digital.hmrc.gov.uk";
        userDetails.baseLocationUuid = Locations.Location_EXT_UID;
        userDetails.baseLocation = "EXT";
        userDetails.jobTitle = "new job title";

        UsersMeResponseObject userResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = userResponseObject1.opLockVersion;

        userDetails.reason = FileUtilities.GenerateRandomAlphaNumericString(61, true, true);
        Response responseForLongReason = API.RulesManagementService.Utils.Users.EditUser(userDetails);

        userDetails.reason = FileUtilities.GenerateRandomAlphaNumericString(4, true, true);
        Response responseForShortReason = API.RulesManagementService.Utils.Users.EditUser(userDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, responseForLongReason.statusCode());
        assertEquals(HttpStatus.SC_BAD_REQUEST, responseForShortReason.statusCode());

    }

    @Test
    @Category({ChangeRequest.CR_2225.class, ChangeRequest.CR_1422.class, ChangeRequest.CR_2628.class})
    public void WhenUserDetailsEdited_HistoryUpdatedSuccessfully() {

        //Arrange
        TestUserModel.UserDetails userDetailsSuperAdmin = Users_API.DefaultSuperAdminUser();
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        userDetails.jobTitle = "new job title";

        UsersMeResponseObject userResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = userResponseObject1.opLockVersion;
        String reason1 = "Modifying User Job Title";
        userDetails.reason = reason1;
        API.RulesManagementService.Utils.Users.EditUser(userDetails);


        userDetails.mobileNumber = "07932165477";

        UsersMeResponseObject userResponseObject2 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = userResponseObject2.opLockVersion;
        String reason2 = "Modifying User Mobile";
        userDetails.reason = reason2;
        API.RulesManagementService.Utils.Users.EditUser(userDetails);

        UserHistoryResponse.UserHistoryResponseObject userHistoryResponseObject = Users.GetListOfUserHistory(userDetails.pid);

        //Assert
        assertEquals(HttpStatus.SC_OK, userHistoryResponseObject.httpStatusCode);


        Assertions.assertThat(userHistoryResponseObject.userHistoryResponseList)
                .hasSize(3)
                .extracting("pid", "updaterName", "updaterPid")
                .contains(new Tuple(userDetails.pid, userDetailsSuperAdmin.getFullName(), userDetailsSuperAdmin.pid));

        assertEquals("version", 3, userHistoryResponseObject.userHistoryResponseList.get(0).version);
        assertEquals(reason2, userHistoryResponseObject.userHistoryResponseList.get(0).reason);

        assertEquals("version", 2, userHistoryResponseObject.userHistoryResponseList.get(1).version);
        assertEquals(reason1, userHistoryResponseObject.userHistoryResponseList.get(1).reason);

        assertEquals("version", 1, userHistoryResponseObject.userHistoryResponseList.get(2).version);
        assertEquals("User created", userHistoryResponseObject.userHistoryResponseList.get(2).reason);
    }


    @Test
    @Category({ChangeRequest.CR_1426.class})
    public void WhenUserWithValidSCClearanceEdited_UserUpdatedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());

        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();
        userDetails.scClearanceLevel = "BPSS";
        userDetails.scClearanceExpiryDate = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(1, DateTime.DateTimeUTCZ);
        userDetails.scValidated = false;

        API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Act
        userDetails.scClearanceLevel = "DV";
        userDetails.scClearanceExpiryDate = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(100, DateTime.DateTimeUTCZ);
        userDetails.scValidated = true;

        UsersMeResponseObject userResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = userResponseObject1.opLockVersion;
        userDetails.reason = "Modifying User Job ssc details";
        Response responseEditUser = API.RulesManagementService.Utils.Users.EditUser(userDetails);

        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(userDetails.pid);

        //Assert
        assertEquals(HttpStatus.SC_NO_CONTENT, responseEditUser.statusCode());
        ViewUserDetailsResponse.AssertViewUserDetailsResponse(userDetails, viewUserDetailsResponse);
    }

    @Test
    @Category({ChangeRequest.CR_2244.class})
    public void WhenRedactedUserUpdated_UserUpdatedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());

        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();
        userDetails.redacted=false;
        API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Act
        userDetails.redacted=true;

        UsersMeResponseObject userResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = userResponseObject1.opLockVersion;
        userDetails.reason = "Making user redact from the user list";
        Response responseEditUser = API.RulesManagementService.Utils.Users.EditUser(userDetails);

        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(userDetails.pid);

        //Assert
        assertEquals(HttpStatus.SC_NO_CONTENT, responseEditUser.statusCode());
        ViewUserDetailsResponse.AssertViewUserDetailsResponse(userDetails, viewUserDetailsResponse);
    }
}
