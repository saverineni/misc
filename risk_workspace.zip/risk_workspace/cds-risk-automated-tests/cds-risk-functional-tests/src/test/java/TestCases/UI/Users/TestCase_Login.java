package TestCases.UI.Users;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Users;
import Categories_CDSRisk.CDS_Risk_UI_Users_2;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.LoggedInUserDetails;
import UI.Pages.Home_Page;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Users.class, CDS_Risk_UI_Users_2.class})
public class TestCase_Login extends BaseUIWebDriverTestCase {
    @Test
    public void WhenUserLogsIn_CDSRiskHomePageDisplayedWithUserDetails()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.DefaultSuperAdminUser();

        //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        Home_Page home_page = utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        //Assert
        assertEquals(home_page.getTitle(), driver.getTitle());
        assertEquals("Superadmin", home_page.getHomeIntroText());

        LoggedInUserDetails loggedInUserDetails = new LoggedInUserDetails(driver);
        assertEquals(UserDetails.roles.toLowerCase(), loggedInUserDetails.userType.getText().toLowerCase());
        assertEquals(UserDetails.firstname + " " + UserDetails.lastname, loggedInUserDetails.userName.getText());
    }
}
