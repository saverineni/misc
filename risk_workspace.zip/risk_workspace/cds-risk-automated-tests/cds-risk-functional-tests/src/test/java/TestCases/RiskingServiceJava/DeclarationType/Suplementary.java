package TestCases.RiskingServiceJava.DeclarationType;

import API.RiskingServiceJava.Utils.SoapMessageHelper;
import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.Risking_JavaService;
import TestCases.RiskingServiceJava.BaseRiskingServiceJava;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.*;
import uk.gov.hmrc.risk.test.common.model.darService.DarDeclarationRiskedEventModel;
import uk.gov.hmrc.risk.test.common.model.darService.DarDeclarationRiskedModel;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel;

import java.time.ZonedDateTime;
import java.util.*;

import static API.DataForTests.TestEnumerators.RuleOutputs.*;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by developer on 10/05/18.
 */
@Slf4j
@Category({ChangeRequest_RiskingService.CREP_611.class, Risking_JavaService.class})
public class Suplementary extends BaseRiskingServiceJava {

    private CreateRuleModel model;
    private Map<DeclarationParam, String> conditions = new HashMap<>();
    private String declarationId;
    String ruleId;
    String responseId;

    @Before
    public void addConditionToRule() {
        super.before();
        model = createRuleModel();
        model.getQueryOptions().setDeclarationType("IM");
        model.getQueryOptions().setDeclarationSubTypes(Arrays.asList(DeclarationSubType.Y.toString()));
        model.getQuery().get(0).setQuery(
                Arrays.asList(CreateRuleModel.Query.builder()
                        .conditionType(ConditionType.normal.toString())
                        .attribute(HeaderDeclarationParam.CONSIGNOR_NAME.toString())
                        .value("consignor name")
                        .operator(Operator.eq.toString())
                        .build()
                )
        );

        declarationId = UUID.randomUUID().toString();
        conditions.put(HeaderDeclarationParam.ID, declarationId);
        conditions.put(HeaderDeclarationParam.DECLARATION_REFERENCE, declarationId);
        conditions.put(HeaderDeclarationParam.CONSIGNOR_NAME, "consignor name");
        conditions.put(HeaderDeclarationParam.TRANSPORT_MODE, TransportMode.All.toString());
        conditions.put(HeaderDeclarationParam.DECLARATION_TYPE, "IM");
        conditions.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "Y");
        conditions.put(GoodsItemDeclarationParam.SEQUENCE_NUMBER, "2001");
        conditions.put(GoodsItemDeclarationParam.Second.SEQUENCE_NUMBER, "2002");
        conditions.put(GoodsItemDeclarationParam.Third.SEQUENCE_NUMBER, "2003");
        conditions.put(GoodsItemDeclarationParam.Fourth.SEQUENCE_NUMBER, "2004");
    }

    @Test
    public void WhenNoRuleIsHit_NoResponseToDMSnorCDAPnorMDGareSent() {
        CreateRuleModel noHitModel = createRuleModel();
        noHitModel.getQueryOptions().setDeclarationType("IM");
        noHitModel.getQueryOptions().setDeclarationSubTypes(Arrays.asList(DeclarationSubType.E.toString()));
        noHitModel.getQuery().get(0).setQuery(
                Arrays.asList(CreateRuleModel.Query.builder()
                        .attribute(HeaderDeclarationParam.CONSIGNOR_NAME.toString())
                        .conditionType(ConditionType.normal.toString())
                        .operator(Operator.eq.toString())
                        .value("Something that should never be")
                        .build())
        );
        createAndRefreshRule(noHitModel);

        String responseId = createSendDeckarationAndAssertDMSResponseShowNoRisk();

        DarDeclarationRiskedModel expectedRiskedModel = DarDeclarationRiskedModel.builder()
                .type(DarEventType.DECLARATION_RISKED.toString())
                .responseId(responseId)
                .declarationId(declarationId)
                .declarationVersion("1")
                .rulesPackage("")
                .numberOfResults("0")
                .build();

        assertDeclarationRiskedEvent(expectedRiskedModel);

        List<DarDeclarationRiskedEventModel> logs = darServiceAuditSupport.parseDeclarationRiskedEvent();

        List<DarDeclarationRiskedEventModel> filtered = new ArrayList<>();
        logs.stream().filter(log -> log.getResponseId().equals(declarationId))
                .forEach(filtered::add);
        Assertions.assertThat(filtered).isEmpty();

    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenPhysicalCheckRuleIsHit_NoResponseToDMSSuppDeckCheckToCDAPandNoMessageToMDG() {
        model.getRuleOutputs().setActionType(PHYSICAL_CHECK.actionType);
        model.getRuleOutputs().setReleaseNarrative(null);
        ruleId = createAndRefreshRule(model);

        responseId = createSendDeckarationAndAssertDMSResponseShowNoRisk();

        DarDeclarationRiskedModel expectedRiskedModel = DarDeclarationRiskedModel.builder()
                .type(DarEventType.DECLARATION_RISKED.toString())
                .responseId(responseId)
                .declarationId(declarationId)
                .declarationVersion("1")
                .rulesPackage("")
                .numberOfResults("1")
                .build();

        assertDeclarationRiskedEvent(expectedRiskedModel);

        DarDeclarationRiskedEventModel expectedRiskedEventModel = DarDeclarationRiskedEventModel.builder()
                .type(DarEventType.DECLARATION_RISK_RESULT.toString())
                .responseId(responseId)
                .ruleId(ruleId.concat("-1"))
                .actionControlType(SUPP_DEC_CHECK.toString())
                .reportBackElement("/declaration")
                .narrative(HOLD_NARRATIVE)
                .matchReason("Declaration field: 'Consignor Name' was equal to consignor name. The value was: 'consignor name'")
                .workBasket("NCH Open General Export Licence")
                .email("")
                .blockingRelease("true")
                .isSecret("false")
                .notifyDeclarant("false")
                .isSuppressedByRats("false")
                .ruleControlType(PHYSICAL_CHECK.toString())
                .build();

        assertDeclarationRiskedEvent(expectedRiskedEventModel);
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenDocCheckRuleIsHit_NoResponseToDMSSuppDeckCheckToCDAPandNoMessageToMDG() {
        model.getRuleOutputs().setActionType(DOC_CHECK_HOLD_GOODS.actionType);
        model.getRuleOutputs().setReleaseNarrative(null);
        ruleId = createAndRefreshRule(model);

        responseId = createSendDeckarationAndAssertDMSResponseShowNoRisk();

        DarDeclarationRiskedModel expectedRiskedModel = DarDeclarationRiskedModel.builder()
                .type(DarEventType.DECLARATION_RISKED.toString())
                .responseId(responseId)
                .declarationId(declarationId)
                .declarationVersion("1")
                .rulesPackage("")
                .numberOfResults("1")
                .build();

        assertDeclarationRiskedEvent(expectedRiskedModel);

        DarDeclarationRiskedEventModel expectedRiskedEventModel = DarDeclarationRiskedEventModel.builder()
                .type(DarEventType.DECLARATION_RISK_RESULT.toString())
                .responseId(responseId)
                .ruleId(ruleId.concat("-1"))
                .actionControlType(SUPP_DEC_CHECK.toString())
                .reportBackElement("/declaration")
                .narrative(HOLD_NARRATIVE)
                .matchReason("Declaration field: 'Consignor Name' was equal to consignor name. The value was: 'consignor name'")
                .workBasket("NCH Open General Export Licence")
                .email("")
                .blockingRelease("true")
                .isSecret("false")
                .notifyDeclarant("false")
                .isSuppressedByRats("false")
                .ruleControlType("DOCUMENT_CHECK")
                .build();

        assertDeclarationRiskedEvent(expectedRiskedEventModel);
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenPhysicalCheckWithInformationTaskRuleIsHit_NoResponseToDMSSuppDeckCheckAndInfoToCDAPandInfoMessageToMDG() {
        model.getRuleOutputs().setActionType(PHYSICAL_CHECK.actionType);
        model.getRuleOutputs().setReleaseNarrative(null);
        model.getRuleOutputs().setInformationNarrative("Physical check with information task rule");
        model.getRuleOutputs().setInformationNarrativeAssignee("someGuy@ce.gsi.gov.uk");
        ruleId = createAndRefreshRule(model);

        responseId = createSendDeckarationAndAssertDMSResponseShowNoRisk();

        DarDeclarationRiskedModel expectedRiskedModel = DarDeclarationRiskedModel.builder()
                .type(DarEventType.DECLARATION_RISKED.toString())
                .responseId(responseId)
                .declarationId(declarationId)
                .declarationVersion("1")
                .rulesPackage("")
                .numberOfResults("2")
                .build();

        assertDeclarationRiskedEvent(expectedRiskedModel);

        DarDeclarationRiskedEventModel physicalRiskResultEvent = DarDeclarationRiskedEventModel.builder()
                .type(DarEventType.DECLARATION_RISK_RESULT.toString())
                .responseId(responseId)
                .ruleId(ruleId.concat("-1"))
                .actionControlType(SUPP_DEC_CHECK.toString())
                .reportBackElement("/declaration")
                .narrative(HOLD_NARRATIVE)
                .matchReason("Declaration field: 'Consignor Name' was equal to consignor name. The value was: 'consignor name'")
                .workBasket("NCH Open General Export Licence")
                .email("")
                .blockingRelease("true")
                .isSecret("false")
                .notifyDeclarant("false")
                .isSuppressedByRats("false")
                .ruleControlType(PHYSICAL_CHECK.toString())
                .build();

        DarDeclarationRiskedEventModel infoRiskedModel = DarDeclarationRiskedEventModel.builder()
                .type(DarEventType.DECLARATION_RISK_RESULT.toString())
                .responseId(responseId)
                .ruleId(ruleId.concat("-1"))
                .actionControlType(INFORMATION_TASK.toString())
                .reportBackElement("/declaration")
                .narrative(model.getRuleOutputs().getInformationNarrative())
                .matchReason("Declaration field: 'Consignor Name' was equal to consignor name. The value was: 'consignor name'")
                .workBasket("VGEM")
                .email(model.getRuleOutputs().getInformationNarrativeAssignee())
                .blockingRelease("false")
                .isSecret("false")
                .notifyDeclarant("false")
                .isSuppressedByRats("false")
                .ruleControlType(INFORMATION_TASK.toString())
                .build();

        assertDeclarationRiskedEvent(physicalRiskResultEvent, infoRiskedModel);
    }

    @Test
   // @Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenDockCheckWithInformationTaskRuleIsHit_NoResponseToDMSSuppDeckCheckAndInfoToCDAPandInfoMessageToMDG() {
        model.getRuleOutputs().setActionType(DOC_CHECK_RELEASE_GOODS.actionType);
        model.getRuleOutputs().setReleaseNarrative(RELEASE_NARRATIVE);
        model.getRuleOutputs().setReleasePercentage(100);
        model.getRuleOutputs().setHoldNarrative(null);
        model.getRuleOutputs().setHoldPercentage(null);
        model.getRuleOutputs().setInformationNarrative("Document check with information task rule");
        model.getRuleOutputs().setInformationNarrativeAssignee("someGuy@ce.gsi.gov.uk");
        model.getRuleOutputs().setBlockingRelease(false);
        ruleId = createAndRefreshRule(model);

        responseId = createSendDeckarationAndAssertDMSResponseShowNoRisk();

        DarDeclarationRiskedModel expectedRiskedModel = DarDeclarationRiskedModel.builder()
                .type(DarEventType.DECLARATION_RISKED.toString())
                .responseId(responseId)
                .declarationId(declarationId)
                .declarationVersion("1")
                .rulesPackage("")
                .numberOfResults("2")
                .build();

        assertDeclarationRiskedEvent(expectedRiskedModel);

        DarDeclarationRiskedEventModel physicalRiskResultEvent = DarDeclarationRiskedEventModel.builder()
                .type(DarEventType.DECLARATION_RISK_RESULT.toString())
                .responseId(responseId)
                .ruleId(ruleId.concat("-1"))
                .actionControlType(SUPP_DEC_CHECK.toString())
                .reportBackElement("/declaration")
                .narrative(RELEASE_NARRATIVE)
                .matchReason("Declaration field: 'Consignor Name' was equal to consignor name. The value was: 'consignor name'")
                .workBasket("NCH Open General Export Licence")
                .email("")
                .blockingRelease("false")
                .isSecret("false")
                .notifyDeclarant("false")
                .isSuppressedByRats("false")
                .ruleControlType("DOCUMENT_CHECK")
                .build();

        DarDeclarationRiskedEventModel infoRiskedModel = DarDeclarationRiskedEventModel.builder()
                .type(DarEventType.DECLARATION_RISK_RESULT.toString())
                .responseId(responseId)
                .ruleId(ruleId.concat("-1"))
                .actionControlType(INFORMATION_TASK.toString())
                .reportBackElement("/declaration")
                .narrative(model.getRuleOutputs().getInformationNarrative())
                .matchReason("Declaration field: 'Consignor Name' was equal to consignor name. The value was: 'consignor name'")
                .workBasket("VGEM")
                .email("someGuy@ce.gsi.gov.uk")
                .blockingRelease("false")
                .isSecret("false")
                .notifyDeclarant("false")
                .isSuppressedByRats("false")
                .ruleControlType(INFORMATION_TASK.toString())
                .build();

        assertDeclarationRiskedEvent(physicalRiskResultEvent, infoRiskedModel);
    }

    @Test
   // @Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenInformationTaskRuleIsHit_NoResponseToDMSInfoToCDAPandInfoMessageToMDG() {
        model.getRuleOutputs().setActionType(INFORMATION_TASK.actionType);
        model.getRuleOutputs().setReleaseNarrative(null);
        model.getRuleOutputs().setHoldNarrative(null);
        model.getRuleOutputs().setInformationNarrative("Information task rule");
        model.getRuleOutputs().setInformationNarrativeAssignee("someGuy@ce.gsi.gov.uk");
        ruleId = createAndRefreshRule(model);

        responseId = createSendDeckarationAndAssertDMSResponseShowNoRisk();

        DarDeclarationRiskedModel expectedRiskedModel = DarDeclarationRiskedModel.builder()
                .type(DarEventType.DECLARATION_RISKED.toString())
                .responseId(responseId)
                .declarationId(declarationId)
                .declarationVersion("1")
                .rulesPackage("")
                .numberOfResults("1")
                .build();

        assertDeclarationRiskedEvent(expectedRiskedModel);

        DarDeclarationRiskedEventModel infoRiskedModel = DarDeclarationRiskedEventModel.builder()
                .type(DarEventType.DECLARATION_RISK_RESULT.toString())
                .responseId(responseId)
                .ruleId(ruleId.concat("-1"))
                .actionControlType(INFORMATION_TASK.toString())
                .reportBackElement("/declaration")
                .narrative(model.getRuleOutputs().getInformationNarrative())
                .matchReason("Declaration field: 'Consignor Name' was equal to consignor name. The value was: 'consignor name'")
                .workBasket("VGEM")
                .email(model.getRuleOutputs().getInformationNarrativeAssignee())
                .blockingRelease("false")
                .isSecret("false")
                .notifyDeclarant("false")
                .isSuppressedByRats("false")
                .ruleControlType(INFORMATION_TASK.toString())
                .build();

        assertDeclarationRiskedEvent(infoRiskedModel);

        assertMDGMessage(model.getRuleOutputs().getInformationNarrative(),
                model.getRuleOutputs().getInformationNarrativeAssignee());
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenSupplementaryRuleIsHit_NoResponseToDMSSuppToCDAPandInfoMessageToMDG() {
        model.getRuleOutputs().setActionType(SUPP_DEC_CHECK.actionType);
        model.getRuleOutputs().setReleaseNarrative(RELEASE_NARRATIVE);
        model.getRuleOutputs().setHoldNarrative(null);
        model.getRuleOutputs().setInformationNarrative(null);
        model.getRuleOutputs().setInformationNarrativeAssignee(null);
        model.getRuleOutputs().setAssigneeId(null);
        ruleId = createAndRefreshRule(model);

        responseId = createSendDeckarationAndAssertDMSResponseShowNoRisk();

        DarDeclarationRiskedModel expectedRiskedModel = DarDeclarationRiskedModel.builder()
                .type(DarEventType.DECLARATION_RISKED.toString())
                .responseId(responseId)
                .declarationId(declarationId)
                .declarationVersion("1")
                .rulesPackage("")
                .numberOfResults("1")
                .build();

        assertDeclarationRiskedEvent(expectedRiskedModel);

        DarDeclarationRiskedEventModel suppRiskModel = DarDeclarationRiskedEventModel.builder()
                .type(DarEventType.DECLARATION_RISK_RESULT.toString())
                .responseId(responseId)
                .ruleId(ruleId.concat("-1"))
                .actionControlType(SUPP_DEC_CHECK.toString())
                .reportBackElement("/declaration")
                .narrative(model.getRuleOutputs().getReleaseNarrative())
                .matchReason("Declaration field: 'Consignor Name' was equal to consignor name. The value was: 'consignor name'")
                .workBasket("VGEM")
                .email("")
                .blockingRelease("false")
                .isSecret("false")
                .notifyDeclarant("false")
                .isSuppressedByRats("false")
                .ruleControlType(SUPP_DEC_CHECK.toString())
                .build();

        assertDeclarationRiskedEvent(suppRiskModel);
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenSupplementaryAndInfoRuleIsHit_NoResponseToDMSSuppAndInfoToCDAPandInfoMessageToMDG() {
        model.getRuleOutputs().setActionType(SUPP_DEC_CHECK.actionType);
        model.getRuleOutputs().setReleaseNarrative(RELEASE_NARRATIVE);
        model.getRuleOutputs().setHoldNarrative(null);
        model.getRuleOutputs().setInformationNarrative("Information task rule");
        model.getRuleOutputs().setInformationNarrativeAssignee("someGuy@ce.gsi.gov.uk");
        model.getRuleOutputs().setAssigneeId(null);
        ruleId = createAndRefreshRule(model);

        responseId = createSendDeckarationAndAssertDMSResponseShowNoRisk();

        DarDeclarationRiskedModel expectedRiskedModel = DarDeclarationRiskedModel.builder()
                .type(DarEventType.DECLARATION_RISKED.toString())
                .responseId(responseId)
                .declarationId(declarationId)
                .declarationVersion("1")
                .rulesPackage("")
                .numberOfResults("2")
                .build();

        assertDeclarationRiskedEvent(expectedRiskedModel);

        DarDeclarationRiskedEventModel suppRiskedModel = DarDeclarationRiskedEventModel.builder()
                .type(DarEventType.DECLARATION_RISK_RESULT.toString())
                .responseId(responseId)
                .ruleId(ruleId.concat("-1"))
                .actionControlType(SUPP_DEC_CHECK.toString())
                .reportBackElement("/declaration")
                .narrative(model.getRuleOutputs().getReleaseNarrative())
                .matchReason("Declaration field: 'Consignor Name' was equal to consignor name. The value was: 'consignor name'")
                .workBasket("VGEM")
                .email("")
                .blockingRelease("false")
                .isSecret("false")
                .notifyDeclarant("false")
                .isSuppressedByRats("false")
                .ruleControlType(SUPP_DEC_CHECK.toString())
                .build();

        DarDeclarationRiskedEventModel infoRiskedModel = DarDeclarationRiskedEventModel.builder()
                .type(DarEventType.DECLARATION_RISK_RESULT.toString())
                .responseId(responseId)
                .ruleId(ruleId.concat("-1"))
                .actionControlType(INFORMATION_TASK.toString())
                .reportBackElement("/declaration")
                .narrative(model.getRuleOutputs().getInformationNarrative())
                .matchReason("Declaration field: 'Consignor Name' was equal to consignor name. The value was: 'consignor name'")
                .workBasket("VGEM")
                .email("someGuy@ce.gsi.gov.uk")
                .blockingRelease("false")
                .isSecret("false")
                .notifyDeclarant("false")
                .isSuppressedByRats("false")
                .ruleControlType(INFORMATION_TASK.toString())
                .build();

        assertDeclarationRiskedEvent(suppRiskedModel, infoRiskedModel);
    }


    private String createSendDeckarationAndAssertDMSResponseShowNoRisk() {
        DeclarationResponse response = createAndSendDeclaration(conditions, false);
        Assertions.assertThat(response.getControlType()).isEmpty();
        Assertions.assertThat(response.getReportBackElements()).isEmpty();

        return response.getResponseId();
    }

    private void assertDeclarationRiskedEvent(DarDeclarationRiskedModel expectedRiskedModel) {

        List<DarDeclarationRiskedModel> logs = darServiceAuditSupport.parseDeclarationRisk();

        List<DarDeclarationRiskedModel> filtered = new ArrayList<>();
        logs.stream().filter(log -> log.getDeclarationId().equals(expectedRiskedModel.getDeclarationId()))
                .forEach(filtered::add);
        Assertions.assertThat(filtered.size()).isNotZero();

        filtered.forEach(log ->
        {
            Assertions.assertThat(log.getType()).isEqualTo(DarEventType.DECLARATION_RISKED.toString());
            ZonedDateTime time = darServiceAuditSupport.getFormattedTimestamp(log.getEventTime());
            Assertions.assertThat(time).isBeforeOrEqualTo(ZonedDateTime.now().plusHours(2));
            Assertions.assertThat(log.getResponseId()).isEqualTo(expectedRiskedModel.getResponseId());
            Assertions.assertThat(log.getDeclarationVersion()).isEqualTo(expectedRiskedModel.getDeclarationVersion());
            Assertions.assertThat(log.getRulesPackage()).isNotEmpty();
            Assertions.assertThat(log.getNumberOfResults()).isEqualTo(expectedRiskedModel.getNumberOfResults());
        });

    }

    private void assertDeclarationRiskedEvent(DarDeclarationRiskedEventModel... expectedBody) {
        List<DarDeclarationRiskedEventModel> logs = darServiceAuditSupport.parseDeclarationRiskedEvent();

        List<DarDeclarationRiskedEventModel> filtered = new ArrayList<>();
        logs.stream().filter(log -> log.getResponseId().equals(expectedBody[0].getResponseId()))
                .forEach(filtered::add);
        Assertions.assertThat(filtered.size()).isNotZero();

        filtered.forEach( log -> {
            int i = filtered.indexOf(log);
            Assertions.assertThat(log.getType()).isEqualTo(DarEventType.DECLARATION_RISK_RESULT.toString());
            Assertions.assertThat(log.getRuleId()).isEqualTo(expectedBody[i].getRuleId());
            Assertions.assertThat(log.getActionControlType()).isEqualTo(expectedBody[i].getActionControlType());
            Assertions.assertThat(log.getReportBackElement()).isEqualTo(expectedBody[i].getReportBackElement());
            Assertions.assertThat(log.getNarrative()).isEqualTo(expectedBody[i].getNarrative());
            Assertions.assertThat(log.getMatchReason()).contains(expectedBody[i].getMatchReason());
            Assertions.assertThat(log.getWorkBasket()).isEqualTo(expectedBody[i].getWorkBasket());
            Assertions.assertThat(log.getEmail()).isEqualTo(expectedBody[i].getEmail());
            Assertions.assertThat(log.getBlockingRelease()).isEqualTo(expectedBody[i].getBlockingRelease());
            Assertions.assertThat(log.getIsSecret()).isEqualTo(expectedBody[i].getIsSecret());
            Assertions.assertThat(log.getNotifyDeclarant()).isEqualTo(expectedBody[i].getNotifyDeclarant());
            Assertions.assertThat(log.getIsSuppressedByRats()).isEqualTo(expectedBody[i].getIsSuppressedByRats());
            Assertions.assertThat(log.getRuleControlType()).isEqualTo(expectedBody[i].getRuleControlType());
        });
    }

    private void assertMDGMessage(String narrative, String assignee) {
        String message = mdgEmailQueueAccessor.receive();
        SoapMessageHelper.SoapMessage emailRequest = soapHelper.parse(message);

        log.debug("emailRequest = " + message);

        // Check information narrative isn't sent #CR-3304
        assertThat(emailRequest.getValueFromBody("EmailRequest/EmailContent/Content"))
                .doesNotContain(narrative);

        // Check an ID is present #CR-3305
        assertThat(emailRequest.getValueFromBody("EmailRequest/EmailContent/Content"))
                .contains("NAT-ADD");

        assertThat(emailRequest.getValueFromBody("EmailRequest/EmailContent/Bcc"))
                .contains(assignee);
    }
}
