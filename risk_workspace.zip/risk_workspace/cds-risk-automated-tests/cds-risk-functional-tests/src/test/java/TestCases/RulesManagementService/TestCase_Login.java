package TestCases.RulesManagementService;

import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.EnvDetails.EnvDetails;
import API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse;
import API.RulesManagementService.ViewRuleList.ViewRuleListResponse;
import Categories_CDSRisk.CDS_RM_Login;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static API.RulesManagementService.Utils.Users.UpdateStatusOfUser;
import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

@Slf4j
@Category({Rules_Management.class, CDS_RM_Login.class})
public class TestCase_Login extends BaseWebAPITestCase {

    @Before
    public void Setup() {
        TestUserModel.UserDetails udNatSuperAdmin = Users_API.DefaultSuperAdminUser();
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
    }

    @Test
    @Category(ChangeRequest.CR_494.class)
    public void WhenValidTokenUsedWithGetRequest_OKResponseReceived() {
        //Arrange
        TestUserModel.UserDetails udNatRuleManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleManager.pid,Users_API.SUPER_ADMIN_DEFAULT_PASSWORD);

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject viewRuleListResponseObject = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        assertEquals(HttpStatus.SC_OK, viewRuleListResponseObject.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_494.class)
    public void WhenNoAuthorizationUsedWithGetRequest_UnAuthorizedResponseReceived() {
        //Arrange

        //Act
        String url = EnvDetails.url_RuleCreate;
        log.info("\r\n GET Request: " + url);

        //No Authorization Header
        //Header header = new Header("Authorization", "Bearer " + EnvDetails.sCurrentLoggedInUserToken);
        Response response = given().when().get(url).then().extract().response();

        //Assert
        assertEquals(HttpStatus.SC_UNAUTHORIZED, response.getStatusCode());
    }

    @Test
    @Category(ChangeRequest.CR_494.class)
    public void WhenInvalidAuthorizationTokenUsedWithGetRequest_UnAuthorizedResponseReceived() {
        //Arrange
        EnvDetails.sCurrentLoggedInUserToken = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIn0.cj7dExYdBV5dVPVmx0wXPtV1C9ZYoeGGu9JF3PAR2ZZ";

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject viewRuleListResponseObject = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        assertEquals(HttpStatus.SC_UNAUTHORIZED, viewRuleListResponseObject.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_494.class)
    public void WhenNoTokenUsedWithGetRequest_UnAuthorizedResponseReceived() {
        //Arrange
        EnvDetails.sCurrentLoggedInUserToken = "";

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject viewRuleListResponseObject = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        assertEquals(HttpStatus.SC_UNAUTHORIZED, viewRuleListResponseObject.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_494.class)
    public void WhenValidTokenUsedWithPostRequest_OKResponseReceived() {
        //Arrange
        TestUserModel.UserDetails udNatRuleManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleManager.pid,Users_API.SUPER_ADMIN_DEFAULT_PASSWORD);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        //Act
        Response response = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.getStatusCode());
    }


    @Test
    @Category(ChangeRequest.CR_494.class)
    public void WhenInvalidTokenUsedWithPostRequest_OKResponseReceived() {
        //Arrange
        TestUserModel.UserDetails udNatRuleManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleManager.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        //Act
        EnvDetails.sCurrentLoggedInUserToken = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIn0.cj7dExYdBV5dVPVmx0wXPtV1C9ZYoeGGu9JF3PAR2ZZ";
        Response response = API.RulesManagementService.Utils.Rules.EditRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_UNAUTHORIZED, response.getStatusCode());
    }


    @Test
    @Category(ChangeRequest.CR_494.class)
    public void WhenValidTokenUsedWithPutRequest_OKResponseReceived() {
        //Arrange
        TestUserModel.UserDetails udNatRuleManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleManager.pid,Users_API.SUPER_ADMIN_DEFAULT_PASSWORD);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Response createResponse = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Act
        ruleDetails.description = "updatedRule";
        ruleDetails.version = 2;
        ruleDetails.uniqueID = createResponse.path("uniqueId");
        Response editResponse = API.RulesManagementService.Utils.Rules.EditRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_OK, editResponse.getStatusCode());
    }


    @Test
    @Category(ChangeRequest.CR_494.class)
    public void WhenInvalidTokenUsedWithPutRequest_OKResponseReceived() {
        //Arrange
        TestUserModel.UserDetails udNatRuleManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleManager.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Response createResponse = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Act
        ruleDetails.description = "updatedRule";
        ruleDetails.version = 2;
        ruleDetails.uniqueID = createResponse.path("uniqueId");
        EnvDetails.sCurrentLoggedInUserToken = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIn0.cj7dExYdBV5dVPVmx0wXPtV1C9ZYoeGGu9JF3PAR2ZZ";
        Response editResponse = API.RulesManagementService.Utils.Rules.EditRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_UNAUTHORIZED, editResponse.getStatusCode());
    }


    @Test
    @Category(ChangeRequest.CR_494.class)
    public void WhenCDSRiskUserLogsIn_OKResponseReceived() {
        //Arrange
        TestUserModel.UserDetails udNatRuleManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();

        //Act
        int iStatusCode = API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleManager.pid,Users_API.SUPER_ADMIN_DEFAULT_PASSWORD);

        //Assert
        assertEquals("Http status code: ", HttpStatus.SC_OK, iStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_2698.class)
    public void WhenRedactedUserLogsIn_OKResponseReceived() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.RulesManagerLocal_POO();
        userDetails.redacted = true;
        API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Act
        int iStatusCode = API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Assert
        assertEquals("Http status code: ", HttpStatus.SC_OK, iStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_494.class)
    public void WhenHMRCUserWithNoAccessToCDSRiskLogsIn_UnAuthorizedResponseReceived() {
        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.UserWithNoAccessToCDSRisk();

        //Act
        int iStatusCode = API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Assert
        assertEquals("Http status code: ", HttpStatus.SC_UNAUTHORIZED, iStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_494.class)
    public void WhenUserWithNoAccessToHMRCLogsIn_UnAuthorizedResponseReceived() {
        //Arrange
        String sPID = "9999999";

        //Act
        int iStatusCode = API.RulesManagementService.Utils.Users.LoginAsUser(sPID);

        //Assert
        assertEquals("Http status code: ", HttpStatus.SC_UNAUTHORIZED, iStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_557.class)
    public void WhenLocalUserLoggedIn_CurrentUserSummaryReturned() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Act
        API.RulesManagementService.Users.Me.UsersMeResponse.UsersMeResponseObject userMeResponse = API.RulesManagementService.Utils.Users.GetCurrentUserMeSummary(userDetails.pid);

        //Assert
        assertEquals("Http status code: ", HttpStatus.SC_OK, userMeResponse.httpStatusCode);
        API.RulesManagementService.Users.Me.UsersMeResponse.AssertViewUserResponse(userDetails, userMeResponse);
    }

    @Test
    @Category(ChangeRequest.CR_557.class)
    public void WhenNationalUserLoggedIn_CurrentUserSummaryReturned() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid,Users_API.SUPER_ADMIN_DEFAULT_PASSWORD);

        //Act
        API.RulesManagementService.Users.Me.UsersMeResponse.UsersMeResponseObject userMeResponse = API.RulesManagementService.Utils.Users.GetCurrentUserMeSummary(userDetails.pid);

        //Assert
        assertEquals("Http status code: ", HttpStatus.SC_OK, userMeResponse.httpStatusCode);
        API.RulesManagementService.Users.Me.UsersMeResponse.AssertViewUserResponse(userDetails, userMeResponse);
    }

    @Test
    @Category(ChangeRequest.CR_557.class)
    public void WhenLocalUserLoggedIn_CurrentUserDetailsReturned() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Act
        UserMeDetailsResponse.UsersMeResponseObject userMeResponse = API.RulesManagementService.Utils.Users.GetCurrentUserMeDetails(userDetails.pid);

        //Assert
        assertEquals("Http status code: ", HttpStatus.SC_OK, userMeResponse.httpStatusCode);
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails, userMeResponse);
    }

    @Test
    @Category({ChangeRequest.CR_557.class, ChangeRequest.CR_1398.class})
    public void WhenNationalUserLoggedIn_CurrentUserDetailsReturned() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid,Users_API.SUPER_ADMIN_DEFAULT_PASSWORD);

        //Act
        UserMeDetailsResponse.UsersMeResponseObject userMeResponse = API.RulesManagementService.Utils.Users.GetCurrentUserMeDetails(userDetails.pid);

        //Assert
        assertEquals("Http status code: ", HttpStatus.SC_OK, userMeResponse.httpStatusCode);
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails, userMeResponse);
    }



    //----------------------------------------------
    //Archived User / Suspended User / Reinstate
    //----------------------------------------------

    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void AttemptToLoginAsArchivedUser_UnAuthorizedResponseReceived() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_ARCHIVE.apiAction);

        //Act
        int responseCode = API.RulesManagementService.Utils.Users.AttemptLoginAsUser(userDetails.pid);

        //Assert
        assertEquals(HttpStatus.SC_UNAUTHORIZED, responseCode);
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void AttemptToLoginAsSuspendedUser_UnAuthorizedResponseReceived() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_SUSPEND.apiAction);

        //Act
        int responseCode = API.RulesManagementService.Utils.Users.AttemptLoginAsUser(userDetails.pid);

        //Assert
        assertEquals(HttpStatus.SC_UNAUTHORIZED, responseCode);
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenUserLogsInAsReinstatedUser_UserLoggedInSuccessfully() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_SUSPEND.apiAction);

        //Act
        UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_REINSTATE.apiAction);
        int responseCode = API.RulesManagementService.Utils.Users.AttemptLoginAsUser(userDetails.pid);

        //Assert
        assertEquals(HttpStatus.SC_OK, responseCode);
    }

    @Test
    @Category(ChangeRequest.CRX_203.class)
    @Ignore("Disabled until we have an AD stub")
    public void WhenUserLogsInWithInvalidPassword_UnAuthorizedResponseReceived() {
        TestUserModel.UserDetails udNatRuleManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();

        //Act
        int responseCode = API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleManager.pid, "==invalid_password==");

        //Assert
        assertEquals(HttpStatus.SC_UNAUTHORIZED, responseCode);
    }

}
