package TestCases;

import lombok.extern.slf4j.Slf4j;
import org.junit.After;

@Slf4j
public class WebAPITestCaseWithDatatablesCleanup extends BaseWebAPITestCase {

    @After
    public void Cleanup() {
        log.info("#### Cleanup up datatables from DB");
        dataTableDao.deleteAll();
    }

}
