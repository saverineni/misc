package TestCases;

import Categories_CDSRisk.CDS_Connectivity;
import org.junit.experimental.categories.Category;

@Category(CDS_Connectivity.class)
public class TestCase_CDS_Connectivity {

//    @Before
//    public void setUp() throws Exception
//    {
//        String environment = System.getProperty("test-environment", "local");
//
//        EnvDetails.GetEnvironmentConfigDetails(environment); //sEnvironment= local or aws
//    }

    //TODO update to use rest assured
//    @Test
//    public void WhenValidRequestSubmitted_OKResponseReceived() throws Throwable
//    {
//        log.info("\r\n" + "WhenValidRequestSubmitted_OKResponseReceived" + "\r\n");
//
//        //Act
//
//        //Arrange
//        CloseableHttpResponse response = HttpClient.SendHttpGetRequest(EnvDetails.url_RiskingServiceHealthCheck);
//
//        String sServerResponse = EntityUtils.toString(response.getEntity());
//        log.info("Server Response: " + "\r\n" + sServerResponse);
//        JSONObject jsonObject = new JSONObject(sServerResponse);
//        Map jsonResponse = ConvertJSON_RM_Response.ConvertJSONObjectToMap(jsonObject);
//
//        //Assert
//        assertEquals(HttpStatus.SC_OK, response.getStatusLine().getStatusCode());
//        assertEquals("CDS Risk", jsonResponse.get("service-name"));
//        assertEquals("GREEN", jsonResponse.get("status"));
//    }




}