package TestCases.RiskingService;

import API.DataForTests.Conditions;
import API.DataForTests.DataTables;
import API.DataForTests.TestDataTableModel;
import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestRuleModel.RuleDetails;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.Utils.RuleAtStatus;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service_Operators;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.riskingservice.model.internal.request.DeclaredDutyTaxFee;
import uk.gov.hmrc.risk.test.common.enums.ConditionType;
import uk.gov.hmrc.risk.test.common.model.declarationSupport.DeclarationModel;
import uk.gov.hmrc.risk.test.common.model.declarationSupport.ItemModel;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.service.declarationSupport.ItemColllectionsTemplates;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import static API.DataForTests.TestRuleModel.RuleDetails.AttributeType.*;
import static API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody;
import static org.assertj.core.api.Assertions.assertThat;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.crossmatch;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.normal;

@Slf4j
@Category(Risking_Service_Operators.class)
public class TestCase_Risking_Operators_NotEqual_collectionField extends WebAPITestCaseWithDatatablesCleanup {

    public static final String NO_CONTROL_ROUTE = "";
    private RuleDetails testRule;
    private RuleDetails.Condition condition;
    private TestDeclarationModel.Declaration declaration;

    @Before
    public void setup() throws IOException, TimeoutException {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
        testRule = API.DataForTests.Rules.DraftNatRuleNatManager();
        condition = testRule.queryConditions.get(0).conditions.get(0);
        condition.operator = "neq";
        declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.goodsLocationID = declaration.goodsLocationName;
    }

    private void commitRuleAndPublish() {
        EditRuleVersionResponse.PutResponse commitResponse = RuleAtStatus.CreateCommittedRule(testRule);
        assertThat(commitResponse.httpStatusCode)
                .describedAs("Failed to commit rule. response:\n" + commitResponse.body)
                .isEqualTo(200);
        publishAndWait(5000);
    }

    private DeclarationResponse riskDeclaration() {
        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());
        queue.send(declarationRequest);
        return new DeclarationResponse(queue.receive());
    }

    private DeclarationResponse riskDeclarationForMultipleItems() {
        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultMultiItemDeclarationTemplate());
        queue.send(declarationRequest);
        return new DeclarationResponse(queue.receive());
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionFieldEqualValue_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = "Jane";
        condition.operator = "eq";
        commitRuleAndPublish();

        declaration.additionalInformation_TextHeader = "Jane";
        declaration.additionalInfoText_Header = "not the same";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    /*
     * collection field to value
     */
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionFieldNotEqualValue_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = "Jane";
        commitRuleAndPublish();

        declaration.additionalInformation_TextHeader = "Bob";
        declaration.additionalInfoText_Header = "not the same";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionFieldNotEqualValue_oneDifferentOneBlank_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = "Jane";
        commitRuleAndPublish();

        declaration.additionalInformation_TextHeader = "Bob";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionFieldNotEqualValue_allSame_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = "Jane";
        commitRuleAndPublish();

        declaration.additionalInformation_TextHeader = " Jane";
        declaration.additionalInfoText_Header = "Jane";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionFieldNotEqualValue_oneSameOneDifferent_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = "Jane";
        commitRuleAndPublish();

        declaration.additionalInformation_TextHeader = "Bob";
        declaration.additionalInfoText_Header = "Jane";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionFieldNotEqualValue_oneSameOneBlank_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = "Jane";
        commitRuleAndPublish();

        declaration.additionalInfoText_Header = "Jane";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionFieldNotEqualValue_allFieldNull_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = "Jane";
        commitRuleAndPublish();

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberCollectionFieldNotEqualValue_thenRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.declaredDutyTaxFees_TaxAmountItemCollection().attribute;
        condition.value = "12.8";
        commitRuleAndPublish();

        declaration.declaredDutyTaxFees_TaxAmountItem = "999.99";
        declaration.taxAmount = "789.29";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberCollectionFieldNotEqualValue_oneDifferentOneBlank_thenRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.declaredDutyTaxFees_TaxAmountItemCollection().attribute;
        condition.value = "12.8";
        commitRuleAndPublish();

        declaration.taxAmount = "789.29";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberCollectionFieldNotEqualValue_allSame_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.declaredDutyTaxFees_TaxAmountItemCollection().attribute;
        condition.value = "12.8";
        commitRuleAndPublish();

        declaration.declaredDutyTaxFees_TaxAmountItem = "12.8";
        declaration.taxAmount = "12.8";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberCollectionFieldNotEqualValue_oneSameOneDifferent_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.declaredDutyTaxFees_TaxAmountItemCollection().attribute;
        condition.value = "12.8";
        commitRuleAndPublish();

        declaration.declaredDutyTaxFees_TaxAmountItem = "12.8";
        declaration.taxAmount = "789.29";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberCollectionFieldNotEqualValue_oneSameOneBlank_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.declaredDutyTaxFees_TaxAmountItemCollection().attribute;
        condition.value = "12.8";
        commitRuleAndPublish();

        declaration.taxAmount = "12.8";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberCollectionFieldNotEqualValue_allFieldNull_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.declaredDutyTaxFees_TaxAmountItemCollection().attribute;
        condition.value = "12.8";
        commitRuleAndPublish();

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    /*
     * multiple fields from same collection to value
     */
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionMultipleFieldsNotEqualValues_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = "Jane";

        RuleDetails.Condition condition = Conditions.additionalInfoCode_HeaderCollections();
        condition.operator = "neq";
        condition.value = "789";
        testRule.queryConditions.get(0).conditions.add(condition);

        commitRuleAndPublish();

        declaration.additionalInformation_TextHeader = "Bob";
        declaration.additionalInfoText_Header = "not the same";

        declaration.additionalInformation_CodeHeader = "123";
        declaration.additionalInfoCode_Header = "456";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionMultipleFieldsNotEqualValues_populatedFieldsDifferentOtherFieldsOnSameItemBlank_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = "Jane";

        RuleDetails.Condition condition = Conditions.additionalInfoCode_HeaderCollections();
        condition.operator = "neq";
        condition.value = "789";
        testRule.queryConditions.get(0).conditions.add(condition);

        commitRuleAndPublish();

        declaration.additionalInformation_TextHeader = "Bob";
        declaration.additionalInfoText_Header = "";

        declaration.additionalInformation_CodeHeader = "";
        declaration.additionalInfoCode_Header = "456";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionMultipleFieldsMixOfEqualAndNotEqualValues_fieldsMatchAllConditionsOnSameCollectionItemFailOnOthers_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = "Jane";

        RuleDetails.Condition condition = Conditions.additionalInfoCode_HeaderCollections();
        condition.operator = "eq";
        condition.value = "789";
        testRule.queryConditions.get(0).conditions.add(condition);

        commitRuleAndPublish();

        declaration.additionalInformation_TextHeader = "Bob";
        declaration.additionalInformation_CodeHeader = "789";

        declaration.additionalInfoText_Header = "Jane";
        declaration.additionalInfoCode_Header = "456";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionMultipleFieldsMixOfEqualAndNotEqualValues_matchAcrossDifferentItemsButNoMatchOnSameItem_thenRouteNotReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = "Jane";

        RuleDetails.Condition condition = Conditions.additionalInfoCode_HeaderCollections();
        condition.operator = "eq";
        condition.value = "789";
        testRule.queryConditions.get(0).conditions.add(condition);

        commitRuleAndPublish();

        declaration.additionalInformation_TextHeader = "Jane";
        declaration.additionalInformation_CodeHeader = "789";

        declaration.additionalInfoText_Header = "Bob";
        declaration.additionalInfoCode_Header = "456";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    /*
     * collection field to collection field
     */
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionFieldNotEqualCollection_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = Conditions.additionalInfoCode_HeaderCollections().attribute;
        commitRuleAndPublish();

        declaration.additionalInformation_CodeHeader = "Bob";
        declaration.additionalInfoCode_Header = "not the same";
        declaration.additionalInformation_TextHeader = "Jane";
        declaration.additionalInfoText_Header = "different";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionFieldNotEqualCollection_oneBlankLHS_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = Conditions.additionalInfoCode_HeaderCollections().attribute;
        commitRuleAndPublish();

        declaration.additionalInformation_CodeHeader = "Bob";
        declaration.additionalInformation_TextHeader = "Jane";
        declaration.additionalInfoText_Header = "different";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionFieldNotEqualCollection_oneBlankRHS_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = Conditions.additionalInfoCode_HeaderCollections().attribute;
        commitRuleAndPublish();

        declaration.additionalInformation_CodeHeader = "Bob";
        declaration.additionalInfoCode_Header = "not the same";
        declaration.additionalInformation_TextHeader = "Jane";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionFieldNotEqualCollection_oneBlankBothSide_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = Conditions.additionalInfoCode_HeaderCollections().attribute;
        commitRuleAndPublish();

        declaration.additionalInfoCode_Header = "not the same";
        declaration.additionalInformation_TextHeader = "Jane";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionFieldNotEqualCollection_allSame_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = Conditions.additionalInfoCode_HeaderCollections().attribute;
        commitRuleAndPublish();

        declaration.additionalInformation_CodeHeader = "Bob";
        declaration.additionalInfoCode_Header = "Bob";
        declaration.additionalInformation_TextHeader = "Bob";
        declaration.additionalInfoText_Header = "Bob";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionFieldNotEqualCollection_someSame_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = Conditions.additionalInfoCode_HeaderCollections().attribute;
        commitRuleAndPublish();

        declaration.additionalInformation_CodeHeader = "Bob";
        declaration.additionalInfoCode_Header = "Jane";
        declaration.additionalInformation_TextHeader = "Mary";
        declaration.additionalInfoText_Header = "Bob";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionFieldNotEqualCollection_allBlankLHS_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = Conditions.additionalInfoCode_HeaderCollections().attribute;
        commitRuleAndPublish();

        declaration.additionalInformation_TextHeader = "Mary";
        declaration.additionalInfoText_Header = "Bob";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionFieldNotEqualCollection_allBlankRHS_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = Conditions.additionalInfoCode_HeaderCollections().attribute;
        commitRuleAndPublish();

        declaration.additionalInformation_CodeHeader = "Bob";
        declaration.additionalInfoCode_Header = "Jane";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionFieldNotEqualCollection_allBlankRHSSomeBlankLHS_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = Conditions.additionalInfoCode_HeaderCollections().attribute;
        commitRuleAndPublish();

        declaration.additionalInfoCode_Header = "Jane";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionFieldNotEqualCollection_allBlankBothSides_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = Conditions.additionalInfoCode_HeaderCollections().attribute;
        commitRuleAndPublish();

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberCollectionFieldNotEqualCollection_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.declaredDutyTaxFees_TaxAmountItemCollection().attribute;
        condition.value = Conditions.declaredDutyTaxFees_VatValueItemCollection().attribute;
        commitRuleAndPublish();

        declaration.declaredDutyTaxFees_TaxAmountItem = "999.99";
        declaration.taxAmount = "789.29";

        declaration.declaredDutyTaxFees_TaxTypeItem = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.declaredDutyTaxFees_VatValueItem = "123.35";
        declaration.taxTypeCode = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue = "741";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionNotContainsValue_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = "Jane";

        RuleDetails.Condition condition = Conditions.additionalInfoCode_HeaderCollections();
        condition.operator = "nco";
        condition.value = "789";
        testRule.queryConditions.get(0).conditions.add(condition);

        commitRuleAndPublish();

        declaration.additionalInformation_TextHeader = "Mary";
        declaration.additionalInformation_CodeHeader = "781234567";

        declaration.additionalInfoText_Header = "Bob";
        declaration.additionalInfoCode_Header = "09877784";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionNotStartsValue_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.additionalInfoText_HeaderCollections().attribute;
        condition.value = "Jane";

        RuleDetails.Condition condition = Conditions.additionalInfoCode_HeaderCollections();
        condition.operator = "nst";
        condition.value = "789";
        testRule.queryConditions.get(0).conditions.add(condition);

        commitRuleAndPublish();

        declaration.additionalInformation_TextHeader = "Mary";
        declaration.additionalInformation_CodeHeader = "781234567";

        declaration.additionalInfoText_Header = "Bob";
        declaration.additionalInfoCode_Header = "09877784";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    public void whenCollectionNotEqualDataTable_ValueExistsInDataTable_thenRouteNotReturned() {

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CountryCode_Valid();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(createDataTableResponse.uuid);
        //tableDetails.tableVersionUuid = responseDetail.tableVersionUuid;
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //add data items to data table
        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        condition.attribute = Conditions.goodsLocationCountry().attribute;
        condition.conditionType = ConditionType.datatable;
        condition.operator = "neq";
        condition.value = tableDetails.uuid;
        condition.isDataTable = true;
        commitRuleAndPublish();

        declaration.goodsLocationCountry = "FR";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionNotEqualsToForPaymentMethod_thenRoutesShouldbeReturnedCorrectly() {

        condition.attributeType = ITEM_COLLECTION;
        condition.conditionType = normal;
        condition.attribute = Conditions.declaredDutyTaxFees_PaymentMethodItemCollection().attribute;
        condition.operator = "neq";
        condition.value = "A";
        commitRuleAndPublish();
        declaration.declaredDutyTaxFees_PaymentMethodItem="A";
        DeclarationResponse declarationResponse1 = riskDeclaration();
        declaration.declaredDutyTaxFees_PaymentMethodItem="B";
        DeclarationResponse declarationResponse2 = riskDeclaration();
        declaration.declaredDutyTaxFees_PaymentMethodItem="1";
        DeclarationResponse  declarationResponse3 = riskDeclaration();
        assertThat(declarationResponse1.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
        assertThat(declarationResponse2.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
        assertThat(declarationResponse3.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionNotEqualsToForPackageTypes_NotInDeclaration_thenNoRouteReturned() {

        condition.attributeType = ITEM_COLLECTION;
        condition.conditionType = normal;
        condition.attribute = Conditions.packageCount_ItemCollections().attribute;
        condition.operator = "neq";
        condition.value = "5";

        RuleDetails.Condition condition = Conditions.packageType_ItemCollections();
        condition.operator = "neq";
        condition.value = "AB";
        testRule.queryConditions.get(0).conditions.add(condition);


        commitRuleAndPublish();
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenCollectionNotEqualsValue_noOfrulesHitShouldBeCorrect() {

        condition.attributeType = ITEM_COLLECTION;
        condition.conditionType = normal;
        condition.attribute = Conditions.additionalDocumentsType_ItemCollections().attribute;
        condition.operator = "neq";
        condition.value = "ABCDEF";
        commitRuleAndPublish();

        DeclarationResponse declarationResponse = createDeclarationForAdditionalDocuments();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3315.class})
    public void whenAdditionalCommodityCodeNATCollectionNotEqualsValue_NotEqualInDeclaration_thenRouteReturned() {

        condition.attributeType = ITEM_COLLECTION;
        condition.conditionType = normal;
        condition.attribute = Conditions.natClassifications_IdItemCollection().attribute;
        condition.operator = "neq";
        condition.value = "ABD1";
        commitRuleAndPublish();

        declaration.natClassificationId = "1234";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

    }

    @Test
    @Category({ChangeRequest.CR_3315.class})
    public void whenAdditionalCommodityCodeTaricCollectionNotStartsValue_NotStartsInDeclaration_thenRouteReturned() {

        condition.attributeType = ITEM_COLLECTION;
        condition.conditionType = normal;
        condition.attribute = Conditions.taricClassifications_IdItemCollection().attribute;
        condition.operator = "nst";
        condition.value = "66";
        commitRuleAndPublish();

        declaration.taricClassificationId = "7358";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

    }

    @Test
    @Category({ChangeRequest.CR_3322.class})
    public void whenAdditionalDocumentsStatusNotMatchesPatternValue_ValueNotInDeclaration_thenRouteReturned() {

        condition.attributeType = ITEM_COLLECTION;
        condition.conditionType = normal;
        condition.attribute = Conditions.additionalDocuments_StatusItemCollection().attribute;
        condition.operator = "notMatchesPattern";
        condition.value = "?A";
        commitRuleAndPublish();

        declaration.additionalDocuments_StatusItem = "BB";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

    }

    @Test
    @Category({ChangeRequest.CR_3322.class})
    public void whenAdditionalDocumentsStatusNotPresent_PresentInDeclaration_thenNoRouteReturned() {

        condition.attributeType = ITEM_COLLECTION;
        condition.conditionType = normal;
        condition.attribute = Conditions.additionalDocuments_StatusItemCollection().attribute;
        condition.operator = "npr";
        condition.value = " ";
        commitRuleAndPublish();

        declaration.additionalDocuments_StatusItem = "BB";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);

    }

    @Test
    @Category({ChangeRequest.CR_3414.class})
    public void whenValuationAdjustCodeNotEqualValue_ConditionAndDeclarationNotEqual_thenRouteReturned() {
        condition.attributeType = HEADER_COLLECTION;
        condition.conditionType = normal;
        condition.operator = "neq";
        condition.attribute = Conditions.valuationAdjustCode_Header().attribute;
        condition.value="AH1";
        commitRuleAndPublish();
        declaration.valuationAdjustCode_Header="B33";
        declaration.valuationAdjustCode2_Header="B34";
        DeclarationResponse declarationResponse = riskDeclarationForMultipleItems();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3414.class})
    public void whenValuationAdjustAmountNotEqualValue_OneValueSameInCollection_thenRouteNotReturned() {
        condition.attributeType = HEADER_COLLECTION;
        condition.conditionType = normal;
        condition.operator = "neq";
        condition.attribute = Conditions.valuationAdjustAmount().attribute;
        condition.value="17789.333";
        commitRuleAndPublish();
        declaration.valuationAdjustAmount_Header="17789.333";
        declaration.valuationAdjustAmount2_Header="17788.40";
        DeclarationResponse declarationResponse = riskDeclarationForMultipleItems();
        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CR_3414.class})
    public void whenValuationAdjustCurrencyNotEqualValue_OneValueSameInCollection_thenRouteNotReturned() {
        condition.attributeType = HEADER_COLLECTION;
        condition.conditionType = normal;
        condition.operator = "neq";
        condition.attribute = Conditions.valuationAdjustCurrency().attribute;
        condition.value="150";
        commitRuleAndPublish();
        declaration.valuationAdjustAmount_Header="17789.83";
        declaration.valuationAdjustAmount2_Header="17788.40";
        declaration.valuationAdjustCurrency_Header="150";
        declaration.valuationAdjustCurrency2_Header="190";
        DeclarationResponse declarationResponse = riskDeclarationForMultipleItems();
        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    private DeclarationResponse createDeclarationForAdditionalDocuments() {

        DeclarationModel model = DeclarationModel.builder().declarationType("EX").declarationSubType("C").transportMode("4").transportType("1")
                .goodsLocationName("GBBYMNCABZNASInfo")
                .goodsLocationID("GBBYMNCABZNASInfo")
                .goodsItems(
                        createGoodsItem()
                )
                .build();

        String declarationRequest = declarationSupport.createDeclaration(declarationSupport.getDefaultDynamicCollectionDeclarationTemplate(),
                model);

        queue.send(declarationRequest);
        return new DeclarationResponse(queue.receive());
    }
    //Will be used in future

    private String createGoodsItem() {
        ItemModel model = ItemModel.builder()
                .sequenceNumber("1")
                .additionalDocuments( createAdditionalDocumentsType() )
                .build();

        ItemColllectionsTemplates itemCollectionsTemplates = new ItemColllectionsTemplates();
        return declarationSupport.createDeclaration(itemCollectionsTemplates.getItemTemplate(), model);
    }

    private String createAdditionalDocumentsType() {
        ItemModel.AdditionalDocuments doc1 = ItemModel.AdditionalDocuments.builder().type("FEDCB").build();

        ItemModel.AdditionalDocuments doc2 = ItemModel.AdditionalDocuments.builder().type("FEDCBA")
                .build();
        String result1 = declarationSupport.createDeclaration(declarationSupport.getAdditionalDocuments(),
                doc1);
        String result2 = declarationSupport.createDeclaration(declarationSupport.getAdditionalDocuments(),
                doc2);
               return result1.concat(result2);
    }

}
