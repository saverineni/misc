package TestCases.RiskingService;

import API.DataForTests.Conditions;
import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestRuleModel.RuleDetails;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.Utils.RuleAtStatus;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service;
import TestCases.BaseWebAPITestCase;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeoutException;

import static API.DataForTests.TestRuleModel.RuleDetails.AttributeType.HEADER;
import static API.DataForTests.TestRuleModel.RuleDetails.AttributeType.HEADER_COLLECTION;
import static API.DataForTests.TestRuleModel.RuleDetails.AttributeType.ITEM;
import static API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody;
import static org.assertj.core.api.Java6Assertions.assertThat;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.crossmatch;

@Slf4j
@Category(Risking_Service.class)
public class TestCase_RiskingMatchingAttributes extends BaseWebAPITestCase {

    @Before
    public void setup() throws IOException, TimeoutException {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
    }


    @Test
    @Category({ChangeRequest.CR_2849.class})
    public void WhenDeclarationSubmittedForRuleMatchingAttributeHeaderToItem_RouteReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = HEADER;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.consigneeName().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.consigneeName_Item().attribute;

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.consigneeName = "SameConsignee";
        declaration.consigneeName_Item = "SameConsignee";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_2849.class})
    public void WhenDeclarationSubmittedForRuleNotMatchingAttributeHeaderToItem_NoRouteReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = HEADER;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.consigneeName().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.consigneeName_Item().attribute;

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeName = "SameConsignee";
        declaration.consigneeName_Item = "NewConsignee";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());


        //Assert
        declaration.controlTypeExpectedValue = "";
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_2849.class})
   // @Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenDeclarationSubmittedForRuleMatchingAttributeHeaderToHeader_RouteReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = HEADER;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.consigneeName().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.consignorName_Header().attribute;

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.consigneeName = "SameConsign";
        declaration.consignorName_Header = "SameConsign";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_2849.class})
    public void WhenDeclarationSubmittedForRuleNotMatchingAttributeHeaderToHeader_NoRouteReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = ITEM;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.consigneeName().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.consignorName_Header().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeName = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.consigneeName = "SameConsign";
        declaration.consignorName_Header = "NewConsign";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        declaration.controlTypeExpectedValue = "";
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Ignore("Not Implemented in CR-2849")
    @Test
    @Category({ChangeRequest.CR_2849.class})
    public void WhenDeclarationSubmittedForRuleMatchingAttributeItemToHeader_RouteReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = HEADER;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.consigneeName_Item().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.consigneeName().attribute;

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeName_Item = "SameConsign";
        declaration.consigneeName = "SameConsign";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CR_2849.class})
    public void WhenDeclarationSubmittedForRuleNotMatchingAttributeItemToHeader_NoRouteReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = ITEM;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.consigneeName_Item().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.consigneeName().attribute;

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeName_Item = "SameConsign";
        declaration.consigneeName = "NewConsign";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        declaration.controlTypeExpectedValue = "";
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_2849.class})
    public void WhenDeclarationSubmittedForRuleMatchingAttributeItemToItem_RouteReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = ITEM;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.consigneeName_Item().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.exporterConsignorName_Item().attribute;

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.consigneeName_Item = "SameConsign";
        declaration.exporterConsignorName_Item = "SameConsign";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_2974.class})
    public void WhenDeclarationSubmittedForRuleMatchingAttributeHeaderToDomain_RouteReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = HEADER;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.consigneeCountry().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.country().attribute;

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.consigneeCountry = "SC";
        declaration.dispatchCountry = "SC";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_2974.class})
    public void WhenDeclarationSubmittedForRuleMatchingAttributeItemToDomain_RouteReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = HEADER;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.destinationCountry_Item().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.country().attribute;

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.destinationCountry_Item = "SC";
        declaration.dispatchCountry_Item = "SC";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_2974.class})
    public void WhenDeclarationSubmittedForRuleMatchingAttributeHeaderToHeaderCollection_RouteReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = HEADER;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.consigneeName().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.additionalInfoText_HeaderCollections().attribute;

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.consigneeName = "SameName";
        declaration.additionalInfoText_Header = "SameName";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumericalAttributeToCollectionAndCollectionContainsNull_NoRouteReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = ITEM;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.commodityNetMass().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.additionalDocuments_QuantityItemCollection().attribute;

        EditRuleVersionResponse.PutResponse response = RuleAtStatus.CreateCommittedRule(ruleDetails);
        Assertions.assertThat(response.httpStatusCode)
                  .describedAs("Failed to commit rule. response:\n"+response.body)
                  .isEqualTo(200);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.commodityNetMass = "12.51";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        declaration.controlTypeExpectedValue = "";
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3331.class})
    public void WhenDeclarationSubmittedForRuleMatchingAttributeHeaderCollectionToHeaderCollection_RouteReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = HEADER_COLLECTION;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.additionalDocumentsId_HeaderCollections().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.additionalInfoText_HeaderCollections().attribute;

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.additionalDocuments_IdHeader = "77777777";
        declaration.additionalInfoText_Header = "77777777";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
}
