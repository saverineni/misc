package TestCases.UI.Users;

import API.DataForTests.PaginationInfo;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Utils.Users;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Users;
import Categories_CDSRisk.CDS_Risk_UI_Users_2;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.PaginationToolBar;
import UI.Pages.UserManagement.ListUsers_Page;
import UI.Utils.Navigation;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.openqa.selenium.WebElement;
import java.util.List;
import java.util.stream.IntStream;
import static FunctionsLibrary.Utils.SleepForMilliSeconds;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Users.class, CDS_Risk_UI_Users_2.class})
public class TestCase_SortUsers extends BaseUIWebDriverTestCase {
    private PaginationInfo paginationInfo;


    @Test
    @Category(ChangeRequest.CR_2247.class)
    public void WhenNameIsSortedInAscendingOrder_NameIsDisplayedInCorrectOrder() {

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsAdmin);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);
        listUsers_page.sortNameColum();

        //Assert
        List<WebElement> element = listUsers_page.getColumnValues();
        Assertions.assertThat(
                isSordertingOrderCorrect(listUsers_page.getListOfUsers(), "name", "ASC")).isEqualTo(true);

    }

    @Test
    @Category(ChangeRequest.CR_2247.class)
    public void WhenNameIsSortedInDescendingOrder_NameIsDisplayedInCorrectOrder() {

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsAdmin);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);
        listUsers_page.sortNameColum();
        listUsers_page.descSort();

        //Assert
        List<WebElement> element = listUsers_page.getColumnValues();
        Assertions.assertThat(
                isSordertingOrderCorrect(listUsers_page.getListOfUsers(), "name", "DESC")).isEqualTo(true);

    }

    @Test
    @Category(ChangeRequest.CR_2247.class)
    public void WhenPIDIsSortedInDescendingOrder_PIDIsDisplayedInCorrectOrderInMultiplePages() {

        //Arrange
        Users.createAListOfUsers();
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsAdmin);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);
        listUsers_page.sortPidColum();
        listUsers_page.descSort();

        paginationInfo = new PaginationInfo();
        paginationInfo.iSizeOfPage = 5;
        paginationInfo.iElementsAdded = 0;
        paginationInfo = paginationInfo.calculatePaginationInfo(paginationInfo);
        PaginationToolBar paginationToolBar = new PaginationToolBar(driver);
        paginationToolBar.selectPageSize(paginationInfo.iSizeOfPage);
        SleepForMilliSeconds(500);
        List<ListUsers_Page.UserListTableObject> userListTableObjectsPage1 = listUsers_page.getListOfUsers();
        paginationToolBar.nextPage.click();
        SleepForMilliSeconds(500);
        List<ListUsers_Page.UserListTableObject> userListTableObjectsPage2 = listUsers_page.getListOfUsers();

        //Assert
        Assertions.assertThat(
                isSordertingOrderCorrect(userListTableObjectsPage1, "pid", "DESC")).isEqualTo(true);

        Assertions.assertThat(
                isSordertingOrderCorrect(userListTableObjectsPage2, "pid", "DESC")).isEqualTo(true);

    }


    private boolean isSordertingOrderCorrect(List<ListUsers_Page.UserListTableObject> userListTableObjects, String property, String order) {

        if (property.equals("pid")) {
            return IntStream.range(0, userListTableObjects.size() - 1)
                    .allMatch(i -> {
                        String pid1 = userListTableObjects.get(i).pid;
                        String pid2 = userListTableObjects.get(i + 1).pid;
                        boolean sortedOrder = order.equals("DESC") ? pid1.compareTo(pid2) >= 0 : pid1.compareTo(pid2) <= 0;
                        return sortedOrder;
                    });

        } else if (property.equals("name")) {
            return IntStream.range(0, userListTableObjects.size() - 1)
                    .allMatch(i -> {
                        String pid1 = userListTableObjects.get(i).name;
                        String pid2 = userListTableObjects.get(i + 1).name;
                        boolean sortedOrder = order.equals("DESC") ? pid1.compareTo(pid2) >= 0 : pid1.compareTo(pid2) <= 0;
                        return sortedOrder;
                    });

        }
        return false;
    }

}
