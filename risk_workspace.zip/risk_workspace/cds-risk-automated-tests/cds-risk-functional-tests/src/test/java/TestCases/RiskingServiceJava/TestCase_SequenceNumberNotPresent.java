package TestCases.RiskingServiceJava;

import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.Risking_JavaService;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.ConditionType;
import uk.gov.hmrc.risk.test.common.enums.DeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.HeaderDeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.Operator;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel.Query;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.Condition;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.conditions;

@Slf4j
@Category({ChangeRequest_RiskingService.CREP_482.class, Risking_JavaService.class})
public class TestCase_SequenceNumberNotPresent extends BaseRiskingServiceJava{

    @Test
    public void WhenDeclarationWithoutSequenceNumberIsSent_ErrorIsSent() {
        createRule(Arrays.asList(consignorCityHeaderQuery()));

        Map<DeclarationParam, String> declarationFields = new HashMap<>();
        conditions( consignorCityHeaderCondition(), declarationType(), declarationSubtype(), transpoerMode())
                .forEach(condition -> declarationFields.put(condition.declarationParam, condition.declarationValue) );

        DeclarationResponse response = sendDeclaration(declarationFields, false, true);

        Assertions.assertThat(response.getFaultCode()).isEqualTo("soapenv:client");
        Assertions.assertThat(response.getFaultString()).isEqualTo("Error unmarshalling message to RiskAssessmentRequest");

    }

    private void createRule(List<Query> conditions) {
        CreateRuleModel model = createRuleModel();

        model.getQuery().get(0).setQuery( conditions );

        createAndRefreshRule(model);
    }

    private Query consignorCityHeaderQuery() {
        return Query.builder()
                .attribute(HeaderDeclarationParam.CONSIGNOR_ADDRESS_CITY.toString())
                .conditionType(ConditionType.normal.toString())
                .operator(Operator.eq.toString())
                .value("ConsignorCity")
                .build();
    }

    private Condition consignorCityHeaderCondition() {
        return Condition.builder()
                .declarationParam(HeaderDeclarationParam.CONSIGNOR_ADDRESS_CITY)
                .declarationValue("ConsignorCity")
                .build();
    }
}
