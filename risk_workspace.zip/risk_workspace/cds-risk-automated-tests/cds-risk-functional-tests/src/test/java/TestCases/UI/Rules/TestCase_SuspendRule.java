package TestCases.UI.Rules;

import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import Categories_CDSRisk.*;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleDetails_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_2.class})
public class TestCase_SuspendRule extends BaseUIWebDriverTestCase{

    @Test
    @Category({SmokeTests_UI_2.class, ChangeRequest.CR_1574.class,ChangeRequest.CR_3203.class})
    public void WhenNationalRuleManagerLoggedIn_CanSuspendCommittedRule()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();
        ruleDetails.description = committedRuleResponse.description;

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        boolean bSuspendEnabled = ruleSummary_page.suspendRule.isEnabled();
        assertEquals("Expect suspend button to be enabled", true, bSuspendEnabled);

        Dialog_Confirm dialog_confirm = ruleSummary_page.clickSuspendButton();
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        ruleSummary_page.waitForAngularRequestsToFinish();
        publishAndWait(5000);

        ruleSummary_page.refreshPage();

        //Assert
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();

        assertEquals(ruleDetails.description, listRuleSummaryTableObjects.get(0).description);
        assertEquals("Expect Rule Version to be 1", ruleDetails.version, listRuleSummaryTableObjects.get(0).version);
        assertEquals("Expect Rule Status to be Suspended", "Suspended", listRuleSummaryTableObjects.get(0).status);
        assertEquals("View\n" + "Rule Revision 1", listRuleSummaryTableObjects.get(0).versionDetailAction.getText());

        //TO DO Check locations
        //need to store location name for checks in UI
        assertEquals("ABZ - Aberdeen Airport", ruleSummary_page.locations.getText().trim());
    }


    @Test
    public void WhenLocalRuleManagerLoggedIn_CanSuspendCommittedRule()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        ruleDetails.description = committedRuleResponse.description;

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        Dialog_Confirm dialog_confirm = ruleSummary_page.clickSuspendButton();
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        ruleSummary_page.waitForAngularRequestsToFinish();
        publishAndWait(5000);
        ruleSummary_page.refreshPage();

        //Assert
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        String sRuleStatus = listRuleSummaryTableObjects.get(0).status;

        assertEquals("Expect Rule Status to be Suspended", "Suspended", sRuleStatus);
    }


    @Test
    public void WhenNationalRuleViewerLoggedIn_CanNOTSuspendCommittedRule()
    {
        //Arrange
        TestUserModel.UserDetails userDetails_RM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RM);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_RM.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();
        ruleDetails.description = committedRuleResponse.description;

        TestUserModel.UserDetails UserDetails_RV = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Assert
        boolean bSuspendEnabled = ruleSummary_page.isActionButtonPresent("Suspend Rule");
        assertEquals("Expect SUSPENDED button to be not present", false, bSuspendEnabled);
    }


    @Test
    public void WhenLocalRuleViewerLoggedIn_CanNOTSuspendCommittedRule()
    {
        //Arrange
        TestUserModel.UserDetails userDetails_RM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RM);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_RM.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        ruleDetails.description = committedRuleResponse.description;

        TestUserModel.UserDetails UserDetails_RV = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Assert
        boolean bSuspendEnabled = ruleSummary_page.isActionButtonPresent("Suspend Rule");
        assertEquals("Expect SUSPENDED button to be not present", false, bSuspendEnabled);
    }


    @Test
    @Category(ChangeRequest.CR_1574.class)
    public void WhenRuleManagerSuspendsRule_ConfirmationMessageAppears()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();
        ruleDetails.description = committedRuleResponse.description;

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);
        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Act
        Dialog_Confirm dialog_confirm = ruleSummary_page.clickSuspendButton();
        String actText = dialog_confirm.getMessageText();

        //Assert
        assertEquals("Please enter a reason for suspending this rule", actText);
        assertTrue("Expect OK button to be present", dialog_confirm.ok.isDisplayed());
        assertTrue("Expect Cancel button to be present", dialog_confirm.cancel.isDisplayed());
    }


    @Test
    @Category(ChangeRequest.CR_1574.class)
    public void WhenRuleManagerCancelsSuspendRule_ConfirmationMessageClosed()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();
        ruleDetails.description = committedRuleResponse.description;

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);
        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Act
        Dialog_Confirm dialog_confirm = ruleSummary_page.clickSuspendButton();
        dialog_confirm.clickCancelButton();

        //Assert
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();

        assertEquals("Expect Rule Status to be committed", "Committed", listRuleSummaryTableObjects.get(0).status);
    }

    @Test
    @Category({ChangeRequest.CR_3105.class})
    public void WhenRuleManagerSuspendAnActiveRule_RuleIsSuspendedToUser() throws InterruptedException {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page =  utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(createRuleResponse.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Act
        ruleSummary_page.commitAndConfirm();

        utilNavigation = new Navigation(driver);
        listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        publishAndWait(5000);

        //Assert
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        ruleSummary_page = new RuleSummary_Page(driver);
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();

        assertEquals("Expect Rule Status to be Active", "Active", listRuleSummaryTableObjects.get(0).status);

        ruleSummary_page.suspendAndConfirm();

        ruleSummary_page.waitForAngularRequestsToFinish();

        publishAndWait(5000);

        ruleSummary_page.refreshPage();

        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects1 = ruleSummary_page.getListOfRuleSummaryDetails();

        assertEquals("Expect Rule Status to be Suspended", "Suspended", listRuleSummaryTableObjects1.get(0).status);

        assertTrue(ruleSummary_page.reinstateRule.isDisplayed());
    }

    @Test
    @Category({ChangeRequest.CR_3105.class,ChangeRequest.CR_3203.class, ChangeRequest.CR_3228.class})
    public void WhenRuleManagerReinstatedASuspendedRule_RuleIsReinstated_AllLocationsActionTypeIsDisplayed() throws InterruptedException {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page =  utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(createRuleResponse.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Act
        ruleSummary_page.commitAndConfirm();

        utilNavigation = new Navigation(driver);
        listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        publishAndWait(5000);

        //Assert
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        ruleSummary_page = new RuleSummary_Page(driver);
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();

        assertEquals("Expect Rule Status to be Active", "Active", listRuleSummaryTableObjects.get(0).status);

        ruleSummary_page.suspendAndConfirm();

        ruleSummary_page.waitForAngularRequestsToFinish();

        publishAndWait(5000);

        ruleSummary_page.refreshPage();

        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects1 = ruleSummary_page.getListOfRuleSummaryDetails();

        assertEquals("Expect Rule Status to be Suspended", "Suspended", listRuleSummaryTableObjects1.get(0).status);

        assertTrue(ruleSummary_page.reinstateRule.isDisplayed());

        ruleSummary_page.reinstateAndConfirm();

        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects2 = ruleSummary_page.getListOfRuleSummaryDetails();

        assertEquals("Expect Rule Status to be Committed", "Committed", listRuleSummaryTableObjects2.get(0).status);

        boolean locations = ruleSummary_page.locations.isDisplayed();
        assertEquals("Expect locations are displayed in the Rule Summary Page", true, locations);
        assertEquals("Expect the Location is All Location", "ABZ - Aberdeen Airport", ruleSummary_page.locations.getText());

        boolean actionType = ruleSummary_page.actionType.isDisplayed();
        assertEquals("Expect action type are displayed in the Rule Summary Page", true, actionType);
        assertEquals("Expect the Action Type is Physical Check", "Physical Check", ruleSummary_page.actionType.getText());
    }

    @Test
    @Category({ChangeRequest.CR_2116.class})
    public void WhenRuleManagerSuspendARule_RuleCanBeAmended() throws InterruptedException {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page =  utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(createRuleResponse.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Act
        ruleSummary_page.commitAndConfirm();

        utilNavigation = new Navigation(driver);
        listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        publishAndWait(5000);

        //Assert
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        ruleSummary_page = new RuleSummary_Page(driver);
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();

        assertEquals("Expect Rule Status to be Active", "Active", listRuleSummaryTableObjects.get(0).status);

        ruleSummary_page.suspendAndConfirm();

        ruleSummary_page.waitForAngularRequestsToFinish();

        publishAndWait(5000);

        ruleSummary_page.refreshPage();

        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects1 = ruleSummary_page.getListOfRuleSummaryDetails();

        assertEquals("Expect Rule Status to be Suspended", "Suspended", listRuleSummaryTableObjects1.get(0).status);

        assertTrue(ruleSummary_page.reinstateRule.isDisplayed());

        //Assert
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects2 = ruleSummary_page.getListOfRuleSummaryDetails();

        assertEquals(ruleDetails.description, listRuleSummaryTableObjects2.get(0).description);
        assertEquals("Expect Rule Version to be 1", ruleDetails.version, listRuleSummaryTableObjects2.get(0).version);
        assertEquals("Expect Rule Status to be Suspended", "Suspended", listRuleSummaryTableObjects2.get(0).status);

        listRuleSummaryTableObjects2.get(0).versionDetailActionAmend.click();
        RuleDetails_Page ruleDetails_page = new RuleDetails_Page(driver);
        ruleDetails_page.waitForAngularRequestsToFinish();

        ruleDetails_page.enterHoldNarrativeText();

        ruleDetails_page.clickSaveAndCommitButtonWithDefaultReason();

        ruleSummary_page.waitForAngularRequestsToFinish();

        List<RuleSummary_Page.RuleUpcomingChangesTableObject> listOfUpcomingChangesTableObjects = ruleSummary_page.getListOfUpcomingChanges();

        assertEquals(ruleDetails.description, listOfUpcomingChangesTableObjects.get(0).description);
        assertEquals("Expect Rule Version to be 1", 2, listOfUpcomingChangesTableObjects.get(0).version);
        assertEquals("Expect Rule Status to be Suspended", "Committed", listOfUpcomingChangesTableObjects.get(0).status);
    }
}
