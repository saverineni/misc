package TestCases.RiskingServiceJava.DataDomain;

import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.Risking_JavaService;
import TestCases.RiskingServiceJava.BaseRiskingServiceJava;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.*;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel.Query;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.Condition;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.conditions;

@Slf4j
@Category({ChangeRequest_RiskingService.CREP_281.class, ChangeRequest_RiskingService.CREP_383.class,
        Risking_JavaService.class})
public class TestCase_WhichDomainCauseRuleFire extends BaseRiskingServiceJava {

    @Test
    public void WhenDeclarationHitsRuleWithDataDomainHeaderRule_OneHitOnDeclarationLevelOccur() {
        createRule(Arrays.asList(
                countryDomain()
        ));

        DeclarationResponse response = createAndSendDeclaration(conditions(destinationCountryHeader("PL")));

        Assertions.assertThat(response.getReportBackElements()).contains("/declaration").hasSize(1);

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .contains("Declaration field: 'Destination Country' was equal to a value in data domain: 'Country'.  The value was: 'PL'");
    }

    @Test
    public void WhenDeclarationHitRuleWithDomainConditionsOnItemAttributes_OneItemLevelHitOccur() {
        createRule(Arrays.asList(
                countryDomain()
        ));

        DeclarationResponse response = createAndSendDeclaration(conditions(dispatchCountryItem("PL")));

        Assertions.assertThat(response.getReportBackElements()).contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2001\"]").hasSize(1);

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .contains("Goods Item (sequenceId=2001) field: 'Dispatch Country' was equal to a value in data domain: 'Country'.  The value was: 'PL'");
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenDeclarationHitRuleWithDomainAndHeaderConditionsOnAttributes_OneDeclarationLevelHitOccur() {
        createRule(Arrays.asList(
                countryDomain(), importerCityHeaderQuery()
        ));

        DeclarationResponse response = createAndSendDeclaration( conditions( destinationCountryHeader("PL"), importerCityHeaderCondition() ));

        Assertions.assertThat(response.getReportBackElements()).contains("/declaration").hasSize(1);

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .contains("Declaration field: 'Destination Country' was equal to a value in data domain: 'Country'.  The value was: 'PL'")
                .contains("Declaration field: 'Importer City' was equal to importerCity. The value was: 'importerCity'");
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenDeclarationHitRuleWithDomainAndHeaderConditionsOnAttributes_OneItemLevelHitOccur() {
        createRule(Arrays.asList(
                countryDomain(), importerCityHeaderQuery()
        ));

        DeclarationResponse response = createAndSendDeclaration( conditions( dispatchCountryItem("PL"), importerCityHeaderCondition() ));

        Assertions.assertThat(response.getReportBackElements()).contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2001\"]").hasSize(1);

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .contains("Goods Item (sequenceId=2001) field: 'Dispatch Country' was equal to a value in data domain: 'Country'.  The value was: 'PL'")
                .contains("Declaration field: 'Importer City' was equal to importerCity. The value was: 'importerCity'");
    }

    @Test
    public void WhenDeclarationHitRuleWithDomainAndItemConditionsOnAttributes_OneItemLevelHitOccur() {
        createRule(Arrays.asList(
                countryDomain(), consignorNameDomain()
        ));

        DeclarationResponse response = createAndSendDeclaration(conditions(destinationCountryHeader("PL"), consignorNameItemCondition()));

        Assertions.assertThat(response.getReportBackElements()).contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2001\"]").hasSize(1);

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .contains("Declaration field: 'Destination Country' was equal to a value in data domain: 'Country'.  The value was: 'PL'")
                .contains("Goods Item (sequenceId=2001) field: 'Consignor Name' was equal to a value in data domain: 'Consignor Name'.  The value was: 'ConsignorName'");
    }

    @Test
    public void WhenDeclarationHitRuleWithDomainAndItemConditionsAttributes_OneItemLevelHitOccur() {
        createRule(Arrays.asList(
                countryDomain(), consignorNameDomain()
        ));

        DeclarationResponse response = createAndSendDeclaration(conditions(dispatchCountryItem("PL"), consignorNameItemCondition()));

        Assertions.assertThat(response.getReportBackElements()).contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2001\"]").hasSize(1);

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .contains("Goods Item (sequenceId=2001) field: 'Dispatch Country' was equal to a value in data domain: 'Country'.  The value was: 'PL'")
                .contains("Goods Item (sequenceId=2001) field: 'Consignor Name' was equal to a value in data domain: 'Consignor Name'.  The value was: 'ConsignorName'");
    }


    @Test
    public void WhenDeclarationHitRuleWithDomainWithTwoDifferentValuesOnHeaderAndItemValues_OneItemLevelHitOccur() {
        Query countryDomainWithNewValue = countryDomain();
        countryDomainWithNewValue.setValue("DE");

        createRule(Arrays.asList(
                countryDomain(), countryDomainWithNewValue
        ));

        Condition dispatchCountryItemNewValue = dispatchCountryItem("PL");
        dispatchCountryItemNewValue.setDeclarationValue("DE");

        DeclarationResponse response = createAndSendDeclaration(conditions(destinationCountryHeader("PL"), dispatchCountryItemNewValue));

        Assertions.assertThat(response.getReportBackElements()).contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2001\"]").hasSize(1);

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .contains("Declaration field: 'Destination Country' was equal to a value in data domain: 'Country'.  The value was: 'PL'")
                .contains("Goods Item (sequenceId=2001) field: 'Dispatch Country' was equal to a value in data domain: 'Country'.  The value was: 'DE'");
    }

    @Test
    public void WhenDeclarationHitRuleWithDomainAttributeOnHeaderAndItemValues_OneHeaderAndItemLevelHitsForEachItemOccur() {

        createRule(Arrays.asList(
                countryDomain()
        ));

        DeclarationResponse response = createAndSendDeclaration(conditions(destinationCountryHeader("PL"),
                firstItemSequenceId(), dispatchCountryItem("PL"),
                secondItemSequenceId(), secondItemOriginCountryCondition()));

        Assertions.assertThat(response.getReportBackElements())
                .contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2001\"]")
                .contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2002\"]")
                .contains("/declaration")
                .hasSize(3);

        Assertions.assertThat(response.getMatchReasons()).hasSize(3);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .contains("Goods Item (sequenceId=2001) field: 'Dispatch Country' was equal to a value in data domain: 'Country'.  The value was: 'PL'");

        Assertions.assertThat(response.getMatchReasons().get(1))
                .contains("Goods Item (sequenceId=2002) field: 'Origin Country' was equal to a value in data domain: 'Country'.  The value was: 'PL'");

        Assertions.assertThat(response.getMatchReasons().get(2))
                .contains("Declaration field: 'Destination Country' was equal to a value in data domain: 'Country'.  The value was: 'PL'");
    }

    @Test
   // @Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenDeclarationHitRuleWithTwoDomainAttributesAndOneHeader_OneHeaderOccur() {

        createRule(Arrays.asList(
                countryDomain(), consignorNameDomain()
        ));

        DeclarationResponse response = createAndSendDeclaration(conditions(destinationCountryHeader("PL"), consignorNameHeaderCondition()
        ));


        Assertions.assertThat(response.getReportBackElements())
                .contains("/declaration")
                .hasSize(1);

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .contains("Declaration field: 'Consignor Name' was equal to a value in data domain: 'Consignor Name'.  The value was: 'ConsignorName'")
                .contains("Declaration field: 'Destination Country' was equal to a value in data domain: 'Country'.  The value was: 'PL'");
    }

    @Test
    public void WhenDeclarationDoesNotContainRequiredCountry_MultipleFieldHitOccur() {

        createRule(Collections.singletonList(notCountryDomain("PL")));

        DeclarationResponse response = createAndSendDeclaration(conditions(
                destinationCountryHeader("FR"),
                intermediateCountriesHeader("FR"),
                dispatchCountryHeaderCondition("FR"),
                dispatchCountryItem("FR"),
                destinationCountryItem("FR"),
                originCountryItem("FR")
        ));

        Assertions.assertThat(response.getReportBackElements())
                .containsOnly("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2001\"]",
                                "/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2002\"]",
                                "/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2003\"]",
                                "/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2004\"]");

        Assertions.assertThat(response.getMatchReasons()).hasSize(4);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .containsOnly(
                        "Declaration field: 'Dispatch Country' was populated with a value in data domain: 'Country'.  The value was: 'FR'",
                        "Declaration field: 'Dispatch Country' was not equal to a value in data domain: 'Country'.  The value was: 'FR'",
                        "Declaration field: 'Destination Country' was populated with a value in data domain: 'Country'.  The value was: 'FR'",
                        "Declaration field: 'Destination Country' was not equal to a value in data domain: 'Country'.  The value was: 'FR'",
                        "Goods Item (sequenceId=2001) field: 'Destination Country' was populated with a value in data domain: 'Country'.  The value was: 'FR'",
                        "Goods Item (sequenceId=2001) field: 'Destination Country' was not equal to a value in data domain: 'Country'.  The value was: 'FR'",
                        "Goods Item (sequenceId=2001) field: 'Dispatch Country' was populated with a value in data domain: 'Country'.  The value was: 'FR'",
                        "Goods Item (sequenceId=2001) field: 'Dispatch Country' was not equal to a value in data domain: 'Country'.  The value was: 'FR'",
                        "Goods Item (sequenceId=2001) field: 'Origin Country' was populated with a value in data domain: 'Country'.  The value was: 'FR'",
                        "Goods Item (sequenceId=2001) field: 'Origin Country' was not equal to a value in data domain: 'Country'.  The value was: 'FR'",
                        "Declaration field: 'Declaration Type' was equal to IM. The value was: 'IM'",
                        "Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'",
                        "'Declaration' collection 'Intermediate Countries': Collection fields 'Country Route' matched");

        response.getMatchReasons().stream().skip(1).forEach(r-> {
            Assertions.assertThat(r)
                    .containsOnly(
                            "Declaration field: 'Dispatch Country' was populated with a value in data domain: 'Country'.  The value was: 'FR'",
                            "Declaration field: 'Dispatch Country' was not equal to a value in data domain: 'Country'.  The value was: 'FR'",
                            "Declaration field: 'Destination Country' was populated with a value in data domain: 'Country'.  The value was: 'FR'",
                            "Declaration field: 'Destination Country' was not equal to a value in data domain: 'Country'.  The value was: 'FR'",
                            "Declaration field: 'Declaration Type' was equal to IM. The value was: 'IM'",
                            "'Declaration' collection 'Intermediate Countries': Collection fields 'Country Route' matched",
                            "Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'");
        });
    }

    @Test
    @Category({ChangeRequest.CRX_288.class})
    public void WhenDeclarationHasEmptyDomainFields_HitWillStillOccur() {

        createRule(Collections.singletonList(notCountryDomain("PL")));

        DeclarationResponse response = createAndSendDeclaration(conditions(
                destinationCountryHeader("FR"),
                intermediateCountriesHeader("FR"),
                dispatchCountryHeaderCondition("FR"),
                dispatchCountryItem("FR"),
                destinationCountryItem("FR")
                // originCountryItem("FR") => left empty on purpose
        ));

        Assertions.assertThat(response.getReportBackElements())
                .containsOnly("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2001\"]",
                        "/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2002\"]",
                        "/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2003\"]",
                        "/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2004\"]");

        Assertions.assertThat(response.getMatchReasons()).hasSize(4);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .containsOnly(
                        "Declaration field: 'Dispatch Country' was populated with a value in data domain: 'Country'.  The value was: 'FR'",
                        "Declaration field: 'Dispatch Country' was not equal to a value in data domain: 'Country'.  The value was: 'FR'",
                        "Declaration field: 'Destination Country' was populated with a value in data domain: 'Country'.  The value was: 'FR'",
                        "Declaration field: 'Destination Country' was not equal to a value in data domain: 'Country'.  The value was: 'FR'",
                        "Goods Item (sequenceId=2001) field: 'Destination Country' was populated with a value in data domain: 'Country'.  The value was: 'FR'",
                        "Goods Item (sequenceId=2001) field: 'Destination Country' was not equal to a value in data domain: 'Country'.  The value was: 'FR'",
                        "Goods Item (sequenceId=2001) field: 'Dispatch Country' was populated with a value in data domain: 'Country'.  The value was: 'FR'",
                        "Goods Item (sequenceId=2001) field: 'Dispatch Country' was not equal to a value in data domain: 'Country'.  The value was: 'FR'",
                        "Declaration field: 'Declaration Type' was equal to IM. The value was: 'IM'",
                        "'Declaration' collection 'Intermediate Countries': Collection fields 'Country Route' matched",
                        "Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'");

        response.getMatchReasons().stream().skip(1).forEach(r-> {
            Assertions.assertThat(r)
                    .containsOnly(
                            "Declaration field: 'Dispatch Country' was populated with a value in data domain: 'Country'.  The value was: 'FR'",
                            "Declaration field: 'Dispatch Country' was not equal to a value in data domain: 'Country'.  The value was: 'FR'",
                            "Declaration field: 'Destination Country' was populated with a value in data domain: 'Country'.  The value was: 'FR'",
                            "Declaration field: 'Destination Country' was not equal to a value in data domain: 'Country'.  The value was: 'FR'",
                            "Declaration field: 'Declaration Type' was equal to IM. The value was: 'IM'",
                            "'Declaration' collection 'Intermediate Countries': Collection fields 'Country Route' matched",
                            "Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'");
        });
    }

    @Test
    public void WhenDeclarationContainRequiredCountryOnce_NoFieldHitOccur() {

        createRule(Collections.singletonList(notCountryDomain("PL")));

        DeclarationResponse response = createAndSendDeclaration(conditions(
                destinationCountryHeader("PL"),
                intermediateCountriesHeader("FR"),
                dispatchCountryHeaderCondition("FR"),
                dispatchCountryItem("FR"),
                destinationCountryItem("FR"),
                originCountryItem("FR")
        ));

        Assertions.assertThat(response.getReportBackElements())
                .hasSize(0);

        Assertions.assertThat(response.getMatchReasons()).hasSize(0);
    }

    @Test
    public void WhenDeclarationContainRequiredCountrySeveralTimes_NoFieldHitOccur() {

        createRule(Collections.singletonList(notCountryDomain("PL")));

        DeclarationResponse response = createAndSendDeclaration(conditions(
                destinationCountryHeader("PL"),
                intermediateCountriesHeader("FR"),
                dispatchCountryHeaderCondition("FR"),
                dispatchCountryItem("PL"),
                destinationCountryItem("FR"),
                originCountryItem("PL")
        ));

        Assertions.assertThat(response.getReportBackElements())
                .hasSize(0);

        Assertions.assertThat(response.getMatchReasons()).hasSize(0);
    }

    private void createRule(List<Query> conditions) {
        CreateRuleModel model = createRuleModel();

        model.getQuery().get(0).setQuery(conditions);

        createAndRefreshRule(model);
    }

    private Query countryDomain() {
        return Query.builder()
                .attribute(DomainAttribute.Country.toString())
                .operator(Operator.eq.toString())
                .conditionType(ConditionType.normal.toString())
                .value("PL")
                .build();
    }

    private Query notCountryDomain(String country) {
        return Query.builder()
                .attribute(DomainAttribute.Country.toString())
                .operator(Operator.neq.toString())
                .conditionType(ConditionType.normal.toString())
                .value(country)
                .build();
    }

    private Query consignorNameDomain() {
        return Query.builder()
                .attribute(DomainAttribute.ConsignorName.toString())
                .operator(Operator.eq.toString())
                .conditionType(ConditionType.normal.toString())
                .value("ConsignorName")
                .build();
    }

    private Query importerCityHeaderQuery() {
        return Query.builder()
                .attribute(HeaderDeclarationParam.IMPORTER_CITY_NAME.toString())
                .operator(Operator.eq.toString())
                .conditionType(ConditionType.normal.toString())
                .value("importerCity")
                .build();
    }

    private Condition destinationCountryHeader(String country) {
        return Condition.builder()
                .declarationParam(HeaderDeclarationParam.DESTINATION_COUNTRY)
                .declarationValue(country)
                .build();
    }

    private Condition destinationCountryItem(String country) {
        return Condition.builder()
                .declarationParam(GoodsItemDeclarationParam.DESTINATION_COUNTRY)
                .declarationValue(country)
                .build();
    }

    private Condition originCountryItem(String country) {
        return Condition.builder()
                .declarationParam(GoodsItemDeclarationParam.ORIGIN_COUNTRY)
                .declarationValue(country)
                .build();
    }

    private Condition intermediateCountriesHeader(String country) {
        return Condition.builder()
                .declarationParam(HeaderDeclarationParam.COUNTRY_ROUTE)
                .declarationValue(country)
                .build();
    }

    private Condition consignorNameHeaderCondition() {
        return Condition.builder()
                .declarationParam(HeaderDeclarationParam.CONSIGNOR_NAME)
                .declarationValue("ConsignorName")
                .build();
    }

    private Condition dispatchCountryHeaderCondition(String country) {
        return Condition.builder()
                .declarationParam(HeaderDeclarationParam.DISPATCH_COUNTRY)
                .declarationValue(country)
                .build();
    }

    private Condition importerCityHeaderCondition() {
        return Condition.builder()
                .declarationParam(HeaderDeclarationParam.IMPORTER_CITY_NAME)
                .declarationValue("importerCity")
                .build();
    }

    private Condition consignorNameItemCondition() {
        return Condition.builder()
                .declarationParam(GoodsItemDeclarationParam.CONSIGNORNAME_ITEM)
                .declarationValue("ConsignorName")
                .build();
    }

    private Condition dispatchCountryItem(String country) {
        return Condition.builder()
                .declarationParam(GoodsItemDeclarationParam.DISPATCH_COUNTRY)
                .declarationValue(country)
                .build();
    }

    private Condition secondItemOriginCountryCondition() {
        return Condition.builder()
                .declarationParam(GoodsItemDeclarationParam.Second.ORIGIN_COUNTRY)
                .declarationValue("PL")
                .build();
    }
}
