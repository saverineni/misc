package TestCases.DARService;

import API.DataForTests.TestEnumerators.ShareTypes;
import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.DAR_Client;
import TestCases.RiskingServiceJava.BaseRiskingServiceJava;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.rulesengine.publishing.PublishEventFullDto;
import uk.gov.hmrc.risk.test.common.enums.DarEventType;
import uk.gov.hmrc.risk.test.common.model.darService.DarDataTableAuditModel;
import uk.gov.hmrc.risk.test.common.model.darService.DarDataTableItemsModel;
import uk.gov.hmrc.risk.test.common.model.darService.DarDataTableLocationsModel;
import uk.gov.hmrc.risk.test.common.model.darService.DarDataTableTagsModel;
import uk.gov.hmrc.risk.test.common.model.dataService.DataTableCreationModel;
import uk.gov.hmrc.risk.test.common.model.dataService.DataTableCreationModel.TableShares;
import uk.gov.hmrc.risk.test.common.model.dataService.DataTableDetailsModel;
import uk.gov.hmrc.risk.test.common.model.dataService.DataTableEditModel;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static API.DataForTests.Locations.Location_ABD_UID;
import static API.DataForTests.Locations.Location_BOS_UID;
import static API.DataForTests.Locations.Location_EXT_UID;
import static API.DataForTests.Locations.Location_MAN_UID;

@Slf4j
@Category({ChangeRequest_RiskingService.CREP_294.class, DAR_Client.class})
public class TestCase_AreDataTablesWrittenCorrectly extends BaseRiskingServiceJava{

    PublishEventFullDto publishEvent;
    DataTableCreationModel dataTableCreationModel;
    String dataTableUuid;
    List<String> dataItems = new ArrayList<>();

    @Before
    public void setup() {
        publishAndWait();
        dataTableCreationModel = baseDataTableModel();
        dataTableCreationModel.setTags( Arrays.asList( "tag1", "tag2", "tag3"));
        dataTableCreationModel.setTableShares( Arrays.asList(
            TableShares.builder()
                .locationUuids( Arrays.asList( Location_ABD_UID) )
                .shareType(ShareTypes.creator.toString())
                .build(),
            TableShares.builder()
                .locationUuids( Arrays.asList( Location_BOS_UID, Location_EXT_UID, Location_MAN_UID) )
                .shareType(ShareTypes.owner.toString())
                .build()
            ));
        dataItems.addAll(Arrays.asList( "0000000001", "0000000002", "0000000003", "0000000004", "0000000005"));
        dataTableUuid = dataTableSupport.createDataTable(dataTableCreationModel, dataItems);
        publishEvent = publishAndWait(5000);
    }

    @Test
    public void WhenPublishEventAppear_LatestDataTablesAreWrittenInFile() {

        parseDataTableAuditEventsAndAssertFile("5");
        parseDataTableItemsEventsAndAssertFile();
        parseDataTableLocationsEventsAndAssertFile();
        parseDataTableTagsEventsAndAssertFile();
    }

    @Test
    public void WhenPublishEventAppearAndDataTableWasUpdated_LatestDataTablesAreWrittenInFile() {

        editDataTable();
        publishEvent = publishAndWait(3000);

        parseDataTableAuditEventsAndAssertFile("9");
    }

    private void editDataTable() {
        dataItems = new ArrayList<>();
        dataItems.add("0200000000");
        dataItems.add("0300000000");
        dataItems.add("0400000000");
        dataItems.add("0500000000");

        DataTableDetailsModel details = dataTableSupport.getDataTableDetails(dataTableUuid);

        DataTableEditModel editModel = DataTableEditModel.builder()
                .reason("Testing")
                .description("Test datatable")
                .tableName(details.getTableName())
                .dataTableUuid(details.getUuid())
                .userPid(details.getCreatorPid())
                .opLockVersion(details.getOpLockVersion())
                .addedElements(dataItems)
                .build();

        dataTableSupport.editDataTable_data(editModel);
    }

    private void parseDataTableAuditEventsAndAssertFile(String expecterNoOfItems) {
        List<DarDataTableAuditModel> filtered = darServicePublishingSupport.parseDataTableAuditEvents()
                .stream()
                .filter(model -> matchFileListingsBasedOnPackageId(model.getPackageUuid()))
                .collect(Collectors.toList());
        Assertions.assertThat(filtered.size()).isNotZero();

        filtered.forEach(log ->
        {
            ZonedDateTime logTime = darServiceAuditSupport.getFormattedTimestamp(log.getEventTime());
            Assertions.assertThat(logTime).isBeforeOrEqualTo(ZonedDateTime.now().plusHours(2));
            Assertions.assertThat(log.getType()).isEqualTo(DarEventType.DATA_TABLE_AUDIT.toString());
            Assertions.assertThat(log.getTableUuid()).isEqualTo(dataTableUuid);
            Assertions.assertThat(log.getTableName()).isEqualTo(dataTableCreationModel.getTableName());
            Assertions.assertThat(log.getTableDescription()).isEqualTo(dataTableCreationModel.getDescription());
            Assertions.assertThat(log.getTableType()).isEqualTo("Commodity Code");
            Assertions.assertThat(log.getTableLastChangedBy()).isEqualTo("1234561");
            Assertions.assertThat(log.getNumberOfDataItems()).isEqualTo(expecterNoOfItems);
            Assertions.assertThat(log.getNumberOfTags()).isEqualTo("3");
            Assertions.assertThat(log.getNumberOfLocations()).isEqualTo("4");
        });
    }

    private void parseDataTableItemsEventsAndAssertFile() {
        List<DarDataTableItemsModel> filtered = darServicePublishingSupport.parseDataTableItemsEvents()
                .stream()
                .filter(model -> matchFileListingsBasedOnPackageId(model.getPackageUuid()))
                .collect(Collectors.toList());
        Assertions.assertThat(filtered.size()).isEqualTo(5);
        List<String> items = filtered.stream()
                .map(DarDataTableItemsModel::getValue)
                .collect(Collectors.toList());
        Assertions.assertThat(items).containsExactlyInAnyOrder("0000000001", "0000000002", "0000000003",
                "0000000004", "0000000005");

        filtered.forEach(log ->
        {
            Assertions.assertThat(log.getType()).isEqualTo(DarEventType.DATA_TABLE_ITEMS.toString());
            Assertions.assertThat(log.getTableUuid()).isEqualTo(dataTableUuid);
        });
    }

    private void parseDataTableLocationsEventsAndAssertFile() {
        List<DarDataTableLocationsModel> filtered = darServicePublishingSupport.parseDataTableLocationsEvents()
                .stream()
                .filter(model -> matchFileListingsBasedOnPackageId(model.getPackageUuid()))
                .collect(Collectors.toList());
        Assertions.assertThat(filtered.size()).isEqualTo(4);

        List<String> locUuids = filtered.stream()
                .map(DarDataTableLocationsModel::getLocationUuid)
                .collect(Collectors.toList());
        Assertions.assertThat(locUuids).containsExactlyInAnyOrder(Location_ABD_UID, Location_BOS_UID,
                Location_EXT_UID, Location_MAN_UID);

        List<String> locNames = filtered.stream()
                .map(DarDataTableLocationsModel::getLocationName)
                .collect(Collectors.toList());
        Assertions.assertThat(locNames).containsExactlyInAnyOrder("ABD", "BOS", "EXT", "MAN");

        filtered.forEach(log ->
        {
            Assertions.assertThat(log.getType()).isEqualTo(DarEventType.DATA_TABLE_LOCATIONS.toString());
            Assertions.assertThat(log.getTableUuid()).isEqualTo(dataTableUuid);
        });
    }

    private void parseDataTableTagsEventsAndAssertFile() {
        List<DarDataTableTagsModel> filtered = darServicePublishingSupport.parseDataTableTagsEvents()
                .stream()
                .filter(model -> matchFileListingsBasedOnPackageId(model.getPackageUuid()))
                .collect(Collectors.toList());

        Assertions.assertThat(filtered.size()).isEqualTo(3);
        List<String> tags = filtered.stream()
                .map(DarDataTableTagsModel::getTagName)
                .collect(Collectors.toList());
        Assertions.assertThat(tags).containsExactlyInAnyOrder("tag1", "tag2", "tag3");

        filtered.forEach(log ->
        {
            Assertions.assertThat(log.getType()).isEqualTo(DarEventType.DATA_TABLE_TAGS.toString());
            Assertions.assertThat(log.getTableUuid()).isEqualTo(dataTableUuid);
        });
    }

    private boolean matchFileListingsBasedOnPackageId(String packageId) {
        return packageId.equals(publishEvent.getPublishEventId().toString());
    }
}
