package TestCases.UI.publish;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Publish;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.MenuToolBar;
import UI.Pages.Publish.Publish_Page;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Publish.class})
public class TestCase_PublishInterval extends BaseUIWebDriverTestCase{

    @Test
    @Category(ChangeRequest.CR_2645.class)
    public void WhenPublishIntervalIsSet_PublishIntervalShouldBeSavedCorreactly()
    {
        String publishIntervalInSeconds="150";
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        MenuToolBar menuToolBar = new MenuToolBar(driver);
        menuToolBar.publish.click();

        String reasonForPublishing = "Interval";
        Publish_Page publishPage = new Publish_Page(driver);

        publishPage.publishIntervalTextField.clear();
        publishPage.publishIntervalTextField.sendKeys("3");
        String actualValidationMessage = publishPage.validationMessage.getText();

        publishPage.setThePublishTimeInterval(publishIntervalInSeconds,reasonForPublishing);
        String updatedInterval= publishPage.publishIntervalTextField.getAttribute("value");

        //Assert
        assertEquals("Min value for Publish interval is 60",actualValidationMessage);
        assertEquals(publishIntervalInSeconds,updatedInterval);


    }



}