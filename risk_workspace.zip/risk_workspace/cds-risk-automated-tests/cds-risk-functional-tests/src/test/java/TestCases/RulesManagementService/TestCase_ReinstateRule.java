package TestCases.RulesManagementService;


import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.EditRule.EditRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.RuleAction.RuleActionResponse;
import Categories_CDSRisk.CDS_RM_RuleLifeCycle;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import org.apache.http.HttpStatus;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import static API.RulesManagementService.Utils.RuleAtStatus.*;
import static API.RulesManagementService.Utils.Rules.ReinstateRule;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_RuleLifeCycle.class})
public class TestCase_ReinstateRule extends BaseWebAPITestCase {

    @Test
    @Category(ChangeRequest.CR_351.class)
    public void WhenSuspendedRuleReinstated_RuleActivatedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse suspendResponse = CreateSuspendedRule(ruleDetails);
        ruleDetails.uniqueID = suspendResponse.uniqueId;

        //Act
        RuleActionResponse.PostResponse reinstateResponse = ReinstateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_OK, reinstateResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_351.class)
    public void AttemptToReinstateDraftRule_InvalidRequest() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        RuleActionResponse.PostResponse reinstateResponse = ReinstateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, reinstateResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_351.class)
    public void AttemptToReinstateArchivedRule_InvalidRequest() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse archivedRuleResp = CreateArchivedRule(ruleDetails);

        //Act
        RuleActionResponse.PostResponse reinstateResponse = ReinstateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, reinstateResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_351.class)
    public void AttemptToReinstateReinstatedRule_InvalidRequest() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse reinstatedRuleResp = CreateReinstatedRule();
        ruleDetails.uniqueID = reinstatedRuleResp.uniqueId;

        //Act
        RuleActionResponse.PostResponse reinstateResponse = ReinstateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, reinstateResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_351.class)
    public void AttemptToDeleteReinstatedRule_InvalidRequest() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse reinstatedRuleResp = ReinstateRule(ruleDetails);
        ruleDetails.uniqueID = reinstatedRuleResp.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse deletedResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.delete);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, deletedResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_351.class)
    public void WhenReinstatedRuleUpdated_RuleUpdatedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse suspendedRuleResponse = CreateSuspendedRule(ruleDetails);
        ruleDetails.uniqueID = suspendedRuleResponse.uniqueId;

        RuleActionResponse.PostResponse reinstateResponse = ReinstateRule(ruleDetails);

        //Act
        ruleDetails.description = "ta_ruleupdated";
        EditRuleResponse.PutResponse editResponse = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_OK, editResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.draft.toString(), editResponse.status);
        assertEquals("Expected Rule version 2:", 2, editResponse.versionId);
        assertEquals(ruleDetails.description,  editResponse.description);
    }


    @Test
    @Category(ChangeRequest.CR_351.class)
    public void AttemptToCommitReinstatedRule_InvalidRequest() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse reinstatedRuleResp = CreateReinstatedRule();
        ruleDetails.uniqueID = reinstatedRuleResp.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Ignore("Bug: Reinstating rule with invalid uid get 500 error")
    @Test
    @Category(ChangeRequest.CR_351.class)
    public void AttemptToReinstateRuleWithInvalidID_RuleNotFound() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse suspendedRuleResponse = SuspendRule(ruleDetails);

        //Act
        ruleDetails.uniqueID = suspendedRuleResponse.uniqueId + "zzz";
        RuleActionResponse.PostResponse reinstateResponse = ReinstateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_NOT_FOUND, reinstateResponse.httpStatusCode);

        //TODO Bug: Reinstating rule with invalid uid get 500 error
    }


    @Ignore("Bug: Reinstating rule with invalid uid get 500 error")
    @Test
    @Category(ChangeRequest.CR_351.class)
    public void AttemptToReinstateRuleWithInvalidVersion_RuleNotFound() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse suspendedRuleResponse = SuspendRule(ruleDetails);
        ruleDetails.uniqueID = suspendedRuleResponse.uniqueId;

        //Act
        ruleDetails.version = 9;
        RuleActionResponse.PostResponse reinstateResponse = ReinstateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_NOT_FOUND, reinstateResponse.httpStatusCode);

        //TODO Bug: Reinstating rule with invalid version get 500 error
    }

    @Test
    @Category(ChangeRequest.CR_351.class)
    public void AttemptToReinstateOldRuleVersion_RuleNotFound() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleResponse.PutResponse draftV2Rule = API.RulesManagementService.Utils.RuleAtStatus.CreateDraftRuleVersion2Rule();
        ruleDetails.uniqueID = draftV2Rule.uniqueId;

        RuleActionResponse.PostResponse suspendedResponse = ReinstateRule(ruleDetails);

        //Act
        ruleDetails.version = 1;
        RuleActionResponse.PostResponse reinstateResponse = ReinstateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, reinstateResponse.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_351.class)
    public void AttemptToReinstateRuleWithNoReason_RuleNotReinstated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse suspendedRuleResponse = CreateSuspendedRule(ruleDetails);
        ruleDetails.uniqueID = suspendedRuleResponse.uniqueId;

        //Act
        ruleDetails.reason = null;
        RuleActionResponse.PostResponse reinstateResponse = ReinstateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_OK, reinstateResponse.httpStatusCode);
    }

}
