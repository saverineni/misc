package TestCases;


import API.DataForTests.*;
import API.DataService.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.Data.EditDataTableData.EditDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import API.RulesManagementService.Utils.RuleAtStatus;
import FunctionsLibrary.Utils;
import com.google.common.collect.ImmutableList;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import static org.junit.Assert.assertEquals;

// Used for data setup by jenkins jobs
@Slf4j
public class TestCase_DataSetupForEnvironments extends WebAPITestCaseWithDatatablesCleanup {

    private  ImmutableList<String> immutableList = ImmutableList.of("Animals", "Vegetables", "Fats",
            "Oils", "Minerals", "Chemicals", "Plastics", "Woods", "Textiles", "Metals", "Arms", "Vehicles",
            "Fats of bovine animals", "Fats and oils", "Other animal fats", "Animal or vegetable fats", "Vegetable waxes");

    @Test
    public void TestRandomness(){

        for (int j = 0; j < 10; j++) {
            log.info(Utils.getRandomValueFromList(immutableList));;
        }

    }

    @Test
    public void CreateDataTables() throws Throwable {

        //Creates data table as National user
        String sTablesToCreate = System.getProperty("noOfDataTablesToCreate", "10");
        String sDataItems = System.getProperty("noOfDataItems", "10");

        int noOfDataTablesToCreate = Integer.parseInt(sTablesToCreate);
        int noOfDataItems = Integer.parseInt(sDataItems);
        int iNoOfTagsToAdd = 3;

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        tableDetails.description = "Test Data Table";
        tableDetails.dataType = "Free Text";
        tableDetails.dataTypeUuid = DataTypes.DataType_FreeText_UID;

        UUID uID = UUID.randomUUID();
        String randomChars = uID.toString().substring(0, 7);

        for (int j = 0; j < noOfDataItems; j++) {
            tableDetails.dataItems.add(Integer.toString(j) + randomChars);
        }

        tableDetails.dataItemsToAdd.addAll(tableDetails.dataItems);


        for (int i = 0; i < noOfDataTablesToCreate; i++){

            tableDetails.tableName = FunctionsLibrary.FileUtilities.GenerateAppendUIDToString("datatable_", 5);

            tableDetails.tags.clear();
            for (int t = 0; t < iNoOfTagsToAdd; t++) {
                tableDetails.tags.add(Utils.getRandomValueFromList(immutableList));
            }

            //Act
            CreateDataTableResponse.PostResponse createDataTableResponse = API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
            assertEquals("HTTP Status Code: ", HttpStatus.SC_CREATED, createDataTableResponse.httpStatusCode);

            tableDetails.uuid = createDataTableResponse.uuid;

            ViewDataTableResponse.ViewDataTableResponseObject responseDetail = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(createDataTableResponse.uuid);
            tableDetails.opLockVersion = responseDetail.opLockVersion;

            EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);
            assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, responseEdit.httpStatusCode);

            ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponseObject = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(tableDetails.uuid);
            assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, viewDataTableResponseObject.httpStatusCode);
        }
    }

    @Test
    public void CreateDataTablesForLocations10Locations() throws Throwable {

        String sTablesToCreate = System.getProperty("noOfDataTablesToCreate", "11");
        String sDataItems = System.getProperty("noOfDataItems", "10");

        int noOfDataTablesToCreate = Integer.parseInt(sTablesToCreate);
        int noOfDataItems = Integer.parseInt(sDataItems);
        int iNoOfTagsToAdd = 3;

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        tableDetails.description = "Test Data Table";
        tableDetails.dataType = "Free Text";
        tableDetails.dataTypeUuid = DataTypes.DataType_FreeText_UID;

        UUID uID = UUID.randomUUID();
        String randomChars = uID.toString().substring(0, 7);

        for (int j = 0; j < noOfDataItems; j++) {
            tableDetails.dataItems.add(Integer.toString(j) + randomChars);
        }

        tableDetails.dataItemsToAdd.addAll(tableDetails.dataItems);


        List<String> locationsUIDS = new ArrayList<>();
        locationsUIDS.add(Locations.Location_WAT_UID);
        locationsUIDS.add(Locations.Location_SUN_UID);
        locationsUIDS.add(Locations.Location_BOS_UID);
        locationsUIDS.add(Locations.Location_POO_UID);
        locationsUIDS.add(Locations.Location_EXT_UID);
        locationsUIDS.add(Locations.Location_ABD_UID);
        locationsUIDS.add(Locations.Location_ABZ_UID);
        locationsUIDS.add(Locations.Location_LON_UID);
        locationsUIDS.add(Locations.Location_RMG_UID);
        locationsUIDS.add(Locations.Location_ROS_UID);
        locationsUIDS.add(Locations.Location_AllLocations_UID);

        List<String> locationNames = new ArrayList<>();
        locationNames.add("DAT_WAT");
        locationNames.add("DAT_SUN");
        locationNames.add("DAT_BOS");
        locationNames.add("DAT_POO");
        locationNames.add("DAT_EXT");
        locationNames.add("DAT_ABD");
        locationNames.add("DAT_ABZ");
        locationNames.add("DAT_LON");
        locationNames.add("DAT_RMG");
        locationNames.add("DAT_ROS");
        locationNames.add("DAT_ALL");

        for (int i = 0; i < noOfDataTablesToCreate; i++){

            tableDetails.manageTableLocationUuids.clear();
            tableDetails.manageTableLocationUuids.add(locationsUIDS.get(i));

            tableDetails.tableName = FunctionsLibrary.FileUtilities.GenerateAppendUIDToString(locationNames.get(i), 5);

            tableDetails.tags.clear();
            for (int t = 0; t < iNoOfTagsToAdd; t++) {
                tableDetails.tags.add(Utils.getRandomValueFromList(immutableList));
            }

            //Act
            CreateDataTableResponse.PostResponse createDataTableResponse = API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
            tableDetails.uuid = createDataTableResponse.uuid;

            ViewDataTableResponse.ViewDataTableResponseObject responseDetail = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(createDataTableResponse.uuid);
            tableDetails.opLockVersion = responseDetail.opLockVersion;

            EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);
            ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponseObject = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(tableDetails.uuid);

            //Assert
            assertEquals("HTTP Status Code: ", HttpStatus.SC_CREATED, createDataTableResponse.httpStatusCode);
            assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, responseEdit.httpStatusCode);
            assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, viewDataTableResponseObject.httpStatusCode);
        }
    }


    @Test
    public void CreatesLocalRule() throws Throwable
    {
        String sNoOfRulesToCreate = System.getProperty("noOfRulesToCreate", "10");
        int iNoOfRulesToCreate = Integer.parseInt(sNoOfRulesToCreate);

        //Arrange
        TestUserModel.UserDetails udRuleManWAT = Users_API.RulesManagerLocal_WAT();

        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManWAT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManWAT.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_WAT();

        //Act
        for (int i = 0; i < iNoOfRulesToCreate; i++) {

            ruleDetails.description = "LRule_" + i;

            CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
            assertEquals(HttpStatus.SC_CREATED, createRuleResponse.response.getStatusCode());
        }
    }


    @Test
    public void CreatesNationalRule() throws Throwable
    {
        String sNoOfRulesToCreate = System.getProperty("noOfRulesToCreate", "10");
        int iNoOfRulesToCreate = Integer.parseInt(sNoOfRulesToCreate);

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        //Act
        for (int i = 0; i < iNoOfRulesToCreate; i++) {

            ruleDetails.description = "NRule_" + i;
            CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
            assertEquals(HttpStatus.SC_CREATED, createRuleResponse.response.getStatusCode());
        }
    }


    @Test
    public void CreateRulesAtVariousStatusLocalAndNational()
    {
        String sNoOfRulesToCreate = System.getProperty("MaxNoOfRulesToCreateOfEachStatusType", "5");
        int iNoOfRulesToCreate = Integer.parseInt(sNoOfRulesToCreate);

        Random random = new Random();

        TestRuleModel.RuleDetails ruleDetailsNat = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsNat.descriptionStaticPrefix = "ta_NatRule";

        TestRuleModel.RuleDetails ruleDetailsLoc = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        ruleDetailsLoc.descriptionStaticPrefix = "ta_LocRule";

        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat, TestEnumerators.RuleStatus.draft, (random.nextInt(iNoOfRulesToCreate)+1));
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat, TestEnumerators.RuleStatus.active, (random.nextInt(iNoOfRulesToCreate)+1));
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat, TestEnumerators.RuleStatus.pending, (random.nextInt(iNoOfRulesToCreate)+1));
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat, TestEnumerators.RuleStatus.suspended, (random.nextInt(iNoOfRulesToCreate)+1));
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat, TestEnumerators.RuleStatus.expired, (random.nextInt(iNoOfRulesToCreate)+1));
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat, TestEnumerators.RuleStatus.archived, (random.nextInt(iNoOfRulesToCreate)+1));

        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsLoc, TestEnumerators.RuleStatus.draft, (random.nextInt(iNoOfRulesToCreate)+1));
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsLoc, TestEnumerators.RuleStatus.active, (random.nextInt(iNoOfRulesToCreate)+1));
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsLoc, TestEnumerators.RuleStatus.pending, (random.nextInt(iNoOfRulesToCreate)+1));
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsLoc, TestEnumerators.RuleStatus.suspended, (random.nextInt(iNoOfRulesToCreate)+1));
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsLoc, TestEnumerators.RuleStatus.expired, (random.nextInt(iNoOfRulesToCreate)+1));
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsLoc, TestEnumerators.RuleStatus.archived, (random.nextInt(iNoOfRulesToCreate)+1));

        publishAndWait(5000);

    }




}
