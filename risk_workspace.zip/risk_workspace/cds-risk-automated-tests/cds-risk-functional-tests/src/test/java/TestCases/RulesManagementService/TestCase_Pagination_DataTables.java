package TestCases.RulesManagementService;


import API.DataForTests.DataTables;
import API.DataForTests.PaginationInfo;
import API.DataForTests.TestDataTableModel;
import API.RulesManagementService.Data.ViewDataTableList.ViewDataTableListResponse;
import Categories_CDSRisk.CDS_RM_Pagination;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_Pagination. class})
public class TestCase_Pagination_DataTables extends WebAPITestCaseWithDatatablesCleanup {

    public PaginationInfo paginationInfo;

    @Before
    public void Setup(){

        dataTablesUtils.CreateDefaultDataTable();

        paginationInfo = new PaginationInfo();

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListROStart = API.RulesManagementService.Utils.DataTables.GetListOfDataTables();
        paginationInfo.iElementsAtStart = viewDataTableListROStart.totalElements;

        paginationInfo.iPagesAtStart = viewDataTableListROStart.totalPages;
    }

    @Test
    @Category(ChangeRequest.CR_582.class)
    public void WhenListOfDataTablesHasOnePageOfData_CorrectNoOfTotalPagesReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = API.RulesManagementService.Utils.DataTables.GetListOfDataTables();

        //Assert
        assertEquals("Expect Total Page = 1", 1, viewDataTableListResponseObject.totalPages);
  }

    @Test
    @Category(ChangeRequest.CR_582.class)
    public void WhenDataTablesPageSizeIsSet_CorrectNoOfDataTablesReturnedOnPage() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        API.RulesManagementService.Utils.DataTables.CreateSpecifiedNoOfDataTables(3, tableDetails);

        //Act
        String query = "?size=1";
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(query);

        //Assert
        assertEquals("Expect Data Tables per page = 1", 1, viewDataTableListResponseObject.numberOfElements);
        assertEquals("Expect contents to contain 1 table", 1, viewDataTableListResponseObject.content.size());
    }

    @Test
    @Category(ChangeRequest.CR_582.class)
    public void WhenDataTablesPageNoIsSetToPage1_CorrectPageIsReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        API.RulesManagementService.Utils.DataTables.CreateSpecifiedNoOfDataTables(3, tableDetails);

        //Act
        String query = "?size=" + (paginationInfo.iElementsAtStart + 1) + "&page=0";
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(query);

        //Assert
        //latest data table created is returned first
        assertEquals("Expect page 1 to contain data table 1", "ta_datatable_0003", viewDataTableListResponseObject.content.get(0).tableName);
        assertEquals("Expect first page to equal true", true , viewDataTableListResponseObject.first);
    }

    @Test
    @Category(ChangeRequest.CR_582.class)
    public void WhenDataTablesPageNoIsSetToPage2_CorrectPageIsReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        API.RulesManagementService.Utils.DataTables.CreateSpecifiedNoOfDataTables(3, tableDetails);

        //Act
        String query = "?size=" + (paginationInfo.iElementsAtStart + 1) + "&page=1";
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(query);

        //Assert
        assertEquals("Expect current page to be 1", 1, viewDataTableListResponseObject.number);
    }

    @Test
    @Category(ChangeRequest.CR_582.class)
    public void WhenDataTablesPageNoIsSetToPage10_CorrectPageIsReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        API.RulesManagementService.Utils.DataTables.CreateSpecifiedNoOfDataTables(10, tableDetails);

        //Act
        String query = "?size=1&page=9";
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(query);

        //Assert
        assertEquals("Expect current page to be 9", 9, viewDataTableListResponseObject.number);
    }

    @Test
    @Category(ChangeRequest.CR_582.class)
    public void WhenDataTablesPageNoIsSetToPage100_CorrectPageIsReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        API.RulesManagementService.Utils.DataTables.CreateSpecifiedNoOfDataTables(100, tableDetails);

        //Act
        String query = "?size=1&page=99";
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(query);

        //Assert
        assertEquals("Expect current page to be 99", 99, viewDataTableListResponseObject.number);
    }

    @Test
    @Category(ChangeRequest.CR_582.class)
    public void WhenDataTablesPageNoIsNotSet_FirstPageIsReturnedByDefault() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        API.RulesManagementService.Utils.DataTables.CreateSpecifiedNoOfDataTables(3, tableDetails);

        //Act
        String query = "?size=1";
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(query);

        //Assert
        assertEquals("Expect current page to be 0", 0, viewDataTableListResponseObject.number);
        assertEquals("Expect first page to equal true", true , viewDataTableListResponseObject.first);
    }


    @Test
    @Category(ChangeRequest.CR_582.class)
    public void WhenDataTablePageLastIsSet_LastPageIsReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        API.RulesManagementService.Utils.DataTables.CreateSpecifiedNoOfDataTables(3, tableDetails);

        //Act
        String query = "?size=1&page=" + (paginationInfo.iPagesAtStart + 3);
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(query);

        //Assert
        assertEquals("Expect last page to equal true", true , viewDataTableListResponseObject.last);
        assertEquals("Expect last page to be + 3 pages", paginationInfo.iPagesAtStart + 3 , viewDataTableListResponseObject.totalPages);
    }

    @Test
    @Category(ChangeRequest.CR_582.class)
    public void WhenListOfDataTablesIsSelected_CorrectTotalNoOfElementsIsReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        API.RulesManagementService.Utils.DataTables.CreateSpecifiedNoOfDataTables(3, tableDetails);

        //Act
        String query = "?size=2";
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(query);

        //Assert
        paginationInfo.iSizeOfPage= 2;
        paginationInfo.iElementsAdded = 3;
        paginationInfo = paginationInfo.calculatePaginationInfo(paginationInfo);

        assertEquals("Expect contents to contain 2 table", paginationInfo.iCalcElementsOnLastPage, viewDataTableListResponseObject.content.size());
        assertEquals("Expect number of elements to be 2", paginationInfo.iCalcElementsOnLastPage, viewDataTableListResponseObject.numberOfElements);
    }

    @Test
    @Category(ChangeRequest.CR_582.class)
    public void WhenListOfDataTablesHasFourPagesOfData_CorrectNoOfTotalPagesReturned() throws Throwable {

        //Arrange
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListROStart = API.RulesManagementService.Utils.DataTables.GetListOfDataTables();
        int iPageAtStart = viewDataTableListROStart.totalPages;

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        API.RulesManagementService.Utils.DataTables.CreateSpecifiedNoOfDataTables(3, tableDetails);

        //Act
        String query = "?size=1";
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(query);

        //Assert
        paginationInfo.iSizeOfPage = 1;
        paginationInfo.iElementsAdded = 3;
        paginationInfo = paginationInfo.calculatePaginationInfo(paginationInfo);
        assertEquals("Expect Total Page = 4", paginationInfo.iCalcTotalPages, viewDataTableListResponseObject.totalPages);
    }

    @Test
    @Category(ChangeRequest.CR_582.class)
    public void WhenListOfDataTablesHasTenPagesOfData_CorrectNoOfTotalPagesReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        API.RulesManagementService.Utils.DataTables.CreateSpecifiedNoOfDataTables(9, tableDetails);

        //Act
        String query = "?size=1";
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(query);

        //Assert
        paginationInfo.iSizeOfPage = 1;
        paginationInfo.iElementsAdded = 9;
        paginationInfo = paginationInfo.calculatePaginationInfo(paginationInfo);
        assertEquals("Expect Total Page = 10", paginationInfo.iCalcTotalPages, viewDataTableListResponseObject.totalPages);
    }

    @Test
    @Category(ChangeRequest.CR_582.class)
    public void WhenListOfDataTablesHasHundredPagesOfData_CorrectNoOfTotalPagesReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        API.RulesManagementService.Utils.DataTables.CreateSpecifiedNoOfDataTables(99, tableDetails);

        //Act
        String query = "?size=1";
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(query);

        //Assert
        paginationInfo.iSizeOfPage = 1;
        paginationInfo.iElementsAdded = 99;
        paginationInfo = paginationInfo.calculatePaginationInfo(paginationInfo);
        assertEquals("Expect Total Page = 100", paginationInfo.iCalcTotalPages, viewDataTableListResponseObject.totalPages);
    }

}
