package TestCases.DARService;

import API.RiskingServiceJava.Utils.SoapMessageHelper;
import Categories_CDSRisk.DAR_Client;
import TestCases.RiskingServiceJava.BaseRiskingServiceJava;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.*;
import uk.gov.hmrc.risk.test.common.model.darService.*;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel.Query;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel.RuleOutputs;

import java.time.ZonedDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static API.DataForTests.TestEnumerators.RuleOutputs.*;
import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
@Category(DAR_Client.class)
public class TestCase_IsSupplementaryRuleCorrectlyWrittenAndRisked extends BaseRiskingServiceJava{

    String ruleId;
    String declarationID;
    private String assignee="someguys@test.gsi.gov.uk";
    private String releaseNarrative="Supplementary rule release narrative";
    private String infoNarrative="Supplementary rule info narrative";


    @Test
    public void WhenSupplementaryInfoRuleIsHit_CorrectDarFilesAreGenerated() {

        ruleId = createRule();
        DeclarationResponse declarationResponse = getDeclarationResponse();
        Assertions.assertThat(declarationResponse.getReportBackElements()).isEmpty();
        Assertions.assertThat(declarationResponse.getControlType()).isEmpty();

        assertDeclarationRisked(declarationResponse.getResponseId());
        assertDeclarationRiskedEvent(declarationResponse.getResponseId());

        assertRuleBehaviourFiles();

        assertMDGMessage();
    }

    private String createRule() {
        CreateRuleModel model = createRuleModel();
        model.setBaseLocation(null);
        model.setStartDateTime(null);
        model.setRuleOutputs(RuleOutputs.builder()
                .actionType("6")
                .releaseNarrative(releaseNarrative)
                .informationNarrative(infoNarrative)
                 .informationNarrativeAssignee(assignee)
                .build()
        );
        model.getQuery().get(0).setQuery(Arrays.asList(
                Query.builder()
                        .attribute(HeaderDeclarationParam.CONSIGNEE_NAME.toString())
                        .conditionType(ConditionType.normal.toString())
                        .operator(Operator.eq.toString())
                        .value("cons name")
                        .build()
                )
        );
        return createAndRefreshRule(model);
    }

    private DeclarationResponse getDeclarationResponse() {

        declarationID = UUID.randomUUID().toString();
        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_REFERENCE, declarationID);
        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNEE_NAME, "cons name");

        return createAndSendDeclaration(declarationFieldValues);

    }

    private void assertRuleBehaviourFiles() {
        List<DarRuleBehavioursModel> behaviourEvents = darServicePublishingSupport.parseRuleBehavioursEvents()
                .stream().filter(
                        model -> matchFileListingsBasedPackageId(model.getRuleUuid()))
                .collect(Collectors.toList());

        Assertions.assertThat(behaviourEvents.size()).isEqualTo(2);

        List<String> narratives = behaviourEvents.stream()
                .map(DarRuleBehavioursModel::getNarrative)
                .collect(Collectors.toList());
        Assertions.assertThat(narratives).containsExactlyInAnyOrder( "Supplementary rule release narrative",
                "Supplementary rule info narrative");

        List<String> actionTypes = behaviourEvents.stream()
                .map(DarRuleBehavioursModel::getDarActionType)
                .collect(Collectors.toList());
        Assertions.assertThat(actionTypes).containsExactlyInAnyOrder( "SUPP_DEC_CHECK:RELEASE", "INFORMATION_TASK:RELEASE");
    }

    private void assertDeclarationRiskedEvent(String responseId) {
        List<DarDeclarationRiskedEventModel> filtered = darServiceAuditSupport.parseDeclarationRiskedEvent()
                .stream().filter(log -> log.getResponseId().equals(responseId))
                .collect(Collectors.toList());

        Assertions.assertThat(filtered.size()).isNotZero();

        DarDeclarationRiskedEventModel suppEvent = filtered.get(0);
        Assertions.assertThat(suppEvent.getNarrative()).isEqualTo(releaseNarrative);
        Assertions.assertThat(suppEvent.getActionControlType()).isEqualTo(SUPP_DEC_CHECK.toString());
        Assertions.assertThat(suppEvent.getRuleControlType()).isEqualTo(SUPP_DEC_CHECK.toString());

        DarDeclarationRiskedEventModel infoEvent = filtered.get(1);
        Assertions.assertThat(infoEvent.getNarrative()).isEqualTo(infoNarrative);
        Assertions.assertThat(infoEvent.getActionControlType()).isEqualTo(INFORMATION_TASK.toString());
        Assertions.assertThat(infoEvent.getRuleControlType()).isEqualTo(INFORMATION_TASK.toString());
    }

    private void assertDeclarationRisked(String responseId) {
        List<DarDeclarationRiskedModel> filtered = darServiceAuditSupport.parseDeclarationRisk()
                .stream().filter(log -> log.getDeclarationId().equals(declarationID))
                .collect(Collectors.toList());
        Assertions.assertThat(filtered.size()).isNotZero();

        filtered.forEach(log ->
        {
            ZonedDateTime time = darServiceAuditSupport.getFormattedTimestamp(log.getEventTime());
            Assertions.assertThat(time).isBeforeOrEqualTo(ZonedDateTime.now().plusHours(2));
            Assertions.assertThat(log.getType()).isEqualTo(DarEventType.DECLARATION_RISKED.toString());
            Assertions.assertThat(log.getResponseId()).isEqualTo(responseId);
            Assertions.assertThat(log.getRulesPackage()).isNotEmpty();
            Assertions.assertThat(log.getNumberOfResults()).isEqualTo("2");
        });

    }

    private void assertMDGMessage() {
        String message = mdgEmailQueueAccessor.receive();
        SoapMessageHelper.SoapMessage emailRequest = soapHelper.parse(message);

        log.debug("emailRequest = " + message);

        // Check information narrative isn't sent
        assertThat(emailRequest.getValueFromBody("EmailRequest/EmailContent/Content"))
                .doesNotContain(infoNarrative);

        // Check an ID is present
        assertThat(emailRequest.getValueFromBody("EmailRequest/EmailContent/Content"))
                .contains("NAT-ADD");

        assertThat(emailRequest.getValueFromBody("EmailRequest/EmailContent/Bcc"))
                .contains(assignee);
    }

    private boolean matchFileListingsBasedPackageId(String ruleId) {
        return ruleId.equals(this.ruleId);
    }
}
