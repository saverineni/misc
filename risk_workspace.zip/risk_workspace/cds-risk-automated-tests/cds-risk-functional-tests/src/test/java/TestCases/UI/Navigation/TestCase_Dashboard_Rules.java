package TestCases.UI.Navigation;

import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Utils.RuleAtStatus;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Navigation;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.Pages.Home_Page;
import UI.Pages.RulesManagement.ListRules_Page;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static FunctionsLibrary.Utils.SleepForMilliSeconds;
import static junit.framework.TestCase.assertEquals;
import static org.assertj.core.api.Assertions.assertThat;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Navigation.class})
public class TestCase_Dashboard_Rules extends BaseUIWebDriverTestCase{


    @Test
    public void WhenHomePageLoaded_DefaultRulesDashboardDetailsDisplayed() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        //Act
        Home_Page home_page = new Home_Page(driver);

        //Assert
        assertEquals("Default Total Rule", 0, home_page.getTotalRules());
        assertEquals("Default Rule Filter Total", "Total Rules", home_page.ruleType.getSelectedItem());
    }


    @Test
    public void whenNationalLocalRulesExist_RulesDashboardDisplayCorrectDetails() {
        TestRuleModel.RuleDetails ruleDetailsNat = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsNat.descriptionStaticPrefix = "ta_NatRule";

        TestRuleModel.RuleDetails ruleDetailsLoc = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        ruleDetailsLoc.descriptionStaticPrefix = "ta_LocRule";

        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat, TestEnumerators.RuleStatus.draft, 1);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat, TestEnumerators.RuleStatus.active, 1);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat, TestEnumerators.RuleStatus.silent, 2);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsLoc, TestEnumerators.RuleStatus.pending, 1);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsLoc, TestEnumerators.RuleStatus.suspended, 1);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsLoc, TestEnumerators.RuleStatus.expired, 1);
        publishAndWait(5000);

        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        SleepForMilliSeconds(1000);
        Home_Page home_page = new Home_Page(driver);
        List<Home_Page.DashBoardItemObject> dashboardRulesItems = home_page.getDashboardRulesItems();
        Home_Page.DashBoardItemObject draft = dashboardRulesItems.get(0);
        Home_Page.DashBoardItemObject active = dashboardRulesItems.get(1);
        Home_Page.DashBoardItemObject pending = dashboardRulesItems.get(2);
        Home_Page.DashBoardItemObject suspended = dashboardRulesItems.get(3);
        Home_Page.DashBoardItemObject silent = dashboardRulesItems.get(4);
        int actTotalRules = home_page.getTotalRules();

        home_page = new Home_Page(driver);
        home_page.ruleType.select("National Rules");
        SleepForMilliSeconds(500);
        home_page.waitForAngularRequestsToFinish();
        List<Home_Page.DashBoardItemObject> dashboardRulesItemsNAT = home_page.getDashboardRulesItems();
        Home_Page.DashBoardItemObject draftNAT = dashboardRulesItemsNAT.get(0);
        Home_Page.DashBoardItemObject activeNAT = dashboardRulesItemsNAT.get(1);
        Home_Page.DashBoardItemObject pendingNAT = dashboardRulesItemsNAT.get(2);
        Home_Page.DashBoardItemObject suspendedNAT = dashboardRulesItemsNAT.get(3);
        Home_Page.DashBoardItemObject silentNAT = dashboardRulesItemsNAT.get(4);
        int actNationalRules = home_page.getTotalRules();

        home_page = new Home_Page(driver);
        home_page.ruleType.select("Local Rules");
        SleepForMilliSeconds(500);
        home_page.waitForAngularRequestsToFinish();
        List<Home_Page.DashBoardItemObject> dashboardRulesItemsLOC = home_page.getDashboardRulesItems();
        Home_Page.DashBoardItemObject draftLOC = dashboardRulesItemsLOC.get(0);
        Home_Page.DashBoardItemObject activeLOC = dashboardRulesItemsLOC.get(1);
        Home_Page.DashBoardItemObject pendingLOC = dashboardRulesItemsLOC.get(2);
        Home_Page.DashBoardItemObject suspendedLOC = dashboardRulesItemsLOC.get(3);
        Home_Page.DashBoardItemObject silentLOC = dashboardRulesItemsLOC.get(4);
        int actLocalRules = home_page.getTotalRules();

        assertEquals("Default Total Rules", 6, actTotalRules);

        assertEquals("DRAFT", draft.status);
        assertEquals("ACTIVE", active.status);
        assertEquals("PENDING", pending.status);
        assertEquals("SUSPENDED", suspended.status);
        assertEquals("SILENT", silent.status);

        assertEquals("DRAFT count", 1, draft.count);
        assertEquals("ACTIVE count", 1, active.count);
        assertEquals("PENDING count", 1, pending.count);
        assertEquals("SUSPENDED count", 1, suspended.count);
        assertEquals("SILENT count", 2, silent.count);

        assertEquals("DRAFT percentage", 16.67, draft.percentage);
        assertEquals("ACTIVE percentage", 16.67, active.percentage);
        assertEquals("PENDING percentage", 16.67, pending.percentage);
        assertEquals("SUSPENDED percentage", 16.67, suspended.percentage);
        assertEquals("SILENT percentage", 33.33, silent.percentage);

        //National
        assertEquals("Default National Rules", 4, actNationalRules);
        assertEquals("DRAFT count", 1, draftNAT.count);
        assertEquals("ACTIVE count", 1, activeNAT.count);
        assertEquals("PENDING count", 0, pendingNAT.count);
        assertEquals("SUSPENDED count", 0, suspendedNAT.count);
        assertEquals("SILENT count", 2, silentNAT.count);

        assertEquals("DRAFT percentage", 25.00, draftNAT.percentage);
        assertEquals("ACTIVE percentage", 25.00, activeNAT.percentage);
        assertEquals("PENDING percentage", 00.00, pendingNAT.percentage);
        assertEquals("SUSPENDED percentage", 00.00, suspendedNAT.percentage);
        assertEquals("SILENT percentage", 50.00, silentNAT.percentage);

        //Local
        assertEquals("Default Local Rules", 2, actLocalRules);
        assertEquals("DRAFT count", 0, draftLOC.count);
        assertEquals("ACTIVE count", 0, activeLOC.count);
        assertEquals("PENDING count", 1, pendingLOC.count);
        assertEquals("SUSPENDED count", 1, suspendedLOC.count);
        assertEquals("SILENT count", 0, silentLOC.count);

        assertEquals("DRAFT percentage", 00.00, draftLOC.percentage);
        assertEquals("ACTIVE percentage", 00.00, activeLOC.percentage);
        assertEquals("PENDING percentage", 50.00, pendingLOC.percentage);
        assertEquals("SUSPENDED percentage", 50.00, suspendedLOC.percentage);
        assertEquals("SILENT percentage", 00.00, silentLOC.percentage);
    }

    @Test
    public void WhenDraftRulesExist_ClickingOnDraftDonutInDashboardRendersDraftRulesList() {

        TestRuleModel.RuleDetails ruleDetailsNat = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsNat.descriptionStaticPrefix = "ta_NatRule";

        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat, TestEnumerators.RuleStatus.draft, 1);

        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        Home_Page home_page = new Home_Page(driver);
        List<Home_Page.DashBoardItemObject> dashboardRulesItems = home_page.getDashboardRulesItems();
        int actTotalRules = home_page.getTotalRules();

        String draftDialPercentage = home_page.getPercentageForDial("DRAFT");

        assertEquals(1, actTotalRules);
        assertEquals("DRAFT", dashboardRulesItems.get(0).status);
        assertEquals("100.00%", draftDialPercentage);

        home_page.clickRuleStatusDial("draft");
        home_page.waitForAngularRequestsToFinish();

        ListRules_Page listRules_page = new ListRules_Page(driver);
        listRules_page.waitTillListRulesVisible();

        assertThat(listRules_page.getListOfRules()).extracting("status").contains("Draft");
    }
}
