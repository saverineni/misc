package TestCases.RiskingService;


import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestRuleModel;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service;
import TestCases.BaseWebAPITestCase;
import com.google.common.collect.ImmutableList;
import junitparams.JUnitParamsRunner;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import uk.gov.hmrc.risk.test.common.enums.DeclarationType;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeoutException;

import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
@Category(Risking_Service.class)
@RunWith(JUnitParamsRunner.class)
public class TestCase_RiskingDeclarationType extends BaseWebAPITestCase {

    @Before
    public void setup() throws IOException, TimeoutException
    {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
    }


    @Test
    @Category({ChangeRequest.CR_1628.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithTypeFull_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryOptions.declarationSubTypes .add("A");
        ruleDetails.queryOptions.declarationSubTypes .add("B");
        ruleDetails.queryOptions.declarationSubTypes .add("D");
        ruleDetails.queryOptions.declarationSubTypes .add("E");
        ruleDetails.queryOptions.declarationSubTypes .add("F");
        ruleDetails.queryOptions.declarationSubTypes .add("Y");
        ruleDetails.queryOptions.declarationSubTypes .add("Z");

        ruleDetails.ruleOutputs.timeToClose=3600;


        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act

        //Declaration 1
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry = ruleDetails.queryConditions.get(0).conditions.get(0).value;

        declaration.declarationSubType = "A";   //A (A, D), C(B, C, E, F), E (X, Y, Z), All (A,B,C,D,E,F,X,Y or Z)
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        log.info(declarationResponse.toString());

        //Declaration 2
        TestDeclarationModel.Declaration declaration2 = new TestDeclarationModel.Declaration();
        declaration2.dispatchCountry = ruleDetails.queryConditions.get(0).conditions.get(0).value;

        declaration2.declarationType = "EX";     //EX or IM
        declaration2.declarationSubType = "D";   //A (A, D), C(B, C, E, F), E (X, Y, Z), All (A,B,C,D,E,F,X,Y or Z)
        declaration2.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest2 = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration2, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest2);
        DeclarationResponse declarationResponse2 = new DeclarationResponse(queue.receive());

        log.info(declarationResponse2.toString());

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).contains(declaration.controlTypeExpectedValue);

        List<String> returnedControlType2 = declarationResponse2.getControlTypeList();
        assertThat(returnedControlType2).contains(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_1628.class})
    public void WhenDeclarationSubmittedForNonMatchingRuleWithTypeFull_NoRouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryOptions.declarationSubTypes .add("A");

        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry = ruleDetails.queryConditions.get(0).conditions.get(0).value;

        declaration.declarationSubType = "B";   //A (A, D), C(B, C, E, F), E (X, Y, Z), All (A,B,C,D,E,F,X,Y or Z)

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        log.info(declarationResponse.toString());

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).doesNotContain(ruleDetails.ruleOutputs.actionType);
    }


    @Test
    @Category({ChangeRequest.CR_1628.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithTypeSimplified_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryOptions.declarationSubTypes .add("B");

       ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry = ruleDetails.queryConditions.get(0).conditions.get(0).value;

        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        //A (A, D), C(B, C, E, F), E (X, Y, Z), All (A,B,C,D,E,F,X,Y or Z)
        ImmutableList<String> simplifiedValues = ImmutableList.of("B", "C");
        declaration.declarationSubType = FunctionsLibrary.Utils.getRandomValueFromList(simplifiedValues);

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        log.info(declarationResponse.toString());

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).contains(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_1628.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithTypeAll_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        String[] decSubTypeArray = {"A", "B", "D", "E", "F","Y", "Z"};
        List<String> decSubTypeList = Arrays.asList(decSubTypeArray);
        ruleDetails.queryOptions.declarationSubTypes .addAll( decSubTypeList);

        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        //A (A, D), C(B, C, E, F), E (X, Y, Z), All (A,B,C,D,E,F,X,Y or Z)
        ImmutableList<String> fullValues = ImmutableList.of("A", "B", "C", "D", "E", "F", "Y", "Z");
        declaration.declarationSubType = FunctionsLibrary.Utils.getRandomValueFromList(fullValues);

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        log.info(declarationResponse.toString());

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).contains(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_1628.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithTypeSupplementary_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryOptions.declarationSubTypes .add( "Y");

        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act

        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry = ruleDetails.queryConditions.get(0).conditions.get(0).value;

        //A (A, D), C(B, C, E, F), E (X, Y, Z), All (A,B,C,D,E,F,X,Y or Z)
        declaration.declarationSubType = "Y";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
       DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        log.info(declarationResponse.toString());

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).contains(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category(ChangeRequest.CR_1218.class)
    public void WhenDeclarationSubmittedForRuleWithDeclarationSubTypeBoth_RouteReturnedWithEitherFullOrSimplified() throws Throwable{

        //Arrange
        //1. create a draft rule
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryOptions.declarationType = DeclarationType.IM.toString();
        ruleDetails.queryOptions.declarationSubTypes .add("A");
        ruleDetails.queryOptions.declarationSubTypes .add("C");

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        //2. Synchronize rule with risking service
        publishAndWait(5000);

        //Arrange
        //3. Submit declaration
        TestDeclarationModel.Declaration declarationSimple = new TestDeclarationModel.Declaration();
        declarationSimple.dispatchCountry = "SP";
        declarationSimple.declarationType = "IM";     //EX or IM
        declarationSimple.declarationSubType = "A";   //C = C, A = A
        declarationSimple.goodsLocationName = "GBBYMNCABZNASInfo";

        TestDeclarationModel.Declaration declarationFull = new TestDeclarationModel.Declaration();
        declarationFull.dispatchCountry = "SP";
        declarationFull.declarationType = "IM";     //EX or IM
        declarationFull.declarationSubType = "C";   //C = C, A = A
        declarationFull.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest1 = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declarationSimple, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest1);
        DeclarationResponse declarationResponse1 = new DeclarationResponse(queue.receive());

        //Assert
        String returnedControlType = declarationResponse1.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declarationSimple.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse1.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains("/declaration");

        //read 2nd message
        String declarationRequest2 = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declarationFull, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest2);
        DeclarationResponse declarationResponse2 = new DeclarationResponse(queue.receive());

        String returnedControlType2 = declarationResponse2.getControlType();
        Assertions.assertThat(returnedControlType2).isEqualTo(declarationFull.controlTypeExpectedValue);
    }


    @Test
    @Category(ChangeRequest.CR_1866.class)
    public void WhenDeclarationSubmittedForRuleWithDeclarationTypeBoth_RouteReturnedWithEitherImportOrExport() throws Throwable{

        //Arrange
        //1. create a draft rule
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryOptions.declarationType = DeclarationType.Both.toString();
        ruleDetails.queryOptions.declarationSubTypes = null;

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        //2. Synchronize rule with risking service
        publishAndWait(5000);

        //Arrange
        //3. Submit declaration
        TestDeclarationModel.Declaration declarationImportFull = new TestDeclarationModel.Declaration();
        declarationImportFull.dispatchCountry = "SP";
        declarationImportFull.declarationType = "IM";     //EX or IM
        declarationImportFull.declarationSubType = "A";   //C = C, A = A
        declarationImportFull.goodsLocationName = "GBBYMNCABZNASInfo";

        TestDeclarationModel.Declaration declarationExportSimple = new TestDeclarationModel.Declaration();
        declarationExportSimple.dispatchCountry = "SP";
        declarationExportSimple.declarationType = "EX";     //EX or IM
        declarationExportSimple.declarationSubType = "C";   //C = C, A = A
        declarationExportSimple.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest1 = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declarationImportFull, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest1);
        DeclarationResponse declarationResponse1 = new DeclarationResponse(queue.receive());

        //2nd declaration
        String declarationRequest2 = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declarationExportSimple, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest2);
        DeclarationResponse declarationResponse2 = new DeclarationResponse(queue.receive());

        //Assert
        String returnedControlType = declarationResponse1.getControlType();
        Assertions.assertThat(returnedControlType).isEqualTo(declarationImportFull.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse1.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains("/declaration");

        String returnedControlType2 = declarationResponse2.getControlType();
        Assertions.assertThat(returnedControlType2).isEqualTo(declarationExportSimple.controlTypeExpectedValue);
    }

}
