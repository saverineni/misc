package TestCases.RulesManagementService;


import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.RuleAction.RuleActionResponse;
import API.RulesManagementService.ViewRule.ViewRuleResponse;
import Categories_CDSRisk.CDS_RM_RuleLifeCycle;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import org.apache.http.HttpStatus;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static API.RulesManagementService.Utils.RuleAtStatus.*;
import static org.junit.Assert.assertEquals;


@Category({Rules_Management.class, CDS_RM_RuleLifeCycle.class})
public class TestCase_SilentRule extends BaseWebAPITestCase {

    @Test
    @Category({ChangeRequest.CR_3408.class})
    public void WhenActiveRuleIsSilenced_RuleStatusIsChangedToSilent() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();

        ruleDetails.uniqueID = committedRuleResponse.uniqueId;

        //Act
        RuleActionResponse.PostResponse silentRuleResponse = SilentRule(ruleDetails);

        assertEquals(HttpStatus.SC_OK, silentRuleResponse.httpStatusCode);

        publishAndWait(5000);

        ViewRuleResponse.ViewRuleResponseObject getResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals(TestEnumerators.RuleStatus.silent.toString(), getResponse.leadVersion.status);
    }

    @Test
    @Category(ChangeRequest.CR_3423.class)
    public void WhenReinstatedRule_RuleStatusShouldBective() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse reinstatedRuleResponse = CreateReinstatedSilentRule();
        ruleDetails.uniqueID = reinstatedRuleResponse.uniqueId;

        //Act
        assertEquals(HttpStatus.SC_OK, reinstatedRuleResponse.httpStatusCode);
        publishAndWait(5000);
        ViewRuleResponse.ViewRuleResponseObject getResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals(TestEnumerators.RuleStatus.active.toString(), getResponse.leadVersion.status);
    }

    @Test
    @Category(ChangeRequest.CR_3424.class)
    public void WhenSilentRuleIsSuspended_RuleStatusShouldBeSuspended() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse silentRuleResponse = CreateSilentRule(ruleDetails);
        ruleDetails.uniqueID = silentRuleResponse.uniqueId;

        //Act
        assertEquals(HttpStatus.SC_OK, silentRuleResponse.httpStatusCode);
        SuspendRule(ruleDetails);
        publishAndWait(5000);
        ViewRuleResponse.ViewRuleResponseObject getResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals(TestEnumerators.RuleStatus.suspended.toString(), getResponse.leadVersion.status);
    }

    @Test
    @Category(ChangeRequest.CR_3425.class)
    public void WhenSilentRuleIsArchived_RuleStatusShouldBeArchived() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse silentRuleResponse = CreateSilentRule(ruleDetails);
        ruleDetails.uniqueID = silentRuleResponse.uniqueId;

        //Act
        assertEquals(HttpStatus.SC_OK, silentRuleResponse.httpStatusCode);
        ArchiveRule(ruleDetails);
        publishAndWait(5000);
        ViewRuleResponse.ViewRuleResponseObject getResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals(TestEnumerators.RuleStatus.archived.toString(), getResponse.leadVersion.status);
    }

    @Test
    @Category(ChangeRequest.CR_3406.class)
    public void WhenSuspendedRuleIsSilenced_RuleStatusShouldBeSilent() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse suspendedRuleResponse = CreateSuspendedRule(ruleDetails);
        ruleDetails.uniqueID = suspendedRuleResponse.uniqueId;

        //Act
        assertEquals(HttpStatus.SC_OK, suspendedRuleResponse.httpStatusCode);
        SilentRule(ruleDetails);
        publishAndWait(5000);
        ViewRuleResponse.ViewRuleResponseObject getResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals(TestEnumerators.RuleStatus.silent.toString(), getResponse.leadVersion.status);
    }



}
