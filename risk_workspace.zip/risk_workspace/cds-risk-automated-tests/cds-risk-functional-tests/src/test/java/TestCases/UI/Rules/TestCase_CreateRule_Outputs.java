package TestCases.UI.Rules;

import API.DataForTests.TestEnumerators;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Rules;
import Categories_CDSRisk.CDS_Risk_UI_Rules_1;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.Pages.RulesManagement.CreateLocalRule_Page;
import UI.Pages.RulesManagement.CreateNationalRule_Page;
import UI.Utils.Navigation;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_1.class})
public class TestCase_CreateRule_Outputs extends BaseUIWebDriverTestCase {

    @Category({ChangeRequest.CR_3128.class,ChangeRequest.CR_3378.class})
    @Test
    public void WhenSearchingForAssigneeForLocalRuleManager_CorrectCaseAssigneesDisplayed() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.Rules.DraftLocalRule_POO();

        //Act
        createLocalRule_page.setActionType(TestEnumerators.RuleOutputs.PHYSICAL_CHECK.actionType);
        List<String> originalCaseAssigneeValues = createLocalRule_page.getListOfCaseAssigneeValues();
        createLocalRule_page.searchCaseAssignee("Import");
        List<String> filteredCaseAssigneeValues = createLocalRule_page.getListOfCaseAssigneeValues();

        //Assert
        Assertions.assertThat(originalCaseAssigneeValues).hasSize(7)
                .containsOnly(
                        "BF Import",
                        "BF Export",
                        "BF Frontline Import",
                        "BF Frontline Export",
                        "BF Project 1",
                        "BF Project 2",
                        "BF Project 3");
        Assertions.assertThat(filteredCaseAssigneeValues).hasSize(2)
                .containsOnly("BF Import", "BF Frontline Import");
    }

    @Category({ChangeRequest.CR_3128.class,ChangeRequest.CR_3377.class})
    @Test
    public void WhenSearchingForAssigneeForNationalRule_CorrectCaseAssigneesDisplayed() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateNationalRule_Page createNationalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateNationalRule);

        UI.DataForTests.Rules.baseRuleSingleCondition();

        //Act
        createNationalRule_page.setActionType(TestEnumerators.RuleOutputs.DOC_CHECK_VARY_RELEASE_GOODS.actionType);
        List<String> originalCaseAssigneeValues = createNationalRule_page.getListOfCaseAssigneeValues();
        createNationalRule_page.searchCaseAssignee("Export");
        List<String> filteredCaseAssigneeValues = createNationalRule_page.getListOfCaseAssigneeValues();

        createNationalRule_page.setActionType(TestEnumerators.RuleOutputs.INFORMATION_TASK.actionType);
        boolean caseAssigneeDropDown_Visible = createNationalRule_page.isElementDisplayed(createNationalRule_page.caseAssigneeDropdown);
        //Assert
        Assertions.assertThat(originalCaseAssigneeValues).hasSize(18)
                .containsOnly(
                        "BF Import",
                        "BF Export",
                        "BF Frontline Import",
                        "BF Frontline Export",
                        "BF Project 1",
                        "BF Project 2",
                        "BF Project 3",
                        "NCH Documentary Checks - Imports",
                        "NCH Documentary Checks - Exports",
                        "NCH Strategic Exports",
                        "NCH Common Agricultural Policy",
                        "NCH Live Animals and Human Remains - Imports",
                        "NCH Live Animals and Human Remains - Exports",
                        "NCH Open General Export Licence",
                        "NCH Post-Clearance",
                        "NCH Project A",
                        "NCH Project B",
                        "NCH Project C");
        Assertions.assertThat(filteredCaseAssigneeValues).hasSize(6)
                .containsOnly("BF Export",
                        "BF Frontline Export",
                        "NCH Documentary Checks - Exports",
                        "NCH Strategic Exports",
                        "NCH Live Animals and Human Remains - Exports",
                        "NCH Open General Export Licence");

        //
        assertEquals(caseAssigneeDropDown_Visible,false);
    }

}
