package TestCases.UI.DataTables;

import API.DataForTests.DataTables;
import API.DataForTests.TestDataTableModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_DataTables;
import Categories_CDSRisk.CDS_Risk_UI_DataTables_2;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.Pages.DataManagement.DataTableData_Page;
import UI.Pages.DataManagement.DataTableSummary_Page;
import UI.Pages.DataManagement.EditDataTable_Page;
import UI.Pages.DataManagement.ListDataTable_Page;
import UI.Utils.Navigation;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static FunctionsLibrary.Utils.SleepForMilliSeconds;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_DataTables.class, CDS_Risk_UI_DataTables_2.class})
public class TestCase_ImportDataTable extends BaseUIWebDriverTestCase {

    private TestDataTableModel.TableDetails tableDetailsFreeText;
    private TestUserModel.UserDetails userDetails;

    @Before
    public void Setup(){

        this.userDetails = Users_API.NationalRulesManagerDefaultTestAutomationUser();

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetails);

        tableDetailsFreeText = DataTables.DataTable_FreeText_Valid();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsFreeText);
        tableDetailsFreeText.uuid = createDataTableResponse.uuid;
        tableDetailsFreeText.uniqueId = createDataTableResponse.uniqueId;
    }


    @Ignore("Note Selenium Grid and Jenkins are on different servers, therefore file cannot be imported or exported")
    @Category(ChangeRequest.CR_2211.class)
    @Test
    public void WhenRuleManagerLoggedIn_CanImportDataFromValidCSVFile() {

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listMyDataTables_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = listMyDataTables_page.clickTableSummaryForSpecifiedDataTableID(tableDetailsFreeText.uniqueId);

        //Act
        dataTableSummary_page.dataTab.click();
        DataTableData_Page dataTableTab_page = new DataTableData_Page(driver);
        EditDataTable_Page editDataTable_page = dataTableTab_page.clickEditDataTableButton();

        editDataTable_page.upload.click();
        String actMessage = editDataTable_page.validateFile("uploadValidData_nonAsciiCharacters.csv");

        editDataTable_page.reason.isDisplayedWithWait(2,true);
        editDataTable_page.reason.setValue("Testing");
        editDataTable_page.add.click();
        SleepForMilliSeconds(1000);

        //assert
        assertEquals("The file contains 4 valid items and 0 invalid items.", actMessage);

        List<EditDataTable_Page.DataTableItemObject> listDataTableItemsObjects = editDataTable_page.getListDataTableItems();

        int iDataItems = listDataTableItemsObjects.size();
        assertEquals("Expect 4 data items", 4, iDataItems);
        assertThat(listDataTableItemsObjects).extracting("name").containsOnly("£234567891",
                "€234567892", "½234567893", "¾234567894");
    }


    @Ignore("Note Selenium Grid and Jenkins are on different servers, therefore file cannot be imported or exported")
    @Category(ChangeRequest.CR_2211.class)
    @Test
    public void AttemptToImportInvalidData_ErrorMessagesDisplayed() {
        TestDataTableModel.TableDetails commCodeTable = DataTables.DataTable_CommodityCodes_Invalid();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(commCodeTable);
        commCodeTable.uuid = createDataTableResponse.uuid;
        commCodeTable.uniqueId = createDataTableResponse.uniqueId;


        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listMyDataTables_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = listMyDataTables_page.clickTableSummaryForSpecifiedDataTableID(commCodeTable.uniqueId);

        //Act
        dataTableSummary_page.dataTab.click();
        DataTableData_Page dataTableTab_page = new DataTableData_Page(driver);
        EditDataTable_Page editDataTable_page = dataTableTab_page.clickEditDataTableButton();

        editDataTable_page.upload.click();
        String actMessageInValidType = editDataTable_page.validateFile("uploadInValidFileType.dat");
        String actMessageInValidData = editDataTable_page.validateFile("uploadValidInvalidData.csv");

        editDataTable_page.reason.isDisplayedWithWait(2,true);
        editDataTable_page.reason.setValue("Testing");
        editDataTable_page.add.click();
        SleepForMilliSeconds(1000);

        //assert
        assertEquals("File must be a CSV file.", actMessageInValidType);
        assertEquals("The file contains 3 valid items and 3 invalid items.", actMessageInValidData);

        List<EditDataTable_Page.DataTableItemObject> listDataTableItemsObjects = editDataTable_page.getListDataTableItems();

        int iDataItems = listDataTableItemsObjects.size();
        assertEquals("Expect 3 data items", 3, iDataItems);
    }

    
    @Ignore("Note Selenium Grid and Jenkins are on different servers, therefore file cannot be imported or exported")
    @Category(ChangeRequest.CR_2211.class)
    @Test
    public void WhenImportDataFromCSVFileCancelled_NoDataImported() {

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listMyDataTables_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = listMyDataTables_page.clickTableSummaryForSpecifiedDataTableID(tableDetailsFreeText.uniqueId);

        //Act
        dataTableSummary_page.dataTab.click();
        DataTableData_Page dataTableTab_page = new DataTableData_Page(driver);
        EditDataTable_Page editDataTable_page = dataTableTab_page.clickEditDataTableButton();

        editDataTable_page.upload.click();
        editDataTable_page.validateFile("uploadValidData.csv");

        editDataTable_page.reason.isDisplayedWithWait(2,true);
        editDataTable_page.reason.setValue("Testing");
        editDataTable_page.cancel.click();

        editDataTable_page.cancelEdit.click();
        dataTableSummary_page = new DataTableSummary_Page(driver);

        //assert
        assertEquals("Expect data items are 0 ", "There are no data items added to this table.",
                dataTableSummary_page.dataItemsEmptyMessage.getText());
    }



}
