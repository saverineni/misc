package TestCases.RuleService;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Monitoring.AdminResponse;
import API.Utils;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.HealthCheck;
import TestCases.BaseWebAPITestCase;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static API.EnvDetails.EnvDetails.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpStatus.OK;

@Category(HealthCheck.class)
public class TestCase_HealthCheck extends BaseWebAPITestCase {

    @Test
    @Category(ChangeRequest.CR_261.class)
    public void givenInfoEndpointWhenGetRequestThen200ReturnedWithCorrectBuildInfo() {
        String expectedServiceName = "rule-service-java";

        AdminResponse.InfoResponseObject infoResponse = Utils.makeInfoRequest(url_RS_Info);
        AdminResponse.BuildInfo buildInfo = infoResponse.getBuild();

        assertThat(infoResponse.httpStatusCode).isEqualTo(OK.value());
        assertThat(buildInfo.getVersion()).startsWith("v");

        assertThat(buildInfo.getArtifact()).isEqualTo(expectedServiceName);
        assertThat(buildInfo.getName()).isEqualTo(expectedServiceName);

        assertThat(infoResponse.getGit()).isNotNull();
    }

    @Test
    @Category(ChangeRequest.CR_261.class)
    public void givenHealthEndpointWhenGetRequestedThen200WithUpStatusReturned() {
        AdminResponse.HealthResponseObject healthResponse = Utils.makeHealthRequest(url_RS_Health);

        assertThat(healthResponse).isNotNull();
        assertThat(healthResponse.httpStatusCode).isEqualTo(OK.value());
        assertThat(healthResponse.getStatus()).isEqualTo("UP");
    }

    @Test
    @Category(ChangeRequest.CR_3314.class)
    public void givenRegenerateDrlsEndpointWhenPostRequestThen200ReturnedWithCorrectBuildInfo() {

        TestUserModel.UserDetails udNatRuleManager = Users_API.DefaultSuperAdminUser();
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleManager.pid,Users_API.SUPER_ADMIN_DEFAULT_PASSWORD);

        AdminResponse.HealthResponseObject healthResponse = Utils.regenerateDRLs(url_RM_Renegerate_Drls);

        assertThat(healthResponse.httpStatusCode).isEqualTo(OK.value());
        assertThat(healthResponse.body).isEqualTo("Success");
    }
}
