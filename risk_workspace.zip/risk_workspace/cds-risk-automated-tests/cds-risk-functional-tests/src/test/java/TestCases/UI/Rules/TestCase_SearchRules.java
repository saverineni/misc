package TestCases.UI.Rules;

import API.DataForTests.*;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.Utils.RuleAtStatus;
import API.RulesManagementService.Utils.Rules;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Rules;
import Categories_CDSRisk.CDS_Risk_UI_Rules_2;
import Categories_CDSRisk.ChangeRequest;
import FunctionsLibrary.DateTime;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.ElementControls.MultiSelectDropDown;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Utils.Navigation;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.DeclarationType;
import uk.gov.hmrc.risk.test.common.enums.TransportMode;

import java.util.ArrayList;
import java.util.Arrays;

import static FunctionsLibrary.Utils.SleepForMilliSeconds;
import static org.assertj.core.api.Assertions.assertThat;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_2.class})
public class TestCase_SearchRules extends BaseUIWebDriverTestCase {

    private MultiSelectDropDown multiSelectDropDown;

    @Before
    public void setup() {
        multiSelectDropDown = new MultiSelectDropDown(driver);
    }

    @Test
    public void WheListRulesFilteredByStatusAndType_CorrectRulesDisplayed() {

        //Arrange
        TestRuleModel.RuleDetails ruleDetailsDraftLOC = API.DataForTests.Rules.DraftLOCRuleNatManager();
        ruleDetailsDraftLOC.locations.add(Locations.Location_ABZ_UID);
        CreateRuleResponse.PostResponse createRuleResponse = Rules.CreateRuleAndGetResponseObject(ruleDetailsDraftLOC);
        ruleDetailsDraftLOC.description = createRuleResponse.description;

        TestRuleModel.RuleDetails ruleDetailsActiveLoc = API.DataForTests.Rules.DraftLOCRuleNatManager();
        ruleDetailsActiveLoc.locations.add(Locations.Location_ABZ_UID);
        ruleDetailsActiveLoc.description = "ta_active";
        RuleAtStatus.CreateActiveRule(ruleDetailsActiveLoc);

        TestRuleModel.RuleDetails ruleDetailsDraftNAT = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsDraftNAT.locations.add(Locations.Location_EXT_UID);
        CreateRuleResponse.PostResponse response = Rules.CreateRuleAndGetResponseObject(ruleDetailsDraftNAT);
        ruleDetailsDraftNAT.description = response.description;

        TestUserModel.UserDetails UserDetails_RV = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.filterRulesByStatus("Draft");
        listRules_page.filterRulesByRuleType("Local");

        //Assert
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .hasSize(1)
                .contains(ruleDetailsDraftLOC.description);
    }


    @Category(ChangeRequest.CR_2559.class)
    @Test
    public void WheListRulesFilteredByPartialRuleTitle_CorrectRulesDisplayed() {

        //Arrange
        TestRuleModel.RuleDetails ruleDetailsDraftLOC = API.DataForTests.Rules.DraftLOCRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = Rules.CreateRuleAndGetResponseObject(ruleDetailsDraftLOC);
        ruleDetailsDraftLOC.description = createRuleResponse.description;
        ruleDetailsDraftLOC.ruleId = createRuleResponse.ruleId;

        TestRuleModel.RuleDetails ruleDetailsActiveLoc = API.DataForTests.Rules.DraftLOCRuleNatManager();
        ruleDetailsActiveLoc.description = "ta_active";
        RuleAtStatus.CreateActiveRule(ruleDetailsActiveLoc);

        TestRuleModel.RuleDetails ruleDetailsDraftNAT = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = Rules.CreateRuleAndGetResponseObject(ruleDetailsDraftNAT);
        ruleDetailsDraftNAT.description = response.description;

        TestUserModel.UserDetails UserDetails_RV = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.ruleDescription.sendKeys("rule");

        //Assert
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .hasSize(2)
                .contains(ruleDetailsDraftNAT.description, ruleDetailsDraftLOC.description);
    }


    @Category(ChangeRequest.CR_2559.class)
    @Test
    public void WheListRulesFilteredByPartialRuleId_CorrectRulesDisplayed() {

        //Arrange
        TestRuleModel.RuleDetails ruleDetailsDraftLOC = API.DataForTests.Rules.DraftLOCRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = Rules.CreateRuleAndGetResponseObject(ruleDetailsDraftLOC);
        ruleDetailsDraftLOC.description = createRuleResponse.description;
        ruleDetailsDraftLOC.ruleId = createRuleResponse.ruleId;

        TestRuleModel.RuleDetails ruleDetailsActiveLoc = API.DataForTests.Rules.DraftLOCRuleNatManager();
        ruleDetailsActiveLoc.description = "ta_active";
        RuleAtStatus.CreateActiveRule(ruleDetailsActiveLoc);

        TestRuleModel.RuleDetails ruleDetailsDraftNAT = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = Rules.CreateRuleAndGetResponseObject(ruleDetailsDraftNAT);
        ruleDetailsDraftNAT.description = response.description;

        TestUserModel.UserDetails UserDetails_RV = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.ruleId.sendKeys("at-add");

        //Assert
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .hasSize(1)
                .contains(ruleDetailsDraftNAT.description);
    }

    @Category({ChangeRequest.CR_2557.class, ChangeRequest.CR_2599.class})
    @Test
    public void WheListRulesFilteredByRuleTypeAndDeclarationType_CorrectRulesDisplayed() {
        //Search for Local Rules with Declaration types as import and export
        //Arrange
        //This rule will not be shown in search result as this is a National rule and Import
        TestRuleModel.RuleDetails ruleDetailsNatImport = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsNatImport.queryOptions.declarationType = DeclarationType.IM.toString();
        CreateRuleResponse.PostResponse createRuleResponse = Rules.CreateRuleAndGetResponseObject(ruleDetailsNatImport);

        //This rule will be shown in search result as this is a Local rule and Declaration type is Export
        TestRuleModel.RuleDetails ruleDetailsLocExport = API.DataForTests.Rules.DraftLocRuleLocalManager_EXT();
        ruleDetailsLocExport.queryOptions.declarationType = DeclarationType.EX.toString();
        RuleAtStatus.CreateActiveRule(ruleDetailsLocExport);

        //This rule will be shown in search result as this is a Local rule and Declaration type is import
        TestRuleModel.RuleDetails ruleDetailsLocImport = API.DataForTests.Rules.DraftLocRuleLocalManager_POOEXT();
        ruleDetailsLocImport.queryOptions.declarationType = DeclarationType.IM.toString();
        RuleAtStatus.CreateActiveRule(ruleDetailsLocImport);

        TestUserModel.UserDetails UserDetails_RV = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);
        ArrayList<String> declarationList = new ArrayList<String>(
                Arrays.asList("Imports", "Exports"));
        listRules_page.filterRulesByRuleType("Local");
        listRules_page.filterRulesByDeclarationTypes(declarationList);
        SleepForMilliSeconds(500);

        //Assert
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .hasSize(2)
                .containsOnly(ruleDetailsLocExport.description, ruleDetailsLocImport.description);
    }

    @Category({ChangeRequest.CR_2557.class, ChangeRequest.CR_2593.class})
    @Test
    public void WheListRulesFilteredByRuleStatusAndModeOfTransport_CorrectRulesDisplayed() {

        //Search for Archived rule with Transport mode as Air
        //Arrange
        //This rule will not be shown in search result as this is a Expired rule and Transport Mode Air
        TestRuleModel.RuleDetails expiredRuleTransportModeAir = API.DataForTests.Rules.DraftNatRuleNatManager();
        expiredRuleTransportModeAir.descriptionStaticPrefix = "Expiredrule";
        expiredRuleTransportModeAir.queryOptions.transportMode = TransportMode.Air.toString();

        //This rule will not be shown in search result as this is a Suspended rule and Transport Mode Air
        TestRuleModel.RuleDetails suspendedRuleAir = API.DataForTests.Rules.DraftLocRuleLocalManager_EXT();
        suspendedRuleAir.descriptionStaticPrefix = "SuspendedRule";
        suspendedRuleAir.queryOptions.transportMode = TransportMode.Air.toString();

        //This rule will be shown in search result as this is a Archived rule and Transport Mode Air
        TestRuleModel.RuleDetails archivedRuleAir = API.DataForTests.Rules.DraftLocRuleLocalManager_POOEXT();
        suspendedRuleAir.descriptionStaticPrefix = "ArchivedRule";
        suspendedRuleAir.queryOptions.transportMode = TransportMode.Air.toString();


        RuleAtStatus.CreateXNoRulesAtStatus(suspendedRuleAir, TestEnumerators.RuleStatus.suspended, 1);
        RuleAtStatus.CreateXNoRulesAtStatus(expiredRuleTransportModeAir, TestEnumerators.RuleStatus.expired, 1);
        RuleAtStatus.CreateXNoRulesAtStatus(archivedRuleAir, TestEnumerators.RuleStatus.archived, 1);
        publishAndWait(2000);


        TestUserModel.UserDetails UserDetails_RV = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);
        ArrayList<String> transportList = new ArrayList<String>(
                Arrays.asList("Air"));
        listRules_page.filterRulesByStatus("Archived");
        SleepForMilliSeconds(500);

        listRules_page.filterRulesByModesOfTransport(transportList);
        SleepForMilliSeconds(500);

        //Assert
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .hasSize(1)
                .containsOnly(archivedRuleAir.description);
    }

    @Category({ChangeRequest.CR_2560.class, ChangeRequest.CR_2594.class})
    @Test
    public void WheListRulesFilteredByRuleTitleAndActionType_CorrectRulesDisplayed() {

        //Search by rule title as "ActionType" and Action type as Physical Check and Document check and "Document Check And Hold Goods"
        //Arrange
        //This rule will be shown in search result as this has action type as physical check and rule name has ActionType
        TestRuleModel.RuleDetails ruleDetailsPhysicalCheck = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsPhysicalCheck.description = "ActionTypePhysicalCheck";
        CreateRuleResponse.PostResponse createRuleResponse = Rules.CreateRuleAndGetResponseObject(ruleDetailsPhysicalCheck);

        //This rule will be shown in search result as this has action type as doccheckandhold goods and rule name has ActionType
        TestRuleModel.RuleDetails ruleDetailsDocCheck = API.DataForTests.Rules.DraftLocRuleLocalManager_EXT();
        ruleDetailsDocCheck.description = "ActionTypeDoCheck";
        ruleDetailsDocCheck.ruleOutputs.actionType = "2";
        ruleDetailsDocCheck.ruleOutputs.holdNarrative = "Document Check";
        ruleDetailsDocCheck.ruleOutputs.assigneeID= "nch_open_general_export_licence";
        RuleAtStatus.CreateActiveRule(ruleDetailsDocCheck);

        //This rule will not be shown in search result as this has action type as doccheckandhold goods but rule name doesnot have ActionType
        TestRuleModel.RuleDetails ruleDetailsDocumentCheck = API.DataForTests.Rules.DraftLocRuleLocalManager_POOEXT();
        ruleDetailsDocumentCheck.description = "LocalRuleForPooExt";
        ruleDetailsDocumentCheck.ruleOutputs.actionType = "2";
        ruleDetailsDocumentCheck.ruleOutputs.holdNarrative = "Document Check";
        RuleAtStatus.CreateActiveRule(ruleDetailsDocumentCheck);

        TestUserModel.UserDetails UserDetails_RV = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);
        ArrayList<String> actionTypeList = new ArrayList<String>(
                Arrays.asList("Physical Check", "Document Check And Hold Goods"));
        listRules_page.ruleDescription.sendKeys("ActionType");
        listRules_page.filterRulesByActionTypes(actionTypeList);
        SleepForMilliSeconds(500);


        //Assert
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .hasSize(2)
                .contains(ruleDetailsPhysicalCheck.description, ruleDetailsDocCheck.description);
    }

    @Category({ChangeRequest.CR_2625.class})
    @Test
    public void WhenListRulesFilteredByFreightLocationsAndRuleStatus_CorrectRulesDisplayed() {
        //Arrange

        //Create a national pending rule
        TestRuleModel.RuleDetails ruleDetailsPendingRuleNat = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsPendingRuleNat.description="NationalPendingRule";
        RuleAtStatus.CreatePendingExpiredRuleVersion(ruleDetailsPendingRuleNat,5,8);

        //Create a pending rule for rule with Goods Location WAT, LON
        TestRuleModel.RuleDetails ruleDetailsPendingRuleWatLon= API.DataForTests.Rules.DraftLocRuleLocalManager_WAT();
        ruleDetailsPendingRuleWatLon.locations.add(Locations.Location_LON_UID);
        ruleDetailsPendingRuleWatLon.description = "PendingRuleWATLON";
        RuleAtStatus.CreatePendingExpiredRuleVersion(ruleDetailsPendingRuleWatLon,5,9);
        ruleDetailsPendingRuleWatLon.description = "rule3DaysTime";
        ruleDetailsPendingRuleWatLon.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(3, DateTime.DateTimeUTCZ);
        ruleDetailsPendingRuleWatLon.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(4, DateTime.DateTimeUTCZ);
        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetailsPendingRuleWatLon, 2);
        publishAndWait(5000);

        //Create Committed Rule for Rule with Goods Location POO
        TestRuleModel.RuleDetails ruleDetailsCommittedRulePoo = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        ruleDetailsCommittedRulePoo.description = "CommittedRulePoo";
        RuleAtStatus.CreateCommittedRule(ruleDetailsCommittedRulePoo);

        TestUserModel.UserDetails UserDetails_RV = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        //Act
        //Serach for rules which has status Committed and Pending and the locations as London And Poole
        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);
        ArrayList<String> status = new ArrayList<String>(
                Arrays.asList("Committed","Pending"));
        ArrayList<String> locations = new ArrayList<String>(
                Arrays.asList("LON - London"));
        listRules_page.filterRulesByStatus(status);
        listRules_page.filterRulesByFreightLocations(locations);
        multiSelectDropDown.searchAndSelectTheValue(listRules_page.freightLocationsDropDown,listRules_page.searchInput,"poo","POO - Poole");
        SleepForMilliSeconds(500);


        //Assert
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .hasSize(2)
                .containsOnly(ruleDetailsPendingRuleWatLon.description, ruleDetailsCommittedRulePoo.description);

        assertThat(listRules_page.getListOfRules()).extracting("pending")
                .hasSize(2)
                .containsOnly(2,0);

    }
}
