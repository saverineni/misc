package TestCases.RiskingService;

import API.DataForTests.DataTables;
import API.DataForTests.Rules;
import API.DataForTests.TestDataTableModel;
import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestRuleModel.RuleDetails;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.EditDataTableData.EditDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.ConditionType;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;
import uk.gov.hmrc.risk.test.common.model.publishService.PublishEventModel;
import uk.gov.hmrc.risk.test.common.model.publishService.PublishedRules;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import static API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody;

@Slf4j
@Category(Risking_Service.class)
public class TestCase_Risking_DataTables extends WebAPITestCaseWithDatatablesCleanup {

    @Before
    public void setup() throws IOException, TimeoutException {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
    }

    private RuleDetails CreateCommittedRuleWithCommodityCodeDataTable(){

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(createDataTableResponse.uuid);
        //tableDetails.tableVersionUuid = responseDetail.tableVersionUuid;
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //add data items to data table
        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "commodityCode";
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = tableDetails.uuid;
        ruleDetails.queryConditions.get(0).conditions.get(0).isDataTable = true;
        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        return ruleDetails;
    }

    private RuleDetails CreateCommittedRuleWithFreeTextDataTable(TestDataTableModel.TableDetails tableDetails, String operator) {

        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(createDataTableResponse.uuid);
        //tableDetails.tableVersionUuid = responseDetail.tableVersionUuid;
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //add data items to data table
        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        //ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "consigneeAddress";
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "goodsDescription";
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).operator = operator;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = tableDetails.uuid;
        ruleDetails.queryConditions.get(0).conditions.get(0).isDataTable = true;
        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        return ruleDetails;
    }

    @Test
    @Category(ChangeRequest.CR_904.class)
    public void WhenDeclarationSubmittedWithValueNotInDataTable_NoRouteReturned() {

        //Arrange
        CreateCommittedRuleWithCommodityCodeDataTable();

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry = "9900000000";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        declaration.controlTypeExpectedValue = "";
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category(ChangeRequest.CR_904.class)
    public void WhenDeclarationSubmittedWithValueInDataTable_RouteReturned() {

        //Arrange
        CreateCommittedRuleWithCommodityCodeDataTable();

        publishAndWait(5000);

        //Debugging purposes
        PublishEventModel latestPublishEvent = cacheLoaderSupport.getLatestPublishEvent(2);
        PublishedRules publishedRules = cacheLoaderSupport.getPublishedRules(latestPublishEvent.getRulePackageId().toString());
        log.debug(publishedRules.toString());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.commodity = "0200000000";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category(ChangeRequest.CR_904.class)
    public void WhenDeclarationSubmittedWithUpdatedValueInDataTable_RouteReturned() {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(createDataTableResponse.uuid);
        //tableDetails.tableVersionUuid = responseDetail.tableVersionUuid;
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //add data items to data table
        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponseObject = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(tableDetails.uuid);

        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "commodityCode";
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = tableDetails.uuid;
        ruleDetails.queryConditions.get(0).conditions.get(0).isDataTable = true;
        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        //Add new data item to data table
        tableDetails.dataItemsToAdd.add("0700000000");
        //tableDetails.tableVersionUuid = viewDataTableResponseObject.tableVersionUuid;
        tableDetails.opLockVersion = viewDataTableResponseObject.opLockVersion;
        EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.commodity = "0700000000";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category(ChangeRequest.CR_904.class)
    public void WhenDeclarationSubmittedWithValueRemovedFromDataTable_NoRouteReturned() {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(createDataTableResponse.uuid);
        //tableDetails.tableVersionUuid = responseDetail.tableVersionUuid;
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //add data items to data table
        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponseObject = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(tableDetails.uuid);

        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "commodityCode";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = tableDetails.uuid;
        ruleDetails.queryConditions.get(0).conditions.get(0).isDataTable = true;
        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        //Add new data item to data table
        tableDetails.dataItemsToRemove.add("0200000000");
        EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry = "0200000000";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        declaration.controlTypeExpectedValue = "";
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    //Note this test will fail until CR-2191 cancels previous active rule versions
    //@Ignore("Note this test will fail until CR-2191 cancels previous active rule versions")
    @Test
    @Category(ChangeRequest.CR_904.class)
    public void WhenDeclarationSubmittedWithNewDataTable_RouteReturned() {

        //Arrange
        RuleDetails ruleDetails = CreateCommittedRuleWithCommodityCodeDataTable();
        publishAndWait(5000);

        //Create 2nd table
        TestDataTableModel.TableDetails tableDetails2 = DataTables.DataTable_CommodityCodes_POO();
        CreateDataTableResponse.PostResponse createDataTableResponse2 = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails2);
        tableDetails2.uuid = createDataTableResponse2.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail2 = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(createDataTableResponse2.uuid);
        //tableDetails2.tableVersionUuid = responseDetail2.tableVersionUuid;
        tableDetails2.opLockVersion = responseDetail2.opLockVersion;

        //add data items to data table
        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails2);

        //Update rule to point to new data table
        ruleDetails.queryConditions.get(0).conditions.get(0).value = tableDetails2.uuid;
        API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetails);

        ruleDetails.version = 2;
        API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails, RuleVersionActions.commit);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.commodity = "1001000000";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category(ChangeRequest.CR_1714.class)
    public void WhenDeclarationSubmittedWithValueInDataTableMatchingOnOperatorStartsWith_RouteReturned() {

        //Arrange
        CreateCommittedRuleWithFreeTextDataTable(DataTables.DataTable_FreeText_Risking(), "st");

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.goodsDescription = "North Korea Arms Corporation";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category(ChangeRequest.CR_1714.class)
    public void WhenDeclarationSubmittedWithValueInDataTableMatchingOnOperatorNotStartsWith_RouteReturned() {

        //Arrange
        CreateCommittedRuleWithFreeTextDataTable(DataTables.DataTable_FreeText_Risking(), "nst");

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.goodsDescription = "Korea Arms Corporation";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category(ChangeRequest.CR_1762.class)
    public void WhenDeclarationSubmittedWithValueInDataTableMatchingOnOperatorContains_RouteReturned() {

        //Arrange
        CreateCommittedRuleWithFreeTextDataTable(DataTables.DataTable_FreeText_Risking(), "con");

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.goodsDescription = "The Military Trading Corporation";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category(ChangeRequest.CR_1762.class)
    public void WhenDeclarationSubmittedWithValueInDataTableMatchingOnOperatorNotContains_RouteReturned() {

        //Arrange
        CreateCommittedRuleWithFreeTextDataTable(DataTables.DataTable_FreeText_Risking(), "nco");

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.goodsDescription = "The Trading Corporation";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category(ChangeRequest.CR_1847.class)
    public void WhenDeclarationSubmittedWithValueInDataTableMatchingOnOperatorMatchesPattern_RouteReturned() {

        //Arrange
        CreateCommittedRuleWithFreeTextDataTable(DataTables.DataTable_FreeText_RiskingMatchPattern(), "matchesPattern");

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        //declaration.consignee = "Robinson &amp; Crusoes";  //note & is an escape character in xml need to use &amp;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.goodsDescription = "car";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category(ChangeRequest.CR_1847.class)
    public void WhenDeclarationSubmittedWithValueInDataTableMatchingOnOperatorNotMatchesPattern_RouteReturned() {

        //Arrange
        CreateCommittedRuleWithFreeTextDataTable(DataTables.DataTable_FreeText_RiskingMatchPattern(), "notMatchesPattern");

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.goodsDescription = "miles";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category(ChangeRequest.CR_3395.class)
    public void WhenDeclarationSubmittedWithValidDataTableForBuyerPostCodeHeaderLevel_RouteReturned() {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_PostCodeValid();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //add data items to data table
        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponseObject = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(tableDetails.uuid);

        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "buyerPostcode_Header";
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = tableDetails.uuid;
        ruleDetails.queryConditions.get(0).conditions.get(0).isDataTable = true;
        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        //Add new data item to data table
        tableDetails.dataItemsToAdd.add("M23 4AH");
        tableDetails.opLockVersion = viewDataTableResponseObject.opLockVersion;
        EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.buyerPostcode_Header = "m23 4AH";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category(ChangeRequest.CR_3395.class)
    public void WhenDeclarationSubmittedWithValidDataTableForImporterBuyerEoriDomain_RouteReturned() {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_EORI_Valid();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //add data items to data table
        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponseObject = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(tableDetails.uuid);

        RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "importerBuyerEori_domain";
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = tableDetails.uuid;
        ruleDetails.queryConditions.get(0).conditions.get(0).isDataTable = true;
        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        //Add new data item to data table
        tableDetails.dataItemsToAdd.add("FG1234567890");
        tableDetails.opLockVersion = viewDataTableResponseObject.opLockVersion;
        EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.buyerId_Header = "FG1234567890";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
}
