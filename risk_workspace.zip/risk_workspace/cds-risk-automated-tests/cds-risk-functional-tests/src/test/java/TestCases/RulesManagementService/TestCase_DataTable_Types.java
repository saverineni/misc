package TestCases.RulesManagementService;


import API.DataForTests.TestDataTableModel;
import API.DataForTests.TestRuleModel;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.EditDataTableData.EditDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import API.RulesManagementService.ViewRuleVersion.ViewRuleVersionResponse;
import Categories_CDSRisk.CDS_RM_CreateRules;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import org.apache.http.HttpStatus;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.ConditionType;

import static API.DataForTests.DataTables.*;
import static API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject;
import static API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID;
import static API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject;
import static API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_CreateRules.class})
public class TestCase_DataTable_Types extends WebAPITestCaseWithDatatablesCleanup {

    @Test
    @Category(ChangeRequest.CR_2861.class)
    public void WhenDataTableTypeCommodityCodeCreated_DataTableCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_CommodityCodes_NAT();

        //Act & Assert
        CreateDataTableWithDataForDataTypeAndCheckValidResponse(tableDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2861.class)
    public void WhenDataTableTypeFreeTextCreated_DataTableCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_FreeText_Valid();

        //Act & Assert
        CreateDataTableWithDataForDataTypeAndCheckValidResponse(tableDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2861.class)
    @Ignore("Should have been fixed as part of CR-3194, but still broken")
    public void WhenDataTableTypePartialCommodityCodeCreated_DataTableCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_PartCommodityCodes();

        //Act & Assert
        CreateDataTableWithDataForDataTypeAndCheckValidResponse(tableDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2861.class)
    public void WhenDataTableTypeCountryCodeCreated_DataTableCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_CountryCode_Valid();

        //Act & Assert
        CreateDataTableWithDataForDataTypeAndCheckValidResponse(tableDetails);
    }


    @Test
    @Category(ChangeRequest.CR_2861.class)
    public void WhenDataTableTypeDecimalCreated_DataTableCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_Decimal_Valid();

        //Act & Assert
        CreateDataTableWithDataForDataTypeAndCheckValidResponse(tableDetails);
    }


    @Test
    @Category(ChangeRequest.CR_2861.class)
    public void WhenDataTableTypeDocumentCategoryCodeCreated_DataTableCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_DocumentCategoryCode_Valid();

        //Act & Assert
        CreateDataTableWithDataForDataTypeAndCheckValidResponse(tableDetails);
    }


    @Test
    @Category(ChangeRequest.CR_2861.class)
    public void WhenDataTableTypeDocumentTypeCodeCreated_DataTableCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_DocumentTypeCode_Valid();

        //Act & Assert
        CreateDataTableWithDataForDataTypeAndCheckValidResponse(tableDetails);
    }


    @Test
    @Category(ChangeRequest.CR_2861.class)
    public void WhenDataTableTypeEORICreated_DataTableCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_EORI_Valid();

        //Act & Assert
        CreateDataTableWithDataForDataTypeAndCheckValidResponse(tableDetails);
    }


    @Test
    @Category(ChangeRequest.CR_2862.class)
    public void WhenDataTableTypeIntegerCreated_DataTableCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_Integer_Valid();

        //Act & Assert
        CreateDataTableWithDataForDataTypeAndCheckValidResponse(tableDetails);
    }


    @Test
    @Category(ChangeRequest.CR_2862.class)
    public void WhenDataTableTypeMoneyCreated_DataTableCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_Money_Valid();

        //Act & Assert
        CreateDataTableWithDataForDataTypeAndCheckValidResponse(tableDetails);
    }


    @Test
    @Category(ChangeRequest.CR_2862.class)
    public void WhenDataTableTypePackageTypeCreated_DataTableCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_PackageType_Valid();

        //Act & Assert
        CreateDataTableWithDataForDataTypeAndCheckValidResponse(tableDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2954.class)
    public void WhenDataTableTypePaymentMethodCreated_DataTableCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_PaymentMethodValid();

        //Act & Assert
        CreateDataTableWithDataForDataTypeAndCheckValidResponse(tableDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2954.class)
    public void WhenDataTableTypePostCodeCreated_DataTableCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_PostCodeValid();

        //Act & Assert
        CreateDataTableWithDataForDataTypeAndCheckValidResponse(tableDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2954.class)
    public void WhenDataTableTypePreferenceCodeCreated_DataTableCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_PreferenceCodeValid();

        //Act & Assert
        CreateDataTableWithDataForDataTypeAndCheckValidResponse(tableDetails);
    }


    @Test
    @Category(ChangeRequest.CR_2954.class)
    public void WhenDataTableTypePreviousDocTypeCreated_DataTableCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_PreviousDocTypeValid();

        //Act & Assert
        CreateDataTableWithDataForDataTypeAndCheckValidResponse(tableDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2954.class)
    public void WhenDataTableTypeCPCCreated_DataTableCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_CPCValid();

        //Act & Assert
        CreateDataTableWithDataForDataTypeAndCheckValidResponse(tableDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2954.class)
    public void WhenDataTableTypeSpecificCircumstanceCreated_DataTableCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_SpecificCircumstanceValid();

        //Act & Assert
        CreateDataTableWithDataForDataTypeAndCheckValidResponse(tableDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2954.class)
    public void WhenDataTableTypeTaxTypeCreated_DataTableCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_TaxTypeValid();

        //Act & Assert
        CreateDataTableWithDataForDataTypeAndCheckValidResponse(tableDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2861.class)
    public void WhenRuleCreatedWithDataTableTypeCountryCode_RuleCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_CountryCode_Valid();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "dispatchCountry_Header";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act & Assert
        CreateRuleAndCheckResponse(ruleDetails);
    }


    @Test
    @Category(ChangeRequest.CR_2861.class)
    public void WhenRuleCreatedWithDataTableTypeDecimal_RuleCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_Decimal_Valid();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "totalGrossMass";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).isDataTable = true;

        //Act & Assert
        CreateRuleAndCheckResponse(ruleDetails);
    }


    @Test
    @Category(ChangeRequest.CR_2861.class)
    public void WhenRuleCreatedWithDataTableTypeDocumentCategoryCode_RuleCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_DocumentCategoryCode_Valid();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "previousDocumentClass";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act & Assert
        CreateRuleAndCheckResponse(ruleDetails);
    }


    @Test
    @Category(ChangeRequest.CR_2861.class)
    public void WhenRuleCreatedWithDataTableTypeDocumentTypeCode_RuleCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_DocumentTypeCode_Valid();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "documentType";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act & Assert
        CreateRuleAndCheckResponse(ruleDetails);
    }


    @Test
    @Category(ChangeRequest.CR_2861.class)
    public void WhenRuleCreatedWithDataTableTypeEORI_RuleCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_EORI_Valid();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "consigneeEori";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act & Assert
        CreateRuleAndCheckResponse(ruleDetails);
    }


    @Test
    @Category(ChangeRequest.CR_2862.class)
    public void WhenRuleCreatedWithDataTableTypeInteger_RuleCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_Integer_Valid();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "packageCount_Header";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act & Assert
        CreateRuleAndCheckResponse(ruleDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2862.class)
    public void WhenRuleCreatedWithDataTableTypeMoney_RuleCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_Money_Valid();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "invoiceTotal";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act & Assert
        CreateRuleAndCheckResponse(ruleDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2862.class)
    public void WhenRuleCreatedWithDataTablePackageType_RuleCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_PackageType_Valid();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "packageType";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act & Assert
        CreateRuleAndCheckResponse(ruleDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2954.class)
    public void WhenRuleCreatedWithDataTableTypeAdditionalCommodityCode_RuleCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_AdditionalCommodityCodes_Valid();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "additionalCommodityCode2";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act & Assert
        CreateRuleAndCheckResponse(ruleDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2954.class)
    public void WhenRuleCreatedWithDataTableTypePaymentMethod_RuleCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_PaymentMethodValid();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "declaredDutyTaxFees_PaymentMethodItem";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act & Assert
        CreateRuleAndCheckResponse(ruleDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2954.class)
    public void WhenRuleCreatedWithDataTableTypePostCode_RuleCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_PostCodeValid();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "representativePostcode";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act & Assert
        CreateRuleAndCheckResponse(ruleDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2954.class)
    public void WhenRuleCreatedWithDataTableTypePreferenceCode_RuleCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_PreferenceCodeValid();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "declaredDutyTaxFees_PreferenceCodeItem";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act & Assert
        CreateRuleAndCheckResponse(ruleDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2954.class)
    public void WhenRuleCreatedWithDataTableTypePreviousDocType_RuleCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_PreviousDocTypeValid();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "previousDocuments_TypeItem";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act & Assert
        CreateRuleAndCheckResponse(ruleDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2954.class)
    public void WhenRuleCreatedWithDataTableTypeCPC_RuleCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_CPCValid();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "cpc";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act & Assert
        CreateRuleAndCheckResponse(ruleDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2954.class)
    public void WhenRuleCreatedWithDataTableTypeSpecificCircumstance_RuleCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_SpecificCircumstanceValid();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "specificCircumstance";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        //Act & Assert
        CreateRuleAndCheckResponse(ruleDetails);
    }

    @Test
    @Category(ChangeRequest.CR_2954.class)
    public void WhenRuleCreatedWithDataTableTypeTaxType_RuleCreatedSuccessfully()  {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_TaxTypeValid();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "declaredDutyTaxFees_TaxTypeItem";

        //Act & Assert
        CreateRuleAndCheckResponse(ruleDetails);
    }


    private void CreateDataTableWithDataForDataTypeAndCheckValidResponse(TestDataTableModel.TableDetails tableDetails)
    {
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_CREATED, createDataTableResponse.httpStatusCode);
        assertEquals(tableDetails.tableName, createDataTableResponse.tableName);
        assertEquals(tableDetails.dataType, createDataTableResponse.dataType);

        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, responseEdit.httpStatusCode);
    }


    private void CreateRuleAndCheckResponse(TestRuleModel.RuleDetails ruleDetails) {

        ruleDetails.queryConditions.get(0).conditions.get(0).isDataTable = true;

        //Act
        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, createRuleResponse.httpStatusCode);
    }

}
