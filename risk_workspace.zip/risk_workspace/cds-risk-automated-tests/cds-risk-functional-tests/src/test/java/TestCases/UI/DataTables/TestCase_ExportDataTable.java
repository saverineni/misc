package TestCases.UI.DataTables;

import API.DataForTests.DataTables;
import API.DataForTests.TestDataTableModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_DataTables;
import Categories_CDSRisk.ChangeRequest;
import FunctionsLibrary.FileUtilities;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.Pages.DataManagement.DataTableData_Page;
import UI.Pages.DataManagement.DataTableSummary_Page;
import UI.Pages.DataManagement.ListDataTable_Page;
import UI.Utils.Navigation;
import com.google.common.collect.Iterables;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.CharEncoding;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import static API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject;
import static API.RulesManagementService.Utils.DataTables.editDataTableDataItems;
import static FunctionsLibrary.Utils.SleepForMilliSeconds;
import static org.assertj.core.api.Assertions.assertThat;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_DataTables.class})
public class TestCase_ExportDataTable extends BaseUIWebDriverTestCase {

    private TestDataTableModel.TableDetails tableDetailsFreeText;

    @Before
    public void Setup()  {

        tableDetailsFreeText = DataTables.DataTable_FreeText_Valid();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetailsFreeText);
        tableDetailsFreeText.uuid = createDataTableResponse.uuid;
        tableDetailsFreeText.uniqueId = createDataTableResponse.uniqueId;

        editDataTableDataItems(tableDetailsFreeText);

        FileUtilities.DeleteFileFromDirectory(FileUtils.getTempDirectory(), new String[]{"csv"});
    }



    @Ignore("TODO: Can't execute in pipeline until Selenium Grid is hosted on same box as Jenkins. As exported file can not be found")
    @Category(ChangeRequest.CR_2094.class)
    @Test
    public void WhenRuleManagerLoggedIn_CanExportNationalDataTableToCSVFile() throws Exception {

        //Arrange
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(Users_API.NationalRulesManagerDefaultTestAutomationUser());

        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listMyDataTables_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = listMyDataTables_page.clickTableSummaryForSpecifiedDataTableID(tableDetailsFreeText.uniqueId);

        //Act5
        dataTableSummary_page.dataTab.click();
        DataTableData_Page dataTableTab_page = new DataTableData_Page(driver);

        dataTableTab_page.export.click();
        SleepForMilliSeconds(1000);
        Collection<File> exportedFiles = FileUtils.listFiles(FileUtils.getTempDirectory(), new String[]{"csv"}, false);

        File exportedFile = Iterables.get(exportedFiles, 0);
        List<String> exportedFileLines = FileUtils.readLines(exportedFile, CharEncoding.UTF_8);

        //Assert
        assertThat(exportedFileLines).hasSize(2)
                .containsOnlyElementsOf(tableDetailsFreeText.dataItems);

        DateFormat df = new SimpleDateFormat("yyyyMMdd");
        String expectedFileDate = df.format(new Date());
        String expectedFileNamePattern = "DT-NAT-[0-9]{4}-[0-9]{2}-" + expectedFileDate + "-[0-9]{6}.csv";

        assertThat(exportedFile.getName()).matches(expectedFileNamePattern);
    }


    @Ignore("TODO: Can't execute in pipeline until Selenium Grid is hosted on same box as Jenkins. As exported file can not be found")
    @Category(ChangeRequest.CR_2094.class)
    @Test
    public void WhenRuleManagerLoggedIn_CanExportLocalDataTableToCSVFile() throws Exception {

        //Arrange
        TestUserModel.UserDetails userDetailsLocalRM = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(userDetailsLocalRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);

        TestDataTableModel.TableDetails tableDetailsEXTComCodes = DataTables.DataTable_CommodityCodes_EXT();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetailsEXTComCodes);
        tableDetailsEXTComCodes.uuid = createDataTableResponse.uuid;
        tableDetailsEXTComCodes.uniqueId = createDataTableResponse.uniqueId;

        editDataTableDataItems(tableDetailsEXTComCodes);

        utilUsers.LoginToCDSRiskUIAsUser(userDetailsLocalRM);
        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listMyDataTables_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = listMyDataTables_page.clickTableSummaryForSpecifiedDataTableID(tableDetailsEXTComCodes.uniqueId);

        //Act
        dataTableSummary_page.dataTab.click();
        DataTableData_Page dataTableTab_page = new DataTableData_Page(driver);

        dataTableTab_page.export.click();
        SleepForMilliSeconds(1000);
        Collection<File> exportedFiles = FileUtils.listFiles(FileUtils.getTempDirectory(), new String[]{"csv"}, false);

        File exportedFile = Iterables.get(exportedFiles, 0);
        List<String> exportedFileLines = FileUtils.readLines(exportedFile, CharEncoding.UTF_8);

        //Assert
        assertThat(exportedFileLines).hasSize(4)
                .containsOnlyElementsOf(tableDetailsEXTComCodes.dataItems);

        DateFormat df = new SimpleDateFormat("yyyyMMdd");
        String expectedFileDate = df.format(new Date());
        String expectedFileNamePattern = "DT-EXT-[0-9]{4}-[0-9]{2}-" + expectedFileDate + "-[0-9]{6}.csv";

        assertThat(exportedFile.getName()).matches(expectedFileNamePattern);
    }

    //Note Exporting more than 64K covered by Dev Integration Tests.

}
