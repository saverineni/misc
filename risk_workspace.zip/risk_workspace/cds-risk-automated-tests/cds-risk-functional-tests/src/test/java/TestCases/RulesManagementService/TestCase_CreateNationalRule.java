package TestCases.RulesManagementService;


import API.DataForTests.Locations;
import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.ViewRule.ViewRuleResponse;
import API.RulesManagementService.ViewRuleList.ViewRuleListResponse;
import API.RulesManagementService.ViewRuleVersion.ViewRuleVersionResponse;
import Categories_CDSRisk.CDS_RM_CreateRules;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import org.apache.http.HttpStatus;
import org.assertj.core.api.Assertions;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.TransportMode;

import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_CreateRules.class})
public class TestCase_CreateNationalRule extends BaseWebAPITestCase{

    @Test
    @Category(ChangeRequest.CR_585.class)
    public void WhenNationalRuleSaved_LocationSetToNational() throws Throwable
    {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryOptions.transportMode = TransportMode.All.toString();

        ruleDetails.locations.add(0, Locations.Location_National_UID);
        ruleDetails.locations.remove(1);

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(createRuleResponse.uniqueId);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        //Assert
        assertEquals("Location uid: ", Locations.Location_National_UID, createRuleResponse.locationUuids.get(0));
        assertEquals("Location uid: ", Locations.Location_National_UID, viewRuleResponse.versions.get(0).locations.get(0).locationUuid);
        assertEquals("Location uid: ", Locations.Location_National_UID, viewRuleVerResponse.locations.get(0).locationUuid);
    }


    @Ignore("Placeholder Test: Note Backend API is not current restricting creation of rule by user pid")
    @Test
    @Category(ChangeRequest.CR_585.class)
    public void AttemptToCreateNationalRuleAsLocalUser_RuleNotCreated() throws Throwable
    {

        //Arrange
        TestUserModel.UserDetails udRuleManPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOO.pid);

                //Act
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_UNAUTHORIZED, createRuleResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_621.class)
    public void WhenNationalRuleSaved_RuleCanNOTBeViewedByLocalUser() throws Throwable
    {
        //National Rules Manager User creates National Rule
        //A Local Rule Manager: POO can NOT view the created local rule

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        TestUserModel.UserDetails udRuleViewerPOO = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleViewerPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleViewerPOO.pid);

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject viewListRulesResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        int ruleNo = API.RulesManagementService.Utils.Rules.GetNoOfMatchingRuleFromRuleList(viewListRulesResponse, ruleDetails.uniqueID);
        assertEquals("Expect no matching rules", 0, ruleNo);
    }


    @Test
    @Category({ChangeRequest.CR_619.class, ChangeRequest.CR_609.class, ChangeRequest.CR_1205.class})
    public void WhenNationalRuleSaved_RuleIDSetToNATRegimeCodeSequenceNoAndYear() throws Throwable
    {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(createRuleResponse.uniqueId);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);
        ViewRuleListResponse.ViewRuleListResponseObject viewListRulesResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        Assertions.assertThat(createRuleResponse.ruleId).containsPattern(ruleDetails.ruleId);
        Assertions.assertThat(viewRuleResponse.ruleId).containsPattern(ruleDetails.ruleId);
        Assertions.assertThat(viewRuleVerResponse.ruleId).containsPattern(ruleDetails.ruleId);

        int ruleNo = API.RulesManagementService.Utils.Rules.GetNoOfMatchingRuleFromRuleList(viewListRulesResponse, createRuleResponse.uniqueId);
        String actRuleID = viewListRulesResponse.content.get(ruleNo).ruleId;
        Assertions.assertThat(actRuleID).containsPattern(ruleDetails.ruleId);

        assertEquals("RegimeCode " + createRuleResponse.regime.regimeCodeUuid, ruleDetails.regimeCodeUuid, createRuleResponse.regime.regimeCodeUuid);
        assertEquals("RegimeCode " + viewRuleResponse.versions.get(0).regime.regimeCodeUuid, ruleDetails.regimeCodeUuid, viewRuleResponse.versions.get(0).regime.regimeCodeUuid);
        assertEquals("RegimeCode " + viewRuleVerResponse.regime.regimeCodeUuid, ruleDetails.regimeCodeUuid,  viewRuleVerResponse.regime.regimeCodeUuid);

    }

    @Test
    @Category(ChangeRequest.CR_2975.class)
    public void WhenNationalRuleSavedWithFallbackStatus_RuleShouldBeSavedCorrectly() throws Throwable
    {
        //National Rules Manager User creates National Rule
        //A Local Rule Manager: POO can NOT view the created local rule

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.fallback=true;
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(createRuleResponse.uniqueId);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        //Assert
        assertEquals("Fallback", true, createRuleResponse.fallback);
     }

}
