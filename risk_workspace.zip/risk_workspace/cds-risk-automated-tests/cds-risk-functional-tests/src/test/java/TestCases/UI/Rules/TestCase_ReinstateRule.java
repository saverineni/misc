package TestCases.UI.Rules;

import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.RuleAction.RuleActionResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Rules;
import Categories_CDSRisk.CDS_Risk_UI_Rules_2;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static API.RulesManagementService.Utils.RuleAtStatus.CreateSuspendedRule;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_2.class})
public class TestCase_ReinstateRule extends BaseUIWebDriverTestCase{

    @Test
    @Category({ChangeRequest.CR_1577.class, ChangeRequest.CR_3057.class})
    public void WhenNationalRuleManagerLoggedIn_CanReinstateSuspendedRule()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse ruleResponse = CreateSuspendedRule();
        ruleDetails.description = ruleResponse.description;

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        boolean bReinstateEnabled = ruleSummary_page.reinstateRule.isEnabled();
        assertEquals("Expect reinstate button to be enabled", true, bReinstateEnabled);

        Dialog_Confirm dialog_confirm = ruleSummary_page.clickReinstateButton();
        dialog_confirm.EnterReason("Test1");
        boolean bOkButtonEnabled = dialog_confirm.ok.isEnabled();
        assertEquals("Expect ok button to be enabled", true, bOkButtonEnabled);
        dialog_confirm.CloseConfirmAndSuccessDialogBox();

        //Assert
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();

        assertEquals(ruleDetails.description, listRuleSummaryTableObjects.get(0).description);
        assertEquals("Expect Rule Version to be 1", ruleDetails.version, listRuleSummaryTableObjects.get(0).version);
        assertEquals("Expect Rule Status to be Committed", "Committed", listRuleSummaryTableObjects.get(0).status);
        assertEquals("View\n" + "Rule Revision 1", listRuleSummaryTableObjects.get(0).versionDetailAction.getText());

        //TO DO Check locations
        //need to store location name for checks in UI
        assertEquals("ABZ - Aberdeen Airport", ruleSummary_page.locations.getText().trim());
    }

    @Test
    public void WhenLocalRuleManagerLoggedIn_CanReinstateSuspendedRule()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        RuleActionResponse.PostResponse ruleResponse = CreateSuspendedRule(ruleDetails);
        ruleDetails.description = ruleResponse.description;

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);
        listRules_page.waitForAngularRequestsToFinish();

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        Dialog_Confirm dialog_confirm = ruleSummary_page.clickReinstateButton();
        ruleSummary_page.waitForAngularRequestsToFinish();
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        //Assert
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        String sRuleStatus = listRuleSummaryTableObjects.get(0).status;

        assertEquals("Expect Rule Status to be Committed", "Committed", sRuleStatus);
    }


    @Test
    public void WhenNationalRuleViewerLoggedIn_CanNOTReinstateSuspendedRule()
    {
        //Arrange
        TestUserModel.UserDetails userDetails_RM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RM);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_RM.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse committedRuleResponse = CreateSuspendedRule(ruleDetails);

        TestUserModel.UserDetails UserDetails_RV = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);
        listRules_page.waitForAngularRequestsToFinish();

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Assert
        boolean bReinstatePresent = ruleSummary_page.isActionButtonPresent("Reinstate Rule");
        assertEquals("Expect Reinstate button to be not present", false, bReinstatePresent);
    }


    @Test
    public void WhenLocalRuleViewerLoggedIn_CanNOTReinstateSuspendedRule()
    {
        //Arrange
        TestUserModel.UserDetails userDetails_RM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RM);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_RM.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        ruleDetails.description = committedRuleResponse.description;

        TestUserModel.UserDetails UserDetails_RV = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Assert
        boolean bReinstatePresent = ruleSummary_page.isActionButtonPresent("Reinstate Rule");
        assertEquals("Expect Reinstate button to be not present", false, bReinstatePresent);
    }



    @Test
    @Category(ChangeRequest.CR_1575.class)
    public void WhenRuleManagerReinstatesRule_ConfirmationMessageAppears()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse ruleResponse = CreateSuspendedRule(ruleDetails);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);
        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Act
        Dialog_Confirm dialog_confirm = ruleSummary_page.clickReinstateButton();
        ruleSummary_page.waitForAngularRequestsToFinish();
        String actText = dialog_confirm.getMessageText();

        //Assert
        assertEquals("Please enter a reason for reinstating this rule", actText);
        assertTrue("Expect OK button to be present", dialog_confirm.ok.isDisplayed());
        assertTrue("Expect Cancel button to be present", dialog_confirm.cancel.isDisplayed());
    }


    @Test
    public void WhenRuleManagerCancelsReinstateRule_ConfirmationMessageClosed()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse ruleResponse = CreateSuspendedRule();
        ruleDetails.description = ruleResponse.description;

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);
        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Act
        Dialog_Confirm dialog_confirm = ruleSummary_page.clickReinstateButton();
        dialog_confirm.clickCancelButton();

        ruleSummary_page.waitForAngularRequestsToFinish();
        publishAndWait(5000);

        ruleSummary_page.refreshPage();

        //Assert
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();

        assertEquals("Expect Rule Status to be suspended", "Suspended", listRuleSummaryTableObjects.get(0).status);
    }

}
