package TestCases.RiskingServiceJava.DataDomain;

import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.Risking_JavaService;
import TestCases.RiskingServiceJava.BaseRiskingServiceJava;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.*;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel.Query;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.Condition;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.conditions;

@Slf4j
@Category({ChangeRequest_RiskingService.CREP_383.class, Risking_JavaService.class})
public class TestCase_NarrativeTests extends BaseRiskingServiceJava {

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithDomainNotEqualsAttribute_CorrectNarrativeTextIsPresent() {
        createRule(Collections.singletonList(consignorCityDomainQuery(Operator.neq, "Manchester")));

        DeclarationResponse response = createAndSendDeclaration( conditions(
                consignorCityHeaderCondition("London"),
                consignorCityItemCondition("London")
        ));

        Assertions.assertThat(response.getReportBackElements())
                .contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2001\"]")
                .contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2002\"]")
                .contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2003\"]")
                .contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2004\"]")
                .hasSize(4);

        Assertions.assertThat(response.getMatchReasons()).hasSize(4);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .hasSize(6)
                .containsOnly(
                        "Declaration field: 'Consignor City' was populated with a value in data domain: 'Consignor City'.  The value was: 'London'",
                        "Declaration field: 'Consignor City' was not equal to a value in data domain: 'Consignor City'.  The value was: 'London'",
                        "Goods Item (sequenceId=2001) field: 'Consignor City' was populated with a value in data domain: 'Consignor City'.  The value was: 'London'",
                        "Goods Item (sequenceId=2001) field: 'Consignor City' was not equal to a value in data domain: 'Consignor City'.  The value was: 'London'",
                        "Declaration field: 'Declaration Type' was equal to IM. The value was: 'IM'",
                        "Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'");

        response.getMatchReasons().stream().skip(1).forEach(mr -> {
            Assertions.assertThat(mr)
                    .hasSize(4)
                    .containsOnly(
                            "Declaration field: 'Consignor City' was populated with a value in data domain: 'Consignor City'.  The value was: 'London'",
                            "Declaration field: 'Consignor City' was not equal to a value in data domain: 'Consignor City'.  The value was: 'London'",
                            "Declaration field: 'Declaration Type' was equal to IM. The value was: 'IM'",
                            "Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'");
        });

    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithDomainContainsAttribute_CorrectNarrativeTextIsPresent() {
        createRule(Collections.singletonList(consignorCityDomainQuery(Operator.con, "Manchester")));

        DeclarationResponse response = createAndSendDeclaration( conditions(consignorCityHeaderCondition("ManchesterCity")
        ));

        Assertions.assertThat(response.getReportBackElements())
                .contains("/declaration")
                .hasSize(1);

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .containsOnly(
                        "Declaration field: 'Consignor City' contains a value in data domain: 'Consignor City'.  The value was: 'ManchesterCity'",
                        "Declaration field: 'Declaration Type' was equal to IM. The value was: 'IM'",
                        "Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'"
                );
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithDomainNotContainsAttribute_CorrectNarrativeTextIsPresent() {
        createRule(Collections.singletonList(consignorCityDomainQuery(Operator.nco, "Manchester")));

        DeclarationResponse response = createAndSendDeclaration( conditions(
                consignorCityHeaderCondition("London is not Mnchstr"),
                consignorCityItemCondition("London is not Mnchstr")
        ));

        Assertions.assertThat(response.getReportBackElements())
                .contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2001\"]")
                .contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2002\"]")
                .contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2003\"]")
                .contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2004\"]")
                .hasSize(4);

        Assertions.assertThat(response.getMatchReasons()).hasSize(4);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .hasSize(6)
                .containsOnly(
                        "Declaration field: 'Consignor City' was populated with a value in data domain: 'Consignor City'.  The value was: 'London is not Mnchstr'",
                        "Declaration field: 'Consignor City' did not contain a value in data domain: 'Consignor City'.  The value was: 'London is not Mnchstr'",
                        "Goods Item (sequenceId=2001) field: 'Consignor City' was populated with a value in data domain: 'Consignor City'.  The value was: 'London is not Mnchstr'",
                        "Goods Item (sequenceId=2001) field: 'Consignor City' did not contain a value in data domain: 'Consignor City'.  The value was: 'London is not Mnchstr'",
                        "Declaration field: 'Declaration Type' was equal to IM. The value was: 'IM'",
                        "Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'");

        response.getMatchReasons().stream().skip(1).forEach(mr -> {
            Assertions.assertThat(mr)
                    .hasSize(4)
                    .containsOnly(
                            "Declaration field: 'Consignor City' was populated with a value in data domain: 'Consignor City'.  The value was: 'London is not Mnchstr'",
                            "Declaration field: 'Consignor City' did not contain a value in data domain: 'Consignor City'.  The value was: 'London is not Mnchstr'",
                            "Declaration field: 'Declaration Type' was equal to IM. The value was: 'IM'",
                            "Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'");
        });
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithDomainStartsWithAttribute_CorrectNarrativeTextIsPresent() {
        createRule(Arrays.asList( consignorCityDomainQuery(Operator.st, "Manchester")));

        DeclarationResponse response = createAndSendDeclaration( conditions( consignorCityHeaderCondition("Manchester is nice")
        ));

        Assertions.assertThat(response.getReportBackElements())
                .contains("/declaration")
                .hasSize(1);

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .containsOnly(
                        "Declaration field: 'Consignor City' starts with a value in data domain: 'Consignor City'.  The value was: 'Manchester is nice'",
                        "Declaration field: 'Declaration Type' was equal to IM. The value was: 'IM'",
                        "Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'"
                );
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithDomainNotStartsWithAttribute_CorrectNarrativeTextIsPresent() {
        createRule(Collections.singletonList(consignorCityDomainQuery(Operator.nst, "Manchester")));

        DeclarationResponse response = createAndSendDeclaration( conditions(
                consignorCityHeaderCondition("Is Manchester nice"),
                consignorCityItemCondition("Is Manchester nice")
        ));

        Assertions.assertThat(response.getReportBackElements())
                .contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2001\"]")
                .contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2002\"]")
                .contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2003\"]")
                .contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2004\"]")
                .hasSize(4);

        Assertions.assertThat(response.getMatchReasons()).hasSize(4);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .hasSize(6)
                .containsOnly(
                        "Declaration field: 'Consignor City' was populated with a value in data domain: 'Consignor City'.  The value was: 'Is Manchester nice'",
                        "Declaration field: 'Consignor City' did not start with a value in data domain: 'Consignor City'.  The value was: 'Is Manchester nice'",
                        "Goods Item (sequenceId=2001) field: 'Consignor City' was populated with a value in data domain: 'Consignor City'.  The value was: 'Is Manchester nice'",
                        "Goods Item (sequenceId=2001) field: 'Consignor City' did not start with a value in data domain: 'Consignor City'.  The value was: 'Is Manchester nice'",
                        "Declaration field: 'Declaration Type' was equal to IM. The value was: 'IM'",
                        "Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'");

        response.getMatchReasons().stream().skip(1).forEach(mr -> {
            Assertions.assertThat(mr)
                    .hasSize(4)
                    .containsOnly(
                            "Declaration field: 'Consignor City' was populated with a value in data domain: 'Consignor City'.  The value was: 'Is Manchester nice'",
                            "Declaration field: 'Consignor City' did not start with a value in data domain: 'Consignor City'.  The value was: 'Is Manchester nice'",
                            "Declaration field: 'Declaration Type' was equal to IM. The value was: 'IM'",
                            "Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'");
        });
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithDomainMatchesPatternAttribute_CorrectNarrativeTextIsPresent() {
        createRule(Arrays.asList( consignorCityDomainQuery(Operator.matchesPattern, "M??chester")));

        DeclarationResponse response = createAndSendDeclaration( conditions( consignorCityHeaderCondition("Manchester")
        ));

        Assertions.assertThat(response.getReportBackElements())
                .contains("/declaration")
                .hasSize(1);

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .containsOnly(
                        "Declaration field: 'Consignor City' matches a value in data domain: 'Consignor City'.  The value was: 'Manchester'",
                        "Declaration field: 'Declaration Type' was equal to IM. The value was: 'IM'",
                        "Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'"
                );
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithDomainNotMatchesPatternAttribute_CorrectNarrativeTextIsPresent() {
        createRule(Arrays.asList( consignorCityDomainQuery(Operator.notMatchesPattern, "M??chester")));

        DeclarationResponse response = createAndSendDeclaration( conditions(
                consignorCityHeaderCondition("London"),
                consignorCityItemCondition("London")
        ));

        Assertions.assertThat(response.getReportBackElements())
                .contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2001\"]")
                .contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2002\"]")
                .contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2003\"]")
                .contains("/declaration/consignmentShipment/goodsItems[sequenceNumber=\"2004\"]")
                .hasSize(4);

        Assertions.assertThat(response.getMatchReasons()).hasSize(4);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .hasSize(6)
                .containsOnly(
                        "Declaration field: 'Consignor City' was populated with a value in data domain: 'Consignor City'.  The value was: 'London'",
                        "Declaration field: 'Consignor City' did not match a value in data domain: 'Consignor City'.  The value was: 'London'",
                        "Goods Item (sequenceId=2001) field: 'Consignor City' was populated with a value in data domain: 'Consignor City'.  The value was: 'London'",
                        "Goods Item (sequenceId=2001) field: 'Consignor City' did not match a value in data domain: 'Consignor City'.  The value was: 'London'",
                        "Declaration field: 'Declaration Type' was equal to IM. The value was: 'IM'",
                        "Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'");

        response.getMatchReasons().stream().skip(1).forEach(mr -> {
            Assertions.assertThat(mr)
                    .hasSize(4)
                    .containsOnly(
                            "Declaration field: 'Consignor City' was populated with a value in data domain: 'Consignor City'.  The value was: 'London'",
                            "Declaration field: 'Consignor City' did not match a value in data domain: 'Consignor City'.  The value was: 'London'",
                            "Declaration field: 'Declaration Type' was equal to IM. The value was: 'IM'",
                            "Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'");
        });
    }

    private void createRule(List<Query> conditions) {
        CreateRuleModel model = createRuleModel();

        model.getQuery().get(0).setQuery( conditions );

        createAndRefreshRule(model);
    }

    private Query consignorCityDomainQuery(Operator operator, String value) {
        return Query.builder()
                .attribute(DomainAttribute.ConsignorCity.toString())
                .operator(operator.toString())
                .conditionType(ConditionType.normal.toString())
                .value(value)
                .build();
    }

    private Condition consignorCityHeaderCondition(String value) {
        return Condition.builder()
                .declarationParam(HeaderDeclarationParam.CONSIGNOR_ADDRESS_CITY)
                .declarationValue(value)
                .build();
    }

    private Condition consignorCityItemCondition(String value) {
        return Condition.builder()
                .declarationParam(GoodsItemDeclarationParam.CONSIGNORCITY_ITEM)
                .declarationValue(value)
                .build();
    }
}
