package TestCases;

import org.junit.Ignore;
import org.junit.Test;


public class ManualTestCases {

    @Ignore ("Manual Test Case")
    @Test
    public void WhenPendingRuleWithFutureStartDateCommitted_StatusSetToActiveWhenDateTimePassed() throws Throwable
    {
        //1. Create a Draft Rule with a Start Date Time of NOW + 5 mins
        //2. Commit Draft Rule
        //3. View Status of Rule in Rule List, Rule Summary, Rule Details --> Status = Draft
        //4. View Status of Rule in Rule List, Rule Summary, Rule Details --> Status = Pending

        //5. Wait for 5 minutes
        //
        //6. View Status of Rule in Rule List, Rule Summary, Rule Details --> Status = Active
    }


    @Ignore ("Manual Test Case")
    @Test
    public void WhenPendingRuleWithFutureStartDateCommitted_MatchingRouteFound() throws Throwable
    {
        //1. Create a Draft Rule with a Start Date Time of NOW + 5 mins
        //2. Commit Draft Rule
        //3. View Status of Rule in Rule List, Rule Summary, Rule Details --> Status = Draft
        //4. View Status of Rule in Rule List, Rule Summary, Rule Details --> Status = Pending
        //5. Synchronise Rules on Risking Service
        //6. Submit Declarations on Risking Service: DispatchCountry = DE  --> NO matching routes found
        //7. Wait for 5 minutes
        //
        //8. View Status of Rule in Rule List, Rule Summary, Rule Details --> Status = Active
        //9. Synchronise Rules on Risking Service
        //10. Submit Declarations on Risking Service: DispatchCountry = DE  --> 1 matching routes found
    }
}
