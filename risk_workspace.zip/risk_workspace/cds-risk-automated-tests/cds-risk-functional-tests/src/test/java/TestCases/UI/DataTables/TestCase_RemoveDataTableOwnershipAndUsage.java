package TestCases.UI.DataTables;


import API.DataForTests.*;
import API.DataService.CreateDataTable.CreateDataTableResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_DataTables;
import Categories_CDSRisk.CDS_Risk_UI_DataTables_2;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.DataForTests.TestDataTableModel;
import UI.Pages.DataManagement.CreateDataTable_Page;
import UI.Pages.DataManagement.DataTableManage_Page;
import UI.Pages.DataManagement.DataTableSummary_Page;
import UI.Pages.DataManagement.ListDataTable_Page;
import UI.Utils.Navigation;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import org.assertj.core.api.Assertions;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;
import java.util.Map;

import static API.Utils.LoginAsAPIUserAndCreateDataTableForLocation;
import static UI.DataForTests.TestDataTableModel.TableDetails.FreightTypeCategories.MARITIME;
import static UI.DataForTests.TestDataTableModel.TableDetails.FreightTypeCategories.NATIONAL;
import static UI.Utils.DataTables.NavigateToListMyDataTablesAndGetListOfDataTablesTitles;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_DataTables.class, CDS_Risk_UI_DataTables_2.class})
public class TestCase_RemoveDataTableOwnershipAndUsage extends BaseUIWebDriverTestCase {

    @Category({ChangeRequest.CR_2109.class,ChangeRequest.CR_3063.class})
    @Test
    public void WhenRuleManagerCreatesOpenDataTable_ManageUsageSectionIsNotAvailable(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateDataTable_Page createDataTable_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        TestDataTableModel.TableDetails tableDetails = UI.DataForTests.DataTables.DataTable_CommodityCodes_POO();
        tableDetails.tableType = "Open";

        createDataTable_page.populateDataTableFields(tableDetails);

        createDataTable_page.clickSaveAndPublishButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing1");

        DataTableSummary_Page dataTableSummary_page = createDataTable_page.clickViewDataTableButton();

        //Act
        dataTableSummary_page.accessTab.click();

        assertFalse("Expect Manage Use Location Button is not Displayed", dataTableSummary_page.manageUseLocationsBtnNotDisplayed.isDisplayed());
    }


    @Category({ChangeRequest.CR_2148.class,ChangeRequest.CR_3063.class})
    @Test
    public void WhenRuleManagerCreatesOpenDataTable_CanRemoveOwners(){

        //Arrange
        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        API.DataForTests.TestDataTableModel.TableDetails tableDetailsPOO = DataTables.DataTable_CommodityCodes_POO();
        tableDetailsPOO.tableType = "open";

        CreateDataTableResponse.PostResponse createDataTableResponse1 = LoginAsAPIUserAndCreateDataTableForLocation(UserDetailsPOO, tableDetailsPOO);

        tableDetailsPOO.manageTableLocationUuids.add(Locations.Location_POO_UID);
        tableDetailsPOO.manageTableLocationUuids.add(Locations.Location_BOS_UID);
        tableDetailsPOO.manageTableLocationUuids.add(Locations.Location_National_UID);
        tableDetailsPOO.uuid = createDataTableResponse1.uuid;
        tableDetailsPOO.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        tableDetailsPOO.uniqueId = createDataTableResponse1.uniqueId;

        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetailsPOO);

        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        NavigateToListMyDataTablesAndGetListOfDataTablesTitles(driver, "Owner");

        ListDataTable_Page listDataTable_page = new ListDataTable_Page(driver);

        DataTableSummary_Page dataTableSummary_page = listDataTable_page.clickTableSummaryForSpecifiedDataTableID(tableDetailsPOO.uniqueId);

        //Act
        dataTableSummary_page.accessTab.click();

        //Assert
       assertTrue("Manage for use button should be disabled", dataTableSummary_page.manageOwnersBtn.isDisplayed());
    }


    @Category({ChangeRequest.CR_2109.class, ChangeRequest.CR_2226.class,ChangeRequest.CR_3063.class})
    @Test
    public void WhenRuleManagerCreatedRestrictedDataTable_CanRemoveMultipleManageLocations(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateDataTable_Page createDataTable_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        TestDataTableModel.TableDetails tableDetails = UI.DataForTests.DataTables.DataTable_CommodityCodes_POO();
        tableDetails.tableType = "Restricted";

        createDataTable_page.populateDataTableFields(tableDetails);

        createDataTable_page.clickSaveAndPublishButton();
        createDataTable_page.waitForAngularRequestsToFinish();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing1");

        DataTableSummary_Page dataTableSummary_page = createDataTable_page.clickViewDataTableButton();
        dataTableSummary_page.accessTab.click();
        dataTableSummary_page.waitForAngularRequestsToFinish();

        //Act
        DataTableManage_Page manage_page = new DataTableManage_Page(driver);
        manage_page.clickManageOwnersButton();
        manage_page.waitForAngularRequestsToFinish();

        Map<TestDataTableModel.TableDetails.FreightTypeCategories, List<String>> freightTypeCategoriesListMap =
                new ImmutableMap.Builder<TestDataTableModel.TableDetails.FreightTypeCategories, List<String>>()
                        .put(NATIONAL, Lists.newArrayList("All Locations"))
                        .put(MARITIME, Lists.newArrayList("WAT", "Avonmouth", "col"))
                        .build();

        manage_page.SearchForFreightLocationAndSelectIt(freightTypeCategoriesListMap);
        manage_page.clickSaveAndShareForOwn();
        manage_page.waitForAngularRequestsToFinish();

        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");
        manage_page.waitForAngularRequestsToFinish();
        manage_page.scrollToViewTheElement(manage_page.manageOwnersBtn);
        manage_page.manageOwnersBtn.click();
        manage_page.waitForAngularRequestsToFinish();

        manage_page.removeMultipleManageLocations();
        manage_page.clickSaveAndShareForOwn();
        manage_page.waitForAngularRequestsToFinish();
        dialog_confirm.EnterReasonAndCloseDialogBox("Removing manage test");

        //Assert
        Assertions.assertThat(dataTableSummary_page.manageOwnersLocationsTab.size() == 1);
        Assertions.assertThat(dataTableSummary_page.manageOwnersLocationsTab.get(0).getText().contains("POO - Poole"));
    }

    @Category({ChangeRequest.CR_2109.class, ChangeRequest.CR_2226.class,ChangeRequest.CR_3063.class})
    @Test
    public void WhenRuleManagerCreatesSensitiveDataTable_CanRemoveMultipleUseLocations(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateDataTable_Page createDataTable_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        TestDataTableModel.TableDetails tableDetails = UI.DataForTests.DataTables.DataTable_FreeText_NAT();
        tableDetails.tableType = "Sensitive";

        createDataTable_page.populateDataTableFields(tableDetails);

        createDataTable_page.clickSaveAndPublishButton();
        createDataTable_page.waitForAngularRequestsToFinish();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing1");

        DataTableSummary_Page dataTableSummary_page = createDataTable_page.clickViewDataTableButton();
        dataTableSummary_page.accessTab.click();

        //Act
        DataTableManage_Page manage_page = new DataTableManage_Page(driver);
        manage_page.clickManageUseLocationsButton();

        Map<TestDataTableModel.TableDetails.FreightTypeCategories, List<String>> freightTypeCategoriesListMap =
                new ImmutableMap.Builder<TestDataTableModel.TableDetails.FreightTypeCategories, List<String>>()
                        .put(NATIONAL, Lists.newArrayList("All Locations"))
                        .put(MARITIME, Lists.newArrayList("WAT", "Avonmouth", "col"))
                        .build();

        manage_page.SearchForFreightLocationAndSelectIt(freightTypeCategoriesListMap);
        manage_page.clickSaveAndShareForOwn();

        dialog_confirm.EnterReasonAndCloseDialogBox("Removing manage test");

        manage_page.clickManageUseLocationsButton();
        manage_page.removeMultipleManageLocations();
        manage_page.clickSaveAndShareForOwn();
        dialog_confirm.EnterReasonAndCloseDialogBox("Removing manage test");

        List<String> useLocationsList = dataTableSummary_page.getListOfManageUserLocations();

        //Assert
        Assertions.assertThat(dataTableSummary_page.manageOwnersLocationsTab.size() == 1);
        Assertions.assertThat(dataTableSummary_page.manageOwnersLocationsTab.get(0).getText().contains("National Office"));
    }

    @Category({ChangeRequest.CR_2135.class,ChangeRequest.CR_3063.class})
    @Test
    public void WhenRuleManagerLoggedIn_CanRemoveOwnershipForALocation(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateDataTable_Page createDataTable_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        TestDataTableModel.TableDetails tableDetails = UI.DataForTests.DataTables.DataTable_CommodityCodes_POO();
        tableDetails.tableType = "Open";

        createDataTable_page.populateDataTableFields(tableDetails);

        createDataTable_page.clickSaveAndPublishButton();
        createDataTable_page.waitForAngularRequestsToFinish();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing1");
        createDataTable_page.waitForAngularRequestsToFinish();

        DataTableSummary_Page dataTableSummary_page = createDataTable_page.clickViewDataTableButton();
        createDataTable_page.waitForAngularRequestsToFinish();
        dataTableSummary_page.accessTab.click();
        dataTableSummary_page.waitForAngularRequestsToFinish();

        //Act
        DataTableManage_Page manage_page = new DataTableManage_Page(driver);
        manage_page.clickManageOwnersButton();
        manage_page.waitForAngularRequestsToFinish();

        Map<TestDataTableModel.TableDetails.FreightTypeCategories, List<String>> freightTypeCategoriesListMap =
                new ImmutableMap.Builder<TestDataTableModel.TableDetails.FreightTypeCategories, List<String>>()
                        .put(NATIONAL, Lists.newArrayList("All Locations"))
                        .put(MARITIME, Lists.newArrayList("WAT"))
                        .build();

        manage_page.SearchForFreightLocationAndSelectIt(freightTypeCategoriesListMap);
        manage_page.clickSaveAndShareForOwn();
        manage_page.waitForAngularRequestsToFinish();

        dialog_confirm.EnterReasonAndCloseDialogBox("Removing manage test");
        manage_page.waitForAngularRequestsToFinish();

        manage_page.clickManageOwnersButton();
        manage_page.waitForAngularRequestsToFinish();

        int locationsToRemove = 0;
        manage_page.selectLocationsToRemove(locationsToRemove);
        manage_page.clickSaveAndShareForUse();
        manage_page.waitForAngularRequestsToFinish();
        dialog_confirm.EnterReasonAndCloseDialogBox("Removing manage test");

        List<String> ownLocationsList = dataTableSummary_page.getListOfManageOwnerLocations();

        Assertions.assertThat(dataTableSummary_page.manageOwnersLocationsTab.size() == 2);
        Assertions.assertThat(dataTableSummary_page.manageOwnersLocationsTab.get(0).getText().contains("POO - Poole"));
    }

    @Category({ChangeRequest.CR_2148.class,ChangeRequest.CR_3063.class})
    @Test @Ignore("this test will not work until bug is fixed - CR-2501")
    public void WhenRuleManagerRemovesOwnerForDataTable_RemovedOwnerHasNoAccessToDataTable(){

        //Arrange
        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerNational();
        API.DataForTests.TestDataTableModel.TableDetails tableDetailsPOO = DataTables.DataTable_CommodityCodes_NAT();
        tableDetailsPOO.tableType = "Restricted";

        CreateDataTableResponse.PostResponse createDataTableResponse1 = LoginAsAPIUserAndCreateDataTableForLocation(UserDetailsPOO, tableDetailsPOO);

        tableDetailsPOO.manageTableLocationUuids.add(Locations.Location_POO_UID);
        tableDetailsPOO.uuid = createDataTableResponse1.uuid;
        tableDetailsPOO.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        tableDetailsPOO.uniqueId = createDataTableResponse1.uniqueId;

        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetailsPOO);

        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        NavigateToListMyDataTablesAndGetListOfDataTablesTitles(driver, "User");

        ListDataTable_Page listDataTable_page = new ListDataTable_Page(driver);

        DataTableSummary_Page dataTableSummary_page = listDataTable_page.clickTableSummaryForSpecifiedDataTableID(tableDetailsPOO.uniqueId);

        //Act
        dataTableSummary_page.accessTab.click();

        DataTableManage_Page manage_page = new DataTableManage_Page(driver);
        manage_page.clickManageOwnersButton();
        manage_page.removeMultipleManageLocations();
        manage_page.clickSaveAndShareForOwn();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Removing manage test");

        //Assert
        assertTrue("Manage for use button should be disabled", dataTableSummary_page.manageOwnersBtn.isDisplayed());
    }
}
