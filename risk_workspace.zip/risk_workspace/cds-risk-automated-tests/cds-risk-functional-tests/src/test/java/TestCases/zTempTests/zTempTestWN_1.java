package TestCases.zTempTests;

import TestCases.BaseSpringBootTestCase;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import static io.restassured.RestAssured.given;

@Slf4j
public class zTempTestWN_1 extends BaseSpringBootTestCase {

    @Test
    public void TestSpringEnvironment(){

        log.debug("Environment Default: " + Arrays.asList(springEnvironment.getActiveProfiles()));
        log.debug("UI HomePAge: " + testConfig.getUrls().getRiskUi().getHomepage());

        log.debug("Database Rules: " + testConfig.getDb().getRules().getUrl());
        log.debug("Database UserName: " + testConfig.getDb().getRules().getUsername());
        log.debug("Database Password: " + testConfig.getDb().getRules().getPassword());

        log.debug("Database User: " + testConfig.getDb().getUsers().getUrl());
        log.debug("Database UserName: " + testConfig.getDb().getUsers().getUsername());
        log.debug("Database Password: " + testConfig.getDb().getUsers().getPassword());

        log.debug("Database Data: " + testConfig.getDb().getData().getUrl());
        log.debug("Database UserName: " + testConfig.getDb().getData().getUsername());
        log.debug("Database Password: " + testConfig.getDb().getData().getPassword());

        log.debug("Database Locations: " + testConfig.getDb().getLocations().getUrl());
        log.debug("Database UserName: " + testConfig.getDb().getLocations().getUsername());
        log.debug("Database Password: " + testConfig.getDb().getLocations().getPassword());

    }

    @Test
    public void TestRegExpression(){

        SimpleDateFormat date = new SimpleDateFormat("yy");
        String yy =  date.format(new Date());

        String ruleIDFormat = "NAT " + "ADD" + " \\d\\d\\d\\d " + yy;

        log.debug("Rule ID format: " + ruleIDFormat);

        String ruleIDToTest = "NAT ADD 0001 17";
        Assertions.assertThat(ruleIDToTest).containsPattern(ruleIDFormat);
    }

    @Test
    public void TestRiskingLogParsing() {

        String descriptionToSearchFor = "rule \"ta_NatDraftRule 9604f\"";
        GetRiskingServiceLogBasedOnDescription(descriptionToSearchFor);
    }

    public void GetRiskingServiceLogBasedOnDescription(String descriptionToSearchFor){

        String url = "http://10.102.81.58:12604/logfile";
        Response response = given().when().get(url);

        if (response.getStatusCode() == 200) {

            log.info("Risking Service LogFile for: " + url);

            String fullLog = response.getBody().asString();

            int iStartOfTest = fullLog.indexOf(descriptionToSearchFor);

            if (iStartOfTest > 0)
            {
                String logForTest = fullLog.substring(iStartOfTest);
                log.info(logForTest);
            }
            else {
                log.info("log details for rule: " + descriptionToSearchFor + " NOT Found.");
            }
        }

    }


    }
