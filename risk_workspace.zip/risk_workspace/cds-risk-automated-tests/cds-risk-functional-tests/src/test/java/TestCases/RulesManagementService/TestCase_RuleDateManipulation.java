package TestCases.RulesManagementService;


import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.Utils.Rules;
import API.RulesManagementService.ViewRuleVersion.ViewRuleVersionResponse;
import Categories_CDSRisk.CDS_RM_RulesGeneral;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import FunctionsLibrary.DateTime;
import TestCases.BaseWebAPITestCase;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import static API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule;
import static org.junit.Assert.assertEquals;


@Category({Rules_Management.class, CDS_RM_RulesGeneral.class})
public class TestCase_RuleDateManipulation extends BaseWebAPITestCase {

    @Test //rv0,1 //done
    @Category(ChangeRequest.CR_2191.class)
    public void WhenCommittedRuleWithStartAndEndDateModifiedWithNewDatesInTheFuture_NoChangesMadeToTheExistingRuleDates() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsV1 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsV1.startDateTime = DateTime.AdjustLocalDateTimeNowByXDays(1, DateTime.DateTimeUTCZ);
        ruleDetailsV1.endDateTime = DateTime.AdjustLocalDateTimeNowByXDays(2, DateTime.DateTimeUTCZ);
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetailsV1);

        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetailsV2.startDateTime = DateTime.AdjustLocalDateTimeNowByXDays(10, DateTime.DateTimeUTCZ);
        ruleDetailsV2.endDateTime = DateTime.AdjustLocalDateTimeNowByXDays(15, DateTime.DateTimeUTCZ);
        ruleDetailsV2.uniqueID = commitResponse.uniqueId;
        ruleDetailsV2.version = 2;

        //Act
        Rules.EditRuleAndGetResponseObject(ruleDetailsV2);

        Rules.UpdateStatusOfRule(ruleDetailsV2, RuleVersionActions.commit);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV2 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV2.uniqueID, 2);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV1 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV1.uniqueID, 1);

        //Assert
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), viewRuleVersionResponseObjectV2.status);
        assertEquals(ruleDetailsV2.startDate(), viewRuleVersionResponseObjectV2.startDate());
        assertEquals(ruleDetailsV2.endDate(), viewRuleVersionResponseObjectV2.endDate());

        assertEquals(TestEnumerators.RuleStatus.committed.toString(), viewRuleVersionResponseObjectV1.status);
        assertEquals(ruleDetailsV1.startDate(), viewRuleVersionResponseObjectV1.startDate());
        assertEquals(ruleDetailsV1.endDate(), viewRuleVersionResponseObjectV1.endDate());
    }

    @Test //rv2,3,4
    @Category(ChangeRequest.CR_2191.class)
    public void WhenCommittedRuleUpdatedWithNewStartDateAfterOriginal_OriginalEndDateIsSetAsStartDateOfNewVersion() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsV1 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsV1.startDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(2, DateTime.DateTimeUTCZ);
        ruleDetailsV1.endDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(30, DateTime.DateTimeUTCZ);
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetailsV1);

        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetailsV2.startDateTime = DateTime.AdjustCustomRuleDateTimeByXMinutes(ruleDetailsV1.startDateTime, 5, DateTime.DateTimeUTCZ);
        ruleDetailsV2.endDateTime = DateTime.AdjustCustomRuleDateTimeByXMinutes(ruleDetailsV1.endDateTime, 5, DateTime.DateTimeUTCZ);
        ruleDetailsV2.uniqueID = commitResponse.uniqueId;
        ruleDetailsV2.version = 2;

        //Act
        Rules.EditRuleAndGetResponseObject(ruleDetailsV2);
        Rules.UpdateStatusOfRule(ruleDetailsV2, RuleVersionActions.commit);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV1 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV1.uniqueID, 1);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV2 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV2.uniqueID, 2);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV3 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV1.uniqueID, 3);

        //Assert

        // v1 cancelled
        assertEquals(TestEnumerators.RuleStatus.cancelling.toString(), viewRuleVersionResponseObjectV1.status);
        assertEquals(ruleDetailsV1.startDate(), viewRuleVersionResponseObjectV1.startDate());
        assertEquals(ruleDetailsV1.endDate(), viewRuleVersionResponseObjectV1.endDate()) ;

        // v2 created
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), viewRuleVersionResponseObjectV2.status);
        assertEquals(ruleDetailsV2.startDate(), viewRuleVersionResponseObjectV2.startDate());
        assertEquals(ruleDetailsV2.endDate(), viewRuleVersionResponseObjectV2.endDate());

        // v1 cloned into v3 with new start date
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), viewRuleVersionResponseObjectV3.status);
        assertEquals(ruleDetailsV1.startDate(), viewRuleVersionResponseObjectV3.startDate());
        assertEquals(ruleDetailsV2.startDate(), viewRuleVersionResponseObjectV3.endDate());

    }

    @Test //rv6,7,8
    @Category(ChangeRequest.CR_2191.class)
    public void WhenCommittedARuleUpdatedAndNewVersionDatesConsumesOriginalDates_OldVersionStatusIsCancelled() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsV1 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsV1.startDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(5, DateTime.DateTimeUTCZ);
        ruleDetailsV1.endDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(50, DateTime.DateTimeUTCZ);
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetailsV1);

        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetailsV2.startDateTime = DateTime.AdjustCustomRuleDateTimeByXMinutes(ruleDetailsV1.startDateTime, -10, DateTime.DateTimeUTCZ);
        ruleDetailsV2.endDateTime = DateTime.AdjustCustomRuleDateTimeByXMinutes(ruleDetailsV1.endDateTime, 10, DateTime.DateTimeUTCZ);
        ruleDetailsV2.uniqueID = commitResponse.uniqueId;
        ruleDetailsV2.version = 2;

        //Act
        Rules.EditRuleAndGetResponseObject(ruleDetailsV2);
        Rules.UpdateStatusOfRule(ruleDetailsV2, RuleVersionActions.commit);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV2 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV2.uniqueID, 2);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV1 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV1.uniqueID, 1);

        //Assert
        assertEquals(TestEnumerators.RuleStatus.cancelling.toString(), viewRuleVersionResponseObjectV1.status);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), viewRuleVersionResponseObjectV2.status);
        assertEquals(ruleDetailsV2.startDate(), viewRuleVersionResponseObjectV2.startDate());
        assertEquals(ruleDetailsV2.endDate(), viewRuleVersionResponseObjectV2.endDate());
        assertEquals(ruleDetailsV1.startDate(), viewRuleVersionResponseObjectV1.startDate());
        assertEquals(ruleDetailsV1.endDate(), viewRuleVersionResponseObjectV1.endDate());
    }

    @Test //rv 9b, 12b
    @Category(ChangeRequest.CR_2191.class)
    public void WhenACommittedRuleUpdatedWithSameStartDateAndEndDateLaterThanExisting_StartOfExistingBecomesEndOfNew() throws Throwable
    {

        //Arrange
        TestRuleModel.RuleDetails ruleDetailsV1 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsV1.startDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(10, DateTime.DateTimeUTCZ);
        ruleDetailsV1.endDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(50000, DateTime.DateTimeUTCZ);
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetailsV1);

        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetailsV2.startDateTime = ruleDetailsV1.startDateTime;
        ruleDetailsV2.endDateTime = DateTime.AdjustCustomRuleDateTimeByXMinutes(ruleDetailsV1.endDateTime, -500, DateTime.DateTimeUTCZ);
        ruleDetailsV2.uniqueID = commitResponse.uniqueId;
        ruleDetailsV2.version = 2;

        //Act
        Rules.EditRuleAndGetResponseObject(ruleDetailsV2);

        Rules.UpdateStatusOfRule(ruleDetailsV2, RuleVersionActions.commit);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV3 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV2.uniqueID, 3);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV2 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV2.uniqueID, 2);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV1 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV1.uniqueID, 1);

        //Assert
        // v1 cancelled
        assertEquals(TestEnumerators.RuleStatus.cancelling.toString(), viewRuleVersionResponseObjectV1.status);
        assertEquals(ruleDetailsV1.startDate(), viewRuleVersionResponseObjectV1.startDate());
        assertEquals(ruleDetailsV1.endDate(), viewRuleVersionResponseObjectV1.endDate()) ;

        // v2 created
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), viewRuleVersionResponseObjectV2.status);
        assertEquals(ruleDetailsV2.startDate(), viewRuleVersionResponseObjectV2.startDate());
        assertEquals(ruleDetailsV2.endDate(), viewRuleVersionResponseObjectV2.endDate());

        // v1 cloned into v3 with new start date
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), viewRuleVersionResponseObjectV3.status);
        assertEquals(ruleDetailsV2.endDate(), viewRuleVersionResponseObjectV3.startDate());
        assertEquals(ruleDetailsV1.endDate(), viewRuleVersionResponseObjectV3.endDate());
    }

    @Test //rv 10,11
    @Category(ChangeRequest.CR_2191.class)
    public void WhenACommittedRuleUpdatedWithNewStartDateBeforeTheOriginalRuleDates_NoChangesHappen() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsV1 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsV1.startDateTime = DateTime.AdjustLocalDateTimeNowByXDays(5, DateTime.DateTimeUTCZ);
        ruleDetailsV1.endDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(10, DateTime.DateTimeUTCZ);
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetailsV1);

        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetailsV2.startDateTime = DateTime.AdjustLocalDateTimeNowByXDays(3, DateTime.DateTimeUTCZ);
        ruleDetailsV2.endDateTime = DateTime.AdjustLocalDateTimeNowByXDays(4, DateTime.DateTimeUTCZ);
        ruleDetailsV2.uniqueID = commitResponse.uniqueId;

        //Act
        Rules.EditRuleAndGetResponseObject(ruleDetailsV2);

        Rules.UpdateStatusOfRule(ruleDetailsV2, RuleVersionActions.commit);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV2 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV2.uniqueID, 2);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV1 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV1.uniqueID, 1);

        //Assert
        assertEquals(ruleDetailsV1.startDate() , viewRuleVersionResponseObjectV1.startDate());
        assertEquals(ruleDetailsV2.endDate() , viewRuleVersionResponseObjectV2.endDate());
    }

    @Test //rv6,7,8
    @Category(ChangeRequest.CR_2191.class)
    public void WhenALiveRuleUpdatedWithNewStartDateFallsWithInTheOriginalDates_OldVersionStatusIsCancelled() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsV1 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsV1.startDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(50, DateTime.DateTimeUTCZ);
        ruleDetailsV1.endDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(1000, DateTime.DateTimeUTCZ);
        EditRuleVersionResponse.PutResponse commitResponse = CreateCommittedRule(ruleDetailsV1);

        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsV2.startDateTime = DateTime.AdjustCustomRuleDateTimeByXMinutes(ruleDetailsV1.startDateTime, -5, DateTime.DateTimeUTCZ);
        ruleDetailsV2.endDateTime = DateTime.AdjustLocalDateTimeNowByXDays(2, DateTime.DateTimeUTCZ);
        ruleDetailsV2.uniqueID = commitResponse.uniqueId;
        ruleDetailsV2.version = 2;

        //Act
        Rules.EditRuleAndGetResponseObject(ruleDetailsV2);

        Rules.UpdateStatusOfRule(ruleDetailsV2, RuleVersionActions.commit);

        publishAndWait(5000);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV2 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV2.uniqueID, 2);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV1 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV1.uniqueID, 1);

        //Assert
        assertEquals(TestEnumerators.RuleStatus.cancelled.toString(), viewRuleVersionResponseObjectV1.status);
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), viewRuleVersionResponseObjectV2.status);
        assertEquals(ruleDetailsV2.startDate(), viewRuleVersionResponseObjectV2.startDate());
        assertEquals(ruleDetailsV2.endDate(), viewRuleVersionResponseObjectV2.endDate());
    }

    @Test //rv2,3,4
    @Category(ChangeRequest.CR_2191.class)
    public void WhenALiveRuleUpdatedWithNewStartDateAfterOriginal_EndOfFirstSetToStartOfNew() throws Throwable
    {

        //Arrange
        TestRuleModel.RuleDetails ruleDetailsV1 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsV1.startDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(10, DateTime.DateTimeUTCZ);
        ruleDetailsV1.endDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(40, DateTime.DateTimeUTCZ);
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetailsV1);

        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetailsV2.startDateTime = DateTime.AdjustCustomRuleDateTimeByXMinutes(ruleDetailsV1.startDateTime, 5, DateTime.DateTimeUTCZ);
        ruleDetailsV2.endDateTime = DateTime.AdjustCustomRuleDateTimeByXMinutes(ruleDetailsV1.endDateTime, 5, DateTime.DateTimeUTCZ);
        ruleDetailsV2.uniqueID = commitResponse.uniqueId;
        ruleDetailsV2.version = 2;

        //Act
        Rules.EditRuleAndGetResponseObject(ruleDetailsV2);

        Rules.UpdateStatusOfRule(ruleDetailsV2, RuleVersionActions.commit);

        publishAndWait(5000);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV3 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV2.uniqueID, 3);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV2 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV2.uniqueID, 2);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV1 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV1.uniqueID, 1);

        //Assert
        // v1 cancelled
        assertEquals(TestEnumerators.RuleStatus.cancelled.toString(), viewRuleVersionResponseObjectV1.status);
        assertEquals(ruleDetailsV1.startDate(), viewRuleVersionResponseObjectV1.startDate() );
        assertEquals(ruleDetailsV1.endDate(), viewRuleVersionResponseObjectV1.endDate());

        // v2 created
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), viewRuleVersionResponseObjectV2.status);
        assertEquals(ruleDetailsV2.startDate(), viewRuleVersionResponseObjectV2.startDate());
        assertEquals(ruleDetailsV2.endDate(), viewRuleVersionResponseObjectV2.endDate());

        // v1 cloned into v3 with new end date
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), viewRuleVersionResponseObjectV3.status);
        assertEquals(ruleDetailsV1.startDate(), viewRuleVersionResponseObjectV3.startDate() );
        assertEquals(ruleDetailsV2.startDate(), viewRuleVersionResponseObjectV3.endDate());

    }

    @Test //rv2,3,4
    @Category(ChangeRequest.CR_2191.class)
    public void WhenALiveRuleUpdatedWithNewStartDateBeforeExistingEndDate_EndDateOfFirstSetToStartOfNewVersion() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsV1 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsV1.startDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(10, DateTime.DateTimeUTCZ);
        ruleDetailsV1.endDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(40, DateTime.DateTimeUTCZ);
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetailsV1);

        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetailsV2.startDateTime = DateTime.AdjustCustomRuleDateTimeByXMinutes(ruleDetailsV1.startDateTime, 5, DateTime.DateTimeUTCZ);
        ruleDetailsV2.endDateTime = DateTime.AdjustCustomRuleDateTimeByXMinutes(ruleDetailsV1.endDateTime, 5, DateTime.DateTimeUTCZ);
        ruleDetailsV2.uniqueID = commitResponse.uniqueId;
        ruleDetailsV2.version = 2;

        //Act
        Rules.EditRuleAndGetResponseObject(ruleDetailsV2);

        Rules.UpdateStatusOfRule(ruleDetailsV2, RuleVersionActions.commit);

        publishAndWait(5000);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV3 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV2.uniqueID, 3);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV2 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV2.uniqueID, 2);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObjectV1 = Rules.GetRuleDByUIDAndVersion(ruleDetailsV1.uniqueID, 1);

        //Assert
        assertEquals(TestEnumerators.RuleStatus.cancelled.toString(), viewRuleVersionResponseObjectV1.status);
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), viewRuleVersionResponseObjectV2.status);
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), viewRuleVersionResponseObjectV3.status);

        assertEquals(viewRuleVersionResponseObjectV1.endDate(), ruleDetailsV1.endDate());
        assertEquals(viewRuleVersionResponseObjectV3.endDate(), viewRuleVersionResponseObjectV2.startDate());
    }
}