package TestCases.RiskingService;


import API.DataForTests.Conditions;
import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestRuleModel;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service;
import TestCases.BaseWebAPITestCase;
import junitparams.JUnitParamsRunner;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeoutException;

import static API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody;
import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
@Category(Risking_Service.class)
@RunWith(JUnitParamsRunner.class)
public class TestCase_RiskingItemCollections extends BaseWebAPITestCase {

    private static TestRuleModel.RuleDetails ruleDetails;
    private static DeclarationResponse declarationResponse;

    @Before
    public void setup() throws IOException, TimeoutException {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
    }


    private TestRuleModel.RuleDetails CreateCommittedRuleWithConditionAndPublish(TestRuleModel.RuleDetails.Condition condition) {
        ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).operator = "and";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);
        ruleDetails.ruleOutputs.actionType = "1";
        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(6000);
        return ruleDetails;
    }

    private DeclarationResponse CreateDeclarationXMLSubmitAndGetResponse(TestDeclarationModel.Declaration declaration) {
        return CreateDeclarationXMLSubmitAndGetResponse(declaration, declarationSupport.getDefaultDeclarationTemplate());
    }

    private DeclarationResponse CreateDeclarationXMLSubmitAndGetResponse(TestDeclarationModel.Declaration declaration, String template) {
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        String declarationRequest = createDeclarationXMLBody(declaration, template);
        queue.send(declarationRequest);
        declarationResponse = new DeclarationResponse(queue.receive());
        log.info(declarationResponse.toString());
        return declarationResponse;
    }


    private void AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(TestDeclarationModel.Declaration declaration) {

        String returnedControlType = declarationResponse.getControlType();
        assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3315.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithAdditionalCommodityCodeNATItemCollection_RouteReturned() {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.natClassifications_IdItemCollection();
        condition.operator = "st";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.natClassificationId = "AB44";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    @Test
    @Category({ChangeRequest.CR_3315.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithAdditionalCommodityCodeTaricItemCollection_RouteReturned() {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.taricClassifications_IdItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.taricClassificationId = "6100";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    @Test
    @Category({ChangeRequest.CR_3318.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithAdditionalActorIdItemCollection_RouteReturned() {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.additionalActorId_ItemCollections("D34");
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalActor_Id_Item = "D34";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    @Test
    @Category({ChangeRequest.CR_3318.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithVatDeclaringPartyRoleItemCollection_RouteReturned() {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.vatDeclaringPartyRole_ItemCollections("GTY");
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.vatDeclaringParty_Role_Item = "GTY";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    @Test
    @Category({ChangeRequest.CR_2770.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithAdditionalInfoCodeItemCollection_RouteReturned() {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.additionalInfoCode_ItemCollections();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalInformation_Code_Item = "100456";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    @Test
    @Category({ChangeRequest.CR_2770.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithAdditionalInfoTextItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.additionalInfoText_ItemCollections();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalInformation_Text_Item = "duty";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_2769.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDocumentTypeItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.additionalDocumentsType_ItemCollections();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalDocuments_Type_Item = "doctyp";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_2951.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithPackageCountItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.packageCount_ItemCollections();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.packageCount_ItemCollections();
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    @Test
    @Category({ChangeRequest.CR_2952.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithValuationAdjustmentsCodeItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.valuationAdjustments_CodeItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.valuationAdjustments_CodeItemCollection();
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_2952.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithContainersIdItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.containers_IdItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.containers_IdItemCollection();
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_2955.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDeclaredDutyTaxFeesBaseAmountItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.declaredDutyTaxFees_BaseAmountItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.declaredDutyTaxFees_BaseAmountItemCollection();
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    @Test
    @Category({ChangeRequest.CR_2955.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDeclaredDutyTaxFees_BaseQuantityItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.declaredDutyTaxFees_BaseQuantityItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.declaredDutyTaxFees_BaseQuantityItemCollection();
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    @Test
    @Category({ChangeRequest.CR_2955.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDeclaredDutyTaxFees_PaymentMethodItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.declaredDutyTaxFees_PaymentMethodItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.declaredDutyTaxFees_PaymentMethodItemCollection();
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    @Test
    @Category({ChangeRequest.CR_2955.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDeclaredDutyTaxFeesPercentageAdjustmentItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.declaredDutyTaxFees_PercentageAdjustmentItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.declaredDutyTaxFees_PercentageAdjustmentItemCollection();
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_2955.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDeclaredDutyTaxFeesPreferenceCodeItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.declaredDutyTaxFees_PreferenceCodeItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.declaredDutyTaxFees_PreferenceCodeItemCollection();
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    @Test
    @Category({ChangeRequest.CR_2955.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDeclaredDutyTaxFees_QuotaCodeItemCollectionCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.declaredDutyTaxFees_QuotaCodeItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.declaredDutyTaxFees_QuotaCodeItemCollection();
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_2955.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDeclaredDutyTaxFees_TaxAmountItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.declaredDutyTaxFees_TaxAmountItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.declaredDutyTaxFees_TaxAmountItemCollection();
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_2955.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDeclaredDutyTaxFees_TaxRevenueItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.declaredDutyTaxFees_TaxRevenueItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.declaredDutyTaxFees_TaxRevenueItemCollection();
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_2955.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDeclaredDutyTaxFees_TaxTypeItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.declaredDutyTaxFees_TaxTypeItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.declaredDutyTaxFees_TaxTypeItemCollection();
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_2955.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDeclaredDutyTaxFees_VatValueItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.declaredDutyTaxFees_VatValueItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.declaredDutyTaxFees_VatValueItemCollection();
        declaration.declaredDutyTaxFees_TaxTypeItem = "B00";

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_2863.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithAdditionalInformationLanguageItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.additionalInformation_LanguageItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.additionalInformation_LanguageItemCollection();

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_2863.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithAdditionalDocumentsIdItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.additionalDocuments_IdItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.additionalDocuments_IdItemCollection();

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    @Test
    @Category({ChangeRequest.CR_2863.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithAdditionalDocumentsQuantityItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.additionalDocuments_QuantityItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.additionalDocuments_QuantityItemCollection();

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    @Test
    @Category({ChangeRequest.CR_3322.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithAdditionalDocumentsStatusItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.additionalDocuments_StatusItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.additionalDocuments_StatusItemCollection();

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }



    @Test
    @Category({ChangeRequest.CR_2863.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithPreviousDocumentsClassItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.previousDocuments_ClassItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.previousDocuments_ClassItemCollection();

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_2863.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithPreviousDocumentsIdItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.previousDocuments_IdItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.previousDocuments_IdItemCollection();

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    @Test
    @Category({ChangeRequest.CR_2863.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithPreviousDocuments_TypeItemCollection_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.previousDocuments_TypeItemCollection();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.previousDocuments_TypeItemCollection();

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_2770.class})
    public void WhenDeclarationSubmittedDoesNotMatchWithAdditionalInfoItemCollectionInRule_RouteNotReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.additionalInfoText_ItemCollections();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalInformation_Text_Item = "BOXES";

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).isEmpty();
    }


    @Test
    @Category({ChangeRequest.CR_2770.class})
    public void WhenDeclarationSubmittedMatchesOnlyInformationCodeAndNotTextInRule_RouteNotReturned() throws Throwable {

        //Arrange

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        TestRuleModel.RuleDetails.Condition conditionItemCollectionCode = Conditions.additionalInfoCode_ItemCollections();
        conditionItemCollectionCode.operator = "eq";
        TestRuleModel.RuleDetails.Condition conditionItemCollectionText = Conditions.additionalInfoText_ItemCollections();
        conditionItemCollectionText.operator = "eq";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(conditionItemCollectionCode);
        ruleDetails.queryConditions.get(0).conditions.add(conditionItemCollectionText);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(6000);

        //Act
        //Rule is fired as the declaration starts with 100456
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalInformation_Code_Item = "100456";
        declaration.additionalInformation_Text_Item = "information";

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).isEmpty();
    }


    @Test
    @Category({ChangeRequest.CR_2770.class})
    public void WhenDeclarationSubmittedMatchesBothInformationCodeAndTextInRule_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        TestRuleModel.RuleDetails.Condition conditionItemCollectionCode = Conditions.additionalInfoCode_ItemCollections();
        conditionItemCollectionCode.operator = "eq";
        TestRuleModel.RuleDetails.Condition conditionItemCollectionText = Conditions.additionalInfoText_ItemCollections();
        conditionItemCollectionText.operator = "eq";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(conditionItemCollectionCode);
        ruleDetails.queryConditions.get(0).conditions.add(conditionItemCollectionText);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(6000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalInformation_Code_Item = "100456";
        declaration.additionalInformation_Text_Item = "duty";

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    @Test
    @Category({ChangeRequest.CR_2770.class})
    public void WhenAtLeastOneCollectionInDeclarationMatchesInformationCodeAndTextInRule_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        TestRuleModel.RuleDetails.Condition conditionItemCollectionCode = Conditions.additionalInfoCode_ItemCollections();
        conditionItemCollectionCode.operator = "eq";
        TestRuleModel.RuleDetails.Condition conditionItemCollectionText = Conditions.additionalInfoText_ItemCollections();
        conditionItemCollectionText.operator = "eq";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(conditionItemCollectionCode);
        ruleDetails.queryConditions.get(0).conditions.add(conditionItemCollectionText);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(6000);

        //Act
        //Rule is fired as the declaration starts with 100456
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalInformation_Code_Item = "8788778";
        declaration.additionalInformation_Text_Item = "notMatching";
        declaration.additionalInformation_Code_Item1 = "100456";
        declaration.additionalInformation_Text_Item1 = "duty";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration, declarationSupport.getDefaultDeclarationTemplate());

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    @Test
    @Category({ChangeRequest.CR_2770.class})
    public void WhenInfoCodeAndTextInDeclarationDoesNotMatchAnySingleCollectionInRule_RouteNotReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        TestRuleModel.RuleDetails.Condition conditionItemCollectionCode = Conditions.additionalInfoCode_ItemCollections();
        conditionItemCollectionCode.operator = "eq";
        TestRuleModel.RuleDetails.Condition conditionItemCollectionText = Conditions.additionalInfoText_ItemCollections();
        conditionItemCollectionText.operator = "eq";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(conditionItemCollectionCode);
        ruleDetails.queryConditions.get(0).conditions.add(conditionItemCollectionText);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(6000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.additionalInformation_Code_Item = "8788778";
        declaration.additionalInformation_Text_Item = "duty";
        declaration.additionalInformation_Code_Item1 = "100456";
        declaration.additionalInformation_Text_Item1 = "notmatching";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration, declarationSupport.getTemplateWithMultipleAdditionalInfo());

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).isEmpty();
    }

    @Test
    @Category({ChangeRequest.CR_2770.class})
    public void WhenAllCollectionInDeclarationMatchesCollectionsInRule_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        TestRuleModel.RuleDetails.Condition conditionItemCollectionCode = Conditions.additionalInfoCode_ItemCollections();
        conditionItemCollectionCode.operator = "nco";
        TestRuleModel.RuleDetails.Condition conditionItemCollectionText = Conditions.additionalInfoText_ItemCollections();
        conditionItemCollectionText.operator = "nco";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(conditionItemCollectionCode);
        ruleDetails.queryConditions.get(0).conditions.add(conditionItemCollectionText);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(6000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.additionalInformation_Code_Item = "8788778";
        declaration.additionalInformation_Text_Item = "information";
        declaration.additionalInformation_Code_Item1 = "23";
        declaration.additionalInformation_Text_Item1 = "notmatching";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration, declarationSupport.getTemplateWithMultipleAdditionalInfo());

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_2770.class})
    public void WhenDocumentTypeItemMatchesWithItemAndText_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        TestRuleModel.RuleDetails.Condition conditionItemCollectionCode = Conditions.additionalInfoCode_ItemCollections();
        conditionItemCollectionCode.operator = "eq";
        TestRuleModel.RuleDetails.Condition conditionItemCollectionText = Conditions.additionalInfoText_ItemCollections();
        conditionItemCollectionText.operator = "eq";
        TestRuleModel.RuleDetails.Condition conditionDocumentType = Conditions.additionalDocumentsType_ItemCollections();
        conditionItemCollectionText.operator = "eq";

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(conditionItemCollectionCode);
        ruleDetails.queryConditions.get(0).conditions.add(conditionItemCollectionText);
        ruleDetails.queryConditions.get(0).conditions.add(conditionDocumentType);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(6000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalInformation_Code_Item = "100456";
        declaration.additionalInformation_Text_Item = "duty";
        declaration.additionalDocuments_Type_Item="doctyp";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration, declarationSupport.getDefaultDeclarationTemplate());

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_2770.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithNotEqualTo_RouteReturned() {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.additionalInfoCode_ItemCollections();
        condition.operator = "neq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalInformation_Code_Item = "8788778";
        declaration.additionalInformation_Code_Item1 = "23";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_2770.class})
    public void WhenDeclarationSubmittedForNotMatchingRuleWithNotEqualTo_RouteReturned() {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.additionalInfoCode_ItemCollections();
        condition.operator = "neq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalInformation_Code_Item = "8788778";
        declaration.additionalInformation_Code_Item1 = "100456";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).isEmpty();
    }


    @Test
    @Category({ChangeRequest.CR_2770.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithNotEqualToAndContains_RouteReturned() {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        TestRuleModel.RuleDetails.Condition conditionItemCollectionCode = Conditions.additionalInfoCode_ItemCollections();
        conditionItemCollectionCode.operator = "neq";
        TestRuleModel.RuleDetails.Condition conditionItemCollectionText = Conditions.additionalInfoText_ItemCollections();
        conditionItemCollectionText.operator = "con";

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(conditionItemCollectionCode);
        ruleDetails.queryConditions.get(0).conditions.add(conditionItemCollectionText);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(6000);


        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalInformation_Code_Item = "8788778";
        declaration.additionalInformation_Text_Item = "Taxduty";
        declaration.additionalInformation_Code_Item1 = "23";
        declaration.additionalInformation_Text_Item1 = "notmatching";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void GivenRuleWithNotEqualConditionOnItemCollectionWhenDeclarationDoesNotContainTheCollection_RouteNotReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.additionalInfoCode_ItemCollections();
        condition.operator = "neq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration, declarationSupport.getTemplateWithNoAdditionalInfo());

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).isEmpty();

    }

    @Test
    @Category({ChangeRequest.CR_3414.class})
    public void whenMonetaryAdjustmentValueEqualsValue_DeclarationEqualsValue_thenRouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.monetaryAdjustmentValue_ItemCollections();
        condition.operator = "eq";
        condition.value="123.45";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.monetaryAmountAdjustment_Item="123.45";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration, declarationSupport.getDefaultDeclarationTemplate());

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);


    }

    @Test
    @Category({ChangeRequest.CR_3414.class})
    public void whenValuationAdjustmentAmountAndCurrencyInCondition_DeclarationMatchesBoth_thenRouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        TestRuleModel.RuleDetails.Condition conditionItemCollection1 = Conditions.valuationAdjustmentAmount_ItemCollections();
        conditionItemCollection1.operator = "gt";
        conditionItemCollection1.value="300000.00";
        TestRuleModel.RuleDetails.Condition conditionItemCollection2 = Conditions.valuationAdjustmentCurrency_ItemCollections();
        conditionItemCollection2.operator = "eq";
        conditionItemCollection2.value="EUR";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(conditionItemCollection1);
        ruleDetails.queryConditions.get(0).conditions.add(conditionItemCollection2);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(6000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.valuationAdjustAmount_Item="300000.01";
        declaration.valuationAdjustCurrency_Item="EUR";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration, declarationSupport.getDefaultDeclarationTemplate());
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);


    }

}
