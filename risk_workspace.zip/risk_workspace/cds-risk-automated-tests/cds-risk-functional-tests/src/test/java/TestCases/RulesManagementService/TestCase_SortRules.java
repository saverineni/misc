package TestCases.RulesManagementService;


import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.EnvDetails.EnvDetails;
import API.RulesManagementService.Utils.RuleAtStatus;
import API.RulesManagementService.ViewRuleList.ViewRuleListResponse;
import Categories_CDSRisk.CDS_RM_RulesGeneral;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

import static API.RulesManagementService.Utils.Rules.GetListOfRules;

@Category({Rules_Management.class, CDS_RM_RulesGeneral.class})
public class TestCase_SortRules extends BaseWebAPITestCase {

    @Before
    public void setUp() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsNat1 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsNat1.descriptionStaticPrefix = "DraftRule";

        TestRuleModel.RuleDetails ruleDetailsLoc1 = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        ruleDetailsLoc1.descriptionStaticPrefix = "archived";

        TestRuleModel.RuleDetails ruleDetailsNat2 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsNat2.descriptionStaticPrefix = "ActiveRule";

        TestRuleModel.RuleDetails ruleDetailsLoc2 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsLoc2.descriptionStaticPrefix = "commited";

        TestRuleModel.RuleDetails ruleDetailsNat3 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsNat3.descriptionStaticPrefix = "pendingRule";


        TestRuleModel.RuleDetails ruleDetailsNat4 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsNat4.descriptionStaticPrefix = "Suspendedrule";

        TestRuleModel.RuleDetails ruleDetailsNat5 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsNat5.descriptionStaticPrefix = "expiredrule";


        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat1, TestEnumerators.RuleStatus.draft, 1);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat2, TestEnumerators.RuleStatus.active, 1);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat3, TestEnumerators.RuleStatus.pending, 1);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat4, TestEnumerators.RuleStatus.suspended, 1);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat5, TestEnumerators.RuleStatus.expired, 1);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsLoc1, TestEnumerators.RuleStatus.archived, 1);
        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetailsNat2, 2);

        publishAndWait(5000);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsLoc2, TestEnumerators.RuleStatus.committed, 1);
        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetailsLoc2, 4);

    }

    @Test
    @Category(ChangeRequest.CR_2566.class)
    public void WhenRuleIdIsSortedInDescendingOrder_RuleIdIsDisplayedInCorrectOrder() throws Throwable {

        //Act
        String url = EnvDetails.url_RuleCreate + "?size=20&page=0&sort=ruleId,DESC";
        //Assert
        ViewRuleListResponse.ViewRuleListResponseObject viewRuleListResponseObject = GetListOfRules(url);
        Assertions.assertThat(
                verifySortOrder(viewRuleListResponseObject, "ruleId", "DESC")).isEqualTo(true);
    }

    @Test
    @Category(ChangeRequest.CR_2566.class)
    public void WhenRuleIdIsSortedInAscendingOrder_RuleIdIsDisplayedInCorrectOrder() throws Throwable {


        //Act
        String url = EnvDetails.url_RuleCreate + "?size=20&page=0&sort=ruleId,ASC";
        ViewRuleListResponse.ViewRuleListResponseObject viewRuleListResponseObject = GetListOfRules(url);
        //Assert
        Assertions.assertThat(
                verifySortOrder(viewRuleListResponseObject, "ruleId", "ASC")).isEqualTo(true);
    }

    @Test
    @Category(ChangeRequest.CR_2566.class)
    public void WhenRuleTitleIsSortedInDescendingOrder_RuleTitleIsDisplayedInCorrectOrder() throws Throwable {

        //Act
        String url = EnvDetails.url_RuleCreate + "?size=20&page=0&sort=description,DESC";
        ViewRuleListResponse.ViewRuleListResponseObject viewRuleListResponseObject = GetListOfRules(url);
        //Assert
        Assertions.assertThat(
                verifySortOrder(viewRuleListResponseObject, "description", "DESC")).isEqualTo(true);
    }

    @Test
    @Category(ChangeRequest.CR_2566.class)
    public void WhenRuleTitleIsSortedInAscendingOrder_RuleTitleIsDisplayedInCorrectOrder() throws Throwable {

        //Act
        String url = EnvDetails.url_RuleCreate + "?size=20&page=0&sort=description,ASC";
        ViewRuleListResponse.ViewRuleListResponseObject viewRuleListResponseObject = GetListOfRules(url);
        //Assert
        Assertions.assertThat(
                verifySortOrder(viewRuleListResponseObject, "description", "ASC")).isEqualTo(true);
    }

    @Test
    @Category(ChangeRequest.CR_2566.class)
    public void WhenVersionIsSortedInDescendingOrder_VersionIsDisplayedInCorrectOrder() throws Throwable {


        //Act
        String url = EnvDetails.url_RuleCreate + "?size=20&page=0&sort=version,DESC";
        ViewRuleListResponse.ViewRuleListResponseObject viewRuleListResponseObject = GetListOfRules(url);
        //Assert
        Assertions.assertThat(
                verifySortOrder(viewRuleListResponseObject, "version", "DESC")).isEqualTo(true);
    }

    @Test
    @Category(ChangeRequest.CR_2566.class)
    public void WhenVersionIsSortedInAscendingOrder_VersionIsDisplayedInCorrectOrder() throws Throwable {

        //Act
        String url = EnvDetails.url_RuleCreate + "?size=20&page=0&sort=version,ASC";
        ViewRuleListResponse.ViewRuleListResponseObject viewRuleListResponseObject = GetListOfRules(url);
        //Assert
        Assertions.assertThat(
                verifySortOrder(viewRuleListResponseObject, "version", "ASC")).isEqualTo(true);
    }

    @Test
    @Category(ChangeRequest.CR_2566.class)
    public void WhenStatusIsSortedInDescendingOrder_StatusIsDisplayedInCorrectOrder() throws Throwable {
        //Act
        String url = EnvDetails.url_RuleCreate + "?size=20&page=0&sort=status,DESC";
        ViewRuleListResponse.ViewRuleListResponseObject viewRuleListResponseObject = GetListOfRules(url);

        //Assert
        List<String> statusOrder = Arrays.asList(new String[]{"archived", "expired", "suspended", "active", "active", "pending", "draft"});
        Assertions.assertThat(viewRuleListResponseObject.content).extracting("status").isEqualTo(statusOrder);
    }

    @Test
    @Category(ChangeRequest.CR_2566.class)
    public void WhenStatusIsSortedInAscendingOrder_StatusIsDisplayedInCorrectOrder() throws Throwable {

        //Act
        String url = EnvDetails.url_RuleCreate + "?size=20&page=0&sort=status,ASC";
        ViewRuleListResponse.ViewRuleListResponseObject viewRuleListResponseObject = GetListOfRules(url);

        //Assert
        List<String> statusOrder = Arrays.asList(new String[]{"draft", "pending", "active", "active", "suspended", "expired", "archived"});
        Assertions.assertThat(viewRuleListResponseObject.content).extracting("status").isEqualTo(statusOrder);
    }


    private boolean verifySortOrder(ViewRuleListResponse.ViewRuleListResponseObject viewRuleListResponseObject, String property, String order) {

        if (property.equals("ruleId")) {
            return IntStream.range(0, viewRuleListResponseObject.content.size() - 1)
                    .allMatch(i -> {
                        String ruleId1 = viewRuleListResponseObject.content.get(i).ruleId;
                        String ruleId2 = viewRuleListResponseObject.content.get(i + 1).ruleId;
                        boolean sortedOrder = order.equals("DESC") ? ruleId1.compareTo(ruleId2) >= 0 : ruleId1.compareTo(ruleId2) <= 0;
                        return sortedOrder;
                    });
        } else if (property.equals("description")) {
            return IntStream.range(0, viewRuleListResponseObject.content.size() - 1)
                    .allMatch(i -> {
                        String description1 = viewRuleListResponseObject.content.get(i).description;
                        String description2 = viewRuleListResponseObject.content.get(i + 1).description;
                        boolean sortedOrder = order.equals("DESC") ? description1.compareToIgnoreCase(description2) >= 0 : description1.compareToIgnoreCase(description2) <= 0;
                        return sortedOrder;
                    });
        } else if (property.equals("version")) {
            return IntStream.range(0, viewRuleListResponseObject.content.size() - 1)
                    .allMatch(i -> {
                        String version1 = String.valueOf(viewRuleListResponseObject.content.get(i).versionId);
                        String version2 = String.valueOf(viewRuleListResponseObject.content.get(i + 1).versionId);
                        boolean sortedOrder = order.equals("DESC") ? version1.compareTo(version2) >= 0 : version1.compareTo(version2) <= 0;
                        return sortedOrder;
                    });
        } else if (property.equals("pending")) {
            return IntStream.range(0, viewRuleListResponseObject.content.size() - 1)
                    .allMatch(i -> {
                        String pending1 = String.valueOf(viewRuleListResponseObject.content.get(i).pendingVersionsCount);
                        String pending2 = String.valueOf(viewRuleListResponseObject.content.get(i + 1).pendingVersionsCount);
                        boolean sortedOrder = order.equals("DESC") ? pending1.compareTo(pending2) >= 0 : pending1.compareTo(pending2) <= 0;
                        return sortedOrder;
                    });
        }

        return false;
    }

}