package TestCases.UI;

import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import Categories_CDSRisk.SmokeTests_UI;
import UI.CommonComponents.Dialog_Confirm;
import UI.DataForTests.TestDataTableModel;
import UI.Pages.DataManagement.CreateDataTable_Page;
import UI.Pages.DataManagement.ListDataTable_Page;
import UI.Pages.Home_Page;
import UI.Pages.RulesManagement.CreateLocalRule_Page;
import UI.Pages.RulesManagement.CreateNationalRule_Page;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static UI.DataForTests.TestRuleModel.RuleDetails.Condition.Attribute.COMMODITY_CODE;
import static UI.DataForTests.TestRuleModel.RuleDetails.Condition.AttributeType.ITEM;
import static org.junit.Assert.assertEquals;

@Category(SmokeTests_UI.class)
public class TestCase_SmokeTests extends BaseUIWebDriverTestCase{

    @Test
    public void WhenUserLogsIn_CDSRiskHomePageDisplayed()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.DefaultSuperAdminUser();

        //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        Home_Page home_page = utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        //Assert
        assertEquals(home_page.getTitle(), driver.getTitle());
        assertEquals("Superadmin", home_page.getHomeIntroText());
    }

    @Test
    public void WhenLocalRuleManagerLoggedIn_CanCreateDataTable(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateDataTable_Page createDataTable_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        //Act
        TestDataTableModel.TableDetails tableDetails = UI.DataForTests.DataTables.DataTable_CommodityCodes_POO();

        createDataTable_page.populateDataTableFields(tableDetails);

        createDataTable_page.clickSaveAndPublishButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        //Assert
        ListDataTable_Page listDataTable_page = new ListDataTable_Page(driver);
        List<ListDataTable_Page.DataTableListObject> dataTables = listDataTable_page.getDataTableListDetails();
        Assertions.assertThat(dataTables).extracting("tableTitle").contains(tableDetails.title);
    }

    @Test
    public void WhenLocalRuleManagerLoggedIn_CanCreateRuleLinkedToDataTable(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateDataTable_Page createDataTable_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        TestDataTableModel.TableDetails tableDetails = UI.DataForTests.DataTables.DataTable_CommodityCodes_POO();
        createDataTable_page.populateDataTableFields(tableDetails);
        createDataTable_page.clickSaveAndPublishButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();
        ruleDetails.conditionGroups.get(0).conditions.get(0).isDataTable = true;
        ruleDetails.conditionGroups.get(0).conditions.get(0).value = tableDetails.title;
        ruleDetails.conditionGroups.get(0).conditions.get(0).attribute = COMMODITY_CODE;
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = ITEM;

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveButton();

        dialog_confirm.EnterReasonAndCloseDialogBox("updated Auto Testing");

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        Assertions.assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }

    @Test
    public void WhenRuleManagerLoggedIn_CanCreateNewDraftVersionFromCommittedVersion()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse  committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();
        ruleDetails.description = committedRuleResponse.description;

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        boolean bNewDraft = ruleSummary_page.amend.isEnabled();
        assertEquals("Expect amend button to be enabled", true, bNewDraft);

        ruleSummary_page.amend.click();

        CreateNationalRule_Page createNationalRule_page = new CreateNationalRule_Page(driver);

        //Act
        String newDescription = ruleDetails.description  + "V2";
        createNationalRule_page.setDescription(newDescription);

        createNationalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        RuleSummary_Page ruleSummary_page2 = new RuleSummary_Page(driver);

        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page2.getListOfRuleSummaryDetails();

        assertEquals("Expect Lead Rule Status to be Committed", "Committed", listRuleSummaryTableObjects.get(0).status);
        assertEquals("Expect Lead Rule Version to be the latest", 2, listRuleSummaryTableObjects.get(0).version);
        assertEquals("Expect Lead Rule Name to be " + newDescription, newDescription, listRuleSummaryTableObjects.get(0).description);
    }

}
