package TestCases.RulesManagementService;


import API.DataForTests.DataTables;
import API.DataForTests.TestDataTableModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.EditDataTableData.EditDataTableResponse;
import API.RulesManagementService.Data.EditDataTableHeaderDetails.EditDataTableHeaderDetailsResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import API.RulesManagementService.Data.ViewDataTableData.ViewDataTableDataResponse;
import API.RulesManagementService.Users.CreateUser.CreateUserResponse;
import API.RulesManagementService.Users.ViewUserDetails.ViewUserDetailsResponse;
import Categories_CDSRisk.CDS_RM_DataTable;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import org.apache.commons.httpclient.HttpStatus;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import static API.RulesManagementService.Utils.DataTables.GetDataTableDataItems;
import static API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID;
import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_DataTable.class})
public class TestCase_DataTable_Ammend extends WebAPITestCaseWithDatatablesCleanup {


    @Test
    @Category(ChangeRequest.CR_825.class)
    public void WhenExistingDataTableEdited_CorrectDataTableDetailsReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);
        tableDetails.version = 2;

        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponseObject = GetDataTableDetailsByUID(tableDetails.uuid);

        //Assert
        SimpleDateFormat date = new SimpleDateFormat("yy");
        String yy =  date.format(new Date());

        tableDetails.uniqueId = "DT-" + "NAT" + "-\\d\\d\\d\\d-" + yy;
        Assertions.assertThat(createDataTableResponse.uniqueId).containsPattern(tableDetails.uniqueId);

        assertEquals("Unique ID has changed: ", createDataTableResponse.uniqueId, viewDataTableResponseObject.uniqueId);

        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, responseEdit.httpStatusCode);
        assertEquals(tableDetails.tableName, viewDataTableResponseObject.tableName);
        assertEquals(tableDetails.description, viewDataTableResponseObject.description);
        assertEquals(tableDetails.dataType, viewDataTableResponseObject.dataType);

        assertEquals(tableDetails.version, viewDataTableResponseObject.version);

        Assertions.assertThat(createDataTableResponse.locations.manageTables).extracting("locationName").containsOnly("National Office");
        Assertions.assertThat(createDataTableResponse.locations.useTables).extracting("locationName").containsOnly("National Office", "All Locations");
    }


    @Test
    @Category({ChangeRequest.CR_825.class, ChangeRequest.CR_936.class})
    public void WhenNewDataItemsAddedToDataTable_DataTableSavedSuccessfully() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        //tableDetails.tableVersionUuid = responseDetail.tableVersionUuid;
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableDataResponseObject = GetDataTableDataItems(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, responseEdit.httpStatusCode);
        assertEquals("Expect 4 data items: ", tableDetails.dataItems.size(), viewDataTableDataResponseObject.dataItems.size());
        assertTrue("Difference found in data items: ", viewDataTableDataResponseObject.dataItems.containsAll(tableDetails.dataItems));

        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponseObject = API.RulesManagementService.Utils.DataTables.GetDataTableByUID(tableDetails.uuid);
        assertEquals("Expect 4 data items as row count: ", tableDetails.dataItems.size(), viewDataTableResponseObject.rowCount.intValue());
    }


    @Test
    @Category(ChangeRequest.CR_825.class)
    public void When500DataItemsAddedToDataTable_DataTableSavedSuccessfully() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_Large();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        //tableDetails.tableVersionUuid = responseDetail.tableVersionUuid;
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        API.RulesManagementService.Utils.DataTables.editDataTableDataItems(tableDetails);

        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableDataResponseObject = GetDataTableDataItems(tableDetails.uuid);

        //Assert
        assertEquals("Expect 500 data items: ", tableDetails.dataItems.size(), viewDataTableDataResponseObject.dataItems.size());
        assertTrue("Difference found in data items: ", viewDataTableDataResponseObject.dataItems.containsAll(tableDetails.dataItems));
    }


    @Test
    @Category({ChangeRequest.CR_825.class, ChangeRequest.CR_938.class})
    public void WhenDataItemDeletedFromDataTable_DataTableSavedSuccessfully() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table opLockVersion via details and set it to current value
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);
        //API.RulesManagementService.Utils.DataTables.

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail1 = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail1.opLockVersion;
        assertEquals("OpLockVersion is not correct", tableDetails.opLockVersion, 1);

        //Act
        //Add no new items but remove 1st item in list

        tableDetails.dataItemsToAdd.clear();
        tableDetails.dataItemsToRemove.add(tableDetails.dataItems.get(0));
        String removedDataItem = tableDetails.dataItems.get(0);
        tableDetails.dataItems.remove(0);

        EditDataTableResponse.EditDataTableDetailsResponseObject editDataTableDetailsResponseObject = API.RulesManagementService.Utils.DataTables.editDataTableDataItems(tableDetails);

        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableDataResponseObject = GetDataTableDataItems(tableDetails.uuid);
        //Assert
        assertEquals("Expect 3 data items: ", tableDetails.dataItems.size(), viewDataTableDataResponseObject.dataItems.size());
        assertTrue("Difference found in data items: ", viewDataTableDataResponseObject.dataItems.containsAll(tableDetails.dataItems));
        assertTrue("Expect removed item to be not present", !viewDataTableDataResponseObject.dataItems.contains(removedDataItem));
    }


    @Test
    @Category({ChangeRequest.CR_825.class, ChangeRequest.CR_939.class})
    public void WhenNewDataItemsAddedToExistingDataTableWithData_DataTableSavedSuccessfully() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail1 = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail1.opLockVersion;
        assertEquals("OpLockVersion is not correct", tableDetails.opLockVersion, 1);

        //Act
        //Add 2 new items but remove 0 items
        tableDetails.dataItemsToAdd.clear();
        tableDetails.dataItemsToAdd.add("5000000000");
        tableDetails.dataItemsToAdd.add("6000000000");
        tableDetails.dataItems.addAll(tableDetails.dataItemsToAdd);

        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableDataResponseObject = GetDataTableDataItems(tableDetails.uuid);

        //Assert
        assertEquals("Expect 6 data items: ", tableDetails.dataItems.size(), viewDataTableDataResponseObject.dataItems.size());
        assertTrue("Difference found in data items: ", viewDataTableDataResponseObject.dataItems.containsAll(tableDetails.dataItems));

        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponseObject = API.RulesManagementService.Utils.DataTables.GetDataTableByUID(tableDetails.uuid);
        assertEquals("Expect 6 data items as row count: ", tableDetails.dataItems.size(), viewDataTableResponseObject.rowCount.intValue());
    }


    @Test
    @Category({ChangeRequest.CR_825.class, ChangeRequest.CR_939.class})
    public void WhenDuplicateDataItemsAddedToExistingDataTableWithData_DataTableSavedSuccessfullyWithNoDuplicates() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);

        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail1 = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail1.opLockVersion;
        assertEquals("OpLockVersion is not correct", tableDetails.opLockVersion, 1);

        //Act
        //Add 2 new items but remove 0 items
        tableDetails.dataItemsToAdd.clear();
        tableDetails.dataItemsToAdd.add(tableDetails.dataItems.get(0));
        tableDetails.dataItemsToAdd.add(tableDetails.dataItems.get(1));

        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableDataResponseObject = GetDataTableDataItems(tableDetails.uuid);

        //Assert
        assertEquals("Expect 4 data items: ", tableDetails.dataItems.size(), viewDataTableDataResponseObject.dataItems.size());
        assertTrue("Difference found in data items: ", viewDataTableDataResponseObject.dataItems.containsAll(tableDetails.dataItems));
    }

    @Test
    @Category(ChangeRequest.CR_825.class)
    public void WhenDataItemsAddedAndRemovedFromDataTable_DataTableSavedSuccessfully() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail1 = GetDataTableDetailsByUID(tableDetails.uuid);
        tableDetails.opLockVersion = responseDetail1.opLockVersion;
        assertEquals("OpLockVersion is not correct", tableDetails.opLockVersion, 1);

        //Act
        //Add 3 new items and remove 2 existing items therefore have 5 items at end 3000000000, 4000000000, 5000000000, 6000000000, 7000000000
        tableDetails.dataItemsToAdd.clear();
        tableDetails.dataItemsToAdd.add("5000000000");
        tableDetails.dataItemsToAdd.add("6000000000");
        tableDetails.dataItemsToAdd.add("7000000000");

        tableDetails.dataItems.addAll(tableDetails.dataItemsToAdd);

        tableDetails.dataItemsToRemove.add(tableDetails.dataItems.get(0));
        tableDetails.dataItemsToRemove.add(tableDetails.dataItems.get(1));
        tableDetails.dataItems.removeAll(tableDetails.dataItemsToRemove);

        EditDataTableResponse.EditDataTableDetailsResponseObject editDataTableDetailsResponseObject = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);
        assertEquals(200, editDataTableDetailsResponseObject.httpStatusCode);

        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableDataResponseObject = GetDataTableDataItems(tableDetails.uuid);

        //Assert
        assertEquals("Expect 5 data items: ", tableDetails.dataItems.size(), viewDataTableDataResponseObject.dataItems.size());
        assertTrue("Difference found in data items: ", viewDataTableDataResponseObject.dataItems.containsAll(tableDetails.dataItems));
    }


    @Test
    @Category(ChangeRequest.CR_825.class)
    public void AttemptToUpdateNonExistentDataTableUUID_NotFoundMessageReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        tableDetails.uuid = "0d164726-958a-432b-a47f-1e2fd7b458d0";
        EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals(org.apache.http.HttpStatus.SC_NOT_FOUND, responseEdit.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_825.class)
    public void AttemptToUpdateNonExistentOpLockVersion_BadRequestMessageReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        GetDataTableDetailsByUID(createDataTableResponse.uuid);

        //Act
        tableDetails.opLockVersion = 2;
        EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals(org.apache.http.HttpStatus.SC_BAD_REQUEST, responseEdit.httpStatusCode);
        assertEquals("Table version superseded - optimistic locking failed.", responseEdit.response.path("message"));
    }

    @Test
    @Category(ChangeRequest.CR_825.class)
    public void WhenNonExistentDataItemRemovedFromDataTable_NoServerErrorOccurs() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail1 = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail1.opLockVersion;
        assertEquals("OpLockVersion is not correct", tableDetails.opLockVersion, 1);

        //Act
        tableDetails.dataItemsToAdd.clear();
        tableDetails.dataItemsToRemove.add("99999999");

        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableDataResponseObject = GetDataTableDataItems(tableDetails.uuid);

        //Assert
        assertEquals("Expect 4 data items: ", tableDetails.dataItems.size(), viewDataTableDataResponseObject.dataItems.size());
        assertTrue("Difference found in data items: ", viewDataTableDataResponseObject.dataItems.containsAll(tableDetails.dataItems));
    }


    @Test
    @Category(ChangeRequest.CR_825.class)
    public void WhenAllDataItemsRemovedFromDataTable_DataTableSavedSuccessfully() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail1 = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        assertEquals("OpLockVersion is not correct", 1, responseDetail1.opLockVersion);

        //Act
        tableDetails.dataItemsToAdd.clear();
        tableDetails.dataItemsToRemove.addAll(tableDetails.dataItems);
        tableDetails.dataItems.clear();

        tableDetails.opLockVersion = responseDetail1.opLockVersion;
        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableDataResponseObject = GetDataTableDataItems(tableDetails.uuid);

        //Assert
        assertEquals("OpLockVersion is not correct", 2, viewDataTableDataResponseObject.opLockVersion);
        assertEquals("Expect 0 data items: ", tableDetails.dataItems.size(), viewDataTableDataResponseObject.dataItems.size());
    }


    @Test
    @Category(ChangeRequest.CR_825.class)
    public void AttemptToUpdateDataTableUsingOldOpLockVersion_BadRequestMessageReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        //Act
        EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit2 = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals(org.apache.http.HttpStatus.SC_BAD_REQUEST, responseEdit2.httpStatusCode);

        String expMessage = "Table version superseded - optimistic locking failed.";
        assertEquals(expMessage, responseEdit2.response.path("message"));
    }


    @Test
    @Category(ChangeRequest.CR_947.class)
    public void WhenDataItemsAddedToLocalDataTable_DataTableSavedSuccessfully() throws Throwable {

        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);
        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableDataResponseObject = GetDataTableDataItems(tableDetails.uuid);

        //Assert
        assertEquals("Expect 4 data items: ", tableDetails.dataItems.size(), viewDataTableDataResponseObject.dataItems.size());
        assertTrue("Difference found in data items: ", viewDataTableDataResponseObject.dataItems.containsAll(tableDetails.dataItems));
    }


    @Test
    @Category({ChangeRequest.CR_1712.class})
    public void AttemptToUpdateCommodityDataTableWithInvalidDataItems_BadRequestMessageReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_Invalid();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        //Assert
        API.RulesManagementService.Data.EditDataTableData.EditDataTableResponse.ErrorResponse errorResponse = responseEdit.response.as(EditDataTableResponse.ErrorResponse.class);

        assertEquals(org.apache.http.HttpStatus.SC_BAD_REQUEST, responseEdit.httpStatusCode);

        String expMessage1 = "Added element '11111111111' does not match pattern";

        Assertions.assertThat(errorResponse.fieldErrors).hasSize(1);
        Assertions.assertThat(errorResponse.fieldErrors).extracting("message").contains(expMessage1);
    }



    @Test
    @Category({ChangeRequest.CR_1712.class})
    public void WhenNewDataItemsAddedToFreeTextDataTable_DataTableSavedSuccessfully() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_FreeText_Valid();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableDataResponseObject = GetDataTableDataItems(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, responseEdit.httpStatusCode);
        assertEquals("Expect 2 data items: ", tableDetails.dataItems.size(), viewDataTableDataResponseObject.dataItems.size());
        assertTrue("Difference found in data items: ", viewDataTableDataResponseObject.dataItems.containsAll(tableDetails.dataItems));
    }


    @Test
    @Category({ChangeRequest.CR_1712.class})
    public void AttemptToUpdateFreeTextDataTableWithInvalidDataItems_BadRequestMessageReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_FreeText_Invalid();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        //Assert
        API.RulesManagementService.Data.EditDataTableData.EditDataTableResponse.ErrorResponse errorResponse = responseEdit.response.as(EditDataTableResponse.ErrorResponse.class);

        assertEquals(org.apache.http.HttpStatus.SC_BAD_REQUEST, responseEdit.httpStatusCode);

        String expMessage1 = "Added element '" + tableDetails.dataItems.get(3) + "' does not match pattern";
        String expMessage2 = "Added element '' does not match pattern";

        Assertions.assertThat(errorResponse.fieldErrors).hasSize(2);
        Assertions.assertThat(errorResponse.fieldErrors).extracting("message").contains(expMessage1);
        Assertions.assertThat(errorResponse.fieldErrors).extracting("message").contains(expMessage2);
    }

    @Test
    @Category(ChangeRequest.CR_1421.class)
    public void WhenExistingDataTableHeaderDetailsEdited_CorrectDataTableDetailsReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        String newTableName = "ta_editedTable_" + UUID.randomUUID().toString().substring(0,5);
        String newTableDescription = "ta_editedTitle_" + UUID.randomUUID().toString().substring(0,5);
        String tag = "new tag";

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;
        tableDetails.tableName = newTableName;
        tableDetails.description = newTableDescription;
        tableDetails.tags.add(tag);
        tableDetails.reason = "automated tests";

        //Act
        EditDataTableHeaderDetailsResponse.EditDataTableHeaderDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableHeaderDetailsAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponseObject = GetDataTableDetailsByUID(tableDetails.uuid);

        //assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, responseEdit.httpStatusCode);
        assertEquals(tableDetails.tableName, viewDataTableResponseObject.tableName);
        assertEquals(tableDetails.description, viewDataTableResponseObject.description);
        assertEquals(tag, viewDataTableResponseObject.tags.get(0).tagName);
    }

    @Test
    @Category(ChangeRequest.CR_1421.class)
    public void WhenExistingDataTableHeaderDetailsEdited_WithWrongValues_ErrorReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        String newTableName = "wrong";
        String newTableDescription = "wrong" ;
        String tag = "new tag";

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;
        tableDetails.tableName = newTableName;
        tableDetails.description = newTableDescription;
        tableDetails.tags.add(tag);

        //Act
        EditDataTableHeaderDetailsResponse.EditDataTableHeaderDetailsResponseObject errorResponseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableHeaderDetailsAndGetResponseObject(tableDetails);
        EditDataTableHeaderDetailsResponse.ErrorResponse response = errorResponseEdit.response.as(EditDataTableHeaderDetailsResponse.ErrorResponse.class);

        //assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_BAD_REQUEST, errorResponseEdit.httpStatusCode);
        Assertions.assertThat(response.fieldErrors).extracting("message").contains("size must be between 10 and 60");
        Assertions.assertThat(response.fieldErrors).extracting("message").contains("size must be between 10 and 30");
    }

    @Test
    @Category(ChangeRequest.CR_3077.class)
    public void WhenUserWithRuleManagerAndAdminNationalRoles_CanCreateAndEditDatatable() {

        //Arrange
        TestUserModel.UserDetails userDetails_AdminNational = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(userDetails_AdminNational);
        TestUserModel.UserDetails userDetails = Users_API.RuleManagerAndAdminNational();

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);
        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(userDetails.pid);

        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid, Users_API.DEFAULT_PASSWORD);

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Assert
        CreateUserResponse.AssertCreateUserResponse(userDetails, createUserResponse);
        ViewUserDetailsResponse.AssertViewUserDetailsResponse(userDetails, viewUserDetailsResponse);

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);
        tableDetails.version = 2;

        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponseObject = GetDataTableDetailsByUID(tableDetails.uuid);

        //Assert
        SimpleDateFormat date = new SimpleDateFormat("yy");
        String yy =  date.format(new Date());

        tableDetails.uniqueId = "DT-" + "NAT" + "-\\d\\d\\d\\d-" + yy;
        Assertions.assertThat(createDataTableResponse.uniqueId).containsPattern(tableDetails.uniqueId);

        assertEquals("Unique ID has changed: ", createDataTableResponse.uniqueId, viewDataTableResponseObject.uniqueId);

        assertEquals("HTTP Status Code: ", org.apache.commons.httpclient.HttpStatus.SC_OK, responseEdit.httpStatusCode);
        assertEquals(tableDetails.tableName, viewDataTableResponseObject.tableName);
        assertEquals(tableDetails.description, viewDataTableResponseObject.description);
        assertEquals(tableDetails.dataType, viewDataTableResponseObject.dataType);

        assertEquals(tableDetails.version, viewDataTableResponseObject.version);

        Assertions.assertThat(createDataTableResponse.locations.manageTables).extracting("locationName").containsOnly("National Office");
        Assertions.assertThat(createDataTableResponse.locations.useTables).extracting("locationName").containsOnly("National Office", "All Locations");
    }

}
