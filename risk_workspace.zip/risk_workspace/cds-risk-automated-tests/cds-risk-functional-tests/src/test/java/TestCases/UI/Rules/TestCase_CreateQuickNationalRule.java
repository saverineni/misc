package TestCases.UI.Rules;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Rules;
import Categories_CDSRisk.CDS_Risk_UI_Rules_1;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.CommonComponents.MenuToolBar;
import UI.CommonComponents.MenuToolBar_RulesManagement;
import UI.DataForTests.TestRuleModel;
import UI.ElementControls.MultiSelectDropDown;
import UI.Pages.RulesManagement.CreateLocalRule_Page;
import UI.Pages.RulesManagement.CreateQuickNationalRule_Page;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Utils.Navigation;
import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_1.class})
@RunWith(JUnitParamsRunner.class)
public class TestCase_CreateQuickNationalRule extends BaseUIWebDriverTestCase{

    @Test
    public void WhenNationalRuleManagerLoggedIn_CanCreateQuickNationalRuleWithAllStaticConditions(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateQuickNationalRule_Page createQuickNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickNationalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftQuickNATRule();

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalQuickRule(ruleDetails);

        createQuickNationalRule_page.clickSaveAndCommitButtonWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }


    @Category(ChangeRequest.CR_1211.class)
    @Test
    public void WhenNationalRuleManagerLoggedIn_CanCreateQuickNationalRuleWithASingleCondition(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateQuickNationalRule_Page createQuickNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickNationalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftQuickNATRuleSingleCondition();

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalQuickRule(ruleDetails);

        createQuickNationalRule_page.clickSaveAndCommitButtonWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);

    }


    @Test
    public void WhenLocalRuleManagerLoggedIn_CanNOTCreateQuickNationalRule(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        //Act
        MenuToolBar menuToolBar = new MenuToolBar(driver);
        menuToolBar.rulesManagement.click();

        MenuToolBar_RulesManagement menuToolBar_rulesManagement = new MenuToolBar_RulesManagement(driver);

        //Assert
        boolean menuPresent = menuToolBar_rulesManagement.isElementDisplayed(menuToolBar_rulesManagement.createQuickNatRule,2,false);
        assertTrue("Expect Create Quick National Rule menu to be NOT Present", menuPresent == false);
    }


    @Category(ChangeRequest.CR_1869.class)
    @Test
    public void WhenNationalRuleManagerCreatesQuickNationalRule_ByDefaultStartEndDateTimeNotRequired() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);

        //Act
        CreateQuickNationalRule_Page createQuickNationalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickNationalRule);
        boolean bStartDateTime = createQuickNationalRule_page.isElementDisplayed(createQuickNationalRule_page.startDateTime, 1, false);

        //Assert
        assertEquals("Expect Start Date Time to not be present: ", false, bStartDateTime);
    }

    @Category(ChangeRequest.CR_1869.class)
    @Test
    public void WhenNationalRuleManagerCreatesQuickNationalRuleAndSelectNoSetRuleStartDate_StartEndDateTimeAreRequired() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);

        //Act
        CreateQuickNationalRule_Page createQuickNationalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickNationalRule);
        createQuickNationalRule_page.scrollToViewTheElement( createQuickNationalRule_page.includeStartDate);
        createQuickNationalRule_page.includeStartDate.click();
        boolean bStartDateTime = createQuickNationalRule_page.isElementDisplayed(createQuickNationalRule_page.startDateTime);

        //Assert
        assertEquals("Expect Start Date Time to be present: ", true, bStartDateTime);

    }


    @Category(ChangeRequest.CR_1104.class)
    @Test
    public void WhenNationalRuleManagerLoggedIn_SupplementarySubTypeOptionNotPresentForQuickRule(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        CreateQuickNationalRule_Page createQuickNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickNationalRule);
        createQuickNationalRule_page.selectDeclarationType("Imports");
        List<String> actDeclarationSubTypes = createQuickNationalRule_page.getDeclarationSubTypeList();
        Assertions.assertThat(actDeclarationSubTypes).doesNotContain("Supplementary");

        }



    @Test
    @Parameters(method = "mandatoryFieldsTestData")
    public void WhenRuleManagerLoggedIn_CanNOTCommitQuickNationalRuleWithoutMandatoryFields(String testName, TestRuleModel.RuleDetails ruleDetails){

        //Arrange

        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateQuickNationalRule_Page createQuickNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickNationalRule);

        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);

        //Act
        ruleUtils.createNationalQuickRule(ruleDetails);

        //Assert
        boolean bEnabled = createQuickNationalRule_page.saveAndCommit.isEnabled();

        assertTrue("Expect Save And Commit button to be disabled", bEnabled == false);
    }


    @Category(ChangeRequest.CR_1211.class)
    @Test
    public void WhenQuickNationalRuleReasonCancelled_RuleNotCreated(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateQuickNationalRule_Page createQuickNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickNationalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftQuickNATRuleSingleCondition();

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalQuickRule(ruleDetails);

        createQuickNationalRule_page.clickSaveAndCommitButton();
        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.clickCancelButton();


        //Assert
        assertTrue("Expect Save&Commit button to be Enabled", createQuickNationalRule_page.saveAndCommit.isEnabled());
    }

    @Category(ChangeRequest.CR_1871.class)
    @Test
    @Parameters(method = "mandatoryFieldsTestData")
    public void WhenRuleManagerLoggedIn_DocCheckAndVaryReleaseForQuickNationalRuleIsNotPresent(String testName, TestRuleModel.RuleDetails ruleDetails){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateQuickNationalRule_Page createQuickNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickNationalRule);

        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);

        //Act
        ruleUtils.createLocalQuickRule(ruleDetails);

        //Assert
        assertTrue("", createQuickNationalRule_page.isElementDisplayed(By.xpath("//label[@for='actionType_3']"), 5, false) == false);
    }

    private Object[] mandatoryFieldsTestData()
    {
        //note only going to test mandatory fields which are not on local rules, as duplication of test effort
        TestRuleModel.RuleDetails rule1 =  UI.DataForTests.Rules.DraftNATRule();
        rule1.regime = null;

        return new Object[]{

                new Object[]{"regime", new TestRuleModel.RuleDetails(rule1)}

        };
    }

    @Category(ChangeRequest.CR_2822.class)
    @Test
    public void WhenActionTypeIsSelected_TimeToCloseTaskShouldNotBeAvailable(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateQuickNationalRule_Page createQuickNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickNationalRule);
        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftQuickLocalRule_POO();
        createQuickNationalRule_page.setActionType(ruleDetails.actionType.value);

        CreateLocalRule_Page localRule = new CreateLocalRule_Page(driver);
        boolean selfClosingTaskDisplayed= createQuickNationalRule_page.isElementDisplayed(localRule.timeToCloseCheckBox);
        assertFalse("Self Closing Task should not be visible for Quick Rules",selfClosingTaskDisplayed);
    }

    @Test
    @Category(ChangeRequest.CR_2977.class)
    public void WhenCreatingNationalRule_CanAddAndDeleteTheLocations() {

        //Arrange
        ArrayList<String> locations = new ArrayList<String>(Arrays.asList("BHX - Birmingham Airport","LBA - Leeds Bradford Airport"));

        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateQuickNationalRule_Page createQuickNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickNationalRule);

        MultiSelectDropDown dropDown = new MultiSelectDropDown(driver);
        createQuickNationalRule_page.selectTransportMode("Air");
        dropDown.selectMultipleValues(createQuickNationalRule_page.goodsLocationList,locations);
        List<String> selectedLocations = createQuickNationalRule_page.getSelectedGoodsLocations();
        createQuickNationalRule_page.removeLocation.click();
        List<String> locationsAfterRemoveLocations = createQuickNationalRule_page.getSelectedGoodsLocations();
        String selectedLocation = createQuickNationalRule_page.getSelectedGoodsLocation();

        assertThat(selectedLocations).contains
                ("BHX - Birmingham Airport","LBA - Leeds Bradford Airport");
        assertThat(locationsAfterRemoveLocations).hasSize(1);
        assertThat(selectedLocation).contains
                ("LBA - Leeds Bradford Airport");

    }
}
