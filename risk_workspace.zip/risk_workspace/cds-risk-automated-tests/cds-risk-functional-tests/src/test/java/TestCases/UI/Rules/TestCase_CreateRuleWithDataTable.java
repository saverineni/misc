package TestCases.UI.Rules;

import API.DataForTests.*;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.EditDataTableData.EditDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Rules;
import Categories_CDSRisk.CDS_Risk_UI_Rules_1;
import Categories_CDSRisk.ChangeRequest;
import FunctionsLibrary.Utils;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.Pages.RulesManagement.CreateNationalRule_Page;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;

import java.util.List;

import static API.DataForTests.DataTables.DataTable_CommodityCodes_NAT;
import static API.DataForTests.DataTables.DataTable_CommodityCodes_POO;
import static API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject;
import static API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject;
import static FunctionsLibrary.Utils.SleepForMilliSeconds;
import static UI.DataForTests.TestRuleModel.RuleDetails.Condition.Attribute.*;
import static UI.DataForTests.TestRuleModel.RuleDetails.Condition.AttributeType.HEADER;
import static UI.DataForTests.TestRuleModel.RuleDetails.Condition.AttributeType.ITEM;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.groups.Tuple.tuple;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.datatable;


@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_1.class})
@RunWith(JUnitParamsRunner.class)
public class TestCase_CreateRuleWithDataTable extends BaseUIWebDriverTestCase{

    private TestDataTableModel.TableDetails freeText_valid;
    public static String operator;

    @Before
    public void setup(){

        freeText_valid = DataTables.DataTable_FreeText_Valid();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(freeText_valid);
        freeText_valid.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(createDataTableResponse.uuid);
        freeText_valid.opLockVersion = responseDetail.opLockVersion;

        //Act
        EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(freeText_valid);

    }

    @Test
    @Category({ChangeRequest.CR_1762.class, ChangeRequest.CR_1714.class})
    @Parameters(method  = "operatorsForTestData")
    public void WhenRuleCreatedWithOperatorEqualsUsingDataTable_RuleCreatedSuccessfully(String operator){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateNationalRule_Page createNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateNationalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftNATRule();

        ruleDetails.conditionGroups.get(0).conditions.get(0).attribute = CONSIGNEE_ADDRESS;
        ruleDetails.conditionGroups.get(0).conditions.get(0).operator =  operator;
        ruleDetails.conditionGroups.get(0).conditions.get(0).value = freeText_valid.tableName;
        ruleDetails.conditionGroups.get(0).conditions.get(0).isDataTable = true;
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = HEADER;

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalRuleSingleCondition(ruleDetails);

        createNationalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }

    @Test
    @Ignore("Will be fixed as part of CR-3194")
    public void WhenTryingToCreateRulesWithCommodityCode_UsingEqualsOperatorDisplaysListOfCommodityAndPartCommodityTablesOnly(){

        //Arrange
        CreateDataTableResponse.PostResponse commodityTable = CreateDataTableAndGetResponseObject(DataTables.DataTable_CommodityCodes_NAT());
        CreateDataTableResponse.PostResponse freeTextTable = CreateDataTableAndGetResponseObject(DataTables.DataTable_FreeText_Extra());
        CreateDataTableResponse.PostResponse partCommodityTable = CreateDataTableAndGetResponseObject(DataTables.DataTable_PartCommodityCodes());

        //Act
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateNationalRule_Page createNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateNationalRule);

        String operator = "Equal";
        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftNATRuleUsingDataTable(COMMODITY_CODE, operator, commodityTable.tableName);
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = ITEM;

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalRuleSingleCondition(ruleDetails);
        List<String> dataTablesInDropDown = createNationalRule_page.getPopulatedDataTables();
        assertThat(dataTablesInDropDown, hasItems(commodityTable.tableName, partCommodityTable.tableName));
        assertThat(dataTablesInDropDown, not(hasItems(freeTextTable.tableName)));

        createNationalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }

    @Test
    public void WhenTryingToCreateRulesWithConsigneeAddress_UsingEqualsOperatorDisplaysListOfFeeTextTablesOnly(){

        //Arrange
        CreateDataTableResponse.PostResponse commodityTable = CreateDataTableAndGetResponseObject(DataTables.DataTable_CommodityCodes_NAT());
        CreateDataTableResponse.PostResponse partCommodityTable = CreateDataTableAndGetResponseObject(DataTables.DataTable_PartCommodityCodes());
        CreateDataTableResponse.PostResponse freeTextTable_Ext = CreateDataTableAndGetResponseObject(DataTables.DataTable_FreeText_Extra());

        //Act
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateNationalRule_Page createNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateNationalRule);

        String operator = "Equal";
        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftNATRuleUsingDataTable(CONSIGNEE_ADDRESS, operator, freeText_valid.tableName);
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = HEADER;

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalRuleSingleCondition(ruleDetails);

        List<String> dataTablesInDropDown = createNationalRule_page.getPopulatedDataTables();

        assertThat(dataTablesInDropDown, not(hasItems(commodityTable.tableName, partCommodityTable.tableName)));
        assertThat(dataTablesInDropDown, hasItems(freeText_valid.tableName, freeTextTable_Ext.tableName));

        createNationalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat
        (listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }

    @Test
    public void WhenTryingToCreateRulesWithGoodsDescription_UsingMatchingOperatorDisplaysListOfFeeTextTablesOnly(){

        //Arrange
        CreateDataTableResponse.PostResponse commodityTable = CreateDataTableAndGetResponseObject(DataTables.DataTable_CommodityCodes_NAT());
        CreateDataTableResponse.PostResponse partCommodityTable = CreateDataTableAndGetResponseObject(DataTables.DataTable_PartCommodityCodes());
        CreateDataTableResponse.PostResponse freeTextTable_Ext = CreateDataTableAndGetResponseObject(DataTables.DataTable_FreeText_Extra());

        //Act
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateNationalRule_Page createNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateNationalRule);

        String operator = "Not Equal";
        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftNATRuleUsingDataTable(GOODS_DESCRIPTION, operator, freeText_valid.tableName);
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = ITEM;
        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalRuleSingleCondition(ruleDetails);

        List<String> dataTablesInDropDown = createNationalRule_page.getPopulatedDataTables();

        assertThat(dataTablesInDropDown, not(hasItems(commodityTable.tableName, partCommodityTable.tableName)));
        assertThat(dataTablesInDropDown, hasItems(freeText_valid.tableName, freeTextTable_Ext.tableName));

        createNationalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }


    @Test
    @Category({ChangeRequest.CR_2127.class})
    public void WhenRuleCreatedWithDataTable_DataTablesTabShowsCorrectTable(){

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestDataTableModel.TableDetails tableDetails2 = DataTable_CommodityCodes_POO();
        CreateDataTableResponse.PostResponse createDataTableResponse2 = CreateDataTableAndGetResponseObject(tableDetails2);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.Draft2ConditionsNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).isDataTable = true;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = datatable;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        ruleDetails.queryConditions.get(0).conditions.get(1).isDataTable = true;
        ruleDetails.queryConditions.get(0).conditions.get(1).conditionType = datatable;
        ruleDetails.queryConditions.get(0).conditions.get(1).value = createDataTableResponse2.uuid;

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.description = createRuleResponse.description;

        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRulesPage =  utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRulesPage.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);
        Utils.SleepForMilliSeconds(500);
        ruleSummary_page.dataTableTab.click();
        List<RuleSummary_Page.RuleDataTableObject> listOfRuleDataTables = ruleSummary_page.getListOfRuleDataTables();

        //Assert
        Assertions.assertThat(listOfRuleDataTables)
                .hasSize(2)
                .extracting("tableId", "tableTitle", "description", "version", "status")
                .contains(
                        tuple(createDataTableResponse.uniqueId, tableDetails.tableName, tableDetails.description, 1, "Active"),
                        tuple(createDataTableResponse2.uniqueId, tableDetails2.tableName, tableDetails2.description, 1, "Active")
                );

    }

    @Test
    @Category(ChangeRequest.CR_3319.class)
    public void WhenTryingCreatingANatRuleWithDataTable_OnlyTablesWithCorrectDataTableTypesAreAvailableToUseWithRule(){

        //Arrange
        CreateDataTableResponse.PostResponse freeText = CreateDataTableAndGetResponseObject(DataTables.DataTable_FreeText_Valid());
        CreateDataTableResponse.PostResponse eoriDataTable = CreateDataTableAndGetResponseObject(DataTables.DataTable_EORI_Valid());
        CreateDataTableResponse.PostResponse commodityCode = CreateDataTableAndGetResponseObject(DataTables.DataTable_DefaultCommodityCodes());
        //Act
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateNationalRule_Page createNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateNationalRule);

        String operator = "Equal";
        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftNATRuleUsingDataTable(BUYER_ID_ITEM_COLLECTION, operator, eoriDataTable.tableName);
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = ITEM;
        createNationalRule_page.selectTransportMode("All");
        createNationalRule_page.selectGoodsLocation(ruleDetails);
        createNationalRule_page.populateSingleCondition(ruleDetails);
        List<String> datatablesBuyerId =  createNationalRule_page.getPopulatedDataTables();

        operator = "Equal";
        ruleDetails = UI.DataForTests.Rules.DraftNATRuleUsingDataTable(SELLER_ID_HEADER_COLLECTION, operator, eoriDataTable.tableName);
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = HEADER;
        createNationalRule_page.populateSingleCondition(ruleDetails);
        List<String> datatablesSellerId =  createNationalRule_page.getPopulatedDataTables();

        //Assert
        SleepForMilliSeconds(1000);
        Assertions.assertThat(datatablesBuyerId).containsOnly(eoriDataTable.tableName);
        Assertions.assertThat(datatablesSellerId).containsOnly(eoriDataTable.tableName);

    }



    public Object[] operatorsForTestData()
    {

        return new Object[]{
                new Object[]{"Equal"},
                new Object[]{"Not Equal"},
                new Object[]{"Contains"},
                new Object[]{"Not Contains"},
                new Object[]{"Starts With"},
                new Object[]{"Matches Pattern"},
                new Object[]{"Not Matches Pattern"}
        };
    }
    




}
