package TestCases.UI.DataTables;


import API.DataForTests.*;
import API.DataService.CreateDataTable.CreateDataTableResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_DataTables;
import Categories_CDSRisk.CDS_Risk_UI_DataTables_2;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.Pages.DataManagement.ListDataTable_Page;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.ArrayList;
import java.util.List;

import static API.Utils.LoginAsAPIUserAndCreateDataTableForLocation;
import static UI.Utils.DataTables.NavigateToListMyDataTablesAndGetListOfDataTablesTitles;
import static org.junit.Assert.assertFalse;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_DataTables.class, CDS_Risk_UI_DataTables_2.class})
public class TestCase_ListMyDataTables extends BaseUIWebDriverTestCase {


    @Category(ChangeRequest.CR_1190.class)
    @Test
    public void WhenLocalRuleManagerLoggedIn_CanViewDataDataTablesCreatedByThemInListMyDataTables() {

        //Arrange
        //Login as User 1 create data table for POO
        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        TestDataTableModel.TableDetails tableDetailsPOO = DataTables.DataTable_CommodityCodes_POO();
        LoginAsAPIUserAndCreateDataTableForLocation(UserDetailsPOO, tableDetailsPOO);

        //Login as User 2 create data table for EXT
        TestUserModel.UserDetails UserDetails_EXT = Users_API.RulesManagerLocal_EXT();
        TestDataTableModel.TableDetails tableDetailsEXT = DataTables.DataTable_CommodityCodes_EXT();
        LoginAsAPIUserAndCreateDataTableForLocation(UserDetails_EXT, tableDetailsEXT);

        //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_EXT);

        List<String> dataTableTitles = NavigateToListMyDataTablesAndGetListOfDataTablesTitles(driver, "Owner");

        //Assert
        Assertions.assertThat(dataTableTitles).contains(tableDetailsEXT.tableName);

        assertFalse("Expect Local Table POO to be not visible when 'List My Data Tables' selected",
                dataTableTitles.contains(tableDetailsPOO.tableName));

    }

    @Category({ChangeRequest.CR_1190.class})
    @Test
    public void WhenLocalRuleManagerLoggedIn_CanViewDataDataTablesSharedForUseWithThemInListMyDataTables(){

        //Arrange
        //Login as User 1 create data table for POO
        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        TestDataTableModel.TableDetails tableDetailsPOO = DataTables.DataTable_CommodityCodes_POO();
        tableDetailsPOO.tableType = "sensitive";
        CreateDataTableResponse.PostResponse createDataTableResponse1 = LoginAsAPIUserAndCreateDataTableForLocation(UserDetailsPOO, tableDetailsPOO);

        tableDetailsPOO.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetailsPOO.uuid = createDataTableResponse1.uuid;
        tableDetailsPOO.creationShareType = "user";

        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetailsPOO);
        //Response response = API.DataService.Utils.DataTables.ShareDataTableWithLocations(tableDetailsPOO);

        //Act
        TestUserModel.UserDetails UserDetails_EXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_EXT);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_EXT);

        List<String> dataTableTitles = NavigateToListMyDataTablesAndGetListOfDataTablesTitles(driver, "User");

        //Assert
        Assertions.assertThat(dataTableTitles).contains(tableDetailsPOO.tableName);
    }


    @Category(ChangeRequest.CR_1190.class)
    @Test
    public void WhenLocalRuleManagerLoggedIn_CanViewDataDataTablesSharedForOwnershipWithThemInListMyDataTables(){

        //Arrange
        //Login as User 1 create data table for POO
        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        TestDataTableModel.TableDetails tableDetailsPOO = DataTables.DataTable_CommodityCodes_POO();
        CreateDataTableResponse.PostResponse createDataTableResponse1 = LoginAsAPIUserAndCreateDataTableForLocation(UserDetailsPOO, tableDetailsPOO);

        tableDetailsPOO.manageTableLocationUuids.add(Locations.Location_EXT_UID);
        tableDetailsPOO.uuid = createDataTableResponse1.uuid;
        tableDetailsPOO.creationShareType = "owner";

        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetailsPOO);

        //Act
        TestUserModel.UserDetails UserDetails_EXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_EXT);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_EXT);

        List<String> dataTableTitles = NavigateToListMyDataTablesAndGetListOfDataTablesTitles(driver, "Owner");

        //Assert
        Assertions.assertThat(dataTableTitles).contains(tableDetailsPOO.tableName);
    }


    @Category(ChangeRequest.CR_1190.class)
    @Test
    public void WhenLocalRuleManagerLoggedIn_CanViewDataDataTablesSharedForUseWithAllInListMyDataTables(){

        //Arrange
        //Login as User 1 create data table for POO
        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        TestDataTableModel.TableDetails tableDetailsPOO = DataTables.DataTable_CommodityCodes_POO();
        tableDetailsPOO.tableType = "sensitive";
        CreateDataTableResponse.PostResponse createDataTableResponse1 = LoginAsAPIUserAndCreateDataTableForLocation(UserDetailsPOO, tableDetailsPOO);

        tableDetailsPOO.useTablesLocationUuids.add(Locations.Location_AllLocations_UID);
        tableDetailsPOO.uuid = createDataTableResponse1.uuid;
        tableDetailsPOO.creationShareType = "user";

        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetailsPOO);

        //Act
        TestUserModel.UserDetails UserDetails_EXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_EXT);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_EXT);

        List<String> dataTableTitles = NavigateToListMyDataTablesAndGetListOfDataTablesTitles(driver, "User");

        //Assert
        Assertions.assertThat(dataTableTitles).contains(tableDetailsPOO.tableName);
    }


    @Category(ChangeRequest.CR_1190.class)
    @Test
    public void WhenLocalRuleManagerLoggedIn_CanViewDataDataTablesSharedForOwnershipWithAllInListMyDataTables(){

        //Arrange
        //Login as User 1 create data table for POO
        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        TestDataTableModel.TableDetails tableDetailsPOO = DataTables.DataTable_CommodityCodes_POO();
        CreateDataTableResponse.PostResponse createDataTableResponse1 = LoginAsAPIUserAndCreateDataTableForLocation(UserDetailsPOO, tableDetailsPOO);

        tableDetailsPOO.manageTableLocationUuids.add(Locations.Location_AllLocations_UID);
        tableDetailsPOO.uuid = createDataTableResponse1.uuid;
        tableDetailsPOO.creationShareType = "owner";

        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetailsPOO);

        //Act
        TestUserModel.UserDetails UserDetails_EXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_EXT);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_EXT);

        List<String> dataTableTitles = NavigateToListMyDataTablesAndGetListOfDataTablesTitles(driver, "Owner");

        //Assert
        Assertions.assertThat(dataTableTitles).contains(tableDetailsPOO.tableName);
    }


    @Category(ChangeRequest.CR_1057.class)
    @Test
    public void WhenLocalRuleManagerFiltersMyDataTablesByUserOnly_CanViewDataDataTablesSharedForUse(){

        //Arrange
        //Login as User 1 create data table for POO
        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        TestDataTableModel.TableDetails tableDetailsPOO = DataTables.DataTable_CommodityCodes_POO();
        tableDetailsPOO.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse1 = LoginAsAPIUserAndCreateDataTableForLocation(UserDetailsPOO, tableDetailsPOO);

        tableDetailsPOO.useTablesLocationUuids.add(Locations.Location_AllLocations_UID);
        tableDetailsPOO.uuid = createDataTableResponse1.uuid;

        tableDetailsPOO.creationShareType = TestEnumerators.ShareTypes.user.toString();
        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetailsPOO);

        //Act
        TestUserModel.UserDetails UserDetails_EXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_EXT);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_EXT);

        List<String> dataTableTitles = NavigateToListMyDataTablesAndGetListOfDataTablesTitles(driver, "User");

        ListDataTable_Page listDataTable_page = new ListDataTable_Page(driver);
        listDataTable_page.accessDropDown.click();

        listDataTable_page.userOnly.click();

        List<ListDataTable_Page.DataTableListObject> dataTables = listDataTable_page.getDataTableListDetails();

        List<String> userDataTableTitles = new ArrayList<>();

        for (ListDataTable_Page.DataTableListObject dataTableListObject : dataTables){

            userDataTableTitles.add(dataTableListObject.tableTitle);
        }

        //Assert
        Assertions.assertThat(dataTableTitles).containsOnly(tableDetailsPOO.tableName);
        Assertions.assertThat(userDataTableTitles).containsOnly(tableDetailsPOO.tableName);
    }


}
