package TestCases.RiskingServiceJava.MDG;

import API.RiskingServiceJava.Utils.SoapMessageHelper.SoapMessage;
import Categories_CDSRisk.ChangeRequest_RiskingService.CREP_650;
import Categories_CDSRisk.Risking_JavaService;
import TestCases.RiskingServiceJava.BaseRiskingServiceJava;
import com.google.common.collect.ImmutableList;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.DeclarationType;
import uk.gov.hmrc.risk.test.common.enums.DomainAttribute;
import uk.gov.hmrc.risk.test.common.enums.HeaderDeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.Operator;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel.Query;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel.RuleOutputs;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants;

import static API.DataForTests.TestEnumerators.RuleOutputs.INFORMATION_TASK;
import static API.DataForTests.TestEnumerators.RuleOutputs.PHYSICAL_CHECK;
import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
@Category({CREP_650.class, Risking_JavaService.class})
public class TestCase_MDGEmailRequest extends BaseRiskingServiceJava {

    @Test
    public void emailRequestIsSentWhenRuleOutputIsInformationTaskOnly() throws Exception {
        CreateRuleModel rule = createInformationTaskOnlyRule();
        RuleOutputs ruleOutputs = rule.getRuleOutputs();


        createAndSendDeclaration(ImmutableList.of(
                consignorCountry("DE")
        ));


        String message = mdgEmailQueueAccessor.receive();
        SoapMessage emailRequest = soapHelper.parse(message);

        // Check information narrative isn't sent #CR-3304
        assertThat(emailRequest.getValueFromBody("EmailRequest/EmailContent/Content"))
                .doesNotContain(ruleOutputs.getInformationNarrative());

        // Check an ID is present #CR-3305
        assertThat(emailRequest.getValueFromBody("EmailRequest/EmailContent/Content"))
                .contains("NAT-ADD");

        assertThat(emailRequest.getValueFromBody("EmailRequest/EmailContent/Bcc"))
                .contains(ruleOutputs.getInformationNarrativeAssignee());
    }

    @Test
    public void emailRequestIsSentWhenRuleOutputIsPhysicalCheckAndInformationTask() throws Exception {
        CreateRuleModel rule = createPhysicalCheckAndInformationTaskRule();
        RuleOutputs ruleOutputs = rule.getRuleOutputs();

        createAndSendDeclaration(ImmutableList.of(
                consignorCountry("FR")
        ));

        String message = mdgEmailQueueAccessor.receive();
        SoapMessage emailRequest = soapHelper.parse(message);

        assertThat(emailRequest.getValueFromBody("EmailRequest/EmailContent/Bcc"))
                .contains(ruleOutputs.getInformationNarrativeAssignee());
    }

    @Test
    public void emailRequestIsNotSentWhenRuleOutputIsNotInformationTask() throws Exception {
        createPhysicalCheckOnlyRule();

        createAndSendDeclaration(ImmutableList.of(
                consignorCountry("GB")
        ));

        assertThat(mdgEmailQueueAccessor.receive()).isNull();
    }


    private RuleDefinitionConstants.Condition consignorCountry(String value) {
        return RuleDefinitionConstants.Condition.builder()
                .declarationParam(HeaderDeclarationParam.CONSIGNOR_ADDRESS_COUNTRY)
                .declarationValue(value)
                .build();
    }

    private CreateRuleModel createInformationTaskOnlyRule() {
        RuleOutputs ruleOutputs = RuleOutputs.builder()
                .actionType(INFORMATION_TASK.actionType)
                .informationNarrative("there is a consignment of things you should be aware of")
                .informationNarrativeAssignee("mraware@hmrc.gsi.gov.uk")
                .build();

        return createRule(ruleOutputs, "DE");
    }

    private CreateRuleModel createPhysicalCheckAndInformationTaskRule() {
        RuleOutputs ruleOutputs = RuleOutputs.builder()
                .actionType(PHYSICAL_CHECK.actionType)
                .holdNarrative("physically check the goods")
                .assigneeId("nch_open_general_export_licence")
                .informationNarrative("there is a consignment of things you should be aware of")
                .informationNarrativeAssignee("mraware@hmrc.gsi.gov.uk")
                .build();

        return createRule(ruleOutputs, "FR");
    }

    private CreateRuleModel createPhysicalCheckOnlyRule() {
        RuleOutputs ruleOutputs = RuleOutputs.builder()
                .actionType(PHYSICAL_CHECK.actionType)
                .holdNarrative("physically check the goods")
                .assigneeId("nch_open_general_export_licence")
                .build();

        return createRule(ruleOutputs, "GB");
    }

    private CreateRuleModel createRule(RuleOutputs ruleOutputs, String consigneeCountry) {
        CreateRuleModel model = createRuleModel();
        model.setStartDateTime(null);
        model.getQueryOptions().setDeclarationType(DeclarationType.Both.name());
        model.getQueryOptions().setDeclarationSubTypes(null);
        model.getQuery().get(0).setQuery(ImmutableList.of(
                Query.builder()
                        .attribute(DomainAttribute.ConsignorCountry.toString())
                        .operator(Operator.eq.name())
                        .value(consigneeCountry)
                        .build()
        ));

        model.setRuleOutputs(ruleOutputs);

        createAndRefreshRule(model);

        return model;
    }


}
