package TestCases.UI.DataTables;


import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_DataTables;
import Categories_CDSRisk.CDS_Risk_UI_DataTables_1;
import Categories_CDSRisk.ChangeRequest;
import FunctionsLibrary.FileUtilities;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.DataForTests.TestDataTableModel;
import UI.Pages.DataManagement.CreateDataTable_Page;
import UI.Pages.DataManagement.DataTableSummary_Page;
import UI.Utils.Navigation;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_DataTables.class, CDS_Risk_UI_DataTables_1.class})
public class TestCase_CreateDataTable extends BaseUIWebDriverTestCase {

    @Test
    @Category({ChangeRequest.CR_2135.class, ChangeRequest.CR_3063.class})
    public void WhenDataTableCreated_TableSummaryContainsAllValidData() {

        //arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        Navigation utilNavigation = new Navigation(driver);
        CreateDataTable_Page createDataTable_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        TestDataTableModel.TableDetails tableDetails = UI.DataForTests.DataTables.DataTable_FreeText_NAT();

        //act
        createDataTable_page.populateDataTableFields(tableDetails);

        createDataTable_page.clickSaveAndPublishButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        DataTableSummary_Page dataTableSummary_page = createDataTable_page.clickViewDataTableButton();

        //assert
        assertEquals("Owner", dataTableSummary_page.accessLevel.getText());
        assertEquals(tableDetails.title, dataTableSummary_page.title.getText());
        assertEquals(tableDetails.description, dataTableSummary_page.description.getText());
        assertEquals(tableDetails.dataType, dataTableSummary_page.dataType.getText());
        assertTrue(dataTableSummary_page.createdBy.getText().contains(UserDetails.getFullName()));

        Assertions.assertThat(dataTableSummary_page.tableType.getText()).contains("Open");
    }

    @Category(ChangeRequest.CR_2213.class)
    @Test
    public void AttemptToSaveDataTableWithInvalidReasonLength_ContinueButtonDisabled() {

        //arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        Navigation utilNavigation = new Navigation(driver);
        CreateDataTable_Page createDataTable_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        TestDataTableModel.TableDetails tableDetails = UI.DataForTests.DataTables.DataTable_CommodityCodes_POO();

        createDataTable_page.populateDataTableFields(tableDetails);
        createDataTable_page.clickSaveAndPublishButton();

        //act
        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);

        dialog_confirm.reason.setValue("Test");
        boolean bButtonStatusLessThan5Chars = dialog_confirm.ok.isEnabled();

        dialog_confirm.reason.setValue("Test5");
        boolean bButtonStatus5Chars = dialog_confirm.ok.isEnabled();


        dialog_confirm.reason.setValue(FileUtilities.GenerateRandomAlphaNumericString(61, true, true));
        boolean bButtonStatusMoreThanMaxChars = dialog_confirm.ok.isEnabled();

        dialog_confirm.reason.setValue(FileUtilities.GenerateRandomAlphaNumericString(60, true, true));
        boolean bButtonStatus60Chars = dialog_confirm.ok.isEnabled();

        //assert
        assertEquals("Expect bButtonStatusLessThan5Chars to be Disabled", false, bButtonStatusLessThan5Chars);
        assertEquals("Expect bButtonStatus5Chars to be Enabled", true, bButtonStatus5Chars);
        assertEquals("Expect bButtonStatus60Chars to be Disabled", true, bButtonStatus60Chars);
    }


    @Test
    @Category(ChangeRequest.CR_2135.class)
    public void AttemptToSaveDataTableWithoutTableType_ContinueButtonDisabled() {

        //arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        Navigation utilNavigation = new Navigation(driver);
        CreateDataTable_Page createDataTable_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        TestDataTableModel.TableDetails tableDetails = UI.DataForTests.DataTables.DataTable_CommodityCodes_POO();

        //act
        tableDetails.tableType = "";
        createDataTable_page.populateDataTableFields(tableDetails);

        boolean bButtonStatus = createDataTable_page.saveAndPublish.isEnabled();

        //assert
        assertEquals("Expect bButtonStatus to be Disabled", false, bButtonStatus);
    }

    @Test
    @Category(ChangeRequest.CR_2982.class)
    public void WhenUserTryToCreateDataTableWithSameTitle_DataTableWithNameExistsMessageIsDisplayed() {

        //arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        Navigation utilNavigation = new Navigation(driver);
        CreateDataTable_Page createDataTable_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        TestDataTableModel.TableDetails tableDetails = UI.DataForTests.DataTables.DataTable_CommodityCodes_POO();

        //act
        createDataTable_page.populateDataTableFields(tableDetails);

        createDataTable_page.clickSaveAndPublishButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        //assert
        CreateDataTable_Page createDataTableTwo_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        TestDataTableModel.TableDetails tableDetailsWithSameTitle = UI.DataForTests.DataTables.DataTable_CommodityCodes_POO();

        //act
        createDataTableTwo_page.populateDataTableFields(tableDetailsWithSameTitle);

        createDataTableTwo_page.clickSaveAndPublishButton();

        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");
        String dataTableWithSameNameExistsErrorMessage =  createDataTableTwo_page.dataTableWithSameNameExistsError.getText();
        //assert
        assertEquals("Data table with name 'ta_uiTableCommodityCodesPOO' exists", dataTableWithSameNameExistsErrorMessage);
    }
}
