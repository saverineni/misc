package TestCases.DARService;

import API.DataForTests.Locations;
import API.DataForTests.TestEnumerators;
import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.DAR_Client;
import TestCases.RiskingServiceJava.BaseRiskingServiceJava;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.rulesengine.publishing.PublishEventFullDto;
import uk.gov.hmrc.risk.test.common.enums.ConditionType;
import uk.gov.hmrc.risk.test.common.enums.DarEventType;
import uk.gov.hmrc.risk.test.common.enums.GoodsItemDeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.HeaderDeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.Operator;
import uk.gov.hmrc.risk.test.common.enums.TransportMode;
import uk.gov.hmrc.risk.test.common.model.darService.DarRuleAuditModel;
import uk.gov.hmrc.risk.test.common.model.darService.DarRuleBehavioursModel;
import uk.gov.hmrc.risk.test.common.model.darService.DarRuleDataTablesModel;
import uk.gov.hmrc.risk.test.common.model.darService.DarRuleLocationsModel;
import uk.gov.hmrc.risk.test.common.model.dataService.DataTableCreationModel;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel.Query;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Category({ChangeRequest_RiskingService.CREP_294.class, DAR_Client.class})
public class TestCase_AreRulesWrittenCorrectly extends BaseRiskingServiceJava{

    PublishEventFullDto publishEvent;
    CreateRuleModel createRuleModel;
    DataTableCreationModel dataTableCreationModel;
    String ruleId;
    String dataTableUuid;

    @Test
    public void WhenPublishEventAppear_LatestRulesAreWrittenInFile() {
        createRule();
        assertRuleAuditFile();
        assertRuleDataTableFile();
        assertRuleLocationsFile();
        assertRuleBehavioursFile();
    }

    public void createRule() {

        dataTableCreationModel = baseDataTableModel();
        List<String> dataItems = new ArrayList<>();
        dataItems.addAll(Arrays.asList( "0000000001", "0000000002", "0000000003", "0000000004", "0000000005"));
        dataTableUuid = dataTableSupport.createDataTable(dataTableCreationModel, dataItems);

        createRuleModel = createRuleModel();
        createRuleModel.setLocationUuids( Arrays.asList(
                Locations.Location_ABD_UID, Locations.Location_National_UID));

        createRuleModel.setQuery( Arrays.asList( Query.builder()
                .operator(Operator.or.toString())
                .query( Arrays.asList(
                        Query.builder()
                                .attribute(HeaderDeclarationParam.CONSIGNEE_NAME.toString())
                                .operator(Operator.eq.toString())
                                .conditionType(ConditionType.normal.toString())
                                .value("MrTester")
                                .build(),
                        Query.builder()
                                .attribute(GoodsItemDeclarationParam.COMMODITY_CODE.toString())
                                .operator(Operator.eq.toString())
                                .conditionType(ConditionType.datatable.toString())
                                .value(dataTableUuid)
                                .build()
                        )
                )
                .build()
                )
        );
        createRuleModel.setRuleOutputs(
                CreateRuleModel.RuleOutputs.builder()
                        .actionType(TestEnumerators.RuleOutputs.DOC_CHECK_VARY_RELEASE_GOODS.actionType)
                        .holdPercentage(20)
                        .holdNarrative("Hold the goods")
                        .releasePercentage(80)
                        .releaseNarrative("Release the goods")
                        .informationNarrative("Im informing you")
                        .informationNarrativeAssignee("mr.tester@ce.gsi.gov.uk")
                        .assigneeId("nch_open_general_export_licence")
                        .secretTask(false)
                        .build()
        );

        ruleId = createRule(createRuleModel);
        publishEvent = publishAndWait();
    }

    private void assertRuleAuditFile() {
        List<DarRuleAuditModel> filtered = darServicePublishingSupport.parseRuleAuditEvents()
                .stream().filter(
                        model -> matchFileListingsBasedPackageId(model.getRuleUuid()))
                .collect(Collectors.toList());

        Assertions.assertThat(filtered.size()).isEqualTo(1);

        filtered.forEach(rule ->
        {
            ZonedDateTime ruleTime = darServiceAuditSupport.getFormattedTimestamp(rule.getEventTime());
            Assertions.assertThat(ruleTime).isBeforeOrEqualTo(ZonedDateTime.now().plusHours(2));
            Assertions.assertThat(rule.getType()).isEqualTo(DarEventType.RULE_AUDIT.toString());
            Assertions.assertThat(rule.getPackageUuid()).isEqualTo(publishEvent.getPublishEventId().toString());
            Assertions.assertThat(rule.getRuleDescription()).isEqualTo(createRuleModel.getDescription());
            Assertions.assertThat(rule.getRuleName()).isNotEmpty();
            Assertions.assertThat(rule.getRuleType()).isEqualTo(createRuleModel.getRuleType());
            Assertions.assertThat(rule.getRuleVersionId()).isEqualTo("1");
            Assertions.assertThat(rule.getRuleStatus()).isEqualTo(TestEnumerators.RuleStatus.active.toString());
            Assertions.assertThat(rule.getRegimeCode()).isEqualTo("ADD");
            Assertions.assertThat(rule.getRuleVersionId()).isEqualTo("1");
            Assertions.assertThat(rule.getDeclarationType()).isEqualTo("Imports");
            Assertions.assertThat(rule.getModeOfTransport()).isEqualTo(TransportMode.All.toString());
            Assertions.assertThat(rule.getCreatorPid()).isEqualTo(appStateSupport.getLoggedInUserPID());
            Assertions.assertThat(rule.getCreatedTimestamp()).isNotEmpty();
            Assertions.assertThat(rule.getUpdatorPid()).isEqualTo(appStateSupport.getLoggedInUserPID());
            Assertions.assertThat(rule.getLastUpdateTimestamp()).isNotEmpty();
            Assertions.assertThat(rule.getCreatedTimestamp()).isNotEmpty();
            Assertions.assertThat(rule.getStartDate()).isNotEmpty();
            Assertions.assertThat(rule.getEndDate()).isEmpty();
            Assertions.assertThat(rule.getRatLimit()).isEmpty();
            Assertions.assertThat(rule.getRatFrequency()).isEmpty();
            Assertions.assertThat(rule.getDrlDef()).contains("declaration: DeclarationWrapper");
            Assertions.assertThat(rule.getNumberOfLocations()).isEqualTo("2");
            Assertions.assertThat(rule.getNumberOfDataTables()).isEqualTo("1");
            Assertions.assertThat(rule.getNumberOfBehaviours()).isEqualTo("3");
        });
    }

    private void assertRuleDataTableFile() {
        List<DarRuleDataTablesModel> filtered = darServicePublishingSupport.parseRuleDataTableEvents()
                .stream().filter(
                        model -> matchFileListingsBasedPackageId(model.getRuleUuid()))
                .collect(Collectors.toList());

        Assertions.assertThat(filtered.size()).isEqualTo(1);

        filtered.forEach(dataTablesModel ->
        {
            Assertions.assertThat(dataTablesModel.getType()).isEqualTo(DarEventType.RULE_DATA_TABLES.toString());
            Assertions.assertThat(dataTablesModel.getPackageUuid())
                    .isEqualTo(publishEvent.getPublishEventId().toString());
            Assertions.assertThat(dataTablesModel.getRuleVersionId()).isEqualTo("1");
            Assertions.assertThat(dataTablesModel.getDataTableUuid()).isEqualTo(dataTableUuid);
            Assertions.assertThat(dataTablesModel.getDataTableName()).isEqualTo(dataTableCreationModel.getTableName());
        });
    }

    private void assertRuleLocationsFile() {
        List<DarRuleLocationsModel> filtered = darServicePublishingSupport.parseRuleLocationsEvents()
                .stream().filter(
                        model -> matchFileListingsBasedPackageId(model.getRuleUuid()))
                .collect(Collectors.toList());

        Assertions.assertThat(filtered.size()).isEqualTo(2);

        List<String> locationUuds = filtered.stream()
                .map(DarRuleLocationsModel::getLocationUuid)
                .collect(Collectors.toList());
        Assertions.assertThat(locationUuds).containsExactlyInAnyOrder(Locations.Location_ABD_UID, Locations.Location_National_UID);

        List<String> locationNames = filtered.stream()
                .map(DarRuleLocationsModel::getLocationName)
                .collect(Collectors.toList());
        Assertions.assertThat(locationNames).containsExactlyInAnyOrder("ABD", "National Office");

        filtered.forEach(dataTablesModel ->
        {
            Assertions.assertThat(dataTablesModel.getType()).isEqualTo(DarEventType.RULE_LOCATIONS.toString());
            Assertions.assertThat(dataTablesModel.getPackageUuid())
                    .isEqualTo(publishEvent.getPublishEventId().toString());
            Assertions.assertThat(dataTablesModel.getRuleVersionId()).isEqualTo("1");
        });
    }

    private void assertRuleBehavioursFile() {
        List<DarRuleBehavioursModel> filtered = darServicePublishingSupport.parseRuleBehavioursEvents()
                .stream().filter(
                        model -> matchFileListingsBasedPackageId(model.getRuleUuid()))
                .collect(Collectors.toList());

        Assertions.assertThat(filtered.size()).isEqualTo(3);

        List<String> narratives = filtered.stream()
                .map(DarRuleBehavioursModel::getNarrative)
                .collect(Collectors.toList());
        Assertions.assertThat(narratives).containsExactlyInAnyOrder( "Hold the goods", "Release the goods",  "Im informing you");

        List<String> actionTypes = filtered.stream()
                .map(DarRuleBehavioursModel::getDarActionType)
                .collect(Collectors.toList());
        Assertions.assertThat(actionTypes).containsExactlyInAnyOrder( "DOCUMENT_CHECK:HOLD", "DOCUMENT_CHECK:RELEASE",
                "INFORMATION_TASK:RELEASE");

        List<String> releasePercentages = filtered.stream()
                .map(DarRuleBehavioursModel::getReleasePercentage)
                .collect(Collectors.toList());
        Assertions.assertThat(releasePercentages).containsExactly( "0", "80", "");

        List<String> holdPercentages = filtered.stream()
                .map(DarRuleBehavioursModel::getHoldPercentage)
                .collect(Collectors.toList());
        Assertions.assertThat(holdPercentages).containsExactly( "20", "0", "0");

        filtered.forEach(
                behaviourModel -> {
                    Assertions.assertThat(behaviourModel.getIsSecretTask()).isEqualTo("false");
                }
        );

        Assertions.assertThat(filtered.get(0).getAssignee()).isEqualTo("NCH Open General Export Licence");
        Assertions.assertThat(filtered.get(1).getAssignee()).isEqualTo("NCH Open General Export Licence");
        Assertions.assertThat(filtered.get(2).getEmail()).isEqualTo("mr.tester@ce.gsi.gov.uk");
    }

    private boolean matchFileListingsBasedPackageId(String ruleId) {
        return ruleId.equals(this.ruleId);
    }
}
