package TestCases.UI.DataTables;

import API.DataForTests.DataTables;
import API.DataForTests.TestDataTableModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_DataTables;
import Categories_CDSRisk.CDS_Risk_UI_DataTables_1;
import Categories_CDSRisk.ChangeRequest;
import FunctionsLibrary.Utils;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.Pages.DataManagement.DataTableData_Page;
import UI.Pages.DataManagement.DataTableSummary_Page;
import UI.Pages.DataManagement.EditDataTable_Page;
import UI.Pages.DataManagement.ListDataTable_Page;
import UI.Utils.Navigation;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.openqa.selenium.Keys;

import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_DataTables.class, CDS_Risk_UI_DataTables_1.class})
public class TestCase_EditDataTable extends BaseUIWebDriverTestCase {

    private TestDataTableModel.TableDetails tableDetailsFreeText;
    private TestUserModel.UserDetails userDetails;

    @Before
    public void Setup() {

        this.userDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetails);

        tableDetailsFreeText = DataTables.DataTable_FreeText_Valid();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsFreeText);
        tableDetailsFreeText.uuid = createDataTableResponse.uuid;
        tableDetailsFreeText.uniqueId = createDataTableResponse.uniqueId;
    }

    @Category({ChangeRequest.CR_1712.class, ChangeRequest.CR_3063.class})
    @Test
    public void WhenRuleManagerLoggedIn_CanAddDataItemsToDataTableFreeText() {

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page ListDataTable_Page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = ListDataTable_Page.clickTableSummaryForSpecifiedDataTableID(tableDetailsFreeText.uniqueId);

        //Act
        dataTableSummary_page.dataTab.click();
        DataTableData_Page dataTableTab_page = new DataTableData_Page(driver);
        EditDataTable_Page editDataTable_page = dataTableTab_page.clickEditDataTableButton();

        editDataTable_page.setAddItem("item one");
        editDataTable_page.addItem.click();
        dataTableSummary_page.waitForAngularRequestsToFinish();

        editDataTable_page.setAddItem("item two");
        editDataTable_page.addItem.click();
        dataTableSummary_page.waitForAngularRequestsToFinish();

        editDataTable_page.setAddItem("item two");
        editDataTable_page.addItem.click();
        dataTableSummary_page.waitForAngularRequestsToFinish();

        assertEquals("The data contains 0 valid item(s) and 1 invalid/duplicate item(s).",dataTableTab_page.dataTableError.getText());

        //assert
        List<EditDataTable_Page.DataTableItemObject> listDataTableItemsObjects = editDataTable_page.getListDataTableItems();

        int iDataItems = listDataTableItemsObjects.size();
        assertEquals("Expect 2 data items", 2, iDataItems);

        assertEquals("item one", listDataTableItemsObjects.get(0).name);
        assertEquals("item two", listDataTableItemsObjects.get(1).name);

        editDataTable_page.clickSaveButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        editDataTable_page.clickTableSummaryButton();
        dataTableSummary_page.waitForAngularRequestsToFinish();

        DataTableSummary_Page dataTableSummaryPage = new DataTableSummary_Page(driver);
        assertEquals("Showing 1-2 of 2 Data Items", dataTableSummaryPage.dataRowCount.getText());
    }

    @Test
    public void WhenRuleManagerLoggedIn_CanAddBulkDataItemsToDataTable() {

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page ListDataTable_Page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = ListDataTable_Page.clickTableSummaryForSpecifiedDataTableID(tableDetailsFreeText.uniqueId);

        //Act
        dataTableSummary_page.dataTab.click();
        DataTableData_Page dataTableTab_page = new DataTableData_Page(driver);
        EditDataTable_Page editDataTable_page = dataTableTab_page.clickEditDataTableButton();

        editDataTable_page.setBulkItems("line1\n" +
                "line2\n" +
                "line3");
        editDataTable_page.clickBulkAddButton();
        dataTableSummary_page.waitForAngularRequestsToFinish();
        editDataTable_page.scrollToViewTheElement(editDataTable_page.addItems);
        editDataTable_page.addItems.click();

       //assert
        List<EditDataTable_Page.DataTableItemObject> listDataTableItemsObjects = editDataTable_page.getListDataTableItems();

        int iDataItems = listDataTableItemsObjects.size();
        assertEquals("Expect 3 data items", 3, iDataItems);

        assertEquals("line1", listDataTableItemsObjects.get(0).name);
        assertEquals("line2", listDataTableItemsObjects.get(1).name);
        assertEquals("line3", listDataTableItemsObjects.get(2).name);

        editDataTable_page.clickSaveButton();
        dataTableSummary_page.waitForAngularRequestsToFinish();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        editDataTable_page.clickTableSummaryButton();
        dataTableSummary_page.waitForAngularRequestsToFinish();
        DataTableSummary_Page dataTableSummaryPage = new DataTableSummary_Page(driver);
        assertEquals("Showing 1-3 of 3 Data Items", dataTableSummaryPage.dataRowCount.getText());
    }

    @Test
    public void WhenRuleManagerLoggedIn_CanRemoveDataItemFromDataTable() {

        //Arrange
        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(tableDetailsFreeText.uniqueId);
        tableDetailsFreeText.opLockVersion = responseDetail.opLockVersion;

        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetailsFreeText);

        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page ListDataTable_Page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = ListDataTable_Page.clickTableSummaryForSpecifiedDataTableID(tableDetailsFreeText.uniqueId);

        //Act
        dataTableSummary_page.dataTab.click();
        DataTableData_Page dataTableTab_page = new DataTableData_Page(driver);
        EditDataTable_Page editDataTable_page = dataTableTab_page.clickEditDataTableButton();

        List<EditDataTable_Page.DataTableItemObject> listDataTableItemsObjects = editDataTable_page.getListDataTableItems();

        int iDataItems = listDataTableItemsObjects.size();

        editDataTable_page.selectActionsDataItem(editDataTable_page.delete);

        editDataTable_page.clickSaveButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        //assert
        DataTableData_Page dataTableData_Page = new DataTableData_Page(driver);
        List<String> dataItems = dataTableData_Page.getListOfDataItems();

        DataTableData_Page.DataTableDataObject dataTableDataObject = dataTableData_Page.getDataItemsDetail();

        assertEquals("Expecting 1 data item", iDataItems - 1, dataItems.size());
        assertTrue(dataTableDataObject.dataTypeHeader.endsWith(tableDetailsFreeText.dataType));
        // assertEquals(tableDetailsFreeText.dataValidation, dataTableDataObject.dataValidation);
    }

    @Category({ChangeRequest.CR_1480.class, ChangeRequest.CR_1442.class, ChangeRequest.CR_3063.class})
    @Test
    public void WhenRuleManagerLoggedIn_CanEditDataItemFromDataTable() {

        //Arrange
        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(tableDetailsFreeText.uniqueId);
        tableDetailsFreeText.opLockVersion = responseDetail.opLockVersion;

        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetailsFreeText);

        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page ListDataTable_Page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = ListDataTable_Page.clickTableSummaryForSpecifiedDataTableID(tableDetailsFreeText.uniqueId);

        //Act
        dataTableSummary_page.dataTab.click();
        DataTableData_Page dataTableTab_page = new DataTableData_Page(driver);
        EditDataTable_Page editDataTable_page = dataTableTab_page.clickEditDataTableButton();

        List<EditDataTable_Page.DataTableItemObject> listDataTableItemsObjects = editDataTable_page.getListDataTableItems();

        int iDataItems = listDataTableItemsObjects.size();

        listDataTableItemsObjects = editDataTable_page.getListDataTableItems();
        editDataTable_page.scrollToViewTheElement(listDataTableItemsObjects.get(0).editDataItem);
        listDataTableItemsObjects.get(0).editDataItem.click();
        editDataTable_page.waitForAngularRequestsToFinish();
        editDataTable_page.dataInputTextField.sendKeys(Keys.CONTROL, "a", Keys.DELETE);
        editDataTable_page.dataInputTextField.sendKeys("0001000000");
        editDataTable_page.scrollToViewTheElement(editDataTable_page.saveDataItem);
        editDataTable_page.saveDataItem.click();

        listDataTableItemsObjects = editDataTable_page.getListDataTableItems();

        assertEquals("0001000000", listDataTableItemsObjects.get(0).name);

        editDataTable_page.clickSaveButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        //assert
        DataTableData_Page dataTableData_Page = new DataTableData_Page(driver);
        List<String> dataItems = dataTableData_Page.getListOfDataItems();

        DataTableData_Page.DataTableDataObject dataTableDataObject = dataTableData_Page.getDataItemsDetail();

        assertEquals("0001000000", dataItems.get(0));
        assertEquals(iDataItems, dataItems.size());
        assertTrue(dataTableDataObject.dataTypeHeader.endsWith(tableDetailsFreeText.dataType));
        //assertEquals(tableDetailsFreeText.dataValidation, dataTableDataObject.dataValidation);
    }

    @Category({ChangeRequest.CR_1712.class, ChangeRequest.CR_3063.class,ChangeRequest.CR_3184.class})
    @Test
    public void WhenBulkDataItemsContainsValidAndInvalidItems_OnlyValidItemsAreAddedToDataTable() {

        //Arrange
        TestDataTableModel.TableDetails tableDetailsComCode;
        tableDetailsComCode = DataTables.DataTable_CommodityCodes_InvalidMixedOrder();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsComCode);
        tableDetailsComCode.uuid = createDataTableResponse.uuid;
        tableDetailsComCode.uniqueId = createDataTableResponse.uniqueId;

        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page ListDataTable_Page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = ListDataTable_Page.clickTableSummaryForSpecifiedDataTableID(tableDetailsComCode.uniqueId);

        //Act
        dataTableSummary_page.dataTab.click();
        DataTableData_Page dataTableTab_page = new DataTableData_Page(driver);
        EditDataTable_Page editDataTable_page = dataTableTab_page.clickEditDataTableButton();

        editDataTable_page.setBulkItems("0100000000\n" +
                "0200000000\n" +
                "0300000000\n" +
                "0300000000\n" +
                "11111111111\n" + //invalid
                "0400000000");

        editDataTable_page.clickBulkAddButton();
        dataTableSummary_page.waitForAngularRequestsToFinish();
        assertEquals("The data contains 4 valid item(s) and 2 invalid/duplicate item(s).\n" +
                "Add 4 Item(s)",dataTableTab_page.dataTableError.getText());

        editDataTable_page.scrollToViewTheElement(editDataTable_page.notificationMessageLink);
        editDataTable_page.notificationMessageLink.click();
        dataTableSummary_page.waitForAngularRequestsToFinish();

        List<String> invalidItems = editDataTable_page.getListOfInvalidItems();
        String[] expBulkItemsToNotBeAdded = {"11111111111","0300000000"};
        assertThat(invalidItems).containsOnly(expBulkItemsToNotBeAdded);
        Dialog_Confirm dialog = new Dialog_Confirm(driver);
        dialog.clickCancelButton();
        dataTableSummary_page.waitForAngularRequestsToFinish();

        editDataTable_page.scrollToViewTheElement(editDataTable_page.addItems);
        editDataTable_page.addItems.click();
        List<EditDataTable_Page.DataTableItemObject> listDataTableItemsObjects = editDataTable_page.getListDataTableItems();
        int iDataItems = listDataTableItemsObjects.size();
        assertEquals("Expect 4 data items", 4, iDataItems);


        assertEquals("0100000000", listDataTableItemsObjects.get(0).name);
        assertEquals("0200000000", listDataTableItemsObjects.get(1).name);
        assertEquals("0300000000", listDataTableItemsObjects.get(2).name);
        assertEquals("0400000000", listDataTableItemsObjects.get(3).name);
    }

    @Category({ChangeRequest.CR_1764.class, ChangeRequest.CR_1752.class})
    @Test
    @Ignore("Will be fixed as part of CR-3194")
    public void WhenBulkDataItemsWithValidAndInvalidItems_OnlyValidItemsAreAddedToDataTable() {

        //Arrange
        TestDataTableModel.TableDetails tableDetailsComCode;
        tableDetailsComCode = DataTables.DataTable_PartCommodityCodes();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsComCode);
        tableDetailsComCode.uuid = createDataTableResponse.uuid;
        tableDetailsComCode.uniqueId = createDataTableResponse.uniqueId;

        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page ListDataTable_Page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = ListDataTable_Page.clickTableSummaryForSpecifiedDataTableID(tableDetailsComCode.uniqueId);

        //Act
        dataTableSummary_page.dataTab.click();
        DataTableData_Page dataTableTab_page = new DataTableData_Page(driver);
        EditDataTable_Page editDataTable_page = dataTableTab_page.clickEditDataTableButton();

        editDataTable_page.setBulkItems("0100000000\n" +
                "0\n" +
                "999£&)999\n" + //invalid
                "0300000000\n" +
                "12345678901\n" + //invalid
                "04000");

        editDataTable_page.clickBulkAddButton();

        //assert
        List<EditDataTable_Page.DataTableItemObject> listDataTableItemsObjects = editDataTable_page.getListDataTableItems();

        int iDataItems = listDataTableItemsObjects.size();
        assertEquals("Expect 4 data items", 4, iDataItems);

        String actBulkItemsNotAdded = editDataTable_page.getBulkItems();
        String errorMessage = editDataTable_page.getErrorMessage();

        String expBulkItemsToNotBeAdded = "999£&)999\n" +
                "12345678901";

        assertEquals(expBulkItemsToNotBeAdded, actBulkItemsNotAdded);
        assertEquals("The invalid items have not been added.", errorMessage);

        assertEquals("0100000000", listDataTableItemsObjects.get(0).name);
        assertEquals("0", listDataTableItemsObjects.get(1).name);
        assertEquals("0300000000", listDataTableItemsObjects.get(2).name);
        assertEquals("04000", listDataTableItemsObjects.get(3).name);
        assertFalse("save button should be not be enabled", editDataTable_page.save.isEnabled());

    }

    @Category({ChangeRequest.CR_1764.class, ChangeRequest.CR_1752.class, ChangeRequest.CR_3063.class})
    @Test
    @Ignore("Will be fixed as part of CR-3194")
    public void WhenBulkDataItems_CanOnlySaveTableWhenInvalidItemsRemoved() {

        //Arrange
        TestDataTableModel.TableDetails tableDetailsComCode;
        tableDetailsComCode = DataTables.DataTable_PartCommodityCodes();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsComCode);
        tableDetailsComCode.uuid = createDataTableResponse.uuid;
        tableDetailsComCode.uniqueId = createDataTableResponse.uniqueId;

        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page ListDataTable_Page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = ListDataTable_Page.clickTableSummaryForSpecifiedDataTableID(tableDetailsComCode.uniqueId);

        //Act
        dataTableSummary_page.dataTab.click();
        DataTableData_Page dataTableTab_page = new DataTableData_Page(driver);
        EditDataTable_Page editDataTable_page = dataTableTab_page.clickEditDataTableButton();

        editDataTable_page.setBulkItems("0100000000\n" +
                "0\n" +
                "999£&)999\n" + //invalid
                "0300000000\n" +
                "12345678901\n" + //invalid
                "04000");

        editDataTable_page.clickBulkAddButton();
        assertFalse("save button should be be enabled", editDataTable_page.save.isEnabled());

        editDataTable_page.clearBulkItemsField();
        editDataTable_page.clickSaveButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        //assert
        editDataTable_page.clickTableSummaryButton();
        DataTableSummary_Page dataTableSummaryPage = new DataTableSummary_Page(driver);
        assertEquals("Showing 1-4 of 4 Data Items", dataTableSummaryPage.dataRowCount.getText());
    }

    @Category({ChangeRequest.CR_1764.class, ChangeRequest.CR_1752.class, ChangeRequest.CR_3063.class})
    @Test
    @Ignore("Will be fixed as part of CR-3194")
    public void WhenSingleInvalidDataItemAdded_CanOnlySaveTableWhenValidItemAdded() {

        //Arrange
        TestDataTableModel.TableDetails tableDetailsComCode;
        tableDetailsComCode = DataTables.DataTable_PartCommodityCodes();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsComCode);
        tableDetailsComCode.uuid = createDataTableResponse.uuid;
        tableDetailsComCode.uniqueId = createDataTableResponse.uniqueId;

        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page ListDataTable_Page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = ListDataTable_Page.clickTableSummaryForSpecifiedDataTableID(tableDetailsComCode.uniqueId);

        //Act
        dataTableSummary_page.dataTab.click();
        DataTableData_Page dataTableTab_page = new DataTableData_Page(driver);
        EditDataTable_Page editDataTable_page = dataTableTab_page.clickEditDataTableButton();

        editDataTable_page.setAddItem("abcdef");
        editDataTable_page.addItem.click();
        assertFalse("save button should be disabled", editDataTable_page.save.isEnabled());

        editDataTable_page.setAddItem("");
        editDataTable_page.setAddItem("1234567890");
        editDataTable_page.clickAddItemButton();
        editDataTable_page.clickSaveButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        //assert
        editDataTable_page.clickTableSummaryButton();
        DataTableSummary_Page dataTableSummaryPage = new DataTableSummary_Page(driver);
        assertEquals("Showing 1-1 of 1 Data Items", dataTableSummaryPage.dataRowCount.getText());
    }

    @Category({ChangeRequest.CR_1764.class, ChangeRequest.CR_1752.class, ChangeRequest.CR_2217.class, ChangeRequest.CR_3063.class})
    @Test
    @Ignore("This test needs to be investigated as it is failing only in jenkins")
    public void WhenTableHeaderDetailsModified_TableSavedSuccessfully() {

        //Arrange
        TestDataTableModel.TableDetails tableDetailsWithTags;
        tableDetailsWithTags = DataTables.DataTable_ValidTags();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsWithTags);
        tableDetailsWithTags.uuid = createDataTableResponse.uuid;
        tableDetailsWithTags.uniqueId = createDataTableResponse.uniqueId;

        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page ListDataTable_Page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = ListDataTable_Page.clickTableSummaryForSpecifiedDataTableID(tableDetailsWithTags.uniqueId);

        //Act
        dataTableSummary_page.updateDetails.click();

        dataTableSummary_page.waitForAngularRequestsToFinish();

        String tableTitle = "ta_" + UUID.randomUUID().toString().substring(0, 9);
        String tableDescription = "Changed table description";
        String tag = "New tag added";
        String reason = "editing header details";
        dataTableSummary_page.setPopupTableTitle(tableTitle);

        dataTableSummary_page.setPopupTableDescription(tableDescription);
        dataTableSummary_page.removeTags();
        dataTableSummary_page.addTagsToTableHeader(Lists.newArrayList(tag));
        dataTableSummary_page.setReasonForTableHeader(reason);
        dataTableSummary_page.popupSave.click();

        dataTableSummary_page.waitForAngularRequestsToFinish();

        //assert
        assertEquals(tableTitle, dataTableSummary_page.title.getText());
        assertEquals(tableDescription, dataTableSummary_page.description.getText());
        assertEquals(tag, dataTableSummary_page.tags.getText());
    }

    @Category({ChangeRequest.CR_1764.class, ChangeRequest.CR_1752.class, ChangeRequest.CR_3063.class})
    @Test
    @Ignore("This test needs to be investigated as it is failing only in jenkins")
    public void WhenTableHeaderDetailsModifiedWithIncorrectValues_TableNotSaved() {

        //Arrange
        TestDataTableModel.TableDetails tableDetailsWithTags;
        tableDetailsWithTags = DataTables.DataTable_ValidTags();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsWithTags);
        tableDetailsWithTags.uuid = createDataTableResponse.uuid;
        tableDetailsWithTags.uniqueId = createDataTableResponse.uniqueId;

        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page ListDataTable_Page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = ListDataTable_Page.clickTableSummaryForSpecifiedDataTableID(tableDetailsWithTags.uniqueId);
        dataTableSummary_page.updateDetails.click();
        Utils.SleepForMilliSeconds(1000);
        //Act

        dataTableSummary_page.waitForAngularRequestsToFinish();

        String tableTitle = "ta_" + UUID.randomUUID().toString().substring(0, 2);
        String tableDescription = "Invalid";
        String tag = "New tag added";
        dataTableSummary_page.setPopupTableTitle(tableTitle);
        dataTableSummary_page.setPopupTableDescription(tableDescription);
        dataTableSummary_page.removeTags();
        dataTableSummary_page.addTagsToTableHeader(Lists.newArrayList(tag));
        dataTableSummary_page.popupSave.click();

        dataTableSummary_page.waitForAngularRequestsToFinish();

        assertFalse("Save button must be disabled", dataTableSummary_page.popupSave.isEnabled());

        dataTableSummary_page.popupCancel.click();

        dataTableSummary_page.waitForAngularRequestsToFinish();

        //assert
        assertEquals(tableDetailsWithTags.tableName, dataTableSummary_page.title.getText());
        assertEquals(tableDetailsWithTags.description, dataTableSummary_page.description.getText());
    }

    @Category({ChangeRequest.CR_1478.class, ChangeRequest.CR_3063.class,ChangeRequest.CR_3184.class})
    @Test
    public void WhenRuleManagerUpdatesADataTableWithNewData_NewDataRowCountIsDisplayedInSummaryPage() {

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page ListDataTable_Page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = ListDataTable_Page.clickTableSummaryForSpecifiedDataTableID(tableDetailsFreeText.uniqueId);
        assertEquals("Expect data items are 0 ", "There are no data items added to this table.", dataTableSummary_page.dataItemsEmptyMessage.getText());

        //Act
        dataTableSummary_page.dataTab.click();
        DataTableData_Page dataTableTab_page = new DataTableData_Page(driver);
        EditDataTable_Page editDataTable_page = dataTableTab_page.clickEditDataTableButton();

        editDataTable_page.setBulkItems(
                "0100000000\n" +
                        "0\n" +
                        "0300000000\n" +
                        "0300000000\n" +
                        "123456872\n" +
                        "12006872\n" +
                        "00456872\n" +
                        "000000\n" +
                        "04000");

        editDataTable_page.clickBulkAddButton();

        dataTableSummary_page.waitForAngularRequestsToFinish();
        assertEquals("The data contains 8 valid item(s) and 1 invalid/duplicate item(s).\n" +
                "Add 8 Item(s)",dataTableTab_page.dataTableError.getText());

        editDataTable_page.scrollToViewTheElement(editDataTable_page.addItems);

        editDataTable_page.addItems.click();

          //Assert
        editDataTable_page.clickSaveButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        //Assert
        editDataTable_page.clickTableSummaryButton();
        DataTableSummary_Page dataTableSummaryPage = new DataTableSummary_Page(driver);
        assertEquals("Showing 1-8 of 8 Data Items", dataTableSummaryPage.dataRowCount.getText());
    }
}
