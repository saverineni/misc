package TestCases.RulesManagementService;

import API.DataForTests.TestEnumerators;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Users.UserHistory.UserHistoryResponse;
import API.RulesManagementService.Utils.Users;
import Categories_CDSRisk.CDS_RM_UserManagement;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import com.google.common.collect.ImmutableList;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.springframework.http.HttpStatus;

import java.util.List;

import static API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.UsersMeResponseObject;
import static API.RulesManagementService.Utils.Users.UpdateStatusOfUser;

@Category({Rules_Management.class, CDS_RM_UserManagement.class, ChangeRequest.CR_2245.class})
public class TestCase_UserManagement_UserHistory extends BaseWebAPITestCase {
    private static final String DATE_TIME_PATTERN = "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}\\.[0-9]{0,3}Z";
    private static final String CREATE_USER_CHANGE_TYPE = "Creation";
    private static final String CREATE_USER_REASON = "User created";

    private TestUserModel.UserDetails loggedInUserDetails;

    @Before
    public void Setup() {
        loggedInUserDetails = Users_API.DefaultSuperAdminUser();
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
    }

    @Test
    public void WhenUserCreated_CreatedUserInAuditHistory() {
        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        // Act
        UserHistoryResponse.UserHistoryResponseObject userHistoryResponseObject = Users.GetListOfUserHistory(userDetails.pid);
        List<UserHistoryResponse.UserHistoryResponseObject.UserHistory> userHistoryResponseList =
                userHistoryResponseObject.userHistoryResponseList;

        // Assert
        Assertions.assertThat(userHistoryResponseList.get(0).changeType).isEqualTo(CREATE_USER_CHANGE_TYPE);
        Assertions.assertThat(userHistoryResponseList.get(0).updaterName).isEqualTo(loggedInUserDetails.getFullName());
        Assertions.assertThat(userHistoryResponseList.get(0).updaterPid).isEqualTo(loggedInUserDetails.pid);
        Assertions.assertThat(userHistoryResponseList.get(0).reason).isEqualTo(CREATE_USER_REASON);
        Assertions.assertThat(userHistoryResponseList.get(0).version).isEqualTo(1);
        Assertions.assertThat(userHistoryResponseList.get(0).updatedTimestamp).matches(DATE_TIME_PATTERN);
    }

    @Test
    public void WhenUserEdited_EditedChangesAreInAuditHistory() {
        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        userDetails.alternativeEmail = "john.doe@hmrc.gsi.gov.uk";
        userDetails.reason = "Changed email";

        UsersMeResponseObject userResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = userResponseObject1.opLockVersion;

        API.RulesManagementService.Utils.Users.EditUser(userDetails);

        // Act
        UserHistoryResponse.UserHistoryResponseObject userHistoryResponseObject = Users.GetListOfUserHistory(userDetails.pid);
        List<UserHistoryResponse.UserHistoryResponseObject.UserHistory> userHistoryResponseList =
                userHistoryResponseObject.userHistoryResponseList;

        // Assert

        // expected edit user history:
        TestUserModel.UserDetails userDetailsUpdate = new TestUserModel.UserDetails();
        userDetailsUpdate.changeType = "Edit User";
        userDetailsUpdate.updaterName = loggedInUserDetails.getFullName();
        userDetailsUpdate.updaterPid = loggedInUserDetails.pid;
        userDetailsUpdate.reason = userDetails.reason;
        userDetailsUpdate.version = 2;

        TestUserModel.UserDetails userDetailsCreate = new TestUserModel.UserDetails();
        userDetailsCreate.changeType = CREATE_USER_CHANGE_TYPE;
        userDetailsCreate.updaterName = loggedInUserDetails.getFullName();
        userDetailsCreate.updaterPid = loggedInUserDetails.pid;
        userDetailsCreate.reason = CREATE_USER_REASON;
        userDetailsCreate.version = 1;

        Assertions.assertThat(userHistoryResponseList.size()).isEqualTo(2);

        assertHistory(userHistoryResponseList, ImmutableList.of(userDetailsUpdate, userDetailsCreate));
    }

    @Test
    public void WhenRetrievingHistoryForNonExistingUser_Then404Returned() {
        // Arrange
        String randomPid = "7777777";

        // Act
        UserHistoryResponse.UserHistoryResponseObject userHistoryResponseObject = Users.GetListOfUserHistory(randomPid);

        //Assert
        Assertions.assertThat(userHistoryResponseObject.httpStatusCode).isEqualTo(HttpStatus.NOT_FOUND.value());
    }


    @Test
    public void WhenUserSuspendedReinstatedAndArchived_UserAuditHistoryUpdated() {
        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_SUSPEND.apiAction, "suspended reason");
        UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_REINSTATE.apiAction, "reinstated reason");
        UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_ARCHIVE.apiAction, "archived reason");

        // Act
        UserHistoryResponse.UserHistoryResponseObject userHistoryResponseObject = Users.GetListOfUserHistory(userDetails.pid);
        List<UserHistoryResponse.UserHistoryResponseObject.UserHistory> userHistoryResponseList =
                userHistoryResponseObject.userHistoryResponseList;

        // Assert

        // expected edit user history:
        TestUserModel.UserDetails userDetailsArchive = new TestUserModel.UserDetails();
        userDetailsArchive.changeType = "Archive User";
        userDetailsArchive.updaterName = loggedInUserDetails.getFullName();
        userDetailsArchive.updaterPid = loggedInUserDetails.pid;
        userDetailsArchive.reason = "archived reason";
        userDetailsArchive.version = 4;

        TestUserModel.UserDetails userDetailsReinstate = new TestUserModel.UserDetails();
        userDetailsReinstate.changeType = "Reinstate User";
        userDetailsReinstate.updaterName = loggedInUserDetails.getFullName();
        userDetailsReinstate.updaterPid = loggedInUserDetails.pid;
        userDetailsReinstate.reason = "reinstated reason";
        userDetailsReinstate.version = 3;

        TestUserModel.UserDetails userDetailsSuspend = new TestUserModel.UserDetails();
        userDetailsSuspend.changeType = "Suspend User";
        userDetailsSuspend.updaterName = loggedInUserDetails.getFullName();
        userDetailsSuspend.updaterPid = loggedInUserDetails.pid;
        userDetailsSuspend.reason = "suspended reason";
        userDetailsSuspend.version = 2;

        TestUserModel.UserDetails userDetailsCreate = new TestUserModel.UserDetails();
        userDetailsCreate.changeType = CREATE_USER_CHANGE_TYPE;
        userDetailsCreate.updaterName = loggedInUserDetails.getFullName();
        userDetailsCreate.updaterPid = loggedInUserDetails.pid;
        userDetailsCreate.reason = CREATE_USER_REASON;
        userDetailsCreate.version = 1;

        Assertions.assertThat(userHistoryResponseList.size()).isEqualTo(4);

        assertHistory(userHistoryResponseList, ImmutableList.of(userDetailsArchive, userDetailsReinstate, userDetailsSuspend, userDetailsCreate));
    }


    private void assertHistory(List<UserHistoryResponse.UserHistoryResponseObject.UserHistory> userHistoryResponseList,
                               List<TestUserModel.UserDetails> expectedUserDetails){
        int i = 0;

        for (UserHistoryResponse.UserHistoryResponseObject.UserHistory history : userHistoryResponseList) {
            Assertions.assertThat(expectedUserDetails.get(i).changeType).isEqualTo(history.changeType);
            Assertions.assertThat(expectedUserDetails.get(i).updaterName).isEqualTo(history.updaterName);
            Assertions.assertThat(expectedUserDetails.get(i).updaterPid).isEqualTo(history.updaterPid);
            Assertions.assertThat(expectedUserDetails.get(i).reason).isEqualTo(history.reason);
            Assertions.assertThat(expectedUserDetails.get(i).version).isEqualTo(history.version);
            Assertions.assertThat(history.updatedTimestamp).matches(DATE_TIME_PATTERN);
            i++;
        }
    }
}
