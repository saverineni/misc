package TestCases.UI.Rules;

import API.DataForTests.*;
import API.RulesManagementService.Utils.RuleAtStatus;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Rules_2;
import Categories_CDSRisk.CDS_Risk_UI_Users;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.PaginationToolBar;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Utils.Navigation;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;
import java.util.stream.IntStream;

import static FunctionsLibrary.Utils.SleepForMilliSeconds;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Users.class, CDS_Risk_UI_Rules_2.class})
public class TestCase_SortRules extends BaseUIWebDriverTestCase {
    private PaginationInfo paginationInfo;

    @Before
    public void setUp() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsNat1 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsNat1.descriptionStaticPrefix = "DraftRule";

        TestRuleModel.RuleDetails ruleDetailsLoc1 = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        ruleDetailsLoc1.descriptionStaticPrefix = "archived";

        TestRuleModel.RuleDetails ruleDetailsNat2 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsNat2.descriptionStaticPrefix = "ActiveRule";

        TestRuleModel.RuleDetails ruleDetailsLoc2 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsLoc2.descriptionStaticPrefix = "commited";

        TestRuleModel.RuleDetails ruleDetailsNat3 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsNat3.descriptionStaticPrefix = "pendingRule";


        TestRuleModel.RuleDetails ruleDetailsNat4 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsNat4.descriptionStaticPrefix = "Suspendedrule";

        TestRuleModel.RuleDetails ruleDetailsNat5 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsNat5.descriptionStaticPrefix = "expiredrule";


        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat1, TestEnumerators.RuleStatus.draft, 1);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat2, TestEnumerators.RuleStatus.active, 2);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat3, TestEnumerators.RuleStatus.pending, 1);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat4, TestEnumerators.RuleStatus.suspended, 1);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat5, TestEnumerators.RuleStatus.expired, 1);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsLoc1, TestEnumerators.RuleStatus.archived, 1);
        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetailsNat2, 2);

        publishAndWait(5000);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsLoc2, TestEnumerators.RuleStatus.committed, 2);
        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetailsLoc2, 4);

    }

    @Test
    @Category(ChangeRequest.CR_2566.class)
    public void WhenRuleTitleIsSortedInAscendingOrder_RuleTitleIsDisplayedInCorrectOrder() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);
        listRules_page.sortRuleTitle();
        List<ListRules_Page.ListRulesTableObject> listRulesTableObjects = listRules_page.getListOfRules();

        //Assert
        Assertions.assertThat(
                verifySortOrder(listRulesTableObjects, "description", "ASC")).isEqualTo(true);

    }

    @Test
    @Category(ChangeRequest.CR_2566.class)
    public void WhenRuleTitleIsSortedInDescendingOrder_RuleTitleIsDisplayedInCorrectOrder() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);
        listRules_page.sortRuleTitle();
        listRules_page.descSort();
        List<ListRules_Page.ListRulesTableObject> listRulesTableObjects = listRules_page.getListOfRules();
        //Assert
        Assertions.assertThat(
                verifySortOrder(listRulesTableObjects, "description", "DESC")).isEqualTo(true);

    }

    @Test
    @Category(ChangeRequest.CR_2566.class)
    public void WhenRuleIdIsSortedInDescendingOrder_RuleIdIsDisplayedInCorrectOrderInMultiplePages() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);
        listRules_page.sortRuleId();
        listRules_page.descSort();

        paginationInfo = new PaginationInfo();

        paginationInfo.iSizeOfPage = 5;
        paginationInfo.iElementsAdded = 0;
        paginationInfo = paginationInfo.calculatePaginationInfo(paginationInfo);
        PaginationToolBar paginationToolBar = new PaginationToolBar(driver);
        paginationToolBar.selectPageSize(paginationInfo.iSizeOfPage);
        SleepForMilliSeconds(500);
        List<ListRules_Page.ListRulesTableObject> listRulesTableObjects1 = listRules_page.getListOfRules();
        paginationToolBar.nextPage.click();
        SleepForMilliSeconds(500);
        List<ListRules_Page.ListRulesTableObject> listRulesTableObjects2 = listRules_page.getListOfRules();
        //Assert
        Assertions.assertThat(
                verifySortOrder(listRulesTableObjects1, "ruleId", "DESC")).isEqualTo(true);

        Assertions.assertThat(
                verifySortOrder(listRulesTableObjects2, "ruleId", "DESC")).isEqualTo(true);
    }

    private boolean verifySortOrder(List<ListRules_Page.ListRulesTableObject> rulesListTableObjects, String property, String order) {

        if (property.equals("description")) {
            return IntStream.range(0, rulesListTableObjects.size() - 1)
                    .allMatch(i -> {
                        String description1 = rulesListTableObjects.get(i).description.toLowerCase();
                        String description2 = rulesListTableObjects.get(i + 1).description.toLowerCase();
                        boolean sortedOrder = order.equals("DESC") ? description1.compareTo(description2) >= 0 : description1.compareTo(description2) <= 0;
                        return sortedOrder;
                    });

        } else if (property.equals("ruleId")) {
            return IntStream.range(0, rulesListTableObjects.size() - 1)
                    .allMatch(i -> {
                        String ruleId1 = rulesListTableObjects.get(i).ruleID;
                        String ruleId2 = rulesListTableObjects.get(i + 1).ruleID;
                        boolean sortedOrder = order.equals("DESC") ? ruleId1.compareTo(ruleId2) >= 0 : ruleId1.compareTo(ruleId2) <= 0;
                        return sortedOrder;
                    });

        }
        return false;
    }

}
