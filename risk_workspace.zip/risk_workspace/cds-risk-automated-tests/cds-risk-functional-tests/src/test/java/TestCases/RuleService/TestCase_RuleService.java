package TestCases.RuleService;


import API.DataForTests.TestRuleModel.RuleDetails;
import API.RulesService.CreateRule.CreateRuleResponse.PostResponse;
import API.RulesService.ViewRegimeCodesList.ViewRegimeCodeListResponse;
import API.RulesService.ViewRule.ViewRuleResponse.ViewRuleResponseObject;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rule_Service;
import TestCases.BaseWebAPITestCase;
import org.apache.commons.httpclient.HttpStatus;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;
import java.util.UUID;

import static API.DataForTests.Rules.DraftNatRuleNatManager;
import static API.DataForTests.Rules.DraftVersion2NatRuleNatManager;
import static API.RulesService.Utils.Rule.*;
import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.assertTrue;

@Category(Rule_Service.class)
public class TestCase_RuleService extends BaseWebAPITestCase {

    @Test
    @Category({ChangeRequest.CR_28.class, ChangeRequest.CR_38.class, ChangeRequest.CR_609.class})
    public void WhenValidRuleSubmitted_RuleCreatedSuccessfully() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = DraftNatRuleNatManager();

        //Act
        PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, createRuleResponse.httpStatusCode);
        Assertions.assertThat(createRuleResponse.ruleId).containsPattern(ruleDetails.ruleId);

        assertEquals(ruleDetails.description, createRuleResponse.description);
        assertEquals(ruleDetails.version, createRuleResponse.versionId);
        assertEquals(ruleDetails.status, createRuleResponse.status);
        assertEquals(ruleDetails.ruleOutputs.actionType, createRuleResponse.json.ruleOutputs.actionType);

        assertEquals(ruleDetails.queryConditions.get(0).conditions.get(0).attribute, createRuleResponse.json.query.get(0).query.get(0).attribute);
        assertEquals(ruleDetails.queryConditions.get(0).conditions.get(0).operator, createRuleResponse.json.query.get(0).query.get(0).operator);
        assertEquals(ruleDetails.queryConditions.get(0).conditions.get(0).value, createRuleResponse.json.query.get(0).query.get(0).value);

        assertEquals(ruleDetails.locations, createRuleResponse.locationUuids);
        assertEquals(ruleDetails.regimeCode, createRuleResponse.regime.regimeCodeName);
    }



    @Test
    @Category({ChangeRequest.CR_38.class, ChangeRequest.CR_609.class})
    public void WhenRuleSearchedByValidID_CorrectRuleReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = DraftNatRuleNatManager();
        PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleResponseObject viewRuleResponse = GetRuleByUID(createRuleResponse.uniqueId);

        //Assert
        assertEquals(HttpStatus.SC_OK, viewRuleResponse.httpStatusCode);

        Assertions.assertThat(viewRuleResponse.ruleId).containsPattern(ruleDetails.ruleId);
        assertEquals(ruleDetails.description, viewRuleResponse.versions.get(0).description);
        assertEquals(ruleDetails.version, viewRuleResponse.versions.get(0).versionId);
        assertEquals(ruleDetails.status, viewRuleResponse.versions.get(0).status);
        assertEquals(ruleDetails.ruleOutputs.actionType, createRuleResponse.json.ruleOutputs.actionType);

        assertEquals(ruleDetails.queryConditions.get(0).conditions.get(0).attribute, viewRuleResponse.versions.get(0).json.query.get(0).query.get(0).attribute);
        assertEquals(ruleDetails.queryConditions.get(0).conditions.get(0).operator, viewRuleResponse.versions.get(0).json.query.get(0).query.get(0).operator);
        assertEquals(ruleDetails.queryConditions.get(0).conditions.get(0).value, viewRuleResponse.versions.get(0).json.query.get(0).query.get(0).value);

        assertEquals(ruleDetails.locations, viewRuleResponse.versions.get(0).locationUuids);
        assertEquals(ruleDetails.regimeCode, viewRuleResponse.versions.get(0).regime.regimeCodeName);
    }

    @Test
    @Category({ChangeRequest.CR_38.class, ChangeRequest.CR_609.class})
    public void WhenNewRuleSearchedByIDAndVersion_CorrectRuleVersionReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = DraftNatRuleNatManager();
        PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        API.RulesService.ViewRuleVersion.ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponse = GetRuleByUIDAndVerions(createRuleResponse.uniqueId, ruleDetails.version);

        //Assert
        assertEquals(HttpStatus.SC_OK, viewRuleVersionResponse.httpStatusCode);

        Assertions.assertThat(viewRuleVersionResponse.ruleId).containsPattern(ruleDetails.ruleId);
        assertEquals(ruleDetails.description, viewRuleVersionResponse.description);
        assertEquals(ruleDetails.version, viewRuleVersionResponse.versionId);
        assertEquals(ruleDetails.status, viewRuleVersionResponse.status);
        assertEquals(ruleDetails.ruleOutputs.actionType, createRuleResponse.json.ruleOutputs.actionType);

        assertEquals(ruleDetails.queryConditions.get(0).conditions.get(0).attribute, viewRuleVersionResponse.json.query.get(0).query.get(0).attribute);
        assertEquals(ruleDetails.queryConditions.get(0).conditions.get(0).operator, viewRuleVersionResponse.json.query.get(0).query.get(0).operator);
        assertEquals(ruleDetails.queryConditions.get(0).conditions.get(0).value, viewRuleVersionResponse.json.query.get(0).query.get(0).value);

        assertEquals(ruleDetails.locations, viewRuleVersionResponse.locationUuids);
        assertEquals(ruleDetails.regimeCode, viewRuleVersionResponse.regime.regimeCodeName);
    }

    @Test
    @Category(ChangeRequest.CR_38.class)
    public void WhenRuleSearchedByInvalidID_NotFoundResponseReceived() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = DraftNatRuleNatManager();
        PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        String invalidUID = UUID.randomUUID().toString();

        //Act
        ViewRuleResponseObject viewRuleResponse = GetRuleByUID(invalidUID);

        //Assert
        assertEquals(HttpStatus.SC_NOT_FOUND, viewRuleResponse.httpStatusCode);
        assertEquals(String.format("Rule not found with uniqueId %s", invalidUID), viewRuleResponse.response.path("message"));
    }

    @Test
    @Category(ChangeRequest.CR_38.class)
    public void WhenRuleSearchedByInvalidVersion_NotFoundResponseReceived() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = DraftNatRuleNatManager();
        PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        int invalidVersion = 2;

        //Act
        API.RulesService.ViewRuleVersion.ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponse = GetRuleByUIDAndVerions(createRuleResponse.uniqueId, invalidVersion);

        //Assert
        assertEquals(HttpStatus.SC_NOT_FOUND, viewRuleVersionResponse.httpStatusCode);
        assertEquals(String.format("Rule not found with uniqueId %s and version %d", createRuleResponse.uniqueId,
                invalidVersion), viewRuleVersionResponse.response.path("message"));
    }


    @Test
    @Category(ChangeRequest.CR_38.class)
    public void WhenPreviousVersionOfRuleSearchedByIDAndVersion_CorrectRuleVersionReturned() throws Throwable {

        RuleDetails ruleDetails = DraftNatRuleNatManager();
        PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);

        RuleDetails ruleVer2Details = DraftVersion2NatRuleNatManager();
        ruleVer2Details.uniqueID = createRuleResponse.uniqueId;

        API.RulesService.EditRule.EditRuleResponse.PutResponse editRuleResponse = EditRuleAndGetResponseObject(ruleVer2Details);

        //Act
        API.RulesService.ViewRuleVersion.ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponse = GetRuleByUIDAndVerions(createRuleResponse.uniqueId, 1);

        //Assert
        assertEquals(HttpStatus.SC_OK, viewRuleVersionResponse.httpStatusCode);

        Assertions.assertThat(viewRuleVersionResponse.ruleId).containsPattern(ruleDetails.ruleId);
        assertEquals(ruleDetails.description, viewRuleVersionResponse.description);
        assertEquals(ruleDetails.version, viewRuleVersionResponse.versionId);
        assertEquals(ruleDetails.status, viewRuleVersionResponse.status);
        assertEquals(ruleDetails.ruleOutputs.actionType, viewRuleVersionResponse.json.ruleOutputs.actionType);

        assertEquals(ruleDetails.queryConditions.get(0).conditions.get(0).attribute, viewRuleVersionResponse.json.query.get(0).query.get(0).attribute);
        assertEquals(ruleDetails.queryConditions.get(0).conditions.get(0).operator, viewRuleVersionResponse.json.query.get(0).query.get(0).operator);
        assertEquals(ruleDetails.queryConditions.get(0).conditions.get(0).value, viewRuleVersionResponse.json.query.get(0).query.get(0).value);

        assertEquals(ruleDetails.locations, viewRuleVersionResponse.locationUuids);
        assertEquals(ruleDetails.regimeCode, viewRuleVersionResponse.regime.regimeCodeName);
    }

    @Test
    @Category(ChangeRequest.CR_609.class)
    public void WhenListOfRegimeCodesSelected_ListOfRegimeCodesReturned() throws Throwable
    {
        //Arrange

        //Act
        List<ViewRegimeCodeListResponse> regimeCodes = API.RulesService.Utils.RegimeCodes.GetListOfRegimeCodes();

        //Assert
        assertTrue("RegimeCodes: ", regimeCodes.size() > 0);
        assertEquals(HttpStatus.SC_OK, regimeCodes.get(0).httpStatusCode);
    }

}

