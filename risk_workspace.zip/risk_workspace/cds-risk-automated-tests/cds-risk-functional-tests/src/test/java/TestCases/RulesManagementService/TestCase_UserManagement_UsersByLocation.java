package TestCases.RulesManagementService;


import API.DataForTests.Locations;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Users.ViewUserListByLocation.ViewUserListByLocationResponse;
import API.RulesManagementService.Users.ViewUserListByLocation.ViewUserListByLocationResponse.ViewUserListByLocationResponseObject;
import Categories_CDSRisk.CDS_RM_UserManagement;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import org.apache.http.HttpStatus;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static API.RulesManagementService.Utils.Users.GetListOfUsersByBaseLocationUuid;
import static API.RulesManagementService.Utils.Users.LoginAsUser;
import static org.assertj.core.groups.Tuple.tuple;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_UserManagement.class})
public class TestCase_UserManagement_UsersByLocation extends BaseWebAPITestCase {

    TestUserModel.UserDetails userDetails_AdminNational;
    TestUserModel.UserDetails userDetails_SuperAdminNational;

    TestUserModel.UserDetails userDetails_SuperAdminLocal_POO;
    TestUserModel.UserDetails userDetails_AdminLocal_POO;
    TestUserModel.UserDetails userDetails_AdminLocal_POO_EXT;

    TestUserModel.UserDetails userDetails_RulesManagerNational;
    TestUserModel.UserDetails userDetails_RulesManagerLocal_POO;

    TestUserModel.UserDetails userDetails_RuleViewerNational;
    TestUserModel.UserDetails userDetails_RuleViewerLocal_POO;

    @Before
    public void Setup() {


    }


    @Test
    @Category({ChangeRequest.CR_1909.class, ChangeRequest.CR_2436.class})
    @Ignore("Will be fixed as part of CR-3392")
    public void WhenViewUsersFilteredByBaseLocation_CorrectUserDetailsReturned() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.DefaultSuperAdminUser();
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails_AdminLocal_POO_EXT = Users_API.AdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO_EXT);

        //Act
        ViewUserListByLocationResponseObject userFromPOO = GetListOfUsersByBaseLocationUuid(Locations.Location_POO_UID);

        //Assert
        Assertions.assertThat(userFromPOO.content)
                .hasSize(1)
                .extracting("highestLevelRole", "firstName", "lastName", "jobTitle", "locationCount", "status")
                .contains(tuple("LocalAdmin", "Firstname19", "Lastname19", "Local User", 2, "active"));

        Assertions.assertThat(userFromPOO.content)
                .extracting("baseLocation.locationName", "baseLocation.locationFullName", "baseLocation.locationType")
                .contains(tuple("POO", "Poole", "maritime"));

        Assertions.assertThat(userFromPOO.content.get(0).baseLocation.ports).hasSize(0);
    }


    @Test
    @Category({ChangeRequest.CR_2436.class})
    public void WhenViewUsersFilteredByBaseLocation_CorrectBaseLocationPortsDetailsReturned() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        LoginAsUser(userDetails.pid);

        TestUserModel.UserDetails userDetails_AdminLocal_WAT = Users_API.RulesManagerLocal_WAT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_WAT);

        //Act
        ViewUserListByLocationResponseObject userFromWAT = GetListOfUsersByBaseLocationUuid(Locations.Location_WAT_UID);

        //Assert
        Assertions.assertThat(userFromWAT.content)
                .extracting("baseLocation.locationName", "baseLocation.locationFullName", "baseLocation.locationType")
                .contains(tuple("WAT", "Watchet", "maritime"));

        Assertions.assertThat(userFromWAT.content.get(0).baseLocation.ports).hasSize(3)
            .contains("Appledore", "Bideford", "Bridgwater");
    }


    @Test
    @Category(ChangeRequest.CR_1909.class)
    public void WhenViewUsersFilteredByBaseLocation_CorrectListOfUserReturned() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.DefaultSuperAdminUser();
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails_AdminNational = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminNational);

        TestUserModel.UserDetails userDetails_SuperAdminNational = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_SuperAdminNational);

        TestUserModel.UserDetails userDetails_SuperAdminLocal_POO = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_SuperAdminLocal_POO);

        TestUserModel.UserDetails userDetails_AdminLocal_POO = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO);

        TestUserModel.UserDetails userDetails_AdminLocal_POO_EXT = Users_API.AdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO_EXT);

        TestUserModel.UserDetails userDetails_RulesManagerNational = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RulesManagerNational);

        TestUserModel.UserDetails userDetails_RulesManagerLocal_POO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RulesManagerLocal_POO);

        TestUserModel.UserDetails userDetails_RuleViewerNational = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RuleViewerNational);

        TestUserModel.UserDetails userDetails_RuleViewerLocal_POO = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RuleViewerLocal_POO);

        //Act
        ViewUserListByLocationResponseObject userFromPOO = GetListOfUsersByBaseLocationUuid(Locations.Location_POO_UID);
        ViewUserListByLocationResponseObject userFromNational = GetListOfUsersByBaseLocationUuid(Locations.Location_National_UID);
        ViewUserListByLocationResponseObject userFromFreightLocationEXT = GetListOfUsersByBaseLocationUuid(Locations.Location_EXT_UID);


        //Assert
        assertEquals(HttpStatus.SC_OK, userFromPOO.httpStatusCode);

        Assertions.assertThat(userFromPOO.content).extracting("baseLocationUuid")
                .hasSize(5)
                .containsOnly(Locations.Location_POO_UID);

        Assertions.assertThat(userFromNational.content).extracting("baseLocationUuid")
                .containsOnly(Locations.Location_National_UID);

        Assertions.assertThat(userFromFreightLocationEXT.content).extracting("baseLocationUuid")
                .hasSize(0);

    }


    @Test
    @Category(ChangeRequest.CR_1909.class)
    public void WhenViewUsersFilteredByBaseLocation_CorrectNoOfUniqueLocationsReturned() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.DefaultSuperAdminUser();
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails_AdminLocal_POO_EXT = Users_API.AdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO_EXT);

        TestUserModel.UserDetails userDetails_MixRoles = Users_API.UserWithAllRoles_MixLocations2();
        userDetails_MixRoles.baseLocation = "EXT";
        userDetails_MixRoles.baseLocationUuid = Locations.Location_EXT_UID;
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_MixRoles);

        //Act
        ViewUserListByLocationResponseObject userFromPOO = GetListOfUsersByBaseLocationUuid(Locations.Location_POO_UID);
        ViewUserListByLocationResponseObject userFromEXT = GetListOfUsersByBaseLocationUuid(Locations.Location_EXT_UID);

        //Assert

        Assertions.assertThat(userFromPOO.content).extracting("locationCount")
                .hasSize(1)
                .containsOnly(2);


        Assertions.assertThat(userFromEXT.content).extracting("locationCount")
                .hasSize(1)
                .containsOnly(4);   //ABD, RMG, ROS, WAR
    }


    @Test
    @Category(ChangeRequest.CR_1909.class)
    public void WhenViewUsersFilteredByBaseLocation_CorrectRoleNoneReturned() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.DefaultSuperAdminUser();
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails_MixRoles = Users_API.UserWithAllRoles_MixLocations2();
        userDetails_MixRoles.baseLocation = "EXT";
        userDetails_MixRoles.baseLocationUuid = Locations.Location_EXT_UID;
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_MixRoles);

        //Act
        ViewUserListByLocationResponseObject userFromEXT = GetListOfUsersByBaseLocationUuid(Locations.Location_EXT_UID);

        //Assert
        Assertions.assertThat(userFromEXT.content).extracting("highestLevelRole")
                .containsOnly("None");
    }

    @Test
    @Category(ChangeRequest.CR_1909.class)
    public void WhenViewUsersFilteredByBaseLocation_CorrectLocalRuleManagerReturned() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.DefaultSuperAdminUser();
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails_MixRoles = Users_API.UserWithAllRoles_MixLocations2();
        userDetails_MixRoles.baseLocation = "RMG";
        userDetails_MixRoles.baseLocationUuid = Locations.Location_RMG_UID;
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_MixRoles);

        //Act
        ViewUserListByLocationResponseObject userFromEXT = GetListOfUsersByBaseLocationUuid(Locations.Location_RMG_UID);

        //Assert
        Assertions.assertThat(userFromEXT.content).extracting("highestLevelRole")
                .containsOnly("LocalRuleManager");
    }


    @Test
    @Category(ChangeRequest.CR_1909.class)
    public void WhenViewUsersFilteredByBaseLocation_CorrectRoleLocalSuperAdminReturned() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.DefaultSuperAdminUser();
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails_MixRoles = Users_API.UserWithAllRoles_MixLocations2();
        userDetails_MixRoles.baseLocation = "ABD";
        userDetails_MixRoles.baseLocationUuid = Locations.Location_ABD_UID;
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_MixRoles);

        //Act
        ViewUserListByLocationResponseObject userFromABD = GetListOfUsersByBaseLocationUuid(Locations.Location_ABD_UID);

        //Assert
        Assertions.assertThat(userFromABD.content).extracting("highestLevelRole")
                .containsOnly("LocalSuperAdmin");
    }

    @Test
    @Category(ChangeRequest.CR_1909.class)
    public void WhenViewUsersFilteredByBaseLocation_CorrectRoleLocalRuleViewerReturned() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails_MixRoles = Users_API.UserWithAllRoles_MixLocations2();
        userDetails_MixRoles.baseLocation = "WAR";
        userDetails_MixRoles.baseLocationUuid = Locations.Location_WAR_UID;
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_MixRoles);

        //Act
        ViewUserListByLocationResponseObject userFromABD = GetListOfUsersByBaseLocationUuid(Locations.Location_WAR_UID);

        //Assert
        Assertions.assertThat(userFromABD.content).extracting("highestLevelRole")
                .containsOnly("LocalRuleViewer");
    }


    @Test
    @Category(ChangeRequest.CR_1909.class)
    public void WhenViewUsersFilteredByBaseLocationAllLocations_HighestLevelRoleLocalSuperAdminReturned() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.DefaultSuperAdminUser();
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails_MixRoles = Users_API.UserWithAllRoles_MixLocations2();
        userDetails_MixRoles.baseLocation = "WAT";
        userDetails_MixRoles.baseLocationUuid = Locations.Location_WAT_UID;
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_MixRoles);

        //Act
        ViewUserListByLocationResponseObject userFromABD = GetListOfUsersByBaseLocationUuid(Locations.Location_AllLocations_UID);

        //Assert
        List<ViewUserListByLocationResponse.Content> viewUserList = userFromABD.content;

        int i;
        for (i= 0; i < viewUserList.size(); i++)
        {
            if (viewUserList.get(i).pid.equals(userDetails_MixRoles.pid))
            { break;}
        }

        Assertions.assertThat(userFromABD.content.get(i)).extracting("highestLevelRole")
                .containsOnly("LocalSuperAdmin");
    }


}
