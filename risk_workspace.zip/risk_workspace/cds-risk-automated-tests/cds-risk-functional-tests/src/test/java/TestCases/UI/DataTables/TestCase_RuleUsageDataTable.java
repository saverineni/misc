package TestCases.UI.DataTables;


import API.DataForTests.TestDataTableModel;
import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.RuleAction.RuleActionResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_DataTables;
import Categories_CDSRisk.CDS_Risk_UI_DataTables_2;
import Categories_CDSRisk.ChangeRequest;
import FunctionsLibrary.DateTime;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.Pages.DataManagement.DataTableSummary_Page;
import UI.Pages.DataManagement.ListDataTable_Page;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Utils.Navigation;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.ConditionType;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import java.util.List;
import java.util.stream.IntStream;

import static API.DataForTests.DataTables.DataTable_CommodityCodes_NAT;
import static API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject;
import static API.RulesManagementService.Utils.RuleAtStatus.SuspendRule;
import static API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject;
import static FunctionsLibrary.Utils.SleepForMilliSeconds;
import static org.assertj.core.groups.Tuple.tuple;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_DataTables.class, CDS_Risk_UI_DataTables_2.class})
public class TestCase_RuleUsageDataTable extends BaseUIWebDriverTestCase {

    private TestDataTableModel.TableDetails tableDetailsFreeText;
    private TestUserModel.UserDetails userDetails;

    @Before
    public void Setup(){

        this.userDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetails);
    }

    @Category(ChangeRequest.CR_1680.class)
    @Test
    public void WhenNoRulesUsedByDataTable_RuleUsageDisplaysNoRules() {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleAndGetResponseObject(ruleDetails);

        TestDataTableModel.TableDetails tableDetails = DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listMyDataTables_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = listMyDataTables_page.clickTableSummaryForSpecifiedDataTableID(createDataTableResponse.uniqueId);

        //Act
        dataTableSummary_page.ruleUsageTab.click();
        String actMessage = dataTableSummary_page.ruleUsageNoRulesMessage.getText();

        //Assert
        assertEquals("There are no rules currently using this table.", actMessage);
    }


    @Category({ChangeRequest.CR_1680.class, ChangeRequest.CR_1771.class, ChangeRequest.CR_3063.class, ChangeRequest.CR_2239.class})
    @Test
    public void WhenRulesUsedByDataTable_RuleUsageDisplaysRulesAndSorted()
    {
        //Arrange
        //Rule 1 - Table 1 - Pending rule
        TestDataTableModel.TableDetails tableDetails = DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetailsForPendingRule = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsForPendingRule.description = "pending";
        ruleDetailsForPendingRule.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetailsForPendingRule.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        ruleDetailsForPendingRule.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(1, DateTime.DateTimeUTCZ);
        ruleDetailsForPendingRule.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(2, DateTime.DateTimeUTCZ);

        CreateRuleResponse.PostResponse response1 = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetailsForPendingRule);
        ruleDetailsForPendingRule.uniqueID = response1.uniqueId;
        ruleDetailsForPendingRule.ruleId = response1.ruleId;

        API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetailsForPendingRule, RuleVersionActions.commit);

        //Rule 2 - Table 2 - Draft Rule
        TestRuleModel.RuleDetails ruleDetailsForDraftRule = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsForDraftRule.description = "draft";
        ruleDetailsForDraftRule.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetailsForDraftRule.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        CreateRuleResponse.PostResponse createRuleResponse2 = CreateRuleAndGetResponseObject(ruleDetailsForDraftRule);
        ruleDetailsForDraftRule.uniqueID = createRuleResponse2.uniqueId;

        //Rule 3 - Table 3 - Suspended rule
        TestRuleModel.RuleDetails ruleDetailsForSuspendedRule = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsForSuspendedRule.description = "suspended";
        ruleDetailsForSuspendedRule.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetailsForSuspendedRule.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        CreateRuleResponse.PostResponse createRuleResponse3 = CreateRuleAndGetResponseObject(ruleDetailsForSuspendedRule);
        ruleDetailsForSuspendedRule.uniqueID = createRuleResponse3.uniqueId;
        ruleDetailsForSuspendedRule.ruleId = createRuleResponse3.ruleId;

        API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetailsForSuspendedRule, RuleVersionActions.commit);

        RuleActionResponse.PostResponse suspendResponse = SuspendRule(ruleDetailsForSuspendedRule);

        //Rule 4- Table 4 - Active rule
        TestRuleModel.RuleDetails ruleDetailsForAnActiveRule = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsForAnActiveRule.description = "active";
        ruleDetailsForAnActiveRule.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;
        ruleDetailsForAnActiveRule.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        CreateRuleResponse.PostResponse createRuleResponse4 = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetailsForAnActiveRule);
        ruleDetailsForAnActiveRule.uniqueID = createRuleResponse4.uniqueId;
        ruleDetailsForAnActiveRule.ruleId = createRuleResponse4.ruleId;

        API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetailsForAnActiveRule, RuleVersionActions.commit);

        publishAndWait(5000);

        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listMyDataTables_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = listMyDataTables_page.clickTableSummaryForSpecifiedDataTableID(createDataTableResponse.uniqueId);

        //Act
        dataTableSummary_page.ruleUsageTab.click();

        String actMessage = dataTableSummary_page.ruleUsingTableMessage.getText();

        ListRules_Page ruleUsageListRules_page = new ListRules_Page(driver);
        List<ListRules_Page.ListRulesTableObject> listOfRules = ruleUsageListRules_page.getListOfRulesAssociatedWithDataTable();

        //Assert
        assertEquals("There are currently 4 rules using the table " + tableDetails.tableName, actMessage);

        dataTableSummary_page.selectRuleSorting(dataTableSummary_page.sortRuleId);

        //Assert
        Assertions.assertThat(
                verifySortOrder(listOfRules, "ruleId", "ASC")).isEqualTo(true);

        dataTableSummary_page.selectRuleSorting(dataTableSummary_page.sortRuleDescription);

        ListRules_Page ruleUsageListRules_page2 = new ListRules_Page(driver);
        List<ListRules_Page.ListRulesTableObject> listOfRulesDescriptionAfterSorting = ruleUsageListRules_page2.getListOfRulesAssociatedWithDataTable();

        assertTrue("Expect Rule Description to be Active",
                listOfRulesDescriptionAfterSorting.get(0).description.contains("active"));

        assertTrue("Expect Rule Description to be draft",
                listOfRulesDescriptionAfterSorting.get(1).description.contains("draft"));

        assertTrue("Expect Rule Description to be draft",
                listOfRulesDescriptionAfterSorting.get(2).description.contains("pending"));

        assertTrue("Expect Rule Description to be draft",
                listOfRulesDescriptionAfterSorting.get(3).description.contains("suspended"));

        dataTableSummary_page.selectRuleSorting(dataTableSummary_page.sortRuleStatus);

        ListRules_Page ruleUsageListRules_page3 = new ListRules_Page(driver);
        List<ListRules_Page.ListRulesTableObject> listOfRulesStatusAfterSorting = ruleUsageListRules_page3.getListOfRulesAssociatedWithDataTable();
        SleepForMilliSeconds(500);

        assertEquals("Expect Lead Rule Status to be Draft", "Draft", listOfRulesStatusAfterSorting.get(0).status);

        assertEquals("Expect Lead Rule Status to be Pending", "Pending", listOfRulesStatusAfterSorting.get(1).status);

        assertEquals("Expect Lead Rule Status to be Active", "Active", listOfRulesStatusAfterSorting.get(2).status);

        assertEquals("Expect Lead Rule Status to be Suspended", "Suspended", listOfRulesStatusAfterSorting.get(3).status);
    }

    private boolean verifySortOrder(List<ListRules_Page.ListRulesTableObject> rulesListTableObjects, String property, String order) {

        if (property.equals("description")) {
            return IntStream.range(0, rulesListTableObjects.size() - 1)
                    .allMatch(i -> {
                        String description1 = rulesListTableObjects.get(i).description.toLowerCase();
                        String description2 = rulesListTableObjects.get(i + 1).description.toLowerCase();
                        boolean sortedOrder = order.equals("DESC") ? description1.compareTo(description2) >= 0 : description1.compareTo(description2) <= 0;
                        return sortedOrder;
                    });

        } else if (property.equals("ruleId")) {
            return IntStream.range(0, rulesListTableObjects.size() - 1)
                    .allMatch(i -> {
                        String ruleId1 = rulesListTableObjects.get(i).ruleID;
                        String ruleId2 = rulesListTableObjects.get(i + 1).ruleID;
                        boolean sortedOrder = order.equals("DESC") ? ruleId1.compareTo(ruleId2) >= 0 : ruleId1.compareTo(ruleId2) <= 0;//ruleId1.compareTo(ruleId2) <= 0 : ruleId1.compareTo(ruleId2) >= 0;
                        return sortedOrder;
                    });

        }
        return false;
    }
}
