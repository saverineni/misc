package TestCases.RiskingServiceJava.ActionType;

import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.Risking_JavaService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel.RuleOutputs;

@Slf4j
@Category({ChangeRequest_RiskingService.CREP_255.class, ChangeRequest_RiskingService.CREP_290.class,
        ChangeRequest_RiskingService.CREP_406.class, Risking_JavaService.class})
public class TestCase_DocumentCheck extends BaseActionTypeTest {

    @Test
    public void WhenRuleWithDocumentCheckHoldActionTypeIsHit_CorrectControlTypeIsSetAndReleaseIsBlocked() {

        //When
        RuleOutputs outputs = RuleOutputs.builder()
                                .actionType("2")
                                .holdNarrative(HOLD_NARRATIVE)
                                .assigneeId(ASSIGNEE_ID)
                                .build();

        //Then
        createRule(outputs);
        DeclarationResponse response = sendDeclaration( createDeclaration(), false);

        //Assert
        assertDeclarationResponse( response, expectedDocCheckHold());
    }

    @Test
    public void WhenRuleWithDocumentCheckReleaseActionTypeIsHit_CorrectControlTypeIsSetAndReleaseIsNotBlocked() {

        //When
        RuleOutputs outputs = RuleOutputs.builder()
                .actionType("3")
                .releaseNarrative(RELEASE_NARRATIVE)
                .assigneeId(ASSIGNEE_ID)
                .build();

        //Then
        createRule(outputs);
        DeclarationResponse response = sendDeclaration( createDeclaration(), false );

        //Assert
        assertDeclarationResponse( response, expectedDocCheckRelease());
    }
}
