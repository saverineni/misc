package TestCases.RulesManagementService;


import API.DataForTests.*;
import API.RulesManagementService.Data.EditDataTableData.EditDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import API.RulesManagementService.Data.ViewDataTableData.ViewDataTableDataResponse;
import API.RulesManagementService.Data.ViewDataTableList.ViewDataTableListResponse;
import Categories_CDSRisk.CDS_RM_DataTable;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import org.apache.commons.httpclient.HttpStatus;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static API.RulesManagementService.Utils.DataTables.GetDataTableDataItems;
import static API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_DataTable.class})
public class TestCase_Admin_DataTableArchive extends WebAPITestCaseWithDatatablesCleanup {

    TestUserModel.UserDetails userDetails_POO;
    TestUserModel.UserDetails userDetails_EXT;
    TestUserModel.UserDetails userDetails_NAT;

    TestDataTableModel.TableDetails tableDetailsPOO;
    TestDataTableModel.TableDetails tableDetailsEXT;
    TestDataTableModel.TableDetails tableDetailsEXTPOO;
    TestDataTableModel.TableDetails tableDetailsNational;
    String dataTableNationalUuid;
    String dataTablePooUniqueId;



    @Before
    public void LocalSetup()
    {
        //Login as User 1 create data table for POO
        userDetails_POO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_POO);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_POO.pid);
        tableDetailsPOO = DataTables.DataTable_CommodityCodes_POO();
        tableDetailsPOO.tableType= TestEnumerators.TableType.restricted.toString();
        API.DataService.CreateDataTable.CreateDataTableResponse.PostResponse createDataTableResponse = API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsPOO);
        tableDetailsPOO.uuid=createDataTableResponse.uuid;
        dataTablePooUniqueId=createDataTableResponse.uniqueId;

        //Login as User 2 create data table for EXT
        userDetails_EXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_EXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_EXT.pid);
        tableDetailsEXT = DataTables.DataTable_CommodityCodes_EXT();
        tableDetailsEXT.tableType= TestEnumerators.TableType.sensitive.toString();
        API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsEXT);

        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_EXT.pid);
        tableDetailsEXTPOO = DataTables.DataTable_CommodityCodes_POOEXT();
        API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsEXTPOO);

        userDetails_NAT = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_NAT);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_NAT.pid);

        tableDetailsNational = DataTables.DataTable_CommodityCodes_NAT();
        createDataTableResponse = API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsNational);
        tableDetailsNational.uuid=createDataTableResponse.uuid;;
        dataTableNationalUuid=createDataTableResponse.uuid;
    }

    @Test
    @Category(ChangeRequest.CR_2724.class)
    public void WhenSuperAdminNationalViewDataTableListPage_CorrectArchiveAccessShouldBeDisplayed() {
        // Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.SuperAdminNational());

       // Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables();

        //Assert
        assertThat(viewDataTableList.content).extracting("tableAccessLevel").containsOnly("Archiver");
    }

    @Test
    @Category(ChangeRequest.CR_2724.class)
    public void WhenAdminNationalViewDataTableListPage_CorrectArchiveAccessShouldBeDisplayed() {
        // Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());

        // Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables();

        //Assert
        assertThat(viewDataTableList.content).extracting("tableAccessLevel").containsOnly("Archiver");
    }

    @Test
    @Category(ChangeRequest.CR_2724.class)
    public void WhenLocalAdminPooViewDataTableListPage_CorrectArchiveAccessShouldBeDisplayed() {
        // Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminLocal_POO());

        // Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables();
        String dataTablePoo= getCanArchiveForTheDataTable(viewDataTableList,tableDetailsPOO.tableName);
        String dataTablePooExt= getCanArchiveForTheDataTable(viewDataTableList,tableDetailsEXTPOO.tableName);
        String dataTableExt= getCanArchiveForTheDataTable(viewDataTableList,tableDetailsEXT.tableName);
        String dataTableNational= getCanArchiveForTheDataTable(viewDataTableList,tableDetailsNational.tableName);

        //Assert
        assertEquals("Archiver",dataTablePoo);
        assertEquals("Archiver",dataTablePooExt);
        assertEquals("Not Shared",dataTableExt);
        assertEquals("Not Shared",dataTableNational);


    }

    @Test
    @Category(ChangeRequest.CR_2724.class)
    public void WhenLocalSuperAdminPooViewDataTableListPage_CorrectArchiveAccessShouldBeDisplayed() {
        // Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.SuperAdminLocal_POO());

        // Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables();
        String dataTablePoo= getCanArchiveForTheDataTable(viewDataTableList,tableDetailsPOO.tableName);
        String dataTablePooExt= getCanArchiveForTheDataTable(viewDataTableList,tableDetailsEXTPOO.tableName);
        String dataTableExt= getCanArchiveForTheDataTable(viewDataTableList,tableDetailsEXT.tableName);
        String dataTableNational= getCanArchiveForTheDataTable(viewDataTableList,tableDetailsNational.tableName);

        //Assert
        assertEquals("Archiver",dataTablePoo);
        assertEquals("Archiver",dataTablePooExt);
        assertEquals("Not Shared",dataTableExt);
        assertEquals("Not Shared",dataTableNational);


    }

    @Test
    @Category(ChangeRequest.CR_2724.class)
    public void WhenLoggedInAsAdminNational_CannotEditDataTable() {
        // Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(dataTableNationalUuid);
        //tableDetails.tableVersionUuid = responseDetail.tableVersionUuid;
        tableDetailsNational.opLockVersion = responseDetail.opLockVersion;

        //Act
        EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetailsNational);
        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableDataResponseObject = GetDataTableDataItems(tableDetailsNational.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_FORBIDDEN, responseEdit.httpStatusCode);

    }

    @Test
    @Category(ChangeRequest.CR_2724.class)
    public void WhenLoggedInAsSuperAdminNational_CannotEditDataTable() {
        // Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.SuperAdminNational());

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(tableDetailsPOO.uuid);
        tableDetailsNational.opLockVersion = responseDetail.opLockVersion;

        //Act
        EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetailsPOO);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_FORBIDDEN, responseEdit.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_2724.class)
    public void WhenLoggedInAsAdmin_CannotViewTheContents() {

        // Arrange
       API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.SuperAdminNational());
       ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableDataResponseObject = GetDataTableDataItems(tableDetailsNational.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_FORBIDDEN, viewDataTableDataResponseObject.httpStatusCode);
    }

    private String getCanArchiveForTheDataTable(ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList,String tableName){


        //Act
        int iListTables = viewDataTableList.content.size();

        for (int i = 0; i < iListTables; i++)
        {
            if (viewDataTableList.content.get(i).tableName.equals(tableName)){

                return viewDataTableList.content.get(i).tableAccessLevel;

            }
        }

        return null;

    }

}
