package TestCases.UI.Permissions;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Permissions;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.MenuToolBar;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static org.junit.Assert.assertTrue;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Permissions.class})
public class TestCase_NationalRulesManager extends BaseUIWebDriverTestCase{

    @Test
    public void WhenNationalRuleManagerLoggedIn_CorrectToolBarMenusDisplayed() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);

        //Act
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);
        MenuToolBar menuToolBar = new MenuToolBar(driver);

        //Assert
        assertTrue("Expect dashboardIcon to be displayed", menuToolBar.isElementDisplayed(menuToolBar.dashboardIcon) == true);
        assertTrue("Expect rulesManagement to be displayed", menuToolBar.isElementDisplayed(menuToolBar.rulesManagement) == true);
        assertTrue("Expect dataManagement to be displayed", menuToolBar.isElementDisplayed(menuToolBar.dataManagement) == true);
        assertTrue("Expect logout to be displayed", menuToolBar.isElementDisplayed(menuToolBar.logout) == true);
        assertTrue("Expect users to be displayed", menuToolBar.isElementDisplayed(menuToolBar.users) == true);
        assertTrue("Expect publish to be NOT displayed", menuToolBar.isElementDisplayed(menuToolBar.publish,1,false) == false);
    }




}
