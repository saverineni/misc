package TestCases.RiskingService;

import API.DataForTests.Conditions;
import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestRuleModel.RuleDetails;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.Utils.RuleAtStatus;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service_Operators;
import TestCases.BaseWebAPITestCase;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.riskingservice.model.internal.request.DeclaredDutyTaxFee;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import static API.DataForTests.TestRuleModel.RuleDetails.AttributeType.HEADER;
import static API.DataForTests.TestRuleModel.RuleDetails.AttributeType.ITEM;
import static API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody;
import static org.assertj.core.api.Assertions.assertThat;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.normal;

@Slf4j
@Category(Risking_Service_Operators.class)
public class TestCase_Risking_Operators_NotEqual_CalculatedField extends BaseWebAPITestCase {

    public static final String NO_CONTROL_ROUTE = "";
    private RuleDetails testRule;
    private RuleDetails.Condition condition;
    private TestDeclarationModel.Declaration declaration;

    @Before
    public void setup() throws IOException, TimeoutException {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
        testRule = API.DataForTests.Rules.DraftNatRuleNatManager();
        condition = testRule.queryConditions.get(0).conditions.get(0);
        condition.operator = "neq";
        declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
    }

    private void commitRuleAndPublish(){
        EditRuleVersionResponse.PutResponse commitResponse = RuleAtStatus.CreateCommittedRule(testRule);
        assertThat(commitResponse.httpStatusCode)
                .describedAs("Failed to commit rule. response:\n"+commitResponse.body)
                .isEqualTo(200);
        publishAndWait(5000);
    }

    private DeclarationResponse riskDeclaration() {
        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());
        queue.send(declarationRequest);
        return new DeclarationResponse(queue.receive());
    }

    private DeclarationResponse multiItemRiskDeclaration() {
        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultMultiItemDeclarationTemplate());
        queue.send(declarationRequest);
        return new DeclarationResponse(queue.receive());
    }

    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenTaxAmountSumFieldNotEqualValue_allValuesEmpty_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.taxAmountSum().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxTypeCode = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.taxAmount = "";

        declaration.declaredDutyTaxFees_TaxTypeItem = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.declaredDutyTaxFees_TaxAmountItem = "";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenTaxAmountSumFieldNotEqualValue_SumOfValuesEqual_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.taxAmountSum().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxTypeCode = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.taxAmount = "5";

        declaration.declaredDutyTaxFees_TaxTypeItem = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.declaredDutyTaxFees_TaxAmountItem = "5";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenTaxAmountSumFieldNotEqualValue_SumOfValuesNotEqual_thenRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.taxAmountSum().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxTypeCode = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.taxAmount = "6";

        declaration.declaredDutyTaxFees_TaxTypeItem = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.declaredDutyTaxFees_TaxAmountItem = "5";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenTaxAmountSumFieldNotEqualValue_EmptyValuesIgnored_SumOfValuesNotEqual_thenRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.taxAmountSum().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxTypeCode = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.taxAmount = "6";

        declaration.declaredDutyTaxFees_TaxTypeItem = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.declaredDutyTaxFees_TaxAmountItem = "";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenTaxRevenueSumFieldNotEqualValue_allValuesEmpty_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.taxRevenueSum().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxRevenue = "";
        declaration.declaredDutyTaxFees_TaxRevenueItem = "";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenTaxRevenueSumFieldNotEqualValue_SumOfValuesEqual_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.taxRevenueSum().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxRevenue = "5";
        declaration.declaredDutyTaxFees_TaxRevenueItem = "5";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenTaxRevenueSumFieldNotEqualValue_SumOfValuesNotEqual_thenRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.taxRevenueSum().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxRevenue = "6";
        declaration.declaredDutyTaxFees_TaxRevenueItem = "5";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenTaxRevenueSumFieldNotEqualValue_EmptyValuesIgnored_SumOfValuesNotEqual_thenRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.taxRevenueSum().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxRevenue = "6";
        declaration.declaredDutyTaxFees_TaxRevenueItem = "";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenCustomsValuePerQuantityFieldNotEqualValue_allValuesEmpty_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.customsValuePerQuantity().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.declaredCustomsValue = "";
        declaration.baseQuantity = "";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenCustomsValuePerQuantityFieldNotEqualValue_baseQuantityEmpty_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.customsValuePerQuantity().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.declaredCustomsValue = "10";
        declaration.baseQuantity = "";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenCustomsValuePerQuantityFieldNotEqualValue_declaredCustomsValueEmpty_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.customsValuePerQuantity().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.declaredCustomsValue = "";
        declaration.baseQuantity = "3";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenCustomsValuePerQuantityFieldNotEqualValue_calculatedValueEqual_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.customsValuePerQuantity().attribute;
        condition.value = "100.125";
        commitRuleAndPublish();

        declaration.declaredCustomsValue = "300.375";
        declaration.baseQuantity = "3";
        // customsValuePerQuantity= 300.375/3 = 100.125

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenCustomsValuePerQuantityFieldNotEqualValue_calculatedValueNotEqual_thenRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.customsValuePerQuantity().attribute;
        condition.value = "100";
        commitRuleAndPublish();

        declaration.declaredCustomsValue = "300.375";
        declaration.baseQuantity = "3";
        // customsValuePerQuantity= 300.375/3 = 100.125

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenCustomsValueHeaderFieldNotEqualValue_allValuesEmpty_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.customsValue_Header().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.customsValue = "";
        declaration.customsValue2 = "";
        declaration.customsValue3 = "";
        declaration.customsValue4 = "";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenCustomsValueHeaderFieldNotEqualValue_sumOfValuesEqual_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.customsValue_Header().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.customsValue = "1";
        declaration.customsValue2 = "3";
        declaration.customsValue3 = "4";
        declaration.customsValue4 = "2";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenCustomsValueHeaderFieldNotEqualValue_sumOfValuesNotEqual_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.customsValue_Header().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.customsValue = "1";
        declaration.customsValue2 = "3";
        declaration.customsValue3 = "4";
        declaration.customsValue4 = "3";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenCustomsValueHeaderFieldNotEqualValue_EmptyValuesIgnored_sumOfValuesNotEqual_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.customsValue_Header().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.customsValue = "10";
        declaration.customsValue2 = "";
        declaration.customsValue3 = "";
        declaration.customsValue4 = "1";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenDeclaredCustomsValueHeaderFieldNotEqualValue_allValuesEmpty_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.declaredCustomsValue_Header().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.declaredCustomsValue = "";
        declaration.declaredCustomsValue2 = "";
        declaration.declaredCustomsValue3 = "";
        declaration.declaredCustomsValue4 = "";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenDeclaredCustomsValueHeaderFieldNotEqualValue_sumOfValuesEqual_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.declaredCustomsValue_Header().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.declaredCustomsValue = "1";
        declaration.declaredCustomsValue2 = "3";
        declaration.declaredCustomsValue3 = "4";
        declaration.declaredCustomsValue4 = "2";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenDeclaredCustomsValueHeaderFieldNotEqualValue_sumOfValuesNotEqual_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.declaredCustomsValue_Header().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.declaredCustomsValue = "1";
        declaration.declaredCustomsValue2 = "3";
        declaration.declaredCustomsValue3 = "4";
        declaration.declaredCustomsValue4 = "3";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenDeclaredCustomsValueHeaderFieldNotEqualValue_EmptyValuesIgnored_sumOfValuesNotEqual_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.declaredCustomsValue_Header().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.declaredCustomsValue = "10";
        declaration.declaredCustomsValue2 = "";
        declaration.declaredCustomsValue3 = "";
        declaration.declaredCustomsValue4 = "1";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenDutyChargeValueHeaderFieldNotEqualValue_allValuesEmpty_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.dutyChargeValue().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxAmount = "";
        declaration.taxAmount2 = "";
        declaration.taxAmount3 = "";
        declaration.taxAmount4 = "";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenDutyChargeValueHeaderFieldNotEqualValue_sumOfValuesEqual_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.dutyChargeValue().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxAmount = "1";
        declaration.taxAmount2 = "3";
        declaration.taxAmount3 = "4";
        declaration.taxAmount4 = "2";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenDutyChargeValueHeaderFieldNotEqualValue_sumOfValuesNotEqual_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.dutyChargeValue().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxAmount = "1";
        declaration.taxAmount2 = "3";
        declaration.taxAmount3 = "4";
        declaration.taxAmount4 = "3";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenDutyChargeValueHeaderFieldNotEqualValue_EmptyValuesIgnored_sumOfValuesNotEqual_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.dutyChargeValue().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxAmount = "10";
        declaration.taxAmount2 = "";
        declaration.taxAmount3 = "";
        declaration.taxAmount4 = "1";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenTotalRevenueHeaderFieldNotEqualValue_allValuesEmpty_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.totalRevenue().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxRevenue = "";
        declaration.taxRevenue2 = "";
        declaration.taxRevenue3 = "";
        declaration.taxRevenue4 = "";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenTotalRevenueHeaderFieldNotEqualValue_sumOfValuesEqual_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.totalRevenue().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxRevenue = "1";
        declaration.taxRevenue2 = "3";
        declaration.taxRevenue3 = "4";
        declaration.taxRevenue4 = "2";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenTotalRevenueHeaderFieldNotEqualValue_sumOfValuesNotEqual_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.totalRevenue().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxRevenue = "1";
        declaration.taxRevenue2 = "3";
        declaration.taxRevenue3 = "4";
        declaration.taxRevenue4 = "3";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenTotalRevenueHeaderFieldNotEqualValue_EmptyValuesIgnored_sumOfValuesNotEqual_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.totalRevenue().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxRevenue = "10";
        declaration.taxRevenue2 = "";
        declaration.taxRevenue3 = "";
        declaration.taxRevenue4 = "1";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenTotalVatHeaderFieldNotEqualValue_allValuesEmpty_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.totalVat().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxTypeCode = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue = "";
        declaration.taxTypeCode2 = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue2 = "";
        declaration.taxTypeCode3 = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue3 = "";
        declaration.taxTypeCode4 = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue4 = "";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenTotalVatHeaderFieldNotEqualValue_sumOfValuesEqual_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.totalVat().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxTypeCode = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue = "1";
        declaration.taxTypeCode2 = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue2 = "3";
        declaration.taxTypeCode3 = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue3 = "4";
        declaration.taxTypeCode4 = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue4 = "2";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenTotalVatHeaderFieldNotEqualValue_sumOfValuesNotEqual_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.totalVat().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxTypeCode = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue = "1";
        declaration.taxTypeCode2 = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue2 = "3";
        declaration.taxTypeCode3 = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue3 = "4";
        declaration.taxTypeCode4 = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue4 = "3";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenTotalVatHeaderFieldNotEqualValue_EmptyValuesIgnored_sumOfValuesNotEqual_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.totalVat().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxTypeCode = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue = "10";
        declaration.taxTypeCode2 = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue2 = "";
        declaration.taxTypeCode3 = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue3 = "";
        declaration.taxTypeCode4 = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue4 = "1";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenTotalVatHeaderFieldNotEqualValue_TypeCodeNotVATValuesIgnored_sumOfValuesNotEqual_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.totalVat().attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.taxTypeCode = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue = "5";
        declaration.taxTypeCode2 = "xxx";
        declaration.vatValue2 = "2";
        declaration.taxTypeCode3 = "xxx";
        declaration.vatValue3 = "2";
        declaration.taxTypeCode4 = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue4 = "1";

        DeclarationResponse declarationResponse = multiItemRiskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
 }
