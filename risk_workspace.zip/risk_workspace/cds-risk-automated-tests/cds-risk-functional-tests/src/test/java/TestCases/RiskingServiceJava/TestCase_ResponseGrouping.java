package TestCases.RiskingServiceJava;

import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.Risking_JavaService;
import TestCases.RiskingServiceJava.ActionType.BaseActionTypeTest;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel.RuleOutputs;

@Slf4j
@Category(Risking_JavaService.class)
public class TestCase_ResponseGrouping extends BaseActionTypeTest {


    @Test
    @Category({ChangeRequest.CR_3381.class})
    public void WhenRulesWithControlTypeAndWorkbasketIsHit_ReponseIsGroupedCorrectly() {

        String actionType1Group;
        String actionType2Group;

        RuleOutputs outputs5 = RuleOutputs.builder()
                .actionType("5")
                .informationNarrative("information narrative")
                .informationNarrativeAssignee("some@some.gsi.gov.uk")
                .build();

        RuleOutputs outputs1_1 = RuleOutputs.builder()
                .actionType("1")
                .holdNarrative("Rule for bf_frontline_import")
                .assigneeId("bf_frontline_import")
                .build();

        RuleOutputs outputs1_2 = RuleOutputs.builder()
                .actionType("1")
                .holdNarrative("Rule for bf_export")
                .assigneeId("bf_export")
                .build();

        RuleOutputs outputs2_1 = RuleOutputs.builder()
                .actionType("2")
                .holdNarrative("Rule for ActionType 2")
                .assigneeId("nch_open_general_export_licence")
                .build();

        RuleOutputs outputs2_2 = RuleOutputs.builder()
                .actionType("2")
                .holdNarrative("Rule for ActionType 2 with nch_open_general_export_licence")
                .assigneeId("nch_open_general_export_licence")
                .build();

        //When
        RuleOutputs outputs3 = RuleOutputs.builder()
                .actionType("3")
                .releaseNarrative(RELEASE_NARRATIVE)
                .assigneeId("bf_project_1")
                .build();

        //Then
        createRule(outputs1_1);
        createRule(outputs1_2);
        createRule(outputs2_1);
        createRule(outputs2_2);
        createRule(outputs3);
        createRule(outputs5);
        DeclarationResponse response = sendDeclaration( createDeclaration(), false );

        //Assert
        response.getRiskAssement().forEach(riksAssessmentResult -> {
            if (riksAssessmentResult.contains("bf_frontline_import") || riksAssessmentResult.contains("bf_export")) {
                 Assertions.assertThat(riksAssessmentResult).contains(outputs1_1.getHoldNarrative());
                 Assertions.assertThat(riksAssessmentResult).contains(outputs1_2.getHoldNarrative());
            }
            else if (riksAssessmentResult.contains("nch_open_general_export_licence"))
            {
                Assertions.assertThat(riksAssessmentResult).contains(outputs2_1.getHoldNarrative());
                Assertions.assertThat(riksAssessmentResult).contains(outputs2_2.getHoldNarrative());

            }
        });

   }
}
