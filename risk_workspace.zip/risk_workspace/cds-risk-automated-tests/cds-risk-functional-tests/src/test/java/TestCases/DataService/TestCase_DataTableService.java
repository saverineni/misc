package TestCases.DataService;


import API.DataForTests.*;
import API.DataService.CreateDataTable.CreateDataTableResponse;
import API.DataService.Utils.DataTags;
import API.DataService.ViewDataTable.ViewDataTableResponse;
import API.DataService.ViewDataTableDetails.ViewDataTableDetailsResponse;
import API.DataService.ViewDataTypesList.ViewDataTypeListResponse;
import API.DataService.ViewTags.ViewTagResponse.ViewTagsResponseObject;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.DataTable_Service;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import static API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@Category(DataTable_Service.class)
public class TestCase_DataTableService extends WebAPITestCaseWithDatatablesCleanup {

    @Before
    public void LocalSetup()
    {
        TestDataTableModel.TableDetails tdDefaultTestDataTable = DataTables.DataTable_DefaultCommodityCodes();
        CreateDataTableAndGetResponseObject(tdDefaultTestDataTable);
    }

    @Test
    @Category(ChangeRequest.CR_787.class)
    public void WhenEmptyDataTableSaved_NewDataTableCreatedSuccessfully() throws Throwable {

        //Arrange
        TestUserModel.UserDetails udNatRulesManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        //Act
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_CREATED, createDataTableResponse.httpStatusCode);
        assertEquals(tableDetails.tableName, createDataTableResponse.tableName);
        assertEquals(tableDetails.description, createDataTableResponse.description);
        assertEquals(tableDetails.dataType, createDataTableResponse.dataType);

        assertEquals(udNatRulesManager.baseLocationUuid, createDataTableResponse.locations.get(0).locationUuid);
        assertEquals(tableDetails.creationShareType, createDataTableResponse.locations.get(0).shareType);
        assertEquals(tableDetails.reason, createDataTableResponse.reason);
    }

    @Test
    @Category(ChangeRequest.CR_787.class)
    public void WhenDataTypesSearched_ListOfDataTypesReturned() {
        //Arrange

        //Act
        List<ViewDataTypeListResponse> listOfViewDataTypesResponse = API.DataService.Utils.DataTypes.GetListOfDataTypes();

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, listOfViewDataTypesResponse.get(0).httpStatusCode);
        assertTrue("Expecting more than one data type to be returned", listOfViewDataTypesResponse.size() >= 1);
    }



    @Test
    @Category({ChangeRequest.CR_787.class, ChangeRequest.CR_822.class})
    public void WhenListOfDataTablesSelected_ListOfDataTablesReturned() throws Throwable {

        //Arrange
        TestUserModel.UserDetails udNatRulesManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        API.DataService.ViewDataTablesList.ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListAtStart = API.DataService.Utils.DataTables.GetDataTableList();

        TestDataTableModel.TableDetails dataTable1 = DataTables.DataTable_NoData();
        TestDataTableModel.TableDetails dataTable2 = DataTables.DataTable_NoData();
        dataTable2.tableName = "ta_DataTable2";

        CreateDataTableResponse.PostResponse createDataTableResponse1 = CreateDataTableAndGetResponseObject(dataTable1);
        dataTable1.uuid = createDataTableResponse1.uuid;

        CreateDataTableResponse.PostResponse createDataTableResponse2 = CreateDataTableAndGetResponseObject(dataTable2);
        dataTable2.uuid = createDataTableResponse2.uuid;

        //Act
        API.DataService.ViewDataTablesList.ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListAtEnd = API.DataService.Utils.DataTables.GetDataTableList();

        //Assert
        assertEquals(2, viewDataTableListAtEnd.content.size() - viewDataTableListAtStart.content.size());   //2 tables in total

        assertEquals(HttpStatus.SC_OK, viewDataTableListAtEnd.httpStatusCode);


        for (int i=0; i < viewDataTableListAtEnd.content.size(); i++){

            if(viewDataTableListAtEnd.content.get(0).tableName.equals(dataTable1.tableName)){

                assertEquals(dataTable1.tableName, viewDataTableListAtEnd.content.get(0).tableName);
                assertEquals(dataTable1.description, viewDataTableListAtEnd.content.get(0).description);
                assertEquals(dataTable1.dataType, viewDataTableListAtEnd.content.get(0).dataType);

                assertEquals(udNatRulesManager.baseLocationUuid, viewDataTableListAtEnd.content.get(0).locations.get(0).locationUuid);
                assertEquals(dataTable1.creationShareType, viewDataTableListAtEnd.content.get(0).locations.get(0).shareType);
            }
        }

    }


    @Test
    @Category(ChangeRequest.CR_787.class)
    public void WhenNonExistentDataTableUUIDSelected_NotFoundResponseReceived() throws Throwable {

        //Arrange
        String sUUID = "18d7fd9f-3211-44ea-811d-f0c525e75b99";

        //Act
        API.DataService.ViewDataTable.ViewDataTableResponse.ViewDataTableResponseObject dtSummaryTable = API.DataService.Utils.DataTables.GetDataTableByUID(sUUID);

        //Assert
        assertEquals(HttpStatus.SC_NOT_FOUND, dtSummaryTable.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_787.class)
    public void WhenInvalidDataTableUUIDFormatSelected_BadRequestResponseReceived() throws Throwable {

        //Arrange
        String sInvalidUUIDFormat = "NonExistentDataTable";

        //Act
        API.DataService.ViewDataTable.ViewDataTableResponse.ViewDataTableResponseObject dtSummaryTable = API.DataService.Utils.DataTables.GetDataTableByUID(sInvalidUUIDFormat);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, dtSummaryTable.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_823.class)
    public void WhenDataTableSelectedByUUID_DataTableSummaryReturned() throws Throwable {

        //Arrange
        TestUserModel.UserDetails udNatRulesManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        TestDataTableModel.TableDetails dataTable1 = DataTables.DataTable_NoData();

        CreateDataTableResponse.PostResponse createDataTableResponse1 = CreateDataTableAndGetResponseObject(dataTable1);

        //Act
        ViewDataTableResponse.ViewDataTableResponseObject response = API.DataService.Utils.DataTables.GetDataTableByUID(createDataTableResponse1.uuid);

        //Assert
        assertEquals(HttpStatus.SC_OK, response.httpStatusCode);
        assertEquals(dataTable1.tableName, response.tableName);
        assertEquals(dataTable1.description, response.description);
        assertEquals(dataTable1.dataType, response.dataType);

        assertEquals(udNatRulesManager.baseLocationUuid, response.locations.get(0).locationUuid);
        assertEquals(dataTable1.creationShareType, response.locations.get(0).shareType);
    }


    @Test
    @Category({ChangeRequest.CR_927.class, ChangeRequest.CR_1442.class})
    public void WhenDataTableSelectedByUUID_DataTableDetailsReturned() throws Throwable {

        //Arrange
        LocalDateTime dtStartOfTest = LocalDateTime.now(ZoneId.of("UTC")).minusSeconds(2);
        TestUserModel.UserDetails udNatRulesManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        TestDataTableModel.TableDetails dataTable1 = DataTables.DataTable_NoData();

        CreateDataTableResponse.PostResponse createDataTableResponse1 = CreateDataTableAndGetResponseObject(dataTable1);

        //Act
        ViewDataTableDetailsResponse.ViewDataTableDetailsResponseObject response = API.DataService.Utils.DataTables.GetDataTableDetailsByUID(createDataTableResponse1.uuid);

        //Assert
        assertEquals(HttpStatus.SC_OK, response.httpStatusCode);
        assertEquals(dataTable1.tableName, response.tableName);
        assertEquals(dataTable1.description, response.description);
        assertEquals(dataTable1.dataType, response.dataType);
        assertEquals(udNatRulesManager.pid, response.creatorPid);
        assertEquals(udNatRulesManager.pid, response.updaterPid);

        LocalDateTime dtActCreateDate = LocalDateTime.parse(response.createdTimestamp, DateTimeFormatter.ISO_DATE_TIME);

        assertTrue("StartOfTest: " + dtStartOfTest + "\t dtActLastChangeDate: " + dtActCreateDate.toString(),
                (dtActCreateDate.isEqual(dtStartOfTest) | dtActCreateDate.isAfter(dtStartOfTest)));

        LocalDateTime dtActUpdatedDate = LocalDateTime.parse(response.updatedTimestamp, DateTimeFormatter.ISO_DATE_TIME);

        assertTrue("StartOfTest: " + dtStartOfTest + "\t dtActUpdatedDate: " + dtActUpdatedDate.toString(),
                (dtActUpdatedDate.isEqual(dtStartOfTest) | dtActUpdatedDate.isAfter(dtStartOfTest)));
    }


    @Test
    @Category(ChangeRequest.CR_787.class)
    public void AttemptToSaveDuplicateTable_DuplicateTableNotCreated() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails dataTable1 = DataTables.DataTable_NoData();
        CreateDataTableAndGetResponseObject(dataTable1);

        //Act
        CreateDataTableResponse.PostResponse duplicateReponse = CreateDataTableAndGetResponseObject(dataTable1);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, duplicateReponse.httpStatusCode);
        assertEquals("Data table with name '" + dataTable1.tableName + "' exists", duplicateReponse.response.path("message"));
    }


    @Test
    @Category(ChangeRequest.CR_787.class)
    public void WhenDataTableWithMaxFieldLengthsSaved_NewDataTableCreatedSuccessfully() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_MaxAllowedChars();

        //Act
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_CREATED, createDataTableResponse.httpStatusCode);
        assertEquals(tableDetails.tableName, createDataTableResponse.tableName);
        assertEquals(tableDetails.description, createDataTableResponse.description);
        assertEquals(tableDetails.dataType, createDataTableResponse.dataType);
    }

    @Test
    @Category(ChangeRequest.CR_787.class)
    public void WhenDataTableWithMinFieldLengthsSaved_NewDataTableCreatedSuccessfully() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_MinAllowedChars();

        //Act
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_CREATED, createDataTableResponse.httpStatusCode);
        assertEquals(tableDetails.tableName, createDataTableResponse.tableName);
        assertEquals(tableDetails.description, createDataTableResponse.description);
        assertEquals(tableDetails.dataType, createDataTableResponse.dataType);
    }


    @Test
    @Category(ChangeRequest.CR_787.class)
    public void AttemptToSaveTableWithLongTableName_TableNotCreated() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_MaxAllowedChars();

        //Act
        tableDetails.tableName = tableDetails.tableName + "z";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_BAD_REQUEST, createDataTableResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_787.class)
    public void AttemptToSaveTableWithLongTableDescription_TableNotCreated() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_MaxAllowedChars();

        //Act
        tableDetails.description = tableDetails.description + "z";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_BAD_REQUEST, createDataTableResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_787.class)
    public void AttemptToSaveTableWithShortTableName_TableNotCreated() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_MinAllowedChars();

        //Act
        tableDetails.tableName = tableDetails.tableName.substring(0, tableDetails.tableName.length() -2);
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_BAD_REQUEST, createDataTableResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_787.class)
    public void AttemptToSaveTableWithShortTableDescription_TableNotCreated() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_MinAllowedChars();

        //Act
        tableDetails.description = tableDetails.description.substring(0, tableDetails.description.length() -1);
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_BAD_REQUEST, createDataTableResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_787.class)
    public void AttemptToSaveTableWithoutTableName_TableNotCreated() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        //Act
        tableDetails.tableName = "";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_BAD_REQUEST, createDataTableResponse.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_787.class)
    public void AttemptToSaveTableWithoutTableDescription_TableNotCreated() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        //Act
        tableDetails.description = "";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_BAD_REQUEST, createDataTableResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_787.class)
    public void AttemptToSaveTableWithoutDataType_TableNotCreated() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        //Act
        tableDetails.dataTypeUuid = "";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_BAD_REQUEST, createDataTableResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_787.class)
    public void AttemptToSaveTableWithInvalidDataType_TableNotCreated() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        //Act
        tableDetails.dataTypeUuid = "18d7fd9f-3211-44ea-811d-f0c525e75999";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_BAD_REQUEST, createDataTableResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_947.class)
    public void AttemptToSaveTableWithoutLocationTableNotCreated() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        //Act
        tableDetails.manageTableLocationUuids.set(0,"");
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_BAD_REQUEST, createDataTableResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_1016.class)
    public void WhenDataTableSavedWithTags_NewDataTableCreatedSuccessfully() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_ValidTags();

        //Act
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_CREATED, createDataTableResponse.httpStatusCode);
        assertEquals(tableDetails.tableName, createDataTableResponse.tableName);
        assertEquals(tableDetails.description, createDataTableResponse.description);
        assertEquals(tableDetails.dataType, createDataTableResponse.dataType);

        assertEquals(tableDetails.tags.get(0), createDataTableResponse.tags.get(0).tagName);
        assertEquals(tableDetails.tags.get(1), createDataTableResponse.tags.get(1).tagName);
    }


    @Test
    @Category(ChangeRequest.CR_1016.class)
    public void AttemptToSaveTableWithLongTableTagName_TableNotCreated() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_MaxAllowedChars();

        //Act
        tableDetails.tags.set(0, tableDetails.tags.get(0) + "z");
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_BAD_REQUEST, createDataTableResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_1016.class)
    public void AttemptToSaveTableWithShortTableTagName_TableNotCreated() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_MinAllowedChars();

        //Act
        tableDetails.tags.set(0, "AB");
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_BAD_REQUEST, createDataTableResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_1015.class)
    public void WhenDataTablesMetaFilteredBy1DataType_CorrectDataTablesReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetailsA = DataTables.DataTable_CommodityCodes_NAT();
        tableDetailsA.dataTypeUuid = DataTypes.DataType_CommodityCode_UID;
        CreateDataTableAndGetResponseObject(tableDetailsA);

        TestDataTableModel.TableDetails tableDetailsB = DataTables.DataTable_CommodityCodes_POO();
        tableDetailsB.dataTypeUuid = DataTypes.DataType_FreeText_UID;
        CreateDataTableAndGetResponseObject(tableDetailsB);

        //Act
        String filter = "?dataTypeUuids=" + DataTypes.DataType_CommodityCode_UID;
        API.DataService.ViewDataTablesList.ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.DataService.Utils.DataTables.GetDataTableListByFilter(filter);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, viewDataTableList.httpStatusCode);

        assertThat(viewDataTableList.content).hasSize(2);
        assertThat(viewDataTableList.content).extracting("dataType").containsOnly("Commodity Code");
    }


    @Test
    @Category(ChangeRequest.CR_1015.class)
    public void WhenDataTablesMetaFilteredBy2DataTypes_CorrectDataTablesReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetailsA = DataTables.DataTable_CommodityCodes_NAT();
        tableDetailsA.dataTypeUuid = DataTypes.DataType_CommodityCode_UID;
        CreateDataTableAndGetResponseObject(tableDetailsA);

        TestDataTableModel.TableDetails tableDetailsB = DataTables.DataTable_CommodityCodes_POO();
        tableDetailsB.dataTypeUuid = DataTypes.DataType_CommodityCode_UID;
        CreateDataTableAndGetResponseObject(tableDetailsB);

        TestDataTableModel.TableDetails tableDetailsC = DataTables.DataTable_CommodityCodes_POOEXT();
        tableDetailsC.dataTypeUuid = DataTypes.DataType_FreeText_UID;
        CreateDataTableAndGetResponseObject(tableDetailsC);

        //Act
        String filter = "?dataTypeUuids=" + DataTypes.DataType_CommodityCode_UID + "," + DataTypes.DataType_FreeText_UID;
        API.DataService.ViewDataTablesList.ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.DataService.Utils.DataTables.GetDataTableListByFilter(filter);

        //Assert
        assertThat(viewDataTableList.content).hasSize(4);
        assertThat(viewDataTableList.content).extracting("dataType").containsOnly("Commodity Code", "Free Text");
    }


    @Test
    @Category(ChangeRequest.CR_1015.class)
    public void WhenDataTablesMetaFilteredByInvalidDataType_NoDataTablesReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetailsA = DataTables.DataTable_CommodityCodes_NAT();
        tableDetailsA.dataTypeUuid = DataTypes.DataType_CommodityCode_UID;
        CreateDataTableResponse.PostResponse createDataTableResponseA = CreateDataTableAndGetResponseObject(tableDetailsA);

        //Act
        String filter = "?dataTypeUuids=" + "23bf7001-bc59-11e6-8a10-0242ac110019";
        API.DataService.ViewDataTablesList.ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.DataService.Utils.DataTables.GetDataTableListByFilter(filter);

        //Assert
        assertEquals("Expect 0 Data Tables to be returned", 0, viewDataTableList.content.size());
    }


    @Test
    @Category(ChangeRequest.CR_1015.class)
    public void WhenDataTablesMetaFilteredByInvalidLocationType_NoDataTablesReturned() throws Throwable {

        //Arrange

        //Act
        String filter = "?locationUuids=" + "23bf7001-bc59-11e6-8a10-0242ac110019";
        API.DataService.ViewDataTablesList.ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.DataService.Utils.DataTables.GetDataTableListByFilter(filter);

        //Assert
        assertEquals("Expect 0 Data Tables to be returned", 0, viewDataTableList.content.size());
    }


    @Test
    @Category(ChangeRequest.CR_1015.class)
    public void WhenDataTablesMetaFilteredBy1LocationType_CorrectDataTablesReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetailsA = DataTables.DataTable_CommodityCodes_NAT();
        String filter = "?locationUuids=" + tableDetailsA.manageTableLocationUuids.get(0);

        API.DataService.ViewDataTablesList.ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListAtStart = API.DataService.Utils.DataTables.GetDataTableListByFilter(filter);

        CreateDataTableResponse.PostResponse createDataTableResponseA = CreateDataTableAndGetResponseObject(tableDetailsA);

        TestDataTableModel.TableDetails tableDetailsB = DataTables.DataTable_CommodityCodes_POO();
        CreateDataTableResponse.PostResponse createDataTableResponseB = CreateDataTableAndGetResponseObject(tableDetailsB);

        TestDataTableModel.TableDetails tableDetailsC = DataTables.DataTable_CommodityCodes_POOEXT();
        CreateDataTableResponse.PostResponse createDataTableResponseC = CreateDataTableAndGetResponseObject(tableDetailsC);

        //Act
        API.DataService.ViewDataTablesList.ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.DataService.Utils.DataTables.GetDataTableListByFilter(filter);

        //Assert
        assertEquals("Expect 1 Data Tables to be returned", 1, viewDataTableList.content.size() - viewDataTableListAtStart.content.size());
    }


    @Test
    @Category(ChangeRequest.CR_1015.class)
    public void WhenDataTablesMetaFilteredBy2LocationTypes_CorrectDataTablesReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetailsA = DataTables.DataTable_CommodityCodes_NAT();
        TestDataTableModel.TableDetails tableDetailsB = DataTables.DataTable_CommodityCodes_POO();
        String filter = "?locationUuids=" + tableDetailsA.manageTableLocationUuids.get(0) + "," + tableDetailsB.manageTableLocationUuids.get(0);

        API.DataService.ViewDataTablesList.ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListAtStart = API.DataService.Utils.DataTables.GetDataTableListByFilter(filter);

        CreateDataTableResponse.PostResponse createDataTableResponseA = CreateDataTableAndGetResponseObject(tableDetailsA);
        CreateDataTableResponse.PostResponse createDataTableResponseB = CreateDataTableAndGetResponseObject(tableDetailsB);

        TestDataTableModel.TableDetails tableDetailsC = DataTables.DataTable_CommodityCodes_POOEXT();
        CreateDataTableResponse.PostResponse createDataTableResponseC = CreateDataTableAndGetResponseObject(tableDetailsC);

        //Act
        API.DataService.ViewDataTablesList.ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.DataService.Utils.DataTables.GetDataTableListByFilter(filter);

        //Assert
        //DataTable A -> Location A, DataTable B -> Location B, DataTable C -> Locations A & B
        assertEquals("Expect 3 Data Tables to be returned", 3, viewDataTableList.content.size() - viewDataTableListAtStart.content.size());
    }


    @Test
    @Category(ChangeRequest.CR_1015.class)
    public void WhenDataTablesMetaFilteredByDataTypeAndLocation_CorrectDataTablesReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetailsA = DataTables.DataTable_CommodityCodes_NAT();
        tableDetailsA.dataTypeUuid = DataTypes.DataType_CommodityCode_UID;
        CreateDataTableResponse.PostResponse createDataTableResponseA = CreateDataTableAndGetResponseObject(tableDetailsA);

        TestDataTableModel.TableDetails tableDetailsB = DataTables.DataTable_CommodityCodes_POO();
        tableDetailsB.dataTypeUuid = DataTypes.DataType_FreeText_UID;
        CreateDataTableResponse.PostResponse createDataTableResponseB = CreateDataTableAndGetResponseObject(tableDetailsB);

        //Act
        String filter = "?dataTypeUuids=" + tableDetailsA.dataTypeUuid + "&locationUuids=" + tableDetailsA.manageTableLocationUuids.get(0);
        API.DataService.ViewDataTablesList.ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.DataService.Utils.DataTables.GetDataTableListByFilter(filter);


        //Assert
        assertThat(viewDataTableList.content).hasSize(2);
        assertThat(viewDataTableList.content).extracting("dataType").containsOnly("Commodity Code");
    }


    @Test @Ignore
    @Category(ChangeRequest.CR_983.class)
    public void WhenDataTableSharedForUsageWithSingleLocation_ListOfLocationsUpdatedSuccessfully() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();

        CreateDataTableResponse.PostResponse createDataTable = CreateDataTableAndGetResponseObject(tableDetails);

        ViewDataTableDetailsResponse.ViewDataTableDetailsResponseObject tableResponse = API.DataService.Utils.DataTables.GetDataTableDetailsByUID(createDataTable.uuid);

        //Act
        tableDetails.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTable.uuid;
        tableDetails.creationShareType = "user";
        tableDetails.opLockVersion = tableResponse.opLockVersion;

        API.DataService.Utils.DataTables.ShareDataTableWithLocationsResponse(tableDetails);

        ViewDataTableDetailsResponse.ViewDataTableDetailsResponseObject viewTableResponse = API.DataService.Utils.DataTables.GetDataTableDetailsByUID(tableDetails.uuid);

        //Assert
        assertEquals(HttpStatus.SC_OK, viewTableResponse.httpStatusCode);

        List<String> actualUseLocations = new ArrayList<String>();

        for (int i=0; i < viewTableResponse.locations.size(); i++){

            if(viewTableResponse.locations.get(i).shareType.equals("user"))
            {
                actualUseLocations.add(viewTableResponse.locations.get(i).locationUuid);
            }
        }

        assertEquals("expected 2 use locations: ", 2, actualUseLocations.size());
        assertTrue("expected 2 use locations: ",  actualUseLocations.containsAll(tableDetails.useTablesLocationUuids));
    }


    @Test @Ignore
    @Category(ChangeRequest.CR_983.class)
    public void WhenDataTableSharedWithMultipleLocationsForUse_ListOfLocationsUpdatedSuccessfully() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();

        CreateDataTableResponse.PostResponse createDataTable = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.useTablesLocationUuids.add(Locations.Location_WAT_UID);
        tableDetails.useTablesLocationUuids.add(Locations.Location_LON_UID);
        tableDetails.uuid = createDataTable.uuid;
        tableDetails.creationShareType = "user";

        Response response = API.DataService.Utils.DataTables.ShareDataTableWithLocations(tableDetails);

        ViewDataTableDetailsResponse.ViewDataTableDetailsResponseObject viewTableResponse = API.DataService.Utils.DataTables.GetDataTableDetailsByUID(tableDetails.uuid);

        //Assert
        assertEquals(HttpStatus.SC_OK, viewTableResponse.httpStatusCode);

        List<String> actualUseLocations = new ArrayList<String>();

        for (int i=0; i < viewTableResponse.locations.size(); i++){

            if(viewTableResponse.locations.get(i).shareType.equals("user"))
            {
                actualUseLocations.add(viewTableResponse.locations.get(i).locationUuid);
            }
        }

        assertEquals("Expect shared locations: 4", tableDetails.useTablesLocationUuids.size(), actualUseLocations.size());

        assertTrue("POO location missing", actualUseLocations.containsAll(tableDetails.useTablesLocationUuids));
    }


    @Test @Ignore
    @Category(ChangeRequest.CR_983.class)
    public void WhenDataTableSharedWithSameLocationForUse_ServiceHandlesRequestWithoutServerException() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();

        CreateDataTableResponse.PostResponse createDataTable = CreateDataTableAndGetResponseObject(tableDetails);

        tableDetails.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTable.uuid;
        //tableDetails.opLockVersion = createDataTable.opLockVersion;

        tableDetails.creationShareType = "user";
        API.DataService.Utils.DataTables.ShareDataTableWithLocationsResponse(tableDetails);

        //Act
        //Response ShareAgainResponse = API.DataService.Utils.DataTables.ShareDataTableWithLocations(tableDetails);
        ViewDataTableDetailsResponse.ViewDataTableDetailsResponseObject viewTableResponse = API.DataService.Utils.DataTables.GetDataTableDetailsByUID(tableDetails.uuid);

        //Assert
        List<String> actualUseLocations = new ArrayList<String>();

        for (int i=0; i <= viewTableResponse.locations.size(); i++){

            if(viewTableResponse.locations.get(i).shareType.equals("user"))
            {
                actualUseLocations.add(viewTableResponse.locations.get(i).locationUuid);
            }
        }
        assertEquals("expected 1 use locations: ", 1, actualUseLocations.size());
        assertTrue("expected 1 use locations: ",  actualUseLocations.containsAll(tableDetails.useTablesLocationUuids));
    }

    @Test
    @Category(ChangeRequest.CR_1566.class)
    public void WhenDataTagsSearched_ListOfDataTagsReturned() throws Throwable {

        TestDataTableModel.TableDetails tableDetails = API.DataForTests.DataTables.DataTable_ValidTags();

        CreateDataTableAndGetResponseObject(tableDetails);

        ViewTagsResponseObject viewTagsResponseObject = DataTags.GetDataTags("t");

        String firstTag = viewTagsResponseObject.tags.get(0).tag.tagName;
        String secondTag = viewTagsResponseObject.tags.get(1).tag.tagName;

        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK,viewTagsResponseObject.httpStatusCode);
        assertEquals("First Tag name is incorrect: ", tableDetails.tags.get(0),firstTag);
        assertEquals("Second Tag name is incorrect: ", tableDetails.tags.get(1),secondTag);
    }

    @Test
    @Category(ChangeRequest.CR_1566.class)
    public void WhenDataTagsSearched_ExcludedTagsAreNotReturned() throws Throwable {

        TestDataTableModel.TableDetails tableDetails = API.DataForTests.DataTables.DataTable_ValidTags();

        CreateDataTableAndGetResponseObject(tableDetails);

        //response.uuid;
        ViewTagsResponseObject viewTagsResponseObject = DataTags.GetDataTags("ag&excludedNames=ta_tag1,ta_tag2");

        int i = 0;
        List<String> tagname = new ArrayList<>() ;

        for(i =0; i< viewTagsResponseObject.tags.size();i++) {
            tagname.add(viewTagsResponseObject.tags.get(i).tag.tagName);
        }

        assertTrue("", !tagname.contains(tableDetails.tags.get(0)));
        assertTrue("", !tagname.contains(tableDetails.tags.get(1)));
    }

    @Test
    @Category(ChangeRequest.CR_1566.class)
    public void WhenDataTagsSearched_NoTagsReturnedForUnmatchedSearch() throws Throwable {

        TestDataTableModel.TableDetails tableDetails = API.DataForTests.DataTables.DataTable_ValidTags();

        CreateDataTableAndGetResponseObject(tableDetails);

        ViewTagsResponseObject viewTagsResponseObject = DataTags.GetDataTags("1vs2&^%&6");

        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK,viewTagsResponseObject.httpStatusCode);
        assertTrue("Tags have been returned instead of no tags ", viewTagsResponseObject.tags.isEmpty());
    }

}
