package TestCases.RulesManagementService;


import API.DataForTests.PaginationInfo;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.EnvDetails.EnvDetails;
import API.RulesManagementService.Users.ViewUserList.ViewUserListResponse;
import Categories_CDSRisk.CDS_RM_Pagination;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_Pagination. class})
public class TestCase_Pagination_Users extends BaseWebAPITestCase {

    public PaginationInfo paginationInfo;

    @Before
    public void Setup(){

        paginationInfo = new PaginationInfo();

        ViewUserListResponse.ViewUserListResponseObject  viewUserListROStart = API.RulesManagementService.Utils.Users.GetListOfUsers();
        paginationInfo.iElementsAtStart = viewUserListROStart.totalElements;

        paginationInfo.iPagesAtStart = viewUserListROStart.totalPages;

        TestUserModel.UserDetails userDetails = Users_API.DefaultSuperAdminUser();
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
    }

    @Test
    @Category(ChangeRequest.CR_2430.class)
    public void WhenListOfUsersHasOnePageOfData_CorrectNoOfTotalPagesReturned() throws Throwable {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        ViewUserListResponse.ViewUserListResponseObject  viewUserListRO = API.RulesManagementService.Utils.Users.GetListOfUsers();

        //Assert
        assertEquals("Expect Total Page = 1", 1, viewUserListRO.totalPages);
  }

    @Test
    @Category(ChangeRequest.CR_2430.class)
    public void WhenUserPageSizeIsSet_CorrectNoOfDataTablesReturnedOnPage() throws Throwable {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        String query = EnvDetails.url_RM_Users + "?size=1";
        ViewUserListResponse.ViewUserListResponseObject  viewUserListRO = API.RulesManagementService.Utils.Users.getViewUserListResponseObject(query);

        //Assert
        assertEquals("Expect Users per page = 1", 1, viewUserListRO.numberOfElements);
        assertEquals("Expect contents to contain 1 user", 1, viewUserListRO.content.size());
    }

    @Test
    @Category(ChangeRequest.CR_2430.class)
    public void WhenUserPageNoIsSetToPage1_CorrectPageIsReturned() throws Throwable {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        String query = EnvDetails.url_RM_Users + "?size=" + (paginationInfo.iElementsAtStart + 1) + "&page=0";
        ViewUserListResponse.ViewUserListResponseObject  viewUserListRO = API.RulesManagementService.Utils.Users.getViewUserListResponseObject(query);

        //Assert
        Assertions.assertThat(viewUserListRO.content).extracting("pid").contains(userDetails.pid);
        assertEquals("Expect first page to equal true", true , viewUserListRO.first);
    }


    @Test
    @Category(ChangeRequest.CR_2430.class)
    public void WhenUserPageNoIsNotSet_FirstPageIsReturnedByDefault() throws Throwable {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        String query = EnvDetails.url_RM_Users + "?size=1";
        ViewUserListResponse.ViewUserListResponseObject  viewUserListRO = API.RulesManagementService.Utils.Users.getViewUserListResponseObject(query);

        //Assert
        assertEquals("Expect current page to be 0", 0, viewUserListRO.number);
        assertEquals("Expect first page to equal true", true , viewUserListRO.first);
    }


    @Test
    @Category(ChangeRequest.CR_2430.class)
    public void WhenUserPageLastIsSet_LastPageIsReturned() throws Throwable {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        int expTotalPages = paginationInfo.iElementsAtStart + 1;
        String query = EnvDetails.url_RM_Users + "?size=1&page=" + (expTotalPages);
        ViewUserListResponse.ViewUserListResponseObject  viewUserListRO = API.RulesManagementService.Utils.Users.getViewUserListResponseObject(query);

        //Assert
        assertEquals("Expect last page to equal true", true , viewUserListRO.last);
        assertEquals("Expect last page to be page:" + expTotalPages, expTotalPages, viewUserListRO.totalPages);
    }


    @Test
    @Category(ChangeRequest.CR_2430.class)
    public void WhenListOfUsersIsSelected_CorrectPaginationDetailsReturned() throws Throwable {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        int expTotalElements = paginationInfo.iElementsAtStart + 1;

        paginationInfo.iSizeOfPage = 2;
        paginationInfo.iElementsAdded = 1;
        paginationInfo.calculatePaginationInfo(paginationInfo);

        String query = EnvDetails.url_RM_Users + "?size=2&page=" + (paginationInfo.iCalcTotalPages - 1);
        ViewUserListResponse.ViewUserListResponseObject  viewUserListRO = API.RulesManagementService.Utils.Users.getViewUserListResponseObject(query);

        //Assert
        assertEquals("Expect number of total elements to be 3", expTotalElements, viewUserListRO.totalElements);
        assertEquals("Expect page contents to contain 2 users", paginationInfo.iCalcElementsOnLastPage, viewUserListRO.content.size());
        assertEquals("Expect number of elements on page to be 2", paginationInfo.iCalcElementsOnLastPage, viewUserListRO.numberOfElements);
        assertEquals("Expect number of total pages to be 2", paginationInfo.iCalcTotalPages, viewUserListRO.totalPages);
    }


}
