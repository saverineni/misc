package TestCases.RiskingService;


import API.DataForTests.Conditions;
import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestRuleModel;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service_Operators;
import TestCases.BaseWebAPITestCase;
import junitparams.JUnitParamsRunner;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import uk.gov.hmrc.risk.test.common.enums.HeaderDeclarationParam;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeoutException;

import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
@Category(Risking_Service_Operators.class)
@RunWith(JUnitParamsRunner.class)
public class TestCase_Risking_Operators_Logical extends BaseWebAPITestCase {

    @Before
    public void setup() throws IOException, TimeoutException
    {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
    }

    @Test
    @Category({ChangeRequest.CR_1366.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithANDConditionAtHeaderLevel_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.customsProcedureCode();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.dispatchCountry());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consigneeName());

        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.consigneeName = ruleDetails.queryConditions.get(0).conditions.get(1).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        modelSupport.checkDeclarationFieldValue(declarationRequest, "dispatchCountry",
                declaration.dispatchCountry);

        modelSupport.checkDeclarationFieldValue(declarationRequest, HeaderDeclarationParam.CONSIGNEE_NAME.toString(),
                declaration.consigneeName);

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CR_1366.class})
    public void WhenDeclarationSubmittedForNonMatchingRuleWithANDConditionAtHeaderLevel_NoRouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.customsProcedureCode();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.dispatchCountry());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consigneeName());

        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry = "ZZ";
       declaration.consigneeName = ruleDetails.queryConditions.get(0).conditions.get(1).value;

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isNotEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(0);
    }

    @Test
    @Category({ChangeRequest.CR_1366.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithBothORConditionMatchingAtHeaderLevel_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.customsProcedureCode();

        ruleDetails.queryConditions.get(0).operator = "or";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.dispatchCountry());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consigneeName());

        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.consigneeName = ruleDetails.queryConditions.get(0).conditions.get(1).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                    .contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CR_1366.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithOneORConditionMatchingAtHeaderLevel_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.customsProcedureCode();

        ruleDetails.queryConditions.get(0).operator = "or";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.dispatchCountry());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consigneeName());

        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry = "ZZ";
        declaration.consigneeName = ruleDetails.queryConditions.get(0).conditions.get(1).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CR_1366.class})
    public void WhenDeclarationSubmittedForNonMatchingRuleWithNoORConditionMatchingAtHeaderLevel_NoRouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.customsProcedureCode();

        ruleDetails.queryConditions.get(0).operator = "or";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.dispatchCountry());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consigneeName());

        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry = "ZZ";
       declaration.consigneeName = "zz";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isNotEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(0);
    }

    @Test
    @Category({ChangeRequest.CR_1366.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithANDConditionAtItemLevelSubmitted_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.originCountry_Item());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.commodityCode());

        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.originCountry_Item = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.commodity = ruleDetails.queryConditions.get(0).conditions.get(1).value;
        declaration.sequenceNumber = "2";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_1366.class})
    public void WhenDeclarationSubmittedForNonMatchingRuleWithANDConditionAtItemLevelSubmitted_NoRouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.customsProcedureCode();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.originCountry_Item());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.commodityCode());

        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeCountry_Item = "ZZ";
        declaration.commodity = ruleDetails.queryConditions.get(0).conditions.get(1).value;
        declaration.sequenceNumber = "3";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isNotEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(0);
    }

    @Test
    @Category({ChangeRequest.CR_1366.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithBothORConditionMatchingAtItemLevelSubmitted_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.customsProcedureCode();

        ruleDetails.queryConditions.get(0).operator = "or";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.originCountry_Item());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.commodityCode());

        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeCountry_Item = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.commodity = ruleDetails.queryConditions.get(0).conditions.get(1).value;
        declaration.sequenceNumber = "4";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_1366.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithOneORConditionMatchingAtItemLevelSubmitted_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.customsProcedureCode();

        ruleDetails.queryConditions.get(0).operator = "or";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.originCountry_Item());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.commodityCode());

        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeCountry_Item = "ZZ";
        declaration.commodity = ruleDetails.queryConditions.get(0).conditions.get(1).value;
        declaration.sequenceNumber = "5";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_1366.class})
    public void WhenDeclarationSubmittedForNonMatchingRuleWithNoORConditionMatchingAtItemLevelSubmitted_NoRouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.customsProcedureCode();

        ruleDetails.queryConditions.get(0).operator = "or";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.originCountry_Item());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.commodityCode());

        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeCountry_Item = "ZZ";
        declaration.commodity = "0909090909";
        declaration.sequenceNumber = "6";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isNotEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(0);
    }

    @Test
    @Category({ChangeRequest.CR_1637.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithMultiLevelORConditionMatchingAtHeaderLevelSubmitted_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).operator = "or";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.dispatchCountry());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.commodityCode());

        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.commodity = "WrongCommodityCode";
        declaration.sequenceNumber = "4";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        log.debug(declarationResponse.toString());

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).hasSize(1)
                .contains(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CR_1637.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithMultiLevelORConditionMatchingAtItemLevelSubmitted_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).operator = "or";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.dispatchCountry());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.commodityCode());

        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry = "HK";
        declaration.commodity = ruleDetails.queryConditions.get(0).conditions.get(1).value;
        declaration.sequenceNumber = "4";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        log.debug(declarationResponse.toString());

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).hasSize(1)
                .contains(declaration.controlTypeExpectedValue);


        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }

}
