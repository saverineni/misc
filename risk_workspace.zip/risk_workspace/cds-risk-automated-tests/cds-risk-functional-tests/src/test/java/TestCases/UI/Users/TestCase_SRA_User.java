package TestCases.UI.Users;


import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Users;
import Categories_CDSRisk.CDS_Risk_UI_Users_2;
import Categories_CDSRisk.ChangeRequest;
import FunctionsLibrary.Utils;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.Pages.UserManagement.ListUsers_Page;
import UI.Pages.UserManagement.UserDetails_Page;
import UI.Utils.Navigation;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import java.util.List;
import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Users.class, CDS_Risk_UI_Users_2.class})
public class TestCase_SRA_User extends BaseUIWebDriverTestCase {

    //------------------------

    @Before
    public void Setup() {

        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetailsPOO);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsAdmin);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);

        List<ListUsers_Page.UserListTableObject> userListTableObjects = listUsers_page.getListOfUsers();
        ListUsers_Page.UserListTableObject userListTableObject = listUsers_page.getUserTableObjectFromUserListTableObject(userListTableObjects, UserDetailsPOO.pid);

        userListTableObject.pidElement.click();

    }

    @Category(ChangeRequest.CR_1982.class)
    @Test
    public void WhenAdminSuspendsUser_UserSuspendedSuccessfully(){

        //Arrange
        //Get User to perform action on

        //Act
        UserDetails_Page userDetails_page = new UserDetails_Page(driver);
        userDetails_page.suspend.click();
        userDetails_page.waitForAngularRequestsToFinish();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);

        String actTitle1 = dialog_confirm.dialogTitle.getText();
        String actContent1 = dialog_confirm.dialogContent.getText();

        dialog_confirm.EnterReasonAndCloseDialogBox("Archived Temporarily");

        userDetails_page.waitForAngularRequestsToFinish();

        String actTitle2 = dialog_confirm.dialogTitle.getText();

        userDetails_page.clickOKButton();
        userDetails_page.waitForAngularRequestsToFinish();

        String actStatus = userDetails_page.status.getText();

        //Assert
        assertEquals("Suspend user", actTitle1);
        assertEquals("Reason to suspend the user?", actContent1);

        assertEquals("Suspend success", actTitle2);

        assertEquals("Suspended", actStatus);
    }


    @Category(ChangeRequest.CR_1982.class)
    @Test
    public void WhenAdminArchivesUser_UserArchivedSuccessfully(){

        //Arrange
        //Get User to perform action on

        //Act
        UserDetails_Page userDetails_page = new UserDetails_Page(driver);
        userDetails_page.archive.click();
        userDetails_page.waitForAngularRequestsToFinish();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);

        String actTitle1 = dialog_confirm.dialogTitle.getText();
        String actContent1 = dialog_confirm.dialogContent.getText();

        dialog_confirm.EnterReasonAndCloseDialogBox("Archived Temporarily");
        userDetails_page.waitForAngularRequestsToFinish();

        String actTitle2 = dialog_confirm.dialogTitle.getText();
        userDetails_page.clickOKButton();
        userDetails_page.waitForAngularRequestsToFinish();

        String actStatus = userDetails_page.status.getText();

        //Assert
        assertEquals("Archive user", actTitle1);
        assertEquals("Reason to archive the user?", actContent1);

        assertEquals("Archive success", actTitle2);
        assertEquals("Archived", actStatus);
    }


    @Category(ChangeRequest.CR_1982.class)
    @Test
    public void WhenAdminReinstatesUser_UserReinstatedSuccessfully(){

        //Arrange
        //Get User to perform action on
        UserDetails_Page userDetails_page = new UserDetails_Page(driver);
        userDetails_page.suspend.click();
        userDetails_page.waitForAngularRequestsToFinish();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Suspend Temporarily");
        userDetails_page.waitForAngularRequestsToFinish();
        userDetails_page.clickOKButton();
        userDetails_page.waitForAngularRequestsToFinish();

        //Act
        userDetails_page.reinstate.click();
        userDetails_page.waitForAngularRequestsToFinish();

        String actTitle1 = dialog_confirm.dialogTitle.getText();
        String actContent1 = dialog_confirm.dialogContent.getText();

        dialog_confirm.EnterReasonAndCloseDialogBox("Archived Temporarily");
        userDetails_page.waitForAngularRequestsToFinish();
        String actTitle2 = dialog_confirm.dialogTitle.getText();
        userDetails_page.clickOKButton();
        userDetails_page.waitForAngularRequestsToFinish();

        String actStatus = userDetails_page.status.getText();

        //Assert
        assertEquals("Reinstate user", actTitle1);
        assertEquals("Reason to reinstate the user?", actContent1);

        assertEquals("Reinstate success", actTitle2);
        assertEquals("Inactive", actStatus);
    }


    @Category(ChangeRequest.CR_1982.class)
    @Test
    public void WhenAdminCancelsUserSuspension_UserRemainsAtActiveStatus(){

        //Arrange
        //Get User to perform action on

        //Act
        UserDetails_Page userDetails_page = new UserDetails_Page(driver);
        Utils.SleepForMilliSeconds(500);
        userDetails_page.suspend.click();

        userDetails_page.dialogCancel.click();

        String actStatus = userDetails_page.status.getText();

        //Assert
        assertEquals("Inactive", actStatus);
    }


    @Category(ChangeRequest.CR_1982.class)
    @Test
    public void WhenAdminCancelsUserReinstate_UserRemainsAtSuspendedStatus(){

        //Arrange
        //Get User to perform action on

        //Act
        UserDetails_Page userDetails_page = new UserDetails_Page(driver);
        userDetails_page.suspend.click();
        userDetails_page.waitForAngularRequestsToFinish();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Suspend Temporarily");
        userDetails_page.waitForAngularRequestsToFinish();
        userDetails_page.clickOKButton();
        userDetails_page.waitForAngularRequestsToFinish();

        //Act
        userDetails_page.reinstate.click();
        userDetails_page.waitForAngularRequestsToFinish();
        userDetails_page.dialogCancel.click();
        userDetails_page.waitForAngularRequestsToFinish();

        String actStatus = userDetails_page.status.getText();

        //Assert
        assertEquals("Suspended", actStatus);
    }


    @Category(ChangeRequest.CR_1982.class)
    @Test
    public void WhenAdminCancelsUserArchive_UserRemainsAtActiveStatus(){

        //Arrange
        //Get User to perform action on

        //Act
        UserDetails_Page userDetails_page = new UserDetails_Page(driver);
        userDetails_page.archive.click();

        userDetails_page.dialogCancel.click();

        String actStatus = userDetails_page.status.getText();

        //Assert
        assertEquals("Inactive", actStatus);
    }
}
