package TestCases.RulesManagementService;

import API.RulesManagementService.Users.ViewUserList.ViewUserListResponse;
import Categories_CDSRisk.CDS_RM_UserManagement;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static API.RulesManagementService.Utils.Users.GetListOfUsersByUserRoleFilter;
import static API.RulesManagementService.Utils.Users.createAListOfUsers;

@Category({Rules_Management.class, CDS_RM_UserManagement.class})
public class TestCase_UserManagement_FilterUsersByUserRole extends BaseWebAPITestCase {

    @Test
    @Category(ChangeRequest.CR_2462.class)
    public void WhenUsersFilteredUserRoleSuperAdmin_OnlyListOfSuperAdminUsersReturned() {

        //Arrange
        createAListOfUsers();



        String UserRole = "superadmin";
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsersByUserRoleFilter(UserRole);

        //Act
        List<ViewUserListResponse.Content> viewUserList = viewUserListResponseObject.content;

        //Assert
        Assertions.assertThat(viewUserList).extracting("superAdmin").containsOnly(true);
    }

    @Test
    @Category(ChangeRequest.CR_2462.class)
    public void WhenUsersFilteredUserRoleAdmin_OnlyListOfAdminUsersReturned() {

        //Arrange
        createAListOfUsers();

        String UserRole = "admin";
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsersByUserRoleFilter(UserRole);

        //Act
        List<ViewUserListResponse.Content> viewUserList = viewUserListResponseObject.content;

        //Assert
        Assertions.assertThat(viewUserList.size()).isEqualTo(3);
        Assertions.assertThat(viewUserList).extracting("admin").containsOnly(true);
    }

    @Test
    @Category(ChangeRequest.CR_2462.class)
    public void WhenUsersFilteredUserRoleRuleManager_OnlyListOfRuleManagerUsersReturned() {

        //Arrange
        createAListOfUsers();

        String UserRole = "rulemanager";
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsersByUserRoleFilter(UserRole);

        //Act
        List<ViewUserListResponse.Content> viewUserList = viewUserListResponseObject.content;

        //Assert
        //RuleManager(1234530) is created for peformance test. So the assertion for view user list is taken off.
        Assertions.assertThat(viewUserList).extracting("ruleManager").containsOnly(true);
    }

    @Test
    @Category(ChangeRequest.CR_2462.class)
    public void WhenUsersFilteredUserRoleByIncorrectFilter_400IsReturned() {

        //Arrange
        createAListOfUsers();

        String UserRole = "localRuleManager";
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsersByUserRoleFilter(UserRole);

        //Act
        List<ViewUserListResponse.Content> viewUserList = viewUserListResponseObject.content;

        //Assert
        Assertions.assertThat(viewUserListResponseObject.httpStatusCode).isEqualTo(400);
    }

}
