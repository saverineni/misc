package TestCases.RiskingServiceJava.ManualIntervention;

import Categories_CDSRisk.ChangeRequest_RiskingService.CREP_403;
import Categories_CDSRisk.Risking_JavaService;
import TestCases.RiskingServiceJava.BaseRiskingServiceJava;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel.RuleDefinition;
import uk.gov.hmrc.risk.rulesengine.rules.RuleMetadata;
import uk.gov.hmrc.risk.test.common.enums.*;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleCreationModel;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static uk.gov.hmrc.risk.test.common.enums.Matcher.equalTo;
import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.*;

@Category({CREP_403.class, Risking_JavaService.class})
public class TestCase_ManualInterventionText extends BaseRiskingServiceJava {

    String description = "ta_manual_intervention_rule_1";

    @Test
    public void WhenRuleMatches_ReturnsDefaultManualInterventionData() {
        String ruleDefinition = createRuleDefinition(description).toString();

        RuleCreationModel rule = baseRuleCreationModelBuilder()
                .description(description)
                .json(
                        RuleCreationModel.JsonContainer.builder()
                                .behaviours(Arrays.asList(
                                        RuleCreationModel.BehaviourContainer.builder()
                                                .behaviourType(RuleBehaviourType.DEFAULT)
                                                .narrative(description)
                                                .controlType("2")
                                                .build()
                                ))
                                .build()
                )
                .definition(ruleDefinition)
                .build();

        rulesSupport.createActiveRule(rule, appStateSupport.getLoggedInUserPID());
        publishAndWait(5000);

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();
        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNOR_EORI, "NL000111222");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_TYPE, "EX");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "A");

        DeclarationResponse declarationResponse = createAndSendDeclaration(declarationFieldValues);

        assertThat(declarationResponse.getConclusion().get(0)).isEqualTo("4");
//        assertThat(declarationResponse.getControlAgent().get(0)).contains("Team01");
        assertThat(declarationResponse.getTotalScore().get(0)).contains("99");
        assertThat(declarationResponse.getTimeToClose()).containsOnly("0");
        assertThat(declarationResponse.getIsSelfClosing()).containsOnly(false);
        assertThat(declarationResponse.getIsSecret().get(0)).isEqualTo(false);
        assertThat(declarationResponse.getInvolvesNotifyingDeclarant().get(0)).isEqualTo(true);
        assertThat(declarationResponse.getIsMachine().get(0)).isEqualTo(true);
        assertThat(declarationResponse.getSourceId().get(0)).isEqualTo("Risk");
        assertThat(declarationResponse.getControlMeans().get(0)).isEqualTo("5");
        assertThat(declarationResponse.getDescription().get(0)).isNotNull();
        assertThat(declarationResponse.getProfileId().get(0)).isNotNull();
        assertThat(declarationResponse.getScore().get(0)).isEqualTo("99");
    }

    private RuleDefinitionModel createRuleDefinition(String description) {
        RuleDefinitionModel model = defaultModel();
        model.getRuleDefinitions().clear();
        RuleDefinition ruleDefinition = RuleDefinition.builder().build();
        ruleDefinition.addMetadata(new RuleDefinitionModel.MetadataDefinition(RuleMetadata.UNIQUE_ID, Optional.of("#UniqueId#")));

        RuleDefinitionConstants.Condition consigneeEori = RuleDefinitionConstants.Condition.builder()
                .attribute(HeaderAttribute.CONSIGNOR_EORI)
                .matcherClass(RuleDefinitionConstants.MatcherClass.Matchers)
                .matcher(equalTo)
                .matcherType(MatcherType.EQUAL)
                .value("NL000111222")
                .source(Source.declaration)
                .build();

        String declaration = declarationWrapper(
                strCheck( consigneeEori ));

        ruleDefinition.setName(description);
        ruleDefinition.setWhenDef(declaration);
        ruleDefinition.setThenDef(thenCreator( Source.declaration, conditions( consigneeEori )));
        model.getRuleDefinitions().add(ruleDefinition);
        return model;
    }
}
