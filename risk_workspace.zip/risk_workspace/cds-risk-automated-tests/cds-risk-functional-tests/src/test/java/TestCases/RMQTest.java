package TestCases;

import app.helpers.QueueAccessor;
import lombok.extern.slf4j.Slf4j;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

@Slf4j
@Ignore
public class RMQTest extends BaseSpringBootTestCase {

    @Autowired
    private QueueAccessor queueAccessor;

    @Test
    public void testRMQ(){
        log.info("RMQTest.testWMQ OK !!!!! :-) !!!!! :-) ");

        queueAccessor.send("<xml></xml>");

        log.info("sent, check your queue");
    }
}
