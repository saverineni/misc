package TestCases.RulesManagementService;

import API.DataForTests.TestEnumerators;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.EnvDetails.EnvDetails;
import API.RulesManagementService.Users.CreateUser.CreateUserResponse;
import API.RulesManagementService.Users.ViewUser.ViewUserResponse;
import API.RulesManagementService.Users.ViewUserDetails.ViewUserDetailsResponse;
import API.RulesManagementService.Users.ViewUserList.ViewUserListResponse;
import API.RulesManagementService.Utils.Users;
import Categories_CDSRisk.CDS_RM_UserManagement;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import FunctionsLibrary.DateTime;
import TestCases.BaseWebAPITestCase;
import org.apache.http.HttpStatus;
import org.assertj.core.api.Assertions;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

import static org.junit.Assert.*;

@Category({Rules_Management.class, CDS_RM_UserManagement.class})
public class TestCase_UserManagement_CreateUser extends BaseWebAPITestCase {

    @Autowired
    @Qualifier("usersJdbcTemplate")
    private JdbcTemplate usersJdbcTemplate;

    @Test
    @Category(ChangeRequest.CR_475.class)
    public void WhenNewUserWithNoCDSRiskAccountSelectedByPID_DefaultDataPopulatedFromDB()
    {
        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
        TestUserModel.UserDetails userDetails = Users_API.UserWithNoAccessToCDSRisk();

        //Act
        ViewUserResponse actResp = API.RulesManagementService.Utils.Users.GetUserByPID(userDetails.pid);


        //Assert
        assertEquals("Expect HttpStatus OK ", HttpStatus.SC_OK, actResp.httpStatusCode);
        ViewUserResponse.AssertViewUserResponse(userDetails, actResp);
    }

    @Test
    @Category(ChangeRequest.CR_475.class)
    public void WhenNonExistentUserSelectedByPID_NotFoundResponseReceived() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
        //Ensure user pid 9999999 does not exist on system

        //Act
        ViewUserResponse actResp = API.RulesManagementService.Utils.Users.GetUserByPID("9999999");

        //Assert
        String sErrorMessage = actResp.response.path("message");
        assertEquals("User not found for pid '9999999'.", sErrorMessage);
    }

    @Test
    @Category(ChangeRequest.CR_1151.class)
    public void WhenInvalidUserSelectedByPID_NotFoundResponseReceived() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
        //Ensure user with 1234560 exists 'default test automation user'
        String invalidPID = "1234560aaa";

        //Act
        ViewUserResponse actResp = API.RulesManagementService.Utils.Users.GetUserByPID(invalidPID);
        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(invalidPID);

        //Assert
        String sErrorMessage = actResp.response.path("message");
        assertEquals("User not found for pid '1234560aaa'.", sErrorMessage);

        String sErrorMessage2 = viewUserDetailsResponse.response.path("message");
        assertEquals("User not found for pid '1234560aaa'.", sErrorMessage2);
    }


    @Test
    @Category({ChangeRequest.CR_557.class, ChangeRequest.CR_475.class, ChangeRequest.CR_495.class, ChangeRequest.CR_622.class})
    public void WhenLocalRuleViewerUserSaved_NewUserCreatedSuccessfully() {

        //Arrange

        //Ensure user exists on system in DB but does not have a cds-risk user account
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());
        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);
        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(userDetails.pid);

        //Assert
        CreateUserResponse.AssertCreateUserResponse(userDetails, createUserResponse);
        assertEquals("Expect HttpStatus.SC_OK ", HttpStatus.SC_OK, viewUserDetailsResponse.httpStatusCode);
        ViewUserDetailsResponse.AssertViewUserDetailsResponse(userDetails, viewUserDetailsResponse);
    }

    @Test
    @Category({ChangeRequest.CR_557.class, ChangeRequest.CR_554.class, ChangeRequest.CR_495.class, ChangeRequest.CR_622.class})
    public void WhenLocalSuperAdminUserSaved_NewUserCreatedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
        TestUserModel.UserDetails userDetails = Users_API.SuperAdminLocal_POO();

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);
        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(userDetails.pid);

        //Assert
        CreateUserResponse.AssertCreateUserResponse(userDetails, createUserResponse);
        ViewUserDetailsResponse.AssertViewUserDetailsResponse(userDetails, viewUserDetailsResponse);
    }

    @Test
    @Category({ChangeRequest.CR_557.class, ChangeRequest.CR_553.class, ChangeRequest.CR_495.class, ChangeRequest.CR_622.class})
    public void WhenLocalAdminUserSaved_NewUserCreatedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());
        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO();

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);
        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(userDetails.pid);

        //Assert
        CreateUserResponse.AssertCreateUserResponse(userDetails, createUserResponse);
        ViewUserDetailsResponse.AssertViewUserDetailsResponse(userDetails, viewUserDetailsResponse);
    }


    @Test
    @Category({ChangeRequest.CR_557.class, ChangeRequest.CR_554.class, ChangeRequest.CR_495.class, ChangeRequest.CR_622.class})
    public void WhenNationalSuperAdminUserSaved_NewUserCreatedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
        TestUserModel.UserDetails userDetails = Users_API.SuperAdminNational("1234510");

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);
        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(userDetails.pid);

        //Assert
        CreateUserResponse.AssertCreateUserResponse(userDetails, createUserResponse);
        ViewUserDetailsResponse.AssertViewUserDetailsResponse(userDetails, viewUserDetailsResponse);
    }


    @Test
    @Category({ChangeRequest.CR_557.class, ChangeRequest.CR_597.class, ChangeRequest.CR_495.class, ChangeRequest.CR_622.class})
    @Ignore("Will be fixed as part of CR-3392")
    public void WhenNationalRulesManagerUserSaved_NewUserCreatedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());
        TestUserModel.UserDetails userDetails = Users_API.RulesManagerNational();

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);
        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(userDetails.pid);

        //Assert
        CreateUserResponse.AssertCreateUserResponse(userDetails, createUserResponse);
        ViewUserDetailsResponse.AssertViewUserDetailsResponse(userDetails, viewUserDetailsResponse);
    }


    @Test
    @Category({ChangeRequest.CR_557.class, ChangeRequest.CR_598.class, ChangeRequest.CR_495.class, ChangeRequest.CR_622.class})
    public void WhenNationalRulesViewerUserSaved_NewUserCreatedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());
        TestUserModel.UserDetails userDetails = Users_API.RulesViewerNational();

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);
        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(userDetails.pid);

        //Assert
        CreateUserResponse.AssertCreateUserResponse(userDetails, createUserResponse);
        ViewUserDetailsResponse.AssertViewUserDetailsResponse(userDetails, viewUserDetailsResponse);
    }


    @Test
    @Category({ChangeRequest.CR_655.class, ChangeRequest.CR_495.class, ChangeRequest.CR_622.class})
    public void WhenUserWithMultipleRolesSaved_NewUserCreatedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
        TestUserModel.UserDetails userDetails = Users_API.SuperAdminAndAdminNational();

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);
        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(userDetails.pid);

        //Assert
        CreateUserResponse.AssertCreateUserResponse(userDetails, createUserResponse);
        ViewUserDetailsResponse.AssertViewUserDetailsResponse(userDetails, viewUserDetailsResponse);
    }

    @Test
    @Category({ChangeRequest.CR_475.class, ChangeRequest.CR_496.class})
    public void WhenMultipleUsersCreated_UsersPresentInListOfUsers() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());

        int iNoOfUsersInAtStartOfTest =  Users.GetListOfUsers().content.size();

        TestUserModel.UserDetails udNatRuleViewer = Users_API.RulesViewerNational();
        TestUserModel.UserDetails udSuperAdminPOO = Users_API.SuperAdminLocal_POO();

        API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(udNatRuleViewer);
        API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(udSuperAdminPOO);

        //Assert
        List<ViewUserListResponse.Content> viewUserListResponse = Users.GetListOfUsers().content;

        int noOfUsers = viewUserListResponse.size();
        assertEquals(2, noOfUsers - iNoOfUsersInAtStartOfTest);   //2 users in total

        ViewUserListResponse.AssertUserInViewUserListResponse(udNatRuleViewer, viewUserListResponse);
        ViewUserListResponse.AssertUserInViewUserListResponse(udSuperAdminPOO, viewUserListResponse);
    }

    @Test
    @Category(ChangeRequest.CR_475.class)
    public void AttemptToSaveDuplicateUser_BadRequestResponseReceived() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
        TestUserModel.UserDetails userDetails = Users_API.NationalRulesManagerDefaultTestAutomationUser("1234561","Password1");

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, createUserResponse.httpStatusCode);

        String sErrorMessage = createUserResponse.response.path("message");
        assertEquals("User with pid '" + userDetails.pid + "' already exists", sErrorMessage);
    }

    @Test
    @Category(ChangeRequest.CR_475.class)
    public void AttemptToCreateUserWithJustPID_NewUserNOTCreated() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
        TestUserModel.UserDetails userDetails = Users_API.UserWithJustPID();

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, createUserResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_557.class)
    public void AttemptToCreateUserWithoutLocation_NewUserNOTCreated() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
        TestUserModel.UserDetails userDetails = Users_API.UserWithoutLocation();

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, createUserResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_557.class)
    public void AttemptToCreateUserWithoutRole_NewUserNOTCreated() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
        TestUserModel.UserDetails userDetails = Users_API.UserWithoutRole();

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, createUserResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_557.class)
    public void AttemptToCreateUserWithInvalidLocation_NewUserNOTCreated() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
        TestUserModel.UserDetails userDetails = Users_API.UserWithInvalidLocation();

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, createUserResponse.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_557.class)
    public void AttemptToCreateUserWithInvalidRole_NewUserNOTCreated() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
        TestUserModel.UserDetails userDetails = Users_API.UserWithInvalidRole();

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, createUserResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_622.class)
    public void AttemptToCreateUserWithoutBaseLocation_NewUserNOTCreated() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
        TestUserModel.UserDetails userDetails = Users_API.UserWithoutBaseLocation();

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, createUserResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_622.class)
    public void AttemptToCreateUserWithInvalidBaseLocation_NewUserNOTCreated() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
        TestUserModel.UserDetails userDetails = Users_API.UserWithInvalidBaseLocation();

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, createUserResponse.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_1403.class)
    public void AttemptToCreateUserWithNoJobTitle_NewUserNOTCreated() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
        TestUserModel.UserDetails userDetails = Users_API.UserWithoutJobTitle();

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, createUserResponse.httpStatusCode);
        assertEquals("size must be between 1 and 30", createUserResponse.response.path("fieldErrors[0].message"));
        assertEquals("jobTitle", createUserResponse.response.path("fieldErrors[0].field"));
    }


    @Test
    @Category({ChangeRequest.CR_2224.class})
    public void WhenUserSavedWithoutMobileNumber_NewUserCreatedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());
        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();
        userDetails.mobileNumber = "";

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);
        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(userDetails.pid);

        //Assert
        CreateUserResponse.AssertCreateUserResponse(userDetails, createUserResponse);
        assertEquals("Expect HttpStatus.SC_OK ", HttpStatus.SC_OK, viewUserDetailsResponse.httpStatusCode);
        ViewUserDetailsResponse.AssertViewUserDetailsResponse(userDetails, viewUserDetailsResponse);
    }

    @Test
    @Category({ChangeRequest.CR_2224.class})
    public void WhenUserSavedWithValidMobileNumber_NewUserCreatedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());
        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();
        userDetails.mobileNumber = "07912345678";

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);
        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(userDetails.pid);

        //Assert
        CreateUserResponse.AssertCreateUserResponse(userDetails, createUserResponse);
        assertEquals("Expect HttpStatus.SC_OK ", HttpStatus.SC_OK, viewUserDetailsResponse.httpStatusCode);
        ViewUserDetailsResponse.AssertViewUserDetailsResponse(userDetails, viewUserDetailsResponse);
    }

    @Test
    @Category(ChangeRequest.CR_2224.class)
    public void AttemptToCreateUserWithLongMobileNumber_NewUserNOTCreated() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());
        TestUserModel.UserDetails userDetails = Users_API.RulesManagerNational();
        userDetails.mobileNumber = "123456789012";

        //Act

        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, createUserResponse.httpStatusCode);
        assertEquals("Phone number must be 0 to 11 numeric characters", createUserResponse.response.path("fieldErrors[0].message"));
        assertEquals("mobileNumber", createUserResponse.response.path("fieldErrors[0].field"));
    }


    @Test
    @Category({ChangeRequest.CR_1422.class})
    public void WhenUserSavedWithoutAlternativeEmail_NewUserCreatedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());
        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();
        userDetails.alternativeEmail = null;

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);
        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(userDetails.pid);

        //Assert
        CreateUserResponse.AssertCreateUserResponse(userDetails, createUserResponse);
        assertEquals("Expect HttpStatus.SC_OK ", HttpStatus.SC_OK, viewUserDetailsResponse.httpStatusCode);
        ViewUserDetailsResponse.AssertViewUserDetailsResponse(userDetails, viewUserDetailsResponse);
    }


    @Test
    @Category({ChangeRequest.CR_1422.class})
    public void WhenUserSavedWithAlternativeEmail_NewUserCreatedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());
        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();
        userDetails.alternativeEmail = "Mark@gsi.gov.uk";

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);
        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(userDetails.pid);

        //Assert
        CreateUserResponse.AssertCreateUserResponse(userDetails, createUserResponse);
        assertEquals("Expect HttpStatus.SC_OK ", HttpStatus.SC_OK, viewUserDetailsResponse.httpStatusCode);
        ViewUserDetailsResponse.AssertViewUserDetailsResponse(userDetails, viewUserDetailsResponse);
    }


    @Test
    @Category(ChangeRequest.CR_1422.class)
    public void AttemptToCreateUserWithInvalidAlternateEmailAddress_NewUserNOTCreated() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        userDetails.alternativeEmail = "Fake.Imposter@Fake.gov.uk";

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, createUserResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_1872.class,ChangeRequest.CR_1404.class})
    public void WhenNationalUserCreatesLocalUserWithAllMyFreightLocations_NewUserCreatedWithIndividualLocations() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails = Users_API.SuperAdminLocal_AllLocations();

        //Act
        API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);
        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(userDetails.pid);

        //Assert
        Assertions.assertThat(viewUserDetailsResponse.roles).extracting("locationName")
                .hasSize(149)
                .contains("MAN")
                .doesNotContain("National Office", "All My Freight Locations", "All Locations");
        Assertions.assertThat(viewUserDetailsResponse.roles).extracting("locationFullName")
                .hasSize(149)
                .contains("Manchester Airport")
                .doesNotContain("National Office", "All My Freight Locations", "All Locations");
        assertEquals("Base Location A Name", "Poole", viewUserDetailsResponse.baseLocation.locationFullName);
    }


    @Test
    @Category({ChangeRequest.CR_1872.class})
    public void WhenLocalUserCreatesLocalUserWithAllMyFreightLocations_NewUserCreatedWithIndividualLocations() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminLocal_POO_EXT());

        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO();
        userDetails.locationRoles.get(0).locationName = "All My Freight Locations";

        //Note this should not change as it hard coded static value in the application. This uid is not stored in location service
        userDetails.locationRoles.get(0).locationNameUuid = "914e4be8-1b00-4bf9-a0f7-d1d567978954";

        //Act
        API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails, EnvDetails.sCurrentLoggedInUserToken);
        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(userDetails.pid);

        //Assert
        Assertions.assertThat(viewUserDetailsResponse.roles).extracting("locationName")
                .hasSize(2)
                .contains("POO", "EXT")
                .doesNotContain("National Office", "All My Freight Locations", "All Locations");
    }


    @Test
    @Category({ChangeRequest.CR_1872.class})
    public void WhenUserWithMixRolesCreatesLocalUserWithAllMyFreightLocations_NewUserCreatedWithIndividualLocationsForRole() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.UserWithAllRoles_MixLocations2());

        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_AllLocations();

        //Act
        API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails, EnvDetails.sCurrentLoggedInUserToken);
        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(userDetails.pid);

        //Assert
        Assertions.assertThat(viewUserDetailsResponse.roles).extracting("locationName")
                .hasSize(2)
                .contains("ABD", "ROS")
                .doesNotContain("National Office", "All My Freight Locations", "All Locations");

    }

    @Test
    @Category({ChangeRequest.CR_2589.class})
    @Ignore("Will be fixed as part of CR-3392")
    public void WhenUserCreatedAndRetrievedThenCorrectPidReturnedInResponse() {
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());

        TestUserModel.UserDetails userDetails = Users_API.RulesManagerNational();

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        ViewUserResponse viewUserResponse = Users.GetUserByPID(createUserResponse.pid);

        assertTrue(viewUserResponse.pid.equals(createUserResponse.pid));
    }

    @Test
    @Category({ChangeRequest.CR_1426.class})
    public void WhenUserWithValidSCClearanceSaved_NewUserCreatedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());
        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();
        userDetails.scClearanceLevel = "BPSS";
        userDetails.scClearanceExpiryDate = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(1, DateTime.DateTimeUTCZ);
        userDetails.scValidated = true;

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);
        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(userDetails.pid);

        //Assert
        CreateUserResponse.AssertCreateUserResponse(userDetails, createUserResponse);
        assertEquals("Expect HttpStatus.SC_OK ", HttpStatus.SC_OK, viewUserDetailsResponse.httpStatusCode);
        ViewUserDetailsResponse.AssertViewUserDetailsResponse(userDetails, viewUserDetailsResponse);
    }

    @Test
    @Category({ChangeRequest.CR_1426.class})
    public void AttemptToSaveUserWithInValidSCClearance_400BadRequest() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());
        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();
        userDetails.scClearanceLevel = "BPSS";
        userDetails.scClearanceExpiryDate = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-1, DateTime.DateTimeUTCZ);
        userDetails.scValidated = true;

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, createUserResponse.httpStatusCode);
    }

    @Test
    @Category({ChangeRequest.CR_2244.class})
    @Ignore("Will be fixed as part of CR-3392")
    public void WhenRedactedUserCreated_NewUserCreatedSuccessfully() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());
        TestUserModel.UserDetails userDetails = Users_API.RulesManagerNational();
        userDetails.redacted = true;

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);
        ViewUserDetailsResponse.userDetails viewUserDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetailsByPID(userDetails.pid);

        //Assert
        CreateUserResponse.AssertCreateUserResponse(userDetails, createUserResponse);
        assertEquals("Expect HttpStatus.SC_OK ", HttpStatus.SC_OK, viewUserDetailsResponse.httpStatusCode);
        ViewUserDetailsResponse.AssertViewUserDetailsResponse(userDetails, viewUserDetailsResponse);
    }

    @Test
    @Category(ChangeRequest.CRX_203.class)
    @Ignore("Will be fixed as part of CR-3392")
    public void WhenUserCreated_SuppliedPasswordIsEncrypted() {
        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());
        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();
        userDetails.password = Users_API.DEFAULT_PASSWORD;

        //Act
        CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);
        CreateUserResponse.AssertCreateUserResponse(userDetails, createUserResponse);

        //Assert
        String sqlQuery = "SELECT password FROM users WHERE pid = " + userDetails.pid;


        String actualPassword = usersJdbcTemplate.queryForObject(sqlQuery, String.class);
        assertNotEquals(userDetails.password, actualPassword);
    }

    @Test
    @Category(ChangeRequest.CR_1398.class)
    public void AttemptToCreateALocalUserWithNationalRole_BadRequestResponse() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.RulesManagerLocal_POO();

        //Act
        userDetails.locationRoles.get(0).roleName = TestEnumerators.UserRoles.RuleManager.toString();

        API.RulesManagementService.Users.CreateUser.CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, createUserResponse.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_1398.class)
    public void AttemptToCreateANationalUserWithLocalRole_BadRequestResponse() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();

        //Act
        userDetails.locationRoles.get(0).roleName = TestEnumerators.UserRoles.LocalAdmin.toString();

        API.RulesManagementService.Users.CreateUser.CreateUserResponse createUserResponse = API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, createUserResponse.httpStatusCode);
    }
}
