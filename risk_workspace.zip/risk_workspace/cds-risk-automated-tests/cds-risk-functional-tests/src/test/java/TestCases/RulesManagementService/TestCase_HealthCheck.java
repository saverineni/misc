package TestCases.RulesManagementService;

import API.EnvDetails.EnvDetails;
import API.RulesManagementService.Monitoring.AdminResponse;
import API.Utils;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.HealthCheck;
import TestCases.BaseWebAPITestCase;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpStatus.OK;

@Category(HealthCheck.class)
public class TestCase_HealthCheck extends BaseWebAPITestCase {

    @Test
    @Category(ChangeRequest.CR_259.class)
    public void givenInfoEndpointWhenGetRequestThen200ReturnedWithCorrectBuildInfo() throws Exception {
        String expectedServiceName = "cds-risk";

        AdminResponse.InfoResponseObject infoResponse = Utils.makeInfoRequest(EnvDetails.url_RM_Info);
        AdminResponse.BuildInfo buildInfo = infoResponse.getBuild();

        assertThat(infoResponse.httpStatusCode).isEqualTo(OK.value());
        assertThat(buildInfo.getVersion()).startsWith("v");

        assertThat(buildInfo.getArtifact()).isEqualTo(expectedServiceName);
        assertThat(buildInfo.getName()).isEqualTo(expectedServiceName);

        assertThat(infoResponse.getGit()).isNotNull();
    }

    @Test
    @Category(ChangeRequest.CR_259.class)
    public void givenHealthEndpointWhenGetRequestedThen200WithUpStatusReturned() throws Exception {
        AdminResponse.HealthResponseObject healthResponse = Utils.makeHealthRequest(EnvDetails.url_RM_Health);

        assertThat(healthResponse).isNotNull();
        assertThat(healthResponse.httpStatusCode).isEqualTo(OK.value());
        assertThat(healthResponse.getStatus()).isEqualTo("UP");
    }
}
