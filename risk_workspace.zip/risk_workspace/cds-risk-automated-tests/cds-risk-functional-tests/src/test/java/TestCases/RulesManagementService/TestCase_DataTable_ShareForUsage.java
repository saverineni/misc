package TestCases.RulesManagementService;

import API.DataForTests.*;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.ShareDataTable.ShareDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import API.RulesManagementService.Data.ViewDataTableList.ViewDataTableListResponse;
import Categories_CDSRisk.CDS_RM_DataTable;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import org.apache.commons.httpclient.HttpStatus;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.ArrayList;
import java.util.List;

import static API.RulesManagementService.Utils.DataTables.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@Category({Rules_Management.class, CDS_RM_DataTable.class})
public class TestCase_DataTable_ShareForUsage extends WebAPITestCaseWithDatatablesCleanup {

    private TestDataTableModel.TableDetails tableDetails;

    @Before
    public void Setup() {

        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_POO());
        tableDetails = DataTables.DataTable_CommodityCodes_POO();
    }


    @Test
    @Category({ChangeRequest.CR_787.class, ChangeRequest.CR_2109.class})
    public void WhenRestrictedDataTableSharedWithSingleLocation_ListOfLocationsUpdatedSuccessfully()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.useTablesLocationUuids.clear();
        tableDetails.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        ShareDataTableResponse.ShareDataTableResponseObject shareDataTableResponseObject = ShareDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject responseTableDetails = GetDataTableByUID(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, shareDataTableResponseObject.httpStatusCode);

        Assertions.assertThat(shareDataTableResponseObject.manageTables).extracting("locationName")
                .containsOnly("POO");

        Assertions.assertThat(shareDataTableResponseObject.useTables).extracting("locationName")
                .containsOnly("POO", "EXT");

        Assertions.assertThat(responseTableDetails.locations.manageTables).extracting("locationName")
                .containsOnly("POO");

        Assertions.assertThat(responseTableDetails.locations.useTables).extracting("locationName")
                .containsOnly("POO", "EXT");
    }


    @Test
    @Category(ChangeRequest.CR_787.class)
    public void WhenDataTableSharedWithMultipleLocations_ListOfLocationsUpdatedSuccessfully()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.useTablesLocationUuids.clear();
        tableDetails.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.useTablesLocationUuids.add(Locations.Location_WAT_UID);
        tableDetails.useTablesLocationUuids.add(Locations.Location_LON_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        ShareDataTableResponse.ShareDataTableResponseObject shareDataTableResponseObject = ShareDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject responseTableDetails = GetDataTableByUID(tableDetails.uuid);

        //Assert
        Assertions.assertThat(shareDataTableResponseObject.manageTables).extracting("locationName")
                .containsOnly("POO");

        Assertions.assertThat(shareDataTableResponseObject.useTables).extracting("locationName")
                .containsOnly("POO", "EXT", "WAT", "LON");

        Assertions.assertThat(responseTableDetails.locations.manageTables).extracting("locationName")
                .containsOnly("POO");

        Assertions.assertThat(responseTableDetails.locations.useTables).extracting("locationName")
                .containsOnly("POO", "EXT", "WAT", "LON");
   }


    @Test
    @Category(ChangeRequest.CR_983.class)
    public void WhenDataTableSharedWithSameLocation_ServiceHandlesRequestWithoutServerException()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        tableDetails.useTablesLocationUuids.clear();
        tableDetails.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponseObject = GetDataTableDetailsByUID(tableDetails.uuid);
        tableDetails.opLockVersion = viewDataTableResponseObject.opLockVersion;
        //Act
        ShareDataTableResponse.ShareDataTableResponseObject shareDataTableAgainResp = API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject responseTableDetails = GetDataTableByUID(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, shareDataTableAgainResp.httpStatusCode);

        Assertions.assertThat(shareDataTableAgainResp.manageTables).extracting("locationName")
                .containsOnly("POO");

        Assertions.assertThat(shareDataTableAgainResp.useTables).extracting("locationName")
                .containsOnly("POO", "EXT");

        Assertions.assertThat(responseTableDetails.locations.manageTables).extracting("locationName")
                .containsOnly("POO");

        Assertions.assertThat(responseTableDetails.locations.useTables).extracting("locationName")
                .containsOnly("POO", "EXT");

    }


    @Test
    @Category(ChangeRequest.CR_787.class)
    public void WhenDataTableSharedWithLocationEXT_UserFromEXTCanViewDataTable()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.useTablesLocationUuids.clear();
        tableDetails.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        //Assert
        TestUserModel.UserDetails usTD2 = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(usTD2);
        API.RulesManagementService.Utils.Users.LoginAsUser(usTD2.pid);

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = GetListOfDataTables();

        boolean tableFound = CheckIfDataTableNameIsPresentInListOfTables(viewDataTableListResponseObject, tableDetails.tableName);
        assertEquals("Expect table: " + tableDetails.tableName + " to be present", true, tableFound);
    }

    @Test
    @Category(ChangeRequest.CR_787.class)
    public void WhenDataTableSharedWithLocalDataMangerWithLocationEXT_DataManagerWithEXTCanViewDataTable()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.useTablesLocationUuids.clear();
        tableDetails.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        //Assert
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminLocal_POO_EXT());
        TestUserModel.UserDetails usTD2 = Users_API.DataManager_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(usTD2);
        API.RulesManagementService.Utils.Users.LoginAsUser(usTD2.pid);

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = GetListOfDataTables();

        boolean tableFound = CheckIfDataTableNameIsPresentInListOfTables(viewDataTableListResponseObject, tableDetails.tableName);
        assertEquals("Expect table: " + tableDetails.tableName + " to be present", true, tableFound);
    }


    @Test
    @Category(ChangeRequest.CR_787.class)
    public void WhenDataTableSharedWithLocationEXTAndWAT_UserFromEXTOrWATCanViewDataTable()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.useTablesLocationUuids.clear();
        tableDetails.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.useTablesLocationUuids.add(Locations.Location_WAT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        //Assert
        TestUserModel.UserDetails usTD2 = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(usTD2);
        API.RulesManagementService.Utils.Users.LoginAsUser(usTD2.pid);

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListEXTResponse = GetListOfDataTables();

        boolean tableFound = CheckIfDataTableNameIsPresentInListOfTables(viewDataTableListEXTResponse, tableDetails.tableName);
        assertEquals("Expect table: " + tableDetails.tableName + " to be present", true, tableFound);

        TestUserModel.UserDetails udLOCRuleManagerWAT = Users_API.RulesManagerLocal_WAT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManagerWAT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManagerWAT.pid);

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListWATResponse = GetListOfDataTables();

        tableFound = CheckIfDataTableNameIsPresentInListOfTables(viewDataTableListWATResponse, tableDetails.tableName);
        assertEquals("Expect table: " + tableDetails.tableName + " to be present", true, tableFound);
    }


    @Test
    @Category(ChangeRequest.CR_787.class)
    public void WhenDataTableSharedWithLocationNational_NationalUserCanViewDataTable()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.useTablesLocationUuids.clear();
        tableDetails.useTablesLocationUuids.add(Locations.Location_National_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        ShareDataTableResponse.ShareDataTableResponseObject shareDataTableResponseObject = ShareDataTableAndGetResponseObject(tableDetails);

        //Assert
        TestUserModel.UserDetails udNATRuleManager = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(udNATRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udNATRuleManager.pid);

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = GetListOfDataTables();

        boolean tableFound = CheckIfDataTableNameIsPresentInListOfTables(viewDataTableListResponseObject, tableDetails.tableName);
        assertEquals("Expect table: " + tableDetails.tableName + " to be present", true, tableFound);
    }


    @Test
    @Category(ChangeRequest.CR_787.class)
    public void WhenDataTableSharedWithAllLocations_LocalUserCanViewDataTable()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.useTablesLocationUuids.clear();
        tableDetails.useTablesLocationUuids.add(Locations.Location_AllLocations_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        //Assert
        TestUserModel.UserDetails udLOCRuleManagerEXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManagerEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManagerEXT.pid);


        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = GetListOfDataTables();

        boolean tableFound = CheckIfDataTableNameIsPresentInListOfTables(viewDataTableListResponseObject, tableDetails.tableName);
        assertEquals("Expect table: " + tableDetails.tableName + " to be present", true, tableFound);
    }


    @Test
    @Category(ChangeRequest.CR_787.class)
    public void WhenDataTableSharedWithAllLocationsSetToTrue_LocalUserCanViewDataTable()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.shareAllLocations = true;
        tableDetails.useTablesLocationUuids.clear();
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        //Assert
        TestUserModel.UserDetails udLOCRuleManagerEXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManagerEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManagerEXT.pid);


        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = GetListOfDataTables();

        boolean tableFound = CheckIfDataTableNameIsPresentInListOfTables(viewDataTableListResponseObject, tableDetails.tableName);
        assertEquals("Expect table: " + tableDetails.tableName + " to be present", true, tableFound);
    }


    @Test
    @Category(ChangeRequest.CR_1027.class)
    public void WhenDataTableSharedWithLocationEXT_UserFromEXTIsNotManagerOfSharedDataTable()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.useTablesLocationUuids.clear();
        tableDetails.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_POO());
        ShareDataTableAndGetResponseObject(tableDetails);

        TestUserModel.UserDetails udLOCRuleManagerEXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManagerEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManagerEXT.pid);

        ViewDataTableResponse.ViewDataTableResponseObject viewDTResponse = GetDataTableByUID(tableDetails.uuid);

        //Assert
        assertEquals(tableDetails.tableName, viewDTResponse.tableName);

        assertEquals("Expect 2 Use Locations: ", 2,  viewDTResponse.locations.useTables.size());
        assertEquals("Expect Manage Locations: ", 1,  viewDTResponse.locations.manageTables.size());
        assertEquals("Expect Manage Locations to contain manage location: ", Locations.Location_POO_UID,  viewDTResponse.locations.manageTables.get(0).locationUuid);
    }


    @Test
    @Category(ChangeRequest.CR_1027.class)
    public void WhenDataTableSharedWithAllLocations_UserFromEXTIsNotManagerOfSharedDataTable()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.useTablesLocationUuids.clear();
        tableDetails.useTablesLocationUuids.add(Locations.Location_AllLocations_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        TestUserModel.UserDetails udLOCRuleManagerEXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManagerEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManagerEXT.pid);

        ViewDataTableResponse.ViewDataTableResponseObject viewDTResponse = GetDataTableByUID(tableDetails.uuid);

        //Assert
        assertEquals(tableDetails.tableName, viewDTResponse.tableName);

        assertEquals("Expect 2 Use Locations: ", 2,  viewDTResponse.locations.useTables.size());
        assertEquals("Expect Manage Locations: ", 1,  viewDTResponse.locations.manageTables.size());
        assertEquals("Expect Manage Locations to contain manage location: ", Locations.Location_POO_UID,  viewDTResponse.locations.manageTables.get(0).locationUuid);
    }

    @Test
    @Category(ChangeRequest.CR_1186.class)
    public void WhenDataTableSharedWithLocationAndViewedByRuleManager_DataTableActionsCorrect()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        TestUserModel.UserDetails udLOCRuleManagerEXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManagerEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManagerEXT.pid);

        ViewDataTableResponse.ViewDataTableResponseObject response = GetDataTableByUID(tableDetails.uuid);

        //Assert
        //Actions should not contain "DATA_TABLE_MANAGE_USE", "DATA_TABLE_MANAGE_OWNERS", "DATA_TABLE_EDIT"
        Assertions.assertThat(response.metaData.actions).doesNotContainAnyElementsOf(tableDetails.actions);
    }


    @Test
    @Category(ChangeRequest.CR_1186.class)
    public void WhenDataTableSharedWithAllLocationsAndViewedByRuleManager_DataTableActionsCorrect()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.shareAllLocations = true;
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        TestUserModel.UserDetails udLOCRuleManagerEXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManagerEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManagerEXT.pid);

        ViewDataTableResponse.ViewDataTableResponseObject response = GetDataTableByUID(tableDetails.uuid);

        //Assert
        //Actions should not contain "DATA_TABLE_MANAGE_USE", "DATA_TABLE_MANAGE_OWNERS", "DATA_TABLE_EDIT"
        Assertions.assertThat(response.metaData.actions).doesNotContainAnyElementsOf(tableDetails.actions);
    }


    @Test
    @Category(ChangeRequest.CR_1186.class)
    public void WhenDataTableSharedWithLocationAndViewedByRuleViewer_DataTableActionsCorrect()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        TestUserModel.UserDetails udLOCRuleViewerEXT = Users_API.RulesViewerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleViewerEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleViewerEXT.pid);

        ViewDataTableResponse.ViewDataTableResponseObject response = GetDataTableByUID(tableDetails.uuid);

        //Assert
        //Actions should not contain "DATA_TABLE_MANAGE_USE", "DATA_TABLE_MANAGE_OWNERS", "DATA_TABLE_EDIT"
        Assertions.assertThat(response.metaData.actions).doesNotContainAnyElementsOf(tableDetails.actions);
    }


    @Test
    @Category(ChangeRequest.CR_1186.class)
    public void WhenDataTableSharedWithAllLocationsAndViewedByRuleViewer_DataTableActionsCorrect()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.shareAllLocations = true;
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        TestUserModel.UserDetails udLOCRuleViewerEXT = Users_API.RulesViewerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleViewerEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleViewerEXT.pid);

        ViewDataTableResponse.ViewDataTableResponseObject response = GetDataTableByUID(tableDetails.uuid);

        //Assert
        //Actions should not contain "DATA_TABLE_MANAGE_USE", "DATA_TABLE_MANAGE_OWNERS", "DATA_TABLE_EDIT"
        Assertions.assertThat(response.metaData.actions).doesNotContainAnyElementsOf(tableDetails.actions);
    }


    @Test
    @Category({ChangeRequest.CR_787.class, ChangeRequest.CR_2148.class})
    public void WhenSensitiveDataTableSharedWithSingleLocation_ListOfLocationsUpdatedSuccessfully()
    {
        //Arrange
        tableDetails.tableType = "sensitive";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.useTablesLocationUuids.clear();
        tableDetails.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        ShareDataTableResponse.ShareDataTableResponseObject shareDataTableResponseObject = ShareDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject response = GetDataTableByUID(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, shareDataTableResponseObject.httpStatusCode);
        assertEquals("Expect Manage Locations: ", 1,  shareDataTableResponseObject.manageTables.size());
        assertEquals("Expect Use Locations: ", 2,  shareDataTableResponseObject.useTables.size());

        List<String> actUseLocations = new ArrayList<String>();
        for (int i=0; i < response.locations.useTables.size(); i++){

            actUseLocations.add(response.locations.useTables.get(i).locationUuid);
        }

        assertEquals("Expect 2 Use Locations: ", 2,  response.locations.useTables.size());
        assertTrue("Expect Use Locations to contain shared location", actUseLocations.containsAll(tableDetails.useTablesLocationUuids));
        assertTrue("Expect Use Locations to contain manage location", actUseLocations.containsAll(tableDetails.manageTableLocationUuids));

        assertEquals("Expect Manage Locations: ", 1,  response.locations.manageTables.size());
        assertEquals("Expect Manage Locations to contain manage location: ", Locations.Location_POO_UID,  response.locations.manageTables.get(0).locationUuid);
    }


    @Test
    @Category({ChangeRequest.CR_2465.class})
    public void AttemptToShareOpenDataTableSharedWithSingleLocation_ForbiddenReturned()
    {
        //Arrange
        tableDetails.tableType = "open";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.useTablesLocationUuids.clear();
        tableDetails.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        ShareDataTableResponse.ShareDataTableResponseObject shareDataTableResponseObject = ShareDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject response = GetDataTableByUID(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_FORBIDDEN, shareDataTableResponseObject.httpStatusCode);

        Assertions.assertThat(response.locations.manageTables).extracting("locationName")
                .containsOnly("POO");

        Assertions.assertThat(response.locations.useTables).extracting("locationName")
                .containsOnly("POO", "All Locations");

        assertEquals("Expect Manage Locations: ", 1,  response.locations.manageTables.size());
        assertEquals("Expect Use Locations: ", 2,  response.locations.useTables.size());
    }

}
