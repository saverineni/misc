package TestCases.RiskingServiceJava.RATS;

import Categories_CDSRisk.ChangeRequest_RiskingService.CREP_145;
import Categories_CDSRisk.Risking_JavaService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel.MetadataDefinition;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel.RuleDefinition;
import uk.gov.hmrc.risk.rulesengine.rules.RuleMetadata;
import uk.gov.hmrc.risk.test.common.enums.DeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.HeaderAttribute;
import uk.gov.hmrc.risk.test.common.enums.HeaderDeclarationParam;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleCreationModel;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static org.junit.Assert.assertTrue;
import static uk.gov.hmrc.risk.test.common.enums.Matcher.equalTo;
import static uk.gov.hmrc.risk.test.common.enums.MatcherType.EQUAL;
import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.*;

;

@Slf4j
@Category({CREP_145.class, Risking_JavaService.class})
public class TestCase_VerifyRatsFirstCountWeeklyHitLimit extends BaseRatsTests {

    String description = "taRATSRule";

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenConsigneeEORIRuleWithRatsLimit_RuleStopsFiringAfterReachingRatsLimit() {

        int ratsLimit = 2;
        int decCount = ratsLimit + 5;

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();
        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNOR_EORI,  "AE123456789ABCDE");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_TYPE, "IM");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "C");

        String ruleDefinition = createRuleDefinitionModel("AE123456789ABCDE", ratsLimit).toString();

        RuleCreationModel rule = baseRuleCreationModelBuilder()
                .description(description)
                .definition(ruleDefinition)
                .build();

        int routesReturned = createRuleAndSendDeclarations(rule, declarationFieldValues, decCount);
        assertTrue(routesReturned==ratsLimit);
    }

    @Test
    public void WhenWeeklyRatsLimitIsSetToZero_RuleDoNotFire() {

        int ratsLimit = 0;
        int decCount = ratsLimit + 5;

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();
        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNOR_EORI,  "AE123456789ABCDE");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_TYPE, "IM");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "C");

        String ruleDefinition = createRuleDefinitionModel("AE123456789ABCDE", ratsLimit).toString();

        RuleCreationModel rule = baseRuleCreationModelBuilder()
                .description(description)
                .definition(ruleDefinition)
                .build();

        int routesReturned = createRuleAndSendDeclarations(rule, declarationFieldValues, decCount);
        assertTrue(routesReturned==0);
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRatsLimitForWeeklyLimitIsHitAndWeekReset_RuleShouldFire() {

        int ratsLimit = 5;
        int decCount = ratsLimit + 1;

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();
        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNOR_EORI,  "NL000111222");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_TYPE, "IM");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "C");

        String ruleDefinition = createRuleDefinitionModel("NL000111222", ratsLimit).toString();

        RuleCreationModel rule = baseRuleCreationModelBuilder()
                .description(description)
                .definition(ruleDefinition)
                .build();

        int routesReturned = createRuleAndSendDeclarations(rule, declarationFieldValues, decCount);
        assertTrue(routesReturned==ratsLimit);

        //add the new week
        addWeeksToRiskingSystemTime(1);

        DeclarationResponse response = sendDeclaration(declarationFieldValues);
        assertTrue(!response.getControlType().isEmpty());
    }

    private RuleDefinitionModel createRuleDefinitionModel(String EORI, int ratsLimit) {

        RuleDefinitionModel model = defaultModel();
        model.getRuleDefinitions().clear();
        RuleDefinition ruleDefinition = RuleDefinition.builder().build();
        ruleDefinition.addMetadata(new MetadataDefinition(RuleMetadata.UNIQUE_ID, Optional.of("#UniqueId#")));
        ruleDefinition.addMetadata(new MetadataDefinition(RuleMetadata.RAT_FIRST_COUNT_WEEKLY_LIMIT, Optional.of(ratsLimit)));
        ruleDefinition.setName(description);

        Condition consigneeEori = Condition.builder()
                .attribute(HeaderAttribute.CONSIGNOR_EORI)
                .matcherType(EQUAL)
                .matcherClass(MatcherClass.Matchers)
                .matcher(equalTo)
                .value(EORI)
                .source(Source.declaration)
                .build();

        String declaration = strCheck( consigneeEori );
        ruleDefinition.setWhenDef( declarationWrapper(declaration) );
        ruleDefinition.setThenDef(thenCreator(Source.declaration, conditions( consigneeEori )));
        model.getRuleDefinitions().add(ruleDefinition);
        return model;
    }
}
