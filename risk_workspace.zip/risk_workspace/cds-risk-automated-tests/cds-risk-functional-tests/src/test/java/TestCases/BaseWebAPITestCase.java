package TestCases;

import API.DataForTests.Locations;
import API.DataForTests.RegimeCodes;
import lombok.extern.slf4j.Slf4j;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.rules.TestName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import uk.gov.hmrc.risk.test.common.dao.DataTableDao;
import uk.gov.hmrc.risk.test.common.dao.RuleDao;

import java.io.IOException;

import static API.RulesManagementService.Utils.Publish.setPublishAutomaticEventTime;

@Slf4j
public class BaseWebAPITestCase extends BaseSpringBootTestCase
{
    public BaseWebAPITestCase()
    {

    }
    @Autowired
    protected RuleDao ruleDao;
    @Autowired
    protected DataTableDao dataTableDao;
    @Autowired
    @Qualifier("ruleJdbcTemplate")
    protected JdbcTemplate ruleJdbcTemplate;


    @Rule
    public TestName testName = new TestName();

    @Before
    public void BaseAPISetup() throws Throwable
    {
        String className = this.getClass().getSimpleName();
        String methodName = this.testName.getMethodName();

        ruleDao.deleteAll();
        mySQL_cds_rules.DeleteUsersFromDB();
        mySQL_cds_publishing.deletePublishHistoryDataFromDB();
        setPublishAutomaticEventTime("18000");
        cacheLoaderSupport.clearDown();

        Locations.SetAllLocationUIDs();
        RegimeCodes.SetAllRegimeCodeUIDs();

        //need to login via api to get token to allow users to be created
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        //need to login via api to get token to allow get security status uids to be retrieved
        API.RulesManagementService.Utils.Users.LoginAsNationalRulesManagerDefaultTestAutomationUser();

//        dataTypesUtils.getDefaultDataTypesUUIDSFromMySQLDB();

        log.info("------End of Setup-------------------------------------");

        log.info("#### Start of test: " + className + "." + methodName + "####");
        log.info("\r\n");
    }


    @After
    public void TearDown() throws IOException
    {
        String className = this.getClass().getSimpleName();
        String methodName = this.testName.getMethodName();
        log.info("#### Finished Test: " + className + "." + methodName + "####");
        log.info("\r\n");
    }


}
