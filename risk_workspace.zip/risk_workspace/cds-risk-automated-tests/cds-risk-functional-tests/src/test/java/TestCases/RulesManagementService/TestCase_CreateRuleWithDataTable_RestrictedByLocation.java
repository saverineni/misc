package TestCases.RulesManagementService;


import API.DataForTests.*;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import Categories_CDSRisk.CDS_RM_CreateRules;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import org.apache.http.HttpStatus;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_CreateRules.class})
public class TestCase_CreateRuleWithDataTable_RestrictedByLocation extends WebAPITestCaseWithDatatablesCleanup {

    @Test
    @Category(ChangeRequest.CR_2066.class)
    @Ignore("Negative test - Backend does not stop creating a rule with wrong data type atm ")
    public void WhenCreatingARuleWithDataTable_CanOnlyAddDataTableWithSpecificToRuleLocationAndDataType() throws Throwable {

        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.manageTableLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.manageTableLocationUuids.add(Locations.Location_WAT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = Rules.DraftLOCRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.commodityCode().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = Conditions.commodityCode().attributeType;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = tableDetails.uuid;

        ruleDetails.locations.add(0, Locations.Location_EXT_UID);
        ruleDetails.queryConditions.get(0).conditions.get(0).isDataTable = true;
        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);

        assertEquals(HttpStatus.SC_CREATED, createRuleResponse.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_2066.class)
    @Ignore("Negative test - Backend does not stop creating a rule with wrong data type atm ")
        //"Positive scenarios are already cover by other tests"
    public void WhenCreatingARuleWithDataTable_CanOnlyAddDataTableWithSpecificToRuleLocation() throws Throwable {

        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_FreeText_Valid();
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.manageTableLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.manageTableLocationUuids.add(Locations.Location_WAT_UID);
        tableDetails.manageTableLocationUuids.add(Locations.Location_LON_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetails);

        TestRuleModel.RuleDetails ruleDetails = Rules.DraftLOCRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.commodityCode().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = Conditions.commodityCode().attributeType;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = tableDetails.uuid;

        ruleDetails.locations.add(0, Locations.Location_POO_UID);
        ruleDetails.queryConditions.get(0).conditions.get(0).isDataTable = true;
        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);

        assertEquals(HttpStatus.SC_BAD_REQUEST, createRuleResponse.httpStatusCode);
    }

}
