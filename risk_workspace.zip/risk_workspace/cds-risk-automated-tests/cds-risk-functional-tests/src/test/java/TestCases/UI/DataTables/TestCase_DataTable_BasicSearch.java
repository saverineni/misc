package TestCases.UI.DataTables;


import API.DataForTests.*;
import API.DataService.CreateDataTable.CreateDataTableResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_DataTables;
import Categories_CDSRisk.CDS_Risk_UI_DataTables_1;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.ElementControls.MultiSelectDropDown;
import UI.Pages.DataManagement.ListDataTable_Page;
import UI.Utils.Navigation;
import com.google.common.collect.ImmutableList;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static API.Utils.LoginAsAPIUserAndCreateDataTableForLocation;
import static FunctionsLibrary.Utils.SleepForMilliSeconds;
import static UI.Utils.DataTables.getDataTableListDetails;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_DataTables.class, CDS_Risk_UI_DataTables_1.class})
public class TestCase_DataTable_BasicSearch extends BaseUIWebDriverTestCase {

    private TestUserModel.UserDetails userDetails_POO;
    private TestUserModel.UserDetails userDetails_EXT;
    private TestUserModel.UserDetails userDetails_NAT;
    private TestDataTableModel.TableDetails tableDetailsPOO;
    private TestDataTableModel.TableDetails tableDetailsPartCommodityPOO;
    private  TestDataTableModel.TableDetails tableDetailsFreeText;
    private TestDataTableModel.TableDetails tableDetailsEXT;
    private TestDataTableModel.TableDetails tdDefaultTestDataTable;
    private TestDataTableModel.TableDetails tableDetailsLON;


    @Before
    public void LocalSetup()
    {
        //Login as User 1 create data table for POO
        userDetails_POO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_POO);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_POO.pid);

        tableDetailsPOO = DataTables.DataTable_CommodityCodes_POO();
        tableDetailsPOO.tags = ImmutableList.of("POO", "Commodity Codes");
        API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsPOO);

        tableDetailsPartCommodityPOO = DataTables.DataTable_PartCommodityCodes_POO();
        tableDetailsPartCommodityPOO.tags = ImmutableList.of("Poo", "Part Commodity Codes");
        API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsPartCommodityPOO);

        tableDetailsFreeText = DataTables.DataTable_FreeText_Valid();
        tableDetailsFreeText.tags = ImmutableList.of("National Office", "Free text");
        API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsFreeText);

        //Login as User 2 create data table for EXT
        userDetails_EXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_EXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_EXT.pid);

        tableDetailsEXT = DataTables.DataTable_CommodityCodes_EXT();
        CreateDataTableResponse.PostResponse createDataTableesponse3 = API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsEXT);

        //Create user
        userDetails_NAT = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_NAT);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_NAT.pid);

        tableDetailsLON = DataTables.DataTable_RestrictedToLondon();
        API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsLON);

        tdDefaultTestDataTable = DataTables.DataTable_DefaultCommodityCodes();
//        API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tdDefaultTestDataTable);

    }


    @Category({ChangeRequest.CR_2602.class})
    @Test
    @Ignore("Will be fixed as part of CR-3194")
    public void WhenLocalRuleManagerLoggedIn_FilterByNameShouldShowCorrectTablesInListMyTablesPage() {

        //Arrange
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetails_POO);
        //Act
        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listDataTable_page =utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);
        SleepForMilliSeconds(2000);
        listDataTable_page.filterTableTitleTextField.sendKeys("paRt");
        SleepForMilliSeconds(2000);
        List<String> dataTableTitles = getDataTableListDetails(listDataTable_page);
        //Assert
        Assertions.assertThat(dataTableTitles).containsOnly(tableDetailsPartCommodityPOO.tableName);
  }

    @Category({ChangeRequest.CR_2621.class})
    @Test
    public void WhenLocalRuleManagerLoggedIn_FilterByAccessShouldShowCorrectTablesInListAllTablesPage() {

        //Arrange
        TestDataTableModel.TableDetails tdDefaultTestDataTable = DataTables.DataTable_DefaultCommodityCodes();
        API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tdDefaultTestDataTable);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetails_EXT);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);
        SleepForMilliSeconds(1000);

        ListDataTable_Page listDataTable_page = new ListDataTable_Page(driver);
        listDataTable_page.accessDropDown.click();
        listDataTable_page.selectFromDropdown("Not shared with me");

        listDataTable_page.locationDropDown.click();
        listDataTable_page.selectFromDropdown("National Office");

        List<ListDataTable_Page.DataTableListObject> dataTables = listDataTable_page.getDataTableListDetails();
        Assertions.assertThat(dataTables).extracting("tableTitle").containsOnly(tableDetailsFreeText.tableName,tdDefaultTestDataTable.tableName);
    }

    @Category({ChangeRequest.CR_2621.class,ChangeRequest.CR_2622.class})
    @Test
    public void WhenFilteredByCombination_ResultShouldBeShownCorrectlyInListAllTablesPage() {
        //Arrange
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetails_NAT);

        API.DataForTests.TestDataTableModel.TableDetails tableDetails1 = DataTables.DataTable_Decimal_Valid();
        tableDetails1.tableType = "Sensitive";
        LoginAsAPIUserAndCreateDataTableForLocation(userDetails_NAT, tableDetails1);

        API.DataForTests.TestDataTableModel.TableDetails tableDetails2 = DataTables.DataTable_CommodityCodes_POOEXT();
        tableDetails2.tableType = "Sensitive";
        LoginAsAPIUserAndCreateDataTableForLocation(userDetails_NAT, tableDetails2);


        //Act
        Navigation utilNavigation = new Navigation(driver);
        utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        ListDataTable_Page listDataTable_page = new ListDataTable_Page(driver);
        listDataTable_page.accessDropDown.click();
        listDataTable_page.selectFromDropdown("Owner");

        listDataTable_page.locationDropDown.click();
        listDataTable_page.selectFromDropdown("National Office");

        listDataTable_page.dataTypeDropDown.click();
        listDataTable_page.selectFromDropdown("Decimal");

        listDataTable_page.tableTypeDropDown.click();
        listDataTable_page.selectFromDropdown("Sensitive");

        List<ListDataTable_Page.DataTableListObject> dataTables = listDataTable_page.getDataTableListDetails();
       //Assert
        Assertions.assertThat(dataTables).extracting("tableTitle").containsOnly(tableDetails1.tableName);
    }


    @Category({ChangeRequest.CR_2627.class})
    @Test
    @Ignore("Will be fixed as part of CR-3194")
    public void WhenFilteredByDataTablesTag_ResultShouldBeShownCorrectlyInListAllTablesPage() {
        //Arrange
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetails_NAT);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        ListDataTable_Page listDataTable_page = new ListDataTable_Page(driver);
        listDataTable_page.datatTableTagDropDown.click();
        listDataTable_page.datatTableTagTextField.sendKeys("Commodity Codes");
        SleepForMilliSeconds(500);
        List<String> listOfMatchingTags = listDataTable_page.getTheListOfMatchingTags();

        listDataTable_page.datatTableTagTextField.clear();
        listDataTable_page.datatTableTagTextField.sendKeys("Banned");
        SleepForMilliSeconds(500);
        List<String> listOfResultsForANonExistentTag = listDataTable_page.getTheListOfMatchingTags();


        listDataTable_page.datatTableTagTextField.clear();
        listDataTable_page.datatTableTagTextField.sendKeys(" ");
        listDataTable_page.datatTableTagDropDown.click();

        ArrayList<String> tagsToFilterBy = new ArrayList<String>(Arrays.asList("Commodity Codes","Part Commodity Codes"));
        listDataTable_page.filterDataTablesByTag(tagsToFilterBy);

        SleepForMilliSeconds(500);
        List<ListDataTable_Page.DataTableListObject> listOfDataTablesDisplayedFor2Tags = listDataTable_page.getDataTableListDetails();
        listDataTable_page.selectFromDropdown("National Office");
        List<ListDataTable_Page.DataTableListObject> listOfDataTablesDipslayedForNational = listDataTable_page.getDataTableListDetails();


        //Assert for the list of matching tags after searching for a particular tag
        Assertions.assertThat(listOfMatchingTags).containsOnly("Commodity Codes","Part Commodity Codes");

        //Assert there are no matching tags when searched for a non existent tag
        Assertions.assertThat(listOfResultsForANonExistentTag).hasSize(0);

        //Filtering on particular tag displays the relevant data tables
        Assertions.assertThat(listOfDataTablesDisplayedFor2Tags).extracting("tableTitle")
                            .contains(tableDetailsPartCommodityPOO.tableName, tableDetailsPOO.tableName);

    }

    @Category({ChangeRequest.CR_3009.class})
    @Test
    public void WhenNationalAdminLoggedIN_FilterByLocationShouldShowCorrectTablesInListAllTablesPage() {

        //Arrange
        TestDataTableModel.TableDetails tdDefaultTestDataTable = DataTables.DataTable_DefaultCommodityCodes();
        API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tdDefaultTestDataTable);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetails_NAT);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);
        SleepForMilliSeconds(1000);

        ListDataTable_Page listDataTable_page = new ListDataTable_Page(driver);
        MultiSelectDropDown dropDown = new MultiSelectDropDown(driver);
        listDataTable_page.scrollToViewTheElement(listDataTable_page.locationDropDown);
        listDataTable_page.locationDropDown.click();
        dropDown.searchAndSelectTheValue(listDataTable_page.locationDropDown, listDataTable_page.searchInput, "POO", "POO - Poole");
        dropDown.searchAndSelectTheValue(listDataTable_page.locationDropDown, listDataTable_page.searchInput, "Lon", "LON - London");

        List<ListDataTable_Page.DataTableListObject> dataTables = listDataTable_page.getDataTableListDetails();
        Assertions.assertThat(dataTables).extracting("tableTitle").containsOnly("ta_TableRestrictedToLondon", "ta_TableCommodityCodesPOO");
    }

}

