package TestCases.RiskingService;


import API.DataForTests.Conditions;
import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestRuleModel;
import API.RiskingService.Declaration.SubmitDeclarationRequestFromFile;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Slow_Tests;
import TestCases.BaseWebAPITestCase;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.HeaderDeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.TransportMode;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeoutException;

import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
@Category(Slow_Tests.class)
public class TestCase_RiskingService_AttributesMultiple extends BaseWebAPITestCase {

    @Before
    public void setup() throws IOException, TimeoutException
    {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
    }


    @Test
    @Category({ChangeRequest.CRX_2.class})
    public void WhenDeclarationSubmittedForTransportCountry_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.transportCountry());
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.transportCountry = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.transportRole = "2";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CRX_2.class})
    public void WhenDeclarationSubmittedForTransportIdentifier_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.transportIdentifier());
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.transportIdentifier = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.transportRole = "2";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }



    @Test
    @Category({ChangeRequest.CRX_2.class})
    public void WhenDeclarationSubmittedForInlandModeOfTransport_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.inlandModeOfTransport());
        ruleDetails.ruleOutputs.actionType = "1";
        ruleDetails.queryOptions.transportMode = TransportMode.All.toString();

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.transportMode = Conditions.inlandModeOfTransport().value;
        declaration.transportRole = "5";        //5 = inland
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        //note inland mode of transport is allways 5. It actually returns mode of transport
        modelSupport.checkDeclarationFieldValue(declarationRequest, HeaderDeclarationParam.INLAND_MODE_OF_TRANSPORT.toString(),
                declaration.transportMode);

        modelSupport.checkDeclarationFieldValue(declarationRequest, HeaderDeclarationParam.TRANSPORT_MODE.toString(),
                declaration.transportMode);

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CRX_6.class})
    public void WhenDeclarationSubmittedForAdditionalCommodityCodeTwo14Digits_NoRouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.additionalCommodityCode2());
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.commodity = "1234567890" + Conditions.additionalCommodityCode2().value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

//        modelSupport.checkItemFieldValue(declarationRequest, GoodsItemDeclarationParam.ADDITIONAL_COM_CODE.toString(),
//                                        declaration.commodity);

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        declaration.controlTypeExpectedValue = "";
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }



    @Test
    @Category({ChangeRequest.CRX_104.class})
    public void WhenDeclarationSubmittedForImportConsigneeHeaderFields_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consigneeAddress());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consigneeCity());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consigneeCountry());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consigneeEori());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consigneeName());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consigneePostcode());

        ruleDetails.ruleOutputs.actionType = "1";
        ruleDetails.queryOptions.declarationType = "EX";


        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.consigneeAddress = Conditions.consigneeAddress().value;
        declaration.consigneeCity = Conditions.consigneeCity().value;
        declaration.consigneeCountry = Conditions.consigneeCountry().value;
        declaration.consigneeEori = Conditions.consigneeEori().value;
        declaration.consigneeName = Conditions.consigneeName().value;
        declaration.consigneePostcode = Conditions.consigneePostcode().value;

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }


    @Test
    @Category({ChangeRequest.CRX_104.class})
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenDeclarationSubmittedForImportConsignorHeaderFields_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consignorAddress_Header());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consignorCity_Header());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consignorCountry_Header());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consignorEori_Header());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consignorName_Header());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consignorPostcode_Header());

        ruleDetails.ruleOutputs.actionType = "1";
        ruleDetails.queryOptions.declarationType = "EX";


        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.consignorAddress_Header = Conditions.consignorAddress_Header().value;
        declaration.consignorCity_Header = Conditions.consignorCity_Header().value;
        declaration.consignorCountry_Header = Conditions.consignorCountry_Header().value;
        declaration.consignorEori_Header = Conditions.consignorEori_Header().value;
        declaration.consignorName_Header = Conditions.consignorName_Header().value;
        declaration.consignorPostcode_Header = Conditions.consignorPostcode_Header().value;

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }


    @Test
    @Category({ChangeRequest.CRX_104.class})
    public void WhenDeclarationSubmittedForImportConsignorItemFields_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.exporterConsignorAddress_Item());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.exporterConsignorCity_Item());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.exporterConsignorCountry_Item());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.exporterConsignorEori_Item());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.exporterConsignorName_Item());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.exporterConsignorPostcode_Item());

        ruleDetails.ruleOutputs.actionType = "1";
        ruleDetails.queryOptions.declarationType = "EX";


        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.exporterConsignorAddress_Item = Conditions.exporterConsignorAddress_Item().value;
        declaration.exporterConsignorCity_Item = Conditions.exporterConsignorCity_Item().value;
        declaration.exporterConsignorCountry_Item = Conditions.exporterConsignorCountry_Item().value;
        declaration.exporterConsignorId_Item = Conditions.exporterConsignorEori_Item().value;
        declaration.exporterConsignorName_Item = Conditions.exporterConsignorName_Item().value;
        declaration.exporterConsignorZipCode_Item = Conditions.exporterConsignorPostcode_Item().value;

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        String returnedControlType = declarationResponse.getControlType();
        assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }



    //------------------------------------------------------------------------------------------

//    @Test
//    public void TEMP_WhenDeclarationSubmittedFor_HeaderField_goodsLocation() throws Throwable {
//
//        //Arrange
//        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
//
//        ruleDetails.queryConditions.get(0).conditions.clear();
//        ruleDetails.queryConditions.get(0).conditions.add(Conditions.goodsLocation());
//        ruleDetails.ruleOutputs.actionType = "1";
//
//        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
//        publishAndWait(5000);
//
//        //Debugging purposes
//        PublishEventModel latestPublishEvent = redisSupport.getLatestPublishEvent(2);
//        String s = redisSupport.get(latestPublishEvent.getRulePackageId().toString());
//
//        //Act
//        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
//        declaration.goodsLocation = ruleDetails.queryConditions.get(0).conditions.get(0).value;
//
//        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());
//
//        modelSupport.checkDeclarationFieldValue(declarationRequest, "goodsLocation",
//                                                    declaration.goodsLocation);
//
//        queue.send(declarationRequest);
//        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());
//
//        //Assert
//        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
//
//        List<String> reportBackElements = declarationResponse.getReportBackElements();
//        Assertions.assertThat(reportBackElements).contains("/declaration");
//    }

//
//
//

//    @Test
//    @Category({ChangeRequest.CRX_2.class})
//    public void TEMP_WhenDeclarationSubmittedFor_ItemField_baseAmount_Item() throws Throwable {
//
//        //Arrange
//        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
//
//        ruleDetails.queryConditions.get(0).conditions.clear();
//        ruleDetails.queryConditions.get(0).conditions.add(Conditions.baseAmount());
////        ruleDetails.queryConditions.get(0).conditions.add(Conditions.taxTypeCode());
//        ruleDetails.ruleOutputs.actionType = "1";
//
//        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
//        publishAndWait(5000);
//

          //Debugging purposes
//        PublishEventModel latestPublishEvent = redisSupport.getLatestPublishEvent(2);
//        String s = redisSupport.get(latestPublishEvent.getRulePackageId().toString());

//        //Act
//        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
//        declaration.baseAmount = ruleDetails.queryConditions.get(0).conditions.get(0).value;
////        declaration.taxTypeCode = ruleDetails.queryConditions.get(0).conditions.get(1).value;
//
//        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());
//
//        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
//
////        modelSupport.checkItemFieldValue(declarationRequest, GoodsItemDeclarationParam.CONSIGNEE_NAME_ITEM.toString(),
////                declaration.consigneeName_Item);
//
//        queue.send(declarationRequest);
//        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());
//
//        //Assert
//        String returnedControlType = declarationResponse.getControlType();
//        assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
//
//        List<String> reportBackElements = declarationResponse.getReportBackElements();
//        Assertions.assertThat(reportBackElements).hasSize(1)
//                .contains(declaration.reportBackElementsExpectedValue);
//    }


//    @Test
//    @Category({ChangeRequest.CRX_2.class})
//    public void TEMP_WhenDeclarationSubmittedFor_ItemField_prefOriginCountry() throws Throwable {
//
//        //Arrange
//        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
//
//        ruleDetails.queryConditions.get(0).conditions.clear();
//        ruleDetails.queryConditions.get(0).conditions.add(Conditions.preferentialOriginCountry());
//        ruleDetails.ruleOutputs.actionType = "1";
//
//        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
//        publishAndWait(5000);
//
//        //Debugging purposes
//        PublishEventModel latestPublishEvent = redisSupport.getLatestPublishEvent(2);
//        String s = redisSupport.get(latestPublishEvent.getRulePackageId().toString());
//        log.info(s);
//
//        //Act
//        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
//        declaration.preferentialOriginCountry = ruleDetails.queryConditions.get(0).conditions.get(0).value;
//        declaration.subRole = "2";
//
//        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());
//
//        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
//
//        modelSupport.checkItemFieldValue(declarationRequest, "preferentialOriginCountry",
//                declaration.preferentialOriginCountry);
//
//        queue.send(declarationRequest);
//        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());
//
//        //Assert
//        String returnedControlType = declarationResponse.getControlType();
//        assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);
//
//        List<String> reportBackElements = declarationResponse.getReportBackElements();
//        Assertions.assertThat(reportBackElements).hasSize(1)
//                .contains(declaration.reportBackElementsExpectedValue);
//    }




}
