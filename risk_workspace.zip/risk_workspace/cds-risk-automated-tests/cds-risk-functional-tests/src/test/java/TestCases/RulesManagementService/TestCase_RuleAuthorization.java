package TestCases.RulesManagementService;


import API.DataForTests.Locations;
import API.DataForTests.TestRuleModel.RuleDetails;
import API.DataForTests.Users_API;
import API.EnvDetails.EnvDetails;
import API.RulesManagementService.AmendRule.AmendRuleResponse;
import API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse;
import API.RulesManagementService.EditRule.EditRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionRequest;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse.PutResponse;
import API.RulesManagementService.ViewRule.ViewRuleResponse.ViewRuleResponseObject;
import API.RulesManagementService.ViewRuleList.ViewRuleListResponse.ViewRuleListResponseObject;
import API.RulesManagementService.ViewRuleVersion.ViewRuleVersionResponse.ViewRuleVersionResponseObject;
import Categories_CDSRisk.CDS_RM_RulesGeneral;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import FunctionsLibrary.DateTime;
import TestCases.BaseWebAPITestCase;
import org.apache.http.HttpStatus;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import static API.DataForTests.Rules.*;
import static API.RulesManagementService.Utils.RuleAtStatus.CreatePendingExpiredRuleVersion;
import static API.RulesManagementService.Utils.Rules.*;
import static API.RulesManagementService.Utils.Users.CreateUserAndLogin;
import static API.RulesManagementService.Utils.Users.LoginAsSuperAdmin;
import static org.assertj.core.api.Assertions.assertThat;

@Category({Rules_Management.class, CDS_RM_RulesGeneral.class})
public class TestCase_RuleAuthorization extends BaseWebAPITestCase {
    @Test
    @Category({ChangeRequest.CR_775.class})
    public void WhenRulesAreSearched_HttpForbiddenIsReturned_IfUserIsNotAuthorized() {
        RuleDetails rule = DraftLOCRuleNatManager();
        CreateRuleAndGetResponseObject(rule);

        LoginAsSuperAdmin();

        ViewRuleListResponseObject response = GetListOfRules(EnvDetails.url_RuleCreate);

        assertThat(response.httpStatusCode).isEqualTo(HttpStatus.SC_FORBIDDEN);
        assertThat(response.content).isNull();
    }

    @Test
    @Category({ChangeRequest.CR_775.class})
    public void WhenRetrievingARuleByUUid_HttpForbiddenIsReturned_IfUserIsNotAuthorized() {
        RuleDetails rule = DraftLOCRuleNatManager();
        rule.locations.add(Locations.Location_ABZ_UID);
        PostResponse createRuleResponse = CreateRuleAndGetResponseObject(rule);

        CreateUserAndLogin(Users_API.RulesManagerLocal_EXT());

        ViewRuleResponseObject viewRuleResponse = GetRuleByUID(createRuleResponse.uniqueId);

        assertThat(viewRuleResponse.httpStatusCode).isEqualTo(HttpStatus.SC_FORBIDDEN);
        assertThat(viewRuleResponse.uniqueId).isNull();
    }

    @Test
    @Category({ChangeRequest.CR_775.class})
    public void WhenRetrievingRuleByUuidAndVersion_HttpForbiddenIsReturned_IfUserIsNotAuthorised() {
        RuleDetails rule = DraftLOCRuleNatManager();
        rule.locations.add(Locations.Location_ABZ_UID);
        PostResponse createRuleResponse = CreateRuleAndGetResponseObject(rule);

        CreateUserAndLogin(Users_API.RulesManagerLocal_EXT());

        ViewRuleVersionResponseObject viewRuleResponse = GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, 1);

        assertThat(viewRuleResponse.httpStatusCode).isEqualTo(HttpStatus.SC_FORBIDDEN);
        assertThat(viewRuleResponse.ruleId).isNull();
    }

    @Test
    @Category({ChangeRequest.CR_775.class})
    public void WhenCreatingARule_HttpForbiddenIsReturned_IfUserIsNotAuthorized() {
        LoginAsSuperAdmin();
        RuleDetails ruleDetailsLOC = DraftLOCRuleNatManager();
        PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetailsLOC);
        assertThat(createRuleResponse.httpStatusCode).isEqualTo(HttpStatus.SC_FORBIDDEN);
        assertThat(createRuleResponse.uniqueId).isNull();
    }

    @Test
    @Category({ChangeRequest.CR_775.class})
    public void WhenUpdatingARule_HttpForbiddenIsReturned_IfUserIsNotAuthorized() {
        RuleDetails rule = DraftLocRuleLocalManager_POO();
        PostResponse createRuleResponse = CreateRuleAndGetResponseObject(rule);

        RuleDetails updatedRule = DraftVersion2NatRuleNatManager();
        updatedRule.uniqueID = createRuleResponse.uniqueId;

        CreateUserAndLogin(Users_API.RulesManagerLocal_EXT());

        EditRuleResponse.PutResponse updateRuleResponse = EditRuleAndGetResponseObject(updatedRule);

        assertThat(updateRuleResponse.httpStatusCode).isEqualTo(HttpStatus.SC_FORBIDDEN);
        assertThat(updateRuleResponse.uniqueId).isNull();
    }

    @Test
    @Category({ChangeRequest.CR_775.class})
    public void WhenUpdatingARuleVersion_HttpForbiddenIsReturned_IfUserIsNotAuthorized() {
        RuleDetails ruleDetails = DraftLocRuleLocalManager_POO();
        PostResponse ruleResponse = CreateRuleAndGetResponseObject(ruleDetails);

        CreateUserAndLogin(Users_API.RulesManagerLocal_EXT());

        ruleDetails.uniqueID = ruleResponse.uniqueId;

        EditRuleVersionRequest.PutRequest editRuleVersion  = new EditRuleVersionRequest.PutRequest();
        editRuleVersion.action = RuleVersionActions.delete.toString();
        PutResponse updateRuleResponse = EditRuleVersionAndGetResponseObject(ruleDetails, editRuleVersion);

        assertThat(updateRuleResponse.httpStatusCode).isEqualTo(HttpStatus.SC_FORBIDDEN);
        assertThat(updateRuleResponse.uniqueId).isNull();
    }

    @Test
    @Category({ChangeRequest.CR_775.class})
    public void WhenAmendingARule_HttpForbiddenIsReturned_IfUserIsNotAuthorized() {
        RuleDetails rule = CreatePendingExpiredRuleVersion(1, 3);
        publishAndWait(5000);

        RuleDetails amendedRule = DraftVersion2NatRuleNatManager();
        amendedRule.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(+10, DateTime.DateTimeUTCZ);
        amendedRule.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(+30, DateTime.DateTimeUTCZ);
        amendedRule.uniqueID = rule.uniqueID;
        amendedRule.version = 1;

        CreateUserAndLogin(Users_API.RulesManagerLocal_EXT());

        AmendRuleResponse.PostResponse amendRuleResponse = AmendRuleAndGetResponseObject(amendedRule);

        assertThat(amendRuleResponse.httpStatusCode).isEqualTo(HttpStatus.SC_FORBIDDEN);
        assertThat(amendRuleResponse.uniqueId).isNull();
    }
}
