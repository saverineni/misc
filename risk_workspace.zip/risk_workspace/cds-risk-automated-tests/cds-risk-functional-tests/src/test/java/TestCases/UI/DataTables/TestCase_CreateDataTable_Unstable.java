package TestCases.UI.DataTables;


import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.UnstableTests;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.DataForTests.TestDataTableModel;
import UI.Pages.DataManagement.CreateDataTable_Page;
import UI.Pages.DataManagement.ListDataTable_Page;
import UI.Utils.Navigation;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Category(UnstableTests.class)
public class TestCase_CreateDataTable_Unstable extends BaseUIWebDriverTestCase {

    @Test
    public void WhenLocalRuleManagerLoggedIn_CanCreateDataTableCommodityCode() {

        //arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        Navigation utilNavigation = new Navigation(driver);
        CreateDataTable_Page createDataTable_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        TestDataTableModel.TableDetails tableDetails = UI.DataForTests.DataTables.DataTable_CommodityCodes_POO();

        //act
        createDataTable_page.populateDataTableFields(tableDetails);

        createDataTable_page.clickSaveAndPublishButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        ListDataTable_Page listDataTable_page = new ListDataTable_Page(driver);

        List<ListDataTable_Page.DataTableListObject> dataTables = listDataTable_page.getDataTableListDetails();

        Assertions.assertThat(dataTables).extracting("tableTitle").contains(tableDetails.title);


        SimpleDateFormat date = new SimpleDateFormat("yy");
        String yy =  date.format(new Date());

        tableDetails.tableId = "Table Summary for\n" + "DT-" + "POO" + "-\\d\\d\\d\\d-" + yy;
        Assertions.assertThat(dataTables.get(0).tableID).containsPattern(tableDetails.tableId);
    }


    @Test
    public void WhenNationalRuleManagerLoggedIn_CanCreateDataTableFreeText() {

        //arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        Navigation utilNavigation = new Navigation(driver);
        CreateDataTable_Page createDataTable_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        TestDataTableModel.TableDetails tableDetails = UI.DataForTests.DataTables.DataTable_FreeText_NAT();

        //act
        createDataTable_page.populateDataTableFields(tableDetails);

        createDataTable_page.clickSaveAndPublishButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        ListDataTable_Page listDataTable_page = new ListDataTable_Page(driver);

        List<ListDataTable_Page.DataTableListObject> dataTables = listDataTable_page.getDataTableListDetails();

        List<String> dataTableTitles = new ArrayList<>();

        for (ListDataTable_Page.DataTableListObject dataTableListObject : dataTables){

            dataTableTitles.add(dataTableListObject.tableTitle);
        }

        Assertions.assertThat(dataTableTitles).contains(tableDetails.title);
    }
}
