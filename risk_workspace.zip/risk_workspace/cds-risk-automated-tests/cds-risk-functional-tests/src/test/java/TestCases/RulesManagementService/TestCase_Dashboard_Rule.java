package TestCases.RulesManagementService;

import API.DataForTests.*;
import API.RulesManagementService.Dashboard.ViewDashboardRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.Utils.Dashboard;
import API.RulesManagementService.Utils.RuleAtStatus;
import Categories_CDSRisk.CDS_RM_Dashboard;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import FunctionsLibrary.DateTime;
import TestCases.BaseWebAPITestCase;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.stream.Collectors;

import static API.RulesManagementService.Utils.RuleAtStatus.CreateSuspendedRule;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_Dashboard.class})
public class TestCase_Dashboard_Rule extends BaseWebAPITestCase {

    @Test
    @Category({ChangeRequest.CR_2558.class})
    public void allExpectedDashboardCategoriesAreReturned() {
        ViewDashboardRuleResponse.ViewRuleResponseObject viewRuleResponseObject = Dashboard.GetDashboardRule("national");

        assertThat(viewRuleResponseObject.items.stream().map(i -> i.name).collect(Collectors.toList()))
                .containsExactly("draft", "active", "pending", "suspended", "silent");
    }

    @Test
    @Category({ChangeRequest.CR_2558.class})
    public void whenNatDraftRuleCreated_RulesDashboardHasCorrectData() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewDashboardRuleResponse.ViewRuleResponseObject viewRuleResponseObject = Dashboard.GetDashboardRule("national");

        //Assert
        assertEquals("Expect Total Rules", 1, viewRuleResponseObject.total);
        assertEquals("Expect draft = 1", 1, viewRuleResponseObject.items.get(0).value);
    }

    @Test
    @Category({ChangeRequest.CR_2558.class})
    public void whenLocDraftRuleCreated_RulesDashboardHasCorrectData() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLOCRuleNatManager();
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewDashboardRuleResponse.ViewRuleResponseObject viewRuleResponseObject = Dashboard.GetDashboardRule("local");

        //Assert
        assertEquals("Expect Total Rules", 1, viewRuleResponseObject.total);
        assertEquals("Expect draft = 1", 1, viewRuleResponseObject.items.get(0).value);
    }

    @Test
    @Category({ChangeRequest.CR_2558.class})
    public void whenNatActiveRuleCreated_RulesDashboardHasCorrectData() {
        //Arrange
        API.RulesManagementService.Utils.RuleAtStatus.CreateActiveRule();
        publishAndWait(5000);

        //Act
        ViewDashboardRuleResponse.ViewRuleResponseObject viewRuleResponseObject = Dashboard.GetDashboardRule("national");

        //Assert
        assertEquals("Expect Total Rules", 1, viewRuleResponseObject.total);
        assertEquals("Expect active = 1", 1, viewRuleResponseObject.items.get(1).value);
    }

    @Test
    @Category({ChangeRequest.CR_2558.class})
    public void whenLocActiveRuleCreated_RulesDashboardHasCorrectData() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLOCRuleNatManager();
        ruleDetails.locations.add(Locations.Location_ABZ_UID);

        //Act
        API.RulesManagementService.Utils.RuleAtStatus.CreateActiveRule(ruleDetails);
        publishAndWait(1000);

        ViewDashboardRuleResponse.ViewRuleResponseObject viewRuleResponseObject = Dashboard.GetDashboardRule("local");

        //Assert
        assertEquals("Expect Total Rules", 1, viewRuleResponseObject.total);
        assertEquals("Expect active = 1", 1, viewRuleResponseObject.items.get(1).value);
    }


    @Test
    @Category({ChangeRequest.CR_2558.class})
    public void whenNatPendingRuleCreated_RulesDashboardHasCorrectData() {
        //Arrange
        API.RulesManagementService.Utils.RuleAtStatus.CreatePendingExpiredRuleVersion(1, 5);
        publishAndWait(5000);

        //Act
        ViewDashboardRuleResponse.ViewRuleResponseObject viewRuleResponseObject = Dashboard.GetDashboardRule("national");

        //Assert
        assertEquals("Expect Total Rules", 1, viewRuleResponseObject.total);
        assertEquals("Expect pending = 1", 1, viewRuleResponseObject.items.get(2).value);
    }

    @Test
    @Category({ChangeRequest.CR_2558.class})
    public void whenLocPendingRuleCreated_RulesDashboardHasCorrectData() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLOCRuleNatManager();
        ruleDetails.locations.add(Locations.Location_ABZ_UID);

        //Act
        API.RulesManagementService.Utils.RuleAtStatus.CreatePendingExpiredRuleVersion(ruleDetails, 1, 5);
        publishAndWait(5000);

        ViewDashboardRuleResponse.ViewRuleResponseObject viewRuleResponseObject = Dashboard.GetDashboardRule("local");

        //Assert
        assertEquals("Expect Total Rules", 1, viewRuleResponseObject.total);
        assertEquals("Expect pending = 1", 1, viewRuleResponseObject.items.get(2).value);
    }


    @Test
    @Category({ChangeRequest.CR_2558.class})
    public void whenNatSuspendedRuleCreated_RulesDashboardHasCorrectData() {
        //Arrange
        CreateSuspendedRule();

        //Act
        ViewDashboardRuleResponse.ViewRuleResponseObject viewRuleResponseObject = Dashboard.GetDashboardRule("national");

        //Assert
        assertEquals("Expect Total Rules", 1, viewRuleResponseObject.total);
        assertEquals("Expect suspended = 1", 1, viewRuleResponseObject.items.get(3).value);
    }

    @Test
    @Category({ChangeRequest.CR_2558.class})
    public void whenLocSuspendedRuleCreated_RulesDashboardHasCorrectData() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLOCRuleNatManager();
        ruleDetails.locations.add(Locations.Location_ABZ_UID);

        //Act
        API.RulesManagementService.Utils.RuleAtStatus.CreateSuspendedRule(ruleDetails);

        ViewDashboardRuleResponse.ViewRuleResponseObject viewRuleResponseObject = Dashboard.GetDashboardRule("local");

        //Assert
        assertEquals("Expect Total Rules", 1, viewRuleResponseObject.total);
        assertEquals("Expect suspended = 1", 1, viewRuleResponseObject.items.get(3).value);
    }

    @Test
    @Category({ChangeRequest.CR_2558.class})
    public void whenArchivedRuleCreated_RulesDashboardDoesNotContainRule() {
        //Arrange
        API.RulesManagementService.Utils.RuleAtStatus.CreateArchivedRule();

        //Act
        ViewDashboardRuleResponse.ViewRuleResponseObject viewRuleResponseObject = Dashboard.GetDashboardRule("national");

        //Assert
        assertEquals("Expect Total Rules", 0, viewRuleResponseObject.total);
    }

    @Test
    @Category({ChangeRequest.CR_2558.class})
    public void whenDeletedRuleCreated_RulesDashboardDoesNotContainRule() {
        //Arrange
        API.RulesManagementService.Utils.RuleAtStatus.CreateDeletedRule();

        //Act
        ViewDashboardRuleResponse.ViewRuleResponseObject viewRuleResponseObject = Dashboard.GetDashboardRule("national");

        //Assert
        assertEquals("Expect Total Rules", 0, viewRuleResponseObject.total);
    }

    @Test
    @Category({ChangeRequest.CR_2558.class})
    public void whenMultipleVersionsOfRuleCreatedLeadVersionActive_RulesDashboardContainsDetailsOfLeadVersionOnly() {
        //Arrange
        EditRuleVersionResponse.PutResponse response1 = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();
        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(response1.uniqueId, 2);
        publishAndWait(5000);

        //Act
        ViewDashboardRuleResponse.ViewRuleResponseObject viewRuleResponseObject = Dashboard.GetDashboardRule("national");

        //Assert
        assertEquals("Expect Total Rules", 1, viewRuleResponseObject.total);
        assertEquals("Expect active = 1", 1, viewRuleResponseObject.items.get(1).value);
    }

    @Test
    @Category({ChangeRequest.CR_3433.class})
    public void whenSilentRuleCreated_RulesDashboardHasCorrectData() {
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.Utils.RuleAtStatus.CreateSilentRule(ruleDetails);

        ViewDashboardRuleResponse.ViewRuleResponseObject viewRuleResponseObject = Dashboard.GetDashboardRule("national");

        //Assert
        assertEquals("Expect Total Rules", 1, viewRuleResponseObject.total);
        assertEquals("Expect silent = 1", 1, viewRuleResponseObject.items.get(4).value);
    }

    @Test
    @Category({ChangeRequest.CR_2558.class})
    public void whenMultipleVersionsOfRuleCreatedWithFuturePendingDates_RulesDashboardContainsDetailsOfSinglePendingVersion() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = RuleAtStatus.CreatePendingExpiredRuleVersion(1, 2);
        publishAndWait(5000);

        ruleDetails.description = "ta_updatedRule";
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(3, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(4, DateTime.DateTimeUTCZ);

        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetails, 2);
        publishAndWait(5000);

        //Act
        ViewDashboardRuleResponse.ViewRuleResponseObject viewRuleResponseObject = Dashboard.GetDashboardRule("national");

        //Assert
        assertEquals("Expect Total Rules", 1, viewRuleResponseObject.total);
        assertEquals("Expect pending = 1", 1, viewRuleResponseObject.items.get(2).value);
    }


    @Test
    @Category({ChangeRequest.CR_2558.class})
    public void whenLocRulesCreated_RulesDashboardHasCorrectDataForLoggedInUserLocation() {
        //Arrange
        TestUserModel.UserDetails udRuleManPOOEXT = Users_API.RulesManagerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOOEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOOEXT.pid);

        TestRuleModel.RuleDetails ruleDetails_POOEXT = API.DataForTests.Rules.DraftLocRuleLocalManager_POOEXT();
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails_POOEXT);

        TestRuleModel.RuleDetails ruleDetails_POO = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails_POO);

        TestRuleModel.RuleDetails ruleDetails_EXT = API.DataForTests.Rules.DraftLocRuleLocalManager_EXT();
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails_EXT);

        //Act
        ViewDashboardRuleResponse.ViewRuleResponseObject viewRuleResponseObject_POOEXT = Dashboard.GetDashboardRule("local");

        TestUserModel.UserDetails udRuleViewPOO = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleViewPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleViewPOO.pid);

        ViewDashboardRuleResponse.ViewRuleResponseObject viewRuleResponseObject_POO = Dashboard.GetDashboardRule("local");

        //Assert
        assertEquals("Expect Total Rules", 3, viewRuleResponseObject_POOEXT.total);
        assertEquals("Expect draft = 3", 3, viewRuleResponseObject_POOEXT.items.get(0).value);

        assertEquals("Expect Total Rules", 1, viewRuleResponseObject_POO.total);
        assertEquals("Expect draft = 1", 1, viewRuleResponseObject_POO.items.get(0).value);
    }


    @Test
    @Category({ChangeRequest.CR_2558.class})
    public void whenMultipleNatRulesCreated_RulesDashboardHasCorrectDataForTotalNationalAndLocal() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsNat = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsNat.descriptionStaticPrefix = "ta_NatRule";

        TestRuleModel.RuleDetails ruleDetailsLoc = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        ruleDetailsLoc.descriptionStaticPrefix = "ta_LocRule";

        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat, TestEnumerators.RuleStatus.draft, 5);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat, TestEnumerators.RuleStatus.active, 4);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsLoc, TestEnumerators.RuleStatus.pending, 3);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsLoc, TestEnumerators.RuleStatus.suspended, 2);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsLoc, TestEnumerators.RuleStatus.silent, 3);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsLoc, TestEnumerators.RuleStatus.expired, 1);

        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsNat, TestEnumerators.RuleStatus.archived, 1);
        RuleAtStatus.CreateXNoRulesAtStatus(ruleDetailsLoc, TestEnumerators.RuleStatus.deleted, 1);

        publishAndWait(5000);

        //Act
        ViewDashboardRuleResponse.ViewRuleResponseObject viewRuleResponseObjectTotal = Dashboard.GetDashboardRule("");
        ViewDashboardRuleResponse.ViewRuleResponseObject viewRuleResponseObjectNat = Dashboard.GetDashboardRule("national");
        ViewDashboardRuleResponse.ViewRuleResponseObject viewRuleResponseObjectLoc = Dashboard.GetDashboardRule("local");

        //Assert
        assertEquals("Expect Total Rules", 17, viewRuleResponseObjectTotal.total);
        assertEquals("Expect Items @ draft status", 5, viewRuleResponseObjectTotal.items.get(0).value);
        assertEquals("Expect Items @ active status", 4, viewRuleResponseObjectTotal.items.get(1).value);
        assertEquals("Expect Items @ pending status", 3, viewRuleResponseObjectTotal.items.get(2).value);
        assertEquals("Expect Items @ suspended status", 2, viewRuleResponseObjectTotal.items.get(3).value);
        assertEquals("Expect Items @ silent status", 3, viewRuleResponseObjectTotal.items.get(4).value);

        assertEquals("Expect Total National Rules", 9, viewRuleResponseObjectNat.total);
        assertEquals("Expect Items @ draft status", 5, viewRuleResponseObjectNat.items.get(0).value);
        assertEquals("Expect Items @ active status", 4, viewRuleResponseObjectNat.items.get(1).value);
        assertEquals("Expect Items @ pending status", 0, viewRuleResponseObjectNat.items.get(2).value);
        assertEquals("Expect Items @ suspended status", 0, viewRuleResponseObjectNat.items.get(3).value);
        assertEquals("Expect Items @ silent status", 0, viewRuleResponseObjectNat.items.get(4).value);

        assertEquals("Expect Total Local Rules", 8, viewRuleResponseObjectLoc.total);
        assertEquals("Expect Items @ draft status", 0, viewRuleResponseObjectLoc.items.get(0).value);
        assertEquals("Expect Items @ active status", 0, viewRuleResponseObjectLoc.items.get(1).value);
        assertEquals("Expect Items @ pending status", 3, viewRuleResponseObjectLoc.items.get(2).value);
        assertEquals("Expect Items @ suspended status", 2, viewRuleResponseObjectLoc.items.get(3).value);
        assertEquals("Expect Items @ silent status", 3, viewRuleResponseObjectLoc.items.get(4).value);
    }
}
