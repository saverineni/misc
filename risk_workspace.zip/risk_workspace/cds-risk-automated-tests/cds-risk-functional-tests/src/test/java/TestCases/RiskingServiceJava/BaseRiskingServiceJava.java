
package TestCases.RiskingServiceJava;

import API.DataForTests.Locations;
import API.DataForTests.RegimeCodes;
import API.DataForTests.TestEnumerators;
import API.DataForTests.Users_API;
import API.RiskingServiceJava.Utils.SoapMessageHelper;
import TestCases.BaseSpringBootTestCase;
import com.google.common.collect.ImmutableList;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel.MetadataDefinition;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel.RuleDefinition;
import uk.gov.hmrc.risk.test.common.enums.*;
import uk.gov.hmrc.risk.test.common.model.dataService.DataTableCreationModel;
import uk.gov.hmrc.risk.test.common.model.dataService.DataTableCreationModel.TableShares;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel.BaseLocation;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel.Query;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel.QueryOptions;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel.RuleOutputs;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleCreationModel;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleCreationModel.RuleCreationModelBuilder;
import uk.gov.hmrc.risk.test.common.service.QueueAccessor;
import uk.gov.hmrc.risk.test.common.service.RiskingServiceSupport.RiskingSystemTime;

import java.util.*;

import static API.DataForTests.DataTypes.DataType_CommodityCode_UID;
import static uk.gov.hmrc.risk.rulesengine.rules.RuleMetadata.UNIQUE_ID;
import static uk.gov.hmrc.risk.test.common.enums.MatcherType.EQUAL;
import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.*;


@Slf4j
public class BaseRiskingServiceJava extends BaseSpringBootTestCase {

    protected static String DECLARATION_TEMPLATE;

    protected final String creatorPID = Users_API.NationalRulesManagerDefaultTestAutomationUser().pid;

    protected final static String DOCUMENT_CHECK_CTRL_TYPE = "1";
    protected final static String PHYSICAL_CHECK_CTRL_TYPE = "2";
    protected final static String DEFAULT_CTRL_TYPE = "1";

    protected final static String DEFAULT_NARRATIVE = "Default";
    protected final static String PRE_CLEARANCE_NARRATIVE = "Pre clearance";
    protected final static String POST_CLEARANCE_NARRATIVE = "Post clearance";

    protected final static String HOLD_NARRATIVE = "Hold narrative";
    protected final static String RELEASE_NARRATIVE = "Release narrative";

    protected String defaultDescription = "ta_DefaultRiskingServiceRule";

    @Autowired
    @Qualifier("mdgEmailQueueAccessor")
    protected QueueAccessor mdgEmailQueueAccessor;

    @Autowired
    protected SoapMessageHelper soapHelper;

    @Before
    @SneakyThrows
    public void before() {
        DECLARATION_TEMPLATE = declarationSupport.getDefaultMultiItemDeclarationTemplate();
        appStateSupport.resetAppState();
        initialiseRiskingSystemTime();
    }

    protected void addDaysToRiskingSystemTime(int daysToAdd) {

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.HOUR_OF_DAY,1);
        cal.add(Calendar.DAY_OF_MONTH,daysToAdd);
        int base1Month = cal.get(Calendar.MONTH)+1;

        riskingServiceSupport.setTime(
                cal.get(Calendar.DAY_OF_MONTH),
                base1Month,
                cal.get(Calendar.YEAR),
                cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE),
                cal.get(Calendar.SECOND));

        RiskingSystemTime time = riskingServiceSupport.getTime();
        log.info("current time : " + time.getTimeUtc().toString());
    }

    private void initialiseRiskingSystemTime() {

        Calendar cal = Calendar.getInstance();
        int base1Month = cal.get(Calendar.MONTH)+1;

        riskingServiceSupport.setTime(
                cal.get(Calendar.DAY_OF_MONTH),
                base1Month,
                cal.get(Calendar.YEAR),
                cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE),
                cal.get(Calendar.SECOND));

        RiskingSystemTime time = riskingServiceSupport.getTime();
        log.info("current time : " + time.getTimeUtc().toString());
    }

    protected void addWeeksToRiskingSystemTime(int weeksToAdd) {

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.WEEK_OF_YEAR,weeksToAdd);
        int base1Month = cal.get(Calendar.MONTH)+1;

        riskingServiceSupport.setTime(
                cal.get(Calendar.DAY_OF_MONTH),
                base1Month,
                cal.get(Calendar.YEAR),
                cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE),
                cal.get(Calendar.SECOND));

        RiskingSystemTime time = riskingServiceSupport.getTime();
        log.info("current time : " + time.getTimeUtc().toString());
    }

    protected void createRule(Source source, List<Condition> declarationConditions, List<Condition> goodsItemConditions) {
        RuleDefinitionModel.RuleDefinition ruleDefinition = baseRuleDefinition();

        ruleDefinition.setWhenDef(
                whenCreator(declarationConditions, goodsItemConditions)
        );

        List<Condition> allConditions = new ArrayList<>();
        declarationConditions.forEach(allConditions::add);
        goodsItemConditions.forEach(allConditions::add);

        ruleDefinition.setThenDef(
                thenCreator( source, allConditions)
        );

        RuleDefinitionModel definitionModel = baseRuleDefinitionModel(ruleDefinition);

        RuleCreationModel ruleModel = baseRuleCreationModelBuilder()
                .definition(definitionModel.toString())
                .build();

        createAndRefreshRule(ruleModel);
    }

    protected DeclarationResponse createAndSendDeclaration(List<Condition> conditions) {
        return createAndSendDeclaration(conditions, true);
    }

    protected DeclarationResponse createAndSendDeclaration(List<Condition> conditions, boolean defaultOptions) {
        Map<DeclarationParam, String> declarationFields = new HashMap<>();
        conditions.forEach(condition -> declarationFields.put(condition.declarationParam, condition.declarationValue) );

        return sendDeclaration(declarationFields, defaultOptions);
    }

    protected DeclarationResponse createAndSendDeclaration(Map<DeclarationParam, String> declarationFields) {
        return createAndSendDeclaration(declarationFields, true);
    }

    protected DeclarationResponse createAndSendDeclaration(Map<DeclarationParam, String> declarationFields, boolean defaultOptions) {
        return sendDeclaration(declarationFields, defaultOptions);
    }

    protected DeclarationResponse sendDeclaration(Map<DeclarationParam, String> declarationFieldValues) {
        return sendDeclaration(declarationFieldValues, true);
    }

    protected DeclarationResponse sendDeclaration(Map<DeclarationParam, String> declarationFieldValues, boolean defaultOptions) {
        return sendDeclaration(declarationFieldValues, defaultOptions, false);
    }

    protected DeclarationResponse sendDeclaration(Map<DeclarationParam, String> declarationFieldValues, boolean defaultOptions,
                                                  boolean expectedError) {

        if (defaultOptions) {
            declarationFieldValues.put(HeaderDeclarationParam.TRANSPORT_MODE, TransportMode.All.toString());
            declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_TYPE, "IM");
            declarationFieldValues.put(HeaderDeclarationParam.CONSIGNEE_TYPE, "IM");
            declarationFieldValues.put(HeaderDeclarationParam.CONSIGNOR_TYPE, "CZ");
            declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "C");

            declarationFieldValues.put(GoodsItemDeclarationParam.SEQUENCE_NUMBER, "2001");
            declarationFieldValues.put(GoodsItemDeclarationParam.Second.SEQUENCE_NUMBER, "2002");
            declarationFieldValues.put(GoodsItemDeclarationParam.Third.SEQUENCE_NUMBER, "2003");
            declarationFieldValues.put(GoodsItemDeclarationParam.Fourth.SEQUENCE_NUMBER, "2004");
        }

        declarationFieldValues.putIfAbsent(HeaderDeclarationParam.DECLARATION_REFERENCE, UUID.randomUUID().toString());

        String declarationRequest = declarationSupport.createDeclaration(DECLARATION_TEMPLATE, declarationFieldValues);

        log.info(declarationRequest);

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive(), expectedError, this::decryptField);
        String returnedControlCode = declarationResponse.getControlType();
        log.info("\n" + "The controlType returned for this particular rule is : " + returnedControlCode);
        return declarationResponse;
    }

    protected String createAndRefreshRule(CreateRuleModel model) {
        String ruleId = rulesManagementServiceSupport.createActiveRule(model, appStateSupport.getRuleManagerToken());
        publishAndWait(10000);
        return ruleId;
    }

    protected String createRule(CreateRuleModel model) {
        String ruleId = rulesManagementServiceSupport.createActiveRule(model, appStateSupport.getRuleManagerToken());
        return ruleId;
    }

    protected String createSilentRule(String ruleId) {
        rulesManagementServiceSupport.createSilentRule(ruleId,appStateSupport.getRuleManagerToken(),"Testing");
        publishAndWait(10000);
        return ruleId;
    }

    protected String createAndRefreshRule(RuleCreationModel ruleCreationModel) {
        String ruleId = rulesSupport.createActiveRule(ruleCreationModel, appStateSupport.getRuleManagerPid());
        publishAndWait(10000);
        return ruleId;
    }

    protected RuleDefinition baseRuleDefinition() {
        RuleDefinition definition = RuleDefinition.builder().build();
        definition.setName(defaultDescription);
        definition.addMetadata(new MetadataDefinition(UNIQUE_ID, Optional.of("#UniqueId#")));

        Condition dispatchCoutry = Condition.builder()
                .source(Source.declaration)
                .attribute(HeaderAttribute.DISPATCH_COUNTRY)
                .matcherType(EQUAL)
                .matcher(Matcher.equalTo)
                .matcherClass(MatcherClass.Matchers)
                .value("DE")
                .build();

        definition.setWhenDef(
                declarationWrapper(
                        strCheck( dispatchCoutry )
                ));
        definition.setThenDef(thenCreator(Source.declaration, conditions( dispatchCoutry )));
        return definition;
    }

    protected RuleDefinitionModel baseRuleDefinitionModel() {
        return baseRuleDefinitionModel( baseRuleDefinition() );
    }

    protected RuleDefinitionModel baseRuleDefinitionModel(RuleDefinition definition) {
        RuleDefinitionModel model = defaultModel();

        model.getRuleDefinitions().clear();
        model.getRuleDefinitions().add(definition);
        return model;
    }

    protected RuleCreationModelBuilder baseRuleCreationModelBuilder() {

//        LocalDateTime startDateTime = LocalDateTime.now(ZoneId.of("UTC")).minusSeconds(2);
        //TODO make time be dynamic
        String startDateTime = "2016-07-13T06:15:17Z";

        return RuleCreationModel.builder()
                .description(defaultDescription)
                .definition(baseRuleDefinitionModel().toString())
                .startDateTime(startDateTime)
                .creatorPid(creatorPID)
                .ruleType("national")
                .regimeCodeUuid(RegimeCodes.Regime_ADD_UID)
                .locationUuids(Collections.singletonList(Locations.Location_National_UID))
                .reason("Default test reason")
                .json(
                        RuleCreationModel.JsonContainer.builder()
                                .valid(true)
                                .description(defaultDescription)
                                .route("2")
                                .startDateTime(startDateTime)
                                .regimeUuid(RegimeCodes.Regime_ADD_UID)
                                .query(Arrays.asList(
                                        RuleCreationModel.QueryContainerJson.builder()
                                                .operator("and")
                                                .query(Arrays.asList(
                                                        RuleCreationModel.QueryJson.builder()
                                                                .attribute("commodityCode")
                                                                .operator("eq")
                                                                .value("1234567890")
                                                                .build()
                                                ))
                                                .build()
                                ))
                                .behaviours(Arrays.asList(
                                        RuleCreationModel.BehaviourContainer.builder()
                                                .behaviourType(RuleBehaviourType.DEFAULT)
                                                .narrative(DEFAULT_NARRATIVE)
                                                .controlType(DEFAULT_CTRL_TYPE)
                                                .build(),
                                        RuleCreationModel.BehaviourContainer.builder()
                                                .behaviourType(RuleBehaviourType.PRE_CLEARANCE)
                                                .narrative(PRE_CLEARANCE_NARRATIVE)
                                                .controlType(DOCUMENT_CHECK_CTRL_TYPE)
                                                .build(),
                                        RuleCreationModel.BehaviourContainer.builder()
                                                .behaviourType(RuleBehaviourType.POST_CLEARANCE)
                                                .narrative(POST_CLEARANCE_NARRATIVE)
                                                .controlType(PHYSICAL_CHECK_CTRL_TYPE)
                                                .build()
                                ))
                                .build()
                );
    }

    protected DataTableCreationModel baseDataTableModel() {
//        dataTypesUtils.getDefaultDataTypesUUIDSFromMySQLDB();

        List<TableShares> creatorTableShares = ImmutableList.of(TableShares.builder()
                .shareType(TestEnumerators.ShareTypes.owner.toString())
                .locationUuids(Arrays.asList(Locations.Location_National_UID))
                .build());

        return DataTableCreationModel.builder()
                .tableName("ta_defaultDataTableForTests")
                .description("Data table used for test automation tests")
                .dataTypeUuid(DataType_CommodityCode_UID)
                .userPid(creatorPID)
//                .locationUuids(Arrays.asList(Locations.Location_National_UID))
                .creationShareType(TestEnumerators.ShareTypes.owner.toString())
                .tags(Arrays.asList("Items"))
                .userBaseLocation("NAT")
                .reason("Testing")
                .tableType("Open")
                .tableShares(creatorTableShares)
                .build();
    }

    protected CreateRuleModel createRuleModel() {
        return CreateRuleModel.builder()
                .description(defaultDescription)
                .startDateTime("2016-07-13T06:15:17Z")
                .regimeUuid(RegimeCodes.Regime_ADD_UID)
                .locationUuids(Collections.singletonList(Locations.Location_National_UID))
                .query(
                        Arrays.asList(
                                Query.builder()
                                .operator(Operator.and.toString())
                                .build()
                        )
                )
                .queryOptions(
                        QueryOptions.builder()
                        .declarationType(DeclarationType.IM.toString())
                        .declarationSubTypes(Arrays.asList(DeclarationSubType.C.toString()))
                        .transportMode(TransportMode.All.toString())
                        .build()
                )
                .reason("Default test reason")
                .ruleOutputs(
                        RuleOutputs.builder()
                        .actionType("1")
                        .blockingRelease(true)
                        .holdNarrative(HOLD_NARRATIVE)
                        .holdPercentage(100)
                        .releaseNarrative(RELEASE_NARRATIVE)
                        .releasePercentage(0)
                        .assigneeId("nch_open_general_export_licence")
                        .build()
                )
                .ruleType("national")
                .baseLocation(
                        BaseLocation.builder()
                        .locationName("National Office")
                        .build()
                )
                .build();
    }

    protected String generateReportBackElementString(String sequenceNumber) {
        return "/declaration/consignmentShipment/goodsItems[sequenceNumber=\""+sequenceNumber+"\"]";
    }

    protected Condition firstItemSequenceId() {
        return Condition.builder()
                .declarationParam(GoodsItemDeclarationParam.SEQUENCE_NUMBER)
                .declarationValue("2001")
                .build();
    }

    protected Condition secondItemSequenceId() {
        return Condition.builder()
                .declarationParam(GoodsItemDeclarationParam.Second.SEQUENCE_NUMBER)
                .declarationValue("2002")
                .build();
    }

    protected Condition thirdItemSequenceId() {
        return Condition.builder()
                .declarationParam(GoodsItemDeclarationParam.Third.SEQUENCE_NUMBER)
                .declarationValue("2003")
                .build();
    }

    protected Condition fourthItemSequenceId() {
        return Condition.builder()
                .declarationParam(GoodsItemDeclarationParam.Fourth.SEQUENCE_NUMBER)
                .declarationValue("2004")
                .build();
    }

    protected Condition declarationType() {
        return Condition.builder()
                .declarationParam(HeaderDeclarationParam.DECLARATION_TYPE)
                .declarationValue("IM")
                .build();
    }

    protected Condition declarationSubtype() {
        return Condition.builder()
                .declarationParam(HeaderDeclarationParam.DECLARATION_SUBTYPE)
                .declarationValue("C")
                .build();
    }

    protected Condition transpoerMode() {
        return Condition.builder()
                .declarationParam(HeaderDeclarationParam.TRANSPORT_MODE)
                .declarationValue(TransportMode.All.toString())
                .build();
    }

    @Data
    @AllArgsConstructor
    protected class PrePostResult {
        private String controlType;
        private boolean blocking;
        private String narrative;
    }
}
