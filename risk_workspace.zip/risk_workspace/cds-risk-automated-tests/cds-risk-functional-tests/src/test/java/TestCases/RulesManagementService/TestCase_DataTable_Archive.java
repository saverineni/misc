package TestCases.RulesManagementService;


import API.DataForTests.DataTables;
import API.DataForTests.TestDataTableModel;
import API.DataForTests.TestRuleModel;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.EditDataTableData.EditDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import Categories_CDSRisk.CDS_RM_DataTable;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import io.restassured.response.Response;
import org.apache.commons.httpclient.HttpStatus;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static API.DataForTests.DataTables.DataTable_CommodityCodes_NAT;
import static API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject;
import static API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID;
import static API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_DataTable.class})
public class TestCase_DataTable_Archive extends WebAPITestCaseWithDatatablesCleanup {


    @Test
    @Category(ChangeRequest.CR_2949.class)
    public void WhenDataTableArchived_DataTableArchivedSuccessfully() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        //Act
        Response response = API.RulesManagementService.Utils.DataTables.ArchiveDataTable(tableDetails);
        tableDetails.version = 2;

        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponseObject = GetDataTableDetailsByUID(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_NO_CONTENT, response.statusCode());
        assertEquals(tableDetails.tableName, viewDataTableResponseObject.tableName);
        assertEquals(tableDetails.version, viewDataTableResponseObject.version);
        assertEquals("archived", viewDataTableResponseObject.status);
    }


    @Test
    @Category(ChangeRequest.CR_2949.class)
    public void AttemptToArchivePreviouslyArchivedDataTable_400BadRequestReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        Response response1 = API.RulesManagementService.Utils.DataTables.ArchiveDataTable(tableDetails);

        //Act
        tableDetails.version = 2;
        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponseObject = GetDataTableDetailsByUID(tableDetails.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        Response response2 = API.RulesManagementService.Utils.DataTables.ArchiveDataTable(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_NO_CONTENT, response1.statusCode());
        assertEquals("HTTP Status Code: ", HttpStatus.SC_BAD_REQUEST, response2.statusCode());
    }


    @Test
    @Category(ChangeRequest.CR_2949.class)
    public void AttemptToEditPreviouslyArchivedDataTable_400BadRequestReturned() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        Response response1 = API.RulesManagementService.Utils.DataTables.ArchiveDataTable(tableDetails);

        //Act
        tableDetails.version = 2;
        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponseObject = GetDataTableDetailsByUID(tableDetails.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        EditDataTableResponse.EditDataTableDetailsResponseObject responseEdit = API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);


        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_NO_CONTENT, response1.statusCode());
        assertEquals("HTTP Status Code: ", HttpStatus.SC_FORBIDDEN, responseEdit.httpStatusCode);
    }

    @Ignore("Backend API does not currently validate datatable uuid as part of rule creation. So no check if data table is archived. Will be done as part of Rule Migration stories.")
    @Test
    @Category(ChangeRequest.CR_2949.class)
    public void WhenDataTableArchived_RuleCanNotUseDataTable() throws Throwable {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;
        tableDetails.uuid = createDataTableResponse.uuid;

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "commodityCode";
        ruleDetails.queryConditions.get(0).conditions.get(0).value = "0101210000";
        ruleDetails.queryConditions.get(0).conditions.get(0).isDataTable = true;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = createDataTableResponse.uuid;

        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        //Act
        API.RulesManagementService.Utils.DataTables.ArchiveDataTable(tableDetails);
        tableDetails.version = 2;

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(org.apache.http.HttpStatus.SC_BAD_REQUEST, createRuleResponse.httpStatusCode);
    }

}
