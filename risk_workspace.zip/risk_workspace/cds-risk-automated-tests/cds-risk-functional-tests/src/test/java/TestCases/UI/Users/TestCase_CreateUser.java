package TestCases.UI.Users;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.*;
import FunctionsLibrary.Utils;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.LoggedInUserDetails;
import UI.CommonComponents.MenuToolBar;
import UI.Pages.Login_Page;
import UI.Pages.UserManagement.CreateUser_Page;
import UI.Pages.UserManagement.ListUsers_Page;
import UI.Pages.UserManagement.UserDetails_Page;
import UI.Utils.Navigation;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static FunctionsLibrary.DateTime.DateTimeUTCZ;
import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Users.class, CDS_Risk_UI_Users_1.class})
public class TestCase_CreateUser extends BaseUIWebDriverTestCase {

    @Category({ChangeRequest.CR_1426.class, ChangeRequest.CR_3329.class})
    @Test
    public void WhenNationalSuperAdminLoggedIn_CanCreateNationalAdmin(){

        //Arrange
        TestUserModel.UserDetails UserDetailsSuperAdmin = Users_API.DefaultSuperAdminUser();

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetailsSuperAdmin);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateUser_Page createUser_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateUser);

        createUser_page.waitForAngularRequestsToFinish();

        //Act
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminNational();
        userDetailsAdmin.scClearanceLevel = "SC - Security Check";
        userDetailsAdmin.scClearanceExpiryDate = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(1, DateTimeUTCZ);;
        userDetailsAdmin.scValidated = true;
        userDetailsAdmin.redacted=true;
        userDetailsAdmin.status="Inactive";

        utilUsers.CreateCDSRiskUIUser(userDetailsAdmin);

        //Assert
        String userCreatedMessage = createUser_page.userCreatedMessage.getText();
        assertEquals("User has been created with pid " + userDetailsAdmin.pid,  userCreatedMessage);

        createUser_page.setPID(userDetailsAdmin.pid);
        createUser_page.clickSearchSRSButton();

        createUser_page.assertCreatedUserSRSDetails(userDetailsAdmin);

        UserDetails_Page userDetails_page = createUser_page.clickViewProfileLink();
        userDetails_page.assertUserDetails(userDetailsAdmin);
    }


    @Category({ChangeRequest.CR_2808.class, ChangeRequest.CR_3329.class})
    @Test
    public void WhenNationalSuperAdminLoggedIn_CanCreateLocalSuperAdmin(){

        //Arrange
        TestUserModel.UserDetails UserDetailsSuperAdmin = Users_API.DefaultSuperAdminUser();

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetailsSuperAdmin);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateUser_Page createUser_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateUser);

        //Act
        TestUserModel.UserDetails userDetailsLocalSuperAdmin = Users_API.SuperAdminLocal_POO();
        utilUsers.CreateCDSRiskUIUser(userDetailsLocalSuperAdmin);

        //Assert
        String userCreatedMessage = createUser_page.userCreatedMessage.getText();
        assertEquals("User has been created with pid " + userDetailsLocalSuperAdmin.pid,  userCreatedMessage);

        createUser_page.setPID(userDetailsLocalSuperAdmin.pid);
        createUser_page.clickSearchSRSButton();

        createUser_page.assertCreatedUserSRSDetails(userDetailsLocalSuperAdmin);
        userDetailsLocalSuperAdmin.status="Inactive";
        UserDetails_Page userDetails_page = createUser_page.clickViewProfileLink();
        userDetails_page.assertUserDetails(userDetailsLocalSuperAdmin);
    }


    @Category(ChangeRequest.CR_2808.class)
    @Test
    public void WhenNationalSuperAdminLoggedIn_CanNotCreateLocalAdmin(){

        //Arrange
        TestUserModel.UserDetails UserDetailsSuperAdmin = Users_API.DefaultSuperAdminUser();

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetailsSuperAdmin);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateUser_Page createUser_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateUser);

        //Act
        TestUserModel.UserDetails userAdminLocal= Users_API.AdminLocal_POO();

        createUser_page.setPID(userAdminLocal.pid);
        createUser_page.searchSRS.click();

        List<String> listOfCustomRoles = createUser_page.getListOfCustomRoles();

        //Assert
        Assertions.assertThat(listOfCustomRoles)
                .doesNotContain("LocalAdmin");
    }

    @Category(SmokeTests_UI.class)
    @Test
    public void WhenNationalAdminLoggedIn_CanCreateNationalRuleManager(){

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminNational("1234520");
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsAdmin);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateUser_Page createUser_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateUser);

        //Act
        TestUserModel.UserDetails userRulesManager = Users_API.RulesManagerNational("1234521");
        utilUsers.CreateCDSRiskUIUser(userRulesManager);

        //Assert
        String userCreatedMessage = createUser_page.userCreatedMessage.getText();
        assertEquals("User has been created with pid " + userRulesManager.pid,  userCreatedMessage);

        createUser_page.setPID(userRulesManager.pid);
        createUser_page.clickSearchSRSButton();
        userRulesManager.status="Inactive";

        createUser_page.assertCreatedUserSRSDetails(userRulesManager);
        UserDetails_Page userDetails_page = createUser_page.clickViewProfileLink();
        userDetails_page.assertUserDetails(userRulesManager);
    }

    @Category(SmokeTests_UI.class)
    @Test
    public void WhenNationalAdminLoggedIn_CanCreateDataManager(){

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminNational("1234520");
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsAdmin);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateUser_Page createUser_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateUser);

        //Act
        TestUserModel.UserDetails dataManager = Users_API.DataManager("1234543");
        utilUsers.CreateCDSRiskUIUser(dataManager);

        //Assert
        String userCreatedMessage = createUser_page.userCreatedMessage.getText();
        assertEquals("User has been created with pid " + dataManager.pid,  userCreatedMessage);

        createUser_page.setPID(dataManager.pid);
        createUser_page.clickSearchSRSButton();
        dataManager.status="Inactive";

        createUser_page.assertCreatedUserSRSDetails(dataManager);
        UserDetails_Page userDetails_page = createUser_page.clickViewProfileLink();
        userDetails_page.assertUserDetails(dataManager);
    }

    @Test
    public void WhenNationalAdminLoggedIn_CanCreateNationalRuleViewer(){

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsAdmin);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateUser_Page createUser_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateUser);

        //Act
        TestUserModel.UserDetails userRulesViewer = Users_API.RulesViewerNational();
        utilUsers.CreateCDSRiskUIUser(userRulesViewer);

        //Assert
        String userCreatedMessage = createUser_page.userCreatedMessage.getText();
        assertEquals("User has been created with pid " + userRulesViewer.pid,  userCreatedMessage);

        createUser_page.setPID(userRulesViewer.pid);
        createUser_page.clickSearchSRSButton();
        userRulesViewer.status="Inactive";

        createUser_page.assertCreatedUserSRSDetails(userRulesViewer);

        UserDetails_Page userDetails_page = createUser_page.clickViewProfileLink();
        userDetails_page.assertUserDetails(userRulesViewer);
    }

    @Category({ChangeRequest.CR_2808.class, ChangeRequest.CR_3329.class})
    @Test
    public void WhenLocalAdminLoggedIn_CanCreateLocalRuleManager(){

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsAdmin);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateUser_Page createUser_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateUser);

        //Act
        TestUserModel.UserDetails userRulesManager = Users_API.RulesManagerLocal_POO();
        utilUsers.CreateCDSRiskUIUser(userRulesManager);

        //Assert
        String userCreatedMessage = createUser_page.userCreatedMessage.getText();
        assertEquals("User has been created with pid " + userRulesManager.pid,  userCreatedMessage);

        createUser_page.setPID(userRulesManager.pid);
        createUser_page.clickSearchSRSButton();
        userRulesManager.status="Inactive";

        createUser_page.assertCreatedUserSRSDetails(userRulesManager);

        UserDetails_Page userDetails_page = createUser_page.clickViewProfileLink();
        userDetails_page.assertUserDetails(userRulesManager);
    }


    @Category(ChangeRequest.CR_2808.class)
    @Test
    public void WhenNationalAdminLoggedIn_CanNotCreateLocalRuleManagerOrLocalRuleViewer(){

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsAdmin);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateUser_Page createUser_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateUser);

        //Act
        TestUserModel.UserDetails userRulesViewer = Users_API.RulesManagerLocal_POO();

        createUser_page.setPID(userRulesViewer.pid);
        createUser_page.searchSRS.click();

        List<String> listOfCustomRoles = createUser_page.getListOfCustomRoles();

        //Assert
        Assertions.assertThat(listOfCustomRoles)
                .doesNotContain("LocalRuleManager");
    }


    @Category({ChangeRequest.CR_2808.class, ChangeRequest.CR_3329.class})
    @Test
    public void WhenLocalAdminLoggedIn_CanCreateLocalRuleViewer(){

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsAdmin);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateUser_Page createUser_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateUser);

        //Act
        TestUserModel.UserDetails userRulesViewer = Users_API.RulesManagerLocal_POO();
        utilUsers.CreateCDSRiskUIUser(userRulesViewer);

        //Assert
        String userCreatedMessage = createUser_page.userCreatedMessage.getText();
        assertEquals("User has been created with pid " + userRulesViewer.pid,  userCreatedMessage);

        createUser_page.setPID(userRulesViewer.pid);
        createUser_page.clickSearchSRSButton();
        userRulesViewer.status="Inactive";

        createUser_page.assertCreatedUserSRSDetails(userRulesViewer);

        UserDetails_Page userDetails_page = createUser_page.clickViewProfileLink();
        userDetails_page.assertUserDetails(userRulesViewer);
    }



    @Test
    public void WhenUserLogsOut_CanLogBackInAsDifferentUser(){

        //Arrange
        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetailsPOO);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetailsPOO);

        //Act
        utilUsers.Logout(driver);

        //Login as User 2 create data table for EXT
        TestUserModel.UserDetails UserDetails_EXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_EXT);

        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_EXT);

        //Assert
        LoggedInUserDetails loggedInUserDetails = new LoggedInUserDetails(driver);
        assertEquals(UserDetails_EXT.jobTitle.toLowerCase(), loggedInUserDetails.userType.getText().toLowerCase());
        //Base location is not displayed on UI anymore - only jobtitle + user name is displayed
        //assertEquals(UserDetails_EXT.baseLocation.toLowerCase(), loggedInUserDetails.getUserLocation().toLowerCase());
        assertEquals(UserDetails_EXT.firstname + " " + UserDetails_EXT.lastname, loggedInUserDetails.userName.getText());

    }


    @Category({ChangeRequest.CR_1403.class, ChangeRequest.CR_1422.class, ChangeRequest.CR_2224.class, ChangeRequest.CR_2225.class})
    @Test
    public void WhenCreatingAUserWithExtraUserDetails_UserIsCreatedSuccessfully() {

        //Arrange
        TestUserModel.UserDetails UserDetailsSuperAdmin = Users_API.DefaultSuperAdminUser();

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetailsSuperAdmin);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        utilNavigation.NavigateToPage(Navigation.Pages.CreateUser);

        TestUserModel.UserDetails natAdminUser = Users_API.AdminNational();
        natAdminUser.alternativeEmail = "Mark@hmrc.gsi.gov.uk";
        natAdminUser.alternativeEmailUserName = "mark.davis";
        natAdminUser.alternativeEmailDomain = "hmrc.gsi.gov.uk";
        natAdminUser.mobileNumber = "07912312312311";
        natAdminUser.jobTitle = "Supervisor";

        utilUsers.CreateCDSRiskUIUser(natAdminUser);

        MenuToolBar menuToolBar = new MenuToolBar(driver);
        menuToolBar.logout.click();

        Login_Page loginPage = new Login_Page(driver);
        utilUsers.LoginToCDSRiskUIAsUser(natAdminUser);

        ListUsers_Page usersPage = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);

        List<ListUsers_Page.UserListTableObject> listTableObject = usersPage.getListOfUsers();

        Assertions.assertThat(listTableObject).extracting("customsJobTitle").contains(natAdminUser.jobTitle);
        Assertions.assertThat(loginPage.userJobTitleHeader.getText()).isEqualTo(natAdminUser.jobTitle);
    }

    @Test
    public void AttemptToCreateUserWithNoCustomJobTitle_UseNotCreated(){

        //Arrange
        TestUserModel.UserDetails UserDetailsSuperAdmin = Users_API.DefaultSuperAdminUser();

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetailsSuperAdmin);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateUser_Page createUser_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateUser);

        //Act
        TestUserModel.UserDetails userNationalAdmin = Users_API.AdminNational();
        userNationalAdmin.jobTitle = "";

        utilUsers.CreateCDSRiskUIUser(userNationalAdmin);

        //Assert
        Assertions.assertThat(createUser_page.addUser.isEnabled()).isFalse();
    }

    @Test
    public void AttemptToCreateUserWithNoCustomRole_UseNotCreated(){

        //Arrange
        TestUserModel.UserDetails UserDetailsSuperAdmin = Users_API.DefaultSuperAdminUser();

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetailsSuperAdmin);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateUser_Page createUser_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateUser);

        //Act
        TestUserModel.UserDetails userNationalAdmin = Users_API.AdminNational();
        userNationalAdmin.locationRoles.remove(0);

        utilUsers.CreateCDSRiskUIUser(userNationalAdmin);

        //Assert
        Assertions.assertThat(createUser_page.addUser.isEnabled()).isFalse();
    }


    @Category({ChangeRequest.CR_1398.class, ChangeRequest.CR_2673.class})
    @Test
    public void WhenCustomRoleSetToAdminBySuperAdminUser_CustomLocationsFilteredCorrectly(){

        //Arrange
        TestUserModel.UserDetails UserDetailsSuperAdmin = Users_API.DefaultSuperAdminUser();

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetailsSuperAdmin);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateUser_Page createUser_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateUser);

        //Act
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();

        createUser_page.setPID(userDetails.pid);
        createUser_page.searchSRS.click();

        createUser_page.selectCustomRole("Admin");
        List<String> actCustomLocationsForAdmin = createUser_page.getListOfCustomLocations();

        //Assert
        Assertions.assertThat(actCustomLocationsForAdmin)
                .hasSize(1)
                .containsOnly("National Office");
    }

    @Category({ChangeRequest.CR_1398.class, ChangeRequest.CR_2673.class})
    @Test
    public void WhenCustomRoleSetToLocalAdminByLocalSuperAdminUser_CustomLocationsFilteredCorrectly(){

        //Arrange
        TestUserModel.UserDetails UserDetailsLocalSuperAdmin = Users_API.SuperAdminLocal_POO_EXT();

        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetailsLocalSuperAdmin);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetailsLocalSuperAdmin);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateUser_Page createUser_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateUser);

        //Act
        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO_EXT();

        createUser_page.setPID(userDetails.pid);
        createUser_page.searchSRS.click();


        createUser_page.selectCustomRole("LocalAdmin");
        List<String> actCustomLocationsForLocalAdmin = createUser_page.getListOfCustomLocations();

        //Assert
        Assertions.assertThat(actCustomLocationsForLocalAdmin)
                .containsOnly("All My Freight Locations", "EXT - Exeter Airport", "POO - Poole");
    }


    @Category({ChangeRequest.CR_1398.class, ChangeRequest.CR_2673.class})
    @Test
    public void WhenCustomRoleSetToRuleManagerByAdminUser_CustomLocationsFilteredCorrectly(){

        //Arrange
        TestUserModel.UserDetails UserDetailsAdmin = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetailsAdmin);
        
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetailsAdmin);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateUser_Page createUser_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateUser);

        //Act
        String userPidThatHasNotBeenUsedYet = "1234543"; //Need to make this dynamic

        createUser_page.setPID(userPidThatHasNotBeenUsedYet);
        createUser_page.searchSRS.click();

        createUser_page.selectCustomRole("RuleManager");
        List<String> actCustomLocationsForRM = createUser_page.getListOfCustomLocations();


        //Assert
        Assertions.assertThat(actCustomLocationsForRM)
                .hasSize(1)
                .containsOnly("National Office");
    }


    @Category({ChangeRequest.CR_1398.class, ChangeRequest.CR_2673.class})
    @Test
    public void WhenCustomRoleSetToLocalRuleManagerByLocalAdminUser_CustomLocationsFilteredCorrectly(){

        //Arrange
        TestUserModel.UserDetails UserDetailsAdmin = Users_API.AdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetailsAdmin);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetailsAdmin);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateUser_Page createUser_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateUser);

        //Act
        String userPidThatHasNotBeenUsedYet = "1234543"; //Need to make this dynamic

        createUser_page.setPID(userPidThatHasNotBeenUsedYet);
        createUser_page.searchSRS.click();

        createUser_page.selectCustomRole("LocalRuleManager");
        List<String> actCustomLocationsForLocalRM = createUser_page.getListOfCustomLocations();

        //Assert
        Assertions.assertThat(actCustomLocationsForLocalRM)
                .containsOnly("All My Freight Locations", "EXT - Exeter Airport", "POO - Poole");

    }

    @Category({ChangeRequest.CR_1422.class, ChangeRequest.CR_2224.class, ChangeRequest.CR_2225.class})
    @Test
    public void WhenCreatingAUserWithOnlyMandatoryFields_UserIsCreatedSuccessfully() {

        //Arrange
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(Users_API.DefaultSuperAdminUser());

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        utilNavigation.NavigateToPage(Navigation.Pages.CreateUser);

        TestUserModel.UserDetails natAdminUser = Users_API.AdminNational();
        natAdminUser.alternativeEmail = "";
        natAdminUser.alternativeEmailUserName = "";
        natAdminUser.alternativeEmailDomain = "";
        natAdminUser.mobileNumber = "";

        utilUsers.CreateCDSRiskUIUser(natAdminUser);

        Utils.SleepForMilliSeconds(500);
        MenuToolBar menuToolBar = new MenuToolBar(driver);
        menuToolBar.scrollToViewTheElement( menuToolBar.logout);
        menuToolBar.logout.click();
        Utils.SleepForMilliSeconds(500);


        Login_Page loginPage = new Login_Page(driver);
        utilUsers.LoginToCDSRiskUIAsUser(natAdminUser);

        ListUsers_Page usersPage = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);
        List<ListUsers_Page.UserListTableObject> listTableObject = usersPage.getListOfUsers();

        Assertions.assertThat(listTableObject).extracting("customsJobTitle").contains(natAdminUser.jobTitle);
        Assertions.assertThat(loginPage.userJobTitleHeader.getText()).isEqualTo(natAdminUser.jobTitle);
    }


    @Category({ChangeRequest.CR_1872.class,ChangeRequest.CR_1404.class, ChangeRequest.CR_3329.class})
    @Test
    public void WhenNationalSuperAdminLoggedIn_CanCreateLocalSuperAdminWithAllMyLocations(){

        //Arrange
        UI.ElementControls.DropDown dropDown = new UI.ElementControls.DropDown(driver);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(Users_API.DefaultSuperAdminUser());

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateUser_Page createUser_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateUser);

        //Act
        TestUserModel.UserDetails userLocalSuperAdmin = Users_API.SuperAdminLocal_AllLocations();
        utilUsers.CreateCDSRiskUIUser(userLocalSuperAdmin);

        String userCreatedMessage = createUser_page.userCreatedMessage.getText();
        assertEquals("User has been created with pid " + userLocalSuperAdmin.pid,  userCreatedMessage);

        createUser_page.setPID(userLocalSuperAdmin.pid);
        createUser_page.clickSearchSRSButton();

        createUser_page.assertCreatedUserSRSDetails(userLocalSuperAdmin);

        UserDetails_Page userDetails_page = createUser_page.clickViewProfileLink();
        List<UserDetails_Page.CustomRolesTableObject> customRolesTableObjects = userDetails_page.getCustomRoles();

        //Assert
        Assertions.assertThat(customRolesTableObjects).extracting("location")
                .hasSize(149)
                .contains("MAN - Manchester Airport")
                .doesNotContain("National Office")
                .doesNotContain("All My Freight Locations")
                .doesNotContain("All Locations");
        assertEquals("Base Location A Name",userLocalSuperAdmin.baseLocationFullName, userDetails_page.baseLocation.getText());
    }


    @Category(ChangeRequest.CRX_205.class)
    @Test
    public void WhenNewUserIsCreated_UserCanLogin(){

        //Arrange
        TestUserModel.UserDetails UserDetailsSuperAdmin = Users_API.DefaultSuperAdminUser();

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetailsSuperAdmin);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateUser_Page createUser_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateUser);

        //Act
        TestUserModel.UserDetails userDetailsLocalSuperAdmin = Users_API.SuperAdminLocal_POO();
        utilUsers.CreateCDSRiskUIUser(userDetailsLocalSuperAdmin);

        //Assert
        String userCreatedMessage = createUser_page.userCreatedMessage.getText();
        utilUsers.logOut();
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsLocalSuperAdmin);
        assertEquals("User has been created with pid " + userDetailsLocalSuperAdmin.pid,  userCreatedMessage);
    }
}
