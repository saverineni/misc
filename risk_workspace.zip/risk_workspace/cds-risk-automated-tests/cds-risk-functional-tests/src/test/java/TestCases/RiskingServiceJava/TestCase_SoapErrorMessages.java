package TestCases.RiskingServiceJava;

import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.Risking_JavaService;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

@Slf4j
@Category({ChangeRequest_RiskingService.CREP_322.class, Risking_JavaService.class})
public class TestCase_SoapErrorMessages extends BaseRiskingServiceJava{

    @Test
    public void WhenIncorrectDeclarationSent_SoapErrorReturned() {
        String incorrectDeclaration = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"\n" +
                ">\n" +
                "    <soapenv:Header/>\n" +
                "    <soapenv:Body>\n" +
                "            <riskAssessmentRequest>\n" +
                "                <_30_1:id>#id#</_30_1:id>\n" +
                "                <_30_2:object>\n" +
                "                    <_30_3:declarationWithResults>\n" +
                "                        <_30_5:modeOfEntry>5</_30_5:modeOfEntry> <!-- 1, 2 or 3 -->\n" +
                "                    </_30_3:declarationWithResults>\n" +
                "                </_30_2:object>\n" +
                "            </riskAssessmentRequest>\n" +
                "        </_30:initiateRiskAssessment>\n" +
                "    </soapenv:Body>\n" +
                "</soapenv:Envelope>";

        queue.send(incorrectDeclaration);
        DeclarationResponse response = new DeclarationResponse(queue.receive(), true);

        Assertions.assertThat(response.getFaultCode()).isEqualTo("soapenv:client");
        Assertions.assertThat(response.getFaultString()).isEqualTo("Error unmarshalling message to RiskAssessmentRequest");
    }
}
