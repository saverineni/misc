package TestCases.RulesManagementService;


import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.AmendRule.AmendRuleResponse;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.EditRule.EditRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.ViewRule.ViewRuleResponse;
import API.RulesManagementService.ViewRuleVersion.ViewRuleVersionResponse;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Slow_Tests;
import FunctionsLibrary.DateTime;
import TestCases.BaseWebAPITestCase;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import java.util.UUID;

import static API.DataForTests.Rules.DraftVersion2NatRuleNatManager;
import static API.RulesManagementService.Utils.Publish.getPublishHistory;
import static API.RulesManagementService.Utils.Publish.publishEvent;
import static API.RulesManagementService.Utils.Rules.AmendRuleAndGetResponseObject;
import static API.RulesManagementService.Utils.Users.CreateUserAndLogin;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.assertEquals;

@Slf4j
@Category(Slow_Tests.class)
public class TestCase_ExpiredRule extends BaseWebAPITestCase{

    @Test
    @Category(ChangeRequest.CR_1882.class)
    public void WhenRuleEndDateSetToExpireAfterPublish_StatusOfTheRuleIsExpired() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.endDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(1, DateTime.DateTimeUTCZ);

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        TestUserModel.UserDetails superAdminUser = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(superAdminUser);
        String reasonForPublishing = "Rule status Expired check" + UUID.randomUUID().toString().substring(0,4);
        publishEvent(reasonForPublishing);

        //Act
        Response response = getPublishHistory();
        response.then().body("content.reason", hasItem(reasonForPublishing));

        log.debug("Waiting 90 Seconds for Rule end Date Time to be triggered and rule becomes Expired");
        Thread.sleep(90000);

        TestUserModel.UserDetails rulesManagerNational = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(rulesManagerNational);
        ViewRuleResponse.ViewRuleResponseObject ruleResponseAfterPublish = API.RulesManagementService.Utils.Rules.GetRuleByUID(commitResponse.uniqueId);

        //Assert
        log.debug("\n" + "The rule status is currently : " + ruleResponseAfterPublish.response.path("versions[0].status"));
        assertEquals(TestEnumerators.RuleStatus.expired.toString(), ruleResponseAfterPublish.response.path("versions[0].status"));
    }

    @Test
    @Category(ChangeRequest.CR_1882.class)
    public void WhenRuleEndDateSetToExpireBeforePublished_StatusOfTheRuleIsExpired() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.endDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(-90, DateTime.DateTimeUTCZ);

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        TestUserModel.UserDetails superAdminUser = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(superAdminUser);
        String reasonForPublishing = "Rule status Expired check - " + UUID.randomUUID().toString().substring(0,4);
        publishEvent(reasonForPublishing);

        //Act
        Response response = getPublishHistory();
        response.then().body("content.reason", hasItem(reasonForPublishing));

        TestUserModel.UserDetails rulesManagerNational = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(rulesManagerNational);
        ViewRuleResponse.ViewRuleResponseObject ruleResponseAfterPublish = API.RulesManagementService.Utils.Rules.GetRuleByUID(commitResponse.uniqueId);

        //Assert
        log.debug("\n" + "The rule status is currently : " + ruleResponseAfterPublish.response.path("versions[0].status"));
        assertEquals(TestEnumerators.RuleStatus.expired.toString(), ruleResponseAfterPublish.response.path("versions[0].status"));
    }

    @Test
    @Category(ChangeRequest.CR_2350.class)
    public void WhenExpiredRuleIsAmended_ErrorShouldBeShownItCoulNotbeAmended() throws Throwable
    {
       //Create an expired rule
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.endDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(-90, DateTime.DateTimeUTCZ);

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);
        publishAndWait(5000);

        //Try to amend the rule
        TestRuleModel.RuleDetails amendedRule = DraftVersion2NatRuleNatManager();
        amendedRule.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(+10, DateTime.DateTimeUTCZ);
        amendedRule.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(+30, DateTime.DateTimeUTCZ);
        amendedRule.uniqueID = ruleDetails.uniqueID;
        amendedRule.version = 1;

        //400 error is displayed as expired rule cannot be amended
        AmendRuleResponse.PostResponse amendRuleResponse = AmendRuleAndGetResponseObject(amendedRule);
        assertThat(amendRuleResponse.httpStatusCode).isEqualTo(HttpStatus.SC_BAD_REQUEST);
        assertThat(amendRuleResponse.uniqueId).isNull();
    }

}
