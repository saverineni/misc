package TestCases.RulesManagementService;


import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.RuleAction.RuleActionResponse;
import API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse;
import API.RulesManagementService.Users.UserHistory.UserHistoryResponse;
import API.RulesManagementService.Utils.Users;
import API.RulesManagementService.ViewRule.ViewRuleResponse;
import API.RulesManagementService.ViewRuleList.ViewRuleListResponse;
import API.RulesManagementService.ViewRuleVersion.ViewRuleVersionResponse;
import Categories_CDSRisk.CDS_RM_Login;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.assertj.core.api.Assertions;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import static API.DataForTests.Users_API.NationalRulesManagerDefaultTestAutomationUser;
import static API.DataForTests.Users_API.RulesViewerNational;
import static API.RulesManagementService.Utils.RuleAtStatus.ArchiveRule;
import static API.RulesManagementService.Utils.RuleAtStatus.SuspendRule;
import static API.RulesManagementService.Utils.Rules.ReinstateRule;
import static API.RulesManagementService.Utils.Users.CreateUserAndLogin;
import static API.RulesManagementService.Utils.Users.UpdateStatusOfUser;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_Login.class})
public class TestCase_LoginRuleViewer extends BaseWebAPITestCase{

    @Test
    @Category(ChangeRequest.CR_598.class)
    public void WhenUserViewRule_CanViewRule() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        CreateUserAndLogin(RulesViewerNational());
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(createRuleResponse.uniqueId);

        //Assert
        assertEquals(HttpStatus.SC_OK, viewRuleResponse.httpStatusCode);
        assertEquals(ruleDetails.description, viewRuleResponse.versions.get(0).description);
    }

    @Test
    @Category(ChangeRequest.CR_598.class)
    public void WhenUserViewRules_CanViewRules() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        CreateUserAndLogin(RulesViewerNational());
        ViewRuleListResponse.ViewRuleListResponseObject viewRulesResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        assertEquals(HttpStatus.SC_OK, viewRulesResponse.httpStatusCode);

        int ruleNo = API.RulesManagementService.Utils.Rules.GetNoOfMatchingRuleFromRuleList(viewRulesResponse, createRuleResponse.uniqueId);
        assertEquals(ruleDetails.description, viewRulesResponse.content.get(ruleNo).description);
    }

    @Test
    @Category(ChangeRequest.CR_598.class)
    public void WhenUserViewsRuleDetails_CanViewRule() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        CreateUserAndLogin(RulesViewerNational());
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        //Assert
        assertEquals(HttpStatus.SC_OK, viewRuleResponse.httpStatusCode);
        assertEquals(ruleDetails.description, viewRuleResponse.description);
    }


    //Note back end services are not restricted by user yet
    @Ignore("Placeholder Test: Note back end services are not restricted by user yet. Only UI is restricting actions which can be performed on rule")
    @Test
    @Category(ChangeRequest.CR_598.class)
    public void WhenUserCreatesRule_CanNOTCreateRule() throws Throwable {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        //Act
        Response response = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_UNAUTHORIZED, response.getStatusCode());
    }


    //Note back end services are not restricted by user yet
    @Ignore("Placeholder Test: Note back end services are not restricted by user yet. Only UI is restricting actions which can be performed on rule")
    @Test
    @Category(ChangeRequest.CR_598.class)
    public void WhenUserSavesRule_CanNOTSaveRule() throws Throwable {

        //Arrange
        TestUserModel.UserDetails udNatRuleManager = NationalRulesManagerDefaultTestAutomationUser();
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleManager.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ruleDetails.description = "ta_updatedRule";
        ruleDetails.version = 2;
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        TestUserModel.UserDetails udNatRuleViewer = RulesViewerNational();
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleViewer.pid);

        Response editResponse = API.RulesManagementService.Utils.Rules.EditRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_UNAUTHORIZED, editResponse.getStatusCode());
    }

    //Note back end services are not restricted by user yet
    @Ignore("Placeholder Test: Note back end services are not restricted by user yet. Only UI is restricting actions which can be performed on rule")
    @Test
    @Category(ChangeRequest.CR_598.class)
    public void WhenUserCommitsRule_CanNOTCommitRule() throws Throwable
    {
        //Arrange
        TestUserModel.UserDetails udNatRuleManager = NationalRulesManagerDefaultTestAutomationUser();
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleManager.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        TestUserModel.UserDetails udNatRuleViewer = RulesViewerNational();
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleViewer.pid);

        EditRuleVersionResponse.PutResponse editResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_UNAUTHORIZED, editResponse.httpStatusCode);
    }

    //Note back end services are not restricted by user yet
    @Ignore("Placeholder Test: Note back end services are not restricted by user yet. Only UI is restricting actions which can be performed on rule")
    @Test
    @Category(ChangeRequest.CR_598.class)
    public void WhenUserDeletesRule_CanNOTDeleteRule() throws Throwable
    {
        //Arrange
        TestUserModel.UserDetails udNatRuleManager = NationalRulesManagerDefaultTestAutomationUser();
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleManager.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        TestUserModel.UserDetails udNatRuleViewer = RulesViewerNational();
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleViewer.pid);

        EditRuleVersionResponse.PutResponse editResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.delete);

        //Assert
        assertEquals(HttpStatus.SC_UNAUTHORIZED, editResponse.httpStatusCode);
    }


    @Ignore("Placeholder Test: Note back end services are not restricted by user yet. Only UI is restricting actions which can be performed on rule")
    @Test
    @Category(ChangeRequest.CR_598.class)
    public void WhenUserSuspendsLiveRule_CanNOTSuspendRule() throws Throwable
    {
        //Arrange
        TestUserModel.UserDetails udNatRuleManager = NationalRulesManagerDefaultTestAutomationUser();
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleManager.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        ruleDetails.uniqueID = createRuleResponse.uniqueId;
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Act
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        TestUserModel.UserDetails udNatRuleViewer = RulesViewerNational();
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleViewer.pid);

        RuleActionResponse.PostResponse suspendResponse = SuspendRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_UNAUTHORIZED, suspendResponse.httpStatusCode);
    }

    @Ignore("Placeholder Test: Note back end services are not restricted by user yet. Only UI is restricting actions which can be performed on rule")
    @Test
    @Category(ChangeRequest.CR_598.class)
    public void WhenUserReinstatesSuspendedRule_CanNOTReinstateRule() throws Throwable
    {
        //Arrange
        TestUserModel.UserDetails udNatRuleManager = NationalRulesManagerDefaultTestAutomationUser();
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleManager.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        ruleDetails.uniqueID = createRuleResponse.uniqueId;
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        RuleActionResponse.PostResponse suspendResponse = SuspendRule(ruleDetails);

        //Act
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        TestUserModel.UserDetails udNatRuleViewer = RulesViewerNational();
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleViewer.pid);

        RuleActionResponse.PostResponse reinstateResponse = ReinstateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_UNAUTHORIZED, reinstateResponse.httpStatusCode);
    }


    @Ignore("Placeholder Test: Note back end services are not restricted by user yet. Only UI is restricting actions which can be performed on rule")
    @Test
    @Category(ChangeRequest.CR_598.class)
    public void WhenUserArchivesLiveRule_CanArchiveRule() throws Throwable
    {
        //Arrange
        TestUserModel.UserDetails udNatRuleManager = NationalRulesManagerDefaultTestAutomationUser();
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleManager.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        ruleDetails.uniqueID = createRuleResponse.uniqueId;
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Act
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        TestUserModel.UserDetails udNatRuleViewer = RulesViewerNational();
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRuleViewer.pid);

        RuleActionResponse.PostResponse archiveResponse = ArchiveRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_UNAUTHORIZED, archiveResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenRuleViewerLoggedIn_NoMetaDataActionsAvailableForRuleViewer() {

        //Arrange
        TestUserModel.UserDetails userDetails = RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(0);
    }

    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void AttemptToArchiveRuleViewerUser_ForbiddenResponseReceived() {

        //Arrange
        CreateUserAndLogin(Users_API.AdminNational());
        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        CreateUserAndLogin(RulesViewerNational());
        Response userResponse = UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_ARCHIVE.apiAction);

        //Assert
        assertEquals(HttpStatus.SC_FORBIDDEN, userResponse.statusCode());
    }


    @Test
    @Category(ChangeRequest.CR_2698.class)
    public void AttemptToSuspendRuleViewerUser_ForbiddenResponseReceived() {

        //Arrange
        CreateUserAndLogin(Users_API.AdminNational());
        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        CreateUserAndLogin(RulesViewerNational());
        Response userResponse = UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_SUSPEND.apiAction);

        //Assert
        assertEquals(HttpStatus.SC_FORBIDDEN, userResponse.statusCode());
    }


    @Test
    @Category(ChangeRequest.CR_2698.class)
    public void AttemptToEditUser_ForbiddenResponseReceived() {

        //Arrange
        CreateUserAndLogin(Users_API.AdminNational());
        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        CreateUserAndLogin(RulesViewerNational());

        UserMeDetailsResponse.UsersMeResponseObject usersMeResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = usersMeResponseObject1.opLockVersion;
        userDetails.reason = "Editing User";
        Response response = API.RulesManagementService.Utils.Users.EditUser(userDetails);

        //Assert
        assertEquals(HttpStatus.SC_FORBIDDEN, response.statusCode());
    }

    //TODO Attempt to create user - placeholder test not restricted by API yet
   // @Ignore("Placeholder Test: Note back end services are not restricted by user yet. Only UI is restricting actions which can be performed on rule")
//    @Test
//    @Category(ChangeRequest.CR_598.class)
//    public void WhenUserCreatesUser_CanNOTCreateUser() throws Throwable {
//
//        log.info("\r\n" + "WhenUserCreatesUser_CanNOTCreateUser" + "\r\n");
//
//        //Arrange
//
//        //Act
//        //attempt to create user
//
//        //Assert
//        //assertEquals(HttpStatus.SC_UNAUTHORIZED, uoUser1.httpStatusCode);
//
//    }


    @Test
    public void AttemptToViewUserHistory_ForbiddenResponseReceived() {

        //Arrange
        CreateUserAndLogin(Users_API.RulesViewerLocal_EXT());

        // Act
        UserHistoryResponse.UserHistoryResponseObject userHistoryResponseObject = Users.GetListOfUserHistory(Users_API.RulesViewerLocal_EXT().pid);

        //Assert
        assertEquals("Expect HttpStatus.SC_FORBIDDEN ", org.apache.http.HttpStatus.SC_FORBIDDEN, userHistoryResponseObject.httpStatusCode);
    }

}
