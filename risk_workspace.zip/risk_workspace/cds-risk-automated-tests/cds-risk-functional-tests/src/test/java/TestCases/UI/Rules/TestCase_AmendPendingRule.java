package TestCases.UI.Rules;


import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Utils.RuleAtStatus;
import Categories_CDSRisk.*;
import FunctionsLibrary.DateTime;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.Pages.RulesManagement.CreateNationalRule_Page;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.time.ZoneId;
import java.util.List;

import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_1.class})
public class TestCase_AmendPendingRule extends BaseUIWebDriverTestCase {

    @Before
    public void Setup()
    {
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);
    }


    @Category({SmokeTests_UI_2.class, ChangeRequest.CR_1966.class})
    @Test
    public void WhenRuleManagerLoggedIn_CanAmendPendingRuleVersion()
    {
        //Amend amends a specific version of a pending rule, previous version is cancelled

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = RuleAtStatus.CreatePendingExpiredRuleVersion(1, 2);
        publishAndWait(5000);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        //Act
        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);
        List<RuleSummary_Page.RuleUpcomingChangesTableObject> rulePendingTableObjects = ruleSummary_page.getListOfUpcomingChanges();

        boolean amendLink = rulePendingTableObjects.get(0).versionDetailActionAmend.isDisplayed();
        assertEquals("Expect Amend Link to be displayed", true, amendLink);

        rulePendingTableObjects.get(0).versionDetailActionAmend.click();
        ruleSummary_page.waitForAngularRequestsToFinish();

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetailsV2 = UI.DataForTests.Rules.DraftNATRuleVersion2();
        ruleDetailsV2.startRuleImmediately = false;

        ruleDetailsV2.startDate = DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.systemDefault(), 150, "dd/MM/yyyy");
        ruleDetailsV2.startTime = DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.systemDefault(), 150, "HH:mm");

        ruleDetailsV2.endDate = DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.systemDefault(), 180, "dd/MM/yyyy");
        ruleDetailsV2.endTime = DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.systemDefault(), 180, "HH:mm");

        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalRuleSingleCondition(ruleDetailsV2);

        CreateNationalRule_Page createNationalRule_page = new CreateNationalRule_Page(driver);
        createNationalRule_page.clickSaveAndCommitWithDefaultReason();

        publishAndWait(5000);

        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        List<RuleSummary_Page.RuleUpcomingChangesTableObject> listRulePendingTableObjects = ruleSummary_page.getListOfUpcomingChanges();


        ruleSummary_page.ruleVersionsTab.click();
        ruleSummary_page.waitForAngularRequestsToFinish();
        List<RuleSummary_Page.RuleVersionsTableObject> listRuleVersionTableObjects = ruleSummary_page.getListOfRuleVersions();

        //Assert
        assertEquals("Expect Rule Status to be Pending", "Pending", listRuleSummaryTableObjects.get(0).status);
        assertEquals("Expect Rule Version to be 2", 2, listRuleSummaryTableObjects.get(0).version);
        assertEquals("Expect Rule Name to be " + ruleDetailsV2.description, ruleDetailsV2.description, listRuleSummaryTableObjects.get(0).description);

        assertEquals("Expect Rule Status to be Pending", "Pending", listRulePendingTableObjects.get(0).status);
        assertEquals("Expect Rule Version to be 2", 2, listRulePendingTableObjects.get(0).version);

        assertEquals("Expect Rule Version Status to be Cancelled", "Cancelled", listRuleVersionTableObjects.get(1).status);
        assertEquals("Expect Rule Version to be 1", 1, listRuleVersionTableObjects.get(1).version);

        assertEquals("Expect Rule Version Status to be Pending", "Pending", listRuleVersionTableObjects.get(0).status);
        assertEquals("Expect Rule Version to be 2", 2, listRuleVersionTableObjects.get(0).version);
 }



    @Category(ChangeRequest.CR_1966.class)
    @Test
    public void WhenAmendingPendingRule_SaveButtonIsNotDisplayed()
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = RuleAtStatus.CreatePendingExpiredRuleVersion(1, 2);
        publishAndWait(5000);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);
        List<RuleSummary_Page.RuleUpcomingChangesTableObject> rulePendingTableObjects = ruleSummary_page.getListOfUpcomingChanges();

        //Act
        CreateNationalRule_Page createNationalRule_page = ruleSummary_page.clickAmendLink(rulePendingTableObjects.get(0).versionDetailActionAmend);

        boolean saveButton =createNationalRule_page.isElementDisplayed(createNationalRule_page.save);
        boolean saveCommitButton = createNationalRule_page.saveAndCommit.isDisplayed();

        //Assert
        assertEquals("Expect Save button to be not displayed", false, saveButton);
        assertEquals("Expect Save & Commit button to be displayed", true, saveCommitButton);
    }

}
