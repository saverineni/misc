package TestCases.RiskingServiceJava.NarrativeResponse;

import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.Risking_JavaService;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel;
import uk.gov.hmrc.risk.test.common.enums.Matcher;
import uk.gov.hmrc.risk.test.common.enums.MatcherType;
import uk.gov.hmrc.risk.test.common.model.dataService.DataTableCreationModel;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleCreationModel;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static API.DataForTests.DataTypes.DataType_FreeText_UID;
import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.*;

@Slf4j
@Category({ChangeRequest_RiskingService.CREP_378.class, ChangeRequest_RiskingService.CREP_382.class,
        Risking_JavaService.class})
public class TestCase_DataTableOperatorNarratives extends BaseNarrativeTest{

    @Test
   // @Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithDataTableConstainsStringIsHit_CorrectNarrativeIsPresent() {

        Condition dtConsignorName = dataTableFreeTextConsignorName();
        dtConsignorName.setMatcher(Matcher.collectionContainsString);
        dtConsignorName.setMatcherType(MatcherType.CONTAINS);
        dtConsignorName.setDeclarationValue("This text should 'contain this' part");

        String dataTableName = createRuleWithDataTable(dtConsignorName);

        DeclarationResponse response = createAndSendDeclaration( conditions( dtConsignorName));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).contains(
                expectedReason(
                        dtConsignorName, "",
                        "Consignor Name", "contains a value in data table:","'"+dataTableName + "'",
                        "'This text should 'contain this' part'")
        );
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithNotDataTableConstainsStringIsHit_CorrectNarrativeIsPresent() {

        Condition dtConsignorName = dataTableFreeTextConsignorName();
        dtConsignorName.setPositive(false);
        dtConsignorName.setMatcher(Matcher.collectionContainsString);
        dtConsignorName.setMatcherType(MatcherType.CONTAINS);
        dtConsignorName.setDeclarationValue("Does not contain expected text");

        String dataTableName = createRuleWithDataTable(dtConsignorName);

        DeclarationResponse response = createAndSendDeclaration( conditions( dtConsignorName));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).contains(
                expectedReason(
                        dtConsignorName, "",
                        "Consignor Name", "did not contain a value in data table:", "'"+dataTableName +"'",
                        "'Does not contain expected text'")
        );
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithDataTableStartsWithIsHit_CorrectNarrativeIsPresent() {

        Condition dtConsignorName = dataTableFreeTextConsignorName();
        dtConsignorName.setMatcher(Matcher.collectionStartsWith);
        dtConsignorName.setMatcherType(MatcherType.STARTS_WITH);
        dtConsignorName.setDeclarationValue("start with this, then move on");

        String dataTableName = createRuleWithDataTable(dtConsignorName);

        DeclarationResponse response = createAndSendDeclaration( conditions( dtConsignorName));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).contains(
                expectedReason(
                        dtConsignorName, "",
                        "Consignor Name", "starts with a value in data table:", "'"+dataTableName+"'",
                        "'start with this, then move on'")
        );
    }

    @Test
   // @Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithNotDataTableStartsWithIsHit_CorrectNarrativeIsPresent() {

        Condition dtConsignorName = dataTableFreeTextConsignorName();
        dtConsignorName.setPositive(false);
        dtConsignorName.setMatcher(Matcher.collectionStartsWith);
        dtConsignorName.setMatcherType(MatcherType.STARTS_WITH);
        dtConsignorName.setDeclarationValue("Does not start with anything special");

        String dataTableName = createRuleWithDataTable(dtConsignorName);

        DeclarationResponse response = createAndSendDeclaration( conditions( dtConsignorName));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).contains(
                expectedReason(
                        dtConsignorName, "",
                        "Consignor Name", "did not start with a value in data table:", "'"+dataTableName+"'",
                        "'Does not start with anything special'")
        );
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithDataTableEqualToIsHit_CorrectNarrativeIsPresent() {

        Condition dtConsignorName = dataTableFreeTextConsignorName();
        dtConsignorName.setMatcher(Matcher.collectionEqualTo);
        dtConsignorName.setMatcherType(MatcherType.EQUAL);
        dtConsignorName.setDeclarationValue("equal to this");

        String dataTableName = createRuleWithDataTable(dtConsignorName);

        DeclarationResponse response = createAndSendDeclaration( conditions( dtConsignorName));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).contains(
                expectedReason(
                        dtConsignorName, "",
                        "Consignor Name", "was equal to a value in data table:", "'"+dataTableName+"'",
                        "'equal to this'")
        );
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithNotDataTableEqualToIsHit_CorrectNarrativeIsPresent() {

        Condition dtConsignorName = dataTableFreeTextConsignorName();
        dtConsignorName.setPositive(false);
        dtConsignorName.setMatcher(Matcher.collectionEqualTo);
        dtConsignorName.setMatcherType(MatcherType.EQUAL);
        dtConsignorName.setDeclarationValue("Shouldn't be equal to anything");

        String dataTableName = createRuleWithDataTable(dtConsignorName);

        DeclarationResponse response = createAndSendDeclaration( conditions( dtConsignorName));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).contains(
                expectedReason(
                        dtConsignorName, "",
                        "Consignor Name", "was not equal to a value in data table:", "'"+dataTableName+"'",
                        "'Shouldn't be equal to anything'")
        );
    }

    @Test
   // @Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithDataTableMatchesPatternIsHit_CorrectNarrativeIsPresent() {

        Condition dtConsignorName = dataTableFreeTextConsignorName();
        dtConsignorName.setMatcher(Matcher.collectionMatchesPattern);
        dtConsignorName.setMatcherType(MatcherType.MATCHES_PATTERN);
        dtConsignorName.setDeclarationValue("match this pattern");

        String dataTableName = createRuleWithDataTable(dtConsignorName);

        DeclarationResponse response = createAndSendDeclaration( conditions( dtConsignorName));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).contains(
                expectedReason(
                        dtConsignorName, "",
                        "Consignor Name", "matches a value in data table:", "'"+dataTableName+"'",
                        "'match this pattern'")
        );
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithNotDataTableMatchesPatternIsHit_CorrectNarrativeIsPresent() {

        Condition dtConsignorName = dataTableFreeTextConsignorName();
        dtConsignorName.setPositive(false);
        dtConsignorName.setMatcher(Matcher.collectionMatchesPattern);
        dtConsignorName.setMatcherType(MatcherType.MATCHES_PATTERN);
        dtConsignorName.setDeclarationValue("Does not match any patterns");

        String dataTableName = createRuleWithDataTable(dtConsignorName);

        DeclarationResponse response = createAndSendDeclaration( conditions( dtConsignorName));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).contains(
                expectedReason(
                        dtConsignorName, "",
                        "Consignor Name", "did not match a value in data table:", "'"+dataTableName+"'",
                        "'Does not match any patterns'")
        );

    }

    private String createRuleWithDataTable(Condition con) {

        String dataTableUuid = createDataTable();

        con.setValue( dataTableReference(dataTableUuid) );

        RuleDefinitionModel.RuleDefinition ruleDefinition = baseRuleDefinition();
        ruleDefinition.setName(defaultDescription);

        ruleDefinition.setWhenDef(
                whenCreator(conditions( con), Arrays.asList()));

        ruleDefinition.setThenDef(thenCreator(Source.declaration, conditions( con )));

        RuleDefinitionModel definitionModel = defaultDataTableModel();
        definitionModel.getGlobals().add( globalDataTable(dataTableUuid) );
        definitionModel.getRuleDefinitions().clear();
        definitionModel.getRuleDefinitions().add(ruleDefinition);

        String definitionModelString = definitionModel.toString();

        RuleCreationModel model = baseRuleCreationModelBuilder().build();
        model.setDefinition(definitionModelString);

        createAndRefreshRule(model);

        return dataTableSupport.getDataTableDetails(dataTableUuid).getTableName();
    }

    private String createDataTable() {
        DataTableCreationModel model = baseDataTableModel();
        model.setDataTypeUuid(DataType_FreeText_UID);

        List<String> dataItems = new ArrayList<>();
        dataItems.add("contain this");
        dataItems.add("start with this");
        dataItems.add("equal to this");
        dataItems.add("m?tch this pattern");

        return dataTableSupport.createDataTable(model, dataItems);
    }
}
