package TestCases.UI.DataTables;


import API.DataForTests.*;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_DataTables;
import Categories_CDSRisk.CDS_Risk_UI_DataTables_1;
import Categories_CDSRisk.ChangeRequest;
import FunctionsLibrary.DateTime;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.Pages.DataManagement.BaseListDataTable_Page;
import UI.Pages.DataManagement.DataTableSummary_Page;
import UI.Pages.DataManagement.ListDataTable_Page;
import UI.Pages.Home_Page;
import UI.Utils.Navigation;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.ConditionType;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import java.util.List;

import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_DataTables.class, CDS_Risk_UI_DataTables_1.class})
public class TestCase_Archive_DataTables extends BaseUIWebDriverTestCase {

    TestUserModel.UserDetails userDetails_POO;
    TestUserModel.UserDetails userDetails_EXT;
    TestUserModel.UserDetails userDetails_NAT;

    TestDataTableModel.TableDetails tableDetailsPOO;
    TestDataTableModel.TableDetails tableDetailsEXT;
    TestDataTableModel.TableDetails tableDetailsEXTPOO;
    TestDataTableModel.TableDetails tableDetailsNational;
    String dataTableNationalUuid;
    String dataTablePooUniqueId;
    String dataTableNationalUniqueId;


    @Before
    public void LocalSetup() {
        //Login as User 1 create data table for POO
        userDetails_POO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_POO);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_POO.pid);
        tableDetailsPOO = DataTables.DataTable_CommodityCodes_POO();
        tableDetailsPOO.tableType = TestEnumerators.TableType.restricted.toString();
        API.DataService.CreateDataTable.CreateDataTableResponse.PostResponse createDataTableResponse = API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsPOO);
        dataTablePooUniqueId = createDataTableResponse.uniqueId;

        //Login as User 2 create data table for EXT
        userDetails_EXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_EXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_EXT.pid);
        tableDetailsEXT = DataTables.DataTable_CommodityCodes_EXT();
        tableDetailsEXT.tableType = TestEnumerators.TableType.sensitive.toString();
        API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsEXT);

        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_EXT.pid);
        tableDetailsEXTPOO = DataTables.DataTable_CommodityCodes_POOEXT();
        API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsEXTPOO);

        userDetails_NAT = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_NAT);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_NAT.pid);

        tableDetailsNational = DataTables.DataTable_CommodityCodes_NAT();
        createDataTableResponse = API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsNational);
        dataTableNationalUuid = createDataTableResponse.uuid;
        dataTableNationalUniqueId = createDataTableResponse.uniqueId;
    }

    @Category({ChangeRequest.CR_2724.class})
    @Test
    public void WhenAdminViewTheDataTableListPage_DataTablesShouldShowCorrectArchiveStatus() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listDataTable_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        //Assert
        String canArchiveForTheDataTable_Poo = listDataTable_page.getCanArchiveForTheDataTable(tableDetailsPOO.tableName);
        String canArchiveForTheDataTable_Poo_Ext = listDataTable_page.getCanArchiveForTheDataTable(tableDetailsEXTPOO.tableName);
        String canArchiveForTheDataTable_Ext = listDataTable_page.getCanArchiveForTheDataTable(tableDetailsEXT.tableName);
        String canArchiveForTheDataTable_National = listDataTable_page.getCanArchiveForTheDataTable(tableDetailsNational.tableName);

        assertEquals("Yes", canArchiveForTheDataTable_Poo);
        assertEquals("Yes", canArchiveForTheDataTable_Poo_Ext);
        assertEquals("No", canArchiveForTheDataTable_Ext);
        assertEquals("No", canArchiveForTheDataTable_National);

    }

    @Category({ChangeRequest.CR_2724.class})
    @Test
    public void WhenDataTableHasAssociatedRule_DataTableCannotBeArchived() {

        //Arrange
        useDataTableInRule();

        TestUserModel.UserDetails UserDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listDataTable_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);
        String canArchiveForTheDataTable_National_Initial = listDataTable_page.getCanArchiveForTheDataTable(tableDetailsNational.tableName);
        //Assert
        assertEquals("No", canArchiveForTheDataTable_National_Initial);

    }


    @Category({ChangeRequest.CR_2724.class, ChangeRequest.CR_3063.class})
    @Test
    @Ignore("Issue with angular not loading in datatable summary page")
    public void WhenLoggedInAsAdminAndViewDataTableSummaryPage_CorrectDetailsShouldBeDisplayed() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);
        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listDataTable_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);
        listDataTable_page.waitForAngularRequestsToFinish();
        boolean canCreateDataTable = listDataTable_page.canCreateDataTable();
        DataTableSummary_Page summaryPage = listDataTable_page.clickTableSummaryForSpecifiedDataTableID(dataTablePooUniqueId);
        summaryPage.waitForAngularRequestsToFinish();

        String pageHeaderTitle = summaryPage.pageHeaderTitle.getText();
        assertEquals("Data Table ID: "+dataTablePooUniqueId, pageHeaderTitle);

        boolean pageSummaryVisible = summaryPage.isElementDisplayed(summaryPage.pageSummary);
        String dataTableStatus = summaryPage.dataTableStatus.getText();
        assertEquals("Active", dataTableStatus);
        boolean dataTabVisible = summaryPage.isElementDisplayed(summaryPage.dataTab);
        boolean ruleUsageTabVisible = summaryPage.isElementDisplayed(summaryPage.ruleUsageTab);
        boolean historyTabVisible = summaryPage.isElementDisplayed(summaryPage.dataTableHistory);
        boolean accessTabVisible = summaryPage.isElementDisplayed(summaryPage.accessTab);
        assertEquals(false, canCreateDataTable);
        assertEquals(false, dataTabVisible);
        assertEquals(false, ruleUsageTabVisible);
        assertEquals(true,pageSummaryVisible);
        assertEquals(true, accessTabVisible);
        assertEquals(true, historyTabVisible);
    }

    @Category({ChangeRequest.CR_2724.class, ChangeRequest.CR_2949.class, ChangeRequest.CR_3063.class})
    @Test
    public void WhenActiveDataTableIsArchived_DataTableArchivedSuccessfully() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        Navigation utilNavigation = new Navigation(driver);

        ListDataTable_Page listDataTable_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);
        DataTableSummary_Page summaryPage= listDataTable_page.clickTableSummaryForSpecifiedDataTableID(dataTablePooUniqueId);
        boolean summaryPageWithArchiveButton = summaryPage.isElementDisplayed(summaryPage.datatableArchive);

        //Act
        summaryPage.datatableArchive.click();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        listDataTable_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);
        summaryPage=listDataTable_page.clickTableSummaryForSpecifiedDataTableID(dataTablePooUniqueId);
        boolean summaryPageAfterArchiveButton = summaryPage.isElementDisplayed(summaryPage.datatableArchive);

        //Assert
        assertEquals(true, summaryPageWithArchiveButton);
        assertEquals(false, summaryPageAfterArchiveButton);
        assertEquals("Archived", summaryPage.dataTableStatus.getText());
    }


    @Test
    @Category({ChangeRequest.CR_2724.class})
    public void WhenAdminClicksOnDataTableDashBoardDial_DataTablesAreDisplayedCorrectly() {

        //Act
        TestUserModel.UserDetails UserDetails = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);


        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        Home_Page home_page = new Home_Page(driver);
        home_page.dataTab.click();
        home_page.clickDataTableStatusDial("SENSITIVE");
        ListDataTable_Page listDataTable_page = new ListDataTable_Page(driver);
        List<BaseListDataTable_Page.DataTableListObject> dataTableListObjectRestricted = listDataTable_page.getListOfDataTablesForAdmin();
        Assertions.assertThat(dataTableListObjectRestricted).extracting("tableTitle").containsOnly(tableDetailsEXT.tableName);
        Assertions.assertThat(dataTableListObjectRestricted).extracting("canArchive").containsOnly("No");
    }

    private void useDataTableInRule() {

        userDetails_NAT = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_NAT);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_NAT.pid);

        TestRuleModel.RuleDetails ruleDetails = Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).isDataTable = true;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = dataTableNationalUuid;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = ConditionType.datatable;

        ruleDetails.startDateTime = DateTime.AdjustLocalDateTimeNowByXDays(1, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = DateTime.AdjustLocalDateTimeNowByXDays(2, DateTime.DateTimeUTCZ);

        CreateRuleResponse.PostResponse response1 = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response1.uniqueId;
        ruleDetails.ruleId = response1.ruleId;
        API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails, RuleVersionActions.commit);
        publishAndWait(2000);
    }

}

