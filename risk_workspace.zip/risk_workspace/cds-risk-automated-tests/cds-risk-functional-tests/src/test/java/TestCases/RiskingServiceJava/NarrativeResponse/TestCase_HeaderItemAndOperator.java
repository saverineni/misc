package TestCases.RiskingServiceJava.NarrativeResponse;

import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.Risking_JavaService;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.GoodsItemDeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.ItemCollectionDeclarationParam;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.Condition;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.Source;

import java.util.Arrays;

import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.conditions;

@Slf4j
@Category({ChangeRequest_RiskingService.CREP_258.class, ChangeRequest_RiskingService.CREP_299.class,
        ChangeRequest_RiskingService.CREP_378.class, ChangeRequest_RiskingService.CREP_382.class,
        Risking_JavaService.class})
public class TestCase_HeaderItemAndOperator extends BaseNarrativeTest {

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenTwoHeaderConditionsAreMet_CorrectNarrativeIsPresent() {

        createRule(Source.declaration,
                conditions( consignorNameHeader(), consignorAddressHeader() ), Arrays.asList());

        DeclarationResponse response =
                createAndSendDeclaration( conditions( consignorNameHeader(), consignorAddressHeader()));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(2);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .contains("Declaration field: 'Consignor Name' was equal to ConsignorName. The value was: 'ConsignorName'")
                .contains("Declaration field: 'Consignor Street and Number' was equal to Consignor address. The value was: 'Consignor address'");
    }

    @Test
    public void WhenTwoItemConditionsAreMet_CorrectNarrativeIsPresent() {

        createRule(Source.goodsItem,
                Arrays.asList(), conditions( destinationCountryItem(), packageCountItem() ));

        DeclarationResponse response =
                createAndSendDeclaration( conditions( destinationCountryItem(), packageCountItem()));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(2);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .contains("Goods Item (sequenceId=2001) field: 'Destination Country' was equal to PL. The value was: 'PL'")
                .contains("Goods Item (sequenceId=2001) field: 'Package Count' was equal to 1. The value was: 1");
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenHeaderAndItemConditionAreMet_CorrectNarrativeIsPresent() {

        createRule(Source.goodsItem,
                conditions( consignorNameHeader()), conditions( destinationCountryItem()));

        DeclarationResponse response =
                createAndSendDeclaration( conditions( consignorNameHeader(), destinationCountryItem()));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(2);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .contains("Declaration field: 'Consignor Name' was equal to ConsignorName. The value was: 'ConsignorName'")
                .contains("Goods Item (sequenceId=2001) field: 'Destination Country' was equal to PL. The value was: 'PL'");
    }

    @Test
    public void WhenMultipleItemsHitTwoItemConditions_CorrectNarrativeIsPresent() {

        Condition item2DestinationCountryItem = destinationCountryItem();
        Condition item2PackageCountItem = packageCountItem();
        Condition item2SequenceNumber = firstItemSequenceId();

        item2DestinationCountryItem.setDeclarationParam(GoodsItemDeclarationParam.Second.DESTINATION_COUNTRY);
        item2PackageCountItem.setDeclarationParam(ItemCollectionDeclarationParam.Second.PACKAGE_COUNT_ITEM);
        item2SequenceNumber.setDeclarationParam(GoodsItemDeclarationParam.Second.SEQUENCE_NUMBER);
        item2SequenceNumber.setDeclarationValue("2002");

        createRule(Source.goodsItem,
                Arrays.asList(), conditions( destinationCountryItem(), packageCountItem()));

        DeclarationResponse response =
                createAndSendDeclaration( conditions( destinationCountryItem(), packageCountItem(), firstItemSequenceId(),
                        item2DestinationCountryItem, item2PackageCountItem, item2SequenceNumber));

        Assertions.assertThat(response.getMatchReasons()).hasSize(2);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(2);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .contains("Goods Item (sequenceId=2002) field: 'Destination Country' was equal to PL. The value was: 'PL'")
                .contains("Goods Item (sequenceId=2002) field: 'Package Count' was equal to 1. The value was: 1");

        Assertions.assertThat(response.getMatchReasons().get(1)).hasSize(2);
        Assertions.assertThat(response.getMatchReasons().get(1))
                .contains("Goods Item (sequenceId=2001) field: 'Destination Country' was equal to PL. The value was: 'PL'")
                .contains("Goods Item (sequenceId=2001) field: 'Package Count' was equal to 1. The value was: 1");
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenMultipleItemsHitHeaderAndItemConditions_CorrectNarrativeIsPresent() {
        Condition item2DestinationCountryItem = destinationCountryItem();
        Condition item2SequenceNumber = firstItemSequenceId();

        item2DestinationCountryItem.setDeclarationParam(GoodsItemDeclarationParam.Second.DESTINATION_COUNTRY);
        item2SequenceNumber.setDeclarationParam(GoodsItemDeclarationParam.Second.SEQUENCE_NUMBER);
        item2SequenceNumber.setDeclarationValue("2002");

        createRule(Source.goodsItem,
                conditions( consignorNameHeader()), conditions( destinationCountryItem()));

        DeclarationResponse response =
                createAndSendDeclaration( conditions( consignorNameHeader(),
                        destinationCountryItem(), firstItemSequenceId(),
                        item2DestinationCountryItem, item2SequenceNumber));

        Assertions.assertThat(response.getMatchReasons()).hasSize(2);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(2);
        Assertions.assertThat(response.getMatchReasons().get(0))
                .contains("Declaration field: 'Consignor Name' was equal to ConsignorName. The value was: 'ConsignorName'")
                .contains("Goods Item (sequenceId=2002) field: 'Destination Country' was equal to PL. The value was: 'PL'");

        Assertions.assertThat(response.getMatchReasons().get(1)).hasSize(2);
        Assertions.assertThat(response.getMatchReasons().get(1))
                .contains("Declaration field: 'Consignor Name' was equal to ConsignorName. The value was: 'ConsignorName'")
                .contains("Goods Item (sequenceId=2001) field: 'Destination Country' was equal to PL. The value was: 'PL'");
    }
}
