package TestCases;

import Categories_CDSRisk.Rules_Management;
import junitparams.JUnitParamsRunner;
import org.junit.Before;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;

@Category(Rules_Management.class)
@RunWith(JUnitParamsRunner.class)
public class TestCase_RM_MetaDataService extends BaseWebAPITestCase
{
	//CR-178 Extend Metadata Service API to include additional fields

	@Before
	public void Setup() throws Throwable
	{

	}

//TODO Convert to Rest Assured
//	@Category(ChangeRequest.CR_904.class)
//	@Test
//	public void WhenRuleMetaServiceAPICalled_CorrectJSONResponseReturned() throws Throwable
//	{
//		log.info("\r\n" + "WhenRuleMetaServiceAPICalled_CorrectJSONResponseReturned" + "\r\n");
//
//		//Arrange
//
//		//Act
//		CloseableHttpResponse response = HttpClient.SendHttpGetRequest(EnvDetails.url_MetaService);
//
//		//Assert
//		assertEquals(HttpStatus.SC_OK, response.getStatusLine().getStatusCode());
//
//		String sServerResponse = EntityUtils.toString(response.getEntity());
//		log.info("Server Response: " + sServerResponse);
//
//		JSONObject joAll = new JSONObject(sServerResponse);
//
//		assertTrue("createLocations not found", joAll.has("createLocations"));
//		assertTrue("conditionAttributes not found", joAll.has("conditionAttributes"));
//
//		JSONArray jaLocations = joAll.getJSONArray("createLocations");
//		assertTrue("locationName not found", jaLocations.getJSONObject(0).has("locationName"));
//
//		JSONArray jaCondAttributes = joAll.getJSONArray("conditionAttributes");
//		assertTrue("Condition name not found", jaCondAttributes.getJSONObject(0).has("name"));
//		assertTrue("Condition value not found", jaCondAttributes.getJSONObject(0).has("value"));
//		assertTrue("minimum not found", jaCondAttributes.getJSONObject(0).has("minimum"));
//		assertTrue("maximum not found", jaCondAttributes.getJSONObject(0).has("maximum"));
//		assertTrue("pattern not found", jaCondAttributes.getJSONObject(0).has("pattern"));
//		assertTrue("operators not found", jaCondAttributes.getJSONObject(0).has("operators"));
//		assertTrue("inputType not found", jaCondAttributes.getJSONObject(0).has("inputType"));
//
//		JSONArray jaOperators = jaCondAttributes.getJSONObject(0).getJSONArray("operators");
//		assertTrue("operator name not found", jaOperators.getJSONObject(0).has("name"));
//		assertTrue("operator value not found", jaOperators.getJSONObject(0).has("value"));
//		assertTrue("isDataTableAllowed not found", jaOperators.getJSONObject(0).has("isDataTableAllowed"));
//	}
//
//
//	@Test
//	@Category(ChangeRequest.CR_178.class)
//	@Parameters(method  = "RuleMetaServiceAPI_TextTypeTestData")
//	public void WhenRuleMetaServiceAPICalled_CorrectTextFieldDataReturned(MetaServiceAPITestData metaServiceData) throws Throwable
//	{
//		log.info("\r\n" + "WhenRuleMetaServiceAPICalled_CorrectTextFieldDataReturned" + "\r\n");
//		log.info("Testing Rule Meta Data for Field name: " + metaServiceData.name + "\r\n");
//
//		//Arrange
//		//read data
//
//		//Act
//		CloseableHttpResponse response = HttpClient.SendHttpGetRequest(EnvDetails.url_MetaService);
//
//		//Assert
//		assertEquals(HttpStatus.SC_OK, response.getStatusLine().getStatusCode());
//
//		String sServerResponse = EntityUtils.toString(response.getEntity());
//		log.info("Server Response: " + sServerResponse);
//
////		String sMockServerResponse = MockMetaDataServiceResponse1();
////		sServerResponse = sMockServerResponse;
//
//		JSONObject jsonObject = ConvertJSON_RM_Response.GetJSONMetaDataObjectFromJSONBasedOnFieldName(sServerResponse, metaServiceData.name);
//		Map mapMetaData = ConvertJSON_RM_Response.MapJSONMetaDataObjectToHashMap(jsonObject);
//
//		assertEquals(metaServiceData.name, mapMetaData.get("name"));
//		assertEquals(metaServiceData.value, mapMetaData.get("value"));
//
//		//TODO Additional operators
//		assertEquals("minimum: ", metaServiceData.minimum, mapMetaData.get("minimum"));
//		assertEquals("maximum: ",metaServiceData.maximum, mapMetaData.get("maximum"));
//		assertEquals("pattern: ",metaServiceData.pattern, mapMetaData.get("pattern"));
//		assertEquals("inputType: ",metaServiceData.inputType, mapMetaData.get("inputType"));
//
//		assertEquals("operator_Equal: ",metaServiceData.operators.get(0), mapMetaData.get("operator_Equal").toString());
//		assertEquals("operator_NotEqual: ",metaServiceData.operators.get(1), mapMetaData.get("operator_NotEqual").toString());
//		//assertEquals("operator_Starts: ",metaServiceData.operators.get(2), mapMetaData.get("operator_Starts With").toString());
//		//assertEquals("operator_Not Starts With: ",metaServiceData.operators.get(3), mapMetaData.get("operator_Not Starts With").toString());
//		//assertEquals("operator_Contains: ",metaServiceData.operators.get(4), mapMetaData.get("operator_Contains").toString());
//		//assertEquals("operator_Not Contains: ",metaServiceData.operators.get(5), mapMetaData.get("operator_Not Contains").toString());
//	}
//
//	@Ignore ("Placeholder Test: Number Type Attribute not implemented yet")
//	@Test
//	@Category(ChangeRequest.CR_178.class)
//	@Parameters(method  = "RuleMetaServiceAPI_NumberTypeTestData")
//	public void WhenRuleMetaServiceAPICalled_CorrectNumberFieldDataReturned(MetaServiceAPITestData metaServiceData) throws Throwable
//	{
//		log.info("\r\n" + "WhenRuleMetaServiceAPICalled_CorrectNumberFieldDataReturned" + "\r\n");
//		log.info("Testing Meta Data for Field name: " + metaServiceData.name + "\r\n");
//
//		//Arrange
//		//read data
//
//		//Act
//		CloseableHttpResponse response = HttpClient.SendHttpGetRequest(EnvDetails.url_MetaService);
//
//		//Assert
//		assertEquals(HttpStatus.SC_OK, response.getStatusLine().getStatusCode());
//
//		String sServerResponse = EntityUtils.toString(response.getEntity());
//
//		JSONObject jsonObject = ConvertJSON_RM_Response.GetJSONMetaDataObjectFromJSONBasedOnFieldName(sServerResponse, metaServiceData.name);
//		Map mapMetaData = ConvertJSON_RM_Response.MapJSONMetaDataObjectToHashMap(jsonObject);
//
//		assertEquals(metaServiceData.name, mapMetaData.get("name"));
//		assertEquals(metaServiceData.value, mapMetaData.get("value"));
//
//		//TODO Number operators
//		assertEquals(metaServiceData.minimum, mapMetaData.get("minimum"));
//		assertEquals(metaServiceData.maximum, mapMetaData.get("maximum"));
//		assertEquals(metaServiceData.pattern, mapMetaData.get("pattern"));
//		assertEquals(metaServiceData.inputType, mapMetaData.get("inputType"));
//
//		assertEquals(metaServiceData.operators.get(0), mapMetaData.get("operator_Equal").toString());
//		assertEquals(metaServiceData.operators.get(1), mapMetaData.get("operator_Less Than").toString());
//		assertEquals(metaServiceData.operators.get(2), mapMetaData.get("operator_Greater Than").toString());
//		assertEquals(metaServiceData.operators.get(3), mapMetaData.get("operator_Less Than Or Equal To").toString());
//		assertEquals(metaServiceData.operators.get(4), mapMetaData.get("operator_Greater Than Or Equal To").toString());
//
//		//assertEquals(metaServiceData.allowDecimals, mapMetaData.get("allowDecimals")); //boolean
//	}
//
//	private String MockMetaDataServiceResponse1()
//	{
//		return "[\n" +
//				"  {\n" +
//				"    \"name\": \"Consignee Name\",\n" +
//				"    \"value\": \"consigneeName\",\n" +
//				"    \"minimum\": \"1\",\n" +
//				"    \"maximum\": \"256\",\n" +
//				"    \"pattern\": \"[A-Za-z0-9]\",\n" +
//				"    \"inputType\": \"text\",\n" +
//				"    \"operators\": [\n" +
//				"      {\n" +
//				"        \"name\": \"Equal\",\n" +
//				"        \"value\": \"eq\"\n" +
//				"      },\n" +
//				"      {\n" +
//				"        \"name\": \"NotEqual\",\n" +
//				"        \"value\": \"neq\"\n" +
//				"      },\n" +
//				"      {\n" +
//				"        \"name\": \"Starts With\",\n" +
//				"        \"value\": \"st\"\n" +
//				"      },\n" +
//				"      {\n" +
//				"        \"name\": \"Not Starts With\",\n" +
//				"        \"value\": \"nst\"\n" +
//				"      },\n" +
//				"      {\n" +
//				"        \"name\": \"Contains\",\n" +
//				"        \"value\": \"co\"\n" +
//				"      },\n" +
//				"      {\n" +
//				"        \"name\": \"Not Contains\",\n" +
//				"        \"value\": \"nco\"\n" +
//				"      }\n" +
//				"    ]\n" +
//				"  }\n" +
//				"]";
//	}
//
//	private String MockMetaDataServiceResponse2()
//	{
//		return "[\n" +
//				"  {\n" +
//				"    \"name\": \"Commodity Code\",\n" +
//				"    \"value\": \"commodityCode\",\n" +
//				"    \"minimum\": \"100000000\",\n" +
//				"    \"maximum\": \"9999999999\",\n" +
//				"    \"inputType\": \"number\",\n" +
//				"    \"allowDecimals\": \"true\",\n" +
//				"    \"operators\": [\n" +
//				"      {\n" +
//				"        \"name\": \"Equal\",\n" +
//				"        \"value\": \"eq\"\n" +
//				"      },\n" +
//				"      {\n" +
//				"        \"name\": \"Less Than\",\n" +
//				"        \"value\": \"lt\"\n" +
//				"      },\n" +
//				"      {\n" +
//				"        \"name\": \"Greater Than\",\n" +
//				"        \"value\": \"gt\"\n" +
//				"      },\n" +
//				"      {\n" +
//				"        \"name\": \"Less Than Or Equal To\",\n" +
//				"        \"value\": \"lte\"\n" +
//				"      },\n" +
//				"      {\n" +
//				"        \"name\": \"Greater Than Or Equal To\",\n" +
//				"        \"value\": \"gte\"\n" +
//				"      },\n" +
//				"    ]\n" +
//				"  }\n" +
//				"]";
//	}
//
//
//	private Object[] RuleMetaServiceAPI_TextTypeTestData()
//	{
//		return MetaServiceAPITestData.MetaServiceAPI_TextTypeTestData();
//	}
//
//	private Object[] RuleMetaServiceAPI_NumberTypeTestData()
//	{
//		return MetaServiceAPITestData.MetaServiceAPI_NumberTypeTestData();
//	}
//
//
//	@Category(ChangeRequest.CR_826.class)
//	@Test
//	public void WhenDataTableMetaServiceAPICalled_CorrectJSONResponseReturned() throws Throwable
//	{
//		log.info("\r\n" + "WhenDataTableMetaServiceAPICalled_CorrectJSONResponseReturned" + "\r\n");
//
//		//Arrange
//		String sURL = EnvDetails.url_RM_DataService + "/meta";
//
//		//Act
//		CloseableHttpResponse response = HttpClient.SendHttpGetRequest(sURL);
//
//		//Assert
//		assertEquals(HttpStatus.SC_OK, response.getStatusLine().getStatusCode());
//
//		String sServerResponse = EntityUtils.toString(response.getEntity());
//		log.info("Server Response: " + sServerResponse);
//
//		JSONArray jaAll = new JSONArray(sServerResponse);
//
//		assertTrue("uuid not found", jaAll.getJSONObject(0).has("uuid"));
//		assertTrue("tableName not found", jaAll.getJSONObject(0).has("tableName"));
//	}
//
////	@Category(ChangeRequest.CR_826.class)
////	@Test
////	public void WhenDataTableMetaServiceAPICalled_CorrectDataTableDataReturned() throws Throwable
////	{
////		log.info("\r\n" + "WhenDataTableMetaServiceAPICalled_CorrectDataTableDataReturned" + "\r\n");
////
////		//Arrange
////		String sActualUUID = "";
////		String sActualName= "";
////		String sDefaultDataTableUid = ConvertJSON_DataTableResponse.GetDataTableUuidForDataTable("Default Test Data Table");
////		String sURL = EnvDetails.url_RM_DataService + "/meta";
////
////		//Act
////		CloseableHttpResponse response = HttpClient.SendHttpGetRequest(sURL);
////
////		//Assert
////		assertEquals(HttpStatus.SC_OK, response.getStatusLine().getStatusCode());
////
////		String sServerResponse = EntityUtils.toString(response.getEntity());
////		log.info("Server Response: " + sServerResponse);
////
////		JSONArray jaAll = new JSONArray(sServerResponse);
////
////		int iDataTables = jaAll.length();
////		for (int i=0; i < iDataTables; i++)
////		{
////			sActualUUID = jaAll.getJSONObject(i).getString("uuid");
////			if (sActualUUID.equals(sDefaultDataTableUid))
////			{
////				sActualName = jaAll.getJSONObject(i).getString("tableName");
////				break;
////			}
////		}
////
////		assertEquals(sDefaultDataTableUid, sActualUUID);
////		assertEquals("Default Test Data Table", sActualName);
////	}
//
//
//	@Ignore("Test failing due to Bug: CR-1233. Data Table is no longer being filtered by Data Type")
//	@Test
//	@Category(ChangeRequest.CR_1015.class)
//	public void WhenDataTablesMetaFilteredBy1DataType_CorrectDataTablesReturned() throws Throwable {
//
//		log.info("\r\n" + "WhenDataTablesMetaFilteredBy1DataType_CorrectDataTablesReturned" + "\r\n");
//
//		//Arrange
//		String sExpDataType_A = "ta_DataTypeA";
//		String sExpDataType_B = "ta_DataTypeB";
//		String sExpDataType_C = "ta_DataTypeC";
//		String sExpPattern = "";
//
//		API_DataTable_Responses.DataTypeCreatedResponseObject dtTypeA = DT_CreateDataTable_TestData.DT_CreateDataType(sExpDataType_A, sExpPattern);
//		API_DataTable_Responses.DataTypeCreatedResponseObject dtTypeB = DT_CreateDataTable_TestData.DT_CreateDataType(sExpDataType_B, sExpPattern);
//		API_DataTable_Responses.DataTypeCreatedResponseObject dtTypeC = DT_CreateDataTable_TestData.DT_CreateDataType(sExpDataType_C, sExpPattern);
//
//
//		DT_CreateDataTable_TestData.DataTableServiceAPITestData dtTableA = DT_CreateDataTable_TestData.DataTable_CommodityCodes_NAT();
//		DT_CreateDataTable_TestData.DataTableServiceAPITestData dtTableB = DT_CreateDataTable_TestData.DataTable_CommodityCodes_POO();
//		DT_CreateDataTable_TestData.DataTableServiceAPITestData dtTableC = DT_CreateDataTable_TestData.DataTable_CommodityCodes_POOEXT();
//
//		dtTableA.dataTypeUuid = dtTypeA.dataTypeUuid;
//		dtTableB.dataTypeUuid = dtTypeB.dataTypeUuid;
//		dtTableC.dataTypeUuid = dtTypeA.dataTypeUuid;       // Table C --> Type A
//
//		API_DataTable_Responses.DataTableCreatedResponseObject dtCreateTableA = DT_CreateDataTable_TestData.DT_CreateDataTable(dtTableA);
//		API_DataTable_Responses.DataTableCreatedResponseObject dtCreateTableB = DT_CreateDataTable_TestData.DT_CreateDataTable(dtTableB);
//		API_DataTable_Responses.DataTableCreatedResponseObject dtCreateTableC = DT_CreateDataTable_TestData.DT_CreateDataTable(dtTableC);
//
//		//Act
//		String sURL = EnvDetails.url_RM_DataService + "/meta?dataTypeUuids=" + dtTypeA.dataTypeUuid;
//		CloseableHttpResponse serverResponse2 = HttpClient.SendHttpGetRequest(sURL);
//		API_DataTable_Responses.DataTableGetAllTableResponse dtAllTables = ConvertJSON_DataTableResponse.RM_GetListOfDataTables(serverResponse2);
//
//
//		//Assert
//		//assertEquals("Expect 2 Data Tables to be returned", 2, dtAllTables.iNoOfTables);
//
//		List<String> actDataTables = new ArrayList<>();
//		actDataTables.add(dtAllTables.dataTableResponse.get(0).tableName);
//		actDataTables.add(dtAllTables.dataTableResponse.get(1).tableName);
//
//		Assert.assertTrue("Expect Data Table: " + dtTableA.tableName, actDataTables.contains(dtTableA.tableName));
//		Assert.assertTrue("Expect Data Table: " + dtTableC.tableName, actDataTables.contains(dtTableC.tableName));
//	}
}
