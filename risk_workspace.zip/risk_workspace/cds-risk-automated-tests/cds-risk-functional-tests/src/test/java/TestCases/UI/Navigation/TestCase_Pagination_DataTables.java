package TestCases.UI.Navigation;

import API.DataForTests.*;
import API.RulesManagementService.Data.ViewDataTableList.ViewDataTableListResponse;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.UnstableTests;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.PaginationToolBar;
import UI.Pages.DataManagement.ListDataTable_Page;
import UI.Utils.Navigation;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static FunctionsLibrary.Utils.SleepForMilliSeconds;
import static org.junit.Assert.assertEquals;

@Category(UnstableTests.class)
public class TestCase_Pagination_DataTables extends BaseUIWebDriverTestCase {

    private PaginationInfo paginationInfo;
    public TestUserModel.UserDetails UserDetails_EXT;

    @Before
    public void LocalSetup() {

        paginationInfo = new PaginationInfo();

        UserDetails_EXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_EXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails_EXT.pid);

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListROStart = API.RulesManagementService.Utils.DataTables.GetListOfDataTables();
        paginationInfo.iElementsAtStart = viewDataTableListROStart.totalElements;
        paginationInfo.iPagesAtStart = viewDataTableListROStart.totalPages;
    }


    @Category(ChangeRequest.CR_582.class)
    @Test
    public void WhenListAllDataTablesContainsMoreThan20Tables_PaginationInfoCorrect() {
        //Act
        paginationInfo.iSizeOfPage = 20;
        paginationInfo.iElementsAdded = 21;
        paginationInfo = paginationInfo.calculatePaginationInfo(paginationInfo);

        CreateDataTables(paginationInfo.iElementsAdded);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_EXT);

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listDataTable_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        List<ListDataTable_Page.DataTableListObject> dataTables = listDataTable_page.getDataTableListDetails();

        //Assert
        assertEquals("Expect default size 20 data tables to be displayed", 20, dataTables.size());

        PaginationToolBar paginationToolBar = new PaginationToolBar(driver);

        String actPageSize = paginationToolBar.getPageSize();
        int iActPageSize = Integer.parseInt(actPageSize);

        assertEquals("Expect default page size to be 20", 20, iActPageSize);

        String actNoOfDataTablesMessage = paginationToolBar.totalPagesFoundText.getText();
        int actNoOfDataTables = Integer.parseInt(actNoOfDataTablesMessage.split(" ")[0]);
        assertEquals("Expect total data tables to be ", paginationInfo.iTotalElementsAtEnd, actNoOfDataTables);

        String actPageXofY = paginationToolBar.pageXofY.getText();
        assertEquals("Expect Page 1 of x", "Page 1 of " + paginationInfo.iCalcTotalPages, actPageXofY);

        boolean bNextPage = paginationToolBar.nextPage.isDisplayed();
        assertEquals("Expect Next page button to be displayed", true, bNextPage);

        boolean bLastPage = paginationToolBar.lastPage.isDisplayed();
        assertEquals("Expect Last page button to be displayed", true, bLastPage);

        boolean bPage1 = paginationToolBar.page1.isDisplayed();
        assertEquals("Expect Page 1 button to be displayed", true, bPage1);

        boolean bPage2 = paginationToolBar.page2.isDisplayed();
        assertEquals("Expect Page 2 button to be displayed", true, bPage2);

        boolean bFirstPage = paginationToolBar.isPaginationButtonDisplayed("First page");
        assertEquals("Expect First Page button to be NOT displayed", false, bFirstPage);

        boolean bPreviousPage = paginationToolBar.isPaginationButtonDisplayed("Previous page");
        assertEquals("Expect Previous Page button to be NOT displayed", false, bPreviousPage);
    }

    @Category(ChangeRequest.CR_582.class)
    @Test
    public void WhenListAllDataTablesPageSizeIsSetTo5_PaginationInfoResetCorrectly() {
        //Act
        paginationInfo.iSizeOfPage = 5;
        paginationInfo.iElementsAdded = 21;
        paginationInfo = paginationInfo.calculatePaginationInfo(paginationInfo);

        CreateDataTables(paginationInfo.iElementsAdded);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_EXT);

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listDataTable_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        PaginationToolBar paginationToolBar = new PaginationToolBar(driver);

        paginationToolBar.selectPageSize(paginationInfo.iSizeOfPage);

        //Assert
        List<ListDataTable_Page.DataTableListObject> dataTables = listDataTable_page.getDataTableListDetails();

        assertEquals("Expect 5 data tables to be displayed", paginationInfo.iSizeOfPage, dataTables.size());

        String actPageSize = paginationToolBar.getPageSize();
        int iActPageSize = Integer.parseInt(actPageSize);

        assertEquals("Expect page size to be 5", paginationInfo.iSizeOfPage, iActPageSize);

        String actNoOfDataTablesMessage = paginationToolBar.totalPagesFoundText.getText();
        int actNoOfDataTables = Integer.parseInt(actNoOfDataTablesMessage.split(" ")[0]);
        assertEquals("Expect total data tables to be ", paginationInfo.iTotalElementsAtEnd, actNoOfDataTables);

        String actPageXofY = paginationToolBar.pageXofY.getText();
        assertEquals("Expect Page 1 of x", "Page 1 of " + paginationInfo.iCalcTotalPages, actPageXofY);

        boolean bNextPage = paginationToolBar.nextPage.isDisplayed();
        assertEquals("Expect Next page button to be displayed", true, bNextPage);

        boolean bLastPage = paginationToolBar.lastPage.isDisplayed();
        assertEquals("Expect Last page button to be displayed", true, bLastPage);

        boolean bPage1 = paginationToolBar.page1.isDisplayed();
        assertEquals("Expect Page 1 button to be displayed", true, bPage1);

        boolean bPage2 = paginationToolBar.page2.isDisplayed();
        assertEquals("Expect Page 2 button to be displayed", true, bPage2);

        boolean bPage3 = paginationToolBar.page3.isDisplayed();
        assertEquals("Expect Page 3 button to be displayed", true, bPage3);

        boolean bPage4 = paginationToolBar.page4.isDisplayed();
        assertEquals("Expect Page 4 button to be displayed", true, bPage4);

        boolean bPage5 = paginationToolBar.page5.isDisplayed();
        assertEquals("Expect Page 5 button to be displayed", true, bPage5);
    }


    @Category(ChangeRequest.CR_582.class)
    @Test
    public void WhenListAllDataTablesPageNavigationNextButtonClicked_CorrectPageDetailsDisplayed() {
        //Act
        paginationInfo.iSizeOfPage = 5;
        paginationInfo.iElementsAdded = 21;
        paginationInfo = paginationInfo.calculatePaginationInfo(paginationInfo);

        CreateDataTables(paginationInfo.iElementsAdded);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_EXT);

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listDataTable_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        PaginationToolBar paginationToolBar = new PaginationToolBar(driver);

        paginationToolBar.selectPageSize(paginationInfo.iSizeOfPage);

        paginationToolBar.nextPage.click();

        //Assert
        List<ListDataTable_Page.DataTableListObject> dataTables = listDataTable_page.getDataTableListDetails();

        assertEquals("Expect 5 data tables to be displayed", paginationInfo.iSizeOfPage, dataTables.size());

        String actPageSize = paginationToolBar.getPageSize();
        int iActPageSize = Integer.parseInt(actPageSize);

        assertEquals("Expect page size to be 5", paginationInfo.iSizeOfPage, iActPageSize);

        String actNoOfDataTablesMessage = paginationToolBar.totalPagesFoundText.getText();
        int actNoOfDataTables = Integer.parseInt(actNoOfDataTablesMessage.split(" ")[0]);
        assertEquals("Expect total data tables to be ", paginationInfo.iTotalElementsAtEnd, actNoOfDataTables);

        String actPageXofY = paginationToolBar.pageXofY.getText();
        assertEquals("Expect Page 2 of x", "Page 2 of " + paginationInfo.iCalcTotalPages, actPageXofY);

        boolean bNextPage = paginationToolBar.nextPage.isDisplayed();
        assertEquals("Expect Next page button to be displayed", true, bNextPage);

        boolean bLastPage = paginationToolBar.lastPage.isDisplayed();
        assertEquals("Expect Last page button to be displayed", true, bLastPage);

        boolean bPage1 = paginationToolBar.page1.isDisplayed();
        assertEquals("Expect Page 1 button to be displayed", true, bPage1);

        boolean bPage2 = paginationToolBar.page2.isDisplayed();
        assertEquals("Expect Page 2 button to be displayed", true, bPage2);

        boolean bPage3 = paginationToolBar.page3.isDisplayed();
        assertEquals("Expect Page 3 button to be displayed", true, bPage3);

        boolean bPage4 = paginationToolBar.page4.isDisplayed();
        assertEquals("Expect Page 4 button to be displayed", true, bPage4);

        boolean bPage5 = paginationToolBar.page5.isDisplayed();
        assertEquals("Expect Page 5 button to be displayed", true, bPage5);

        boolean bPrevious = paginationToolBar.previousPage.isDisplayed();
        assertEquals("Expect previous page button to be displayed", true, bPrevious);

        boolean bFirst = paginationToolBar.firstPage.isDisplayed();
        assertEquals("Expect first page button to be displayed", true, bFirst);
    }


    @Category(ChangeRequest.CR_582.class)
    @Test
    public void WhenListAllDataTablesPageNavigationPage3ButtonClicked_CorrectPageDetailsDisplayed() {
        //Act
        paginationInfo.iSizeOfPage = 5;
        paginationInfo.iElementsAdded = 21;
        paginationInfo = paginationInfo.calculatePaginationInfo(paginationInfo);

        CreateDataTables(paginationInfo.iElementsAdded);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_EXT);

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listDataTable_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        PaginationToolBar paginationToolBar = new PaginationToolBar(driver);

        paginationToolBar.selectPageSize(paginationInfo.iSizeOfPage);

        paginationToolBar.page3.click();

        //Assert
        List<ListDataTable_Page.DataTableListObject> dataTables = listDataTable_page.getDataTableListDetails();

        assertEquals("Expect 5 data tables to be displayed", paginationInfo.iSizeOfPage, dataTables.size());

        String actPageSize = paginationToolBar.getPageSize();
        int iActPageSize = Integer.parseInt(actPageSize);

        assertEquals("Expect page size to be 5", paginationInfo.iSizeOfPage, iActPageSize);

        String actNoOfDataTablesMessage = paginationToolBar.totalPagesFoundText.getText();
        int actNoOfDataTables = Integer.parseInt(actNoOfDataTablesMessage.split(" ")[0]);
        assertEquals("Expect total data tables to be ", paginationInfo.iTotalElementsAtEnd, actNoOfDataTables);

        String actPageXofY = paginationToolBar.pageXofY.getText();
        assertEquals("Expect Page 3 of x", "Page 3 of " + paginationInfo.iCalcTotalPages, actPageXofY);

        boolean bNextPage = paginationToolBar.nextPage.isDisplayed();
        assertEquals("Expect Next page button to be displayed", true, bNextPage);

        boolean bLastPage = paginationToolBar.lastPage.isDisplayed();
        assertEquals("Expect Last page button to be displayed", true, bLastPage);

        boolean bPage1 = paginationToolBar.page1.isDisplayed();
        assertEquals("Expect Page 1 button to be displayed", true, bPage1);

        boolean bPage2 = paginationToolBar.page2.isDisplayed();
        assertEquals("Expect Page 2 button to be displayed", true, bPage2);

        boolean bPage3 = paginationToolBar.page3.isDisplayed();
        assertEquals("Expect Page 3 button to be displayed", true, bPage3);

        boolean bPage4 = paginationToolBar.page4.isDisplayed();
        assertEquals("Expect Page 4 button to be displayed", true, bPage4);

        boolean bPage5 = paginationToolBar.page5.isDisplayed();
        assertEquals("Expect Page 5 button to be displayed", true, bPage5);

        boolean bPrevious = paginationToolBar.previousPage.isDisplayed();
        assertEquals("Expect previous page button to be displayed", true, bPrevious);

        boolean bFirst = paginationToolBar.firstPage.isDisplayed();
        assertEquals("Expect first page button to be displayed", true, bFirst);
    }


    @Category(ChangeRequest.CR_582.class)
    @Test
    public void WhenListAllDataTablesPageNavigationLastPageButtonClicked_CorrectPageDetailsDisplayed() {
        //Act
        paginationInfo.iSizeOfPage = 5;
        paginationInfo.iElementsAdded = 21;
        paginationInfo = paginationInfo.calculatePaginationInfo(paginationInfo);

        CreateDataTables(paginationInfo.iElementsAdded);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_EXT);

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listDataTable_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        PaginationToolBar paginationToolBar = new PaginationToolBar(driver);

        paginationToolBar.selectPageSize(paginationInfo.iSizeOfPage);

        paginationToolBar.lastPage.click();

        //Assert
        List<ListDataTable_Page.DataTableListObject> dataTables = listDataTable_page.getDataTableListDetails();

        //20 tables over 4 pages, and 1 table on page 5
        assertEquals("Expect " + paginationInfo.iCalcElementsOnLastPage + "data tables to be displayed",
                paginationInfo.iCalcElementsOnLastPage, dataTables.size());

        String actPageSize = paginationToolBar.getPageSize();
        int iActPageSize = Integer.parseInt(actPageSize);

        assertEquals("Expect page size to be 5", paginationInfo.iSizeOfPage, iActPageSize);

        String actNoOfDataTablesMessage = paginationToolBar.totalPagesFoundText.getText();
        int actNoOfDataTables = Integer.parseInt(actNoOfDataTablesMessage.split(" ")[0]);
        assertEquals("Expect total data tables to be ", paginationInfo.iTotalElementsAtEnd, actNoOfDataTables);

        String actPageXofY = paginationToolBar.pageXofY.getText();
        assertEquals("Expect Page 5 of x", "Page " + paginationInfo.iCalcTotalPages + " of " + paginationInfo.iCalcTotalPages, actPageXofY);

        boolean bNextPage = paginationToolBar.isPaginationButtonDisplayed("Next page");
        assertEquals("Expect Next page button to be NOT displayed", false, bNextPage);

        boolean bLastPage = paginationToolBar.isPaginationButtonDisplayed("Last page");
        assertEquals("Expect Last page button to be NOT displayed", false, bLastPage);

        boolean bPage1 = paginationToolBar.page1.isDisplayed();
        assertEquals("Expect Page 1 button to be displayed", true, bPage1);

        boolean bPage2 = paginationToolBar.page2.isDisplayed();
        assertEquals("Expect Page 2 button to be displayed", true, bPage2);

        boolean bPage3 = paginationToolBar.page3.isDisplayed();
        assertEquals("Expect Page 3 button to be displayed", true, bPage3);

        boolean bPage4 = paginationToolBar.page4.isDisplayed();
        assertEquals("Expect Page 4 button to be displayed", true, bPage4);

        boolean bPage5 = paginationToolBar.page5.isDisplayed();
        assertEquals("Expect Page 5 button to be displayed", true, bPage5);

        boolean bPrevious = paginationToolBar.previousPage.isDisplayed();
        assertEquals("Expect previous page button to be displayed", true, bPrevious);

        boolean bFirst = paginationToolBar.firstPage.isDisplayed();
        assertEquals("Expect first page button to be displayed", true, bFirst);
    }


    @Category(ChangeRequest.CR_582.class)
    @Test
    public void WhenListAllDataTablesPageNavigationPreviousButtonClicked_CorrectPageDetailsDisplayed() {
        //Act
        paginationInfo.iSizeOfPage = 5;
        paginationInfo.iElementsAdded = 21;
        paginationInfo = paginationInfo.calculatePaginationInfo(paginationInfo);

        CreateDataTables(paginationInfo.iElementsAdded);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_EXT);

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listDataTable_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        PaginationToolBar paginationToolBar = new PaginationToolBar(driver);

        paginationToolBar.selectPageSize(paginationInfo.iSizeOfPage);

        paginationToolBar.page4.click();
        SleepForMilliSeconds(1000);
        paginationToolBar.previousPage.click();
        SleepForMilliSeconds(1000);

        //Assert
        List<ListDataTable_Page.DataTableListObject> dataTables = listDataTable_page.getDataTableListDetails();

        assertEquals("Expect 5 data tables to be displayed", paginationInfo.iSizeOfPage, dataTables.size());

        String actPageSize = paginationToolBar.getPageSize();
        int iActPageSize = Integer.parseInt(actPageSize);

        assertEquals("Expect page size to be 5", paginationInfo.iSizeOfPage, iActPageSize);

        String actNoOfDataTablesMessage = paginationToolBar.totalPagesFoundText.getText();
        int actNoOfDataTables = Integer.parseInt(actNoOfDataTablesMessage.split(" ")[0]);
        assertEquals("Expect total data tables to be ", paginationInfo.iTotalElementsAtEnd, actNoOfDataTables);

        String actPageXofY = paginationToolBar.pageXofY.getText();
        assertEquals("Expect Page 3 of x", "Page 3 of " + paginationInfo.iCalcTotalPages, actPageXofY);

        boolean bNextPage = paginationToolBar.nextPage.isDisplayed();
        assertEquals("Expect Next page button to be displayed", true, bNextPage);

        boolean bLastPage = paginationToolBar.lastPage.isDisplayed();
        assertEquals("Expect Last page button to be displayed", true, bLastPage);

        boolean bPage1 = paginationToolBar.page1.isDisplayed();
        assertEquals("Expect Page 1 button to be displayed", true, bPage1);

        boolean bPage2 = paginationToolBar.page2.isDisplayed();
        assertEquals("Expect Page 2 button to be displayed", true, bPage2);

        boolean bPage3 = paginationToolBar.page3.isDisplayed();
        assertEquals("Expect Page 3 button to be displayed", true, bPage3);

        boolean bPage4 = paginationToolBar.page4.isDisplayed();
        assertEquals("Expect Page 4 button to be displayed", true, bPage4);

        boolean bPage5 = paginationToolBar.page5.isDisplayed();
        assertEquals("Expect Page 5 button to be displayed", true, bPage5);

        boolean bPrevious = paginationToolBar.previousPage.isDisplayed();
        assertEquals("Expect previous page button to be displayed", true, bPrevious);

        boolean bFirst = paginationToolBar.firstPage.isDisplayed();
        assertEquals("Expect first page button to be displayed", true, bFirst);
    }


    @Category(ChangeRequest.CR_582.class)
    @Test
    public void WhenListAllDataTablesPageNavigationFirstButtonClicked_CorrectPageDetailsDisplayed() {
        //Act
        paginationInfo.iSizeOfPage = 5;
        paginationInfo.iElementsAdded = 21;
        paginationInfo = paginationInfo.calculatePaginationInfo(paginationInfo);

        CreateDataTables(paginationInfo.iElementsAdded);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_EXT);

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listDataTable_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        PaginationToolBar paginationToolBar = new PaginationToolBar(driver);

        paginationToolBar.selectPageSize(paginationInfo.iSizeOfPage);
        paginationToolBar.page3.click();
        paginationToolBar.firstPage.click();

        //Assert
        List<ListDataTable_Page.DataTableListObject> dataTables = listDataTable_page.getDataTableListDetails();

        assertEquals("Expect 5 data tables to be displayed", paginationInfo.iSizeOfPage, dataTables.size());

        String actPageSize = paginationToolBar.getPageSize();
        int iActPageSize = Integer.parseInt(actPageSize);

        assertEquals("Expect page size to be 5", paginationInfo.iSizeOfPage, iActPageSize);

        String actNoOfDataTablesMessage = paginationToolBar.totalPagesFoundText.getText();
        int actNoOfDataTables = Integer.parseInt(actNoOfDataTablesMessage.split(" ")[0]);
        assertEquals("Expect total data tables to be ", paginationInfo.iTotalElementsAtEnd, actNoOfDataTables);

        String actPageXofY = paginationToolBar.pageXofY.getText();
        assertEquals("Expect Page 1 of x", "Page 1 of " + paginationInfo.iCalcTotalPages, actPageXofY);

        boolean bNextPage = paginationToolBar.nextPage.isDisplayed();
        assertEquals("Expect Next page button to be displayed", true, bNextPage);

        boolean bLastPage = paginationToolBar.lastPage.isDisplayed();
        assertEquals("Expect Last page button to be displayed", true, bLastPage);

        boolean bPage1 = paginationToolBar.page1.isDisplayed();
        assertEquals("Expect Page 1 button to be displayed", true, bPage1);

        boolean bPage2 = paginationToolBar.page2.isDisplayed();
        assertEquals("Expect Page 2 button to be displayed", true, bPage2);

        boolean bPage3 = paginationToolBar.page3.isDisplayed();
        assertEquals("Expect Page 3 button to be displayed", true, bPage3);

        boolean bPage4 = paginationToolBar.page4.isDisplayed();
        assertEquals("Expect Page 4 button to be displayed", true, bPage4);

        boolean bPage5 = paginationToolBar.page5.isDisplayed();
        assertEquals("Expect Page 5 button to be displayed", true, bPage5);
    }


    public void CreateDataTables(int noOfDataTablesToCreate) {

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData_EXT();

        for (int i = 0; i < noOfDataTablesToCreate; i++) {

            tableDetails.tableName = FunctionsLibrary.FileUtilities.GenerateAppendUIDToString("ta_datatable_", 5);

            API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        }

    }
}