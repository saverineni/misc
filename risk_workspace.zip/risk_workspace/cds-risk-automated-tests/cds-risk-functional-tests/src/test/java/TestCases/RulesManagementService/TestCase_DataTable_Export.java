package TestCases.RulesManagementService;

import API.DataForTests.DataTables;
import API.DataForTests.TestDataTableModel;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.EditDataTableData.EditDataTableResponse;
import API.RulesManagementService.Data.Validate.ValidateDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import API.RulesManagementService.Data.ViewDataTableData.ViewDataTableDataResponse;
import Categories_CDSRisk.CDS_RM_DataTable;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import io.restassured.response.Response;
import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.io.File;
import java.util.List;

import static API.RulesManagementService.Utils.DataTables.*;
import static org.apache.commons.httpclient.HttpStatus.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@Category({Rules_Management.class, CDS_RM_DataTable.class})
public class TestCase_DataTable_Export extends WebAPITestCaseWithDatatablesCleanup {

    private static final String PATH_TO_DOWNLOADED_FILE = FileUtils.getTempDirectoryPath() + File.separator + "testFileName.csv";

    private File downloadedFile;

    @Before
    public void setUp() throws Exception {
        downloadedFile = new File(PATH_TO_DOWNLOADED_FILE);

        if (downloadedFile.exists())
            FileUtils.forceDelete(downloadedFile);
    }

    @Test
    @Category(ChangeRequest.CR_2094.class)
    public void whenDataExportedThenCSVExportedSuccessfully() throws Exception {

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createdDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createdDataTableResponse.uuid;

        EditDataTableResponse.EditDataTableDetailsResponseObject editDataTableDetailsResponseObject = editDataTableDataItems(tableDetails);

        downloadedFile = DownloadCSVFileRequest(tableDetails, PATH_TO_DOWNLOADED_FILE);

        List<String> lines = FileUtils.readLines(downloadedFile);

        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableResponse = GetDataTableDataItems(tableDetails.uuid);

        assertNotNull("Downloaded file name: ", downloadedFile);
        assertEquals("Data Table Items Status: ", SC_OK, editDataTableDetailsResponseObject.httpStatusCode);

        assertThat(lines).hasSize(4)
                .containsOnlyElementsOf(viewDataTableResponse.dataItems);
    }

    @Test
    public void whenDataReImportedThenDataIsReImportedSuccessfully() throws Exception {
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createdDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createdDataTableResponse.uuid;

        EditDataTableResponse.EditDataTableDetailsResponseObject editDataTableDetailsResponseObject = editDataTableDataItems(tableDetails);

        downloadedFile = DownloadCSVFileRequest(tableDetails, PATH_TO_DOWNLOADED_FILE);

        TestDataTableModel.TableDetails tableDetails2 = DataTables.DataTable_NoData();

        CreateDataTableResponse.PostResponse emptyDataTableCreateResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails2);
        tableDetails2.uuid = emptyDataTableCreateResponse.uuid;
        tableDetails2.opLockVersion = emptyDataTableCreateResponse.opLockVersion;

        ValidateDataTableResponse.ValidateDataTableResponseObject validateResponse = ValidateUploadCSVFileRequestResponseObject(tableDetails2, downloadedFile);
        Response uploadCSVFileResponse = UploadCSVFileRequest(tableDetails2, downloadedFile);

        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableResponse = GetDataTableDataItems(tableDetails2.uuid);

        assertEquals("Valid items: ", 4, validateResponse.validCount);
        assertEquals("Invalid items: ", 0, validateResponse.invalidCount);
        assertEquals("Upload file status: ", SC_NO_CONTENT, uploadCSVFileResponse.getStatusCode());
        assertEquals("Data Table Items Status: ", SC_OK, editDataTableDetailsResponseObject.httpStatusCode);

        assertThat(viewDataTableResponse.dataItems)
            .hasSize(4)
            .containsOnlyElementsOf(tableDetails.dataItems);
    }

    //TODO Re-IMPORT previously exported file using special characters e.g. £
    //Currently this feature is not supported


    @Test
    public void whenDataExportedThenDataContentTypeIsCSV() throws Exception {
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createdDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createdDataTableResponse.uuid;

        EditDataTableResponse.EditDataTableDetailsResponseObject editDataTableDetailsResponseObject = editDataTableDataItems(tableDetails);

        Response downloadCSVFileRequestAndGetResponse = DownloadCSVFileRequestAndGetResponse(tableDetails);

        assertEquals("Add data items: ", SC_OK, editDataTableDetailsResponseObject.httpStatusCode);
        assertEquals("Download status: ", SC_OK, downloadCSVFileRequestAndGetResponse.getStatusCode());
        assertEquals("Content Type: ", "text/csv;charset=UTF-8", downloadCSVFileRequestAndGetResponse.contentType());
    }

    @Test
    @Category(ChangeRequest.CR_2094.class)
    public void whenDataExceedsMaxRowsThenCSVNotExported() {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Act
        Response uploadResponse = UploadCSVFileRequest(tableDetails, "uploadValidData64K.csv");

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        tableDetails.dataItemsToAdd.add("1234345678");

        EditDataTableResponse.EditDataTableDetailsResponseObject editDataTableDetailsResponseObject = editDataTableDataItems(tableDetails);

        Response downloadCSVFileRequestAndGetResponse = DownloadCSVFileRequestAndGetResponse(tableDetails);

        assertEquals("Add extra data item: ", SC_OK, editDataTableDetailsResponseObject.httpStatusCode);
        assertEquals("Download CSV status: ", SC_BAD_REQUEST, downloadCSVFileRequestAndGetResponse.getStatusCode());
        assertEquals("Upload Status Code: ", SC_NO_CONTENT, uploadResponse.getStatusCode());
    }

    @Test
    @Category(ChangeRequest.CR_2094.class)
    public void whenDataExportedThenPreviousExportedDataIsOverwritten() throws Exception {
        File existingFile = new File(FileUtils.getTempDirectoryPath() + File.separator + "existingFile.csv");
        FileUtils.write(existingFile, "0982819202", true);

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createdDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createdDataTableResponse.uuid;

        // Add items to data table:
        editDataTableDataItems(tableDetails);

        downloadedFile = DownloadCSVFileRequest(tableDetails, existingFile.getAbsolutePath());

        ViewDataTableDataResponse.ViewDataTableDataResponseObject viewDataTableResponse = GetDataTableDataItems(tableDetails.uuid);

        List<String> lines = FileUtils.readLines(downloadedFile);

        assertThat(lines).hasSize(4)
                .containsOnlyElementsOf(viewDataTableResponse.dataItems);

        FileUtils.forceDelete(existingFile);
    }
}
