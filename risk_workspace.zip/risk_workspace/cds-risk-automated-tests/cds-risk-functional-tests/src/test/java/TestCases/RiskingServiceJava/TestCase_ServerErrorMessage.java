package TestCases.RiskingServiceJava;


import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.Risking_JavaService;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.DeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.GoodsItemDeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.HeaderDeclarationParam;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleCreationModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Category({ChangeRequest_RiskingService.CREP_322.class, Risking_JavaService.class})
public class TestCase_ServerErrorMessage extends BaseRiskingServiceJava{

    @Test
    public void WhenBehaviourNarrativeIsMissingFromRule_ServerErrorIsReturned() {
        RuleCreationModel model = baseRuleCreationModelBuilder().build();
        model.getJson().setBehaviours(new ArrayList<>());
        rulesSupport.createActiveRule(model, appStateSupport.getLoggedInUserPID());
        publishAndWait(5000);

        Map<DeclarationParam, String> declarationFields = new HashMap<>();
        declarationFields.put(HeaderDeclarationParam.DISPATCH_COUNTRY, "DE");

        declarationFields.put(GoodsItemDeclarationParam.SEQUENCE_NUMBER, "2001");
        declarationFields.put(GoodsItemDeclarationParam.Second.SEQUENCE_NUMBER, "2002");
        declarationFields.put(GoodsItemDeclarationParam.Third.SEQUENCE_NUMBER, "2003");
        declarationFields.put(GoodsItemDeclarationParam.Fourth.SEQUENCE_NUMBER, "2004");

        String declarationRequest = declarationSupport.createDeclaration(DECLARATION_TEMPLATE, declarationFields);
        queue.send(declarationRequest);
        DeclarationResponse response = new DeclarationResponse(queue.receive(), true);

        Assertions.assertThat(response.getFaultCode()).isEqualTo("soapenv:Server");
        Assertions.assertThat(response.getFaultString())
                .contains("Unknown Exception: Behaviour of type: DEFAULT not found for rule Id:");
    }
}
