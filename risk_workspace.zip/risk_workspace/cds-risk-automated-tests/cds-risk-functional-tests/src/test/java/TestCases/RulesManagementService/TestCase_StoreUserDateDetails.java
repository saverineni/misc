package TestCases.RulesManagementService;


import API.DataForTests.*;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.RuleAction.RuleActionResponse;
import API.RulesManagementService.ViewRuleVersion.ViewRuleVersionResponse;
import Categories_CDSRisk.CDS_RM_RulesGeneral;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import FunctionsLibrary.DateTime;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import io.restassured.response.Response;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

import static API.RulesManagementService.Utils.RuleAtStatus.ArchiveRule;
import static API.RulesManagementService.Utils.RuleAtStatus.SuspendRule;
import static java.time.temporal.ChronoUnit.SECONDS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_RulesGeneral.class})
public class TestCase_StoreUserDateDetails extends WebAPITestCaseWithDatatablesCleanup {
    private static final int TIMING_TOLERANCE = 30;

    public void assertRuleMetaDataCreateDateTime(TestRuleModel.RuleDetails expRuleDetails, ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse) {

        LocalDateTime dtExpCreatedModifiedTime = LocalDateTime.parse(expRuleDetails.metaData.createdDateTime, DateTimeFormatter.ISO_DATE_TIME);
        LocalDateTime dtActualCreatedDateTime = LocalDateTime.parse(viewRuleVerResponse.metaData.created, DateTimeFormatter.ISO_DATE_TIME);

        assertThat(dtActualCreatedDateTime).isCloseTo(dtExpCreatedModifiedTime, within(TIMING_TOLERANCE, SECONDS));
    }

    @Test
    @Category(ChangeRequest.CR_578.class)
    public void WhenNewRuleCreated_UserDetailsStored() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        //Assert
        assertEquals("User Pid: ", ruleDetails.metaData.User.pid, viewRuleVerResponse.metaData.createdUser.pid);
        assertEquals("User Pid: ", ruleDetails.metaData.User.firstName, viewRuleVerResponse.metaData.createdUser.firstName);
        assertEquals("User Pid: ", ruleDetails.metaData.User.lastName, viewRuleVerResponse.metaData.createdUser.lastName);
        assertEquals("User Pid: ", ruleDetails.metaData.User.hmrcDepartment, viewRuleVerResponse.metaData.createdUser.hmrcDepartment);
        assertEquals("User Pid: ", ruleDetails.metaData.User.location, viewRuleVerResponse.metaData.createdUser.location);
        assertEquals("User Pid: ", ruleDetails.metaData.User.email, viewRuleVerResponse.metaData.createdUser.email);
        assertEquals("User Pid: ", ruleDetails.metaData.User.isRiskUser, viewRuleVerResponse.metaData.createdUser.riskUser);
        assertRuleMetaDataCreateDateTime(ruleDetails, viewRuleVerResponse);
    }


    @Test
    @Category(ChangeRequest.CR_578.class)
    public void WhenRuleEditedByDifferentUser_UserDetailsStored() throws Throwable {

        //Arrange

        //login as 1st User
        TestUserModel.UserDetails udRuleManPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOO.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        TestUserModel.UserDetails udRuleManNAT = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManNAT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManNAT.pid);

        ruleDetails.description = "ta_updated";
        ruleDetails.metaData.User.pid = udRuleManNAT.pid;
        ruleDetails.uniqueID = createRuleResponse.uniqueId;
        Response editResponse = API.RulesManagementService.Utils.Rules.EditRule(ruleDetails);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, 2);

        //Assert
        assertEquals("User Pid: ", ruleDetails.metaData.User.pid, viewRuleVerResponse.metaData.createdUser.pid);
        assertRuleMetaDataCreateDateTime(ruleDetails, viewRuleVerResponse);
    }


    @Test
    @Category({ChangeRequest.CR_578.class, ChangeRequest.CR_1908.class})
    public void WhenDraftRuleCommitted_UserDetailsStored() throws Throwable
    {
        //Arrange
        TestUserModel.UserDetails udRuleManPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOO.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        
        //Act
        TestUserModel.UserDetails udRuleManNAT = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManNAT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManNAT.pid);        
        
        ruleDetails.uniqueID = createRuleResponse.uniqueId;
        API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        //Assert
        assertEquals("User Pid: ", udRuleManPOO.pid, viewRuleVerResponse.metaData.createdUser.pid);
        assertEquals("User Pid: ", udRuleManNAT.pid, viewRuleVerResponse.metaData.updatedUser.pid);

        assertEquals("User Pid: ", udRuleManNAT.firstname, viewRuleVerResponse.metaData.updatedUser.firstName);
        assertEquals("User Pid: ", udRuleManNAT.lastname, viewRuleVerResponse.metaData.updatedUser.lastName);
        assertEquals("User Pid: ", udRuleManNAT.hmrcDepartment, viewRuleVerResponse.metaData.updatedUser.hmrcDepartment);
        assertEquals("User Pid: ", udRuleManNAT.location, viewRuleVerResponse.metaData.updatedUser.location);
        assertEquals("User Pid: ", udRuleManNAT.email, viewRuleVerResponse.metaData.updatedUser.email);
        assertEquals("User Pid: ", udRuleManNAT.isRiskUser, viewRuleVerResponse.metaData.updatedUser.riskUser);
        
        assertRuleMetaDataCreateDateTime(ruleDetails, viewRuleVerResponse);
    }


    @Test
    @Category(ChangeRequest.CR_578.class)
    public void WhenLiveRuleArchived_UserDetailsStored() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse editResponse= API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();

        //Act
        ruleDetails.uniqueID = editResponse.uniqueId;

        RuleActionResponse.PostResponse archiveResponse = ArchiveRule(ruleDetails);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(ruleDetails.uniqueID, ruleDetails.version);

        //Assert
        assertEquals("User Pid: ", ruleDetails.metaData.User.pid, viewRuleVerResponse.metaData.createdUser.pid);
        assertRuleMetaDataCreateDateTime(ruleDetails, viewRuleVerResponse);
    }


    @Test
    @Category(ChangeRequest.CR_578.class)
    public void WhenDraftRuleDeleted_UserDetailsStored() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ruleDetails.uniqueID = createRuleResponse.uniqueId;
        API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.delete);

        //Assert

        String sqlQuery = "select creator_pid " +
                "from rule r " +
                "join rule_version rv" +
                " on (r.id = rv.rule_id)" +
                "where r.uuid = '" + createRuleResponse.uniqueId + "' " +
                "and rv.version = " + createRuleResponse.versionId;

        String actualCreatorPid = ruleJdbcTemplate.queryForObject(sqlQuery, String.class);

        assertEquals("creatorPID:", ruleDetails.metaData.User.pid, actualCreatorPid);
    }


    @Test
    @Category(ChangeRequest.CR_578.class)
    public void WhenPendingRuleCreated_UserDetailsStored() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        String sStartDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(1, DateTime.DateTimeUTCZ);
        ruleDetails.startDateTime = sStartDateTime;
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ruleDetails.uniqueID = createRuleResponse.uniqueId;
        API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(ruleDetails.uniqueID, ruleDetails.version);

        //Assert
        assertEquals("User Pid: ", ruleDetails.metaData.User.pid, viewRuleVerResponse.metaData.createdUser.pid);
        assertRuleMetaDataCreateDateTime(ruleDetails, viewRuleVerResponse);
    }


    @Test
    @Category(ChangeRequest.CR_578.class)
    public void WhenSuspendedRuleReinstated_UserDetailsStored() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ruleDetails.uniqueID = createRuleResponse.uniqueId;
        API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(ruleDetails.uniqueID, ruleDetails.version);

        //Assert
        assertEquals("User Pid: ", ruleDetails.metaData.User.pid, viewRuleVerResponse.metaData.createdUser.pid);
        assertRuleMetaDataCreateDateTime(ruleDetails, viewRuleVerResponse);
    }

    @Test
    @Category(ChangeRequest.CR_578.class)
    public void WhenLiveRuleSuspended_UserDetailsStored() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse editResponse= API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();

        //Act
        ruleDetails.uniqueID = editResponse.uniqueId;
        RuleActionResponse.PostResponse ruleResponse = SuspendRule(ruleDetails);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(ruleDetails.uniqueID, ruleDetails.version);

        //Assert
        assertEquals("User Pid: ", ruleDetails.metaData.User.pid, viewRuleVerResponse.metaData.createdUser.pid);
        assertRuleMetaDataCreateDateTime(ruleDetails, viewRuleVerResponse);
    }


    @Test
    @Category({ChangeRequest.CR_825.class, ChangeRequest.CR_1442.class})
    public void WhenEmptyDataTableSaved_UserDetailsStored() throws Throwable
    {
        //Arrange
        LocalDateTime dtStartOfTest = LocalDateTime.now(ZoneId.of("UTC")).minusSeconds(5);
        TestUserModel.UserDetails userDetails = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        //Act
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;
        ViewDataTableResponse.ViewDataTableResponseObject response = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(tableDetails.uuid);

        //Assert
        assertEquals("createdByPid:", userDetails.pid, response.metaData.createdUser.pid);
        assertEquals("createdByFirstName:", userDetails.firstname, response.metaData.createdUser.firstName);
        assertEquals("createdByLastName:", userDetails.lastname, response.metaData.createdUser.lastName);

        LocalDateTime dtActCreatedDate = LocalDateTime.parse(response.metaData.created, DateTimeFormatter.ISO_DATE_TIME);

        assertThat(dtActCreatedDate).isCloseTo(dtStartOfTest, within(TIMING_TOLERANCE, SECONDS));

        //assertEquals("lastUpdatedByPid:", userDetails.pid, response.metaData.updatedUser.pid);
        assertEquals("lastChangeByFirstName:", userDetails.firstname, response.metaData.updatedUser.firstName);
        assertEquals("lastChangeByLastName:", userDetails.lastname, response.metaData.updatedUser.lastName);

        LocalDateTime dtActLastChangeDate = LocalDateTime.parse(response.metaData.updated, DateTimeFormatter.ISO_DATE_TIME);

        assertThat(dtActLastChangeDate).isCloseTo(dtStartOfTest, within(TIMING_TOLERANCE, SECONDS));
    }


    @Test
    @Category({ChangeRequest.CR_825.class, ChangeRequest.CR_1442.class})
    public void WhenNewDataItemsAddedToDataTableByDifferentUser_UserDetailsStored() throws Throwable {

        //Arrange
        LocalDateTime dtStartOfTest = LocalDateTime.now(ZoneId.of("UTC")).minusSeconds(5);
        TestUserModel.UserDetails userDetails = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();

        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        ViewDataTableResponse.ViewDataTableResponseObject viewDetailResponse1 = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(tableDetails.uuid);
        tableDetails.opLockVersion = viewDetailResponse1.opLockVersion;

        //Act
        TestUserModel.UserDetails udRuleManager = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManager.pid);

        LocalDateTime dtAmendTest = LocalDateTime.now(ZoneId.of("UTC")).minusSeconds(5);

        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject viewDetailResponse2 = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(tableDetails.uuid);

        //Assert
        assertEquals("createdByPid:", userDetails.pid, viewDetailResponse1.metaData.createdUser.pid);
        assertEquals("createdByFirstName:", userDetails.firstname, viewDetailResponse1.metaData.createdUser.firstName);
        assertEquals("createdByLastName:", userDetails.lastname, viewDetailResponse1.metaData.createdUser.lastName);

        LocalDateTime dtActCreatedDate = LocalDateTime.parse(viewDetailResponse1.metaData.created, DateTimeFormatter.ISO_DATE_TIME);

        assertThat(dtActCreatedDate).isCloseTo(dtActCreatedDate, within(TIMING_TOLERANCE, SECONDS));

        assertEquals("lastUpdatedByPid creator: ", userDetails.pid, viewDetailResponse1.metaData.updatedUser.pid);
        assertEquals("lastUpdatedByPid editor: ", udRuleManager.pid, viewDetailResponse2.metaData.updatedUser.pid);

        LocalDateTime dtActLastChangeDate = LocalDateTime.parse(viewDetailResponse2.metaData.updated, DateTimeFormatter.ISO_DATE_TIME);


        assertThat(dtActLastChangeDate).isCloseTo(dtStartOfTest, within(TIMING_TOLERANCE, SECONDS));
    }

}

