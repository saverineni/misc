package TestCases.RulesManagementService;

import API.DataForTests.Conditions;
import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import Categories_CDSRisk.CDS_RM_RulesGeneral;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import org.apache.http.HttpStatus;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_RulesGeneral.class})
public class TestCase_RuleWithComplexGroups  extends BaseWebAPITestCase {

    @Test
    @Category({ChangeRequest.CR_1637.class})
    public void WhenDraftRuleWithMultiLevelOrIsCommitted_CommittedRuleCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.clear();

        TestRuleModel.RuleDetails.QueryConditions queryConditions = new TestRuleModel.RuleDetails.QueryConditions();
        queryConditions.operator = "or";



        TestRuleModel.RuleDetails.Condition dispatchCountryHeader = Conditions.dispatchCountry();
        dispatchCountryHeader.value = "DE";
        TestRuleModel.RuleDetails.Condition dispatchCountryItem = Conditions.dispatchCountry_Item();
        dispatchCountryItem.value = "GB";

        queryConditions.conditions.add(dispatchCountryHeader);
        queryConditions.conditions.add(dispatchCountryItem);

        ruleDetails.queryConditions.add(queryConditions);



        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
    }
}
