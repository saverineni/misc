package TestCases.UI.Rules;


import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.EditRule.EditRuleResponse;
import Categories_CDSRisk.*;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.Pages.RulesManagement.CreateNationalRule_Page;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_1.class})
public class TestCase_CreateNewDraftRule extends BaseUIWebDriverTestCase {

    @Category(SmokeTests_UI.class)
    @Test
    public void WhenRuleManagerLoggedIn_CanCreateNewDraftVersion()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse ruleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.description = ruleResponse.description;

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        boolean bAmend = ruleSummary_page.amend.isEnabled();
        assertEquals("Expect amend button to be enabled", true, bAmend);

        ruleSummary_page.amend.click();

        CreateNationalRule_Page createNationalRule_page = new CreateNationalRule_Page(driver);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetailsV2 = UI.DataForTests.Rules.DraftNATRuleVersion2();
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalRuleSingleCondition(ruleDetailsV2);

        createNationalRule_page.clickSaveAndCommitWithDefaultReason();
        ruleSummary_page.waitForAngularRequestsToFinish();

        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        assertEquals("Expect Rule Status to be Committed", "Committed", listRuleSummaryTableObjects.get(0).status);
        assertEquals("Expect Rule Version to be 2", 2, listRuleSummaryTableObjects.get(0).version);
        assertEquals("Expect Rule Name to be " + ruleDetailsV2.description, ruleDetailsV2.description, listRuleSummaryTableObjects.get(0).description);

        List<RuleSummary_Page.RuleVersionsTableObject> listRuleVersionsTableObjects = ruleSummary_page.getListOfRuleVersions();
        assertEquals("Expect Rule Version Status to be Draft", "Draft", listRuleVersionsTableObjects.get(1).status);
        assertEquals("Expect Rule Version to be 1", 1, listRuleVersionsTableObjects.get(1).version);

        //TODO IGNORE for now until Bug: CR-1365 is Fixed. When rule is saved, the rule name is capitalized in Rule Version Table
        //assertEquals("Expect Rule Name to be " + ruleDetails.description, ruleDetails.description, listRuleVersionsTableObjects.get(0).name);
    }


    @Category(ChangeRequest.CR_1149.class)
    @Test
    public void WhenRuleWithOneVersionViewed_VersionHistoryTabIsNOTDisplayed()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse ruleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.description = ruleResponse.description;

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Assert
        boolean bVersionTab = ruleSummary_page.isElementDisplayed(ruleSummary_page.ruleVersionsTab,1,false);
        assertEquals("Expect Rule Versions Tab to be NOT present", false, bVersionTab);
    }


    @Category(ChangeRequest.CR_1149.class)
    @Test
    public void WhenRuleWithTwoVersionsViewed_VersionHistoryTabIsDisplayed()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateDraftRuleVersion2Rule();
        ruleDetails.description = ruleResponse.description;

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Assert
        boolean bVersionTab = ruleSummary_page.isElementDisplayed(ruleSummary_page.ruleVersionsTab);
        assertEquals("Expect Rule Versions Tab to be present", true, bVersionTab);

        List<RuleSummary_Page.RuleVersionsTableObject> listRuleVersionsTableObjects = ruleSummary_page.getListOfRuleVersions();
        assertEquals("Expect Rule Version Status to be Draft", "Draft", listRuleVersionsTableObjects.get(1).status);
        assertEquals("Expect Rule Version to be 1", 1, listRuleVersionsTableObjects.get(1).version);
    }

}
