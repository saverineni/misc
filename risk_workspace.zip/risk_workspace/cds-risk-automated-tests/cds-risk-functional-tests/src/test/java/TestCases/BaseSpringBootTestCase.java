package TestCases;

import API.DataForTests.DataTables;
import API.DataForTests.DataTypes;
import API.EnvDetails.EnvDetails;
import API.UserService.Utils.User;
import FunctionsLibrary.MySQL_CDS_Publishing;
import FunctionsLibrary.MySQL_CDS_Rules;
import app.config.ApplicationConfiguration;
import app.config.TestConfig;
import app.helpers.AppStateSupport;
import app.helpers.DataServiceSupport;
import app.helpers.ModelSupport;
import app.helpers.QueueAccessor;
import junit.framework.TestResult;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.rules.TestName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.rules.SpringClassRule;
import org.springframework.test.context.junit4.rules.SpringMethodRule;
import uk.gov.hmrc.risk.rulesengine.publishing.PublishEventFullDto;
import uk.gov.hmrc.risk.test.common.service.AssigneeServiceSupport;
import uk.gov.hmrc.risk.test.common.service.CacheLoaderSupport;
import uk.gov.hmrc.risk.test.common.service.DARServiceSupport;
import uk.gov.hmrc.risk.test.common.service.DataTableSupport;
import uk.gov.hmrc.risk.test.common.service.DockerSupport;
import uk.gov.hmrc.risk.test.common.service.PublishSupport;
import uk.gov.hmrc.risk.test.common.service.RiskingServiceSupport;
import uk.gov.hmrc.risk.test.common.service.RulesManagementServiceSupport;
import uk.gov.hmrc.risk.test.common.service.RulesSupport;
import uk.gov.hmrc.risk.test.common.service.declarationSupport.DeclarationSupport;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.PrivateKey;

@Slf4j
@SpringBootTest(classes = TestConfig.class)
@ContextConfiguration
@EnableConfigurationProperties
//When adding environment profile, leave wmq-for-risking
//@ActiveProfiles({"wmq-for-risking"})  //user-waheed, qa-fastp, dev2-fastp, pre-dev, pre-dev2, user-mark
public class BaseSpringBootTestCase {

    // These rules are required to combine spring boot functionality with other test runners
    @ClassRule
    public static final SpringClassRule SclearCR = new SpringClassRule();
    @Rule
    public final SpringMethodRule springMethodRule = new SpringMethodRule();

    @Autowired
    protected AppStateSupport appStateSupport;
    @Autowired
    protected RulesSupport rulesSupport;
    @Autowired
    protected QueueAccessor queue;
    @Autowired
    protected ApplicationConfiguration testConfig;
    @Autowired
    protected DataServiceSupport dataServiceSupport;
    @Autowired
    protected PublishSupport publishSupport;
//    @Autowired
//    protected RiskingPublishSupport riskingPublishSupport;
    @Autowired
    protected CacheLoaderSupport cacheLoaderSupport;
    @Autowired
    protected DockerSupport dockerSupport;
    @Autowired
    protected DataTableSupport dataTableSupport;
    @Autowired
    protected RiskingServiceSupport riskingServiceSupport;
    @Autowired
    protected DARServiceSupport darServiceAuditSupport;
    @Autowired
    protected DARServiceSupport darServicePublishingSupport;
    @Autowired
    protected DeclarationSupport declarationSupport;
    @Autowired
    protected RulesManagementServiceSupport rulesManagementServiceSupport;
    @Autowired
    protected ModelSupport modelSupport;
    @Autowired
    protected AssigneeServiceSupport assigneeServiceSupport;

    @Autowired
    protected MySQL_CDS_Publishing mySQL_cds_publishing;
    @Autowired
    protected MySQL_CDS_Rules mySQL_cds_rules;
    @Autowired
    protected DataTypes dataTypesUtils;
    @Autowired
    protected User userUtils;
    @Autowired
    protected DataTables dataTablesUtils;

    @Autowired
    protected Environment springEnvironment;

    @Rule
    public TestName testName = new TestName();
    public TestResult testResult = new TestResult();

    //Remove when CR-3387 is resolved
    private static Boolean publishInitialized = false;

    @Before
    public void CommonSetup() throws Throwable {
        log.info("-----BaseSpringBootTestCase-------------------" + "\r\n");
        String className = this.getClass().getSimpleName();
        String methodName = this.testName.getMethodName();

        EnvDetails.loadFromConfig(testConfig);

        //this initial publish check is needed to work around a defect in the risking service that causes
        //the first rule published (if there have been no previous publish events) to fail (CR-3387)
        if (publishInitialized == false) {
            int publishHistory = publishSupport.findPublishHistory().size();

            if (!(publishHistory > 0)) {
                log.info("Performing initial publish to initialize risking service");
                publishAndWait();
            }

            publishInitialized = true;
        }

        log.info("------End of BaseSpringBootTestCase Setup-----");
        log.info("");
        log.info("\r\n#### Start of Test: " + className + "." + methodName + "####");
        log.info("");


            publishInitialized = true;


        log.info("------End of BaseSpringBootTestCase Setup-----");
        log.info("");
        log.info("\r\n#### Start of Test: " + className + "." + methodName + "####");
        log.info("");
    }

    public PublishEventFullDto publishAndWait() {
        return publishAndWait(10000);
    }

    public PublishEventFullDto publishAndWait(int timeout) {
        return publishAndWait(timeout, "Default test reason", "1234560");
    }

    public PublishEventFullDto publishAndWait(int timeout, String reason, String userPid) {
        String oldVersion = riskingServiceSupport.getLatestPackageVersion();
        PublishEventFullDto publishId = publishSupport.sendPublishRequest(reason, userPid);
        riskingServiceSupport.waitForPackageVersionChange(timeout, oldVersion);
        log.info("publish "+publishId+" has been completed. was "
                + oldVersion + " and now is "
                + riskingServiceSupport.getLatestPackageVersion());
        return publishId;
    }

    @SneakyThrows
    public String decryptField(String encryptedValue) {
        if (StringUtils.isEmpty(encryptedValue) || !encryptedValue.contains(":")) {
            log.info("'{}' does not appear to be encrypted", encryptedValue);
            return encryptedValue;
        }

        PrivateKey privateKey = riskingServiceSupport.getPrivateKey();


        String[] split = encryptedValue.split(":");
        String key = split[0];
        String data = split[1];

        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        String keyAndIv = new String(cipher.doFinal(Base64.decodeBase64(key.getBytes("UTF-8"))), "UTF-8");

        split = keyAndIv.split(":");
        String symmetricKey = split[0];
        String iv = split[1];

        SecretKeySpec symKey = new SecretKeySpec(Base64.decodeBase64(symmetricKey), "AES");
        byte[] ivArray = Base64.decodeBase64(iv);
        Cipher symCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        symCipher.init(Cipher.DECRYPT_MODE, symKey, new IvParameterSpec(ivArray));

        return new String(symCipher.doFinal(Base64.decodeBase64(data)));
    }
}
