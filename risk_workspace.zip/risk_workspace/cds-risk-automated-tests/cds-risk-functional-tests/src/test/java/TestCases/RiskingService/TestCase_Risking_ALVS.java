package TestCases.RiskingService;


import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service;
import TestCases.BaseWebAPITestCase;
import junitparams.JUnitParamsRunner;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
@Category(Risking_Service.class)
@RunWith(JUnitParamsRunner.class)
public class TestCase_Risking_ALVS extends BaseWebAPITestCase {

    @Before
    public void setup() throws IOException, TimeoutException {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
    }

    @Test
    @Category({ChangeRequest.CR_3383.class,ChangeRequest.CR_3386.class})
    public void WhenDeclarationSubmittedForALVSActionType_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = "7";
        ruleDetails.ruleOutputs.alvsCheckCode = "checkcode";
        ruleDetails.ruleOutputs.alvsDepartmentCode = "deptcode";
        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());
        modelSupport.checkDeclarationFieldValue(declarationRequest, "dispatchCountry",
                declaration.dispatchCountry);
        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(TestEnumerators.RuleOutputs.ALVS.controlType);
        assertThat(declarationResponse.getControlAgent()).isEqualTo("ALVS");
        assertThat(declarationResponse.getIsTimed().get(0)).isEqualTo(true);
        assertThat(declarationResponse.getIsSelfClosing().get(0)).isEqualTo(false);
        assertThat(declarationResponse.getIsSecret().get(0)).isEqualTo(false);
        assertThat(declarationResponse.getAlvsCheckCode()).isEqualTo(ruleDetails.ruleOutputs.alvsCheckCode);
        assertThat(declarationResponse.getAlvsDepartmentCode()).isEqualTo(ruleDetails.ruleOutputs.alvsDepartmentCode);
        assertThat(declarationResponse.getNarrativeText()).isEmpty();
        assertThat(declarationResponse.getWorkBasket()).isEmpty();


    }
}

