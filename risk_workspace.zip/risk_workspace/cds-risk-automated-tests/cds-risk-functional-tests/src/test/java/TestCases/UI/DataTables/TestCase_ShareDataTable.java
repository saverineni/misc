package TestCases.UI.DataTables;


import API.DataForTests.*;
import API.DataService.CreateDataTable.CreateDataTableResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_DataTables;
import Categories_CDSRisk.CDS_Risk_UI_DataTables_2;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.DataForTests.TestDataTableModel;
import UI.Pages.DataManagement.CreateDataTable_Page;
import UI.Pages.DataManagement.DataTableManage_Page;
import UI.Pages.DataManagement.DataTableSummary_Page;
import UI.Pages.DataManagement.ListDataTable_Page;
import UI.Pages.RulesManagement.CreateLocalRule_Page;
import UI.Utils.Navigation;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static API.Utils.LoginAsAPIUserAndCreateDataTableForLocation;
import static UI.DataForTests.TestDataTableModel.TableDetails.FreightTypeCategories.*;
import static UI.Utils.DataTables.NavigateToListMyDataTablesAndGetListOfDataTablesTitles;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_DataTables.class, CDS_Risk_UI_DataTables_2.class})
public class TestCase_ShareDataTable extends BaseUIWebDriverTestCase {

    @Category({ChangeRequest.CR_2109.class, ChangeRequest.CR_2226.class,ChangeRequest.CR_3063.class})
    @Test
    public void WhenRuleManagerLoggedIn_CanShareRestrictedDataTableForOwnershipWithLocations(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateDataTable_Page createDataTable_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        TestDataTableModel.TableDetails tableDetails = UI.DataForTests.DataTables.DataTable_CommodityCodes_POO();
        tableDetails.tableType = "Restricted";

        createDataTable_page.populateDataTableFields(tableDetails);

        createDataTable_page.clickSaveAndPublishButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing1");

        DataTableSummary_Page dataTableSummary_page = createDataTable_page.clickViewDataTableButton();

        //Act
        dataTableSummary_page.accessTab.click();

        DataTableManage_Page manage_page = new DataTableManage_Page(driver);
        manage_page.clickManageOwnersButton();

        // map contains all freight types and their possible locations:
        Map<TestDataTableModel.TableDetails.FreightTypeCategories, List<String>> locationsAndCategoryMap = new HashMap<>();
        locationsAndCategoryMap.put(MARITIME, Lists.newArrayList("WAT"));

        manage_page.SearchForFreightLocationAndSelectIt(locationsAndCategoryMap);

        manage_page.clickSaveAndShareForOwn();
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing2");

        //Assert
        Assertions.assertThat(dataTableSummary_page.manageOwnersLocationsTab.size() == 2);
        Assertions.assertThat(dataTableSummary_page.manageOwnersLocationsTab.get(0).getText().contains("WAT - Watchet"));
        Assertions.assertThat(dataTableSummary_page.manageOwnersLocationsTab.get(1).getText().contains("POO - Poole"));
    }


    @Category({ChangeRequest.CR_2148.class, ChangeRequest.CR_2226.class,ChangeRequest.CR_3063.class})
    @Test
    public void WhenRuleManagerLoggedIn_CanShareSensitiveDataTableForUsageWithLocations(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateDataTable_Page createDataTable_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        TestDataTableModel.TableDetails tableDetails = UI.DataForTests.DataTables.DataTable_CommodityCodes_POO();
        tableDetails.tableType = "Sensitive";

        createDataTable_page.populateDataTableFields(tableDetails);

        createDataTable_page.clickSaveAndPublishButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing1");

        DataTableSummary_Page dataTableSummary_page = createDataTable_page.clickViewDataTableButton();

        //Act
        dataTableSummary_page.accessTab.click();

        DataTableManage_Page manage_page = new DataTableManage_Page(driver);
        manage_page.clickManageUseLocationsButton();

        Map<TestDataTableModel.TableDetails.FreightTypeCategories, List<String>> freightTypeCategoriesListMap =
                new ImmutableMap.Builder<TestDataTableModel.TableDetails.FreightTypeCategories, List<String>>()
                        .put(NATIONAL, Lists.newArrayList("National Office"))
                        .put(MARITIME, Lists.newArrayList("WAT", "MNC"))
                        .put(AIR, Lists.newArrayList("Cambridge"))
                        .build();

        manage_page.SearchForFreightLocationAndSelectIt(freightTypeCategoriesListMap);

        manage_page.clickSaveAndShareForUse();
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing2");

        //Assert
        Assertions.assertThat(dataTableSummary_page.manageUserLocationsTab.size() == 3);
        Assertions.assertThat(dataTableSummary_page.manageUserLocationsTab.get(0).getText().contains("CBG - Cambridge Airport"));
        Assertions.assertThat(dataTableSummary_page.manageUserLocationsTab.get(1).getText().contains("WAT - Watchet"));
        Assertions.assertThat(dataTableSummary_page.manageUserLocationsTab.get(2).getText().contains("National Office"));
    }


    @Category({ChangeRequest.CR_2109.class, ChangeRequest.CR_2226.class,ChangeRequest.CR_2487.class,ChangeRequest.CR_3063.class})
    @Test
    public void WhenRuleManagerLoggedIn_CanShareRestrictedDataTableForUsageWithAllLocations(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateDataTable_Page createDataTable_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        TestDataTableModel.TableDetails tableDetails = UI.DataForTests.DataTables.DataTable_CommodityCodes_POO();
        tableDetails.tableType = "Restricted";

        createDataTable_page.populateDataTableFields(tableDetails);

        createDataTable_page.clickSaveAndPublishButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing1");

        DataTableSummary_Page dataTableSummary_page = createDataTable_page.clickViewDataTableButton();

        //Act
        dataTableSummary_page.accessTab.click();
        DataTableManage_Page manage_page = new DataTableManage_Page(driver);
        manage_page.clickManageUseLocationsButton();

        Map<TestDataTableModel.TableDetails.FreightTypeCategories, List<String>> freightTypeCategoriesListMap =
                new ImmutableMap.Builder<TestDataTableModel.TableDetails.FreightTypeCategories, List<String>>()
                        .put(NATIONAL, Lists.newArrayList("All Locations"))
                        .put(AIR, Lists.newArrayList("Cambridge"))
                        .build();

        manage_page.SearchForFreightLocationAndSelectIt(freightTypeCategoriesListMap);

        manage_page.clickSaveAndShareForUse();
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing2");

        Assertions.assertThat(dataTableSummary_page.manageUserLocationsTab.size() == 1);
        Assertions.assertThat(dataTableSummary_page.manageUserLocationsTab.get(0).getText().contains("All Locations"));

    }


    @Category({ChangeRequest.CR_2135.class, ChangeRequest.CR_2226.class,ChangeRequest.CR_2487.class,ChangeRequest.CR_3063.class})
    @Test
    public void WhenRuleManagerLoggedIn_CanShareOpenDataTableForOwnershipWithAllLocations(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateDataTable_Page createDataTable_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        TestDataTableModel.TableDetails tableDetails = UI.DataForTests.DataTables.DataTable_CommodityCodes_POO();
        tableDetails.tableType = "Open";

        createDataTable_page.populateDataTableFields(tableDetails);

        createDataTable_page.clickSaveAndPublishButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing1");

        DataTableSummary_Page dataTableSummary_page = createDataTable_page.clickViewDataTableButton();

        //Act
        dataTableSummary_page.accessTab.click();
        DataTableManage_Page manage_page = new DataTableManage_Page(driver);
        manage_page.clickManageOwnersButton();

        Map<TestDataTableModel.TableDetails.FreightTypeCategories, List<String>> freightTypeCategoriesListMap =
                new ImmutableMap.Builder<TestDataTableModel.TableDetails.FreightTypeCategories, List<String>>()
                        .put(NATIONAL, Lists.newArrayList("All Locations"))
                        .build();

        manage_page.SearchForFreightLocationAndSelectIt(freightTypeCategoriesListMap);
        manage_page.clickSaveAndShareForUse();
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        List<String> ownLocationsList = dataTableSummary_page.getListOfManageOwnerLocations();
        List<String> useLocationsList = dataTableSummary_page.getListOfManageUserLocations();


        //Assert
        Assertions.assertThat(dataTableSummary_page.manageOwnersLocationsTab.get(1).getText().contains("POO - Poole"));
        Assertions.assertThat(dataTableSummary_page.manageUserLocationsTab.get(0).getText().contains("All Locations"));

    }

    @Category({ChangeRequest.CR_2226.class,ChangeRequest.CR_3063.class})
    @Test
    public void WhenRuleManagerLoggedIn_CanFilterShareLocationsByPartialMatchAndShareIt(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateDataTable_Page createDataTable_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        TestDataTableModel.TableDetails tableDetails = UI.DataForTests.DataTables.DataTable_CommodityCodes_POO();
        tableDetails.tableType = "Restricted";

        createDataTable_page.populateDataTableFields(tableDetails);
        createDataTable_page.clickSaveAndPublishButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing1");

        DataTableSummary_Page dataTableSummary_page = createDataTable_page.clickViewDataTableButton();

        //Act
        dataTableSummary_page.accessTab.click();
        DataTableManage_Page manage_page = new DataTableManage_Page(driver);
        manage_page.clickManageOwnersButton();

        manage_page.addLocationDropDown.click();
        manage_page.searchFreightLocationFilter.sendKeys("man");

        //assert
        manage_page.airTab.click();
        assertTrue("Filtered list is not correct", manage_page.airTab.getText().contains("3"));
        manage_page.maritimeTab.click();
        assertTrue("Filtered list is not correct", manage_page.locationsDropDownList.size()==1);
        assertEquals(manage_page.locationsDropDownList.get(0).getText(), "MNC - Manchester");
        manage_page.nationalTab.click();
        assertTrue("Filtered list is not correct", manage_page.locationsDropDownList.size()==0);
    }

    @Category({ChangeRequest.CR_2465.class, ChangeRequest.CR_2226.class,ChangeRequest.CR_3063.class})
    @Test
    public void AttemptToShareOpenDataTableForUse_ShareForUseButtonNotDisplayed(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateDataTable_Page createDataTable_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        TestDataTableModel.TableDetails tableDetails = UI.DataForTests.DataTables.DataTable_CommodityCodes_POO();
        tableDetails.tableType = "Open";

        createDataTable_page.populateDataTableFields(tableDetails);

        createDataTable_page.clickSaveAndPublishButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing1");

        DataTableSummary_Page dataTableSummary_page = createDataTable_page.clickViewDataTableButton();
        dataTableSummary_page.accessTab.click();

        //Act
        boolean manageUse = dataTableSummary_page.isElementDisplayed(dataTableSummary_page.manageUseLocationsBtn,1,false);

        //Assert
        assertTrue("Expect Manage Use Locations button to be NOT displayed", manageUse == false);
    }


    @Category({ChangeRequest.CR_1190.class,ChangeRequest.CR_3063.class})
    @Test
    public void WhenDataTableSharedForUseOnly_UserCanNotEditOrShareDataTable(){

        //Arrange
        //Login as User 1 create data table for POO
        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        API.DataForTests.TestDataTableModel.TableDetails tableDetailsPOO = DataTables.DataTable_CommodityCodes_POO();
        tableDetailsPOO.tableType = "Restricted";

        CreateDataTableResponse.PostResponse createDataTableResponse1 = LoginAsAPIUserAndCreateDataTableForLocation(UserDetailsPOO, tableDetailsPOO);

        tableDetailsPOO.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetailsPOO.uuid = createDataTableResponse1.uuid;
        tableDetailsPOO.creationShareType = TestEnumerators.ShareTypes.user.toString();
        tableDetailsPOO.uniqueId = createDataTableResponse1.uniqueId;

        //API.DataService.Utils.DataTables.ShareDataTableWithLocations(tableDetailsPOO);
        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetailsPOO);

        //Act
        TestUserModel.UserDetails UserDetails_EXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_EXT);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_EXT);

        NavigateToListMyDataTablesAndGetListOfDataTablesTitles(driver, "User");

        ListDataTable_Page listDataTable_page = new ListDataTable_Page(driver);

        DataTableSummary_Page dataTableSummary_page = listDataTable_page.clickTableSummaryForSpecifiedDataTableID(tableDetailsPOO.uniqueId);

        //Assert
        boolean manageOwners = dataTableSummary_page.isElementDisplayed(dataTableSummary_page.manageOwnersBtn,1,false);
        boolean manageUse = dataTableSummary_page.isElementDisplayed(dataTableSummary_page.manageUseLocationsBtn,1,false);
        //If the user has no manage permissions ManageTab does not appear
        assertTrue("Expect Manage Owners button to be NOT displayed", manageOwners == false);
        assertTrue("Expect Manage Owners button to be NOT displayed", manageUse == false);
    }

    @Category({ChangeRequest.CR_1190.class,ChangeRequest.CR_3063.class})
    @Test
    public void WhenRestrictedDataTableSharedForManage_UserCanEditOrShareDataTable(){

        //Arrange
        //Login as User 1 create data table for POO
        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        API.DataForTests.TestDataTableModel.TableDetails tableDetailsPOO = DataTables.DataTable_CommodityCodes_POO();
        tableDetailsPOO.tableType = "Restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse1 = LoginAsAPIUserAndCreateDataTableForLocation(UserDetailsPOO, tableDetailsPOO);

        tableDetailsPOO.manageTableLocationUuids.add(Locations.Location_EXT_UID);
        tableDetailsPOO.uuid = createDataTableResponse1.uuid;
        tableDetailsPOO.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        tableDetailsPOO.uniqueId = createDataTableResponse1.uniqueId;

        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetailsPOO);

        //Act
        TestUserModel.UserDetails UserDetails_EXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_EXT);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_EXT);

        NavigateToListMyDataTablesAndGetListOfDataTablesTitles(driver, "Owner");

        ListDataTable_Page listDataTable_page = new ListDataTable_Page(driver);

        DataTableSummary_Page dataTableSummary_page = listDataTable_page.clickTableSummaryForSpecifiedDataTableID(tableDetailsPOO.uniqueId);

        //Assert
        dataTableSummary_page.accessTab.click();
        assertTrue("Update data table button should be enabled and displayed", dataTableSummary_page.manageOwnersBtn.isEnabled());

        dataTableSummary_page.dataTab.click();
        assertTrue("Update data table button should be enabled and displayed", dataTableSummary_page.editData.isEnabled());
    }

    @Category(ChangeRequest.CR_1567.class)
    @Test
    public void WhenSearchedByDataTableTags_DataTablesShouldbeShownCorrectlyInRuleCreation(){

        //Arrange
        List<String> dataTableTags = new ArrayList<>();
        dataTableTags.add("Flammable");
        dataTableTags.add("Restricted");

        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        //Create datable for FreeText POO
        API.DataForTests.TestDataTableModel.TableDetails tableDetailsFreeText = DataTables.DataTable_FreeText_Valid_Poo();
        tableDetailsFreeText.tableType = "Restricted";
        tableDetailsFreeText.userBaseLocation = "POO";
        tableDetailsFreeText.manageTableLocationUuids.add(Locations.Location_POO_UID);
        tableDetailsFreeText.tags=dataTableTags;

        //Create datable for Eori Poo
        API.DataForTests.TestDataTableModel.TableDetails tableDetailsEori = DataTables.DataTable_EORI_Valid_Poo();
        tableDetailsEori.tableType = "Restricted";
        tableDetailsEori.tags=dataTableTags;

        //Create datable for Eori National
        API.DataForTests.TestDataTableModel.TableDetails tableDetailsNational = DataTables.DataTable_EORI_Valid();
        tableDetailsNational.tableType = "Restricted";
        tableDetailsNational.tags=dataTableTags;

        //Create datable for Country code Poo
        API.DataForTests.TestDataTableModel.TableDetails tableDetailsCountry = DataTables.DataTable_CountryCode_Valid_Poo();
        tableDetailsCountry.tableType = "Restricted";
        tableDetailsCountry.tags=dataTableTags;

        //Create Datatable and share it with EXT
        CreateDataTableResponse.PostResponse createDataTableResponse = LoginAsAPIUserAndCreateDataTableForLocation(UserDetailsPOO, tableDetailsFreeText);
        tableDetailsFreeText.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetailsFreeText.uuid = createDataTableResponse.uuid;
        tableDetailsFreeText.creationShareType = TestEnumerators.ShareTypes.user.toString();
        tableDetailsFreeText.uniqueId = createDataTableResponse.uniqueId;

        //Create Datatable and share it with EXT
        createDataTableResponse = LoginAsAPIUserAndCreateDataTableForLocation(UserDetailsPOO, tableDetailsEori);
        tableDetailsEori.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetailsEori.uuid = createDataTableResponse.uuid;
        tableDetailsEori.creationShareType = TestEnumerators.ShareTypes.user.toString();
        tableDetailsEori.uniqueId = createDataTableResponse.uniqueId;

        //Create Datatable and share it with EXT
        createDataTableResponse = LoginAsAPIUserAndCreateDataTableForLocation(UserDetailsPOO, tableDetailsCountry);
        tableDetailsCountry.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetailsCountry.uuid = createDataTableResponse.uuid;
        tableDetailsCountry.creationShareType = TestEnumerators.ShareTypes.user.toString();
        tableDetailsCountry.uniqueId = createDataTableResponse.uniqueId;

        createDataTableResponse = LoginAsAPIUserAndCreateDataTableForLocation(UserDetailsPOO, tableDetailsNational);

        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetailsFreeText);
        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetailsEori);
        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetailsCountry);


        //Act
        TestUserModel.UserDetails UserDetails_EXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_EXT);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_EXT);

        Navigation utilNavigation = new Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        String attributeToSelect = "Consignee EORI (Header)";
        createLocalRule_page.SearchForAttributeAndSelectIt(attributeToSelect, UI.DataForTests.TestRuleModel.RuleDetails.Condition.AttributeType.HEADER);
        UI.ElementControls.DropDown dropDown = new UI.ElementControls.DropDown(driver);
        dropDown.select(createLocalRule_page.conditionOperator, "Equal");
        List<String> dataTablesInDropDownForEori = searchForTagsAndGetThePopulatedDataTables(createLocalRule_page);

        attributeToSelect = "Dispatch Country (Header)";
        createLocalRule_page.SearchForAttributeAndSelectIt(attributeToSelect, UI.DataForTests.TestRuleModel.RuleDetails.Condition.AttributeType.HEADER);
        dropDown = new UI.ElementControls.DropDown(driver);
        dropDown.select(createLocalRule_page.conditionOperator, "Equal");
        List<String> dataTablesInDropDownForCountry = searchForTagsAndGetThePopulatedDataTables(createLocalRule_page);


        Assertions.assertThat(dataTablesInDropDownForEori)
                .hasSize(1)
                .containsOnly(tableDetailsEori.tableName);

        Assertions.assertThat(dataTablesInDropDownForCountry)
                .hasSize(1)
                .containsOnly(tableDetailsCountry.tableName);
    }

    private List<String> searchForTagsAndGetThePopulatedDataTables(CreateLocalRule_Page createLocalRule_page) {
        UI.ElementControls.CheckBox checkBox = new UI.ElementControls.CheckBox((driver));
        checkBox.check(createLocalRule_page.selectDataTable);
        createLocalRule_page.selectDataTableFromList.click();
        createLocalRule_page.searchDataTableDropdown.sendKeys("res");
        return (List<String>) createLocalRule_page.getListOfDataTables(createLocalRule_page.selectDataTableFromList);
    }


}
