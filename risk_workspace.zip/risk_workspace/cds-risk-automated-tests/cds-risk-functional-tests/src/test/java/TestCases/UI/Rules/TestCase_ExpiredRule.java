package TestCases.UI.Rules;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Rules;
import Categories_CDSRisk.CDS_Risk_UI_Rules_2;
import Categories_CDSRisk.ChangeRequest;
import FunctionsLibrary.DateTime;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.Pages.RulesManagement.CreateQuickNationalRule_Page;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.time.ZoneId;
import java.util.List;

import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class})
public class TestCase_ExpiredRule extends BaseUIWebDriverTestCase{

    @Category({ChangeRequest.CR_1882.class, CDS_Risk_UI_Rules_2.class,ChangeRequest.CR_2350.class})
    @Test
    public void WhenRuleManagerSavesAndCommitsRuleWithEndDateWhichExpiresInOneMinute_RuleShouldBeExpiredAndCanBeArchived() throws Throwable {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        //Create a rule with end time 2 minutes from now, so the rule will expire
        Navigation utilNavigation = new Navigation(driver);
        CreateQuickNationalRule_Page createQuickNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickNationalRule);
        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftQuickNATRule();
        ruleDetails.endDate = DateTime.AdjustLocalDateTimeNowByXDays(0);
        ruleDetails.endTime = DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.systemDefault(), 2, "HH:mm");
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalQuickRule(ruleDetails);
        createQuickNationalRule_page.clickSaveAndCommitButtonWithDefaultReason();
        createQuickNationalRule_page.waitForAngularRequestsToFinish();

        //Wait for the rule to be expired and check suspend and amend buttons are not displayed
        utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);
        publishAndWait(5000);
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);
        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);
        ruleSummary_page.RefreshRuleSummaryPageEverySeconds(10, 180, "Expired");
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetailsForExpiredRule();
        String actStatus = listRuleSummaryTableObjects.get(0).status;
        assertEquals("Expect Status: Expired", "Expired", actStatus);
        assertEquals("Expect suspend button not to be displayed", false, ruleSummary_page.isElementDisplayed(ruleSummary_page.suspendRule));
        assertEquals("Expect amend button not to be displayed", false, ruleSummary_page.isElementDisplayed(ruleSummary_page.amend));
        assertEquals("Expect archived button to be enabled", true, ruleSummary_page.archiveRule.isEnabled());

        //Archive the rule
        Dialog_Confirm dialog_confirm = ruleSummary_page.clickArchiveButton();
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");
        dialog_confirm.waitForAngularRequestsToFinish();
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);
        ruleSummary_page.waitForAngularRequestsToFinish();
        publishAndWait(5000);
        ruleSummary_page.refreshPage();

        //Verify the rule is archived
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjectsAfterArchivingRule = ruleSummary_page.getListOfRuleSummaryDetailsForExpiredRule();
        assertEquals(ruleDetails.description, listRuleSummaryTableObjectsAfterArchivingRule.get(0).description);
        assertEquals("Expect Rule Status to be Archived", "Archived", listRuleSummaryTableObjectsAfterArchivingRule.get(0).status);
        assertEquals("View\n" +"Rule Revision 1", listRuleSummaryTableObjectsAfterArchivingRule.get(0).versionDetailAction.getText());
    }
}