package TestCases.UI.Rules;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.*;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.DataForTests.TestRuleModel;
import UI.ElementControls.MultiSelectDropDown;
import UI.Pages.RulesManagement.*;
import UI.Utils.Navigation;
import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_3.class})
@RunWith(JUnitParamsRunner.class)
public class TestCase_CreateQuickLocalRule extends BaseUIWebDriverTestCase{

    @Category(ChangeRequest.CR_1147.class)
    @Test
    public void WhenLocalRuleManagerLoggedIn_CanCreateQuickLocalRuleWithAllStaticConditions(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateQuickLocalRule_Page createQuickLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftQuickLocalRule_POO();

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalQuickRule(ruleDetails);

        createQuickLocalRule_page.clickSaveAndCommitButtonWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }



    @Test
    public void WhenQuickLocalRuleSaved_CorrectViewRuleDetailsDisplayed(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateQuickLocalRule_Page createQuickLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftQuickLocalRuleSingleCondition_POO();

        List<String> goodsLocationList = createQuickLocalRule_page.getGoodsLocationList();

        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalQuickRule(ruleDetails);

        createQuickLocalRule_page.clickSaveAndCommitButtonWithDefaultReason();

        //Act
        RuleSummary_Page ruleSummary_page = createQuickLocalRule_page.clickViewRule();
        List<RuleSummary_Page.RuleSummaryTableObject> ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        ruleSummaryTableObjects.get(0).versionDetailAction.click();

        //Assert
        assertThat(goodsLocationList).doesNotContain("National Office");
        RuleDetails_Page ruleDetails_page = new RuleDetails_Page(driver);

        ruleDetails_page.assertRuleDetailsLocalRule(ruleDetails, userDetailsRM);
    }


    @Category({ChangeRequest.CR_1211.class, ChangeRequest.CR_1235.class})
    @Test
    public void WhenNationalRuleManagerLoggedIn_CanCreateQuickLocalRuleWithOneCondition(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateQuickLocalRule_Page createQuickLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftQuickLocalRuleSingleCondition_POO();

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalQuickRule(ruleDetails);

        createQuickLocalRule_page.clickSaveAndCommitButtonWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }


    @Category(ChangeRequest.CR_1211.class)
    @Test
    public void WhenRuleManagerLoggedIn_CanNOTCommitQuickLocalRuleWithInvalidConditions(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateQuickLocalRule_Page createQuickLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftQuickLocalRule_POO();
        //Set 1st Condition Country Code to invalid code
        ruleDetails.conditionGroups.get(0).conditions.get(0).value = "&&";

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalQuickRule(ruleDetails);

        boolean bEnabled = createQuickLocalRule_page.saveAndCommit.isEnabled();

        //Assert
        assertTrue("Expect Save And Commit button to be disabled", bEnabled == false);
    }


    @Category(ChangeRequest.CR_1213.class)
    @Test
    public void WhenRuleManagerLoggedIn_CanOnlyCreateRuleWithOperatorEqualOrNotEqual(){

        //Arrange

        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateQuickLocalRule_Page createQuickLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickLocalRule);

        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);

        //Act
        List<String> listOfOperators = createQuickLocalRule_page.getListOfOperators(createQuickLocalRule_page.commodityCodeConditionOperator);

        //Assert
        Assertions.assertThat(listOfOperators).containsOnly("Equal", "Not Equal", "Please select a test");
    }

    @Category({ChangeRequest.CR_1866.class})
    @Test
    public void WhenQuickNationalRuleWithDeclarationTypeBothAndNoDeclarationSubTypeCommitted_RuleCommittedSuccessfully(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateQuickLocalRule_Page createQuickLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftQuickLocalRuleSingleCondition_POO();
        ruleDetails.declarationType = UI.DataForTests.TestRuleModel.RuleDetails.DeclarationType.BOTH;
        ruleDetails.declarationSubType = null;

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalQuickRule(ruleDetails);

        createQuickLocalRule_page.clickSaveAndCommitButtonWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }


    @Category(ChangeRequest.CR_1235.class)
    @Test
    @Parameters(method = "mandatoryFieldsTestData")
    public void WhenRuleManagerLoggedIn_CanNOTCommitQuickLocalRuleWithoutMandatoryFields(String testName, TestRuleModel.RuleDetails ruleDetails){

        //Arrange

        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateQuickLocalRule_Page createQuickLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickLocalRule);

        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);

        //Act
        ruleUtils.createLocalQuickRule(ruleDetails);

        //Assert
        boolean bEnabled = createQuickLocalRule_page.saveAndCommit.isEnabled();

        assertTrue("Expect Save And Commit button to be disabled", bEnabled == false);
    }

    @Category(ChangeRequest.CR_1871.class)
    @Test
    @Parameters(method = "mandatoryFieldsTestData")
    public void WhenRuleManagerLoggedIn_DocCheckAndVaryReleaseForQuickLocalRuleIsNotPresent(String testName, TestRuleModel.RuleDetails ruleDetails){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateQuickLocalRule_Page createQuickLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickLocalRule);

        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);

        //Act
        ruleUtils.createLocalQuickRule(ruleDetails);

        //Assert
        assertTrue("", createQuickLocalRule_page.isElementDisplayed(By.xpath("//label[@for='actionType_3']"), 5, false) == false);
    }

    @Category(ChangeRequest.CR_1674.class)
    @Test
    public void WhenRuleManagerCreatesALocalRule_RegimeCodeIsNotDisplayedInRuleDetails(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateQuickLocalRule_Page createQuickLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftQuickLocalRule_POO();

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalQuickRule(ruleDetails);

        createQuickLocalRule_page.clickSaveAndCommitButtonWithDefaultReason();

        //Assert
        RuleSummary_Page ruleSummary_page = createQuickLocalRule_page.clickViewRule();
        ruleSummary_page.view.click();

        RuleDetails_Page ruleDetails_page = new RuleDetails_Page(driver);

        //Assert
        assertTrue("Regime code should not be shown for local rule ", ruleDetails_page.isElementDisplayed(ruleDetails_page.regimeLabel, 2, false)==false);

    }


    @Category(ChangeRequest.CR_1880.class)
    @Test
    public void WhenQuickLocalRuleReasonCancelled_RuleNotCreated(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateQuickLocalRule_Page createQuickLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftQuickLocalRule_POO();

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalQuickRule(ruleDetails);

        createQuickLocalRule_page.clickSaveAndCommitButton();
        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.clickCancelButton();

        //Assert
        assertTrue("Expect Save&Commit button to be Enabled", createQuickLocalRule_page.saveAndCommit.isEnabled());
    }


    private Object[] mandatoryFieldsTestData()
    {
        TestRuleModel.RuleDetails rule1 =  UI.DataForTests.Rules.DraftQuickLocalMandatoryFields_POO();
        rule1.description = "";

        TestRuleModel.RuleDetails rule3 =  UI.DataForTests.Rules.DraftQuickLocalMandatoryFields_POO();
        rule3.declarationType = null;

        TestRuleModel.RuleDetails rule4 =  UI.DataForTests.Rules.DraftQuickLocalMandatoryFields_POO();
        rule4.declarationSubType = null;

        TestRuleModel.RuleDetails rule5 =  UI.DataForTests.Rules.DraftQuickLocalMandatoryFields_POO();
        rule5.goodsLocations.clear();

        TestRuleModel.RuleDetails rule6 =  UI.DataForTests.Rules.DraftQuickLocalMandatoryFields_POO();
        rule6.conditionGroups.get(0).conditions.remove(0);

        TestRuleModel.RuleDetails rule7 =  UI.DataForTests.Rules.DraftQuickLocalMandatoryFields_POO();
        rule7.actionType = null;

        TestRuleModel.RuleDetails rule8 =  UI.DataForTests.Rules.DraftQuickLocalMandatoryFields_POO();
        rule8.startRuleImmediately = false;
        rule8.startTime = "";
        rule8.startDate = "";

        TestRuleModel.RuleDetails rule10 =  UI.DataForTests.Rules.DraftQuickLocalMandatoryFields_POO();
        rule10.endTime = "";
        rule10.endDate = "";

        TestRuleModel.RuleDetails rule12 =  UI.DataForTests.Rules.DraftQuickLocalMandatoryFields_POO();
        rule12.holdNarrative = "";

        TestRuleModel.RuleDetails rule13 =  UI.DataForTests.Rules.DraftQuickLocalMandatoryFields_POO();
        rule13.actionType = TestRuleModel.RuleDetails.ActionType.DocCheckReleaseGoods;
        rule13.releaseNarrative = "";
        rule13.holdNarrative = null;

        /*TestRuleModel.RuleDetails rule15 =  UI.DataForTests.Rules.DraftQuickLocalMandatoryFields_POO();
        rule15.actionType = TestRuleModel.RuleDetails.ActionType.DocCheckVaryReleaseOfGoods;
        rule15.holdPercentage = "";*/

        TestRuleModel.RuleDetails rule14 =  UI.DataForTests.Rules.DraftQuickLocalMandatoryFields_POO();
        rule14.transportMode = null;

        return new Object[]{
                new Object[]{"description", new TestRuleModel.RuleDetails(rule1)},
                new Object[]{"declarationType", new TestRuleModel.RuleDetails(rule3)},
                new Object[]{"declarationSubType", new TestRuleModel.RuleDetails(rule4)},
                new Object[]{"goodsLocation", new TestRuleModel.RuleDetails(rule5)},
                new Object[]{"conditions", new TestRuleModel.RuleDetails(rule6)},
                new Object[]{"actionType", new TestRuleModel.RuleDetails(rule7)},
                new Object[]{"startDateTime", new TestRuleModel.RuleDetails(rule8)},
                new Object[]{"endDateTime", new TestRuleModel.RuleDetails(rule10)},
                new Object[]{"holdNarrative", new TestRuleModel.RuleDetails(rule12)},
                new Object[]{"actionType3", new TestRuleModel.RuleDetails(rule13)},
                //new Object[]{"actionType4", new TestRuleModel.RuleDetails(rule14)}, .... Action type 4 is not applicable to quick rules
                new Object[]{"transportMode", new TestRuleModel.RuleDetails(rule14)}
            };
    }

    @Category(ChangeRequest.CR_2822.class)
    @Test
    public void WhenActionTypeIsSelected_TimeToCloseTaskShouldNotBeAvailable(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateQuickLocalRule_Page createQuickLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickLocalRule);
        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftQuickLocalRule_POO();
        createQuickLocalRule_page.setActionType(ruleDetails.actionType.value);

        CreateLocalRule_Page localRule = new CreateLocalRule_Page(driver);
        boolean selfClosingTaskDisplayed= createQuickLocalRule_page.isElementDisplayed(localRule.timeToCloseCheckBox);
        assertFalse("Self Closing Task should not be visible for Quick Rules",selfClosingTaskDisplayed);
    }

    @Test
    @Category(ChangeRequest.CR_2925.class)
    public void WhenCreatingLocalRule_CanAddAndDeleteTheLocations() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        //Act
        MultiSelectDropDown dropDown = new MultiSelectDropDown(driver);
        createLocalRule_page.scrollToViewTheElement(createLocalRule_page.transportModes);
        createLocalRule_page.selectTransportMode("Air");
        createLocalRule_page.goodsLocationList.click();
        dropDown.searchAndSelectTheValue(createLocalRule_page.goodsLocationList, createLocalRule_page.searchInput, "eDin", "EDI - Edinburgh Airport");
        dropDown.searchAndSelectTheValue(createLocalRule_page.goodsLocationList, createLocalRule_page.searchInput, "BFS", "BFS - Belfast International Airport");
        List<String> selectedLocations = createLocalRule_page.getSelectedGoodsLocations();
        createLocalRule_page.removeLocation.click();
        List<String> locationsAfterRemoveLocations = createLocalRule_page.getSelectedGoodsLocations();
        String selectedLocation = createLocalRule_page.getSelectedGoodsLocation();

        //Assert
        assertThat(selectedLocations).contains
                ("EDI - Edinburgh Airport","BFS - Belfast International Airport");
        assertThat(locationsAfterRemoveLocations).hasSize(1);
        assertThat(selectedLocation).contains
                ("EDI - Edinburgh Airport");

    }

    @Test
    @Category(ChangeRequest.CR_2975.class)
    public void WhenRuleManagerLoggedIn_CanAmendTheFallbackStatus() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateQuickLocalRule_Page createQuickLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftQuickLocalRuleSingleCondition_POO();
        ruleDetails.fallback = true;
        //Act
        //Create a rule with fallback status as true
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);

        ruleUtils.createLocalQuickRule(ruleDetails);
        createQuickLocalRule_page.waitForAngularRequestsToFinish();
        createQuickLocalRule_page.clickSaveAndCommitButtonWithDefaultReason();

        //Should be "true" in rule summary page and then amend the rule
        RuleSummary_Page ruleSummary_page = createQuickLocalRule_page.clickViewRule();
        List<RuleSummary_Page.RuleSummaryTableObject> ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        ruleSummaryTableObjects.get(0).versionDetailAction.click();
        ruleSummary_page.waitForAngularRequestsToFinish();

        String fallback = createQuickLocalRule_page.rulesFallback.getText();
        ruleSummary_page.scrollToViewTheElement(ruleSummary_page.amendInRuleDetail);
        ruleSummary_page.amendInRuleDetail.click();
        ruleSummary_page.waitForAngularRequestsToFinish();

        //Set fallback status to false
        UI.ElementControls.CheckBox checkBox = new UI.ElementControls.CheckBox((driver));
        checkBox.check(createQuickLocalRule_page.fallback);
        createQuickLocalRule_page.clickSaveAndCommitButtonWithDefaultReason();
        createQuickLocalRule_page.waitForAngularRequestsToFinish();

        publishAndWait(8000);

        ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        ruleSummaryTableObjects.get(0).versionDetailAction.click();

        //Assert
        assertEquals("Yes", fallback);
        assertEquals("No", createQuickLocalRule_page.rulesFallback.getText());
    }
}
