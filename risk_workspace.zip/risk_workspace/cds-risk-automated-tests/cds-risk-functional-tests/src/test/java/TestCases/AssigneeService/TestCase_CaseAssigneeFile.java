package TestCases.AssigneeService;

import API.CaseAssigneeService.CaseAssigneeResponse;
import Categories_CDSRisk.Assignee_Service;
import Categories_CDSRisk.ChangeRequest;
import TestCases.BaseSpringBootTestCase;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.assertj.core.api.Assertions;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.service.DockerSupport;

import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;

//import org.apache.bcel.util.ClassLoader;

@Slf4j
@Ignore("This functionality is likely to change")
@Category({Assignee_Service.class})
public class TestCase_CaseAssigneeFile extends BaseSpringBootTestCase {

    @Test
    public void WhenAssigneeEndpointIsHit_InfoFromAssigneeFileIsUpdatedInCache() throws Exception {

        CopyFileToContainer();

        Map<String, String> response = assigneeServiceSupport.refreshAssigneeCache();
        Assertions.assertThat(response.get("message"))
        .contains("CaseAssignee(value=CaseAssignee.AssigneeValue(description=Team01, id=Team01, group=BORDER_FORCE, location=LHR))")
        .contains("CaseAssignee(value=CaseAssignee.AssigneeValue(description=Team02, id=0002, group=BORDER_FORCE, location=MAN))")
        .contains("CaseAssignee(value=CaseAssignee.AssigneeValue(description=Team03, id=0003, group=BORDER_FORCE, location=POO))")
        .contains("CaseAssignee(value=CaseAssignee.AssigneeValue(description=Team04, id=0004, group=BORDER_FORCE, location=WAT))")
        .contains("CaseAssignee(value=CaseAssignee.AssigneeValue(description=Team05, id=0005, group=BORDER_FORCE, location=HUL))");
    }


    @Test
    @Category(ChangeRequest.CR_2743.class)
    public void WhenCaseAssigneeEndPointIsHit_ListOfAssigneesReturned()
    {
        //Arrange
        CopyFileToContainer();
        assigneeServiceSupport.refreshAssigneeCache();

        //Act
        List<CaseAssigneeResponse> listOfCaseAssigneeResponse = API.CaseAssigneeService.Utils.CaseAssignee.GetListOfAssignees();

        //Assert
        assertEquals(HttpStatus.SC_OK, listOfCaseAssigneeResponse.get(0).httpStatusCode);
        assertTrue(listOfCaseAssigneeResponse.size() > 1);
        Assertions.assertThat(listOfCaseAssigneeResponse).extracting("id").contains("Team01");
    }


    @Test
    @Category(ChangeRequest.CR_2743.class)
    public void WhenCaseAssigneeFileIsUpdated_UpdatedListOfAssigneesReturned() throws Exception
    {
        //Arrange
        CopyFileToContainer();
        assigneeServiceSupport.refreshAssigneeCache();

        //Act
        List<CaseAssigneeResponse> listOfCaseAssigneeResponse = API.CaseAssigneeService.Utils.CaseAssignee.GetListOfAssignees();

        //Assert
        assertEquals(HttpStatus.SC_OK, listOfCaseAssigneeResponse.get(0).httpStatusCode);
        assertTrue(listOfCaseAssigneeResponse.size() > 1);
        Assertions.assertThat(listOfCaseAssigneeResponse).extracting("description").contains("Team02");
    }

    @SneakyThrows
    private void CopyFileToContainer()
    {
        DockerSupport.ContainerAccessor assigneeServiceContainer = dockerSupport.getAssigneeServiceContainer();

        dockerSupport.copyFileToContainer(Paths.get(ClassLoader.getSystemResource("TestData/RiskingData/assignee2/").toURI()),
                assigneeServiceContainer.getShortId(),
                "/tmp");

    }

}