package TestCases.RiskingService;

import API.DataForTests.Conditions;
import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestRuleModel.RuleDetails;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.Utils.RuleAtStatus;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service_Operators;
import TestCases.BaseWebAPITestCase;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import static API.DataForTests.TestRuleModel.RuleDetails.AttributeType.DOMAIN;
import static API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody;
import static org.assertj.core.api.Assertions.assertThat;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.normal;

@Slf4j
@Category(Risking_Service_Operators.class)
public class TestCase_Risking_Operators_DomainField extends BaseWebAPITestCase {

    public static final String NO_CONTROL_ROUTE = "";
    private RuleDetails testRule;
    private RuleDetails.Condition condition;
    private TestDeclarationModel.Declaration declaration;

    @Before
    public void setup() throws IOException, TimeoutException {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
        testRule = API.DataForTests.Rules.DraftNatRuleNatManager();
        condition = testRule.queryConditions.get(0).conditions.get(0);
        condition.operator = "eq";
        declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
    }

    private void commitRuleAndPublish(){
        EditRuleVersionResponse.PutResponse commitResponse = RuleAtStatus.CreateCommittedRule(testRule);
        assertThat(commitResponse.httpStatusCode)
                .describedAs("Failed to commit rule. response:\n"+commitResponse.body)
                .isEqualTo(200);
        publishAndWait(5000);
    }

    private DeclarationResponse riskDeclaration() {
        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());
        queue.send(declarationRequest);
        return new DeclarationResponse(queue.receive());
    }

    @Test
    @Category({ChangeRequest.CR_3317.class})
    public void whenDomainFieldMatchingAtHeaderItemLevel_ImporterBuyerCity_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.importerBuyerCity_domain(condition.value = "Sidney").attribute;
        commitRuleAndPublish();

        // Importer City (Header)/Buyer City (Header)/Buyer City (Item)
        declaration.importerCity_Header = "siDNey";
        declaration.buyerCity_Header = "siDNey";
        declaration.buyerCity_Item = "siDNey";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3317.class})
    public void whenDomainFieldMatchingAtHeaderItemLevel_ExporterSellerCity_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.exporterSellerCity_domain(condition.value = "Manchester").attribute;
        commitRuleAndPublish();

        //Exporter City (Header)/Seller City (Header)/Seller City (Item)
        declaration.exporterCity_Header = "MaNChesTer";
        declaration.sellerCity_Header = "MaNChesTer";
        declaration.sellerCity_Item = "MaNChesTer";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3317.class})
    public void whenDomainFieldMatchingAtHeaderLevel_DeclarantRepresentativeCity_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.declarantRepCity_domain(condition.value = "London").attribute;
        commitRuleAndPublish();

        //Declarant City (Header)/Representative City (Header)
        declaration.declarantCity = "LoNDon";
        declaration.representativeCity = "LoNDon";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3317.class})
    public void whenDomainFieldMatchingAtHeaderItemLevel_ImporterBuyerAddress_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.importerBuyerAddress_domain(condition.value = "1 Great Northern").attribute;
        commitRuleAndPublish();

//Importer Address (Header)/Buyer Address (Header)/Buyer Address (Item)
        declaration.importerAddress_Header = " 1 gREat nORthern";
        declaration.buyerAddress_Header = " 1 gREat nORthern";
        declaration.buyerAddress_Item = " 1 gREat nORthern";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3317.class})
    public void whenDomainFieldMatchingAtHeaderItemLevel_ExporterSellerAddress_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.exporterSellerAddress_domain(condition.value = "12 Jesmond Avenue").attribute;
        commitRuleAndPublish();

//Exporter Address (Header)/Seller Address (Header)/Seller Address (Item)
        declaration.exporterAddress_Header = "12  JeSMond Avenue";
        declaration.sellerAddress_Header = "12  JeSMond Avenue";
        declaration.sellerAddress_Item = "12  JeSMond Avenue";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3317.class})
    public void whenDomainFieldMatchingAtHeaderLevel_DeclarantRepresentativeAddress_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.declarantRepAddress_domain(condition.value = "45 Forster Place").attribute;
        commitRuleAndPublish();

        //Declarant Address (Header)/Representative Address (Header)
        declaration.declarantAddress = "45  FORstEr PlACE";
        declaration.representativeAddress = "";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3317.class})
    public void whenDomainFieldMatchingAtHeaderItemLevel_ImporterBuyerEori_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.importerBuyerEori_domain(condition.value = "CE1234567890").attribute;

        commitRuleAndPublish();

        // Importer EORI (Header)/Buyer EORI (Header)/Buyer EORI (Item)
        declaration.importerEori_Header = "CE1234567890";
        declaration.buyerId_Header = "cE1234567890";
        declaration.buyerId_Item = " CE1234567890";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3317.class})
    public void whenDomainFieldMatchingAtHeaderItemLevel_ExporterSellerEori_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.exporterSellerEori_domain(condition.value = "CE1234567890").attribute;
        commitRuleAndPublish();

        //Exporter EORI (Header)/Seller EORI (Header)/Seller EORI (Item)
        declaration.exporterId_Header = "Ce1234567890";
        declaration.sellerId_Header = " cE1234567890 ";
        declaration.sellerId_Item = "CE1234567890";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3317.class})
    public void whenDomainFieldMatchingAtHeaderLevel_DeclarantRepresentativeEori_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.declarantRepEori_domain(condition.value = "CE1234567890").attribute;
        commitRuleAndPublish();

        //Declarant EORI (Header)/Representative EORI (Header)
        declaration.declarantEORI = "CE1234567890";
        declaration.representativeEori = "CE1234567890";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3317.class})
    public void whenDomainFieldMatchingAtHeaderItemLevel_ImporterEoriBuyerIdExporterIdSellerId_RouteReturned() {  //ESIBEORIS
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.esibEoris_domain(condition.value = "DF12345T45YU").attribute;
        commitRuleAndPublish();

        //Importer EORI (Header)/Buyer EORI (Header)/Buyer EORI (Item)/Exporter EORI (Header)/Seller EORI (Header)/Seller EORI (Item)
        declaration.importerEori_Header = " DF12345T45YU";
        declaration.buyerId_Header = "DF12345T45YU ";
        declaration.buyerId_Item = "DF12345T45yU";
        declaration.exporterId_Header = "DF12345T45YU";
        declaration.sellerId_Header = "DF12345t45YU";
        declaration.sellerId_Item = "Df12345T45yu";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3317.class})
    public void whenDomainFieldMatchingAtHeaderItemLevel_ImporterBuyerPostcode_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.importerBuyerPostcode_domain(condition.value = "M1 2AY").attribute;
        commitRuleAndPublish();

        //Importer Postcode (Header)/Buyer Postcode (Header)/Buyer Postcode (Item)
        declaration.importerZipCode_Header = " m1 2ay";
        declaration.buyerPostcode_Header = "M1 2Ay ";
        declaration.buyerPostcode_Item = "M1 2ay";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3317.class})
    public void whenDomainFieldMatchingAtHeaderItemLevel_ExporterSellerPostcode_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.exporterSellerPostcode_domain(condition.value = "Sk8 2GH").attribute;
        commitRuleAndPublish();

        //Exporter Postcode (Header)/Seller Postcode (Header)/Seller Postcode (Item)
        declaration.exporterZipCode_Header = "Sk8 2gh";
        declaration.sellerPostcode_Header = " Sk8 2GH";
        declaration.sellerPostcode_Item = "Sk8 2GH ";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
//
    @Test
    @Category({ChangeRequest.CR_3317.class})
    public void whenDomainFieldMatchingAtHeaderLevel_DeclarantRepresentativePostcode_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.declarantRepPostcode_domain(condition.value = "YK234 I89").attribute;
        commitRuleAndPublish();


       //Declarant Postcode (Header)/Representative Postcode (Header)
        declaration.declarantPostcode = "YK234 i89 ";
        declaration.representativePostcode = " Yk234 I89";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3317.class})
    public void whenDomainFieldMatchingAtHeaderItemLevel_ImporterBuyerName_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.importerBuyerName_domain(condition.value = "Volkswagen12345").attribute;
        commitRuleAndPublish();

        //Importer Name (Header)/Buyer Name (Header)/Buyer Name (Item)
        declaration.importerName_Header = " VolKSwagEn12345";
        declaration.buyerName_Header = "Volkswagen12345 ";
        declaration.buyerName_Item = "volksWAgeN";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3317.class})
    public void whenDomainFieldMatchingAtHeaderItemLevel_ExporterSellerName_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.exporterSellerName_domain(condition.value = "Jaguar Land Rover").attribute;

        commitRuleAndPublish();

        //Exporter Name (Header)/Seller Name (Header)/Seller Name (Item)
        declaration.exporterName_Header = " Jaguar Land rOVer ";
        declaration.sellerName_Header = "Jaguar land Rover";
        declaration.sellerName_Item = "JagUAr Land Rover";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3317.class})
    public void whenDomainFieldMatchingAtHeaderLevel_DeclarantRepresentativeName_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.declarantRepName_domain(condition.value = "Jaguar Land Rover").attribute;
        commitRuleAndPublish();

        // Declarant Name (Header)/Representative Name (Header)
        declaration.declarantName = "Jaguar Land Rover";
        declaration.representativeName = "Jaguar Land Rover";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3317.class})
    public void whenDomainFieldMatchingAtHeaderItemLevelImporterBuyerExporterSellerName_RouteReturned() {  //ESIB NAmes
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.esibNames_domain(condition.value = "Ferrari 1234567890").attribute;

        commitRuleAndPublish();

        //Importer Name (Header)/Buyer Name (Header)/Buyer Name (Item)/Exporter Name (Header)/Seller Name (Header)/Seller Name (Item)
        declaration.importerName_Header = "ferrari 1234567890";
        declaration.buyerName_Header = "FeRRari 1234567890";
        declaration.buyerName_Item = "FerrarI 1234567890 ";
        declaration.exporterName_Header = "Ferrari  1234567890";
        declaration.sellerName_Header = "FErrari 1234567890";
        declaration.sellerName_Item = "FerRAri 1234567890 ";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3393.class})
    public void whenDomainFieldMatchingAtHeaderLevel_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.eori().attribute;
        condition.value = "AH123457890";

        commitRuleAndPublish();

        declaration.exporterConsignorId_Item = "AH123457890";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3394.class})
    public void whenDomainFieldMatchingAtItemLevelExporterEori_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.esibEoris_domain(condition.value = "AB1234567890").attribute;
        commitRuleAndPublish();

        declaration.exporterConsignorId_Item = "AB1234567890";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3394.class})
    public void whenDomainFieldMatchingAtItemLevelExporterName_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.esibNames_domain(condition.value = "AUDI 1234").attribute;
        commitRuleAndPublish();

        declaration.exporterConsignorName_Item = "AuDi 1234";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3394.class})
    public void whenDomainFieldMatchingAtItemLevelExporterCity_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.exporterSellerCity_domain(condition.value = "Leeds").attribute;
        commitRuleAndPublish();

        declaration.exporterConsignorCity_Item = "leEdS";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3396.class})
    public void whenDomainFieldMatchingAtDeclarantRepCountryDomain_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.declarantRepCountry_domain(condition.value = "FR").attribute;
        commitRuleAndPublish();

        declaration.representativeFunction = "2";
        declaration.representativeCountry = "FR";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3396.class})
    public void whenDomainFieldMatchingAtExporterSellerCountryDomain_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.exporterSellerCountry_domain(condition.value = "GB").attribute;
        commitRuleAndPublish();

        declaration.exporterConsignorCountry_Item= "gb";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3396.class})
    public void whenDomainFieldMatchingAtImporterBuyerCountryDomain_RouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.importerBuyerCountry_domain(condition.value = "FR").attribute;
        commitRuleAndPublish();

        declaration.importerCountry_Header = "FR";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
}
