package TestCases.UI.Rules;

import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Rules;
import Categories_CDSRisk.CDS_Risk_UI_Rules_1;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.Pages.RulesManagement.CreateNationalRule_Page;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_1.class})
public class TestCase_ActiveRule extends BaseUIWebDriverTestCase{

    public static final String TEST_DRAFT_RULE = "TestDraftRule";

    @Test
    @Category({ChangeRequest.CR_1882.class,ChangeRequest.CR_3100.class})
    public void WhenRuleManagerCommitsRuleAndPublishes_ActiveIsCreated() throws InterruptedException {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page =  utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(createRuleResponse.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Act
        ruleSummary_page.commitAndConfirm();

        utilNavigation = new Navigation(driver);
        listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        publishAndWait(5000);

        //Assert
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        ruleSummary_page = new RuleSummary_Page(driver);
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        boolean upcomingChangesDisplayed = ruleSummary_page.isElementDisplayed(ruleSummary_page.upcomingChangesTable);
        assertEquals("Expect Rule Status to be Active", "Active", listRuleSummaryTableObjects.get(0).status);
        assertEquals("Expect Rule Version to be 1", 1, listRuleSummaryTableObjects.get(0).version);
        assertEquals("Expect Rule Name to be " + ruleDetails.description, ruleDetails.description, listRuleSummaryTableObjects.get(0).description);
        //As this is active there should not be any upcoming changes table
        assertFalse("Upcoming changes dataTable should not be displayed",upcomingChangesDisplayed);
        assertEquals("Expect Rule Name to be " + ruleDetails.description, ruleDetails.description, listRuleSummaryTableObjects.get(0).description);
    }

    @Test
    @Category({ChangeRequest.CR_3521.class})
    public void WhenRuleManagerAmendsDraftRuleAndFillsAllMandatoryDetails_ActiveRuleIsCreated() throws InterruptedException {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateNationalRule_Page createNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateNationalRule);

        //Create a draft rule only with rule desc and regime
        createNationalRule_page.description.sendKeys(TEST_DRAFT_RULE);
        UI.ElementControls.DropDown dropDown = new UI.ElementControls.DropDown(driver);
        createNationalRule_page.scrollToViewTheElement(createNationalRule_page.regime);
        dropDown.selectFromCdsDropdown(createNationalRule_page.regime, "ADD");
        createNationalRule_page.save.click();
        createNationalRule_page.waitForAngularRequestsToFinish();
        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("testrule");
        createNationalRule_page.waitForAngularRequestsToFinish();

        //In List rules page select the newly created rule  and in rule summary page amend the rule
        ListRules_Page listRules_page =  new ListRules_Page(driver);
        listRules_page.clickRuleSummaryForSpecifiedRule(TEST_DRAFT_RULE);
        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);
        ruleSummary_page.amend.click();
        ruleSummary_page.waitForAngularRequestsToFinish();

        //Now fill all the mandatory details for the rules.
        UI.DataForTests.TestRuleModel.RuleDetails ruleDetailsNational = UI.DataForTests.Rules.DraftNATRule();
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalRuleSingleCondition(ruleDetailsNational);
        createNationalRule_page.clickSaveAndCommitWithDefaultReason();
        createNationalRule_page.waitForAngularRequestsToFinish();
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        assertEquals("Expect Rule Status to be Committed", "Committed", listRuleSummaryTableObjects.get(0).status);

        utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Assert that the rule status should be active as it is a committed rule
        listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("status")
                .contains("Active");

    }
}