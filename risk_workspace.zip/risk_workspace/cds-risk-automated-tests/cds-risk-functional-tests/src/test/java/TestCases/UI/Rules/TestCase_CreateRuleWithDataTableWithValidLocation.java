package TestCases.UI.Rules;

import API.DataForTests.DataTables;
import API.DataForTests.TestDataTableModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Rules;
import Categories_CDSRisk.CDS_Risk_UI_Rules_2;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.Pages.RulesManagement.CreateLocalRule_Page;
import UI.Pages.RulesManagement.CreateNationalRule_Page;
import UI.Utils.Navigation;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject;
import static FunctionsLibrary.Utils.SleepForMilliSeconds;
import static UI.DataForTests.TestRuleModel.RuleDetails.Condition.Attribute.COMMODITY_CODE;
import static UI.DataForTests.TestRuleModel.RuleDetails.Condition.AttributeType.ITEM;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_2.class})
public class TestCase_CreateRuleWithDataTableWithValidLocation extends BaseUIWebDriverTestCase{

    @Test
    @Category(ChangeRequest.CR_2066.class)
    public void WhenTryingCreatingANatRuleWithDataTable_OnlyTablesWithCorrectDataTableTypesAreAvailableToUseWithRule(){

        //Arrange
        CreateDataTableResponse.PostResponse commodityExt = CreateDataTableAndGetResponseObject(DataTables.DataTable_CommodityCodes_EXT());
        CreateDataTableResponse.PostResponse partCommodityTable = CreateDataTableAndGetResponseObject(DataTables.DataTable_CommodityCodes_NAT());

        //Act
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateNationalRule_Page createNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateNationalRule);

        String operator = "Equal";
        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftNATRuleUsingDataTable(COMMODITY_CODE, operator, commodityExt.tableName);
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = ITEM;

        //Act
        createNationalRule_page.selectTransportMode("All");
        createNationalRule_page.selectGoodsLocation(ruleDetails);
        createNationalRule_page.populateSingleCondition(ruleDetails);

        //Assert
        SleepForMilliSeconds(1000);
        assertThat(createNationalRule_page.getPopulatedDataTables(), hasItems(partCommodityTable.tableName, commodityExt.tableName));
    }

    @Test
    @Category(ChangeRequest.CR_2066.class)
    public void WhenTryingCreatingALocalRuleWithDataTable_RuleCannotBeCreatedWithDataTableThatDoesNotHaveThatLocationSetForShare(){

        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        TestDataTableModel.TableDetails tableDetailsPoo = DataTables.DataTable_CommodityCodes_POO();
        tableDetailsPoo.tableType = "sensitive";

        TestDataTableModel.TableDetails tableDetails_Ext = DataTables.DataTable_CommodityCodes_EXT();
        tableDetails_Ext.tableType = "sensitive";

        API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsPoo);
        API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails_Ext);

        //Act
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateLocalRule_Page createLocalRule_Page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();
        ruleDetails.conditionGroups.get(0).conditions.get(0).attribute = COMMODITY_CODE;
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = ITEM;
        ruleDetails.goodsLocations.clear();
        ruleDetails.goodsLocations.add("EXT");

        //Act
        createLocalRule_Page.selectGoodsLocation(ruleDetails);
        createLocalRule_Page.populateSingleCondition(ruleDetails);
        createLocalRule_Page.selectDataTable.click();

        //Assert
        SleepForMilliSeconds(1000);
        assertThat(createLocalRule_Page.getPopulatedDataTables(), hasItems(tableDetails_Ext.tableName));
        assertThat(createLocalRule_Page.getPopulatedDataTables(), not(hasItems(tableDetailsPoo.tableName)));
    }

    @Test
    @Category(ChangeRequest.CR_2066.class)
    public void WhenTryingCreatingALocalRuleWithOpenDataTable_RuleCanBeUsedWithTheDataTable(){

        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();
        tableDetails.tableType = "open";

        API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateLocalRule_Page createLocalRule_Page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();
        ruleDetails.conditionGroups.get(0).conditions.get(0).attribute = COMMODITY_CODE;
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = ITEM;

        //Act
        createLocalRule_Page.populateSingleCondition(ruleDetails);
        createLocalRule_Page.selectDataTable.click();

        //Assert
        SleepForMilliSeconds(1000);
        assertThat(createLocalRule_Page.getPopulatedDataTables(), hasItems(tableDetails.tableName));
    }

    @Test
    @Category(ChangeRequest.CR_2066.class)
    public void WhenTryingCreatingALocalRuleWithDataTable_NoLocationSelected_CanNotUseDataTableWithRule(){

        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();
        tableDetails.tableType = "restricted";

        API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateLocalRule_Page createLocalRule_Page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();
        ruleDetails.conditionGroups.get(0).conditions.get(0).attribute = COMMODITY_CODE;
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = ITEM;

        //Act
        //Don't select location
        createLocalRule_Page.populateSingleCondition(ruleDetails);

        //Assert
        SleepForMilliSeconds(1000);
        assertTrue("Option to select data table should be disabled", !createLocalRule_Page.isElementDisplayed(createLocalRule_Page.selectDataTable, 1, false));
    }
}
