package TestCases.UI.DataTables;

import API.DataForTests.DataTables;
import API.DataForTests.TestDataTableModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.Validate.ValidateDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_DataTables;
import Categories_CDSRisk.CDS_Risk_UI_DataTables_2;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.CommonComponents.PaginationToolBar;
import UI.Pages.DataManagement.DataTableData_Page;
import UI.Pages.DataManagement.DataTableSummary_Page;
import UI.Pages.DataManagement.EditDataTable_Page;
import UI.Pages.DataManagement.ListDataTable_Page;
import UI.Utils.Navigation;
import io.restassured.response.Response;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.openqa.selenium.Keys;

import java.util.List;

import static API.RulesManagementService.Utils.DataTables.*;
import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_DataTables.class, CDS_Risk_UI_DataTables_2.class})
public class TestCase_DataTableItemsPagination extends BaseUIWebDriverTestCase {

    private DataTableSummary_Page dataTableSummary_page;
    private DataTableData_Page dataTableData_Page;


    @Before
    public void setup() {

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;
        tableDetails.uniqueId = createDataTableResponse.uniqueId;

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        ValidateDataTableResponse.ValidateDataTableResponseObject validateResponse = ValidateUploadCSVFileRequestResponseObject(tableDetails, "UPLOAD-DATA-ITEMS_10000.csv");
        Response uploadResponse = UploadCSVFileRequest(tableDetails, "UPLOAD-DATA-ITEMS_10000.csv");


        //Arrange
        TestDataTableModel.TableDetails tdDefaultTestDataTable = DataTables.DataTable_DefaultCommodityCodes();
        API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tdDefaultTestDataTable);

        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listDataTable_Page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);
        listDataTable_Page.waitForAngularRequestsToFinish();
        dataTableSummary_page = listDataTable_Page.clickTableSummaryForSpecifiedDataTableID(tableDetails.uniqueId);
        listDataTable_Page.waitForAngularRequestsToFinish();
        dataTableData_Page = new DataTableData_Page(driver);
    }

    @Test
    @Category(ChangeRequest.CR_3435.class)
    public void WhenDataTableHasDataItemInMultiplePages_PaginationShouldWorkCorrectlyForDataItems() {
        //Arrange
        PaginationToolBar paginationToolBar = new PaginationToolBar(driver);
        paginationToolBar.selectDataItemsPageSize(5);
        dataTableData_Page.waitForAngularRequestsToFinish();
        paginationToolBar.scrollToViewTheElement(paginationToolBar.lastPage);
        paginationToolBar.lastPage.click();
        dataTableData_Page.waitForAngularRequestsToFinish();
        //Check Active page and page number of total pages
        assertEquals("pageSize", "5", paginationToolBar.getPageSizeForDataItems()); // Check page size is 5
        assertEquals("Current active page number", "Page\n" +
                "2000", paginationToolBar.activePageNumber.getText()); //check the page number is 2000
        paginationToolBar.previousPage.click();
        dataTableData_Page.waitForAngularRequestsToFinish();
        assertEquals("page number of total pages", "Page 1999 of 2000", paginationToolBar.pageXofY.getText()); // Check page size is 5
        dataTableData_Page.scrollToViewTheElement(paginationToolBar.nextPage);
        paginationToolBar.nextPage.click();
        assertEquals("page number of total pages", "Page 2000 of 2000", paginationToolBar.pageXofY.getText()); // Check page size is 5


        //When page size is 5 amount of items in each page should be 5
        paginationToolBar.scrollToViewTheElement(paginationToolBar.firstPage);
        paginationToolBar.firstPage.click();
        dataTableData_Page.waitForAngularRequestsToFinish();
        paginationToolBar.scrollToViewTheElement(paginationToolBar.page3);
        paginationToolBar.page3.click();
        dataTableData_Page.waitForAngularRequestsToFinish();
        List<String> dataItems = dataTableData_Page.getListOfDataItems();
        Assertions.assertThat(dataItems).hasSize(5);


        //When page size is 10 amount of items in each page should be 10
        paginationToolBar.selectDataItemsPageSize(10);
        dataTableData_Page.waitForAngularRequestsToFinish();
        paginationToolBar.scrollToViewTheElement(paginationToolBar.page5);
        paginationToolBar.page5.click();
        dataTableData_Page.waitForAngularRequestsToFinish();
        dataItems = dataTableData_Page.getListOfDataItems();
        Assertions.assertThat(dataItems).hasSize(10);

        //When page size is 20 amount of items in each page should be 20
        paginationToolBar.selectDataItemsPageSize(20);
        dataTableData_Page.waitForAngularRequestsToFinish();
        paginationToolBar.scrollToViewTheElement(paginationToolBar.page3);
        paginationToolBar.page3.click();
        dataTableData_Page.waitForAngularRequestsToFinish();
        dataItems = dataTableData_Page.getListOfDataItems();
        Assertions.assertThat(dataItems).hasSize(20);

        //When page size is 40 amount of items in each page should be 40
        paginationToolBar.selectDataItemsPageSize(40);
        dataTableData_Page.waitForAngularRequestsToFinish();
        paginationToolBar.scrollToViewTheElement(paginationToolBar.lastPage);
        paginationToolBar.lastPage.click();
        dataTableData_Page.waitForAngularRequestsToFinish();
        dataItems = dataTableData_Page.getListOfDataItems();
        Assertions.assertThat(dataItems).hasSize(37);

        //When page size is 100 amount of items in each page should be 100
        paginationToolBar.selectDataItemsPageSize(100);
        dataTableData_Page.waitForAngularRequestsToFinish();
        dataItems = dataTableData_Page.getListOfDataItems();
        Assertions.assertThat(dataItems).hasSize(100);

    }

    @Test
    @Category(ChangeRequest.CR_3435.class)
    public void WhenDataItemsAreEditedInDifferentPages_ItShouldWorkCorrectly() {
        //Arrange
        dataTableSummary_page.dataTab.click();
        DataTableData_Page dataTableTab_page = new DataTableData_Page(driver);
        EditDataTable_Page editDataTable_page = dataTableTab_page.clickEditDataTableButton();

        //Edit a data item in page 3
        PaginationToolBar paginationToolBar = new PaginationToolBar(driver);
        paginationToolBar.selectDataItemsPageSize(5);
        paginationToolBar.scrollToViewTheElement(paginationToolBar.page3);
        paginationToolBar.page3.click();
        dataTableData_Page.waitForAngularRequestsToFinish();
        List<EditDataTable_Page.DataTableItemObject> listDataTableItemsObjects = editDataTable_page.getListDataTableItems();
        listDataTableItemsObjects = editDataTable_page.getListDataTableItems();
        editDataTable_page.scrollToViewTheElement(listDataTableItemsObjects.get(3).editDataItem);
        listDataTableItemsObjects.get(3).editDataItem.click();
        editDataTable_page.waitForAngularRequestsToFinish();
        editDataTable_page.dataInputTextField.sendKeys(Keys.CONTROL, "a", Keys.DELETE);
        editDataTable_page.dataInputTextField.sendKeys("08Mm12");
        editDataTable_page.saveDataItem.click();

        paginationToolBar.scrollToViewTheElement(paginationToolBar.page5);
        paginationToolBar.page5.click();
        dataTableData_Page.waitForAngularRequestsToFinish();
        listDataTableItemsObjects = editDataTable_page.getListDataTableItems();
        editDataTable_page.scrollToViewTheElement(listDataTableItemsObjects.get(4).editDataItem);
        listDataTableItemsObjects.get(4).editDataItem.click();
        editDataTable_page.waitForAngularRequestsToFinish();
        editDataTable_page.dataInputTextField.sendKeys(Keys.CONTROL, "a", Keys.DELETE);
        editDataTable_page.dataInputTextField.sendKeys("0EndS3");
        editDataTable_page.saveDataItem.click();

        editDataTable_page.scrollToViewTheElement(editDataTable_page.save);
        editDataTable_page.save.click();
        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        paginationToolBar.selectDataItemsPageSize(5);
        editDataTable_page.scrollToViewTheElement(paginationToolBar.page3);
        paginationToolBar.page3.click();
        editDataTable_page.waitForAngularRequestsToFinish();
        List<String> dataItems = dataTableData_Page.getListOfDataItems();
        Assertions.assertThat(dataItems.get(3)).contains("08Mm12");
        editDataTable_page.scrollToViewTheElement(paginationToolBar.page5);
        paginationToolBar.page5.click();
        editDataTable_page.waitForAngularRequestsToFinish();
        dataItems = dataTableData_Page.getListOfDataItems();
        Assertions.assertThat(dataItems.get(4)).contains("0EndS3");
    }

    @Test
    @Category(ChangeRequest.CR_3435.class)
    public void WhenDataItemsAreDeletedInDifferentPages_ItShouldWorkCorrectly() {
        //Arrange
        dataTableSummary_page.dataTab.click();
        DataTableData_Page dataTableTab_page = new DataTableData_Page(driver);
        EditDataTable_Page editDataTable_page = dataTableTab_page.clickEditDataTableButton();

        PaginationToolBar paginationToolBar = new PaginationToolBar(driver);
        paginationToolBar.selectDataItemsPageSize(5);
        paginationToolBar.scrollToViewTheElement(paginationToolBar.page3);
        paginationToolBar.page3.click();
        editDataTable_page.waitForAngularRequestsToFinish();
        List<EditDataTable_Page.DataTableItemObject> listDataTableItemsObjects = editDataTable_page.getListDataTableItems();
        listDataTableItemsObjects = editDataTable_page.getListDataTableItems();
        editDataTable_page.scrollToViewTheElement(listDataTableItemsObjects.get(3).delete);
        listDataTableItemsObjects.get(3).delete.click();

        paginationToolBar.scrollToViewTheElement(paginationToolBar.page5);
        paginationToolBar.page5.click();
        dataTableData_Page.waitForAngularRequestsToFinish();
        listDataTableItemsObjects = editDataTable_page.getListDataTableItems();
        editDataTable_page.scrollToViewTheElement(listDataTableItemsObjects.get(4).delete);
        listDataTableItemsObjects.get(4).delete.click();

        editDataTable_page.scrollToViewTheElement(editDataTable_page.save);
        editDataTable_page.save.click();
        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        DataTableData_Page dataTableData_Page = new DataTableData_Page(driver);
        paginationToolBar.selectDataItemsPageSize(5);
        editDataTable_page.scrollToViewTheElement(paginationToolBar.page3);
        paginationToolBar.page3.click();
        editDataTable_page.waitForAngularRequestsToFinish();
        List<String> dataItems = dataTableData_Page.getListOfDataItems();
        Assertions.assertThat(dataItems.get(3)).doesNotContain("08Mm1");
        editDataTable_page.scrollToViewTheElement(paginationToolBar.page5);
        paginationToolBar.page5.click();
        dataTableData_Page.waitForAngularRequestsToFinish();
        dataItems = dataTableData_Page.getListOfDataItems();
        Assertions.assertThat(dataItems.get(4)).doesNotContain("0EndS");
    }


}
