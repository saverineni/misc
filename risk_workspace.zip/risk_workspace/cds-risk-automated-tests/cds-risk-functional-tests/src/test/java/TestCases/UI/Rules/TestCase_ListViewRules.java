package TestCases.UI.Rules;

import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Rules;
import Categories_CDSRisk.CDS_Risk_UI_Rules_2;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_2.class})
public class TestCase_ListViewRules extends BaseUIWebDriverTestCase {


    @Category(ChangeRequest.CR_1771.class)
    @Test
    public void WhenListRulesPageViewed_CorrectDetailsDisplayed() {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse ruleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.description = ruleResponse.description;

        TestUserModel.UserDetails UserDetails_RV = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        List<ListRules_Page.ListRulesTableObject> listRulesTableObjects = listRules_page.getListOfRules();

        //Assert
        assertEquals("Expect Rule Version to be 1", 1, listRulesTableObjects.get(0).version);
        assertEquals("Expect Rule Status to be Draft", "Draft", listRulesTableObjects.get(0).status);
        assertEquals("Expect No of Pending to be 0", 0, listRulesTableObjects.get(0).pending);
        assertEquals("Expect Rule Name to be " + ruleDetails.description, ruleDetails.description, listRulesTableObjects.get(0).description);
    }

    @Category(ChangeRequest.CR_621.class)
    @Test
    public void WhenNationalRuleCreated_RuleCanBeViewedByNationalRuleViewer() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse ruleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.description = ruleResponse.description;

        //Act
        TestUserModel.UserDetails UserDetails_RV = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Assert
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetailsForLocalRuleViewer();

        assertEquals("Expect Rule Status to be Draft", "Draft", listRuleSummaryTableObjects.get(0).status);
        assertEquals("Expect Rule Version to be 1", 1, listRuleSummaryTableObjects.get(0).version);
        assertEquals("Expect Rule Name to be " + ruleDetails.description, ruleDetails.description, listRuleSummaryTableObjects.get(0).description);
    }


    @Category(ChangeRequest.CR_621.class)
    @Test
    public void WhenLocalRuleCreated_RuleCanBeViewedByNationalRuleViewer() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse ruleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.description = ruleResponse.description;

        //Act
        TestUserModel.UserDetails UserDetails_RV = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Assert
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetailsForLocalRuleViewer();

        assertEquals("Expect Rule Status to be Draft", "Draft", listRuleSummaryTableObjects.get(0).status);
        assertEquals("Expect Rule Version to be 1", 1, listRuleSummaryTableObjects.get(0).version);
        assertEquals("Expect Rule Name to be " + ruleDetails.description, ruleDetails.description, listRuleSummaryTableObjects.get(0).description);
    }


    @Test
    public void WhenNationalRuleCreated_RuleCanNotBeViewedByLocalRuleViewer() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse ruleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.description = ruleResponse.description;

        //Act
        TestUserModel.UserDetails UserDetails_POO = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_POO);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_POO);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Assert
        boolean actRuleFound = listRules_page.isRulePresent(ruleDetails.description);

        assertTrue("Expect Rule to be NOT Found: " + ruleDetails.description, actRuleFound == false);
    }


    @Category(ChangeRequest.CR_621.class)
    @Test
    public void WhenLocalRuleCreated_RuleCanBeViewedByLocalRuleViewerFromSameGoodsLocation() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse ruleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.description = ruleResponse.description;

        //Act
        TestUserModel.UserDetails UserDetails_RV = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Assert
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetailsForLocalRuleViewer();

        assertEquals("Expect Rule Status to be Draft", "Draft", listRuleSummaryTableObjects.get(0).status);
        assertEquals("Expect Rule Version to be 1", 1, listRuleSummaryTableObjects.get(0).version);
        assertEquals("Expect Rule Name to be " + ruleDetails.description, ruleDetails.description, listRuleSummaryTableObjects.get(0).description);
    }


    @Category(ChangeRequest.CR_621.class)
    @Test
    public void WhenLocalRuleCreatedWith2GoodsLocations_RuleCanBeViewedByLocalRuleViewerWithBothGoodsLocations() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POOEXT();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse ruleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.description = ruleResponse.description;

        //Act
        TestUserModel.UserDetails UserDetails_RV = Users_API.RuleViewerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Assert
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetailsForLocalRuleViewer();

        assertEquals("Expect Rule Status to be Draft", "Draft", listRuleSummaryTableObjects.get(0).status);
        assertEquals("Expect Rule Version to be 1", 1, listRuleSummaryTableObjects.get(0).version);
        assertEquals("Expect Rule Name to be " + ruleDetails.description, ruleDetails.description, listRuleSummaryTableObjects.get(0).description);
    }


    @Category(ChangeRequest.CR_621.class)
    @Test
    public void WhenLocalRuleCreatedWith2GoodsLocations_RuleCanNotBeViewedByLocalRuleViewerWith1OfTheGoodsLocations() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POOEXT();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse ruleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.description = ruleResponse.description;

        //Act
        TestUserModel.UserDetails UserDetails_RV = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RV);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_RV);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Assert
        boolean actRuleFound = listRules_page.isRulePresent(ruleDetails.description);

        assertTrue("Expect Rule to be NOT Found: " + ruleDetails.description, actRuleFound == false);
    }


}
