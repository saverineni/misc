package TestCases.RiskingService;


import API.DataForTests.Conditions;
import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestRuleModel;
import API.RiskingService.Declaration.SubmitDeclarationRequestFromFile;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Slow_Tests;
import TestCases.BaseWebAPITestCase;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.riskingservice.model.internal.request.DeclaredDutyTaxFee;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.TimeoutException;

import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
@Category(Slow_Tests.class)
public class TestCase_Risking_Attributes_Calculated extends BaseWebAPITestCase {

    @Before
    public void setup() throws IOException, TimeoutException
    {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
    }


    @Test
    @Category({ChangeRequest.CRX_4.class})
    public void WhenDeclarationSubmittedFor_TaxAmountSum_1TaxAmount_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.taxAmountSum());
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.taxAmount = Conditions.taxAmount().value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        String returnedControlType = declarationResponse.getControlType();
        assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_4.class})
    public void WhenDeclarationSubmittedFor_TaxAmountSum_4TaxAmountsSummed_RouteReturned() throws Throwable {

        //1 Goods Item with 4 Tax Amounts. Should match on total tax amount

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.taxAmountSum());
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.taxAmount = Conditions.taxAmount().value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declaredDutyBlock = "\t\t\t\t\t\t\t\t<_31:declaredDutyTaxFees>\n" +
                "                                    <_22_1:totalAmount>#totalAmount#</_22_1:totalAmount>\n" +
                "\t\t\t\t\t\t\t\t</_31:declaredDutyTaxFees>";


        String declaredDutyBlock1 = declaredDutyBlock.replace("#totalAmount#", "123.50");
        String declaredDutyBlock2 = declaredDutyBlock.replace("#totalAmount#", "35");
        String declaredDutyBlock3 = declaredDutyBlock.replace("#totalAmount#", "15");
        String declaredDutyBlock4 = declaredDutyBlock.replace("#totalAmount#", "50");
        //Total = £223.50
        String declaredDutyBlocks = declaredDutyBlock1 + "\n" + declaredDutyBlock2 + "\n" + declaredDutyBlock3 + "\n" + declaredDutyBlock4;

        String goodsItemsBlock = "                            <_31:goodsItems>\n\n"
                + "                               <_22_1:sequenceNumber>1</_22_1:sequenceNumber>"
                + declaredDutyBlocks
                + "                            </_31:goodsItems>\n\n";

        String declarationRequest = DeclarationTemplateCutDownVersion().replace("#goodsItemsBlock#", goodsItemsBlock)
                .replace("#goodsLocationID#","GBBYMNCABZNASInfo");

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        modelSupport.checkItemFieldValue(declarationRequest, "taxAmountSum", new BigDecimal("223.50"));

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        String returnedControlType = declarationResponse.getControlType();
        assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_4.class})
    public void WhenDeclarationSubmittedFor_TaxAmountSum_2GoodsItemTaxAmountsNotSummed_NoRouteReturned() throws Throwable {

        //2 Goods Item with 1 Tax Amount each. Should NOT match on total tax amount across items

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.taxAmountSum());
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String goodsItemsBlock =
                "                            <_31:goodsItems>\n\n" +
                        "                               <_22_1:sequenceNumber>1</_22_1:sequenceNumber>" +
                        "                               <_31:declaredDutyTaxFees>\n" +
                        "                                    <_22_1:totalAmount>123.50</_22_1:totalAmount>\n" +
                        "                               </_31:declaredDutyTaxFees>\n" +
                        "                            </_31:goodsItems>\n" +

                        "                            <_31:goodsItems>\n\n" +
                        "                               <_22_1:sequenceNumber>2</_22_1:sequenceNumber>" +
                        "                               <_31:declaredDutyTaxFees>\n" +
                        "                                    <_22_1:totalAmount>100</_22_1:totalAmount>\n" +
                        "                               </_31:declaredDutyTaxFees>\n" +
                        "                            </_31:goodsItems>";


        String declarationRequest = DeclarationTemplateCutDownVersion().replace("#goodsItemsBlock#", goodsItemsBlock).replace("#goodsLocationName#","GBBYMNCABZNASInfo");
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        modelSupport.checkItemFieldValue(declarationRequest, "taxAmountSum", new BigDecimal("123.50"), new BigDecimal("100"));

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        declaration.controlTypeExpectedValue = "";
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_4.class})
    public void WhenDeclarationSubmittedFor_TaxAmountSum_2GoodsItemTaxAmountsSummed_RouteReturned() throws Throwable {

        //2 Goods Item with 1 Goods Item Total equals, and 1 Goods Item not match total.
        // Should match on total tax amount across items

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.taxAmountSum());
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        //declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String goodsItemsBlock =
                "                            <_31:goodsItems>\n\n" +
                        "                               <_22_1:sequenceNumber>1</_22_1:sequenceNumber>" +
                        "                               <_31:declaredDutyTaxFees>\n" +
                        "                                    <_22_1:totalAmount>123.25</_22_1:totalAmount>\n" +
                        "                               </_31:declaredDutyTaxFees>\n" +

                        "                               <_31:declaredDutyTaxFees>\n" +
                        "                                    <_22_1:totalAmount>100.25</_22_1:totalAmount>\n" +
                        "                               </_31:declaredDutyTaxFees>\n" +
                        "                            </_31:goodsItems>\n" +

                        "                            <_31:goodsItems>\n\n" +
                        "                               <_22_1:sequenceNumber>2</_22_1:sequenceNumber>" +
                        "                               <_31:declaredDutyTaxFees>\n" +
                        "                                    <_22_1:totalAmount>500</_22_1:totalAmount>\n" +
                        "                               </_31:declaredDutyTaxFees>\n" +
                        "                            </_31:goodsItems>";


        String declarationRequest = DeclarationTemplateCutDownVersion().replace("#goodsItemsBlock#", goodsItemsBlock)
                .replace("#goodsLocationID#","GBBYMNCABZNASInfo");

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        modelSupport.checkItemFieldValue(declarationRequest, "taxAmountSum", new BigDecimal("223.50"), new BigDecimal("500"));

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        String returnedControlType = declarationResponse.getControlType();
        assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_4.class})
    public void WhenDeclarationSubmittedFor_TaxRevenueSum_1TaxRevenue_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.taxRevenueSum());
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.taxRevenue = Conditions.taxRevenue().value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        String returnedControlType = declarationResponse.getControlType();
        assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_4.class})
    public void WhenDeclarationSubmittedFor_TaxRevenueSum_4TaxRevenuesSummed_RouteReturned() throws Throwable {

        //1 Goods Item with 4 Tax Revenues. Should match on total tax amount

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.taxRevenueSum());
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.taxRevenue = Conditions.taxAmount().value;

        String declaredDutyBlock = "\t\t\t\t\t\t\t\t<_31:declaredDutyTaxFees>\n" +
                "                                    <_22_1:payableAmount>#payableAmount#</_22_1:payableAmount>\n" +
                "\t\t\t\t\t\t\t\t</_31:declaredDutyTaxFees>";

        String declaredDutyBlock1 = declaredDutyBlock.replace("#payableAmount#", "161.23");
        String declaredDutyBlock2 = declaredDutyBlock.replace("#payableAmount#", "130");
        String declaredDutyBlock3 = declaredDutyBlock.replace("#payableAmount#", "100");
        String declaredDutyBlock4 = declaredDutyBlock.replace("#payableAmount#", "170");
        //Total = £561.23
        String declaredDutyBlocks = declaredDutyBlock1 + "\n" + declaredDutyBlock2 + "\n" + declaredDutyBlock3 + "\n" + declaredDutyBlock4;

        String goodsItemsBlock = "                            <_31:goodsItems>\n\n"
                + "                               <_22_1:sequenceNumber>1</_22_1:sequenceNumber>"
                + declaredDutyBlocks
                + "                            </_31:goodsItems>\n\n";

        String declarationRequest = DeclarationTemplateCutDownVersion().replace("#goodsItemsBlock#", goodsItemsBlock)
                .replace("#goodsLocationID#","GBBYMNCABZNASInfo");

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        modelSupport.checkItemFieldValue(declarationRequest, "taxRevenueSum", new BigDecimal("561.23"));

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        String returnedControlType = declarationResponse.getControlType();
        assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_4.class})
    public void WhenDeclarationSubmittedFor_TaxRevenueSum_2GoodsItemTaxRevenuesNotSummed_NoRouteReturned() throws Throwable {

        //2 Goods Item with 1 Tax Revenue each. Should NOT match on total revenue amount across items

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.taxRevenueSum());
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String goodsItemsBlock =
                "                            <_31:goodsItems>\n\n" +
                        "                               <_22_1:sequenceNumber>1</_22_1:sequenceNumber>" +
                        "                               <_31:declaredDutyTaxFees>\n" +
                        "                                    <_22_1:totalAmount>461.23</_22_1:totalAmount>\n" +
                        "                               </_31:declaredDutyTaxFees>\n" +
                        "                            </_31:goodsItems>\n" +

                        "                            <_31:goodsItems>\n\n" +
                        "                               <_22_1:sequenceNumber>2</_22_1:sequenceNumber>" +
                        "                               <_31:declaredDutyTaxFees>\n" +
                        "                                    <_22_1:totalAmount>100</_22_1:totalAmount>\n" +
                        "                               </_31:declaredDutyTaxFees>\n" +
                        "                            </_31:goodsItems>";


        String declarationRequest = DeclarationTemplateCutDownVersion().replace("#goodsItemsBlock#", goodsItemsBlock).replace("#goodsLocationName#","GBBYMNCABZNASInfo");

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        modelSupport.checkItemFieldValue(declarationRequest, "taxAmountSum", new BigDecimal("461.23"), new BigDecimal("100"));

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        declaration.controlTypeExpectedValue = "";
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_4.class})
    public void WhenDeclarationSubmittedFor_CustomsValuePerQuantityItem_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.customsValuePerQuantity());
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.declaredCustomsValue = "300.375";
        declaration.baseQuantity = "3";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        //customsValuePerQuantity= 300.375/3 = 100.125

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        String returnedControlType = declarationResponse.getControlType();
        assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_4.class})
    public void WhenDeclarationSubmittedFor_CustomsValuePerQuantityItem_QuantityDecimal_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.customsValuePerQuantity());
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.declaredCustomsValue = "250.3125";
        declaration.baseQuantity = "2.5";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        //customsValuePerQuantity= 250.3125/2.5 = 100.125

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        String returnedControlType = declarationResponse.getControlType();
        assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_4.class})
    public void WhenDeclarationSubmittedFor_CustomsValuePerQuantityItem_QuantityZero_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.customsValuePerQuantity());
        ruleDetails.queryConditions.get(0).conditions.get(0).value = "0";
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.declaredCustomsValue = "250.3125";
        declaration.baseQuantity = "0";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        //customsValuePerQuantity= 250.3125/0 = error but returns 0

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        modelSupport.checkItemFieldValue(declarationRequest, "customsValuePerQuantity", new BigDecimal("0"));

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        String returnedControlType = declarationResponse.getControlType();
        assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_141.class})
    public void WhenDeclarationSubmittedFor_CustomsValueHeader_1CustomValueSummed_RouteReturned() throws Throwable {

        ////Customs Value Header Sums over all item customs values

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.customsValue_Header());
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.customsValue = Conditions.customsValue_Header().value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CRX_141.class})
    public void WhenDeclarationSubmittedFor_CustomsValuesHeader_MultipleCustomsValuesSummed_RouteReturned() throws Throwable {

        ////Customs Value Header Sums over all item customs values

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        TestRuleModel.RuleDetails.Condition condition = Conditions.customsValue_Header();

        condition.value = "4444.44";

        ruleDetails.queryConditions.get(0).conditions.add(condition);
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.customsValue = "1000.01";
        declaration.customsValue2 = "1100.10";
        declaration.customsValue3 = "1100.20";
        declaration.customsValue4 = "1244.13";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultMultiItemDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CRX_141.class})
    public void WhenDeclarationSubmittedFor_DeclaredCustomsValueHeader_1DeclaredCustomValueSummed_RouteReturned() throws Throwable {

        ////Declared Customs Value Header Sums over all item declared customs values

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.declaredCustomsValue_Header());
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.declaredCustomsValue = Conditions.declaredCustomsValue_Header().value;

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CRX_141.class})
    public void WhenDeclarationSubmittedFor_DeclaredCustomsValuesHeader_MultipleDeclaredCustomsValuesSummed_RouteReturned() throws Throwable {

        ////Declared Customs Value Header Sums over all item declared customs values

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        TestRuleModel.RuleDetails.Condition condition = Conditions.declaredCustomsValue_Header();

        condition.value = "4444.44";

        ruleDetails.queryConditions.get(0).conditions.add(condition);
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.declaredCustomsValue = "1000.01";
        declaration.declaredCustomsValue2 = "1100.10";
        declaration.declaredCustomsValue3 = "1100.20";
        declaration.declaredCustomsValue4 = "1244.13";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultMultiItemDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CRX_141.class})
    public void WhenDeclarationSubmittedFor_DutyChargeValueHeader_1TaxAmountSummed_RouteReturned() throws Throwable {

        ////DutyChargeValueHeader Sum of item tax amount

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.dutyChargeValue());
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.taxAmount = Conditions.dutyChargeValue().value;

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CRX_141.class})
    public void WhenDeclarationSubmittedFor_DutyChargeValueHeader_MultipleTaxAmountSummed_RouteReturned() throws Throwable {

        ////DutyChargeValueHeader Sum of item tax amount

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        TestRuleModel.RuleDetails.Condition condition = Conditions.dutyChargeValue();

        condition.value = "4444.44";

        ruleDetails.queryConditions.get(0).conditions.add(condition);
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.taxAmount = "1000.01";
        declaration.taxAmount2 = "1100.10";
        declaration.taxAmount3 = "1100.20";
        declaration.taxAmount4 = "1244.13";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultMultiItemDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CRX_141.class})
    public void WhenDeclarationSubmittedFor_TotalRevenueHeader_1TaxRevenueSummed_RouteReturned() throws Throwable {

        ////TotalRevenueHeader Sum of all item tax revenue

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.totalRevenue());
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.taxRevenue = Conditions.totalRevenue().value;

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CRX_141.class})
    public void WhenDeclarationSubmittedFor_TotalRevenueHeader_MultipleTaxRevenueSummed_RouteReturned() throws Throwable {

        ////TotalRevenueHeader Sum of all item tax revenue

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        TestRuleModel.RuleDetails.Condition condition = Conditions.totalRevenue();

        condition.value = "4444.44";

        ruleDetails.queryConditions.get(0).conditions.add(condition);
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.taxRevenue = "1000.01";
        declaration.taxRevenue2 = "1100.10";
        declaration.taxRevenue3 = "1100.20";
        declaration.taxRevenue4 = "1244.13";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultMultiItemDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CRX_141.class})
    public void WhenDeclarationSubmittedFor_TotalVatHeader_1TaxAmountSummed_RouteReturned() throws Throwable {

        ////TotalVatHeader Sum of all item tax amount with type = B00

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.totalVat());
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.vatValue = Conditions.totalVat().value;     //Note Tax Amount
        declaration.taxTypeCode ="B00";  //????
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CRX_141.class})
    public void WhenDeclarationSubmittedFor_TotalVatHeader_3TaxAmountSummed_RouteReturned() throws Throwable {

        ////TotalRevenueHeader Sum of all item tax revenue

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        TestRuleModel.RuleDetails.Condition condition = Conditions.totalVat();

        condition.value = "4444.44";

        ruleDetails.queryConditions.get(0).conditions.add(condition);
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.taxTypeCode = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue = "1000.01";
        declaration.taxTypeCode2 = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue2 = "1100.10";
        declaration.taxTypeCode3 = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue3 = "1100.20";
        declaration.taxTypeCode4 = DeclaredDutyTaxFee.VAT_TYPE;
        declaration.vatValue4 = "1244.13";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultMultiItemDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CRX_4.class})
    public void WhenDeclarationSubmittedFor_BigDecimalFieldIntegerMatch_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.commodityNetMass());
        ruleDetails.queryConditions.get(0).conditions.get(0).value = "100";
        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.commodityNetMass = "100";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        modelSupport.checkItemFieldValue(declarationRequest, "netMass", new BigDecimal("100"));

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        String returnedControlType = declarationResponse.getControlType();
        assertThat(returnedControlType).isEqualTo(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }

    public String DeclarationTemplateCutDownVersion()
    {

        String declarationTemplate = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                "\n" +
                "    <soapenv:Header/>\n" +
                "    <soapenv:Body>\n" +
                "        <_30:initiateRiskAssessment xmlns:_22=\"http://cmm.core.ecf/BaseTypes/cmmEnhancementTypes/trade/2017/02/22/\"\n" +
                "                                    xmlns:_22_1=\"http://cmm.core.ecf/BaseTypes/cmmDeclarationTypes/trade/2017/02/22/\"\n" +
                "                                    xmlns:_22_3=\"http://cmm.core.ecf/BaseTypes/cmmValueTypes/trade/2017/02/22/\"\n" +
                "                                    xmlns:__22_3=\"http://cmm.core.ecf/BaseTypes/cmmPartyTypes/trade/2017/02/22/\"\n" +
                "                                    xmlns:_30=\"http://risk.core/RiskAssessmentServiceSOAP/2016/12/30/\"\n" +
                "                                    xmlns:_30_1=\"http://serviceobjects.cmm.core.ecf/2011/11/30/\"\n" +
                "                                    xmlns:_30_2=\"http://risk.core.ecf/messages/2011/11/30/\"\n" +
                "                                    xmlns:_31=\"http://trade.core.ecf/messages/2017/03/31/\">\n" +
                "            <riskAssessmentRequest>\n" +
                "                <_30_1:id>#id#</_30_1:id>\n" +
                "                <_30_2:object>\n" +
                "                    <_31:declarationWithResults>\n" +
                "\n" +
                "                        <_22_1:modeOfEntry></_22_1:modeOfEntry>\n" +
                "                        <_22_1:goodsItemCount></_22_1:goodsItemCount>\n" +
                "                        <_22_1:tradeMovementType>EX</_22_1:tradeMovementType>\n" +
                "                        <_22_1:type>C</_22_1:type>\n" +
                "\n" +
                "\n" +
                "                        <_31:consignmentShipment>\n" +
                "\n" +
                "                           <_31:transportMeans>\n" +
                "                           <_22_1:mode>4</_22_1:mode>    <!-- mode = 1 to 9 -->\n" +
                "                           <_22_1:type>1</_22_1:type>\n" +
                "                           </_31:transportMeans>" +
                "\n\n" +
                "\n" +
                "                            <_31:locations>\n" +
                "\n" +
                "                                <_22_1:type>14</_22_1:type> <!-- 14 -->\n" +
                "                                <_22_1:locationAdditionalId>#goodsLocationID#</_22_1:locationAdditionalId>               <!--goodsLocationID or PremiseId -->\n" +
                "                                <_22_1:locationId>#goodsLocationName#</_22_1:locationId>       <!--goodsLocation or PremiseName -->\n" +
                "                                <_31:physicalAddress>\n" +
                "                                    <_22_3:cityName>#goodsLocationCity#</_22_3:cityName>\n" +
                "                                    <_22_3:country>\n" +
                "                                        <_22_3:code>#goodsLocationCountry#</_22_3:code>\n" +
                "                                    </_22_3:country>\n" +
                "                                    <_22_3:zipCode>#goodsLocationPostcode#</_22_3:zipCode>\n" +
                "                                    <_22_3:streetAndNumber>#goodsLocationAddress#</_22_3:streetAndNumber>\n" +
                "                                </_31:physicalAddress>\n" +
                "                            </_31:locations>\n"+
                "#goodsItemsBlock#\n" +
                "\n\n" +
                "                        </_31:consignmentShipment>\n" +
                "                    </_31:declarationWithResults>\n" +
                "                </_30_2:object>\n" +
                "            </riskAssessmentRequest>\n" +
                "        </_30:initiateRiskAssessment>\n" +
                "    </soapenv:Body>\n" +
                "</soapenv:Envelope>";

        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declarationTemplate = declarationTemplate.replace("#id#", declaration.id);

        return declarationTemplate;

    }

}
