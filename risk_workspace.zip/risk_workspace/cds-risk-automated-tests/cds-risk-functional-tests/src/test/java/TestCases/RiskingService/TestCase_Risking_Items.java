package TestCases.RiskingService;


import API.DataForTests.Conditions;
import API.DataForTests.Rules;
import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestRuleModel;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.Utils.RuleAtStatus;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import junitparams.JUnitParamsRunner;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import uk.gov.hmrc.risk.test.common.enums.DeclarationSubType;
import uk.gov.hmrc.risk.test.common.enums.DeclarationType;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.TimeoutException;

import static API.DataForTests.TestRuleModel.RuleDetails.AttributeType.HEADER;
import static API.DataForTests.TestRuleModel.RuleDetails.AttributeType.ITEM;
import static API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody;
import static org.assertj.core.api.Assertions.assertThat;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.crossmatch;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.normal;

@Slf4j
@Category(Risking_Service.class)
@RunWith(JUnitParamsRunner.class)
public class TestCase_Risking_Items extends WebAPITestCaseWithDatatablesCleanup {

    public static final String NO_CONTROL_ROUTE = "";
    private TestRuleModel.RuleDetails testRule;
    private TestRuleModel.RuleDetails.Condition condition;
    private TestDeclarationModel.Declaration declaration;

    @Before
    public void setup() throws IOException, TimeoutException {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
        testRule = Rules.DraftNatRuleNatManager();
        testRule.queryOptions.declarationType = DeclarationType.EX.toString();
        testRule.queryOptions.declarationSubTypes = Arrays.asList(DeclarationSubType.C.toString());
        condition = testRule.queryConditions.get(0).conditions.get(0);
        declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
    }

    private void commitRuleAndPublish() {
        EditRuleVersionResponse.PutResponse commitResponse = RuleAtStatus.CreateCommittedRule(testRule);
        assertThat(commitResponse.httpStatusCode)
                .describedAs("Failed to commit rule. response:\n" + commitResponse.body)
                .isEqualTo(200);
        publishAndWait(5000);
    }

    private DeclarationResponse riskDeclaration() {
        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());
        queue.send(declarationRequest);
        return new DeclarationResponse(queue.receive());
    }

    @Category({ChangeRequest.CR_3418.class})
    public void whenCusCodeItemEqualAttribute_conditionAndDeclarationEqual_thenRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = crossmatch;
        condition.operator = "eq";

        condition.attribute = Conditions.cusCommodityCode_Item("123456NL").attribute;
        condition.value = Conditions.commodityCode().attribute;
        commitRuleAndPublish();

        declaration.cusCommodityCode_Item = "123456NL";
        declaration.commodity="123456NL";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3418.class})
    public void whenCusCodeItemMatchedPatternValue_conditionAndDeclarationNotEqual_thenRouteNotReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.operator = "nco";
        condition.attribute = Conditions.cusCommodityCode_Item("1234").attribute;
        condition.value = "1234";
        commitRuleAndPublish();
        declaration.cusCommodityCode_Item = "123456XY";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CR_3417.class})
    public void whenCountryGroupOfOriginItemEqualValue_ConditionAndDeclarationEqual_thenRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.operator = "eq";
        condition.attribute = Conditions.countryGroupOfOrigin_Item("CHIN").attribute;
        condition.value = "CHIN";
        commitRuleAndPublish();
        declaration.subRole="1";
        declaration.countryGroupOfOrigin_Item = "CHIN";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3417.class})
    public void whenCountryGroupOfOriginItemEqualAttribute_ConditionAndDeclarationAttributesEqual_thenRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = crossmatch;
        condition.operator = "eq";
        condition.attribute = Conditions.countryGroupOfOrigin_Item("CH").attribute;
        condition.value = Conditions.originCountry_Item().attribute;
        commitRuleAndPublish();
        declaration.subRole="1";
        declaration.originCountry_Item = "CH";
        declaration.countryGroupOfOrigin_Item = "CH";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3417.class})
    public void whenCountryGroupOfPreferentialOriginItemEqualsValue_ConditionAndDeclarationNotEqual_thenRouteNotReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.operator = "eq";
        condition.attribute = Conditions.countryGroupOfPreferentialOrigin_Item("CHIN").attribute;
        condition.value="CHIN";
        commitRuleAndPublish();
        declaration.subRole="2";
        declaration.countryGroupOfOrigin_Item = "CHN";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CR_3414.class})
    public void whenGoodsValuationHasPriceInfluenceEqualsValue_DeclarationNotEqualsCondition_thenRouteNotReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="eq";
        condition.attribute = Conditions.goodsValuationHasPriceInfluence().attribute;
        condition.value="0";
        commitRuleAndPublish();
        declaration.valuationIndicator = "1010";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CR_3414.class})
    public void whenGoodsValuationHasRestrictionsPresents_DeclarationDoesNotHaveCorrectValuationIndicatorFormat_thenRouteNotReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="pr";
        condition.attribute = Conditions.goodsValuationHasRestrictions().attribute;
        commitRuleAndPublish();
        declaration.valuationIndicator = "4568";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CR_3414.class})
    public void whenGoodsValuationHasSaleCondtionEqualsValue_DeclarationHaveTheSame_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="eq";
        condition.value="1";
        condition.attribute = Conditions.goodsValuationHasSaleCondition().attribute;
        commitRuleAndPublish();
        declaration.valuationIndicator = "0010";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3414.class})
    public void whenGoodsValuationHasFutureProceedsNotPresent_DeclarationHasDifferentValuationIndicationFormat_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="npr";
        condition.attribute = Conditions.goodsValuationHasFutureProceeds().attribute;
        commitRuleAndPublish();
        declaration.valuationIndicator = "9010";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }



  }
