package TestCases.UI.Users;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Users;
import Categories_CDSRisk.CDS_Risk_UI_Users_1;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.Pages.UserManagement.ListUsersByLocation_Page;
import UI.Utils.Navigation;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import java.util.List;
import static org.junit.Assert.assertEquals;


@Category({CDS_Risk_UI.class, CDS_Risk_UI_Users.class, CDS_Risk_UI_Users_1.class})
public class TestCase_BulkSuspendUsers extends BaseUIWebDriverTestCase {

    @Category({ChangeRequest.CR_1905.class})
    @Test
    public void WhenAdminBulkSuspendsTheUsers_UsersAreSuspendedSuccessfully(){

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminNational("1234510");
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        TestUserModel.UserDetails userDetailsSuperAdmin = Users_API.SuperAdminNational("1234511");
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsSuperAdmin);
        //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(Users_API.DefaultSuperAdminUser());

        Navigation utilNavigation = new Navigation(driver);
        ListUsersByLocation_Page listUsersByLocation_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsersByLocation);
        List<ListUsersByLocation_Page.UserListTableObject> userListTableObjects = listUsersByLocation_page.getListOfUsers();
        ListUsersByLocation_Page.UserListTableObject userListTableObjectAdmin = listUsersByLocation_page.getUserTableObjectFromUserListTableObject(userListTableObjects, userDetailsAdmin.getFullName());
        ListUsersByLocation_Page.UserListTableObject userListTableObjectSuperAdmin = listUsersByLocation_page.getUserTableObjectFromUserListTableObject(userListTableObjects, userDetailsSuperAdmin.getFullName());

        //Suspend the user
        listUsersByLocation_page.selectTheSuspendCheckBox(userListTableObjectAdmin.suspendUserCheckBox);
        listUsersByLocation_page.selectTheSuspendCheckBox(userListTableObjectSuperAdmin.suspendUserCheckBox);
        listUsersByLocation_page.clickSuspendButton();

        //Check confirm dialog box messages
        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        Assertions.assertThat(dialog_confirm.dialogConfirm.getText().contains("Reason To Suspend The User"));
        dialog_confirm.EnterReasonAndCloseDialogBox("Suspended Temporarily");
        Assertions.assertThat(dialog_confirm.dialogConfirm.getText().contains("Suspend was successful"));
        dialog_confirm.clickOKButton();

        //Get latest status and assert
        userListTableObjects = listUsersByLocation_page.getListOfUsers();
        userListTableObjectAdmin = listUsersByLocation_page.getUserTableObjectFromUserListTableObject(userListTableObjects, userDetailsAdmin.getFullName());
        userListTableObjectSuperAdmin = listUsersByLocation_page.getUserTableObjectFromUserListTableObject(userListTableObjects, userDetailsSuperAdmin.getFullName());

        assertEquals("Suspended", userListTableObjectAdmin.status);
        assertEquals("Suspended", userListTableObjectSuperAdmin.status);

    }
}
