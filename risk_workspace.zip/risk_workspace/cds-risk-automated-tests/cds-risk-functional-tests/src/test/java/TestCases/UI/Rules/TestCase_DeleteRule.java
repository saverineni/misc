package TestCases.UI.Rules;

import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.EditRule.EditRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.RuleAction.RuleActionResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Rules;
import Categories_CDSRisk.CDS_Risk_UI_Rules_2;
import Categories_CDSRisk.ChangeRequest;
import FunctionsLibrary.FileUtilities;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static API.RulesManagementService.Utils.RuleAtStatus.CreateArchivedRule;
import static API.RulesManagementService.Utils.RuleAtStatus.CreateSuspendedRule;
import static org.junit.Assert.*;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_2.class})
public class TestCase_DeleteRule extends BaseUIWebDriverTestCase{


    @Test
    @Category({ChangeRequest.CR_1575.class})
    public void WhenNationalRuleManagerLoggedIn_CanDeleteDraftRule()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page =  utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(createRuleResponse.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        boolean bDelete = ruleSummary_page.deleteDraft.isEnabled();
        assertEquals("Expect delete button to be enabled", true, bDelete);

        Dialog_Confirm dialog_confirm = ruleSummary_page.clickDeleteDraftButton();
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        //Assert
        ListRules_Page listRules_pageNew =  utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Note if there are no rules in database get message but if there is a rule need to check list of rules to see if rule is not present
        //boolean bNoRulesPresent = listRules_pageNew.isMessageNoRulesFoundPresent();
        boolean bNoRulesPresent = listRules_pageNew.isElementDisplayed(listRules_pageNew.noRulesFoundMessage,1, false);

        if (bNoRulesPresent == true)
        {
            assertEquals("Expect Rule to be NOT present in List", true, bNoRulesPresent);
        }
        else
        {
            assertEquals("Expect Rule to be NOT present in List", false, listRules_pageNew.isRulePresent(ruleDetails.description));
        }

    }


    @Test
    public void WhenRuleManagerLoggedIn_CanDeleteDraftVersionOfRule()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateDraftRuleVersion2Rule();
        ruleDetails.description = ruleResponse.description;

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        Dialog_Confirm dialog_confirm = ruleSummary_page.clickDeleteDraftButton();
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        //Assert
        ListRules_Page listRules_pageNew =  utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Note if there are no rules in database get message but if there is a rule need to check list of rules to see if rule is not present
        //boolean bNoRulesPresent = listRules_pageNew.isMessageNoRulesFoundPresent();
        boolean bNoRulesPresent = listRules_pageNew.isElementDisplayed(listRules_pageNew.noRulesFoundMessage,1, false);

        if (bNoRulesPresent == true)
        {
            assertEquals("Expect Rule to be NOT present in List", true, bNoRulesPresent);
        }
        else
        {
            assertEquals("Expect Rule to be NOT present in List", false, listRules_pageNew.isRulePresent(ruleDetails.description));
        }

    }


    @Test
    public void WhenRuleManagerLoggedIn_CanNOTDeleteCommittedRule()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();
        ruleDetails.description = ruleResponse.description;

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Assert
        boolean bDeleteEnabled = ruleSummary_page.isActionButtonPresent("Delete Rule");
        assertEquals("Expect delete button to be not present", false, bDeleteEnabled);
    }


    @Test
    public void WhenRuleManagerLoggedIn_CannotDeleteSuspendedRule()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse ruleResponse = CreateSuspendedRule(ruleDetails);
        ruleDetails.description = ruleResponse.description;

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);
        listRules_page.waitForAngularRequestsToFinish();

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Assert
        boolean bDeleteEnabled = ruleSummary_page.isActionButtonPresent("Delete Rule");
        assertEquals("Expect delete button to be not present", false, bDeleteEnabled);
    }


    @Test
    public void WhenRuleManagerLoggedIn_CanNOTDeleteArchivedRule()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse ruleResponse = CreateArchivedRule(ruleDetails);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Assert
        boolean bDeleteEnabled = ruleSummary_page.isActionButtonPresent("Delete Rule");
        assertEquals("Expect delete button to be not present", false, bDeleteEnabled);
    }


    @Test
    @Category(ChangeRequest.CR_1575.class)
    public void WhenRuleManagerDeletesRule_ConfirmationMessageAppears()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page =  utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(createRuleResponse.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Act
        Dialog_Confirm dialog_confirm = ruleSummary_page.clickDeleteDraftButton();
        String actText = dialog_confirm.getMessageText();

        //Assert
        assertEquals("Please enter a reason for deleting this rule", dialog_confirm.getMessageText(), actText);
        assertTrue("Expect OK button to be present", dialog_confirm.ok.isDisplayed());
        assertTrue("Expect Cancel button to be present", dialog_confirm.cancel.isDisplayed());
    }


    @Test
    @Category(ChangeRequest.CR_1575.class)
    public void WhenRuleManagerCancelsDeleteRule_ConfirmationMessageClosed()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page =  utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(createRuleResponse.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Act
        Dialog_Confirm dialog_confirm = ruleSummary_page.clickDeleteDraftButton();
        dialog_confirm.clickCancelButton();

        //Assert
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();

        assertEquals("Expect Rule Status to be draft", "Draft", listRuleSummaryTableObjects.get(0).status);
    }


    @Test
    @Category(ChangeRequest.CR_1880.class)
    public void AttemptToDeleteRuleWithoutInvalidReasons_DeleteButtonDisabled()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        ListRules_Page listRules_page =  utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(createRuleResponse.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Act
        Dialog_Confirm dialog_confirm = ruleSummary_page.clickDeleteDraftButton();
        dialog_confirm.EnterReasonAndCloseDialogBox("");


        //Assert
        assertFalse("Expect Delete button to be Disabled", dialog_confirm.ok.isEnabled());

        dialog_confirm.EnterReasonAndCloseDialogBox("Test");  //less than 5 chars
        assertFalse("Expect Delete button to be Disabled", dialog_confirm.ok.isEnabled());

        dialog_confirm.reason.setValue("Tests");
        assertTrue("Expect Delete button to be Enabled", dialog_confirm.ok.isEnabled());

        String reason60Chars = FileUtilities.GenerateRandomAlphaNumericString(60, true, true);
        dialog_confirm.EnterReasonAndCloseDialogBox(reason60Chars + "1");  //more than 60 chars
        assertFalse("Expect Delete button to be Disabled",dialog_confirm.ok.isEnabled());

    }

}
