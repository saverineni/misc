package TestCases.UI.Rules;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.*;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.DataForTests.TestRuleModel;
import UI.ElementControls.MultiSelectDropDown;
import UI.Pages.RulesManagement.CreateNationalRule_Page;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleDetails_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.assertj.core.api.Assertions;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static API.RulesManagementService.Utils.Publish.setPublishAutomaticEventTime;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_1.class})
public class TestCase_CreateNationalRule extends BaseUIWebDriverTestCase{

    @Category(SmokeTests_UI.class)
    @Test
    public void WhenNationalRuleManagerLoggedIn_CanCreateNationalRule(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateNationalRule_Page createNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateNationalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftNATRule();


        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalRuleSingleCondition(ruleDetails);

        createNationalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }

    @Test
    @Category({ChangeRequest.CR_2739.class,ChangeRequest.CR_2742.class})
    @Ignore("Will be fixed as part of CR-3062,CR-3072")
    public void WhenNationalRuleSaved_CorrectViewRuleDetailsDisplayed(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateNationalRule_Page createNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateNationalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftNATRule();
        ruleDetails.secretTask = true;
        ruleDetails.addInformationTask=true;
        ruleDetails.standaloneInfoNarrative = "Test Standalone Narrative Text for";
        ruleDetails.assigneeID = "NCH Documentary Checks – Imports";
        ruleDetails.emailDomainType = TestRuleModel.RuleDetails.EmailDomainType.Digital;
        // ruleDetails.timeToClose="1200";  This will be reinstated in future


        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalRuleSingleCondition(ruleDetails);

        createNationalRule_page.enterEmailUsername("test.user");
        createNationalRule_page.clickSaveAndCommitWithDefaultReason();

        //Act
        RuleSummary_Page ruleSummary_page = createNationalRule_page.clickViewRule();
        List<RuleSummary_Page.RuleSummaryTableObject> ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        ruleSummaryTableObjects.get(0).versionDetailAction.click();

        //Assert
        RuleDetails_Page ruleDetails_page = new RuleDetails_Page(driver);
        ruleDetails_page.assertRuleDetailsNationalRule(ruleDetails, userDetailsRM);
    }

    @Category(ChangeRequest.CR_3076.class)
    @Test
    public void WhenNationalRuleManagerLoggedIn_CannotCreateNationalRuleWithBlankReason(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateNationalRule_Page createNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateNationalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftNATRule();

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalRuleSingleCondition(ruleDetails);

        createNationalRule_page.clickSaveAndCommitWithReason("        ");

        //Assert
        String actMessage = createNationalRule_page.getErrorMessage();
        assertEquals("Pattern must match ^.*\\S.*$", actMessage);
    }

    @Category(ChangeRequest.CR_1237.class)
    @Test
    public void WhenNationalRuleManagerCreatesNationalRule_GoodsLocationsShouldContainsAllFreightLocations(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        //Act
        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateNationalRule_Page createNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateNationalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftNATRule();

        //Assert
        List<String> goodsLocationList = createNationalRule_page.getGoodsLocationList("All");
        assertThat(goodsLocationList).doesNotContain("National Office");
        assertThat(goodsLocationList).contains("All freight locations");
    }


    @Category(ChangeRequest.CR_1104.class)
    @Test
    public void WhenNationalRuleManagerLoggedIn_SupplementarySubTypeOptionPresentForFullRuleAfterDeclarationTypeSet(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        CreateNationalRule_Page createNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateNationalRule);

        createNationalRule_page.selectDeclarationType("Imports");
        List<String> actDeclarationSubTypes = createNationalRule_page.getDeclarationSubTypeList();

        String[] myArray = {"Normal (A)",
                "Simplified Occasional (B)",
                "Simplified Regular (C)",
                "Advance (D)",
                "Advance Simplified Occasional (E)",
                "Advance Simplified Regular (F)",
                "Supplemented Occasional (X)",
                "Supplemented Regular (Y)",
                "Local Clearance (Z)"};
        //Assert
        Assertions.assertThat(actDeclarationSubTypes).containsOnly(myArray);
    }

    
    @Category({ChangeRequest.CR_1636.class, ChangeRequest.CR_3278.class})
    @Test
    public void WhenNationalRuleManagerLoggedIn_CanCreateRatsNationalRule(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateNationalRule_Page createNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateNationalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftNatRatsRule();

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalRuleSingleCondition(ruleDetails);

        createNationalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }



    @Test
    @Category(ChangeRequest.CR_2977.class)
    public void WhenRuleManagerLoggedIn_CanAddLocationsAndEditInAmendPage() {

        //Arrange
        ArrayList<String> locations = new ArrayList<String>(Arrays.asList("BHX - Birmingham Airport","LBA - Leeds Bradford Airport"));
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateNationalRule_Page createNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateNationalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftNATRule();

        //Act
        //Create a rule with Goods Location as "All Freight Locations"
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalRuleSingleCondition(ruleDetails);
        createNationalRule_page.clickSaveAndCommitWithDefaultReason();
        createNationalRule_page.waitForAngularRequestsToFinish();

        //Should be "all locations" in rule summary page and then amend the rule
        RuleSummary_Page ruleSummary_page = createNationalRule_page.clickViewRule();
        List<RuleSummary_Page.RuleSummaryTableObject> ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        ruleSummaryTableObjects.get(0).versionDetailAction.click();
        ruleSummary_page.waitForAngularRequestsToFinish();

        String allLocations = createNationalRule_page.ruleGoodsLocation.getText();
        ruleSummary_page.scrollToViewTheElement(ruleSummary_page.amendInRuleDetail);
        ruleSummary_page.amendInRuleDetail.click();
        ruleSummary_page.waitForAngularRequestsToFinish();

        //Select Birmingham and Leeds location
        MultiSelectDropDown dropDown = new MultiSelectDropDown(driver);
        createNationalRule_page.scrollToViewTheElement(createNationalRule_page.transportModes);
        createNationalRule_page.selectTransportMode("Air");
        createNationalRule_page.goodsLocationList.click();
        dropDown.selectMultipleValues(createNationalRule_page.airBaseLocations,locations);
        createNationalRule_page.clickSaveAndCommitWithDefaultReason();
        createNationalRule_page.waitForAngularRequestsToFinish();

        publishAndWait(8000);

        ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        ruleSummaryTableObjects.get(0).versionDetailAction.click();
        ruleSummary_page.waitForAngularRequestsToFinish();

        //Assert
        Assertions.assertThat(createNationalRule_page.ruleGoodsLocation.getText()).contains("BHX");
        Assertions.assertThat(createNationalRule_page.ruleGoodsLocation.getText()).contains("LBA");
    }

    @Test
    @Category({ChangeRequest.CR_3067.class})
    public void WhenNationalRuleSavedWithPhysicalCheckAndInformationTask_CorrectViewRuleDetailsDisplayed(){

        //Arrange
        String timeInSeconds="300";
        TestUserModel.UserDetails superAdminUser = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(superAdminUser);
        setPublishAutomaticEventTime(timeInSeconds, superAdminUser.pid);

        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateNationalRule_Page createNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateNationalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftNATRule();
        ruleDetails.secretTask = true;
        ruleDetails.addInformationTask=true;
        ruleDetails.standaloneInfoNarrative = "Test Standalone Narrative Text for";
        ruleDetails.assigneeID = "BF Import";
        ruleDetails.emailDomainType = TestRuleModel.RuleDetails.EmailDomainType.Gsi;
        ruleDetails.emailSubDomain="user";
        ruleDetails.emailUser="test";

        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalRuleSingleCondition(ruleDetails);

        createNationalRule_page.enterEmailUsername("test");
        createNationalRule_page.enterEmailSubDomain("user");
        createNationalRule_page.clickSaveAndCommitWithDefaultReason();

        //Act
        RuleSummary_Page ruleSummary_page = createNationalRule_page.clickViewRule();
        List<RuleSummary_Page.RuleSummaryTableObject> ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        ruleSummaryTableObjects.get(0).versionDetailAction.click();

        //Assert
        RuleDetails_Page ruleDetails_page = new RuleDetails_Page(driver);
        ruleDetails_page.assertRuleDetailsNationalRule(ruleDetails, userDetailsRM);
    }

    @Test
    public void WhenNationalRuleManagerLoggedIn_CanCreateNationalRuleWithALVSActionType(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateNationalRule_Page createNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateNationalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftNATRule();
        ruleDetails.actionType = TestRuleModel.RuleDetails.ActionType.ALVS;
        ruleDetails.holdNarrative = null;
        ruleDetails.useRats = false;
        ruleDetails.assigneeID = null;
        ruleDetails.departmentCode = "testDC";
        ruleDetails.checkCode = "testCC";

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalRuleSingleCondition(ruleDetails);

        createNationalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }
}
