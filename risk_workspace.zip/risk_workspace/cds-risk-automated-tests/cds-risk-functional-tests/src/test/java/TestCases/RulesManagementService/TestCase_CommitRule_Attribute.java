package TestCases.RulesManagementService;

import API.DataForTests.Conditions;
import API.DataForTests.TestRuleModel;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import Categories_CDSRisk.CDS_RM_RuleLifeCycle;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertEquals;


@Category({Rules_Management.class, CDS_RM_RuleLifeCycle.class})
@RunWith(JUnitParamsRunner.class)
public class TestCase_CommitRule_Attribute extends BaseWebAPITestCase {


    @Test
    @Category({ChangeRequest.CR_1366.class, ChangeRequest.CR_1582.class, ChangeRequest.CR_1487.class, ChangeRequest.CR_1643.class})
    @Parameters(method = "singleDataDomainConditionTestData")
    public void WhenRuleCommittedWithSingleDataDomainAttribute_RuleStatusSetToCommitted(String testName, SingleCondition testData) throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        //Act
        EditRuleVersionResponse.PutResponse response = createCommittedRuleWithSingleCondition(ruleDetails, testData.condition);

        //Assert
        assertEquals("committed", response.status);
    }

    @Test
    @Category({ChangeRequest.CR_1366.class, ChangeRequest.CR_1582.class, ChangeRequest.CR_1487.class, ChangeRequest.CR_1643.class})
    @Parameters(method = "singleHeaderConditionTestData")
    public void WhenRuleCommittedWithSingleHeaderAttribute_RuleStatusSetToCommitted(String testName, SingleCondition testData) throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        //Act
        EditRuleVersionResponse.PutResponse response = createCommittedRuleWithSingleCondition(ruleDetails, testData.condition);

        //Assert
        assertEquals("committed", response.status);
    }


    @Test
    @Category({ChangeRequest.CR_1366.class, ChangeRequest.CR_1582.class, ChangeRequest.CR_1487.class, ChangeRequest.CR_1643.class})
    @Parameters(method = "singleItemConditionTestData")
    public void WhenRuleCommittedWithSingleItemAttribute_RuleStatusSetToCommitted(String testName, SingleCondition testData) throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        //Act
        EditRuleVersionResponse.PutResponse response = createCommittedRuleWithSingleCondition(ruleDetails, testData.condition);

        //Assert
        assertEquals("committed", response.status);
    }


    @Test
    @Category({ChangeRequest.CR_2770.class, ChangeRequest.CR_2782.class})
    @Parameters(method = "singleCollectionConditionTestData")
    public void WhenRuleCommittedWithSingleCollectionAttribute_RuleStatusSetToCommitted(String testName, SingleCondition testData) throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        //Act
        EditRuleVersionResponse.PutResponse response = createCommittedRuleWithSingleCondition(ruleDetails, testData.condition);

        //Assert
        assertEquals("committed", response.status);
    }



    public EditRuleVersionResponse.PutResponse createCommittedRuleWithSingleCondition(TestRuleModel.RuleDetails ruleDetails, TestRuleModel.RuleDetails.Condition condition){

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        EditRuleVersionResponse.PutResponse response = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        return response;
    }

    private class SingleCondition{

        public TestRuleModel.RuleDetails.Condition condition;

        public SingleCondition(TestRuleModel.RuleDetails.Condition condition)
        {
            this.condition = condition;
        }

    }

    private Object[] singleDataDomainConditionTestData()
    {

        return new Object[]{

                //Domain Level Fields
                new Object[]{"country", new SingleCondition(Conditions.country())},
                new Object[]{"dispatchCountry_domain", new SingleCondition(Conditions.dispatchCountry_domain())},
                new Object[]{"eori", new SingleCondition(Conditions.eori())},
                new Object[]{"destinationCountry_Header", new SingleCondition(Conditions.destinationCountry_domain())},
                new Object[]{"consignorCountry_Header", new SingleCondition(Conditions.consignorCountry_domain())},
                new Object[]{"consignorCity_domain", new SingleCondition(Conditions.consignorCity_domain())},
                new Object[]{"consignorName_domain", new SingleCondition(Conditions.consignorName_domain())},
                new Object[]{"consignorAddress_domain", new SingleCondition(Conditions.consignorAddress_domain())}
        };
    }

    private Object[] singleHeaderConditionTestData()
    {

        return new Object[]{

//              //Header Level fields

                //NEW

                //-----------------------------
                new Object[]{"consigneeAddress", new SingleCondition(Conditions.consigneeAddress())},
                new Object[]{"consigneeCity", new SingleCondition(Conditions.consigneeCity())},
                new Object[]{"consigneeCountry", new SingleCondition(Conditions.consigneeCountry())},
                new Object[]{"consigneeEori", new SingleCondition(Conditions.consigneeEori())},
                new Object[]{"consigneeName", new SingleCondition(Conditions.consigneeName())},
                new Object[]{"consigneePostcode", new SingleCondition(Conditions.consigneePostcode())},

                new Object[]{"consignorAddress_Header", new SingleCondition(Conditions.consignorAddress_Header())},
                new Object[]{"consignorCity_Header", new SingleCondition(Conditions.consignorCity_Header())},
                new Object[]{"consignorCountry_Header", new SingleCondition(Conditions.consignorCountry_Header())},
                new Object[]{"consignorEori_Header", new SingleCondition(Conditions.consignorEori_Header())},
                new Object[]{"consignorName_Header", new SingleCondition(Conditions.consignorName_Header())},
                new Object[]{"consignorPostcode_Header", new SingleCondition(Conditions.consignorPostcode_Header())},

                new Object[]{"consignmentReference", new SingleCondition(Conditions.consignmentReference())},
                new Object[]{"customsValue_Header", new SingleCondition(Conditions.customsValue_Header())},

                new Object[]{"declarantCountry", new SingleCondition(Conditions.declarantCountry())},
                new Object[]{"declarantName", new SingleCondition(Conditions.declarantName())},
                new Object[]{"declarantPostCode", new SingleCondition(Conditions.declarantPostcode())},
                new Object[]{"declarantAddress", new SingleCondition(Conditions.declarantAddress())},
                new Object[]{"declarantCity", new SingleCondition(Conditions.declarantCity())},
                new Object[]{"declarantEORI", new SingleCondition(Conditions.declarantEori())}, //traderID is now Declarant EORI

                new Object[]{"dispatchCountry_Header", new SingleCondition(Conditions.dispatchCountry())},
                new Object[]{"destinationCountry", new SingleCondition(Conditions.destinationCountry_Header())},

                new Object[]{"declaredCustomsValue_Header", new SingleCondition(Conditions.declaredCustomsValue_Header())},
                new Object[]{"dutyChargeValue", new SingleCondition(Conditions.dutyChargeValue())},

                new Object[]{"exitOffice", new SingleCondition(Conditions.officeOfExit())},

                new Object[]{"freightCharge", new SingleCondition(Conditions.freightCharge())},
                new Object[]{"freightChargeCurrency", new SingleCondition(Conditions.freightChargeCurrency())},

                new Object[]{"goodsArrivalIndicator", new SingleCondition(Conditions.goodsArrivalIndicator())},

                new Object[]{"invoiceCurrency_Header", new SingleCondition(Conditions.invoiceCurrency_Header())},
                new Object[]{"invoiceTotal_Header", new SingleCondition(Conditions.invoiceTotal_Header())},
                new Object[]{"itemCount", new SingleCondition(Conditions.itemCount())},
                new Object[]{"inlandModeOfTransport", new SingleCondition(Conditions.inlandModeOfTransport())},

                new Object[]{"modeOfEntry", new SingleCondition(Conditions.modeOfEntry())},

                new Object[]{"payingAgentEori", new SingleCondition(Conditions.payingAgentEori())},
                new Object[]{"packageCount_Header", new SingleCondition(Conditions.packageCount_Header())},

                new Object[]{"representativeCity", new SingleCondition(Conditions.representativeCity())},
                new Object[]{"representativeCountry", new SingleCondition(Conditions.representativeCountry())},
                new Object[]{"representativeEori", new SingleCondition(Conditions.representativeEori())},
                new Object[]{"representativeName", new SingleCondition(Conditions.representativeName())},
                new Object[]{"representativeAddress", new SingleCondition(Conditions.representativeAddress())},
                new Object[]{"representativePostcode", new SingleCondition(Conditions.representativePostcode())},
                new Object[]{"representativeFunction", new SingleCondition(Conditions.representativeFunction())},

                new Object[]{"specificCircumstance", new SingleCondition(Conditions.specificCircumstance())},
                new Object[]{"supervisingOfficeEori", new SingleCondition(Conditions.supervisingOfficeEori())},

                new Object[]{"totalGrossMass_Header", new SingleCondition(Conditions.totalGrossMass_Header())},
                new Object[]{"tradersOwnReference", new SingleCondition(Conditions.tradersOwnReference())},
                new Object[]{"transportCountry", new SingleCondition(Conditions.transportCountry())},
                new Object[]{"transportIdentifier", new SingleCondition(Conditions.transportIdentifier())},
                new Object[]{"transportMOP", new SingleCondition(Conditions.transportMOP())},
                new Object[]{"totalRevenue", new SingleCondition(Conditions.totalRevenue())},
                new Object[]{"totalVat", new SingleCondition(Conditions.totalVat())},

                new Object[]{"uniqueConsignmentReference", new SingleCondition(Conditions.uniqueConsignmentReference())},

                new Object[]{"goodsLocationID_Header", new SingleCondition(Conditions.goodsLocationID())},
                new Object[]{"goodsLocationName_Header", new SingleCondition(Conditions.goodsLocationName())},
                new Object[]{"goodsLocationAddress_Header", new SingleCondition(Conditions.goodsLocationAddress())},
                new Object[]{"goodsLocationCity_Header", new SingleCondition(Conditions.goodsLocationCity())},
                new Object[]{"goodsLocationCountry_Header", new SingleCondition(Conditions.goodsLocationCountry())},
                new Object[]{"goodsLocationPostcode_Header", new SingleCondition(Conditions.goodsLocationPostcode())}
         };
    }

    private Object[] singleItemConditionTestData()
    {

        return new Object[]{


                //new
                new Object[]{"preferentialOriginCountry", new SingleCondition(Conditions.preferentialOriginCountry())},


                new Object[]{"unDangerousGoodsCode", new SingleCondition(Conditions.unDangerousGoodsCode())},


                new Object[]{"customsValuePerQuantity", new SingleCondition(Conditions.customsValuePerQuantity())},

                 new Object[]{"taxAmountSum", new SingleCondition(Conditions.taxAmountSum())},
                new Object[]{"taxRevenueSum", new SingleCondition(Conditions.taxRevenueSum())},


                //Not Doing fields for now future story
                ////new Object[]{"supervisingOfficeName", new SingleCondition(Conditions.supervisingOfficeName())},
                ////TODO//                new Object[]{"modeOfTransport", new SingleCondition(Conditions.modeOfTransport())},


//               // Item Level fields
                new Object[]{"commodityCode", new SingleCondition(Conditions.commodityCode())},
                new Object[]{"customsValue", new SingleCondition(Conditions.customsValue())},
                new Object[]{"CPC", new SingleCondition(Conditions.customsProcedureCode())},


                new Object[]{"consigneeAddress_Item", new SingleCondition(Conditions.consigneeAddress_Item())},
                new Object[]{"consigneeCity_Item", new SingleCondition(Conditions.consigneeCity_Item())},
                new Object[]{"consigneeCountry_Item", new SingleCondition(Conditions.consigneeCountry_Item())},
                new Object[]{"consigneeEori_Item", new SingleCondition(Conditions.consigneeEori_Item())},
                new Object[]{"consigneeName_Item", new SingleCondition(Conditions.consigneeName_Item())},
                new Object[]{"consigneePostcode_Item", new SingleCondition(Conditions.consigneePostcode_Item())},

                new Object[]{"consignorAddress_Item", new SingleCondition(Conditions.exporterConsignorAddress_Item())},
                new Object[]{"consignorCity_Item", new SingleCondition(Conditions.exporterConsignorCity_Item())},
                new Object[]{"consignorCountry_Item", new SingleCondition(Conditions.exporterConsignorCountry_Item())},
                new Object[]{"consignorEori_Item", new SingleCondition(Conditions.exporterConsignorEori_Item())},
                new Object[]{"consignorName_Item", new SingleCondition(Conditions.exporterConsignorName_Item())},
                new Object[]{"consignorPostcode_Item", new SingleCondition(Conditions.exporterConsignorPostcode_Item())},

                new Object[]{"dispatchCountry_Item", new SingleCondition(Conditions.dispatchCountry_Item())},

                new Object[]{"declaredCustomsValue", new SingleCondition(Conditions.declaredCustomsValue())},

                new Object[]{"goodsDescription", new SingleCondition(Conditions.goodsDescription())},
                new Object[]{"commodityGrossMass", new SingleCondition(Conditions.commodityGrossMass())},

                new Object[]{"invoicePriceItem", new SingleCondition(Conditions.invoicePrice())},

                new Object[]{"originCountry_Item", new SingleCondition(Conditions.originCountry_Item())}, //country code is now originCountry

                new Object[]{"statisticalValue", new SingleCondition(Conditions.statisticalValue())},
                new Object[]{"supplementaryUnits", new SingleCondition(Conditions.supplementaryUnits())},

                new Object[]{"valuationMethodCode", new SingleCondition(Conditions.valuationMethodCode())},

        };
    }

    private Object[] singleCollectionConditionTestData()
    {

        return new Object[]{

                //Header
                new Object[]{"containersCode_HeaderCollections", new SingleCondition(Conditions.containersCode_HeaderCollections())},
                new Object[]{"sealId_HeaderCollections", new SingleCondition(Conditions.sealId_HeaderCollections())},
                new Object[]{"countryRoute_HeaderCollections", new SingleCondition(Conditions.countryRoute_HeaderCollections())},

                new Object[]{"additionalInformation_TextHeader", new SingleCondition(Conditions.additionalInfoText_HeaderCollections())},
                new Object[]{"additionalDocuments_TypeHeader", new SingleCondition(Conditions.additionalDocumentsType_HeaderCollections())},

                 //Item
                new Object[]{"additionalInformation_CodeItem", new SingleCondition(Conditions.additionalInfoCode_ItemCollections())},
                new Object[]{"additionalInformation_TextItem", new SingleCondition(Conditions.additionalInfoText_ItemCollections())},
                new Object[]{"additionalDocuments_TypeItem", new SingleCondition(Conditions.additionalDocumentsType_ItemCollections())},

                new Object[]{"valuationAdjustments_CodeItem", new SingleCondition(Conditions.valuationAdjustments_CodeItemCollection())},
                new Object[]{"containers_IdItem", new SingleCondition(Conditions.containers_IdItemCollection())},
                new Object[]{"declaredDutyTaxFees_BaseAmountItem", new SingleCondition(Conditions.declaredDutyTaxFees_BaseAmountItemCollection())},
                new Object[]{"declaredDutyTaxFees_BaseQuantityItem", new SingleCondition(Conditions.declaredDutyTaxFees_BaseQuantityItemCollection())},
                new Object[]{"declaredDutyTaxFees_PaymentMethodItem", new SingleCondition(Conditions.declaredDutyTaxFees_PaymentMethodItemCollection())},
                new Object[]{"declaredDutyTaxFees_PercentageAdjustmentItem", new SingleCondition(Conditions.declaredDutyTaxFees_PercentageAdjustmentItemCollection())},
                new Object[]{"declaredDutyTaxFees_PreferenceCodeItem", new SingleCondition(Conditions.declaredDutyTaxFees_PreferenceCodeItemCollection())},
                new Object[]{"declaredDutyTaxFees_QuotaCodeItem", new SingleCondition(Conditions.declaredDutyTaxFees_QuotaCodeItemCollection())},
                new Object[]{"declaredDutyTaxFees_TaxAmountItem", new SingleCondition(Conditions.declaredDutyTaxFees_TaxAmountItemCollection())},
                new Object[]{"declaredDutyTaxFees_TaxRevenueItem", new SingleCondition(Conditions.declaredDutyTaxFees_TaxRevenueItemCollection())},
                new Object[]{"declaredDutyTaxFees_TaxTypeItem", new SingleCondition(Conditions.declaredDutyTaxFees_TaxTypeItemCollection())},
                new Object[]{"declaredDutyTaxFees_VatValueItem", new SingleCondition(Conditions.declaredDutyTaxFees_VatValueItemCollection())},

                new Object[]{"additionalInformation_LanguageItem", new SingleCondition(Conditions.additionalInformation_LanguageItemCollection())},
                new Object[]{"additionalDocuments_IdItem", new SingleCondition(Conditions.additionalDocuments_IdItemCollection())},
                new Object[]{"additionalDocuments_QuantityItem", new SingleCondition(Conditions.additionalDocuments_QuantityItemCollection())},
                new Object[]{"previousDocuments_ClassItem", new SingleCondition(Conditions.previousDocuments_ClassItemCollection())},
                new Object[]{"previousDocuments_IdItem", new SingleCondition(Conditions.previousDocuments_IdItemCollection())},
                new Object[]{"previousDocuments_TypeItem", new SingleCondition(Conditions.previousDocuments_TypeItemCollection())},

        };
    }

}
