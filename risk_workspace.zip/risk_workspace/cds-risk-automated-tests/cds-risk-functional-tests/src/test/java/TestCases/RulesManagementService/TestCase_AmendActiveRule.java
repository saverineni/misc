package TestCases.RulesManagementService;


import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.RulesManagementService.EditRule.EditRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.RuleAction.RuleActionResponse;
import API.RulesManagementService.ViewRule.ViewRuleResponse;
import API.RulesManagementService.ViewRuleVersion.ViewRuleVersionResponse;
import Categories_CDSRisk.CDS_RM_RuleLifeCycle;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import org.apache.http.HttpStatus;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import static API.RulesManagementService.Utils.RuleAtStatus.ArchiveRule;
import static API.RulesManagementService.Utils.RuleAtStatus.SuspendRule;
import static org.junit.Assert.assertEquals;


@Category({Rules_Management.class, CDS_RM_RuleLifeCycle.class})
public class TestCase_AmendActiveRule extends BaseWebAPITestCase {

    @Test
    @Category(ChangeRequest.CR_339.class)
    public void WhenLiveRuleEdited_NewVersionCreatedOriginalVersionCommitted() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();

        //Act
        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        ruleDetailsV2.uniqueID = committedRuleResponse.uniqueId;
        EditRuleResponse.PutResponse editResponse = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetailsV2);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject ruleVersion1Response =
                API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(committedRuleResponse.uniqueId, 1);
        //Assert
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), ruleVersion1Response.status);
        assertEquals(2, editResponse.versionId);
        assertEquals(TestEnumerators.RuleStatus.draft.toString(), editResponse.status);
        assertEquals(committedRuleResponse.ruleId, editResponse.ruleId);
    }


    @Test
    @Category(ChangeRequest.CR_339.class)
    public void WhenLiveRuleEditedAndNewDraftSaved_NewDraftCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleResponse.PutResponse draftV2Rule = API.RulesManagementService.Utils.RuleAtStatus.CreateDraftRuleFromCommittedRule();
        ruleDetails.uniqueID = draftV2Rule.uniqueId;

        //Act
        TestRuleModel.RuleDetails ruleDetailsV3 = API.DataForTests.Rules.DraftVersion3NatRuleNatManager();
        ruleDetailsV3.uniqueID = draftV2Rule.uniqueId;
        EditRuleResponse.PutResponse editResponse3 = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetailsV3);

        //Assert
        assertEquals(3, editResponse3.versionId);
        assertEquals(TestEnumerators.RuleStatus.draft.toString(), editResponse3.status);
    }


    @Test
    @Category(ChangeRequest.CR_339.class)
    public void EditLiveRuleAndAttemptToSuspend_NewDraftCanBeSuspended() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleResponse.PutResponse draftV2Rule = API.RulesManagementService.Utils.RuleAtStatus.CreateDraftRuleFromCommittedRule();
        ruleDetails.uniqueID = draftV2Rule.uniqueId;
        ruleDetails.version = 2;

        //Act
        RuleActionResponse.PostResponse suspendResponse = SuspendRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_OK, suspendResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_349.class)
    public void EditLiveRuleAndAttemptToArchive_NewDraftCanBeArchived() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleResponse.PutResponse draftV2Rule = API.RulesManagementService.Utils.RuleAtStatus.CreateDraftRuleFromCommittedRule();
        ruleDetails.uniqueID = draftV2Rule.uniqueId;
        ruleDetails.version = 2;

        //Act
        RuleActionResponse.PostResponse archiveResponse = ArchiveRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_OK, archiveResponse.httpStatusCode);
    }


    //Note This test needs to be updated after CR-2191 implemented to:
    //WhenEditedLiveRuleCommitted_NewVersionCommittedOriginalVersionCancelled
    //WhenEditedLiveRuleCommitted_NewVersionCommittedOriginalVersionArchived
    @Test
    @Category({ChangeRequest.CR_348.class, ChangeRequest.CR_349.class})
    public void WhenEditedLiveRuleCommitted_NewVersionCommittedOriginalVersionCancelled()
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleResponse.PutResponse draftV2Rule = API.RulesManagementService.Utils.RuleAtStatus.CreateDraftRuleFromCommittedRule();
        ruleDetails.uniqueID = draftV2Rule.uniqueId;

        //Act
        ruleDetails.version = 2;
        EditRuleVersionResponse.PutResponse commitResponseV2 = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject ruleVersion1Response =
                API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(ruleDetails.uniqueID, 1);

        //Assert
        assertEquals("Expected Version: 2", 2, commitResponseV2.versionId);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponseV2.status);

        //TODO Update when CR-2191 implemented
        //assertEquals("Cancelled", ruleVersion1Response.status);
    }


    @Test
    @Category(ChangeRequest.CR_348.class)
    public void WhenEditedLiveRuleCommitted_LatestRuleCommittedInRuleSummary() throws Throwable
    {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleResponse.PutResponse draftV2Rule = API.RulesManagementService.Utils.RuleAtStatus.CreateDraftRuleFromCommittedRule();
        ruleDetails.uniqueID = draftV2Rule.uniqueId;

        //Act
        ruleDetails.version = 2;
        EditRuleVersionResponse.PutResponse commitResponseV2 = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponseObject  =
                API.RulesManagementService.Utils.Rules.GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals("Expected Version: 2", 2, commitResponseV2.versionId);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponseV2.status);

        assertEquals("Expected 2 Version: ", 2, viewRuleResponseObject.versions.size());
        assertEquals(2, viewRuleResponseObject.versions.get(0).versionId);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), viewRuleResponseObject.versions.get(0).status);
    }

}
