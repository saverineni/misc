package TestCases.DARService;

import API.DataForTests.TestEnumerators;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.DAR_Client;
import TestCases.RiskingServiceJava.BaseRiskingServiceJava;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.*;
import uk.gov.hmrc.risk.test.common.model.darService.DarDeclarationRiskedEventModel;
import uk.gov.hmrc.risk.test.common.model.darService.DarDeclarationRiskedModel;
import uk.gov.hmrc.risk.test.common.model.darService.DarRuleBehavioursModel;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel.Query;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel.RuleOutputs;

import java.time.ZonedDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static API.DataForTests.TestEnumerators.RuleOutputs.ALVS;

@Slf4j
@Category(DAR_Client.class)
public class TestCase_IsALVSRuleCorrectlyWrittenAndRisked extends BaseRiskingServiceJava{

    String ruleId;
    String declarationID;
    private String checkCode="HH224";
    private String deptCode="RN1234";


    @Test
    @Category({ChangeRequest.CR_3383.class,ChangeRequest.CR_3386.class})
    public void WhenALVSRuleIsPublished_CorrectDarFilesAreGenerated() {

        ruleId = createRule();
        assertRuleBehavioursFile();

    }
    @Test
    @Category({ChangeRequest.CR_3383.class,ChangeRequest.CR_3386.class})
    public void WhenALVSRuleIsHit_CorrectDarFilesAreGenerated() {

        ruleId = createRule();
        DeclarationResponse declarationResponse = getDeclarationResponse();
        assertDeclarationRisked(declarationResponse.getResponseId());
        assertDeclarationRiskedEvent(declarationResponse.getResponseId());

    }

    private String createRule() {
        CreateRuleModel model = createRuleModel();
        model.setBaseLocation(null);
        model.setStartDateTime(null);
        model.setRuleOutputs(RuleOutputs.builder()
                 .actionType(TestEnumerators.RuleOutputs.ALVS.actionType)
                .alvsDepartmentCode(deptCode)
                .alvsCheckCode(checkCode)
                .secretTask(false)
                .build()
        );
        model.getQuery().get(0).setQuery(Arrays.asList(
                Query.builder()
                        .attribute(HeaderDeclarationParam.CONSIGNEE_NAME.toString())
                        .conditionType(ConditionType.normal.toString())
                        .operator(Operator.eq.toString())
                        .value("cons name")
                        .build()
                )
        );
        return createAndRefreshRule(model);
    }

    private DeclarationResponse getDeclarationResponse() {

        declarationID = UUID.randomUUID().toString();
        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_REFERENCE, declarationID);
        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNEE_NAME, "cons name");
        return createAndSendDeclaration(declarationFieldValues);

    }

    private void assertDeclarationRiskedEvent(String responseId) {
        List<DarDeclarationRiskedEventModel> filtered = darServiceAuditSupport.parseDeclarationRiskedEvent()
                .stream().filter(log -> log.getResponseId().equals(responseId))
                .collect(Collectors.toList());

        Assertions.assertThat(filtered.size()).isNotZero();

        DarDeclarationRiskedEventModel alvsEvent = filtered.get(0);
        Assertions.assertThat(alvsEvent.getActionControlType()).isEqualTo(ALVS.toString());
        Assertions.assertThat(alvsEvent.getRuleControlType()).isEqualTo(ALVS.toString());
        Assertions.assertThat(alvsEvent.getCheckCode()).isEqualTo(this.checkCode);
        Assertions.assertThat(alvsEvent.getDeptCode()).isEqualTo(this.deptCode);
    }

    private void assertDeclarationRisked(String responseId) {
        List<DarDeclarationRiskedModel> filtered = darServiceAuditSupport.parseDeclarationRisk()
                .stream().filter(log -> log.getDeclarationId().equals(declarationID))
                .collect(Collectors.toList());
        Assertions.assertThat(filtered.size()).isNotZero();

        filtered.forEach(log ->
        {
            ZonedDateTime time = darServiceAuditSupport.getFormattedTimestamp(log.getEventTime());
            Assertions.assertThat(time).isBeforeOrEqualTo(ZonedDateTime.now().plusHours(2));
            Assertions.assertThat(log.getType()).isEqualTo(DarEventType.DECLARATION_RISKED.toString());
            Assertions.assertThat(log.getResponseId()).isEqualTo(responseId);
            Assertions.assertThat(log.getRulesPackage()).isNotEmpty();
            Assertions.assertThat(log.getNumberOfResults()).isEqualTo("1");
        });

    }

    private void assertRuleBehavioursFile() {
        List<DarRuleBehavioursModel> filtered = darServicePublishingSupport.parseRuleBehavioursEvents()
                .stream().filter(
                        model -> matchFileListingsBasedPackageId(model.getRuleUuid()))
                .collect(Collectors.toList());

        Assertions.assertThat(filtered.size()).isEqualTo(1);

        List<String> checkCode = filtered.stream()
                .map(DarRuleBehavioursModel::getCheckCode)
                .collect(Collectors.toList());
        Assertions.assertThat(checkCode).containsOnly(this.checkCode);

        List<String> actionTypes = filtered.stream()
                .map(DarRuleBehavioursModel::getDarActionType)
                .collect(Collectors.toList());
        Assertions.assertThat(actionTypes).containsOnly("ALVS:HOLD");


        List<String> deptCode = filtered.stream()
                .map(DarRuleBehavioursModel::getDepCode)
                .collect(Collectors.toList());
        Assertions.assertThat(deptCode).containsOnly(this.deptCode);

    }


    private boolean matchFileListingsBasedPackageId(String ruleId) {
        return ruleId.equals(this.ruleId);
    }
}
