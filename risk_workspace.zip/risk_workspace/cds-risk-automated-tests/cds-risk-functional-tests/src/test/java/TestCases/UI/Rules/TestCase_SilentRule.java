package TestCases.UI.Rules;

import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Rules;
import Categories_CDSRisk.CDS_Risk_UI_Rules_1;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_1.class})
public class TestCase_SilentRule extends BaseUIWebDriverTestCase{

    private TestRuleModel.RuleDetails ruleDetails;
    private ListRules_Page listRules_page;

    @Before
    public void setup() {
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse  committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();
        ruleDetails.description = committedRuleResponse.description;

        Navigation utilNavigation = new Navigation(driver);
        listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);
    }

    @Test
    @Category({ChangeRequest.CR_3408.class,ChangeRequest.CR_3423.class})
    public void WhenNationalRuleManagerLoggedIn_CanSilenceAndReinstateRuleAnActiveRule()
    {
        //Arrange
        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);
        Dialog_Confirm dialog_confirm = ruleSummary_page.clickSilentButton();  //takes you to list rules page at the moment.
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");
        ruleSummary_page.waitForAngularRequestsToFinish();
        publishAndWait(5000);
        ruleSummary_page.refreshPage();
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetailsForLocalRuleViewer();
        String sRuleStatus = listRuleSummaryTableObjects.get(0).status;
        assertEquals("Expect Rule Status to be Silent", "Silent", sRuleStatus);

        //Assert
        dialog_confirm = ruleSummary_page.clickReinstateButton();  //takes you to list rules page at the moment.
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");
        ruleSummary_page.waitForAngularRequestsToFinish();
        publishAndWait(5000);
        ruleSummary_page.refreshPage();
        listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetailsForLocalRuleViewer();
        sRuleStatus = listRuleSummaryTableObjects.get(0).status;
        assertEquals("Expect Rule Status to be Active", "Active", sRuleStatus);

        ruleSummary_page.ruleHistoryLog.click();

        ruleSummary_page.waitForAngularRequestsToFinish();

        List<RuleSummary_Page.RuleHistoryLog> listRuleHistoryTableObjects = ruleSummary_page.getListOfRuleHistoryLogs();
        assertEquals("Expect Rule Change is ", "Reinstated", listRuleHistoryTableObjects.get(0).change);
        assertEquals("Expect Rule Change is ", "Silenced", listRuleHistoryTableObjects.get(1).change);
        assertEquals("Expect Rule Change is ", "Created", listRuleHistoryTableObjects.get(2).change);

    }

    @Test
    @Category({ChangeRequest.CR_3424.class})
    public void WhenNationalRuleManagerLoggedIn_CanSuspendSilencedRule()
    {
        //Arrange
        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);
        Dialog_Confirm dialog_confirm = ruleSummary_page.clickSilentButton();  //takes you to list rules page at the moment.
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");
        ruleSummary_page.waitForAngularRequestsToFinish();
        publishAndWait(5000);
        ruleSummary_page.refreshPage();
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetailsForLocalRuleViewer();
        String sRuleStatus = listRuleSummaryTableObjects.get(0).status;
        assertEquals("Expect Rule Status to be Silent", "Silent",sRuleStatus);

        //Assert
        dialog_confirm = ruleSummary_page.clickSuspendButton();  //takes you to list rules page at the moment.
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");
        ruleSummary_page.waitForAngularRequestsToFinish();
        publishAndWait(5000);
        ruleSummary_page.refreshPage();
        listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetailsForLocalRuleViewer();
        sRuleStatus = listRuleSummaryTableObjects.get(0).status;
        assertEquals("Expect Rule Status to be Suspended", "Suspended", sRuleStatus);
        ruleSummary_page.ruleHistoryLog.click();

        ruleSummary_page.waitForAngularRequestsToFinish();

        List<RuleSummary_Page.RuleHistoryLog> listRuleHistoryTableObjects = ruleSummary_page.getListOfRuleHistoryLogs();
        assertEquals("Expect Rule Change is ", "Suspended", listRuleHistoryTableObjects.get(0).change);
        assertEquals("Expect Rule Change is ", "Silenced", listRuleHistoryTableObjects.get(1).change);
        assertEquals("Expect Rule Change is ", "Created", listRuleHistoryTableObjects.get(2).change);

    }

    @Test
    @Category({ChangeRequest.CR_3425.class})
    public void WhenNationalRuleManagerLoggedIn_CanArchiveSilencedRule()
    {
        //Arrange
        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);
        Dialog_Confirm dialog_confirm = ruleSummary_page.clickSilentButton();  //takes you to list rules page at the moment.
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");
        ruleSummary_page.waitForAngularRequestsToFinish();
        publishAndWait(5000);
        ruleSummary_page.refreshPage();
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetailsForLocalRuleViewer();
        String sRuleStatus = listRuleSummaryTableObjects.get(0).status;
        assertEquals("Expect Rule Status to be Silent", "Silent",sRuleStatus);

        //Assert
        dialog_confirm = ruleSummary_page.clickArchiveButton();  //takes you to list rules page at the moment.
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");
        ruleSummary_page.waitForAngularRequestsToFinish();
        publishAndWait(5000);
        ruleSummary_page.refreshPage();
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);
        ruleSummary_page.waitForAngularRequestsToFinish();
        listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetailsForLocalRuleViewer();
        sRuleStatus = listRuleSummaryTableObjects.get(0).status;
        assertEquals("Expect Rule Status to be Archived", "Archived", sRuleStatus);

        ruleSummary_page.ruleHistoryLog.click();

        ruleSummary_page.waitForAngularRequestsToFinish();

        List<RuleSummary_Page.RuleHistoryLog> listRuleHistoryTableObjects = ruleSummary_page.getListOfRuleHistoryLogs();
        assertEquals("Expect Rule Change is ", "Archived", listRuleHistoryTableObjects.get(0).change);
        assertEquals("Expect Rule Change is ", "Silenced", listRuleHistoryTableObjects.get(1).change);
        assertEquals("Expect Rule Change is ", "Created", listRuleHistoryTableObjects.get(2).change);

    }

    @Test
    @Category({ChangeRequest.CR_3406.class})
    public void WhenNationalRuleManagerLoggedIn_CanSilenceSuspendedRule()
    {
        //Arrange
        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);
        Dialog_Confirm dialog_confirm = ruleSummary_page.clickSuspendButton();  //takes you to list rules page at the moment.
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");
        ruleSummary_page.waitForAngularRequestsToFinish();
        publishAndWait(5000);
        ruleSummary_page.refreshPage();
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetailsForLocalRuleViewer();
        String sRuleStatus = listRuleSummaryTableObjects.get(0).status;
        assertEquals("Expect Rule Status to be Suspended", "Suspended",sRuleStatus);

        //Assert
        dialog_confirm = ruleSummary_page.clickSilentButton();  //takes you to list rules page at the moment.
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");
        ruleSummary_page.waitForAngularRequestsToFinish();
        publishAndWait(5000);
        ruleSummary_page.refreshPage();
        listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetailsForLocalRuleViewer();
        sRuleStatus = listRuleSummaryTableObjects.get(0).status;
        assertEquals("Expect Rule Status to be Silent", "Silent", sRuleStatus);
        ruleSummary_page.ruleHistoryLog.click();

        ruleSummary_page.waitForAngularRequestsToFinish();
        List<RuleSummary_Page.RuleHistoryLog> listRuleHistoryTableObjects = ruleSummary_page.getListOfRuleHistoryLogs();
        assertEquals("Expect Rule Change is ", "Silenced", listRuleHistoryTableObjects.get(0).change);
        assertEquals("Expect Rule Change is ", "Suspended", listRuleHistoryTableObjects.get(1).change);
        assertEquals("Expect Rule Change is ", "Created", listRuleHistoryTableObjects.get(2).change);
    }



}