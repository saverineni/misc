package TestCases.RulesManagementService;

import API.DataForTests.*;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.ShareDataTable.ShareDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import Categories_CDSRisk.CDS_RM_DataTable;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import org.apache.commons.httpclient.HttpStatus;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_DataTable.class})
public class TestCase_DataTable_RemoveOwnership extends WebAPITestCaseWithDatatablesCleanup {

    @Test
    @Category(ChangeRequest.CR_2097.class)
    public void WhenNatRuleManagerRemovesMultipleOwnerOfDataTable_DataTableOwnershipIsRemoved() throws Throwable {

        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_FreeText_Valid();
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.manageTableLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.manageTableLocationUuids.add(Locations.Location_WAT_UID);
        tableDetails.manageTableLocationUuids.add(Locations.Location_LON_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject response = API.RulesManagementService.Utils.DataTables.GetDataTableByUID(tableDetails.uuid);
        tableDetails.opLockVersion = response.opLockVersion;
        tableDetails.manageTableLocationUuids.remove(Locations.Location_EXT_UID);
        tableDetails.manageTableLocationUuids.remove(Locations.Location_WAT_UID);

        ShareDataTableResponse.ShareDataTableResponseObject shareDataTableResponseObject1 = API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetails);
        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponse =
                API.RulesManagementService.Utils.DataTables.GetDataTableByUID(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, shareDataTableResponseObject1.httpStatusCode);
        assertEquals("Expect Locations: ", 2, shareDataTableResponseObject1.manageTables.size());
        assertThat(shareDataTableResponseObject1.manageTables).extracting("locationName")
                .containsOnly("National Office", "LON");
        assertThat(shareDataTableResponseObject1.manageTables).extracting("locationName")
                .doesNotContain("EXT", "WAT");

        assertEquals("Expect 2 Manage Locations: ", 2, viewDataTableResponse.locations.manageTables.size());
    }

    @Test
    @Category(ChangeRequest.CR_2097.class)
    public void WhenNatRuleManagerLoggedIn_IsOwnerOfRestrictedDataTable_CanRemoveUseLocations() throws Throwable {

        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.useTablesLocationUuids.clear();
        tableDetails.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.useTablesLocationUuids.add(Locations.Location_MAN_UID);
        tableDetails.useTablesLocationUuids.add(Locations.Location_SUN_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject response = API.RulesManagementService.Utils.DataTables.GetDataTableByUID(tableDetails.uuid);
        tableDetails.opLockVersion = response.opLockVersion;
        tableDetails.useTablesLocationUuids.remove(Locations.Location_EXT_UID);

        ShareDataTableResponse.ShareDataTableResponseObject shareDataTableResponseObject1 = API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetails);
        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponse =
                API.RulesManagementService.Utils.DataTables.GetDataTableByUID(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, shareDataTableResponseObject1.httpStatusCode);
        assertEquals("Expect Locations: ", 3, shareDataTableResponseObject1.useTables.size());
        assertThat(shareDataTableResponseObject1.useTables).extracting("locationName")
                .containsOnly("MAN", "SUN", "National Office");
        assertThat(shareDataTableResponseObject1.useTables).extracting("locationName")
                .doesNotContain("EXT");

        assertEquals("Expect 3 Manage Locations: ", 3, viewDataTableResponse.locations.useTables.size());
    }

    @Test
    @Category(ChangeRequest.CR_2097.class)
    public void WhenLocalRuleManager_OwnerOfSensitiveDataTable_DataTableOwnershipIsRemoved() throws Throwable {

        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();
        tableDetails.tableType = "sensitive";

        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.manageTableLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.manageTableLocationUuids.add(Locations.Location_WAT_UID);
        tableDetails.manageTableLocationUuids.add(Locations.Location_LON_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject response = API.RulesManagementService.Utils.DataTables.GetDataTableByUID(tableDetails.uuid);
        tableDetails.opLockVersion = response.opLockVersion;
        tableDetails.manageTableLocationUuids.remove(Locations.Location_LON_UID);
        tableDetails.manageTableLocationUuids.remove(Locations.Location_WAT_UID);

        ShareDataTableResponse.ShareDataTableResponseObject shareDataTableResponseObject1 = API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetails);
        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponse =
                API.RulesManagementService.Utils.DataTables.GetDataTableByUID(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, shareDataTableResponseObject1.httpStatusCode);
        assertEquals("Expect Locations: ", 2, shareDataTableResponseObject1.manageTables.size());
        assertThat(shareDataTableResponseObject1.manageTables).extracting("locationName")
                .containsOnly("POO", "EXT");
        assertThat(shareDataTableResponseObject1.manageTables).extracting("locationName")
                .doesNotContain("WAT", "LON");

        assertEquals("Expect 1 Manage Locations: ", 2, viewDataTableResponse.locations.manageTables.size());
    }
    @Test
    @Category(ChangeRequest.CR_2097.class)
    public void WhenNatRuleManagerLoggedIn_IsOwnerOfSensitive_DataTable_CanRemoveUseLocations() throws Throwable {

        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        tableDetails.tableType = "sensitive";
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.useTablesLocationUuids.clear();
        tableDetails.useTablesLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.useTablesLocationUuids.add(Locations.Location_MAN_UID);
        tableDetails.useTablesLocationUuids.add(Locations.Location_SUN_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.user.toString();
        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject response = API.RulesManagementService.Utils.DataTables.GetDataTableByUID(tableDetails.uuid);
        tableDetails.opLockVersion = response.opLockVersion;
        tableDetails.useTablesLocationUuids.remove(Locations.Location_EXT_UID);

        ShareDataTableResponse.ShareDataTableResponseObject shareDataTableResponseObject1 = API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetails);
        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponse =
                API.RulesManagementService.Utils.DataTables.GetDataTableByUID(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, shareDataTableResponseObject1.httpStatusCode);
        assertEquals("Expect Locations: ", 3, shareDataTableResponseObject1.useTables.size());
        assertThat(shareDataTableResponseObject1.useTables).extracting("locationName")
                .containsOnly("MAN", "SUN", "National Office");
        assertThat(shareDataTableResponseObject1.useTables).extracting("locationName")
                .doesNotContain("EXT");

        assertEquals("Expect 3 Manage Locations: ", 3, viewDataTableResponse.locations.useTables.size());
    }

    @Test
    @Category(ChangeRequest.CR_2097.class)
    public void WhenNatRuleManagerLoggedIn_CannotRemoveDefaultOwnerLocation() throws Throwable {

        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();
        tableDetails.tableType = "open";
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.uuid = createDataTableResponse.uuid;

        ViewDataTableResponse.ViewDataTableResponseObject response = API.RulesManagementService.Utils.DataTables.GetDataTableByUID(tableDetails.uuid);
        tableDetails.opLockVersion = response.opLockVersion;
        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        tableDetails.manageTableLocationUuids.remove(Locations.Location_National_UID);

        ShareDataTableResponse.ShareDataTableResponseObject shareDataTableResponseObject = API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetails);
        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponse =
                API.RulesManagementService.Utils.DataTables.GetDataTableByUID(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, shareDataTableResponseObject.httpStatusCode);
        assertEquals("Expect Locations: ", 1, shareDataTableResponseObject.manageTables.size());
        assertThat(shareDataTableResponseObject.manageTables).extracting("locationName")
                .containsOnly("National Office");

        assertEquals("Expect 2 Use Locations: ", 2, viewDataTableResponse.locations.useTables.size());
    }



    @Category(ChangeRequest.CR_2097.class)
    @Test
    public void WhenLocalRuleManagerRemovesMultipleOwnerOfOpenDataTable_DataTableOwnershipIsRemoved() throws Throwable {

        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();
        tableDetails.tableType = "open";

        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.manageTableLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.manageTableLocationUuids.add(Locations.Location_WAT_UID);
        tableDetails.manageTableLocationUuids.add(Locations.Location_LON_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject response = API.RulesManagementService.Utils.DataTables.GetDataTableByUID(tableDetails.uuid);
        tableDetails.opLockVersion = response.opLockVersion;
        tableDetails.manageTableLocationUuids.remove(Locations.Location_LON_UID);
        tableDetails.manageTableLocationUuids.remove(Locations.Location_WAT_UID);

        ShareDataTableResponse.ShareDataTableResponseObject shareDataTableResponseObject1 = API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetails);
        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponse =
                API.RulesManagementService.Utils.DataTables.GetDataTableByUID(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, shareDataTableResponseObject1.httpStatusCode);
        assertEquals("Expect Locations: ", 2, shareDataTableResponseObject1.manageTables.size());
        assertThat(shareDataTableResponseObject1.manageTables).extracting("locationName")
                .containsOnly("POO", "EXT");
        assertThat(shareDataTableResponseObject1.manageTables).extracting("locationName")
                .doesNotContain("WAT", "LON");

        assertEquals("Expect 1 Manage Locations: ", 2, viewDataTableResponse.locations.manageTables.size());
    }

}
