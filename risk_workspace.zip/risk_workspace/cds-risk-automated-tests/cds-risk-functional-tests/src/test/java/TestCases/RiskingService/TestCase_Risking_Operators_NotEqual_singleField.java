package TestCases.RiskingService;

import API.DataForTests.Conditions;
import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestRuleModel.RuleDetails;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.Utils.RuleAtStatus;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service_Operators;
import TestCases.BaseWebAPITestCase;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import static API.DataForTests.TestRuleModel.RuleDetails.AttributeType.*;
import static API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody;
import static org.assertj.core.api.Assertions.assertThat;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.crossmatch;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.normal;

@Slf4j
@Category(Risking_Service_Operators.class)
public class TestCase_Risking_Operators_NotEqual_singleField extends BaseWebAPITestCase {

    public static final String NO_CONTROL_ROUTE = "";
    private RuleDetails testRule;
    private RuleDetails.Condition condition;
    private TestDeclarationModel.Declaration declaration;

    @Before
    public void setup() throws IOException, TimeoutException {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
        testRule = API.DataForTests.Rules.DraftNatRuleNatManager();
        condition = testRule.queryConditions.get(0).conditions.get(0);
        condition.operator = "neq";
        declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
    }

    private void commitRuleAndPublish(){
        EditRuleVersionResponse.PutResponse commitResponse = RuleAtStatus.CreateCommittedRule(testRule);
        assertThat(commitResponse.httpStatusCode)
                .describedAs("Failed to commit rule. response:\n"+commitResponse.body)
                .isEqualTo(200);
        publishAndWait(5000);
    }

    private DeclarationResponse riskDeclaration() {
        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());
        queue.send(declarationRequest);
        return new DeclarationResponse(queue.receive());
    }

    /*
     * single field to value
     */
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualValue_thenRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeCity().attribute;
        condition.value = "San Francisco";
        commitRuleAndPublish();

        declaration.consigneeCity = "New York";
        declaration.additionalCommodityCode="`11";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualValue_fieldNull_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeCity().attribute;
        condition.value = "San Fransisco";
        commitRuleAndPublish();

        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualValue_equalValues_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeCity().attribute;
        condition.value = "san Fransisco";
        commitRuleAndPublish();

        declaration.consigneeCity = "San Fransisco";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotMatchesValue_equalValues_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeCity().attribute;
        condition.operator="notMatchesPattern";
        condition.value = "??? Fransisco";
        commitRuleAndPublish();

        declaration.consigneeCity = "San Fransisco";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenMultipleFieldsWithNotEqualAndEqualValues_EqualsDoesNotMatch_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = "Consignee";

        RuleDetails.Condition condition = Conditions.consignorName_Header();
        condition.operator = "eq";
        condition.value = "consignor";
        testRule.queryConditions.get(0).conditions.add(condition);

        commitRuleAndPublish();

        declaration.consigneeName = "TraderName";
        declaration.consignorName_Header = "TradeName";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotStartsValueEORI_thenRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.operator="nst";
        condition.attribute = Conditions.consigneeEori().attribute;
        condition.value = "A";
        commitRuleAndPublish();

        declaration.consigneeEori = "BBC";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    /*
     * number field to value
     */


    /*
     * single field to single field
     */
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualField_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.consignorName_Header().attribute;
        commitRuleAndPublish();

        declaration.consigneeName = "Bob";
        declaration.consignorName_Header = "Jane";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotContainsField_containsValue_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.consignorName_Header().attribute;
        condition.operator="nco";
        commitRuleAndPublish();

        declaration.consigneeName = "This is consignee";
        declaration.consignorName_Header = "consignee";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualField_equalValues_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.consignorName_Header().attribute;
        commitRuleAndPublish();

        declaration.consigneeName = "Jane";
        declaration.consignorName_Header = "Jane";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualField_nullLHS_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.consignorName_Header().attribute;
        commitRuleAndPublish();

        declaration.consignorName_Header = "Jane";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualField_nullRHS_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.consignorName_Header().attribute;
        commitRuleAndPublish();

        declaration.consigneeName = "Jane";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualField_nullBothSides_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.consignorName_Header().attribute;
        commitRuleAndPublish();

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }


    /*
     * Number field to field
     */
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberFieldNotEqualField_thenRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.commodityNetMass().attribute;
        condition.value = Conditions.commodityGrossMass().attribute;
        commitRuleAndPublish();

        declaration.commodityNetMass = "12.5";
        declaration.commodityGrossMass = "55.6";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberFieldNotEqualField_equalValues_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.commodityNetMass().attribute;
        condition.value = Conditions.commodityGrossMass().attribute;
        commitRuleAndPublish();

        declaration.commodityNetMass = "12.5";
        declaration.commodityGrossMass = "12.5";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberFieldNotEqualField_nullLHS_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.commodityNetMass().attribute;
        condition.value = Conditions.commodityGrossMass().attribute;
        commitRuleAndPublish();

        declaration.commodityGrossMass = "55.6";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberFieldNotEqualField_nullRHS_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.commodityNetMass().attribute;
        condition.value = Conditions.commodityGrossMass().attribute;
        commitRuleAndPublish();

        declaration.commodityNetMass = "12.5";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberFieldNotEqualField_nullBothSides_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.commodityNetMass().attribute;
        condition.value = Conditions.commodityGrossMass().attribute;
        commitRuleAndPublish();

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }


    /*
     * single field to collection field
     * Collection needs to be not empty and all not null values not equal to the field
     */
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualCollectionField_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.additionalDocumentsType_HeaderCollections().attribute;
        commitRuleAndPublish();

        declaration.consigneeName = "Bob";
        declaration.additionalDocuments_TypeHeader = "Jane";
        // IMPORTANT. There must only be one defined header additional doc. Else the second is blank

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualCollectionField_allDifferent_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.additionalInfoText_HeaderCollections().attribute;
        commitRuleAndPublish();

        declaration.consigneeName = "Bob";
        declaration.additionalInformation_TextHeader = "different";
        declaration.additionalInfoText_Header = "not the same";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualCollectionField_oneDifferentOneBlank_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.additionalInfoText_HeaderCollections().attribute;
        commitRuleAndPublish();

        declaration.consigneeName = "Bob";
        declaration.additionalInformation_TextHeader = "different";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualCollectionField_emptyCollection_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.additionalInfoText_HeaderCollections().attribute;
        commitRuleAndPublish();

        declaration.consigneeName = "Bob";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualCollectionField_collectionEmptyStrings_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.additionalInfoCode_HeaderCollections().attribute;
        commitRuleAndPublish();

        declaration.consigneeName = "Bob";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualCollectionField_sameValue_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.additionalDocumentsType_HeaderCollections().attribute;
        commitRuleAndPublish();

        declaration.consigneeName = "Bob";
        declaration.additionalDocuments_TypeHeader = "Bob";
        // IMPORTANT. There must only be one defined header additional doc. Else the second is blank

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualCollectionField_oneSameValue_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.additionalInfoText_HeaderCollections().attribute;
        commitRuleAndPublish();

        declaration.consigneeName = "Bob";
        declaration.additionalInformation_TextHeader = "Bob";
        declaration.additionalInfoText_Header = "not the same";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualCollectionField_oneSameOneBlank_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.additionalInfoText_HeaderCollections().attribute;
        commitRuleAndPublish();

        declaration.consigneeName = "Bob";
        declaration.additionalInformation_TextHeader = "Bob";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberFieldNotEqualCollectionField_thenRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.commodityNetMass().attribute;
        condition.value = Conditions.additionalDocuments_QuantityItemCollection().attribute;
        commitRuleAndPublish();

        declaration.commodityNetMass = "789.24";
        declaration.additionalDocuments_QuantityItem = "654.32";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberFieldNotEqualCollectionField_allDifferent_thenRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.commodityNetMass().attribute;
        condition.value = Conditions.declaredDutyTaxFees_TaxAmountItemCollection().attribute;
        commitRuleAndPublish();

        declaration.commodityNetMass = "789.24";
        declaration.declaredDutyTaxFees_TaxAmountItem = "999.99";
        declaration.taxAmount = "123456.12";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberFieldNotEqualCollectionField_oneDifferentOneBlank_thenRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.commodityNetMass().attribute;
        condition.value = Conditions.declaredDutyTaxFees_TaxAmountItemCollection().attribute;
        commitRuleAndPublish();

        declaration.commodityNetMass = "789.24";
        declaration.declaredDutyTaxFees_TaxAmountItem = "999.99";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberFieldNotEqualCollectionField_emptyCollection_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.commodityNetMass().attribute;
        condition.value = Conditions.declaredDutyTaxFees_TaxAmountItemCollection().attribute;
        commitRuleAndPublish();

        declaration.commodityNetMass = "789.21";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberFieldNotEqualCollectionField_sameValue_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.commodityNetMass().attribute;
        condition.value = Conditions.additionalDocuments_QuantityItemCollection().attribute;
        commitRuleAndPublish();

        declaration.commodityNetMass = "789.25";
        declaration.additionalDocuments_QuantityItem = "789.25";
        // IMPORTANT. There must only be one defined header additional doc. Else the second is blank

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberFieldNotEqualCollectionField_oneSameValue_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.commodityNetMass().attribute;
        condition.value = Conditions.declaredDutyTaxFees_TaxAmountItemCollection().attribute;
        commitRuleAndPublish();

        declaration.commodityNetMass = "789.29";
        declaration.declaredDutyTaxFees_TaxAmountItem = "999.99";
        declaration.taxAmount = "789.29";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberFieldNotEqualCollectionField_oneSameOneBlank_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.commodityNetMass().attribute;
        condition.value = Conditions.declaredDutyTaxFees_TaxAmountItemCollection().attribute;
        commitRuleAndPublish();

        declaration.commodityNetMass = "789.77";
        declaration.declaredDutyTaxFees_TaxAmountItem = "789.77";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumberFieldNotEqualCollectionField_fieldAndCollectionBlank_thenNoRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.commodityNetMass().attribute;
        condition.value = Conditions.declaredDutyTaxFees_TaxAmountItemCollection().attribute;
        commitRuleAndPublish();

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    /*
     * single field to domain field
     * One of the domain fields needs to be not empty and all not null values not equal to the field
     */
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualDomainField_thenRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.consignorName_domain().attribute;
        commitRuleAndPublish();

        declaration.consigneeName = "Bob";
        declaration.consignorName_Header = "Jane";
        declaration.exporterConsignorName_Item = "Mary";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualDomainField_oneDifferentOneBlank_thenRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.consignorName_domain().attribute;
        commitRuleAndPublish();

        declaration.consigneeName = "Bob";
        declaration.consignorName_Header = "Jane";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualDomainField_allSame_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.consignorName_domain().attribute;
        commitRuleAndPublish();

        declaration.consigneeName = "Bob";
        declaration.consignorName_Header = "Bob";
        declaration.exporterConsignorName_Item = "Bob";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualDomainField_oneSame_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.consignorName_domain().attribute;
        commitRuleAndPublish();

        declaration.consigneeName = "Bob";
        declaration.consignorName_Header = "Bob";
        declaration.exporterConsignorName_Item = "Jane";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualDomainField_oneSameOneBlank_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.consignorName_domain().attribute;
        commitRuleAndPublish();

        declaration.consigneeName = "Bob";
        declaration.consignorName_Header = "Bob";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualDomainField_allBlank_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.consignorName_domain().attribute;
        commitRuleAndPublish();

        declaration.consigneeName = "Bob";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualDomainField_fieldAndCollectionBlank_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.consignorName_domain().attribute;
        commitRuleAndPublish();

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualDomainField_fieldBlankAndOneDomainHasValue_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.consignorName_domain().attribute;
        commitRuleAndPublish();

        declaration.consignorName_Header = "Bob";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualDomainField_fieldBlank_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeName().attribute;
        condition.value = Conditions.consignorName_domain().attribute;
        commitRuleAndPublish();

        declaration.consignorName_Header = "Bob";
        declaration.exporterConsignorName_Item = "Jane";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualItemField_fieldNotEquals_thenRouteReturned() {
        condition.attributeType = ITEM_COLLECTION;
        condition.conditionType = normal;
        condition.attribute = Conditions.declaredDutyTaxFees_PreferenceCodeItemCollection().attribute;
        condition.operator="neq";
        condition.value = "ABC";
        commitRuleAndPublish();

        declaration.declaredDutyTaxFees_PreferenceCodeItem = "ABC";
        DeclarationResponse declarationResponse1 = riskDeclaration();

        declaration.declaredDutyTaxFees_PreferenceCodeItem = "BCD";
        DeclarationResponse declarationResponse2 = riskDeclaration();

        declaration.declaredDutyTaxFees_PreferenceCodeItem = "123";
        DeclarationResponse declarationResponse3 = riskDeclaration();

        declaration.declaredDutyTaxFees_PreferenceCodeItem = "";
        DeclarationResponse declarationResponse4 = riskDeclaration();

        assertThat(declarationResponse1.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
        assertThat(declarationResponse2.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
        assertThat(declarationResponse3.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
        assertThat(declarationResponse4.getControlType()).isEqualTo(NO_CONTROL_ROUTE);

    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualForDecimalFields_fieldNotEquals_thenRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.commodityNetMass().attribute;
        condition.operator="neq";
        condition.value = "15.5";
        commitRuleAndPublish();

        declaration.commodityNetMass = "0";
        DeclarationResponse declarationResponse1 = riskDeclaration();
        assertThat(declarationResponse1.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
      }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotEqualForDecimalFields_fieldBlank_thenRouteNotReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.commodityNetMass().attribute;
        condition.operator="neq";
        condition.value = "15.5";
        commitRuleAndPublish();

       declaration.commodityNetMass = "";
       DeclarationResponse declarationResponse = riskDeclaration();
       assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CR_3321.class})
    public void whenFieldNotEqualsValueExporter_DeclarationNotEquals_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.exporterPostcode_Header("M334tr").attribute;
        condition.value="M334tr";
        commitRuleAndPublish();
        declaration.exporterZipCode_Header = "L122AH";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

    }

    @Test
    @Category({ChangeRequest.CR_3419.class})
    public void whenGoodsShippedByContainerIndicatorNotEqualValue_DeclarationHasSameValue_thenRouteNotReturned() throws Throwable {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "neq";
        condition.attribute = Conditions.goodsShippedByContainerIndicator_Header("1").attribute;
        condition.value = "1";
        commitRuleAndPublish();
        declaration.goodsShippedByContainerIndicator = "1";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CR_3418.class})
    public void whenFieldNotEqualsValueCustCommodityCodeItem_DeclarationNotEquals_thenRouteReturned() throws Throwable {

        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.cusCommodityCode_Item("AH123456").attribute;
        condition.value="AH123456";
        commitRuleAndPublish();
        declaration.cusCommodityCode_Item = "AK123456";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3419.class})
    public void whenMeansOfTransportArrivalIndicatorNotEqualValue_DeclarationHasDifferentValue_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="neq";
        condition.attribute = Conditions.meansOfTransportOnArrivalIdentifier("Arrival").attribute;
        condition.value="Arrival";
        commitRuleAndPublish();
        declaration.transportRole = "5";
        declaration.transportIdentifier="NotArrived";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3419.class})
    public void whenMeansOfTransportArrivalIndicatorTypeNotContainValue_DeclarationHasDifferentValue_thenRouteReturned() throws Throwable {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="nco";
        condition.attribute = Conditions.meansOfTransportOnArrivalType("Secure").attribute;
        condition.value="Secure";
        commitRuleAndPublish();
        declaration.transportRole = "5";
        declaration.transportArrivalIdentifierType="NotArrived";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3417.class})
    public void whenCountryGroupOfOriginItemNotEqualValue_ConditionAndDeclarationEqual_thenRouteNotReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.operator = "neq";
        condition.attribute = Conditions.countryGroupOfOrigin_Item("CHIN").attribute;
        condition.value = "CHIN";
        commitRuleAndPublish();
        declaration.countryGroupOfOrigin_Item = "CHIN";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CR_3417.class})
    public void whenCountryGroupOfPreferentialOriginItemNotEqualsValue_ConditionAndDeclarationNotEqual_thenRouteReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.operator = "neq";
        condition.attribute = Conditions.countryGroupOfPreferentialOrigin_Item("CHIN").attribute;
        condition.value="CHIN";
        commitRuleAndPublish();
        declaration.subRole="2";
        declaration.countryGroupOfOrigin_Item = "ENG";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void whenTValuationAdjustmentsTypeIsAR_andAirTransportSumIsNot10_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "neq";
        condition.attribute = Conditions.airTransportCostsSum_Header(null).attribute;
        condition.value = "10";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "AR";
        declaration.valuationAdjustmentsType2 = "AR";
        declaration.valuationAdjustmentsType3 = "BR";
        declaration.valuationAdjustmentsType4 = "BS";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void whenTValuationAdjustmentsTypeAreAPandAQ_andFreightChargesSumIsNotEqualToTheirSum_thenRouteReturned() throws Throwable {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "neq";
        condition.attribute = Conditions.freightChargesSum_Header(null).attribute;
        condition.value = "40.0";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "AP";
        declaration.valuationAdjustmentsType2 = "AP";
        declaration.valuationAdjustmentsType3 = "AQ";
        declaration.valuationAdjustmentsType4 = "AQ";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void whenValuationAdjustmentsFieldsAreOnTheFreightApportionmentIndicatorList_thenRouteReturned() throws Throwable {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "neq";
        condition.attribute = Conditions.freightApportionmentIndicator_Header(null).attribute;
        condition.value = "0";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "AW";
        declaration.valuationAdjustmentsType2 = "AP";
        declaration.valuationAdjustmentsType3 = "AR";
        declaration.valuationAdjustmentsType4 = "BR";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void whenValuationAdjustmentsFieldIsBHinConsignmentShipmentAndGoodsItems_andDiscountAmountIsNotTheirSum_thenRouteReturned() throws Throwable {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "neq";
        condition.attribute = Conditions.discountAmountSum_Header(null).attribute;
        condition.value = "100";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "BH";
        declaration.valuationAdjustmentsType2 = "BH";
        declaration.valuationAdjustmentsType3 = "AR";
        declaration.valuationAdjustmentsType4 = "BR";

        declaration.valuationAdjustments_CodeItem = "BH";
        declaration.valuationAdjustAmount_Item = "1";
        declaration.valuationAdjustCurrency_Item = "GBP";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void whenValuationAdjustmentsFieldIsBIinConsignmentShipmentAndGoodsItems_andDiscountPercentIsNotTheirSum_thenRouteReturned() throws Throwable {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "neq";
        condition.attribute = Conditions.discountPercentSum_Header(null).attribute;
        condition.value = "50";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "BI";
        declaration.valuationAdjustmentsType2 = "BH";
        declaration.valuationAdjustmentsType3 = "BI";
        declaration.valuationAdjustmentsType4 = "BR";

        declaration.valuationAdjustments_CodeItem = "BI";
        declaration.valuationAdjustAmount_Item = "1";
        declaration.valuationAdjustCurrency_Item = "GBP";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void whenValuationAdjustmentsFieldIsAKinConsignmentShipment_andInsuranceAmountIsNotTheirSum_thenRouteReturned() throws Throwable {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "neq";
        condition.attribute = Conditions.insuranceAmountSum_Header(null).attribute;
        condition.value = "50";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "AK";
        declaration.valuationAdjustmentsType2 = "BH";
        declaration.valuationAdjustmentsType3 = "AK";
        declaration.valuationAdjustmentsType4 = "BR";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void declarationResponsewhenValuationAdjustmentsFieldsHaveATOrBTType_andOtherTransportChargesIsNotTheirSum_thenRouteReturned() throws Throwable {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "neq";
        condition.attribute = Conditions.otherTransportChargesSum_Header(null).attribute;
        condition.value = "20";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "AT";
        declaration.valuationAdjustmentsType2 = "AT";
        declaration.valuationAdjustmentsType3 = "BT";
        declaration.valuationAdjustmentsType4 = "BT";

        declaration.valuationAdjustments_CodeItem = "AT";
        declaration.valuationAdjustCurrency_Item = "GBP";
        declaration.valuationAdjustAmount_Item = "1";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void whenValuationAdjustmentsFieldAreAWorAVinConsignmentShipment_andVATAdjustmentIsNotTheirSum_thenRouteReturned() throws Throwable {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "neq";
        condition.attribute = Conditions.vatAdjustmentSum_Header(null).attribute;
        condition.value = "50";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "AV";
        declaration.valuationAdjustmentsType2 = "AW";
        declaration.valuationAdjustmentsType3 = "BT";
        declaration.valuationAdjustmentsType4 = "AV";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3414.class})
    public void whenInternalCurrencyUnitItemNotEqualsValue_ConditionAndDeclarationNotEqual_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "neq";
        condition.attribute = Conditions.internalCurrencyUnit_Header().attribute;
        condition.value="GBP";
        commitRuleAndPublish();
        declaration.internalCurrencyUnit = "EUR";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

}
