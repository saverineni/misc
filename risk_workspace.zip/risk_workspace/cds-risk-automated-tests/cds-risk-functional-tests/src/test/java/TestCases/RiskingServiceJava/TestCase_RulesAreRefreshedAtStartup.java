package TestCases.RiskingServiceJava;


import org.assertj.core.api.Assertions;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel.RuleDefinition;
import uk.gov.hmrc.risk.test.common.enums.DeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.GoodsItemDeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.HeaderDeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.ItemAttribute;
import uk.gov.hmrc.risk.test.common.model.dataService.DataTableCreationModel;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleCreationModel;
import uk.gov.hmrc.risk.test.common.service.DockerSupport.ContainerAccessor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static uk.gov.hmrc.risk.test.common.enums.Matcher.equalTo;
import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.*;
import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.MatcherClass.Matchers;
import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.Source.goodsItem;

@Ignore
public class TestCase_RulesAreRefreshedAtStartup extends BaseRiskingServiceJava{

    ContainerAccessor riskingServiceContainer;
    RuleCreationModel ruleCreationModel;


    @Before
    public void setup() {
        riskingServiceContainer = dockerSupport.getRiskingServiceContainer();
        riskingServiceContainer.stop();
        ruleCreationModel = baseRuleCreationModelBuilder().build();
    }

    @After
    public void teardown() {
        riskingServiceContainer.start();
        riskingServiceContainer.checkConnectivity(30);
    }

    @Ignore
    @Test
    public void WhenRiskingServiceIsStarting_RulesAreRefreshed() {

        rulesSupport.createActiveRule(ruleCreationModel, appStateSupport.getLoggedInUserPID());

        riskingServiceContainer.start();
        riskingServiceContainer.checkConnectivity(60);

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();
        declarationFieldValues.put(HeaderDeclarationParam.DISPATCH_COUNTRY, "DE");

        sendDeclarationAndAssertDefaultHit(declarationFieldValues);
    }

    @Ignore
    @Test
    public void WhenRiskingServiceIsStarting_DataTablesAreRefreshed() {

        createRuleWithDataTable();

        riskingServiceContainer.start();
        riskingServiceContainer.checkConnectivity(60);

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();
        declarationFieldValues.put(GoodsItemDeclarationParam.COMMODITY_CODE, "0100000000");

        sendDeclarationAndAssertDefaultHit(declarationFieldValues);
    }

    private void sendDeclarationAndAssertDefaultHit(Map<DeclarationParam, String> declarationFieldValues) {
        String declarationRequest = declarationSupport.createDeclaration(DECLARATION_TEMPLATE, declarationFieldValues);
        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());
        Assertions.assertThat(declarationResponse.getNarrativeText()).isEqualTo(DEFAULT_NARRATIVE);
    }

    private void createRuleWithDataTable() {
        DataTableCreationModel model = baseDataTableModel();

        List<String> dataItems = new ArrayList<>();
        dataItems.add("0100000000");
        dataItems.add("0200000000");
        dataItems.add("0300000000");
        dataItems.add("0400000000");

        String dataTableUuid = dataTableSupport.createDataTable(model, dataItems);

        RuleDefinitionModel definitionModel = defaultDataTableModel();
        definitionModel.getRuleDefinitions().clear();
        RuleDefinition definition = baseRuleDefinition();

        Condition commodityCode = Condition.builder()
                .source(goodsItem)
                .attribute(ItemAttribute.COMMODITY_CODE)
                .matcherClass(Matchers)
                .matcher(equalTo)
                .build();
        definition.setWhenDef(
                value(dataTableUuid) + "\n" +
                        declarationWrapper( goodsItemVariable() ) + "\n" +
                        goodsItemsWrapper(
                                dtCheck( commodityCode )
        ));
        definition.setThenDef(thenCreator( goodsItem, conditions(commodityCode)));

        definitionModel.getGlobals().add( globalDataTable(dataTableUuid) );
        definitionModel.getRuleDefinitions().add(definition);

        ruleCreationModel.setDefinition(definitionModel.toString());

        rulesSupport.createActiveRule(ruleCreationModel, appStateSupport.getLoggedInUserPID());
    }
}
