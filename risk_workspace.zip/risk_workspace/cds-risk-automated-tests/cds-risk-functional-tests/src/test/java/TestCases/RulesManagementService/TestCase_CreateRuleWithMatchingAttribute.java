package TestCases.RulesManagementService;


import API.DataForTests.Conditions;
import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import Categories_CDSRisk.CDS_RM_RuleLifeCycle;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import org.apache.http.HttpStatus;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import static API.DataForTests.TestRuleModel.RuleDetails.AttributeType.HEADER;
import static API.DataForTests.TestRuleModel.RuleDetails.AttributeType.ITEM;
import static org.junit.Assert.assertEquals;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.crossmatch;


@Category({Rules_Management.class, CDS_RM_RuleLifeCycle.class})
public class TestCase_CreateRuleWithMatchingAttribute extends BaseWebAPITestCase {

    @Test
    @Category({ChangeRequest.CR_2849.class})
    public void WhenMatchingAttributeHeaderToItemConsigneeNameCreated_RuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = HEADER;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.consigneeName().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.consigneeName_Item().attribute;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
        assertEquals(createRuleResponse.ruleId, commitResponse.ruleId);
    }

    @Test
    @Category({ChangeRequest.CR_2849.class})
    public void WhenMatchingAttributeItemToHeaderConsigneeNameCreated_RuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = HEADER;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.consigneeName_Item().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.consigneeName().attribute;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
        assertEquals(createRuleResponse.ruleId, commitResponse.ruleId);
    }


    @Test
    @Category({ChangeRequest.CR_2849.class})
    public void WhenMatchingAttributeHeaderToHeaderConsigneeNameConsignorNameCreated_RuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = HEADER;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.consigneeName().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.consignorName_Header().attribute;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
        assertEquals(createRuleResponse.ruleId, commitResponse.ruleId);
    }


    @Test
    @Category({ChangeRequest.CR_2849.class})
    public void WhenMatchingAttributeItemToItemConsigneeNameCreated_RuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = HEADER;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.consigneeName_Item().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.exporterConsignorName_Item().attribute;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
        assertEquals(createRuleResponse.ruleId, commitResponse.ruleId);
    }


    @Test
    @Category({ChangeRequest.CR_2974.class})
    public void WhenMatchingAttributeHeaderToDomainCreated_RuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = HEADER;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.consigneeName().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.consigneeName_domain().attribute;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
        assertEquals(createRuleResponse.ruleId, commitResponse.ruleId);
    }


    @Test
    @Category({ChangeRequest.CR_2974.class})
    public void WhenMatchingAttributeItemToDomainCreated_RuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = ITEM;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.consigneeName_Item().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.consigneeName_domain().attribute;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
        assertEquals(createRuleResponse.ruleId, commitResponse.ruleId);
    }


    @Test
    @Category({ChangeRequest.CR_2974.class})
    public void WhenMatchingAttributeDomainToHeaderCreated_RuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = HEADER;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.consigneeName_domain().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.consigneeName().attribute;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
        assertEquals(createRuleResponse.ruleId, commitResponse.ruleId);
    }

    @Test
    @Category({ChangeRequest.CR_2974.class})
    public void WhenMatchingAttributeDomainToItemCreated_RuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = ITEM;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.consigneeName_domain().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.consigneeName_Item().attribute;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
        assertEquals(createRuleResponse.ruleId, commitResponse.ruleId);
    }


    @Test
    @Category({ChangeRequest.CR_2974.class})
    public void WhenMatchingAttributeHeaderToHeaderCollectionCreated_RuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = HEADER;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.consigneeName().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.additionalDocuments_IdItemCollection().attribute;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
        assertEquals(createRuleResponse.ruleId, commitResponse.ruleId);
    }


    @Test
    @Category({ChangeRequest.CR_2974.class})
    public void WhenMatchingAttributeItemToItemCollectionCreated_RuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = ITEM;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.consigneeName_Item().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.additionalInfoText_ItemCollections().attribute;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
        assertEquals(createRuleResponse.ruleId, commitResponse.ruleId);
    }


    @Test
    @Category({ChangeRequest.CR_2974.class})
    public void WhenMatchingAttributeHeaderCollectionToHeaderCreated_RuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = HEADER;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.additionalInfoText_ItemCollections().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.consigneeName().attribute;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
        assertEquals(createRuleResponse.ruleId, commitResponse.ruleId);
    }


    @Test
    @Category({ChangeRequest.CR_2974.class})
    public void WhenMatchingAttributeItemCollectionToItemCreated_RuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.get(0).attributeType = ITEM;
        ruleDetails.queryConditions.get(0).conditions.get(0).conditionType = crossmatch;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = Conditions.additionalInfoText_ItemCollections().attribute;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = Conditions.consigneeName_Item().attribute;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
        assertEquals(createRuleResponse.ruleId, commitResponse.ruleId);
    }
}
