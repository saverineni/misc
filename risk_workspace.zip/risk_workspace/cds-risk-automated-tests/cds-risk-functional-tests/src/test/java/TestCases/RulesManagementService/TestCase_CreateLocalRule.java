package TestCases.RulesManagementService;


import API.DataForTests.Locations;
import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.EditRule.EditRuleResponse;
import API.RulesManagementService.ViewRule.ViewRuleResponse;
import API.RulesManagementService.ViewRuleList.ViewRuleListResponse;
import API.RulesManagementService.ViewRuleVersion.ViewRuleVersionResponse;
import Categories_CDSRisk.CDS_RM_CreateRules;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import org.assertj.core.api.Assertions;
import org.junit.Assume;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@Category({Rules_Management.class, CDS_RM_CreateRules.class})
public class TestCase_CreateLocalRule extends BaseWebAPITestCase {


    @Test
    @Category(ChangeRequest.CR_624.class)
    public void WhenLocalRuleManagerCreatesLocalRule_LocationSetToLocal() throws Throwable
    {
        //Arrange
        TestUserModel.UserDetails udRuleManPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOO.pid);

        //Act
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(createRuleResponse.uniqueId);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);


        //Assert
        assertEquals("Location uid: ", ruleDetails.locations.get(0), createRuleResponse.locationUuids.get(0));
        assertEquals("Location uid: ", ruleDetails.locations.get(0), viewRuleResponse.versions.get(0).locations.get(0).locationUuid);
        assertEquals("Location uid: ", ruleDetails.locations.get(0), viewRuleVerResponse.locations.get(0).locationUuid);
    }


    @Test
    @Category({ChangeRequest.CR_624.class, ChangeRequest.CR_848.class})
    public void WhenRuleWithMultipleLocalLocationCreated_MultipleLocationsSet() throws Throwable
    {
        //Arrange

        //Act
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftMultipleLOCsRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(createRuleResponse.uniqueId);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        //Assert
        assertEquals("Location uid: ", ruleDetails.locations.size(), createRuleResponse.locationUuids.size());
        assertEquals("Location uid: ", ruleDetails.locations.size(), viewRuleResponse.versions.get(0).locations.size());
        assertEquals("Location uid: ", ruleDetails.locations.size(), viewRuleVerResponse.locations.size());
    }


    //ChangeRequest-621 Apply filters to List Rules based on user's rule and location
    @Test
    @Category(ChangeRequest.CR_621.class)
    public void WhenLocalRuleSaved_RuleCanBeViewedBySameUser() throws Throwable
    {
        //Local Rules Manager User creates Local Rule. This same user can then view this local rule

        //Arrange
        TestUserModel.UserDetails udRuleManPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOO.pid);

        //Act
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(createRuleResponse.uniqueId);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);
        ViewRuleListResponse.ViewRuleListResponseObject viewListRulesResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        Assertions.assertThat(viewRuleResponse.ruleId).containsPattern(ruleDetails.ruleId);
        Assertions.assertThat(viewRuleVerResponse.ruleId).containsPattern(ruleDetails.ruleId);

        int ruleNo = API.RulesManagementService.Utils.Rules.GetNoOfMatchingRuleFromRuleList(viewListRulesResponse, createRuleResponse.uniqueId);
        String actRuleID = viewListRulesResponse.content.get(ruleNo).ruleId;

        Assertions.assertThat(viewRuleVerResponse.regime).isNull();
        Assertions.assertThat(actRuleID).containsPattern(ruleDetails.ruleId);
    }


    @Test
    @Category(ChangeRequest.CR_621.class)
    public void WhenLocalRuleSaved_RuleCanBeViewedByUserFromSameLocation() throws Throwable
    {
        //Local Rules Manager User creates Local Rule.
        //A different Local Rule Manager from same location can view the created local rule

        //Arrange
        TestUserModel.UserDetails udRuleManPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOO.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        TestUserModel.UserDetails udRuleViewPOO = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleViewPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleViewPOO.pid);

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(createRuleResponse.uniqueId);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);
        ViewRuleListResponse.ViewRuleListResponseObject viewListRulesResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        Assertions.assertThat( viewRuleResponse.ruleId).containsPattern(ruleDetails.ruleId);
        Assertions.assertThat( viewRuleVerResponse.ruleId).containsPattern(ruleDetails.ruleId);

        int ruleNo = API.RulesManagementService.Utils.Rules.GetNoOfMatchingRuleFromRuleList(viewListRulesResponse, createRuleResponse.uniqueId);
        String actRuleID = viewListRulesResponse.content.get(ruleNo).ruleId;

        Assertions.assertThat(actRuleID).containsPattern(ruleDetails.ruleId);
    }


    @Test
    @Category(ChangeRequest.CR_621.class)
    public void WhenLocalRuleSaved_RuleCanBeViewedByNationalUser() throws Throwable
    {
        //Arrange
        TestUserModel.UserDetails udRuleManPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOO.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        TestUserModel.UserDetails udRuleManNAT = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManNAT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManNAT.pid);

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(createRuleResponse.uniqueId);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);
        ViewRuleListResponse.ViewRuleListResponseObject viewListRulesResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        Assertions.assertThat(viewRuleResponse.ruleId).containsPattern(ruleDetails.ruleId);
        Assertions.assertThat(viewRuleVerResponse.ruleId).containsPattern(ruleDetails.ruleId);

        int ruleNo = API.RulesManagementService.Utils.Rules.GetNoOfMatchingRuleFromRuleList(viewListRulesResponse, createRuleResponse.uniqueId);
        String actRuleID = viewListRulesResponse.content.get(ruleNo).ruleId;

        Assertions.assertThat(actRuleID).containsPattern(ruleDetails.ruleId);
    }


    @Test
    @Category(ChangeRequest.CR_621.class)
    public void WhenLocalRuleSaved_RuleCanNOTBeViewedByUserFromDifferentLocation() throws Throwable
    {
        //Local Rules Manager User creates Local Rule.
        //A different Local Rule Manager from different location can NOT view the created local rule

        //Arrange
        TestUserModel.UserDetails udRuleManPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOO.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        TestUserModel.UserDetails udRuleViewEXT = Users_API.RulesViewerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleViewEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleViewEXT.pid);

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject viewListRulesResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(createRuleResponse.uniqueId);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        //Assert
        int ruleNo = API.RulesManagementService.Utils.Rules.GetNoOfMatchingRuleFromRuleList(viewListRulesResponse, ruleDetails.uniqueID);
        assertTrue("rule list ruleID should NOT be present: " + ruleDetails.uniqueID, ruleNo == 0);

        //Expected Failure: Until Story ChangeRequest-775 is implemented
        //It is possible to view rule summary and rule details for a a rule which user does not have access via API

        Assume.assumeTrue("Expected No Rule ID. Rule ID from Rule Summary: " + ruleDetails.uniqueID, viewRuleResponse.ruleId == "");
        Assume.assumeTrue("Expected No Rule ID. Rule ID from Rule Details: " + ruleDetails.uniqueID, viewRuleVerResponse.ruleId == "");
    }


    @Test
    @Category(ChangeRequest.CR_621.class)
    public void WhenLocalRuleWith2LocationsSaved_RuleCanNOTBeViewedByUserFromLocation1() throws Throwable
    {
        //Local Rules Manager User creates Local Rule for POO and EXT
        //A different Local Rule Manager with access to only one of the locations: POO can NOT view the created local rule

        //Arrange
        TestUserModel.UserDetails udRuleManPOOEXT = Users_API.RulesManagerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOOEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOOEXT.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POOEXT();

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        TestUserModel.UserDetails udRuleViewPOO = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleViewPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleViewPOO.pid);

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject viewListRulesResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        int ruleNo = API.RulesManagementService.Utils.Rules.GetNoOfMatchingRuleFromRuleList(viewListRulesResponse, ruleDetails.uniqueID);
        assertTrue("rule list ruleID should NOT be present: " + ruleDetails.uniqueID, ruleNo == 0);
  }

    @Test
    @Category(ChangeRequest.CR_621.class)
    public void WhenLocalRuleWith2LocationsSaved_RuleCanNOTBeViewedByUserFromLocation2() throws Throwable
    {
        //Local Rules Manager User creates Local Rule for POO and EXT
        //A different Local Rule Manager with access to only one of the locations: EXT can NOT view the created local rule

        //Arrange
        TestUserModel.UserDetails udRuleManPOOEXT = Users_API.RulesManagerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOOEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOOEXT.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POOEXT();

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        TestUserModel.UserDetails udRuleViewEXT = Users_API.RulesViewerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleViewEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleViewEXT.pid);

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject viewListRulesResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        int ruleNo = API.RulesManagementService.Utils.Rules.GetNoOfMatchingRuleFromRuleList(viewListRulesResponse, ruleDetails.uniqueID);
        assertTrue("rule list ruleID should NOT be present: " + ruleDetails.uniqueID, ruleNo == 0);
    }


    @Test
    @Category({ChangeRequest.CR_621.class, ChangeRequest.CR_848.class})
    public void WhenLocalRuleWith2LocationsSaved_RuleCanBeViewedByUserWithBothLocations1And2() throws Throwable
    {
        //Local Rules Manager User creates Local Rule for POO and EXT
        //A different Local Rule Manager with access to both POO and EXT can view the created local rule

        //Arrange
        TestUserModel.UserDetails udRuleManPOOEXT = Users_API.RulesManagerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOOEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOOEXT.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POOEXT();

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        TestUserModel.UserDetails udRuleViewPOOEXT = Users_API.RuleViewerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleViewPOOEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleViewPOOEXT.pid);

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject viewListRulesResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        int ruleNo = API.RulesManagementService.Utils.Rules.GetNoOfMatchingRuleFromRuleList(viewListRulesResponse, createRuleResponse.uniqueId);
        String actRuleID = viewListRulesResponse.content.get(ruleNo).ruleId;

        //TODO update check to confirm rule created successfully, can't use rule id now as rule id is not unique
        Assertions.assertThat(actRuleID).containsPattern(ruleDetails.ruleId);
    }


    @Test
    @Category(ChangeRequest.CR_594.class)
    public void WhenLocalUserWith2LocationsCreatesRuleFor1stSingleLocations_RulesCreatedSuccessfully() throws Throwable
    {
        //Local Rules Manager User for locations: POO and EXT
        //Creates one rule for POO

        //Arrange
        TestUserModel.UserDetails udRuleManPOOEXT = Users_API.RulesManagerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOOEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOOEXT.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        TestUserModel.UserDetails udRuleViewPOO = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleViewPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleViewPOO.pid);

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject viewListRulesResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        int ruleNo = API.RulesManagementService.Utils.Rules.GetNoOfMatchingRuleFromRuleList(viewListRulesResponse, createRuleResponse.uniqueId);
        String actRuleID = viewListRulesResponse.content.get(ruleNo).ruleId;

        //TODO update check to confirm rule created successfully, can't use rule id now as rule id is not unique
        Assertions.assertThat(actRuleID).containsPattern(ruleDetails.ruleId);
    }


    @Test
    @Category(ChangeRequest.CR_594.class)
    public void WhenLocalUserWith2LocationsCreatesRuleFor2ndSingleLocations_RulesCreatedSuccessfully() throws Throwable
    {
        //Local Rules Manager User for locations: POO and EXT
        //Creates one rule for EXT

        //Arrange
        TestUserModel.UserDetails udRuleManPOOEXT = Users_API.RulesManagerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOOEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOOEXT.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_EXT();

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        TestUserModel.UserDetails udRuleViewEXT= Users_API.RulesViewerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleViewEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleViewEXT.pid);

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject viewListRulesResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        int ruleNo = API.RulesManagementService.Utils.Rules.GetNoOfMatchingRuleFromRuleList(viewListRulesResponse, createRuleResponse.uniqueId);
        String actRuleID = viewListRulesResponse.content.get(ruleNo).ruleId;

        //TODO update check to confirm rule created successfully, can't use rule id now as rule id is not unique
        ruleDetails.ruleId = "LOC" + "-POO-" + "\\d{4}-\\d{2}";
        Assertions.assertThat(actRuleID).containsPattern(ruleDetails.ruleId);
    }


    @Test
    @Category(ChangeRequest.CR_586.class)
    public void WhenNationalRuleManagerCreatesLocalRule_LocationSetToLocal() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLOCRuleNatManager();
        ruleDetails.locations.add(Locations.Location_ABZ_UID);

        //Act
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        //Assert
        assertEquals("Expect only 1 location: ", 1, viewRuleVerResponse.locations.size());
        assertEquals(ruleDetails.locations.get(0), viewRuleVerResponse.locations.get(0).locationUuid);
    }


    @Test
    @Category(ChangeRequest.CR_586.class)
    public void WhenNationalUserSavesLocalRuleForMultipleLocations_RuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLOCRuleNatManager();

        ruleDetails.locations.add(Locations.Location_EXT_UID);
        ruleDetails.locations.add(Locations.Location_BHX_UID);
        ruleDetails.locations.add(Locations.Location_ABZ_UID);

        //Act
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        //Assert
        assertEquals("Expect only 3 location: ", 3, viewRuleVerResponse.locations.size());

        List<String> actLocations = new ArrayList<String>();
        for (int i=0; i < viewRuleVerResponse.locations.size(); i++){
            actLocations.add(viewRuleVerResponse.locations.get(i).locationUuid);
        }

        assertTrue("3 Locations as expected: ", actLocations.containsAll(ruleDetails.locations));
    }


    @Test
    @Category(ChangeRequest.CR_621.class)
    public void WhenLocalRuleLocationUpdated_RuleCanBeViewedByUserFromNewLocation() throws Throwable
    {
        //Local Rules Manager User creates Local Rule for POO
        //Local Rules Manager User updates location to use at location EXT
        //Local User from EXT can view Rule

        //Arrange
        TestUserModel.UserDetails udRuleManPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOO.pid);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        TestRuleModel.RuleDetails ruleDetailsLocEXT = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        ruleDetailsLocEXT.description = "ta_LocalRuleEXT";
        ruleDetailsLocEXT.locations.clear();
        ruleDetailsLocEXT.locations.add((Locations.Location_EXT_UID));

        ruleDetailsLocEXT.uniqueID = createRuleResponse.uniqueId;
        API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetailsLocEXT);

        TestUserModel.UserDetails udRuleViewEXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleViewEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleViewEXT.pid);

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject viewListRulesResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        int ruleNo = API.RulesManagementService.Utils.Rules.GetNoOfMatchingRuleFromRuleList(viewListRulesResponse, createRuleResponse.uniqueId);
        assertEquals( ruleDetailsLocEXT.description, viewListRulesResponse.content.get(ruleNo).description);
    }


    @Test
    @Category({ChangeRequest.CR_624.class, ChangeRequest.CR_1204.class})
    public void WhenLocalRulesManagerSavesLocalRule_RuleIDSetToLOCWithBaseLocationSequenceNoAndYear()
    {
        //Arrange
        TestUserModel.UserDetails udRuleManPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOO.pid);

        //Act
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(createRuleResponse.uniqueId);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        ViewRuleListResponse.ViewRuleListResponseObject viewListRulesResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        Assertions.assertThat(createRuleResponse.ruleId).containsPattern(ruleDetails.ruleId);
        Assertions.assertThat(viewRuleResponse.ruleId).containsPattern(ruleDetails.ruleId);
        Assertions.assertThat(viewRuleVerResponse.ruleId).containsPattern(ruleDetails.ruleId);

        int ruleNo = API.RulesManagementService.Utils.Rules.GetNoOfMatchingRuleFromRuleList(viewListRulesResponse, createRuleResponse.uniqueId);
        String actRuleID = viewListRulesResponse.content.get(ruleNo).ruleId;

        Assertions.assertThat(actRuleID).containsPattern(ruleDetails.ruleId);
    }


    @Test
    @Category({ChangeRequest.CR_1204.class})
    public void WhenLocalRulesManagerWith2LocationsSavesLocalRuleFor2ndLocation_RuleIDSetToLOCWithBaseLocationSequenceNoAndYear()
    {
        //Arrange
        TestUserModel.UserDetails udRuleManPOOEXT = Users_API.RulesManagerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udRuleManPOOEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udRuleManPOOEXT.pid);

        //Act
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_EXT();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(createRuleResponse.uniqueId);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        ViewRuleListResponse.ViewRuleListResponseObject viewListRulesResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        ruleDetails.ruleId = "LOC" + "-POO-" + "\\d{4}-\\d{2}";       //POO is the base location for user, but rule has been created for EXT
        Assertions.assertThat(createRuleResponse.ruleId).containsPattern(ruleDetails.ruleId);
        Assertions.assertThat(viewRuleResponse.ruleId).containsPattern(ruleDetails.ruleId);
        Assertions.assertThat(viewRuleVerResponse.ruleId).containsPattern(ruleDetails.ruleId);

        int ruleNo = API.RulesManagementService.Utils.Rules.GetNoOfMatchingRuleFromRuleList(viewListRulesResponse, createRuleResponse.uniqueId);
        String actRuleID = viewListRulesResponse.content.get(ruleNo).ruleId;

        Assertions.assertThat(actRuleID).containsPattern(ruleDetails.ruleId);
    }

    @Test
    @Category({ChangeRequest.CR_586.class, ChangeRequest.CR_1204.class})
    public void WhenNationalUserSavesLocalRule_RuleIDSetLOCWithNATBaseLocationSequenceNoAndYear()
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLOCRuleNatManager();

        //Act
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        ViewRuleListResponse.ViewRuleListResponseObject viewListRulesResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        int ruleNo = API.RulesManagementService.Utils.Rules.GetNoOfMatchingRuleFromRuleList(viewListRulesResponse, createRuleResponse.uniqueId);
        String actRuleID = viewListRulesResponse.content.get(ruleNo).ruleId;

        Assertions.assertThat(actRuleID).containsPattern(ruleDetails.ruleId);
    }


    @Test
    @Category({ChangeRequest.CR_586.class, ChangeRequest.CR_1204.class})
    public void WhenNationalUserChangesLocationOnLocalRule_RuleIDDoesNotChange()
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLOCRuleNatManager();

        //Act
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        String v1RuleID = createRuleResponse.ruleId;

        ruleDetails.uniqueID = createRuleResponse.uniqueId;
        ruleDetails.locations.add(0, Locations.Location_EXT_UID);
        EditRuleResponse.PutResponse editResponse = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetails);

        ViewRuleListResponse.ViewRuleListResponseObject viewListRulesResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        int ruleNo = API.RulesManagementService.Utils.Rules.GetNoOfMatchingRuleFromRuleList(viewListRulesResponse, createRuleResponse.uniqueId);
        String actRuleID = viewListRulesResponse.content.get(ruleNo).ruleId;

        assertEquals(v1RuleID, actRuleID);
    }

    @Test
    @Category(ChangeRequest.CR_2975.class)
    public void WhenFallbackIsEdited_RuleShouldShowEditedDetailsCorrectly() throws Throwable
    {
        //National Rules Manager User creates National Rule
        //A Local Rule Manager: POO can NOT view the created local rule

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLOCRuleNatManager();
        ruleDetails.fallback=true;
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ruleDetails.uniqueID = createRuleResponse.uniqueId;
        ruleDetails.fallback=false;
        EditRuleResponse.PutResponse editResponse = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetails);
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(createRuleResponse.uniqueId);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        //Assert
        assertEquals("Fallback", true, createRuleResponse.fallback);
        assertEquals("Fallback", false, editResponse.fallback);

    }

}
