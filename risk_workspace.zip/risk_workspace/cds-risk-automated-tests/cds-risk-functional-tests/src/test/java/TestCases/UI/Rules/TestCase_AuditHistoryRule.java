package TestCases.UI.Rules;

import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Rules;
import Categories_CDSRisk.CDS_Risk_UI_Rules_1;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleDetails_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_1.class})
public class TestCase_AuditHistoryRule extends BaseUIWebDriverTestCase{

    @Test
    @Category({ChangeRequest.CR_2149.class})
    public void WhenRuleIsCreated_AuditHistoryForRuleIsAvailable() throws InterruptedException {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page =  utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(createRuleResponse.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //Act
        ruleSummary_page.commitAndConfirm();

        utilNavigation = new Navigation(driver);
        listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        publishAndWait(5000);

        //Assert
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        ruleSummary_page = new RuleSummary_Page(driver);
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        assertEquals("Expect Rule Status to be Active", "Active", listRuleSummaryTableObjects.get(0).status);
        assertEquals("Expect Rule Version to be 1", 1, listRuleSummaryTableObjects.get(0).version);
        assertEquals("Expect Rule Name to be " + ruleDetails.description, ruleDetails.description, listRuleSummaryTableObjects.get(0).description);

        ruleSummary_page.ruleHistoryLog.click();

        ruleSummary_page.waitForAngularRequestsToFinish();

        List<RuleSummary_Page.RuleHistoryLog> listRuleHistoryTableObjects = ruleSummary_page.getListOfRuleHistoryLogs();

        assertEquals("Expect Rule Version to be 1", 1, listRuleHistoryTableObjects.get(0).revision);
        assertEquals("Expect Rule Change Author is ", UserDetails.getFullName(), listRuleHistoryTableObjects.get(0).changeAuthor);
        assertEquals("Expect Rule Change is ", "Created", listRuleHistoryTableObjects.get(0).change);
        assertEquals("Expect Change Reason is ", "Testing", listRuleHistoryTableObjects.get(0).changeReason);

        ruleSummary_page.suspendAndConfirm();

        ruleSummary_page.waitForAngularRequestsToFinish();

        publishAndWait(5000);

        ruleSummary_page.refreshPage();

        ruleSummary_page.ruleHistoryLog.click();

        List<RuleSummary_Page.RuleHistoryLog> listRuleHistoryTableObjects2 = ruleSummary_page.getListOfRuleHistoryLogs();

        assertEquals("Expect Rule Version to be 1", 1, listRuleHistoryTableObjects2.get(0).revision);
        assertEquals("Expect Rule Change Author is ", UserDetails.getFullName(), listRuleHistoryTableObjects2.get(0).changeAuthor);
        assertEquals("Expect Rule Change is ", "Suspended", listRuleHistoryTableObjects2.get(0).change);
        assertEquals("Expect Change Reason is ", "Suspending the rule", listRuleHistoryTableObjects2.get(0).changeReason);

        listRuleHistoryTableObjects2.get(0).versionDetailAction.click();

        RuleDetails_Page ruleDetails_page = new RuleDetails_Page(driver);
        ruleDetails_page.waitForAngularRequestsToFinish();
        Assertions.assertThat(ruleDetails_page.sectionHeaderRuleID.getText()).containsPattern(ruleDetails.ruleId);
    }
}