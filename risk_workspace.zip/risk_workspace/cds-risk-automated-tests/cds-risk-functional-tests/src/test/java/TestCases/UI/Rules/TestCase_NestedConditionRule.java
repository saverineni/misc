package TestCases.UI.Rules;


import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.*;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.DataForTests.Conditions;
import UI.Pages.RulesManagement.CreateLocalRule_Page;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleDetails_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.ArrayList;
import java.util.List;

import static UI.DataForTests.TestRuleModel.RuleDetails.Condition.Attribute.*;
import static UI.DataForTests.TestRuleModel.RuleDetails.Condition.AttributeType.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_3.class})
public class TestCase_NestedConditionRule extends BaseUIWebDriverTestCase{

    @Test
    public void WhenManagerLoggedIn_CanCreateRuleWithMultipleANDConditions(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();
        ruleDetails.conditionGroups.get(0).conditions.clear();

        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.commodityCode());
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = ITEM;

        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.dispatchCountry());
        ruleDetails.conditionGroups.get(0).conditions.get(1).attributeType = HEADER;

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleMultipleConditions(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);

        //TODO Additional checking
    }

    @Test
    public void WhenManagerLoggedIn_CanCreateRuleWithMultipleORConditions(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();

        ruleDetails.conditionGroups.get(0).groupOperator = UI.DataForTests.TestRuleModel.RuleDetails.GroupOperator.OR;
        ruleDetails.conditionGroups.get(0).conditions.clear();
        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.dispatchCountry());
        ruleDetails.conditionGroups.get(0).conditions.get(0).attribute = DISPATCH_COUNTRY_HEADER;
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = HEADER;

        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.countryCode_Item());
        ruleDetails.conditionGroups.get(0).conditions.get(1).attribute = COUNTRY_CODE_ITEM;
        ruleDetails.conditionGroups.get(0).conditions.get(1).attributeType = ITEM;

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleMultipleConditions(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert

        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);

        //TODO Additional checking
    }


    @Test
    public void WhenManagerLoggedIn_CanCreateRuleWithMultipleGroupConditions(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();

        ruleDetails.conditionGroups.get(0).conditions.clear();
        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.commodityCode());
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = ITEM;

        List<UI.DataForTests.TestRuleModel.RuleDetails.ConditionGroup> conditionGroups = new ArrayList<>();
        conditionGroups.addAll(ruleDetails.conditionGroups);


        UI.DataForTests.TestRuleModel.RuleDetails.ConditionGroup conditionGroup = new UI.DataForTests.TestRuleModel.RuleDetails.ConditionGroup();
        conditionGroup.groupOperator = UI.DataForTests.TestRuleModel.RuleDetails.GroupOperator.OR;

        List<UI.DataForTests.TestRuleModel.RuleDetails.Condition> conditions = new ArrayList<>();

        conditions.add(Conditions.countryCode_Item());
        conditions.add(Conditions.consigneeName());

        conditionGroup.conditions = conditions;

        conditionGroups.add(conditionGroup);
        ruleDetails.conditionGroups = conditionGroups;

        ruleDetails.conditionGroups.get(1).conditions.get(0).attributeType = ITEM;
        ruleDetails.conditionGroups.get(1).conditions.get(1).attributeType = HEADER;


        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleMultipleGroupConditions(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();
        String actMessage = createLocalRule_page.getSuccessMessage();

        RuleSummary_Page ruleSummary_page = createLocalRule_page.clickViewRule();
        List<RuleSummary_Page.RuleSummaryTableObject> ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        ruleSummaryTableObjects.get(0).versionDetailAction.click();

        RuleDetails_Page ruleDetails_page = new RuleDetails_Page(driver);

        //Assert

        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(0).attribute.displayText, ruleDetails_page.ruleAttributes.get(0).getText());
        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(0).operator,  ruleDetails_page.ruleOperators.get(0).getText());
        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(0).value, ruleDetails_page.ruleValues.get(0).getText());

        assertEquals(ruleDetails.conditionGroups.get(1).conditions.get(0).attribute.displayText, ruleDetails_page.ruleAttributes.get(1).getText());
        assertEquals(ruleDetails.conditionGroups.get(1).conditions.get(0).operator,  ruleDetails_page.ruleOperators.get(1).getText());
        assertEquals(ruleDetails.conditionGroups.get(1).conditions.get(0).value, ruleDetails_page.ruleValues.get(1).getText());

        assertEquals(ruleDetails.conditionGroups.get(1).conditions.get(1).attribute.displayText, ruleDetails_page.ruleAttributes.get(2).getText());
        assertEquals(ruleDetails.conditionGroups.get(1).conditions.get(1).operator,  ruleDetails_page.ruleOperators.get(2).getText());
        assertEquals(ruleDetails.conditionGroups.get(1).conditions.get(1).value, ruleDetails_page.ruleValues.get(2).getText());

    }

    @Test
    @Category({ChangeRequest.CR_2782.class,ChangeRequest.CR_2769.class})
    public void WhenRuleCreatedWithHeaderCollectionsCommitted_RuleCommittedSuccessfully(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();

        ruleDetails.conditionGroups.get(0).groupOperator = UI.DataForTests.TestRuleModel.RuleDetails.GroupOperator.OR;
        ruleDetails.conditionGroups.get(0).conditions.clear();
        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.additionalInformation_CodeHeaderCollection());
        ruleDetails.conditionGroups.get(0).conditions.get(0).attribute = ADDITIONAL_INFO_CODE_HEADER_COLLECTION;
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = HEADER_COLLECTION;

        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.additionalInformation_TextHeaderCollection());
        ruleDetails.conditionGroups.get(0).conditions.get(1).attribute = ADDITIONAL_INFO_TEXT_HEADER_COLLECTION;
        ruleDetails.conditionGroups.get(0).conditions.get(1).attributeType = HEADER_COLLECTION;

        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.additionalDocument_TypeHeaderCollection());
        ruleDetails.conditionGroups.get(0).conditions.get(2).attribute = ADDITIONAL_INFO_DOCUMENT_TYPE_HEADER_COLLECTION;
        ruleDetails.conditionGroups.get(0).conditions.get(2).attributeType = HEADER_COLLECTION;

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleMultipleConditions(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        String actMessage = createLocalRule_page.getSuccessMessage();

        RuleSummary_Page ruleSummary_page = createLocalRule_page.clickViewRule();
        List<RuleSummary_Page.RuleSummaryTableObject> ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        ruleSummaryTableObjects.get(0).versionDetailAction.click();
        RuleDetails_Page ruleDetails_page = new RuleDetails_Page(driver);

        createLocalRule_page.getListOfFilteredAttributeValues();

        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(0).attribute.displayText, ruleDetails_page.ruleAttributes.get(0).getText());
        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(0).operator,  ruleDetails_page.ruleOperators.get(0).getText());
        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(0).value, ruleDetails_page.ruleValues.get(0).getText());

        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(1).attribute.displayText, ruleDetails_page.ruleAttributes.get(1).getText());
        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(1).operator,  ruleDetails_page.ruleOperators.get(1).getText());
        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(1).value, ruleDetails_page.ruleValues.get(1).getText());

        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(2).attribute.displayText, ruleDetails_page.ruleAttributes.get(2).getText());
        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(2).operator,  ruleDetails_page.ruleOperators.get(2).getText());
        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(2).value, ruleDetails_page.ruleValues.get(2).getText());
    }


    @Test
    @Category({ChangeRequest.CR_2770.class})
    public void WhenRuleCreatedWithItemCollectionsCommitted_RuleCommittedSuccessfully(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();

        ruleDetails.conditionGroups.get(0).groupOperator = UI.DataForTests.TestRuleModel.RuleDetails.GroupOperator.OR;
        ruleDetails.conditionGroups.get(0).conditions.clear();
        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.additionalInformation_CodeItemCollection());
        ruleDetails.conditionGroups.get(0).conditions.get(0).attribute = ADDITIONAL_INFO_CODE_ITEM_COLLECTION;
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = ITEM_COLLECTION;

        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.additionalInformation_TextHeaderCollection());
        ruleDetails.conditionGroups.get(0).conditions.get(1).attribute = ADDITIONAL_INFO_TEXT_ITEM_COLLECTION;
        ruleDetails.conditionGroups.get(0).conditions.get(1).attributeType = ITEM_COLLECTION;

        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.additionalDocument_TypeHeaderCollection());
        ruleDetails.conditionGroups.get(0).conditions.get(2).attribute = ADDITIONAL_INFO_DOCUMENT_TYPE_ITEM_COLLECTION;
        ruleDetails.conditionGroups.get(0).conditions.get(2).attributeType = ITEM_COLLECTION;

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleMultipleConditions(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        String actMessage = createLocalRule_page.getSuccessMessage();

        RuleSummary_Page ruleSummary_page = createLocalRule_page.clickViewRule();
        List<RuleSummary_Page.RuleSummaryTableObject> ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        ruleSummaryTableObjects.get(0).versionDetailAction.click();
        RuleDetails_Page ruleDetails_page = new RuleDetails_Page(driver);

        createLocalRule_page.getListOfFilteredAttributeValues();

        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(0).attribute.displayText, ruleDetails_page.ruleAttributes.get(0).getText());
        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(0).operator,  ruleDetails_page.ruleOperators.get(0).getText());
        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(0).value, ruleDetails_page.ruleValues.get(0).getText());

        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(1).attribute.displayText, ruleDetails_page.ruleAttributes.get(1).getText());
        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(1).operator,  ruleDetails_page.ruleOperators.get(1).getText());
        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(1).value, ruleDetails_page.ruleValues.get(1).getText());

        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(2).attribute.displayText, ruleDetails_page.ruleAttributes.get(2).getText());
        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(2).operator,  ruleDetails_page.ruleOperators.get(2).getText());
        assertEquals(ruleDetails.conditionGroups.get(0).conditions.get(2).value, ruleDetails_page.ruleValues.get(2).getText());
    }

}
