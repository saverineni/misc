package TestCases.UI.DataTables;

import API.DataForTests.DataTables;
import API.DataForTests.TestDataTableModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_DataTables;
import Categories_CDSRisk.CDS_Risk_UI_DataTables_1;
import Categories_CDSRisk.ChangeRequest;
import FunctionsLibrary.DateTime;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.Pages.DataManagement.DataTableHistory_Page;
import UI.Pages.DataManagement.DataTableSummary_Page;
import UI.Pages.DataManagement.ListDataTable_Page;
import UI.Utils.Navigation;
import org.junit.Assert;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;

import static API.RulesManagementService.Utils.DataTables.*;
import static FunctionsLibrary.Utils.SleepForMilliSeconds;
import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_DataTables.class, CDS_Risk_UI_DataTables_1.class})
public class TestCase_DataTableHistory extends BaseUIWebDriverTestCase {

    @Category(ChangeRequest.CR_2203.class)
    @Test
    public void WhenDataAddedToDataTableByDifferentUser_CorrectEventsDisplayedInDataTableHistoryTable() {

        //Arrange
        TestUserModel.UserDetails udNatRulesManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;
        tableDetails.uniqueId = createDataTableResponse.uniqueId;

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        TestUserModel.UserDetails udNatRulesManager2 = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(udNatRulesManager2);
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRulesManager2.pid);

        tableDetails.dataItemsToAdd.add("1000000000");
        tableDetails.dataItemsToAdd.add("2000000000");
        tableDetails.dataItems.addAll(tableDetails.dataItemsToAdd);

        EditDataTableAndGetResponseObject(tableDetails);
        
        //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(udNatRulesManager2);

        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listMyDataTables_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = listMyDataTables_page.clickTableSummaryForSpecifiedDataTableID(createDataTableResponse.uniqueId);

        //Act
        dataTableSummary_page.dataTableHistory.click();
        
        DataTableHistory_Page dataTableHistory_page = new DataTableHistory_Page(driver);
        List<DataTableHistory_Page.DTHistoryObject> listDTHistoryObjects = dataTableHistory_page.getListOfDataTableHistory();

        //Assert
        assertEquals("Expected Events: 2", 2, listDTHistoryObjects.size());

        assertEquals("Expected version 2", "2", listDTHistoryObjects.get(0).tableVersion);
        assertEquals(udNatRulesManager2.getFullName(), listDTHistoryObjects.get(0).changeAuthor);

        LocalDateTime expDateTime = LocalDateTime.now(ZoneId.of("UTC")).plusMinutes(-2);
        LocalDateTime actDateTime =  DateTime.FormatTextToLocalDateTime(listDTHistoryObjects.get(0).changeDate, "dd/MM/yyyy HH:mm");
        Assert.assertTrue(actDateTime.isAfter(expDateTime));

        assertEquals("Expected version 1", "1", listDTHistoryObjects.get(1).tableVersion);
        assertEquals(udNatRulesManager.getFullName(), listDTHistoryObjects.get(1).changeAuthor);

    }

    @Category({ChangeRequest.CR_2217.class, ChangeRequest.CR_3063.class})
    @Test
    public void WhenDataDatAndHeaderEdited_AndHistoryTableDisplaysCorrectInfo_CanGoToTableSummaryPage() {


        //Arrange
        TestUserModel.UserDetails udNatRulesManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;
        tableDetails.uniqueId = createDataTableResponse.uniqueId;

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        tableDetails.dataItemsToAdd.add("1000000000");
        tableDetails.dataItemsToAdd.add("2000000000");
        tableDetails.dataItems.addAll(tableDetails.dataItemsToAdd);

        editDataTableDataItems(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail1 = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        TestDataTableModel.TableDetails tableDetails1 = DataTables.DataTable_NoData();
        tableDetails1.opLockVersion = responseDetail1.opLockVersion;

        tableDetails1.tableName = "Table edited for testing";
        tableDetails1.uuid = createDataTableResponse.uuid;
        EditDataTableHeaderDetailsAndGetResponseObject(tableDetails1);

        //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(udNatRulesManager);

        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listMyDataTables_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        DataTableSummary_Page dataTableSummary_page = listMyDataTables_page.clickTableSummaryForSpecifiedDataTableID(createDataTableResponse.uniqueId);

        //Act
        dataTableSummary_page.dataTableHistory.click();

        DataTableHistory_Page dataTableHistory_page = new DataTableHistory_Page(driver);
        dataTableHistory_page.scrollToViewTheElement( dataTableHistory_page.allFilter);
        dataTableHistory_page.allFilter.click();
        List<DataTableHistory_Page.DTHistoryObject> listDTHistoryObjects = dataTableHistory_page.getListOfDataTableHistory();
        assertEquals("Expected Events: 3", 3, listDTHistoryObjects.size());

        //assert
        dataTableHistory_page.dataFilter.click();
        SleepForMilliSeconds(1000);
        List<DataTableHistory_Page.DTHistoryObject> listDTHistoryObjects1 = dataTableHistory_page.getListOfDataTableHistory();
        assertEquals("Expected version 2", "2", listDTHistoryObjects1.get(0).tableVersion);
        assertEquals("Expected version 1", "1", listDTHistoryObjects1.get(1).tableVersion);
        assertEquals(udNatRulesManager.getFullName(), listDTHistoryObjects1.get(0).changeAuthor);

        dataTableHistory_page.scrollToViewTheElement(dataTableHistory_page.nonDataFilter);
        dataTableHistory_page.nonDataFilter.click();
        SleepForMilliSeconds(1000);
        List<DataTableHistory_Page.DTHistoryObject> listDTHistoryObjects2 = dataTableHistory_page.getListOfDataTableHistory();
        assertEquals("Expected version 3", "3", listDTHistoryObjects2.get(0).tableVersion);
        assertEquals("Expected version 1", "1", listDTHistoryObjects2.get(1).tableVersion);
        assertEquals(udNatRulesManager.getFullName(), listDTHistoryObjects2.get(0).changeAuthor);

        dataTableHistory_page.allFilter.click();
        SleepForMilliSeconds(1000);
        dataTableHistory_page.selectViewTableSummary();
        DataTableSummary_Page summary_page = new DataTableSummary_Page(driver);
        assertEquals("Expected version 3", "3", summary_page.version.getText());
        dataTableHistory_page.selectBackToLatestVersion();
        assertEquals("Data Items", summary_page.dataTab.getText());
    }


    @Category({ChangeRequest.CR_2724.class, ChangeRequest.CR_2949.class})
    @Test
    public void WhenDataTableIsArchived_DataTableHistoryUpdatedSuccessfully() {

        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();

        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;
        tableDetails.uniqueId = createDataTableResponse.uniqueId;

        TestUserModel.UserDetails UserDetails = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);
        Navigation utilNavigation = new Navigation(driver);

        ListDataTable_Page listDataTable_page = utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);
        DataTableSummary_Page summaryPage = listDataTable_page.clickTableSummaryForSpecifiedDataTableID(tableDetails.uniqueId);
        summaryPage.isElementDisplayed(summaryPage.datatableArchive);

        //Act
        summaryPage.datatableArchive.click();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        summaryPage.dataTableHistory.click();

        DataTableHistory_Page dataTableHistory_page = new DataTableHistory_Page(driver);
        dataTableHistory_page.scrollToViewTheElement(dataTableHistory_page.allFilter);
        dataTableHistory_page.allFilter.click();
        List<DataTableHistory_Page.DTHistoryObject> listDTHistoryObjects = dataTableHistory_page.getListOfDataTableHistory();

        //Assert
        assertEquals("Expected Events: 2", 2, listDTHistoryObjects.size());
        assertEquals("Expected version 2", "2", listDTHistoryObjects.get(0).tableVersion);
        assertEquals("Expected change type", "Non-Data", listDTHistoryObjects.get(0).changeType);
    }

}
