package TestCases.RiskingServiceJava.NarrativeResponse;

import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.Risking_JavaService;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.Matcher;
import uk.gov.hmrc.risk.test.common.enums.MatcherType;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.Condition;

import java.util.Arrays;

import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.Source;
import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.conditions;

@Slf4j
@Category({ChangeRequest_RiskingService.CREP_378.class, ChangeRequest_RiskingService.CREP_382.class,
        Risking_JavaService.class})
public class TestCase_NumericalOperatorNarratives extends BaseNarrativeTest {

    @Test
    public void WhenRuleWithEqualToOperatorIsHit_CorrectNarrativeIsPresent() {
        Condition invoicePrice = invoicePriceItem();
        invoicePrice.setMatcher(Matcher.equalTo);
        invoicePrice.setMatcherType(MatcherType.EQUAL);
        invoicePrice.setDeclarationValue("10");

        createRule(Source.goodsItem, Arrays.asList(), conditions( invoicePrice ));

        DeclarationResponse response = createAndSendDeclaration( conditions( invoicePrice));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).contains(
            "Goods Item (sequenceId=2001) field: 'Invoice Price' was equal to 10. The value was: 10"
        );
    }

    @Test
    public void WhenRuleWithLessThanOperatorIsHit_CorrectNarrativeIsPresent() {
        Condition invoicePrice = invoicePriceItem();
        invoicePrice.setMatcher(Matcher.lessThan);
        invoicePrice.setMatcherType(MatcherType.LESS_THAN);

        createRule(Source.goodsItem, Arrays.asList(), conditions( invoicePrice ));

        DeclarationResponse response = createAndSendDeclaration( conditions( invoicePrice));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).contains(
                "Goods Item (sequenceId=2001) field: 'Invoice Price' was less than 10. The value was: 9"
        );
    }

    @Test
    public void WhenRuleWithGreaterThanOrEqualOperatorIsHit_CorrectNarrativeIsPresent() {

        Condition invoicePrice = invoicePriceItem();
        invoicePrice.setMatcher(Matcher.greaterThanOrEqualTo);
        invoicePrice.setMatcherType(MatcherType.GREATER_THAN_EQUAL_TO);
        invoicePrice.setDeclarationValue("11");

        createRule(Source.goodsItem, Arrays.asList(), conditions( invoicePrice ));

        DeclarationResponse response = createAndSendDeclaration( conditions( invoicePrice));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).contains(
                "Goods Item (sequenceId=2001) field: 'Invoice Price' was greater than or equal to 10. The value was: 11"
        );
    }

    @Test
    public void WhenRuleWithGreaterThanOperatorIsHit_CorrectNarrativeIsPresent() {

        Condition invoicePrice = invoicePriceItem();
        invoicePrice.setMatcher(Matcher.greaterThan);
        invoicePrice.setMatcherType(MatcherType.GREATER_THAN);
        invoicePrice.setDeclarationValue("11");

        createRule(Source.goodsItem, Arrays.asList(), conditions( invoicePrice ));

        DeclarationResponse response = createAndSendDeclaration( conditions( invoicePrice));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).contains(
              "Goods Item (sequenceId=2001) field: 'Invoice Price' was greater than 10. The value was: 11"
        );
    }

    @Test
    public void WhenRuleWithLessThanOrEqualOperatorIsHit_CorrectNarrativeIsPresent() {
        Condition invoicePrice = invoicePriceItem();
        invoicePrice.setMatcher(Matcher.lessThanOrEqualTo);
        invoicePrice.setMatcherType(MatcherType.LESS_THAN_EQUAL_TO);
        invoicePrice.setDeclarationValue("9");

        createRule(Source.goodsItem, Arrays.asList(), conditions( invoicePrice ));

        DeclarationResponse response = createAndSendDeclaration( conditions( invoicePrice));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).contains(
                "Goods Item (sequenceId=2001) field: 'Invoice Price' was less than or equal to 10. The value was: 9"
        );
    }
}
