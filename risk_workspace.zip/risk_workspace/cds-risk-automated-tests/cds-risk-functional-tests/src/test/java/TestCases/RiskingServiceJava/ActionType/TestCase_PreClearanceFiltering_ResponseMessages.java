package TestCases.RiskingServiceJava.ActionType;

import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.ChangeRequest_RiskingService.CREP_255;
import Categories_CDSRisk.Risking_JavaService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Category({CREP_255.class, ChangeRequest_RiskingService.CREP_290.class, Risking_JavaService.class})
public class TestCase_PreClearanceFiltering_ResponseMessages extends BaseActionTypeTest {

    private String preClearanceCtrlType;
    private String postClearanceCtrlType;

    @Test
    public void WhenPreClearanceAndDocumentCheckAreSet_ThenHoldNarrativeIsDisplayedAndReleaseIsBlocked() {

        //When
        CreateRuleModel.RuleOutputs outputs = CreateRuleModel.RuleOutputs.builder()
                .actionType("4")
                .holdNarrative(HOLD_NARRATIVE)
                .holdPercentage(100)
                .releaseNarrative(RELEASE_NARRATIVE)
                .releasePercentage(0)
                .assigneeId(ASSIGNEE_ID)
                .build();

        //Then
        createRule(outputs);
        DeclarationResponse response = sendDeclaration(createDeclaration(), false);

        //Assert
        assertDeclarationResponse(response, expectedDocCheckHold());
    }

    @Test
    public void WhenPreClearanceSetToAHighValueWithDocCheck_ControlType1AndBlockingReleaseIs() {

        //When
        CreateRuleModel.RuleOutputs outputs = CreateRuleModel.RuleOutputs.builder()
                .actionType("4")
                .holdNarrative(HOLD_NARRATIVE)
                .holdPercentage(90)
                .releaseNarrative(RELEASE_NARRATIVE)
                .releasePercentage(10)
                .assigneeId(ASSIGNEE_ID)
                .build();

        //Then
        createRule(outputs);

        List<DeclarationResponse> declarationResponseList = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            declarationResponseList.add( sendDeclaration(createDeclaration(), false) );
        }

        //Assert
        Assert.assertTrue("PreClearance count should be 4",
                declarationResponseList.stream().filter(res -> res.getNarrativeText().equals(HOLD_NARRATIVE)).count() == 4);
        Assert.assertTrue("PostClearance count should be 1",
                declarationResponseList.stream().filter(res -> res.getNarrativeText().equals(RELEASE_NARRATIVE)).count() == 1);

        declarationResponseList.forEach( declarationResponse -> {
            switch (declarationResponse.getNarrativeText()) {
                case HOLD_NARRATIVE:
                    assertDeclarationResponse(declarationResponse, expectedDocCheckHold());
                    break;
                case RELEASE_NARRATIVE:
                    assertDeclarationResponse(declarationResponse, expectedDocCheckRelease());
                    break;
                default:
                    throw new AssertionError("Default route found and not expected");
            }
        });
    }

    @Test
    public void WhenPreClearanceSetToLowValueAndDocCheck_ControlType1AndBlockingReleaseIsFalse() {

        //When
        CreateRuleModel.RuleOutputs outputs = CreateRuleModel.RuleOutputs.builder()
                .actionType("4")
                .holdNarrative(HOLD_NARRATIVE)
                .holdPercentage(30)
                .releaseNarrative(RELEASE_NARRATIVE)
                .releasePercentage(70)
                .assigneeId(ASSIGNEE_ID)
                .build();

        //Then
        createRule(outputs);

        List<DeclarationResponse> declarationResponseList = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            declarationResponseList.add( sendDeclaration(createDeclaration(), false) );
        }

        //Assert
        Assert.assertTrue("PreClearance count should be 4",
                declarationResponseList.stream().filter(res -> res.getNarrativeText().equals(HOLD_NARRATIVE)).count() == 3);
        Assert.assertTrue("PostClearance count should be 1",
                declarationResponseList.stream().filter(res -> res.getNarrativeText().equals(RELEASE_NARRATIVE)).count() == 7);

        declarationResponseList.forEach( declarationResponse -> {
            switch (declarationResponse.getNarrativeText()) {
                case HOLD_NARRATIVE:
                    assertDeclarationResponse(declarationResponse, expectedDocCheckHold());
                    break;
                case RELEASE_NARRATIVE:
                    assertDeclarationResponse(declarationResponse, expectedDocCheckRelease());
                    break;
                default:
                    throw new AssertionError("Default route found and not expected");
            }
        });
    }
}
