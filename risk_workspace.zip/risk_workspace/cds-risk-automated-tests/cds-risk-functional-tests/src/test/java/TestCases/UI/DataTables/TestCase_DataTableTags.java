package TestCases.UI.DataTables;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.*;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.Dialog_Confirm;
import UI.DataForTests.TestDataTableModel;
import UI.Pages.DataManagement.CreateDataTable_Page;
import UI.Utils.Navigation;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.openqa.selenium.Keys;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@Slf4j
@Category({CDS_Risk_UI.class, CDS_Risk_UI_DataTables.class, CDS_Risk_UI_DataTables_2.class})
public class TestCase_DataTableTags extends BaseUIWebDriverTestCase {

    @Before
    public void AddMultipleTagsToMultipleTables2(){

        addMultipleTagsToDataTable();
    }

    private void addMultipleTagsToDataTable() {

        List<String> table1Tags = new ArrayList<>();
        table1Tags.add("primaryTag");
        table1Tags.add("secondaryTag");
        table1Tags.add("newTag");
        table1Tags.add("newTag1Tag");

        List<String> table2Tags = new ArrayList<>();
        table2Tags.add("primaryTag");
        table2Tags.add("table2Tag");
        table2Tags.add("table2newTag");
        table2Tags.add("table2Tag");

        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        //create 1st data table
        Navigation utilNavigation = new Navigation(driver);
        CreateDataTable_Page createDataTable_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        TestDataTableModel.TableDetails tableDetails = UI.DataForTests.DataTables.DataTable_WithMultipleTags(table1Tags);

        createDataTable_page.populateDataTableFields(tableDetails);

        createDataTable_page.clickSaveAndPublishButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        //create second table
        utilNavigation = new Navigation(driver);
        createDataTable_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        tableDetails = UI.DataForTests.DataTables.DataTable_WithMultipleTags(table2Tags);

        createDataTable_page.populateDataTableFields(tableDetails);
    }


    @Test
    @Category({CDS_Risk_UI.class, CDS_Risk_UI_DataTables.class, CDS_Risk_UI_DataTables_2.class, ChangeRequest.CR_1566.class})
    public void WhenAddingTagsToDataTable_SuggestionListContainsMostPopularTagFirst(){

        //Act
        CreateDataTable_Page createDataTable_page = new CreateDataTable_Page(driver);
        createDataTable_page.clickSaveAndPublishButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        Navigation utilNavigation = new Navigation(driver);
        createDataTable_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);
        createDataTable_page.tableTags.sendKeys("tag");

        //Assert
        assertTrue(createDataTable_page.suggestedTagsList().get(0), createDataTable_page.suggestedTagsList().get(0).equals("primaryTag"));
        assertTrue(createDataTable_page.suggestedTagsList().contains("primaryTag"));
    }

    @Test
    @Category({CDS_Risk_UI.class, CDS_Risk_UI_DataTables.class, CDS_Risk_UI_DataTables_2.class, ChangeRequest.CR_1566.class})
    public void WhenAddingTagsFromSuggestedList_TagsAddedAndNotPresentOnSuggestedList() throws InterruptedException {

        List<String> tagName = new ArrayList<>();
        tagName.add("primaryTag");
        tagName.add("secondaryTag");
        tagName.add("newTag");
        tagName.add("table2Tag");
        tagName.add("table2newTag");
        tagName.add("table2Tag");

        //act
        CreateDataTable_Page createDataTable_page = new CreateDataTable_Page(driver);
        createDataTable_page.clickSaveAndPublishButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        Navigation utilNavigation = new Navigation(driver);
        createDataTable_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);
        createDataTable_page.tableTags.sendKeys("tag");

        //assert
        while(createDataTable_page.tagSuggestionList.size()>0) {
            createDataTable_page.tagSuggestionList.size();
            createDataTable_page.tableTags.sendKeys(Keys.ARROW_DOWN);
            createDataTable_page.tableTags.sendKeys(Keys.ENTER);

            String[] tagName1 = createDataTable_page.listOfAddedTags.get(0).getText().split(" ");
            String actualTagName =tagName1[0];
            log.debug("Adding a new tag : " + actualTagName);

            //assert most popular tag is displayed.. Once that is added assert it is not displayed again in the list
            assertEquals(tagName.get(0),actualTagName);
            assertTrue(!createDataTable_page.tagSuggestionList.contains(tagName.get(0)));
        }
    }

    @Test
    @Category({UnstableTests.class, ChangeRequest.CR_1566.class})
    public void WhenTryingToAddTags_SuggestedListIsUpdatedAppropriately() throws InterruptedException {

        //act
        List<String> searchItems = new ArrayList<>();
        searchItems.add("p");
        searchItems.add("s");
        searchItems.add("2");
        searchItems.add("-3rp1");

        CreateDataTable_Page createDataTable_page = new CreateDataTable_Page(driver);
        createDataTable_page.clickSaveAndPublishButton();

        Dialog_Confirm dialog_confirm = new Dialog_Confirm(driver);
        dialog_confirm.EnterReasonAndCloseDialogBox("Testing");

        Navigation utilNavigation = new Navigation(driver);
        createDataTable_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateDataTable);

        //assert
        for(int i=0; i<=searchItems.size()-1; i++) {
        createDataTable_page.tableTags.setValue(searchItems.get(i),true);
        createDataTable_page.waitForAngularRequestsToFinish();

            if(searchItems.get(i).equals("p")) {
                createDataTable_page.waitForAngularRequestsToFinish();
                log.debug(createDataTable_page.tagSuggestionList.get(0).getText());
                assertTrue("Wrong suggest list - Expected : primaryTag " , createDataTable_page.tagSuggestionList.get(0).getText().equals("primaryTag"));
            } else if (searchItems.get(i).equals("s")) {
                createDataTable_page.waitForAngularRequestsToFinish();
                String tag = createDataTable_page.tagSuggestionList.get(0).getText();
                log.debug("The actual list : " + tag);
                assertTrue("Wrong suggest list - Expected : secondaryTag " , createDataTable_page.tagSuggestionList.get(0).getText().equals("secondaryTag"));
            } else if (searchItems.get(i).equals("2")) {
                createDataTable_page.waitForAngularRequestsToFinish();
                createDataTable_page.tagSuggestionList.remove(0);
                createDataTable_page.waitForAngularRequestsToFinish();
                assertTrue("Wrong suggest list - Expected : table2newTag ", createDataTable_page.tagSuggestionList.get(0).getText().equals("table2newTag"));
            } else  {
                createDataTable_page.waitForAngularRequestsToFinish();
                assertTrue(createDataTable_page.tagSuggestionList.isEmpty());
            }
        }
    }

    @Test
    @Category({CDS_Risk_UI.class, CDS_Risk_UI_DataTables.class, CDS_Risk_UI_DataTables_2.class, ChangeRequest.CR_1566.class})
    public void WhenAddingTagsToDataTable_UserCanAddAndRemoveTags() throws InterruptedException {

        //remove all tags
        CreateDataTable_Page createDataTable_page = new CreateDataTable_Page(driver);
        createDataTable_page.deleteAllAddedTags();

        //assert
        assertEquals(createDataTable_page.listOfAddedTags.size(),0);

    }
}
