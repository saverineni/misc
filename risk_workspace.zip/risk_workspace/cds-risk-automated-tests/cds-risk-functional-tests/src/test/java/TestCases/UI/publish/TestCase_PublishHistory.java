package TestCases.UI.publish;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Publish;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.MenuToolBar;
import UI.Pages.Publish.Publish_Page;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.ArrayList;
import java.util.List;

import static API.RulesManagementService.Utils.Publish.publishEvent;
import static API.RulesManagementService.Utils.Publish.setPublishAutomaticEventTime;
import static FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays;
import static FunctionsLibrary.DateTime.GetCurrentDateInHoursFormat;
import static org.junit.Assert.assertTrue;

@Slf4j
@Category({CDS_Risk_UI.class, CDS_Risk_UI_Publish.class})
public class TestCase_PublishHistory extends BaseUIWebDriverTestCase{

    @Test
    @Category({ChangeRequest.CR_1761.class, ChangeRequest.CR_1792.class})
    @SneakyThrows
    public void WhenLoggedInAsNationalSuperAdmin_CanViewPublishHistoryTable() throws InterruptedException {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        MenuToolBar menuToolBar = new MenuToolBar(driver);
        menuToolBar.publish.click();

        List<String> reasonForPublishing = new ArrayList<>();
        reasonForPublishing.add("History publish event 1");
        reasonForPublishing.add("History publish event 2");
        reasonForPublishing.add("History publish event 3");

        //Act
        Publish_Page publishPage = new Publish_Page(driver);
        reasonForPublishing.forEach(publishPage::publishImmediately);

        List<Publish_Page.ListPublishHistoryTableObject> historyList =  publishPage.getListOfHistoryItems();

        GetCurrentDateInHoursFormat();
        String actualDate = historyList.get(0).date;
        String userName = UserDetails.firstname + " "+ UserDetails.lastname;

        //assert
        Assertions.assertThat(historyList).hasSize(3);
        Assertions.assertThat(actualDate).containsPattern("../../.... ..:.."); //date pattern //dd/MM/yyyy HH:mm
        Assertions.assertThat(historyList).extracting("publisher")
                .contains(userName);
        Assertions.assertThat(historyList).extracting("reason")
                .containsSequence(reasonForPublishing.get(2), reasonForPublishing.get(1), reasonForPublishing.get(0));
        Assertions.assertThat(historyList).extracting("date").isNotEmpty();
    }

    @Test
    @Category({ChangeRequest.CR_1761.class, ChangeRequest.CR_1792.class})
    public void WhenLoggedInAsNationalSuperAdmin_CanViewNextScheduledPublishEvent() throws InterruptedException {

        //Arrange
        //set it for next day
        String timeInSeconds = "87000";
        setPublishAutomaticEventTime(timeInSeconds);

        TestUserModel.UserDetails UserDetails = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        MenuToolBar menuToolBar = new MenuToolBar(driver);
        menuToolBar.publish.click();

        //Act
        Publish_Page publishPage = new Publish_Page(driver);

        String message = "The next scheduled publish for Rules and Data will be at ";

        String date = AdjustLocalDateTimeNowByXDays(1, "dd/MM/yyyy");
        String nextDay = date.substring(0, 10);
        String nextScheduleMessage = publishPage.nextSchedulePublishMsg.getText();

        log.debug("\n" + nextScheduleMessage);
        log.debug("\n" + message + nextDay + "\n");

        //Assert
        assertTrue(nextScheduleMessage.contains(message + nextDay));
    }

    @Test
    @Category({ChangeRequest.CR_1761.class, ChangeRequest.CR_1792.class})
    public void WhenLoggedInAsNationalSuperAdmin_PublishHistoryTableDisplaysMax20ItemsOnly() throws InterruptedException {

        //Arrange
        //Create 25 manual publish events
        TestUserModel.UserDetails superAdminUser = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(superAdminUser);
        List<String> reasons = new ArrayList<>();

        for(int i = 0; i < 25; i++) {
            reasons.add("Manual publish reason " + (i + 1));
            publishEvent(reasons.get(i));

            /*
             Selenium grid timeout is 30 seconds.
             Publishing can take that long and so session can timeout.
             Therefore, need to user driver to keep session alive.
              */
            driver.getCurrentUrl();
        }

        TestUserModel.UserDetails UserDetails = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        MenuToolBar menuToolBar = new MenuToolBar(driver);
        menuToolBar.publish.click();

        //Act
        Publish_Page publishPage = new Publish_Page(driver);

        List<Publish_Page.ListPublishHistoryTableObject> historyList =  publishPage.getListOfHistoryItems();

        //Assert
        Assertions.assertThat(historyList).hasSize(20);
        Assertions.assertThat(historyList).extracting("reason").doesNotContain("Manual publish reason 1", "Manual publish reason 2", "Manual publish reason 3", "Manual publish reason 4", "Manual publish reason 5");
        Assertions.assertThat(historyList).extracting("reason").contains("Manual publish reason 25");
    }

}