package TestCases.RiskingServiceJava.NarrativeResponse;

import TestCases.RiskingServiceJava.BaseRiskingServiceJava;
import uk.gov.hmrc.risk.test.common.enums.*;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.Condition;

import static uk.gov.hmrc.risk.test.common.enums.Matcher.equalTo;
import static uk.gov.hmrc.risk.test.common.enums.MatcherType.EQUAL;
import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.MatcherClass.CdsRiskMatchers;
import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.MatcherClass.Matchers;
import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.Source.declaration;
import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.Source.goodsItem;


public class BaseNarrativeTest extends BaseRiskingServiceJava {

    protected String expectedReason(Condition condition, String sequenceId, String fieldName, String operator,
                                    String ruleValue, String declarationValue) {
        StringBuilder sb = new StringBuilder();

        switch (condition.source) {
            case declaration:
                sb.append("Declaration field:");
                break;
            case goodsItem:
                sb.append("Goods Item (sequenceId=");
                if (sequenceId.isEmpty()) {
                    sb.append("unknown) field:");
                } else {
                    sb.append(sequenceId+") field:");
                }
                break;
        }
        sb.append(" '"+ fieldName + "' " + operator);
        sb.append(" " +ruleValue + ". The value was: " + declarationValue);
        return sb.toString();
    }

    protected Condition dataTableFreeTextConsignorName() {
        return Condition.builder()
                .attribute(HeaderAttribute.CONSIGNOR_NAME)
                .declarationParam(HeaderDeclarationParam.CONSIGNOR_NAME)
                .matcherClass(CdsRiskMatchers)
                .matcher(Matcher.collectionEqualTo)
                .matcherType(EQUAL)
                .source(declaration)
                .build();
    }

    protected Condition invoicePriceItem() {
        return Condition.builder()
                .attribute(ItemAttribute.INVOICE_PRICE)
                .declarationParam(GoodsItemDeclarationParam.INVOICE_PRICE)
                .declarationValue("9")
                .matcherClass(Matchers)
                .matcher(equalTo)
                .matcherType(EQUAL)
                .value(10)
                .source(goodsItem)
                .build();
    }

    protected Condition consignorNameHeader() {
        return Condition.builder()
                .attribute(HeaderAttribute.CONSIGNOR_NAME)
                .declarationParam(HeaderDeclarationParam.CONSIGNOR_NAME)
                .declarationValue("ConsignorName")
                .matcherClass(Matchers)
                .matcher(equalTo)
                .matcherType(EQUAL)
                .value("ConsignorName")
                .source(declaration)
                .build();
    }

    protected Condition consignorAddressHeader() {
        return Condition.builder()
                .attribute(HeaderAttribute.CONSIGNOR_ADDRESS)
                .declarationParam(HeaderDeclarationParam.CONSIGNOR_ADDRESS_STREET)
                .declarationValue("Consignor address")
                .matcherClass(Matchers)
                .matcher(equalTo)
                .matcherType(EQUAL)
                .value("Consignor address")
                .source(declaration)
                .build();
    }

    protected Condition destinationCountryItem() {
        return Condition.builder()
                .attribute(ItemAttribute.DESTINATION_COUNTRY)
                .declarationParam(GoodsItemDeclarationParam.DESTINATION_COUNTRY)
                .declarationValue("PL")
                .matcherClass(Matchers)
                .matcher(equalTo)
                .matcherType(EQUAL)
                .value("PL")
                .source(goodsItem)
                .build();
    }

    protected Condition packageCountItem() {
        return Condition.builder()
                .attribute(ItemAttribute.PACKAGE_COUNT)
                .declarationParam(ItemCollectionDeclarationParam.PACKAGE_COUNT_ITEM)
                .declarationValue("1")
                .matcherClass(Matchers)
                .matcher(equalTo)
                .matcherType(EQUAL)
                .value(1)
                .source(goodsItem)
                .build();
    }
}
