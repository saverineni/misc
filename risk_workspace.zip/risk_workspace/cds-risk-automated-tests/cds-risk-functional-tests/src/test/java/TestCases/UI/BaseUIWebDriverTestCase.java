package TestCases.UI;


import API.DataForTests.Locations;
import API.DataForTests.RegimeCodes;
import API.DataForTests.Users_API;
import API.EnvDetails.EnvDetails;
import TestCases.BaseSpringBootTestCase;
import UI.Pages.BaseUIPage;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import uk.gov.hmrc.risk.test.common.dao.RuleDao;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import static io.restassured.RestAssured.given;

@Slf4j
public class BaseUIWebDriverTestCase extends BaseSpringBootTestCase {

    @Autowired
    protected RuleDao ruleDao;

    protected static WebDriver driver;

    @Value("${chrome-driver}")
    private String chromeDriver;
    @Value("${use-remote-driver}")
    private Boolean useRemoteDriver;

    @Before
    public void BaseUISetup() throws Throwable {

        log.info("------BaseUIWebDriverTestCase BaseUISetup Start-------------" + "\r\n");

        String className = this.getClass().getSimpleName();
        String methodName = this.testName.getMethodName();
        log.info("#### Start of test: " + className + "." + methodName + "####");
        log.info("\r\n");

        log.info("Use remote chromedriver ".concat(useRemoteDriver.toString()));

        String sBrowser = "chrome";

        String downloadFilepath = "/tmp";
        HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
        chromePrefs.put("profile.default_content_settings.popups", 0);
        chromePrefs.put("download.default_directory", downloadFilepath);
        ChromeOptions options = new ChromeOptions();
        options.setExperimentalOption("prefs", chromePrefs);

        DesiredCapabilities cap = DesiredCapabilities.chrome();
        //cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
        cap.setCapability(ChromeOptions.CAPABILITY, options);


        if (useRemoteDriver)
        {
            options.addArguments("--no-sandbox");
            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setBrowserName(sBrowser);
            capabilities.setCapability(ChromeOptions.CAPABILITY, options);

            log.info(options.toString());
            log.info("RemoteWebDriver url: " + EnvDetails.url_RemoteWebDriver);
            driver = new RemoteWebDriver(new URL(EnvDetails.url_RemoteWebDriver), capabilities);
        }
        else
        {
            URL resource = getClass().getResource("/" + chromeDriver);

            String path = resource.getPath();
            log.info("Chrome Webdriver path: " + path);

            System.setProperty("webdriver.chrome.driver", path);
            driver = new ChromeDriver(cap);
        }

        try {

            Response response = given().when().get(EnvDetails.url_MetaService).then().extract().response();
            if (response.getStatusCode() == 503){

                log.info("UI tests cannot continue as metadata service is unavailable");
                log.info("Request GET: " + EnvDetails.url_MetaService);
                log.info("Response: " + response.getStatusCode());
                System.exit(0);
            }
        }
        catch(Throwable e){
            log.info("fatal error: " + e.getMessage());
            log.info("UI tests cannot continue as metadata service is unavailable");
            log.info("Request GET: " + EnvDetails.url_MetaService);
            System.exit(0);
        }


        mySQL_cds_rules.DeleteUsersFromDB();
        mySQL_cds_rules.DeleteDataTablesFromDB(false);
        ruleDao.deleteAll();
        mySQL_cds_publishing.deletePublishHistoryDataFromDB();

        Locations.SetAllLocationUIDs();
        RegimeCodes.SetAllRegimeCodeUIDs();

        //need to login via api to get token to allow users to be created
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        //need to login via api to get token to allow get security status uids to be retrieved
        API.RulesManagementService.Utils.Users.LoginAsUser(Users_API.NationalRulesManagerDefaultTestAutomationUser().pid,Users_API.SUPER_ADMIN_DEFAULT_PASSWORD);

//        dataTypesUtils.getDefaultDataTypesUUIDSFromMySQLDB();

        driver.manage().timeouts().implicitlyWait(BaseUIPage.DEFAULT_TIMEOUT, TimeUnit.SECONDS);
        driver.get(EnvDetails.url_CDSRisk_HomePage);
        log.info("Navigating to url: " + EnvDetails.url_CDSRisk_HomePage);

        log.info("------BaseUIWebDriverTestCase BaseUISetup End-------------" + "\r\n");
    }

    @After
    public void TearDown() throws IOException {

        String className = this.getClass().getSimpleName();
        String methodName = this.testName.getMethodName();
        log.info("#### Finished test: " + className + "." + methodName + "####");
        log.info("Taking Screenshot");

        log.info("\r\n");

        //TODO screen is taken at end of every test, should take screenshot on failure only. not working.
//        if (testResult.failureCount() > 0){
//            saveScreenshot(methodName);
//        }
        //saveScreenshot(methodName);

        driver.close();
        driver.quit();
    }


    private void saveScreenshot(String testName) throws IOException {

        File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        //FileUtils.copyFile(scrFile, new File("/home/waheed/Screenshots/testScreenShot.png"));

        String currentDir = System.getProperty("user.dir");
        log.info("currentDir:" + currentDir);
        File ScreenshotFolder = new File(currentDir + "/screenshots");
        if (!ScreenshotFolder.exists())
        {
            ScreenshotFolder.mkdirs();
        }

        String timeStamp = new SimpleDateFormat("MMdd_HHmmss").format(Calendar.getInstance().getTime());
        String sScreenshotFileName = ScreenshotFolder + "/" + testName + "_" + timeStamp + ".png";
        log.info("Screenshot: " + sScreenshotFileName);
        FileUtils.copyFile(scrFile, new File(sScreenshotFileName));
    }

}
