package TestCases.RulesManagementService;


import API.DataForTests.DataTables;
import API.DataForTests.TestDataTableModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import API.RulesManagementService.Data.ViewDataTableList.ViewDataTableListResponse;
import API.RulesManagementService.Data.ViewDataTypesList.ViewDataTypesListResponse;
import API.RulesManagementService.Data.ViewTags.ViewTagsResponse;
import Categories_CDSRisk.CDS_RM_DataTable;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import FunctionsLibrary.FileUtilities;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import com.google.common.collect.ImmutableList;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.httpclient.HttpStatus;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@Slf4j
@Category({Rules_Management.class, CDS_RM_DataTable.class})
public class TestCase_DataTable_Create extends WebAPITestCaseWithDatatablesCleanup {

    private String expectedTableUniqueIDPattern;

    @Before
    public void Setup()
    {
        SimpleDateFormat date = new SimpleDateFormat("yy");
        String yy =  date.format(new Date());
        expectedTableUniqueIDPattern = "DT-" + "NAT" + "-\\d\\d\\d\\d-" + yy;
    }

    @Test
    @Category({ChangeRequest.CR_787.class, ChangeRequest.CR_2135.class, ChangeRequest.CR_2236.class})
    public void WhenEmptyOpenDataTableSaved_NewDataTableCreatedSuccessfully()
    {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        //Act
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_CREATED, createDataTableResponse.httpStatusCode);
        assertEquals(tableDetails.tableName, createDataTableResponse.tableName);
        assertEquals(tableDetails.description, createDataTableResponse.description);
        assertEquals(tableDetails.dataType, createDataTableResponse.dataType);

        tableDetails.uniqueId = expectedTableUniqueIDPattern;
        Assertions.assertThat(createDataTableResponse.uniqueId).containsPattern(tableDetails.uniqueId);

        assertEquals(tableDetails.version, createDataTableResponse.version);

        Assertions.assertThat(createDataTableResponse.locations.useTables).extracting("locationName").contains("National Office", "All Locations");
        Assertions.assertThat(createDataTableResponse.locations.manageTables).extracting("locationName").contains("National Office");

        assertEquals("Owner", createDataTableResponse.tableAccessLevel);
    }

    @Test
    @Category({ChangeRequest.CR_787.class, ChangeRequest.CR_822.class, ChangeRequest.CR_2236.class})
    public void WhenListOfDataTablesSelected_ListOfDataTablesReturned()
    {
        //Arrange
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListROStart = API.RulesManagementService.Utils.DataTables.GetListOfDataTables();
        log.debug("Number of data tables at start of test" + viewDataTableListROStart.content.size());

        TestDataTableModel.TableDetails dataTable1 = DataTables.DataTable_NoData();
        TestDataTableModel.TableDetails dataTable2 = DataTables.DataTable_NoData();
        dataTable2.tableName = "ta_DataTable2";

        CreateDataTableResponse.PostResponse createDataTableResponse1 = CreateDataTableAndGetResponseObject(dataTable1);
        dataTable1.uuid = createDataTableResponse1.uuid;

        CreateDataTableResponse.PostResponse createDataTableResponse2 = CreateDataTableAndGetResponseObject(dataTable2);
        dataTable2.uuid = createDataTableResponse2.uuid;


        //Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = API.RulesManagementService.Utils.DataTables.GetListOfDataTables();
        log.debug("Number of data tables at end of test" + viewDataTableListResponseObject.content.size());

        //Assert
        dataTable1.uniqueId = expectedTableUniqueIDPattern;

        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, viewDataTableListResponseObject.httpStatusCode);

        assertEquals(2, viewDataTableListResponseObject.content.size() - viewDataTableListROStart.content.size());   //2 tables in total

        for (int i = 0; i < viewDataTableListResponseObject.content.size(); i++) {

            if (viewDataTableListResponseObject.content.get(i).tableName.equals(dataTable1.tableName)) {

                Assertions.assertThat(viewDataTableListResponseObject.content.get(i).uniqueId).containsPattern(dataTable1.uniqueId);

                assertEquals(dataTable1.tableName, viewDataTableListResponseObject.content.get(i).tableName);
                assertEquals(dataTable1.description, viewDataTableListResponseObject.content.get(i).description);
                assertEquals(dataTable1.dataType, viewDataTableListResponseObject.content.get(i).dataType);

                assertEquals("Owner", viewDataTableListResponseObject.content.get(i).tableAccessLevel);

                assertEquals(dataTable1.version, viewDataTableListResponseObject.content.get(i).version);
                //assertEquals("Exactly 10 numeric characters", viewDataTableListResponseObject.content.get(i).dataTypeValidation);

                Assertions.assertThat(viewDataTableListResponseObject.content.get(i).locations.manageTables).extracting("locationName")
                        .containsOnly("National Office");

                Assertions.assertThat(viewDataTableListResponseObject.content.get(i).locations.useTables).extracting("locationName")
                        .containsOnly("National Office", "All Locations");

                Assertions.assertThat(viewDataTableListResponseObject.content.get(i).rowCount).isEqualTo(0);
            }
        }

    }

    @Test
    @Category({ChangeRequest.CR_823.class, ChangeRequest.CR_2236.class})
    public void WhenDataTableSelectedByUUID_DataTableSummaryReturned()
    {
        //Arrange
        TestDataTableModel.TableDetails dataTable1 = DataTables.DataTable_NoData();
        dataTable1.tableType = "Restricted";

        CreateDataTableResponse.PostResponse createDataTableResponse1 = CreateDataTableAndGetResponseObject(dataTable1);

        TestUserModel.UserDetails udNatRulesManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        //Act
        ViewDataTableResponse.ViewDataTableResponseObject response = API.RulesManagementService.Utils.DataTables.GetDataTableByUID(createDataTableResponse1.uuid);

        //Assert
        dataTable1.uniqueId = expectedTableUniqueIDPattern;
        Assertions.assertThat(response.uniqueId).containsPattern(dataTable1.uniqueId);

        assertEquals(HttpStatus.SC_OK, response.httpStatusCode);
        assertEquals(dataTable1.tableName, response.tableName);
        assertEquals(dataTable1.description, response.description);
        assertEquals(dataTable1.dataType, response.dataType);
        assertEquals(dataTable1.dataType, response.dataType);
        assertEquals(dataTable1.opLockVersion, response.opLockVersion);
        assertEquals(dataTable1.userPid, response.metaData.createdUser.pid);
        assertEquals(dataTable1.version, response.version);

        assertEquals("Owner", response.tableAccessLevel);

        assertEquals(udNatRulesManager.firstname, response.metaData.createdUser.firstName);
        assertEquals(udNatRulesManager.lastname, response.metaData.createdUser.lastName);
        assertTrue(udNatRulesManager.isRiskUser.equals(response.metaData.createdUser.riskUser));
        assertEquals(udNatRulesManager.jobTitle, response.metaData.createdUser.jobTitle);
        assertEquals(udNatRulesManager.status.toLowerCase(), response.metaData.createdUser.status);
        assertEquals(udNatRulesManager.email, response.metaData.createdUser.email);

        Assertions.assertThat(response.locations.manageTables).extracting("locationName")
                .containsOnly("National Office");

        Assertions.assertThat(response.locations.useTables).extracting("locationName")
                .containsOnly("National Office");

        Assertions.assertThat(response.metaData.actions).containsAll(dataTable1.actions);
    }


    @Test
    @Category({ChangeRequest.CR_927.class, ChangeRequest.CR_2236.class})
    public void WhenDataTableSelectedByUUID_DataTableDetailsReturned()
    {
        //Arrange
        TestDataTableModel.TableDetails dataTable1 = DataTables.DataTable_NoData();
        dataTable1.tableType = "Restricted";

        CreateDataTableResponse.PostResponse createDataTableResponse1 = CreateDataTableAndGetResponseObject(dataTable1);

        //Act
        ViewDataTableResponse.ViewDataTableResponseObject response = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(createDataTableResponse1.uuid);

        //Assert
        dataTable1.uniqueId = expectedTableUniqueIDPattern;

        assertEquals(HttpStatus.SC_OK, response.httpStatusCode);
        assertEquals(dataTable1.tableName, response.tableName);
        assertEquals(dataTable1.description, response.description);
        assertEquals(dataTable1.dataType, response.dataType);

        assertEquals(dataTable1.version, response.version);

        assertEquals("Owner", response.tableAccessLevel);

        Assertions.assertThat(response.locations.manageTables).extracting("locationName")
                .containsOnly("National Office");

        Assertions.assertThat(response.locations.useTables).extracting("locationName")
                .containsOnly("National Office");
        Assertions.assertThat(response.metaData.actions).containsAll(dataTable1.actions);
    }

    @Test
    @Category({ChangeRequest.CR_1186.class, ChangeRequest.CR_2236.class})
    public void WhenOpenDataTableViewedByRuleViewer_DataTableActionsCorrect()
    {
        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        TestDataTableModel.TableDetails tableSummary = DataTables.DataTable_CommodityCodes_POO();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableSummary);

        //Act
        TestUserModel.UserDetails udLOCRuleViewerPOO = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleViewerPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleViewerPOO.pid);

        ViewDataTableResponse.ViewDataTableResponseObject response = API.RulesManagementService.Utils.DataTables.GetDataTableByUID(createDataTableResponse.uuid);

        //Assert
        //Actions should not contain "DATA_TABLE_MANAGE_USE", "DATA_TABLE_MANAGE_OWNERS", "DATA_TABLE_EDIT"
        Assertions.assertThat(response.metaData.actions).doesNotContainAnyElementsOf(tableSummary.actions);
        assertEquals("User", response.tableAccessLevel);
    }


    @Test
    @Category(ChangeRequest.CR_787.class)
    public void WhenDataTypesSearched_ListOfDataTypesReturned()
    {
        //Arrange

        //Act
        List<ViewDataTypesListResponse> listOfViewDataTypesResponse = API.RulesManagementService.Utils.DataTypes.GetListOfDataTypes();

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, listOfViewDataTypesResponse.get(0).httpStatusCode);
        assertTrue("Expecting more than one data type to be returned", listOfViewDataTypesResponse.size() >= 1);
    }


    @Test
    @Category(ChangeRequest.CR_947.class)
    public void WhenOpenDataTableSavedByLocalUser_NewDataTableCreatedSuccessfully()
    {
        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        //Act
        TestDataTableModel.TableDetails tableSummary = DataTables.DataTable_CommodityCodes_POO();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableSummary);

        //Assert
        tableSummary.uniqueId = expectedTableUniqueIDPattern.replace("NAT", "POO");
        Assertions.assertThat(createDataTableResponse.uniqueId).containsPattern(tableSummary.uniqueId);

        assertEquals(tableSummary.tableName, createDataTableResponse.tableName);

        Assertions.assertThat(createDataTableResponse.locations.manageTables).extracting("locationName")
                .containsOnly("POO");

        Assertions.assertThat(createDataTableResponse.locations.useTables).extracting("locationName")
                .containsOnly("POO", "All Locations");
    }


    @Test
    @Category(ChangeRequest.CR_947.class)
    public void WhenOpenDataTableSavedByLocalUserWithMultipleLocations_NewDataTableCreatedSuccessfully()
    {

        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        //Act
        TestDataTableModel.TableDetails tableSummary = DataTables.DataTable_CommodityCodes_POOEXT();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableSummary);

        //Assert
        assertEquals(tableSummary.tableName, createDataTableResponse.tableName);

        Assertions.assertThat(createDataTableResponse.locations.manageTables).extracting("locationName")
                .hasSize(2)
                .containsOnly("POO", "EXT");

        Assertions.assertThat(createDataTableResponse.locations.useTables).extracting("locationName")
                .hasSize(3)
                .containsOnly("POO", "EXT", "All Locations");

        tableSummary.uniqueId = expectedTableUniqueIDPattern.replace("NAT", "POO");
        Assertions.assertThat(createDataTableResponse.uniqueId).containsPattern(tableSummary.uniqueId);
    }


    @Test
    @Category(ChangeRequest.CR_1566.class)
    public void WhenDataTableCreatedAndSearchTags_SuggestedTagsDisplayed()
    {
        //Arrange
        TestDataTableModel.TableDetails tableSummary = DataTables.DataTable_ValidTags();
        CreateDataTableAndGetResponseObject(tableSummary);

        //Act
        ViewTagsResponse.ViewTagsResponseObject tagsResponseObject = API.RulesManagementService.Utils.DataTags.getTagsData("tag");


        String firstTag = tagsResponseObject.tags.get(0).tag.tagName;
        String secondTag = tagsResponseObject.tags.get(1).tag.tagName;

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, tagsResponseObject.httpStatusCode);
        assertEquals("First Tag name is incorrect: ", tableSummary.tags.get(0),firstTag);
        assertEquals("Second Tag name is incorrect: ", tableSummary.tags.get(1),secondTag);
    }

    @Test
    @Category(ChangeRequest.CR_1566.class)
    public void WhenAddingTagsToDataTable_AddedTagsNotDisplayedInTheSuggestedList()
    {
        //Arrange
        TestDataTableModel.TableDetails tableSummary = DataTables.DataTable_ValidTags();
        CreateDataTableAndGetResponseObject(tableSummary);

        //Act
        ViewTagsResponse.ViewTagsResponseObject tagsResponseObject = API.RulesManagementService.Utils.DataTags.getTagsData("ag&excludedNames=ta_tag1,ta_tag2");

        List<String> tagName = new ArrayList<>() ;

        for(int i =0; i< tagsResponseObject.tags.size();i++) {
            tagName.add(tagsResponseObject.tags.get(i).tag.tagName);
            log.debug("Name of all the tags "+ tagName);
        }

        assertTrue("", !tagName.contains(tableSummary.tags.get(0)));
        assertTrue("", !tagName.contains(tableSummary.tags.get(1)));
    }

    @Test
    @Category(ChangeRequest.CR_1566.class)
    public void WhenAddingTagsToDataTable_NoMatchingResultsInZeroResults()
    {
        //Arrange
        TestDataTableModel.TableDetails tableSummary = DataTables.DataTable_ValidTags();
        CreateDataTableAndGetResponseObject(tableSummary);

        //Act
        ViewTagsResponse.ViewTagsResponseObject tagsResponseObject = API.RulesManagementService.Utils.DataTags.getTagsData("!vs2&^%&6");

        assertEquals("HTTP Status Code: ", org.apache.http.HttpStatus.SC_OK,tagsResponseObject.httpStatusCode);
        assertTrue("Tags have been returned instead of no tags ", tagsResponseObject.tags.isEmpty());
    }

    @Test
    @Category(ChangeRequest.CR_1566.class)
    @Ignore("Will be fixed as part of CR-3194")
    public void WhenDuplicateTagsAreAdded_OnlyUniqueDataTagsAreAddedAndDuplicatesAreIgnored()
    {
        //Arrange
        TestDataTableModel.TableDetails tableDetails_PartCommodityCodes_National = DataTables.DataTable_PartCommodityCodes();
        tableDetails_PartCommodityCodes_National.tags = ImmutableList.of("Commodity", "Codes", "Part","Commodity","Part");

        //Act
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails_PartCommodityCodes_National);

        //Assert
        assertThat(createDataTableResponse.tags)
                .hasSize(3)
                .extracting("tagName").containsOnly("Commodity", "Codes", "Part");
    }


    @Test
    @Category(ChangeRequest.CR_2213.class)
    public void WhenDataTableSavedWithReasonUpToMaxChars_DataTableSavedSuccessfully()
    {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        //Act
        tableDetails.reason = FileUtilities.GenerateRandomAlphaNumericString(60, true, true);
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_CREATED, createDataTableResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_2213.class)
    public void AttemptToSaveDataTableWithReasonLessThanMinChars_BadRequestReceived()
    {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        //Act
        tableDetails.reason = "Test";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_BAD_REQUEST, createDataTableResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_2213.class)
    public void AttemptToSaveDataTableWithLongReason_BadRequestReceived()
    {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        //Act
        tableDetails.reason = FileUtilities.GenerateRandomAlphaNumericString(61, true, true);
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_BAD_REQUEST, createDataTableResponse.httpStatusCode);
    }


    //----------------------------------------

    //NOTE:
    // 1. OPEN Table can NOT SHARE
    // 2. RESTRICTED and SENSITIVE are the same, just the process to create them is different, sesnsitive requires phone call
    // 3. RESTRICTED and SENSITIVE can be SHARED
    // 4. Table SHARED for USE, Location shared with can view all data, details for table

    @Test
    @Category({ChangeRequest.CR_2135.class})
    public void WhenOpenDataTableSavedByNationalUser_NewDataTableCreatedSuccessfully()
    {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        //Act
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_CREATED, createDataTableResponse.httpStatusCode);

        Assertions.assertThat(createDataTableResponse.locations.manageTables).extracting("locationName")
                .contains("National Office");

        Assertions.assertThat(createDataTableResponse.locations.useTables).extracting("locationName")
                .contains("National Office", "All Locations");
    }


    @Test
    @Category({ChangeRequest.CR_2109.class})
    public void WhenRestrictedDataTableSavedByNationalUser_NewDataTableCreatedSuccessfully()
    {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        //Act
        tableDetails.tableType = "Restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_CREATED, createDataTableResponse.httpStatusCode);

        Assertions.assertThat(createDataTableResponse.locations.manageTables).extracting("locationName")
                .contains("National Office");

        Assertions.assertThat(createDataTableResponse.locations.useTables).extracting("locationName")
                .contains("National Office");
    }


    @Test
    @Category({ChangeRequest.CR_2148.class})
    public void WhenSensitiveDataTableSavedByNationalUser_NewDataTableCreatedSuccessfully()
    {
        //Arrange
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        //Act
        tableDetails.tableType = "Sensitive";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_CREATED, createDataTableResponse.httpStatusCode);

        Assertions.assertThat(createDataTableResponse.locations.useTables).extracting("locationName")
                .contains("National Office");

        Assertions.assertThat(createDataTableResponse.locations.manageTables).extracting("locationName")
                .contains("National Office");
    }


    @Test
    @Category(ChangeRequest.CR_2109.class)
    public void WhenRestrictedDataTableSavedByLocalUser_NewDataTableCreatedSuccessfully()
    {
        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        //Act
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();
        tableDetails.tableType = "Restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        tableDetails.uniqueId = expectedTableUniqueIDPattern.replace("NAT", "POO");
        Assertions.assertThat(createDataTableResponse.uniqueId).containsPattern(tableDetails.uniqueId);

        assertEquals(tableDetails.tableName, createDataTableResponse.tableName);

        Assertions.assertThat(createDataTableResponse.locations.manageTables).extracting("locationName")
                .containsOnly("POO");

        Assertions.assertThat(createDataTableResponse.locations.useTables).extracting("locationName")
                .containsOnly("POO");
    }


    @Test
    @Category(ChangeRequest.CR_2148.class)
    public void WhenSensitiveDataTableSavedByLocalUser_NewDataTableCreatedSuccessfully()
    {
        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        //Act
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();
        tableDetails.tableType = "Sensitive";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        tableDetails.uniqueId = expectedTableUniqueIDPattern.replace("NAT", "POO");
        Assertions.assertThat(createDataTableResponse.uniqueId).containsPattern(tableDetails.uniqueId);

        assertEquals(tableDetails.tableName, createDataTableResponse.tableName);

        Assertions.assertThat(createDataTableResponse.locations.manageTables).extracting("locationName")
                .containsOnly("POO");

        Assertions.assertThat(createDataTableResponse.locations.useTables).extracting("locationName")
                .containsOnly("POO");
    }


    @Test
    @Category(ChangeRequest.CR_2109.class)
    public void WhenRestrictedDataTableSavedByLocalUserWithMultipleLocations_NewDataTableCreatedSuccessfully()
    {

        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        //Act
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POOEXT();
        tableDetails.tableType = "Restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals(tableDetails.tableName, createDataTableResponse.tableName);

        Assertions.assertThat(createDataTableResponse.locations.manageTables).extracting("locationName")
                .hasSize(2)
                .containsOnly("POO", "EXT");

        Assertions.assertThat(createDataTableResponse.locations.useTables).extracting("locationName")
                .hasSize(2)
                .containsOnly("POO", "EXT");
    }


    @Test
    @Category(ChangeRequest.CR_2148.class)
    public void WhenSensitiveDataTableSavedByLocalUserWithMultipleLocations_NewDataTableCreatedSuccessfully()
    {

        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        //Act
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POOEXT();
        tableDetails.tableType = "Sensitive";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Assert
        assertEquals(tableDetails.tableName, createDataTableResponse.tableName);

        Assertions.assertThat(createDataTableResponse.locations.manageTables).extracting("locationName")
                .hasSize(2)
                .containsOnly("POO", "EXT");

        Assertions.assertThat(createDataTableResponse.locations.useTables).extracting("locationName")
                .hasSize(2)
                .containsOnly("POO", "EXT");
    }

    @Test
    @Category(ChangeRequest.CR_1186.class)
    public void WhenRestrictedDataTableViewedByRuleViewer_DataTableActionsCorrect()
    {
        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager.pid);

        TestDataTableModel.TableDetails tableSummary = DataTables.DataTable_CommodityCodes_POO();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableSummary);

        //Act
        TestUserModel.UserDetails udLOCRuleViewerPOO = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleViewerPOO);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleViewerPOO.pid);

        ViewDataTableResponse.ViewDataTableResponseObject response = API.RulesManagementService.Utils.DataTables.GetDataTableByUID(createDataTableResponse.uuid);

        //Assert
        //Actions should not contain "DATA_TABLE_MANAGE_USE", "DATA_TABLE_MANAGE_OWNERS", "DATA_TABLE_EDIT"
        Assertions.assertThat(response.metaData.actions).doesNotContainAnyElementsOf(tableSummary.actions);
    }

}
