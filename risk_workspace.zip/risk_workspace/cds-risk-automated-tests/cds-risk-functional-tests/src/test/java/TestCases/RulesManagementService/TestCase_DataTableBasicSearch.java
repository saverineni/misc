package TestCases.RulesManagementService;


import API.DataForTests.*;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.ViewDataTableList.ViewDataTableListResponse;
import Categories_CDSRisk.CDS_RM_DataTable;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import com.google.common.collect.ImmutableList;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject;
import static API.Utils.LoginAsAPIUserAndCreateDataTableForLocation;
import static org.assertj.core.api.Assertions.assertThat;

@Category({Rules_Management.class, CDS_RM_DataTable.class})
public class TestCase_DataTableBasicSearch extends WebAPITestCaseWithDatatablesCleanup {

    private TestDataTableModel.TableDetails tableDetails_NoData_National;
    private TestDataTableModel.TableDetails tableDetails_CommodityCodes_National;
    private TestDataTableModel.TableDetails tableDetails_CommodityCodes_Poo;
    private TestDataTableModel.TableDetails tableDetails_DefaultCommodityCodes_National;
    private TestDataTableModel.TableDetails tableDetails_PartCommodityCodes_National;
    private TestDataTableModel.TableDetails tableDetails_FreeText_National;
    private TestDataTableModel.TableDetails tableDetails_FreeTextExtra_National;
    private TestDataTableModel.TableDetails tableDetails_Restricted_Poo;
    private TestDataTableModel.TableDetails tableDetails_Sensitive_Poo_Ext;
    private TestDataTableModel.TableDetails tableDetails_Sensitive_Poo;

    private TestDataTableModel.TableDetails tdDefaultTestDataTable;

    @Before
    public void Setup() {

        //Arrange
        tableDetails_NoData_National = DataTables.DataTable_NoData();
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails_NoData_National);
        tableDetails_NoData_National.uniqueId=createDataTableResponse.uniqueId;

        tableDetails_CommodityCodes_National = DataTables.DataTable_CommodityCodes_NAT();
        tableDetails_CommodityCodes_National.tags = ImmutableList.of("Commodity", "Codes");
        createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails_CommodityCodes_National);

        tableDetails_CommodityCodes_Poo = DataTables.DataTable_CommodityCodes_POO();
        createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails_CommodityCodes_Poo);

        tableDetails_DefaultCommodityCodes_National = DataTables.DataTable_DefaultCommodityCodes();

        tableDetails_PartCommodityCodes_National = DataTables.DataTable_PartCommodityCodes();
        tableDetails_PartCommodityCodes_National.tags = ImmutableList.of("Commodity", "Codes", "Part");
        createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails_PartCommodityCodes_National);

         tableDetails_FreeText_National = DataTables.DataTable_FreeText_Valid();
        createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails_FreeText_National);
        tableDetails_FreeText_National.uniqueId=createDataTableResponse.uniqueId;

        tableDetails_FreeTextExtra_National = DataTables.DataTable_FreeText_Extra();
        CreateDataTableAndGetResponseObject(tableDetails_FreeTextExtra_National);

        tdDefaultTestDataTable = DataTables.DataTable_DefaultCommodityCodes();
        CreateDataTableAndGetResponseObject(tdDefaultTestDataTable);

        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        tableDetails_Restricted_Poo = DataTables.DataTable_CommodityCodes_POO();
        tableDetails_Restricted_Poo.tableType = "Restricted";
        LoginAsAPIUserAndCreateDataTableForLocation(UserDetailsPOO, tableDetails_Restricted_Poo);

        tableDetails_Sensitive_Poo_Ext =DataTables.DataTable_CommodityCodes_POOEXT();
        tableDetails_Sensitive_Poo_Ext.tableType = "Sensitive";
        LoginAsAPIUserAndCreateDataTableForLocation(UserDetailsPOO, tableDetails_Sensitive_Poo_Ext);

        tableDetails_Sensitive_Poo =DataTables.DataTable_PartCommodityCodes_POO();
        tableDetails_Sensitive_Poo.tableType = "Sensitive";
        LoginAsAPIUserAndCreateDataTableForLocation(UserDetailsPOO, tableDetails_Sensitive_Poo);

    }


    @Test
    @Category(ChangeRequest.CR_2602.class)
    public void WhenDataTableSearchedByOwnerWithPartialTableName_CorrectResultsAreDisplayed() throws Throwable {

        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_POO());

        //Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables("?shareType=OWNER&dataTableName=PooEXt&size=20&page=0");

        assertThat(viewDataTableList.content)
                .hasSize(1)
                .extracting("tableName").containsOnly(tableDetails_Sensitive_Poo_Ext.tableName);

    }

    @Test
    @Category(ChangeRequest.CR_2602.class)
    public void WhenDataTableSearchedByFullTableName_CorrectResulatsAreDisplayed() throws Throwable {

        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerNational());

        //Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables("?dataTableName="+ tableDetails_FreeTextExtra_National.tableName);


        assertThat(viewDataTableList.content)
                .hasSize(1)
                .extracting("tableName").containsOnly(tableDetails_FreeTextExtra_National.tableName);
    }

    @Test
    @Category(ChangeRequest.CR_2622.class)
    @Ignore("Should have been fixed as part of CR-3194, but still broken")
    public void WhenDataTableSearchedByTableType_CorrectResultsAreDisplayed() throws Throwable {

        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerNational());

        //Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables("?shareType=OWNER&dataTableType=SENSITIVE&size=20&page=0");

        assertThat(viewDataTableList.content)
                .hasSize(2)
                .extracting("tableName").containsOnly(tableDetails_Sensitive_Poo_Ext.tableName, tableDetails_Sensitive_Poo.tableName);

    }


    @Test
    @Category(ChangeRequest.CR_2622.class)
    @Ignore("Should have been fixed as part of CR-3194, but still broken")
    public void WhenDataTableSearchedByDataTypeAndShareType_CorrectResultsAreDisplayed() throws Throwable {

        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerNational());

        //Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables("?shareType=USE,OWNER&dataTypeUuids="+DataTypes.DataType_PartCommodityCode_UID);

        assertThat(viewDataTableList.content)
                .hasSize(2)
                .extracting("tableName").containsOnly(tableDetails_PartCommodityCodes_National.tableName, tableDetails_Sensitive_Poo.tableName);

    }

    @Test
    @Category({ChangeRequest.CR_2601.class,ChangeRequest.CR_2602.class,ChangeRequest.CR_2621.class,ChangeRequest.CR_2622.class})
    public void WhenThereAreNoSearchResults_NoResultsMessageIsDisplayed() throws Throwable {

        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_POO());

        //Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables("?shareType=USE,OWNER&dataTableType=RESTRICTED");
        assertThat(viewDataTableList.content)
                .hasSize(0);
        assertThat(viewDataTableList.totalElements).isEqualTo(0);
        assertThat(viewDataTableList.totalPages).isEqualTo(0);

    }

    @Test
    @Category(ChangeRequest.CR_2601.class)
    public void WhenDataTableSearchedByPartialTableId_CorrectResultsAreDisplayed() throws Throwable {

        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_POO());

         //Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables("?dataTableId="+ tableDetails_FreeText_National.uniqueId.substring(0,11).toUpperCase());

        assertThat(viewDataTableList.content)
                .hasSize(1)
                .extracting("uniqueId").containsOnly(tableDetails_FreeText_National.uniqueId);

        assertThat(viewDataTableList.content)
                .hasSize(1)
                .extracting("tableName").containsOnly(tableDetails_FreeText_National.tableName);

    }

    @Test
    @Category(ChangeRequest.CR_2601.class)
    public void WhenDataTableSearchedByFullTableId_CorrectResultsAreDisplayed() throws Throwable {

        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_POO());

        //Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables("?dataTableId="+ tableDetails_NoData_National.uniqueId.toLowerCase());

        assertThat(viewDataTableList.content)
                .hasSize(1)
                .extracting("uniqueId").containsOnly(tableDetails_NoData_National.uniqueId);

        assertThat(viewDataTableList.content)
                .hasSize(1)
                .extracting("tableName").containsOnly(tableDetails_NoData_National.tableName);

    }

    @Test
    @Category(ChangeRequest.CR_2621.class)
    @Ignore("Should have been fixed as part of CR-3194, but still broken")
    public void WhenDataTableSearchedByNationalLocation_CorrectResultsAreDisplayed() throws Throwable {

        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_POO());

        //Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables("?locationUuids="+Locations.Location_National_UID);


          assertThat(viewDataTableList.content)
                .hasSize(6)
                .extracting("tableName").containsOnly(tableDetails_NoData_National.tableName, tableDetails_CommodityCodes_National.tableName, tableDetails_DefaultCommodityCodes_National.tableName, tableDetails_PartCommodityCodes_National.tableName, tableDetails_FreeText_National.tableName, tableDetails_FreeTextExtra_National.tableName,tdDefaultTestDataTable.tableName);

    }

    @Test
    @Category(ChangeRequest.CR_2621.class)
    public void WhenDataTableSearchedBySpecificLocation_CorrectResultsAreDisplayed() throws Throwable {

        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_POO());

        //Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables("?locationUuids="+Locations.Location_EXT_UID);


       assertThat(viewDataTableList.content)
                .hasSize(1)
                .extracting("tableName").containsOnly(tableDetails_Sensitive_Poo_Ext.tableName);

    }

    @Test
    @Category(ChangeRequest.CR_2627.class)
    @Ignore("Should have been fixed as part of CR-3194, but still broken")
    public void WhenDataTableSearchedByFullTags_CorrectResultsAreDisplayed() throws Exception {
        // Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerNational());

        String tagSearchQuery = "commodity,codes";

        // Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables("?tags=" + tagSearchQuery);

        //Assert
        assertThat(viewDataTableList.content)
                .hasSize(2)
                .extracting("tableName").containsOnly(tableDetails_CommodityCodes_National.tableName, tableDetails_PartCommodityCodes_National.tableName);
    }

    @Test
    @Category(ChangeRequest.CR_2627.class)
    public void WhenDataTableSearchedByNonExistingTags_NoTablesAreReturnedInResponse() {
        // Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerNational());

        String tagSearchQuery = "NonExistingTag";

        // Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables("?tags=" + tagSearchQuery);

        //Assert
        assertThat(viewDataTableList.content).isEmpty();
    }
}
