package TestCases.RiskingServiceJava.HeaderItem;

import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.Risking_JavaService;
import TestCases.RiskingServiceJava.BaseRiskingServiceJava;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.*;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel.Query;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static uk.gov.hmrc.risk.test.common.enums.DeclarationSubType.C;
import static uk.gov.hmrc.risk.test.common.enums.TransportMode.Air;


@Slf4j
@Category({ChangeRequest_RiskingService.CREP_258.class, ChangeRequest_RiskingService.CREP_299.class,
        ChangeRequest_RiskingService.CREP_410.class, Risking_JavaService.class})
public class TestCase_WhichHeaderOrItemCausedRuleFire extends BaseRiskingServiceJava{

    final String ruleConst = "taHeaderItemTestRule";

    @Before
    public void givenRulesContainingHeadersAndItemsConnectedByMetadataTagAreCreated() {

        Query orBAse = Query.builder()
                .operator(Operator.or.toString())
                .query( Arrays.asList(
                        twoHeadersCondition(),
                        oneHeaderCondition(),
                        oneHeaderAndOneItemCondition(),
                        oneGoodsItemCondition(),
                        twoGoodsItemCondition()
                ))
                .build();

        CreateRuleModel createRuleModel = createRuleModel();

        createRuleModel.setQuery( Arrays.asList(orBAse) );
        createRuleModel.getRuleOutputs().setActionType("1");
        createRuleModel.getQueryOptions().setDeclarationType("EX");
        createRuleModel.getQueryOptions().setDeclarationSubTypes(Arrays.asList(C.toString()));

        createRuleModel.getRuleOutputs().setReleaseNarrative(null);

        createAndRefreshRule(createRuleModel);
        publishAndWait(5000);
    }

    private Query twoHeadersCondition() {

        Query consigneeName = Query.builder()
                .attribute(HeaderDeclarationParam.CONSIGNEE_NAME.toString())
                .operator(Operator.eq.toString())
                .value(ruleConst)
                .conditionType(ConditionType.normal.toString())
                .build();

        Query exporterName = Query.builder()
                .attribute(HeaderDeclarationParam.EXPORTER_NAME.toString())
                .operator(Operator.eq.toString())
                .value(ruleConst)
                .conditionType(ConditionType.normal.toString())
                .build();

        return Query.builder()
                .operator(Operator.and.toString())
                .query( Arrays.asList( consigneeName, exporterName))
                .build();
    }

    private Query oneHeaderCondition() {

        return Query.builder()
                .attribute(HeaderDeclarationParam.REP_COUNTRY.toString())
                .operator(Operator.eq.toString())
                .value("FI")
                .conditionType(ConditionType.normal.toString())
                .build();
    }

    private Query oneHeaderAndOneItemCondition() {

        Query consigneeName = Query.builder()
                .attribute(HeaderDeclarationParam.CONSIGNEE_NAME.toString())
                .operator(Operator.eq.toString())
                .value(ruleConst)
                .conditionType(ConditionType.normal.toString())
                .build();

        Query commodityCode = Query.builder()
                .attribute(GoodsItemDeclarationParam.COMMODITY_CODE.toString())
                .operator(Operator.eq.toString())
                .value("0000000001")
                .conditionType(ConditionType.normal.toString())
                .build();

        return Query.builder()
                .operator(Operator.and.toString())
                .query( Arrays.asList( consigneeName, commodityCode))
                .build();
    }

    private Query oneGoodsItemCondition() {
        return Query.builder()
                .attribute(GoodsItemDeclarationParam.DESTINATION_COUNTRY.toString())
                .operator(Operator.eq.toString())
                .value("PL")
                .conditionType(ConditionType.normal.toString())
                .build();
    }

    private Query twoGoodsItemCondition() {
        Query commodityCode = Query.builder()
                .attribute(GoodsItemDeclarationParam.COMMODITY_CODE.toString())
                .operator(Operator.eq.toString())
                .value("0000000001")
                .conditionType(ConditionType.normal.toString())
                .build();

        Query originCountry = Query.builder()
                .attribute(GoodsItemDeclarationParam.ORIGIN_COUNTRY.toString())
                .operator(Operator.eq.toString())
                .value("GR")
                .conditionType(ConditionType.normal.toString())
                .build();

        return Query.builder()
                .operator(Operator.and.toString())
                .query( Arrays.asList( commodityCode, originCountry))
                .build();
    }

    private Map<DeclarationParam, String> queryOptionsDeclarationFields() {

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();

        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_TYPE, "EX");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "C");
        declarationFieldValues.put(HeaderDeclarationParam.MODE_OF_TRANSPORT, Air.toString());

        return declarationFieldValues;
    }

    //Covers AC's 1,7 & 11 from CREP-299
    @Test
   // @Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenHeadersConditionFromOneRuleAreMet_OneHeaderHitAndOneControlTaskAreReported() {

        Map<DeclarationParam, String> declarationFieldValues = queryOptionsDeclarationFields();

        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNEE_NAME, ruleConst);
        declarationFieldValues.put(HeaderDeclarationParam.EXPORTER_NAME, ruleConst);


        DeclarationResponse declarationResponse = getAndAssertDeclarationResponse(declarationFieldValues);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration").hasSize(1);

        List<List<String>> matchReasons = declarationResponse.getMatchReasons();
        Assertions.assertThat(matchReasons).hasSize(1);
        Assertions.assertThat(matchReasons.get(0))
                .contains("Declaration field: 'Consignee Name' was equal to taHeaderItemTestRule. The value was: 'taHeaderItemTestRule'")
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .contains("Declaration field: 'Exporter Name' was equal to taHeaderItemTestRule. The value was: 'taHeaderItemTestRule'")
                .hasSize(4);
    }

    //Covers AC's 2 from CREP-299
    @Test
   // @Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenHeaderConditionsFromTwoRulesAreMet_TwoHeaderHitsGeneratedAndOneControlTask() {
        Map<DeclarationParam, String> declarationFieldValues = queryOptionsDeclarationFields();

        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNEE_NAME, ruleConst);
        declarationFieldValues.put(HeaderDeclarationParam.EXPORTER_NAME, ruleConst);

        declarationFieldValues.put(HeaderDeclarationParam.REP_COUNTRY, "FI");
        declarationFieldValues.put(HeaderDeclarationParam.REP_FUNCTION, "2");

        DeclarationResponse declarationResponse = getAndAssertDeclarationResponse(declarationFieldValues);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration").hasSize(1);

        List<List<String>> matchReasons = declarationResponse.getMatchReasons();
        Assertions.assertThat(matchReasons).hasSize(1);
        Assertions.assertThat(matchReasons.get(0))
                .contains("Declaration field: 'Representative Country' was equal to FI. The value was: 'FI'")
                .contains("Declaration field: 'Exporter Name' was equal to taHeaderItemTestRule. The value was: 'taHeaderItemTestRule'")
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .contains("Declaration field: 'Consignee Name' was equal to taHeaderItemTestRule. The value was: 'taHeaderItemTestRule'")
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .hasSize(5);
    }

    //Covers AC's 3 & 12 from CREP-299
    @Test
    public void WhenItemConditionFromOneRuleIsMet_OneItemHitAndOneControlTask() {
        Map<DeclarationParam, String> declarationFieldValues = queryOptionsDeclarationFields();
        declarationFieldValues.put(GoodsItemDeclarationParam.DESTINATION_COUNTRY, "PL");

        declarationFieldValues.put(HeaderDeclarationParam.REP_COUNTRY, "DE");

        DeclarationResponse declarationResponse = getAndAssertDeclarationResponse(declarationFieldValues);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements)
                .contains(generateReportBackElementString("2001"))
                .hasSize(1);

        List<List<String>> matchReasons = declarationResponse.getMatchReasons();
        Assertions.assertThat(matchReasons).hasSize(1);
        Assertions.assertThat(matchReasons.get(0))
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .contains("Goods Item (sequenceId=2001) field: 'Destination Country' was equal to PL. The value was: 'PL'")
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .hasSize(3);
    }

    //Covers AC's 4 & 13 from CREP-299
    @Test
    public void WhenMultipleItemsHitOneRuleCondition_OneItemHitAndOneControTaskPerItemThatHitIsGenerated() {

        Map<DeclarationParam, String> declarationFieldValues = queryOptionsDeclarationFields();
        //item1
        declarationFieldValues.put(GoodsItemDeclarationParam.COMMODITY_CODE, "0000000001");
        declarationFieldValues.put(GoodsItemDeclarationParam.ORIGIN_COUNTRY, "GR");
        //item2
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.COMMODITY_CODE, "0000000001");
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.ORIGIN_COUNTRY, "GR");
        //item3
        declarationFieldValues.put(GoodsItemDeclarationParam.Third.COMMODITY_CODE, "0000000123");
        declarationFieldValues.put(GoodsItemDeclarationParam.Third.ORIGIN_COUNTRY, "GR");
        //item4
        declarationFieldValues.put(GoodsItemDeclarationParam.Fourth.COMMODITY_CODE, "0000000001");
        declarationFieldValues.put(GoodsItemDeclarationParam.Fourth.ORIGIN_COUNTRY, "DE");

        DeclarationResponse declarationResponse = getAndAssertDeclarationResponse(declarationFieldValues);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements)
                .contains(
                generateReportBackElementString("2002"))
                .contains(
                generateReportBackElementString("2001"))
                .doesNotContain(
                generateReportBackElementString("2003"))
                .doesNotContain(
                generateReportBackElementString("2004"))
                .hasSize(2);

        List<List<String>> matchReasons = declarationResponse.getMatchReasons();
        Assertions.assertThat(matchReasons).hasSize(2);
        Assertions.assertThat(matchReasons.get(0))
                .contains("Goods Item (sequenceId=2001) field: 'Commodity Code (TSP & TRC)' was equal to 0000000001. The value was: '0000000001'")
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .contains("Goods Item (sequenceId=2001) field: 'Origin Country' was equal to GR. The value was: 'GR'")
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .hasSize(4);

        Assertions.assertThat(matchReasons.get(1))
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .contains("Goods Item (sequenceId=2002) field: 'Origin Country' was equal to GR. The value was: 'GR'")
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .contains("Goods Item (sequenceId=2002) field: 'Commodity Code (TSP & TRC)' was equal to 0000000001. The value was: '0000000001'")
                .hasSize(4);
    }

    //Covers AC's 5 & 8 from CREP-299
    @Test
    public void WhenOneItemHitTwoRulesConditions_OneItemHitAndOneControlTaskIsGeneratedTwoHitsAreLogged() {
        Map<DeclarationParam, String> declarationFieldValues = queryOptionsDeclarationFields();

        declarationFieldValues.put(GoodsItemDeclarationParam.DESTINATION_COUNTRY, "PL");
        declarationFieldValues.put(GoodsItemDeclarationParam.COMMODITY_CODE, "0000000001");
        declarationFieldValues.put(GoodsItemDeclarationParam.ORIGIN_COUNTRY, "GR");

        DeclarationResponse declarationResponse = getAndAssertDeclarationResponse(declarationFieldValues);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements)
                .contains(generateReportBackElementString("2001"))
                .hasSize(1);

        List<List<String>> matchReasons = declarationResponse.getMatchReasons();
        Assertions.assertThat(matchReasons).hasSize(1);
        Assertions.assertThat(matchReasons.get(0))
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .contains("Goods Item (sequenceId=2001) field: 'Origin Country' was equal to GR. The value was: 'GR'")
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .contains("Goods Item (sequenceId=2001) field: 'Destination Country' was equal to PL. The value was: 'PL'")
                .contains("Goods Item (sequenceId=2001) field: 'Commodity Code (TSP & TRC)' was equal to 0000000001. The value was: '0000000001'")
                .hasSize(5);
    }

    //Covers AC's 6 from CREP-299
    @Test
    public void WhenMultipleItemsHitTwoRulesConditions_MultipleItemHitsAndMultipleControlTasksAreGeneratedTwoHitsAreLogged() {
        Map<DeclarationParam, String> declarationFieldValues = queryOptionsDeclarationFields();

        //Item 1
        declarationFieldValues.put(GoodsItemDeclarationParam.DESTINATION_COUNTRY, "PL");
        declarationFieldValues.put(GoodsItemDeclarationParam.COMMODITY_CODE, "0000000001");
        declarationFieldValues.put(GoodsItemDeclarationParam.ORIGIN_COUNTRY, "GR");
        //Item 2
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.DESTINATION_COUNTRY, "PL");
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.COMMODITY_CODE, "0000000001");
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.ORIGIN_COUNTRY, "GR");
        //Item 3
        declarationFieldValues.put(GoodsItemDeclarationParam.Third.DESTINATION_COUNTRY, "FI");
        declarationFieldValues.put(GoodsItemDeclarationParam.Third.COMMODITY_CODE, "0000000123");
        declarationFieldValues.put(GoodsItemDeclarationParam.Third.ORIGIN_COUNTRY, "GR");

        DeclarationResponse declarationResponse = getAndAssertDeclarationResponse(declarationFieldValues);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements)
                .contains( generateReportBackElementString("2001"))
                .contains( generateReportBackElementString("2002"))
                .hasSize(2);

        List<List<String>> matchReasons = declarationResponse.getMatchReasons();
        Assertions.assertThat(matchReasons).hasSize(2);
        Assertions.assertThat(matchReasons.get(0))
                .contains("Goods Item (sequenceId=2001) field: 'Origin Country' was equal to GR. The value was: 'GR'")
                .contains("Goods Item (sequenceId=2001) field: 'Commodity Code (TSP & TRC)' was equal to 0000000001. The value was: '0000000001'")
                .contains("Goods Item (sequenceId=2001) field: 'Destination Country' was equal to PL. The value was: 'PL'")
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .hasSize(5);

        Assertions.assertThat(matchReasons.get(1))
                .contains("Goods Item (sequenceId=2002) field: 'Destination Country' was equal to PL. The value was: 'PL'")
                .contains("Goods Item (sequenceId=2002) field: 'Commodity Code (TSP & TRC)' was equal to 0000000001. The value was: '0000000001'")
                .contains("Goods Item (sequenceId=2002) field: 'Origin Country' was equal to GR. The value was: 'GR'")
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .hasSize(5);
    }

    //Covers AC's 9 from CREP-299
    @Test
    public void WhenHeadersAndItemConditionIsMet_OneDeclarationAndOneGoodsItemHitGenerated() {

        Map<DeclarationParam, String> declarationFieldValues = queryOptionsDeclarationFields();

        declarationFieldValues.put(HeaderDeclarationParam.REP_COUNTRY, "FI");
        declarationFieldValues.put(HeaderDeclarationParam.REP_FUNCTION, "2");

        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNEE_NAME, ruleConst);
        declarationFieldValues.put(GoodsItemDeclarationParam.COMMODITY_CODE, "0000000001");

        DeclarationResponse declarationResponse = getAndAssertDeclarationResponse(declarationFieldValues);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements)
                .contains("/declaration")
                .contains(generateReportBackElementString("2001"))
                .hasSize(2);

        List<List<String>> matchReasons = declarationResponse.getMatchReasons();
        Assertions.assertThat(matchReasons).hasSize(2);
        Assertions.assertThat(matchReasons.get(0))
                .contains("Declaration field: 'Consignee Name' was equal to taHeaderItemTestRule. The value was: 'taHeaderItemTestRule'")
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .contains("Goods Item (sequenceId=2001) field: 'Commodity Code (TSP & TRC)' was equal to 0000000001. The value was: '0000000001'")
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .hasSize(4);

        Assertions.assertThat(matchReasons.get(1))
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .contains("Declaration field: 'Representative Country' was equal to FI. The value was: 'FI'")
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .hasSize(3);
    }

    //Covers AC's 10 from CREP-299
    @Test
    public void WhenMultipleItemsHitHeaderAndItemCondition_OneDeclarationAndMutlipleItemHitsAreGenerated() {
        Map<DeclarationParam, String> declarationFieldValues = queryOptionsDeclarationFields();

        declarationFieldValues.put(HeaderDeclarationParam.REP_COUNTRY, "FI");
        declarationFieldValues.put(HeaderDeclarationParam.REP_FUNCTION, "3");

        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNEE_NAME, ruleConst);
        //Item 1
        declarationFieldValues.put(GoodsItemDeclarationParam.COMMODITY_CODE, "0000000001");
        //Item 2
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.COMMODITY_CODE, "0000000001");

        DeclarationResponse declarationResponse = getAndAssertDeclarationResponse(declarationFieldValues);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements)
                .contains("/declaration")
                .contains(generateReportBackElementString("2001"))
                .contains(generateReportBackElementString("2002"))
                .hasSize(3);

        List<List<String>> matchReasons = declarationResponse.getMatchReasons();
        Assertions.assertThat(matchReasons).hasSize(3);
        Assertions.assertThat(matchReasons.get(0))
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .contains("Goods Item (sequenceId=2001) field: 'Commodity Code (TSP & TRC)' was equal to 0000000001. The value was: '0000000001'")
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .contains("Declaration field: 'Consignee Name' was equal to taHeaderItemTestRule. The value was: 'taHeaderItemTestRule'")
                .hasSize(4);

        Assertions.assertThat(matchReasons.get(1))
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .contains("Declaration field: 'Consignee Name' was equal to taHeaderItemTestRule. The value was: 'taHeaderItemTestRule'")
                .contains("Goods Item (sequenceId=2002) field: 'Commodity Code (TSP & TRC)' was equal to 0000000001. The value was: '0000000001'")
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .hasSize(4);

        Assertions.assertThat(matchReasons.get(2))
                .contains("Declaration field: 'Representative Country' was equal to FI. The value was: 'FI'")
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .hasSize(3);
    }

    //Covers AC's 14 from CREP-299
    @Test
    public void WhenDeclarationHitOnHeaderAndTwoItemConditions_OneDeclarationMultipleItemsHitAreGenerated() {
        Map<DeclarationParam, String> declarationFieldValues = queryOptionsDeclarationFields();

        declarationFieldValues.put(HeaderDeclarationParam.REP_COUNTRY, "FI");
        declarationFieldValues.put(HeaderDeclarationParam.REP_FUNCTION, "2");
        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNEE_NAME, ruleConst);

        //Item 1
        declarationFieldValues.put(GoodsItemDeclarationParam.DESTINATION_COUNTRY, "PL");
        declarationFieldValues.put(GoodsItemDeclarationParam.COMMODITY_CODE, "0000000001");
        //Item 2
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.DESTINATION_COUNTRY, "PL");
        //Item 3
        declarationFieldValues.put(GoodsItemDeclarationParam.Third.COMMODITY_CODE, "0000000001");
        //Item 4
        declarationFieldValues.put(GoodsItemDeclarationParam.Fourth.DESTINATION_COUNTRY, "NO");
        declarationFieldValues.put(GoodsItemDeclarationParam.Fourth.COMMODITY_CODE, "0000000123");

        DeclarationResponse declarationResponse = getAndAssertDeclarationResponse(declarationFieldValues);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements)
                .contains("/declaration")
                .contains(generateReportBackElementString("2001"))
                .contains(generateReportBackElementString("2002"))
                .contains(generateReportBackElementString("2003"))
                .hasSize(4);

        List<List<String>> matchReasons = declarationResponse.getMatchReasons();
        Assertions.assertThat(matchReasons).hasSize(4);
        Assertions.assertThat(matchReasons.get(0))
                .contains("Goods Item (sequenceId=2001) field: 'Commodity Code (TSP & TRC)' was equal to 0000000001. The value was: '0000000001'")
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .contains("Declaration field: 'Consignee Name' was equal to taHeaderItemTestRule. The value was: 'taHeaderItemTestRule'")
                .contains("Goods Item (sequenceId=2001) field: 'Destination Country' was equal to PL. The value was: 'PL'")
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .hasSize(5);

        Assertions.assertThat(matchReasons.get(1))
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .contains("Goods Item (sequenceId=2002) field: 'Destination Country' was equal to PL. The value was: 'PL'")
                .hasSize(3);

        Assertions.assertThat(matchReasons.get(2))
                .contains("Goods Item (sequenceId=2003) field: 'Commodity Code (TSP & TRC)' was equal to 0000000001. The value was: '0000000001'")
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .contains("Declaration field: 'Consignee Name' was equal to taHeaderItemTestRule. The value was: 'taHeaderItemTestRule'")
                .hasSize(4);

        Assertions.assertThat(matchReasons.get(3))
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .contains("Declaration field: 'Representative Country' was equal to FI. The value was: 'FI'")
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .hasSize(3);
    }

    @Test
    public void WhenDeclarationHitOnMultipleHeaderAndItemRules_OneDeclarationAndMultipleItemHitsReturned() {
        Map<DeclarationParam, String> declarationFieldValues = queryOptionsDeclarationFields();

        declarationFieldValues.put(HeaderDeclarationParam.REP_COUNTRY, "FI");
        declarationFieldValues.put(HeaderDeclarationParam.REP_FUNCTION, "2");
        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNEE_NAME, ruleConst);
        declarationFieldValues.put(HeaderDeclarationParam.EXPORTER_NAME, ruleConst);

        //Item 1
        declarationFieldValues.put(GoodsItemDeclarationParam.DESTINATION_COUNTRY, "PL");
        //Item 2
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.ORIGIN_COUNTRY, "GR");
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.COMMODITY_CODE, "0000000001");

        DeclarationResponse declarationResponse = getAndAssertDeclarationResponse(declarationFieldValues);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements)
                .contains("/declaration")
                .contains(generateReportBackElementString("2001"))
                .contains(generateReportBackElementString("2002"))
                .hasSize(3);

        List<List<String>> matchReasons = declarationResponse.getMatchReasons();
        Assertions.assertThat(matchReasons).hasSize(3);
        Assertions.assertThat(matchReasons.get(0))
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .contains("Goods Item (sequenceId=2001) field: 'Destination Country' was equal to PL. The value was: 'PL'")
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .hasSize(3);

        Assertions.assertThat(matchReasons.get(1))
                .contains("Goods Item (sequenceId=2002) field: 'Origin Country' was equal to GR. The value was: 'GR'")
                .contains("Goods Item (sequenceId=2002) field: 'Commodity Code (TSP & TRC)' was equal to 0000000001. The value was: '0000000001'")
                .contains("Declaration field: 'Consignee Name' was equal to taHeaderItemTestRule. The value was: 'taHeaderItemTestRule'")
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .hasSize(5)
                .doesNotContain("Declaration field: 'Consignor Name' was equal to ta_HeaderItemTestRule. The value was: 'ta_HeaderItemTestRule'")
                .doesNotContain("Goods Item (sequenceId=2001) field: 'Destination Country' was equal to PL. The value was: 'PL'");

        Assertions.assertThat(matchReasons.get(2))
                .contains("Declaration field: 'Declaration Sub-type' was equal to C. The value was: 'C'")
                .contains("Declaration field: 'Consignee Name' was equal to taHeaderItemTestRule. The value was: 'taHeaderItemTestRule'")
                .contains("Declaration field: 'Representative Country' was equal to FI. The value was: 'FI'")
                .contains("Declaration field: 'Exporter Name' was equal to taHeaderItemTestRule. The value was: 'taHeaderItemTestRule'")
                .contains("Declaration field: 'Declaration Type' was equal to EX. The value was: 'EX'")
                .hasSize(5);
    }

    private DeclarationResponse getAndAssertDeclarationResponse(Map<DeclarationParam, String> declarationFieldValues) {

        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNEE_TYPE, "CN");

        declarationFieldValues.put(GoodsItemDeclarationParam.SEQUENCE_NUMBER, "2001");
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.SEQUENCE_NUMBER, "2002");
        declarationFieldValues.put(GoodsItemDeclarationParam.Third.SEQUENCE_NUMBER, "2003");
        declarationFieldValues.put(GoodsItemDeclarationParam.Fourth.SEQUENCE_NUMBER, "2004");

        DeclarationResponse declarationResponse = createAndSendDeclaration(declarationFieldValues, false);

        Assertions.assertThat(declarationResponse.getNarrativeText()).isEqualTo(HOLD_NARRATIVE);
        return declarationResponse;
    }
}
