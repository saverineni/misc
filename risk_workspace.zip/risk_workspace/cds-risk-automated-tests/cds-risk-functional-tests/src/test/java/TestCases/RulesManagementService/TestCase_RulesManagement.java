package TestCases.RulesManagementService;

import API.DataForTests.TestRuleModel;
import API.EnvDetails.EnvDetails;
import API.RulesManagementService.CreateRule.CreateRuleRequestFromFile;
import Categories_CDSRisk.CDS_RM_RulesGeneral;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import io.restassured.response.Response;
import junitparams.JUnitParamsRunner;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;

import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

@Slf4j
@Category({Rules_Management.class, CDS_RM_RulesGeneral.class})
@RunWith(JUnitParamsRunner.class)
public class TestCase_RulesManagement extends BaseWebAPITestCase {

    @Test
    @Category(ChangeRequest.CR_107.class)
    public void WhenCORSOptionsRequestSent_ResponseContainsHostUIURL() throws Throwable
    {
        //Arrange
        String url = EnvDetails.url_RuleCreate;
        String sHost = url.split("/")[2];

        log.info("\r\n POST Request: " + url);

        //http://rules-manager.fastp-dev.net/rule/create


        //Act
        Response response = given().headers(
                "Accept", "*/*",
                "Access-Control-Request-Headers", "content-type",
                "Access-Control-Request-Method", "POST",
                "Authorization", "Bearer " + EnvDetails.sCurrentLoggedInUserToken,
                "Host", sHost,
                "Origin", EnvDetails.url_CDSRisk_HomePage,
                "referer", EnvDetails.url_CDSRisk_HomePage
                ).log().all()
                .when().options(url).then().log().all().extract().response();

        //Assert
        assertEquals(HttpStatus.SC_OK, response.statusCode());
        String actHeader = response.header("Access-Control-Allow-Origin");
        assertEquals("Access-Control-Allow-Origin: ", EnvDetails.url_CDSRisk_HomePage, actHeader);
    }


    @Test
    @Category(ChangeRequest.CR_107.class)
    public void WhenCORSPostRequestSent_ResponseContainsHostUIURL() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        String ruleRequestJsonBody = CreateRuleRequestFromFile.CreateRuleRequestBodyForSingleQueryCondition(ruleDetails);

        String url = EnvDetails.url_RuleCreate;
        String sHost = url.split("/")[2];

        log.info("\r\n POST Request: " + url);

        String sContentType = "application/json";

        //Act
        Response response = given().headers(
                "Accept", "*/*",
                "Content-type", sContentType,
                "Authorization", "Bearer " + EnvDetails.sCurrentLoggedInUserToken,
                "Host", sHost,
                "Origin", EnvDetails.url_CDSRisk_HomePage,
                "referer", EnvDetails.url_CDSRisk_HomePage
            )
                .body(ruleRequestJsonBody)
                .log().all()
                .when().post(url).then().log().all().extract().response();

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.statusCode());
        String actHeader = response.header("Access-Control-Allow-Origin");
        assertEquals("Access-Control-Allow-Origin: ", EnvDetails.url_CDSRisk_HomePage, actHeader);
    }


    @Test
    @Category(ChangeRequest.CR_28.class)
    public void WhenInvalidRequestSubmitted_UnsupportedMediaTypeResponseReceived() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        String ruleRequestJsonBody = CreateRuleRequestFromFile.CreateRuleRequestBodyForSingleQueryCondition(ruleDetails);

        String url = EnvDetails.url_RuleCreate;
        String sHost = url.split("/")[2];

        log.info("\r\n POST Request: " + url);

        String sContentType = "text/plain";

        //Act
        Response response = given().headers(
                "Accept", "*/*",
                "Content-type", sContentType,
                "Authorization", "Bearer " + EnvDetails.sCurrentLoggedInUserToken,
                "Host", sHost,
                "Origin", EnvDetails.url_CDSRisk_HomePage,
                "referer", EnvDetails.url_CDSRisk_HomePage
        )
                .body(ruleRequestJsonBody)
                .log().all()
                .when().post(url).then().log().all().extract().response();

        //Assert
        assertEquals(HttpStatus.SC_UNSUPPORTED_MEDIA_TYPE, response.statusCode());
    }


    @Test
    @Category(ChangeRequest.CR_28.class)
    public void WhenInValidRuleURLSubmitted_NotFoundResponseReceived() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        String ruleRequestJsonBody = CreateRuleRequestFromFile.CreateRuleRequestBodyForSingleQueryCondition(ruleDetails);

        String url = EnvDetails.url_RuleCreate + "-foo";
        log.info("\r\n POST Request: " + url);

        String sContentType = "application/json";

        //Act
        Response response = given().headers(
                "Content-type", sContentType,
                "Authorization", "Bearer " + EnvDetails.sCurrentLoggedInUserToken
        )
                .body(ruleRequestJsonBody)
                .log().body()
                .when().post(url).then().log().all().extract().response();

        //Assert
        assertEquals(HttpStatus.SC_NOT_FOUND, response.statusCode());
    }


}
