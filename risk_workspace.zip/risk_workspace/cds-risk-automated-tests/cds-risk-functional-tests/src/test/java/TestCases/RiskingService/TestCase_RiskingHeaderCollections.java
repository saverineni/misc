package TestCases.RiskingService;


import API.DataForTests.Conditions;
import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestRuleModel;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service;
import TestCases.BaseWebAPITestCase;
import junitparams.JUnitParamsRunner;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeoutException;

import static API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody;
import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
@Category(Risking_Service.class)
@RunWith(JUnitParamsRunner.class)
public class TestCase_RiskingHeaderCollections extends BaseWebAPITestCase {

    private static TestRuleModel.RuleDetails ruleDetails;
    private static DeclarationResponse declarationResponse;

    @Before
    public void setup() throws IOException, TimeoutException {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
    }


    private TestRuleModel.RuleDetails CreateCommittedRuleWithConditionAndPublish(TestRuleModel.RuleDetails.Condition condition) {
        ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).operator = "and";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);
        ruleDetails.ruleOutputs.actionType = "1";
        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(6000);
        return ruleDetails;
    }

    private DeclarationResponse CreateDeclarationXMLSubmitAndGetResponse(TestDeclarationModel.Declaration declaration) {
        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());
        queue.send(declarationRequest);
        declarationResponse = new DeclarationResponse(queue.receive());
        log.info(declarationResponse.toString());
        return declarationResponse;
    }

    private DeclarationResponse CreateDeclarationXMLSubmit(TestDeclarationModel.Declaration declaration) {
        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultNewDeclarationTemplate());
        queue.send(declarationRequest);
        declarationResponse = new DeclarationResponse(queue.receive());
        log.info(declarationResponse.toString());
        return declarationResponse;
    }

    private DeclarationResponse CreateDeclarationXMLSubmitAndGetResponse(TestDeclarationModel.Declaration declaration, String template) {
        String declarationRequest = createDeclarationXMLBody(declaration, template);
        queue.send(declarationRequest);
        declarationResponse = new DeclarationResponse(queue.receive());
        log.info(declarationResponse.toString());
        return declarationResponse;
    }


    private void AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(TestDeclarationModel.Declaration declaration, int size) {

        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).hasSize(size)
                .contains(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(size)
                .contains("/declaration");
    }



    @Test
    @Category({ChangeRequest.CR_2782.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithAdditionalInfoCodeHeaderCollection_RouteReturned() throws Throwable {

        //Arrange
        API.DataForTests.TestRuleModel.RuleDetails.Condition condition = Conditions.additionalInfoCode_HeaderCollections();
        condition.operator = "st";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        //Rule is fired as the declaration starts with 100456
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalInformation_CodeHeader = "100456789";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration, 1);
    }

    @Test
    @Category({ChangeRequest.CR_2782.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithAdditionalInfoTextHeaderCollection_RouteReturned() throws Throwable {

        //Arrange
        API.DataForTests.TestRuleModel.RuleDetails.Condition condition = Conditions.additionalInfoText_HeaderCollections("G? BOXES");
        condition.operator = "matchesPattern";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        //Rule is fired as the declaration matches pattern G? BOXES
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalInformation_TextHeader = "GE BOXES";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration, 1);
    }


    @Test
    @Category({ChangeRequest.CR_2769.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDocumentTypeHeaderCollection_RouteReturned() throws Throwable {

        //Arrange
        API.DataForTests.TestRuleModel.RuleDetails.Condition condition = Conditions.additionalDocumentsType_HeaderCollections();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalDocuments_TypeHeader = "doctyp";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration, 1);
    }

    @Test
    @Category({ChangeRequest.CR_3331.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDocumentIdHeaderCollection_RouteReturned() throws Throwable {

        //Arrange
        API.DataForTests.TestRuleModel.RuleDetails.Condition condition = Conditions.additionalDocumentsId_HeaderCollections();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalDocuments_IdHeader = "77777777";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration, 1);
    }

    @Test
    @Category({ChangeRequest.CR_2950.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithContainerCodeHeaderCollection_RouteReturned() throws Throwable {

        //Arrange
        API.DataForTests.TestRuleModel.RuleDetails.Condition condition = Conditions.containersCode_HeaderCollections();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.containerCode_Header();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration, 1);
    }

    @Test
    @Category({ChangeRequest.CR_2950.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithSealIdHeaderCollection_RouteReturned() throws Throwable {

        //Arrange
        API.DataForTests.TestRuleModel.RuleDetails.Condition condition = Conditions.sealId_HeaderCollections();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.sealId_Header();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration, 1);
    }


    @Test
    @Category({ChangeRequest.CR_2950.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithCountryHeaderCollection_RouteReturned() throws Throwable {

        //Arrange
        API.DataForTests.TestRuleModel.RuleDetails.Condition condition = Conditions.countryRoute_HeaderCollections();
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = TestDeclarationModel.countryRoute_Header();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration, 1);
    }

    @Test
    @Category({ChangeRequest.CR_3212.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithSpecificCircumstanceHeader_RouteReturned() throws Throwable {

        //Arrange
        API.DataForTests.TestRuleModel.RuleDetails.Condition condition = Conditions.specificCircumstanceHeader("ABC");
        condition.operator = "eq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.specificCircumstance = "ABC";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration, 1);
    }

    @Test
    @Category({ChangeRequest.CR_3212.class})
    public void WhenDeclarationSubmittedForNotMatchingRuleWithSpecificCircumstanceHeader_NoRouteReturned() throws Throwable {

        //Arrange
        API.DataForTests.TestRuleModel.RuleDetails.Condition condition = Conditions.specificCircumstanceHeader("EDf");
        condition.operator = "neq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.specificCircumstance = "EDf";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).isEmpty();
    }


    @Test
    @Category({ChangeRequest.CR_2782.class})
    public void WhenDeclarationSubmittedDoesNotMatchWithAdditionalInfoHeaderCollectionInRule_RouteNotReturned() throws Throwable {

        //Arrange
        API.DataForTests.TestRuleModel.RuleDetails.Condition condition = Conditions.additionalInfoText_HeaderCollections("G? BOXES");
        condition.operator = "matchesPattern";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        //Rule is not fired as the declaration oes not match pattern G? BOXES
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalInformation_TextHeader = "MR BOXES";

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).isEmpty();
    }


    @Test
    @Category({ChangeRequest.CR_2782.class})
    public void WhenDeclarationSubmittedMatchesOnlyInformationCodeAndNotTextInRule_RouteNotReturned() throws Throwable {

        //Arrange

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionHeaderCollectionCode = Conditions.additionalInfoCode_HeaderCollections();
        conditionHeaderCollectionCode.operator = "con";
        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionHeaderCollectionText = Conditions.additionalInfoText_HeaderCollections();
        conditionHeaderCollectionText.operator = "con";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(conditionHeaderCollectionCode);
        ruleDetails.queryConditions.get(0).conditions.add(conditionHeaderCollectionText);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(6000);

        //Act
        //Rule is fired as the declaration starts with 100456
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalInformation_CodeHeader = "100456789";
        declaration.additionalInformation_TextHeader = "information";

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).isEmpty();
    }


    @Test
    @Category({ChangeRequest.CR_2950.class})
    public void WhenDeclarationSubmittedMatchesOnlyContainerAndNotSealIdInRule_RouteNotReturned() throws Throwable {

        //Arrange

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionContainer = Conditions.containersCode_HeaderCollections();
        conditionContainer.operator = "eq";
        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionSealId = Conditions.sealId_HeaderCollections();
        conditionSealId.operator = "eq";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(conditionContainer);
        ruleDetails.queryConditions.get(0).conditions.add(conditionSealId);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(6000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.containers_IdHeader = "conCode123";
        declaration.sealId_Header = "999";

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).isEmpty();
    }

    @Test
    @Category({ChangeRequest.CR_2782.class})
    public void WhenDeclarationSubmittedMatchesBothInformationCodeAndTextInRule_RouteReturned() throws Throwable {

        //Arrange

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionHeaderCollectionCode = Conditions.additionalInfoCode_HeaderCollections();
        conditionHeaderCollectionCode.operator = "con";
        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionHeaderCollectionText = Conditions.additionalInfoText_HeaderCollections();
        conditionHeaderCollectionText.operator = "con";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(conditionHeaderCollectionCode);
        ruleDetails.queryConditions.get(0).conditions.add(conditionHeaderCollectionText);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(6000);

        //Act
        //Rule is fired as the declaration starts with 100456
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalInformation_CodeHeader = "100456789";
        declaration.additionalInformation_TextHeader = "matchestheinfotext";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration, 1);
    }

    @Test
    @Category({ChangeRequest.CR_2782.class})
    public void WhenDeclarationSubmittedMatchesBothContainerCodeAndSealIdInRule_RouteReturned() throws Throwable {

        //Arrange

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionContainer = Conditions.containersCode_HeaderCollections();
        conditionContainer.operator = "eq";
        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionSealId = Conditions.sealId_HeaderCollections();
        conditionSealId.operator = "eq";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(conditionContainer);
        ruleDetails.queryConditions.get(0).conditions.add(conditionSealId);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(6000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.containers_IdHeader = "conCode123";
        declaration.sealId_Header = "SealId123";

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration, 1);

    }

    @Test
    @Category({ChangeRequest.CR_2782.class})
    public void WhenAtLeastOneCollectionInDeclarationMatchesInformationCodeAndTextInRule_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionHeaderCollectionCode = Conditions.additionalInfoCode_HeaderCollections();
        conditionHeaderCollectionCode.operator = "neq";
        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionHeaderCollectionText = Conditions.additionalInfoText_HeaderCollections();
        conditionHeaderCollectionText.operator = "eq";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(conditionHeaderCollectionCode);
        ruleDetails.queryConditions.get(0).conditions.add(conditionHeaderCollectionText);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(6000);

        //Act
        //Rule is fired as the declaration starts with 100456
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.additionalInformation_CodeHeader = "8788778";
        declaration.additionalInformation_TextHeader = "text";
        declaration.additionalInformation_CodeHeader1 = "100456";
        declaration.additionalInformation_TextHeader1 = "notmatching";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration, declarationSupport.getTemplateWithMultipleAdditionalInfo());

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration, 1);
    }


    @Test
    @Category({ChangeRequest.CR_2782.class})
    public void WhenInfoCodeAndTextInDeclarationDoesNotMatchAnySingleCollectionInRule_RouteNotReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionHeaderCollectionCode = Conditions.additionalInfoCode_HeaderCollections();
        conditionHeaderCollectionCode.operator = "neq";
        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionHeaderCollectionText = Conditions.additionalInfoText_HeaderCollections();
        conditionHeaderCollectionText.operator = "neq";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(conditionHeaderCollectionCode);
        ruleDetails.queryConditions.get(0).conditions.add(conditionHeaderCollectionText);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(6000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalInformation_CodeHeader = "8788778";
        declaration.additionalInformation_TextHeader = "text";
        declaration.additionalInformation_CodeHeader1 = "100456";
        declaration.additionalInformation_TextHeader1 = "notmatching";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration, declarationSupport.getTemplateWithMultipleAdditionalInfo());

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).isEmpty();
    }

    @Test
    @Category({ChangeRequest.CR_2782.class})
    public void WhenAllCollectionInDeclarationMatchesCollectionsInRule_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionHeaderCollectionCode = Conditions.additionalInfoCode_HeaderCollections();
        conditionHeaderCollectionCode.operator = "nco";
        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionHeaderCollectionText = Conditions.additionalInfoText_HeaderCollections();
        conditionHeaderCollectionText.operator = "nco";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(conditionHeaderCollectionCode);
        ruleDetails.queryConditions.get(0).conditions.add(conditionHeaderCollectionText);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(6000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.additionalInformation_CodeHeader = "8788778";
        declaration.additionalInformation_TextHeader = "information";
        declaration.additionalInformation_CodeHeader1 = "23";
        declaration.additionalInformation_TextHeader1 = "notmatching";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration, declarationSupport.getTemplateWithMultipleAdditionalInfo());

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration, 1);
    }

    @Test
    @Category({ChangeRequest.CR_2769.class})
    public void WhenDocumentTypeHeaderMatchesAndNotHeaderAndTexts_RouteNotReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionHeaderCollectionCode = Conditions.additionalInfoCode_HeaderCollections();
        conditionHeaderCollectionCode.operator = "neq";
        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionHeaderCollectionText = Conditions.additionalInfoText_HeaderCollections();
        conditionHeaderCollectionText.operator = "neq";
        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionDocumentType = Conditions.additionalDocumentsType_HeaderCollections();
        conditionHeaderCollectionText.operator = "nco";

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(conditionHeaderCollectionCode);
        ruleDetails.queryConditions.get(0).conditions.add(conditionHeaderCollectionText);
        ruleDetails.queryConditions.get(0).conditions.add(conditionDocumentType);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(6000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalInformation_CodeHeader = "8788778";
        declaration.additionalInformation_TextHeader = "text";
        declaration.additionalDocuments_TypeHeader="suppo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration, declarationSupport.getTemplateWithMultipleAdditionalInfo());

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).isEmpty();
    }

    @Test
    @Category({ChangeRequest.CR_2769.class})
    public void WhenDocumentTypeHeaderMatchesWithHeaderAndText_RouteReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionHeaderCollectionCode = Conditions.additionalInfoCode_HeaderCollections();
        conditionHeaderCollectionCode.operator = "neq";
        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionHeaderCollectionText = Conditions.additionalInfoText_HeaderCollections();
        conditionHeaderCollectionText.operator = "neq";
        API.DataForTests.TestRuleModel.RuleDetails.Condition conditionDocumentType = Conditions.additionalDocumentsType_HeaderCollections();
        conditionHeaderCollectionText.operator = "nco";

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(conditionHeaderCollectionCode);
        ruleDetails.queryConditions.get(0).conditions.add(conditionHeaderCollectionText);
        ruleDetails.queryConditions.get(0).conditions.add(conditionDocumentType);

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(6000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.additionalInformation_CodeHeader = "8778";
        declaration.additionalInformation_TextHeader = "test";
        declaration.additionalDocuments_TypeHeader="docs";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration, declarationSupport.getTemplateWithMultipleAdditionalInfo());

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).isEmpty();
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void GivenRuleWithNotEqualConditionOnHeaderCollectionWhenDeclarationDoesNotContainTheCollection_RouteNotReturned() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails.Condition condition = Conditions.additionalInfoCode_HeaderCollections();
        condition.operator = "neq";
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(condition);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration, declarationSupport.getTemplateWithNoAdditionalInfo());

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        //Assert
        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).isEmpty();

    }
}
