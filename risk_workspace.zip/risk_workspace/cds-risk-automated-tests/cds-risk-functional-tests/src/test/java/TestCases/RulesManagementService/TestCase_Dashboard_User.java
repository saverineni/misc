package TestCases.RulesManagementService;


import API.DataForTests.TestEnumerators;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Dashboard.ViewDashboarUserResponse;
import API.RulesManagementService.Users.ViewUserList.ViewUserListResponse;
import API.RulesManagementService.Utils.Dashboard;
import Categories_CDSRisk.CDS_RM_Dashboard;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import com.google.common.collect.ImmutableMap;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.Map;

import static API.RulesManagementService.Utils.Users.SearchUsers;
import static API.RulesManagementService.Utils.Users.UpdateStatusOfUser;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.junit.Assert.*;


@Category({Rules_Management.class, CDS_RM_Dashboard.class})
public class TestCase_Dashboard_User extends BaseWebAPITestCase {

    @Before
    public void Setup() {
        TestUserModel.UserDetails userDetails = Users_API.DefaultSuperAdminUser();
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

    }

    @Test
    @Category({ChangeRequest.CR_2640.class})
    public void WhenUserIsCheckedForLastLoginBeforeAndAfter90Days_CorrectDetailsAreDisplayed() {
        //Arrange
        TestUserModel.UserDetails userDetails_AdminLocal_POO = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO);
        Instant instant = Instant.parse(Instant.now ().toString());
        LocalDateTime ldt = LocalDateTime.ofInstant(instant, ZoneOffset.UTC);

        //Update the last login  of the user to below 90 days
        Instant lastLoginActive = instant.minus ( 89 , ChronoUnit.DAYS ).minus(23,ChronoUnit.HOURS).minus(59,ChronoUnit.MINUTES);
        LocalDateTime localDateTime = LocalDateTime.ofInstant(lastLoginActive, ZoneOffset.UTC);
       //Update the last login
        mySQL_cds_rules.updateLastLoginForTheUser(userDetails_AdminLocal_POO.pid,localDateTime.toString());
        API.UserService.ViewUser.ViewUserResponse actRespActiveUser = API.UserService.Utils.User.GetUserByPID(userDetails_AdminLocal_POO.pid);

        //Update the last login  of the user to above 90 days
        Instant lastLoginInActiveUser = instant.minus (90 , ChronoUnit.DAYS ).minus (5, ChronoUnit.MINUTES );
        localDateTime = LocalDateTime.ofInstant(lastLoginInActiveUser, ZoneOffset.UTC);
        mySQL_cds_rules.updateLastLoginForTheUser(userDetails_AdminLocal_POO.pid,localDateTime.toString());
        API.UserService.ViewUser.ViewUserResponse actRespInActiveUser = API.UserService.Utils.User.GetUserByPID(userDetails_AdminLocal_POO.pid);

        //As the last login is within 90 days the inactive should be false
        assertEquals(false,actRespActiveUser.inactive);
        //As the last login is above 90 days the inactive should be true
        assertEquals(true,actRespInActiveUser.inactive);

    }

    @Test
    @Category({ChangeRequest.CR_2640.class})
    public void WhenUserDashboardIsViewed_CorrectInActiveUsersAreDisplayed() {
        //Arrange
        TestUserModel.UserDetails userDetails_AdminLocal_POO = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO);

        TestUserModel.UserDetails userDetails_AdminLocal_POO_EXT = Users_API.AdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO_EXT);

        //Act

        ViewDashboarUserResponse.ViewUserResponseObject userResponseDashboard = Dashboard.GetDashboardUser("", "");
        int inactiveUserSize = userResponseDashboard.items.get(2).value;

        //Search for inactive users
        Map<String, String> queryParams = new ImmutableMap.Builder<String, String>()
                .put("inactive", "true")
                .build();
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = SearchUsers(queryParams);

        //Make one more user active and then search
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_AdminLocal_POO.pid);
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject1 = SearchUsers(queryParams);

        //initially when the navigated to user dashboard page
        assertEquals(inactiveUserSize,viewUserListResponseObject.content.size());
        assertTrue( userResponseDashboard.items.get(2).name.equalsIgnoreCase("INACTIVE"));

        //Inactive users will become less as one more user logs in
        assertEquals(inactiveUserSize-1,viewUserListResponseObject1.content.size());
    }

    @Test
    @Category({ChangeRequest.CR_2640.class})
    public void WhenUserDashboardIsFilteredByUserType_CorrectInActiveUsersAreDisplayed() {

        //Arrange
        TestUserModel.UserDetails userDetails_AdminLocal_POO = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO);

        TestUserModel.UserDetails userDetails_AdminLocal_POO_EXT = Users_API.AdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO_EXT);

        TestUserModel.UserDetails userDetails_RulesManagerNational = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RulesManagerNational);

        //Act
        ViewDashboarUserResponse.ViewUserResponseObject userResponseDashboard = Dashboard.GetDashboardUser("local", "");
        int inactiveUserSize = userResponseDashboard.items.get(2).value;

        //Search for inactive local users
        Map<String, String> queryParams = new ImmutableMap.Builder<String, String>()
                .put("userType", "local")
                .put("inactive", "true")
                .build();

        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = SearchUsers(queryParams);

        //Make one more user active and then search
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_AdminLocal_POO.pid);
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject1 = SearchUsers(queryParams);

        //initially when local user is selected in dashboard
        assertEquals(inactiveUserSize,viewUserListResponseObject.content.size());
        //Inactive users will become less as one more local user logs in
        assertEquals(inactiveUserSize-1,viewUserListResponseObject1.content.size());

    }

    @Test
    @Category({ChangeRequest.CR_2640.class})
    public void WhenUserDashboardIsFilteredByUserRole_CorrectInActiveUsersAreDisplayed() {

        //Arrange
        TestUserModel.UserDetails userDetails_RulesManagerLocal_POO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RulesManagerLocal_POO);

        TestUserModel.UserDetails userDetails_RuleViewerNational = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RuleViewerNational);

        TestUserModel.UserDetails userDetails_RuleViewerLocal_POO = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RuleViewerLocal_POO);

        //Act
        ViewDashboarUserResponse.ViewUserResponseObject viewUserResponseObject = Dashboard.GetDashboardUser("", "rulemanager");
        int inactiveUserSize = viewUserResponseObject.items.get(2).value;

        //Search for inactive rule manager users
        Map<String, String> queryParams = new ImmutableMap.Builder<String, String>()
                .put("userRole", "rulemanager")
                .put("inactive", "true")
                .build();

        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = SearchUsers(queryParams);

        //Make one more user active and then search
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_RulesManagerLocal_POO.pid);
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject1 = SearchUsers(queryParams);

        //initially when the rulemanager is selected in the dashboard
        assertEquals(inactiveUserSize,viewUserListResponseObject.content.size());
        //Inactive users will become less as one more rule manager logs in
        assertEquals(inactiveUserSize-1,viewUserListResponseObject1.content.size());

    }

    @Test
    @Category({ChangeRequest.CR_2640.class})
    public void WhenCheckedForSuspendedUsersInDashboard_VerifyTheyAreNotInListOfInActiveUsers() {

        //Arrange
        TestUserModel.UserDetails userDetails_AdminLocal_POO = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO);

        TestUserModel.UserDetails userDetails_AdminLocal_POO_EXT = Users_API.AdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO_EXT);

        //Act
        ViewDashboarUserResponse.ViewUserResponseObject viewUserResponseObjectAtStart = Dashboard.GetDashboardUser("", "");
        int inactiveUserSize = viewUserResponseObjectAtStart.items.get(2).value;
        int suspendedUserSizeAtStart = viewUserResponseObjectAtStart.items.get(1).value;

        //Search for inactive users
        Map<String, String> queryParams = new ImmutableMap.Builder<String, String>()
                .put("inactive", "true")
                .build();
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = SearchUsers(queryParams);

        //Make one user suspended and then search
        UpdateStatusOfUser(Users_API.AdminLocal_POO().pid, TestEnumerators.MetaDataActions.USER_SUSPEND.apiAction);
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject1 = SearchUsers(queryParams);

        ViewDashboarUserResponse.ViewUserResponseObject viewUserResponseObjectAfterUserIsSuspended = Dashboard.GetDashboardUser("", "");
        int suspendedUserSize = viewUserResponseObjectAfterUserIsSuspended.items.get(1).value;

        //inactive user and suspended user at start
        assertEquals(inactiveUserSize,viewUserListResponseObject.content.size());
        assertEquals(0,suspendedUserSizeAtStart);

        //Inactive users will become less as suspended user will not be in list of inactive users
        assertEquals(inactiveUserSize-1,viewUserListResponseObject1.content.size());
        assertEquals(1,suspendedUserSize);

    }

    @Test
    @Category({ChangeRequest.CR_2640.class})
    public void WhenCheckedForArchivedUsers_VerifyTheyAreNotInListOfInActiveUsers() {

        //Arrange
        TestUserModel.UserDetails userDetails_AdminLocal_POO = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO);

        TestUserModel.UserDetails userDetails_AdminLocal_POO_EXT = Users_API.AdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO_EXT);

        //Act
        ViewDashboarUserResponse.ViewUserResponseObject viewUserResponseObjectAtStart = Dashboard.GetDashboardUser("", "");
        int inactiveUserSize = viewUserResponseObjectAtStart.items.get(2).value;

        //Search for inactive users
        Map<String, String> queryParams = new ImmutableMap.Builder<String, String>()
                .put("inactive", "true")
                .build();
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = SearchUsers(queryParams);

        //Make one user archived and then search
        UpdateStatusOfUser(Users_API.AdminLocal_POO().pid, TestEnumerators.MetaDataActions.USER_ARCHIVE.apiAction);
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject1 = SearchUsers(queryParams);


        //inactive user at start
        assertEquals(inactiveUserSize,viewUserListResponseObject.content.size());

        //Inactive users will become less as archived user will not be in list of inactive users
        assertEquals(inactiveUserSize-1,viewUserListResponseObject1.content.size());

    }


    @Test
    @Category({ChangeRequest.CR_2611.class})
    public void WhenActiveUserCreated_UserDashboardHasCorrectData()
    {
        //Arrange

        //Act
        ViewDashboarUserResponse.ViewUserResponseObject viewUserResponseObject = Dashboard.GetDashboardUser("", "");

        //Assert
        assertThat("Expect Total Users ",viewUserResponseObject.total,greaterThanOrEqualTo(2));
        assertThat("Expect Total Item Status",viewUserResponseObject.items.size(),greaterThanOrEqualTo(2));
        assertTrue( viewUserResponseObject.items.get(0).name.equalsIgnoreCase("ACTIVE"));
        assertThat("Expect ACTIVE >= 2", viewUserResponseObject.items.get(0).value,greaterThanOrEqualTo(2));
    }

    @Test
    @Category({ChangeRequest.CR_2611.class})
    public void WhenSuspendedUserCreated_UserDashboardHasCorrectData()
    {
        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_SUSPEND.apiAction);

        //Act
        ViewDashboarUserResponse.ViewUserResponseObject viewUserResponseObject = Dashboard.GetDashboardUser("", "");

        //Assert
        assertThat("Expect Total Users ",viewUserResponseObject.total,greaterThanOrEqualTo(3));
        assertTrue( viewUserResponseObject.items.get(1).name.equalsIgnoreCase("SUSPENDED"));
        assertThat("Expect SUSPENDED >= 1",viewUserResponseObject.items.get(1).value,greaterThanOrEqualTo(1));
    }

    @Test
    @Category({ChangeRequest.CR_2611.class})
    public void WhenUserDashboardFilteredByUserTypeAndRole_UserDashboardDisplayCorrectData()
    {
        //Arrange
        TestUserModel.UserDetails userDetails_RM = Users_API.RulesManagerLocal_WAT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RM);

        TestUserModel.UserDetails userDetails_RV = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RV);

        //Act
        ViewDashboarUserResponse.ViewUserResponseObject viewUserResponseObject_Local = Dashboard.GetDashboardUser("local", "");
        ViewDashboarUserResponse.ViewUserResponseObject viewUserResponseObject_Local_RV = Dashboard.GetDashboardUser("local", "ruleviewer");
        ViewDashboarUserResponse.ViewUserResponseObject viewUserResponseObject_SAdmin = Dashboard.GetDashboardUser("", "superadmin");

        //Assert
        assertThat("Expect Total Users ", viewUserResponseObject_Local.total,greaterThanOrEqualTo(2));
        assertThat("Expect Total Users ", viewUserResponseObject_Local_RV.total,greaterThanOrEqualTo(1));
        assertThat("Expect Total Users ", viewUserResponseObject_SAdmin.total,greaterThanOrEqualTo(1));
    }


}
