package TestCases.RulesManagementService;

import API.DataForTests.*;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.ShareDataTable.ShareDataTableMetaResponse;
import API.RulesManagementService.Data.ShareDataTable.ShareDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import API.RulesManagementService.Data.ViewDataTableList.ViewDataTableListResponse;
import Categories_CDSRisk.CDS_RM_DataTable;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import org.apache.commons.httpclient.HttpStatus;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static API.RulesManagementService.Utils.DataTables.*;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_DataTable.class})
public class TestCase_DataTable_ShareForOwnership extends WebAPITestCaseWithDatatablesCleanup {

    private TestDataTableModel.TableDetails tableDetails;

    @Before
    public void Setup() {

        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_POO());
        tableDetails = DataTables.DataTable_CommodityCodes_POO();
    }

    @Test
    @Category(ChangeRequest.CR_1029.class)
    public void WhenRestrictedDataTableSharedWithSingleLocation_ListOfLocationsUpdatedSuccessfully()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.manageTableLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        ShareDataTableResponse.ShareDataTableResponseObject shareDataTableResponseObject = ShareDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject responseTableDetails = GetDataTableByUID(tableDetails.uuid);

        //locations shared for manage are also shared for usage
        tableDetails.useTablesLocationUuids = tableDetails.manageTableLocationUuids;

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, shareDataTableResponseObject.httpStatusCode);

        Assertions.assertThat(shareDataTableResponseObject.manageTables).extracting("locationName")
                .containsOnly("POO", "EXT");

        Assertions.assertThat(shareDataTableResponseObject.useTables).extracting("locationName")
                .containsOnly("POO", "EXT");

        Assertions.assertThat(responseTableDetails.locations.manageTables).extracting("locationName")
                .containsOnly("POO", "EXT");

        Assertions.assertThat(responseTableDetails.locations.useTables).extracting("locationName")
                .containsOnly("POO", "EXT");
    }


    @Test
    @Category(ChangeRequest.CR_1029.class)
    public void WhenDataTableSharedWithMultipleLocations_ListOfLocationsUpdatedSuccessfully()
        {
            //Arrange
            tableDetails.tableType = "restricted";
            CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

            //Act
            tableDetails.manageTableLocationUuids.add(Locations.Location_EXT_UID);
            tableDetails.manageTableLocationUuids.add(Locations.Location_WAT_UID);
            tableDetails.manageTableLocationUuids.add(Locations.Location_LON_UID);
            tableDetails.uuid = createDataTableResponse.uuid;

            tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
            ShareDataTableAndGetResponseObject(tableDetails);

            ViewDataTableResponse.ViewDataTableResponseObject response = GetDataTableByUID(tableDetails.uuid);

            //locations shared for manage are also shared for usage
            tableDetails.useTablesLocationUuids = tableDetails.manageTableLocationUuids;

            //Assert
            Assertions.assertThat(response.locations.manageTables).extracting("locationName")
                    .containsOnly("POO", "EXT", "WAT", "LON");

            Assertions.assertThat(response.locations.useTables).extracting("locationName")
                    .containsOnly("POO", "EXT", "WAT", "LON");
        }


    @Test
    @Category(ChangeRequest.CR_1029.class)
    public void WhenDataTableSharedWithSameLocation_ServiceHandlesRequestWithoutServerException()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        tableDetails.manageTableLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetails);
        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponseObject = GetDataTableDetailsByUID(tableDetails.uuid);
        tableDetails.opLockVersion = viewDataTableResponseObject.opLockVersion;

        //Act
        ShareDataTableResponse.ShareDataTableResponseObject shareDataTableAgainResp = API.RulesManagementService.Utils.DataTables.ShareDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject response = GetDataTableByUID(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, shareDataTableAgainResp.httpStatusCode);

        Assertions.assertThat(response.locations.manageTables).extracting("locationName")
                .containsOnly("POO", "EXT");

        Assertions.assertThat(response.locations.useTables).extracting("locationName")
                .containsOnly("POO", "EXT");
    }


    @Test
    @Category(ChangeRequest.CR_1029.class)
    public void WhenDataTableSharedWithLocationEXT_UserFromEXTCanViewDataTable()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.manageTableLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        //Assert
        TestUserModel.UserDetails usTD2 = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(usTD2);
        API.RulesManagementService.Utils.Users.LoginAsUser(usTD2.pid);

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = GetListOfDataTables();

        boolean tableFound = CheckIfDataTableNameIsPresentInListOfTables(viewDataTableListResponseObject, tableDetails.tableName);
        assertEquals("Expect table: " + tableDetails.tableName + " to be present", true, tableFound);
    }


    @Test
    @Category(ChangeRequest.CR_1029.class)
    public void WhenDataTableSharedWithLocationEXTAndWAT_UserFromEXTOrWATCanViewDataTable()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.manageTableLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.manageTableLocationUuids.add(Locations.Location_WAT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        //Assert
        TestUserModel.UserDetails usTD2 = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(usTD2);
        API.RulesManagementService.Utils.Users.LoginAsUser(usTD2.pid);

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListEXTResponse = GetListOfDataTables();

        boolean tableFound = CheckIfDataTableNameIsPresentInListOfTables(viewDataTableListEXTResponse, tableDetails.tableName);
        assertEquals("Expect table: " + tableDetails.tableName + " to be present", true, tableFound);

        TestUserModel.UserDetails udLOCRuleManagerWAT = Users_API.RulesManagerLocal_WAT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManagerWAT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManagerWAT.pid);

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListWATResponse = GetListOfDataTables();

        tableFound = CheckIfDataTableNameIsPresentInListOfTables(viewDataTableListWATResponse, tableDetails.tableName);
        assertEquals("Expect table: " + tableDetails.tableName + " to be present", true, tableFound);
    }


    @Test
    @Category(ChangeRequest.CR_1029.class)
    public void WhenDataTableSharedWithLocationNational_NationalUserCanViewDataTable()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.manageTableLocationUuids.add(Locations.Location_National_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        //Assert
        TestUserModel.UserDetails udNATRuleManager = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(udNATRuleManager);
        API.RulesManagementService.Utils.Users.LoginAsUser(udNATRuleManager.pid);

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = GetListOfDataTables();

        boolean tableFound = CheckIfDataTableNameIsPresentInListOfTables(viewDataTableListResponseObject, tableDetails.tableName);
        assertEquals("Expect table: " + tableDetails.tableName + " to be present", true, tableFound);
    }


    @Test
    @Category(ChangeRequest.CR_1029.class)
    public void WhenDataTableSharedWithAllLocations_LocalUserCanViewDataTable() {

        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.manageTableLocationUuids.add(Locations.Location_AllLocations_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        //Assert
        TestUserModel.UserDetails udLOCRuleManagerEXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManagerEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManagerEXT.pid);

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = GetListOfDataTables();

        boolean tableFound = CheckIfDataTableNameIsPresentInListOfTables(viewDataTableListResponseObject, tableDetails.tableName);
        assertEquals("Expect table: " + tableDetails.tableName + " to be present", true, tableFound);
     }


    @Test
    @Category(ChangeRequest.CR_1029.class)
    public void WhenDataTableSharedWithAllLocationsSetToTrue_LocalUserCanViewDataTable()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.shareAllLocations = true;
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        //Assert
        TestUserModel.UserDetails udLOCRuleManagerEXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManagerEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManagerEXT.pid);

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListResponseObject = GetListOfDataTables();

        boolean tableFound = CheckIfDataTableNameIsPresentInListOfTables(viewDataTableListResponseObject, tableDetails.tableName);
        assertEquals("Expect table: " + tableDetails.tableName + " to be present", true, tableFound);
    }


    @Test
    @Category(ChangeRequest.CR_1186.class)
    public void WhenDataTableSharedWithLocationAndViewedByRuleManager_DataTableActionsCorrect()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.manageTableLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        TestUserModel.UserDetails udLOCRuleManagerEXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManagerEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManagerEXT.pid);

        ViewDataTableResponse.ViewDataTableResponseObject response = GetDataTableByUID(tableDetails.uuid);

        //Assert
        Assertions.assertThat(response.metaData.actions).containsAll(tableDetails.actions);
    }


    @Test
    @Category(ChangeRequest.CR_1186.class)
    public void WhenDataTableSharedWithAllLocationsAndViewedByRuleManager_DataTableActionsCorrect()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.shareAllLocations = true;
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        TestUserModel.UserDetails udLOCRuleManagerEXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManagerEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManagerEXT.pid);

        ViewDataTableResponse.ViewDataTableResponseObject response = GetDataTableByUID(tableDetails.uuid);

        //Assert
        Assertions.assertThat(response.metaData.actions).containsAll(tableDetails.actions);
    }


    @Test
    @Category(ChangeRequest.CR_1186.class)
    public void WhenDataTableSharedWithLocationAndViewedByRuleViewer_DataTableActionsCorrect()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.manageTableLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        TestUserModel.UserDetails udLOCRuleViewerEXT = Users_API.RulesViewerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleViewerEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleViewerEXT.pid);

        ViewDataTableResponse.ViewDataTableResponseObject response = GetDataTableByUID(tableDetails.uuid);

        //Assert
        //Actions should not contain "DATA_TABLE_MANAGE_USE", "DATA_TABLE_MANAGE_OWNERS", "DATA_TABLE_EDIT"
        Assertions.assertThat(response.metaData.actions).doesNotContainAnyElementsOf(tableDetails.actions);
    }


    @Test
    @Category(ChangeRequest.CR_1186.class)
    public void WhenDataTableSharedWithAllLocationsAndViewedByRuleViewer_DataTableActionsCorrect()
    {
        //Arrange
        tableDetails.tableType = "restricted";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.shareAllLocations = true;
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        TestUserModel.UserDetails udLOCRuleViewerEXT = Users_API.RulesViewerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleViewerEXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleViewerEXT.pid);

        ViewDataTableResponse.ViewDataTableResponseObject response = GetDataTableByUID(tableDetails.uuid);

        //Assert
        //Actions should not contain "DATA_TABLE_MANAGE_USE", "DATA_TABLE_MANAGE_OWNERS", "DATA_TABLE_EDIT"
        Assertions.assertThat(response.metaData.actions).doesNotContainAnyElementsOf(tableDetails.actions);
    }

//TODO Share Data Table for Ownership and check user can edit table: Note not restricted by backend


    @Test
    @Category(ChangeRequest.CR_1029.class)
    public void WhenSensitiveDataTableSharedWithSingleLocation_ListOfLocationsUpdatedSuccessfully()
    {
        //Arrange
        tableDetails.tableType = "sensitive";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.manageTableLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        ShareDataTableResponse.ShareDataTableResponseObject shareDataTableResponseObject = ShareDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject response = GetDataTableByUID(tableDetails.uuid);

        //locations shared for manage are also shared for usage
        tableDetails.useTablesLocationUuids = tableDetails.manageTableLocationUuids;

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, shareDataTableResponseObject.httpStatusCode);

        Assertions.assertThat(shareDataTableResponseObject.manageTables).extracting("locationName")
                .containsOnly("POO", "EXT");

        Assertions.assertThat(shareDataTableResponseObject.useTables).extracting("locationName")
                .containsOnly("POO", "EXT");

        assertEquals("Expect Manage Locations: ", 2,  response.locations.manageTables.size());
        assertEquals("Expect Use Locations: ", 2,  response.locations.useTables.size());
    }


    @Test
    @Category({ChangeRequest.CR_2135.class})
    public void WhenOpenDataTableSharedForOwnershipWithSingleLocation_ListOfLocationsUpdatedSuccessfully()
    {
        //Arrange
        tableDetails.tableType = "open";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.manageTableLocationUuids.clear();
        tableDetails.manageTableLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        ShareDataTableResponse.ShareDataTableResponseObject shareDataTableResponseObject = ShareDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject response = GetDataTableByUID(tableDetails.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, shareDataTableResponseObject.httpStatusCode);

        Assertions.assertThat(shareDataTableResponseObject.manageTables).extracting("locationName")
                .containsOnly("POO", "EXT");

        Assertions.assertThat(shareDataTableResponseObject.useTables).extracting("locationName")
                .containsOnly("POO", "All Locations", "EXT");

        assertEquals("Expect Manage Locations: ", 2,  response.locations.manageTables.size());
        assertEquals("Expect Use Locations: ", 3,  response.locations.useTables.size());
    }

    @Test
    @Category({ChangeRequest.CR_2226.class})
    public void WhenDataTableShared_FreightTypeCategoryContainsFreightTypes()
    {
        //Arrange
        tableDetails.tableType = "open";
        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);

        //Act
        tableDetails.manageTableLocationUuids.clear();
        tableDetails.manageTableLocationUuids.add(Locations.Location_EXT_UID);
        tableDetails.uuid = createDataTableResponse.uuid;

        tableDetails.creationShareType = TestEnumerators.ShareTypes.owner.toString();
        ShareDataTableAndGetResponseObject(tableDetails);

        ShareDataTableMetaResponse.ShareDataTableMetaResponseObject shareDataTableMetaResponseObject = GetMetaResponseForSharedDataTable(tableDetails);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, shareDataTableMetaResponseObject.httpStatusCode);

        Assertions.assertThat(shareDataTableMetaResponseObject.freightTypeCategories).extracting("name")
                .containsOnly("Air", "Maritime", "National");

        Assertions.assertThat(shareDataTableMetaResponseObject.freightTypeCategories).extracting("value")
                .containsOnly("air", "maritime", "none");

    }
}
