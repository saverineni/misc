package TestCases.RulesManagementService;


import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.RuleAction.RuleActionResponse;
import API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse;
import API.RulesManagementService.Users.UserHistory.UserHistoryResponse;
import API.RulesManagementService.Utils.Users;
import API.RulesManagementService.ViewRule.ViewRuleResponse;
import API.RulesManagementService.ViewRuleList.ViewRuleListResponse;
import API.RulesManagementService.ViewRuleVersion.ViewRuleVersionResponse;
import Categories_CDSRisk.CDS_RM_Login;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import static API.RulesManagementService.Utils.RuleAtStatus.ArchiveRule;
import static API.RulesManagementService.Utils.RuleAtStatus.SuspendRule;
import static API.RulesManagementService.Utils.Rules.ReinstateRule;
import static API.RulesManagementService.Utils.Users.UpdateStatusOfUser;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_Login.class})
public class TestCase_LoginRuleManager  extends BaseWebAPITestCase {

    @Before
    public void Setup()
    {
        //Logged in as National Rules Manager via Base Web API Test Class
    }

    @Test
    @Category(ChangeRequest.CR_597.class)
    public void WhenUserCreatesRule_CanCreateRule() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        //Act
        Response response = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.getStatusCode());
        assertEquals(ruleDetails.description, response.path("description"));
    }


    @Test
    @Category(ChangeRequest.CR_597.class)
    public void WhenUserViewRule_CanViewRule() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(createRuleResponse.uniqueId);

        //Assert
        assertEquals(HttpStatus.SC_OK, viewRuleResponse.httpStatusCode);
        assertEquals(ruleDetails.description, viewRuleResponse.versions.get(0).description);
    }


    @Test
    @Category(ChangeRequest.CR_597.class)
    public void WhenUserViewRules_CanViewRules() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject viewRulesResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        assertEquals(HttpStatus.SC_OK, viewRulesResponse.httpStatusCode);

        int ruleNo = API.RulesManagementService.Utils.Rules.GetNoOfMatchingRuleFromRuleList(viewRulesResponse, createRuleResponse.uniqueId);

        assertEquals(ruleDetails.description, viewRulesResponse.content.get(ruleNo).description);
    }

    @Test
    @Category(ChangeRequest.CR_597.class)
    public void WhenUserViewsRuleDetails_CanViewRule() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(createRuleResponse.uniqueId, createRuleResponse.versionId);

        //Assert
        assertEquals(HttpStatus.SC_OK, viewRuleResponse.httpStatusCode);
        assertEquals(ruleDetails.description, viewRuleResponse.description);
    }

    @Test
    @Category(ChangeRequest.CR_597.class)
    public void WhenUserSavesRule_CanSaveRule() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ruleDetails.description = "ta_updatedRule";
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        Response editResponse = API.RulesManagementService.Utils.Rules.EditRule(ruleDetails);
        ruleDetails.version = 2;

        //Assert
        assertEquals(HttpStatus.SC_OK, editResponse.getStatusCode());
        assertEquals(ruleDetails.description, editResponse.path("description"));
    }


    @Test
    @Category(ChangeRequest.CR_597.class)
    public void WhenUserCommitsRule_CanCommitRule() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        EditRuleVersionResponse.PutResponse editResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);
        ruleDetails.status = "committed";

        //Assert
        assertEquals(HttpStatus.SC_OK, editResponse.httpStatusCode);
        assertEquals(ruleDetails.description, editResponse.description);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), editResponse.status);
    }


    @Test
    @Category(ChangeRequest.CR_597.class)
    public void WhenUserDeletesRule_CanDeleteRule() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        EditRuleVersionResponse.PutResponse editResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.delete);


        //Assert
        assertEquals(HttpStatus.SC_OK, editResponse.httpStatusCode);
        assertEquals(ruleDetails.description, editResponse.description);
        assertEquals(TestEnumerators.RuleStatus.deleted.toString(), editResponse.status);
    }


    @Test
    @Category(ChangeRequest.CR_597.class)
    public void WhenUserSuspendsLiveRule_CanSuspendRule() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        ruleDetails.uniqueID = createRuleResponse.uniqueId;
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Act
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        RuleActionResponse.PostResponse suspendResponse = SuspendRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_OK, suspendResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_597.class)
    public void WhenUserReinstatesSuspendedRule_CanReinstateRule() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        ruleDetails.uniqueID = createRuleResponse.uniqueId;
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        RuleActionResponse.PostResponse suspendResponse = SuspendRule(ruleDetails);

        //Act
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        RuleActionResponse.PostResponse reinstateResponse = ReinstateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_OK, reinstateResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_597.class)
    public void WhenUserArchivesLiveRule_CanArchiveRule() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        ruleDetails.uniqueID = createRuleResponse.uniqueId;
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Act
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        RuleActionResponse.PostResponse archiveResponse = ArchiveRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_OK, archiveResponse.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenRuleManagerLoggedIn_NoMetaDataActionsAvailableForRuleManager() {

        //Arrange

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(0);
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void AttemptToArchiveRuleViewerUser_ForbiddenResponseReceived() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());
        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        API.RulesManagementService.Utils.Users.LoginAsUser(Users_API.NationalRulesManagerDefaultTestAutomationUser().pid,Users_API.SUPER_ADMIN_DEFAULT_PASSWORD);
        Response userResponse = UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_ARCHIVE.apiAction);

        //Assert
        assertEquals(HttpStatus.SC_FORBIDDEN, userResponse.statusCode());
    }

    @Test
    @Category(ChangeRequest.CR_2698.class)
    public void AttemptToSuspendRuleViewerUser_ForbiddenResponseReceived() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());
        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        API.RulesManagementService.Utils.Users.LoginAsUser(Users_API.NationalRulesManagerDefaultTestAutomationUser().pid,Users_API.SUPER_ADMIN_DEFAULT_PASSWORD);
        Response userResponse = UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_SUSPEND.apiAction);

        //Assert
        assertEquals(HttpStatus.SC_FORBIDDEN, userResponse.statusCode());
    }


    @Test
    @Category(ChangeRequest.CR_2698.class)
    public void AttemptToEditUser_ForbiddenResponseReceived() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());
        TestUserModel.UserDetails userDetails = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        API.RulesManagementService.Utils.Users.LoginAsUser(Users_API.NationalRulesManagerDefaultTestAutomationUser().pid,Users_API.SUPER_ADMIN_DEFAULT_PASSWORD);

        UserMeDetailsResponse.UsersMeResponseObject usersMeResponseObject1 = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails.pid);
        userDetails.opLockVersion = usersMeResponseObject1.opLockVersion;
        userDetails.reason = "Editing User";
        Response response = API.RulesManagementService.Utils.Users.EditUser(userDetails);

        //Assert
        assertEquals(HttpStatus.SC_FORBIDDEN, response.statusCode());
    }


    @Test
    public void AttemptToViewUserHistory_ForbiddenResponseReceived() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsUser(Users_API.NationalRulesManagerDefaultTestAutomationUser().pid,Users_API.SUPER_ADMIN_DEFAULT_PASSWORD);

        // Act
        UserHistoryResponse.UserHistoryResponseObject userHistoryResponseObject = Users.GetListOfUserHistory(Users_API.NationalRulesManagerDefaultTestAutomationUser().pid);

        //Assert
        assertEquals("Expect HttpStatus.SC_FORBIDDEN ", org.apache.http.HttpStatus.SC_FORBIDDEN, userHistoryResponseObject.httpStatusCode);
    }


}
