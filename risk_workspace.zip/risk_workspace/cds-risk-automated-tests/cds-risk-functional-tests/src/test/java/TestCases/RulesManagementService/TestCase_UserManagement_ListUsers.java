package TestCases.RulesManagementService;


import API.DataForTests.TestEnumerators;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.EnvDetails.EnvDetails;
import API.RulesManagementService.Users.ViewUserList.ViewUserListResponse;
import Categories_CDSRisk.CDS_RM_UserManagement;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;
import java.util.Map;

import static API.RulesManagementService.Utils.Users.*;

@Category({Rules_Management.class, CDS_RM_UserManagement.class})
public class TestCase_UserManagement_ListUsers extends BaseWebAPITestCase {

    @Before
    public void Setup() {

        TestUserModel.UserDetails userDetails = Users_API.DefaultSuperAdminUser();
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenActiveUserCreated_ActiveUserPresentInListOfUsers() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers();

        //Assert
        Assertions.assertThat(viewUserListResponseObject.content).extracting("status").contains(TestEnumerators.MetaDataActions.USER_REINSTATE.apiResponse);
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenUserArchived_ArchivedUserPresentInListOfUsers() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_ARCHIVE.apiAction);

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers();

        //Assert
        Assertions.assertThat(viewUserListResponseObject.content).extracting("status").contains(TestEnumerators.MetaDataActions.USER_ARCHIVE.apiResponse);
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenUserSuspended_SuspendedUserPresentInListOfUsers() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_SUSPEND.apiAction);

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers();

        //Assert
        Assertions.assertThat(viewUserListResponseObject.content).extracting("status").contains(TestEnumerators.MetaDataActions.USER_SUSPEND.apiResponse);
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenUserReinstated_ReinstatedUserPresentInListOfUsers() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_SUSPEND.apiAction);
        UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_REINSTATE.apiAction);

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers();

        //Assert
        Assertions.assertThat(viewUserListResponseObject.content).extracting("status").contains(TestEnumerators.MetaDataActions.USER_REINSTATE.apiResponse);
    }


    @Test
    @Category(ChangeRequest.CR_2429.class)
    public void WhenListOfUserDisplayed_CorrectRoleDisplayedForUsers() {

        //Arrange
        TestUserModel.UserDetails userDetailsMixRoles = Users_API.UserWithAllRoles_MixLocations2();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsMixRoles);

        TestUserModel.UserDetails userDetailsLocalAdmin = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsLocalAdmin);

        TestUserModel.UserDetails userDetailsLocalSuperAdmin = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsLocalSuperAdmin);

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers();
        ViewUserListResponse.Content userMixRoles = GetUserFromListOfUsersByPID(viewUserListResponseObject.content, userDetailsMixRoles.pid);
        ViewUserListResponse.Content userLocalAdmin = GetUserFromListOfUsersByPID(viewUserListResponseObject.content, userDetailsLocalAdmin.pid);
        ViewUserListResponse.Content userLocalSuperAdmin = GetUserFromListOfUsersByPID(viewUserListResponseObject.content, userDetailsLocalSuperAdmin.pid);


        //Assert
        Assertions.assertThat(userMixRoles.superAdmin).isTrue();
        Assertions.assertThat(userMixRoles.admin).isTrue();
        Assertions.assertThat(userMixRoles.ruleManager).isTrue();

        Assertions.assertThat(userLocalAdmin.superAdmin).isFalse();
        Assertions.assertThat(userLocalAdmin.admin).isTrue();
        Assertions.assertThat(userLocalAdmin.ruleManager).isFalse();

        Assertions.assertThat(userLocalSuperAdmin.superAdmin).isTrue();
        Assertions.assertThat(userLocalSuperAdmin.admin).isFalse();
        Assertions.assertThat(userLocalSuperAdmin.ruleManager).isFalse();
    }

    @Test
    @Category(ChangeRequest.CR_2623.class)
    public void WhenListOfUsersFilteredByUserTypeNational_OnlyListOfNationalUsersReturned() {

        TestUserModel.UserDetails userDetails1 = Users_API.AdminNational();
        TestUserModel.UserDetails userDetails2 = Users_API.SuperAdminNational();
        TestUserModel.UserDetails userDetailsLocalAdmin = Users_API.AdminLocal_POO();

        List<TestUserModel.UserDetails> usersToCreate = Lists.newArrayList(userDetails1, userDetails2, userDetailsLocalAdmin);

        createUsersFilterByTypeAndAssertUserPids(usersToCreate, TestEnumerators.UserType.national,
                Lists.newArrayList(userDetails1.pid, userDetails2.pid));
    }

    @Test
    @Category(ChangeRequest.CR_2623.class)
    public void WhenListOfUsersFilteredByUserTypeLocal_OnlyListOfLocalUsersReturned() {

        TestUserModel.UserDetails userDetails1 = Users_API.AdminNational();
        TestUserModel.UserDetails userDetailsLocalAdminPOO = Users_API.SuperAdminLocal_POO();
        TestUserModel.UserDetails userDetailsLocalAdminEXT = Users_API.AdminLocal_POO_EXT();

        List<TestUserModel.UserDetails> usersToCreate = Lists.newArrayList(userDetails1, userDetailsLocalAdminPOO, userDetailsLocalAdminEXT);

        createUsersFilterByTypeAndAssertUserPids(usersToCreate, TestEnumerators.UserType.local,
                Lists.newArrayList(userDetailsLocalAdminPOO.pid, userDetailsLocalAdminEXT.pid));
    }

    @Test
    @Category(ChangeRequest.CR_2623.class)
    public void WhenListOfUsersFilteredByStatusActive_OnlyListOfActiveUsersReturned() {

        // Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_ARCHIVE.apiAction);

        TestUserModel.UserDetails userDetails2 = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UpdateStatusOfUser(userDetails2.pid, TestEnumerators.MetaDataActions.USER_SUSPEND.apiAction);

        // Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = SearchUsers("userStatus",
                TestEnumerators.UserStatus.active.name());

        // Assert
        Assertions.assertThat(viewUserListResponseObject.content)
                .extracting("status").containsOnly(TestEnumerators.UserStatus.active.name());

        Assertions.assertThat(viewUserListResponseObject.content)
                .extracting("pid").doesNotContain(userDetails.pid, userDetails2.pid);
    }

    @Test
    @Category(ChangeRequest.CR_2623.class)
    public void WhenListOfUsersFilteredByStatusSuspended_OnlyListOfSuspendedUsersReturned() {

        // Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_ARCHIVE.apiAction);

        TestUserModel.UserDetails userDetails2 = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UpdateStatusOfUser(userDetails2.pid, TestEnumerators.MetaDataActions.USER_SUSPEND.apiAction);

        // Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = SearchUsers("userStatus",
                TestEnumerators.UserStatus.suspended.name());

        // Assert
        Assertions.assertThat(viewUserListResponseObject.content)
                .extracting("status").containsOnly(TestEnumerators.UserStatus.suspended.name());

        Assertions.assertThat(viewUserListResponseObject.content)
                .extracting("pid").contains(userDetails2.pid);
    }

    @Test
    @Category(ChangeRequest.CR_2623.class)
    public void WhenListOfUsersFilteredByNationalAndActiveFilter_OnlyUsersThatAreNationalAndActiveReturned() {

        // Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_SUSPEND.apiAction);

        // Act
        Map<String, String> queryParams = new ImmutableMap.Builder<String, String>()
                .put("userType", TestEnumerators.UserType.national.name())
                .put("userStatus", TestEnumerators.UserStatus.active.name())
                .build();

        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = SearchUsers(queryParams);

        // Assert
        Assertions.assertThat(viewUserListResponseObject.content)
                .extracting("status").containsOnly(TestEnumerators.UserStatus.active.name());

        Assertions.assertThat(viewUserListResponseObject.content)
                .extracting("userType").containsOnly(TestEnumerators.UserType.national.name());

        Assertions.assertThat(viewUserListResponseObject.content)
                .extracting("pid")
                .doesNotContain(userDetails.pid)
                .contains(Users_API.NationalRulesManagerDefaultTestAutomationUser().pid,
                            Users_API.DefaultSuperAdminUser().pid);
    }


    @Test
    @Category(ChangeRequest.CR_2623.class)
    public void WhenListOfUsersFilteredByLocalAndActiveFilter_OnlyUsersThatAreLocalAndActiveReturned() {

        // Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        UpdateStatusOfUser(userDetails.pid, TestEnumerators.MetaDataActions.USER_SUSPEND.apiAction);

        TestUserModel.UserDetails userDetails2 = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);

        // Act
        Map<String, String> queryParams = new ImmutableMap.Builder<String, String>()
                .put("userType", TestEnumerators.UserType.local.name())
                .put("userStatus", TestEnumerators.UserStatus.active.name())
                .build();

        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = SearchUsers(queryParams);

        // Assert
        Assertions.assertThat(viewUserListResponseObject.content)
                .extracting("status").containsOnly(TestEnumerators.UserStatus.active.name());

        Assertions.assertThat(viewUserListResponseObject.content)
                .extracting("userType").containsOnly(TestEnumerators.UserType.local.name());

        Assertions.assertThat(viewUserListResponseObject.content)
                .extracting("pid")
                .contains(userDetails2.pid)
                .doesNotContain(userDetails.pid);
    }


    private void createUsersFilterByTypeAndAssertUserPids(List<TestUserModel.UserDetails> usersToCreate,
                                                          TestEnumerators.UserType expectedUserType, List<String> expectedPids) {
        // Arrange
        usersToCreate.forEach(userDetails -> API.RulesManagementService.Utils.Users.CreateNewUser(userDetails));

        // Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = SearchUsers("userType", expectedUserType.name());

        //Assert
        Assertions.assertThat(viewUserListResponseObject.content)
                .extracting("userType").containsOnly(expectedUserType.name());
        Assertions.assertThat(viewUserListResponseObject.content).extracting("pid")
                .containsAll(expectedPids);
    }

    @Test
    @Category({ChangeRequest.CR_2680.class})
    public void WhenVerifiedForListOfInactiveUsers_ListUsersShouldBeShownCorrectly() {

        //Arrange
        TestUserModel.UserDetails userDetails_Admin_National_InActive = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_Admin_National_InActive);

        TestUserModel.UserDetails userDetails_Admin_Local_InActive = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_Admin_Local_InActive);

        TestUserModel.UserDetails userDetails_Admin_AllLocations_Active = Users_API.AdminLocal_AllLocations();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_Admin_AllLocations_Active);

        TestUserModel.UserDetails userDetails_RulesViewerNational_Inactive = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RulesViewerNational_Inactive);

        TestUserModel.UserDetails userDetails_RuleViewerLocal_POO_Inactive = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RuleViewerLocal_POO_Inactive);

        TestUserModel.UserDetails userDetails_RuleViewerLocal_POO_EXT_Active = Users_API.RuleViewerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RuleViewerLocal_POO_EXT_Active);

        mySQL_cds_rules.updateLastLoginForTheUser(userDetails_Admin_National_InActive.pid,FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-91,"yyyy-MM-dd HH:mm:ss.SSS"));
        mySQL_cds_rules.updateLastLoginForTheUser(userDetails_Admin_Local_InActive.pid,FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-91,"yyyy-MM-dd HH:mm:ss.SSS"));
        mySQL_cds_rules.updateLastLoginForTheUser(userDetails_Admin_AllLocations_Active.pid,FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-89,"yyyy-MM-dd HH:mm:ss.SSS"));
        mySQL_cds_rules.updateLastLoginForTheUser(userDetails_RulesViewerNational_Inactive.pid,FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-91,"yyyy-MM-dd HH:mm:ss.SSS"));
        mySQL_cds_rules.updateLastLoginForTheUser(userDetails_RuleViewerLocal_POO_Inactive.pid,FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-91,"yyyy-MM-dd HH:mm:ss.SSS"));
        mySQL_cds_rules.updateLastLoginForTheUser(userDetails_RuleViewerLocal_POO_EXT_Active.pid,FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-89,"yyyy-MM-dd HH:mm:ss.SSS"));

        //Act
        String url = EnvDetails.url_RM_Users + "?userType=national&userRole=admin&size=20&page=0&inactive=true";
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseForInactiveNationalAdmin = getViewUserListResponseObject(url);

        url = EnvDetails.url_RM_Users + "?userType=local&userRole=ruleviewer&size=20&page=0&inactive=true";
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseForInactiveLocalRuleViewer = getViewUserListResponseObject(url);

        //Assertions for Inactive National Admin
        Assertions.assertThat(viewUserListResponseForInactiveNationalAdmin.content).extracting("inactive")
                .containsOnly(true);
        Assertions.assertThat(viewUserListResponseForInactiveNationalAdmin.content).extracting("pid")
                .contains(userDetails_Admin_National_InActive.pid);
        Assertions.assertThat(viewUserListResponseForInactiveNationalAdmin.content).extracting("pid")
                .doesNotContain(userDetails_Admin_AllLocations_Active.pid,userDetails_Admin_Local_InActive.pid);

        //Assertions for Inactive Local Ruleviewer
        Assertions.assertThat(viewUserListResponseForInactiveLocalRuleViewer.content).extracting("inactive")
                .containsOnly(true);
        Assertions.assertThat(viewUserListResponseForInactiveLocalRuleViewer.content).extracting("pid")
                .contains(userDetails_RuleViewerLocal_POO_Inactive.pid);
        Assertions.assertThat(viewUserListResponseForInactiveLocalRuleViewer.content).extracting("pid")
                .doesNotContain(userDetails_RulesViewerNational_Inactive.pid,userDetails_RuleViewerLocal_POO_EXT_Active.pid);
    }

    @Test
    @Category({ChangeRequest.CR_2680.class})
    public void WhenVerifiedForListOfInactiveUsers_ListOfUsersShouldNotHaveSuspendedAndArchivedUsers() {

        //Arrange
        TestUserModel.UserDetails userDetails_Admin_National_InActive = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_Admin_National_InActive);

        TestUserModel.UserDetails userDetails_AdminLocal_POO_Suspended= Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO_Suspended);

        TestUserModel.UserDetails userDetails_AdminLocal_POO_EXT_Archived= Users_API.AdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO_EXT_Archived);

        mySQL_cds_rules.updateLastLoginForTheUser(userDetails_Admin_National_InActive.pid,FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-91,"yyyy-MM-dd HH:mm:ss.SSS"));
        UpdateStatusOfUser(userDetails_AdminLocal_POO_Suspended.pid, TestEnumerators.MetaDataActions.USER_SUSPEND.apiAction);
        UpdateStatusOfUser(userDetails_AdminLocal_POO_EXT_Archived.pid, TestEnumerators.MetaDataActions.USER_ARCHIVE.apiAction);


        //Act
        String url = EnvDetails.url_RM_Users + "?inactive=true";
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseForInactiveUsers= getViewUserListResponseObject(url);

        //Assertions for archived and suspended users should not be shown
        Assertions.assertThat(viewUserListResponseForInactiveUsers.content).extracting("inactive")
                .containsOnly(true);
        Assertions.assertThat(viewUserListResponseForInactiveUsers.content).extracting("pid")
                .contains(userDetails_Admin_National_InActive.pid);
        Assertions.assertThat(viewUserListResponseForInactiveUsers.content).extracting("pid")
                .doesNotContain(userDetails_AdminLocal_POO_Suspended.pid,userDetails_AdminLocal_POO_EXT_Archived.pid);

    }


    @Test
    @Category({ChangeRequest.CR_2698.class})
    public void WhenRedactedUserCreated_RedactedUserVisibleInListOfUsersForSuperAdmin() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        userDetails.redacted = true;

        API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers();

        //Assert
        Assertions.assertThat(viewUserListResponseObject.content).extracting("pid")
                .contains(userDetails.pid);
    }


    @Test
    @Category({ChangeRequest.CR_2698.class})
    public void WhenRedactedUserCreated_RedactedUserVisibleInListOfUsersForAdmin() {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());

        TestUserModel.UserDetails userDetails = Users_API.RulesManagerNational();
        userDetails.redacted = true;

        API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers();

        //Assert
        Assertions.assertThat(viewUserListResponseObject.content).extracting("pid")
                .contains(userDetails.pid);
    }

    @Test
    @Category({ChangeRequest.CR_2698.class})
    public void WhenRedactedUserCreated_RedactedUserNotVisibleInListOfUsersForRulesManager() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        userDetails.redacted = true;

        API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Act
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerNational());
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers();

        //Assert
        Assertions.assertThat(viewUserListResponseObject.content).extracting("pid")
                .doesNotContain(userDetails.pid);
    }


    @Test
    @Category({ChangeRequest.CR_2698.class})
    public void WhenRedactedUserCreated_RedactedUserNotVisibleInListOfUsersForRulesViewer() {

        //Arrange
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        userDetails.redacted = true;

        API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Act
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesViewerLocal_EXT());
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers();

        //Assert
        Assertions.assertThat(viewUserListResponseObject.content).extracting("pid")
                .doesNotContain(userDetails.pid);
    }

}
