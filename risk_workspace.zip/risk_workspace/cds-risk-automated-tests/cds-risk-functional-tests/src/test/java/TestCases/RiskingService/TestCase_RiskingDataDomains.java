package TestCases.RiskingService;


import API.DataForTests.Conditions;
import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestRuleModel;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service;
import TestCases.BaseWebAPITestCase;
import junitparams.JUnitParamsRunner;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeoutException;

import static API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody;
import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
@Category(Risking_Service.class)
@RunWith(JUnitParamsRunner.class)
public class TestCase_RiskingDataDomains extends BaseWebAPITestCase {

    private static TestRuleModel.RuleDetails ruleDetails;
    private static DeclarationResponse declarationResponse;

    @Before
    public void setup() throws IOException, TimeoutException
    {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
    }


    private TestRuleModel.RuleDetails CreateCommittedRuleWithConditionAndPublish(TestRuleModel.RuleDetails.Condition condition)
    {
        ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).operator = "and";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = "1";

        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(6000);

        return ruleDetails;
    }

    private DeclarationResponse CreateDeclarationXMLSubmitAndGetResponse(TestDeclarationModel.Declaration declaration)
    {
        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        declarationResponse = new DeclarationResponse(queue.receive());

        log.info(declarationResponse.toString());

        return declarationResponse;
    }


    private void AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(TestDeclarationModel.Declaration declaration){

        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).hasSize(1)
                .contains(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains("/declaration");
    }

    private void AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(TestDeclarationModel.Declaration declaration){

        List<String> returnedControlType = declarationResponse.getControlTypeList();
        assertThat(returnedControlType).hasSize(1)
                .contains(declaration.controlTypeExpectedValue);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }


    //--------------------------------------------
    //Data Domain Country
    //--------------------------------------------

    @Test
    @Category({ChangeRequest.CR_1487.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainCountryMatchingAtHeaderLevelDispatchCountry_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.country());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_1487.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainCountryMatchingAtHeaderLevelDestinationCountry_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.country());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.destinationCountry_Header = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_1487.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainCountryMatchingAtItemLevelDispatchCountry_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.country());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry_Item = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "1";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_1487.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainCountryMatchingAtItemLevelCountryOfOrigin_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.country());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.originCountry_Item = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "2";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_1487.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainCountryMatchingAtItemLevelDestinationCountry_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.country());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.destinationCountry_Item= ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "3";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest. CRX_140.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainCountryMatchingAtItemLevelCountryRoute_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.country());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.countryRoute = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


    //--------------------------------------------
    //Data Domain EORI
    //--------------------------------------------

    @Test
    @Category({ChangeRequest.CR_1815.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainEoriMatchingAtHeaderLevelConsigneeEori_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.eori());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeEori = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }

    @Test
    @Category({ChangeRequest.CR_1815.class})
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainEoriMatchingAtHeaderLevelConsignorEori_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.eori());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consignorEori_Header = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }

    @Ignore("Notified Party EORI is currently not handled by DMS and field does not exist - Confirmed not supported at present in DMS 11/09/2017")
    @Test
    @Category({ChangeRequest.CR_1815.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainEoriMatchingAtHeaderLevelNotifiedPartyEori_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.eori());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        //declaration.notifiedParyEori = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_1815.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainEoriMatchingAtHeaderLevelPayingAgentEori_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.eori());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.payingAgentEori = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


    @Ignore("ItemLevelConsigneeEori is currently not handled by DMS and field does not exist - Confirmed not supported at present in DMS 11/09/2017")
    @Test
    @Category({ChangeRequest.CR_1815.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainCountryMatchingAtItemLevelConsigneeEori_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.eori());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        //declaration.eori = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "1";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_1850.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainCountryMatchingAtItemLevelConsignorEori_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.eori());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.exporterConsignorId_Item = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "1";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    //--------------------------------------------
    //Data Domain Dispatch Country
    //--------------------------------------------

    @Test
    @Category({ChangeRequest.CR_1815.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainDispatchCountryMatchingAtHeaderLevelDispatchCountry_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.dispatchCountry_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_1815.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainDispatchCountryMatchingAtItemLevelDispatchCountry_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.dispatchCountry_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry_Item = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "2";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }



    //--------------------------------------------
    //Data Domain Destination Country
    //--------------------------------------------

    @Test
    @Category({ChangeRequest.CR_1850.class})    //actually 1859 but done as one ticket
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainDestinationCountryMatchingAtHeaderLevelDestinationCountry_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.destinationCountry_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.destinationCountry_Header = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_1850.class})    //actually 1859 but done as one ticket
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainDestinationCountryMatchingAtItemLevelDestinationCountry_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.destinationCountry_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.destinationCountry_Item = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "2";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    //--------------------------------------------
    //Data Domain Consignor Country
    //--------------------------------------------

    @Test
    @Category({ChangeRequest.CR_1850.class})    //actually 1863 but done as one ticket
   // @Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsignorCountryMatchingAtHeaderLevelConsignorCountry_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consignorCountry_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consignorCountry_Header = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_1850.class}) //actually 1863 but done as one ticket
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsignorCountryMatchingAtItemLevelConsignorCountry_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consignorCountry_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.exporterConsignorCountry_Item = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "2";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    //--------------------------------------------
    //Data Domain Consignor City
    //--------------------------------------------

    @Test
    @Category({ChangeRequest.CR_1850.class})    //actually 1864 but done as one ticket
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsignorCityMatchingAtHeaderLevelConsignorCity_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consignorCity_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consignorCity_Header = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_1850.class}) //actually 1864 but done as one ticket
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsignorCityMatchingAtItemLevelConsignorCity_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consignorCity_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.exporterConsignorCity_Item = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "2";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    //--------------------------------------------
    //Data Domain Consignor Name
    //--------------------------------------------

    @Test
    @Category({ChangeRequest.CR_1850.class})    //actually 1861 but done as one ticket
   /// @Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsignorNameMatchingAtHeaderLevelConsignorName_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consignorName_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consignorName_Header = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_1850.class}) //actually 1861 but done as one ticket
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsignorNameMatchingAtItemLevelConsignorName_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consignorName_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.exporterConsignorName_Item = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "2";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    //--------------------------------------------
    //Data Domain Consignor Eori
    //--------------------------------------------

    @Test
    @Category({ChangeRequest.CR_1850.class})    //actually 1858 but done as one ticket
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsignorEoriMatchingAtHeaderLevelConsignorEori_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consignorEori_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consignorEori_Header = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_1850.class}) //actually 1858 but done as one ticket
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsignorEoriMatchingAtItemLevelConsignorEori_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consignorEori_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.exporterConsignorId_Item = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "2";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    //--------------------------------------------
    //Data Domain Consignor Address
    //--------------------------------------------

    @Test
    @Category({ChangeRequest.CR_1850.class})    //actually 1857 but done as one ticket
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsignorAddressMatchingAtHeaderLevelConsignorAddress_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consignorAddress_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consignorAddress_Header = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CR_1850.class}) //actually 1857 but done as one ticket
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsignorAddressMatchingAtItemLevelConsignorAddress_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consignorAddress_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.exporterConsignorAddress_Item = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "2";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
        declaration.declarationType = "EX";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    //--------------------------------------------
    //Data Domain Consignor Postcode
    //--------------------------------------------

    @Test
    @Category({ChangeRequest. CRX_140.class})
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsignorPostCodeMatchingAtHeaderLevelConsignorPostCode_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consignorPostCode_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consignorPostcode_Header = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest. CRX_140.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsignorPostCodeMatchingAtItemLevelConsignorPostCode_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consignorPostCode_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.exporterConsignorZipCode_Item = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "2";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
        declaration.declarationType = "EX";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }




    //--------------------------------------------
    //Data Domain Consignee Address
    //--------------------------------------------

    @Test
    @Category({ChangeRequest.CRX_140.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsigneeAddressMatchingAtHeaderLevelConsigneeAddress_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consigneeAddress_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeAddress = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest. CRX_140.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsigneeAddressMatchingAtItemLevelConsigneeAddress_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consigneeAddress_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeAddress_Item = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "2";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
        declaration.declarationType = "EX";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    //--------------------------------------------
    //Data Domain Consignee Eori
    //--------------------------------------------

    @Test
    @Category({ChangeRequest.CRX_140.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsigneeEoriMatchingAtHeaderLevelConsigneeEori_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consigneeEori_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeEori = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CRX_140.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsigneeEoriMatchingAtItemLevelConsigneeEori_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consigneeEori_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeEori_Item = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "2";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    //--------------------------------------------
    //Data Domain Consignee Name
    //--------------------------------------------

    @Test
    @Category({ChangeRequest.CRX_140.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsigneeNameMatchingAtHeaderLevelConsigneeName_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consigneeName_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeName = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CRX_140.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsigneeNameMatchingAtItemLevelConsigneeName_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consigneeName_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeName_Item = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "2";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    //--------------------------------------------
    //Data Domain Consignee City
    //--------------------------------------------

    @Test
    @Category({ChangeRequest.CRX_140.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsigneeCityMatchingAtHeaderLevelConsigneeCity_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consigneeCity_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeCity = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CRX_140.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsigneeCityMatchingAtItemLevelConsigneeCity_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consigneeCity_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeCity_Item = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "2";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    //--------------------------------------------
    //Data Domain Consignee Country
    //--------------------------------------------

    @Test
    @Category({ChangeRequest.CRX_140.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsigneeCountryMatchingAtHeaderLevelConsigneeCountry_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consigneeCountry_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeCountry = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest.CRX_140.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsigneeCountryMatchingAtItemLevelConsigneeCountry_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consigneeCountry_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneeCountry_Item = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "2";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }

    //--------------------------------------------
    //Data Domain Consignee PostCode
    //--------------------------------------------

    @Test
    @Category({ChangeRequest. CRX_140.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsigneePostCodeMatchingAtHeaderLevelConsigneePostCode_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consigneePostCode_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneePostcode = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


    @Test
    @Category({ChangeRequest. CRX_140.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainConsigneePostCodeMatchingAtItemLevelConsigneePostCode_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.consigneePostCode_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.consigneePostcode_Item = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "2";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
        declaration.declarationType = "EX";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtItemLevelForControlTypeAndReportBackElement(declaration);
    }


    //--------------------------------------------
    //Data Domain Transport Charge MOP
    //--------------------------------------------

    @Test
    @Category({ChangeRequest. CRX_140.class})
    public void WhenDeclarationSubmittedForMatchingRuleWithDomainTransportChargeMOPMatchingAtHeaderLevelTransportMOP_RouteReturned() throws Throwable {

        //Arrange
        ruleDetails = CreateCommittedRuleWithConditionAndPublish(Conditions.transportChargeMop_domain());

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.transportMOP = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declarationResponse = CreateDeclarationXMLSubmitAndGetResponse(declaration);

        //Assert
        AssertDeclarationResponseMatchAtHeaderLevelForControlTypeAndReportBackElement(declaration);
    }


}
