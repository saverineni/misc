package TestCases.RiskingServiceJava.NarrativeResponse;

import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.Risking_JavaService;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.Matcher;
import uk.gov.hmrc.risk.test.common.enums.MatcherType;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.Condition;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.MatcherClass;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.Source;

import java.util.Arrays;

import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.conditions;

@Slf4j
@Category({ChangeRequest_RiskingService.CREP_378.class, ChangeRequest_RiskingService.CREP_382.class,
        Risking_JavaService.class})
public class TestCase_PatternMatchingOperatorsNarratives extends BaseNarrativeTest {

    @Test
   // @Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithContainsOperatorIsHit_CorrectNarrativeIsPresent() {

        Condition consignorNameHeader = consignorNameHeader();
        consignorNameHeader.setMatcher(Matcher.containsString);
        consignorNameHeader.setMatcherType(MatcherType.CONTAINS);
        consignorNameHeader.setDeclarationValue("My name is ConsignorName, nice to meet you");

        createRule(Source.declaration, conditions( consignorNameHeader ), Arrays.asList() );

        DeclarationResponse response = createAndSendDeclaration( conditions( consignorNameHeader));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).contains(
                expectedReason(
                        consignorNameHeader, "", "Consignor Name", "contains", consignorNameHeader.value,
                        "'"+consignorNameHeader.declarationValue+"'")
        );
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithNotContainsOperatorIsHit_CorrectNarrativeIsPresent() {

        Condition consignorNameHeader = consignorNameHeader();
        consignorNameHeader.setPositive(false);
        consignorNameHeader.setMatcher(Matcher.containsString);
        consignorNameHeader.setMatcherType(MatcherType.CONTAINS);
        consignorNameHeader.setDeclarationValue("My name is SomeStrangeName, nice to meet you");

        createRule(Source.declaration, conditions( consignorNameHeader ), Arrays.asList() );

        DeclarationResponse response = createAndSendDeclaration( conditions( consignorNameHeader));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).contains(
                expectedReason(
                        consignorNameHeader, "", "Consignor Name", "did not contain", consignorNameHeader.value,
                        "'"+consignorNameHeader.declarationValue+"'")
        );
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithStartsWithOperatorIsHit_CorrectNarrativeIsPresent() {

        Condition consignorNameHeader = consignorNameHeader();
        consignorNameHeader.setMatcher(Matcher.startsWith);
        consignorNameHeader.setMatcherType(MatcherType.STARTS_WITH);
        consignorNameHeader.setDeclarationValue("ConsignorName, nice to meet you");

        createRule(Source.declaration, conditions( consignorNameHeader ), Arrays.asList() );

        DeclarationResponse response = createAndSendDeclaration( conditions( consignorNameHeader));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).contains(
                expectedReason(
                        consignorNameHeader, "", "Consignor Name", "starts with", consignorNameHeader.value,
                        "'"+consignorNameHeader.declarationValue+"'")
        );
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithNotStartsWithOperatorIsHit_CorrectNarrativeIsPresent() {

        Condition consignorNameHeader = consignorNameHeader();
        consignorNameHeader.setPositive(false);
        consignorNameHeader.setMatcher(Matcher.startsWith);
        consignorNameHeader.setMatcherType(MatcherType.STARTS_WITH);
        consignorNameHeader.setDeclarationValue("StrangeName, nice to meet you");

        createRule(Source.declaration, conditions( consignorNameHeader ), Arrays.asList() );

        DeclarationResponse response = createAndSendDeclaration( conditions( consignorNameHeader));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).contains(
                expectedReason(
                        consignorNameHeader, "", "Consignor Name", "did not start with", consignorNameHeader.value,
                        "'"+consignorNameHeader.declarationValue+"'")
        );
    }

    @Test
   // @Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithMatchingPatternOperatorIsHit_CorrectNarrativeIsPresent() {
        Condition consignorNameHeader = consignorNameHeader();
        consignorNameHeader.setValue("C?nsignorName");
        consignorNameHeader.setMatcherClass(MatcherClass.CdsRiskMatchers);
        consignorNameHeader.setMatcher(Matcher.matchesPattern);
        consignorNameHeader.setMatcherType(MatcherType.MATCHES_PATTERN);
        consignorNameHeader.setDeclarationValue("ConsignorName");

        createRule(Source.declaration, conditions( consignorNameHeader ), Arrays.asList() );

        DeclarationResponse response = createAndSendDeclaration( conditions( consignorNameHeader));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).contains(
                expectedReason(
                        consignorNameHeader, "", "Consignor Name", "matches", consignorNameHeader.value,
                        "'"+consignorNameHeader.declarationValue+"'")
        );
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRuleWithNotMatchingPatternOperatorIsHit_CorrectNarrativeIsPresent() {
        Condition consignorNameHeader = consignorNameHeader();
        consignorNameHeader.setValue("C?nsignorName");
        consignorNameHeader.setPositive(false);
        consignorNameHeader.setMatcherClass(MatcherClass.CdsRiskMatchers);
        consignorNameHeader.setMatcher(Matcher.matchesPattern);
        consignorNameHeader.setMatcherType(MatcherType.MATCHES_PATTERN);
        consignorNameHeader.setDeclarationValue("StrangeName");

        createRule(Source.declaration, conditions( consignorNameHeader ), Arrays.asList() );

        DeclarationResponse response = createAndSendDeclaration( conditions( consignorNameHeader));

        Assertions.assertThat(response.getMatchReasons()).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).hasSize(1);
        Assertions.assertThat(response.getMatchReasons().get(0)).contains(
                expectedReason(
                        consignorNameHeader, "", "Consignor Name", "did not match", consignorNameHeader.value,
                        "'"+consignorNameHeader.declarationValue+"'")
        );
    }
}
