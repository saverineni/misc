package TestCases.UI.Permissions;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Permissions;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.MenuToolBar;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static org.junit.Assert.assertTrue;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Permissions.class})
public class TestCase_LoggedOutUser extends BaseUIWebDriverTestCase{

    @Test
    public void WhenLocalAdminLoggedIn_CorrectToolBarMenusDisplayed() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        //Act
        utilUsers.Logout(driver);

        MenuToolBar menuToolBar = new MenuToolBar(driver);

        //Assert
        assertTrue("Expect dashboardIcon to be NOT displayed", menuToolBar.isElementDisplayed(menuToolBar.dashboardIcon,1,false) == false);
        assertTrue("Expect rulesManagement to be NOT displayed", menuToolBar.isElementDisplayed(menuToolBar.rulesManagement,1,false) == false);
        assertTrue("Expect dataManagement to be NOT displayed", menuToolBar.isElementDisplayed(menuToolBar.dataManagement,1,false) == false);
        assertTrue("Expect logout to be NOT displayed", menuToolBar.isElementDisplayed(menuToolBar.logout,1,false) == false);
        assertTrue("Expect users to be NOT displayed", menuToolBar.isElementDisplayed(menuToolBar.users,1,false) == false);
        assertTrue("Expect publish to be NOT displayed", menuToolBar.isElementDisplayed(menuToolBar.publish,1,false) == false);
    }

}
