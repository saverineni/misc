package TestCases.RulesManagementService;


import API.DataForTests.Locations;
import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.EditRule.EditRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.ViewRule.ViewRuleResponse;
import Categories_CDSRisk.CDS_RM_RuleLifeCycle;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import FunctionsLibrary.FileUtilities;
import TestCases.BaseWebAPITestCase;
import org.apache.http.HttpStatus;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.DeclarationSubType;
import uk.gov.hmrc.risk.test.common.enums.DeclarationType;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import static org.junit.Assert.assertEquals;


@Category({Rules_Management.class, CDS_RM_RuleLifeCycle.class})
public class TestCase_CommitRule extends BaseWebAPITestCase {

    @Test
    @Category({ChangeRequest.CR_281.class, ChangeRequest.CR_380.class,ChangeRequest.CR_3100.class})
    public void WhenDraftRuleCommitted_CommittedRuleCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);
        ViewRuleResponse.ViewRuleResponseObject ruleResponseAfterPublish = API.RulesManagementService.Utils.Rules.GetRuleByUID(commitResponse.uniqueId);


        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
        assertEquals(createRuleResponse.ruleId, commitResponse.ruleId);
        //Assertion for upcoming changes
        assertEquals(1, ruleResponseAfterPublish.upcoming.get(0).versionId);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), ruleResponseAfterPublish.upcoming.get(0).status);


    }

    @Test
    @Category({ChangeRequest.CR_281.class})
    public void WhenUpdatedDraftRuleCommitted_LiveCommittedRuleCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        EditRuleResponse.PutResponse  draftRuleVersion2Rule = API.RulesManagementService.Utils.RuleAtStatus.CreateDraftRuleVersion2Rule();
        ruleDetails.uniqueID = draftRuleVersion2Rule.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
    }


    @Test
    @Category({ChangeRequest.CR_281.class})
    public void AttemptToCommitPreviousVersion_PreviousVersionNotCommitted() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        EditRuleResponse.PutResponse  draftRuleVersion2Rule = API.RulesManagementService.Utils.RuleAtStatus.CreateDraftRuleVersion2Rule();
        ruleDetails.uniqueID = draftRuleVersion2Rule.uniqueId;

        //Act
        ruleDetails.version = 1;
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_281.class})
    public void AttemptToCommitRuleWithInvalidID_NotFoundResponseReceived() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ruleDetails.uniqueID = "3b3f816b-146e-11e7-bbc6-0242ac110dbb";
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_NOT_FOUND, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_281.class})
    public void AttemptToCommitRuleWithInvalidVersion_NotFoundResponseReceived() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        ruleDetails.version = 9;
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_NOT_FOUND, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_281.class})
    public void AttemptToCommitRuleWithNoOperator_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).operator = "";
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_281.class})
    public void AttemptToCommitRuleWithNoAttribute_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "";
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_281.class})
    public void AttemptToCommitRuleWithNoValue_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).value = "";
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_281.class})
    public void AttemptToCommitRuleWithNoDescription_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.description = "";
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_281.class})
    public void AttemptToCommitRuleWithIncorrectAttribute_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = "dispatchCountryzzz";
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_281.class})
    public void AttemptToCommitRuleWithLongerValueThanAllowed_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        String sConsigneeAttributeValue = FunctionsLibrary.FileUtilities.GenerateRandomAlphaNumericString(257, true, true);

        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = sConsigneeAttributeValue;
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_281.class})
    public void AttemptToCommitRuleWithInvalidCharacter_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        char[] charsToUse = new char[] { '!', '£', '%', '^', '&', '*', '(' , ')'};
        String sConsigneeAttributeValue = FileUtilities.GenerateRandomSpecialCharString(10, charsToUse);
        sConsigneeAttributeValue = sConsigneeAttributeValue.replace("$", "\\\\$"); //need to character escape $ character

        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = sConsigneeAttributeValue;
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_281.class})
    public void AttemptToCommitLiveRule_LiveRuleAlreadyCommitted() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.BlankDraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse committedRule = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();
        ruleDetails.uniqueID = committedRule.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_586.class)
    public void WhenNationalRuleManagerCommitsLocalRule_StatusSetToCommitted() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLOCRuleNatManager();
        ruleDetails.locations.add(Locations.Location_ABZ_UID);
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
    }


    @Test
    @Category(ChangeRequest.CR_624.class)
    public void WhenLocalRulesManagerCommitsLocalRule_StatusSetToCommitted() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
    }


    @Test
    @Category({ChangeRequest.CR_1134.class})
    public void AttemptToCommitRuleWithNoDeclarationType_CommittedRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryOptions.declarationType = "";
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_1134.class})
    public void AttemptToCommitRuleWithNoDeclarationSubType_CommittedRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryOptions.declarationSubTypes .add( "");
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }

    @Test
    @Category({ChangeRequest.CR_1216.class})
    public void AttemptToCommitRuleWithNoTransportMode_CommittedRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryOptions.transportMode = null;
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }

    @Test
    @Category({ChangeRequest.CR_1104.class})
    public void WhenDraftImportRuleWithTypeSupplementaryCommitted_CommittedRuleCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryOptions.declarationType = DeclarationType.IM.toString();
        ruleDetails.queryOptions.declarationSubTypes .add(DeclarationSubType.E.toString());

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
    }

    @Test
    @Category({ChangeRequest.CR_1104.class})
    public void WhenDraftExportRuleWithTypeSupplementaryCommitted_CommittedRuleCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryOptions.declarationType = DeclarationType.EX.toString();

        ruleDetails.queryOptions.declarationSubTypes.add(DeclarationSubType.E.toString());

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
    }


    @Test
    @Category({ChangeRequest.CR_1636.class})
    public void AttemptToCommitRatRuleWithNoThreshold_CommittedRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleWithRatsNatManager();
        ruleDetails.ratDefinition.hitRate.limit = null;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_1636.class})
    public void WhenDraftRatRuleCommitted_CommittedRuleCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleWithRatsNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
        assertEquals(createRuleResponse.ruleId, commitResponse.ruleId);
    }


    @Test
    @Category({ChangeRequest.CR_1217.class})
    public void AttemptToCommitRuleWithNoRuleOutput_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = null;
        ruleDetails.ruleOutputs.holdNarrative = null;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_1695.class})
    public void AttemptToCommitRuleWithNoRuleOutputActionType_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = null;
        ruleDetails.ruleOutputs.holdNarrative = "hold narrative text";

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_1695.class})
    public void AttemptToCommitRuleWithNoRuleOutputHoldNarrativeForActionType1_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.PHYSICAL_CHECK.actionType;
        ruleDetails.ruleOutputs.holdNarrative = null;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_1695.class})
    public void AttemptToCommitRuleWithNoRuleOutputHoldNarrativeForActionType2_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_HOLD_GOODS.actionType;
        ruleDetails.ruleOutputs.holdNarrative = null;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_1711.class})
    public void AttemptToCommitRuleWithNoRuleOutputReleaseNarrativeForActionType3_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.releaseNarrative = null;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_1711.class})
    public void AttemptToCommitRuleWithNoRuleOutputHoldNarrativeForActionType4_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_VARY_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.holdNarrative = null;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_1711.class})
    public void AttemptToCommitRuleWithNoRuleOutputReleaseNarrativeForActionType4_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_VARY_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.releaseNarrative = null;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_1711.class})
    public void AttemptToCommitRuleWithNoHoldPercentageForActionType4_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_VARY_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.releaseNarrative = "Release Narrative";
        ruleDetails.ruleOutputs.holdPercentage = null;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_1711.class})
    public void AttemptToCommitRuleWithNoReleasePercentageForActionType4_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_VARY_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.releaseNarrative = "Release Narrative";
        ruleDetails.ruleOutputs.holdPercentage = 90;
        ruleDetails.ruleOutputs.releasePercentage = null;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_1711.class})
    public void AttemptToCommitRuleWithTotalPercentageLessThan100ForActionType4_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_VARY_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.releaseNarrative = "Release Narrative";
        ruleDetails.ruleOutputs.holdPercentage = 98;
        ruleDetails.ruleOutputs.releasePercentage = 1;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }

    @Test
    @Category({ChangeRequest.CR_1711.class})
    public void AttemptToCommitRuleWithTotalPercentageGreaterThan100ForActionType4_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_VARY_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.releaseNarrative = "Release Narrative";
        ruleDetails.ruleOutputs.holdPercentage = 90;
        ruleDetails.ruleOutputs.releasePercentage = 11;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_2742.class})
    public void AttemptToCommitRuleWithoutAssigneeForInformationTask_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.PHYSICAL_CHECK.actionType;
        ruleDetails.ruleOutputs.standaloneInfoNarrative = "standalone info narrative";
        ruleDetails.ruleOutputs.informationNarrativeAssignee = "test@user.x.gsi.gov.uk";
        ruleDetails.ruleOutputs.assigneeID = null;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_1695.class})
    public void WhenRuleWithHoldNarrativeForActionType2Committed_LiveRuleCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_HOLD_GOODS.actionType;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
    }

    @Test
    @Category({ChangeRequest.CR_1711.class})
    public void WhenRuleWithReleaseNarrativeForActionType3Committed_LiveRuleCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.holdNarrative = null;
        ruleDetails.ruleOutputs.releaseNarrative = "Release Narrative";
        ruleDetails.ruleOutputs.holdPercentage = null;
        ruleDetails.ruleOutputs.releasePercentage = null;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_1711.class})
    public void WhenRuleWithHoldAndReleaseNarrativeForActionType4Committed_LiveRuleCreated() throws Throwable
    {
        //Document Check And Vary Release Of Goods

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_VARY_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.holdNarrative = "Hold Narrative";
        ruleDetails.ruleOutputs.releaseNarrative = "Release Narrative";
        ruleDetails.ruleOutputs.holdPercentage = 40;
        ruleDetails.ruleOutputs.releasePercentage = 60;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
    }


    @Ignore("Confirmed with Sarah: Moved to CR-1817")
    @Test
    @Category({ChangeRequest.CR_1711.class})
    public void WhenRuleWithNoRuleOutputHoldNarrativeForActionType4Committed_LiveRuleCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_VARY_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.holdNarrative = null;
        ruleDetails.ruleOutputs.releaseNarrative = "Release Narrative";
        ruleDetails.ruleOutputs.holdPercentage = 0;
        ruleDetails.ruleOutputs.releasePercentage = 100;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
    }


    @Ignore("Confirmed with Sarah: Moved to CR-1817")
    @Test
    @Category({ChangeRequest.CR_1711.class})
    public void WhenRuleWithNoRuleOutputReleaseNarrativeForActionType4Committed_LiveRuleCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_VARY_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.releaseNarrative = null;
        ruleDetails.ruleOutputs.holdPercentage = 100;
        ruleDetails.ruleOutputs.releasePercentage = 0;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
    }

    @Test
    @Category({ChangeRequest.CR_2741.class})
    public void WhenRuleWithStandaloneInfoNarrativeForActionType5Committed_LiveRuleCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.INFORMATION_TASK.actionType;
        ruleDetails.ruleOutputs.standaloneInfoNarrative = "Standalone Info Narrative";
        ruleDetails.ruleOutputs.informationNarrativeAssignee = "test@user.gsi.gov.uk";
        ruleDetails.ruleOutputs.assigneeID = "TEAM01";

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
    }

    @Test
    @Category({ChangeRequest.CR_2742.class, ChangeRequest.CR_3061.class})
    public void WhenRuleWithInformationTask_LiveRuleCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.holdNarrative=null;
        ruleDetails.ruleOutputs.holdPercentage=null;
        ruleDetails.ruleOutputs.releaseNarrative="Release narrative";
        ruleDetails.ruleOutputs.standaloneInfoNarrative = "Standalone Info Narrative";
        ruleDetails.ruleOutputs.informationNarrativeAssignee = "test@user.gsi.gov.uk";
        ruleDetails.ruleOutputs.assigneeID = "TEAM01";

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
    }

    @Test
    @Category({ChangeRequest.CR_3061.class})
    public void WhenRuleWithInformationTaskAndInvalidEmailAddress_LiveRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.holdNarrative=null;
        ruleDetails.ruleOutputs.holdPercentage=null;
        ruleDetails.ruleOutputs.releaseNarrative="Release narrative";
        ruleDetails.ruleOutputs.standaloneInfoNarrative = "Standalone Info Narrative";
        ruleDetails.ruleOutputs.informationNarrativeAssignee = "testdigital.hmrc.gov.uk";
        ruleDetails.ruleOutputs.assigneeID = "TEAM01";

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_2740.class})
    public void WhenRuleWithRuleOutPutSecretTaskCommitted_CommittedRuleCreated()
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.secretTask = true;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
    }

    @Test
    @Category({ChangeRequest.CR_2739.class})
    public void WhenRuleWithRuleOutPutTimeToCloseCommitted_CommittedRuleCreated()
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.secretTask = false;
        ruleDetails.ruleOutputs.timeToClose=600;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;
        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);
        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
    }

     @Test
    @Category({ChangeRequest.CR_1866.class})
    public void WhenRuleWithDeclarationTypeBothAndNoDeclarationSubTypeCommitted_ActiveRuleCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryOptions.declarationType = UI.DataForTests.TestRuleModel.RuleDetails.DeclarationType.BOTH.value;
        ruleDetails.queryOptions.declarationSubTypes = null;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //AssertF
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
        assertEquals(createRuleResponse.ruleId, commitResponse.ruleId);
    }


    @Test
    @Category({ChangeRequest.CR_1880.class})
    public void AttemptToCommitRuleWithNoReason_CommittedRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        ruleDetails.reason = "";
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_1880.class})
    public void AttemptToCommitRuleWithReasonBelowMinChars_CommittedRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        ruleDetails.reason = "test";  //5 chars minimum
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_1880.class})
    public void AttemptToCommitRuleWithReasonAboveMaxChars_CommittedRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        ruleDetails.reason = FileUtilities.GenerateRandomAlphaNumericString(61, true, true);
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }

    @Test
    @Category({ChangeRequest.CR_1880.class})
    public void WhenRuleWithReasonValidLength_CommittedRuleCommitted() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        ruleDetails.reason = FileUtilities.GenerateRandomAlphaNumericString(60, true, true);
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_2741.class})
    public void AttemptToCommitRuleWithStandaloneTaskAndNoInformationNarrative_CommittedRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.INFORMATION_TASK.actionType;
        ruleDetails.ruleOutputs.assigneeID = "TEAM 01";
        ruleDetails.ruleOutputs.standaloneInfoNarrative = null;

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        ruleDetails.reason = "";
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_2741.class})
    public void AttemptToCommitRuleWithStandaloneTaskAndNoAssigneeID_CommittedRuleNotCreated() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.INFORMATION_TASK.actionType;
        ruleDetails.ruleOutputs.assigneeID = null;
        ruleDetails.ruleOutputs.standaloneInfoNarrative = "standalone narrative";
        ruleDetails.ruleOutputs.informationNarrativeAssignee = "test@user.x.gsi.gov.uk";

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        ruleDetails.reason = "";
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }



}
