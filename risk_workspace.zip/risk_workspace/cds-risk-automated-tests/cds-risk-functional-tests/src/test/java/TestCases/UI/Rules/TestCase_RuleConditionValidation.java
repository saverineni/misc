package TestCases.UI.Rules;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Rules;
import Categories_CDSRisk.CDS_Risk_UI_Rules_2;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.DataForTests.TestRuleModel;
import UI.Pages.RulesManagement.CreateNationalRule_Page;
import UI.Utils.Navigation;
import org.assertj.core.util.Lists;
import org.junit.Assert;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static UI.DataForTests.TestRuleModel.RuleDetails.Condition.Attribute.*;
import static UI.DataForTests.TestRuleModel.RuleDetails.Condition.AttributeType.*;
import static org.assertj.core.api.Assertions.assertThat;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_2.class})
public class TestCase_RuleConditionValidation extends BaseUIWebDriverTestCase {

    @Test
    @Category(ChangeRequest.CR_2694.class)
    public void WhenConditionWithNumericValueEntered_ThenFieldIsValidated() {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftNATRule();

        List<TestRuleModel.RuleDetails.ConditionGroup> conditionGroupItemCountHeader =
                createConditions(HEADER, ITEM_COUNT_HEADER, "Greater Than", "123456789098", false);

        ruleDetails.conditionGroups = conditionGroupItemCountHeader;

        assertRuleConditionValidation(ruleDetails, "12345");

        List<TestRuleModel.RuleDetails.ConditionGroup> conditionGroupCommodityCodeItem =
                createConditions(ITEM, COMMODITY_CODE, "Equal", "1234567890000", false);

        // check another numeric field:
        ruleDetails.conditionGroups = conditionGroupCommodityCodeItem;

        assertRuleConditionValidation(ruleDetails, "1234567890");
    }

    @Test
    @Category({ChangeRequest.CR_3086.class, ChangeRequest.CR_3121.class})
    public void WhenConditionWithAlphaNumericValueIsEntered_ThenFieldIsValidated() {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftNATRule();

        CreateNationalRule_Page createNationalRule_page = new CreateNationalRule_Page(driver);

        List<TestRuleModel.RuleDetails.ConditionGroup> conditionGroupItemCountHeader =
                createConditions(HEADER, FREIGHT_CHARGE, "Equal", "ABCD", false);

        ruleDetails.conditionGroups = conditionGroupItemCountHeader;

        assertRuleConditionValidation(ruleDetails, "ABCD");

        String errorMessage = createNationalRule_page.getErrorMessage();

        Assert.assertEquals("16 digits total, with a maximum of 3 decimal places.",errorMessage);

        List<TestRuleModel.RuleDetails.ConditionGroup> conditionConsigneeAddressHeader =
                createConditions(HEADER, CONSIGNEE_ADDRESS, "Not Equal", "AS@", false);

        ruleDetails.conditionGroups = conditionConsigneeAddressHeader;

        assertRuleConditionValidation(ruleDetails, "AS@");

        String errorMessage1 = createNationalRule_page.getErrorMessage();

        Assert.assertEquals("1 to 70 alphanumeric characters or spaces.",errorMessage1);

        List<TestRuleModel.RuleDetails.ConditionGroup> conditionInvoiceCurrencyHeader =
                createConditions(HEADER, INVOICE_CURRENCY, "Matches Pattern", "£", false);

        ruleDetails.conditionGroups = conditionInvoiceCurrencyHeader;

        assertRuleConditionValidation(ruleDetails, "£");

        String errorMessage2 = createNationalRule_page.getErrorMessage();

        Assert.assertEquals("1 to 3 uppercase letters or special characters.",errorMessage2);

        List<TestRuleModel.RuleDetails.ConditionGroup> conditionTransportChargeMopDomain =
                createConditions(DOMAIN, TRANSPORT_CHARGE_MOP, "Not Equal", "£", false);

        ruleDetails.conditionGroups = conditionTransportChargeMopDomain;

        assertRuleConditionValidation(ruleDetails, "£");

        String errorMessage3 = createNationalRule_page.getErrorMessage();

        Assert.assertEquals("Exactly 1 uppercase letters.",errorMessage3);

        List<TestRuleModel.RuleDetails.ConditionGroup> conditionAdditionalInfoCodeHeaderCollection =
                createConditions(HEADER_COLLECTION, ADDITIONAL_INFO_CODE_HEADER_COLLECTION, "Not Matches Pattern", ".", false);

        ruleDetails.conditionGroups = conditionAdditionalInfoCodeHeaderCollection;

        assertRuleConditionValidation(ruleDetails, ".");

        String errorMessage4 = createNationalRule_page.getErrorMessage();

        Assert.assertEquals("1 to 17 alphanumeric characters or special characters.",errorMessage4);

        List<TestRuleModel.RuleDetails.ConditionGroup> conditionBaseQuantityItemCollection =
                createConditions(ITEM_COLLECTION, BASE_QUANTITY_ITEM_COLLECTION, "Greater Than", "12789699969698696", false);

        ruleDetails.conditionGroups = conditionBaseQuantityItemCollection;

        assertRuleConditionValidation(ruleDetails, "12789699969698696");

        String errorMessage5 = createNationalRule_page.getErrorMessage();

        Assert.assertEquals("16 digits total, with a maximum of 6 decimal places.",errorMessage5);
    }

    private void assertRuleConditionValidation(UI.DataForTests.TestRuleModel.RuleDetails ruleDetails, String expectedConditionValue){
        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateNationalRule_Page createNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateNationalRule);

        // Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalRuleSingleCondition(ruleDetails);

        //Assert
        UI.ElementControls.InputField conditionValueField = new UI.ElementControls.InputField(driver);
        String actualValue = conditionValueField.getValue(ruleUtils.getCreateRuleBase_page().conditionValue);

        assertThat(actualValue).isEqualTo(expectedConditionValue);
    }

    private List<TestRuleModel.RuleDetails.ConditionGroup> createConditions (
            TestRuleModel.RuleDetails.Condition.AttributeType attributeType,
            TestRuleModel.RuleDetails.Condition.Attribute attribute,
            String operator,
            String value,
            boolean isDataTableCondition){
        List<TestRuleModel.RuleDetails.ConditionGroup> conditionGroups = Lists.newArrayList();
        TestRuleModel.RuleDetails.ConditionGroup conditionGroup = new TestRuleModel.RuleDetails.ConditionGroup();
        List<TestRuleModel.RuleDetails.Condition> conditions = Lists.newArrayList();
        TestRuleModel.RuleDetails.Condition condition = new TestRuleModel.RuleDetails.Condition();
        condition.isDataTable = isDataTableCondition;
        condition.attributeType = attributeType;
        condition.attribute = attribute;
        condition.operator = operator;
        condition.value = value;

        conditions.add(condition);

        conditionGroup.conditions = conditions;
        conditionGroups.add(conditionGroup);

        return conditionGroups;

    }
}
