package TestCases.UI.Rules;


import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Rules;
import Categories_CDSRisk.CDS_Risk_UI_Rules_2;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.DataForTests.Conditions;
import UI.DataForTests.TestRuleModel;
import UI.Pages.RulesManagement.CreateLocalRule_Page;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Utils.Navigation;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static UI.DataForTests.TestRuleModel.RuleDetails.Condition.AttributeType.HEADER;
import static UI.DataForTests.TestRuleModel.RuleDetails.Condition.AttributeType.ITEM;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_2.class})
public class TestCase_OperatorConditionRule extends BaseUIWebDriverTestCase{


    @Test
    @Category({ChangeRequest.CR_1213.class})
    public void WhenManagerLoggedIn_CanCreateRuleWithOperatorContains(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();

        ruleDetails.conditionGroups.get(0).conditions.remove(0);
        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.commodityCode());
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = ITEM;
        ruleDetails.conditionGroups.get(0).conditions.get(0).operator = "Equal";
        ruleDetails.conditionGroups.get(0).conditions.get(0).value = "11005AA899";

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }


    @Test
    @Category({ChangeRequest.CR_1213.class})
    public void WhenManagerLoggedIn_CanCreateRuleWithOperatorNotContains(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();

        ruleDetails.conditionGroups.get(0).conditions.remove(0);
        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.consigneeName());
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = HEADER;
        ruleDetails.conditionGroups.get(0).conditions.get(0).operator = "Not Contains";
        ruleDetails.conditionGroups.get(0).conditions.get(0).value = "0101";

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }

    @Test
    @Category({ChangeRequest.CR_1481.class})
    public void WhenManagerLoggedIn_CanCreateRuleWithOperatorStartsWith(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();

        ruleDetails.conditionGroups.get(0).conditions.remove(0);
        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.commodityCode());
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = ITEM;
        ruleDetails.conditionGroups.get(0).conditions.get(0).operator = "Starts With";
        ruleDetails.conditionGroups.get(0).conditions.get(0).value = "1";

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }


    @Test
    @Category({ChangeRequest.CR_1481.class})
    public void WhenManagerLoggedIn_CanCreateRuleWithOperatorNotStartsWith(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();

        ruleDetails.conditionGroups.get(0).conditions.remove(0);
        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.consigneeName());
        ruleDetails.conditionGroups.get(0).conditions.get(0).operator = "Not Starts With";
        ruleDetails.conditionGroups.get(0).conditions.get(0).value = "Z";
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = TestRuleModel.RuleDetails.Condition.AttributeType.HEADER;

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }


    @Test
    @Category({ChangeRequest.CR_1605.class})
    public void WhenManagerLoggedIn_CanCreateRuleWithOperatorMatchesPattern(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();

        ruleDetails.conditionGroups.get(0).conditions.clear();
        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.consigneeName());
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = HEADER;
        ruleDetails.conditionGroups.get(0).conditions.get(0).operator = "Matches Pattern";
        ruleDetails.conditionGroups.get(0).conditions.get(0).value = "R?binsons";

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }


    @Test
    @Category({ChangeRequest.CR_1605.class})
    public void WhenManagerLoggedIn_CanCreateRuleWithOperatorNOTMatchesPattern(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();

        ruleDetails.conditionGroups.get(0).conditions.clear();
        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.consigneeName());
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = HEADER;
        ruleDetails.conditionGroups.get(0).conditions.get(0).operator = "Not Matches Pattern";
        ruleDetails.conditionGroups.get(0).conditions.get(0).value = "R*";

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }

    @Test
    @Category({ChangeRequest.CR_1624.class})
    public void WhenManagerLoggedIn_CanCreateRuleWithOperatorLessThan(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();

        ruleDetails.conditionGroups.get(0).conditions.clear();
        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.netMass());
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = ITEM;

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }

    @Test
    @Category({ChangeRequest.CR_1624.class})
    public void WhenManagerLoggedIn_CanCreateRuleWithOperatorGreaterThanOrEqualTo(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();

        ruleDetails.conditionGroups.get(0).conditions.clear();
        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.netMass());
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = ITEM;
        ruleDetails.conditionGroups.get(0).conditions.get(0).operator = "Greater Than Or Equal To";


        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }

    @Test
    @Category({ChangeRequest.CR_1625.class})
    public void WhenManagerLoggedIn_CanCreateRuleWithOperatorGreaterThan(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();

        ruleDetails.conditionGroups.get(0).conditions.clear();
        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.netMass());
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = ITEM;
        ruleDetails.conditionGroups.get(0).conditions.get(0).operator = "Greater Than";

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }


    @Test
    @Category({ChangeRequest.CR_1625.class})
    public void WhenManagerLoggedIn_CanCreateRuleWithOperatorLessThanOrEqualTo(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();

        ruleDetails.conditionGroups.get(0).conditions.clear();
        ruleDetails.conditionGroups.get(0).conditions.add(Conditions.netMass());
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = ITEM;
        ruleDetails.conditionGroups.get(0).conditions.get(0).operator = "Less Than Or Equal To";

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }

}
