package TestCases.RulesManagementService;


import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.EditRule.EditRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.Utils.RuleAtStatus;
import API.RulesManagementService.ViewRule.ViewRuleResponse;
import API.RulesManagementService.ViewRuleList.ViewRuleListResponse;
import API.RulesManagementService.ViewRuleVersion.ViewRuleVersionResponse;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Slow_Tests;
import FunctionsLibrary.DateTime;
import TestCases.BaseWebAPITestCase;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import static API.RulesManagementService.Utils.RuleAtStatus.CreatePendingExpiredRuleVersion;
import static API.RulesManagementService.Utils.Rules.*;
import static FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXMinutes;
import static org.junit.Assert.assertEquals;

@Slf4j
@Category(Slow_Tests.class)
public class TestCase_PendingRule extends BaseWebAPITestCase{

    @Test
    @Category(ChangeRequest.CR_340.class)
    public void WhenDraftWithFutureStartDateCommitted_RuleSetToPendingSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(1, DateTime.DateTimeUTCZ);

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        ViewRuleListResponse.ViewRuleListResponseObject viewRuleListResponseBefore = API.RulesManagementService.Utils.Rules.GetListOfRules();

        publishAndWait(5000);

        ViewRuleResponse.ViewRuleResponseObject ruleResponseAfterPublish = GetRuleByUID(commitResponse.uniqueId);

        ViewRuleListResponse.ViewRuleListResponseObject viewRuleListResponseAfter = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        assertEquals("Pending Version Count 1:", 1, viewRuleListResponseBefore.content.get(0).pendingVersionsCount);
        assertEquals("Pending Version Count 1:", 1, viewRuleListResponseAfter.content.get(0).pendingVersionsCount);

        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), ruleResponseAfterPublish.versions.get(0).status);
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), ruleResponseAfterPublish.upcoming.get(0).status);
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), ruleResponseAfterPublish.leadVersion.status);

    }

    @Test
    @Category(ChangeRequest.CR_340.class)
    public void WhenDraftRuleUpdatedWithFutureStartDateCommitted_RuleSetToPendingSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        ruleDetailsV2.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(1, DateTime.DateTimeUTCZ);
        ruleDetailsV2.uniqueID = createRuleResponse.uniqueId;
        EditRuleResponse.PutResponse editResponse = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetailsV2);

        EditRuleVersionResponse.PutResponse commitResponse = UpdateStatusOfRule(ruleDetailsV2,
                RuleVersionActions.commit);

        publishAndWait(5000);

        ViewRuleResponse.ViewRuleResponseObject ruleResponseAfterPublish = GetRuleByUID(commitResponse.uniqueId);

        //Assert
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), ruleResponseAfterPublish.versions.get(0).status);
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), ruleResponseAfterPublish.upcoming.get(0).status);

    }


    @Test
    @Category({ChangeRequest.CR_340.class, ChangeRequest.CR_1214.class})
    public void WhenDraftStartDateAndEndDateChanged_StartDateAndEndDateUpdatedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(1, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(2, DateTime.DateTimeUTCZ);

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        ruleDetailsV2.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(5, DateTime.DateTimeUTCZ);
        ruleDetailsV2.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(6, DateTime.DateTimeUTCZ);
        ruleDetailsV2.uniqueID = createRuleResponse.uniqueId;
        EditRuleResponse.PutResponse editResponse = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetailsV2);

        EditRuleVersionResponse.PutResponse commitResponse = UpdateStatusOfRule(ruleDetailsV2,
                RuleVersionActions.commit);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleResponseV2 = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(ruleDetailsV2.uniqueID, 2);

        //Assert
        assertEquals(ruleDetailsV2.startDateTime.substring(0,9), viewRuleResponseV2.startDateTime.substring(0,9));
        assertEquals(ruleDetailsV2.endDateTime.substring(0,9), viewRuleResponseV2.endDateTime.substring(0,9));
    }


    @Test
    @Category(ChangeRequest.CR_340.class)
    public void AttemptToCreateDraftWithInvalidStartDate_BadRequestResponseReceived() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.startDateTime = "19983125 1133";

        //Act
        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, createRuleResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_356.class)
    public void WhenDraftRuleWithCurrentStartDateCommitted_RuleSetToCommittedSuccessfully() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.startDateTime = AdjustLocalDateTimeNowByXMinutes(-1, DateTime.DateTimeUTCZ);

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);
    }


    //@Ignore("Archive Status is no longer displayed until Story CR-1731 is completed. Rules are now Active")
    @Test
    @Category(ChangeRequest.CR_1214.class)
    public void WhenDraftRuleWithStartDateSetToFutureCommitted_RuleSetToActiveSuccessfully() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.startDateTime = AdjustLocalDateTimeNowByXMinutes(-90, DateTime.DateTimeUTCZ);

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        publishAndWait(5000);

        log.debug("Waiting 90 Seconds for Rule Start Date Time to be triggered and rule become Active");
        Thread.sleep(90000);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponseObject = GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals(TestEnumerators.RuleStatus.active.toString(), viewRuleResponseObject.versions.get(0).status);
    }


    //@Ignore("Archive Status is no longer displayed until Story CR-1731 is completed. Rules are now Active")
    @Test
    @Category(ChangeRequest.CR_1214.class)
    public void WhenDraftRuleWithEndDateSetToNowCommitted_RuleSetToExpiredSuccessfully() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.endDateTime = AdjustLocalDateTimeNowByXMinutes(-1, DateTime.DateTimeUTCZ);

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        publishAndWait(5000);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponseObject = GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.expired.toString(), viewRuleResponseObject.versions.get(0).status);
    }


    //@Ignore("Archive Status is no longer displayed until Story CR-1731 is completed. Rules are now Active")
    @Test
    @Category(ChangeRequest.CR_1214.class)
    public void WhenDraftRuleWithEndDateSetToFutureCommitted_RuleSetToExpiredSuccessfully() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.endDateTime = AdjustLocalDateTimeNowByXMinutes(-90, DateTime.DateTimeUTCZ);

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        publishAndWait(5000);

        log.debug("Waiting 90 Seconds for Rule End Date Time to be triggered and rule become Archived");
        Thread.sleep(90000);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponseObject = GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals(TestEnumerators.RuleStatus.expired.toString(), viewRuleResponseObject.versions.get(0).status);
    }


    @Test
    @Category(ChangeRequest.CR_1214.class)
    public void WhenDraftRuleWithEndDateSetToFutureCommitted_RuleRemainsAtCommittedBeforeEndDateTime() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.endDateTime = AdjustLocalDateTimeNowByXMinutes(+10, DateTime.DateTimeUTCZ);

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        log.debug("Waiting 10 Seconds");
        Thread.sleep(10000);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponseObject = GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), viewRuleResponseObject.versions.get(0).status);
    }


    //@Ignore("Archive Status is no longer displayed until Story CR-1731 is completed. Rules are now Active")
    @Test
    @Category(ChangeRequest.CR_1214.class)
    public void WhenDraftRuleWithStartAndEndDateSetToFutureCommitted_RuleStatusChangesFromCommittedToPendingToActiveToExpired() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.startDateTime = AdjustLocalDateTimeNowByXMinutes(+1, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = AdjustLocalDateTimeNowByXMinutes(+2, DateTime.DateTimeUTCZ);

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        assertEquals(TestEnumerators.RuleStatus.committed.toString(), commitResponse.status);

        publishAndWait(5000);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponseObject = GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), viewRuleResponseObject.versions.get(0).status);

        log.debug("Waiting 10 Seconds rule should still be at Pending status");
        Thread.sleep(10000);

        log.debug("Waiting 70 Seconds rule should now be at Active status");
        Thread.sleep(60000);
        viewRuleResponseObject = GetRuleByUID(ruleDetails.uniqueID);
        assertEquals(TestEnumerators.RuleStatus.active.toString(), viewRuleResponseObject.versions.get(0).status);

        log.debug("Waiting 40 Seconds rule should still be at Expired status");
        Thread.sleep(60000);
        viewRuleResponseObject = GetRuleByUID(ruleDetails.uniqueID);
        assertEquals(TestEnumerators.RuleStatus.expired.toString(), viewRuleResponseObject.versions.get(0).status);
    }


    @Test
    @Category(ChangeRequest.CR_1214.class)
    public void AttemptToCreateDraftWithInvalidEndDate_BadRequestResponseReceived() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.endDateTime = "19981125 1133";

        //Act
        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;
        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, createRuleResponse.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_1214.class)
    public void WhenDraftRuleUpdatedWithEndDateSetToFutureCommitted_RuleSetToArchivedSuccessfully() throws Throwable {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.endDateTime = AdjustLocalDateTimeNowByXMinutes(-1, DateTime.DateTimeUTCZ);

        CreateRuleResponse.PostResponse createRuleResponse = CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        ruleDetailsV2.endDateTime = AdjustLocalDateTimeNowByXMinutes(+1, DateTime.DateTimeUTCZ);

        EditRuleResponse.PutResponse editResponse = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetailsV2);

        EditRuleVersionResponse.PutResponse commitResponse = UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        publishAndWait(5000);

        log.debug("Waiting 90 Seconds for Rule End Date Time to be triggered and rule become Archived");
        Thread.sleep(90000);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponseObject = GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals(TestEnumerators.RuleStatus.expired.toString(), viewRuleResponseObject.versions.get(0).status);
    }



    @Test
    @Category({ChangeRequest.CR_1883.class})
    public void WhenMultiplePendingRulesViewed_PendingRulesDisplayedInCorrectOrder()
    {
        //Arrange

        //rule starting in 1 days time
        TestRuleModel.RuleDetails ruleDetails = CreatePendingExpiredRuleVersion(1, 2);

        //rule starting in 3 days time
        ruleDetails.description = "rule3DaysTime";
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(3, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(4, DateTime.DateTimeUTCZ);

        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetails, 2);

        //rule starting in 5 mins time but ends in 1 days time
        ruleDetails.description = "rule5MinsTime";
        ruleDetails.startDateTime = AdjustLocalDateTimeNowByXMinutes(5, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(1, DateTime.DateTimeUTCZ);

        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetails, 3);

        publishAndWait(5000);

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject viewRuleListResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals("Pending Version Count 3:", 3, viewRuleListResponse.content.get(0).pendingVersionsCount);
        assertEquals("Lead Version 3:", 3, viewRuleResponse.leadVersion.versionId);

        Assertions.assertThat(viewRuleResponse.upcoming).extracting("status").containsOnly(TestEnumerators.RuleStatus.pending.toString());

        assertEquals("Next Pending Version 3:", 3, viewRuleResponse.upcoming.get(0).versionId);
        Assertions.assertThat(viewRuleResponse.upcoming.get(0).description.contains("rule5MinsTime"));

        assertEquals("Pending Version after Next Pending Version 4:",4, viewRuleResponse.upcoming.get(1).versionId);

        assertEquals("Last Pending Version 2:", 2, viewRuleResponse.upcoming.get(2).versionId);
        Assertions.assertThat(viewRuleResponse.upcoming.get(0).description.contains("rule3DaysTime"));
    }


    @Test
    @Category(ChangeRequest.CR_1883.class)
    public void GivenMultipleVersionsOfRule_WhenRuleViewedInRuleSummary_OnlyPendingRulesDisplayed()
    {
        //Arrange

        //1. rule starting in 1 days time
        TestRuleModel.RuleDetails ruleDetails = CreatePendingExpiredRuleVersion(1, 2);

        //2. expired Rule
        ruleDetails.description = "expiredRule";
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-2, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-1, DateTime.DateTimeUTCZ);
        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetails, 2);

        publishAndWait(5000);

        //3. draft Rule
        ruleDetails.description = "ruleDraft";
        API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetails);

        //4. committed Rule
        ruleDetails.description = "ruleCommit";
        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetails, 4);

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        Assertions.assertThat(viewRuleResponse.upcoming).extracting("status").containsOnly(TestEnumerators.RuleStatus.committed.toString(),TestEnumerators.RuleStatus.pending.toString());
    }


}
