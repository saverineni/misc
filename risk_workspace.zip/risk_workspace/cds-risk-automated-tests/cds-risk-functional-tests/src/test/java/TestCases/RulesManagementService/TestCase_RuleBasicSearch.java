package TestCases.RulesManagementService;


import API.DataForTests.Locations;
import API.DataForTests.TestRuleModel;
import API.EnvDetails.EnvDetails;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.Utils.Rules;
import API.RulesManagementService.ViewRuleList.ViewRuleListResponse;
import Categories_CDSRisk.CDS_RM_RulesGeneral;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import org.apache.http.HttpStatus;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.DeclarationType;
import uk.gov.hmrc.risk.test.common.enums.TransportMode;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_RulesGeneral.class})
public class TestCase_RuleBasicSearch extends BaseWebAPITestCase {

    @Test
    @Category({ChangeRequest.CR_2559.class})
    public void WhenRulesSearchedByFullRuleID_CorrectRuleReturned() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsLOC = API.DataForTests.Rules.DraftLOCRuleNatManager();
        Rules.CreateRuleAndGetResponseObject(ruleDetailsLOC);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response.uniqueId;
        ruleDetails.description = response.description;
        ruleDetails.ruleId = response.ruleId;

        //Act
        String url = EnvDetails.url_RuleCreate + "?ruleId=" + ruleDetails.ruleId;
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        //Assert
        assertEquals(HttpStatus.SC_OK, ruleList.httpStatusCode);
        assertThat(ruleList.content)
                .hasSize(1)
                .extracting("description").containsOnly(ruleDetails.description);
    }


    @Test
    @Category({ChangeRequest.CR_2559.class})
    public void WhenRulesSearchedByPartialRuleID_CorrectRuleReturned() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsLOC = API.DataForTests.Rules.DraftLOCRuleNatManager();
        Rules.CreateRuleAndGetResponseObject(ruleDetailsLOC);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response.uniqueId;
        ruleDetails.description = response.description;

        //Act
        String url = EnvDetails.url_RuleCreate + "?ruleId=" + ruleDetails.ruleId.substring(0, 5);
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        //Assert
        assertEquals(HttpStatus.SC_OK, ruleList.httpStatusCode);
        assertThat(ruleList.content)
                .hasSize(1)
                .extracting("description").containsOnly(ruleDetails.description);
    }


    @Test
    @Category({ChangeRequest.CR_2559.class})
    public void WhenRulesSearchedByFullDescription_CorrectRuleReturned() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsLOC = API.DataForTests.Rules.DraftLOCRuleNatManager();
        Rules.CreateRuleAndGetResponseObject(ruleDetailsLOC);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response.uniqueId;
        ruleDetails.description = response.description;

        //Act
        String url = EnvDetails.url_RuleCreate + "?description=" + ruleDetails.description;
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        //Assert
        assertEquals(HttpStatus.SC_OK, ruleList.httpStatusCode);
        assertThat(ruleList.content)
                .hasSize(1)
                .extracting("description").containsOnly(ruleDetails.description);
    }


    @Test
    @Category({ChangeRequest.CR_2559.class})
    public void WhenRulesSearchedByPartialDescription_CorrectRuleReturned() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsLOC = API.DataForTests.Rules.DraftLOCRuleNatManager();
        Rules.CreateRuleAndGetResponseObject(ruleDetailsLOC);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response.uniqueId;
        ruleDetails.description = response.description;

        //Act
        String url = EnvDetails.url_RuleCreate + "?description=" + "naTDR";
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        //Assert
        assertEquals(HttpStatus.SC_OK, ruleList.httpStatusCode);
        assertThat(ruleList.content)
                .hasSize(1)
                .extracting("description").containsOnly(ruleDetails.description);
    }

    @Test
    @Category({ChangeRequest.CR_2559.class})
    public void WhenRulesSearchedByRuleTypeNational_CorrectRuleReturned() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsLOC = API.DataForTests.Rules.DraftLOCRuleNatManager();
        Rules.CreateRuleAndGetResponseObject(ruleDetailsLOC);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response.uniqueId;
        ruleDetails.description = response.description;

        //Act
        String url = EnvDetails.url_RuleCreate + "?ruleType=" + "national";
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        //Assert
        assertEquals(HttpStatus.SC_OK, ruleList.httpStatusCode);
        assertThat(ruleList.content)
                .hasSize(1)
                .extracting("description").containsOnly(ruleDetails.description);
    }


    @Test
    @Category({ChangeRequest.CR_2559.class})
    public void WhenRulesSearchedByRuleTypeLocal_CorrectRuleReturned() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsLOC = API.DataForTests.Rules.DraftLOCRuleNatManager();
        Rules.CreateRuleAndGetResponseObject(ruleDetailsLOC);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response.uniqueId;
        ruleDetails.description = response.description;

        //Act
        String url = EnvDetails.url_RuleCreate + "?ruleType=" + "local";
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        //Assert
        assertEquals(HttpStatus.SC_OK, ruleList.httpStatusCode);
        assertThat(ruleList.content)
                .hasSize(1)
                .extracting("description").containsOnly(ruleDetailsLOC.description);
    }


    @Test
    @Category({ChangeRequest.CR_2559.class})
    public void WhenRulesSearchedByRuleStatus_CorrectRulesReturned() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsCommitted = API.DataForTests.Rules.DraftLOCRuleNatManager();
        ruleDetailsCommitted.locations.add(Locations.Location_ABZ_UID);
        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetailsCommitted);

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response.uniqueId;
        ruleDetails.description = response.description;

        //Act
        String url = EnvDetails.url_RuleCreate + "?ruleStatuses=" + "draft";
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        //Assert
        assertEquals(HttpStatus.SC_OK, ruleList.httpStatusCode);
        assertThat(ruleList.content)
                .hasSize(1)
                .extracting("description").containsOnly(ruleDetails.description);
    }

    @Test
    @Category({ChangeRequest.CR_2599.class})
    public void WhenRulesSearchedByDeclarationType_CorrectRulesReturned() {
        //Arrange
        TestRuleModel.RuleDetails draftLocRuleImport = API.DataForTests.Rules.DraftLOCRuleNatManager();
        draftLocRuleImport.queryOptions.declarationType = DeclarationType.IM.toString();
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(draftLocRuleImport);

        TestRuleModel.RuleDetails draftNatRuleExport = API.DataForTests.Rules.DraftNatRuleNatManager();
        draftNatRuleExport.queryOptions.declarationType = DeclarationType.EX.toString();
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(draftNatRuleExport);

        TestRuleModel.RuleDetails draftPooLocRuleImport = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        draftPooLocRuleImport.queryOptions.declarationType = DeclarationType.IM.toString();
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(draftPooLocRuleImport);


        TestRuleModel.RuleDetails draftPooExtLocRuleBothDeclaration = API.DataForTests.Rules.DraftLocRuleLocalManager_POOEXT();
        draftPooExtLocRuleBothDeclaration.queryOptions.declarationType = DeclarationType.Both.toString();
        draftPooExtLocRuleBothDeclaration.queryOptions.declarationSubTypes = null;
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(draftPooExtLocRuleBothDeclaration);

        //Act
        String url = EnvDetails.url_RuleCreate + "?declarationTypes=" + "Imports";
        ViewRuleListResponse.ViewRuleListResponseObject ruleListImportDeclaration = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        url = EnvDetails.url_RuleCreate + "?declarationTypes=" + "Exports";
        ViewRuleListResponse.ViewRuleListResponseObject ruleListExportDeclaration = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        url = EnvDetails.url_RuleCreate + "?declarationTypes=" + "Both";
        ViewRuleListResponse.ViewRuleListResponseObject ruleListBothDeclaration = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        url = EnvDetails.url_RuleCreate + "?declarationTypes=" + "Imports,Exports";
        ViewRuleListResponse.ViewRuleListResponseObject ruleListImportsExportsDeclaration = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        //Assert
        assertEquals(HttpStatus.SC_OK, ruleListExportDeclaration.httpStatusCode);
        assertThat(ruleListImportDeclaration.content)
                .hasSize(2)
                .extracting("description").containsOnly(draftLocRuleImport.description, draftPooLocRuleImport.description);

        assertEquals(HttpStatus.SC_OK, ruleListExportDeclaration.httpStatusCode);
        assertThat(ruleListExportDeclaration.content)
                .hasSize(1)
                .extracting("description").containsOnly(draftNatRuleExport.description);

        assertEquals(HttpStatus.SC_OK, ruleListBothDeclaration.httpStatusCode);
        assertThat(ruleListBothDeclaration.content)
                .hasSize(1)
                .extracting("description").containsOnly(draftPooExtLocRuleBothDeclaration.description);

        assertEquals(HttpStatus.SC_OK, ruleListExportDeclaration.httpStatusCode);
        assertThat(ruleListImportsExportsDeclaration.content)
                .hasSize(3)
                .extracting("description").containsOnly(draftLocRuleImport.description, draftPooLocRuleImport.description, draftNatRuleExport.description);

    }

    @Test
    @Category({ChangeRequest.CR_2593.class})
    public void WhenRulesSearchedByActionType_CorrectRulesReturned() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsPhysicalCheck = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsPhysicalCheck.ruleOutputs.actionType = "1";
        ruleDetailsPhysicalCheck.ruleOutputs.holdNarrative = "Physical Check";
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetailsPhysicalCheck);

        TestRuleModel.RuleDetails ruleDetailsDocCheckAndHoldGoods = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsDocCheckAndHoldGoods.ruleOutputs.actionType = "2";
        ruleDetailsPhysicalCheck.ruleOutputs.holdNarrative = "Document Check And Hold Goods";
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetailsDocCheckAndHoldGoods);

        TestRuleModel.RuleDetails ruleDetailsDocCheckAndRelGoods = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        ruleDetailsDocCheckAndRelGoods.ruleOutputs.actionType = "3";
        ruleDetailsDocCheckAndRelGoods.ruleOutputs.holdNarrative = null;
        ruleDetailsDocCheckAndRelGoods.ruleOutputs.releaseNarrative = "Release Narrative";
        ruleDetailsDocCheckAndRelGoods.ruleOutputs.holdPercentage = null;
        ruleDetailsDocCheckAndRelGoods.ruleOutputs.releasePercentage = null;
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetailsDocCheckAndRelGoods);

        TestRuleModel.RuleDetails ruleDetailsDocCheckAndVaryRelGoods = API.DataForTests.Rules.DraftLocRuleLocalManager_POOEXT();
        ruleDetailsDocCheckAndVaryRelGoods.ruleOutputs.actionType = "4";
        ruleDetailsDocCheckAndVaryRelGoods.ruleOutputs.releaseNarrative = "test release narrative text for rule" + ruleDetailsDocCheckAndVaryRelGoods.uniqueID;
        ruleDetailsDocCheckAndVaryRelGoods.ruleOutputs.holdNarrative = "This narrative will not be used";
        ruleDetailsDocCheckAndVaryRelGoods.ruleOutputs.holdPercentage = 0;
        ruleDetailsDocCheckAndVaryRelGoods.ruleOutputs.releasePercentage = 100;
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetailsDocCheckAndVaryRelGoods);

        //Act
        String url = EnvDetails.url_RuleCreate + "?actionTypes=" + "1";
        ViewRuleListResponse.ViewRuleListResponseObject ruleListPhysicalCheck = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        url = EnvDetails.url_RuleCreate + "?actionTypes=" + "2";
        ViewRuleListResponse.ViewRuleListResponseObject ruleListDocCheckAndHoldGoods = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        url = EnvDetails.url_RuleCreate + "?actionTypes=" + "3";
        ViewRuleListResponse.ViewRuleListResponseObject ruleListDocCheckAndRelGoods = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        url = EnvDetails.url_RuleCreate + "?actionTypes=" + "4";
        ViewRuleListResponse.ViewRuleListResponseObject ruleListDocCheckAndVaryRelGoods = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        url = EnvDetails.url_RuleCreate + "?actionTypes=" + "1,2,3,4";
        ViewRuleListResponse.ViewRuleListResponseObject ruleListAllActionTypes = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        //Assert
        assertEquals(HttpStatus.SC_OK, ruleListPhysicalCheck.httpStatusCode);
        assertThat(ruleListPhysicalCheck.content)
                .hasSize(1)
                .extracting("description").containsOnly(ruleDetailsPhysicalCheck.description);

        assertEquals(HttpStatus.SC_OK, ruleListDocCheckAndHoldGoods.httpStatusCode);
        assertThat(ruleListDocCheckAndHoldGoods.content)
                .hasSize(1)
                .extracting("description").containsOnly(ruleDetailsDocCheckAndHoldGoods.description);

        assertEquals(HttpStatus.SC_OK, ruleListDocCheckAndRelGoods.httpStatusCode);
        assertThat(ruleListDocCheckAndRelGoods.content)
                .hasSize(1)
                .extracting("description").containsOnly(ruleDetailsDocCheckAndRelGoods.description);

        assertEquals(HttpStatus.SC_OK, ruleListDocCheckAndVaryRelGoods.httpStatusCode);
        assertThat(ruleListDocCheckAndVaryRelGoods.content)
                .hasSize(1)
                .extracting("description").containsOnly(ruleDetailsDocCheckAndVaryRelGoods.description);

        assertEquals(HttpStatus.SC_OK, ruleListAllActionTypes.httpStatusCode);
        assertThat(ruleListAllActionTypes.content)
                .hasSize(4)
                .extracting("description").containsOnly(ruleDetailsPhysicalCheck.description, ruleDetailsDocCheckAndHoldGoods.description, ruleDetailsDocCheckAndRelGoods.description, ruleDetailsDocCheckAndVaryRelGoods.description);
    }

    @Test
    @Category({ChangeRequest.CR_2594.class})
    public void WhenRulesSearchedByModeOfTransport_CorrectRulesReturned() {
        //Arrange
        TestRuleModel.RuleDetails draftLocRuleAir = API.DataForTests.Rules.DraftLOCRuleNatManager();
        draftLocRuleAir.queryOptions.transportMode = TransportMode.Air.toString();
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(draftLocRuleAir);

        TestRuleModel.RuleDetails draftNatRuleAir = API.DataForTests.Rules.DraftNatRuleNatManager();
        draftNatRuleAir.queryOptions.transportMode = TransportMode.Air.toString();
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(draftNatRuleAir);

        TestRuleModel.RuleDetails draftPooLocRuleMaritime = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        draftPooLocRuleMaritime.queryOptions.transportMode = TransportMode.Maritime.toString();
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(draftPooLocRuleMaritime);

        //Act
        String url = EnvDetails.url_RuleCreate + "?modesOfTransport=" + "Air";
        ViewRuleListResponse.ViewRuleListResponseObject ruleListAir = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        url = EnvDetails.url_RuleCreate + "?modesOfTransport=" + "Maritime";
        ViewRuleListResponse.ViewRuleListResponseObject ruleListMaritime = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        url = EnvDetails.url_RuleCreate + "?modesOfTransport=" + "Air,Maritime";
        ViewRuleListResponse.ViewRuleListResponseObject ruleListBoth = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        //Assert
        assertEquals(HttpStatus.SC_OK, ruleListAir.httpStatusCode);
        assertThat(ruleListAir.content)
                .hasSize(2)
                .extracting("description").containsOnly(draftLocRuleAir.description, draftNatRuleAir.description);

        assertEquals(HttpStatus.SC_OK, ruleListMaritime.httpStatusCode);
        assertThat(ruleListMaritime.content)
                .hasSize(1)
                .extracting("description").containsOnly(draftPooLocRuleMaritime.description);

        assertEquals(HttpStatus.SC_OK, ruleListBoth.httpStatusCode);
        assertThat(ruleListBoth.content)
                .hasSize(3)
                .extracting("description").containsOnly(draftLocRuleAir.description, draftNatRuleAir.description, draftPooLocRuleMaritime.description);
    }


    @Test
    @Category({ChangeRequest.CR_2559.class})
    public void WhenRulesSearchedByMultipleRuleStatus_CorrectRulesReturned() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsSuspended = API.DataForTests.Rules.DraftLOCRuleNatManager();
        ruleDetailsSuspended.locations.add(Locations.Location_ABZ_UID);
        ruleDetailsSuspended.description = "ta_suspended";
        API.RulesManagementService.Utils.RuleAtStatus.CreateSuspendedRule(ruleDetailsSuspended);


        TestRuleModel.RuleDetails ruleDetailsActive = API.DataForTests.Rules.DraftLOCRuleNatManager();
        ruleDetailsActive.locations.add(Locations.Location_BHX_UID);
        API.RulesManagementService.Utils.RuleAtStatus.CreateActiveRule(ruleDetailsActive);
        ruleDetailsActive.description = "Ta_active";

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.locations.add(Locations.Location_BHX_UID);
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        publishAndWait(1000);

        //Act
        String url = EnvDetails.url_RuleCreate + "?ruleStatuses=" + "active,suspended";
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        //Assert
        assertEquals(HttpStatus.SC_OK, ruleList.httpStatusCode);
        assertThat(ruleList.content)
                .hasSize(2)
                .extracting("status").containsOnly("active", "suspended");
    }


    @Test
    @Category({ChangeRequest.CR_2559.class})
    public void WhenRulesSearchedByMultipleFilters_CorrectRulesReturned() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsDraftLOC = API.DataForTests.Rules.DraftLOCRuleNatManager();
        Rules.CreateRuleAndGetResponseObject(ruleDetailsDraftLOC);

        TestRuleModel.RuleDetails ruleDetailsActive = API.DataForTests.Rules.DraftLOCRuleNatManager();
        API.RulesManagementService.Utils.RuleAtStatus.CreateActiveRule(ruleDetailsActive);
        ruleDetailsActive.description = "Ta_active";

        TestRuleModel.RuleDetails ruleDetailsDraftNAT = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsDraftNAT.queryOptions.declarationType = DeclarationType.EX.toString();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetailsDraftNAT);
        ruleDetailsDraftNAT.description = response.description;

        //Act
        String url = EnvDetails.url_RuleCreate + "?ruleStatuses=" + "draft" + "&ruleType=" + "national" + "&actionTypes=" + "1" + "&declarationtypes=" + "Exports";
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        //Assert
        assertEquals(HttpStatus.SC_OK, ruleList.httpStatusCode);
        assertThat(ruleList.content)
                .hasSize(1)
                .extracting("description").containsOnly(ruleDetailsDraftNAT.description);
    }


    @Test
    @Category({ChangeRequest.CR_2559.class, ChangeRequest.CR_2593.class, ChangeRequest.CR_2594.class, ChangeRequest.CR_2599.class})
    public void WhenThereAreNoMatchingRulesForSearch_NoResultsReturned() {

        //Act
        TestRuleModel.RuleDetails draftImportAirAndPhysicalCheck = API.DataForTests.Rules.DraftLOCRuleNatManager();
        draftImportAirAndPhysicalCheck.queryOptions.transportMode = TransportMode.Air.toString();
        draftImportAirAndPhysicalCheck.queryOptions.declarationType = DeclarationType.IM.toString();
        draftImportAirAndPhysicalCheck.ruleOutputs.actionType = "1";
        draftImportAirAndPhysicalCheck.ruleOutputs.holdNarrative = "Physical Check";
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(draftImportAirAndPhysicalCheck);

        TestRuleModel.RuleDetails draftExportMaritimeAndDocCheck = API.DataForTests.Rules.DraftNatRuleNatManager();
        draftExportMaritimeAndDocCheck.queryOptions.transportMode = TransportMode.Maritime.toString();
        draftExportMaritimeAndDocCheck.queryOptions.declarationType = DeclarationType.IM.toString();
        draftExportMaritimeAndDocCheck.ruleOutputs.actionType = "2";
        draftExportMaritimeAndDocCheck.ruleOutputs.holdNarrative = "Document Check";
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(draftExportMaritimeAndDocCheck);

        //Act
        String url = EnvDetails.url_RuleCreate + "?modesOfTransport=" + "Air" + "&declarationTypes=" + "Exports" + "&actionTypes=" + "1";
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        //Assert
        assertEquals(HttpStatus.SC_OK, ruleList.httpStatusCode);
        assertThat(ruleList.content)
                .hasSize(0);
        assertThat(ruleList.totalElements).isEqualTo(0);
        assertThat(ruleList.totalPages).isEqualTo(0);

    }

    @Test
    @Category({ChangeRequest.CR_2625.class})
    public void WhenRulesSearchedByMultipleFreightLocations_CorrectRulesReturned() {
        //Arrange
        //Create a Local Rule With Locations as EXT, MAN and BHX
        TestRuleModel.RuleDetails ruleDetailsMutipleLocations = API.DataForTests.Rules.DraftLOCRuleNatManager();
        ruleDetailsMutipleLocations.queryOptions.transportMode = TransportMode.Air.toString();
        ruleDetailsMutipleLocations.locations.add(Locations.Location_EXT_UID);
        ruleDetailsMutipleLocations.locations.add(Locations.Location_MAN_UID);
        ruleDetailsMutipleLocations.locations.add(Locations.Location_BHX_UID);
        ruleDetailsMutipleLocations.description = "MultipleLocations";
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetailsMutipleLocations);

        //Create a Local Rule With Locations as POO and BOS with action type as Document Check and Release Goods and Transport Mode as MAritime
        TestRuleModel.RuleDetails ruleDetailsPooMan = API.DataForTests.Rules.DraftLocRuleLocalManager_POO();
        ruleDetailsPooMan.queryOptions.transportMode = TransportMode.Maritime.toString();
        ruleDetailsPooMan.locations.add(Locations.Location_BOS_UID);
        ruleDetailsPooMan.description = "Manchester";
        ruleDetailsPooMan.ruleOutputs.actionType = "3";
        ruleDetailsPooMan.ruleOutputs.holdNarrative = null;
        ruleDetailsPooMan.ruleOutputs.releaseNarrative = "Release Narrative";
        ruleDetailsPooMan.ruleOutputs.holdPercentage = null;
        ruleDetailsPooMan.ruleOutputs.releasePercentage = null;
        ruleDetailsPooMan.queryOptions.transportMode = TransportMode.Maritime.toString();
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetailsPooMan);

        //Create a National rule with transport mode as Air
        TestRuleModel.RuleDetails ruleDetailsNational = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsNational.queryOptions.transportMode = TransportMode.Air.toString();
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetailsNational);

        //Act
        //Search for ABZ, EXT and Mode of Transport as Air. Result should have ruleDetailsMutipleLocations and ruleDetailsNational
        String url = EnvDetails.url_RuleCreate + "?locationUuids="+Locations.Location_ABZ_UID+","+Locations.Location_EXT_UID+"&modesOfTransport=" + "Air";
        ViewRuleListResponse.ViewRuleListResponseObject ruleListLocationTransport = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        //Search for BOS and action type as Document Check and Release Goods.Result should have ruleDetailsPooMan
        url = EnvDetails.url_RuleCreate + "?locationUuids="+Locations.Location_BOS_UID+"&actionTypes=" + "3";;
        ViewRuleListResponse.ViewRuleListResponseObject ruleListLocationsAndActionType = API.RulesManagementService.Utils.Rules.GetListOfRules(url);


        //Assert
        assertEquals(HttpStatus.SC_OK, ruleListLocationTransport.httpStatusCode);
        assertThat(ruleListLocationTransport.content)
                .hasSize(2)
                .extracting("description").containsOnly(ruleDetailsNational.description,ruleDetailsMutipleLocations.description);

        assertEquals(HttpStatus.SC_OK, ruleListLocationsAndActionType.httpStatusCode);
        assertThat(ruleListLocationsAndActionType.content)
                .hasSize(1)
                .extracting("description").containsOnly(ruleDetailsPooMan.description);
    }

    @Test
    @Category({ChangeRequest.CR_3462.class})
    public void WhenRulesSearchedBySilentStatus_CorrectRulesReturned() {
        //Arrange
        TestRuleModel.RuleDetails ruleDetailsSuspended = API.DataForTests.Rules.DraftLOCRuleNatManager();
        ruleDetailsSuspended.locations.add(Locations.Location_ABZ_UID);
        ruleDetailsSuspended.description = "ta_suspended";
        API.RulesManagementService.Utils.RuleAtStatus.CreateSuspendedRule(ruleDetailsSuspended);


        TestRuleModel.RuleDetails ruleDetailsActive = API.DataForTests.Rules.DraftLOCRuleNatManager();
        ruleDetailsActive.locations.add(Locations.Location_BHX_UID);
        API.RulesManagementService.Utils.RuleAtStatus.CreateActiveRule(ruleDetailsActive);
        ruleDetailsActive.description = "Ta_active";

        TestRuleModel.RuleDetails ruleDetailsSielnt = API.DataForTests.Rules.DraftLOCRuleNatManager();
        ruleDetailsActive.locations.add(Locations.Location_MAN_UID);
        API.RulesManagementService.Utils.RuleAtStatus.CreateSilentRule(ruleDetailsActive);
        ruleDetailsActive.description = "Ta_sielnt";

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.locations.add(Locations.Location_BHX_UID);
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        publishAndWait(1000);



        //Act
        String url = EnvDetails.url_RuleCreate + "?ruleStatuses=" + "silent";
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = API.RulesManagementService.Utils.Rules.GetListOfRules(url);

        //Assert
        assertEquals(HttpStatus.SC_OK, ruleList.httpStatusCode);
        assertThat(ruleList.content)
                .hasSize(1)
                .extracting("status").containsOnly("silent");
    }

}



