package TestCases.LocationService;

import API.DataForTests.Locations;
import API.LocationService.LocationResponse;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Location_Service;
import TestCases.BaseSpringBootTestCase;
import org.apache.http.HttpStatus;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;

@Category(Location_Service.class)
public class TestCase_LocationService extends BaseSpringBootTestCase {

    @Before
    public void Setup(){

        Locations.SetAllLocationUIDs();
    }


    //TODO CHECK HOW TO ADD TO CLASS PATH to allow api schema to be validated
//    @Test
//    @Category(ChangeRequest.CR_585.class)
//    public void WhenLocationServiceGetLocationByNameAPICalled_ConformsToSchema() {
//
//        log.info("\r\n" + "WhenLocationServiceGetLocationByNameAPICalled_ConformsToSchema" + "\r\n");
//        //Arrange
//
//        //Act
//        LocationResponse locationResponse = API.LocationService.Utils.Locations.GetLocationByName("POO");
//
//        //Assert
//        assertThat(locationResponse.response.getBody().toString(), matchesJsonSchemaInClasspath("getLocationByNameSchema.json"));
//    }


    @Test
    @Category(ChangeRequest.CR_585.class)
    public void WhenLocationSelectedByName_LocationDetailsReturned() {

        //Arrange

        //Act
        LocationResponse locationResponse = API.LocationService.Utils.Locations.GetLocationByName("POO");

        //Assert
        assertEquals("POO", locationResponse.name);
        assertEquals("POO", locationResponse.freightLocationCodes.get(0));
    }

    @Test
    @Category(ChangeRequest.CR_585.class)
    public void WhenNationalLocationSelectedByName_ListOfFreightLocationsReturned() {

        //Arrange

        //Act
        LocationResponse locationResponse = API.LocationService.Utils.Locations.GetLocationByName("National Office");

        //Assert
        assertEquals("National Office", locationResponse.name);
        assertTrue("Freight Location Codes returned: " + locationResponse.freightLocationCodes.size(), locationResponse.freightLocationCodes.size() > 1);
    }

    @Test
    @Category(ChangeRequest.CR_585.class)
    public void WhenLocationSelectedByUID_LocationDetailsReturned() {

        //Arrange

        //Act
        LocationResponse locationResponse = API.LocationService.Utils.Locations.GetLocationByUID(Locations.Location_POO_UID);

        //Assert
        assertEquals("POO", locationResponse.name);
        assertEquals("POO", locationResponse.freightLocationCodes.get(0));
    }

    @Test
    @Category(ChangeRequest.CR_585.class)
    public void WhenNonExistentLocationSelectedByUID_NotFoundResponseReceived() {

        //Arrange

        //Act
        LocationResponse locationResponse = API.LocationService.Utils.Locations.GetLocationByUID("ZZZZ3229-7997-11e6-94ce-080027eeZZZZZ");
        //API_Location_Responses.LocationResponseObject uoLocation = ConvertJSON_LocationResponse.GetLocationByID("ZZZZ3229-7997-11e6-94ce-080027eeZZZZZ");

        //Assert
        assertEquals(HttpStatus.SC_NOT_FOUND, locationResponse.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_585.class)
    public void WhenNonExistentLocationSelectedByName_NotFoundResponseReceived() {

        //Arrange

        //Act
        LocationResponse locationResponse = API.LocationService.Utils.Locations.GetLocationByName("AAA");

        //Assert
        assertEquals(HttpStatus.SC_NOT_FOUND, locationResponse.httpStatusCode);

    }

    @Test
    @Category(ChangeRequest.CR_585.class)
    public void WhenListOfLocationsSelected_ListOfLocationsReturned() {

        //Arrange

        //Act
        List<API.LocationService.LocationResponse> listOfLocationResponse = API.LocationService.Utils.Locations.GetListOfLocation();

        //Assert
        assertEquals(HttpStatus.SC_OK, listOfLocationResponse.get(0).httpStatusCode);
        assertTrue(listOfLocationResponse.size() > 1);
    }

    @Test
    @Category(ChangeRequest.CR_983.class)
    public void WhenLocationALLSelected_LocationDetailsReturned() throws Throwable {

        //Arrange

        //Act
        LocationResponse locationResponse = API.LocationService.Utils.Locations.GetLocationByName("All Locations");

        //Assert
        assertEquals("All Locations", locationResponse.name);
        assertEquals(0, locationResponse.freightLocationCodes.size());
    }

}
