package TestCases.RulesManagementService;


import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse;
import Categories_CDSRisk.CDS_RM_Login;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static API.DataForTests.TestEnumerators.MetaDataActions.*;
import static API.RulesManagementService.Utils.Users.GetUserDetails;
import static API.RulesManagementService.Utils.Users.UpdateStatusOfUser;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_Login.class})
public class TestCase_LoginAdmin extends BaseWebAPITestCase{

    private TestUserModel.UserDetails userDetails2;

    @Before
    public void Setup(){

        TestUserModel.UserDetails userDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        userDetails2 = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);

    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenNationalAdminLoggedIn_NoMetaDataActionsAvailableForSuperAdmin() {

        //Arrange

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.SuperAdminNational("1234521");
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(0);
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenNationalAdminLoggedIn_CorrectMetaDataActionsAvailableForNationalAdmin() {

        //Arrange

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.AdminNational("1234562");
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(3)
                .contains(USER_ARCHIVE.toString(),
                        USER_SUSPEND.toString(),
                        USER_EDIT.toString());
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenNationalAdminLoggedIn_CorrectMetaDataActionsAvailableForLocalAdmin() {

        //Arrange

        //Act
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(3)
                .contains(USER_ARCHIVE.toString(),
                        USER_SUSPEND.toString(),
                        USER_EDIT.toString());
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenNationalAdminLoggedIn_CorrectMetaDataActionsAvailableForNationalRuleManager() {

        //Arrange

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(3)
                .contains(USER_ARCHIVE.toString(),
                        USER_SUSPEND.toString(),
                        USER_EDIT.toString());
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenNationalAdminLoggedIn_CorrectMetaDataActionsAvailableForLocalRuleManager() {

        //Arrange

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(3)
                .contains(USER_ARCHIVE.toString(),
                        USER_SUSPEND.toString(),
                        USER_EDIT.toString());
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenNationalAdminLoggedIn_CorrectMetaDataActionsAvailableForNationalRuleViewer() {

        //Arrange

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(3)
                .contains(USER_ARCHIVE.toString(),
                        USER_SUSPEND.toString(),
                        USER_EDIT.toString());
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenNationalAdminLoggedIn_CorrectMetaDataActionsAvailableForLocalRuleViewer() {

        //Arrange

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(3)
                .contains(USER_ARCHIVE.toString(),
                        USER_SUSPEND.toString(),
                        USER_EDIT.toString());
    }


    //----------------------------------------------
    //Local Admin
    //----------------------------------------------

    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenLocalAdminLoggedIn_NoMetaDataActionsAvailableForNationalAdmin() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(0);
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenLocalAdminLoggedIn_CorrectMetaDataActionsAvailableForLocalAdmin() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.AdminLocal_POO("1234562");
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(3)
                .contains(USER_ARCHIVE.toString(),
                        USER_SUSPEND.toString(),
                        USER_EDIT.toString());
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenLocalAdminLoggedIn_NoMetaDataActionsAvailableForNationalRuleManager() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(0);
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenLocalAdminLoggedIn_CorrectMetaDataActionsAvailableForLocalRuleManager() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.RulesManagerLocal_POO("1234562");
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(3)
                .contains(USER_ARCHIVE.toString(),
                        USER_SUSPEND.toString(),
                        USER_EDIT.toString());
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenLocalAdminLoggedIn_NoMetaDataActionsAvailableForDifferentLocalRuleManager() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(0);
    }

    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenLocalAdminLoggedIn_NoMetaDataActionsAvailableForLocalRuleManagerForMultipleLocation() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.RulesManagerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(0);
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenLocalAdminLoggedIn_NoMetaDataActionsAvailableForNationalRuleViewer() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(0);
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenLocalAdminLoggedIn_CorrectMetaDataActionsAvailableForLocalRuleViewer() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.RuleViewerLocal_POO("1234562");
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(3)
                .contains(USER_ARCHIVE.toString(),
                        USER_SUSPEND.toString(),
                        USER_EDIT.toString());
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenLocalAdminLoggedIn_NoMetaDataActionsAvailableForDifferentLocalRuleViewer() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.RulesViewerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(0);
    }

    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenLocalAdminLoggedIn_NoMetaDataActionsAvailableForLocalRuleViewerForMultipleLocation() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.RuleViewerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(0);
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenLocalAdminWithMultipleLocationsLoggedIn_CorrectMetaDataActionsAvailableForLocalRuleManagerForMultipleLocation() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO_EXT("1234542");
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.AdminLocal_POO("1234543");
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(3)
                .contains(USER_ARCHIVE.toString(),
                        USER_SUSPEND.toString(),
                        USER_EDIT.toString());
    }

    @Test
    @Category({ChangeRequest.CR_1982.class,ChangeRequest.CR_1404.class})
    public void WhenLocalAdminWithMultipleLocationsLoggedIn_CorrectMetaDataActionsAvailableForLocalRuleViewerForMultipleLocation() {

        //Arrange
        TestUserModel.UserDetails userDetails = Users_API.AdminLocal_POO_EXT("1234542");
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails.pid);

        //Act
        TestUserModel.UserDetails userDetails2 = Users_API.AdminLocal_POO("1234543");
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);
        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = API.RulesManagementService.Utils.Users.GetUserDetails(userDetails2.pid);

        //Assert
        API.RulesManagementService.Users.Me.Details.UserMeDetailsResponse.AssertViewUserResponse(userDetails2, userDetailsResponse);
        assertEquals("Base Location A Name", "Poole", userDetailsResponse.baseLocation.locationFullName);
        assertEquals("Custom Location A Name","Poole",userDetailsResponse.roles.get(0).locationFullName);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(3)
                .contains(USER_ARCHIVE.toString(),
                        USER_SUSPEND.toString(),
                        USER_EDIT.toString());
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenUserArchivesUser_UserArchivedSuccessfullyNoFurtherActionsAvailable() {

        //Arrange

        //Act
        Response userResponse = UpdateStatusOfUser(userDetails2.pid, USER_ARCHIVE.apiAction);

        //Assert
        assertEquals(HttpStatus.SC_NO_CONTENT, userResponse.statusCode());

        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = GetUserDetails(userDetails2.pid);

        Assertions.assertThat(userDetailsResponse.status).isEqualTo(USER_ARCHIVE.apiResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(0);
    }

    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void WhenUserReinstatesUser_UserReinstatedSuccessfullyAndActionsAvailable() {

        //Arrange

        //Act
        UpdateStatusOfUser(userDetails2.pid, USER_SUSPEND.apiAction);
        Response userResponse = UpdateStatusOfUser(userDetails2.pid, USER_REINSTATE.apiAction);


        //Assert
        assertEquals(HttpStatus.SC_NO_CONTENT, userResponse.statusCode());

        UserMeDetailsResponse.UsersMeResponseObject userDetailsResponse = GetUserDetails(userDetails2.pid);

        Assertions.assertThat(userDetailsResponse.status).isEqualTo(USER_REINSTATE.apiResponse);

        Assertions.assertThat(userDetailsResponse.metaData.actions)
                .hasSize(3)
                .contains(USER_SUSPEND.apiMetaResponse,
                        USER_ARCHIVE.apiMetaResponse,
                        USER_EDIT.apiMetaResponse);
    }


    @Test
    @Category(ChangeRequest.CR_1982.class)
    public void AttemptToArchiveSuperAdminUser_ForbiddenResponseReceived() {

        //Arrange
        userDetails2 = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);

        //Act
        Response userResponse = UpdateStatusOfUser(userDetails2.pid, USER_ARCHIVE.apiAction);

        //Assert
        assertEquals(HttpStatus.SC_FORBIDDEN, userResponse.statusCode());
    }


}
