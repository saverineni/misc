package TestCases.RiskingService;

import API.DataForTests.Conditions;
import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestRuleModel.RuleDetails;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.Utils.RuleAtStatus;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service_Operators;
import TestCases.BaseWebAPITestCase;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import static API.DataForTests.TestRuleModel.RuleDetails.AttributeType.DOMAIN;
import static API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody;
import static org.assertj.core.api.Assertions.assertThat;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.crossmatch;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.normal;

@Slf4j
@Category(Risking_Service_Operators.class)
public class TestCase_Risking_Operators_NotEqual_domainField extends BaseWebAPITestCase {

    public static final String NO_CONTROL_ROUTE = "";
    private RuleDetails testRule;
    private RuleDetails.Condition condition;
    private TestDeclarationModel.Declaration declaration;

    @Before
    public void setup() throws IOException, TimeoutException {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
        testRule = API.DataForTests.Rules.DraftNatRuleNatManager();
        condition = testRule.queryConditions.get(0).conditions.get(0);
        condition.operator = "neq";
        declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
    }

    private void commitRuleAndPublish(){
        EditRuleVersionResponse.PutResponse commitResponse = RuleAtStatus.CreateCommittedRule(testRule);
        assertThat(commitResponse.httpStatusCode)
                .describedAs("Failed to commit rule. response:\n"+commitResponse.body)
                .isEqualTo(200);
        publishAndWait(5000);
    }

    private DeclarationResponse riskDeclaration() {
        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());
        queue.send(declarationRequest);
        return new DeclarationResponse(queue.receive(), this::decryptField);
    }

    /*
     * domain field to value
     */
    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualValue_thenRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeCity_domain().attribute;
        condition.value = "Sidney";
        commitRuleAndPublish();

        declaration.consigneeCity = "Cape Town";
        declaration.consigneeCity_Item = "Edinburgh";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualValue_oneBlank_thenRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeCity_domain().attribute;
        condition.value = "Sidney";
        commitRuleAndPublish();

        declaration.consigneeCity = "Cape Town";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualValue_bothSame_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeCity_domain().attribute;
        condition.value = "Sid ney";
        commitRuleAndPublish();

        declaration.consigneeCity = " Sid  ney";
        declaration.consigneeCity_Item = " Sid  ney";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualValue_oneSame_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeCity_domain().attribute;
        condition.value = "Sidney";
        commitRuleAndPublish();

        declaration.consigneeCity = "Sidney";
        declaration.consigneeCity_Item = "Cape Town";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualValue_oneSameOneBlank_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeCity_domain().attribute;
        condition.value = "Sidney";
        commitRuleAndPublish();

        declaration.consigneeCity = "Sidney";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualValue_allBlank_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeCity_domain().attribute;
        condition.value = "Sidney";
        commitRuleAndPublish();

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    /*
     * domain field to field
     */
    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualField_thenRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeCity_domain().attribute;
        condition.value = Conditions.consignorCity_Header().attribute;
        commitRuleAndPublish();

        declaration.consigneeCity = "Paris";
        declaration.consigneeCity_Item = "Edinburgh";
        declaration.consignorCity_Header = "New York";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualField_oneDomainBlank_thenRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeCity_domain().attribute;
        condition.value = Conditions.consignorCity_Header().attribute;
        commitRuleAndPublish();

        declaration.consigneeCity = "Paris";
        declaration.consignorCity_Header = "New York";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualField_allSame_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeCity_domain().attribute;
        condition.value = Conditions.consignorCity_Header().attribute;
        commitRuleAndPublish();

        declaration.consigneeCity = "Paris";
        declaration.consigneeCity_Item = "Paris";
        declaration.consignorCity_Header = "Paris";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualField_oneSame_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeCity_domain().attribute;
        condition.value = Conditions.consignorCity_Header().attribute;
        commitRuleAndPublish();

        declaration.consigneeCity = "Paris";
        declaration.consigneeCity_Item = "New York";
        declaration.consignorCity_Header = "Paris";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualField_oneSameOneBlank_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeCity_domain().attribute;
        condition.value = Conditions.consignorCity_Header().attribute;
        commitRuleAndPublish();

        declaration.consigneeCity = "Paris";
        declaration.consignorCity_Header = "Paris";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualField_fieldBlank_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeCity_domain().attribute;
        condition.value = Conditions.consignorCity_Header().attribute;
        commitRuleAndPublish();

        declaration.consigneeCity = "Paris";
        declaration.consigneeCity_Item = "New York";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualField_oneBlankAndFieldBlank_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeCity_domain().attribute;
        condition.value = Conditions.consignorCity_Header().attribute;
        commitRuleAndPublish();

        declaration.consigneeCity_Item = "New York";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualField_allBlank_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeCity_domain().attribute;
        condition.value = Conditions.consignorCity_Header().attribute;
        commitRuleAndPublish();

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualValue_collectionMember_collectionContainsEmptyAndPopulatedDifferent_thenRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.country().attribute;
        condition.value = "UK";
        commitRuleAndPublish();

        declaration.countryRoute = "DE";
        declaration.countryRoute_Header = "";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualValue_collectionMember_collectionContainsPopulatedSame_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.country().attribute;
        condition.value = "UK";
        commitRuleAndPublish();

        declaration.countryRoute = "UK";
        declaration.countryRoute_Header = "UK";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualValue_collectionMember_collectionContainsPopulatedDifferentAndSame_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.country().attribute;
        condition.value = "UK";
        commitRuleAndPublish();

        declaration.countryRoute = "DE";
        declaration.countryRoute_Header = "UK";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualValue_collectionMember_collectionNotEqualButOtherMemberEqual_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.country().attribute;
        condition.value = "UK";
        commitRuleAndPublish();

        declaration.dispatchCountry = "UK";
        declaration.countryRoute = "DE";
        declaration.countryRoute_Header = "DE";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualValue_collectionMember_allMembersNotEqual_thenRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.country().attribute;
        condition.value = "UK";
        commitRuleAndPublish();

        declaration.dispatchCountry = "DE";
        declaration.dispatchCountry_Item = "DE";
        declaration.destinationCountry_Header = "DE";
        declaration.destinationCountry_Item = "DE";
        declaration.originCountry_Item = "DE";
        declaration.countryRoute = "DE";
        declaration.countryRoute_Header = "DE";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        Object[] matchResons = declarationResponse.getMatchReasons().get(0).stream().distinct().toArray();

        assertThat(matchResons).contains(
                "Declaration field: 'Dispatch Country' was not equal to a value in data domain: 'Country'.  The value was: 'DE'",
                "Declaration field: 'Destination Country' was not equal to a value in data domain: 'Country'.  The value was: 'DE'",
                "Goods Item (sequenceId=1) field: 'Destination Country' was not equal to a value in data domain: 'Country'.  The value was: 'DE'",
                "Goods Item (sequenceId=1) field: 'Dispatch Country' was not equal to a value in data domain: 'Country'.  The value was: 'DE'",
                "Goods Item (sequenceId=1) field: 'Origin Country' was not equal to a value in data domain: 'Country'.  The value was: 'DE'"
        );
    }

    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenFieldNotMatchesPatternValueEORI_thenNoRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.operator="notMatchesPattern";
        condition.attribute = Conditions.consigneeEori_domain().attribute;
        condition.value = "???TESTEORI";
        commitRuleAndPublish();

        declaration.consigneeEori_Item = "nottestEori";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_150.class, ChangeRequest.CRX_288.class})
    public void whenDomainFieldNotEqualValue_collectionMember_itemDifferent_collectionEmpty_thenRouteReturned() {
        condition.attributeType = DOMAIN;
        condition.conditionType = normal;
        condition.attribute = Conditions.country().attribute;
        condition.value = "GB";
        commitRuleAndPublish();

        declaration.destinationCountry_Header = "FR";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }
}
