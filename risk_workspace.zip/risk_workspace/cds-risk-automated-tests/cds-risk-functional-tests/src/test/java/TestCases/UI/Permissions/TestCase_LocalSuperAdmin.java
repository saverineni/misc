package TestCases.UI.Permissions;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Permissions;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.MenuToolBar;
import UI.CommonComponents.MenuToolBar_UserManagement;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static org.junit.Assert.assertTrue;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Permissions.class})
public class TestCase_LocalSuperAdmin extends BaseUIWebDriverTestCase{

    @Test
    public void WhenLocalSuperAdminLoggedIn_CorrectToolBarMenusDisplayed() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);

        //Act
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);
        MenuToolBar menuToolBar = new MenuToolBar(driver);

        //Assert
        assertTrue("Expect dashboardIcon to be displayed", menuToolBar.isElementDisplayed(menuToolBar.dashboardIcon) == true);
        assertTrue("Expect rulesManagement to be NOT displayed", menuToolBar.isElementDisplayed(menuToolBar.rulesManagement,1,false) == false);

        assertTrue("Expect dataManagement to be NOT displayed", menuToolBar.isElementDisplayed(menuToolBar.dataManagement) ==  true);
        assertTrue("Expect logout to be displayed", menuToolBar.isElementDisplayed(menuToolBar.logout) == true);

        assertTrue("Expect users to be displayed", menuToolBar.isElementDisplayed(menuToolBar.users) == true);
        assertTrue("Expect publish to be displayed", menuToolBar.isElementDisplayed(menuToolBar.publish) == true);
    }

    @Test
    public void WhenLocalSuperAdminLoggedIn_CorrectUserManagementMenusDisplayed() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);

        //Act
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);
        MenuToolBar menuToolBar = new MenuToolBar(driver);
        menuToolBar.users.click();
        MenuToolBar_UserManagement menuUM = new MenuToolBar_UserManagement(driver);
        
        //Assert
        assertTrue("Expect listUsers to be displayed",menuUM.isElementDisplayed(menuUM.listUsers) == true);
        assertTrue("Expect createUser to be displayed",menuUM.isElementDisplayed(menuUM.createUser) == true);
        assertTrue("Expect listUsersByLocation to be displayed",menuUM.isElementDisplayed(menuUM.listUsersByLocation) == true);
    }


}
