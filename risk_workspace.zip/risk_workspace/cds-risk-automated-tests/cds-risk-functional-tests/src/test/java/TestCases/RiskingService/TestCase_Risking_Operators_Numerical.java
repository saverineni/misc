package TestCases.RiskingService;

import API.DataForTests.Conditions;
import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestRuleModel.RuleDetails;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.Utils.RuleAtStatus;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service_Operators;
import TestCases.BaseWebAPITestCase;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeoutException;

import static API.DataForTests.TestRuleModel.RuleDetails.AttributeType.ITEM;
import static API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody;
import static org.assertj.core.api.Assertions.assertThat;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.normal;

@Slf4j
@Category(Risking_Service_Operators.class)
public class TestCase_Risking_Operators_Numerical extends BaseWebAPITestCase {

    public static final String NO_CONTROL_ROUTE = "";
    private RuleDetails testRule;
    private RuleDetails.Condition condition;
    private TestDeclarationModel.Declaration declaration;

    @Before
    public void setup() throws IOException, TimeoutException {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
        testRule = API.DataForTests.Rules.DraftNatRuleNatManager();
        condition = testRule.queryConditions.get(0).conditions.get(0);
        condition.operator = "eq";
        declaration = new TestDeclarationModel.Declaration();
        declaration.sequenceNumber = "1";
        declaration.reportBackElementsExpectedValue += declaration.sequenceNumber + "\"]";
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
    }

    private void commitRuleAndPublish(){
        EditRuleVersionResponse.PutResponse commitResponse = RuleAtStatus.CreateCommittedRule(testRule);
        assertThat(commitResponse.httpStatusCode)
                .describedAs("Failed to commit rule. response:\n"+commitResponse.body)
                .isEqualTo(200);
        publishAndWait(5000);
    }

    private DeclarationResponse riskDeclaration() {
        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());
        queue.send(declarationRequest);
        return new DeclarationResponse(queue.receive());
    }

    /*
     * less than
     */
    @Test
    @Category({ChangeRequest.CR_1624.class})
    public void whenNumericLT_fieldLT_thenRouteReturned() throws Throwable {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.statisticalValue().attribute;
        condition.value = "10";
        condition.operator = "lt";
        commitRuleAndPublish();

        declaration.statisticalValue = "9";

        DeclarationResponse declarationResponse = riskDeclaration();
        List<String> reportBackElements = declarationResponse.getReportBackElements();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
        assertThat(reportBackElements)
                .hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CR_1624.class})
    public void whenNumericLT_fieldEQ_thenNoRouteReturned() throws Throwable {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.statisticalValue().attribute;
        condition.value = "10";
        condition.operator = "lt";
        commitRuleAndPublish();

        declaration.statisticalValue = "10";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CR_1624.class})
    public void whenNumericLT_fieldGT_thenNoRouteReturned() throws Throwable {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.statisticalValue().attribute;
        condition.value = "10";
        condition.operator = "lt";
        commitRuleAndPublish();

        declaration.statisticalValue = "11";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenNumericLT_fieldEmpty_thenNoRouteReturned() throws Throwable {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.statisticalValue().attribute;
        condition.value = "10";
        condition.operator = "lt";
        commitRuleAndPublish();

        declaration.statisticalValue = "";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    /*
     * less than or equal to
     */
    @Test
    @Category({ChangeRequest.CR_1624.class})
    public void whenNumericLTE_fieldLT_thenRouteReturned() throws Throwable {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.statisticalValue().attribute;
        condition.value = "10";
        condition.operator = "lte";
        commitRuleAndPublish();

        declaration.statisticalValue = "9";

        DeclarationResponse declarationResponse = riskDeclaration();
        List<String> reportBackElements = declarationResponse.getReportBackElements();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
        assertThat(reportBackElements)
                .hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CR_1624.class})
    public void whenNumericLTE_fieldEQ_thenRouteReturned() throws Throwable {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.statisticalValue().attribute;
        condition.value = "10";
        condition.operator = "lte";
        commitRuleAndPublish();

        declaration.statisticalValue = "10";

        DeclarationResponse declarationResponse = riskDeclaration();
        List<String> reportBackElements = declarationResponse.getReportBackElements();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
        assertThat(reportBackElements)
                .hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CR_1624.class})
    public void whenNumericLTE_fieldGT_thenNoRouteReturned() throws Throwable {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.statisticalValue().attribute;
        condition.value = "10";
        condition.operator = "lte";
        commitRuleAndPublish();

        declaration.statisticalValue = "11";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenNumericLTE_fieldEmpty_thenNoRouteReturned() throws Throwable {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.statisticalValue().attribute;
        condition.value = "10";
        condition.operator = "lte";
        commitRuleAndPublish();

        declaration.statisticalValue = "";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }


    /*
     * greater than
     */
    @Test
    @Category({ChangeRequest.CR_1624.class})
    public void whenNumericGT_fieldGT_thenRouteReturned() throws Throwable {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.statisticalValue().attribute;
        condition.value = "10";
        condition.operator = "gt";
        commitRuleAndPublish();

        declaration.statisticalValue = "11";

        DeclarationResponse declarationResponse = riskDeclaration();
        List<String> reportBackElements = declarationResponse.getReportBackElements();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
        assertThat(reportBackElements)
                .hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CR_1624.class})
    public void whenNumericGT_fieldET_thenNoRouteReturned() throws Throwable {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.statisticalValue().attribute;
        condition.value = "10";
        condition.operator = "gt";
        commitRuleAndPublish();

        declaration.statisticalValue = "10";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CR_1624.class})
    public void whenNumericGT_fieldLT_thenNoRouteReturned() throws Throwable {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.statisticalValue().attribute;
        condition.value = "10";
        condition.operator = "gt";
        commitRuleAndPublish();

        declaration.statisticalValue = "9";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenNumericGT_fieldEmpty_thenNoRouteReturned() throws Throwable {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.statisticalValue().attribute;
        condition.value = "10";
        condition.operator = "gt";
        commitRuleAndPublish();

        declaration.statisticalValue = "";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    /*
     * greater than or equal to
     */
    @Test
    @Category({ChangeRequest.CR_1624.class})
    public void whenNumericGTE_fieldGT_thenRouteReturned() throws Throwable {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.statisticalValue().attribute;
        condition.value = "10";
        condition.operator = "gte";
        commitRuleAndPublish();

        declaration.statisticalValue = "11";

        DeclarationResponse declarationResponse = riskDeclaration();
        List<String> reportBackElements = declarationResponse.getReportBackElements();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
        assertThat(reportBackElements)
                .hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CR_1624.class})
    public void whenNumericGTE_fieldEQ_thenRouteReturned() throws Throwable {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.statisticalValue().attribute;
        condition.value = "10";
        condition.operator = "gte";
        commitRuleAndPublish();

        declaration.statisticalValue = "10";

        DeclarationResponse declarationResponse = riskDeclaration();
        List<String> reportBackElements = declarationResponse.getReportBackElements();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
        assertThat(reportBackElements)
                .hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CR_1624.class})
    public void whenNumericGTE_fieldLT_thenNoRouteReturned() throws Throwable {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.statisticalValue().attribute;
        condition.value = "10";
        condition.operator = "gte";
        commitRuleAndPublish();

        declaration.statisticalValue = "9";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenNumericGTE_fieldEmpty_thenNoRouteReturned() throws Throwable {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.statisticalValue().attribute;
        condition.value = "10";
        condition.operator = "gte";
        commitRuleAndPublish();

        declaration.statisticalValue = "";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }


    /*
    * equals
     */
    @Test
    public void whenNumericEQ_fieldEQ_thenRouteReturned() throws Throwable {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.statisticalValue().attribute;
        condition.value = "10";
        condition.operator = "eq";
        commitRuleAndPublish();

        declaration.statisticalValue = "10";

        DeclarationResponse declarationResponse = riskDeclaration();
        List<String> reportBackElements = declarationResponse.getReportBackElements();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
        assertThat(reportBackElements)
                .hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }
    @Test
    @Category({ChangeRequest.CRX_150.class})
    public void whenNumericEQ_fieldNEQ_thenNoRouteNotReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.commodityNetMass().attribute;
        condition.operator="eq";
        condition.value = "200.1";
        commitRuleAndPublish();

        declaration.commodityNetMass = "0";
        DeclarationResponse declarationResponse1 = riskDeclaration();
        assertThat(declarationResponse1.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
    @Test
    @Category({ChangeRequest.CRX_310.class})
    public void whenNumericEQ_fieldEmpty_thenNoRouteNotReturned() {
        condition.attributeType = ITEM;
        condition.conditionType = normal;
        condition.attribute = Conditions.commodityNetMass().attribute;
        condition.operator="eq";
        condition.value = "200.1";
        commitRuleAndPublish();

        declaration.commodityNetMass = "";
        DeclarationResponse declarationResponse1 = riskDeclaration();
        assertThat(declarationResponse1.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }
}
