
//TODO DMS doesn't support control agent in the repsonse. This might be needed again
// in the future

//package TestCases.RiskingServiceJava.ManualIntervention;
//
//import Categories_CDSRisk.ChangeRequest_RiskingService;
//import Categories_CDSRisk.Risking_JavaService;
//import TestCases.RiskingServiceJava.BaseRiskingServiceJava;
//import lombok.SneakyThrows;
//import org.assertj.core.api.Assertions;
//import org.junit.Before;
//import org.junit.Ignore;
//import org.junit.Test;
//import org.junit.experimental.categories.Category;
//import uk.gov.hmrc.risk.test.common.enums.HeaderAttribute;
//import uk.gov.hmrc.risk.test.common.enums.HeaderDeclarationParam;
//import uk.gov.hmrc.risk.test.common.enums.Operator;
//import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
//import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel;
//import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel.Query;
//import uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.Condition;
//import uk.gov.hmrc.risk.test.common.service.DockerSupport;
//
//import java.nio.file.Paths;
//import java.util.Arrays;
//
//@Category({ChangeRequest_RiskingService.CREP_439.class, ChangeRequest_RiskingService.CREP_440.class, Risking_JavaService.class})
//@Ignore("This functionality is likely to change")
//public class TestCase_ChooseTeam extends BaseRiskingServiceJava{
//
//    /*Currently the combination of which team is responsible for which locations is hardcoded as:
//    * Group               Goods Location      Team Name   ID
//        BORDER_FORCE        MCR                 VGEM     TEAM_01
//        BORDER_FORCE        LHR                 Team01   TEAM_02
//        BORDER_FORCE        POO                 Team02   TEAM_02
//
//    What this means is: when on the rule the Group is set a BORDER_FORCE and header attribute Goods location is set to one of the
//    values, then the corresponding team should be set in the response.
//
//    If the team is set then the that team should be present in the response.
//
//    If nothing is set in the rule, Team01 is the current default
//    */
//
//
//    private final String GROUP = "BORDER_FORCE";
//
//    @Before
//    public void setup()
//    {
//        copyFileToContainer();
//        assigneeServiceSupport.refreshAssigneeCache();
//    }
//
//    @Test
//    @Ignore("Rule service doesn't allow such a rule")
//    public void WhenTeamAndGroupAreNull_ControlAgentIsSetToDefaultInResponse() {
//
////        createRule(null, null, null);
//
//        DeclarationResponse response = sendDeclaration("POO");
//
//        //Note when default team we always get back VGEM
//        Assertions.assertThat(response.getControlAgent()).hasSize(1).contains("VGEM");
//    }
//
//    @Test
//    @Ignore("It's not confirmed that this is an AC")
//    public void WhenTeamIsSpecifiedAndDifferentLocationIsSent_CorrectTeamIsSetInResponse() {
//        createRule(null, null, "0003");
//
//        DeclarationResponse response = sendDeclaration("MAN");
//
//        Assertions.assertThat(response.getControlAgent()).hasSize(1).contains("Team03");
//    }
//
//    @Test
//    public void WhenTeamIsSpecifiedAndCorrectLocationIsSent_CorrectTeamIsSetInResponse() {
//        createRule(null, null, "0003");
//
//        DeclarationResponse response = sendDeclaration("POO");
//
//        Assertions.assertThat(response.getControlAgent()).hasSize(1).contains("Team03");
//    }
//
//    @Test
//    @Ignore("Group cannot be set at the moment")
//    public void WhenGroupAndDeclarationSetButTeamIsSpecified_CorrectTeamIsSetInResponse() {
//        createRule(GROUP, "Team03", "");
//
//        DeclarationResponse response = sendDeclaration("LHR");
//
//        Assertions.assertThat(response.getControlAgent()).hasSize(1).contains("Team03");
//    }
//
//    @Test
//    @Ignore("Group cannot be set at the moment")
//    public void WhenDefaultGroupAndGoodsLocationIsSetToLHR_ControlAgentIsTeam01() {
//        createRule(GROUP, null, "");
//
//        DeclarationResponse response = sendDeclaration("LHR");
//
//        Assertions.assertThat(response.getControlAgent()).hasSize(1).contains("Team01");
//    }
//
//    @Test
//    @Ignore("Group cannot be set at the moment")
//    public void WhenDefaultGroupAndGoodsLocationIsSetToMAN_ControlAgentIsTeam01() {
//        createRule(GROUP, null, "");
//
//        DeclarationResponse response = sendDeclaration("MAN");
//
//        Assertions.assertThat(response.getControlAgent()).hasSize(1).contains("Team03");
//    }
//
//    @Test
//    @Ignore("Group cannot be set at the moment")
//    public void WhenDefaultGroupAndGoodsLocationIsSetToPOO_ControlAgentIsTeam02() {
//        createRule(GROUP, null, "");
//
//        DeclarationResponse response = sendDeclaration("POO");
//
//        Assertions.assertThat(response.getControlAgent()).hasSize(1).contains("Team04");
//    }
//
//    @Test
//    @Ignore("There is a bug at the moment that sets the team empty when empty string is sent. Should be default team")
//    public void WhenDefaultGroupAndGoodsLocationIsSetToPOOTeamIsSetToEmpty_ControlAgentIsTeam02() {
//        createRule(GROUP, "", "");
//
//        DeclarationResponse response = sendDeclaration("POO");
//
//        Assertions.assertThat(response.getControlAgent()).hasSize(1).contains("Team01");
//    }
//
//    private DeclarationResponse sendDeclaration(String goodsLocationValue) {
//
//        Condition goodsLocation = Condition.builder()
//                .declarationParam(HeaderDeclarationParam.GOODS_LOCATION)
//                .declarationValue( goodsLocationValue )
//                .build();
//
////        Condition locationId = Condition.builder()
////                .declarationParam(HeaderDeclarationParam.PREMISES_ID)
////                .declarationValue( Collections.singletonList(Locations.Location_POO_UID ).get(0))
////                .build();
//
//        Condition condition = Condition.builder()
//                .declarationParam(HeaderDeclarationParam.PAYING_AGENT)
//                .declarationValue("1234567890")
//                .build();
//
//        return createAndSendDeclaration( Arrays.asList( condition, goodsLocation ));
//    }
//
//    private void createRule(String groupName, String teamName, String id) {
//
//        CreateRuleModel model = createRuleModel();
////        model.getRuleOutputs().getAssignee().setDescription(teamName);
//////        model.getRuleOutputs().getAssignee().setId("0003");
//////        model.getRuleOutputs().getAssignee().setLocation("POO");
////        model.getRuleOutputs().getAssignee().setGroup(groupName);
//        model.getRuleOutputs().setInformationNarrative("Default information narrative");
//        model.getRuleOutputs().setAssigneeId(id);
//        model.getRuleOutputs().setActionType("5");
//
//        Query query = Query.builder()
//                .attribute(HeaderAttribute.PAYING_AGENT_EORI.toString())
//                .operator(Operator.nco.toString())
//                .isDataTable(false)
//                .value("0000000000")
//                .build();
//
//        model.getQuery().get(0).setQuery(Arrays.asList( query ));
//
//        createAndRefreshRule(model);
//    }
//
//    @SneakyThrows
//    private void copyFileToContainer()
//    {
//        DockerSupport.ContainerAccessor assigneeServiceContainer = dockerSupport.getAssigneeServiceContainer();
//
//        dockerSupport.copyFileToContainer(Paths.get(ClassLoader.getSystemResource("TestData/RiskingData/assignee2/").toURI()),
//                assigneeServiceContainer.getShortId(),
//                "/tmp");
//
//    }
//}