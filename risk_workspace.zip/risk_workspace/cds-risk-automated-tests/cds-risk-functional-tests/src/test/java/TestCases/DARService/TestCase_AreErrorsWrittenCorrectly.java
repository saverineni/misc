package TestCases.DARService;


import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.DAR_Client;
import TestCases.RiskingServiceJava.BaseRiskingServiceJava;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.DarEventType;
import uk.gov.hmrc.risk.test.common.enums.DeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.HeaderDeclarationParam;
import uk.gov.hmrc.risk.test.common.model.darService.DarErrorModel;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleCreationModel;

import java.time.ZonedDateTime;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
@Category({ChangeRequest_RiskingService.CREP_333.class, DAR_Client.class})
public class TestCase_AreErrorsWrittenCorrectly extends BaseRiskingServiceJava {

    private UUID declarationId;

    @Test
    public void WhenServerErrorOccur_ItsCorrectlyWritten() throws Exception {
        declarationId = UUID.randomUUID();
        RuleCreationModel model = baseRuleCreationModelBuilder().build();
        model.getJson().setBehaviours(new ArrayList<>());
        rulesSupport.createActiveRule(model, appStateSupport.getLoggedInUserPID());
        publishAndWait(5000);

        Map<DeclarationParam, String> declarationFields = new HashMap<>();
        declarationFields.put(HeaderDeclarationParam.DECLARATION_REFERENCE, declarationId.toString());
        declarationFields.put(HeaderDeclarationParam.DISPATCH_COUNTRY, "DE");

        sendDeclaration(declarationFields, true, true);

        List<DarErrorModel> logs = darServiceAuditSupport.parseErrorEvents();

        String expectedMessage = "Unknown Exception: Behaviour of type: DEFAULT not found for rule Id:";
        String exceptiionType = "uk.gov.hmrc.risk.riskingservice.postprocess." +
                "ResultEnrichmentFailureException$BehaviourNotFoundException";

        List<DarErrorModel> filtered = new ArrayList<>();
        logs.stream().filter(log -> getLatestErrorLog(log, exceptiionType)).forEach(filtered::add);
        assertThat(filtered.size()).isNotZero();

        filtered.stream().filter(log ->
                log.getDeclarationId().equals(declarationId.toString())).forEach(log ->
        {
            assertThat(log.getType()).isEqualTo(DarEventType.DECLARATION_RISKING_ERROR.toString());
            assertThat(log.getErrorMessage()).contains(expectedMessage);
            assertThat(log.getDeclarationId()).isEqualTo(declarationId.toString());
            assertThat(log.getRiskResponseId()).isNotEmpty();
            assertThat(log.getDeclarationVersion()).isEqualTo("1");
            assertThat(log.getRulesPackage()).isNotEmpty();
            assertThat(log.getExceptionType()).isEqualTo("uk.gov.hmrc.risk.riskingservice.postprocess.ResultEnrichmentFailureException$BehaviourNotFoundException");
            assertThat(log.getSoapErrorType()).isEqualTo("SERVER");
        });
    }

    @Test
    public void WhenSoapErrorOccur_ItsCorrectlyWritten() {
        declarationId = UUID.randomUUID();
        String incorrectDeclaration = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"\n" +
                ">\n" +
                "    <soapenv:Header/>\n" +
                "    <soapenv:Body>\n" +
                "            <riskAssessmentRequest>\n" +
                "                <_30_1:id>" + declarationId + "</_30_1:id>\n" +
                "                <_30_2:object>\n" +
                "                    <_30_3:declarationWithResults>\n" +
                "                        <_30_5:modeOfEntry>5</_30_5:modeOfEntry> <!-- 1, 2 or 3 -->\n" +
                "                    </_30_3:declarationWithResults>\n" +
                "                </_30_2:object>\n" +
                "            </riskAssessmentRequest>\n" +
                "        </_30:initiateRiskAssessment>\n" +
                "    </soapenv:Body>\n" +
                "</soapenv:Envelope>";

        queue.send(incorrectDeclaration);
        new DeclarationResponse(queue.receive(), true);

        List<DarErrorModel> logs = darServiceAuditSupport.parseErrorEvents();

        String expectedMessage = "Error unmarshalling message to RiskAssessmentRequest";
        String exceptionType = "javax.xml.xpath.XPathExpressionException";

        List<DarErrorModel> filtered = new ArrayList<>();
        logs.stream().filter(log -> getLatestErrorLog(log, exceptionType)).forEach(filtered::add);
        assertThat(filtered.size()).isNotZero();
        filtered.forEach(log -> {
            assertThat(log.getType()).isEqualTo(DarEventType.DECLARATION_RISKING_ERROR.toString());
            assertThat(log.getErrorMessage()).contains(expectedMessage);
            assertThat(log.getRiskResponseId()).isNotEmpty();
            assertThat(log.getDeclarationVersion()).isEqualTo("");
            assertThat(log.getExceptionType()).isEqualTo("javax.xml.xpath.XPathExpressionException");
            assertThat(log.getSoapErrorType()).isEqualTo("CLIENT");
        });
    }

    private boolean getLatestErrorLog(DarErrorModel model, String exceptionType) {
        ZonedDateTime now = ZonedDateTime.now();
        ZonedDateTime modelTime = darServiceAuditSupport.getFormattedTimestamp(model.getTime());

        return modelTime.isAfter(now.minusMinutes(1)) &&
                model.getExceptionType().equals(exceptionType);
    }
}
