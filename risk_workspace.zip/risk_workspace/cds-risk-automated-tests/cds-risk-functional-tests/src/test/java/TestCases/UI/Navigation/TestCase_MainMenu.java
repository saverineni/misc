package TestCases.UI.Navigation;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Navigation;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.MenuToolBar;
import UI.Pages.RulesManagement.CreateLocalRule_Page;
import UI.Pages.RulesManagement.RulesDashboard_Page;
import UI.Utils.Navigation;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.assertTrue;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Navigation.class})
public class TestCase_MainMenu extends BaseUIWebDriverTestCase{


    @Test
    public void WhenUserNavigatesToRulesManagement_CorrectPageDisplayed() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);

        //Act
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);
        MenuToolBar menuToolBar = new MenuToolBar(driver);
        menuToolBar.rulesManagement.click();

        RulesDashboard_Page rulesDashboard_page = new RulesDashboard_Page(driver);

        //Assert
        assertEquals(rulesDashboard_page.getTitle(), driver.getTitle());

        assertTrue("Expect section head to be present", rulesDashboard_page.isElementDisplayed(rulesDashboard_page.sectionHeader,1,false) == true);
        String actSectionHeader = rulesDashboard_page.sectionHeader.getText();
        assertEquals("Rule Management", actSectionHeader);
    }

    @Test
    public void WhenUserNavigatesToRulesManagementCreateLocalRule_CorrectPageDisplayed() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);

        //Act
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);
        MenuToolBar menuToolBar = new MenuToolBar(driver);
        menuToolBar.rulesManagement.click();

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        //Assert
        assertEquals(createLocalRule_page.getTitle(), driver.getTitle());

        assertTrue("Expect section head to be present", createLocalRule_page.isElementDisplayed(createLocalRule_page.sectionHeaderRuleID) == true);
        String actSectionHeader = createLocalRule_page.sectionHeaderRuleID.getText();

        assertEquals("Create Risk Rule", actSectionHeader);
    }


}
