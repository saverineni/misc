package TestCases.RulesManagementService;


import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.ViewRule.ViewRuleResponse;
import Categories_CDSRisk.CDS_RM_RuleLifeCycle;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import static API.RulesManagementService.Utils.Publish.getPublishHistory;
import static API.RulesManagementService.Utils.Publish.publishEvent;
import static API.RulesManagementService.Utils.Users.LoginAsNationalRulesManagerDefaultTestAutomationUser;
import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.assertEquals;


@Category({Rules_Management.class, CDS_RM_RuleLifeCycle.class})
public class TestCase_ActiveRule extends BaseWebAPITestCase {

    @Test
    @Category({ChangeRequest.CR_1882.class,ChangeRequest.CR_3100.class})
    public void WhenRuleCommittedAndPublished_RuleStatusChangesToActive() throws Throwable
    {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Arrange
        TestUserModel.UserDetails superAdminUser = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(superAdminUser);

        String reasonForPublishing = "Rule status check for the rule "+ruleDetails.description;
        publishEvent(reasonForPublishing);

        //Act
        Response response = getPublishHistory();
        ValidatableResponse validatableResponse = response.then();

        validatableResponse
                .body("content.reason", hasItem(reasonForPublishing));

        LoginAsNationalRulesManagerDefaultTestAutomationUser();

        ViewRuleResponse.ViewRuleResponseObject ruleResponseAfterPublish = API.RulesManagementService.Utils.Rules.GetRuleByUID(commitResponse.uniqueId);

        //Assert the status is active. As there are no upcoming its size should be zeo
        assertEquals(TestEnumerators.RuleStatus.active.toString(), ruleResponseAfterPublish.response.path("versions[0].status"));
        assertEquals(0, ruleResponseAfterPublish.upcoming.size());

    }

}
