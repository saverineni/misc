package TestCases.RulesManagementService;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_RM_RuleLifeCycle;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;

import static API.EnvDetails.EnvDetails.url_PS_ChangePublishInterval;
import static API.RulesManagementService.Utils.Publish.*;
import static FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays;
import static java.time.format.DateTimeFormatter.ISO_DATE_TIME;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertEquals;

@Slf4j
@Category({Rules_Management.class, CDS_RM_RuleLifeCycle.class})
public class TestCase_Publish extends BaseWebAPITestCase {

    @Test
    @Category(ChangeRequest.CR_1750.class)
    public void WhenAManualPublishIsTriggeredBySuperAdmin_EventIsPublished() throws Throwable
    {
        //Arrange
        TestUserModel.UserDetails superAdminUser = Users_API.DefaultSuperAdminUser();
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        String reasonForPublishing = "Publishing in emergency";
        Response response = publishEvent(reasonForPublishing);
        //Assert
        assertEquals(HttpStatus.SC_OK, response.statusCode());
    }

    @Test
    @Category(ChangeRequest.CR_1750.class)
    public void WhenAManualPublishTriggeredBySuperAdminNat_EventIsPublished() throws Throwable
    {
        //Arrange
        TestUserModel.UserDetails superAdminNational = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(superAdminNational);

        String reasonForPublishing = "Publishing in emergency";
        Response response = publishEvent(reasonForPublishing);
        //Assert
        assertEquals(HttpStatus.SC_OK, response.statusCode());
    }

    @Test
    @Category(ChangeRequest.CR_1750.class)
    public void WhenAManualPublishTriggeredByAdminNational_EventIsPublished() throws Throwable
    {
        //Arrange
        TestUserModel.UserDetails adminNational = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(adminNational);

        String reasonForPublishing = "Publishing in emergency";
        Response response = publishEvent(reasonForPublishing);
        //Assert
        assertEquals(HttpStatus.SC_OK, response.statusCode());
    }

    @Test
    @Category(ChangeRequest.CR_1750.class)
    public void WhenAManualPublishTriggeredByAdminLocal_EventIsPublished() throws Throwable
    {
        //Arrange
        TestUserModel.UserDetails adminNational = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(adminNational);

        String reasonForPublishing = "Publishing in emergency";
        Response response = publishEvent(reasonForPublishing);
        //Assert
        assertEquals(HttpStatus.SC_OK, response.statusCode());
    }

    @Test
    @Category(ChangeRequest.CR_1750.class)
    public void WhenAManualPublishIsTriggeredWithNoPublishReason_BadRequestReturned() throws Throwable
    {
        //Arrange
        TestUserModel.UserDetails superAdminUser = Users_API.DefaultSuperAdminUser();
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        String reasonForPublishing = "";
        Response response = publishEvent(reasonForPublishing);
        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, response.statusCode());
    }

    @Test
    @Category(ChangeRequest.CR_1750.class)
    public void WhenAManualPublishWithReasonMaxLength_EventPublished() throws Throwable
    {
        //Arrange
        TestUserModel.UserDetails superAdminUser = Users_API.DefaultSuperAdminUser();
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        String reasonForPublishing = "123456&*()123456&*()123456&*()123456&*()123456&*()123456&*()";
        Response response = publishEvent(reasonForPublishing);

        //Assert
        assertEquals(HttpStatus.SC_OK, response.statusCode());
    }

    @Test
    @Category(ChangeRequest.CR_1750.class)
    public void WhenAManualPublishWithReasonOverMaxLengthAllowed_BadRequestReturned() throws Throwable
    {
        //Arrange
        TestUserModel.UserDetails superAdminUser = Users_API.DefaultSuperAdminUser();
        API.RulesManagementService.Utils.Users.LoginAsSuperAdmin();

        String reasonForPublishing = "123456789012345678901234567890123456789012345678901234567890!";
        Response response = publishEvent(reasonForPublishing);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, response.statusCode());
    }

    @Test
    @Category(ChangeRequest.CR_1783.class)
    @Ignore("Failing test, incoprporate later")
    public void WhenManualPublishTriggered_CorrectPublishEventDataIsReturned() throws Throwable
    {
        //Arrange
        TestUserModel.UserDetails superAdminUser = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(superAdminUser);

        mySQL_cds_publishing.deletePublishHistoryDataFromDB();

        //set time interval for auto publish to 0 so that it does not interfere with manual publish
        setPublishAutomaticEventTime("18000");

        Response response = getPublishHistory();
        ValidatableResponse validatableResponse = response.then();

        validatableResponse
                .statusCode(200)
                .body("totalElements", Matchers.equalTo(0));

        String reasonForPublishing = "Manual Publish in emergency";
        publishEvent(reasonForPublishing);

        response = getPublishHistory();
        validatableResponse = response.then();

        log.debug("Total Publish events : " + response.path("numberOfElements"));
        log.debug("Total Publish reason : " + response.path("content[0].reason"));
        log.debug("Total Publish timeStamp : " + response.path("content[0].publishTimestamp"));
        log.debug("Total Publish timeStamp : " + response.path("content[0].publisherPid"));

        //Assert
        validatableResponse
                .body("content.publisherPid", hasItem(superAdminUser.pid))
                .body("content.reason", hasItem(reasonForPublishing))
                .body("content.publishTimestamp", notNullValue());

    }

    @Test
    @Category({ChangeRequest.CR_1783.class,ChangeRequest.CR_2645.class})
    public void WhenPublishEventTimeIsSet_PublishHistoryTableIsUpdatedWithCorrectEvents() throws Throwable
    {
        log.debug("the publish time change url :" + url_PS_ChangePublishInterval);
        //Arrange
        TestUserModel.UserDetails superAdminUser = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(superAdminUser);

        String timeInSeconds = "2";
        setPublishAutomaticEventTime(timeInSeconds, superAdminUser.pid);

        //Make sure the automated event is published- its set to 2 seconds
        Thread.sleep(4000);
        Response response = getPublishHistory();
        ValidatableResponse validatableResponse = response.then();

        validatableResponse
                .statusCode(200)
                .body("totalElements", Matchers.greaterThanOrEqualTo(0));

        String reasonForPublishing = "Automated test - Manual Publish Event";
        publishEvent(reasonForPublishing);

        response = getPublishHistory();
        validatableResponse = response.then();

        log.debug("Total Publish events : " + response.path("numberOfElements"));
        log.debug("Manual Publish reason : " + response.path("content[0].reason"));
        log.debug("Total Publish timeStamp : " + response.path("content[0].publishTimestamp"));
        log.debug("Total Publish pid : " + response.path("content[0].publisherPid"));

        //Assert fot the publish interval set
        assertEquals(timeInSeconds,getPublishTime(superAdminUser.pid).path("interval").toString());
        //assert
        validatableResponse
                .body("content.publisherPid", hasItem(superAdminUser.pid))
                .body("content.reason", hasItems(reasonForPublishing, "Automated Publish"));
    }

    @Test
    @Category(ChangeRequest.CR_1761.class)
    public void WhenNextScheduledPublishEventTimeIsSet_nextPublishTimestampIsReturned() throws Throwable {
        log.debug("the publish time change url :" + url_PS_ChangePublishInterval);

        //Arrange
        TestUserModel.UserDetails superAdminUser = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(superAdminUser);

        //set it for next day
        String timeInSeconds = "87000";
        setPublishAutomaticEventTime(timeInSeconds);

        Thread.sleep(400);
        Response response = getPublishHistory();
        ValidatableResponse validatableResponse = response.then();

        validatableResponse
                .statusCode(200)
                .body("totalElements", Matchers.greaterThanOrEqualTo(0));

        //act
        Response response1 = getNextPublishEvent();

        String date = AdjustLocalDateTimeNowByXDays(1, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        String nextDay = date.substring(0, 10);
        String next = response1.path("nextPublishTimestamp");
        String nextPublish = next.substring(0, 10);

        log.debug("\r\n" +"Next Publish event is set to : " + nextPublish + "\r\n");

        //assert
        assertEquals(nextPublish, nextDay);
    }

    @Test
    @Category({ChangeRequest.CR_1761.class,ChangeRequest.CR_2645.class})
    public void WhenPublishIntervalIsChanged_NextPublishShouldBeCorrect() throws Throwable {
         //Arrange
        TestUserModel.UserDetails superAdminUser = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(superAdminUser);
        
        //Act
        //set it for 3 minutes initially
        String timeInSeconds = "180";
        setPublishAutomaticEventTime(timeInSeconds);
        LocalDateTime initialExpectedPublishTime = LocalDateTime.now(ZoneId.of("UTC")).plusMinutes(3);
        Response nextPublishEventResponse = getNextPublishEvent();
        LocalDateTime initialActualPublishTime = LocalDateTime.parse(nextPublishEventResponse.path("nextPublishTimestamp"), ISO_DATE_TIME);

        //Change to 1 minute
        timeInSeconds = "60";
        setPublishAutomaticEventTime(timeInSeconds);
        LocalDateTime changedExpectedPublishTime = LocalDateTime.now(ZoneId.of("UTC")).plusMinutes(1);
        nextPublishEventResponse = getNextPublishEvent();
        LocalDateTime changedActualPublishTime = LocalDateTime.parse(nextPublishEventResponse.path("nextPublishTimestamp"), ISO_DATE_TIME);

        //assert
        assertThat(initialExpectedPublishTime).isCloseTo(initialActualPublishTime, within(30, ChronoUnit.SECONDS));
        assertThat(changedExpectedPublishTime).isCloseTo(changedActualPublishTime, within(30, ChronoUnit.SECONDS));
    }

}
