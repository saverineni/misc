package TestCases.zTempTests;

import TestCases.UI.BaseUIWebDriverTestCase;
import org.junit.Test;


public class TestUI1 extends BaseUIWebDriverTestCase {

    @Test
    public void Test1_Login()
    {
        UI.Pages.Login_Page login_page = new UI.Pages.Login_Page(driver);
        login_page.pid.setValue("1234560");
        login_page.clickLoginButton();
    }

}
