package TestCases.RulesManagementService;

import API.RulesManagementService.RuleMeta.RuleMetaResponse;
import API.RulesManagementService.Utils.Rules;
import Categories_CDSRisk.CDS_RM_RulesGeneral;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import com.google.common.collect.ImmutableList;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_RulesGeneral.class})
public class TestCase_RuleMeta extends BaseWebAPITestCase {

    @Test
    public void WhenRuleMetaServiceCalled_CorrectConditionAttributesReturned() {

        //Arrange

        //Act
        RuleMetaResponse.ViewRuleMetaResponseObject viewRuleMetaResponseObject = Rules.GetRuleMeta();

        //Assert
        ImmutableList<String> attributeList = ImmutableList.of
                (
                        "Country (Domain)",
                        "Consignor Address (Domain)",
                        "Consignor City (Domain)",
                        "Consignor Country (Domain)",
                        "Consignor EORI (Domain)",
                        "Consignor Name (Domain)",

                        "Consignee Address (Domain)",
                        "Consignee City (Domain)",
                        "Consignee Country (Domain)",
                        "Consignee EORI (Domain)",
                        "Consignee Name (Domain)",
                        "Consignee Postcode (Domain)",
                        "Consignor Postcode (Domain)",

                        "Dispatch Country (Domain)",
                        "Destination Country (Domain)",
                        "EORI (Domain)",

                        "Transport Charge MOP (Domain)",

                        "Consignee Address (Header)",
                        "Consignee City (Header)",
                        "Consignee Country (Header)",
                        "Consignee EORI (Header)",
                        "Consignee Name (Header)",
                        "Consignee Postcode (Header)",
                        "Consignor Address (Header)",
                        "Consignor City (Header)",
                        "Consignor Country (Header)",
                        "Consignor EORI (Header)",
                        "Consignor Name (Header)",
                        "Consignor Postcode (Header)",

                        "Consignment Reference (Header)",

                        "Representative Function (Header)",
                        "Declarant Address (Header)",
                        "Declarant City (Header)",
                        "Declarant Country (Header)",
                        "Declarant EORI (Header)",
                        "Declarant Name (Header)",
                        "Declarant Postcode (Header)",
                        "Destination Country (Header)",
                        "Dispatch Country (Header)",

                        "Freight Charge (Header)",
                        "Freight Charge Currency (Header)",

                        "Gross Mass Sum (Header)",

                        "Item Count (Header)",
                        "Invoice Currency (Header)",
                        "Invoice Total (Header)",
                        "Inland Mode of Transport (Header)",

                        "Mode Of Entry (Header)",

                        "Office of Exit (Header)",

                        "Paying Agent EORI (Header)",

                        "Representative Address (Header)",
                        "Representative City (Header)",
                        "Representative Country (Header)",
                        "Representative EORI (Header)",
                        "Representative Name (Header)",
                        "Representative Postcode (Header)",

                        "Specific Circumstance (Header)",

                        "Traders Own Reference (Header)",
                        "Transport Country (Header)",
                        "Transport Identifier (Header)",
                        "Transport MOP (Header)",
                        "Total Packages (Header)",

                        "Unique Consignment Reference (Header)",

                        //NEW
                        "Goods Arrival Indicator (Header)",
                        "Customs Value (Header)",
                        "Declared Customs Value (Header)",
                        "Duty Charge Value (Header)",
                        "Supervising Office (Header)",
                        "Total Revenue (Header)",
                        "Total VAT (Header)",

                        "Air Transport Cost - Sum (Header)",
                        "Freight Charges - Sum (Header)",
                        "Freight Apportionment Indicator (Header)",
                        "Discount Amount - Sum (Header)",
                        "Discount Percentage - Sum (Header)",
                        "Insurance Amount - Sum (Header)",
                        "Other Transport Charges - Sum (Header)",
                        "VAT Adjustment - Sum (Header)",


                        //ITEM
                        "Country of Preferential Origin (Item)",

                        "Additional Commodity Code (NAT) (Item Collection)",
                        "Additional Commodity Code (TARIC) (Item Collection)",

                        "Customs Value per Quantity (Item)",

                        "CPC (Item)",
                        "Commodity Code (TSP & TRC) (Item)",
                        "Country of Origin (Item)",
                        "Customs Value (Item)",

                        "Consignee Address (Item)",
                        "Consignee City (Item)",
                        "Consignee Country (Item)",
                        "Consignee EORI (Item)",
                        "Consignee Name (Item)",
                        "Consignee Postcode (Item)",

                        "Destination Country (Item)",
                        "Dispatch Country (Item)",

                        "Declared Customs Value (Item)",

                        "Goods Description (Item)",
                        "Gross Mass (Item)",

                        "Invoice Price (Item)",

                        "Net Mass (Item)",

                        "Tax Amount Sum (Item)",
                        "Tax Revenue Sum (Item)",

                        "Statistical Value (Item)",
                        "Supplementary Units (Item)",

                        "UN Dangerous Goods Code (Item)",

                        "Valuation Method Code (Item)",

                        "Additional Info Code (Header Collection)",
                        "Additional Info Text (Header Collection)",
                        "Document Type (Header Collection)",
                        "Container ID (Header Collection)",
                        "Country Route (Header Collection)",
                        "Seal ID (Header Collection)",

                        "Additional Info Code (Item Collection)",
                        "Additional Info Text (Item Collection)",
                        "Document Type (Item Collection)",
                        "Package Count (Item Collection)",
                        "Package Marks (Item Collection)",
                        "Package Type (Item Collection)",

                        "Base Amount (Item Collection)",
                        "Base Quantity (Item Collection)",
                        "Container ID (Item Collection)",
                        "Payment Method (Item Collection)",
                        "Percentage Adjustment (Item Collection)",
                        "Preference Code (Item Collection)",
                        "Quota Code (Item Collection)",
                        "Tax Amount (Item Collection)",
                        "Tax Revenue (Item Collection)",
                        "Tax Type Code (Item Collection)",
                        "VAT Value (Item Collection)",
                        "Valuation Adjust Code (Item Collection)",
                        "Document Status (Item Collection)",

                        "Shed Code (Header)",
                        "Goods Location Address (Header)",
                        "Goods Location City (Header)",
                        "Goods Location Country (Header)",
                        "Goods Location ID (Header)",
                        "Goods Location Name (Header)",
                        "Goods Location Postcode (Header)",

                        "Additional Info Language (Item Collection)",

                        "Document Identifier (Item Collection)",
                        "Document Quantity (Item Collection)",

                        "Previous Document Class (Item Collection)",
                        "Previous Document Identifier (Item Collection)",
                        "Previous Document Type (Item Collection)",

                        "Additional Actor Role (Item Collection)",
                        "Additional Actor ID (Item Collection)",

                        "VAT Declaring Party ID (Item Collection)",
                        "VAT Declaring Party Role (Item Collection)",

                        "Additional Actor Role (Header)",
                        "Additional Actor ID (Header)",

                        "VAT Declaring Party ID (Header)",
                        "VAT Declaring Party Role (Header)",

                        "Buyer Address (Header)",
                        "Buyer City (Header)",
                        "Buyer Country (Header)",
                        "Buyer ID (Header)",
                        "Buyer Name (Header)",
                        "Buyer Postcode (Header)",

                        "Exporter Address (Header)",
                        "Exporter City (Header)",
                        "Exporter Country (Header)",
                        "Exporter ID (Header)",
                        "Exporter Name (Header)",
                        "Exporter Postcode (Header)",

                        "Importer Address (Header)",
                        "Importer City (Header)",
                        "Importer Country (Header)",
                        "Importer EORI (Header)",
                        "Importer Name (Header)",
                        "Importer Postcode (Header)",

                        "Presentation Office (Header)",

                        "Seller Address (Header)",
                        "Seller City (Header)",
                        "Seller Country (Header)",
                        "Seller ID (Header)",
                        "Seller Name (Header)",
                        "Seller Postcode (Header)",

                        "Authorisation Holder EORI (Header Collection)",

                        "Buyer Address (Item)",
                        "Buyer City (Item)",
                        "Buyer Country (Item)",
                        "Buyer ID (Item)",
                        "Buyer Name (Item)",
                        "Buyer Postcode (Item)",

                        "Exporter/Consignor Address (Item)",
                        "Exporter/Consignor City (Item)",
                        "Exporter/Consignor Country (Item)",
                        "Exporter/Consignor EORI (Item)",
                        "Exporter/Consignor Name (Item)",
                        "Exporter/Consignor Postcode (Item)",

                        "Seller Address (Item)",
                        "Seller City (Item)",
                        "Seller Country (Item)",
                        "Seller ID (Item)",
                        "Seller Name (Item)",
                        "Seller Postcode (Item)",
                        "Place of Loading (Header)",
                        "Transaction Nature Code (Header)",
                        "Warehouse ID (Header)",
                        "Warehouse Type (Header)",
                        "Authorisation Type (Header Collection)",

                        "Declarant/Rep Address (Domain)",
                        "Declarant/Rep City (Domain)",
                        "Declarant/Rep EORI (Domain)",
                        "Declarant/Rep Name (Domain)",
                        "Declarant/Rep Postcode (Domain)",
                        
                        "ESIB EORIs (Domain)",
                        "ESIB Names (Domain)",

                        "Exporter/Seller Address (Domain)",
                        "Exporter/Seller City (Domain)",
                        "Exporter/Seller EORI (Domain)",
                        "Exporter/Seller Name (Domain)",
                        "Exporter/Seller Postcode (Domain)",

                        "Importer/Buyer Address (Domain)",
                        "Importer/Buyer City (Domain)",
                        "Importer/Buyer EORI (Domain)",
                        "Importer/Buyer Name (Domain)",
                        "Importer/Buyer Postcode (Domain)",

                        "Declarant/Rep Country (Domain)",
                        "Exporter/Seller/Consignor Country (Domain)",
                        "Importer/Buyer Country (Domain)",
                        "Country Group of Origin (Item)",
                        "Country Group of Preferential Origin (Item)",
                        "Goods Shipped By Container Indicator (Header)",
                        "Means of Transport on Arrival Identifier (Header)",
                        "Means of Transport on Arrival Type (Header)",
                        "CUS Commodity Code (Item)",

                        "Delivery Terms Type (Header)",
                        "Delivery Terms Location ID (Header)",
                        "Delivery Terms Location Name (Header)",
                        "Monetary Amount Adjustment (Item Collection)",
                        "Valuation Adjust Code (Header Collection)",
                        "Valuation Adjust Amount (Header Collection)",
                        "Valuation Adjust Currency (Header Collection)",
                        "Valuation Adjust Amount (Item Collection)",
                        "Valuation Adjust Currency (Item Collection)",
                        "Internal Currency Unit (Header)",
                        "Goods Valuation has Price Influence (Item)",
                        "Goods Valuation has Restrictions (Item)",
                        "Goods Valuation has Sale Condition (Item)",
                        "Goods Valuation has Future Proceeds (Item)",
                        "Exchange Rate (Header)"
                );

        Assertions.assertThat(viewRuleMetaResponseObject.conditionAttributes).extracting("name").containsAll(attributeList);
        assertEquals(241, viewRuleMetaResponseObject.conditionAttributes.size());
    }

    public RuleMetaResponse.ViewRuleMetaResponseObject GetExpectedAttributeDetailsFromFile() {
        String sResourcePath = "/TestData/AttributeDetails";

        URL resource = getClass().getResource(sResourcePath);

        Path path = null;
        try {
            path = Paths.get(resource.toURI());
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }

        List<String> lines = null;
        try {
            lines = Files.readAllLines(path);
        } catch (IOException e) {
            e.printStackTrace();
        }

        List<String> attributeList = new ArrayList<>();

        RuleMetaResponse.ViewRuleMetaResponseObject viewRuleMetaResponseObject = new RuleMetaResponse.ViewRuleMetaResponseObject();
        List<RuleMetaResponse.ConditionAttributes> conditionAttributesList = new ArrayList<>();
        //viewRuleMetaResponseObject.conditionAttributes;

        for (String line : lines) {

            //log.info("\n\n line contents: " + line);

            //Dispatch Country (Domain)#Equal,Not Equal#
            String[] fields = line.split("#");
            //log.info("field :" + fields[0]);
            attributeList.add(fields[0]);

            RuleMetaResponse.ConditionAttributes conditionAttributes = new RuleMetaResponse.ConditionAttributes();
            conditionAttributes.name = fields[0];


            String[] operators = fields[1].split(",");
            //log.info("operator 1: " + operators[0]);

            List<RuleMetaResponse.Operators> operatorsList = new ArrayList<>();

            for (String currentOperator : operators) {
                RuleMetaResponse.Operators operator = new RuleMetaResponse.Operators();
                operator.name = currentOperator;
                operatorsList.add(operator);
            }

            conditionAttributes.operators = operatorsList;
            conditionAttributesList.add(conditionAttributes);

        }

        viewRuleMetaResponseObject.conditionAttributes = conditionAttributesList;

        return viewRuleMetaResponseObject;
    }


    //Note these tests will no longer be extended for additional feeds as Developer Tests cover testing attribute operator mapping
    /*@Test
    public void WhenRuleMetaServiceCalled_ConditionAttributesHaveCorrectOperatorsAssigned()
    {

        //Arrange

        //Act
        RuleMetaResponse.ViewRuleMetaResponseObject actViewRuleMetaResponseObject = Rules.GetRuleMeta();
        RuleMetaResponse.ViewRuleMetaResponseObject expViewRuleMetaResponseObject = GetExpectedAttributeDetailsFromFile();

        //Assert
        for (int i=0; i < expViewRuleMetaResponseObject.conditionAttributes.size(); i++)
        {
            String currentConditionAttributeNameToCheck = expViewRuleMetaResponseObject.conditionAttributes.get(i).name;

            List<String> expAttributeOperators = expViewRuleMetaResponseObject.conditionAttributes.get(i).operators.stream()
                    .collect(mapping(op -> op.name, toList()));

            for (int j=0; j < actViewRuleMetaResponseObject.conditionAttributes.size(); j++)
            {
                String currentConditionAttributeNameChecking = actViewRuleMetaResponseObject.conditionAttributes.get(j).name;

                if (currentConditionAttributeNameToCheck.equals(currentConditionAttributeNameChecking))
                {
                    log.info("Checking condition attribute: " + currentConditionAttributeNameToCheck);
                    Assertions.assertThat(actViewRuleMetaResponseObject.conditionAttributes
                            .get(j).operators).extracting("name")
                            .containsOnlyElementsOf(expAttributeOperators);
                    break;
                }
            }
        }

    }*/

    private class AttributeOperator {

        private String attributeName;
        private List<String> operatorName;

    }

}
