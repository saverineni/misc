package TestCases.UI.Rules;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.*;
import FunctionsLibrary.DateTime;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.DataForTests.TestRuleModel;
import UI.ElementControls.MultiSelectDropDown;
import UI.Pages.RulesManagement.CreateLocalRule_Page;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleDetails_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.openqa.selenium.NoSuchElementException;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TimeZone;

import static API.RulesManagementService.Utils.Publish.setPublishAutomaticEventTime;
import static FunctionsLibrary.Utils.SleepForMilliSeconds;
import static UI.DataForTests.TestRuleModel.RuleDetails.Condition.Attribute.COMMODITY_CODE;
import static UI.DataForTests.TestRuleModel.RuleDetails.Condition.AttributeType.ITEM;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_3.class})
public class TestCase_CreateLocalRule extends BaseUIWebDriverTestCase {

    @Category(SmokeTests_UI_2.class)
    @Test
    public void WhenLocalRuleManagerLoggedIn_CanCreateLocalRule() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();
        ruleDetails.transportMode = TestRuleModel.RuleDetails.TransportMode.AIR.value;

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }

    @Test
    public void WhenLocalRuleSaved_CorrectViewRuleDetailsDisplayed() {

        //Arrange
        String timeInSeconds="300";
        TestUserModel.UserDetails superAdminUser = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(superAdminUser);
        setPublishAutomaticEventTime(timeInSeconds, superAdminUser.pid);

        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();
        ruleDetails.secretTask = true;

        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Act
        RuleSummary_Page ruleSummary_page = createLocalRule_page.clickViewRule();
        List<RuleSummary_Page.RuleSummaryTableObject> ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        ruleSummaryTableObjects.get(0).versionDetailAction.click();

        //Assert
        RuleDetails_Page ruleDetails_page = new RuleDetails_Page(driver);
        ruleDetails_page.assertRuleDetailsLocalRule(ruleDetails, userDetailsRM);

        assertEquals("On Publish", ruleDetails_page.startDateTime.getText());
        assertEquals("Not Set", ruleDetails_page.endDateTime.getText());
    }


    @Test
    public void WhenNationalRuleManagerLoggedIn_CanCreateLocalRule() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();
        List<String> goodsLocationList = createLocalRule_page.getGoodsLocationList("All");

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        assertThat(goodsLocationList).doesNotContain("National Office");
        ListRules_Page listRules_page = new ListRules_Page(driver);
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }


    @Test
    public void WhenLocalRuleManagerWithSingleGoodsLocationLoggedIn_CanOnlySelectTheirGoodsLocationsForRuleCreation() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();

        //Act
        String actGoodsLocation = createLocalRule_page.getGoodsLocation(ruleDetails);

        //Assert
        assertEquals("POO - Poole", actGoodsLocation);
    }


    @Test
    public void WhenLocalRuleManagerWithMultipleGoodsLocationLoggedIn_CanSelectOnlyTheirGoodsLocationsForRuleCreation() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO_EXT();

        //Act
        String actAirGoodsLocation = createLocalRule_page.getGoodsLocationList2("Air", "EXT - Exeter Airport");

        //Assert
        assertEquals("EXT - Exeter Airport", actAirGoodsLocation);

        String actMaritimeGoodsLocation = createLocalRule_page.getGoodsLocationList2("Maritime", "POO - Poole");

        assertEquals("POO - Poole", actMaritimeGoodsLocation);
    }


    @Test
    public void WhenNationalRuleManagerLoggedIn_CanCreateLocalRuleForAnyLocation() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();

        //Act
        List<String> actGoodsLocation = createLocalRule_page.getGoodsLocationList("Air");

        //Assert
        assertTrue("Expect Goods Location to be more than 10", actGoodsLocation.size() > 10);
    }


    @Category({ChangeRequest.CR_1636.class})
    @Test
    public void WhenRatsLocalRuleSaved_RuleCreatedSuccessfully() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRatsRule_POO();

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }

    @Ignore("As there is time issue in jenkins and locally it is passing. This has to be investigated and defect to be filed")
    @Category({ChangeRequest.CR_2253.class})
    @Test
    public void WhenRatsLocalRuleCreatedWithStartAndEndDateTime_RuleCreatedSuccessfully() throws Exception{

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRatsRule_POO();

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        ruleDetails.startRuleImmediately = false;
        ruleDetails.startDate = DateTime.AdjustLocalDateTimeNowByXDays(0);
        ruleDetails.startTime = DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.of("Europe/London"), 2, "HH:mm");
        ruleDetails.endDate = DateTime.AdjustLocalDateTimeNowByXDays(0);
        ruleDetails.endTime = DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.of("Europe/London"), 8, "HH:mm");

        createLocalRule_page.enterStartDateAndStartTimeForRules(ruleDetails);
        createLocalRule_page.enterEndDateAndEndTimeForRules(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        String actMessage = createLocalRule_page.getSuccessMessage();

        assertEquals("Rule submitted successfully", actMessage);

        createLocalRule_page.viewRule.click();

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);
        List<RuleSummary_Page.RuleSummaryTableObject> listRuleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();

        String startDateAndTime = ruleDetails.startDate + " " + ruleDetails.startTime;
        String endDateAndTime = ruleDetails.endDate +" " + ruleDetails.endTime;

        //Assert
        assertEquals("Expect Rule Start Date to be " + startDateAndTime, covertToLocalDateTime(startDateAndTime), listRuleSummaryTableObjects.get(0).startDate);
        assertEquals("Expect Rule Start Date to be " + endDateAndTime, covertToLocalDateTime(endDateAndTime), listRuleSummaryTableObjects.get(0).endDate);

        ruleSummary_page.view.click();

        RuleDetails_Page ruleDetails_page = new RuleDetails_Page(driver);

        //Assert
        assertEquals("Expect Rule Start Date to be " + startDateAndTime, covertToLocalDateTime(startDateAndTime), ruleDetails_page.startDateTime.getText());
        assertEquals("Expect Rule Start Date to be " + endDateAndTime, covertToLocalDateTime(endDateAndTime), ruleDetails_page.endDateTime.getText());

        ruleDetails_page.amend.click();

        ruleDetails.holdNarrative = "Test Hold Narrative Text for start and date time";

        createLocalRule_page.amendHoldNarrative("Test Hold Narrative Text for start");

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        assertEquals("Rule submitted successfully", actMessage);
        createLocalRule_page.viewRule.click();

        ruleSummary_page.ruleVersionsTab.click();

        List<RuleSummary_Page.RuleVersionsTableObject> listRuleVersionTableObjects = ruleSummary_page.getListOfRuleVersions();

        //Assert
        assertEquals("Expect Rule Version Status to be Cancelled", "CANCELLING", listRuleVersionTableObjects.get(1).status);
        assertEquals("Expect Rule Version to be 1", 1, listRuleVersionTableObjects.get(1).version);

        assertEquals("Expect Rule Version Status to be Pending", "COMMITTED", listRuleVersionTableObjects.get(0).status);
        assertEquals("Expect Rule Version to be 2", 2, listRuleVersionTableObjects.get(0).version);

        assertEquals("Expect Rule Start Date to be " + startDateAndTime, covertToLocalDateTime(startDateAndTime), listRuleVersionTableObjects.get(0).startDate);
        assertEquals("Expect Rule Start Date to be " + endDateAndTime, covertToLocalDateTime(endDateAndTime), listRuleVersionTableObjects.get(0).endDate);

        assertEquals("Expect Rule Start Date to be " + startDateAndTime, covertToLocalDateTime(startDateAndTime), listRuleVersionTableObjects.get(1).startDate);
        assertEquals("Expect Rule Start Date to be " + endDateAndTime, covertToLocalDateTime(endDateAndTime), listRuleVersionTableObjects.get(1).endDate);
    }


    @Category({ChangeRequest.CR_1711.class})
    @Test
    public void WhenRuleOutputsActionType2LocalRuleSaved_RuleCreatedSuccessfully() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRatsRule_POO();
        ruleDetails.actionType = TestRuleModel.RuleDetails.ActionType.DocCheckHoldGoods;
        ruleDetails.holdNarrative = "Test Hold Narrative Text for";

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }


    @Category({ChangeRequest.CR_1711.class})
    @Test
    public void WhenRuleOutputsActionType3LocalRuleSaved_RuleCreatedSuccessfully() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRatsRule_POO();
        ruleDetails.actionType = TestRuleModel.RuleDetails.ActionType.DocCheckReleaseGoods;
        ruleDetails.releaseNarrative = "Test Release Narrative Text for";
        ruleDetails.holdNarrative=null;

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }


    @Category({ChangeRequest.CR_1711.class, ChangeRequest.CR_2739.class})
    @Test
    public void WhenRuleOutputsActionType4LocalRuleSaved_RuleCreatedSuccessfully() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRatsRule_POO();
        ruleDetails.actionType = TestRuleModel.RuleDetails.ActionType.DocCheckVaryReleaseOfGoods;
        ruleDetails.releaseNarrative = "Test Release Narrative Text for";
        ruleDetails.holdNarrative = "Test Hold Narrative Text for";
        ruleDetails.releasePercentage = "60";
        ruleDetails.holdPercentage = "40";
        ruleDetails.timeToClose = "600";

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        String actMessage = createLocalRule_page.getSuccessMessage();

        //Assert
        RuleSummary_Page ruleSummary_page = createLocalRule_page.clickViewRule();
        List<RuleSummary_Page.RuleSummaryTableObject> ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        ruleSummaryTableObjects.get(0).versionDetailAction.click();

        RuleDetails_Page ruleDetails_page = new RuleDetails_Page(driver);
        ruleDetails_page.assertRuleDetailsLocalRule(ruleDetails, userDetailsRM);
    }

    @Ignore("Will be reinstated as part of CR-3061")
    @Category({ChangeRequest.CR_2741.class, ChangeRequest.CR_3061.class})
    @Test
    public void WhenRuleOutputsActionType5LocalRuleSaved_RuleCreatedSuccessfully() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRatsRule_POO();
        ruleDetails.actionType = TestRuleModel.RuleDetails.ActionType.StandaloneTask;
        ruleDetails.holdNarrative = null;

        ruleDetails.standaloneInfoNarrative = "Test Standalone Narrative Text for";
        ruleDetails.assigneeID = "NCH Documentary Checks – Imports";
        ruleDetails.emailDomainType = TestRuleModel.RuleDetails.EmailDomainType.Gsi;

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleConditionWithoutRuleThreshold(ruleDetails);

        boolean selfClosingTaskDisplayed= createLocalRule_page.isElementDisplayed(createLocalRule_page.timeToCloseCheckBox);
        assertFalse("Self Closing Task should not be visible for Information Task",selfClosingTaskDisplayed);
        createLocalRule_page.enterEmailUsername("test.user");

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        String actMessage = createLocalRule_page.getSuccessMessage();

        //Assert
        RuleSummary_Page ruleSummary_page = createLocalRule_page.clickViewRule();
        List<RuleSummary_Page.RuleSummaryTableObject> ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        ruleSummaryTableObjects.get(0).versionDetailAction.click();

        assertEquals("Rule submitted successfully", actMessage);

        RuleDetails_Page ruleDetails_page = new RuleDetails_Page(driver);
        ruleDetails_page.assertRuleDetailsLocalRule(ruleDetails, userDetailsRM);
    }

    @Category({ChangeRequest.CR_3061.class, ChangeRequest.CR_2985.class})
    @Test
    public void AttemptToCreateRuleWithInvalidEmailUsername_SaveAndCommitButtonIsEnabledAndUserGetsNotificationMessage() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRatsRule_POO();
        ruleDetails.actionType = TestRuleModel.RuleDetails.ActionType.StandaloneTask;
        ruleDetails.holdNarrative = null;

        ruleDetails.standaloneInfoNarrative = "Test Standalone Narrative Text for";
        ruleDetails.assigneeID = "NCH Documentary Checks â€“ Imports";
        ruleDetails.emailDomainType = TestRuleModel.RuleDetails.EmailDomainType.Gsi;

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleConditionWithoutRuleThreshold(ruleDetails);

        boolean ruleActionThresholdDisplayed = createLocalRule_page.isElementDisplayed(createLocalRule_page.useRatYes);
        assertFalse("Rule Action Threshold should not be displayed",ruleActionThresholdDisplayed);

        boolean selfClosingTaskDisplayed= createLocalRule_page.isElementDisplayed(createLocalRule_page.timeToCloseCheckBox);
        assertFalse("Self Closing Task should not be visible for Information Task",selfClosingTaskDisplayed);

        createLocalRule_page.enterEmailUsername("test@");

        boolean bSaveAndCommitButtonIsEnabled = createLocalRule_page.saveAndCommit.isEnabled();
        assertEquals("Expect ok button to be enabled", true, bSaveAndCommitButtonIsEnabled);

        createLocalRule_page.clickSaveAndCommit();

        String errorMessage = createLocalRule_page.errorNotificationMessage.getText();
        assertEquals("Unable to save and commit as the form is incomplete. Please address the issues highlighted below.", errorMessage);
    }

    @Category(ChangeRequest.CR_1674.class)
    @Test
    public void WhenRuleManagerCreatesALocalRule_RegimeCodeIsNotDisplayedInRuleDetails() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);

        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftQuickLocalRule_POO();
        ruleDetails.conditionGroups.get(0).conditions.get(0).attribute = COMMODITY_CODE;
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = ITEM;
        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        RuleSummary_Page ruleSummary_page = createLocalRule_page.clickViewRule();
        ruleSummary_page.view.click();

        RuleDetails_Page ruleDetails_page = new RuleDetails_Page(driver);

        //Assert
        assertTrue("Regime code should not be shown for local rule ", ruleDetails_page.isElementDisplayed(ruleDetails_page.regimeLabel, 2, false) == false);
    }


    @Test
    @Category(ChangeRequest.CR_2925.class)
    public void WhenCreatingLocalRule_CanAddAndDeleteTheLocations() {

        //Arrange
        ArrayList<String> locations = new ArrayList<String>(Arrays.asList("BHX - Birmingham Airport","LBA - Leeds Bradford Airport"));

        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        MultiSelectDropDown dropDown = new MultiSelectDropDown(driver);
        createLocalRule_page.selectTransportMode("Air");
        dropDown.selectMultipleValues(createLocalRule_page.goodsLocationList,locations);
        List<String> selectedLocations = createLocalRule_page.getSelectedGoodsLocations();
        createLocalRule_page.removeLocation.click();
        List<String> locationsAfterRemoveLocations = createLocalRule_page.getSelectedGoodsLocations();
        String selectedLocation = createLocalRule_page.getSelectedGoodsLocation();

        assertThat(selectedLocations).contains
                ("BHX - Birmingham Airport","LBA - Leeds Bradford Airport");
        assertThat(locationsAfterRemoveLocations).hasSize(1);
        assertThat(selectedLocation).contains
                ("LBA - Leeds Bradford Airport");

    }



    @Category(ChangeRequest.CR_2849.class)
    @Test
    public void WhenRuleWithMatchingAttributeCreated_RuleCreatedSuccessfully() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRule_POO();
        ruleDetails.conditionGroups.get(0).conditions.get(0).attribute = TestRuleModel.RuleDetails.Condition.Attribute.CONSIGNEE_NAME;
        ruleDetails.conditionGroups.get(0).conditions.get(0).attributeType = TestRuleModel.RuleDetails.Condition.AttributeType.HEADER;
        ruleDetails.conditionGroups.get(0).conditions.get(0).value = "Consignee Name (Item)";
        ruleDetails.conditionGroups.get(0).conditions.get(0).isAttribute = true;
        ruleDetails.conditionGroups.get(0).conditions.get(0).ruleConditionAttributeType = TestRuleModel.RuleDetails.Condition.AttributeType.ITEM;

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);

        createLocalRule_page.clickSaveAndCommitWithDefaultReason();

        //Assert
        ListRules_Page listRules_page = new ListRules_Page(driver) ;
        assertThat(listRules_page.getListOfRules()).extracting("description")
                .contains(ruleDetails.description);
    }

    @Ignore("Time to close is removed temporarily. May be reinstated in future")
    @Category(ChangeRequest.CR_2739.class)
    @Test
    public void WhenRuleWithTimeToCloseTaskIsAmended_RuleShouldBeAmendedCorrectly() {
        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        //Create a Rule with timed and  time to close as 2 hours
        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftLocalRatsRule_POO();
        ruleDetails.actionType = TestRuleModel.RuleDetails.ActionType.PhysicalCheck;
        ruleDetails.holdNarrative = "Test Hold Narrative Text for";
        ruleDetails.timeToClose = "300";
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createLocalRuleSingleCondition(ruleDetails);
        createLocalRule_page.clickSaveAndCommitWithDefaultReason();
        createLocalRule_page.getSuccessMessage();


        //Amend the rule and chnage the time to close
        RuleSummary_Page ruleSummary_page = createLocalRule_page.clickViewRule();
        ruleSummary_page.amend.click();

        //Get the initial Self closing type and time to close to assert later
        String timeToCloseTypeInitial = createLocalRule_page.getTimeToClose();

        //Change the time and verify the amended timetoclose is displayed correctly
        ruleDetails.timeToClose = "450";
        createLocalRule_page.selfClosingTime.clear();
        createLocalRule_page.selfClosingTime.sendKeys(ruleDetails.timeToClose);
        createLocalRule_page.clickSaveAndCommitWithDefaultReason();
        SleepForMilliSeconds(2000);
        ruleSummary_page = createLocalRule_page.clickViewRule();
        List<RuleSummary_Page.RuleSummaryTableObject> ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        ruleSummaryTableObjects.get(0).versionDetailAction.click();
        RuleDetails_Page ruleDetails_page = new RuleDetails_Page(driver);

        //Assert
        //Assert initial self closing type
        assertEquals("300", timeToCloseTypeInitial);
        //Assert after the time to close is amended
        ruleDetails_page.assertRuleDetailsLocalRule(ruleDetails, userDetailsRM);

    }

    @Test
    public void WhenLocalRuleManagerLoggedIn_CannotCreateLocalRuleWithALVSActionType(){

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        //Act
        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);

        try {
            createLocalRule_page.setActionType(TestRuleModel.RuleDetails.ActionType.ALVS.value);
            fail();
        } catch (Exception e) {
            assertTrue(e instanceof NoSuchElementException);
        }
    }

    public String covertToLocalDateTime(String dateTime) throws Exception {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        LocalDateTime parsedDate = LocalDateTime.parse(dateTime, formatter);
        String formattedDate = parsedDate.format(formatter)+" "+TimeZone.getDefault().getDisplayName(true,TimeZone.SHORT);
        return  formattedDate;
    }

}
