package TestCases.UI.Rules;

import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.Utils.Rules;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Rules;
import Categories_CDSRisk.CDS_Risk_UI_Rules_1;
import Categories_CDSRisk.ChangeRequest;
import FunctionsLibrary.DateTime;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleDetails_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import java.util.List;

import static FunctionsLibrary.DateTime.toLocalDateTimeStringWithZone;
import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_1.class})
public class TestCase_CancelledRule extends BaseUIWebDriverTestCase {
    @Test
    @Category({ChangeRequest.CR_2191.class,ChangeRequest.CR_3100.class})  //done
    public void WhenCommittedRuleUpdatedWithNewDatesThatConsumeTheExistingRuleDate_oldRuleVersionIsSetToCancelled()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetailsV1 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsV1.startDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(5, DateTime.DateTimeUTCZ);
        ruleDetailsV1.endDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(50, DateTime.DateTimeUTCZ);
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetailsV1);

        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetailsV2.startDateTime = DateTime.AdjustCustomRuleDateTimeByXMinutes(ruleDetailsV1.startDateTime, -10, DateTime.DateTimeUTCZ);
        ruleDetailsV2.endDateTime = DateTime.AdjustCustomRuleDateTimeByXMinutes(ruleDetailsV1.endDateTime, 10, DateTime.DateTimeUTCZ);
        ruleDetailsV2.uniqueID = commitResponse.uniqueId;
        ruleDetailsV2.version = 2;

        //Act
        Rules.EditRuleAndGetResponseObject(ruleDetailsV2);
        Rules.UpdateStatusOfRule(ruleDetailsV2, RuleVersionActions.commit);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        List<ListRules_Page.ListRulesTableObject> listOfRules = listRules_page.getListOfRules();
        assertEquals(1, listOfRules.size());
        ListRules_Page.ListRulesTableObject leadVersion = listOfRules.get(0);

        // see CR-3060
        //assertEquals(ruleDetailsV2.description, leadVersion.ruleDescription);

        //Act
        listRules_page.clickRuleSummaryForSpecifiedRule(leadVersion.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        //assert
        List<RuleSummary_Page.RuleSummaryTableObject> listOfRuleSummary = ruleSummary_page.getListOfRuleSummaryDetails();
        assertEquals(listOfRuleSummary.get(0).status.toLowerCase(), TestEnumerators.RuleStatus.committed.toString());

        List<RuleSummary_Page.RuleUpcomingChangesTableObject> listOfUpcomingChanges = ruleSummary_page.getListOfUpcomingChanges();
        RuleSummary_Page.RuleUpcomingChangesTableObject firstUpcomingChange = listOfUpcomingChanges.get(0);

        assertEquals(TestEnumerators.RuleStatus.committed.toString(), firstUpcomingChange.status.toLowerCase());
        assertEquals(2, firstUpcomingChange.version);
        String expStartDateV1 = toLocalDateTimeStringWithZone(ruleDetailsV2.startDate());
        String expEndDateV1 = toLocalDateTimeStringWithZone(ruleDetailsV2.endDate());
        assertEquals(expStartDateV1, firstUpcomingChange.startDateTime);
        assertEquals(expEndDateV1, firstUpcomingChange.endDateTime);

        List<RuleSummary_Page.RuleVersionsTableObject> listOfRuleVersions = ruleSummary_page.getListOfRuleVersions();
        assertEquals(listOfRuleVersions.get(1).status.toLowerCase(), TestEnumerators.RuleStatus.cancelling.toString());
        assertEquals(listOfRuleVersions.get(0).status.toLowerCase(), TestEnumerators.RuleStatus.committed.toString());
    }


    @Test
    @Category(ChangeRequest.CR_2191.class)
    public void WhenLiveRuleUpdatedWithNewDatesThatConsumeTheExistingRuleDate_oldRuleVersionIsSetToCancelled()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetailsV1 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsV1.startDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(5, DateTime.DateTimeUTCZ);
        ruleDetailsV1.endDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(50, DateTime.DateTimeUTCZ);
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetailsV1);

        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetailsV2.startDateTime = DateTime.AdjustCustomRuleDateTimeByXMinutes(ruleDetailsV1.startDateTime, -10, DateTime.DateTimeUTCZ);
        ruleDetailsV2.endDateTime = DateTime.AdjustCustomRuleDateTimeByXMinutes(ruleDetailsV1.endDateTime, 10, DateTime.DateTimeUTCZ);
        ruleDetailsV2.uniqueID = commitResponse.uniqueId;
        ruleDetailsV2.version = 2;

        //Act
        Rules.EditRuleAndGetResponseObject(ruleDetailsV2);
        Rules.UpdateStatusOfRule(ruleDetailsV2, RuleVersionActions.commit);

        publishAndWait(5000);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);
        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetailsV2.description);

        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);

        List<RuleSummary_Page.RuleVersionsTableObject> listOfRuleVersions = ruleSummary_page.getListOfRuleVersions();

        //assert
        assertEquals(listOfRuleVersions.get(1).status.toLowerCase(), TestEnumerators.RuleStatus.cancelled.toString());
        assertEquals(listOfRuleVersions.get(0).status.toLowerCase(), TestEnumerators.RuleStatus.active.toString());
    }

    @Test //This test can move to commit Rule after merge
    @Category(ChangeRequest.CR_2191.class)
    public void WhenALiveRuleUpdatedWithNewStartDateBeforeExistingEndDate_EndDateOfFirstSetToStartOfNewVersion()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        API.RulesManagementService.Utils.Users.LoginAsUser(UserDetails.pid);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        TestRuleModel.RuleDetails ruleDetailsV1 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsV1.startDateTime = DateTime.AdjustLocalDateTimeNowByXDays(2, DateTime.DateTimeUTCZ);
        ruleDetailsV1.endDateTime = DateTime.AdjustLocalDateTimeNowByXDays(10, DateTime.DateTimeUTCZ);
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetailsV1);

        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsV2.startDateTime = DateTime.AdjustLocalDateTimeNowByXDays(5, DateTime.DateTimeUTCZ);
        ruleDetailsV2.endDateTime = DateTime.AdjustLocalDateTimeNowByXDays(15, DateTime.DateTimeUTCZ);
        ruleDetailsV2.uniqueID = commitResponse.uniqueId;
        ruleDetailsV2.version = 2;

        //Act
        Rules.EditRuleAndGetResponseObject(ruleDetailsV2);
        Rules.UpdateStatusOfRule(ruleDetailsV2, RuleVersionActions.commit);

        publishAndWait(8000);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(Navigation.Pages.ListRules);

        listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetailsV1.description);


        //Lead Version V3
        RuleSummary_Page ruleSummary_page = new RuleSummary_Page(driver);
        List<RuleSummary_Page.RuleSummaryTableObject> listOfRuleSummary = ruleSummary_page.getListOfRuleSummaryDetails();
        listOfRuleSummary.get(0).versionDetailAction.click();

        RuleDetails_Page ruleDetails_page = new RuleDetails_Page(driver);
        String startDateV3 = ruleDetails_page.startDateTime.getText();
        String endDateV3 = ruleDetails_page.endDateTime.getText();

        String expStartDateV1 = toLocalDateTimeStringWithZone(ruleDetailsV1.startDate());
        String expStartDateV2 = toLocalDateTimeStringWithZone(ruleDetailsV2.startDate());

        assertEquals(expStartDateV1, startDateV3);
        assertEquals(expStartDateV2, endDateV3);

        driver.navigate().back();

        List<RuleSummary_Page.RuleUpcomingChangesTableObject> listOfRulePendingDetails = ruleSummary_page.getListOfUpcomingChanges();

        RuleSummary_Page.RuleUpcomingChangesTableObject firstUpcomingPendingRule = listOfRulePendingDetails.get(0);
        int firstPendingVersion = firstUpcomingPendingRule.version;
        String firstPendingVersionStartDateTime = firstUpcomingPendingRule.startDateTime;
        String firstPendingVersionStatus =  firstUpcomingPendingRule.status;

        RuleSummary_Page.RuleUpcomingChangesTableObject secondUpcomingPendingRule = listOfRulePendingDetails.get(1);
        int secondPendingVersion = secondUpcomingPendingRule.version;
        String secondPendingVersionStartDateTime = secondUpcomingPendingRule.startDateTime;
        String secondPendingVersionStatus = secondUpcomingPendingRule.status;

        expStartDateV1 = toLocalDateTimeStringWithZone(ruleDetailsV1.startDate());
        expStartDateV2 = toLocalDateTimeStringWithZone(ruleDetailsV2.startDate());

        //assert
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), firstPendingVersionStatus.toLowerCase());
        assertEquals(3, firstPendingVersion);
        assertEquals(expStartDateV1, firstPendingVersionStartDateTime);

        assertEquals(TestEnumerators.RuleStatus.pending.toString(), secondPendingVersionStatus.toLowerCase());
        assertEquals(2, secondPendingVersion);
        assertEquals(expStartDateV2, secondPendingVersionStartDateTime);
    }
}
