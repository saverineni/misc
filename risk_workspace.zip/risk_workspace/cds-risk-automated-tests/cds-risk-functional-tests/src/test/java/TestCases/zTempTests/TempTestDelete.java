package TestCases.zTempTests;


import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;

import java.time.ZoneId;
import java.time.ZonedDateTime;

@Slf4j
public class TempTestDelete {

    @Test
    public void TestSpringEnvironment(){

        String timeToFormat = "2017-08-10T06:52:18.497Z";
        log.debug("Time to Format: " + timeToFormat);

        ZonedDateTime expDateTime = ZonedDateTime.now(ZoneId.of("UTC")).plusMinutes(-2);

        ZonedDateTime actDateTime = ZonedDateTime.parse(timeToFormat);

        //LocalDateTime actDateTime = FormatTextToLocalDateTime(timeToFormat, "yyyy-MM-ddTHH:mm:ss");
        Assert.assertTrue(actDateTime.isAfter(expDateTime));

    }

}
