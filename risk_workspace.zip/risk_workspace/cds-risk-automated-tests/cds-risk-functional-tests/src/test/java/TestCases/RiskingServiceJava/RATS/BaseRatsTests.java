package TestCases.RiskingServiceJava.RATS;


import TestCases.RiskingServiceJava.BaseRiskingServiceJava;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import uk.gov.hmrc.risk.test.common.enums.DeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.GoodsItemDeclarationParam;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleCreationModel;

import java.util.Map;

/**
 * Created by developer on 11/09/17.
 */
@Slf4j
public class BaseRatsTests extends BaseRiskingServiceJava {

    protected int createRuleAndSendDeclarations(RuleCreationModel ruleDefinition, Map<DeclarationParam, String> declarationFieldValues, int decCount) {
        createAndRefreshRule(ruleDefinition);

        int routeFired =0;
        log.info("No of declarations to be fired is: {} ", decCount );

        declarationFieldValues.put(GoodsItemDeclarationParam.SEQUENCE_NUMBER, "2001");
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.SEQUENCE_NUMBER, "2002");
        declarationFieldValues.put(GoodsItemDeclarationParam.Third.SEQUENCE_NUMBER, "2003");
        declarationFieldValues.put(GoodsItemDeclarationParam.Fourth.SEQUENCE_NUMBER, "2004");

        String declarationRequest = declarationSupport.createDeclaration(DECLARATION_TEMPLATE, declarationFieldValues);
        for(int i=1; i<= decCount; i++){
            queue.send(declarationRequest);
            DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());
            String returnedControlCode = declarationResponse.getControlType();
            String narrative = declarationResponse.getNarrativeText();
            log.debug("\n" + "The declaration no is :"+ i + " The controlType returned for this particular rule is (control Type) : " + returnedControlCode);
            if(!narrative.isEmpty()) {
                routeFired++;
                String expectedBehaviour = ruleDefinition.getJson().getBehaviours().get(0).getNarrative();
                Assertions.assertThat(narrative.equals(expectedBehaviour))
                        .withFailMessage("Declaration fired a rule, but with incorrect behaviour");
            }
        }
        log.info("\n" + "The total routes fired  :" + routeFired + "\n");

        return routeFired;
    }
}
