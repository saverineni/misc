package TestCases.RulesManagementService;

import API.DataForTests.TestRuleModel;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.EditRule.EditRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.RuleAction.RuleActionResponse;
import Categories_CDSRisk.CDS_RM_RuleLifeCycle;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import org.apache.http.HttpStatus;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import static API.RulesManagementService.Utils.RuleAtStatus.*;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_RuleLifeCycle.class})
public class TestCase_SuspendRule  extends BaseWebAPITestCase{

    @Test
    @Category(ChangeRequest.CR_325.class)
    public void WhenCommittedRuleSuspended_CommittedActiveSuspendedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();
        ruleDetails.uniqueID = committedRuleResponse.uniqueId;

        //Act
        RuleActionResponse.PostResponse suspendResponse = SuspendRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_OK, suspendResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_325.class)
    public void WhenReinstatedRuleSuspended_RuleSuspendedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse reinstatedRuleResponse = CreateReinstatedRule(ruleDetails);

        ruleDetails.uniqueID = reinstatedRuleResponse.uniqueId;

        //Act
        RuleActionResponse.PostResponse suspendResponse = SuspendRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_OK, suspendResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_325.class)
    public void AttemptToSuspendDraftRule_DraftRuleNotSuspended() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        RuleActionResponse.PostResponse suspendResponse = SuspendRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, suspendResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_325.class)
    public void AttemptToSuspendArchivedRule_InvalidRequest() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse archivedRuleResponse = CreateArchivedRule(ruleDetails);
        ruleDetails.uniqueID = archivedRuleResponse.uniqueId;

        //Act
        RuleActionResponse.PostResponse suspendResponse = SuspendRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, suspendResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_325.class)
    public void AttemptToSuspendSuspendedRule_InvalidRequest() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse suspendResponse = CreateSuspendedRule(ruleDetails);
        ruleDetails.uniqueID = suspendResponse.uniqueId;

        //Act
        RuleActionResponse.PostResponse reSuspendResponse = SuspendRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, reSuspendResponse.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_325.class)
    public void AttemptToDeleteSuspendedRule_InvalidRequest() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse suspendResponse = SuspendRule(ruleDetails);
        ruleDetails.uniqueID = suspendResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse deletedResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.delete);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, deletedResponse.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_325.class)
    public void AttemptToUpdateSuspendedRule_InvalidRequest() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse suspendResponse = SuspendRule(ruleDetails);
        ruleDetails.uniqueID = suspendResponse.uniqueId;

        //Act
        EditRuleResponse.PutResponse editResponse = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetails);


        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, editResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_325.class)
    public void AttemptToCommitSuspendedRule_InvalidRequest() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse suspendResponse = SuspendRule(ruleDetails);
        ruleDetails.uniqueID = suspendResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_325.class)
    public void AttemptToSuspendRuleWithInvalidID_RuleNotFound() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();

        //Act
        ruleDetails.uniqueID = "471e5818-146e-11e7-bbc6-0242ac110dbb";
        RuleActionResponse.PostResponse suspendResponse = SuspendRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_NOT_FOUND, suspendResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_325.class)
    public void AttemptToSuspendRuleWithInvalidVersion_RuleNotFound() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();
        ruleDetails.uniqueID = committedRuleResponse.uniqueId;

        //Act
        ruleDetails.version = 9;
        RuleActionResponse.PostResponse suspendResponse = SuspendRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_OK, suspendResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_325.class)
    public void AttemptToSuspendPreviousVersionOfRule_InvalidRequest() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleResponse.PutResponse draftRuleV2 = API.RulesManagementService.Utils.RuleAtStatus.CreateDraftRuleVersion2Rule();
        ruleDetails.uniqueID = draftRuleV2.uniqueId;

        //Act
        ruleDetails.version = 1;
        RuleActionResponse.PostResponse suspendResponse = SuspendRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, suspendResponse.httpStatusCode);
    }

}
