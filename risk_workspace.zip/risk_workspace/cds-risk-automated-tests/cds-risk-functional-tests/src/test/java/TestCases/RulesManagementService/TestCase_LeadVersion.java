package TestCases.RulesManagementService;

import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.Utils.RuleAtStatus;
import API.RulesManagementService.Utils.Rules;
import API.RulesManagementService.ViewRule.ViewRuleResponse;
import API.RulesManagementService.ViewRuleVersion.ViewRuleVersionResponse;
import Categories_CDSRisk.CDS_RM_RuleLifeCycle;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import FunctionsLibrary.DateTime;
import TestCases.BaseWebAPITestCase;
import org.assertj.core.api.Assertions;
import org.assertj.core.groups.Tuple;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_RuleLifeCycle.class})
public class TestCase_LeadVersion extends BaseWebAPITestCase{

    @Test
    @Category({ChangeRequest.CR_2004.class})
    public void GivenDraftRule_WhenNewDraftRuleVersionIsSaved_LeadRuleIsLatestDraftVersion()
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ruleDetails.description = "ta_updatedRule";
        ruleDetails.uniqueID = createRuleResponse.uniqueId;
        API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetails);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals("Lead Version 2", 2, viewRuleResponse.versions.get(0).versionId);
        assertEquals("Lead Version 2", 2, viewRuleResponse.leadVersion.versionId);

        assertEquals(TestEnumerators.RuleStatus.draft.toString(), viewRuleResponse.versions.get(0).status);
        assertEquals(TestEnumerators.RuleStatus.draft.toString(), viewRuleResponse.leadVersion.status);
        assertEquals(ruleDetails.description, viewRuleResponse.leadVersion.description);

        assertEquals("Version 1", 1, viewRuleResponse.versions.get(1).versionId);
        assertEquals(TestEnumerators.RuleStatus.draft.toString(), viewRuleResponse.versions.get(1).status);
    }


    @Test
    @Category({ChangeRequest.CR_2004.class})
    public void GivenDraftRule_WhenDraftRuleVersionIsCommitted_LeadRuleIsCommittedVersion()
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(createRuleResponse.uniqueId, 2);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(createRuleResponse.uniqueId);

        //Assert
        assertEquals("Lead Version 2", 2, viewRuleResponse.versions.get(0).versionId);
        assertEquals("Lead Version 2", 2, viewRuleResponse.leadVersion.versionId);

        assertEquals(TestEnumerators.RuleStatus.committed.toString(), viewRuleResponse.versions.get(0).status);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), viewRuleResponse.leadVersion.status);

        assertEquals("Version 1", 1, viewRuleResponse.versions.get(1).versionId);
        assertEquals(TestEnumerators.RuleStatus.draft.toString(), viewRuleResponse.versions.get(1).status);
    }


    @Test
    @Category({ChangeRequest.CR_2004.class})
    public void GivenCommittedRule_WhenNewDraftIsCommittedWithLiveDate_LeadRuleIsNewlyCommittedVersion()
    {
        //Arrange
        EditRuleVersionResponse.PutResponse response1 = RuleAtStatus.CreateCommittedRule();

        //Act
        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(response1.uniqueId, 2);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = Rules.GetRuleByUID(response1.uniqueId);

        //Assert
        assertEquals("Lead Version 2", 2, viewRuleResponse.versions.get(0).versionId);
        assertEquals("Lead Version 2", 2, viewRuleResponse.leadVersion.versionId);

        assertEquals(TestEnumerators.RuleStatus.committed.toString(), viewRuleResponse.versions.get(0).status);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), viewRuleResponse.leadVersion.status);

        assertEquals("Version 1", 1, viewRuleResponse.versions.get(1).versionId);
        assertEquals(TestEnumerators.RuleStatus.cancelling.toString(), viewRuleResponse.versions.get(1).status);
    }


    @Test
    @Category({ChangeRequest.CR_2004.class})
    public void GivenCommittedRule_WhenNewDraftIsCommittedWithLiveDateAndPublished_LeadRuleIsActiveVersion()
    {
        //Arrange
        EditRuleVersionResponse.PutResponse response1 = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();

        //Act
        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(response1.uniqueId, 2);
        publishAndWait(5000);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(response1.uniqueId);

        //Assert
        assertEquals("Lead Version 2", 2, viewRuleResponse.versions.get(0).versionId);
        assertEquals("Lead Version 2", 2, viewRuleResponse.leadVersion.versionId);

        assertEquals(TestEnumerators.RuleStatus.active.toString(), viewRuleResponse.versions.get(0).status);
        assertEquals(TestEnumerators.RuleStatus.active.toString(), viewRuleResponse.leadVersion.status);

        assertEquals("Version 1", 1, viewRuleResponse.versions.get(1).versionId);

        assertEquals("cancelled", viewRuleResponse.versions.get(1).status);
    }


    @Test
    @Category({ChangeRequest.CR_2004.class})
    public void GivenActiveRule_WhenNewDraftIsCommitted_LeadRuleIsActiveVersion()
    {
        //Arrange
        EditRuleVersionResponse.PutResponse response1 = API.RulesManagementService.Utils.RuleAtStatus.CreateActiveRule();
        publishAndWait(5000);

        //Act
        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(response1.uniqueId, 2);
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(response1.uniqueId);

        //Assert
        assertEquals("Lead Version 1", 1, viewRuleResponse.versions.get(1).versionId);
        assertEquals("Lead Version 1", 1, viewRuleResponse.leadVersion.versionId);

        assertEquals(TestEnumerators.RuleStatus.active.toString(), viewRuleResponse.versions.get(1).status);
        assertEquals(TestEnumerators.RuleStatus.cancelling.toString(), viewRuleResponse.leadVersion.status);

        assertEquals("Version 2", 2, viewRuleResponse.versions.get(0).versionId);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), viewRuleResponse.versions.get(0).status);
    }


    @Test
    @Category({ChangeRequest.CR_2004.class})
    public void GivenActiveRule_WhenNewDraftIsCommittedWithFutureDateBeforeEndDateOfActiveRule_LeadRuleIsActiveVersion()
    {
        //Arrange
        EditRuleVersionResponse.PutResponse response1 = API.RulesManagementService.Utils.RuleAtStatus.CreateActiveRule();

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.description = "ta_updatedRule";
        ruleDetails.uniqueID = response1.uniqueId;
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(1, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(2, DateTime.DateTimeUTCZ);

        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetails, 2);
        publishAndWait(5000);

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(response1.uniqueId);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVersionResponseObject = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(response1.uniqueId, 2);

        //Note version 1 is cancelled
        //Version 2 is pending
        //Version 3 is now Active

        //Assert
        assertEquals("Lead Version 3", 3, viewRuleResponse.leadVersion.versionId);

        Assertions.assertThat(viewRuleResponse.versions).extracting("versionId", "status").containsOnly(
                Tuple.tuple(3, TestEnumerators.RuleStatus.active.toString())
                ,Tuple.tuple(2, TestEnumerators.RuleStatus.pending.toString())
                ,Tuple.tuple(1, TestEnumerators.RuleStatus.cancelled.toString())
        );
    }


    @Test
    @Category({ChangeRequest.CR_2004.class})
    public void GivenActiveRuleAndCommittedVersionWithFutureDate_WhenPublished_LeadRuleIsActiveVersion()
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(1, DateTime.DateTimeUTCZ);
        EditRuleVersionResponse.PutResponse response1 = API.RulesManagementService.Utils.RuleAtStatus.CreateActiveRule(ruleDetails);
        publishAndWait(5000);


        ruleDetails.description = "ta_updatedRule";
        ruleDetails.uniqueID = response1.uniqueId;
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(2, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(3, DateTime.DateTimeUTCZ);

        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetails, 2);

        //Act
        publishAndWait(5000);
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(response1.uniqueId);

        //Assert
        assertEquals("Lead Version 1", 1, viewRuleResponse.versions.get(1).versionId);
        assertEquals("Lead Version 1", 1, viewRuleResponse.leadVersion.versionId);

        assertEquals(TestEnumerators.RuleStatus.active.toString(), viewRuleResponse.versions.get(1).status);
        assertEquals(TestEnumerators.RuleStatus.active.toString(), viewRuleResponse.leadVersion.status);

        assertEquals("Version 2", 2, viewRuleResponse.versions.get(0).versionId);
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), viewRuleResponse.versions.get(0).status);



    }


    @Test
    @Category({ChangeRequest.CR_2004.class})
    public void GivenActiveRuleAndCommittedVersionWithLiveDate_WhenPublished_LeadRuleIsActiveVersion()
    {
        //Arrange
        EditRuleVersionResponse.PutResponse response1 = API.RulesManagementService.Utils.RuleAtStatus.CreateActiveRule();
        publishAndWait(5000);

        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(response1.uniqueId, 2);
        publishAndWait(5000);

        //Act
        publishAndWait(5000);
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(response1.uniqueId);

        //Assert
        assertEquals("Lead Version 2", 2, viewRuleResponse.versions.get(0).versionId);
        assertEquals("Lead Version 2", 2, viewRuleResponse.leadVersion.versionId);

        assertEquals(TestEnumerators.RuleStatus.active.toString(), viewRuleResponse.versions.get(0).status);
        assertEquals(TestEnumerators.RuleStatus.active.toString(), viewRuleResponse.leadVersion.status);

        assertEquals("Version 1", 1, viewRuleResponse.versions.get(1).versionId);
        assertEquals("cancelled", viewRuleResponse.versions.get(1).status);
    }


    @Test
    @Category({ChangeRequest.CR_2004.class})
    public void GivenActiveRuleAndExpiredRule_WhenViewed_LeadRuleIsActiveVersion()
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-2, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-1, DateTime.DateTimeUTCZ);

        EditRuleVersionResponse.PutResponse response1 = API.RulesManagementService.Utils.RuleAtStatus.CreateActiveRule(ruleDetails);
        publishAndWait(5000);


        ruleDetails.description = "ta_updatedRule";
        ruleDetails.uniqueID = response1.uniqueId;
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXMinutes(-1, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(2, DateTime.DateTimeUTCZ);

        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetails, 2);

        //Act
        publishAndWait(5000);
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(response1.uniqueId);

        //Assert
        assertEquals("Lead Version 2", 2, viewRuleResponse.versions.get(0).versionId);
        assertEquals("Lead Version 2", 2, viewRuleResponse.leadVersion.versionId);

        assertEquals(TestEnumerators.RuleStatus.active.toString(), viewRuleResponse.versions.get(0).status);
        assertEquals(TestEnumerators.RuleStatus.active.toString(), viewRuleResponse.leadVersion.status);

        assertEquals("Version 1", 1, viewRuleResponse.versions.get(1).versionId);
        assertEquals(TestEnumerators.RuleStatus.expired.toString(), viewRuleResponse.versions.get(1).status);
    }


    @Test
    @Category({ChangeRequest.CR_2004.class})
    public void GivenPendingRule_WhenNewDraftIsCommittedWithLaterStartDate_LeadRuleIsPendingVersion()
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = RuleAtStatus.CreatePendingExpiredRuleVersion(1, 2);
        publishAndWait(5000);

        //Act
        ruleDetails.description = "ta_updatedRule";
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(3, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(4, DateTime.DateTimeUTCZ);

        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetails, 2);


        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals("Lead Version 1", 1, viewRuleResponse.versions.get(1).versionId);
        assertEquals("Lead Version 1", 1, viewRuleResponse.leadVersion.versionId);

        assertEquals(TestEnumerators.RuleStatus.pending.toString(), viewRuleResponse.versions.get(1).status);
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), viewRuleResponse.leadVersion.status);

        assertEquals("Version 2", 2, viewRuleResponse.versions.get(0).versionId);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), viewRuleResponse.versions.get(0).status);
    }


    @Test
    @Category({ChangeRequest.CR_2004.class})
    public void GivenPendingRuleAndCommittedPendingVersionWithLiveDate_WhenPublished_LeadRuleIsCommittedNowActiveVersion()
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = RuleAtStatus.CreatePendingExpiredRuleVersion(1, 2);

        //Act
        ruleDetails.description = "ta_updatedRule";
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-1, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(4, DateTime.DateTimeUTCZ);

        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetails, 2);
        publishAndWait(5000);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals("Lead Version 2", 2, viewRuleResponse.versions.get(0).versionId);
        assertEquals("Lead Version 2", 2, viewRuleResponse.leadVersion.versionId);

        assertEquals(TestEnumerators.RuleStatus.active.toString(), viewRuleResponse.versions.get(0).status);
        assertEquals(TestEnumerators.RuleStatus.active.toString(), viewRuleResponse.leadVersion.status);

        assertEquals("Version 1", 1, viewRuleResponse.versions.get(1).versionId);
        assertEquals(TestEnumerators.RuleStatus.cancelled.toString(), viewRuleResponse.versions.get(1).status);
    }


    @Test
    @Category({ChangeRequest.CR_2004.class})
    public void GivenPendingRuleAndCommittedPendingVersionWithSoonerStartDate_WhenPublished_LeadRuleIsNewPendingVersion()
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = RuleAtStatus.CreatePendingExpiredRuleVersion(2, 3);

        //Act
        ruleDetails.description = "ta_updatedRule";
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(1, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(4, DateTime.DateTimeUTCZ);

        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetails, 2);
        publishAndWait(5000);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals("Lead Version 2", 2, viewRuleResponse.versions.get(0).versionId);
        assertEquals("Lead Version 2", 2, viewRuleResponse.leadVersion.versionId);

        assertEquals(TestEnumerators.RuleStatus.pending.toString(), viewRuleResponse.versions.get(0).status);
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), viewRuleResponse.leadVersion.status);

        assertEquals("Version 1", 1, viewRuleResponse.versions.get(1).versionId);
        assertEquals("cancelled", viewRuleResponse.versions.get(1).status);
    }


    @Test
    @Category({ChangeRequest.CR_2004.class})
    public void GivenExpiredRule_WhenNewDraftIsCommitted_LeadRuleIsExpiredVersion()
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = RuleAtStatus.CreatePendingExpiredRuleVersion(-2, -1);
        publishAndWait(5000);

        //Act
        ruleDetails.description = "ta_updatedRule";
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(3, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(4, DateTime.DateTimeUTCZ);

        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetails, 2);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals("Lead Version 1", 1, viewRuleResponse.versions.get(1).versionId);
        assertEquals("Lead Version 1", 1, viewRuleResponse.leadVersion.versionId);

        assertEquals(TestEnumerators.RuleStatus.expired.toString(), viewRuleResponse.versions.get(1).status);
        assertEquals(TestEnumerators.RuleStatus.expired.toString(), viewRuleResponse.leadVersion.status);


        assertEquals("Version 2", 2, viewRuleResponse.versions.get(0).versionId);
        assertEquals(TestEnumerators.RuleStatus.committed.toString(), viewRuleResponse.versions.get(0).status);
    }


    @Test
    @Category({ChangeRequest.CR_2004.class})
    public void GivenExpiredRuleAndCommittedVersionWithLiveDate_WhenPublished_LeadRuleIsCommittedNowActiveVersion()
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = RuleAtStatus.CreatePendingExpiredRuleVersion(-2, -1);

        //Act
        ruleDetails.description = "ta_updatedRule";
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-1, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(1, DateTime.DateTimeUTCZ);

        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetails, 2);
        publishAndWait(5000);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals("Lead Version 2", 2, viewRuleResponse.versions.get(0).versionId);
        assertEquals("Lead Version 2", 2, viewRuleResponse.leadVersion.versionId);

        assertEquals(TestEnumerators.RuleStatus.active.toString(), viewRuleResponse.versions.get(0).status);
        assertEquals(TestEnumerators.RuleStatus.active.toString(), viewRuleResponse.leadVersion.status);

        assertEquals("Version 1", 1, viewRuleResponse.versions.get(1).versionId);
        assertEquals(TestEnumerators.RuleStatus.expired.toString(), viewRuleResponse.versions.get(1).status);
    }


    @Test
    @Category({ChangeRequest.CR_2004.class})
    public void GivenExpiredRuleAndCommittedVersionWithFutureDate_WhenPublished_LeadRuleIsExpiredVersion()
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = RuleAtStatus.CreatePendingExpiredRuleVersion(-2, -1);
        publishAndWait(5000);

        //Act
        ruleDetails.description = "ta_updatedRule";
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(1, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(2, DateTime.DateTimeUTCZ);

        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetails, 2);
        publishAndWait(5000);

        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals("Lead Version 1", 1, viewRuleResponse.versions.get(1).versionId);
        assertEquals("Lead Version 1", 2, viewRuleResponse.leadVersion.versionId);

        assertEquals(TestEnumerators.RuleStatus.expired.toString(), viewRuleResponse.versions.get(1).status);
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), viewRuleResponse.leadVersion.status);

        assertEquals("Version 2", 2, viewRuleResponse.versions.get(0).versionId);
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), viewRuleResponse.versions.get(0).status);
    }


}
