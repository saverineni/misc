package TestCases.RiskingServiceJava.RATS;

import Categories_CDSRisk.ChangeRequest_RiskingService.CREP_133;
import Categories_CDSRisk.ChangeRequest_RiskingService.CREP_233;
import Categories_CDSRisk.Risking_JavaService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel.RuleDefinition;
import uk.gov.hmrc.risk.rulesengine.rules.RuleMetadata;
import uk.gov.hmrc.risk.test.common.enums.DeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.HeaderAttribute;
import uk.gov.hmrc.risk.test.common.enums.HeaderDeclarationParam;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleCreationModel;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static org.junit.Assert.assertTrue;
import static uk.gov.hmrc.risk.test.common.enums.Matcher.equalTo;
import static uk.gov.hmrc.risk.test.common.enums.MatcherType.EQUAL;
import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.*;

@Slf4j
@Category({CREP_133.class, CREP_233.class, Risking_JavaService.class})
public class TestCase_VerifyRatsFirstDailyCount extends BaseRatsTests {

    private String uuid = UUID.randomUUID().toString().substring(0,4);
    private String description = "ta_RATS_Rule_" + uuid ;

    @Test
    public void WhenConsigneeEORIRuleWithRatsLimit_RuleStopsFiringAfterReachingRatsLimit() {

        int ratsLimit = 0;
        int decCount = ratsLimit + 1;

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();
        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNOR_EORI, "AE123456789ABCDE");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_TYPE, "IM");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "C");

        String ruleDefinition = createRuleDefinitionModel("AE123456789ABCDE", ratsLimit).toString();

        RuleCreationModel rule = baseRuleCreationModelBuilder()
                .description(description)
                .definition(ruleDefinition)
                .build();

        int routesReturned = createRuleAndSendDeclarations(rule, declarationFieldValues, decCount);
        assertTrue(routesReturned==ratsLimit);
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenConsigneeEORINewRuleWithRatsLimit_RuleStopsFiringAfterReachingRatsLimit() {

        int ratsLimit = 5;
        int decCount = ratsLimit + 1;

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();
        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNOR_EORI, "NL000111222");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_TYPE, "IM");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "C");

        String ruleDefinition = createRuleDefinitionModel("NL000111222", ratsLimit).toString();

        RuleCreationModel rule = baseRuleCreationModelBuilder()
                .description(description)
                .definition(ruleDefinition)
                .build();

        int routesReturned = createRuleAndSendDeclarations(rule, declarationFieldValues, decCount);
        assertTrue(routesReturned==ratsLimit);
    }

    @Test
    public void WhenRatsLimitIsSetToZero_NoRulesAreFiredRats() {
        int ratsLimit = 0;
        int decCount = ratsLimit + 1;

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();
        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNOR_EORI, "AE123456789ABCDE");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_TYPE, "IM");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "C");

        String ruleDefinition = createRuleDefinitionModel("AE123456789ABCDE", ratsLimit).toString();

        RuleCreationModel rule = baseRuleCreationModelBuilder()
                .description(description)
                .definition(ruleDefinition)
                .build();

        int routesReturned = createRuleAndSendDeclarations(rule, declarationFieldValues, decCount);
        assertTrue(routesReturned==0);
    }

    @Test
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenRatsLimitReachedAndDayIsSetToNextDay_RatsLimitIsReset() {
        int ratsLimit = 3;
        int decCount = ratsLimit + 1;

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();
        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNOR_EORI, "NL000111222");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_TYPE, "IM");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "C");

        String ruleDefinition = createRuleDefinitionModel("NL000111222", ratsLimit).toString();

        RuleCreationModel rule = baseRuleCreationModelBuilder()
                .description(description)
                .definition(ruleDefinition)
                .build();

        int routesReturned = createRuleAndSendDeclarations(rule, declarationFieldValues, decCount);
        assertTrue(routesReturned==ratsLimit);

        //change the day to next day so that Risking engine will reset the RATS count
        addDaysToRiskingSystemTime(1);

        //Send new declaration to verify the RATS count is reset
        DeclarationResponse response = sendDeclaration(declarationFieldValues);

        //assert
        assertTrue(!response.getControlType().isEmpty());
    }

    private RuleDefinitionModel createRuleDefinitionModel(String EORI, int ratsLimit) {
        RuleDefinitionModel model = defaultModel();
        model.getRuleDefinitions().clear();
        RuleDefinition ruleDefinition;
        ruleDefinition = RuleDefinition.builder().build();
        ruleDefinition.addMetadata(new RuleDefinitionModel.MetadataDefinition(RuleMetadata.UNIQUE_ID, Optional.of("#UniqueId#")));
        ruleDefinition.addMetadata(new RuleDefinitionModel.MetadataDefinition(RuleMetadata.RAT_FIRST_COUNT_DAILY_LIMIT, Optional.of(ratsLimit)));
        ruleDefinition.setName(description);

        Condition consigneeEori = Condition.builder()
                .attribute(HeaderAttribute.CONSIGNOR_EORI)
                .matcherType(EQUAL)
                .matcherClass(MatcherClass.Matchers)
                .matcher(equalTo)
                .value(EORI)
                .source(Source.declaration)
                .build();

        String declaration = strCheck( consigneeEori );
        ruleDefinition.setWhenDef( declarationWrapper(declaration) );
        ruleDefinition.setThenDef( thenCreator( Source.declaration, conditions( consigneeEori )));
        model.getRuleDefinitions().add(ruleDefinition);
        return model;
    }
}

