package TestCases.RiskingService;

import API.DataForTests.*;
import API.DataForTests.TestRuleModel.RuleDetails;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.Utils.RuleAtStatus;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.ConditionType;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import static API.DataForTests.TestRuleModel.RuleDetails.AttributeType.HEADER;
import static API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody;
import static org.assertj.core.api.Assertions.assertThat;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.crossmatch;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.normal;

@Slf4j
@Category(Risking_Service.class)
public class TestCase_Risking_Declaration_With_Spaces extends WebAPITestCaseWithDatatablesCleanup {

    public static final String NO_CONTROL_ROUTE = "";
    private RuleDetails testRule;
    private RuleDetails.Condition condition;
    private TestDeclarationModel.Declaration declaration;

    @Before
    public void setup() throws IOException, TimeoutException {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
        testRule = Rules.DraftNatRuleNatManager();
        condition = testRule.queryConditions.get(0).conditions.get(0);
        condition.operator = "neq";
        declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
    }

    private void commitRuleAndPublish() {
        EditRuleVersionResponse.PutResponse commitResponse = RuleAtStatus.CreateCommittedRule(testRule);
        assertThat(commitResponse.httpStatusCode)
                .describedAs("Failed to commit rule. response:\n" + commitResponse.body)
                .isEqualTo(200);
        publishAndWait(5000);
    }

    private DeclarationResponse riskDeclaration() {
        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());
        queue.send(declarationRequest);
        return new DeclarationResponse(queue.receive());
    }


    @Test
    @Category({ChangeRequest.CRX_313.class})
    public void whenDeclarationWithLeadingSpaceEqualCondition_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeAddress_Item().attribute;
        condition.value = "London Road No4";
        condition.operator="eq";
        commitRuleAndPublish();

        declaration.consigneeAddress_Item = "  London Road No4";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_313.class})
    public void whenDeclarationNumericsHasSpaces_NoSpacesForCondition_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.invoiceTotal_Header().attribute;
        condition.value = "55516";
        condition.operator="eq";
        commitRuleAndPublish();

        declaration.invoiceTotal_Header = " 55516";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_313.class})
    public void whenDeclarationWithTrailingSpaceEqualCondition_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeAddress_Item().attribute;
        condition.value = "Manchester Road";
        condition.operator="eq";
        commitRuleAndPublish();

        declaration.consigneeAddress_Item = "Manchester Road ";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_313.class})
    public void whenDeclarationWithLeadingTrailingSpacesInBetween_ConditionHasSpaceBetween_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeAddress_Item().attribute;
        condition.value = "Dearmans Place";
        condition.operator="eq";
        commitRuleAndPublish();

        declaration.consigneeAddress_Item = " Dearmans   place ";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_313.class})
    public void whenDeclarationWithSingleSpace_ConditionHasTwoSpaces_thenRouteNotReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeAddress_Item().attribute;
        condition.value = "Dearmans  Place";
        condition.operator="eq";
        commitRuleAndPublish();

        declaration.consigneeAddress_Item = "Dearmans place";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_313.class})
    public void whenDeclarationWithSingleSpace_ConditionHasAttribute_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.attribute = Conditions.consigneeAddress_Item().attribute;
        condition.value = Conditions.consignorAddress_Header().attribute;
        condition.operator="eq";
        commitRuleAndPublish();

        declaration.consigneeAddress_Item = "Dearmans             Place ";
        declaration.consignorAddress_Header="Dearmans   Place";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_313.class})
    public void whenDeclarationWithoutSpaces_ConditionSpaces_thenRouteNotReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeAddress_Item().attribute;
        condition.value = "Dearmans Place";
        condition.operator="eq";
        commitRuleAndPublish();

        declaration.consigneeAddress_Item = "DearmansPlace";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_313.class})
    public void whenDeclarationHasTab_ConditionSpaces_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeAddress_Item().attribute;
        condition.value = "Dearmans Place";
        condition.operator="eq";
        commitRuleAndPublish();

        declaration.consigneeAddress_Item = "Dearmans \tPlace";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_313.class})
    public void whenDeclarationHasSpace_ConditionHasTab_thenRouteNotReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeAddress_Item().attribute;
        condition.value = "Dearmans\tPlace";
        condition.operator="eq";
        commitRuleAndPublish();

        declaration.consigneeAddress_Item = "Dearmans Place";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_313.class})
    public void whenDeclarationWithSpaces_ConditionHasSpace_NotEquals_thenRouteNotReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeAddress_Item().attribute;
        condition.value = "Dearmans Place";
        condition.operator="neq";
        commitRuleAndPublish();

        declaration.consigneeAddress_Item = "Dearmans   place";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }


    @Test
    @Category({ChangeRequest.CRX_313.class})
    public void whenDeclarationWithSpaces_ConditionHasSpace_Contains_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeAddress_Item().attribute;
        condition.value = "Dearmans Place";
        condition.operator="con";
        commitRuleAndPublish();

        declaration.consigneeAddress_Item = "Dearmans \t\t  place";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_313.class})
    public void whenDeclarationWithSpaces_ConditionHasSpace_NotContains_thenRouteNotReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeAddress_Item().attribute;
        condition.value = "Dearmans Place";
        condition.operator="nco";
        commitRuleAndPublish();

        declaration.consigneeAddress_Item = "Dearmans \t\t  place";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_313.class})
    public void whenDeclarationWithSpaces_ConditionHasSpace_StartsWith_thenRouteNotReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeAddress_Item().attribute;
        condition.value = "Dearman Place";
        condition.operator="st";
        commitRuleAndPublish();

        declaration.consigneeAddress_Item = "Dearmans \t\t  place";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }


    @Test
    @Category({ChangeRequest.CRX_313.class})
    public void whenDeclarationWithSpaces_ConditionHasSpace_matchesPattern_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeAddress_Item().attribute;
        condition.value = "Dearmans?Place";
        condition.operator="matchesPattern";
        commitRuleAndPublish();

        declaration.consigneeAddress_Item = "Dearmans  place";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CRX_313.class})
    public void whenDeclarationWithSpaces_ConditionHasSpace_NotMatchesPattern_thenRouteNotReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.consigneeAddress_Item().attribute;
        condition.value = "Dearmans*Place";
        condition.operator="notMatchesPattern";
        commitRuleAndPublish();

        declaration.consigneeAddress_Item = "Dearmans  place";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CRX_313.class})
    public void whenCollectionEqualDataTable_ValueExistsInDataTable_thenRouteReturned() {

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_FreeText_Valid();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(createDataTableResponse.uuid);
        //tableDetails.tableVersionUuid = responseDetail.tableVersionUuid;
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //add data items to data table
        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        condition.attribute = Conditions.consigneeAddress_Item().attribute;
        condition.conditionType = ConditionType.datatable;
        condition.operator = "eq";
        condition.value = tableDetails.uuid;
        condition.isDataTable = true;
        commitRuleAndPublish();

        declaration.consigneeAddress_Item = "123         \tABC";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


}
