package TestCases.UI.publish;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Publish;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.MenuToolBar;
import UI.Pages.Publish.Publish_Page;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static FunctionsLibrary.Utils.SleepForMilliSeconds;
import static org.junit.Assert.*;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Publish.class})
public class TestCase_Publish extends BaseUIWebDriverTestCase{

    @Test
    @Category(ChangeRequest.CR_1750.class)
    public void WhenLoggedInAsNationalSuperAdmin_CanPublish()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        MenuToolBar menuToolBar = new MenuToolBar(driver);
        menuToolBar.publish.click();

        String reasonForPublishing = "Require immediate publish";
        Publish_Page publishPage = new Publish_Page(driver);
        publishPage.publishImmediately(reasonForPublishing);

        List<Publish_Page.ListPublishHistoryTableObject> historyList =  publishPage.getListOfHistoryItems();

        //Assert
        Assertions.assertThat(historyList).extracting("reason").contains(reasonForPublishing);

    }

    @Test
    @Category(ChangeRequest.CR_1750.class)
    public void WhenLoggedInAsNationalAdmin_CanPublish()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        MenuToolBar menuToolBar = new MenuToolBar(driver);
        menuToolBar.publish.click();

        String reasonForPublishing = "Require immediate publish";
        Publish_Page publishPage = new Publish_Page(driver);
        publishPage.publishImmediately(reasonForPublishing);

        List<Publish_Page.ListPublishHistoryTableObject> historyList =  publishPage.getListOfHistoryItems();

        //Assert
        Assertions.assertThat(historyList).extracting("reason").contains(reasonForPublishing);
    }

    @Test
    @Category(ChangeRequest.CR_1750.class)
    public void WhenLoggedInAsSuperAdminLocal_CanPublish()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        MenuToolBar menuToolBar = new MenuToolBar(driver);
        menuToolBar.publish.click();

        String reasonForPublishing = "Require immediate publish";
        Publish_Page publishPage = new Publish_Page(driver);
        publishPage.publishImmediately(reasonForPublishing);

        List<Publish_Page.ListPublishHistoryTableObject> historyList =  publishPage.getListOfHistoryItems();

        //Assert
        Assertions.assertThat(historyList).extracting("reason").contains(reasonForPublishing);
        /*assertTrue("", publishPage.isElementDisplayed(publishPage.publishSuccessOk));
        assertTrue("", publishPage.publishSuccessMessage.getText().equals("Publish was successful"));*/
    }

    @Test
    @Category(ChangeRequest.CR_1750.class)
    public void WhenLoggedInAsAdminLocal_CanPublish()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        MenuToolBar menuToolBar = new MenuToolBar(driver);
        menuToolBar.publish.click();

        String reasonForPublishing = "Require immediate publish";
        Publish_Page publishPage = new Publish_Page(driver);
        publishPage.publishImmediately(reasonForPublishing);

        List<Publish_Page.ListPublishHistoryTableObject> historyList =  publishPage.getListOfHistoryItems();

        //Assert
        Assertions.assertThat(historyList).extracting("reason").contains(reasonForPublishing);
    }

    @Test
    @Category(ChangeRequest.CR_1750.class)
    public void WhenLoggedInAsLocalRuleManager_CannotPublish()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        MenuToolBar menuToolBar = new MenuToolBar(driver);

        assertTrue("Expect systemAdmin to be displayed", !menuToolBar.isElementDisplayed(menuToolBar.publish, 1, false));
    }

    @Test
    @Category(ChangeRequest.CR_1750.class)
    public void WhenLoggedInAsAdminLocal_CannotPublishWithoutReasonForPublish()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        MenuToolBar menuToolBar = new MenuToolBar(driver);
        menuToolBar.publish.click();

        String reasonForPublishing = "";
        Publish_Page publishPage = new Publish_Page(driver);
        publishPage.publishImmediately.click();
        publishPage.enterReason.sendKeys(reasonForPublishing);

        assertFalse(publishPage.submitButtonInTheReasonDialog.isEnabled());
        assertTrue("", publishPage.isElementDisplayed(publishPage.publishSuccessOk , 1, false));
    }

    @Test
    @Category(ChangeRequest.CR_1750.class)
    public void WhenLoggedInAsAdminLocal_CanCancelPublish()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        MenuToolBar menuToolBar = new MenuToolBar(driver);
        menuToolBar.publish.click();

        String reasonForPublishing = "cancel publish";
        Publish_Page publishPage = new Publish_Page(driver);
        publishPage.publishImmediately.click();
        publishPage.enterReason.sendKeys(reasonForPublishing);
        publishPage.cancel.click();
        SleepForMilliSeconds(250);

        assertTrue("", publishPage.isElementDisplayed(publishPage.publishImmediately));
        assertEquals("", publishPage.isElementDisplayed(publishPage.submitButtonInTheReasonDialog, 1, false), false);
    }

    @Test
    @Category(ChangeRequest.CR_3110.class)
    public void WhenLoggedInAsNationalSuperAdmin_CorrectListShouldBeDisplayed()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        MenuToolBar menuToolBar = new MenuToolBar(driver);
        menuToolBar.publish.click();

        Publish_Page publishPage = new Publish_Page(driver);

        boolean publishImmediatelyVisible = publishPage.isElementDisplayed(publishPage.publishImmediately);
        boolean publishIntervalVisible = publishPage.isElementDisplayed(publishPage.publishInterval);
        boolean nextScheduledPublishVisible = publishPage.isElementDisplayed(publishPage.nextScheduledPublish);
        boolean publishHistoryVisible = publishPage.isElementDisplayed(publishPage.publishHistory);

        //Assert
        assertEquals(true, publishImmediatelyVisible);
        assertEquals(true, publishIntervalVisible);
        assertEquals(true, nextScheduledPublishVisible);
        assertEquals(true, publishHistoryVisible);
    }

    @Test
    @Category(ChangeRequest.CR_3110.class)
    public void WhenLoggedInAsAdminLocal_CorrectListShouldBeDisplayed()
    {
        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(UserDetails);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);


        MenuToolBar menuToolBar = new MenuToolBar(driver);
        menuToolBar.publish.click();

        Publish_Page publishPage = new Publish_Page(driver);

        boolean publishImmediatelyVisible = publishPage.isElementDisplayed(publishPage.publishImmediately);
        boolean publishIntervalVisible = publishPage.isElementDisplayed(publishPage.publishInterval);
        boolean nextScheduledPublishVisible = publishPage.isElementDisplayed(publishPage.nextScheduledPublish);
        boolean publishHistoryVisible = publishPage.isElementDisplayed(publishPage.publishHistory);

        //Assert
        assertEquals(true, publishImmediatelyVisible);
        assertEquals(false, publishIntervalVisible);
        assertEquals(true, nextScheduledPublishVisible);
        assertEquals(true, publishHistoryVisible);
    }


}