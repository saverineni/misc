package TestCases.RiskingService;

import API.DataForTests.Conditions;
import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel.RuleDetails;
import API.DataForTests.TestRuleModel.RuleDetails.Condition;
import API.EnvDetails.EnvDetails;
import API.RulesManagementService.EditRule.EditRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service;
import FunctionsLibrary.DateTime;
import TestCases.BaseWebAPITestCase;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;
import uk.gov.hmrc.risk.test.common.enums.TransportMode;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeoutException;

import static API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody;
import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Java6Assertions.assertThat;
import static org.junit.Assert.assertEquals;

@Slf4j
@Category(Risking_Service.class)
public class TestCase_Risking_RuleLifeCycle extends BaseWebAPITestCase {

    private static final String ASSIGNEE_ID = "nch_open_general_export_licence";

    @Before
    public void setup() throws IOException, TimeoutException {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
    }


    @Test
    @Category(ChangeRequest.CR_260.class)
    public void CheckRiskingServiceHealthCheckEndPoint_OKResponseReceived() {
        //Act

        //Arrange
        String url = EnvDetails.url_RiskingServiceHealthCheck;

        Response response = given().log().all()
                .contentType("application/json")
                .when().log().all().get(url);

        assertEquals(HttpStatus.SC_OK, response.statusCode());

        //TODO new Risking Service returns info in different format
//        assertEquals("CDS Risk", response.path("service-name"));
//        assertEquals("GREEN", response.path("status"));
    }


    @Test
    @Category({ChangeRequest.CR_1.class, ChangeRequest.CR_175.class, ChangeRequest.CR_2858.class})
    public void WhenDeclarationSubmittedForMatchingCommittedRule_RouteReturnedForCommittedRule() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.PHYSICAL_CHECK.actionType; // Action Type --> Control Type will be equal to 2

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);


        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.commodity = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "1";

        // /declaration/consignmentShipments[sequenceNumber=""]/goodsItems[sequenceNumber="1"]
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        List<String> reportBackElements = declarationResponse.getReportBackElements();
        List<String> controlMeans = declarationResponse.getControlMeans();

        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);

        Assertions.assertThat(controlMeans).hasSize(1)
                .contains("5");
    }


    @Test
    @Category(ChangeRequest.CR_339.class)
    public void WhenDeclarationSubmittedForMatchingCommittedVersionWithNewDraftRule_RouteReturnedForCommittedRule() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        //Note Rule version 1: dispatchCountry = DE is Committed Rule
        //Note Rule version 2: countryCode != UK is Draft Rule

        API.RulesManagementService.Utils.RuleAtStatus.CreateDraftRuleFromCommittedRule();


        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.dispatchCountry = "SP";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category(ChangeRequest.CR_339.class)
    //@Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void WhenDeclarationSubmittedForMatchingLatestCommittedVersion_RouteReturnedForLatestCommittedVersionOfRule() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        //Note Rule version 1: dispatchCountry = DE is no longer Committed Rule
        //Note Rule version 2: countryCode != UK is new Committed Rule

        EditRuleResponse.PutResponse response = API.RulesManagementService.Utils.RuleAtStatus.CreateDraftRuleFromCommittedRule();
        ruleDetails.uniqueID = response.uniqueId;
        ruleDetails.version = 2;
        API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails, RuleVersionActions.commit);


        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.consigneeCountry = "DE";
        declaration.declarationType = "IM";
        declaration.declarationSubType = "A";
        declaration.transportMode = "1";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        declaration.controlTypeExpectedValue = TestEnumerators.RuleOutputs.DOC_CHECK_VARY_RELEASE_GOODS.controlType; //Draft Rule Version Action Type changed to 2 --> Control Type 1
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category(ChangeRequest.CR_281.class)
    public void WhenDeclarationSubmittedForNoMatchingCommittedRule_NoRouteReturnedForCommittedRule() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);


        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.dispatchCountry = "ZZ";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        declaration.controlTypeExpectedValue = "";
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category(ChangeRequest.CR_267.class)
    public void WhenDeclarationSubmittedForMatchingDraftRule_NoRouteReturnedForDraftRule() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);


        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.dispatchCountry = "DE";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        declaration.controlTypeExpectedValue = "";
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category(ChangeRequest.CR_356.class)
    public void WhenDeclarationSubmittedForMatchingPendingRule_NoRouteReturnedForPendingRule() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.startDateTime = DateTime.AdjustLocalDateTimeNowByXDays(1, DateTime.DateTimeUTCZ);
        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);


        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.dispatchCountry = "DE";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        declaration.controlTypeExpectedValue = "";
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category(ChangeRequest.CR_279.class)
    public void WhenDeclarationSubmittedForMatchingArchivedRule_NoRouteReturnedForArchivedRule() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.Utils.RuleAtStatus.CreateArchivedRule(ruleDetails);


        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.dispatchCountry = "DE";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        declaration.controlTypeExpectedValue = "";
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_116.class, ChangeRequest.CR_904.class})
    public void WhenDeclarationSubmittedForMatchingCommittedRuleWithOperatorNotEquals_RouteReturnedForCommittedRule() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.queryConditions.get(0).conditions.get(0).operator = "neq";
        API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);


        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.dispatchCountry = "UK";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_1217.class, ChangeRequest.CR_1695.class,ChangeRequest.CR_2822.class})
    public void WhenDeclarationSubmittedForPhysicalCheck_ControlTypeAndHoldNarrativeReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.PHYSICAL_CHECK.actionType;
        ruleDetails.ruleOutputs.releaseNarrative = null;

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);


        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.commodity = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "1";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive(), this::decryptField);

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
        Assertions.assertThat(declarationResponse.isBlockingRelease()).isEqualTo(true);
        Assertions.assertThat(declarationResponse.getNarrativeText()).isEqualTo(ruleDetails.ruleOutputs.holdNarrative);
        Assertions.assertThat(declarationResponse.getIsSelfClosing()).hasSize(1).containsOnly(false);
        Assertions.assertThat(declarationResponse.getTimeToClose()).hasSize(1).containsOnly("0");

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_1217.class, ChangeRequest.CR_1695.class,ChangeRequest.CR_2822.class})
    public void WhenDeclarationSubmittedForDocumentCheckHoldGoods_ControlTypeAndHoldNarrativeReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_HOLD_GOODS.actionType;
        ruleDetails.ruleOutputs.releaseNarrative = "test hold narrative text for rule" + ruleDetails.description;

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);


        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.commodity = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "1";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";


        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive(), this::decryptField);

        //Assert
        declaration.controlTypeExpectedValue = TestEnumerators.RuleOutputs.DOC_CHECK_HOLD_GOODS.controlType; //Action Type 2 --> Control Type 1
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        Assertions.assertThat(declarationResponse.isBlockingRelease()).isTrue();
        Assertions.assertThat(declarationResponse.getNarrativeText()).isEqualTo(ruleDetails.ruleOutputs.holdNarrative);
        Assertions.assertThat(declarationResponse.getIsSelfClosing()).hasSize(1).containsOnly(false);
        Assertions.assertThat(declarationResponse.getTimeToClose()).hasSize(1).containsOnly("0");

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_1695.class, ChangeRequest.CR_1711.class,ChangeRequest.CR_2822.class})
    public void WhenDeclarationSubmittedForDocumentCheckReleaseGoods_ControlTypeAndReleaseNarrativeReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.releaseNarrative = "test release narrative text for rule" + ruleDetails.description;
        ruleDetails.ruleOutputs.holdPercentage = 100;
        ruleDetails.ruleOutputs.releasePercentage = 0;

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);


        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.commodity = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "1";
        declaration.controlTypeExpectedValue = TestEnumerators.RuleOutputs.DOC_CHECK_RELEASE_GOODS.controlType; // Document Check

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive(), this::decryptField);

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        Assertions.assertThat(declarationResponse.isBlockingRelease()).isFalse();
        Assertions.assertThat(declarationResponse.getNarrativeText()).isEqualTo(ruleDetails.ruleOutputs.releaseNarrative);
        Assertions.assertThat(declarationResponse.getIsSelfClosing()).hasSize(1).containsOnly(false);
        Assertions.assertThat(declarationResponse.getTimeToClose()).hasSize(1).containsOnly("0");
    }


    @Test
    @Category({ChangeRequest.CR_1695.class, ChangeRequest.CR_1711.class,ChangeRequest.CR_2822.class})
    public void WhenDeclarationSubmittedForDocumentCheckAndVaryReleaseGoods_ControlTypeAndHoldNarrativeReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_VARY_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.holdNarrative = "test hold narrative text for rule" + ruleDetails.uniqueID;
        ruleDetails.ruleOutputs.releaseNarrative = "This narrative will not be used";
        ruleDetails.ruleOutputs.holdPercentage = 100;
        ruleDetails.ruleOutputs.releasePercentage = 0;

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);


        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.commodity = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "1";
        declaration.controlTypeExpectedValue = TestEnumerators.RuleOutputs.DOC_CHECK_RELEASE_GOODS.controlType; // Document Check

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive(), this::decryptField);

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        Assertions.assertThat(declarationResponse.isBlockingRelease()).isTrue();
        Assertions.assertThat(declarationResponse.getNarrativeText()).isEqualTo(ruleDetails.ruleOutputs.holdNarrative);
        Assertions.assertThat(declarationResponse.getIsSelfClosing()).hasSize(1).containsOnly(false);
        Assertions.assertThat(declarationResponse.getTimeToClose()).hasSize(1).containsOnly("0");
    }

    @Test
    @Category({ChangeRequest.CR_1695.class, ChangeRequest.CR_1711.class, ChangeRequest.CR_2822.class})
    public void WhenDeclarationSubmittedForDocumentCheckAndVaryReleaseGoods_ControlTypeAndReleaseNarrativeReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_VARY_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.releaseNarrative = "test release narrative text for rule" + ruleDetails.uniqueID;
        ruleDetails.ruleOutputs.holdNarrative = "This narrative will not be used";
        ruleDetails.ruleOutputs.holdPercentage = 0;
        ruleDetails.ruleOutputs.releasePercentage = 100;

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);


        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.commodity = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "1";
        declaration.controlTypeExpectedValue = TestEnumerators.RuleOutputs.DOC_CHECK_VARY_RELEASE_GOODS.controlType;

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive(), this::decryptField);

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        Assertions.assertThat(declarationResponse.isBlockingRelease()).isFalse();
        Assertions.assertThat(declarationResponse.getNarrativeText()).isEqualTo(ruleDetails.ruleOutputs.releaseNarrative);
        Assertions.assertThat(declarationResponse.getIsSelfClosing()).hasSize(1).containsOnly(false);
        Assertions.assertThat(declarationResponse.getTimeToClose()).hasSize(1).containsOnly("0");
    }

    @Test
    @Category({ChangeRequest.CR_1216.class})
    public void WhenDeclarationSubmittedForTransportTypeMaritime_ControlTypeAndRouteReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);
        ruleDetails.queryOptions.transportMode = TransportMode.Maritime.toString();

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);


        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.commodity = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "1";
        declaration.transportMode = "1"; //Maritime = 1

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_1216.class})
    public void WhenDeclarationSubmittedForTransportTypeAll_ControlTypeAndRouteReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);
        ruleDetails.queryOptions.transportMode = TransportMode.All.toString();

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);


        publishAndWait(5000);

        //Act

        //Declaration 1
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.commodity = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "1";
        declaration.transportMode = "1"; //Maritime = 1

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());


        //Declaration 2
        TestDeclarationModel.Declaration declaration2 = new TestDeclarationModel.Declaration();
        declaration2.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration2.commodity = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration2.sequenceNumber = "1";
        declaration2.transportMode = "4"; //Air = 4

        declaration2.reportBackElementsExpectedValue = declaration2.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        String declarationRequest2 = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest2);
        DeclarationResponse declarationResponse2 = new DeclarationResponse(queue.receive());

        //Assert
        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);

        List<String> reportBackElements2 = declarationResponse2.getReportBackElements();
        Assertions.assertThat(reportBackElements2).hasSize(1)
                .contains(declaration2.reportBackElementsExpectedValue);
    }


    @Test
    @Category(ChangeRequest.CR_2456.class)
    public void WhenDeclarationSubmitted_NarrativeFieldReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.PHYSICAL_CHECK.actionType; // Action Type --> Control Type will be equal to 2

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.commodity = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "1";

        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        String response = queue.receive();
        System.out.println("Ze xml:\n" + response);
        DeclarationResponse declarationResponse = new DeclarationResponse(response, this::decryptField);

        //Assert
        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);

        Assertions.assertThat(declarationResponse.getMatchReasons()).hasSize(1);

        String expReason1 = "Declaration field: 'Declaration Type' was equal to " + declaration.declarationType + ". The value was: '" + declaration.declarationType + "'";
        String expReason2 = "Declaration field: 'Transport Mode' was equal to " + declaration.transportMode + ". The value was: '" + declaration.transportMode + "'";
        String expReason3 = "Declaration field: 'Declaration Sub-type' was equal to " + declaration.declarationSubType + ". The value was: '" + declaration.declarationSubType + "'";
        String expReason4 = "Goods Item (sequenceId=1) field: 'Commodity Code (TSP & TRC)' was equal to " + declaration.commodity + ". The value was: '" + declaration.commodity + "'";

        Assertions.assertThat(declarationResponse.getMatchReasons().get(0)).containsOnly(expReason1, expReason2, expReason3, expReason4);
    }


    @Test
    @Category({ChangeRequest.CR_2740.class})
    public void WhenDeclarationSubmittedForRuleOutputSecretTask_RouteReturned() {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.destinationCountry_Header();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.PHYSICAL_CHECK.actionType; // Action Type --> Control Type will be equal to 2
        ruleDetails.ruleOutputs.secretTask = true;

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.destinationCountry_Header = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        declaration.controlInstructionExt4IsSecret.add(true);
        assertThat(declarationResponse.getIsSecret()).isEqualTo(declaration.controlInstructionExt4IsSecret);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }


    @Test
    @Category({ChangeRequest.CR_2740.class})
    public void WhenDeclarationSubmittedForRuleOutputSecretTask_2MatchingSecretRules_RouteReturned() {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.destinationCountry_Header();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.PHYSICAL_CHECK.actionType; // Action Type --> Control Type will be equal to 2
        ruleDetails.ruleOutputs.secretTask = true;

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        ruleDetails.description = "rule2";
        EditRuleVersionResponse.PutResponse ruleResponse2 = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.destinationCountry_Header = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        declaration.controlInstructionExt4IsSecret.add(true);
        declaration.controlInstructionExt4IsSecret.add(true);
        assertThat(declarationResponse.getIsSecret()).isEqualTo(declaration.controlInstructionExt4IsSecret);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }


    @Test
    @Category({ChangeRequest.CR_2740.class})
    public void WhenDeclarationSubmittedForRuleOutputSecretTask_2MatchingRules1SecretRule_RouteReturned() {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.destinationCountry_Header();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.PHYSICAL_CHECK.actionType; // Action Type --> Control Type will be equal to 2
        ruleDetails.ruleOutputs.secretTask = true;

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        ruleDetails.description = "rule2";
        ruleDetails.ruleOutputs.secretTask = false;
        EditRuleVersionResponse.PutResponse ruleResponse2 = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.destinationCountry_Header = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        assertThat(declarationResponse.getIsSecret()).contains(true, false);

        if (ruleResponse.ruleId.equals(declarationResponse.getProfileId().get(0))) {

            assertThat(declarationResponse.getIsSecret().get(0).equals(true));
        } else {
            assertThat(declarationResponse.getIsSecret().get(1).equals(true));
        }

        if (ruleResponse2.ruleId.equals(declarationResponse.getProfileId().get(0))) {

            assertThat(declarationResponse.getIsSecret().get(0).equals(false));
        } else {
            assertThat(declarationResponse.getIsSecret().get(1).equals(false));
        }

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }


    @Test
    @Category({ChangeRequest.CR_2739.class})
    public void WhenDeclarationSubmittedForSelfClosingTypeTimed_2MatchingRules1SelfClosingTask_RouteReturned() {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.destinationCountry_Header();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);
        ruleDetails.ruleOutputs.actionType = "1";
        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        ruleDetails.description = "rule2";
        ruleDetails.ruleOutputs.timeToClose = 3600;
        EditRuleVersionResponse.PutResponse ruleResponse2 = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.destinationCountry_Header = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

        assertThat(declarationResponse.getTimeToClose()).containsOnly("0","3600");
        assertThat(declarationResponse.getIsSelfClosing()).containsOnly(false);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).contains("/declaration");
    }

    @Test
    @Category({ChangeRequest.CR_2742.class,ChangeRequest.CR_2822.class})
    public void WhenDeclarationSubmittedForInformationControlTaskForPhysicalCheck_ControlTypeControlAgentAndNarrativeReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.PHYSICAL_CHECK.actionType;
        ruleDetails.ruleOutputs.holdNarrative = "Hold Narrative";
        ruleDetails.ruleOutputs.assigneeID = ASSIGNEE_ID;
        ruleDetails.ruleOutputs.secretTask = true;

        ruleDetails.ruleOutputs.standaloneInfoNarrative = "test standalone info narrative text for rule" + ruleDetails.description;
        ruleDetails.ruleOutputs.informationNarrativeAssignee = "test@user.gsi.gov.uk";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.commodity = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "1";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";
        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getControlTypeList().get(0)).isEqualTo("2");
        Assertions.assertThat(declarationResponse.getBlockingReleaseList().get(0)).isEqualTo(true);
        Assertions.assertThat(declarationResponse.getIsSelfClosing().get(0)).isEqualTo(false);
        Assertions.assertThat(declarationResponse.getTimeToClose()).hasSize(1).containsOnly("0");

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_2742.class,ChangeRequest.CR_2822.class})
    public void WhenDeclarationSubmittedForInformationControlTaskForDocumentCheckAndHoldGoods_ControlTypeControlAgentAndNarrativeReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_HOLD_GOODS.actionType;
        ruleDetails.ruleOutputs.holdNarrative = "Hold Narrative";
        ruleDetails.ruleOutputs.standaloneInfoNarrative = "test standalone info narrative text for rule" + ruleDetails.description;
        ruleDetails.ruleOutputs.informationNarrativeAssignee = "test@user.gsi.gov.uk";
        ruleDetails.ruleOutputs.assigneeID = ASSIGNEE_ID;

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.commodity = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.sequenceNumber = "1";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getControlTypeList().get(0)).isEqualTo("1");
        Assertions.assertThat(declarationResponse.getBlockingReleaseList().get(0)).isEqualTo(true);
        Assertions.assertThat(declarationResponse.getIsSelfClosing().get(0)).isEqualTo(false);
        Assertions.assertThat(declarationResponse.getTimeToClose()).hasSize(1).containsOnly("0");
//        Assertions.assertThat(declarationResponse.getControlAgent().get(0)).isEqualTo(CONTROL_AGENT);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_2742.class,ChangeRequest.CR_2822.class})
    public void WhenDeclarationSubmittedForInformationControlTaskForDocumentCheckAndReleaseGoods_ControlTypeControlAgentAndNarrativeReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.releaseNarrative = "Release Narrative";

        ruleDetails.ruleOutputs.standaloneInfoNarrative = "test standalone info narrative text for rule" + ruleDetails.description;
        ruleDetails.ruleOutputs.informationNarrativeAssignee = "test@user.gsi.gov.uk";

        ruleDetails.ruleOutputs.assigneeID = ASSIGNEE_ID;
        ruleDetails.ruleOutputs.secretTask = false;

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.commodity = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.sequenceNumber = "1";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());


        //Assert
        Assertions.assertThat(declarationResponse.getControlTypeList().get(0)).isEqualTo("1");
        Assertions.assertThat(declarationResponse.getBlockingReleaseList().get(0)).isEqualTo(false);
        Assertions.assertThat(declarationResponse.getIsSelfClosing().get(0)).isEqualTo(false);
        Assertions.assertThat(declarationResponse.getTimeToClose()).hasSize(1).containsOnly("0");
        Assertions.assertThat(declarationResponse.getIsSecret().get(0)).isEqualTo(false);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_2742.class,ChangeRequest.CR_2822.class})
    public void WhenDeclarationSubmittedForInformationControlTaskForDocumentCheckAndVaryReleaseGoods_ControlTypeControlAgentAndNarrativeReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.commodityCode();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_VARY_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.holdNarrative = "Hold Narrative";
        ruleDetails.ruleOutputs.releaseNarrative = "Release Narrative";
        ruleDetails.ruleOutputs.holdPercentage = 50;
        ruleDetails.ruleOutputs.releasePercentage = 50;

        ruleDetails.ruleOutputs.standaloneInfoNarrative = "test standalone info narrative text for rule" + ruleDetails.description;
        ruleDetails.ruleOutputs.informationNarrativeAssignee = "test@user.gsi.gov.uk";

        ruleDetails.ruleOutputs.assigneeID = ASSIGNEE_ID;
        ruleDetails.ruleOutputs.timeToClose = 3600;

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.commodity = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.sequenceNumber = "1";
        declaration.reportBackElementsExpectedValue = declaration.reportBackElementsExpectedValue + declaration.sequenceNumber + "\"]";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());


        //Assert
        Assertions.assertThat(declarationResponse.getControlTypeList().get(0)).isEqualTo("1");
        Assertions.assertThat(declarationResponse.getIsSelfClosing().get(0)).isEqualTo(false);
        Assertions.assertThat(declarationResponse.getTimeToClose().get(0)).isEqualTo("3600");

        Assertions.assertThat(declarationResponse.getIsSecret().get(0)).isEqualTo(false);

        List<String> reportBackElements = declarationResponse.getReportBackElements();
        Assertions.assertThat(reportBackElements).hasSize(1)
                .contains(declaration.reportBackElementsExpectedValue);
    }

    @Test
    @Category(ChangeRequest.CR_3408.class)
    public void WhenDeclarationSubmittedForMatchingSilentRule_NoControlTaskForSilentRule() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.holdNarrative="Silent Rule";
        Condition condition = Conditions.dispatchCountry_domain();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);
        API.RulesManagementService.Utils.RuleAtStatus.CreateSilentRule(ruleDetails);
        publishAndWait(3000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.dispatchCountry = "DM";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getRiskAssement()).isEmpty();
    }

    @Test
    @Category(ChangeRequest.CR_3406.class)
    public void WhenRuleIsSuspendedAndThenSilenced_NoControlTaskForSilentRule() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.description="Silent Rule";
        ruleDetails.ruleOutputs.holdNarrative="Silent Rule";
        Condition condition = Conditions.dispatchCountry_domain();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);
        API.RulesManagementService.Utils.RuleAtStatus.CreateSuspendedRule(ruleDetails);
        publishAndWait(3000);

        API.RulesManagementService.Utils.RuleAtStatus.CreateSilentRule(ruleDetails);
        publishAndWait(3000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.dispatchCountry = "DM";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getRiskAssement()).isEmpty();
    }

    @Test
    @Category(ChangeRequest.CR_3423.class)
    public void WhenDeclarationSubmittedForReinstatedSilentRule_ControlTaskShouldExist() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.dispatchCountry_domain();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);
        publishAndWait(3000);

        API.RulesManagementService.Utils.RuleAtStatus.CreateReinstatedSilentRule(ruleDetails);
        publishAndWait(3000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.dispatchCountry = "DM";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getRiskAssement()).isNotNull();
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);

    }

    @Test
    @Category(ChangeRequest.CR_3424.class)
    public void WhenDeclarationSubmittedForSuspendedSilentRule_ControlTaskShouldNotExist() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        Condition condition = Conditions.dispatchCountry_domain();
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);
        API.RulesManagementService.Utils.RuleAtStatus.CreateSilentRule(ruleDetails);
        publishAndWait(3000);
        API.RulesManagementService.Utils.RuleAtStatus.SuspendRule(ruleDetails);
        publishAndWait(3000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.dispatchCountry = "DM";

        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getRiskAssement()).isEmpty();
    }

}
