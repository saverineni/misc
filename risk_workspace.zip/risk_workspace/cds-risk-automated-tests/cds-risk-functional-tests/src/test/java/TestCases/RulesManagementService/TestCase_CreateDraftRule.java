package TestCases.RulesManagementService;


import API.DataForTests.Conditions;
import API.DataForTests.RegimeCodes;
import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.EditRule.EditRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.Utils.Rules;
import API.RulesManagementService.ViewRule.ViewRuleResponse;
import API.RulesManagementService.ViewRuleList.ViewRuleListResponse;
import API.RulesManagementService.ViewRuleVersion.ViewRuleVersionResponse;
import Categories_CDSRisk.CDS_RM_CreateRules;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import FunctionsLibrary.FileUtilities;
import TestCases.BaseWebAPITestCase;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import static API.DataForTests.Locations.Location_National_UID;
import static API.DataForTests.RegimeCodes.Regime_ADD_UID;
import static API.DataForTests.TestRuleModel.RuleDetails;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@Category({Rules_Management.class, CDS_RM_CreateRules.class})
public class TestCase_CreateDraftRule extends BaseWebAPITestCase {

    @Test
    @Category({ChangeRequest.CR_267.class, ChangeRequest.CR_345.class, ChangeRequest.CR_609.class, ChangeRequest.CR_1135.class,
    ChangeRequest.CR_1147.class})
    public void WhenValidRuleSaved_DraftRuleCreatedSuccessfullyWithAllRuleDetails() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);
    }

    @Test
    @Category({ChangeRequest.CR_267.class})
    public void WhenValidRuleSaved_RulePresentInListOfRulesWithCorrectRuleDetails() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response.uniqueId;

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        assertEquals(HttpStatus.SC_OK, ruleList.httpStatusCode);
        ViewRuleListResponse.AssertViewRuleListResponse(ruleDetails, ruleList);
    }

    @Test
    @Category(ChangeRequest.CR_221.class)
    public void WhenDraftRuleSaved_DraftRulePresentInRuleSummaryWithCorrectRuleDetails() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(response.uniqueId);

        //Assert
        assertEquals(HttpStatus.SC_OK, viewRuleResponse.httpStatusCode);
        ViewRuleResponse.AssertViewRuleResponse(ruleDetails, viewRuleResponse);
    }


    @Test
    @Category({ChangeRequest.CR_221.class, ChangeRequest.CR_609.class, ChangeRequest.CR_1135.class})
    public void WhenNewRuleSearchedByIDAndVersion_CorrectRuleVersionDetailsReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(response.uniqueId, ruleDetails.version);

        //Assert
        assertEquals(HttpStatus.SC_OK, viewRuleVerResponse.httpStatusCode);
        ViewRuleVersionResponse.AssertViewRuleVersionResponse(ruleDetails, viewRuleVerResponse);
    }


    @Test
    @Category({ChangeRequest.CR_267.class})
    public void WhenLocalBlankRuleSavedWithJustMandatoryFields_DraftRuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.BlankDraftLocRuleLocalManager();

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_1837.class})
    public void WhenLocalBlankRuleSavedWithJustMandatoryFields_RuleCanBeViewedSuccessfully() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.BlankDraftLocRuleLocalManager();

        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(response.uniqueId);
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(response.uniqueId, ruleDetails.version);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        assertEquals(HttpStatus.SC_OK, viewRuleResponse.httpStatusCode);
        assertEquals(HttpStatus.SC_OK, viewRuleVerResponse.httpStatusCode);
    }

    @Test
    @Category({ChangeRequest.CR_267.class})
    public void WhenNationalBlankRuleSaved_DraftRuleNOTCreated() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.BlankDraftNatRuleNatManager();

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, response.httpStatusCode);
        //TODO update when proper validation messages returned
        String actMessage = response.response.path("message");

        //assertEquals("Regime code must be set for a national rule", response.response.path("message"));
        //assertEquals("Invalid regime code: ''", response.response.path("message"));

    }


    //This test can be used to test that a rule can be saved without setting value for a field
    @Test
    @Category(ChangeRequest.CR_345.class)
    public void WhenPartiallyCompletedNationalRuleSaved_DraftRuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.BlankDraftNatRuleNatManager();
        ruleDetails.regimeCodeUuid = Regime_ADD_UID;
        ruleDetails.reason = "Testing";
        ruleDetails.description = "Description";

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
    }


    @Test
    @Category({ChangeRequest.CR_222.class, ChangeRequest.CR_1205.class})
    public void WhenDraftRuleSaved_NewVersionOfDraftRuleCreatedSuccessfullyWithSameRuleID() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ruleDetails.description = "ta_updatedRule";
        ruleDetails.uniqueID = createRuleResponse.uniqueId;
        API.RulesManagementService.EditRule.EditRuleResponse.PutResponse editResponse = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_OK, editResponse.httpStatusCode);
        assertEquals(ruleDetails.description, editResponse.description);
        Assertions.assertThat(createRuleResponse.ruleId).containsPattern(ruleDetails.ruleId);
        Assertions.assertThat(editResponse.ruleId).containsPattern(ruleDetails.ruleId);
        assertEquals(createRuleResponse.ruleId, editResponse.ruleId);
    }


    @Test
    @Category({ChangeRequest.CR_221.class, ChangeRequest.CR_220.class})
    public void WhenDraftRuleSaved_OnlyLatestVersionPresentInListOfRules() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        ruleDetails.description = "ta_updatedRule";
        ruleDetails.uniqueID = createRuleResponse.uniqueId;
        Response editResponse = API.RulesManagementService.Utils.Rules.EditRule(ruleDetails);

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert

        CreateRuleResponse.PostResponse actRuleResp = new CreateRuleResponse.PostResponse();
        for (int i=0; i < ruleList.content.size(); i++)
        {
            if(ruleList.content.get(i).uniqueId.equals(ruleDetails.uniqueID)){

                actRuleResp.description = ruleList.content.get(i).description;
                actRuleResp.versionId = ruleList.content.get(i).versionId;
                break;
            }
        }

        assertEquals(ruleDetails.description, editResponse.path("description"));
        assertEquals("latest version: ", 2, actRuleResp.versionId);
    }


    @Test
    @Category({ChangeRequest.CR_222.class, ChangeRequest.CR_609.class})
    public void WhenDraftRuleUpdated_NewVersionOfDraftRuleCreatedSuccessfullyWithAllRuleDetails() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        ruleDetailsV2.uniqueID = createRuleResponse.uniqueId;
        ruleDetailsV2.ruleId = ruleDetails.ruleId;      //Rule ID does not change even if regime code changes

        EditRuleResponse.PutResponse editRule = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetailsV2);

        //Assert
        assertEquals(HttpStatus.SC_OK, editRule.httpStatusCode);
        EditRuleResponse.AssertEditRuleResponse(ruleDetailsV2, editRule);
    }


    @Test
    @Category({ChangeRequest.CR_2741.class})
    public void WhenDraftRuleUpdatedWithNewRuleOutput_NewVersionOfDraftRuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        ruleDetailsV2.uniqueID = createRuleResponse.uniqueId;
        ruleDetailsV2.ruleId = ruleDetails.ruleId;      //Rule ID does not change even if regime code changes
        ruleDetailsV2.ruleOutputs.actionType = "5";
        ruleDetailsV2.ruleOutputs.holdNarrative=null;
        ruleDetailsV2.ruleOutputs.standaloneInfoNarrative = "standalone info narrative";
        ruleDetailsV2.ruleOutputs.informationNarrativeAssignee = "test@user.gsi.gov.uk";
        ruleDetailsV2.ruleOutputs.assigneeID = "TEAM01";
        ruleDetailsV2.ruleOutputs.timeToClose=null;

        EditRuleResponse.PutResponse editRule = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetailsV2);

        //Assert
        assertEquals(HttpStatus.SC_OK, editRule.httpStatusCode);
        EditRuleResponse.AssertEditRuleResponse(ruleDetailsV2, editRule);
    }

    @Test
    @Category({ChangeRequest.CR_2742.class})
    public void WhenDraftRuleUpdatedWithInformationTask_NewVersionOfDraftRuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        ruleDetailsV2.uniqueID = createRuleResponse.uniqueId;
        ruleDetailsV2.ruleId = ruleDetails.ruleId;      //Rule ID does not change even if regime code changes
        ruleDetailsV2.ruleOutputs.actionType = TestEnumerators.RuleOutputs.PHYSICAL_CHECK.actionType;
        ruleDetailsV2.ruleOutputs.standaloneInfoNarrative = "standalone info narrative";
        ruleDetailsV2.ruleOutputs.informationNarrativeAssignee = "test@user.x.gsi.gov.uk";
        ruleDetailsV2.ruleOutputs.assigneeID = "TEAM01";

        EditRuleResponse.PutResponse editRule = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetailsV2);

        //Assert
        assertEquals(HttpStatus.SC_OK, editRule.httpStatusCode);
        EditRuleResponse.AssertEditRuleResponse(ruleDetailsV2, editRule);
    }

    @Test
    @Category(ChangeRequest.CR_116.class)
    public void WhenRuleWithORConditionSubmitted_RuleCreatedSuccessfully() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).operator = "or";
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.dispatchCountry());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consigneeName());

        //Act
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
    }

    @Test
    @Category({ChangeRequest.CR_116.class, ChangeRequest.CR_117.class})
    public void WhenRuleWithNestedConditionSubmitted_RuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        String sDescription = "ta_NestedCondition";

        FunctionsLibrary.FileUtilities fileUtils = new FunctionsLibrary.FileUtilities();
        String ruleRequestJsonBody = fileUtils.ReadContentsOfFileToString("/TestData/RM_JSON_Rule_NestedCondition_1");

        sDescription = fileUtils.GenerateAppendUIDToString(sDescription, 5);
        ruleRequestJsonBody = ruleRequestJsonBody.replaceAll("Nested Condition" , sDescription);
        ruleRequestJsonBody = ruleRequestJsonBody.replaceAll("#locationUuids#" , Location_National_UID);
        ruleRequestJsonBody = ruleRequestJsonBody.replaceAll("#regimeUuidOnlyNeededForNationalRule#" , ",\"regimeUuid\": \"" + Regime_ADD_UID + "\"");
        ruleRequestJsonBody = ruleRequestJsonBody.replaceAll("#actionType#" , "1");
        ruleRequestJsonBody = ruleRequestJsonBody.replaceAll("#holdNarrative#" , "\"test hold narrative\"");
        ruleRequestJsonBody = ruleRequestJsonBody.replaceAll("#reason#" , "\"Testing\"");

        //Act
        Response response = API.RulesManagementService.Utils.Rules.CreateRuleUsingJSONRequestBody(ruleRequestJsonBody, sDescription);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.getStatusCode());
    }


    @Test
    @Category({ChangeRequest.CR_220.class})
    public void WhenMultipleRulesCreated_RulesPresentInListOfRules() {

        //Arrange
        ViewRuleListResponse.ViewRuleListResponseObject ruleListAtStart = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //create 1 Draft Rule with 2 Versions
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response.uniqueId;

        Response editResponse = API.RulesManagementService.Utils.Rules.EditRule(ruleDetails);

        //create 1 Committed Rule
        RuleDetails ruleDetails2 = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response2 = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails2);
        ruleDetails2.uniqueID = response2.uniqueId;

        EditRuleVersionResponse.PutResponse commitRuleResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails2,
                RuleVersionActions.commit);

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject ruleList = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        //3 rules in total, but 1 rule is a previous version so not included
        assertEquals(2, ruleList.content.size() - ruleListAtStart.content.size());
    }


    @Test
    @Category(ChangeRequest.CR_221.class)
    public void WhenNewVersionOfDraftRuleSaved_DraftRuleVersionsPresentInRuleSummary() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        ruleDetailsV2.uniqueID = response.uniqueId;
        Response editResponse = API.RulesManagementService.Utils.Rules.EditRule(ruleDetailsV2);

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(response.uniqueId);

        //Assert
        assertEquals("Expected Number of Rules 2: ", 2, viewRuleResponse.versions.size());
        assertEquals( ruleDetails.description, viewRuleResponse.versions.get(1).description);
        assertEquals( ruleDetailsV2.description, viewRuleResponse.versions.get(0).description);
    }



    @Test
    @Category(ChangeRequest.CR_221.class)
    public void WhenRuleSearchedByInvalidID_NotFoundResponseReceived() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(response.uniqueId + "zzz");

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, viewRuleResponse.httpStatusCode);

    }

    @Test
    @Category(ChangeRequest.CR_221.class)
    public void WhenRuleSearchedByNonExistentID_NotFoundResponseReceived() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        response.uniqueId = "9698fc61-985c-4fa5-a398-8843ca77e82e";
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(response.uniqueId);

        //Assert
        assertEquals(HttpStatus.SC_NOT_FOUND, viewRuleResponse.httpStatusCode);

    }


    @Test
    @Category({ChangeRequest.CR_116.class, ChangeRequest.CR_609.class})
    public void WhenEditedRuleSearchedByIDAndVersion_CorrectRuleVersionReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        ruleDetailsV2.uniqueID = response.uniqueId;
        EditRuleResponse.PutResponse editResponse = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetailsV2);

        ruleDetailsV2.ruleId = ruleDetails.ruleId;      //Rule ID does not change even if Regime code is updated

        //Act
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(response.uniqueId, ruleDetailsV2.version);

        //Assert
        ViewRuleVersionResponse.AssertViewRuleVersionResponse(ruleDetailsV2, viewRuleVerResponse);
    }


    @Test
    @Category(ChangeRequest.CR_221.class)
    public void WhenPreviousVersionOfRuleSearchedByIDAndVersion_CorrectRuleVersionReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        ruleDetailsV2.uniqueID = response.uniqueId;
        EditRuleResponse.PutResponse editResponse = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetailsV2);

        //Act
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(response.uniqueId, ruleDetails.version);

        //Assert
        ViewRuleVersionResponse.AssertViewRuleVersionResponse(ruleDetails, viewRuleVerResponse);
    }


    @Test
    @Category({ChangeRequest.CR_221.class, ChangeRequest.CR_2274.class})
    public void WhenRuleEditedAndSavedMultipleTimes_CorrespondingVersionsCreated() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        ruleDetailsV2.uniqueID = response.uniqueId;
        EditRuleResponse.PutResponse editResponse = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetailsV2);

        RuleDetails ruleDetailsV3 = API.DataForTests.Rules.DraftVersion3NatRuleNatManager();
        ruleDetailsV3.uniqueID = response.uniqueId;
        EditRuleResponse.PutResponse editResponse3 = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetailsV2);

        ruleDetailsV3.ruleId = ruleDetails.ruleId;  //rule id does not change

        //Act
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(response.uniqueId, ruleDetailsV3.version);
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponseObject = Rules.GetRuleByUID(response.uniqueId);

        //Assert
        ViewRuleVersionResponse.AssertViewRuleVersionResponse(ruleDetailsV3, viewRuleVerResponse);

        Assertions.assertThat(viewRuleResponseObject.versions)
                    .extracting("versionId").containsExactly(3,2,1);

    }


    @Test
    @Category(ChangeRequest.CR_222.class)
    public void AttemptToEditInvalidRuleID_NotFoundResponseReceived() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ruleDetails.uniqueID = "471e5818-146e-11e7-bbc6-0242ac110dbb";
        EditRuleResponse.PutResponse editResponse = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_NOT_FOUND, editResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_609.class)
    public void WhenRegimeCodeUpdated_RuleIDContainsOriginalRegimeCode() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.regimeCode = "ADD";
        ruleDetails.regimeCodeUuid = Regime_ADD_UID;

        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response.uniqueId;

        //Act
        ruleDetails.regimeCode = "ICE";
        ruleDetails.regimeCodeUuid = RegimeCodes.Regime_ICE_UID;
        ruleDetails.version = 2;
        ruleDetails.ruleId = "NAT-ADD";

        EditRuleResponse.PutResponse editResponse = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertTrue("Expect Rule ID NOT to change: " + response.ruleId, response.ruleId.contains(ruleDetails.ruleId));
        assertTrue("Expect Rule ID NOT to change: " + editResponse.ruleId, editResponse.ruleId.contains(ruleDetails.ruleId));
    }


    @Test
    @Category({ChangeRequest.CR_609.class})
    public void AttemptToSaveRuleWithNoRegimeCode_RuleNotCreated() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.regimeCodeUuid = "";

        //Act
        Response response = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, response.statusCode());
        assertEquals("National rule type must have regime set.", response.path("message"));
    }


    @Test
    @Category({ChangeRequest.CR_1222.class})
    public void AttemptToSaveRuleWithLongDescription_RuleNotCreated() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.description = "ta_longDescription30CharsAll"; //26 chars + 5 random chars appended by CreateRule method

        //Act
        Response response = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, response.statusCode());
    }


    @Test
    @Category({ChangeRequest.CR_1695.class})
    public void WhenRuleSavedWithMaxLengthHoldNarrative_RuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.holdNarrative = FileUtilities.GenerateRandomAlphaNumericString(256, true, true);

        //Act
        Response response = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.statusCode());
    }


    @Test
    @Category({ChangeRequest.CR_1711.class})
    public void WhenRuleSavedWithMaxLengthReleaseNarrative_RuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.releaseNarrative = FileUtilities.GenerateRandomAlphaNumericString(256, true, true);

        //Act
        Response response = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.statusCode());
    }

    @Test
    @Category({ChangeRequest.CR_2741.class})
    public void WhenRuleSavedWithMaxLengthStandaloneInfoNarrative_RuleCreatedSuccessfully() throws Throwable
    {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.INFORMATION_TASK.actionType;
        ruleDetails.ruleOutputs.holdNarrative = null;
        ruleDetails.ruleOutputs.standaloneInfoNarrative = FileUtilities.GenerateRandomAlphaNumericString(256, true, true);

        //Act
        Response response = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.statusCode());
    }


    @Test
    @Category({ChangeRequest.CR_1695.class})
    public void WhenRuleSavedWithMinLengthHoldNarrative_RuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.holdNarrative = FileUtilities.GenerateRandomAlphaNumericString(1, true, true);

        //Act
        Response response = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.statusCode());
    }

    @Test
    @Category({ChangeRequest.CR_1711.class})
    public void WhenRuleSavedWithMinLengthReleaseNarrative_RuleCreatedSuccessfully() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.DOC_CHECK_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.releaseNarrative = FileUtilities.GenerateRandomAlphaNumericString(1, true, true);

        //Act
        Response response = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.statusCode());
    }

    @Test
    @Category({ChangeRequest.CR_2741.class})
    public void WhenRuleSavedWithMinLengthStandaloneInfoNarrative_RuleCreatedSuccessfully() throws Throwable
    {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType = TestEnumerators.RuleOutputs.INFORMATION_TASK.actionType;
        ruleDetails.ruleOutputs.standaloneInfoNarrative = FileUtilities.GenerateRandomAlphaNumericString(1, true, true);

        //Act
        Response response = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.statusCode());
    }

    @Test
    @Category({ChangeRequest.CR_1695.class, ChangeRequest.CR_3397.class})
    public void AttemptToSaveRuleWithLongHoldNarrative_RuleCreated() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.holdNarrative = FileUtilities.GenerateRandomAlphaNumericString(10000, true, true);

        //Act
        Response response = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.statusCode());
    }


    @Test
    @Category({ChangeRequest.CR_1711.class, ChangeRequest.CR_3397.class})
    public void AttemptToSaveRuleWithLongReleaseNarrative_RuleCreated() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType =  TestEnumerators.RuleOutputs.DOC_CHECK_RELEASE_GOODS.actionType;
        ruleDetails.ruleOutputs.releaseNarrative = FileUtilities.GenerateRandomAlphaNumericString(6000, true, true);

        //Act
        Response response = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.statusCode());
    }

    @Test
    @Category({ChangeRequest.CR_2741.class, ChangeRequest.CR_3397.class})
    public void AttemptToSaveRuleWithLongStandaloneInfoNarrative_RuleNotCreated() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.actionType =  TestEnumerators.RuleOutputs.INFORMATION_TASK.actionType;
        ruleDetails.ruleOutputs.releaseNarrative = FileUtilities.GenerateRandomAlphaNumericString(10001, true, true);

        //Act
        Response response = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, response.statusCode());
    }


    @Test
    @Category(ChangeRequest.CR_1366.class)
    public void WhenRuleWithANDConditionAtHeaderLevelSubmitted_RuleCreatedSuccessfully() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.dispatchCountry());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consigneeName());

        //Act
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_1366.class)
    public void WhenRuleWithORConditionAtHeaderLevelSubmitted_RuleCreatedSuccessfully() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).operator = "or";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.dispatchCountry());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.consigneeName());

        //Act
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_1366.class)
    public void WhenRuleWithANDConditionAtItemLevelSubmitted_RuleCreatedSuccessfully() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.originCountry_Item());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.commodityCode());

        //Act
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_1366.class)
    public void WhenRuleWithORConditionAtItemLevelSubmitted_RuleCreatedSuccessfully() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();

        ruleDetails.queryConditions.get(0).operator = "or";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.originCountry_Item());
        ruleDetails.queryConditions.get(0).conditions.add(Conditions.commodityCode());

        //Act
        API.RulesManagementService.CreateRule.CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
    }

    @Test
    @Category({ChangeRequest.CR_1481.class})
    public void WhenRuleSavedWithOperatorStartWith_DraftRuleCreatedSuccessfully() {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.DataForTests.TestRuleModel.RuleDetails.Condition condition = Conditions.commodityCode();

        condition.operator = "st";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);
    }

    @Test
    @Category({ChangeRequest.CR_1481.class})
    public void WhenRuleSavedWithOperatorDoesNotStartWith_DraftRuleCreatedSuccessfully() {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        API.DataForTests.TestRuleModel.RuleDetails.Condition condition = Conditions.consigneeEori();

        condition.operator = "nst";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);
    }


    //RATS Rules

    @Test
    @Category({ChangeRequest.CR_1636.class})
    public void WhenValidRatsRuleSaved_DraftRuleCreatedSuccessfully() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleWithRatsNatManager();

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);
    }

    @Test
    @Category({ChangeRequest.CR_1636.class})
    public void WhenRatsRuleSearchedByIDAndVersion_CorrectRuleVersionDetailsReturned() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleWithRatsNatManager();
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ViewRuleVersionResponse.ViewRuleVersionResponseObject viewRuleVerResponse = API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(response.uniqueId, ruleDetails.version);

        //Assert
        assertEquals(HttpStatus.SC_OK, viewRuleVerResponse.httpStatusCode);
        ViewRuleVersionResponse.AssertViewRuleVersionResponse(ruleDetails, viewRuleVerResponse);
    }


    @Test
    @Category({ChangeRequest.CR_1636.class})
    public void WhenValidRatsRuleWithThresholdWithinLimitsSaved_DraftRuleCreatedSuccessfully() {

        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleWithRatsNatManager();
        ruleDetails.ratDefinition.hitRate.limit = 99999;

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);
    }

    @Test
    @Category({ChangeRequest.CR_1636.class})
    public void AttemptToSaveRatsRuleWithNegativeThresholdLimit_RuleNotSaved() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleWithRatsNatManager();
        ruleDetails.ratDefinition.hitRate.limit = -1;

        //Act
        Response createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, createRuleResponse.statusCode());
    }


    @Test
    @Category({ChangeRequest.CR_1636.class})
    public void AttemptToSaveRatsRuleWithThresholdLimitAboveUpperLimit_RuleNotSaved() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleWithRatsNatManager();
        ruleDetails.ratDefinition.hitRate.limit = 100000;

        //Act
        Response createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, createRuleResponse.statusCode());
    }

    @Test
    @Category({ChangeRequest.CR_1636.class})
    public void WhenRatsRuleWithThresholdLimitWithinUpperLimitSaved_RuleSaved() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleWithRatsNatManager();
        ruleDetails.ratDefinition.hitRate.limit = 99999;

        //Act
        Response createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, createRuleResponse.statusCode());
    }


    @Test
    @Category({ChangeRequest.CR_1636.class})
    public void WhenRatsRuleWithNoThresholdLimitSaved_RuleNotSaved() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleWithRatsNatManager();
        ruleDetails.ratDefinition.hitRate.limit = null;

        //Act
        Response createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, createRuleResponse.statusCode());
    }


    @Test
    @Category({ChangeRequest.CR_1880.class})
    public void AttemptToSaveRuleWithNoReason_RuleNotCreated() throws Throwable
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.reason = null;

        //Act
        Response response = API.RulesManagementService.Utils.Rules.CreateRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, response.statusCode());
    }


    @Test
    @Category({ChangeRequest.CR_2740.class})
    public void WhenRuleSavedWithRuleOutputSecretTask_DraftRuleCreatedSuccessfully()
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.secretTask = false;

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);
    }

    @Test
    @Category({ChangeRequest.CR_2739.class})
    public void WhenRuleSavedWithRuleOutputTimeToClose_DraftRuleCreatedSuccessfully()
    {
        //Arrange
        RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.ruleOutputs.timeToClose = 50;

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);
    }

}
