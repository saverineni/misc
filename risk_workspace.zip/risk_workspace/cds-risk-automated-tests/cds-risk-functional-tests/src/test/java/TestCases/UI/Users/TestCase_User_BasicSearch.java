package TestCases.UI.Users;

import API.DataForTests.PaginationInfo;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Users;
import Categories_CDSRisk.CDS_Risk_UI_Users_2;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.CommonComponents.PaginationToolBar;
import UI.ElementControls.MultiSelectDropDown;
import UI.Pages.UserManagement.ListUsers_Page;
import UI.Utils.Navigation;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import java.util.List;
import static FunctionsLibrary.Utils.SleepForMilliSeconds;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Users.class, CDS_Risk_UI_Users_2.class})
public class TestCase_User_BasicSearch extends BaseUIWebDriverTestCase {

    TestUserModel.UserDetails userDetails_AdminLocal_POO;
    TestUserModel.UserDetails userDetails_RulesManagerLocal_POO;
    private PaginationInfo paginationInfo;
    MultiSelectDropDown multiSelectDropDown;


    @Before
    public void Setup() {
        //Arrange
        TestUserModel.UserDetails userDetails_AdminNational = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminNational);

        TestUserModel.UserDetails userDetails_SuperAdminNational = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_SuperAdminNational);

        TestUserModel.UserDetails userDetails_SuperAdminLocal_POO = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_SuperAdminLocal_POO);

        userDetails_AdminLocal_POO = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO);

        TestUserModel.UserDetails userDetails_AdminLocal_POO_EXT = Users_API.AdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO_EXT);

        userDetails_RulesManagerLocal_POO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RulesManagerLocal_POO);

        TestUserModel.UserDetails userDetails_RulesManager_EXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RulesManager_EXT);

        TestUserModel.UserDetails userDetails_RulesViewer_WAT = Users_API.RulesManagerLocal_WAT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RulesViewer_WAT);

        multiSelectDropDown = new MultiSelectDropDown(driver);

    }

    @Test
    @Category({ChangeRequest.CR_2610.class, ChangeRequest.CR_2614.class, ChangeRequest.CR_2615.class})
    public void WhenUserSearchedByUserRoleAndNameAndPid_CorrectUsersAreDisplayed() {

        //Act
        TestUserModel.UserDetails userDetails_AdminLocal_POO = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetails_AdminLocal_POO);

        Navigation utilNavigation = new Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);

        //Assert
        listUsers_page.selectValueFromDropDown(listUsers_page.userRole, "Admin");

        listUsers_page.searchNameTextField.sendKeys(userDetails_AdminLocal_POO.firstname);
        listUsers_page.searchPidNameTextField.sendKeys(userDetails_AdminLocal_POO.pid);
        SleepForMilliSeconds(500);

        List<ListUsers_Page.UserListTableObject> userListTableObject = listUsers_page.getListOfUsers();
        ListUsers_Page.UserListTableObject userTableObject = listUsers_page.getUserTableObjectFromUserListTableObject(userListTableObject, userDetails_AdminLocal_POO.pid);

        assertEquals(userDetails_AdminLocal_POO.pid, userTableObject.pid);
        assertEquals(userDetails_AdminLocal_POO.firstname + " " + userDetails_AdminLocal_POO.lastname, userTableObject.name);
    }

    @Test
    @Category({ChangeRequest.CR_2610.class})
    public void WhenUserSearchedByPartialName_CorrectUsersAreDisplayed() {

        //Act
        TestUserModel.UserDetails userDetails_AdminLocal_POO = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetails_AdminLocal_POO);

        Navigation utilNavigation = new Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);

        //Assert
        listUsers_page.searchNameTextField.sendKeys("La");
        SleepForMilliSeconds(500);



        List<ListUsers_Page.UserListTableObject> userListTableObject = listUsers_page.getListOfUsers();

        assertThat(userListTableObject)
                .hasSize(7)
                .extracting("name").containsOnly("Firstname0 Lastname0", "Firstname1 Lastname1", "Megan Lambert","Morriss Lawrence", "Sam Nolan",  "Vincent Landon", "Vicki Lane");

    }

    @Test
    @Category({ChangeRequest.CR_2610.class, ChangeRequest.CR_2614.class, ChangeRequest.CR_2615.class})
    public void WhenUserInAnotherPageIsSearched_CorrectUsersAreDisplayed() {

        //Act
        TestUserModel.UserDetails userDetails_AdminLocal_POO = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetails_AdminLocal_POO);

        Navigation utilNavigation = new Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);

        paginationInfo = new PaginationInfo();
        paginationInfo.iSizeOfPage = 5;
        paginationInfo.iElementsAdded = 0;
        paginationInfo = paginationInfo.calculatePaginationInfo(paginationInfo);
        PaginationToolBar paginationToolBar = new PaginationToolBar(driver);
        paginationToolBar.selectPageSize(paginationInfo.iSizeOfPage);
        SleepForMilliSeconds(500);

        //Assert
        listUsers_page.searchNameTextField.sendKeys("Sam");
        SleepForMilliSeconds(500);

        List<ListUsers_Page.UserListTableObject> userListTableObject = listUsers_page.getListOfUsers();
        ListUsers_Page.UserListTableObject userTableObject = listUsers_page.getUserTableObjectFromUserListTableObject(userListTableObject, userDetails_RulesManagerLocal_POO.pid);

        assertEquals(userDetails_RulesManagerLocal_POO.pid, userTableObject.pid);
        assertEquals(userDetails_RulesManagerLocal_POO.firstname + " " + userDetails_RulesManagerLocal_POO.lastname, userTableObject.name);
    }

    @Test
    @Category({ChangeRequest.CR_2676.class})
    public void WhenUserSearchedByBaseLocations_CorrectUsersAreDisplayed() {

        //Act
        TestUserModel.UserDetails userDetails_AdminLocal_POO = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetails_AdminLocal_POO);

        Navigation utilNavigation = new Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);

        listUsers_page.baseLocationsDropDown.click();
        boolean allLocations = multiSelectDropDown.verifyIfTheValueExists(listUsers_page.baseLocationsDropDown,"All Locations");

        listUsers_page.searchInput.sendKeys("333333");
        String noMatchingBaseLocations = listUsers_page.dropDownNoResults.getText();

        multiSelectDropDown.searchAndSelectTheValue(listUsers_page.baseLocationsDropDown,listUsers_page.searchInput,"waT","WAT - Watchet");
        multiSelectDropDown.searchAndSelectTheValue(listUsers_page.baseLocationsDropDown,listUsers_page.searchInput,"National Office","National Office");

        List<ListUsers_Page.UserListTableObject> listOfUsersForTheSelectedBaseLocations = listUsers_page.getListOfUsers();

        assertEquals("No results found",noMatchingBaseLocations);
        assertEquals(false,allLocations);
        assertThat(listOfUsersForTheSelectedBaseLocations)
                .extracting("baseLocation").containsOnly("National Office","WAT - Watchet");
    }

    @Test
    @Category({ChangeRequest.CR_3027.class})
    public void WhenNoUsersExistInTheUsersDashboard_NoUsersFoundIsDisplayed() {

        //Act
        TestUserModel.UserDetails userDetails_AdminLocal_POO = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AdminLocal_POO);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetails_AdminLocal_POO);

        Navigation utilNavigation = new Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);

        listUsers_page.selectValueFromDropDown(listUsers_page.userRole, "Rule Viewer");
        String noUsersFoundMessage = listUsers_page.noUsersFoundResults.getText();
        assertEquals("No Users Found", noUsersFoundMessage);
        listUsers_page.selectValueFromDropDown(listUsers_page.userRole, "All");

        listUsers_page.selectValueFromDropDown(listUsers_page.userStatus, "Suspended");
        assertEquals("No Users Found", noUsersFoundMessage);
        listUsers_page.selectValueFromDropDown(listUsers_page.userStatus, "All");

        listUsers_page.searchNameTextField.sendKeys("Testing");
        assertEquals("No Users Found", noUsersFoundMessage);
        listUsers_page.searchNameTextField.clear();

        listUsers_page.searchPidNameTextField.sendKeys("123456670");
        assertEquals("No Users Found", noUsersFoundMessage);
        listUsers_page.searchPidNameTextField.clear();

        listUsers_page.selectValueFromDropDown(listUsers_page.baseLocationsDropDown, "ABD - Aberdeen");
        assertEquals("No Users Found", noUsersFoundMessage);
    }
}

