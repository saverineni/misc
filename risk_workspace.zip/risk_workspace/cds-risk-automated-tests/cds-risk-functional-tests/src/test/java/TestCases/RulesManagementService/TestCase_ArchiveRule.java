package TestCases.RulesManagementService;


import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.EditRule.EditRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.RuleAction.RuleActionResponse;
import API.RulesManagementService.Utils.Rules;
import API.RulesManagementService.ViewRule.ViewRuleResponse;
import Categories_CDSRisk.CDS_RM_RuleLifeCycle;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import static API.RulesManagementService.Utils.RuleAtStatus.*;
import static API.RulesManagementService.Utils.Rules.UpdateStatusOfRule;
import static org.junit.Assert.assertEquals;


@Category({Rules_Management.class, CDS_RM_RuleLifeCycle.class})
public class TestCase_ArchiveRule extends BaseWebAPITestCase {

    @Test
    @Category(ChangeRequest.CR_279.class)
    public void WhenActiveRuleArchived_ActiveRuleArchivedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();

        ruleDetails.uniqueID = committedRuleResponse.uniqueId;

        //Act
        RuleActionResponse.PostResponse archiveResponse = ArchiveRule(ruleDetails);

        assertEquals(HttpStatus.SC_OK, archiveResponse.httpStatusCode);

        publishAndWait(5000);

        ViewRuleResponse.ViewRuleResponseObject getResponse = Rules.GetRuleByUID(ruleDetails.uniqueID);

        //Assert
        assertEquals(TestEnumerators.RuleStatus.archived.toString(), getResponse.leadVersion.status);
    }


    @Test
    @Category(ChangeRequest.CR_279.class)
    public void WhenSuspendedRuleArchived_RuleArchivedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse suspendedRuleResponse = CreateSuspendedRule(ruleDetails);
        ruleDetails.uniqueID = suspendedRuleResponse.uniqueId;

        //Act
        RuleActionResponse.PostResponse archiveResponse = ArchiveRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_OK, archiveResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_349.class)
    public void WhenReinstatedRuleArchived_RuleArchivedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse reinstatedRuleResponse = CreateReinstatedRule();
        ruleDetails.uniqueID = reinstatedRuleResponse.uniqueId;

        //Act
        RuleActionResponse.PostResponse archiveResponse = ArchiveRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_OK, archiveResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_279.class)
    public void AttemptToArchiveDraftRule_DraftRuleNotArchived() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        RuleActionResponse.PostResponse archiveResponse = ArchiveRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, archiveResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_279.class)
    public void AttemptToArchiveArchivedRule_InvalidRequest() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse archivedRuleResponse = CreateArchivedRule(ruleDetails);

        //Act
        RuleActionResponse.PostResponse archiveResponse = ArchiveRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, archiveResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_279.class)
    public void AttemptToDeleteArchivedRule_InvalidRequest() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse archivedRuleResponse = CreateArchivedRule(ruleDetails);

        //Act
        EditRuleVersionResponse.PutResponse deleteResponse = UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.delete);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, deleteResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_279.class)
    public void AttemptToUpdateArchivedRule_InvalidRequest() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse archivedRuleResponse = CreateArchivedRule(ruleDetails);

        //Act
        ruleDetails.description = "updateDescription";
        Response editResponse = API.RulesManagementService.Utils.Rules.EditRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, editResponse.getStatusCode());
        //assertEquals("You cannot update a archived rule", editResponse.path("message"));

        //TODO BUG: CR-1303: Message: 'You cannot update a live rule' instead of 'You cannot update a archived rule'
        //It should say you cannot update a archived rule. Will be fixed as part of general validation error message handling
    }


    @Test
    @Category(ChangeRequest.CR_279.class)
    public void AttemptToCommitArchivedRule_InvalidRequest() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse archivedRuleResponse = CreateArchivedRule(ruleDetails);

        //Act
        EditRuleVersionResponse.PutResponse archiveResponse = UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, archiveResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_279.class)
    public void AttemptToArchiveRuleWithInvalidID_RuleNotFound() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse committedRuleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();

        //Act
        ruleDetails.uniqueID = "468e720d-ac5d-4f3e-9ce1-41e6d1197241";
        RuleActionResponse.PostResponse archiveResponse = ArchiveRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_NOT_FOUND, archiveResponse.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_279.class)
    public void AttemptToArchiveOldRuleVersion_InvalidRequest() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleResponse.PutResponse draftV2Rule = API.RulesManagementService.Utils.RuleAtStatus.CreateDraftRuleVersion2Rule();
        ruleDetails.uniqueID = draftV2Rule.uniqueId;

        //Act
        ruleDetails.version = 1;
        RuleActionResponse.PostResponse archiveResponse = ArchiveRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, archiveResponse.httpStatusCode);
    }


    @Test
    @Category(ChangeRequest.CR_279.class)
    public void AttemptToArchiveArchivedRule_RuleNotFound() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse archivedRuleResponse = CreateArchivedRule(ruleDetails);
        ruleDetails.uniqueID = archivedRuleResponse.uniqueId;

        //Act
        RuleActionResponse.PostResponse archiveResponse = ArchiveRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, archiveResponse.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_1880.class)
    public void AttemptToArchiveRuleWithNoReason_RuleNotArchived() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        RuleActionResponse.PostResponse suspendedRuleResponse = CreateSuspendedRule(ruleDetails);

        //Act
        RuleActionResponse.PostResponse archiveResponse = ArchiveRule(ruleDetails, null);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, archiveResponse.httpStatusCode);
    }
}
