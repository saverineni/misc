package TestCases.RulesManagementService;


import API.DataForTests.*;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.ViewDataTableList.ViewDataTableListResponse;
import Categories_CDSRisk.CDS_RM_DataTable;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static org.junit.Assert.assertTrue;

@Slf4j
@Category({Rules_Management.class, CDS_RM_DataTable.class})
public class TestCase_DataTable_Filter extends WebAPITestCaseWithDatatablesCleanup {

    private String dataTableShareType = "?shareType=";

    private static TestDataTableModel.TableDetails tableDetails1 = new TestDataTableModel.TableDetails();
    private static TestDataTableModel.TableDetails tableDetails2 = new TestDataTableModel.TableDetails();
    private static TestDataTableModel.TableDetails tableDetails3 = new TestDataTableModel.TableDetails();
    private static TestDataTableModel.TableDetails tableDetails4 = new TestDataTableModel.TableDetails();
    private static TestDataTableModel.TableDetails tableDetails5 = new TestDataTableModel.TableDetails();
    private static TestDataTableModel.TableDetails tableDetails6 = new TestDataTableModel.TableDetails();

    @Test
    @Category(ChangeRequest.CR_947.class)
    public void WhenDataTableSavedByLocalUser_TableCanBeViewedBySameUser() throws Throwable {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_POO());

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableListROStart = API.RulesManagementService.Utils.DataTables.GetListOfDataTables();
        log.debug("Number of data tables at start of test: " + viewDataTableListROStart.totalElements);

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables();
        log.debug("Number of data tables at end of test: " + viewDataTableList.totalElements);

        //Assert
        boolean bDataTableFound1 = API.RulesManagementService.Utils.DataTables.CheckIfViewDataTableListResponseContainsTableUID(viewDataTableList, tableDetails.uuid);
        assertTrue("Expect Data Table to be found in list: " + tableDetails.uuid, bDataTableFound1 == true);
    }


    @Test
    @Category(ChangeRequest.CR_947.class)
    public void WhenDataTableSavedByLocalUser_TableCanBeViewedByUserFromSameLocation() throws Throwable {

        //Arrange

        //Login as User 1
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_POO());

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Login as User 2
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_POO_EXT());

        //Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables();

        //Assert
        boolean bDataTableFound1 = API.RulesManagementService.Utils.DataTables.CheckIfViewDataTableListResponseContainsTableUID(viewDataTableList, tableDetails.uuid);
        assertTrue("Expect Data Table to be found in list: " + tableDetails.uuid, bDataTableFound1 == true);
    }


    @Test
    @Category(ChangeRequest.CR_1190.class)
    public void WhenDataTableSavedByLocalUser_TableCanBeViewedByUserFromDifferentLocation() throws Throwable {

        //Arrange
        //Login as User 1
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_POO());

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Login as User 2
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_EXT());

        //Act
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables();


        //Assert
        boolean bDataTableFound1 = API.RulesManagementService.Utils.DataTables.CheckIfViewDataTableListResponseContainsTableUID(viewDataTableList, tableDetails.uuid);
        assertTrue("Expect Data Table to be found in list: " + tableDetails.uuid, bDataTableFound1 == true);
    }


    @Test
    @Category(ChangeRequest.CR_1190.class)
    public void WhenDataTableSavedWithMultipleLocationsAndFilteredByASingleLocation_TableCanBeViewed() throws Throwable {

        //Arrange
        TestUserModel.UserDetails udLOCRuleManager = Users_API.RulesManagerLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_POO_EXT());

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POOEXT();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Act
        String queryLocationFilter = "?locationUuids=" + udLOCRuleManager.locationRoles.get(0).locationNameUuid;
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(queryLocationFilter);

        //Assert
        boolean bDataTableFound1 = API.RulesManagementService.Utils.DataTables.CheckIfViewDataTableListResponseContainsTableUID(viewDataTableList, tableDetails.uuid);
        assertTrue("Expect Data Table to be found in list: " + tableDetails.uuid, bDataTableFound1 == true);
    }


    @Test
    @Category(ChangeRequest.CR_1190.class)
    public void WhenDataTablesSavedAndFilteredBy2Locations_TablesCanBeViewed() throws Throwable {

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_POO());

        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);


        TestUserModel.UserDetails udLOCRuleManager2 = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(udLOCRuleManager2);
        API.RulesManagementService.Utils.Users.LoginAsUser(udLOCRuleManager2.pid);

        TestDataTableModel.TableDetails tableDetails2 = DataTables.DataTable_CommodityCodes_EXT();
        CreateDataTableResponse.PostResponse createDataTableResponse2 = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails2);

        //Act
        String queryLocationFilter = "?locationUuids=" + Locations.Location_POO_UID + "," + Locations.Location_EXT_UID;
        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(queryLocationFilter);

        //Assert
        boolean bDataTableFound1 = API.RulesManagementService.Utils.DataTables.CheckIfViewDataTableListResponseContainsTableUID(viewDataTableList, createDataTableResponse.uuid);
        assertTrue("Expect Data Table to be found in list: " + createDataTableResponse.uuid, bDataTableFound1 == true);

        boolean bDataTableFound2 = API.RulesManagementService.Utils.DataTables.CheckIfViewDataTableListResponseContainsTableUID(viewDataTableList, createDataTableResponse2.uuid);
        assertTrue("Expect Data Table to be found in list: " + createDataTableResponse2.uuid, bDataTableFound2 == true);
    }


    //Scenario 1: Logged In as POO. ShareType = USE	Table none
    @Test
    @Category(ChangeRequest.CR_1445.class)
    public void WhenAllDataTableFilteredByUserOnlyAndUserIsCreatorWithNoDataTablesSharedForUse_NoDataTablesAreDisplayed() throws Throwable {

        //Arrange
        CreateDataTablesForTestingShareFilter();
        API.RulesManagementService.Utils.Users.LoginAsUser(Users_API.RulesManagerLocal_POO().pid);

        //Act
        String queryLocationFilter = dataTableShareType + "USE";  //only show tables which have been shared for usage with POO

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(queryLocationFilter);

        //Assert
        Assertions.assertThat(viewDataTableList.content).extracting("uuid")
                .containsOnly(tableDetails4.uuid);
    }


    //Scenario 2: Logged In as POO. ShareType = OWNER	Table 1, 2, 3, 4, 5
    @Test
    @Category(ChangeRequest.CR_1445.class)
    public void WhenAllDataTableFilteredByOwnerAndUserIsCreator_OnlyTablesSharedForOwnerOrUsageAreDisplayed() throws Throwable {

        //Arrange
        CreateDataTablesForTestingShareFilter();
        API.RulesManagementService.Utils.Users.LoginAsUser(Users_API.RulesManagerLocal_POO().pid);

        //Act
        String queryLocationFilter = dataTableShareType + "OWNER";  //only show tables which have been shared for Owner with POO

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(queryLocationFilter);

        //Assert
        Assertions.assertThat(viewDataTableList.content).extracting("uuid")
                .hasSize(5)
                .containsOnly(tableDetails1.uuid, tableDetails2.uuid, tableDetails3.uuid, tableDetails4.uuid, tableDetails5.uuid);
    }


    //Scenario 3: Logged In as POO. ShareType = NONE	Table 6
    @Test
    @Category(ChangeRequest.CR_1445.class)
    public void WhenAllDataTableFilteredByNone_OnlyTablesNOTSharedWithLocationAreDisplayed() throws Throwable {

        //Arrange
        CreateDataTablesForTestingShareFilter();
        API.RulesManagementService.Utils.Users.LoginAsUser(Users_API.RulesManagerLocal_POO().pid);

        //Act
        String queryLocationFilter = dataTableShareType + "NONE";  //only show tables which have been shared for None with POO

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(queryLocationFilter);

        //Assert
        Assertions.assertThat(viewDataTableList.content).extracting("uuid")
                .contains(tableDetails6.uuid)
                .doesNotContain(tableDetails1.uuid, tableDetails2.uuid, tableDetails3.uuid, tableDetails4.uuid, tableDetails5.uuid);
    }


    //Scenario 4: Logged In as POO. ShareType = OWNER,USE	Table 1, 2, 3, 4, 5
    @Test
    @Category(ChangeRequest.CR_1445.class)
    public void WhenMyDataTableFilteredByOwnerAndUseAndUserIsCreator_TablesSharedForUsageAndOwnerAreDisplayed() throws Throwable {

        //Arrange
        CreateDataTablesForTestingShareFilter();
        API.RulesManagementService.Utils.Users.LoginAsUser(Users_API.RulesManagerLocal_POO().pid);

        //Act
        String queryLocationFilter = dataTableShareType + "OWNER,USE";  //only show tables which have been shared for Owner, Use with POO

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(queryLocationFilter);

        //Assert
        Assertions.assertThat(viewDataTableList.content).extracting("uuid")
                .hasSize(5)
                .containsOnly(tableDetails1.uuid, tableDetails2.uuid, tableDetails3.uuid, tableDetails4.uuid, tableDetails5.uuid);
    }


    //Scenario 5: Logged In as EXT. ShareType = USE	Table 1, 4
    @Test
    @Category(ChangeRequest.CR_1445.class)
    public void WhenAllDataTableFilteredByUserOnly_OnlyTablesSharedForUsageAreDisplayed() throws Throwable {

        //Arrange
        CreateDataTablesForTestingShareFilter();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_EXT());

        //Act
        String queryLocationFilter = dataTableShareType + "USE";  //only show tables which have been shared for usage with EXT

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(queryLocationFilter);

        //Assert
        Assertions.assertThat(viewDataTableList.content).extracting("uuid")
                .hasSize(2)
                .containsOnly(tableDetails1.uuid, tableDetails4.uuid);
    }


    //Scenario 6: Logged In as EXT. ShareType = OWNER	Table 1,2,4, 5
    @Test
    @Category(ChangeRequest.CR_1445.class)
    public void WhenAllDataTableFilteredByOwner_OnlyTablesSharedForOwnerShipAreDisplayed() throws Throwable {

        //Arrange
        CreateDataTablesForTestingShareFilter();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_EXT());

        //Act
        String queryLocationFilter = dataTableShareType + "OWNER";  //only show tables which have been shared for ownership with EXT

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(queryLocationFilter);

        //Assert
        Assertions.assertThat(viewDataTableList.content).extracting("uuid")
                .containsOnly(tableDetails2.uuid, tableDetails5.uuid);
            }


    //Scenario 7: Logged In as EXT. ShareType = NONE	Table 3, 6
    @Test
    @Category(ChangeRequest.CR_1445.class)
    public void WhenAllDataTableFilteredByNone_OnlyTablesNotSharedWithMeAreDisplayed() throws Throwable {

        //Arrange
        CreateDataTablesForTestingShareFilter();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_EXT());

        //Act
        String queryLocationFilter = dataTableShareType + "NONE";  //only show tables which have not been shared with me

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(queryLocationFilter);

        //Assert
        Assertions.assertThat(viewDataTableList.content).extracting("uuid")
                .contains(tableDetails3.uuid, tableDetails6.uuid)
                .doesNotContain(tableDetails1.uuid, tableDetails2.uuid, tableDetails4.uuid, tableDetails5.uuid);
    }


    //Scenario 8: Logged In as EXT. ShareType = OWNER,USE	Table 1,2,4,5
    @Test
    @Category(ChangeRequest.CR_1445.class)
    public void WhenMyDataTableFilteredByOwnerAndUse_TablesSharedForUsageAndOwnerAreDisplayed() throws Throwable {

        //Arrange
        CreateDataTablesForTestingShareFilter();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_EXT());

        //Act
        String queryLocationFilter = dataTableShareType + "OWNER,USE";  //only show tables which have been shared for Owner, Use with EXT

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(queryLocationFilter);

        //Assert
        Assertions.assertThat(viewDataTableList.content).extracting("uuid")
                .containsOnly(tableDetails1.uuid, tableDetails2.uuid, tableDetails4.uuid, tableDetails5.uuid);
    }


    //Scenario 9: Logged In as National User. ShareType = OWNER,USE	Table 1,2,3,4,5,6
    @Test
    @Category(ChangeRequest.CR_1445.class)
    public void WhenMyDataTableFilteredByOwnerAndUseForNational_AllTablesSharedForUsageAndOwnerAreDisplayed() throws Throwable {

        //Arrange
        CreateDataTablesForTestingShareFilter();
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerNational());

        //Act
        String queryLocationFilter = dataTableShareType + "OWNER,USE";  //only show tables which have been shared for Owner, Use with EXT

        ViewDataTableListResponse.ViewDataTableListResponseObject viewDataTableList = API.RulesManagementService.Utils.DataTables.GetListOfDataTables(queryLocationFilter);

        //Assert
        Assertions.assertThat(viewDataTableList.content).extracting("uuid")
                .contains(tableDetails1.uuid, tableDetails2.uuid, tableDetails3.uuid, tableDetails4.uuid,
                        tableDetails5.uuid, tableDetails6.uuid);
    }


    private static void CreateDataTablesForTestingShareFilter(){

        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_POO());

        tableDetails1 = DataTables.DataTable_CommodityCodes_POO();
        tableDetails2 = DataTables.DataTable_CommodityCodes_POO();
        tableDetails3 = DataTables.DataTable_CommodityCodes_POO();
        tableDetails4 = DataTables.DataTable_CommodityCodes_POO();
        tableDetails5 = DataTables.DataTable_CommodityCodes_POO();
        tableDetails6 = DataTables.DataTable_CommodityCodes_POO();

        //Create 1st Data Table and share for usage
        tableDetails1.tableType = "restricted";
        tableDetails1.tableName = "ta_T1_Usage_EXT";
        tableDetails1.description = "POO Commodity Codes shared for USE with EXT";

        tableDetails1 = API.RulesManagementService.Utils.DataTables.CreateDataTableAndShareWithLocation(
                tableDetails1, TestEnumerators.ShareTypes.user, Locations.Location_EXT_UID);

        //Create 2nd Data Table and share for ownership
        tableDetails2.tableType = "restricted";
        tableDetails2.tableName = "ta_T2_Owner_EXT";
        tableDetails2.description = "POO Commodity Codes shared for OWN with EXT";
        tableDetails2 = API.RulesManagementService.Utils.DataTables.CreateDataTableAndShareWithLocation(
                tableDetails2, TestEnumerators.ShareTypes.owner, Locations.Location_EXT_UID);

        //Create 3rd Data Table and don't share
        tableDetails3.tableType = "restricted";
        tableDetails3.tableName = "ta_T3_PooNotShared";
        tableDetails3.description = "POO Commodity Codes shared with NONE";
        CreateDataTableResponse.PostResponse createDataTableResponseTable3 = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails3);
        tableDetails3.uuid = createDataTableResponseTable3.uuid;

        //Create 4th Data Table and share for usage with all
        tableDetails4.tableType = "restricted";
        tableDetails4.tableName = "ta_T4_Usage_ALL";
        tableDetails4.description = "POO Commodity Codes shared for USE with AND";
        tableDetails4 = API.RulesManagementService.Utils.DataTables.CreateDataTableAndShareWithLocation(
                tableDetails4, TestEnumerators.ShareTypes.user, Locations.Location_AllLocations_UID);

        //Create 5th Data Table and share for ownership with all
        tableDetails5.tableType = "restricted";
        tableDetails5.tableName = "ta_T5_Owner_ALL";
        tableDetails5.description = "POO Commodity Codes shared for OWN with AND";
        tableDetails5 = API.RulesManagementService.Utils.DataTables.CreateDataTableAndShareWithLocation(
                tableDetails5, TestEnumerators.ShareTypes.owner, Locations.Location_AllLocations_UID);

        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.RulesManagerLocal_WAT());

        //Create 6th Data Table and don't share
        tableDetails6.tableType = "restricted";
        tableDetails6.tableName = "ta_T6_WATNotShared";
        tableDetails6.description = "WAT Commodity Codes";
        tableDetails6.useTablesLocationUuids.clear();
        tableDetails6.useTablesLocationUuids.add(Locations.Location_WAT_UID);
        tableDetails6.manageTableLocationUuids.clear();
        tableDetails6.manageTableLocationUuids.add(Locations.Location_WAT_UID);

        CreateDataTableResponse.PostResponse createDataTableResponseTable6 = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails6);
        tableDetails6.uuid = createDataTableResponseTable6.uuid;
    }

}
