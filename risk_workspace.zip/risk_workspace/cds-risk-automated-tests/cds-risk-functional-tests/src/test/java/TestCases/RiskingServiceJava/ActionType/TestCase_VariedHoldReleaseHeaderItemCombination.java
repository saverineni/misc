package TestCases.RiskingServiceJava.ActionType;

import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.Risking_JavaService;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.*;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel.Query;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Category({ChangeRequest_RiskingService.CREP_229.class, ChangeRequest_RiskingService.CREP_261.class,
        ChangeRequest_RiskingService.CREP_290.class, Risking_JavaService.class})
public class TestCase_VariedHoldReleaseHeaderItemCombination extends BaseActionTypeTest {

    final String ruleConst = "ta229261Rule";
    String description = "";

    Query commodityCode = Query.builder()
            .attribute(GoodsItemDeclarationParam.COMMODITY_CODE.toString())
            .value("0000000001")
            .operator(Operator.eq.toString())
            .conditionType(ConditionType.normal.toString())
            .build();

    Query originCountry = Query.builder()
            .attribute(GoodsItemDeclarationParam.ORIGIN_COUNTRY.toString())
            .operator(Operator.eq.toString())
            .value("GR")
            .conditionType(ConditionType.normal.toString())
            .build();

    List<Query> goodsItemConditions = Arrays.asList(commodityCode, originCountry);

    Query importerName = Query.builder()
            .attribute(HeaderDeclarationParam.IMPORTER_NAME.toString())
            .operator(Operator.eq.toString())
            .value(ruleConst)
            .conditionType(ConditionType.normal.toString())
            .build();

    Query consignorName = Query.builder()
            .attribute(HeaderDeclarationParam.CONSIGNOR_NAME.toString())
            .operator(Operator.eq.toString())
            .value(ruleConst)
            .conditionType(ConditionType.normal.toString())
            .build();

    List<Query> headerConditions = Arrays.asList(importerName, consignorName);

    @Test
   // @Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void HeaderRuleHitByPreClearanceCheck() {
        description = ruleConst + "PreHeader";

        CreateRuleModel declaration = createARule(description, 100, headerConditions);

        createAndRefreshRule(declaration);

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();
        declarationFieldValues.put(HeaderDeclarationParam.IMPORTER_NAME, ruleConst);
        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNOR_NAME, ruleConst);

        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_TYPE, "IM");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "C");

        declarationFieldValues.put(GoodsItemDeclarationParam.SEQUENCE_NUMBER, "2001");
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.SEQUENCE_NUMBER, "2002");
        declarationFieldValues.put(GoodsItemDeclarationParam.Third.SEQUENCE_NUMBER, "2003");
        declarationFieldValues.put(GoodsItemDeclarationParam.Fourth.SEQUENCE_NUMBER, "2004");

        String declarationRequest = declarationSupport.createDeclaration(DECLARATION_TEMPLATE, declarationFieldValues);

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive(), this::decryptField);
        String narrative = declarationResponse.getNarrativeText();
        List<String> reportBackElements = declarationResponse.getReportBackElements();
        String controlType = declarationResponse.getControlType();

        Assertions.assertThat(narrative).isEqualTo(PRE_CLEARANCE_NARRATIVE);
        Assertions.assertThat(reportBackElements).contains("/declaration").hasSize(1);
        Assertions.assertThat(controlType).isEqualTo(DOCUMENT_CHECK_CTRL_TYPE);
    }

    @Test
   // @Ignore("CR-3166: Test broken as consignee / consignor now specific to export / import")
    public void HeaderRuleHitByPostClearanceCheck() {
        description = ruleConst + "PostHeader";
        CreateRuleModel headerRule = createARule(description, 0, headerConditions);
        createAndRefreshRule(headerRule);

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();
        declarationFieldValues.put(HeaderDeclarationParam.IMPORTER_NAME, ruleConst);
        declarationFieldValues.put(HeaderDeclarationParam.CONSIGNOR_NAME, ruleConst);

        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_TYPE, "IM");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "C");

        declarationFieldValues.put(GoodsItemDeclarationParam.SEQUENCE_NUMBER, "2001");
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.SEQUENCE_NUMBER, "2002");
        declarationFieldValues.put(GoodsItemDeclarationParam.Third.SEQUENCE_NUMBER, "2003");
        declarationFieldValues.put(GoodsItemDeclarationParam.Fourth.SEQUENCE_NUMBER, "2004");

        String declarationRequest = declarationSupport.createDeclaration(DECLARATION_TEMPLATE, declarationFieldValues);

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive(), this::decryptField);
        String narrative = declarationResponse.getNarrativeText();
        List<String> reportBackElements = declarationResponse.getReportBackElements();
        String controlType = declarationResponse.getControlType();

        Assertions.assertThat(narrative).isEqualTo(POST_CLEARANCE_NARRATIVE);
        Assertions.assertThat(reportBackElements).contains("/declaration").hasSize(1);
        Assertions.assertThat(controlType).isEqualTo(DOCUMENT_CHECK_CTRL_TYPE);
    }

    @Test
    public void ItemRuleHitByPreClearanceCheck() {
        description = ruleConst + "PreItem";

        CreateRuleModel itemRule = createARule(description, 100, goodsItemConditions);
        createAndRefreshRule(itemRule);

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();

        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_TYPE, "IM");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "C");
        declarationFieldValues.put(HeaderDeclarationParam.TRANSPORT_MODE, TransportMode.All.toString());

        //item1
        declarationFieldValues.put(GoodsItemDeclarationParam.COMMODITY_CODE, "0000000001");
        declarationFieldValues.put(GoodsItemDeclarationParam.ORIGIN_COUNTRY, "GR");
        declarationFieldValues.put(GoodsItemDeclarationParam.SEQUENCE_NUMBER, "2001");
        //item2
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.COMMODITY_CODE, "0000000001");
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.ORIGIN_COUNTRY, "GR");
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.SEQUENCE_NUMBER, "2002");
        //item3
        declarationFieldValues.put(GoodsItemDeclarationParam.Third.COMMODITY_CODE, "0000000123");
        declarationFieldValues.put(GoodsItemDeclarationParam.Third.ORIGIN_COUNTRY, "GR");
        declarationFieldValues.put(GoodsItemDeclarationParam.Third.SEQUENCE_NUMBER, "2003");
        //item4
        declarationFieldValues.put(GoodsItemDeclarationParam.Fourth.COMMODITY_CODE, "0000000001");
        declarationFieldValues.put(GoodsItemDeclarationParam.Fourth.ORIGIN_COUNTRY, "DE");
        declarationFieldValues.put(GoodsItemDeclarationParam.Fourth.SEQUENCE_NUMBER, "2004");

        String declarationRequest = declarationSupport.createDeclaration(DECLARATION_TEMPLATE, declarationFieldValues);

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive(), this::decryptField);
        String narrative = declarationResponse.getNarrativeText();
        List<String> reportBackElements = declarationResponse.getReportBackElements();
        String controlType = declarationResponse.getControlType();

        Assertions.assertThat(narrative).isEqualTo(PRE_CLEARANCE_NARRATIVE);
        Assertions.assertThat(reportBackElements).contains(
                generateReportBackElementString("2002"));
        Assertions.assertThat(reportBackElements).contains(
                generateReportBackElementString("2001"));
        Assertions.assertThat(reportBackElements).doesNotContain(
                generateReportBackElementString("2003"));
        Assertions.assertThat(reportBackElements).doesNotContain(
                generateReportBackElementString("2004"));
        Assertions.assertThat(controlType).isEqualTo(DOCUMENT_CHECK_CTRL_TYPE);
    }

    @Test
    public void ItemRuleHitByPostClearanceCheck() {
        description = ruleConst + "PostItem";

        CreateRuleModel itemRule = createARule(description, 0, goodsItemConditions);
        createAndRefreshRule(itemRule);

        Map<DeclarationParam, String> declarationFieldValues = new HashMap<>();

        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_TYPE, "IM");
        declarationFieldValues.put(HeaderDeclarationParam.DECLARATION_SUBTYPE, "C");
        declarationFieldValues.put(HeaderDeclarationParam.TRANSPORT_MODE, TransportMode.All.toString());

        //item1
        declarationFieldValues.put(GoodsItemDeclarationParam.COMMODITY_CODE, "0000000001");
        declarationFieldValues.put(GoodsItemDeclarationParam.ORIGIN_COUNTRY, "GR");
        declarationFieldValues.put(GoodsItemDeclarationParam.SEQUENCE_NUMBER, "2001");
        //item2
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.COMMODITY_CODE, "0000000001");
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.ORIGIN_COUNTRY, "GR");
        declarationFieldValues.put(GoodsItemDeclarationParam.Second.SEQUENCE_NUMBER, "2002");
        //item3
        declarationFieldValues.put(GoodsItemDeclarationParam.Third.COMMODITY_CODE, "0000000123");
        declarationFieldValues.put(GoodsItemDeclarationParam.Third.ORIGIN_COUNTRY, "GR");
        declarationFieldValues.put(GoodsItemDeclarationParam.Third.SEQUENCE_NUMBER, "2003");
        //item4
        declarationFieldValues.put(GoodsItemDeclarationParam.Fourth.COMMODITY_CODE, "0000000001");
        declarationFieldValues.put(GoodsItemDeclarationParam.Fourth.ORIGIN_COUNTRY, "DE");
        declarationFieldValues.put(GoodsItemDeclarationParam.Fourth.SEQUENCE_NUMBER, "2004");


        String declarationRequest = declarationSupport.createDeclaration(DECLARATION_TEMPLATE, declarationFieldValues);

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive(), this::decryptField);
        String narrative = declarationResponse.getNarrativeText();
        List<String> reportBackElements = declarationResponse.getReportBackElements();
        String controlType = declarationResponse.getControlType();

        Assertions.assertThat(narrative).isEqualTo(POST_CLEARANCE_NARRATIVE);
        Assertions.assertThat(reportBackElements).contains(
                generateReportBackElementString("2002"));
        Assertions.assertThat(reportBackElements).contains(
                generateReportBackElementString("2001"));
        Assertions.assertThat(reportBackElements).doesNotContain(
                generateReportBackElementString("2003"));
        Assertions.assertThat(reportBackElements).doesNotContain(
                generateReportBackElementString("2004"));
        Assertions.assertThat(controlType).isEqualTo(DOCUMENT_CHECK_CTRL_TYPE);
    }

    private CreateRuleModel createARule(String description, int prePercentage, List<Query> query) {

        CreateRuleModel model = createRuleModel();
        model.setDescription(description);
        model.getQuery().get(0).setQuery( query );

        model.getRuleOutputs().setActionType("4");

        model.getRuleOutputs().setHoldPercentage( prePercentage );
        model.getRuleOutputs().setHoldNarrative( PRE_CLEARANCE_NARRATIVE );
        model.getRuleOutputs().setReleasePercentage( 100 - prePercentage );
        model.getRuleOutputs().setReleaseNarrative( POST_CLEARANCE_NARRATIVE );

//        CreateRuleModel definitionModel = createRuleDefinition(when, description, source, prePercentage, conditions);

        return model;
    }

//    private RuleDefinitionModel createRuleDefinition(String when, String description, Source source,
//                                                     String prePercentage, List<Condition> conditions) {
//        RuleDefinitionModel model = defaultModel();
//        model.getRuleDefinitions().clear();
//
//        RuleDefinition ruleDefinition = RuleDefinition.builder().build();
//        ruleDefinition.addMetadata(new MetadataDefinition(RuleMetadata.UNIQUE_ID, Optional.of("#UniqueId#")));
//        ruleDefinition.addMetadata(new MetadataDefinition(RuleMetadata.CONSOLIDATE, Optional.empty()));
//        ruleDefinition.addMetadata(new MetadataDefinition(RuleMetadata.PRE_POST_CLEARANCE, Optional.of(prePercentage)));
//        ruleDefinition.setName(description);
//        ruleDefinition.setWhenDef(when);
//        ruleDefinition.setThenDef(thenCreator(source, conditions ));
//
//        model.getRuleDefinitions().add(ruleDefinition);
//        return model;
//    }
}
