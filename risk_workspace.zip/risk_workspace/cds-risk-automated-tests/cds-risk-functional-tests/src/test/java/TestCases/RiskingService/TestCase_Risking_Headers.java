package TestCases.RiskingService;


import API.DataForTests.*;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.Utils.RuleAtStatus;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import junitparams.JUnitParamsRunner;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import uk.gov.hmrc.risk.test.common.enums.ConditionType;
import uk.gov.hmrc.risk.test.common.enums.DeclarationSubType;
import uk.gov.hmrc.risk.test.common.enums.DeclarationType;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.TimeoutException;

import static API.DataForTests.TestRuleModel.RuleDetails.AttributeType.HEADER;
import static API.DataForTests.TestRuleModel.RuleDetails.AttributeType.HEADER_COLLECTION;
import static API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody;
import static org.assertj.core.api.Assertions.assertThat;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.crossmatch;
import static uk.gov.hmrc.risk.test.common.enums.ConditionType.normal;

@Slf4j
@Category(Risking_Service.class)
@RunWith(JUnitParamsRunner.class)
public class TestCase_Risking_Headers extends WebAPITestCaseWithDatatablesCleanup {

    public static final String NO_CONTROL_ROUTE = "";
    private TestRuleModel.RuleDetails testRule;
    private TestRuleModel.RuleDetails.Condition condition;
    private TestDeclarationModel.Declaration declaration;

    @Before
    public void setup() throws IOException, TimeoutException {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
        testRule = API.DataForTests.Rules.DraftNatRuleNatManager();
        testRule.queryOptions.declarationType = DeclarationType.EX.toString();
        testRule.queryOptions.declarationSubTypes = Arrays.asList(DeclarationSubType.C.toString());
        condition = testRule.queryConditions.get(0).conditions.get(0);
        condition.operator = "neq";
        declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
    }

    private void commitRuleAndPublish() {
        EditRuleVersionResponse.PutResponse commitResponse = RuleAtStatus.CreateCommittedRule(testRule);
        assertThat(commitResponse.httpStatusCode)
                .describedAs("Failed to commit rule. response:\n" + commitResponse.body)
                .isEqualTo(200);
        publishAndWait(5000);
    }

    private DeclarationResponse riskDeclaration() {
        String declarationRequest = createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());
        queue.send(declarationRequest);
        return new DeclarationResponse(queue.receive());
    }

    /*
     * collection field to value
     */
    @Test
    @Category({ChangeRequest.CR_3276.class, ChangeRequest.CR_3278.class})
    public void whenWareHouseIdFieldNotEqualValue_conditionAndDeclatartionNotEqual_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.attribute = Conditions.warehouseId().attribute;
        condition.value = "R123456NL";
        commitRuleAndPublish();

        declaration.warehouseId = "S123456NL";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_3276.class})
    public void whenWareHouseTypeFieldNotMatchesPattern_conditionAndDeclatartionMtaching_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="notMatchesPattern";
        condition.attribute = Conditions.warehouseType().attribute;
        condition.value = "?";
        commitRuleAndPublish();

        declaration.warehouseType = "1";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }



    @Test
    @Category({ChangeRequest.CR_3276.class})
    public void whenAuthorizationTypeEqual_conditionAndDeclatartionqual_thenRouteReturned() {
        condition.attributeType = HEADER_COLLECTION;
        condition.conditionType = normal;
        condition.operator="eq";
        condition.attribute = Conditions.authorizationType().attribute;
        condition.value = "AEOC";
        commitRuleAndPublish();

        declaration.authorizationType = "aeoc";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3276.class})
    public void whenTransactionNatureStartsWithNotEqual_conditionAndDeclatartionEqual_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="neq";
        condition.attribute = Conditions.transactionNature().attribute;
        condition.value = "11";
        commitRuleAndPublish();

        declaration.transactionNature = "11";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CR_3276.class})
    public void whenPlaceOfLoadingWithNotContains_conditionAndDeclatartionNotMatching_thenRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="nco";
        condition.attribute = Conditions.placeOfLoading().attribute;
        condition.value = "Man";
        commitRuleAndPublish();

        declaration.placeOfLoading = "London";
        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3276.class})
    public void whenWareHouseIdNotEqualType_idAndTypeEquals_thenNoRouteReturned() {
        condition.attributeType = HEADER;
        condition.conditionType = crossmatch;
        condition.operator="neq";
        condition.attribute = Conditions.warehouseId().attribute;
        condition.value = Conditions.warehouseType().attribute;
        commitRuleAndPublish();

        declaration.warehouseId = "155";
        declaration.warehouseType = "155";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CR_3276.class})
    public void whenAuthorizationTypeNotContainsInDataTable_valueExistsInDataTable_thenNoRouteReturned() {
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_FreeText_Valid();
        tableDetails.dataItemsToAdd.add("CCAX");
        tableDetails.dataItemsToAdd.add("ACVB");
        tableDetails.dataItemsToAdd.add("SNFB");
        CreateDataTableResponse.PostResponse createDataTableResponse = API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;
        //Need to get table version uid via details
        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = API.RulesManagementService.Utils.DataTables.GetDataTableDetailsByUID(createDataTableResponse.uuid);
        //tableDetails.tableVersionUuid = responseDetail.tableVersionUuid;
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //add data items to data table
        API.RulesManagementService.Utils.DataTables.EditDataTableAndGetResponseObject(tableDetails);

        condition.attribute = Conditions.authorizationType().attribute;
        condition.conditionType = ConditionType.datatable;
        condition.operator = "neq";
        condition.value = tableDetails.uuid;
        condition.isDataTable = true;
        commitRuleAndPublish();

        declaration.authorizationType = "SNFB";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }


    @Test
    @Category({ChangeRequest.CR_3330.class})
    public void whenFieldNotMatchesPatternValueExporter_DeclarationNotMatches_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="notMatchesPattern";
        condition.attribute = Conditions.exporterId_Header("?1122").attribute;
        condition.value="?1122";
        commitRuleAndPublish();
        declaration.exporterId_Header = "1122";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3318.class})
    public void whenFieldEqualValueAdditionalActorId_DeclarationMatches_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="eq";
        condition.attribute = Conditions.additionalActorId_Header("AB1234").attribute;
        condition.value = "AB1234";
        commitRuleAndPublish();
        declaration.additionalActor_Id_Header = "AB1234";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3318.class})
    public void whenFieldEqualValueAdditionalActorRole_DeclarationMatches_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="eq";
        condition.attribute = Conditions.additionalActorRole_Header("HY4").attribute;
        condition.value = "HY4";
        commitRuleAndPublish();
        declaration.additionalActor_Role_Header = "HY4";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3318.class})
    public void whenFieldEqualValueVatDeclaringPartyId_DeclarationMatches_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="eq";
        condition.attribute = Conditions.vatDeclaringPartyId_Header("GH233456").attribute;
        condition.value = "GH233456";
        commitRuleAndPublish();
        declaration.vatDeclaringParty_Id_Header = "gh233456";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3318.class})
    public void whenFieldEqualValueVatDeclaringPartyRole_DeclarationMatches_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="eq";
        condition.attribute = Conditions.vatDeclaringPartyRole_Header("AB2").attribute;
        condition.value = "AB2";
        commitRuleAndPublish();
        declaration.vatDeclaringParty_Role_Header = "AB2";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3330.class})
    public void whenFieldEqualsValueGoodsLocationID_DeclarationMatches_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="eq";
        condition.attribute = Conditions.goodsLocationID().attribute;
        condition.value="GBAUMNCABZFDS";
        commitRuleAndPublish();
        declaration.goodsLocationID = "GBAUMNCABZFDS";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3330.class})
    public void whenFieldEqualsValueGoodsLocationAddress_DeclarationMatches_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="eq";
        condition.attribute = Conditions.goodsLocationAddress().attribute;
        condition.value="FirstStreet";
        commitRuleAndPublish();
        declaration.goodsLocationAddress = "FirstStreet";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_3330.class})
    public void whenFieldEqualsValueGoodsLocationCity_DeclarationMatches_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="eq";
        condition.attribute = Conditions.goodsLocationCity().attribute;
        condition.value="Manchester";
        commitRuleAndPublish();
        declaration.goodsLocationCity = "Manchester";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3330.class})
    public void whenFieldEqualsValueGoodsLocationCountry_DeclarationMatches_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="eq";
        condition.attribute = Conditions.goodsLocationCountry().attribute;
        condition.value="US";
        commitRuleAndPublish();
        declaration.goodsLocationCountry = "US";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3330.class})
    public void whenFieldEqualsValueGoodsLocationPostCode_DeclarationMatches_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="eq";
        condition.attribute = Conditions.goodsLocationPostcode().attribute;
        condition.value="m144ah";
        commitRuleAndPublish();
        declaration.goodsLocationPostcode = "m144ah";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Ignore("Will be fixed as part of CREP-782")
    @Test
    @Category({ChangeRequest.CR_3330.class})
    public void whenFieldEqualsValueGoodsLocationName_DeclarationMatches_thenRouteReturned1() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="eq";
        condition.attribute = Conditions.goodsLocationName_Header("manchester").attribute;
        condition.value="manchester";
        commitRuleAndPublish();
        declaration.goodsLocationName = "Manchester";
        //declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3330.class})
    public void whenFieldEqualsValueShedCode_DeclarationMatches_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="eq";
        condition.attribute = Conditions.shedCode_Header("FDS").attribute;
        condition.value="FDS";
        commitRuleAndPublish();
        declaration.goodsLocationID = "GBAUMNCABZFDS";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3419.class})
    public void whenGoodsShippedByContainerIndicatorPresent_DeclarationHasThatField_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="pr";
        condition.attribute = Conditions.goodsShippedByContainerIndicator_Header(null).attribute;
        commitRuleAndPublish();
        declaration.goodsShippedByContainerIndicator = "1";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3419.class})
    public void whenGoodsShippedByContainerIndicatorEqualValue_ConditionAndDeclarationEqual_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="eq";
        condition.attribute = Conditions.goodsShippedByContainerIndicator_Header("1").attribute;
        condition.value="1";
        commitRuleAndPublish();
        declaration.goodsShippedByContainerIndicator = "1";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3419.class})
    public void whenMeansOfTransportArrivalIndicatorEqualValue_DeclarationHasSameValue_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="eq";
        condition.attribute = Conditions.meansOfTransportOnArrivalIdentifier("aaaaaaa").attribute;
        condition.value="aaaaaaa";
        commitRuleAndPublish();
        declaration.transportRole = "5";
        declaration.transportIdentifier="aaaaaaa";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3419.class})
    public void whenTMeansOfTransportArrivalIndicatorMatchesPattern_DeclarationHasDifferentPattern_thenRouteNotReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="matchesPattern";
        condition.attribute = Conditions.meansOfTransportOnArrivalIdentifier("aaaaaaa").attribute;
        condition.value="Ship!ment";
        commitRuleAndPublish();
        declaration.transportRole = "5";
        declaration.transportIdentifier="Shipment";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CR_3419.class})
    public void whenTMeansOfTransportArrivalTypeContains_DeclarationContainsValue_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="con";
        condition.attribute = Conditions.meansOfTransportOnArrivalType("Security").attribute;
        condition.value="Security";
        commitRuleAndPublish();
        declaration.transportRole = "5";
        declaration.transportArrivalIdentifierType="HighSecurity";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3419.class})
    public void whenTMeansOfTransportArrivalTypeEquals_DeclarationHasDifferentValue_thenRouteNotReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="eq";
        condition.attribute = Conditions.meansOfTransportOnArrivalType("Security").attribute;
        condition.value="Security";
        commitRuleAndPublish();
        declaration.transportRole = "5";
        declaration.transportArrivalIdentifierType="Normal";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void whenTValuationAdjustmentsTypeIsAR_andAirTransportCostsSumIsEqualToTheirSum_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "eq";
        condition.attribute = Conditions.airTransportCostsSum_Header(null).attribute;
        condition.value = "30.0";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "AR";
        declaration.valuationAdjustmentsType2 = "AR";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void whenTValuationAdjustmentsTypeIsARAndAS_andAirTransportCostsSumIsEqualToTheirSum_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "eq";
        condition.attribute = Conditions.airTransportCostsSum_Header(null).attribute;
        condition.value = "30.0";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "AR";
        declaration.valuationAdjustmentsType2 = "AS";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void whenTValuationAdjustmentsTypeAreARAndASAndBRAndBS_andAirTransportCostsSumIsEqualToTheirSum_thenRouteReturned() throws Throwable {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "eq";
        condition.attribute = Conditions.airTransportCostsSum_Header(null).attribute;
        condition.value = "15.0";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "AR";
        declaration.valuationAdjustmentsType2 = "AS";
        declaration.valuationAdjustmentsType3 = "BR";
        declaration.valuationAdjustmentsType4 = "BS";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void whenTValuationAdjustmentsTypeAreAPandAQ_andFreightChargesSumIsEqualToTheirSum_thenRouteReturned() throws Throwable {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "eq";
        condition.attribute = Conditions.freightChargesSum_Header(null).attribute;
        condition.value = "45.0";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "AP";
        declaration.valuationAdjustmentsType2 = "AP";
        declaration.valuationAdjustmentsType3 = "AQ";
        declaration.valuationAdjustmentsType4 = "AQ";

        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3414.class})
    public void whenDeliveryTermsTypeEquals_DeclarationHasDifferentValue_thenRouteNotReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="eq";
        condition.attribute = Conditions.deliveryTermsType().attribute;
        condition.value="AHH";
        commitRuleAndPublish();
        declaration.deliveryTermsType = "NOR";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CR_3414.class})
    public void whenDeliveryTermsTypeMatchesPattern_DeclarationMatchesThePattern_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="matchesPattern";
        condition.attribute = Conditions.deliveryTermsType().attribute;
        condition.value="?OR";
        commitRuleAndPublish();
        declaration.deliveryTermsType = "COR";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void whenValuationAdjustmentsFieldsAreNotOnTheFreightApportionmentIndicatorList_thenNoRouteReturned() throws Throwable {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "eq";
        condition.attribute = Conditions.freightApportionmentIndicator_Header(null).attribute;
        condition.value = "1";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "AP";
        declaration.valuationAdjustmentsType2 = "AP";
        declaration.valuationAdjustmentsType3 = "AR";
        declaration.valuationAdjustmentsType4 = "BR";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void whenOneValuationAdjustmentsFieldIsAW_andFreightApportionmentIndicatorConditionIs1_thenRouteReturned() throws Throwable {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "eq";
        condition.attribute = Conditions.freightApportionmentIndicator_Header(null).attribute;
        condition.value = "1";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "AW";
        declaration.valuationAdjustmentsType2 = "AP";
        declaration.valuationAdjustmentsType3 = "AR";
        declaration.valuationAdjustmentsType4 = "BR";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void whenValuationAdjustmentsFieldIsBHinConsignmentShipmentAndGoodsItems_andDiscountAmountIsTheirSum_thenRouteReturned() throws Throwable {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "eq";
        condition.attribute = Conditions.discountAmountSum_Header(null).attribute;
        condition.value = "31";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "BH";
        declaration.valuationAdjustmentsType2 = "BH";
        declaration.valuationAdjustmentsType3 = "AR";
        declaration.valuationAdjustmentsType4 = "BR";

        declaration.valuationAdjustments_CodeItem = "BH";
        declaration.valuationAdjustAmount_Item = "1";
        declaration.valuationAdjustCurrency_Item = "GBP";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void whenValuationAdjustmentsFieldIsBIinConsignmentShipmentAndGoodsItems_andDiscountPercentIsTheirSum_thenRouteReturned() throws Throwable {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "eq";
        condition.attribute = Conditions.discountPercentSum_Header(null).attribute;
        condition.value = "21";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "BI";
        declaration.valuationAdjustmentsType2 = "BH";
        declaration.valuationAdjustmentsType3 = "BI";
        declaration.valuationAdjustmentsType4 = "BR";

        declaration.valuationAdjustments_CodeItem = "BI";
        declaration.valuationAdjustAmount_Item = "1";
        declaration.valuationAdjustCurrency_Item = "GBP";


        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void whenValuationAdjustmentsFieldIsAKinConsignmentShipment_andInsuranceAmountIsTheirSum_thenRouteReturned() throws Throwable {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "eq";
        condition.attribute = Conditions.insuranceAmountSum_Header(null).attribute;
        condition.value = "20";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "AK";
        declaration.valuationAdjustmentsType2 = "BH";
        declaration.valuationAdjustmentsType3 = "AK";
        declaration.valuationAdjustmentsType4 = "BR";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void whenValuationAdjustmentsFieldsHaveATOrBTType_andOtherTransportChargesIsTheirSum_thenRouteReturned() throws Throwable {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "eq";
        condition.attribute = Conditions.otherTransportChargesSum_Header(null).attribute;
        condition.value = "16";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "AT";
        declaration.valuationAdjustmentsType2 = "AT";
        declaration.valuationAdjustmentsType3 = "BT";
        declaration.valuationAdjustmentsType4 = "BT";

        declaration.valuationAdjustments_CodeItem = "AT";
        declaration.valuationAdjustAmount_Item = "1";
        declaration.valuationAdjustCurrency_Item = "GBP";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3414.class})
    public void whenDeliveryTermsLocationIdStartsWithValue_DeclarationStartsWithTheValue_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="st";
        condition.attribute = Conditions.deliveryTermsLocationId().attribute;
        condition.value="man";
        commitRuleAndPublish();
        declaration.deliveryTermsLocationID = "Manchester";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_3414.class})
    public void whenDeliveryTermsLocationNameEqualsValue_DeclarationEqualsValue_thenRouteReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="eq";
        condition.attribute = Conditions.deliveryTermsLocationName().attribute;
        condition.value="QatykOE1urCs307r4Cgm6sSsCHmAdCcZOFBBuyPPDQ66cKZ9SGZ05cN6r2974ZWkVY6Vztq6pBtLpArfWveMcRCAiDMEuvK0spqVdoQxZs5Nzk6ipNjVd4d5WIMPO3mi0sBalSt41z8d6791gcCahW2hxaTpXzlWgUB86VSiTxbQgXoR4B2HSn9IbekrcVwBjcIz7dUSN8zDLrvnuzZFRg4McZaeg7OG2mKuoIcD4lM4wbU8o7Jl3fxeXpaNfA4a";
        commitRuleAndPublish();
        declaration.deliveryTermsLocationName = "QatykOE1urCs307r4Cgm6sSsCHmAdCcZOFBBuyPPDQ66cKZ9SGZ05cN6r2974ZWkVY6Vztq6pBtLpArfWveMcRCAiDMEuvK0spqVdoQxZs5Nzk6ipNjVd4d5WIMPO3mi0sBalSt41z8d6791gcCahW2hxaTpXzlWgUB86VSiTxbQgXoR4B2HSn9IbekrcVwBjcIz7dUSN8zDLrvnuzZFRg4McZaeg7OG2mKuoIcD4lM4wbU8o7Jl3fxeXpaNfA4a";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void whenValuationAdjustmentsFieldsHaveATOrBTType2_andOtherTransportChargesIsTheirSum_thenRouteReturned() throws Throwable {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "eq";
        condition.attribute = Conditions.otherTransportChargesSum_Header(null).attribute;
        condition.value = "14";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "AT";
        declaration.valuationAdjustmentsType2 = "AT";
        declaration.valuationAdjustmentsType3 = "BT";
        declaration.valuationAdjustmentsType4 = "BT";

        declaration.valuationAdjustments_CodeItem = "BT";
        declaration.valuationAdjustAmount_Item = "1";
        declaration.valuationAdjustCurrency_Item = "GBP";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3464.class})
    public void whenValuationAdjustmentsFieldAreAWorAVinConsignmentShipment_andVATAdjustmentIsTheirSum_thenRouteReturned() throws Throwable {
        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator = "eq";
        condition.attribute = Conditions.vatAdjustmentSum_Header(null).attribute;
        condition.value = "35";
        commitRuleAndPublish();

        declaration.valuationAdjustmentsType = "AV";
        declaration.valuationAdjustmentsType2 = "AW";
        declaration.valuationAdjustmentsType3 = "BT";
        declaration.valuationAdjustmentsType4 = "AV";

        DeclarationResponse declarationResponse = riskDeclaration();

        assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }

    @Test
    @Category({ChangeRequest.CR_3414.class})
    public void whenExchangeRateGreaterThanValue_DeclarationLessThanValue_thenRouteNotReturned() throws Throwable {

        condition.attributeType = HEADER;
        condition.conditionType = normal;
        condition.operator="gt";
        condition.attribute = Conditions.exchangeRate().attribute;
        condition.value="1445.1";
        commitRuleAndPublish();
        declaration.exchangeRate = "1445";
        DeclarationResponse declarationResponse = riskDeclaration();
        assertThat(declarationResponse.getControlType()).isEqualTo(NO_CONTROL_ROUTE);
    }


}
