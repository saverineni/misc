package TestCases.UI.Rules;

import API.DataForTests.TestRuleModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.Utils.RuleAtStatus;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Rules;
import Categories_CDSRisk.CDS_Risk_UI_Rules_2;
import Categories_CDSRisk.ChangeRequest;
import FunctionsLibrary.DateTime;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.Pages.RulesManagement.CreateQuickNationalRule_Page;
import UI.Pages.RulesManagement.ListRules_Page;
import UI.Pages.RulesManagement.RuleDetails_Page;
import UI.Pages.RulesManagement.RuleSummary_Page;
import UI.Utils.Navigation;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import java.time.ZoneId;
import java.util.List;

import static API.RulesManagementService.Utils.RuleAtStatus.CreatePendingExpiredRuleVersion;
import static FunctionsLibrary.Utils.SleepForMilliSeconds;
import static UI.Utils.Navigation.Pages.ListRules;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_2.class})
public class TestCase_ScheduleRule extends BaseUIWebDriverTestCase{

    @Before
    public void Setup()
    {
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);
    }

    @Category(ChangeRequest.CR_1214.class)
    @Test
    public void WhenRuleManagerSavesAndCommitsQuickRuleWithDefaultStartEndDate_RuleSetToCommittedStatus(){

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        CreateQuickNationalRule_Page createQuickNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickNationalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftQuickNATRule();

        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalQuickRule(ruleDetails);

        //Act
        createQuickNationalRule_page.clickSaveAndCommitButtonWithDefaultReason();

        RuleSummary_Page ruleSummary_page = createQuickNationalRule_page.clickViewRule();
        List<RuleSummary_Page.RuleSummaryTableObject> ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();

        //Assert
        String actStatus = ruleSummaryTableObjects.get(0).status;

        assertEquals("Expect Status: Committed", "Committed", actStatus);
    }


    @Category({ChangeRequest.CR_1214.class, ChangeRequest.CR_1883.class})
    @Test
    public void WhenRuleManagerSavesAndCommitsQuickRuleWithAPendingStartDateTime_RuleStatusSetToPending(){

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        CreateQuickNationalRule_Page createQuickNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickNationalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftQuickNATRule();
        ruleDetails.startRuleImmediately = false;
        ruleDetails.startDate =  DateTime.AdjustLocalDateTimeNowByXDays(1);
        ruleDetails.startTime = DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.systemDefault(), 5, "HH:mm");

        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalQuickRule(ruleDetails);

        //Act
        createQuickNationalRule_page.clickSaveAndCommitButtonWithDefaultReason();

        SleepForMilliSeconds(1000);
        publishAndWait(5000);

        RuleSummary_Page ruleSummary_page = createQuickNationalRule_page.clickViewRule();
        List<RuleSummary_Page.RuleSummaryTableObject> ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();

        List<RuleSummary_Page.RuleUpcomingChangesTableObject> rulePendingTableObjects = ruleSummary_page.getListOfUpcomingChanges();

        //Assert
        assertEquals("Expect Status: Pending", "Pending", ruleSummaryTableObjects.get(0).status);

        assertEquals("Expect Name", ruleDetails.description, rulePendingTableObjects.get(0).description);

        String sExpectedDate = DateTime.AdjustLocalDateTimeNowByXDays(1, "dd/MM/yyyy");
        String sExpectedDateTime = sExpectedDate + " " + ruleDetails.startTime;

        assertThat(rulePendingTableObjects.get(0).startDateTime).contains(sExpectedDateTime);
        assertEquals("Expect Version", 1, rulePendingTableObjects.get(0).version);
        assertEquals("Expect Status: Pending", "Pending", rulePendingTableObjects.get(0).status);
    }


    @Category(ChangeRequest.CR_1214.class)
    @Test
    public void WhenRuleManagerSavesAndCommitsQuickRuleWithAPendingStartDateTime_RuleStatusSetToActiveAtSpecifiedTime() throws Throwable {

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        CreateQuickNationalRule_Page createQuickNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickNationalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftQuickNATRule();
        ruleDetails.startTime = DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.systemDefault(), 2, "HH:mm");

        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalQuickRule(ruleDetails);

        //Act
        createQuickNationalRule_page.clickSaveAndCommitButtonWithDefaultReason();

        SleepForMilliSeconds(1000);
        publishAndWait(5000);

        RuleSummary_Page ruleSummary_page = createQuickNationalRule_page.clickViewRule();

        //Assert
        ruleSummary_page.RefreshRuleSummaryPageEverySeconds(10, 80, "Active");

        List<RuleSummary_Page.RuleSummaryTableObject> ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();

        String actStatus = ruleSummaryTableObjects.get(0).status;

        assertEquals("Expect Status: Active", "Active", actStatus);
    }


    @Category(ChangeRequest.CR_1214.class)
    @Test
    public void WhenRuleManagerSavesAndCommitsQuickRuleWithAScheduledEndDateTime_RuleStatusSetToExpiredAtSpecifiedTime() throws Throwable {

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        CreateQuickNationalRule_Page createQuickNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickNationalRule);

        UI.DataForTests.TestRuleModel.RuleDetails ruleDetails = UI.DataForTests.Rules.DraftQuickNATRule();
        ruleDetails.endTime = DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.systemDefault(), 2, "HH:mm");
        ruleDetails.endDate = DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.systemDefault(), 2, "dd/MM/yyyy");

        UI.Utils.Rules ruleUtils = new UI.Utils.Rules(driver);
        ruleUtils.createNationalQuickRule(ruleDetails);

        //Act
        createQuickNationalRule_page.clickSaveAndCommitButtonWithDefaultReason();
        createQuickNationalRule_page.waitForAngularRequestsToFinish();
        publishAndWait(5000);

        RuleSummary_Page ruleSummary_page = createQuickNationalRule_page.clickViewRule();
        ruleSummary_page.waitForAngularRequestsToFinish();

        //Assert
        ruleSummary_page.RefreshRuleSummaryPageEverySeconds(10, 80, "Expired");
        ruleSummary_page.waitForAngularRequestsToFinish();
        List<RuleSummary_Page.RuleSummaryTableObject> ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetailsForExpiredRule();

        String actStatus = ruleSummaryTableObjects.get(0).status;

        assertEquals("Expect Status: Expired", "Expired", actStatus);
    }


    @Category(ChangeRequest.CR_1214.class)
    @Test
    public void WhenRuleWithStartDateTimeEnteredBeforeCurrentTime_WarningMessageDisplayed() throws Throwable {

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        CreateQuickNationalRule_Page createQuickNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickNationalRule);

        createQuickNationalRule_page.scrollToViewTheElement(createQuickNationalRule_page.includeStartDate);
        createQuickNationalRule_page.includeStartDate.click();

        String dateTime = DateTime.AdjustLocalDateTimeNowByXDays(0) + ", "
                            + DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.systemDefault(), -1, "HH:mm");

        createQuickNationalRule_page.startDateTime.sendKeys(dateTime);

        String error1 = createQuickNationalRule_page.inputErrors.getText();

        String dateTime2 = DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.systemDefault(), +1, "HH:mm") + ", "
                + DateTime.AdjustLocalDateTimeNowByXDays(-1, "dd/MM/yyyy");

        createQuickNationalRule_page.startDateTime.sendKeys(dateTime2);

        String error2 = createQuickNationalRule_page.inputErrors.getText();

        //Assert
        assertTrue("Expect error: Date must be greater than or equal to", error1.contains("Date must be greater than or equal to"));
        assertTrue("Expect error: Date must be greater than or equal to", error2.contains("Date must be greater than or equal to"));
    }


    @Category(ChangeRequest.CR_1214.class)
    @Test
    public void WhenRuleWithEndDateTimeEnteredBeforeCurrentTime_WarningMessageDisplayed() throws Throwable {

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        CreateQuickNationalRule_Page createQuickNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickNationalRule);

        String dateTime = DateTime.AdjustLocalDateTimeNowByXDays(0, "dd/MM/yyyy") + ", "
                + DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.systemDefault(), -1, "HH:mm");
        createQuickNationalRule_page.scrollToViewTheElement(createQuickNationalRule_page.includeEndDate);
        createQuickNationalRule_page.includeEndDate.click();
        createQuickNationalRule_page.endDateTime.clear();
        createQuickNationalRule_page.endDateTime.sendKeys(dateTime);

        String error1 = createQuickNationalRule_page.inputErrors.getText();


        String dateTime2 = DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.systemDefault(), +1, "HH:mm") + ", "
                + DateTime.AdjustLocalDateTimeNowByXDays(-367, "dd/MM/yyyy");

        createQuickNationalRule_page.endDateTime.clear();
        createQuickNationalRule_page.endDateTime.sendKeys(dateTime2);

        String error2 = createQuickNationalRule_page.inputErrors.getText();

        //Assert
        assertTrue("Expect error: Date must be greater than or equal to", error1.contains("Date must be greater than or equal to"));
        assertTrue("Expect error: Date must be greater than or equal to", error2.contains("Date must be greater than or equal to"));
    }


    @Ignore("Will fail until CR-1733 or Bug CR-1963 is implemented - Still not implemented 15/11/17")
    @Category(ChangeRequest.CR_1214.class)
    @Test
    public void WhenRuleWithoutStartDateTimeEntered_WarningMessageDisplayed() throws Throwable {

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        CreateQuickNationalRule_Page createQuickNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickNationalRule);

        createQuickNationalRule_page.includeStartDate.click();

        String dateTime = DateTime.AdjustLocalDateTimeNowByXDays(0, "dd/MM/yyyy") + ", ";

        createQuickNationalRule_page.startDateTime.sendKeys(dateTime);
//        createQuickNationalRule_page.setStartTime("");

        String error1 = createQuickNationalRule_page.inputErrors.getText();

        String dateTime2 = " , ";

        createQuickNationalRule_page.startDateTime.sendKeys(dateTime2);

//        createQuickNationalRule_page.setStartTime(DateTime.AdjustLocalDateTimeNowByXMinutes(+1, "HH:mm"));
//        createQuickNationalRule_page.setStartDate("");

        String error2 = createQuickNationalRule_page.inputErrors.getText();

        //Assert
        assertTrue("Expect error: D a date and time are required", error1.contains("D a date and time are required"));
        assertTrue("Expect error: D a date and time are required", error2.contains("D a date and time are required"));
    }


    @Ignore("No longer valid as Date Time is now combined date and time")
    @Category(ChangeRequest.CR_1214.class)
    @Test
    public void WhenRuleWithoutEndDateTimeEntered_WarningMessageDisplayed() throws Throwable {

        //Arrange
        Navigation utilNavigation = new Navigation(driver);
        CreateQuickNationalRule_Page createQuickNationalRule_page =  utilNavigation.NavigateToPage(Navigation.Pages.CreateQuickNationalRule);

        String dateTime1 = " , " + DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.systemDefault(), -1, "HH:mm");

        createQuickNationalRule_page.endDateTime.clear();
        createQuickNationalRule_page.endDateTime.sendKeys(dateTime1);

        String error1 = createQuickNationalRule_page.inputErrors.getText();

        String dateTime2 = DateTime.AdjustLocalDateTimeNowByXMinutes(ZoneId.systemDefault(), +1, "HH:mm") + ", ";
        createQuickNationalRule_page.endDateTime.clear();
        createQuickNationalRule_page.endDateTime.sendKeys(dateTime1);

        String error2 = createQuickNationalRule_page.inputErrors.getText();

        //Assert
        assertTrue("Expect error: D a date and time are required", error1.contains("D a date and time are required"));
        assertTrue("Expect error: D a date and time are required", error2.contains("D a date and time are required"));
    }


    @Test
    @Category({ChangeRequest.CR_1883.class})
    public void WhenMultiplePendingRulesViewedInPendingSummary_PendingRulesDisplayedInCorrectOrder()
    {
        //Arrange

        //rule starting in 1 days time
        TestRuleModel.RuleDetails ruleDetails = CreatePendingExpiredRuleVersion(1, 2);

        //rule starting in 3 days time
        ruleDetails.description = "rule3DaysTime";
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(3, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(4, DateTime.DateTimeUTCZ);

        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetails, 2);

        //rule starting in 5 mins time but ends in 1 days time
        ruleDetails.description = "rule5MinsTime";
        ruleDetails.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXMinutes(5, DateTime.DateTimeUTCZ);
        ruleDetails.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(1, DateTime.DateTimeUTCZ);

        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetails, 3);

        publishAndWait(5000);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(ListRules);

        RuleSummary_Page ruleSummary_page = listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        List<RuleSummary_Page.RuleSummaryTableObject> ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();
        List<RuleSummary_Page.RuleUpcomingChangesTableObject> rulePendingTableObjects = ruleSummary_page.getListOfUpcomingChanges();

        //Assert
        assertEquals("Expect Status: Pending", "Pending", ruleSummaryTableObjects.get(0).status);

        assertEquals("Expect Name", ruleDetails.description, rulePendingTableObjects.get(0).description);

        String sExpectedDate = DateTime.AdjustLocalDateTimeNowByXDays(0, "dd/MM/yyyy");

        assertThat(rulePendingTableObjects.get(0).startDateTime).contains(sExpectedDate);
        assertEquals("Expect Version", 3, rulePendingTableObjects.get(0).version);
        assertEquals("Expect Status: Pending", "Pending", rulePendingTableObjects.get(0).status);
    }

    @Category({ChangeRequest.CR_3275.class})
    @Test
    public void WhenRuleARuleWithStartInThePast_DateShouldBeRemovedAndNotificationIsDisplayed(){

        //This test is modified. Original test was for expired rule. But as per CR-2350, expired rule cannot have amend button.
        //So, changed the test to be active and start date in past
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.startDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(-90, DateTime.DateTimeUTCZ);

        ruleDetails.endDateTime = DateTime.AdjustLocalDateTimeNowByXDays(1, DateTime.DateTimeUTCZ);

        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        publishAndWait(5000);

        Navigation utilNavigation = new Navigation(driver);
        ListRules_Page listRules_page = utilNavigation.NavigateToPage(ListRules);

        RuleSummary_Page ruleSummary_page = listRules_page.clickRuleSummaryForSpecifiedRule(ruleDetails.description);

        List<RuleSummary_Page.RuleSummaryTableObject> ruleSummaryTableObjects = ruleSummary_page.getListOfRuleSummaryDetails();

        //Assert
        assertEquals("Expect Status: Active", "Active", ruleSummaryTableObjects.get(0).status);

        ruleSummaryTableObjects.get(0).versionDetailActionAmend.click();

        RuleDetails_Page ruleDetails_page = new RuleDetails_Page(driver);
        ruleDetails_page.waitForAngularRequestsToFinish();

        String notificationMessage = ruleDetails_page.startDateNotificationMessage.getText();

        assertEquals("Expect the notification message is The value from end date & time has been removed as it was in the past",
                    "The value from start date & time has been removed as it was in the past", notificationMessage);
    }
}
