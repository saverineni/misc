package TestCases.DataService;

import API.RulesManagementService.Monitoring.AdminResponse;
import API.Utils;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.HealthCheck;
import TestCases.BaseWebAPITestCase;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static API.EnvDetails.EnvDetails.url_DS_Health;
import static API.EnvDetails.EnvDetails.url_DS_Info;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpStatus.OK;

@Category(HealthCheck.class)
public class TestCase_HealthCheck extends BaseWebAPITestCase {

    @Test
    @Category(ChangeRequest.CR_2353.class)
    public void givenInfoEndpointWhenGetRequestThen200ReturnedWithCorrectBuildInfo() {
        String expectedServiceName = "data-service";

        AdminResponse.InfoResponseObject infoResponse = Utils.makeInfoRequest(url_DS_Info);
        AdminResponse.BuildInfo buildInfo = infoResponse.getBuild();

        assertThat(infoResponse.httpStatusCode).isEqualTo(OK.value());
        assertThat(buildInfo.getVersion()).startsWith("v");

        assertThat(buildInfo.getArtifact()).isEqualTo(expectedServiceName);
        assertThat(buildInfo.getName()).isEqualTo(expectedServiceName);

        assertThat(infoResponse.getGit()).isNotNull();
    }

    @Test
    @Category(ChangeRequest.CR_2353.class)
    public void givenHealthEndpointWhenGetRequestedThen200WithUpStatusReturned() {
        AdminResponse.HealthResponseObject healthResponse = Utils.makeHealthRequest(url_DS_Health);

        assertThat(healthResponse).isNotNull();
        assertThat(healthResponse.httpStatusCode).isEqualTo(OK.value());
        assertThat(healthResponse.getStatus()).isEqualTo("UP");
    }
}
