package TestCases.RulesManagementService;


import API.DataForTests.Conditions;
import API.DataForTests.TestRuleModel;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import Categories_CDSRisk.CDS_RM_RulesGeneral;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import org.apache.http.HttpStatus;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_RulesGeneral.class})
@RunWith(JUnitParamsRunner.class)
public class TestCase_RuleAttributeOperators extends BaseWebAPITestCase {

    @Test
    @Category({ChangeRequest.CR_1213.class})
    @Parameters(method  = "RulesSingleConditionOperatorContainsMaxCharsTestData")
    public void WhenRuleSavedAndCommittedWithOperatorContainsMaxChars_DraftRuleCreatedSuccessfully(API.DataForTests.RulesSingleCondition rdrTestData) throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.description = rdrTestData.description;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = rdrTestData.attributeName;
        ruleDetails.queryConditions.get(0).conditions.get(0).operator = rdrTestData.attributeOperator;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = rdrTestData.ruleAttributeValue;

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response.uniqueId;

        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);

        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);

    }

    private Object[] RulesSingleConditionOperatorContainsMaxCharsTestData()
    {
        return API.DataForTests.RulesSingleCondition.RulesSingleConditionOperatorContainsMaxCharsTestData();
    }

    @Test
    @Category({ChangeRequest.CR_1213.class})
    @Parameters(method  = "RulesSingleConditionOperatorContainsMinChars")
    public void WhenRuleSavedAndCommittedWithOperatorContainsMinChars_DraftRuleCreatedSuccessfully(API.DataForTests.RulesSingleCondition rdrTestData) throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.description = rdrTestData.description;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = rdrTestData.attributeName;
        ruleDetails.queryConditions.get(0).conditions.get(0).operator = rdrTestData.attributeOperator;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = rdrTestData.ruleAttributeValue;

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response.uniqueId;

        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);

        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
    }

    private Object[] RulesSingleConditionOperatorContainsMinChars()
    {
        return API.DataForTests.RulesSingleCondition.RulesSingleConditionOperatorContainsMinCharsTestData();
    }


    @Test
    @Category({ChangeRequest.CR_1213.class})
    @Parameters(method  = "RulesSingleConditionOperatorNotContainsMaxCharsTestData")
    public void WhenRuleSavedAndCommittedWithOperatorDoesNotContainMaxChars_DraftRuleCreatedSuccessfully(API.DataForTests.RulesSingleCondition rdrTestData) throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.description = rdrTestData.description;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = rdrTestData.attributeName;
        ruleDetails.queryConditions.get(0).conditions.get(0).operator = rdrTestData.attributeOperator;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = rdrTestData.ruleAttributeValue;

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response.uniqueId;

        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);

        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
    }

    private Object[] RulesSingleConditionOperatorNotContainsMaxCharsTestData()
    {
        return API.DataForTests.RulesSingleCondition.RulesSingleConditionOperatorNotContainsMaxCharsTestData();
    }


    @Test
    @Category({ChangeRequest.CR_1213.class})
    @Parameters(method  = "RulesSingleConditionOperatorNotContainsMinCharsTestData")
    public void WhenRuleSavedAndCommittedWithOperatorDoesNotContainMinChars_DraftRuleCreatedSuccessfully(API.DataForTests.RulesSingleCondition rdrTestData) throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.description = rdrTestData.description;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = rdrTestData.attributeName;
        ruleDetails.queryConditions.get(0).conditions.get(0).operator = rdrTestData.attributeOperator;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = rdrTestData.ruleAttributeValue;

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response.uniqueId;

        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);

        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);
    }

    private Object[] RulesSingleConditionOperatorNotContainsMinCharsTestData()
    {
        return API.DataForTests.RulesSingleCondition.RulesSingleConditionOperatorNotContainsMinCharsTestData();
    }


    //--------------

    @Test
    @Category({ChangeRequest.CR_1481.class})
    @Parameters(method  = "RulesSingleConditionOperatorStartsWithMaxCharsTestData")
    public void WhenRuleSavedAndCommittedWithOperatorStartsWithMaxChars_DraftRuleCreatedSuccessfully(API.DataForTests.RulesSingleCondition rdrTestData) throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.description = rdrTestData.description;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = rdrTestData.attributeName;
        ruleDetails.queryConditions.get(0).conditions.get(0).operator = rdrTestData.attributeOperator;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = rdrTestData.ruleAttributeValue;

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response.uniqueId;

        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);

        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);

    }

    private Object[] RulesSingleConditionOperatorStartsWithMaxCharsTestData()
    {
        return API.DataForTests.RulesSingleCondition.RulesSingleConditionOperatorStartsWithMaxCharsTestData();
    }

    @Test
    @Category({ChangeRequest.CR_1481.class})
    @Parameters(method  = "RulesSingleConditionOperatorStartsWithMinCharsTestData")
    public void WhenRuleSavedAndCommittedWithOperatorStartsWithMinChars_DraftRuleCreatedSuccessfully(API.DataForTests.RulesSingleCondition rdrTestData) throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.description = rdrTestData.description;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = rdrTestData.attributeName;
        ruleDetails.queryConditions.get(0).conditions.get(0).operator = rdrTestData.attributeOperator;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = rdrTestData.ruleAttributeValue;

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response.uniqueId;

        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);

        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);

    }

    private Object[] RulesSingleConditionOperatorStartsWithMinCharsTestData()
    {
        return API.DataForTests.RulesSingleCondition.RulesSingleConditionOperatorStartsWithMinCharsTestData();
    }


    @Test
    @Category({ChangeRequest.CR_1481.class})
    @Parameters(method  = "RulesSingleConditionOperatorNotStartsWithMaxCharsTestData")
    public void WhenRuleSavedAndCommittedWithOperatorNotStartsWithMaxChars_DraftRuleCreatedSuccessfully(API.DataForTests.RulesSingleCondition rdrTestData) throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.description = rdrTestData.description;
        ruleDetails.queryConditions.get(0).conditions.get(0).attribute = rdrTestData.attributeName;
        ruleDetails.queryConditions.get(0).conditions.get(0).operator = rdrTestData.attributeOperator;
        ruleDetails.queryConditions.get(0).conditions.get(0).value = rdrTestData.ruleAttributeValue;

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = response.uniqueId;

        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);

        assertEquals(HttpStatus.SC_OK, commitResponse.httpStatusCode);

    }

    private Object[] RulesSingleConditionOperatorNotStartsWithMaxCharsTestData()
    {
        return API.DataForTests.RulesSingleCondition.RulesSingleConditionOperatorNotStartsWithMaxCharsTestData();
    }


    @Test
    @Category({ChangeRequest.CR_1213.class})
    public void WhenRuleSavedWithOperatorContains_DraftRuleCreatedSuccessfully() throws Throwable {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.goodsDescription();

        condition.operator = "con";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);
    }

    @Test
    @Category({ChangeRequest.CR_1213.class})
    public void WhenRuleSavedWithOperatorDoesNotContain_DraftRuleCreatedSuccessfully() throws Throwable {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.consigneeEori();

        condition.operator = "nco";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);
    }


    @Test
    @Category({ChangeRequest.CR_1624.class})
    public void WhenRuleSavedWithOperatorLessThan_DraftRuleCreatedSuccessfully() throws Throwable {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.statisticalValue();

        condition.operator = "lt";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);
    }

    @Test
    @Category({ChangeRequest.CR_1625.class})
    public void WhenRuleSavedWithOperatorLessThanOrEqualTo_DraftRuleCreatedSuccessfully() throws Throwable {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.statisticalValue();

        condition.operator = "lte";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);
    }


    @Test
    @Category({ChangeRequest.CR_1625.class})
    public void WhenRuleSavedWithOperatorGreaterThan_DraftRuleCreatedSuccessfully() throws Throwable {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.statisticalValue();

        condition.operator = "gt";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);
    }

    @Test
    @Category({ChangeRequest.CR_1624.class})
    public void WhenRuleSavedWithOperatorGreaterThanOrEqualTo_DraftRuleCreatedSuccessfully() throws Throwable {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        TestRuleModel.RuleDetails.Condition condition = Conditions.statisticalValue();

        condition.operator = "gte";
        ruleDetails.queryConditions.get(0).conditions.clear();
        ruleDetails.queryConditions.get(0).conditions.add(condition);

        //Act
        CreateRuleResponse.PostResponse response = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_CREATED, response.httpStatusCode);
        CreateRuleResponse.AssertCreateRuleResponse(ruleDetails, response);
    }

}