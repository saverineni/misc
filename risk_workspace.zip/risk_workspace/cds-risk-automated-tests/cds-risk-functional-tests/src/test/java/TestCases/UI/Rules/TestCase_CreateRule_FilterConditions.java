package TestCases.UI.Rules;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Rules;
import Categories_CDSRisk.CDS_Risk_UI_Rules_1;
import Categories_CDSRisk.ChangeRequest;
import FunctionsLibrary.Utils;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.DataForTests.Rules;
import UI.DataForTests.TestRuleModel;
import UI.Pages.RulesManagement.CreateLocalRule_Page;
import UI.Utils.Navigation;
import UI.Utils.Users;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.ArrayList;
import java.util.List;

import static API.RulesManagementService.Utils.DataTables.CreateDataTableAndGetResponseObject;
import static UI.DataForTests.TestRuleModel.RuleDetails.Condition.AttributeType.DOMAIN;
import static UI.DataForTests.TestRuleModel.RuleDetails.Condition.AttributeType.HEADER;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Rules.class, CDS_Risk_UI_Rules_1.class})
public class TestCase_CreateRule_FilterConditions extends BaseUIWebDriverTestCase {

    @Category(ChangeRequest.CR_2362.class)
    @Test
    public void WhenRuleManagerSearchesForAttribute_CorrectAttributesDisplayedInEachTab() {
        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        Navigation utilNavigation = new Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.Rules.DraftLocalRule_POO();

        //Act
        createLocalRule_page.SearchForAttributeAndSelectIt("header", HEADER);
        //createLocalRule_page.headerTab.click();
        List<String> actAttributeValues = createLocalRule_page.getListOfFilteredAttributeValues();

        //Assert
        assertTrue(actAttributeValues.size() > 0);
        assertTrue(createLocalRule_page.extractNumberFromConditionTabs(createLocalRule_page.headerTab) > 0);
        assertEquals(createLocalRule_page.extractNumberFromConditionTabs(createLocalRule_page.itemsTab), 0);
        assertEquals(createLocalRule_page.extractNumberFromConditionTabs(createLocalRule_page.domainTab), 0);
    }


    @Category(ChangeRequest.CR_2362.class)
    @Test
    public void WhenRuleManagerSearchesForAttribute_CanChooseRightValueUsingTabs() {
        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        Users utilUsers = new Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        Rules.DraftLocalRule_POO();

        //Assert
        String attributeToSelect = "Consignee";
        createLocalRule_page.SearchForAttributeAndSelectIt(attributeToSelect, TestRuleModel.RuleDetails.Condition.AttributeType.HEADER);
        assertTrue(createLocalRule_page.extractNumberFromConditionTabs(createLocalRule_page.headerTab) > 0);

        createLocalRule_page.headerTab.click();
        createLocalRule_page.conditionAttributeListOptions.get(0).click();
        assertTrue(createLocalRule_page.selectedAttribute.getText().contains("Consignee Address (Header)"));

        createLocalRule_page.SearchForAttributeAndSelectIt("domain", DOMAIN);
        //createLocalRule_page.domainTab.click();

        List<String> actAttributeValues = createLocalRule_page.getListOfFilteredAttributeValues();
        assertTrue(actAttributeValues.size() > 0);

        createLocalRule_page.itemsTab.click();
        assertTrue(createLocalRule_page.extractNumberFromConditionTabs(createLocalRule_page.itemsTab) == 0);

        createLocalRule_page.domainTab.click();
        assertTrue(createLocalRule_page.extractNumberFromConditionTabs(createLocalRule_page.domainTab) > 0);
    }

    @Category(ChangeRequest.CR_1870.class)
    @Test
    public void WhenRuleManagerSearchesForAttributeCaseIsIgnored_CorrectAttributesDisplayed() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.Rules.DraftLocalRule_POO();

        //Act
        createLocalRule_page.SearchForAttributeAndSelectIt("cOUnTry (doM", DOMAIN);
        List<String> actAttributeValues = createLocalRule_page.getListOfFilteredAttributeValues();

        //Assert
        Assertions.assertThat(actAttributeValues).hasSize(8)
                .containsOnly("Consignee Country (Domain)",
                        "Consignor Country (Domain)",
                        "Country (Domain)",
                        "Declarant/Rep Country (Domain)",
                        "Destination Country (Domain)",
                        "Dispatch Country (Domain)",
                        "Exporter/Seller/Consignor Country (Domain)",
                        "Importer/Buyer Country (Domain)");
    }

    @Category(ChangeRequest.CR_1870.class)
    @Test
    public void WhenRuleManagerSearchesForNonExistentAttribute_NoResultsFound() {

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        UI.Utils.Navigation utilNavigation = new UI.Utils.Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        UI.DataForTests.Rules.DraftLocalRule_POO();

        //Act
        createLocalRule_page.SearchForAttributeAndSelectIt("zero", HEADER);
        List<String> actAttributeValues = createLocalRule_page.getListOfFilteredAttributeValues();

        //Assert
        Assertions.assertThat(actAttributeValues).hasSize(0);
        String actualMessage = createLocalRule_page.conditionAttributeNoResult.getText();

        assertEquals("No results found", actualMessage);
    }


    @Category(ChangeRequest.CR_1567.class)
    @Test
    public void WhenRuleManagerSearchesDataTablesByTags_CorrectDataTablesAreDisplayed() {

        List<String> dataTableTags = new ArrayList<>();
        dataTableTags.add("medical");
        dataTableTags.add("surgical");
        List<String> dataTableTags1 = new ArrayList<>();
        dataTableTags1.add("surgical");

        API.DataForTests.TestDataTableModel.TableDetails tableDetails_CommodityCodes_National = API.DataForTests.DataTables.DataTable_CommodityCodes_NAT();
        tableDetails_CommodityCodes_National.tags = dataTableTags;
        CreateDataTableResponse.PostResponse commodityTableNAT = CreateDataTableAndGetResponseObject(tableDetails_CommodityCodes_National);

        API.DataForTests.TestDataTableModel.TableDetails tableDetails_CommodityCodes_Poo = API.DataForTests.DataTables.DataTable_CommodityCodes_POO();
        tableDetails_CommodityCodes_Poo.tags = dataTableTags1;
        CreateDataTableResponse.PostResponse commodityTablePoo = CreateDataTableAndGetResponseObject(tableDetails_CommodityCodes_Poo);

        API.DataForTests.TestDataTableModel.TableDetails tableDetails_PartCommodityCodes_Poo = API.DataForTests.DataTables.DataTable_PartCommodityCodes_POO();
        CreateDataTableResponse.PostResponse partCommodityTablePoo = CreateDataTableAndGetResponseObject(tableDetails_PartCommodityCodes_Poo);
        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        Users utilUsers = new Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        TestRuleModel.RuleDetails localRulePoo = Rules.DraftLocalRule_POO();

        //Assert
        String attributeToSelect = "Commodity Code (TSP & TRC) (Item)";
        createLocalRule_page.SearchForAttributeAndSelectIt(attributeToSelect, TestRuleModel.RuleDetails.Condition.AttributeType.ITEM);

        UI.ElementControls.DropDown dropDown = new UI.ElementControls.DropDown(driver);
        dropDown.select(createLocalRule_page.conditionOperator, localRulePoo.conditionGroups.get(0).conditions.get(0).operator);

        UI.ElementControls.CheckBox checkBox = new UI.ElementControls.CheckBox((driver));
        checkBox.check(createLocalRule_page.selectDataTable);
        createLocalRule_page.selectDataTableFromList.click();
        createLocalRule_page.searchDataTableDropdown.sendKeys("surgical");
        Utils.SleepForMilliSeconds(500);
        List<String> dataTablesInDropDown = createLocalRule_page.getListOfDataTables(createLocalRule_page.selectDataTableFromList);
        Assertions.assertThat(dataTablesInDropDown)
                .hasSize(2)
                .containsOnly(tableDetails_CommodityCodes_National.tableName, tableDetails_CommodityCodes_Poo.tableName);

    }

    @Category(ChangeRequest.CR_1567.class)
    @Test
    public void WhenRuleManagerSearchesDataTablesWithNonExistentTags_NoDataTablesAreDisplayed() {

        List<String> dataTableTags = new ArrayList<>();
        dataTableTags.add("medical");
        dataTableTags.add("surgical");

        API.DataForTests.TestDataTableModel.TableDetails tableDetails_CommodityCodes_National = API.DataForTests.DataTables.DataTable_CommodityCodes_NAT();
        tableDetails_CommodityCodes_National.tags = dataTableTags;
        CreateDataTableResponse.PostResponse commodityTableNAT = CreateDataTableAndGetResponseObject(tableDetails_CommodityCodes_National);

        API.DataForTests.TestDataTableModel.TableDetails tableDetails_PartCommodityCodes_Poo = API.DataForTests.DataTables.DataTable_PartCommodityCodes_POO();
        CreateDataTableResponse.PostResponse partCommodityTablePoo = CreateDataTableAndGetResponseObject(tableDetails_PartCommodityCodes_Poo);
        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        Users utilUsers = new Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        TestRuleModel.RuleDetails localRulePoo = Rules.DraftLocalRule_POO();

        //Assert
        String attributeToSelect = "Commodity Code (TSP & TRC) (Item)";
        createLocalRule_page.SearchForAttributeAndSelectIt(attributeToSelect, TestRuleModel.RuleDetails.Condition.AttributeType.ITEM);

        UI.ElementControls.DropDown dropDown = new UI.ElementControls.DropDown(driver);
        dropDown.select(createLocalRule_page.conditionOperator, localRulePoo.conditionGroups.get(0).conditions.get(0).operator);

        UI.ElementControls.CheckBox checkBox = new UI.ElementControls.CheckBox((driver));
        checkBox.check(createLocalRule_page.selectDataTable);
        createLocalRule_page.selectDataTableFromList.click();
        createLocalRule_page.searchDataTableDropdown.sendKeys("banned");
        Utils.SleepForMilliSeconds(500);
        List<String> dataTablesInDropDown = createLocalRule_page.getListOfDataTables(createLocalRule_page.selectDataTableFromList);
        Assertions.assertThat(dataTablesInDropDown)
                .hasSize(0);
    }

    @Category(ChangeRequest.CR_1567.class)
    @Test
    public void WhenLocalRuleManagerSearchesDataTablesWithTags_CorrectDataTablesAreDisplayed() {

        List<String> dataTableTags = new ArrayList<>();
        dataTableTags.add("dangerous");

        API.DataForTests.TestDataTableModel.TableDetails tableDetails_CommodityCodes_Poo = API.DataForTests.DataTables.DataTable_CommodityCodes_POO();
        tableDetails_CommodityCodes_Poo.tags = dataTableTags;
        CreateDataTableResponse.PostResponse commodityTablePoo = CreateDataTableAndGetResponseObject(tableDetails_CommodityCodes_Poo);

        API.DataForTests.TestDataTableModel.TableDetails tableDetails_PartCommodityCodes_Ext = API.DataForTests.DataTables.DataTable_CommodityCodes_EXT();
        tableDetails_PartCommodityCodes_Ext.tableType = "Restricted";
        tableDetails_PartCommodityCodes_Ext.tags = dataTableTags;
        CreateDataTableResponse.PostResponse partCommodityTableExt = CreateDataTableAndGetResponseObject(tableDetails_PartCommodityCodes_Ext);

        //Arrange
        TestUserModel.UserDetails userDetailsRM = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsRM);

        Users utilUsers = new Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsRM);

        //Act
        Navigation utilNavigation = new Navigation(driver);
        CreateLocalRule_Page createLocalRule_page = utilNavigation.NavigateToPage(Navigation.Pages.CreateLocalRule);

        TestRuleModel.RuleDetails localRulePoo = Rules.DraftLocalRule_POO();

        //Assert
        String attributeToSelect = "Commodity Code (TSP & TRC) (Item)";
        createLocalRule_page.SearchForAttributeAndSelectIt(attributeToSelect, TestRuleModel.RuleDetails.Condition.AttributeType.ITEM);

        UI.ElementControls.DropDown dropDown = new UI.ElementControls.DropDown(driver);
        dropDown.select(createLocalRule_page.conditionOperator, localRulePoo.conditionGroups.get(0).conditions.get(0).operator);

        UI.ElementControls.CheckBox checkBox = new UI.ElementControls.CheckBox((driver));
        checkBox.check(createLocalRule_page.selectDataTable);
        createLocalRule_page.selectDataTableFromList.click();
        createLocalRule_page.searchDataTableDropdown.sendKeys("dangerous");
        Utils.SleepForMilliSeconds(500);
        List<String> dataTablesInDropDown = createLocalRule_page.getListOfDataTables(createLocalRule_page.selectDataTableFromList);
        Assertions.assertThat(dataTablesInDropDown)
                .hasSize(1)
                .containsOnly(tableDetails_CommodityCodes_Poo.tableName);
    }


}
