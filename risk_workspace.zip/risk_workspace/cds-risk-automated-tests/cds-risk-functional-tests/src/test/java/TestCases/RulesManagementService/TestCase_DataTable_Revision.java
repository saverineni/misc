package TestCases.RulesManagementService;


import API.DataForTests.DataTables;
import API.DataForTests.TestDataTableModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.DataTableDataRevision.ViewDataTableDataRevisionResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import API.RulesManagementService.Data.ViewDataTableHistory.ViewDataTableHistoryResponse.ViewDTHistoryResponseObject;
import API.RulesManagementService.Data.ViewDataTableRevision.ViewDataTableRevisionResponse;
import Categories_CDSRisk.CDS_RM_DataTable;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import org.apache.commons.httpclient.HttpStatus;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static API.RulesManagementService.Utils.DataTables.*;
import static org.junit.Assert.assertEquals;


@Category({Rules_Management.class, CDS_RM_DataTable.class})
public class TestCase_DataTable_Revision extends WebAPITestCaseWithDatatablesCleanup {

    @Test
    @Category(ChangeRequest.CR_2217.class)
    public void WhenDataTableCreated_EventAppearsInDataTableHistoryRevision() {

        //Arrange
        TestUserModel.UserDetails udNatRulesManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_POO();

        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;

        //Act
        ViewDTHistoryResponseObject viewDTHistoryResponseObject = GetListOfDataTableHistory(createDataTableResponse.uuid);
        int revision = viewDTHistoryResponseObject.viewDTHistoryList.get(0).revision;

        ViewDataTableRevisionResponse.ViewDTHistoryRevisionResponseObject tableRevisionResponseObject = getTableRevisionResponse(tableDetails.uuid, revision);
        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, tableRevisionResponseObject.httpStatusCode);

        Integer version = 1;
        assertEquals(tableDetails.tableName, tableRevisionResponseObject.tableName);
        assertEquals(tableDetails.userPid, tableRevisionResponseObject.metaData.createdUser.pid);
        assertEquals(version, tableRevisionResponseObject.version);
        assertEquals(udNatRulesManager.firstname, tableRevisionResponseObject.metaData.createdUser.firstName);
        assertEquals(udNatRulesManager.lastname, tableRevisionResponseObject.metaData.createdUser.lastName);
    }

    @Test
    @Category(ChangeRequest.CR_2217.class)
    public void WhenDataTableHeaderDetailsEdited_RevisionHistoryContainsNonDataSpecificInfo() {

        //Arrange
        TestUserModel.UserDetails udNatRulesManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;
        tableDetails.uniqueId = createDataTableResponse.uniqueId;

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        tableDetails.description = "Table edited for revision details";
        tableDetails.tableName = "Table name edited for revision";
        tableDetails.reason = "Table reason edited for revision details";
        EditDataTableHeaderDetailsAndGetResponseObject(tableDetails);

        ViewDTHistoryResponseObject viewDTHistoryResponseObject = GetListOfDataTableHistory(createDataTableResponse.uuid);
        int revision = viewDTHistoryResponseObject.viewDTHistoryList.get(0).revision;

        ViewDataTableRevisionResponse.ViewDTHistoryRevisionResponseObject tableRevisionResponseObject = getTableRevisionResponse(tableDetails.uuid, revision);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, tableRevisionResponseObject.httpStatusCode);

        Integer tableVersion = 2;
        assertEquals(2, viewDTHistoryResponseObject.viewDTHistoryList.size());
        assertEquals(tableVersion , tableRevisionResponseObject.version);
        assertEquals(udNatRulesManager.firstname, tableRevisionResponseObject.metaData.createdUser.firstName);
        assertEquals(udNatRulesManager.lastname, tableRevisionResponseObject.metaData.createdUser.lastName);
        assertEquals(tableDetails.description , tableRevisionResponseObject.description);
        assertEquals(tableDetails.tableName, tableRevisionResponseObject.tableName);
        assertEquals("Non-Data", viewDTHistoryResponseObject.viewDTHistoryList.get(0).changeType);
    }

    @Test
    @Category(ChangeRequest.CR_2217.class)
    public void WhenDataTableDataItemsEdited_AndDataFilterApplied_RevisionHistoryContainsDataSpecificInfo() {

        //Arrange
        TestUserModel.UserDetails udNatRulesManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;
        tableDetails.uniqueId = createDataTableResponse.uniqueId;

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        tableDetails.dataItemsToAdd.add("1000000000");
        tableDetails.dataItemsToAdd.add("2000000000");
        tableDetails.dataItems.addAll(tableDetails.dataItemsToAdd);

        editDataTableDataItems(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail1 = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail1.opLockVersion;

        tableDetails.tableName = "edited table for revision";
        EditDataTableHeaderDetailsAndGetResponseObject(tableDetails);

        ViewDTHistoryResponseObject viewDTHistoryResponseObject = GetListOfDataTableHistory(createDataTableResponse.uuid);
        int revision = viewDTHistoryResponseObject.viewDTHistoryList.get(0).revision;

        ViewDataTableDataRevisionResponse.ViewDTDataRevisionResponseObject viewDTDataRevisionResponseObject = getTableRevisionDataResponse(tableDetails.uuid, revision);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, viewDTDataRevisionResponseObject.httpStatusCode);

        Integer tableVersion = 3;
        assertEquals(3, viewDTHistoryResponseObject.viewDTHistoryList.size());
        assertEquals("Data", viewDTHistoryResponseObject.viewDTHistoryList.get(1).changeType);
        assertEquals(tableVersion , viewDTDataRevisionResponseObject.version);
        assertEquals(udNatRulesManager.firstname, viewDTDataRevisionResponseObject.metaData.createdUser.firstName);
        assertEquals(udNatRulesManager.lastname, viewDTDataRevisionResponseObject.metaData.createdUser.lastName);
        assertEquals(tableDetails.reason, viewDTDataRevisionResponseObject.reason);
    }

}
