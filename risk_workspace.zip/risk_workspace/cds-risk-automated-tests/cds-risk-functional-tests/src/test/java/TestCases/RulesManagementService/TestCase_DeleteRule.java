package TestCases.RulesManagementService;


import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.RulesManagementService.CreateRule.CreateRuleResponse;
import API.RulesManagementService.EditRule.EditRuleResponse;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import API.RulesManagementService.ViewRule.ViewRuleResponse;
import API.RulesManagementService.ViewRuleList.ViewRuleListResponse;
import Categories_CDSRisk.CDS_RM_RuleLifeCycle;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import FunctionsLibrary.DateTime;
import TestCases.BaseWebAPITestCase;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;

import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_RuleLifeCycle.class})
public class TestCase_DeleteRule extends BaseWebAPITestCase {

    @Test
    @Category(ChangeRequest.CR_271.class)
    public void WhenDraftRuleDeleted_DraftRuleDeletedSuccessfully() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse deletedResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.delete);

        //Assert
        assertEquals(HttpStatus.SC_OK, deletedResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.deleted.toString(), deletedResponse.status);
    }

    @Test
    @Category(ChangeRequest.CR_271.class)
    public void WhenDraftRuleDeleted_DeletedRuleNotPresentInListOfRules() throws Throwable
    {
        //Arrange
        ViewRuleListResponse.ViewRuleListResponseObject viewRulesAtStart = API.RulesManagementService.Utils.Rules.GetListOfRules();

        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        EditRuleVersionResponse.PutResponse deletedResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.delete);

        //Act
        ViewRuleListResponse.ViewRuleListResponseObject viewRulesResponse = API.RulesManagementService.Utils.Rules.GetListOfRules();

        //Assert
        assertEquals("Rule in List: ", 0, viewRulesResponse.content.size() - viewRulesAtStart.content.size());
    }

    @Test
    @Category(ChangeRequest.CR_271.class)
    public void WhenLatestDraftRuleDeleted_DraftRuleVersionDeletedSuccessfully() throws Throwable
    {
        //Arrange
        //Create initial draft rule
        TestRuleModel.RuleDetails initialRuleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse draftRuleV1 = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(initialRuleDetails);

        //Create second version of the draft rule
        TestRuleModel.RuleDetails amendedRuleDetails = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        amendedRuleDetails.uniqueID = draftRuleV1.uniqueId;
        EditRuleResponse.PutResponse draftRuleV2 = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(amendedRuleDetails);
        amendedRuleDetails.uniqueID = draftRuleV2.uniqueId;

        //Confirm draft rule version 2 appears once in rule list
        ViewRuleListResponse.ViewRuleListResponseObject viewRulesResponse1 = API.RulesManagementService.Utils.Rules.GetListOfRules();
        int countOfInstancesOfDraftRuleV2InRuleListBeforeDelete = 0;
        for (int x=0; x< viewRulesResponse1.content.size(); x++)
            if (viewRulesResponse1.content.get(x).description.equals(draftRuleV2.description)) {
                countOfInstancesOfDraftRuleV2InRuleListBeforeDelete++;
            }
        assertEquals(1,countOfInstancesOfDraftRuleV2InRuleListBeforeDelete);

        //Confirm draft rule version 1 does not appear in rule list
        ViewRuleListResponse.ViewRuleListResponseObject viewRulesResponse2 = API.RulesManagementService.Utils.Rules.GetListOfRules();
        int countOfInstancesOfDraftRuleV1InRuleListBeforeDelete = 0;
        for (int x=0; x< viewRulesResponse2.content.size(); x++)
            if (viewRulesResponse2.content.get(x).description.equals(draftRuleV1.description)) {
                countOfInstancesOfDraftRuleV1InRuleListBeforeDelete++;
            }
        assertEquals(0,countOfInstancesOfDraftRuleV1InRuleListBeforeDelete);

        //Act
        //Delete the lead version of the draft rule
        EditRuleVersionResponse.PutResponse deletedResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(amendedRuleDetails,
                RuleVersionActions.delete);

        //Assert
        assertEquals(HttpStatus.SC_OK, deletedResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.draft.toString(), deletedResponse.status);

        //Confirm draft rule version 2 does not appear in the rule list
        ViewRuleListResponse.ViewRuleListResponseObject viewRulesResponse3 = API.RulesManagementService.Utils.Rules.GetListOfRules();
        int countOfInstancesOfDraftRuleV2InRuleListAfterDelete = 0;
        for (int x=0; x< viewRulesResponse3.content.size(); x++)
            if (viewRulesResponse3.content.get(x).description.equals(draftRuleV2.description)) {
                countOfInstancesOfDraftRuleV2InRuleListAfterDelete++;
            }
        assertEquals(0,countOfInstancesOfDraftRuleV2InRuleListAfterDelete);

        //Confirm draft rule version 1 appears once in rule list
        ViewRuleListResponse.ViewRuleListResponseObject viewRulesResponse4 = API.RulesManagementService.Utils.Rules.GetListOfRules();
        int countOfInstancesOfDraftRuleV1InRuleListAfterDelete = 0;
        for (int x=0; x< viewRulesResponse4.content.size(); x++)
            if (viewRulesResponse4.content.get(x).description.equals(draftRuleV1.description)) {
                countOfInstancesOfDraftRuleV1InRuleListAfterDelete++;
            }
        assertEquals(1,countOfInstancesOfDraftRuleV1InRuleListAfterDelete);
    }

    @Test
    @Category(ChangeRequest.CR_271.class)
    public void WhenLatestDraftRuleDeleted_PreviousVersionNowPresentInRuleSummary() throws Throwable {

        //Arrange
        //Create initial draft rule
        TestRuleModel.RuleDetails initialRuleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse draftRuleV1 = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(initialRuleDetails);

        //Create second version of the draft rule
        TestRuleModel.RuleDetails amendedRuleDetails = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        amendedRuleDetails.uniqueID = draftRuleV1.uniqueId;
        EditRuleResponse.PutResponse draftRuleV2 = API.RulesManagementService.Utils.Rules.EditRuleAndGetResponseObject(amendedRuleDetails);
        amendedRuleDetails.uniqueID = draftRuleV2.uniqueId;

        //Confirm draft rule version 2 appears once in rule list
        ViewRuleListResponse.ViewRuleListResponseObject viewRulesResponse1 = API.RulesManagementService.Utils.Rules.GetListOfRules();
        int countOfInstancesOfDraftRuleV2InRuleListBeforeDelete = 0;
        for (int x=0; x< viewRulesResponse1.content.size(); x++)
            if (viewRulesResponse1.content.get(x).description.equals(draftRuleV2.description)) {
                countOfInstancesOfDraftRuleV2InRuleListBeforeDelete++;
            }
        assertEquals(1,countOfInstancesOfDraftRuleV2InRuleListBeforeDelete);

        //Confirm draft rule version 1 does not appear in rule list
        ViewRuleListResponse.ViewRuleListResponseObject viewRulesResponse2 = API.RulesManagementService.Utils.Rules.GetListOfRules();
        int countOfInstancesOfDraftRuleV1InRuleListBeforeDelete = 0;
        for (int x=0; x< viewRulesResponse2.content.size(); x++)
            if (viewRulesResponse2.content.get(x).description.equals(draftRuleV1.description)) {
                countOfInstancesOfDraftRuleV1InRuleListBeforeDelete++;
            }
        assertEquals(0,countOfInstancesOfDraftRuleV1InRuleListBeforeDelete);

        //Act
        //Delete the lead version of the draft rule
        EditRuleVersionResponse.PutResponse deletedResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(amendedRuleDetails,
                RuleVersionActions.delete);

        //Act
        ViewRuleResponse.ViewRuleResponseObject viewRuleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(draftRuleV1.uniqueId);

        //Assert
        assertEquals(draftRuleV1.description, viewRuleResponse.leadVersion.description);
    }

    @Test
    @Category(ChangeRequest.CR_271.class)
    public void AttemptToDeletePreviousVersionOfDraftRule_PreviousVersionNotDeleted() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        EditRuleResponse.PutResponse draftRuleV2 = API.RulesManagementService.Utils.RuleAtStatus.CreateDraftRuleVersion2Rule();
        ruleDetails.uniqueID = draftRuleV2.uniqueId;

        //Act
        ruleDetails.version = 1;
        EditRuleVersionResponse.PutResponse deletedResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.delete);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, deletedResponse.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_271.class)
    public void AttemptToDeleteCommittedRule_LiveRuleNotDeleted() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse committedRuleResp = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();
        ruleDetails.uniqueID = committedRuleResp.uniqueId;

        //Act
        EditRuleVersionResponse.PutResponse deletedResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.delete);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, deletedResponse.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_271.class)
    public void AttemptToUpdateDeletedRule_RuleNotFound() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        EditRuleVersionResponse.PutResponse deletedResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.delete);

        //Act
        Response editResponse = API.RulesManagementService.Utils.Rules.EditRule(ruleDetails);

        //Assert
        assertEquals(HttpStatus.SC_NOT_FOUND, editResponse.getStatusCode());
    }

    @Test
    @Category(ChangeRequest.CR_271.class)
    public void AttemptToCommitDeletedRule_RuleNotFound() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        EditRuleVersionResponse.PutResponse deletedResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.delete);

        //Act
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.commit);

        //Assert
        assertEquals(HttpStatus.SC_NOT_FOUND, commitResponse.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_271.class)
    public void AttemptToDeleteDeletedRule_RuleNotFound() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        EditRuleVersionResponse.PutResponse deletedResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.delete);

        //Act
        EditRuleVersionResponse.PutResponse deletedResponse2 = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.delete);

        //Assert
        assertEquals(HttpStatus.SC_NOT_FOUND, deletedResponse2.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_271.class)
    public void AttemptToDeleteRuleWithInvalidID_RuleNotFound() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);

        //Act
        ruleDetails.uniqueID = "3b3f816b-146e-11e7-bbc6-0242ac110dbb";
        EditRuleVersionResponse.PutResponse deletedResponse2 = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.delete);

        //Assert
        assertEquals(HttpStatus.SC_NOT_FOUND, deletedResponse2.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_271.class)
    public void AttemptToDeleteRuleWithInvalidVersion_RuleNotFound() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        ruleDetails.version = 9;
        EditRuleVersionResponse.PutResponse deletedResponse2 = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.delete);

        //Assert
        assertEquals(HttpStatus.SC_NOT_FOUND, deletedResponse2.httpStatusCode);
    }

    @Test
    @Category(ChangeRequest.CR_1882.class)
    public void AttemptToDeleteActiveRule_ActiveRuleNotDeleted() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        EditRuleVersionResponse.PutResponse committedRuleResp = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule();
        ruleDetails.uniqueID = committedRuleResp.uniqueId;

        publishAndWait(5000);

        //Act
        EditRuleVersionResponse.PutResponse deletedResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.delete);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, deletedResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleErrorMessages.CANNOT_DELETE_ACTIVE_RULE, deletedResponse.response.path("message"));
    }

    @Test
    @Category(ChangeRequest.CR_1882.class)
    public void AttemptToDeleteExpiredRule_ExpiredRuleNotDeleted() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetails.endDateTime = DateTime.AdjustLocalDateTimeNowByXMinutes(1, DateTime.DateTimeUTCZ);
        EditRuleVersionResponse.PutResponse committedRuleResp = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);
        ruleDetails.uniqueID = committedRuleResp.uniqueId;

        publishAndWait(5000);

        Thread.sleep(90000);
        //Act
        EditRuleVersionResponse.PutResponse deletedResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.delete);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, deletedResponse.httpStatusCode);
        //todo - the error message should display "Cannot delete expired rule "
        //assertEquals(TestEnumerators.RuleErrorMessages.CANNOT_DELETE_EXPIRED_RULE, deletedResponse.response.path("message"));
    }

    @Test
    @Category({ChangeRequest.CR_1880.class})
    public void AttemptToDeleteRuleWithNoReason_RuleNotDeleted() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = API.DataForTests.Rules.DraftNatRuleNatManager();
        CreateRuleResponse.PostResponse createRuleResponse = API.RulesManagementService.Utils.Rules.CreateRuleAndGetResponseObject(ruleDetails);
        ruleDetails.uniqueID = createRuleResponse.uniqueId;

        //Act
        ruleDetails.reason = "";
        EditRuleVersionResponse.PutResponse commitResponse = API.RulesManagementService.Utils.Rules.UpdateStatusOfRule(ruleDetails,
                RuleVersionActions.delete);

        //Assert
        assertEquals(HttpStatus.SC_BAD_REQUEST, commitResponse.httpStatusCode);
    }
}
