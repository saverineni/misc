    package TestCases.UI.Navigation;

    import API.DataForTests.PaginationInfo;
    import API.DataForTests.TestUserModel;
    import API.DataForTests.Users_API;
    import API.RulesManagementService.Users.ViewUserList.ViewUserListResponse;
    import Categories_CDSRisk.CDS_Risk_UI;
    import Categories_CDSRisk.CDS_Risk_UI_Navigation;
    import Categories_CDSRisk.ChangeRequest;
    import TestCases.UI.BaseUIWebDriverTestCase;
    import UI.CommonComponents.PaginationToolBar;
    import UI.Pages.UserManagement.ListUsers_Page;
    import UI.Utils.Navigation;
    import org.junit.Before;
    import org.junit.Test;
    import org.junit.experimental.categories.Category;

    import java.util.List;

    import static FunctionsLibrary.Utils.SleepForMilliSeconds;
    import static org.junit.Assert.assertEquals;

    @Category({CDS_Risk_UI.class, CDS_Risk_UI_Navigation.class})
    public class TestCase_Pagination_Users extends BaseUIWebDriverTestCase {

        private PaginationInfo paginationInfo;
        public TestUserModel.UserDetails userDetailsSuperAdmin;

        @Before
        public void LocalSetup(){

            userDetailsSuperAdmin = Users_API.DefaultSuperAdminUser();
            API.RulesManagementService.Utils.Users.LoginAsUser(userDetailsSuperAdmin.pid);

            //Create 5 Users
            TestUserModel.UserDetails userDetails1 = Users_API.AdminNational();
            API.RulesManagementService.Utils.Users.CreateNewUser(userDetails1);

            TestUserModel.UserDetails userDetails2 = Users_API.AdminLocal_POO();
            API.RulesManagementService.Utils.Users.CreateNewUser(userDetails2);

            TestUserModel.UserDetails userDetails3 = Users_API.SuperAdminNational("1234562");
            API.RulesManagementService.Utils.Users.CreateNewUser(userDetails3);

            TestUserModel.UserDetails userDetails4 = Users_API.SuperAdminLocal_POO();
            API.RulesManagementService.Utils.Users.CreateNewUser(userDetails4);

            TestUserModel.UserDetails userDetails5 = Users_API.AdminLocal_POO_EXT();
            API.RulesManagementService.Utils.Users.CreateNewUser(userDetails5);


            paginationInfo = new PaginationInfo();

            ViewUserListResponse.ViewUserListResponseObject  viewUserListROStart = API.RulesManagementService.Utils.Users.GetListOfUsers();
            paginationInfo.iElementsAtStart = viewUserListROStart.totalElements;

            paginationInfo.iPagesAtStart = viewUserListROStart.totalPages;
        }


        @Category(ChangeRequest.CR_2430.class)
        @Test
        public void WhenListAllUsersPageSizeIsSetTo5_PaginationInfoResetCorrectly()
        {
            //Act
            paginationInfo.iSizeOfPage= 5;
            paginationInfo.iElementsAdded = 0;
            paginationInfo = paginationInfo.calculatePaginationInfo(paginationInfo);

            UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
            utilUsers.LoginToCDSRiskUIAsUser(userDetailsSuperAdmin);

            //Arrange
            Navigation utilNavigation = new Navigation(driver);
            ListUsers_Page listUsers_page =  utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);

            PaginationToolBar paginationToolBar = new PaginationToolBar(driver);

            paginationToolBar.selectPageSize(paginationInfo.iSizeOfPage);
            SleepForMilliSeconds(500);

            //Assert
            List<ListUsers_Page.UserListTableObject> listUsers = listUsers_page.getListOfUsers();

            assertEquals("Expect 5 users to be displayed", paginationInfo.iSizeOfPage, listUsers.size());

            String actPageSize = paginationToolBar.getPageSize();
            int iActPageSize = Integer.parseInt(actPageSize);

            assertEquals("Expect page size to be 5", paginationInfo.iSizeOfPage, iActPageSize);

            String actNoOfDataTablesMessage = paginationToolBar.totalPagesFoundText.getText();
            int actNoOfDataTables = Integer.parseInt(actNoOfDataTablesMessage.split(" ")[0]);
            assertEquals("Expect total users to be ", paginationInfo.iTotalElementsAtEnd, actNoOfDataTables);

            String actPageXofY = paginationToolBar.pageXofY.getText();
            assertEquals("Expect Page 1 of x", "Page 1 of " + paginationInfo.iCalcTotalPages, actPageXofY);

            boolean bNextPage = paginationToolBar.nextPage.isDisplayed();
            assertEquals("Expect Next page button to be displayed", true, bNextPage);

            boolean bLastPage = paginationToolBar.lastPage.isDisplayed();
            assertEquals("Expect Last page button to be displayed", true, bLastPage);

            boolean bPage1 = paginationToolBar.page1.isDisplayed();
            assertEquals("Expect Page 1 button to be displayed", true, bPage1);

            boolean bPage2 = paginationToolBar.page2.isDisplayed();
            assertEquals("Expect Page 2 button to be displayed", true, bPage2);
        }


        @Category(ChangeRequest.CR_2430.class)
        @Test
        public void WhenListAllUsersPageNavigationNextButtonClicked_CorrectPageDetailsDisplayed()
        {
            //Act
            paginationInfo.iSizeOfPage = 5;
            paginationInfo.iElementsAdded = 0;
            paginationInfo = paginationInfo.calculatePaginationInfo(paginationInfo);
            int expectedUsersOnSecondPage=2;

            UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
            utilUsers.LoginToCDSRiskUIAsUser(userDetailsSuperAdmin);

            //Arrange
            Navigation utilNavigation = new Navigation(driver);
            ListUsers_Page listUsers_page =  utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);

            PaginationToolBar paginationToolBar = new PaginationToolBar(driver);

            paginationToolBar.selectPageSize(paginationInfo.iSizeOfPage);
            SleepForMilliSeconds(500);
            paginationToolBar.nextPage.click();
            SleepForMilliSeconds(500);

            //Assert
            List<ListUsers_Page.UserListTableObject> listUsers = listUsers_page.getListOfUsers();

            if (paginationInfo.iCalcTotalPages == 2) { //i.e. last page
                assertEquals("Expect 2 of users on 2nd page to be displayed", paginationInfo.iCalcElementsOnLastPage, listUsers.size());
            }
            else {
                assertEquals("Expect " + expectedUsersOnSecondPage + " users on 2nd page to be displayed", expectedUsersOnSecondPage, listUsers.size());
            }


            String actPageSize = paginationToolBar.getPageSize();
            int iActPageSize = Integer.parseInt(actPageSize);

            assertEquals("Expect page size to be 5", paginationInfo.iSizeOfPage, iActPageSize);

            String actNoOfDataTablesMessage = paginationToolBar.totalPagesFoundText.getText();
            int actNoOfDataTables = Integer.parseInt(actNoOfDataTablesMessage.split(" ")[0]);
            assertEquals("Expect total users to be ", paginationInfo.iTotalElementsAtEnd, actNoOfDataTables);

            String actPageXofY = paginationToolBar.pageXofY.getText();
            assertEquals("Expect Page 2 of x", "Page 2 of " + paginationInfo.iCalcTotalPages, actPageXofY);

            boolean bPage1 = paginationToolBar.page1.isDisplayed();
            assertEquals("Expect Page 1 button to be displayed", true, bPage1);

            boolean bPrevious = paginationToolBar.previousPage.isDisplayed();
            assertEquals("Expect previous page button to be displayed", true, bPrevious);

            boolean bFirst = paginationToolBar.firstPage.isDisplayed();
            assertEquals("Expect first page button to be displayed", true, bFirst);
        }

    }