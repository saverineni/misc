package TestCases.RulesManagementService;


import API.RulesManagementService.Users.ViewUserList.ViewUserListResponse;
import Categories_CDSRisk.CDS_RM_UserManagement;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.stream.IntStream;

import static API.RulesManagementService.Utils.Users.GetListOfUsers;
import static API.RulesManagementService.Utils.Users.createAListOfUsers;

@Category({Rules_Management.class, CDS_RM_UserManagement.class})
public class TestCase_UserManagement_SortUsers extends BaseWebAPITestCase {

    @Before
    public void Setup() {
        //Arrange
        createAListOfUsers();
    }

    @Test
    @Category(ChangeRequest.CR_2247.class)
    public void WhenPIDIsSortedInDescendingOrder_PIDIsDisplayedInCorrectOrder() {

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers("pid", "DESC");

        //Assert
        Assertions.assertThat(
                isSordertingOrderCorrect(viewUserListResponseObject, "pid", "DESC")).isEqualTo(true);

    }

    @Test
    @Category(ChangeRequest.CR_2247.class)
    public void WhenNameIsSortedInDescendingOrder_NameIsDisplayedInCorrectOrder() {

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers("name", "DESC");

        //Assert
        Assertions.assertThat(
                isSordertingOrderCorrect(viewUserListResponseObject, "name", "DESC")).isEqualTo(true);

    }

    @Test
    @Category(ChangeRequest.CR_2247.class)
    public void WhenBaseLocationIsSortedInDescendingOrder_BaseLocationIsDisplayedInCorrectOrder() {

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers("base_location", "DESC");

        //Assert
        Assertions.assertThat(
                isSordertingOrderCorrect(viewUserListResponseObject, "base_location", "DESC")).isEqualTo(true);

    }

    @Test
    @Category(ChangeRequest.CR_2247.class)
    public void WhenCustomsJobTitleIsSortedInDescendingOrder_CustomsJobTitleIsDisplayedInCorrectOrder() {

         //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers("customs_job_title", "DESC");

        //Assert
        Assertions.assertThat(
                isSordertingOrderCorrect(viewUserListResponseObject, "customs_job_title", "DESC")).isEqualTo(true);

    }

    @Test
    @Category(ChangeRequest.CR_2247.class)
    public void WhenSuperAdminIsSortedInDescendingOrder_SuperAdminIsDisplayedInCorrectOrder() {

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers("super_admin", "DESC");

        //Assert
        Assertions.assertThat(
                isSordertingOrderCorrect(viewUserListResponseObject, "super_admin", "DESC")).isEqualTo(true);

    }


    @Test
    @Category(ChangeRequest.CR_2247.class)
    public void WhenAdminIsSortedInDescendingOrder_AdminIsDisplayedInCorrectOrder() {

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers("admin", "DESC");

        //Assert
        Assertions.assertThat(
                isSordertingOrderCorrect(viewUserListResponseObject, "admin", "DESC")).isEqualTo(true);

    }

    @Test
    @Category(ChangeRequest.CR_2247.class)
    public void WhenRuleManagerIsSortedInDescendingOrder_RuleManagerIsDisplayedInCorrectOrder() {

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers("rule_manager", "DESC");

        //Assert
        Assertions.assertThat(
                isSordertingOrderCorrect(viewUserListResponseObject, "rule_manager", "DESC")).isEqualTo(true);

    }

    @Test
    @Category(ChangeRequest.CR_2247.class)
    public void WhenStatusIsSortedInDescendingOrder_StatusIsDisplayedInCorrectOrder() {

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers("status", "DESC");

        //Assert
        Assertions.assertThat(
                isSordertingOrderCorrect(viewUserListResponseObject, "status", "DESC")).isEqualTo(true);

    }

    @Test
    @Category(ChangeRequest.CR_2247.class)
    public void WhenPIDIsSortedInAscendingOrder_PIDIsDisplayedInCorrectOrder() {

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers("pid", "ASC");

        //Assert
        Assertions.assertThat(
                isSordertingOrderCorrect(viewUserListResponseObject, "pid", "ASC")).isEqualTo(true);

    }

    @Test
    @Category(ChangeRequest.CR_2247.class)
    public void WhenNameIsSortedInAscendingOrder_NameIsDisplayedInCorrectOrder() {

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers("name", "ASC");

        //Assert
        Assertions.assertThat(
                isSordertingOrderCorrect(viewUserListResponseObject, "name", "ASC")).isEqualTo(true);

    }

    @Test
    @Category(ChangeRequest.CR_2247.class)
    public void WhenBaseLocationIsSortedInAscendingOrder_BaseLocationIsDisplayedInCorrectOrder() {

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers("base_location", "ASC");

        //Assert
        Assertions.assertThat(
                isSordertingOrderCorrect(viewUserListResponseObject, "base_location", "ASC")).isEqualTo(true);

    }

    @Test
    @Category(ChangeRequest.CR_2247.class)
    public void WhenCustomsJobTitleIsSortedInAscendingOrder_CustomsJobTitleIsDisplayedInCorrectOrder() {

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers("customs_job_title", "ASC");

        //Assert
        Assertions.assertThat(
                isSordertingOrderCorrect(viewUserListResponseObject, "customs_job_title", "ASC")).isEqualTo(true);

    }

    @Test
    @Category(ChangeRequest.CR_2247.class)
    public void WhenSuperAdminIsSortedInAscendingOrder_SuperAdminIsDisplayedInCorrectOrder() {

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers("super_admin", "ASC");

        //Assert
        Assertions.assertThat(
                isSordertingOrderCorrect(viewUserListResponseObject, "super_admin", "ASC")).isEqualTo(true);

    }


    @Test
    @Category(ChangeRequest.CR_2247.class)
    public void WhenAdminIsSortedInAscendingOrder_AdminIsDisplayedInCorrectOrder() {

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers("admin", "ASC");

        //Assert
        Assertions.assertThat(
                isSordertingOrderCorrect(viewUserListResponseObject, "admin", "ASC")).isEqualTo(true);

    }

    @Test
    @Category(ChangeRequest.CR_2247.class)
    public void WhenRuleManagerIsSortedInAscendingOrder_RuleManagerIsDisplayedInCorrectOrder() {

       //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers("rule_manager", "ASC");

        //Assert
        Assertions.assertThat(
                isSordertingOrderCorrect(viewUserListResponseObject, "rule_manager", "ASC")).isEqualTo(true);

    }

    @Test
    @Category(ChangeRequest.CR_2247.class)
    public void WhenStatusIsSortedInAscendingOrder_StatusIsDisplayedInCorrectOrder() {
        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = GetListOfUsers("status", "ASC");

        //Assert
        Assertions.assertThat(
                isSordertingOrderCorrect(viewUserListResponseObject, "status", "ASC")).isEqualTo(true);

    }


    private boolean isSordertingOrderCorrect(ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject, String property, String order) {

        if (property.equals("pid")) {
            return IntStream.range(0, viewUserListResponseObject.content.size() - 1)
                    .allMatch(i -> {
                        String pid1 = viewUserListResponseObject.content.get(i).pid;
                        String pid2 = viewUserListResponseObject.content.get(i + 1).pid;
                        boolean sortedOrder = order.equals("DESC") ? pid1.compareTo(pid2) >= 0 : pid1.compareTo(pid2) <= 0;
                        return sortedOrder;
                    });

        } else if (property.equals("name")) {
            return IntStream.range(0, viewUserListResponseObject.content.size() - 1)
                    .allMatch(i -> {
                        String pid1 = viewUserListResponseObject.content.get(i).firstName + " " + viewUserListResponseObject.content.get(i).lastName;
                        String pid2 = viewUserListResponseObject.content.get(i + 1).firstName + " " + viewUserListResponseObject.content.get(i + 1).lastName;
                        boolean sortedOrder = order.equals("DESC") ? pid1.compareTo(pid2) >= 0 : pid1.compareTo(pid2) <= 0;
                        return sortedOrder;
                    });

        } else if (property.equals("base_location")) {

            return IntStream.range(0, viewUserListResponseObject.content.size() - 1)
                    .allMatch(i -> {
                        String pid1 = viewUserListResponseObject.content.get(i).baseLocation.locationFullName;
                        String pid2 = viewUserListResponseObject.content.get(i + 1).baseLocation.locationFullName;
                        boolean sortedOrder = order.equals("DESC") ? pid1.compareTo(pid2) >= 0 : pid1.compareTo(pid2) <= 0;
                        return sortedOrder;
                    });

        } else if (property.equals("customs_job_title")) {

            return IntStream.range(0, viewUserListResponseObject.content.size() - 1)
                    .allMatch(i -> {
                        String pid1 = viewUserListResponseObject.content.get(i).jobTitle;
                        String pid2 = viewUserListResponseObject.content.get(i + 1).jobTitle;
                        boolean sortedOrder = order.equals("DESC") ? pid1.compareTo(pid2) >= 0 : pid1.compareTo(pid2) <= 0;
                        return sortedOrder;

                    });

        } else if (property.equals("super_admin")) {
            return IntStream.range(0, viewUserListResponseObject.content.size() - 1)
                    .allMatch(i -> {
                        String pid1 = String.valueOf(viewUserListResponseObject.content.get(i).superAdmin);
                        String pid2 = String.valueOf(viewUserListResponseObject.content.get(i + 1).superAdmin);
                        boolean sortedOrder = order.equals("DESC") ? pid1.compareTo(pid2) >= 0 : pid1.compareTo(pid2) <= 0;

                        return sortedOrder;
                    });

        } else if (property.equals("admin")) {
            return IntStream.range(0, viewUserListResponseObject.content.size() - 1)
                    .allMatch(i -> {
                        String pid1 = String.valueOf(viewUserListResponseObject.content.get(i).admin);
                        String pid2 = String.valueOf(viewUserListResponseObject.content.get(i + 1).admin);
                        boolean sortedOrder = order.equals("DESC") ? pid1.compareTo(pid2) >= 0 : pid1.compareTo(pid2) <= 0;

                        return sortedOrder;
                    });
        } else if (property.equals("rule_manager")) {
            return IntStream.range(0, viewUserListResponseObject.content.size() - 1)
                    .allMatch(i -> {
                        String pid1 = String.valueOf(viewUserListResponseObject.content.get(i).ruleManager);
                        String pid2 = String.valueOf(viewUserListResponseObject.content.get(i + 1).ruleManager);
                        boolean sortedOrder = order.equals("DESC") ? pid1.compareTo(pid2) >= 0 : pid1.compareTo(pid2) <= 0;

                        return sortedOrder;
                    });
        }
        else if (property.equals("status")) {
            return IntStream.range(0, viewUserListResponseObject.content.size() - 1)
                    .allMatch(i -> {
                        String pid1 = String.valueOf(viewUserListResponseObject.content.get(i).status);
                        String pid2 = String.valueOf(viewUserListResponseObject.content.get(i + 1).status);
                        boolean sortedOrder = order.equals("DESC") ? pid1.compareTo(pid2) >= 0 : pid1.compareTo(pid2) <= 0;

                        return sortedOrder;
                    });
        }
        return false;
    }

}
