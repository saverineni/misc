package TestCases.RulesManagementService;


import API.DataForTests.TestEnumerators;
import API.DataForTests.TestRuleModel;
import API.RulesManagementService.AmendRule.AmendRuleResponse;
import API.RulesManagementService.Utils.RuleAtStatus;
import API.RulesManagementService.ViewRule.ViewRuleResponse;
import API.RulesManagementService.ViewRuleVersion.ViewRuleVersionResponse;
import Categories_CDSRisk.CDS_RM_RuleLifeCycle;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import FunctionsLibrary.DateTime;
import TestCases.BaseWebAPITestCase;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static API.RulesManagementService.Utils.RuleAtStatus.CreatePendingExpiredRuleVersion;
import static org.junit.Assert.assertEquals;

@Slf4j
@Category({Rules_Management.class, CDS_RM_RuleLifeCycle.class})
public class TestCase_AmendPendingRule extends BaseWebAPITestCase {

    @Test
    @Category(ChangeRequest.CR_1966.class)
    public void WhenPendingRuleAmendedWithEarlierDateAndPublished_NewPendingVersionCreatedOriginalVersionCancelled() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = RuleAtStatus.CreatePendingExpiredRuleVersion(1, 2);
        publishAndWait(5000);

        //Act
        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        ruleDetailsV2.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXMinutes(+10, DateTime.DateTimeUTCZ);
        ruleDetailsV2.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXMinutes(+30, DateTime.DateTimeUTCZ);
        ruleDetailsV2.uniqueID = ruleDetails.uniqueID;
        ruleDetailsV2.version = 1;
        AmendRuleResponse.PostResponse amendResponse = API.RulesManagementService.Utils.Rules.AmendRuleAndGetResponseObject(ruleDetailsV2);

        publishAndWait(5000);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject ruleVersion1Response =
                API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(ruleDetails.uniqueID, 1);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject ruleVersion2Response =
                API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(ruleDetails.uniqueID, 2);

        //Assert
        assertEquals(HttpStatus.SC_OK, amendResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.cancelled.toString(), ruleVersion1Response.status);
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), ruleVersion2Response.status);
    }


    @Test
    @Category({ChangeRequest.CR_1966.class,ChangeRequest.CR_3100.class})
    public void WhenPendingRuleAmendedWithFutureDateAndPublished_NewPendingVersionCreatedOriginalVersionCancelled() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = RuleAtStatus.CreatePendingExpiredRuleVersion(1, 2);
        publishAndWait(5000);

        //Act
        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        ruleDetailsV2.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(3, DateTime.DateTimeUTCZ);
        ruleDetailsV2.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXMinutes(4, DateTime.DateTimeUTCZ);
        ruleDetailsV2.uniqueID = ruleDetails.uniqueID;
        ruleDetailsV2.version = 1;
        AmendRuleResponse.PostResponse amendResponse = API.RulesManagementService.Utils.Rules.AmendRuleAndGetResponseObject(ruleDetailsV2);

        publishAndWait(5000);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject ruleVersion1Response =
                API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(ruleDetails.uniqueID, 1);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject ruleVersion2Response =
                API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(ruleDetails.uniqueID, 2);

        ViewRuleResponse.ViewRuleResponseObject ruleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(amendResponse.uniqueId);


        //Assert
        assertEquals(HttpStatus.SC_OK, amendResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.cancelled.toString(), ruleVersion1Response.status);
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), ruleVersion2Response.status);

        //Assert for upcoming chnages
        assertEquals(2, ruleResponse.upcoming.get(0).versionId);
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), ruleResponse.upcoming.get(0).status);
    }


    @Test
    @Category(ChangeRequest.CR_1966.class)
    public void WhenPendingRuleAmendedWithShorterDateAndPublished_NewPendingVersionCreatedOriginalVersionCancelled() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = RuleAtStatus.CreatePendingExpiredRuleVersion(1, 4);
        publishAndWait(5000);

        //Act
        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        ruleDetailsV2.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(2, DateTime.DateTimeUTCZ);
        ruleDetailsV2.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXMinutes(3, DateTime.DateTimeUTCZ);
        ruleDetailsV2.uniqueID = ruleDetails.uniqueID;
        ruleDetailsV2.version = 1;
        AmendRuleResponse.PostResponse amendResponse = API.RulesManagementService.Utils.Rules.AmendRuleAndGetResponseObject(ruleDetailsV2);

        publishAndWait(5000);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject ruleVersion1Response =
                API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(ruleDetails.uniqueID, 1);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject ruleVersion2Response =
                API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(ruleDetails.uniqueID, 2);

        //Assert
        assertEquals(HttpStatus.SC_OK, amendResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.cancelled.toString(), ruleVersion1Response.status);
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), ruleVersion2Response.status);
    }

    @Test
    @Category(ChangeRequest.CR_1966.class)
    public void WhenPendingRuleAmended_NewDetailsSavedCorrectly() throws Throwable
    {
        //Arrange
        TestRuleModel.RuleDetails ruleDetails = RuleAtStatus.CreatePendingExpiredRuleVersion(1, 2);
        publishAndWait(5000);

        //Act
        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        ruleDetailsV2.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(3, DateTime.DateTimeUTCZ);
        ruleDetailsV2.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXMinutes(4, DateTime.DateTimeUTCZ);
        ruleDetailsV2.uniqueID = ruleDetails.uniqueID;
        ruleDetailsV2.ruleId = ruleDetails.ruleId;

        ruleDetailsV2.version = 1; //when amending rule need to be v1
        API.RulesManagementService.AmendRule.AmendRuleResponse.PostResponse amendRuleResponse = API.RulesManagementService.Utils.Rules.AmendRuleAndGetResponseObject(ruleDetailsV2);

        //Assert
        ruleDetailsV2.version = 2; ////when checking amended rule need to be v2
        ruleDetailsV2.status = TestEnumerators.RuleStatus.committed.toString();
        AmendRuleResponse.AssertAmendRuleResponse(ruleDetailsV2, amendRuleResponse);
    }


    @Test
    @Category({ChangeRequest.CR_1966.class, ChangeRequest.CRX_193.class})
    public void GivenMultiplePendingRules_WhenPendingRuleIsAmendedWithShorterDateAndPublished_OriginalVersionsCancelledAndNewPendingVersionsCreatedWithDatesUpdated() throws Throwable
    {
        //Arrange
        //rule starting in 1 days time
        TestRuleModel.RuleDetails ruleDetailsV1 = CreatePendingExpiredRuleVersion(1, 3);

        //rule starting in 4 days time
        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsV2.uniqueID = ruleDetailsV1.uniqueID;
        ruleDetailsV2.description = "rule3DaysTime";
        ruleDetailsV2.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(4, DateTime.DateTimeUTCZ);
        ruleDetailsV2.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(6, DateTime.DateTimeUTCZ);
        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetailsV2, 2);

        //rule starting in 7 days time
        TestRuleModel.RuleDetails ruleDetailsV3 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsV3.uniqueID = ruleDetailsV1.uniqueID;
        ruleDetailsV3.description = "rule5MinsTime";
        ruleDetailsV3.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(7, DateTime.DateTimeUTCZ);
        ruleDetailsV3.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(10, DateTime.DateTimeUTCZ);
        RuleAtStatus.CreateNewDraftRuleVersionAndCommit(ruleDetailsV3, 3);

        publishAndWait(5000);

        //Act
        //Amend V2 to start in 2 days time and end in 8 days time, so it will overlap v1 and v3
        TestRuleModel.RuleDetails ruleDetailsV4 = API.DataForTests.Rules.DraftNatRuleNatManager();
        ruleDetailsV4.uniqueID = ruleDetailsV1.uniqueID;
        ruleDetailsV4.description = "rule2Amended";
        ruleDetailsV4.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(2, DateTime.DateTimeUTCZ);
        ruleDetailsV4.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(8, DateTime.DateTimeUTCZ);

        ruleDetailsV4.version = 2;
        AmendRuleResponse.PostResponse amendResponse = API.RulesManagementService.Utils.Rules.AmendRuleAndGetResponseObject(ruleDetailsV4);

        publishAndWait(5000);

        ViewRuleResponse.ViewRuleResponseObject ruleResponse = API.RulesManagementService.Utils.Rules.GetRuleByUID(ruleDetailsV1.uniqueID);

        //Expect:
        // V1 to be cancelled and cloned into a new version with end date adjusted to ruleDetailsV4.startDateTime
        // V2 to be cancelled
        // V3 to be cancelled and cloned into a new version with start date adjusted to ruleDetailsV4.endDateTime
        // V4 to be created

        //Assert
        ViewRuleResponse.Versions version1 = ruleResponse.versions.stream().filter(v -> v.versionId == 1).findFirst().get();
        ViewRuleResponse.Versions version2 = ruleResponse.versions.stream().filter(v -> v.versionId == 2).findFirst().get();
        ViewRuleResponse.Versions version3 = ruleResponse.versions.stream().filter(v -> v.versionId == 3).findFirst().get();

        assertEquals(TestEnumerators.RuleStatus.cancelled.toString(), version1.status);
        assertEquals(TestEnumerators.RuleStatus.cancelled.toString(), version2.status);
        assertEquals(TestEnumerators.RuleStatus.cancelled.toString(), version3.status);

        ViewRuleResponse.Versions version1Clone = ruleResponse.versions.stream().filter(v ->
                v.versionId != 1
                && v.description.equals(ruleDetailsV1.description)
            ).findFirst().get();
        ViewRuleResponse.Versions amendedVersion2 = ruleResponse.versions.stream().filter(v ->
                v.versionId != 2
                && v.description.equals(ruleDetailsV4.description)
            ).findFirst().get();
        ViewRuleResponse.Versions version3Clone = ruleResponse.versions.stream().filter(v ->
                v.versionId != 3
                && v.description.equals(ruleDetailsV3.description)
            ).findFirst().get();

        assertEquals(TestEnumerators.RuleStatus.pending.toString(), version1Clone.status);
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), amendedVersion2.status);
        assertEquals(TestEnumerators.RuleStatus.pending.toString(), version3Clone.status);

        log.debug("v1 clone start date expected:" + ruleDetailsV1.startDateTime + " actual: " + version1Clone.startDateTime);
        log.debug("v1 clone end date expected:" + ruleDetailsV4.startDateTime + " actual: " + version1Clone.endDateTime);

        log.debug("v3 clone start date expected:" + ruleDetailsV4.startDateTime + " actual: " + version3Clone.startDateTime);
        log.debug("v3 clone end date expected:" + ruleDetailsV3.endDateTime + " actual: " + version3Clone.endDateTime);

        log.debug("v4 start date expected:" + ruleDetailsV4.startDateTime + " actual: " + amendedVersion2.startDateTime);
        log.debug("v4 end date expected:" + ruleDetailsV4.endDateTime + " actual: " + amendedVersion2.endDateTime);

        assertEquals("v1 clone start date expected:", ruleDetailsV1.startDateTime.substring(0,10), version1Clone.startDateTime.substring(0,10));
        assertEquals("v1 clone end date expected:", ruleDetailsV4.startDateTime.substring(0,10), version1Clone.endDateTime.substring(0,10));

        assertEquals("v3 clone start date expected:", ruleDetailsV4.endDateTime.substring(0,10), version3Clone.startDateTime.substring(0,10));
        assertEquals("v3 clone end date expected:", ruleDetailsV3.endDateTime.substring(0,10), version3Clone.endDateTime.substring(0,10));

        assertEquals("v4 start date expected:", ruleDetailsV4.startDateTime.substring(0,10), amendedVersion2.startDateTime.substring(0,10));
        assertEquals("v4 end date expected:", ruleDetailsV4.endDateTime.substring(0,10), amendedVersion2.endDateTime.substring(0,10));
    }


    @Test
    @Category(ChangeRequest.CR_2763.class)
    public void WhenPendingRuleAmendedWithStartDateNowAndPublished_NewActiveVersionCreatedOriginalVersionCancelled() throws Throwable
    {

        //Arrange
        TestRuleModel.RuleDetails ruleDetails = RuleAtStatus.CreatePendingExpiredRuleVersion(2, 10);
        publishAndWait(5000);

        //Act
        TestRuleModel.RuleDetails ruleDetailsV2 = API.DataForTests.Rules.DraftVersion2NatRuleNatManager();
        ruleDetailsV2.startDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXMinutes(-90, DateTime.DateTimeUTCZ);
        ruleDetailsV2.endDateTime = FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(2, DateTime.DateTimeUTCZ);
        ruleDetailsV2.uniqueID = ruleDetails.uniqueID;
        ruleDetailsV2.version = 1;
        AmendRuleResponse.PostResponse amendResponse = API.RulesManagementService.Utils.Rules.AmendRuleAndGetResponseObject(ruleDetailsV2);

        publishAndWait(5000);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject ruleVersion1Response =
                API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(ruleDetails.uniqueID, 1);

        ViewRuleVersionResponse.ViewRuleVersionResponseObject ruleVersion2Response =
                API.RulesManagementService.Utils.Rules.GetRuleDByUIDAndVersion(ruleDetails.uniqueID, 2);

        //Assert
        assertEquals(HttpStatus.SC_OK, amendResponse.httpStatusCode);
        assertEquals(TestEnumerators.RuleStatus.cancelled.toString(), ruleVersion1Response.status);
        assertEquals(TestEnumerators.RuleStatus.active.toString(), ruleVersion2Response.status);
    }

}
