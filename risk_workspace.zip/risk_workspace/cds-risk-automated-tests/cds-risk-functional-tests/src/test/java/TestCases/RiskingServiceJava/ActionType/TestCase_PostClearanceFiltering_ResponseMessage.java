package TestCases.RiskingServiceJava.ActionType;

import Categories_CDSRisk.ChangeRequest_RiskingService;
import Categories_CDSRisk.ChangeRequest_RiskingService.CREP_255;
import Categories_CDSRisk.Risking_JavaService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel;

@Slf4j
@Category({CREP_255.class, ChangeRequest_RiskingService.CREP_290.class, Risking_JavaService.class})
public class TestCase_PostClearanceFiltering_ResponseMessage extends BaseActionTypeTest {

    @Test
    public void WhenPostClearanceAndDocumentCheckAreSet_ThenResponseContainsCtlTypes1AndBlockingReleaseIsFalse() {

        //When
        CreateRuleModel.RuleOutputs outputs = CreateRuleModel.RuleOutputs.builder()
                .actionType("4")
                .holdNarrative(HOLD_NARRATIVE)
                .holdPercentage(0)
                .releaseNarrative(RELEASE_NARRATIVE)
                .releasePercentage(100)
                .assigneeId(ASSIGNEE_ID)
                .build();

        //Then
        createRule(outputs);
        DeclarationResponse response = sendDeclaration(createDeclaration(), false);

        //Assert
        assertDeclarationResponse(response, expectedDocCheckRelease());
    }
}
