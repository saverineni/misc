package TestCases.RulesManagementService;


import API.DataForTests.DataTables;
import API.DataForTests.TestDataTableModel;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import API.RulesManagementService.Data.CreateDataTable.CreateDataTableResponse;
import API.RulesManagementService.Data.ViewDataTable.ViewDataTableResponse;
import API.RulesManagementService.Data.ViewDataTableHistory.ViewDataTableHistoryResponse.ViewDTHistoryResponseObject;
import Categories_CDSRisk.CDS_RM_DataTable;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.WebAPITestCaseWithDatatablesCleanup;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.httpclient.HttpStatus;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.time.ZoneId;
import java.time.ZonedDateTime;

import static API.RulesManagementService.Utils.DataTables.*;
import static org.junit.Assert.assertEquals;

@Slf4j
@Category({Rules_Management.class, CDS_RM_DataTable.class})
public class TestCase_DataTable_History extends WebAPITestCaseWithDatatablesCleanup {

    @Test
    @Category(ChangeRequest.CR_2004.class)
    public void WhenDataTableCreated_EventAppearsInDataTableHistory() {

        //Arrange
        TestUserModel.UserDetails udNatRulesManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uniqueId = createDataTableResponse.uniqueId;

        //Act
        ViewDTHistoryResponseObject viewDTHistoryResponseObject = GetListOfDataTableHistory(createDataTableResponse.uuid);

        //Assert
        assertEquals("HTTP Status Code: ", HttpStatus.SC_OK, viewDTHistoryResponseObject.httpStatusCode);

        assertEquals("Expected Events: 1", 1, viewDTHistoryResponseObject.viewDTHistoryList.size());
        assertEquals(tableDetails.uniqueId, viewDTHistoryResponseObject.viewDTHistoryList.get(0).uniqueId);
        assertEquals(tableDetails.userPid, viewDTHistoryResponseObject.viewDTHistoryList.get(0).updaterPid);
        assertEquals(udNatRulesManager.getFullName(), viewDTHistoryResponseObject.viewDTHistoryList.get(0).updaterName);

        ZonedDateTime expDateTime = ZonedDateTime.now(ZoneId.of("UTC")).plusMinutes(-2);
        ZonedDateTime actDateTime =  ZonedDateTime.parse(viewDTHistoryResponseObject.viewDTHistoryList.get(0).updatedTimestamp);
        Assertions.assertThat(actDateTime.isAfter(expDateTime));
    }


    @Test
    @Category(ChangeRequest.CR_2004.class)
    public void WhenDataAddedToDataTableByDifferentUser_CorrectEventsAppearInDataTableHistory() {

        //Arrange
        TestUserModel.UserDetails udNatRulesManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_NoData();

        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;
        tableDetails.uniqueId = createDataTableResponse.uniqueId;

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        //Act
        TestUserModel.UserDetails udNatRulesManager2 = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(udNatRulesManager2);
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRulesManager2.pid);

        tableDetails.dataItemsToAdd.add("1000000000");
        tableDetails.dataItemsToAdd.add("2000000000");
        tableDetails.dataItems.addAll(tableDetails.dataItemsToAdd);

        EditDataTableAndGetResponseObject(tableDetails);
        ViewDTHistoryResponseObject viewDTHistoryResponseObject = GetListOfDataTableHistory(createDataTableResponse.uuid);

        //Assert
        assertEquals("Expected Events: 2", 2, viewDTHistoryResponseObject.viewDTHistoryList.size());

        assertEquals("Expected version 2", 2, viewDTHistoryResponseObject.viewDTHistoryList.get(0).version);

        //Only if we cannot modify table name
        assertEquals(tableDetails.uniqueId, viewDTHistoryResponseObject.viewDTHistoryList.get(0).uniqueId);
        assertEquals(udNatRulesManager2.pid, viewDTHistoryResponseObject.viewDTHistoryList.get(0).updaterPid);
        assertEquals(udNatRulesManager2.getFullName(), viewDTHistoryResponseObject.viewDTHistoryList.get(0).updaterName);


        assertEquals("Expected version 1", 1, viewDTHistoryResponseObject.viewDTHistoryList.get(1).version);
        assertEquals(tableDetails.uniqueId, viewDTHistoryResponseObject.viewDTHistoryList.get(1).uniqueId);
        assertEquals(udNatRulesManager.pid, viewDTHistoryResponseObject.viewDTHistoryList.get(1).updaterPid);
        assertEquals(udNatRulesManager.getFullName(), viewDTHistoryResponseObject.viewDTHistoryList.get(1).updaterName);
        //Check date too??
    }


    @Test
    @Category(ChangeRequest.CR_2004.class)
    public void WhenDataRemovedFromDataTableByDifferentUser_CorrectEventsAppearInDataTableHistory() {

        //Arrange
        TestUserModel.UserDetails udNatRulesManager = Users_API.NationalRulesManagerDefaultTestAutomationUser();
        TestDataTableModel.TableDetails tableDetails = DataTables.DataTable_CommodityCodes_NAT();

        CreateDataTableResponse.PostResponse createDataTableResponse = CreateDataTableAndGetResponseObject(tableDetails);
        tableDetails.uuid = createDataTableResponse.uuid;
        tableDetails.uniqueId = createDataTableResponse.uniqueId;

        ViewDataTableResponse.ViewDataTableResponseObject responseDetail = GetDataTableDetailsByUID(createDataTableResponse.uuid);
        tableDetails.opLockVersion = responseDetail.opLockVersion;

        tableDetails.dataItemsToAdd.add("1000000000");
        tableDetails.dataItemsToAdd.add("2000000000");
        tableDetails.dataItems.addAll(tableDetails.dataItemsToAdd);

        EditDataTableAndGetResponseObject(tableDetails);

        ViewDataTableResponse.ViewDataTableResponseObject viewDataTableResponseObject = GetDataTableDetailsByUID(tableDetails.uuid);
        tableDetails.opLockVersion = viewDataTableResponseObject.opLockVersion;

        //Act
        TestUserModel.UserDetails udNatRulesManager2 = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(udNatRulesManager2);
        API.RulesManagementService.Utils.Users.LoginAsUser(udNatRulesManager2.pid);

        //Add no new items but remove 1st item in list
        tableDetails.dataItemsToAdd.clear();
        tableDetails.dataItemsToRemove.add(tableDetails.dataItems.get(0));
        String removedDataItem = tableDetails.dataItems.get(0);
        tableDetails.dataItems.remove(0);

        EditDataTableAndGetResponseObject(tableDetails);
        ViewDTHistoryResponseObject viewDTHistoryResponseObject = GetListOfDataTableHistory(createDataTableResponse.uuid);

        //Assert
        assertEquals("Expected Events: 3", 3, viewDTHistoryResponseObject.viewDTHistoryList.size());

        assertEquals("Expected version 3", 3, viewDTHistoryResponseObject.viewDTHistoryList.get(0).version);
        assertEquals(tableDetails.uniqueId, viewDTHistoryResponseObject.viewDTHistoryList.get(0).uniqueId);
        assertEquals(udNatRulesManager2.pid, viewDTHistoryResponseObject.viewDTHistoryList.get(0).updaterPid);
        assertEquals(udNatRulesManager2.getFullName(), viewDTHistoryResponseObject.viewDTHistoryList.get(0).updaterName);


        assertEquals("Expected version 2", 2, viewDTHistoryResponseObject.viewDTHistoryList.get(1).version);
        assertEquals(tableDetails.uniqueId, viewDTHistoryResponseObject.viewDTHistoryList.get(1).uniqueId);
        assertEquals(udNatRulesManager.pid, viewDTHistoryResponseObject.viewDTHistoryList.get(1).updaterPid);
        assertEquals(udNatRulesManager.getFullName(), viewDTHistoryResponseObject.viewDTHistoryList.get(1).updaterName);

        assertEquals("Expected version 1", 1, viewDTHistoryResponseObject.viewDTHistoryList.get(2).version);
        assertEquals(tableDetails.uniqueId, viewDTHistoryResponseObject.viewDTHistoryList.get(2).uniqueId);
        assertEquals(udNatRulesManager.pid, viewDTHistoryResponseObject.viewDTHistoryList.get(2).updaterPid);
        assertEquals(udNatRulesManager.getFullName(), viewDTHistoryResponseObject.viewDTHistoryList.get(2).updaterName);
    }


}
