package TestCases.UI.Users;

import API.DataForTests.TestEnumerators;
import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Users;
import Categories_CDSRisk.CDS_Risk_UI_Users_2;
import Categories_CDSRisk.ChangeRequest;
import FunctionsLibrary.Utils;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.Pages.UserManagement.ListUsersByLocation_Page;
import UI.Pages.UserManagement.ListUsers_Page;
import UI.Pages.UserManagement.UserDetails_Page;
import UI.Utils.Navigation;
import org.assertj.core.api.Assertions;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import java.util.List;
import static API.RulesManagementService.Utils.Users.UpdateStatusOfUser;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Users.class, CDS_Risk_UI_Users_2.class})
public class TestCase_ListUsers extends BaseUIWebDriverTestCase {

    @Test
    public void WhenAdminLoggedIn_ListOfUsersPopulatedWithCorrectDetails(){

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetailsPOO);

        //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsAdmin);

        Navigation utilNavigation = new Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);

        //Assert
        List<ListUsers_Page.UserListTableObject> userListTableObjects = listUsers_page.getListOfUsers();

        int iUsers = userListTableObjects.size();
        assertTrue("Expect 3 or more users to be present", iUsers >= 3);

        ListUsers_Page.UserListTableObject userListTableObject = listUsers_page.getUserTableObjectFromUserListTableObject(userListTableObjects, UserDetailsPOO.pid);

        assertEquals(UserDetailsPOO.pid, userListTableObject.pid);
        assertEquals(UserDetailsPOO.firstname + " " + UserDetailsPOO.lastname, userListTableObject.name);
        assertEquals(UserDetailsPOO.baseLocationFullName, userListTableObject.baseLocation);
        assertEquals(UserDetailsPOO.jobTitle, userListTableObject.customsJobTitle);
        assertEquals(false, userListTableObject.superAdmin);
        assertEquals(false, userListTableObject.admin);
        assertEquals(true, userListTableObject.ruleManager);
        assertEquals("Inactive", userListTableObject.status);
    }


    @Test
    public void WhenAdminLoggedIn_CanViewExistingUserDetails(){

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetailsPOO);

        //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsAdmin);

        Navigation utilNavigation = new Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);

        List<ListUsers_Page.UserListTableObject> userListTableObjects = listUsers_page.getListOfUsers();
        ListUsers_Page.UserListTableObject userListTableObject = listUsers_page.getUserTableObjectFromUserListTableObject(userListTableObjects, UserDetailsPOO.pid);

        userListTableObject.pidElement.click();

        //Assert
        UserDetailsPOO.status="Inactive";
        UserDetails_Page userDetails_page = new UserDetails_Page(driver);
        userDetails_page.assertUserDetails(UserDetailsPOO);
    }


    @Category({ChangeRequest.CR_1909.class, ChangeRequest.CR_2436.class})
    @Test
    public void WhenNationalAdminLoggedIn_ListOfUserByLocationFilteredByNationalByDefault(){

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetailsPOO);

        //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(Users_API.DefaultSuperAdminUser());

        Navigation utilNavigation = new Navigation(driver);
        ListUsersByLocation_Page listUsersByLocation_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsersByLocation);

        List<String> actCustomLocations = listUsersByLocation_page.customsLocation.getListOfItems();

        actCustomLocations = Utils.trimWhiteSpaceFromList(actCustomLocations);

        //Assert
        Assertions.assertThat(actCustomLocations)
                .contains("National Office")
                .doesNotContain("All Locations");

        assertEquals("National Office", listUsersByLocation_page.locationName.getText().trim());
        assertEquals("none", listUsersByLocation_page.locationType.getText().trim());

        List<ListUsersByLocation_Page.UserListTableObject> userListTableObjects = listUsersByLocation_page.getListOfUsers();

        int iUsers = userListTableObjects.size();
        assertTrue("Expect 1 or more users to be present", iUsers >= 1);

        ListUsersByLocation_Page.UserListTableObject userListTableObject = listUsersByLocation_page.getUserTableObjectFromUserListTableObject(userListTableObjects, userDetailsAdmin.getFullName());

        assertEquals("Admin", userListTableObject.role);
        assertEquals(userDetailsAdmin.firstname + " " + userDetailsAdmin.lastname, userListTableObject.name);
        assertEquals(userDetailsAdmin.baseLocation, userListTableObject.baseLocation);
        assertEquals(userDetailsAdmin.jobTitle, userListTableObject.customsJobTitle);
        assertEquals("No. of locations", 1, userListTableObject.locations);
        assertEquals("Inactive", userListTableObject.status);
    }

    @Category({ChangeRequest.CR_1909.class, ChangeRequest.CR_2436.class})
    @Test @Ignore("John is fixing the HTML text to return plain text - once that is done this can be un-ignored")
    public void WhenLocalSuperAdminLoggedIn_ListOfUserByLocationFilteredByUsersBaseLocationByDefault(){

        //Arrange
        TestUserModel.UserDetails userDetailsSuperAdmin = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsSuperAdmin);

        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetailsPOO);

        //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(Users_API.SuperAdminLocal_POO());

        Navigation utilNavigation = new Navigation(driver);
        ListUsersByLocation_Page listUsersByLocation_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsersByLocation);

          //Assert
        assertEquals("POO - Poole", listUsersByLocation_page.customsLocation.getSelectedItem().trim());
        assertEquals("Poole", listUsersByLocation_page.locationName.getText().trim());
        assertEquals("maritime", listUsersByLocation_page.locationType.getText().trim());

        List<ListUsersByLocation_Page.UserListTableObject> userListTableObjects = listUsersByLocation_page.getListOfUsers();

        int iUsers = userListTableObjects.size();
        assertTrue("Expect 2 or more users to be present", iUsers >= 2);

        ListUsersByLocation_Page.UserListTableObject userListTableObject = listUsersByLocation_page.getUserTableObjectFromUserListTableObject(userListTableObjects, userDetailsSuperAdmin.getFullName());

        assertEquals("LocalSuperAdmin", userListTableObject.role);
        assertEquals(userDetailsSuperAdmin.firstname + " " + userDetailsSuperAdmin.lastname, userListTableObject.name);
        assertEquals(userDetailsSuperAdmin.baseLocation, userListTableObject.baseLocation);
        assertEquals(userDetailsSuperAdmin.jobTitle, userListTableObject.customsJobTitle);
        assertEquals("No. of locations", 1, userListTableObject.locations);
        assertEquals("ACTIVE", userListTableObject.status);
    }


    @Category(ChangeRequest.CR_1909.class)
    @Test
    public void WhenUserFiltersByBaseLocations_ListOfUserByLocationFilteredBySelectedLocation(){

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetailsPOO);

        //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(Users_API.DefaultSuperAdminUser());

        Navigation utilNavigation = new Navigation(driver);
        ListUsersByLocation_Page listUsersByLocation_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsersByLocation);

        listUsersByLocation_page.customsLocation.select("POO - Poole");
        List<ListUsersByLocation_Page.UserListTableObject> userListTableObjects = listUsersByLocation_page.getListOfUsers();

        //Assert
        assertTrue("Expect 1 or more users to be present", userListTableObjects.size() >= 1);

        listUsersByLocation_page.customsLocation.select("BEL - Belfast");
        String actMessage = listUsersByLocation_page.noResults.getText();

        assertEquals("No users found", actMessage);
    }


    @Category({ChangeRequest.CR_2436.class})
    @Test
    public void WhenLocationFilteredByLocationWithMultiplePorts_AllPortsDisplayed(){

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsAdmin);

        Navigation utilNavigation = new Navigation(driver);
        ListUsersByLocation_Page listUsersByLocation_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsersByLocation);

        listUsersByLocation_page.customsLocation.select("WAT - Watchet");

        //Assert
        assertEquals("Watchet", listUsersByLocation_page.locationName.getText().trim());
        assertEquals("maritime", listUsersByLocation_page.locationType.getText().trim());
        assertEquals("Bridgwater, Bideford, Appledore", listUsersByLocation_page.ports.getText().trim());
    }


    @Category({ChangeRequest.CR_2436.class})
    @Test
    public void WhenLocationFilteredByLocationWithAirport_AirPortDisplayed(){

        //Arrange
        TestUserModel.UserDetails userDetailsAdmin = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsAdmin);

        //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetailsAdmin);

        Navigation utilNavigation = new Navigation(driver);
        ListUsersByLocation_Page listUsersByLocation_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsersByLocation);

        listUsersByLocation_page.customsLocation.select("ABZ - Aberdeen Airport");

        //Assert
        assertEquals("Aberdeen Airport", listUsersByLocation_page.locationName.getText().trim());
        assertEquals("air", listUsersByLocation_page.locationType.getText().trim());
    }


    @Test
    public void WhenListOfUsersDisplayed_CorrectUserRoleDisplayed(){

        //Arrange
        TestUserModel.UserDetails userDetailsMixRoles = Users_API.UserWithAllRoles_MixLocations2();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsMixRoles);

        TestUserModel.UserDetails userDetailsLocalAdmin = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsLocalAdmin);

        TestUserModel.UserDetails userDetailsLocalSuperAdmin = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsLocalSuperAdmin);


        //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(Users_API.DefaultSuperAdminUser());

        Navigation utilNavigation = new Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);

        List<ListUsers_Page.UserListTableObject> userListTableObjects = listUsers_page.getListOfUsers();

        //Assert
        ListUsers_Page.UserListTableObject userSuperAdminObject = listUsers_page.getUserTableObjectFromUserListTableObject(userListTableObjects, userDetailsLocalSuperAdmin.pid);
        ListUsers_Page.UserListTableObject userAdminObject = listUsers_page.getUserTableObjectFromUserListTableObject(userListTableObjects, userDetailsLocalAdmin.pid);
        ListUsers_Page.UserListTableObject userMixRolesObject = listUsers_page.getUserTableObjectFromUserListTableObject(userListTableObjects, userDetailsMixRoles.pid);

        assertEquals(false, userAdminObject.superAdmin);
        assertEquals(true, userAdminObject.admin);
        assertEquals(false, userAdminObject.ruleManager);

        assertEquals(true, userSuperAdminObject.superAdmin);
        assertEquals(false, userSuperAdminObject.admin);
        assertEquals(false, userSuperAdminObject.ruleManager);

        assertEquals(true, userMixRolesObject.superAdmin);
        assertEquals(true, userMixRolesObject.admin);
        assertEquals(true, userMixRolesObject.ruleManager);
    }

    @Test
    @Category({ChangeRequest.CR_2462.class,ChangeRequest.CR_2615.class, ChangeRequest.CR_2623.class})
    public void WhenListOfUsersFiltered_CorrectResultsDisplayed(){

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.SuperAdminNational());

        TestUserModel.UserDetails userDetailsLocalAdmin = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsLocalAdmin);
        UpdateStatusOfUser(userDetailsLocalAdmin.pid, TestEnumerators.MetaDataActions.USER_SUSPEND.apiAction);

        TestUserModel.UserDetails userDetailsLocalSuperAdmin = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsLocalSuperAdmin);

        TestUserModel.UserDetails userDetailsLocalRMPOO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsLocalRMPOO);

        TestUserModel.UserDetails userDetailsLocalRVExt = Users_API.RulesViewerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetailsLocalRVExt);

        //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(Users_API.DefaultSuperAdminUser());

        Navigation utilNavigation = new Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);

        listUsers_page.selectValueFromDropDown(listUsers_page.userRole, "Super Admin");

        List<ListUsers_Page.UserListTableObject> userListTableObjects1 = listUsers_page.getListOfUsers();
        Assertions.assertThat(userListTableObjects1).extracting("superAdmin").containsOnly(true);
        Assertions.assertThat(userListTableObjects1).extracting("admin").containsOnly(false);
        Assertions.assertThat(userListTableObjects1).extracting("ruleManager").containsOnly(false);

        listUsers_page.selectValueFromDropDown(listUsers_page.userRole, "Admin");

        List<ListUsers_Page.UserListTableObject> userListTableObjects2 = listUsers_page.getListOfUsers();
        Assertions.assertThat(userListTableObjects2).extracting("superAdmin").containsOnly(false);
        Assertions.assertThat(userListTableObjects2).extracting("admin").containsOnly(true);
        Assertions.assertThat(userListTableObjects2).extracting("ruleManager").containsOnly(false);

        listUsers_page.selectValueFromDropDown(listUsers_page.userStatus, "Suspended");
        List<ListUsers_Page.UserListTableObject> userListTableObjects3 = listUsers_page.getListOfUsers();
        Assertions.assertThat(userListTableObjects3).extracting("status").containsOnly("Suspended");

        listUsers_page.selectValueFromDropDown(listUsers_page.userType, "Local");
        List<ListUsers_Page.UserListTableObject> userListTableObjects4 = listUsers_page.getListOfUsers();
        Assertions.assertThat(userListTableObjects4).extracting("baseLocation").doesNotContain("National Office");

    }


    @Category({ChangeRequest.CR_2698.class})
    @Test
    public void WhenRuleManagerLoggedIn_RedactedUserNotDisplayedInListOfUsers(){

        //Arrange
        API.RulesManagementService.Utils.Users.CreateUserAndLogin(Users_API.AdminNational());
        API.RulesManagementService.Utils.Users.CreateNewUser(Users_API.RulesManagerNational());

        TestUserModel.UserDetails userDetails = Users_API.RulesManagerLocal_POO();
        userDetails.redacted = true;

        API.RulesManagementService.Utils.Users.CreateUserAndGetResponseObject(userDetails);

        //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(Users_API.RulesManagerNational());

        Navigation utilNavigation = new Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);

        List<ListUsers_Page.UserListTableObject> userListTableObjects = listUsers_page.getListOfUsers();

        //Assert
        Assertions.assertThat(userListTableObjects).extracting("pid").doesNotContain("1234572");
    }


    @Test
    @Category({ChangeRequest.CR_2784.class})

    public void WhenSuperAdminLoggedIn_ShouldShowListOfActiveAndInActiveUsers(){

        //Arrange
        TestUserModel.UserDetails userDetails_Admin_Local_Active = Users_API.AdminLocal_POO_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_Admin_Local_Active);

        TestUserModel.UserDetails userDetails_RulesViewerNational_Inactive = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RulesViewerNational_Inactive);

        mySQL_cds_rules.updateLastLoginForTheUser(userDetails_Admin_Local_Active.pid,FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-89,"yyyy-MM-dd HH:mm:ss.SSS"));
        mySQL_cds_rules.updateLastLoginForTheUser(userDetails_RulesViewerNational_Inactive.pid,FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-91,"yyyy-MM-dd HH:mm:ss.SSS"));

          //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(Users_API.DefaultSuperAdminUser());

        Navigation utilNavigation = new Navigation(driver);
        ListUsers_Page listUsers_page = utilNavigation.NavigateToPage(Navigation.Pages.ListUsers);

        //Assert
        List<ListUsers_Page.UserListTableObject> userListTableObjects = listUsers_page.getListOfUsers();
        int iUsers = userListTableObjects.size();
        assertTrue("Expect 3 or more users to be present", iUsers >= 3);

        ListUsers_Page.UserListTableObject userListTableObject = listUsers_page.getUserTableObjectFromUserListTableObject(userListTableObjects, userDetails_RulesViewerNational_Inactive.pid);
        assertEquals("Inactive", userListTableObject.status);
        userListTableObject = listUsers_page.getUserTableObjectFromUserListTableObject(userListTableObjects, userDetails_Admin_Local_Active.pid);
        assertEquals("Active", userListTableObject.status);
    }
}
