package TestCases.RulesManagementService;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import com.google.common.collect.ImmutableSet;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.experimental.categories.Category;


@Category(Rules_Management.class)
public class TestCase_RM_UserMetaCreate extends BaseWebAPITestCase
{
	@Test
	@Category(ChangeRequest.CR_655.class)
	public void WhenLocalSuperAdminUserCallsUserMetaCreate_CorrectNoOfCustomRolesReturned() {

		//Arrange
		TestUserModel.UserDetails usTD = Users_API.SuperAdminLocal_POO();
		API.RulesManagementService.Utils.Users.CreateNewUser(usTD);
		API.RulesManagementService.Utils.Users.LoginAsUser(usTD.pid);

		//Act
		API.RulesManagementService.Users.Meta.Create.UsersMetaCreateResponse.UsersMetaCreateResponseObject usersMetaCreateResponseObject = API.RulesManagementService.Utils.Users.GetUserMetaCreate();

		//Assert
		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles).flatExtracting("locations").extracting("locationName")
				.containsOnly(usTD.locationRoles.get(0).locationName, "All My Freight Locations");

		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles).extracting("role")
				.containsOnly("LocalSuperAdmin", "LocalAdmin");

		Assertions.assertThat(usersMetaCreateResponseObject.userTypes)
				.containsOnly("local");
	}

	@Test
	@Category({ChangeRequest.CR_655.class, ChangeRequest.CR_1398.class, ChangeRequest.CR_2808.class})
	public void WhenNationalSuperAdminUserCallsUserMetaCreate_CorrectNoOfCustomRolesReturned() {

		//Arrange
		TestUserModel.UserDetails usTD = Users_API.SuperAdminNational();
		API.RulesManagementService.Utils.Users.CreateNewUser(usTD);
		API.RulesManagementService.Utils.Users.LoginAsUser(usTD.pid);

		//Act
		API.RulesManagementService.Users.Meta.Create.UsersMetaCreateResponse.UsersMetaCreateResponseObject usersMetaCreateResponseObject = API.RulesManagementService.Utils.Users.GetUserMetaCreate();

		//Assert
		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles).extracting("role")
				.hasSize(3)
				.containsOnly("SuperAdmin", "Admin", "LocalSuperAdmin");

		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles.get(0)).extracting("role")
				.containsOnly("SuperAdmin");

		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles.get(0).locations)
				.hasSize(1)
				.extracting("locationName")
				.containsOnly("National Office");


		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles.get(1)).extracting("role")
				.containsOnly("LocalSuperAdmin");

		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles.get(1).locations)
				.hasSize(150)
				.extracting("locationName")
				.contains("All My Freight Locations");


		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles.get(2)).extracting("role")
				.containsOnly("Admin");

		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles.get(2).locations)
				.hasSize(1)
				.extracting("locationName")
				.containsOnly("National Office");

		Assertions.assertThat(usersMetaCreateResponseObject.userTypes)
				.containsOnly("local", "national");
	}

	@Test
	@Category(ChangeRequest.CR_655.class)
	public void WhenLocalAdminUserCallsUserMetaCreate_CorrectNoOfCustomRolesReturned() {

		//Arrange
		TestUserModel.UserDetails usTD = Users_API.AdminLocal_POO();
		API.RulesManagementService.Utils.Users.CreateNewUser(usTD);
		API.RulesManagementService.Utils.Users.LoginAsUser(usTD.pid);

		//Act
		API.RulesManagementService.Users.Meta.Create.UsersMetaCreateResponse.UsersMetaCreateResponseObject usersMetaCreateResponseObject = API.RulesManagementService.Utils.Users.GetUserMetaCreate();

		//Assert
		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles).flatExtracting("locations").extracting("locationName")
				.contains(usTD.locationRoles.get(0).locationName);

		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles).extracting("role")
				.hasSize(3)
				.containsOnly("LocalAdmin", "LocalRuleManager", "LocalRuleViewer");

		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles.get(1).locations)
				.hasSize(2)
				.extracting("locationName")
				.contains("All My Freight Locations", "POO");

		Assertions.assertThat(usersMetaCreateResponseObject.userTypes)
				.containsOnly("local");
	}

	@Test
	@Category({ChangeRequest.CR_655.class, ChangeRequest.CR_2808.class})
	public void WhenNationalAdminUserCallsUserMetaCreate_CorrectNoOfCustomRolesReturned() {

		//Arrange
		TestUserModel.UserDetails usTD = Users_API.AdminNational();
		API.RulesManagementService.Utils.Users.CreateNewUser(usTD);
		API.RulesManagementService.Utils.Users.LoginAsUser(usTD.pid);

		//Act
		API.RulesManagementService.Users.Meta.Create.UsersMetaCreateResponse.UsersMetaCreateResponseObject usersMetaCreateResponseObject = API.RulesManagementService.Utils.Users.GetUserMetaCreate();

		//Assert
		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles).extracting("role")
				.hasSize(3)
				.containsOnly("Admin", "RuleManager", "RuleViewer");

		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles.get(0)).extracting("role")
				.containsOnly("Admin");

		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles.get(0).locations)
				.hasSize(1)
				.extracting("locationName")
				.containsOnly("National Office");

		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles.get(1)).extracting("role")
				.containsOnly("RuleManager");

		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles.get(1).locations)
				.hasSize(1)
				.extracting("locationName")
				.contains("National Office");

		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles.get(2)).extracting("role")
				.containsOnly("RuleViewer");

		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles.get(2).locations)
				.hasSize(1)
				.extracting("locationName")
				.containsOnly("National Office");
	}

	@Test
	@Category(ChangeRequest.CR_1875.class)
	public void WhenNationalSuperAdminUserCallsUserMetaCreate_BaseLocationDoesNotContainAllLocations() {

		//Arrange
		TestUserModel.UserDetails usTD = Users_API.SuperAdminNational();
		API.RulesManagementService.Utils.Users.CreateNewUser(usTD);
		API.RulesManagementService.Utils.Users.LoginAsUser(usTD.pid);

		//Act
		API.RulesManagementService.Users.Meta.Create.UsersMetaCreateResponse.UsersMetaCreateResponseObject usersMetaCreateResponseObject = API.RulesManagementService.Utils.Users.GetUserMetaCreate();

		//Assert
		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles).extracting("role")
				.hasSize(3)
				.containsOnly("SuperAdmin", "Admin", "LocalSuperAdmin");

		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles.get(0)).extracting("role")
				.containsOnly("SuperAdmin");

		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles.get(0).locations)
				.hasSize(1)
				.extracting("locationName")
				.containsOnly("National Office");

		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles.get(2)).extracting("role")
				.containsOnly("Admin");

		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles.get(2).locations)
				.hasSize(1)
				.extracting("locationName")
				.contains("National Office");

		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles.get(1)).extracting("role")
				.containsOnly("LocalSuperAdmin");

		Assertions.assertThat(usersMetaCreateResponseObject.customsRoles.get(1).locations)
				.hasSize(150)
				.extracting("locationName")
				.contains("All My Freight Locations", "POO");
	}

	@Test
	@Category(ChangeRequest.CR_3190.class)
	public void localAdminBaseLocationsRestrictedBasedOnLocationType() {
		TestUserModel.UserDetails maritimeOnly = Users_API.AdminLocal_POO();
		API.RulesManagementService.Utils.Users.CreateNewUser(maritimeOnly);
		API.RulesManagementService.Utils.Users.LoginAsUser(maritimeOnly.pid);

		API.RulesManagementService.Users.Meta.Create.UsersMetaCreateResponse.UsersMetaCreateResponseObject metaCreate
				= API.RulesManagementService.Utils.Users.GetUserMetaCreate();

		Assertions.assertThat(metaCreate.customsBaseLocations).extracting("locationType")
				.containsOnlyElementsOf(ImmutableSet.of("maritime", "none"));

        TestUserModel.UserDetails airOnly = Users_API.adminLocal_ABZ("1234532");

        API.RulesManagementService.Utils.Users.CreateNewUser(airOnly);
        API.RulesManagementService.Utils.Users.LoginAsUser(airOnly.pid);

        metaCreate = API.RulesManagementService.Utils.Users.GetUserMetaCreate();

        Assertions.assertThat(metaCreate.customsBaseLocations).extracting("locationType")
                .containsOnlyElementsOf(ImmutableSet.of("air", "none"));

        TestUserModel.UserDetails airAndMaritimeLocalAdmin = Users_API.adminLocal_POO_ABZ("1234531");

        API.RulesManagementService.Utils.Users.CreateNewUser(airAndMaritimeLocalAdmin);
        API.RulesManagementService.Utils.Users.LoginAsUser(airAndMaritimeLocalAdmin.pid);

        metaCreate = API.RulesManagementService.Utils.Users.GetUserMetaCreate();

        Assertions.assertThat(metaCreate.customsBaseLocations).extracting("locationType")
                .containsOnlyElementsOf(ImmutableSet.of("air", "maritime","none"));
	}

    @Test
    @Category(ChangeRequest.CR_3190.class)
    public void localSuperAdminBaseLocationsRestrictedBasedOnLocationType() {
        TestUserModel.UserDetails maritimeOnly = Users_API.SuperAdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(maritimeOnly);
        API.RulesManagementService.Utils.Users.LoginAsUser(maritimeOnly.pid);

        API.RulesManagementService.Users.Meta.Create.UsersMetaCreateResponse.UsersMetaCreateResponseObject metaCreate
                = API.RulesManagementService.Utils.Users.GetUserMetaCreate();

        Assertions.assertThat(metaCreate.customsBaseLocations).extracting("locationType")
                .containsOnlyElementsOf(ImmutableSet.of("maritime", "none"));

        TestUserModel.UserDetails airOnly = Users_API.superAdminLocal_ABZ("1234532");

        API.RulesManagementService.Utils.Users.CreateNewUser(airOnly);
        API.RulesManagementService.Utils.Users.LoginAsUser(airOnly.pid);

        metaCreate = API.RulesManagementService.Utils.Users.GetUserMetaCreate();

        Assertions.assertThat(metaCreate.customsBaseLocations).extracting("locationType")
                .containsOnlyElementsOf(ImmutableSet.of("air", "none"));

        TestUserModel.UserDetails airAndMaritimeLocalSuperAdmin = Users_API.superAdminLocal_POO_ABZ("1234531");

        API.RulesManagementService.Utils.Users.CreateNewUser(airAndMaritimeLocalSuperAdmin);
        API.RulesManagementService.Utils.Users.LoginAsUser(airAndMaritimeLocalSuperAdmin.pid);

        metaCreate = API.RulesManagementService.Utils.Users.GetUserMetaCreate();

        Assertions.assertThat(metaCreate.customsBaseLocations).extracting("locationType")
                .containsOnlyElementsOf(ImmutableSet.of("air", "maritime","none"));
    }

    @Test
    @Category(ChangeRequest.CR_3190.class)
    public void nationalUserLocationsNotRestricted() {
        TestUserModel.UserDetails nationalSuperAdminAndMaritimeLocalAdmin
                = Users_API.nationalSuperAdminAndLocalAdmin("1234531");

        API.RulesManagementService.Utils.Users.CreateNewUser(nationalSuperAdminAndMaritimeLocalAdmin);
        API.RulesManagementService.Utils.Users.LoginAsUser(nationalSuperAdminAndMaritimeLocalAdmin.pid);

        API.RulesManagementService.Users.Meta.Create.UsersMetaCreateResponse.UsersMetaCreateResponseObject metaCreate
                = API.RulesManagementService.Utils.Users.GetUserMetaCreate();

        Assertions.assertThat(metaCreate.customsBaseLocations).extracting("locationType")
                .containsOnlyElementsOf(ImmutableSet.of("air", "maritime","none"));
    }
}
