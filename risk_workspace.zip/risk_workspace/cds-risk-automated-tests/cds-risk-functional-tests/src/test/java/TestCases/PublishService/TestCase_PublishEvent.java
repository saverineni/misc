//package TestCases.PublishService;
//
//import Categories_CDSRisk.ChangeRequest_RiskingService;
//import Categories_CDSRisk.Publish_Service;
//import lombok.extern.slf4j.Slf4j;
//import org.assertj.core.api.Assertions;
//import org.junit.Test;
//import org.junit.experimental.categories.Category;
//import uk.gov.hmrc.risk.test.common.model.publishService.PublishEventModel;
//import uk.gov.hmrc.risk.test.common.model.publishService.PublishedDataTables;
//import uk.gov.hmrc.risk.test.common.model.publishService.PublishedRules;
//
//import java.util.UUID;
//
//@Slf4j
//@Category({ChangeRequest_RiskingService.CREP_285.class, Publish_Service.class})
//public class TestCase_PublishEvent extends BasePublishServiceTest{
//
//    @Test
//    public void WhenPublishRequestIsSent_EventAppearsOnQueueAndIsSavedInCacheLoader() {
//
//        publishSupport.setPublishInterval(3600);
//
//        publishAndWait();
//
////        PublishEventModel queuePublishEvent = publishSupport.getPublishEvent(10);
////
////        assertBasicEvent(queuePublishEvent);
////
////        UUID expectedPublishEventId = queuePublishEvent.getPublishEventId();
//
//        PublishEventModel cacheLatestEvent =
//                cacheLoaderSupport.getLatestPublishEvent( 5);
//
//        Assertions.assertThat(cacheLatestEvent).isNotNull();
//        Assertions.assertThat(cacheLatestEvent.getDataTablePackageId())
//                  .
//        Assertions.assertThat(cacheLatestEvent.getRulePackageId())
//                  .isEqualTo(queuePublishEvent.getRulePackage().getPackageVersion());
//        Assertions.assertThat(cacheLatestEvent.getDataTablePackage()).isNull();
//        Assertions.assertThat(cacheLatestEvent.getRulePackage()).isNull();
//
//        PublishEventModel riskingPublishEvent = publishSupport.getPublishEvent(5);
//        Assertions.assertThat(riskingPublishEvent).isNotNull();
//        Assertions.assertThat(riskingPublishEvent.getPublishEventId()).isEqualTo(expectedPublishEventId);
//        Assertions.assertThat(riskingPublishEvent.getDataTablePackageId())
//                  .isEqualTo(queuePublishEvent.getDataTablePackage().getPackageVersion());
//        Assertions.assertThat(riskingPublishEvent.getRulePackageId())
//                  .isEqualTo(queuePublishEvent.getRulePackage().getPackageVersion());
//        Assertions.assertThat(riskingPublishEvent.getDataTablePackage()).isNull();
//        Assertions.assertThat(riskingPublishEvent.getRulePackage()).isNull();
//
//        PublishedDataTables publishedDataTables =
//                cacheLoaderSupport.getPublishedDataTables(riskingPublishEvent.getDataTablePackageId().toString());
//        Assertions.assertThat(publishedDataTables).isNotNull();
//        Assertions.assertThat(publishedDataTables.getPackageVersion()).isNotNull();
//        Assertions.assertThat(publishedDataTables.getPackageVersion())
//                  .isEqualTo(riskingPublishEvent.getDataTablePackageId());
//
//        PublishedRules publishedRules =
//                cacheLoaderSupport.getPublishedRules(riskingPublishEvent.getRulePackageId().toString());
//        Assertions.assertThat(publishedRules).isNotNull();
//        Assertions.assertThat(publishedRules.getPackageVersion()).isNotNull();
//        Assertions.assertThat(publishedRules.getPackageVersion())
//                  .isEqualTo(riskingPublishEvent.getRulePackageId());
//    }
//}
