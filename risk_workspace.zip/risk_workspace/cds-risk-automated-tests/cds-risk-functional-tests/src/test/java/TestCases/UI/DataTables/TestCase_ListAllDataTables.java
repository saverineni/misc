package TestCases.UI.DataTables;


import API.DataForTests.*;
import API.DataService.CreateDataTable.CreateDataTableResponse;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.UnstableTests;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.Pages.DataManagement.ListDataTable_Page;
import UI.Utils.Navigation;
import io.restassured.response.Response;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.ArrayList;
import java.util.List;

import static API.Utils.LoginAsAPIUserAndCreateDataTableForLocation;
import static FunctionsLibrary.Utils.SleepForMilliSeconds;

@Category(UnstableTests.class)
public class TestCase_ListAllDataTables extends BaseUIWebDriverTestCase {

    TestUserModel.UserDetails userDetails_POO;
    TestUserModel.UserDetails userDetails_EXT;
    TestDataTableModel.TableDetails tableDetailsPOO;
    TestDataTableModel.TableDetails tableDetailsEXT;
    
    @Before
    public void LocalSetup()
    {
        //Login as User 1 create data table for POO
        userDetails_POO = Users_API.RulesManagerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_POO);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_POO.pid);

        tableDetailsPOO = DataTables.DataTable_CommodityCodes_POO();
        CreateDataTableResponse.PostResponse createDataTableResponse1 = API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsPOO);

        //Login as User 2 create data table for EXT
        userDetails_EXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_EXT);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_EXT.pid);

        tableDetailsEXT = DataTables.DataTable_CommodityCodes_EXT();
        CreateDataTableResponse.PostResponse createDataTableResponse2 = API.DataService.Utils.DataTables.CreateDataTableAndGetResponseObject(tableDetailsEXT);
    }

    private List<String> NavigateToListAllDataTablesAndGetListOfDataTablesTitles()
    {

        Navigation utilNavigation = new Navigation(driver);
        ListDataTable_Page listDataTable_page =  utilNavigation.NavigateToPage(Navigation.Pages.ListAllDataTables);

        List<ListDataTable_Page.DataTableListObject> dataTables = listDataTable_page.getDataTableListDetails();

        List<String> dataTableTitles = new ArrayList<>();

        for (ListDataTable_Page.DataTableListObject dataTableListObject : dataTables){

            dataTableTitles.add(dataTableListObject.tableTitle);
        }

        return dataTableTitles;
    }

    @Category(ChangeRequest.CR_1190.class)
    @Test
    public void WhenLocalRuleManagerLoggedIn_CanViewAllDataTablesCreatedInListAllDataTables() {

        //Arrange
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetails_EXT);

        //Act
        List<String> dataTableTitles = NavigateToListAllDataTablesAndGetListOfDataTablesTitles();

        //Assert
        Assertions.assertThat(dataTableTitles).contains(tableDetailsPOO.tableName);
        Assertions.assertThat(dataTableTitles).contains(tableDetailsEXT.tableName);
    }

    @Category(ChangeRequest.CR_1190.class)
    @Test
    public void WhenNationalRuleManagerLoggedIn_CanViewAllDataTablesCreatedInListAllDataTables() {

        //Arrange
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        TestUserModel.UserDetails UserDetails_NAT = Users_API.RulesManagerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_NAT);

        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_NAT);

        //Act
        List<String> dataTableTitles = NavigateToListAllDataTablesAndGetListOfDataTablesTitles();

        //Assert
        Assertions.assertThat(dataTableTitles).contains(tableDetailsPOO.tableName);
        Assertions.assertThat(dataTableTitles).contains(tableDetailsEXT.tableName);
    }

    @Category(ChangeRequest.CR_1190.class)
    @Test
    public void WhenNationalRuleViewerLoggedIn_CanViewAllDataTablesCreatedInListAllDataTables() {

        //Arrange
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        TestUserModel.UserDetails UserDetails_NAT = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_NAT);

        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_NAT);

        //Act
        List<String> dataTableTitles = NavigateToListAllDataTablesAndGetListOfDataTablesTitles();

        //Assert
        Assertions.assertThat(dataTableTitles).contains(tableDetailsPOO.tableName);
        Assertions.assertThat(dataTableTitles).contains(tableDetailsEXT.tableName);
    }

    @Category(ChangeRequest.CR_1190.class)
    @Test
    public void WhenLocalRuleViewerLoggedIn_CanViewAllDataTablesCreatedInListAllDataTables() {

        //Arrange
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        TestUserModel.UserDetails UserDetails_EXT = Users_API.RulesViewerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_EXT);

        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_EXT);

        //Act
        List<String> dataTableTitles = NavigateToListAllDataTablesAndGetListOfDataTablesTitles();

        //Assert
        Assertions.assertThat(dataTableTitles).contains(tableDetailsPOO.tableName);
        Assertions.assertThat(dataTableTitles).contains(tableDetailsEXT.tableName);
    }

    @Category(ChangeRequest.CR_1190.class)
    @Test
    public void WhenLocalRuleManagerLoggedIn_CanViewDataDataTablesSharedForUseWithAllInListAllDataTables(){

        //Arrange
        //Login as User 1 create data table for POO
        TestUserModel.UserDetails UserDetailsPOO = Users_API.RulesManagerLocal_POO();
        TestDataTableModel.TableDetails tableDetailsPOO = DataTables.DataTable_CommodityCodes_POO();
        CreateDataTableResponse.PostResponse createDataTableResponse1 = LoginAsAPIUserAndCreateDataTableForLocation(UserDetailsPOO, tableDetailsPOO);

        tableDetailsPOO.useTablesLocationUuids.add(Locations.Location_AllLocations_UID);
        tableDetailsPOO.uuid = createDataTableResponse1.uuid;
        tableDetailsPOO.creationShareType = "user";

        Response response = API.DataService.Utils.DataTables.ShareDataTableWithLocations(tableDetailsPOO);

        //Act
        TestUserModel.UserDetails UserDetails_EXT = Users_API.RulesManagerLocal_EXT();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_EXT);

        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_EXT);

        List<String> dataTableTitles = NavigateToListAllDataTablesAndGetListOfDataTablesTitles();

        //Assert
        Assertions.assertThat(dataTableTitles).contains(tableDetailsPOO.tableName);
    }

    @Category(ChangeRequest.CR_1057.class)
    @Test
    public void WhenLocalRuleManagerFiltersAllDataTablesByOwner_CanViewAllDataTablesSharedForOwnership() {

        //Arrange
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(userDetails_EXT);

        //Act
        List<String> allDataTableTitles = NavigateToListAllDataTablesAndGetListOfDataTablesTitles();
        SleepForMilliSeconds(1000);

        ListDataTable_Page listDataTable_page = new ListDataTable_Page(driver);
        listDataTable_page.accessDropDown.click();
        listDataTable_page.selectFromDropdown("Owner");

        List<ListDataTable_Page.DataTableListObject> dataTables = listDataTable_page.getDataTableListDetails();

        List<String> ownerDataTableTitles = new ArrayList<>();

        for (ListDataTable_Page.DataTableListObject dataTableListObject : dataTables){

            ownerDataTableTitles.add(dataTableListObject.tableTitle);
        }

        //Assert
        Assertions.assertThat(allDataTableTitles).contains(tableDetailsPOO.tableName, tableDetailsEXT.tableName);

        Assertions.assertThat(ownerDataTableTitles).contains(tableDetailsEXT.tableName);
    }
}

