package TestCases.RiskingService;

import API.DataForTests.Rules;
import API.DataForTests.TestDeclarationModel;
import API.DataForTests.TestRuleModel.RuleDetails;
import API.RulesManagementService.EditRuleVersion.EditRuleVersionResponse;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Risking_Service;
import TestCases.BaseWebAPITestCase;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import uk.gov.hmrc.risk.test.common.model.riskingService.DeclarationResponse;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

@Slf4j
@Category(Risking_Service.class)
public class TestCase_RiskingService_Rats extends BaseWebAPITestCase {

    @Before
    public void setup() throws IOException, TimeoutException {
        log.debug("Purging Messages from Rabbit MQ");
        queue.purge();
    }


    @Test
    @Category({ChangeRequest.CR_1636.class})
    public void WhenDeclarationSubmittedForRatRuleBelowDailyLimit_RouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleWithRatsNatManager();
        ruleDetails.ratDefinition.hitRate.limit = 1;
        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.dispatchCountry = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.declarationSubType = "C";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
    }


    @Test
    @Category({ChangeRequest.CR_1636.class})
    public void WhenDeclarationSubmittedForRatRuleSetsZero_NoRouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleWithRatsNatManager();
        ruleDetails.ratDefinition.hitRate.limit = 0;
        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.dispatchCountry = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.declarationSubType = "C";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        //Assert
        String returnedControlType = declarationResponse.getControlType();
        Assertions.assertThat(returnedControlType).isEmpty();
    }


    @Test
    @Category({ChangeRequest.CR_1636.class})
    public void WhenDeclarationSubmittedForRatRuleAboveDailyLimit_NoRouteReturned() throws Throwable {

        //Arrange
        RuleDetails ruleDetails = Rules.DraftNatRuleWithRatsNatManager();
        ruleDetails.ratDefinition.hitRate.limit = 1;
        ruleDetails.ruleOutputs.actionType = "1";

        EditRuleVersionResponse.PutResponse ruleResponse = API.RulesManagementService.Utils.RuleAtStatus.CreateCommittedRule(ruleDetails);

        publishAndWait(5000);

        //Act
        TestDeclarationModel.Declaration declaration = new TestDeclarationModel.Declaration();
        declaration.goodsLocationName = "GBBYMNCABZNASInfo";
        declaration.dispatchCountry = ruleDetails.queryConditions.get(0).conditions.get(0).value;
        declaration.declarationSubType = "C";

        String declarationRequest = API.RiskingService.Declaration.SubmitDeclarationRequestFromFile.createDeclarationXMLBody(declaration, declarationSupport.getDefaultDeclarationTemplate());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse = new DeclarationResponse(queue.receive());

        queue.send(declarationRequest);
        DeclarationResponse declarationResponse2 = new DeclarationResponse(queue.receive());

        //Assert
        Assertions.assertThat(declarationResponse.getControlType()).isEqualTo(declaration.controlTypeExpectedValue);
        Assertions.assertThat(declarationResponse2.getControlType()).isEmpty();
    }


}