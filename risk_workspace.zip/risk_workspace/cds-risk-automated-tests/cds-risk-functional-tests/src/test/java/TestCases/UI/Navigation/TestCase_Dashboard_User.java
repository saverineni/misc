package TestCases.UI.Navigation;

import API.DataForTests.TestUserModel;
import API.DataForTests.Users_API;
import Categories_CDSRisk.CDS_Risk_UI;
import Categories_CDSRisk.CDS_Risk_UI_Navigation;
import Categories_CDSRisk.ChangeRequest;
import TestCases.UI.BaseUIWebDriverTestCase;
import UI.Pages.Home_Page;
import UI.Pages.UserManagement.ListUsers_Page;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.List;

import static FunctionsLibrary.Utils.SleepForMilliSeconds;
import static junit.framework.TestCase.assertEquals;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

@Category({CDS_Risk_UI.class, CDS_Risk_UI_Navigation.class})
public class TestCase_Dashboard_User extends BaseUIWebDriverTestCase{


    @Test
    @Category({ChangeRequest.CR_2611.class})
    public void WhenUserTabSelected_UserDashboardDetailsDisplayed() {

        //Arrange
        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational("1234562");
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        //Act
        Home_Page home_page = new Home_Page(driver);
        home_page.usersTab.click();

        //Assert
        assertTrue("Default Total Users Tables", home_page.getTotalUsersTables() >= 3);
        assertEquals("Default Users Type Filter", "All Users", home_page.userType.getSelectedItem());
        assertEquals("Default Users Role Filter", "All Roles", home_page.userRole.getSelectedItem());
    }


    @Test
    @Category({ChangeRequest.CR_2611.class,ChangeRequest.CR_2640.class})

    public void WhenUsersExist_UserDashboardDisplayCorrectDetails() {

        //Arrange
        TestUserModel.UserDetails userDetails_RM_Innactive = Users_API.RulesManagerLocal_WAT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RM_Innactive);
        mySQL_cds_rules.updateLastLoginForTheUser(userDetails_RM_Innactive.pid,FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-91,"yyyy-MM-dd HH:mm:ss.SSS"));


        TestUserModel.UserDetails userDetails_RV = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RV);
        API.RulesManagementService.Utils.Users.LoginAsUser(userDetails_RV.pid);

        TestUserModel.UserDetails userDetails_AN_Inactive = Users_API.AdminLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_AN_Inactive);
        mySQL_cds_rules.updateLastLoginForTheUser(userDetails_AN_Inactive.pid,FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-91,"yyyy-MM-dd HH:mm:ss.SSS"));


        TestUserModel.UserDetails UserDetails = Users_API.RulesManagerNational("1234562");
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails);
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails);

        //Act
        Home_Page home_page = new Home_Page(driver);
        home_page.usersTab.click();
        SleepForMilliSeconds(250);

        List<Home_Page.DashBoardItemObject> dashboardItems = home_page.getDashboardUserItems();
        int actUsersTables = home_page.getTotalUsersTables();

        home_page.userType.select("Local users");
        List<Home_Page.DashBoardItemObject> dashboardItemsLocal = home_page.getDashboardUserItems();
        int actLocalUsersTables = home_page.getTotalUsersTables();

        home_page.userRole.select("Rule Manager");
        SleepForMilliSeconds(250);
        List<Home_Page.DashBoardItemObject> dashboardItemsLocalRM = home_page.getDashboardUserItems();
        int actLocalRMDataTables = home_page.getTotalUsersTables();


        //Assert
        assertTrue("Default Total Users Tables", actUsersTables >= 5);
        assertEquals("ACTIVE", dashboardItems.get(0).status);
        assertEquals("SUSPENDED", dashboardItems.get(1).status);
        assertEquals("INACTIVE", dashboardItems.get(2).status);


        assertTrue("ACTIVE count", dashboardItems.get(0).count >= 4);
        assertEquals("SUSPENDED count", 0, dashboardItems.get(1).count);
        assertTrue("INACTIVE count", dashboardItems.get(2).count >= 2);


        assertEquals("ACTIVE percentage", 66.67,dashboardItems.get(0).percentage);
        assertEquals("SUSPENDED percentage", 0.00, dashboardItems.get(1).percentage);
        assertEquals("INACTIVE percentage", 33.33,dashboardItems.get(2).percentage);


        //Local
        assertEquals("Local Users", 3, actLocalUsersTables);
        assertEquals("ACTIVE count", 1, dashboardItemsLocal.get(0).count);
        assertEquals("SUSPENDED count", 0, dashboardItemsLocal.get(1).count);
        assertEquals("INACTIVE count", 2, dashboardItemsLocal.get(2).count);


        assertEquals("ACTIVE percentage", 33.33, dashboardItemsLocal.get(0).percentage);
        assertEquals("SUSPENDED percentage", 0.00, dashboardItemsLocal.get(1).percentage);
        assertEquals("INACTIVE percentage",66.67, dashboardItemsLocal.get(2).percentage);


        //Local Rule Manager
        assertEquals("Local RM Users", 1, actLocalRMDataTables);
        assertEquals("ACTIVE count", 0, dashboardItemsLocalRM.get(0).count);
        assertEquals("SUSPENDED count", 0, dashboardItemsLocalRM.get(1).count);
        assertEquals("INACTIVE count", 1, dashboardItemsLocalRM.get(2).count);


        assertEquals("ACTIVE percentage", 0.00, dashboardItemsLocalRM.get(0).percentage);
        assertEquals("SUSPENDED percentage", 0.00, dashboardItemsLocalRM.get(1).percentage);
        assertEquals("INACTIVE percentage", 100.00, dashboardItemsLocalRM.get(2).percentage);

    }

    @Test
    @Category({ChangeRequest.CR_2680.class})
    public void WhenClickedOnInactiveUsersDialInDashboard_CorrectListOfInactiveUsersAreDisplayed() {

        //Arrange
        TestUserModel.UserDetails userDetails_RM_Inactive = Users_API.RulesManagerLocal_WAT();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RM_Inactive);

        TestUserModel.UserDetails userDetails_RV_Inactive = Users_API.RuleViewerLocal_POO();
        API.RulesManagementService.Utils.Users.CreateNewUser(userDetails_RV_Inactive);

        TestUserModel.UserDetails UserDetails_AN_Inactive = Users_API.AdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_AN_Inactive);

        TestUserModel.UserDetails UserDetails_RVN_Active = Users_API.RulesViewerNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_RVN_Active);

        TestUserModel.UserDetails UserDetails_SAN_Active = Users_API.SuperAdminNational();
        API.RulesManagementService.Utils.Users.CreateNewUser(UserDetails_SAN_Active);

        //Update the last login
        mySQL_cds_rules.updateLastLoginForTheUser(userDetails_RV_Inactive.pid,FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-91,"yyyy-MM-dd HH:mm:ss.SSS"));
        mySQL_cds_rules.updateLastLoginForTheUser(UserDetails_AN_Inactive.pid,FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-91,"yyyy-MM-dd HH:mm:ss.SSS"));
        mySQL_cds_rules.updateLastLoginForTheUser(userDetails_RM_Inactive.pid,FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-91,"yyyy-MM-dd HH:mm:ss.SSS"));
        mySQL_cds_rules.updateLastLoginForTheUser(UserDetails_RVN_Active.pid,FunctionsLibrary.DateTime.AdjustLocalDateTimeNowByXDays(-89,"yyyy-MM-dd HH:mm:ss.SSS"));


        //Act
        UI.Utils.Users utilUsers = new UI.Utils.Users(driver);
        utilUsers.LoginToCDSRiskUIAsUser(UserDetails_SAN_Active);

        Home_Page home_page = new Home_Page(driver);
        home_page.usersTab.click();
        int actTotalOfInactiveUsers = Integer.parseInt(home_page.getUserCountForDial("INACTIVE"));
        home_page.clickUserStatusDial("inactive");
        ListUsers_Page listUsers_page = new ListUsers_Page(driver);
        List<ListUsers_Page.UserListTableObject> userListTableObjects = listUsers_page.getListOfUsers();

        //should contains only inactive users
        assertThat(userListTableObjects).hasSize(actTotalOfInactiveUsers).extracting("pid").contains(userDetails_RV_Inactive.pid,UserDetails_AN_Inactive.pid,userDetails_RM_Inactive.pid);
        //should not contain active users
        assertThat(userListTableObjects).extracting("pid").doesNotContain(UserDetails_RVN_Active.pid,UserDetails_SAN_Active.pid);

    }

}
