package TestCases.RulesManagementService;


import API.DataForTests.Locations;
import API.EnvDetails.EnvDetails;
import API.RulesManagementService.Users.ViewUserList.ViewUserListResponse;
import Categories_CDSRisk.CDS_RM_UserManagement;
import Categories_CDSRisk.ChangeRequest;
import Categories_CDSRisk.Rules_Management;
import TestCases.BaseWebAPITestCase;
import org.apache.http.HttpStatus;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import static API.RulesManagementService.Utils.Users.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

@Category({Rules_Management.class, CDS_RM_UserManagement.class})
public class TestCase_UserManagement_User_BasicSearch extends BaseWebAPITestCase {

    @Before
    public void Setup() {
        //Arrange
        createAListOfUsers();
    }

    @Test
    @Category(ChangeRequest.CR_2615.class)
    public void WhenSuperAdminRoleleIsSearched_OnlySuperAdminRolesAreDisplayed() {
        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = SearchUsers("userRole", "superadmin");

        //Assert
        assertEquals(HttpStatus.SC_OK, viewUserListResponseObject.httpStatusCode);
        assertThat(viewUserListResponseObject.content)
                .hasSize(viewUserListResponseObject.content.size())
                .extracting("highestLevelRole").containsOnly("SuperAdmin", "LocalSuperAdmin");
    }

    @Test
    @Category(ChangeRequest.CR_2615.class)
    public void WhenAdminRoleIsSearched_OnlyAdminRolesAreDisplayed() {

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = SearchUsers("userRole", "admin");

        //Assert
        assertEquals(HttpStatus.SC_OK, viewUserListResponseObject.httpStatusCode);
        assertThat(viewUserListResponseObject.content)
                .hasSize(viewUserListResponseObject.content.size())
                .extracting("highestLevelRole").containsOnly("LocalAdmin", "Admin");

    }

    @Test
    @Category(ChangeRequest.CR_2615.class)
    public void WhenRuleManagerIsSearched_OnlyRuleManagerRolesAreDisplayed() {

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = SearchUsers("userRole", "rulemanager");

        //Assert
        assertEquals(HttpStatus.SC_OK, viewUserListResponseObject.httpStatusCode);
        assertThat(viewUserListResponseObject.content)
                .hasSize(viewUserListResponseObject.content.size())
                .extracting("highestLevelRole").containsOnly("RuleManager","LocalRuleManager");

    }

    @Test
    @Category(ChangeRequest.CR_2610.class)
    @Ignore("Will be fixed as part of CR-3392")
    public void WhenUserSearchedByPartialName_CorrectUsersAreReturned() {

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = SearchUsers("name", "Ma");

        //Assert
        assertEquals(HttpStatus.SC_OK, viewUserListResponseObject.httpStatusCode);
        assertThat(viewUserListResponseObject.content)
                .hasSize(2)
                .extracting("firstName").containsOnly("Mark", "Maxwell");

        assertThat(viewUserListResponseObject.content)
                .hasSize(2)
                .extracting("lastName").containsOnly("Nicholas", "Logan");

    }

    @Test
    @Category(ChangeRequest.CR_2610.class)
    public void WhenUserSearchedByFullName_CorrectUsersAreReturned() {

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = SearchUsers("name", "Vernon");

        //Assert
        assertEquals(HttpStatus.SC_OK, viewUserListResponseObject.httpStatusCode);
        assertThat(viewUserListResponseObject.content)
                .hasSize(viewUserListResponseObject.content.size())
                .extracting("firstName").containsOnly("Vernon");

        assertThat(viewUserListResponseObject.content)
                .hasSize(viewUserListResponseObject.content.size())
                .extracting("lastName").containsOnly("Nelson");

    }

    @Test
    @Category(ChangeRequest.CR_2614.class)
    @Ignore("Will be fixed as part of CR-3392")
    public void WhenUserSearchedByPartialPid_CorrectUsersAreReturned() {

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = SearchUsers("pid", "123453");

        //Assert
        assertEquals(HttpStatus.SC_OK, viewUserListResponseObject.httpStatusCode);
        assertThat(viewUserListResponseObject.content)
                .hasSize(3)
                .extracting("pid").containsOnly("1234530", "1234531", "1234532");
    }

    @Test
    @Category(ChangeRequest.CR_2614.class)
    public void WhenUserSearchedByFullPid_CorrectUsersAreReturned() {

        //Act
        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = SearchUsers("pid", "1234560");

        //Assert
        assertEquals(HttpStatus.SC_OK, viewUserListResponseObject.httpStatusCode);
        assertThat(viewUserListResponseObject.content)
                .hasSize(1)
                .extracting("pid").containsOnly("1234560");
    }

    @Test
    @Category({ChangeRequest.CR_2610.class, ChangeRequest.CR_2614.class})
    public void WhenUserSearchedByNameAndPid_CorrectUsersReturned() {

        //Act
        String url = EnvDetails.url_RM_Users + "?name=Megan&pid=12";

        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = getViewUserListResponseObject(url);

        //Assert
        assertEquals(HttpStatus.SC_OK, viewUserListResponseObject.httpStatusCode);
        assertThat(viewUserListResponseObject.content)
                .hasSize(1)
                .extracting("pid").containsOnly("1234531");

        assertThat(viewUserListResponseObject.content)
                .extracting("firstName").containsOnly("Megan");
    }

    @Test
    @Category({ChangeRequest.CR_2610.class, ChangeRequest.CR_2614.class,ChangeRequest.CR_2615.class})
    public void WhenThereAreNoSearchResults_NoResultsMessageIsDisplayed() {

        //Act
        String url = EnvDetails.url_RM_Users + "?userRole=admin&name=test&pid=900";

        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = getViewUserListResponseObject(url);

        //Assert
        assertEquals(HttpStatus.SC_OK, viewUserListResponseObject.httpStatusCode);
        assertThat(viewUserListResponseObject.content)
                .hasSize(0);
        assertThat(viewUserListResponseObject.totalElements).isEqualTo(0);
        assertThat(viewUserListResponseObject.totalPages).isEqualTo(0);

    }

    @Test
    @Category({ChangeRequest.CR_2676.class})
    @Ignore("Will be fixed as part of CR-3392")
    public void WhenUserSearchedByBaseLocations_CorrectUsersReturned() {

        //Act
        String locations= Locations.Location_POO_UID+","+Locations.Location_EXT_UID;
        String url = EnvDetails.url_RM_Users + "?baseLocations="+locations+"&size=20&page=0";

        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = getViewUserListResponseObject(url);

        //Assert
        assertEquals(HttpStatus.SC_OK, viewUserListResponseObject.httpStatusCode);
        assertThat(viewUserListResponseObject.content)
                .hasSize(5)
                .extracting("pid").containsOnly("1234510", "1234530", "1234532", "1234541", "1234542");

        assertThat(viewUserListResponseObject.content)
                .extracting("baseLocation.locationFullName").containsOnly("Exeter Airport","Poole");

    }

    @Test
    @Category({ChangeRequest.CR_2676.class})
    @Ignore("Will be fixed as part of CR-3392")
    public void WhenUserSearchedByBaseLocationsAlongWithOtherSearchParams_CorrectUsersReturned() {

        //Act
        String locations = Locations.Location_EXT_UID+","+Locations.Location_WAT_UID;
        String url = EnvDetails.url_RM_Users + "?userType=local&userRole=rulemanager&pid=1234&userStatus=active&baseLocations="+locations+"&size=20&page=0";

        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = getViewUserListResponseObject(url);

        //Assert
        assertEquals(HttpStatus.SC_OK, viewUserListResponseObject.httpStatusCode);
        assertThat(viewUserListResponseObject.content)
                .hasSize(2)
                .extracting("pid").containsOnly("1234531", "1234542");

        assertThat(viewUserListResponseObject.content)
                .extracting("baseLocation.locationFullName").containsOnly("Exeter Airport","Watchet");

    }

    @Test
    @Category({ChangeRequest.CR_2676.class})
    public void WhenThereAreNoMatchingBaseLocations_NoResultsReturned() {

        //Act
        String url = EnvDetails.url_RM_Users + "?baseLocations="+Locations.Location_SUN_UID+"&size=20&page=0";

        ViewUserListResponse.ViewUserListResponseObject viewUserListResponseObject = getViewUserListResponseObject(url);

        //Assert
        assertEquals(HttpStatus.SC_OK, viewUserListResponseObject.httpStatusCode);
        assertThat(viewUserListResponseObject.content)
                .hasSize(0);
        assertThat(viewUserListResponseObject.totalElements).isEqualTo(0);
        assertThat(viewUserListResponseObject.totalPages).isEqualTo(0);

    }


}
