#!/bin/bash

MYSQL_USER=$1
MYSQL_PASSWORD=$2

mysql -u ${MYSQL_USER} -p${MYSQL_PASSWORD} -h 10.69.2.184 -e 'truncate table rules'
