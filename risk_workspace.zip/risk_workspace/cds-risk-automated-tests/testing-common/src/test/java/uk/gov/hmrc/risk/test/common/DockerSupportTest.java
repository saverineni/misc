package uk.gov.hmrc.risk.test.common;

import com.spotify.docker.client.DockerClient;
import com.spotify.docker.client.LogStream;
import com.spotify.docker.client.messages.ContainerConfig;
import com.spotify.docker.client.messages.ContainerCreation;
import com.spotify.docker.client.messages.ExecCreation;
import lombok.SneakyThrows;
import org.junit.Ignore;
import org.junit.Test;
import uk.gov.hmrc.risk.test.common.service.DockerSupport;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Ignore
public class DockerSupportTest {

    private DockerSupport dockerSupport = new DockerSupport(
            DockerSupport.DockerSupportConfig.builder()
                    .host("localhost")
//                    .host("10.102.104.117")
//                    .portPrefix(130)
                    .build()
    );

    @Test
    @SneakyThrows
    public void testExecContainer_canAccessFiles() {
        Optional<DockerSupport.ContainerAccessor> containers =
                dockerSupport.findByPort(dockerSupport.getAllContainers(true), 28080);

        System.out.println(containers);
        //docker exec -i -t c951b6b4fb9d  /bin/bash

        String containerId = containers.get().getId();


        DockerClient client = dockerSupport.getClient();

        ExecCreation creation = client.execCreate(containerId,
                new String[]{"bash", "-c", "cat wait-for-it.sh"},
                new DockerClient.ExecCreateParam[]{
                        DockerClient.ExecCreateParam.attachStdout()
                }
        );

        final LogStream output = client.execStart(creation.id());
        final String execOutput = output.readFully();

        System.out.println("output: " + execOutput);

    }

    @Test
    @SneakyThrows
    public void testExecContainer_canReadJsonEventFile() {
        Optional<DockerSupport.ContainerAccessor> containers =
                dockerSupport.findByPort(dockerSupport.getAllContainers(true), 12215);

        System.out.println(containers);
        //docker exec -i -t c951b6b4fb9d  /bin/bash

        String containerId = containers.get().getId();


        DockerClient client = dockerSupport.getClient();

        ExecCreation creation = client.execCreate(containerId,
                new String[]{"bash", "-c", "cat /tmp/risking_audit_2017-06-28_ab2fe66f-4b59-4df5-b2ed-5b40d5c8389f.json"},
                new DockerClient.ExecCreateParam[]{
                        DockerClient.ExecCreateParam.attachStdout()
                }
        );

        final LogStream output = client.execStart(creation.id());
        final String execOutput = output.readFully();

        String[] events = execOutput.split(System.lineSeparator());

        System.out.println("output: " + execOutput + "" + events.length);

    }

    @Test
    @SneakyThrows
    public void containerTest() {
        String riskingServiceImage = "registry:5000/risking-service-java:v0.0.31-5-g9dfa94f-SNAPSHOT-CREP-367";
//        String rabbitMqImage = "risking-service:test";

        DockerClient client = dockerSupport.getDockerClient();
        client.pull(riskingServiceImage);

        Map<String, String> environmentVariables = new HashMap<>();

        Map<String, String> propertyOverrides = new HashMap<>();
        propertyOverrides.put("risk-service.jms.rabbit.host", "10.102.83.154");
        propertyOverrides.put("risk-service.jms.rabbit.port", "13013");
//        propertyOverrides.put("risk-service.redis.host", "172.18.0.1");

        ContainerCreation container = client.createContainer(

                ContainerConfig.builder()
                        .image(riskingServiceImage)
                        .env("risk-service.jms.rabbit.host=10.102.83.154","risk-service.jms.rabbit.port=13013")
                        .build()
//                DockerSupport.getDockerClient().ContainerCreationConfig.builder()
//                        .sourceImage(rabbitMqImage)
//                        .extraHosts(Arrays.asList(
//                                new DockerSupport.HostFileEntry("myhost1", "127.0.0.1"),
//                                new DockerSupport.HostFileEntry("myhost2", "127.0.0.2")
//                        ))
//                        .environmentVariables(environmentVariables)
//                        .springPropertyOverrides(propertyOverrides)
//                        .build()
        );


        client.startContainer(container.id());

    }

    @Test
    public void testContainerCreate() {
        dockerSupport.testCreate();
    }
}
