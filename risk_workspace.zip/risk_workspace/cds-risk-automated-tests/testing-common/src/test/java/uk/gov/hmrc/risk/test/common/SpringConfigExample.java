//package uk.gov.hmrc.risk.test.common;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.rabbitmq.jms.admin.RMQConnectionFactory;
//import com.rabbitmq.jms.admin.RMQDestination;
//import lombok.SneakyThrows;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.data.redis.connection.RedisConnectionFactory;
//import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
//import org.springframework.data.redis.core.RedisTemplate;
//import org.springframework.data.redis.serializer.GenericToStringSerializer;
//import org.springframework.data.redis.serializer.StringRedisSerializer;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.jdbc.datasource.DriverManagerDataSource;
//import org.springframework.jms.core.JmsTemplate;
//import uk.gov.hmrc.risk.test.common.dao.DataTableDao;
//import uk.gov.hmrc.risk.test.common.dao.RuleDao;
//import uk.gov.hmrc.risk.test.common.service.*;
//import uk.gov.hmrc.risk.test.common.service.DataTableSupport.DataTableSupportConfig;
//import uk.gov.hmrc.risk.test.common.service.DockerSupport.DockerSupportConfig;
//import uk.gov.hmrc.risk.test.common.service.LocationsSupport.LocationsSupportConfig;
//import uk.gov.hmrc.risk.test.common.service.QueueAccessor.QueueConfiguration;
//import uk.gov.hmrc.risk.test.common.service.QueueAccessor.QueueConfiguration.QueueConfigurationBuilder;
//import uk.gov.hmrc.risk.test.common.service.RiskingServiceSupport.RiskingServiceSupportConfig;
//import uk.gov.hmrc.risk.test.common.service.RulesManagementServiceSupport.RulesManagementServiceSupportConfig;
//import uk.gov.hmrc.risk.test.common.service.RulesSupport.RulesSupportConfig;
//import uk.gov.hmrc.risk.test.common.service.declarationSupport.DeclarationSupport;
//import uk.gov.hmrc.risk.test.common.service.sharedstate.RedisSharedStateSupport;
//import uk.gov.hmrc.risk.test.common.service.sharedstate.RedisSharedStateSupport.RedisSharedStateSupportConfig;
//
//import javax.jms.ConnectionFactory;
//import javax.jms.Destination;
//
///**
// * Created by James Philipps on 12/04/17.
// */
//@Configuration
//public class SpringConfigExample {
//
//    @Value("${}")
//    private String rulesDbUrl;
//    @Value("${}")
//    private String rulesDbUser;
//    @Value("${}")
//    private String rulesDbPassword;
//
//    @Value("${}")
//    private String dataDbUrl;
//    @Value("${}")
//    private String dataDbUser;
//    @Value("${}")
//    private String dataDbPassword;
//
//
//    @Value("${}")
//    private String locationsUrl;
//    @Value("${}")
//    private String loginUrl;
//    @Value("${}")
//    private String createRuleUrl;
//    @Value("${}")
//    private String regimeCodesUrl;
//    @Value("${}")
//    private String sensitivityLevelsUrl;
//    @Value("${}")
//    private String dataTablesUrl;
//    @Value("${}")
//    private String riskingServiceTestTimeUrl;
//    @Value("${}")
//    private String riskingServiceTestSubmitDeclarationUrl;
//
//    @Value("${}")
//    private String jmsHost;
//    @Value("${}")
//    private int jmsPort;
//    @Value("${}")
//    private int jmsManagementPort;
//    @Value("${}")
//    private String jmsVirtualHost;
//    @Value("${}")
//    private String jmsUser;
//    @Value("${}")
//    private String jmsPassword;
//    @Value("${}")
//    private String jmsInQueueName;
//    @Value("${}")
//    private String jmsOutQueueName;
//    @Value("${}")
//    private String jmsExchangeName;
//    @Value("${}")
//    private int jmsMessageReceiveTimeoutSeconds;
//
//    @Value("${}")
//    private String redisHost;
//
//    @Value("${}")
//    private String dockerHost;
//    @Value("${}")
//    private int dockerPortPrefix;
//
//    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//    //////////////////////////////////////// BEGIN DAO STUFF ///////////////////////////////////////////////////////////
//    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//    @Bean
//    public RuleDao ruleDao() {
//        return new RuleDao(new JdbcTemplate(
//                new DriverManagerDataSource(rulesDbUrl, rulesDbUser, rulesDbPassword)
//        ));
//    }
//
//    @Bean
//    public DataTableDao dataTableDao() {
//        return new DataTableDao(new JdbcTemplate(
//                new DriverManagerDataSource(dataDbUrl, dataDbUser, dataDbPassword)
//        ));
//    }
//
//
//    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//    //////////////////////////////////////// BEGIN SUPPORT CLASSES STUFF ///////////////////////////////////////////////
//    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//    @Bean
//    public RestSupport restSupport(ObjectMapper jsonMapper) {
//        return new RestSupport(jsonMapper);
//    }
//
//    @Bean
//    public DockerSupport dockerSupport() {
//        DockerSupportConfig dockerSupportConfig = DockerSupportConfig.builder()
//                .host(dockerHost)
//                .portPrefix(dockerPortPrefix)
//                .containerStopForceTimeSeconds(10)
//                .build();
//        return new DockerSupport(dockerSupportConfig);
//    }
//
//    @Bean
//    public LocationsSupport locationsSupport(RestSupport restSupport) {
//        LocationsSupportConfig config = LocationsSupportConfig.builder()
//                .locationsUrl(locationsUrl)
//                .build();
//        return new LocationsSupport(restSupport, config);
//    }
//
//    @Bean
//    public RulesManagementServiceSupport userSupport(RestSupport restSupport, ObjectMapper jsonMapper) {
//        RulesManagementServiceSupportConfig config = RulesManagementServiceSupportConfig.builder()
//                .loginUrl(loginUrl)
//                .build();
//        return new RulesManagementServiceSupport(restSupport, jsonMapper, config);
//    }
//
//
//    @Bean
//    public RulesSupport rulesSupport(RestSupport restSupport, RuleDao ruleDao, ObjectMapper jsonMapper) {
//        RulesSupportConfig config = RulesSupportConfig.builder()
//                .createRuleUrl(createRuleUrl)
//                .regimeCodesUrl(regimeCodesUrl)
//                .sensitivityLevelsUrl(sensitivityLevelsUrl)
//                .build();
//        return new RulesSupport(restSupport, ruleDao, jsonMapper, config);
//    }
//
//    @Bean
//    public DataTableSupport dataTableSupport(RestSupport restSupport, DataTableDao dataTableDao, ObjectMapper jsonMapper) {
//        DataTableSupportConfig config = DataTableSupportConfig.builder()
//                .dataTablesUrl(dataTablesUrl)
//                .build();
//        return new DataTableSupport(restSupport, dataTableDao, jsonMapper, config);
//    }
//
//    @Bean
//    public DeclarationSupport declarationCreationSupport() {
//        return new DeclarationSupport();
//    }
//
//    @Bean
//    public RedisSharedStateSupport sharedStateSupport(RedisTemplate redisTemplate) {
//        RedisSharedStateSupportConfig config = RedisSharedStateSupportConfig.builder()
//                .redisTemplate(redisTemplate)
//                .build();
//        return new RedisSharedStateSupport(config);
//    }
//
//    @Bean
//    @SneakyThrows
//    public RiskingServiceSupport riskingServiceSupport(RestSupport restSupport, ObjectMapper jsonMapper) {
//        RiskingServiceSupportConfig config = RiskingServiceSupportConfig.builder()
//                .timeUrl(riskingServiceTestTimeUrl)
//                .submitDeclarationUrl(riskingServiceTestSubmitDeclarationUrl)
//                .build();
//
//        return new RiskingServiceSupport(
//                restSupport,
//                jsonMapper,
//                config
//        );
//    }
//
//
//    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//    /////////////////////////////////////////// BEGIN SUPPORT STUFF ////////////////////////////////////////////////////
//    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//    @Bean
//    public ObjectMapper jsonMapper() {
//        return new ObjectMapper();
//    }
//
//    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//    ////////////////////////./////////////////////// BEGIN JMS STUFF ///////////////////////////////////////////////////
//    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//    @Bean
//    public ConnectionFactory connectionFactory() {
//        final int ONE_SECOND_MS = 1000;
//
//        RMQConnectionFactory connectionFactory = new RMQConnectionFactory();
//        connectionFactory.setUsername(jmsUser);
//        connectionFactory.setPassword(jmsPassword);
//        connectionFactory.setVirtualHost(jmsVirtualHost);
//        connectionFactory.setHost(jmsHost);
//        connectionFactory.setPort(jmsPort);
//        connectionFactory.setOnMessageTimeoutMs(jmsMessageReceiveTimeoutSeconds * ONE_SECOND_MS);
//        return connectionFactory;
//    }
//
//    @Bean
//    @Qualifier("inboundDestination")
//    public Destination inboundDestination() {
//        return createDestination(jmsInQueueName);
//    }
//
//    @Bean
//    @Qualifier("outboundDestination")
//    public Destination outboundDestination() {
//        return createDestination(jmsOutQueueName);
//    }
//
//    private Destination createDestination(String queueName) {
//        RMQDestination dest = new RMQDestination();
//        dest.setDestinationName(queueName);
//
//        dest.setAmqp(true);
//        dest.setAmqpQueueName(queueName);
//        dest.setAmqpExchangeName(jmsExchangeName);
//        dest.setAmqpRoutingKey(queueName);
//
//        return dest;
//    }
//
//    @Bean
//    public JmsTemplate sendingJmsTemplate(ConnectionFactory connectionFactory, Destination inboundDestination) {
//        JmsTemplate template = new JmsTemplate(connectionFactory);
//        template.setDefaultDestination(inboundDestination);
//        return template;
//    }
//
//    @Bean
//    public JmsTemplate receivingJmsTemplate(ConnectionFactory connectionFactory, Destination outboundDestination) {
//        JmsTemplate template = new JmsTemplate(connectionFactory);
//        template.setDefaultDestination(outboundDestination);
//        template.setReceiveTimeout(10000);
//        return template;
//    }
//
//    @Bean
//    public QueueAccessor sendingQueueAccessor(RestSupport restSupport, JmsTemplate sendingJmsTemplate) {
//        QueueConfiguration queueConfig = baseQueueAccessorConfigurationBuilder()
//                .name(jmsInQueueName)
//                .build();
//        return new QueueAccessor(restSupport, sendingJmsTemplate, queueConfig);
//    }
//
//    @Bean
//    public QueueAccessor receivingQueueAccessor(RestSupport restSupport, JmsTemplate receivingJmsTemplate) {
//        QueueConfiguration queueConfig = baseQueueAccessorConfigurationBuilder()
//                .name(jmsOutQueueName)
//                .build();
//        return new QueueAccessor(restSupport, receivingJmsTemplate, queueConfig);
//    }
//
//    private QueueConfigurationBuilder baseQueueAccessorConfigurationBuilder() {
//        QueueConfigurationBuilder queueConfigurationBuilder = QueueConfiguration.builder()
//                .host(jmsHost)
//                .port(jmsPort)
//                .managementPort(jmsManagementPort)
//                .virtualHost(jmsVirtualHost)
//                .user(jmsUser)
//                .password(jmsPassword);
//        return queueConfigurationBuilder;
//    }
//
//
//    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//    ///////////////////////////////////// BEGIN SHARED STATE STUFF /////////////////////////////////////////////////////
//    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//    @Bean
//    public RedisConnectionFactory redisConnectionFactory() {
//        JedisConnectionFactory factory = new JedisConnectionFactory();
//        factory.setConvertPipelineAndTxResults(false);
//        factory.setHostName(redisHost);
//        return factory;
//    }
//
//    @Bean
//    public RedisTemplate redisTemplate(RedisConnectionFactory redisConnectionFactory) {
//        RedisTemplate template = new RedisTemplate();
//        template.setConnectionFactory(redisConnectionFactory);
//        template.setValueSerializer(new GenericToStringSerializer<>(Long.class));
//        template.setKeySerializer(new StringRedisSerializer());
//        return template;
//    }
//}
