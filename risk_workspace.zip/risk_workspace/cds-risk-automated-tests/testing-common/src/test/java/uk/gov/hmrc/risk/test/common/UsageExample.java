package uk.gov.hmrc.risk.test.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.jms.admin.RMQConnectionFactory;
import com.rabbitmq.jms.admin.RMQDestination;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jms.core.JmsTemplate;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel.RuleDefinition;
import uk.gov.hmrc.risk.rulesengine.rules.RuleMetadata;
import uk.gov.hmrc.risk.test.common.dao.DataTableDao;
import uk.gov.hmrc.risk.test.common.dao.DataTableDao.DataType;
import uk.gov.hmrc.risk.test.common.dao.RuleDao;
import uk.gov.hmrc.risk.test.common.enums.*;
import uk.gov.hmrc.risk.test.common.model.dataService.DataTableCreationModel;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleCreationModel;
import uk.gov.hmrc.risk.test.common.service.*;
import uk.gov.hmrc.risk.test.common.service.DataTableSupport.DataTableSupportConfig;
import uk.gov.hmrc.risk.test.common.service.LocationsSupport.LocationsSupportConfig;
import uk.gov.hmrc.risk.test.common.service.PublishSupport.PublishServiceConfig;
import uk.gov.hmrc.risk.test.common.service.QueueAccessor.QueueConfiguration.QueueConfigurationBuilder;
import uk.gov.hmrc.risk.test.common.service.RiskingServiceSupport.RiskingServiceSupportConfig;
import uk.gov.hmrc.risk.test.common.service.RiskingServiceSupport.RiskingSystemTime;
import uk.gov.hmrc.risk.test.common.service.RulesManagementServiceSupport.RulesManagementServiceSupportConfig;
import uk.gov.hmrc.risk.test.common.service.RulesSupport.RulesSupportConfig;
import uk.gov.hmrc.risk.test.common.service.declarationSupport.DeclarationSupport;
import uk.gov.hmrc.risk.test.common.service.sharedstate.RedisSharedStateSupport;

import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import java.util.*;

import static uk.gov.hmrc.risk.test.common.model.rulesService.RuleDefinitionConstants.*;
import static uk.gov.hmrc.risk.test.common.service.sharedstate.RedisSharedStateSupport.RedisSharedStateSupportConfig;

/**
 * Created by James Philipps on 12/04/17.
 */
@Slf4j
public class UsageExample {

    private static String ENV_HOST = "10.102.104.117";
    private static String PORT_PREFIX = "122";

    private static RuleDefinitionModel ruleDefinitionModel = defaultModel();

    private static String DEFINITION() {
        Condition dispatchCountry = Condition.builder()
                .source(Source.declaration)
                .matcherClass(MatcherClass.Matchers)
                .attribute(HeaderAttribute.DISPATCH_COUNTRY)
                .matcher(Matcher.equalTo)
                .value("DE")
                .build();
        ruleDefinitionModel.getRuleDefinitions().clear();
        RuleDefinition def = RuleDefinition.builder().build();
        def.setName("ExampleRule");
        def.addMetadata(RuleMetadata.UNIQUE_ID, UUID.randomUUID().toString());
        def.setWhenDef(declarationWrapper(
                strCheck( dispatchCountry )
        ));
        def.setThenDef(thenCreator(Source.declaration, conditions( dispatchCountry ))
            );
        ruleDefinitionModel.getRuleDefinitions().add(def);
        return ruleDefinitionModel.toString();
    }


    public static void main(String[] args) {
        new UsageExample().run();
    }

    ObjectMapper jsonMapper;

    RuleDao ruleDao;
    DataTableDao dataTableDao;

    RestSupport restSupport;
    RulesSupport rulesSupport;
    LocationsSupport locationsSupport;
    DataTableSupport dataTableSupport;
    RiskingServiceSupport riskingServiceSupport;
    RulesManagementServiceSupport rulesManagementSupport;
    DeclarationSupport declarationCreationSupport;
    RedisSharedStateSupport redisSharedStateSupport;
    PublishSupport publishSupport;
    DockerSupport dockerSupport;

    QueueAccessor inQueueAccessor;
    QueueAccessor outQueueAccessor;

    public void run() {
        init();

//        riskingServiceSupportExample();
        ruleCreationExample();
//        dataTableCreationExample();
//        queueAccessExample();
//        declarationCreationExample();
//        publishExample();
    }

    private void dockerSupportExample() {
        List<DockerSupport.ContainerAccessor> runningContainers = dockerSupport.getAllContainers(true);
        DockerSupport.ContainerAccessor firstContainer = runningContainers.get(0);

        System.out.println(firstContainer.getName());

        firstContainer.stop();
        System.out.println(firstContainer.getState());

        firstContainer.start();
        firstContainer.checkConnectivity(20);
        System.out.println(firstContainer.getState());
    }

    private void riskingServiceSupportExample() {
        RiskingSystemTime firstTime = riskingServiceSupport.getTime();
        riskingServiceSupport.setTime(5, 11, 2011, 10, 48, 32);
        RiskingSystemTime secondTime = riskingServiceSupport.getTime();
        riskingServiceSupport.useRealSystemTime();
        RiskingSystemTime thirdTime = riskingServiceSupport.getTime();

        String responseXml = riskingServiceSupport.submitDeclarationViaHttp("<xml></xml>");
    }

    private void dataTableCreationExample() {
        String loginToken = rulesManagementSupport.loginAsUser("1234561");
        Map<String, String> locations = locationsSupport.getLocations();
        List<DataType> dataTypes = dataTableSupport.getDataTypes();

        DataTableCreationModel dataTableCreationModel = DataTableCreationModel.builder()
                .tableName("Test Table")
                .description("My Test Table")
                .userPid("1234561")
                .dataTypeUuid(dataTypes.get(0).getUuid())
                .creationShareType("owner")
//                .locationUuids(Arrays.asList(locations.get("MAN")))
                .build();

        dataTableSupport.deleteDataTables();
        dataTableSupport.createDataTable(dataTableCreationModel, Arrays.asList("Entry1", "Entry2"));
    }

    @SneakyThrows
    private void publishExample() {
        publishSupport.sendPublishRequest();
        Thread.sleep(2000);
        publishSupport.getPublishEvent(20);
    }

    private void ruleCreationExample() {
        String loginToken = rulesManagementSupport.loginAsUser("1234560");
        Map<String, String> locations = locationsSupport.getLocations();
        Map<String, String> regimeCodes = rulesSupport.getRegimeCodes();

        String startDateTime = "2016-07-13T06:15:17Z";

        rulesSupport.createActiveRule(
            RuleCreationModel.builder()
                .description("My Rule")
                .definition(DEFINITION())
                .creatorPid("1234560")
                .ruleType("national")
                .regimeCodeUuid(regimeCodes.get("ADD"))
                .locationUuids(Collections.singletonList(locations.get("national")))
                .reason("Default test reason")
                .json(
                        RuleCreationModel.JsonContainer.builder()
                                .valid(true)
                                .description("My Rule")
                                .route("2")
                                .startDateTime(startDateTime)
                                .regimeUuid(regimeCodes.get("ADD"))
                                .query(Arrays.asList(
                                        RuleCreationModel.QueryContainerJson.builder()
                                                .operator("and")
                                                .query(Arrays.asList(
                                                        RuleCreationModel.QueryJson.builder()
                                                                .attribute("commodityCode")
                                                                .operator("eq")
                                                                .value("1234567890")
                                                                .build()
                                                ))
                                                .build()
                                ))
                                .behaviours(Arrays.asList(
                                        RuleCreationModel.BehaviourContainer.builder()
                                                .behaviourType(RuleBehaviourType.DEFAULT)
                                                .narrative("Default narrative")
                                                .controlType("3")
                                                .build(),
                                        RuleCreationModel.BehaviourContainer.builder()
                                                .behaviourType(RuleBehaviourType.PRE_CLEARANCE)
                                                .narrative("Pre clearance Narrative")
                                                .controlType("1")
                                                .build(),
                                        RuleCreationModel.BehaviourContainer.builder()
                                                .behaviourType(RuleBehaviourType.POST_CLEARANCE)
                                                .narrative("Post clearance Narrative")
                                                .controlType("2")
                                                .build()
                                ))
                                .build()
                )
            .build(), "1234561");
    }

    private void queueAccessExample() {
        inQueueAccessor.send("HELLO WORLD");
        String inMsg = inQueueAccessor.receive();

        outQueueAccessor.send("BYE WORLD");
        String outMsg = outQueueAccessor.receive();

        System.out.println();
    }

    private void declarationCreationExample() {
        String template = declarationCreationSupport.getDefaultDeclarationTemplate();

        declarationCreationSupport.getAvailableReplacementTokens(template).stream().forEach(System.out::println);

        Map<DeclarationParam, String> tokens = new HashMap<>();
        tokens.put(HeaderDeclarationParam.DECLARATION_REFERENCE, "MY-ID");
        tokens.put(HeaderDeclarationParam.ORIGIN_COUNTRY, "UK");

        System.out.println(declarationCreationSupport.createDeclaration(template, tokens));
    }

    @SneakyThrows
    private void init() {
        jsonMapper = new ObjectMapper();
        jsonMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

        restSupport = new RestSupport(jsonMapper);

        ruleDao = new RuleDao(new JdbcTemplate(
                new DriverManagerDataSource("jdbc:mysql://" + ENV_HOST + ":" + PORT_PREFIX + "56/rules", "rules", "rulespw")
        ));

        dataTableDao = new DataTableDao(new JdbcTemplate(
                new DriverManagerDataSource("jdbc:mysql://" + ENV_HOST + ":" + PORT_PREFIX + "56/data", "data", "datapw")
        ));

        RedisTemplate redisTemplate = new RedisTemplate();
        RedisSharedStateSupportConfig redisSharedStateSupportConfig = RedisSharedStateSupportConfig.builder()
                .redisTemplate(redisTemplate)
                .build();
        redisSharedStateSupport = new RedisSharedStateSupport(redisSharedStateSupportConfig);

        RulesSupportConfig rulesSupportConfig = RulesSupportConfig.builder()
                .createRuleUrl("http://" + ENV_HOST + ":" + PORT_PREFIX + "05/rule")
                .createRuleUrl2("http://" + ENV_HOST + ":" + PORT_PREFIX + "05/rule2")
                .regimeCodesUrl("http://" + ENV_HOST + ":" + PORT_PREFIX + "05/regimeCodes")
                .sensitivityLevelsUrl("http://" + ENV_HOST + ":" + PORT_PREFIX + "05/sensitivityLevels")
                .build();
        rulesSupport = new RulesSupport(restSupport, ruleDao, jsonMapper, rulesSupportConfig);

        RulesManagementServiceSupportConfig userSupportConfig = RulesManagementServiceSupportConfig.builder()
                .loginUrl("http://" + ENV_HOST + ":" + PORT_PREFIX + "03/login")
                .build();
        rulesManagementSupport = new RulesManagementServiceSupport(restSupport, jsonMapper, userSupportConfig);

        LocationsSupportConfig locationsSupportConfig = LocationsSupportConfig.builder()
                .locationsUrl("http://" + ENV_HOST + ":" + PORT_PREFIX + "07/locations")
                .build();
        locationsSupport = new LocationsSupport(restSupport, locationsSupportConfig);

        DataTableSupportConfig dataTableSupportConfig = DataTableSupportConfig.builder()
                .dataTablesUrl("http://" + ENV_HOST + ":" + PORT_PREFIX + "08/datatables")
                .build();
        dataTableSupport = new DataTableSupport(restSupport, dataTableDao, jsonMapper, dataTableSupportConfig);

        PublishServiceConfig publishSupportConfig = PublishServiceConfig.builder()
                .publishRequestUrl("http://" + ENV_HOST + ":" + PORT_PREFIX + "14/publish")
                .changePublishIntervalUrl("http://" + ENV_HOST + ":" + PORT_PREFIX + "14/change-publish-interval")
                .build();
        PublishEventSubscriber subscriber = new PublishEventSubscriber(jsonMapper);

        publishSupport = new PublishSupport(restSupport, jsonMapper, publishSupportConfig, subscriber, null); // null should be a rabbit template

        RiskingServiceSupportConfig testAccessSupportConfig = RiskingServiceSupportConfig.builder()
                .timeUrl("http://localhost:8080/test/time")
                .submitDeclarationUrl("http://localhost:8080/test/submit-declaration")
                .build();
        riskingServiceSupport = new RiskingServiceSupport(
                restSupport,
                jsonMapper,
                testAccessSupportConfig
        );

        DockerSupport.DockerSupportConfig dockerSupportConfig = DockerSupport.DockerSupportConfig.builder()
                .host("localhost")
                .containerStopForceTimeSeconds(10)
                .build();
        dockerSupport = new DockerSupport(dockerSupportConfig);

        declarationCreationSupport = new DeclarationSupport();

        QueueConfigurationBuilder queueConfigurationBuilder = QueueAccessor.QueueConfiguration.builder()
                .host("127.0.0.1")
                .port(5672)
                .managementPort(15672)
                .virtualHost("/")
                .user("guest")
                .password("guest");

        ConnectionFactory queueConnectionFactory = queueConnectionFactory(queueConfigurationBuilder.build());

        JmsTemplate inJmsTemplate = new JmsTemplate(queueConnectionFactory);
        inJmsTemplate.setDefaultDestination(createDestination("risk.service.declarations.in"));
        inQueueAccessor = new QueueAccessor(restSupport, inJmsTemplate,
                queueConfigurationBuilder.name("risk.service.declarations.in").build()
        );

        JmsTemplate outJmsTemplate = new JmsTemplate(queueConnectionFactory);
        outJmsTemplate.setDefaultDestination(createDestination("risk.service.declarations.out"));
        outQueueAccessor = new QueueAccessor(restSupport, outJmsTemplate,
                queueConfigurationBuilder.name("risk.service.declarations.out").build()
        );
    }


    private static Destination createDestination(String queueName) {
        RMQDestination dest = new RMQDestination();
        dest.setDestinationName(queueName);

        dest.setAmqp(true);
        dest.setAmqpQueueName(queueName);
        dest.setAmqpExchangeName(queueName);
        dest.setAmqpRoutingKey(queueName);

        return dest;
    }

    private static ConnectionFactory queueConnectionFactory(QueueAccessor.QueueConfiguration queueConfiguration) {
        RMQConnectionFactory connectionFactory = new RMQConnectionFactory();
        connectionFactory.setUsername(queueConfiguration.getUser());
        connectionFactory.setPassword(queueConfiguration.getPassword());
        connectionFactory.setVirtualHost(queueConfiguration.getVirtualHost());
        connectionFactory.setHost(queueConfiguration.getHost());
        connectionFactory.setPort(queueConfiguration.getPort());
        connectionFactory.setOnMessageTimeoutMs(1000);
        return connectionFactory;
    }
}
