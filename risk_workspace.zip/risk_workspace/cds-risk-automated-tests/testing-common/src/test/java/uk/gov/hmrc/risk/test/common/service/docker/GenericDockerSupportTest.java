//package uk.gov.hmrc.risk.test.common.service.docker;
//
//import com.spotify.docker.client.DockerClient;
//import com.spotify.docker.client.messages.Container;
//import com.spotify.docker.client.messages.ContainerConfig;
//import com.spotify.docker.client.messages.ContainerCreation;
//import lombok.SneakyThrows;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.ArgumentCaptor;
//import org.mockito.Mock;
//import org.mockito.internal.util.reflection.Whitebox;
//import org.mockito.runners.MockitoJUnitRunner;
//import uk.gov.hmrc.risk.test.common.service.docker.GenericDockerSupport.ContainerCreationConfig;
//
//import java.lang.reflect.InvocationTargetException;
//import java.lang.reflect.Method;
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.Optional;
//import java.util.stream.Collectors;
//
//import static org.mockito.Matchers.any;
//import static org.mockito.Matchers.eq;
//import static org.mockito.Mockito.doReturn;
//import static org.mockito.Mockito.doThrow;
//import static org.mockito.Mockito.mock;
//import static org.mockito.Mockito.verify;
//
///**
// * Created by James Philipps on 07/08/17.
// */
//@RunWith(MockitoJUnitRunner.class)
//public class GenericDockerSupportTest {
//    private final static int CONTAINER_STOP_TIME = 7;
//
//    @Mock
//    DockerClientProvider dockerClientProvider;
//    @Mock
//    DockerClient dockerClient;
//
//    GenericDockerSupport dockerSupport;
//
//    @Test
//    public void dockerClient_initialisedWithLocalDaemonSocket_WhenHostIsLocalhost() {
//        initDockerSupport("localhost");
//        initDockerClientProvider();
//        invokeDockerClientMethod();
//
//        verify(dockerClientProvider).newClient("unix:///var/run/docker.sock");
//    }
//
//    @Test
//    public void dockerClient_initialisedWithLocalDaemonSocket_WhenHostIsLocalhostIp() {
//        initDockerSupport("127.0.0.1");
//        initDockerClientProvider();
//        invokeDockerClientMethod();
//
//        verify(dockerClientProvider).newClient("unix:///var/run/docker.sock");
//    }
//
//    @Test
//    public void dockerClient_initialisedWithRemoteConnectionUri_WhenHostIsHostname() {
//        initDockerSupport("my-host");
//        initDockerClientProvider();
//        invokeDockerClientMethod();
//
//        verify(dockerClientProvider).newClient("http://my-host:2375");
//    }
//
//    @Test
//    public void dockerClient_initialisedWithRemoteConnectionUri_WhenHostIsIp() {
//        initDockerSupport("my-host");
//        initDockerClientProvider();
//        invokeDockerClientMethod();
//
//        verify(dockerClientProvider).newClient("http://my-host:2375");
//    }
//
//    @Test(expected = IllegalArgumentException.class)
//    public void dockerClient_initialisationThrowsIllegalArgumentException_WhenClientIsNull() {
//        initDockerSupport("my-host");
//
//        doReturn(null).when(dockerClientProvider).newClient(any());
//
//        invokeDockerClientMethod();
//    }
//
//    @Test(expected = IllegalArgumentException.class)
//    public void dockerClient_initialisationThrowsIllegalArgumentException_WhenClientCreationThrowsException() {
//        initDockerSupport("my-host");
//
//        doThrow(new RuntimeException()).when(dockerClientProvider).newClient(any());
//
//        invokeDockerClientMethod();
//    }
//
//    @Test
//    public void getContainers_createsDockerClient_WhenNotInitialised() {
//        initDockerSupport("my-host");
//        initDockerClientProvider();
//
//        dockerSupport.getContainers();
//
//        verify(dockerClientProvider).newClient(any());
//    }
//
//    @Test
//    @SneakyThrows
//    public void getContainers_invokesContainerListingForAllContainers() {
//        initDockerSupport("my-host");
//        initDockerClientProvider();
//
//
//        dockerSupport.getContainers();
//        verify(dockerClient).listContainers(DockerClient.ListContainersParam.allContainers());
//    }
//
//    @Test
//    @SneakyThrows
//    public void getContainers_mapsContainerListingToAccessors() {
//        initDockerSupport("my-host");
//        initDockerClientProvider();
//
//        Container c1 = mock(Container.class);
//        Container c2 = mock(Container.class);
//
//        doReturn(Arrays.asList(c1, c2)).when(dockerClient).listContainers(any());
//
//        List<ContainerAccessor> containers = dockerSupport.getContainers().getContainers();
//
////        assertThat(containers.size()).isEqualTo(2);
////
////        ContainerAccessor ca1 = containers.get(0);
////        assertThat(Whitebox.getInternalState(ca1, "dockerClient")).isEqualTo(dockerClient);
////        assertThat(Whitebox.getInternalState(ca1, "container")).isEqualTo(c1);
////
////        ContainerAccessor ca2 = containers.get(1);
////        assertThat(Whitebox.getInternalState(ca2, "dockerClient")).isEqualTo(dockerClient);
////        assertThat(Whitebox.getInternalState(ca2, "container")).isEqualTo(c2);
//    }
//
//    @Test
//    public void pull_createsDockerClient_WhenNotInitialised() {
//        initDockerSupport("my-host");
//        initDockerClientProvider();
//
//        dockerSupport.pull("my-registry", "my-image", "v1.0");
//
//        verify(dockerClientProvider).newClient(any());
//    }
//
//    @Test
//    @SneakyThrows
//    public void pull_invokesDockerClientPull() {
//        initDockerSupport("my-host");
//        initDockerClientProvider();
//
//        dockerSupport.pull("my-registry", "my-image", "v1.0");
//
//        verify(dockerClient).pull("my-registry/my-image:v1.0");
//    }
//
//    @Test
//    public void pullSingleImageArg_createsDockerClient_WhenNotInitialised() {
//        initDockerSupport("my-host");
//        initDockerClientProvider();
//
//        dockerSupport.pull("my-registry:my-image:v1.0");
//
//        verify(dockerClientProvider).newClient(any());
//    }
//
//    @Test
//    @SneakyThrows
//    public void pullSingleImageArg_invokesDockerClientPull() {
//        initDockerSupport("my-host");
//        initDockerClientProvider();
//
//        dockerSupport.pull("my-registry/my-image:v1.0");
//
//        verify(dockerClient).pull("my-registry/my-image:v1.0");
//    }
//
//    @Test
//    @SneakyThrows
//    public void createContainer_createsDockerClient_WhenNotInitialised() {
//        initDockerSupport("my-host");
//        initDockerClientProvider();
//
//        doReturn(containerCreation()).when(dockerClient).createContainer(any(ContainerConfig.class));
//
//        dockerSupport.createContainer(ContainerCreationConfig.builder()
//                .sourceImage("image1")
//                .build()
//        );
//
//        verify(dockerClientProvider).newClient(any());
//    }
//
//    @Test
//    @SneakyThrows
//    public void createContainer_invokesCorrectCreationMethod_WhenNameNotSpecified() {
//        initDockerSupport("my-host");
//        initDockerClientProvider();
//
//        doReturn(containerCreation()).when(dockerClient).createContainer(any());
//
//        dockerSupport.createContainer(ContainerCreationConfig.builder()
//                .sourceImage("image1")
//                .build()
//        );
//
//        verify(dockerClient).createContainer(any());
//    }
//
//    @Test
//    @SneakyThrows
//    public void createContainer_returnsIdOfCreatedContainer() {
//        initDockerSupport("my-host");
//        initDockerClientProvider();
//
//        doReturn(containerCreation()).when(dockerClient).createContainer(any());
//
//        String id = dockerSupport.createContainer(ContainerCreationConfig.builder()
//                .sourceImage("image1")
//                .build()
//        );
//
////        assertThat(id).isEqualTo("1234");
//    }
//
//    @Test
//    @SneakyThrows
//    public void createContainer_invokesCorrectCreationMethod_WhenNameSpecified() {
//        initDockerSupport("my-host");
//        initDockerClientProvider();
//
//        doReturn(containerCreation()).when(dockerClient).createContainer(any(), any());
//
//        dockerSupport.createContainer(ContainerCreationConfig.builder()
//                .sourceImage("image1")
//                .name("my-name")
//                .build()
//        );
//
//        verify(dockerClient).createContainer(any(), eq("my-name"));
//    }
//
//    @Test
//    @SneakyThrows
//    public void createContainer_setsSpringEnvVariable_WhenSpringPropertiesSpecified() {
//        initDockerSupport("my-host");
//        initDockerClientProvider();
//
//        doReturn(containerCreation()).when(dockerClient).createContainer(any());
//
//        Map<String, String> springProps = new HashMap<>();
//        springProps.put("P1", "FOO");
//        springProps.put("P2", "BAR");
//
//        dockerSupport.createContainer(ContainerCreationConfig.builder()
//                .sourceImage("image1")
//                .springPropertyOverrides(springProps)
//                .build()
//        );
//
//        ContainerConfig config = captureContainerCreationConfig();
//
//        String SPRING_JSON_VAR_NAME = "SPRING_APPLICATION_JSON";
//        Optional<String> springJson = config.env().stream()
//                .filter(v -> v.startsWith(SPRING_JSON_VAR_NAME))
//                .map(v -> v.substring(SPRING_JSON_VAR_NAME.length() + 1))
//                .findFirst();
//
////        assertThat(springJson.isPresent()).isTrue();
////
////        Map<String, String> jsonProps = new ObjectMapper().readValue(springJson.get(), Map.class);
////        assertThat(jsonProps).containsKeys(springProps.keySet().toArray(new String[0]));
////        assertThat(jsonProps.get("P1")).isEqualTo("FOO");
////        assertThat(jsonProps.get("P2")).isEqualTo("BAR");
//    }
//
//    @Test
//    @SneakyThrows
//    public void createContainer_setsEnvVariables_WhenEnvVariablesSpecified() {
//        initDockerSupport("my-host");
//        initDockerClientProvider();
//
//        doReturn(containerCreation()).when(dockerClient).createContainer(any());
//
//        Map<String, String> envProps = new HashMap<>();
//        envProps.put("P1", "FOO");
//        envProps.put("P2", "BAR");
//
//        dockerSupport.createContainer(ContainerCreationConfig.builder()
//                .sourceImage("image1")
//                .environmentVariables(envProps)
//                .build()
//        );
//
//        ContainerConfig config = captureContainerCreationConfig();
//
//        Map<String, String> resultEnv = config.env().stream()
//                .map(v -> v.split("="))
//                .collect(Collectors.toMap(s -> s[0], s -> s[1]));
//
////        assertThat(resultEnv).containsKeys(envProps.keySet().toArray(new String[0]));
////        assertThat(resultEnv.get("P1")).isEqualTo("FOO");
////        assertThat(resultEnv.get("P2")).isEqualTo("BAR");
//    }
//
//    @Test
//    @SneakyThrows
//    public void createContainer_setsExtraHosts_WhenExtraHostsSpecified() {
//        initDockerSupport("my-host");
//        initDockerClientProvider();
//
//        doReturn(containerCreation()).when(dockerClient).createContainer(any());
//
////        Map<String, String> envProps = new HashMap<>();
////        envProps.put("P1", "FOO");
////        envProps.put("P2", "BAR");
//
//        List<GenericDockerSupport.HostFileEntry> extraHosts = Arrays.asList(
//                new GenericDockerSupport.HostFileEntry("h1", "127.0.0.1"),
//                new GenericDockerSupport.HostFileEntry("h2", "127.0.0.2")
//        );
//        List<String> extraHostsAsString = extraHosts.stream()
//                .map(GenericDockerSupport.HostFileEntry::toEntry)
//                .collect(Collectors.toList());
//
//        dockerSupport.createContainer(ContainerCreationConfig.builder()
//                .sourceImage("image1")
//                .extraHosts(extraHosts)
//                .build()
//        );
//
//        ContainerConfig config = captureContainerCreationConfig();
////        assertThat(config.hostConfig().extraHosts())
////                .containsExactlyInAnyOrder(extraHostsAsString.toArray(new String[0]));
//    }
//
//    @SneakyThrows
//    private ContainerConfig captureContainerCreationConfig() {
//        ArgumentCaptor<ContainerConfig> configCaptor = ArgumentCaptor.forClass(ContainerConfig.class);
//        verify(dockerClient).createContainer(configCaptor.capture());
//        return configCaptor.getValue();
//    }
//
//    private ContainerCreation containerCreation() {
//        ContainerCreation cc = mock(ContainerCreation.class);
//        doReturn("1234").when(cc).id();
//        return cc;
//    }
//
//    @Test(expected = IllegalArgumentException.class)
//    public void createContainer_throwsIllegalArgumentException_WhenNoImageSpecified() {
//        initDockerSupport("my-host");
//        initDockerClientProvider();
//
//        dockerSupport.createContainer(ContainerCreationConfig.builder().build());
//    }
//
//    private void initDockerClientProvider() {
//        doReturn(dockerClient).when(dockerClientProvider).newClient(any());
//    }
//
//    private void initDockerSupport(String host) {
//        dockerSupport = new GenericDockerSupport(
//                GenericDockerSupport.DockerSupportConfig.builder()
//                        .dockerClientProvider(dockerClientProvider)
//                        .host(host)
//                        .containerStopForceTimeSeconds(CONTAINER_STOP_TIME)
//                        .build()
//        );
//    }
//
//    @SneakyThrows
//    private DockerClient getDockerClient() {
//        return (DockerClient) Whitebox.getInternalState(dockerSupport, "dockerClient");
//    }
//
//    @SneakyThrows
//    private void invokeDockerClientMethod() {
//        Method m = GenericDockerSupport.class.getDeclaredMethod("getDockerClient", null);
//        boolean accessible = m.isAccessible();
//        m.setAccessible(true);
//        try {
//            m.invoke(dockerSupport);
//        } catch (InvocationTargetException e) {
//            // If an exception is thrown internally, throw it up the chain for tests that expect exceptions
//            if (e.getCause() != null) {
//                throw e.getCause();
//            } else {
//                throw e;
//            }
//        }
//        m.setAccessible(accessible);
//    }
//
//}
