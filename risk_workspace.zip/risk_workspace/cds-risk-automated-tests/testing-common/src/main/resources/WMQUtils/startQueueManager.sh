runmqsc < /tmp/clearQueues.sh > /tmp/runmqmcResult.txt
