runmqsc < clearQueues.sh
