package uk.gov.hmrc.risk.test.common.enums;

import lombok.AllArgsConstructor;

/**
 * Created by developer on 31/08/17.
 */
@AllArgsConstructor
public enum GoodsItemDeclarationParam implements DeclarationParam {

    METHOD_OF_PAYMENT("methodOfPayment"),
    PREFERENCE("preferenceCode"),
    STATISTICAL_AMOUNT("statisticalAmount"),
    INVOICE_PRICE("invoicePrice"),

    PREVIOUS_PROCEDURE("prevCpc"),
    REQUESTED_PROCEDURE("reqCpc"),
    SPECIAL_PROCEDURE("specialCpc"),

    SEQUENCE_NUMBER("sequence"),
    SUPERVISING_OFFICE_EORI("supervisingOfficeEori"),

    SUBROLE("subrole"),     //subrole blank or any value except 2, use 2 when country of origin is preferential country of origin
    PREFERENTIAL_ORIGIN_COUNTRY("originCountry_Item"),


    DISPATCH_COUNTRY("dispatchCountry_Item"),
    ORIGIN_COUNTRY("originCountry_Item"),
    DESTINATION_COUNTRY("destinationCountry_Item"),

    DECLARED_DUTY_TAX_FEES_TYPE("declaredDutyTaxFeesType"),                         //Tax Type Code
    DECLARED_DUTY_TAX_FEES_AD_VALOREM_BASE("declaredDutyTaxFeesAdVarloremBase"),    //base amount
    DECLARED_DUTY_TAX_FEES_BASE_QUANTITY("declaredDutyTaxFeesBaseQuantity"),        //base quantity
    DECLARED_DUTY_TAX_FEES_BASE_RATE("declaredDutyTaxFeesRate"),                    //percentage adjustment
    DECLARED_DUTY_TAX_FEES_TOTAL_AMOUNT("declaredDutyTaxFeesTotalAmount"),          //Tax amount
    DECLARED_DUTY_TAX_FEES_PAYABLE_AMOUNT("declaredDutyTaxFeesPayableAmount"),      //Tax Revenue

    DECLARED_CUSTOMS_VALUE("declaredCustomsValue"),

    CUSTOMS_VALUE("customsValue"),

    COMMODITY_DESCRIPTION("goodsDescription"),
    COMMODITY_CODE("commodityCode"),
    COMMODITY_GROSS_MASS("grossMass"),
    COMMODITY_NET_MASS("netMass"),
    COMMODITY_SUPPLEMENTARY_UNITS("supplementaryUnits"),

    UN_DANGEROUS_GOODS_CODE("unDangerousGoodsCode"),    //commodity classification = SSO identifier

    CONSIGNEE_ADDRESS_ITEM("consigneeAddress_Item"),
    CONSIGNEE_CITY_ITEM("consigneeCity_Item"),
    CONSIGNEE_COUNTRY_ITEM("consigneeCountry_Item"),
    CONSIGNEE_EORI_ITEM("consigneeEori_Item"),
    CONSIGNEE_NAME_ITEM("consigneeName_Item"),
    CONSIGNEE_POSTCODE_ITEM("consigneePostcode_Item"),


    ADDITIONAL_COM_CODE("additionalCommodityCode"),
    ADDITIONAL_COM_CODE2("additionalCommodityCode2"),
    ADDITIONAL_INFO_TEXT_LANGUAGE("additionalInfoTextLanguage"),
    CONTAINER_NUMBER("containerNumber"),
    DOCUMENT_QUANTITY("documentQuantity"),
    PREV_DOC_CLASS("previousDocumentClass"),
    PREV_DOC_ID("previousDocumentId"),
    PREV_DOC_TYPE("previousDocumentType"),
    VALUATION_METHOD_CODE("valuationMethodCode"),
    QUOTO_CODE("quotaCode"),

    BUYER_ADDRESS_ITEM("buyerAddress_Item"),
    BUYER_CITY_ITEM("buyerCity_Item"),
    BUYER_COUNTRY_ITEM("buyerCountryCode_Item"),
    BUYER_ID_ITEM("buyerId_Item"),
    BUYER_NAME_ITEM("buyerName_Item"),
    BUYER_POSTCODE_ITEM("buyerPostcode_Item"),

    SELLER_ADDRESS_ITEM("sellerAddress_Item"),
    SELLER_CITY_ITEM("sellerCity_Item"),
    SELLER_COUNTRY_ITEM("sellerCountryCode_Item"),
    SELLER_ID_ITEM("sellerId_Item"),
    SELLER_NAME_ITEM("sellerName_Item"),
    SELLER_POSTCODE_ITEM("sellerPostcode_Item"),

    CONSIGNORADDRESS_ITEM("consignorAddress_Item"),
    CONSIGNORCITY_ITEM("consignorCity_Item"),
    CONSIGNORCOUNTRY_ITEM("consignorCountry_Item"),
    CONSIGNOREORI_ITEM("consignorEori_Item"),
    CONSIGNORNAME_ITEM("consignorName_Item"),
    CONSIGNORPOSTCODE_ITEM("consignorPostcode_Item"),

    CUS_COMMODITY_CODE_ITEM("cusCommodityCode"),
    COUNTRY_GROUP_OF_ORIGIN_ITEM("originCountryGroup"),

    VALUATION_INDICATOR("valuationIndicator");

    private String paramText;

    @Override
    public String toString() {
        return paramText;
    }

    @AllArgsConstructor
    public enum Second implements DeclarationParam {

        METHOD_OF_PAYMENT("methodOfPayment2"),
        PREFERENCE("preferenceCode2"),
        STATISTICAL_AMOUNT("statisticalAmount2"),
        INVOICE_AMOUNT("invoiceAmount2"),

        PREVIOUS_PROCEDURE("prevCpc2"),
        REQUESTED_PROCEDURE("reqCpc2"),

        SEQUENCE_NUMBER("sequence2"),

        PACKAGING_MARKS_NUMBER("packageMarksNumbers2"),
        PACKAGING_QUANTITY("packageCount_Item2"),
        PACKAGING_TYPE("packageType2"),

        ADDITIONAL_DOCUMENTS_IDENTIFIER("additionalDocumentsIdentifier2"),

        DISPATCH_COUNTRY("dispatchCountry_Item2"),
        ORIGIN_COUNTRY("originCountry_Item2"),
        DESTINATION_COUNTRY("destinationCountry_Item2"),

        ADDITIONAL_INFO_CODE("additionalInfoCode_Item2"),
        ADDITIONAL_INFO_TEXT("additionalInfoText_Item2"),

        DECLARED_DUTY_TAX_FEES_TYPE("declaredDutyTaxFeesType2"),                         //Tax Type Code
        DECLARED_DUTY_TAX_FEES_AD_VALOREM_BASE("declaredDutyTaxFeesAdVarloremBase2"),    //base amount
        DECLARED_DUTY_TAX_FEES_BASE_QUANTITY("declaredDutyTaxFeesBaseQuantity2"),        //base quantity
        DECLARED_DUTY_TAX_FEES_BASE_RATE("declaredDutyTaxFeesRate2"),                    //percentage adjustment
        DECLARED_DUTY_TAX_FEES_TOTAL_AMOUNT("declaredDutyTaxFeesTotalAmount2"),          //Tax amount
        DECLARED_DUTY_TAX_FEES_PAYABLE_AMOUNT("declaredDutyTaxFeesPayableAmount2"),      //Tax Revenue

        CUSTOMS_VALUE("customsValue2"),
        DECLARED_CUSTOMS_VALUE("declaredCustomsValue2"),

        COMMODITY_DESCRIPTION("goodsDescription2"),
        COMMODITY_CODE("commodityCode2"),
        COMMODITY_GROSS_MASS("grossMass2"),
        COMMODITY_NET_MASS("netMass2"),
        COMMODITY_SUPPLEMENTARY_UNITS("supplementaryUnits2"),

        CONSIGNOR_NAME("consignorName_Item2"),
        CONSIGNOR_ADDRESS_COUNTRY("consignorCountry_Item2"),
        CONSIGNOR_ADDRESS_CITY("consignorCity_Item2"),
        CONSIGNOR_ADDRESS_STREET("consignorAddress_Item2"),
        CONSIGNOR_ADDRESS_ZIPCODE("consignorPostcode_Item2"),
        CONSIGNOR_EORI("consignorEori_Item2");

        private String paramText;

        @Override
        public String toString() {
            return paramText;
        }
    }

    @AllArgsConstructor
    public enum Third implements DeclarationParam {

        METHOD_OF_PAYMENT("methodOfPayment3"),
        PREFERENCE("preferenceCode3"),
        STATISTICAL_AMOUNT("statisticalAmount3"),
        INVOICE_AMOUNT("invoiceAmount3"),

        PREVIOUS_PROCEDURE("prevCpc3"),
        REQUESTED_PROCEDURE("reqCpc3"),

        SEQUENCE_NUMBER("sequence3"),

        PACKAGING_MARKS_NUMBER("packageMarksNumbers3"),
        PACKAGING_QUANTITY("packageCount_Item3"),
        PACKAGING_TYPE("packageType3"),

        ADDITIONAL_DOCUMENTS_IDENTIFIER("additionalDocumentsIdentifier3"),

        DISPATCH_COUNTRY("dispatchCountry_Item3"),
        ORIGIN_COUNTRY("originCountry_Item3"),
        DESTINATION_COUNTRY("destinationCountry_Item3"),

        ADDITIONAL_INFO_CODE("additionalInfoCode_Item3"),
        ADDITIONAL_INFO_TEXT("additionalInfoText_Item3"),

        DECLARED_DUTY_TAX_FEES_TYPE("declaredDutyTaxFeesType3"),                         //Tax Type Code
        DECLARED_DUTY_TAX_FEES_AD_VALOREM_BASE("declaredDutyTaxFeesAdVarloremBase3"),    //base amount
        DECLARED_DUTY_TAX_FEES_BASE_QUANTITY("declaredDutyTaxFeesBaseQuantity3"),        //base quantity
        DECLARED_DUTY_TAX_FEES_BASE_RATE("declaredDutyTaxFeesRate3"),                    //percentage adjustment
        DECLARED_DUTY_TAX_FEES_TOTAL_AMOUNT("declaredDutyTaxFeesTotalAmount3"),          //Tax amount
        DECLARED_DUTY_TAX_FEES_PAYABLE_AMOUNT("declaredDutyTaxFeesPayableAmount3"),      //Tax Revenue

        CUSTOMS_VALUE("customsValue3"),
        DECLARED_CUSTOMS_VALUE("declaredCustomsValue3"),

        COMMODITY_DESCRIPTION("goodsDescription3"),
        COMMODITY_CODE("commodityCode3"),
        COMMODITY_GROSS_MASS("grossMass3"),
        COMMODITY_NET_MASS("netMass3"),
        COMMODITY_SUPPLEMENTARY_UNITS("supplementaryUnits3"),

        CONSIGNOR_NAME("consignorName_Item3"),
        CONSIGNOR_ADDRESS_COUNTRY("consignorCountry_Item3"),
        CONSIGNOR_ADDRESS_CITY("consignorCity_Item3"),
        CONSIGNOR_ADDRESS_STREET("consignorAddress_Item3"),
        CONSIGNOR_ADDRESS_ZIPCODE("consignorPostcode_Item3"),
        CONSIGNOR_EORI("consignorEori_Item3");

        private String paramText;

        @Override
        public String toString() {
            return paramText;
        }
    }

    @AllArgsConstructor
    public enum Fourth implements DeclarationParam {
        METHOD_OF_PAYMENT("methodOfPayment4"),
        PREFERENCE("preferenceCode4"),
        STATISTICAL_AMOUNT("statisticalAmount4"),
        INVOICE_AMOUNT("invoiceAmount4"),

        PREVIOUS_PROCEDURE("prevCpc4"),
        REQUESTED_PROCEDURE("reqCpc4"),

        SEQUENCE_NUMBER("sequence4"),

        PACKAGING_MARKS_NUMBER("packageMarksNumbers4"),
        PACKAGING_QUANTITY("packageCount_Item4"),
        PACKAGING_TYPE("packageType4"),

        ADDITIONAL_DOCUMENTS_IDENTIFIER("additionalDocumentsIdentifier4"),

        DISPATCH_COUNTRY("dispatchCountry_Item4"),
        ORIGIN_COUNTRY("originCountry_Item4"),
        DESTINATION_COUNTRY("destinationCountry_Item4"),

        ADDITIONAL_INFO_CODE("additionalInfoCode_Item4"),
        ADDITIONAL_INFO_TEXT("additionalInfoText_Item4"),

        DECLARED_DUTY_TAX_FEES_TYPE("declaredDutyTaxFeesType4"),                         //Tax Type Code
        DECLARED_DUTY_TAX_FEES_AD_VALOREM_BASE("declaredDutyTaxFeesAdVarloremBase4"),    //base amount
        DECLARED_DUTY_TAX_FEES_BASE_QUANTITY("declaredDutyTaxFeesBaseQuantity4"),        //base quantity
        DECLARED_DUTY_TAX_FEES_BASE_RATE("declaredDutyTaxFeesRate4"),                    //percentage adjustment
        DECLARED_DUTY_TAX_FEES_TOTAL_AMOUNT("declaredDutyTaxFeesTotalAmount4"),          //Tax amount
        DECLARED_DUTY_TAX_FEES_PAYABLE_AMOUNT("declaredDutyTaxFeesPayableAmount4"),      //Tax Revenue

        CUSTOMS_VALUE("customsValue4"),
        DECLARED_CUSTOMS_VALUE("declaredCustomsValue4"),

        COMMODITY_DESCRIPTION("goodsDescription4"),
        COMMODITY_CODE("commodityCode4"),
        COMMODITY_GROSS_MASS("grossMass4"),
        COMMODITY_NET_MASS("netMass4"),
        COMMODITY_SUPPLEMENTARY_UNITS("supplementaryUnits4"),

        CONSIGNOR_NAME("consignorName_Item4"),
        CONSIGNOR_ADDRESS_COUNTRY("consignorCountry_Item4"),
        CONSIGNOR_ADDRESS_CITY("consignorCity_Item4"),
        CONSIGNOR_ADDRESS_STREET("consignorAddress_Item4"),
        CONSIGNOR_ADDRESS_ZIPCODE("consignorPostcode_Item4"),
        CONSIGNOR_EORI("consignorEori_Item4");

        private String paramText;

        @Override
        public String toString() {
            return paramText;
        }
    }
}
