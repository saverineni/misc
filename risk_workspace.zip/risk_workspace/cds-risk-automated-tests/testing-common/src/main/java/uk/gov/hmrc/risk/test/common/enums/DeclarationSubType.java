package uk.gov.hmrc.risk.test.common.enums;

/**
 * Created by developer on 17/10/17.
 */
public enum DeclarationSubType {
    A, B, C, D, E, F, X, Y, Z
}
