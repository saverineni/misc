package uk.gov.hmrc.risk.test.common.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum ItemAttribute implements Attribute{
    CPC("cpc"),
    COMMODITY_CODE("commodityCode"),
    DESTINATION_COUNTRY("destinationCountry"),
    DISPATCH_COUNTRY("dispatchCountry"),
    PACKAGE_COUNT("packageCount"),
    GROSS_MASS("grossMass"),
    NET_MASS("netMass"),
//    DANGEROUS_GOODS_CODE("dangerousGoodsCode"),  //This goods item attribute doesn't exist in the UI, template or anywhere. Possibly removed
    DOCUMENT_IDENTIFIER("documentIdentifier"),
    CUSTOMS_VALUE("customsValue"),
    INVOICE_PRICE("invoicePrice"),
    PAYMENT_METHOD("paymentMethod"),
    STATISTICAL_VALUE("statisticalValue"),
    TAX_RATE_CODE("taxRateCode"),
    CONSIGNOR_NAME("consignorName"),
    CONSIGNOR_EORI("consignorEori"),
    CONSIGNOR_ADDRESS("consignorAddress"),
    CONSIGNOR_CITY("consignorCity"),
    CONSIGNOR_COUNTRY("consignorCountry"),
    CONSIGNOR_POSTCODE("consignorPostcode"),
    ORIGIN_COUNTRY("originCountry"),
    ORIGIN_COUNTRY_GROUP("originCountryGroup");

    public final String method;

    @Override
    public String toString() {
        return method;
    }
}
