package uk.gov.hmrc.risk.test.common.model.darService;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;

@Builder
@Data
public class DarDeclarationRiskedModel{

    private String type;
    private String eventTime;
    private String responseId;
    private String declarationId;
    private String declarationVersion;
    private String rulesPackage;
    private String numberOfResults;

    public static DarDeclarationRiskedModel create(String[] line) {
        return new DarDeclarationRiskedModel(
                line[0],          // type
                line[1],          // timestamp
                line[2],          // responseId
                line[3],          // declarationId
                line[4],          // declaration version
                line[5],          // rules package
                line[6]);         // count of risk results
    }

    private DarDeclarationRiskedModel(String type, String eventTime, String responseId,
                                     String declarationId, String declarationVersion,
                                     String rulesPackage, String numberOfResults) {
        this.type = type;
        this.eventTime = eventTime;
        this.responseId = responseId;
        this.declarationId = declarationId;
        this.declarationVersion = declarationVersion;
        this.rulesPackage = rulesPackage;
        this.numberOfResults = numberOfResults;
    }
}
