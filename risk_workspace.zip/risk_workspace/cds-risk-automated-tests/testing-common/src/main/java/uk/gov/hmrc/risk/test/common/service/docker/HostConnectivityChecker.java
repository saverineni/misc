package uk.gov.hmrc.risk.test.common.service.docker;

/**
 * Created by James Philipps on 08/08/17.
 */
public interface HostConnectivityChecker {
    boolean canConnect(String host, int port);
}
