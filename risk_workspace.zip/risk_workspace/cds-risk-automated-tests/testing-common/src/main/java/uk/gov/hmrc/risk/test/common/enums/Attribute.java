package uk.gov.hmrc.risk.test.common.enums;

public interface Attribute {

    @Override
    public String toString();
}
