package uk.gov.hmrc.risk.test.common.enums;

/**
 * Created by developer on 16/10/17.
 */
public enum Operator {

    and,
    or,
    eq,
    neq,
    con,
    nco,
    st,
    nst,
    matchesPattern,
    notMatchesPattern,
    lt,
    gt,
    lte,
    gte;
}
