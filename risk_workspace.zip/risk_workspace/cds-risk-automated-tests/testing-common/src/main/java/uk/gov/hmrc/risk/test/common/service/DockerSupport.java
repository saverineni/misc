package uk.gov.hmrc.risk.test.common.service;

import com.spotify.docker.client.DefaultDockerClient;
import com.spotify.docker.client.DockerClient;
import com.spotify.docker.client.DockerClient.ListContainersParam;
import com.spotify.docker.client.LogStream;
import com.spotify.docker.client.messages.*;
import com.spotify.docker.client.messages.Container.PortMapping;
import lombok.*;
import lombok.Builder.Default;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.net.Socket;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by James Philipps on 15/06/17.
 */
@Slf4j
public class DockerSupport {

    @RequiredArgsConstructor
    public enum ContainerState {
        RUNNING("running"),
        EXITED("exited"),
        UNKNOWN("UNKNOWN");

        private final String value;

        public static ContainerState fromString(String s) {
            return Arrays.asList(values()).stream()
                    .filter(v -> v.value.equalsIgnoreCase(s.trim()))
                    .findFirst().orElse(UNKNOWN);
        }
    }

    private final DockerSupportConfig config;

    private DockerClient dockerClient;

    public DockerSupport(DockerSupportConfig config) {
        this.config = config;
        this.dockerClient = getDockerClient();

    }

    /**
     * Bad but working implementation... the api implies its really easy to stream into and out of a container BUT it isnt
     * so scripts are used to do the same thing at least initially.
     *
     * 1. copies script files to container,
     * 2. makes them accessible,
     * 3. executes them in the container (one invokes the other and writes out to another file)
     * 4. read the output file and check for IBM errors
     * @param containerId
     * @throws Exception
     */


    @SneakyThrows
    public void emptyWMQ_Queues(String containerId) {
        String[] commands = new String[]{
                "bash","-l","-c", "/usr/local/bin/ExecuteClearQueues.sh"

        };

        DockerClient.ExecCreateParam param = DockerClient.ExecCreateParam.tty(true);
        DockerClient.ExecCreateParam param3 = DockerClient.ExecCreateParam.attachStdout();
        ExecCreation execCreation = dockerClient.execCreate(containerId, commands, param, param3);
        LogStream logStream = dockerClient.execStart(execCreation.id());

        String execOutput = logStream.readFully();
        log.info("EXEC output: " + execOutput);

//        int successCount = countOccurrencesInContainerFile(containerId,"/tmp/runmqmcResult.txt",
//                MQ_CLEARED.getCode(),MQ_ALREADY_EMPTY.getCode());

//        if(successCount != 2){
//            throw new RuntimeException(
//                    "Failed to empty queues on WMQ expected 2 queues to be cleared but was " + successCount);
//        }
    }

    public int countOccurrencesInContainerFile(String containerId, String fullFileName, String... tokens) throws Exception {

        String  output = readFileInContainer(containerId, fullFileName);
        log.info("instances in file result: " + output);
        int totalCount = 0;
        for (String s : tokens) {
            totalCount += StringUtils.countMatches(
                    output,
                    s);
        }

        return totalCount;

    }

    public String readFileInContainer(String containerId, String fullFileName) throws Exception {
        ExecCreation creation = dockerClient.execCreate(containerId,
                new String[]{"bash", "-c", "cat " + fullFileName },
                new DockerClient.ExecCreateParam[]{
                        DockerClient.ExecCreateParam.attachStdout()
                }
        );

        final LogStream output = dockerClient.execStart(creation.id());
        return output.readFully();
    }

    @SneakyThrows
    public void makeFileAccessible(String containerId, String fileName){
        String[] commands = new String[]{
                "chmod","777",fileName
        };

        DockerClient.ExecCreateParam param = DockerClient.ExecCreateParam.tty(false);

        ExecCreation execCreation = dockerClient.execCreate(containerId, commands, param);
        dockerClient.execStart(execCreation.id());
    }

    public boolean isLocalhost() {
        Set<String> localhostUris = new HashSet<>(Arrays.asList("localhost", "127.0.0.1"));
        return localhostUris.contains(config.getHost().trim().toLowerCase());
    }

    public Optional<ContainerAccessor> findByPort(List<ContainerAccessor> containers, int port) {
        return isLocalhost() ?
                findByPort(containers, null, port) :
                findByPort(containers, config.getPortPrefix(), port);
    }

    public Optional<ContainerAccessor> findByPort(List<ContainerAccessor> containers, Integer portPrefix, int port) {
        Integer fullPort = portPrefix != null ?
                Integer.parseInt(Integer.toString(portPrefix) + Integer.toString(port)) :
                port;

        log.debug("Attempting find by port. portPrefix={}, port={}, fullPort={}", portPrefix, port, fullPort);

        return containers.stream()
                .filter(c -> c.getPublicPorts().contains(fullPort))
                .findFirst();
    }

    @SneakyThrows
    public void copyFileToContainer(Path filePath, String containerId, String pathInContainer) {
        dockerClient.copyToContainer(filePath, containerId, pathInContainer);
    }

    public List<ContainerAccessor> getAllContainers(boolean runningOnly) {
        return getContainers(Optional.empty(), runningOnly);
    }

    public DockerClient getClient() {
        return dockerClient;
    }

    public List<ContainerAccessor> getCurrentEnvironmentContainers(boolean runningOnly) {
        return isLocalhost() ?
                getContainers(Optional.empty(), runningOnly) :
                getPortPrefixedContainers(config.getPortPrefix(), runningOnly);
    }

    public List<ContainerAccessor> getPortPrefixedContainers(int portPrefix, boolean runningOnly) {
        return getContainers(Optional.of(new Integer(portPrefix).toString()), runningOnly);
    }

    @SneakyThrows
    private List<ContainerAccessor> getContainers(Optional<String> portPrefix, boolean runningOnly) {
        Set<ListContainersParam> params = new HashSet<>();
        if (!runningOnly) {
            log.debug("Including stopped containers in listing..");
            params.add(ListContainersParam.allContainers());
        }

        DockerClient dockerClient = getDockerClient();
        System.out.println("Using docker client: " + dockerClient.toString());
        List<Container> containers = dockerClient
                .listContainers(params.toArray(new ListContainersParam[0]));
        return containers.stream()
                .filter(c -> portPrefix.isPresent() ? allPortsStartWith(c, portPrefix.get()) : true)
                .map(ContainerAccessor::new)
                .collect(Collectors.toList());
    }

    private boolean allPortsStartWith(Container c, String prefix) {
        return c.ports().stream()
                .map(p -> p.publicPort().toString().startsWith(prefix) || p.publicPort() == 0)
                .reduce(true, (acc, p) -> acc && p);
    }

    @SneakyThrows
    public DockerClient getDockerClient() {
        if (dockerClient == null) {
            List<String> potentialHostUris = new ArrayList<>();
            if (isLocalhost()) {
                // Attempt a socket connection to the local daemon first
                potentialHostUris.add("unix:///var/run/docker.sock");
            }
            // Attempt a connection via the docker remote protocol
            potentialHostUris.add(String.format("http://%s:2375", config.getHost()));

            for (String uri : potentialHostUris) {
                log.info("Attempting to create DockerClient using URI: '{}'", uri);
                try {
                    dockerClient = new DefaultDockerClient.Builder()
                            .readTimeoutMillis(360000)
                            .connectTimeoutMillis(360000)
                            .uri(uri)
                            .build();

                            log.info("Created a DockerClient using URI: {}", uri);
                    System.out.println("Created a DockerClient using URI: " + uri + ": hascode: " + dockerClient.toString());
                    break;
                } catch (Exception e) {
                    log.warn("Failed to create DockerClient using uri: '{}'", uri);
                    log.debug("", e);
                }
            }
            if (dockerClient == null) {
                throw new IllegalArgumentException("Unable to create a DockerClient using provided host parameter!");
            }
        }
        return dockerClient;
    }

    public ContainerAccessor getRiskingServiceContainer() {
        return getContainerByName("riskingServiceJava");
    }

    public ContainerAccessor getDARClientAuditContainer() {
        return getContainerByName("darClient");
    }

    public ContainerAccessor getAuditServiceContainer() {
        return getContainerByName("auditService");
    }

    public ContainerAccessor getDARClientPublishingContainer() {
        return getContainerByName("darClient");
    }

    public ContainerAccessor getAssigneeServiceContainer() { return getContainerByName("caseAssigneeService"); }

    private ContainerAccessor getContainerByName(String name) {
        List<ContainerAccessor> containers =  getCurrentEnvironmentContainers(true);

        for (ContainerAccessor container: containers) {
            if (container.getName().contains(name)) {
                return container;
            }
        }
        return null;
    }

    public List<ContainerAccessor> getAllRiskingServiceContainers() {
        return getContainersByName("riskingServiceJava");
    }

    private List<ContainerAccessor> getContainersByName(String name) {
        List<ContainerAccessor> all = getCurrentEnvironmentContainers(true);
        return all.stream().filter(
                ca -> ca.getName().contains(name)
        ).collect(Collectors.toList());
    }


    @AllArgsConstructor
    public class ContainerAccessor {

        private Container container;

        public String getId() {
            return container.id();
        }

        public String getShortId() { return container.id().substring(0,12); }

        public String getName() {
            refresh();
            return container.names().get(0);
        }

        public ContainerState getState() {
            refresh();
            return ContainerState.fromString(container.state());
        }

        public Set<Integer> getPublicPorts() {
            return container.ports().stream()
                    .filter(p -> p.publicPort() > 0)
                    .map(p -> p.publicPort())
                    .collect(Collectors.toSet());
        }

        @SneakyThrows
        public List<String> getFileContents(String internalFilePath){

            final String execOutput = executeBashCommand(
                    new String[]{"bash", "-c","cat " + internalFilePath}
            );

            return Arrays.asList(
                    execOutput.split(System.lineSeparator())
            );

        }

        public LocalDateTime getTime() {
            String time = this.executeBashCommand(new String[]{"bash", "-c", "date +\"%Y-%m-%d %T\""});
            return LocalDateTime.parse(time.replace(" ", "T").replace("\n", "").concat(".000"));
        }

        @SneakyThrows
        private String executeBashCommand(String[] command) {
            ExecCreation creation = dockerClient.execCreate(getId(),
                    command,
                    DockerClient.ExecCreateParam.attachStdout());

            final String execOutput = dockerClient
                    .execStart(creation.id())
                    .readFully();

            log.debug("output: "  + execOutput);
            return execOutput;
        }

        @SneakyThrows
        public void stop() {
            log.debug("Stopping container: {}", getId());
            if (getState() != ContainerState.RUNNING) {
                log.debug("Container not running. No action taken");
            } else {
                getDockerClient().stopContainer(getId(), config.getContainerStopForceTimeSeconds());
            }
        }

        @SneakyThrows
        public void remove() {
            log.debug("Removing container: {}", getId());
            stop();
            getDockerClient().removeContainer(getId());
        }

        @SneakyThrows
        public void start() {
            log.debug("Starting container: {}", getId());
            if (getState() == ContainerState.RUNNING) {
                log.debug("Container already running. No action taken");
            } else {
                getDockerClient().startContainer(getId());
            }
        }

        public boolean checkConnectivity(int timeoutSeconds) {
            final int BACKOFF_MS = 200;
            final long startTime = System.currentTimeMillis();

            // First, wait until container is in running state
            while (getState() != ContainerState.RUNNING && !timeoutExpired(startTime, timeoutSeconds)) {
                log.debug("Waiting for container to enter RUNNING state..");
                sleep(BACKOFF_MS);
            }

            if (getState() == ContainerState.RUNNING) {
                log.debug("Container entered RUNNING state");
                // If there are ports,
                if (container.ports().size() > 0) {
                    PortMapping portMapping = container.ports().get(0);
                    while (!timeoutExpired(startTime, timeoutSeconds)) {
                        try {
                            log.debug("Connectivity test for {}:{}..", config.getHost(), portMapping.publicPort());
                            new Socket(config.getHost(), portMapping.publicPort());
                            log.debug("Succeeded!");
                            return true;
                        } catch (IOException e) {
                            try {
                                log.debug("Failed. Backing off {}ms..");
                                Thread.sleep(BACKOFF_MS);
                            } catch (InterruptedException e1) {
                                log.error("", e1);
                            }
                        }
                    }
                } else {
                    log.debug("Connectivity test on a container with no ports. Assuming container is now up");
                    return true;
                }
            } else {
                log.warn("Container did not enter RUNNING state within the specified time!");
            }

            return false;
        }

        @SneakyThrows
        private void refresh() {
//            container = getDockerClient()
//                    .listContainers(ListContainersParam.allContainers()).stream()
//                    .filter(c -> c.id().equalsIgnoreCase(getId()))
//                    .findFirst()
//                    .orElseThrow(() -> new ContainerRefreshException(
//                            String.format("Container: %s seems to have vanished!", getId())
//                    ));
        }

        private boolean timeoutExpired(long startTime, int timeoutSeconds) {
            return System.currentTimeMillis() > startTime + (timeoutSeconds * 1000);
        }

        @SneakyThrows
        private void sleep(long amountMsg) {
            Thread.sleep(amountMsg);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            ContainerAccessor that = (ContainerAccessor) o;

            return container != null ? container.id().equals(that.container.id()) : that.container == null;

        }

        @Override
        public int hashCode() {
            return container != null ? container.id().hashCode() : 0;
        }

        @Override
        public String toString() {
            return String.format("ContainerAccessor{ id='%s', name='%s', state='%s' publicPorts='%s' }", getId(),
                    getName(), getState(), getPublicPorts());
        }
    }

    private class ContainerRefreshException extends RuntimeException {
        public ContainerRefreshException(String message) {
            super(message);
        }
    }

    @SneakyThrows
    public void pullImage(String imageNameAndVersion) {
        dockerClient.pull(imageNameAndVersion);
    }

    @SneakyThrows
    public ContainerCreation createContainer(String imageNameAndVersion, Map<String,String> appProperties, String containerName){
//        final DockerClient client = getDockerClient();

        Map<String, List<PortBinding>> portBidings = new HashMap<>();

        //Need to set logConfig if want to use docker logs [container name] command
        HostConfig hostConfig = HostConfig.builder()
                .logConfig(LogConfig.create("json-file"))
                .build();

        //Create container with environment
        ContainerConfig config = ContainerConfig.builder()
                .image(imageNameAndVersion)
                .env(appProperties.entrySet().stream()
                        .map(e -> String.format("%s=%s", e.getKey(), e.getValue()))
                        .collect(Collectors.toList())
                )
                .hostConfig(hostConfig)
                .build();

        ContainerAccessor containerAccessor = getContainerByName(containerName);

        if ( containerAccessor != null) {
            containerAccessor.remove();
        }

        log.info("Start container creation");
        ContainerCreation containerCreation = dockerClient.createContainer(config, containerName);
        log.info("Container created, starting");
        dockerClient.startContainer(containerCreation.id());
        return containerCreation;
    }

    @SneakyThrows
    public ContainerCreation testCreate(){

        // Create a client based on DOCKER_HOST and DOCKER_CERT_PATH env vars
        final DockerClient docker = getDockerClient();

// Pull an image
//        docker.pull("registry:5000/risking-service-java:v0.0.31-22-g836a586-SNAPSHOT-CREP-270_TestRulesAddedForPerformanceTests");

        // Bind container ports to host ports
        final String[] ports = {"45672"};
        final Map<String, List<PortBinding>> portBindings = new HashMap<>();
//        for (String port : ports) {
            List<PortBinding> hostPorts = new ArrayList<>();
            hostPorts.add(PortBinding.of("0.0.0.0", "45672"));
            portBindings.put("5672", hostPorts);
//        }

        final HostConfig hostConfig = HostConfig.builder().portBindings(portBindings).build();

// Create container with exposed ports
        final ContainerConfig containerConfig = ContainerConfig.builder()
                .hostConfig(hostConfig)
                .image("registry:5000/rabbitmq:3-management").exposedPorts(ports)
                .cmd("sh", "-c", "while :; do sleep 1; done")
                .build();

        final ContainerCreation creation = docker.createContainer(containerConfig);


        getDockerClient().startContainer(creation.id());
        return creation;
//        getDockerClient().pull("registry:5000/rabbitmq");
//        return getDockerClient().createContainer(
//                ContainerConfig.builder()
//                        .image("registry:5000/rabbitmq")
//                        .portSpecs("45672:5672","45671:5671","45674:15672")
//                        .build()
//        );
    }

    @Builder
    @Getter
    public static class DockerSupportConfig {
        String host;
        int portPrefix;
        @Default
        int containerStopForceTimeSeconds = 10;
    }
}
