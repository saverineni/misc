//package uk.gov.hmrc.risk.test.common.model.darService;
//
//import lombok.Data;
//
//import java.time.ZonedDateTime;
//import java.time.format.DateTimeFormatter;
//import java.time.format.DateTimeFormatterBuilder;
//import java.time.temporal.ChronoField;
//
//@Data
//public abstract class BaseDARModel {
//
//    protected String type;
//    protected ZonedDateTime eventTime;
//
//    public BaseDARModel(
//            String eventTime,
//            String type
//    ) {
//        String basePattern = "yyyy-MM-dd'T'HH:mm:ss";
//        DateTimeFormatter formatter =
//                new DateTimeFormatterBuilder().appendPattern(basePattern)
//                        .appendFraction(ChronoField.NANO_OF_SECOND, 0, 9, true)
//                        .appendZoneOrOffsetId()
//                        .toFormatter();
//        this.eventTime = ZonedDateTime.parse(eventTime, formatter);
//        this.type = type;
//    }
//}
