package uk.gov.hmrc.risk.test.common.model.darService;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class DarRuleLocationsModel {

    private String type, packageUuid, ruleUuid, ruleVersionId;
    private String locationUuid, locationName;

    public static DarRuleLocationsModel create(String[] line) {
        return new DarRuleLocationsModel(
                line[0],          // type
                line[1],          // packageUuid
                line[2],          // ruleUuid
                line[3],          // ruleVersionId
                line[4],          // locationUuid
                line[5]);         // locationName
    }

    private DarRuleLocationsModel(String type, String packageUuid, String ruleUuid, String ruleVersionId,
                                  String locationUuid, String locationName) {
        this.type = type;
        this.packageUuid = packageUuid;
        this.ruleUuid = ruleUuid;
        this.ruleVersionId = ruleVersionId;
        this.locationUuid = locationUuid;
        this.locationName = locationName;
    }
}
