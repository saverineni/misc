package uk.gov.hmrc.risk.test.common.model.darService;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class DarRuleDataTablesModel {

    private String type, packageUuid, ruleUuid, ruleVersionId;
    private String dataTableUuid, dataTableName;

    public static DarRuleDataTablesModel create(String[] line) {
        return new DarRuleDataTablesModel(
                line[0],          // type
                line[1],          // packageUuid
                line[2],          // ruleUuid
                line[3],          // ruleVersionId
                line[4],          // dataTableUuid
                line[5]);         // dataTableName
    }

    private DarRuleDataTablesModel(String type, String packageUuid, String ruleUuid, String ruleVersionId,
                                   String dataTableUuid, String dataTableName) {
        this.type = type;
        this.packageUuid = packageUuid;
        this.ruleUuid = ruleUuid;
        this.ruleVersionId = ruleVersionId;
        this.dataTableUuid = dataTableUuid;
        this.dataTableName = dataTableName;
    }
}
