package uk.gov.hmrc.risk.test.common.service;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class RestPageImpl<T> extends PageImpl<T>{

    @JsonCreator(mode = JsonCreator.Mode.PROPERTIES)
    public RestPageImpl(@JsonProperty("content") List<T> content,
                        @JsonProperty("number") int page,
                        @JsonProperty("totalPages") int totalpages,
                        @JsonProperty("numberOfElements") int numElements,
                        @JsonProperty("last") boolean last,
                        @JsonProperty("first") boolean first,
                        @JsonProperty("size") int size,
                        @JsonProperty("sort") List<Map<String,String>> sortOrders,
                        @JsonProperty("totalElements") long total) {
        super(content, new PageRequest(page, size, createSort(sortOrders)), total);
    }

    private static Sort createSort(List<Map<String, String>> sortOrders) {
        return Optional.ofNullable(sortOrders)
                .map(params -> params.stream().map(m -> new Sort.Order(Sort.Direction.fromStringOrNull(m.get("direction")), m.get("property")))
                        .collect(Collectors.collectingAndThen(Collectors.toList(), Sort::new)))
                .orElse(null);
    }

    public RestPageImpl(List<T> content, Pageable pageable, long total) {
        super(content, pageable, total);
    }

    public RestPageImpl(List<T> content) {
        super(content);
    }

    public RestPageImpl() {
        super(new ArrayList());
    }
}