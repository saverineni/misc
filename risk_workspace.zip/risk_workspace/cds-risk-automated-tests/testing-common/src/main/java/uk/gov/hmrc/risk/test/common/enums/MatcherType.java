package uk.gov.hmrc.risk.test.common.enums;


public enum MatcherType {

    EQUAL,
    CONTAINS,
    STARTS_WITH,
    MATCHES_PATTERN,
    LESS_THAN,
    LESS_THAN_EQUAL_TO,
    GREATER_THAN,
    GREATER_THAN_EQUAL_TO;
}
