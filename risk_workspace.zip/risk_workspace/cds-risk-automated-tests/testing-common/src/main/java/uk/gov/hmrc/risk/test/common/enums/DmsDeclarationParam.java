package uk.gov.hmrc.risk.test.common.enums;


public interface DmsDeclarationParam {

    @Override
    public String toString();
}
