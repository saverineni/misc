package uk.gov.hmrc.risk.test.common.model.dataService;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;

import java.util.List;

@Getter
@Builder
public class DataTableDetailsModel {

    private String uuid, tableName, description, dataTypeUuid, dataType, creatorPid, createdTimestamp, updaterPid;
    private String updatedTimestamp;
    private int version, opLockVersion;
    private List<String> dataItems;
    private List<Locations> locations;
    private List<Tags> tags;

    @Builder
    @Data
    public static class Locations {
        private String locationUuid, createdDate, shareType;
    }

    @Builder
    @Data
    public static class Tags {
        private String tagName, tagUuid;
    }
}
