package uk.gov.hmrc.risk.test.common.util;

import lombok.SneakyThrows;

import javax.jms.BytesMessage;
import javax.jms.Message;
import javax.jms.TextMessage;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

public class JmsUtils {

    @SneakyThrows
    public static String extractMessageBody(Message message) {
        if (BytesMessage.class.isAssignableFrom(message.getClass())) {
            return readBytesMessage((BytesMessage) message);
        }
        if (TextMessage.class.isAssignableFrom(message.getClass())) {
            return ((TextMessage) message).getText();
        }
        throw new IllegalArgumentException("Don't know how to extract message body from class: " +
                message.getClass().getName());
    }

    @SneakyThrows
    public static byte[] getMessageBytes(Message message) {
        if (BytesMessage.class.isAssignableFrom(message.getClass())) {
            return readBytes((BytesMessage) message);
        }
        if (TextMessage.class.isAssignableFrom(message.getClass())) {
            return readText((TextMessage) message);
        }
        throw new IllegalArgumentException("Don't know how to extract message body from class: " +
                message.getClass().getName());
    }

    @SneakyThrows
    private static String readBytesMessage(BytesMessage message) {

        return new String(readBytes(message), "UTF-8");
    }

    @SneakyThrows
    public static byte[] readBytes(BytesMessage message) {
        final int byteBufferSize = 16384;

        ByteArrayOutputStream buffer = new ByteArrayOutputStream();

        int nRead;
        byte[] data = new byte[byteBufferSize];

        while ((nRead = message.readBytes(data, byteBufferSize)) >= 0) {
            buffer.write(data, 0, nRead);
        }

        buffer.flush();
        return buffer.toByteArray();
    }

    @SneakyThrows
    public static byte[] readText(TextMessage message) {
        return message.getText().getBytes(StandardCharsets.UTF_8);
    }
}
