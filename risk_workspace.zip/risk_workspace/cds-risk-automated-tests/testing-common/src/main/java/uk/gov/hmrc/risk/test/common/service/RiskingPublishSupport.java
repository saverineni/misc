package uk.gov.hmrc.risk.test.common.service;

import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import uk.gov.hmrc.risk.test.common.model.publishService.PublishEventModel;

@Slf4j
@RequiredArgsConstructor
public class RiskingPublishSupport {

    private final PublishEventSubscriber publishEventSubscriber;

    public PublishEventModel getPublishEvent(int timeoutInSeconds) {
        return publishEventSubscriber.getPublishEvent(timeoutInSeconds);
    }

    public void forgetLastEvent() {
        publishEventSubscriber.forgetLastEvent();
    }

    @Builder
    @Getter
    public static class PublishServiceConfig {
        private String routingKey, exchangeName;
    }
}
