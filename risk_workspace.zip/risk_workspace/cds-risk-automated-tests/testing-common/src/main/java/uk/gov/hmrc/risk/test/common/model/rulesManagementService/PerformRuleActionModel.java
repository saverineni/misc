package uk.gov.hmrc.risk.test.common.model.rulesManagementService;

import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * Created by developer on 05/07/18.
 */
@Builder
@Data
public class PerformRuleActionModel {

    private List<String> ruleUuids;
    private String reason, action;
}

