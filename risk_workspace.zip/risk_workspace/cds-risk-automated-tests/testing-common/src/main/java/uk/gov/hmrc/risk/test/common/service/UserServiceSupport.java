package uk.gov.hmrc.risk.test.common.service;


import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import uk.gov.hmrc.risk.test.common.model.userService.CreateUserModel;
import uk.gov.hmrc.risk.test.common.model.userService.UsersModel;

import java.util.Map;

import static uk.gov.hmrc.risk.test.common.service.RestSupport.statusCode2xx;


@Slf4j
@RequiredArgsConstructor
public class UserServiceSupport {

    public static final String DEFAULT_PASSWORD = "Cd5RD0205";

    private final RestSupport restSupport;
    private final ObjectMapper jsonMapper;

    private final UserServiceSupportConfig config;

    public UsersModel getUsers() {

        Request request = Request.Get(config.getUsersUrl())
                .addHeader(RestSupport.AUTH_HEADER_NAME, config.getSuperAdminPid())
                ;
        return restSupport.getResponseAsJson(request, UsersModel.class, statusCode2xx());
    }

    @SneakyThrows
    public void createUser(CreateUserModel createUserModel) {

        UsersModel users = getUsers();
        if (users.getContent().stream().filter(
                content -> content.getPid().equals(createUserModel.getPid())
            ).count() == 0
        ) {

            log.info("Creating user");
            String json = jsonMapper.writeValueAsString(createUserModel);
            log.info("Json body: {}", json);

            Request request = Request.Post(config.getUsersUrl())
                    .bodyByteArray(json.getBytes(), ContentType.APPLICATION_JSON)
                    .addHeader(RestSupport.AUTH_HEADER_NAME, config.getSuperAdminPid());

            Map<String, String> response = restSupport.getResponseAsJson(request, Map.class, statusCode2xx());
        } else {
            log.info("User present. Moving on");
        }
    }

    @Builder
    @Getter
    public static class UserServiceSupportConfig {
        private String usersUrl, superAdminPid;
    }
}
