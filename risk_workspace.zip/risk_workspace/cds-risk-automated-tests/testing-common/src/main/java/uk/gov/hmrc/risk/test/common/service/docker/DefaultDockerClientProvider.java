package uk.gov.hmrc.risk.test.common.service.docker;

import com.spotify.docker.client.DefaultDockerClient;
import com.spotify.docker.client.DockerClient;

/**
 * Created by James Philipps on 07/08/17.
 */
public class DefaultDockerClientProvider implements DockerClientProvider{


    @Override
    public DockerClient newClient(String uri) {
        return new DefaultDockerClient(uri);
    }
}
