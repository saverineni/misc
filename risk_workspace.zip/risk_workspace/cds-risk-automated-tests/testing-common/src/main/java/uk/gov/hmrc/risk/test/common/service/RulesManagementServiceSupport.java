package uk.gov.hmrc.risk.test.common.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpEntity;
import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import uk.gov.hmrc.risk.test.common.enums.RuleActions;
import uk.gov.hmrc.risk.test.common.enums.RuleVersionActions;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.*;

import java.io.File;
import java.net.URL;
import java.nio.file.Paths;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateDataTableModel;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.CreateRuleModel;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.EditDataTableDetailsModel;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.EditDataTableItemsModel;
import uk.gov.hmrc.risk.test.common.model.rulesManagementService.PerformRuleActionModel;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static uk.gov.hmrc.risk.test.common.service.RestSupport.statusCode2xx;
import static uk.gov.hmrc.risk.test.common.service.RestSupport.statusCode4xx;

/**
 * Created by James Philipps on 12/04/17.
 */
@Slf4j
@RequiredArgsConstructor
public class RulesManagementServiceSupport {

    private final RestSupport restSupport;
    private final ObjectMapper jsonMapper;
    private final RulesManagementServiceSupportConfig config;

    public String loginAsUser(String pid) {
        return loginAsUser(pid, UserServiceSupport.DEFAULT_PASSWORD);
    }

    public String loginAsUser(String pid, String password) {
        int MAX_RETRIES = 3;
        int attempt = 1;
        while (attempt <= MAX_RETRIES) {
            try {
                log.debug("Attempting login (Attempt " + attempt + "/" + MAX_RETRIES + ")");
                return attemptLoginAsUser(pid, password);
            } catch (AssertionError e) {
                log.debug("Login Failed!");
                if (attempt == MAX_RETRIES) {
                    throw e;
                }
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    e1.printStackTrace();
                }
            }
        }

        throw new RuntimeException("Failed to log in!");
    }

    private String attemptLoginAsUser(String pid) {
        return attemptLoginAsUser(pid, UserServiceSupport.DEFAULT_PASSWORD);
    }

    @SneakyThrows
    private String attemptLoginAsUser(String pid, String password) {

        log.debug("Logging in as Test API.User: " + pid);

        Map<String, String> jsonMap = new HashMap<>();
        jsonMap.put("pid", pid);
        jsonMap.put("password", password);
        String requestJson = jsonMapper.writeValueAsString(jsonMap);

        log.info(requestJson);

        Request request = Request.Post(config.getLoginUrl())
                .bodyByteArray(requestJson.getBytes(), ContentType.APPLICATION_JSON);

        Map<String, String> response = restSupport.getResponseAsJson(request, Map.class, statusCode2xx());
        return response.get("token");
    }

    @SneakyThrows
    public String getRules(String token) {
        Request request = Request.Get(config.getRuleUrl())
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer ".concat(token));

        return restSupport.getResponseAsString(request);
    }

    @SneakyThrows
    public String getRuleOverview(String ruleUuid, String token) {
        Request request = Request.Get(config.getRuleUrl().concat("/").concat(ruleUuid))
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer ".concat(token));

        return restSupport.getResponseAsString(request);
    }

    @SneakyThrows
    public String getRuleDetails(String ruleUuid, int version, String token) {

        StringBuilder url = new StringBuilder();
        url.append(config.getRuleUrl())
                .append("/").append(ruleUuid).append("/")
                .append(version);
        Request request = Request.Get(url.toString())
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer ".concat(token));

        return restSupport.getResponseAsString(request);
    }

    @SneakyThrows
    public String getRuleHistory(String ruleUuid, String token) {

        StringBuilder url = new StringBuilder();
        url.append(config.getRuleUrl())
                .append("/audit/").append(ruleUuid);
        Request request = Request.Get(url.toString())
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer ".concat(token));

        return restSupport.getResponseAsString(request);
    }

    @SneakyThrows
    public String createActiveRule(CreateRuleModel model, String token) {
        return createActiveRule(model, token, "Default rule creation reason");
    }

    @SneakyThrows
    public String createActiveRule(CreateRuleModel model, String token, String reason) {
        model.setReason(reason);
        String ruleUuid = createRule(model, token);
        performRuleVersionAction(ruleUuid, 1, RuleVersionActions.commit, reason, token);
        return ruleUuid;
    }

    @SneakyThrows
    public void createSilentRule(String ruleId, String token, String reason) {
        performRuleAction(ruleId,RuleActions.silence, reason, token);
    }

    public String createRule(CreateRuleModel model, String token) {
        return createRule(model, "uniqueId", token);
    }

    public String createRule(CreateRuleModel model, String returnField, String token) {
        Map<String, String> response = createRuleAndReturnMap(model, token);
        return response.get( returnField );
    }

    @SneakyThrows
    public Map<String, String> createRuleAndReturnMap(CreateRuleModel model, String token) {
        log.info("Creating rule");
        String json = jsonMapper.writeValueAsString(model);
        log.info("Json body: {}", json);
        System.out.println("Json body: {}" + json);

        Request request = Request.Post(config.getRuleUrl())
                .bodyByteArray(json.getBytes(), ContentType.APPLICATION_JSON)
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer " + token);

        return restSupport.getResponseAsJson(request, Map.class, statusCode2xx());
    }

    @SneakyThrows
    public String updateRule(CreateRuleModel model, String ruleUuid, String token) {
        log.info("Updating rule with id: {}", ruleUuid);
        String json = jsonMapper.writeValueAsString(model);
        log.info("Json body: {}", json);

        Request request = Request.Put(config.getRuleUrl().concat("/").concat(ruleUuid))
                .bodyByteArray(json.getBytes(), ContentType.APPLICATION_JSON)
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer " + token);

        Map<String, String> response = restSupport.getResponseAsJson(request, Map.class, statusCode2xx());
        return response.get("uniqueId");
    }

    @SneakyThrows
    public Map<String, String> performRuleAction(String ruleUuid, RuleActions action, String reason, String token) {
        PerformRuleActionModel model = PerformRuleActionModel.builder()
                .action( action.toString())
                .ruleUuids( Arrays.asList( ruleUuid))
                .reason( reason)
                .build();

        return performRuleAction( model, token);
    }

    @SneakyThrows
    public Map<String, String> performRuleAction( PerformRuleActionModel model, String token) {

        String jsonBody = jsonMapper.writeValueAsString(model);

        System.out.println("jsonBody = " + jsonBody);

        String updateRuleUrl = config.getRuleUrl().concat( "/action");

        Request request = Request.Post(updateRuleUrl).bodyByteArray(jsonBody.getBytes(), ContentType.APPLICATION_JSON)
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer " + token);

        return restSupport.getResponseAsJson(request, Map.class);
    }

    @SneakyThrows
    public Map<String, String> performRuleVersionAction(String ruleUuid, int version, RuleVersionActions action, String reason, String token) {
        Map<String, String> jsonMap = new HashMap<>();
        jsonMap.put("action", action.toString());
        jsonMap.put("reason", reason);
        String jsonBody = jsonMapper.writeValueAsString(jsonMap);

        String updateRuleUrl = config.getRuleUrl().concat("/" + ruleUuid + "/" + version);

        Request request = Request.Put(updateRuleUrl).bodyByteArray(jsonBody.getBytes(), ContentType.APPLICATION_JSON)
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer " + token);

        return restSupport.getResponseAsJson(request, Map.class);
    }

    public void publish(String reason, String token) {
        publish(reason, token, false);
    }

    @SneakyThrows
    public void publish(String reason, String token, boolean errorExpected) {
        Map<String, String> jsonMap = new HashMap<>();
        jsonMap.put("publishReason", reason);
        String body = jsonMapper.writeValueAsString(jsonMap);

        Request request = Request.Post(config.getPublishUrl()).bodyByteArray(body.getBytes(), ContentType.APPLICATION_JSON)
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer ".concat(token));

        if (errorExpected) {
            restSupport.getResponseAsString(request, statusCode4xx());
        }
        else {
            restSupport.getResponseAsString(request, statusCode2xx());
        }
    }

    public void changePublishInterval(String intervalInSeconds, String reason, String token) {
        changePublishInterval(intervalInSeconds, reason, token, false);
    }

    @SneakyThrows
    public void changePublishInterval(String intervalInSeconds, String reason, String token, boolean errorExpected) {
        Map<String, String> jsonMap = new HashMap<>();
        jsonMap.put("interval", intervalInSeconds);
        jsonMap.put("reason", reason);
        String body = jsonMapper.writeValueAsString(jsonMap);

        Request request = Request.Post(config.getPublishInterval()).bodyByteArray(body.getBytes(), ContentType.APPLICATION_JSON)
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer ".concat(token));

        if (errorExpected) {
            restSupport.getResponseAsString(request, statusCode4xx());
        }
        else {
            restSupport.getResponseAsString(request, statusCode2xx());
        }
    }

    @SneakyThrows
    public String getPublishHistory(String token) {
        Request request = Request.Get(config.getPublishHistory())
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer ".concat(token));
        return restSupport.getResponseAsString(request);
    }

    @SneakyThrows
    public String getDashboardRules(String token) {
        Request request = Request.Get(config.getDashboard().concat("/rules"))
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer ".concat(token));
        return restSupport.getResponseAsString(request);
    }

    @SneakyThrows
    public String getDashboardData(String token) {
        Request request = Request.Get(config.getDashboard().concat("/data"))
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer ".concat(token));
        return restSupport.getResponseAsString(request);
    }

    @SneakyThrows
    public String getDashboardUsers(String token) {
        Request request = Request.Get(config.getDashboard().concat("/users"))
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer ".concat(token));
        return restSupport.getResponseAsString(request);
    }

    @SneakyThrows
    public String getDataTablesManagementPage(String token) {
        Request request = Request.Get(config.getDataTables())
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer ".concat(token));
        return restSupport.getResponseAsString(request);
    }

    @SneakyThrows
    public String getDataTablesSummaryPage(String dataTableUuid, String token) {
        Request request = Request.Get(config.getDataTables().concat("/").concat(dataTableUuid))
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer ".concat(token));
        return restSupport.getResponseAsString(request);
    }

    @SneakyThrows
    public String getDataTablesItemsPage(String dataTableUuid, String token) {
        Request request = Request.Get(config.getDataTables().concat("/").concat(dataTableUuid).concat("/data"))
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer ".concat(token));
        return restSupport.getResponseAsString(request);
    }

    @SneakyThrows
    public String getDataTablesHistoryPage(String dataTableUuid, String token) {
        Request request = Request.Get(config.getDataTables().concat("/").concat(dataTableUuid).concat("/history"))
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer ".concat(token));
        return restSupport.getResponseAsString(request);
    }

    @SneakyThrows
    public String getExportDataTablesData(String dataTableUuid, String token) {
        Request request = Request.Get(config.getDataTables().concat("/").concat(dataTableUuid).concat("/data/download"))
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer ".concat(token));
        return restSupport.getResponseAsString(request);
    }

    @SneakyThrows
    public void importDataTablesData(String dataTableUuid, String opLockVersion, String reason, String fileName, String token) {

        log.info("Updading data table");
        Map<String, String> jsonMap = new HashMap<>();
        jsonMap.put("opLockVersion", opLockVersion);
        jsonMap.put("reason", reason);
        String body = jsonMapper.writeValueAsString(jsonMap);

        String path = "TestData/DataTable/";
        File fileToUpload = new File(getClass().getClassLoader().getResource(path.concat(fileName)).getFile());

        HttpEntity entity = MultipartEntityBuilder.create()
                .addTextBody("dataTable", body, ContentType.APPLICATION_JSON)
                .addBinaryBody("file", fileToUpload, ContentType.APPLICATION_OCTET_STREAM, fileName)
                .build();

        String url = config.getApi()
                .concat("/datatables/")
                .concat(dataTableUuid)
                .concat("/data/upload");

        Request request = Request.Put(url)
                .body( entity )
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer " + token);

        restSupport.getResponseAsString(request, statusCode2xx());
    }

    @SneakyThrows
    public Map<String, String> createDataTable(CreateDataTableModel model, String token) {
        log.info("Creating data table");
        String json = jsonMapper.writeValueAsString(model);
        log.info("Json body: {}", json);
        System.out.println("Json body: {}" + json);

        Request request = Request.Post(config.getDataTables())
                .bodyByteArray(json.getBytes(), ContentType.APPLICATION_JSON)
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer " + token);

        return restSupport.getResponseAsJson(request, Map.class, statusCode2xx());
    }

    @SneakyThrows
    public void updateDataTableDetails(EditDataTableDetailsModel model, String dataTableUuid, String token) {
        log.info("Updading data table");
        String json = jsonMapper.writeValueAsString(model);
        log.info("Json body: {}", json);
        System.out.println("Json body: {}" + json);

        Request request = Request.Put(config.getDataTables().concat("/").concat(dataTableUuid))
                .bodyByteArray(json.getBytes(), ContentType.APPLICATION_JSON)
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer " + token);

        restSupport.getResponseAsString(request, statusCode2xx());
    }

    @SneakyThrows
    public void updateDataTableItems(EditDataTableItemsModel model, String dataTableUuid, String token) {
        log.info("Updading data table items");
        String json = jsonMapper.writeValueAsString(model);
        log.info("Json body: {}", json);
        System.out.println("Json body: {}" + json);

        Request request = Request.Put(config.getApi().concat("/datatables/").concat(dataTableUuid).concat("/data"))
                .bodyByteArray(json.getBytes(), ContentType.APPLICATION_JSON)
                .addHeader(RestSupport.AUTH_HEADER_NAME, "Bearer " + token);

        restSupport.getResponseAsString(request, statusCode2xx());
    }

    @Builder
    @Getter
    public static class RulesManagementServiceSupportConfig {
        private String loginUrl;

        private String ruleUrl;
        private String dataTables;
        private String api;
        private String publishUrl;
        private String publishInterval;
        private String publishHistory;
        private String dashboard;
    }
}
