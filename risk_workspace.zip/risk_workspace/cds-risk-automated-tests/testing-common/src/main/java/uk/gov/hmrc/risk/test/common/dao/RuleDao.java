package uk.gov.hmrc.risk.test.common.dao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import uk.gov.hmrc.risk.test.common.enums.RuleStatus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by James Philipps on 12/04/17.
 */
public class RuleDao extends JdbcDaoSupport {

    public RuleDao(JdbcTemplate jdbcTemplate) {
        setJdbcTemplate(jdbcTemplate);
    }

    @Deprecated
    public void setStatus(String uniqueId, RuleStatus ruleStatus) {
        Long rule_id = ruleIdForUUID(uniqueId);

        getJdbcTemplate().update("UPDATE rule_version SET status=? WHERE rule_id=?", ruleStatus.getValue(), rule_id);
    }

    @Deprecated
    public void setStatusByRuleId(long ruleId, RuleStatus ruleStatus) {
        getJdbcTemplate().update("UPDATE rule_version SET status=? WHERE id=?", ruleStatus.getValue(), ruleId);
    }

    public void deleteAll() {
        getJdbcTemplate().update("set foreign_key_checks=0;");
        getJdbcTemplate().update("SET SQL_SAFE_UPDATES = 0;");
        runUpdateStatementAndLogNumberOfRowsAffected("DELETE FROM rule_version_location");
        runUpdateStatementAndLogNumberOfRowsAffected("DELETE FROM rule_version_location_aud");
        runUpdateStatementAndLogNumberOfRowsAffected("DELETE FROM rule_version_data_table");
        runUpdateStatementAndLogNumberOfRowsAffected("DELETE FROM rule_version");
        runUpdateStatementAndLogNumberOfRowsAffected("DELETE FROM rule");
        runUpdateStatementAndLogNumberOfRowsAffected("DELETE FROM rule_aud");
        runUpdateStatementAndLogNumberOfRowsAffected("DELETE FROM rule_rule_version_aud");
        runUpdateStatementAndLogNumberOfRowsAffected("DELETE FROM rule_version_data_table_aud");
        runUpdateStatementAndLogNumberOfRowsAffected("DELETE FROM rule_version_aud");
        runUpdateStatementAndLogNumberOfRowsAffected("DELETE FROM revinfo");
        runUpdateStatementAndLogNumberOfRowsAffected("DELETE FROM publish_event");
        getJdbcTemplate().update("set foreign_key_checks=1;");
        getJdbcTemplate().update("SET SQL_SAFE_UPDATES = 1;");
    }


    public void deleteById(String uniqueId) {
        Long ruleId = ruleIdForUUID(uniqueId);
        Long ruleVersionId = versionIdForRuleId(ruleId);
        getJdbcTemplate().update("DELETE FROM rule_version_locations WHERE rule_version_id=?", ruleVersionId);
        getJdbcTemplate().update("DELETE FROM rule_version_data_tables WHERE rule_version_id=?", ruleVersionId);
        getJdbcTemplate().update("DELETE FROM rule_version WHERE rule_id=?", ruleId);
        getJdbcTemplate().update("DELETE FROM rule WHERE uuid=?", uniqueId);
    }

    @Deprecated
    public void deleteAllTestRules() {
        getJdbcTemplate().update("set foreign_key_checks=0; " +
                "delete from rule_version_location where rule_version_id in (select rv.id from rule_version rv where rv.name like 'ta_%');" +
                "delete from rule_version_data_table where rule_version_id in (select rv.id from rule_version rv where rv.name like 'ta_%');" +
                "delete from rule where id in (select rv.rule_id from rule_version rv where rv.name like 'ta_%');" +
                "delete from rule_version where name like 'ta_%';" +
                "set foreign_key_checks=1;");
    }

    private void runUpdateStatementAndLogNumberOfRowsAffected(String statement) {
        logger.info("Statement: " + statement + "affected " + getJdbcTemplate().update(statement) + " rows");
    }

    public void deleteByName(String namePattern) {
        Map<String, String> nameIdMap = getJdbcTemplate()
                .query("SELECT hmrc_name,uuid FROM rule", rs -> {
                    Map<String, String> results = new HashMap<>();
                    while (rs.next()) {
                        results.put(rs.getString(1), rs.getString(2));
                    }
                    return results;
                });

        nameIdMap.entrySet().stream()
                .filter(e -> e.getKey().matches(namePattern))
                .map(e -> e.getValue())
                .forEach(this::deleteById);
    }

    public String getBody(String uniqueId) {
        Long ruleId = ruleIdForUUID(uniqueId);

        return getJdbcTemplate().queryForObject("SELECT definition FROM rule_version WHERE rule_id=?",
                new Object[]{ruleId}, String.class);
    }

    public void setBody(String uniqueId, String body) {
        Long ruleId = ruleIdForUUID(uniqueId);

        getJdbcTemplate().update("set foreign_key_checks=0;");
        getJdbcTemplate().update("SET SQL_SAFE_UPDATES = 0;");
        getJdbcTemplate().update("UPDATE rule_version SET definition=? WHERE rule_id=?", body, ruleId);
        getJdbcTemplate().update("UPDATE rule_version_aud SET definition=? WHERE rule_id=?", body, ruleId);
        getJdbcTemplate().update("SET SQL_SAFE_UPDATES = 1;");
        getJdbcTemplate().update("set foreign_key_checks=1;");
    }


    public Long versionIdForRuleId(long ruleId){
        return getJdbcTemplate()
                .query("SELECT id FROM rule_version where rule_id  =?",
                        new Object[]{ruleId},
                        rs -> {
                            List<Long> results = new ArrayList<>();
                            while (rs.next()) {
                                results.add(rs.getLong(1));
                            }
                            return results.get(0);
                        });
    }

    public List<Long> ruleIdsForUuid(String uuid) {
        return getJdbcTemplate().query("select id from rule_version where rule_id = " +
                "(select id from rule where uuid = ?)", new Object[]{uuid}, rs -> {
            List<Long> results = new ArrayList<>();
            while (rs.next()) {
                results.add(rs.getLong(1));
            }
            return results;
        });
    }

    public Long ruleIdForUUID(String ruleId){
        return getJdbcTemplate().query("SELECT id FROM rule where uuid  =? ", new Object[]{ruleId}, rs -> {
            List<Long> results = new ArrayList<>();
            while (rs.next()) {
                results.add(rs.getLong(1));
            }
            return results.get(0);
        });
    }
}
