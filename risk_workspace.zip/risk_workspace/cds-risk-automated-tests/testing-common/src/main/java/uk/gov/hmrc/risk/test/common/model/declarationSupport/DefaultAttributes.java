package uk.gov.hmrc.risk.test.common.model.declarationSupport;

import uk.gov.hmrc.risk.test.common.enums.TransportMode;
import uk.gov.hmrc.risk.test.common.model.declarationSupport.DeclarationModel.DeclarationModelBuilder;

import java.util.UUID;

/**
 * Created by developer on 27/02/18.
 */
public class DefaultAttributes {

    public static DeclarationModelBuilder importDeclaration() {
        UUID randomId = UUID.randomUUID();
        UUID randomReference = UUID.randomUUID();
        return DeclarationModel.builder()
                .id( randomId.toString() )
                .reference( randomReference.toString())
                .declarationType("IM")
                .declarationSubType("C")
                .transportMode(TransportMode.All.toString());
    }

    public static ItemModel.Parties.PartiesBuilder consignorParty(boolean export) {
        return ItemModel.Parties.builder();
    }


}
