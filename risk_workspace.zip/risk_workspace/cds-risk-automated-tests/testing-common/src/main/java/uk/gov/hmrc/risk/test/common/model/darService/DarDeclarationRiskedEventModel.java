package uk.gov.hmrc.risk.test.common.model.darService;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class DarDeclarationRiskedEventModel {

    private String type, responseId, ruleId, actionControlType, reportBackElement, narrative, matchReason, workBasket;
    private String email, blockingRelease, isSecret, notifyDeclarant, isSuppressedByRats, ruleControlType;
    private String checkCode, deptCode;

    public static DarDeclarationRiskedEventModel create(String[] line) {
        return new DarDeclarationRiskedEventModel(
                line[0],          // type
                line[1],          // responseId
                line[2],          // ruleId
                line[3],          // action controlType (sent to DMS)
                line[4],          // reportBackElement version
                line[5],          // narrative
                line[6],          // match reason (called description)
                line[7],          // work basket (assignee)
                line[8],          // email (assignee email)
                line[9],          // blocking release
                line[10],         // is secret
                line[11],         // notify declarant
                line[12],         // is suppressed by rats
                line[13],        // rule control type (actual)
                line[16],        // checkcode
                line[17])  ;      // deptcode

    }

    private DarDeclarationRiskedEventModel(String type, String responseId, String ruleId, String actionControlType,
                                           String reportBackElement, String narrative, String matchReason,
                                           String workBasket, String email, String blockingRelease, String isSecret,
                                           String notifyDeclarant, String isSuppressedByRats, String ruleControlType,
                                           String checkCode,String deptCode) {
        this.type = type;
        this.responseId = responseId;
        this.ruleId = ruleId;
        this.actionControlType = actionControlType;
        this.reportBackElement = reportBackElement;
        this.narrative = narrative;
        this.matchReason = matchReason;
        this.workBasket = workBasket;
        this.email = email;
        this.blockingRelease = blockingRelease;
        this.isSecret = isSecret;
        this.notifyDeclarant = notifyDeclarant;
        this.isSuppressedByRats = isSuppressedByRats;
        this.ruleControlType = ruleControlType;
        this.checkCode=checkCode;
        this.deptCode=deptCode;
    }

    @Override
    public String toString() {
        return String.join(", ", type, responseId, ruleId, actionControlType, reportBackElement, narrative,
                matchReason, workBasket, email, blockingRelease, isSecret, notifyDeclarant, isSuppressedByRats,
                ruleControlType);
    }
}
