package uk.gov.hmrc.risk.test.common.service;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.*;

import java.time.ZonedDateTime;

@Getter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
@JsonDeserialize(builder = PublishHistoryDto.PublishHistoryDtoBuilder.class)
public class PublishHistoryDto {
    private ZonedDateTime publishTimestamp;

    private String publisherPid;

    private String reason;

    private String publishUuid;
    private String rulePackageUuid;
    private String dataPackageUuid;

    @JsonPOJOBuilder(withPrefix = "")
    public static final class PublishHistoryDtoBuilder {
    }
}