//package uk.gov.hmrc.risk.test.common.enums;
//
//import lombok.Getter;
//import lombok.RequiredArgsConstructor;
//
//import java.util.Arrays;
//import java.util.Map;
//import java.util.Optional;
//import java.util.stream.Collectors;
//
///**
// * Created by James Philipps on 09/03/17.
// */
//@Getter
//@RequiredArgsConstructor
//public enum RuleMetadata {
//    UNIQUE_ID("unique_id", String.class),
//    CONSOLIDATE("consolidate", String.class),
//    RAT_PERCENTAGE_DAILY("rat_percentage_daily", Integer.class),
//    RAT_FIRST_COUNT_DAILY_LIMIT("rat_first_count_daily_limit", Integer.class),
//    RAT_VARIABLE_COUNT_DAILY_LIMIT("rat_variable_daily_limit", Integer.class),
//    PRE_POST_CLEARANCE("pre_post_clearance", Integer.class),
//    RAT_FIRST_COUNT_WEEKLY_LIMIT("rat_first_count_weekly_limit", Integer.class);
//
//
//    private static final Map<String, RuleMetadata> MAP = Arrays.asList(values()).stream()
//            .collect(Collectors.toMap(v -> v.getKey().toLowerCase(), v -> v));
//
//    private final String key;
//    private final Class<?> valueType;
//
//
//    public static RuleMetadata fromString(String value) {
//        if (MAP.containsKey(value.trim().toLowerCase())) {
//            return MAP.get(value);
//        }
//        throw new IllegalArgumentException(String.format("Could not parse RuleMetada from input value: %s", value));
//    }
//
//    public String toMetadata(Optional<Object> value) {
//        StringBuilder sb = new StringBuilder();
//        sb.append("@").append(key);
//
//        value.ifPresent(v -> {
//            sb.append("(");
//
//            if (String.class.isAssignableFrom(valueType)) {
//                sb.append("\"").append(v).append("\"");
//            } else if (Number.class.isAssignableFrom(valueType)) {
//                sb.append(v);
//            }
//
//            sb.append(")");
//        });
//
//        return sb.toString();
//    }
//
//    public Optional<Object> extractFromMetadata(Map<String, Optional<Object>> metadata) {
//        if (metadata.containsKey(key)) {
//            Optional<Object> valOption = metadata.get(key);
//            if (valOption.isPresent()) {
//                Object val = valOption.get();
//                if (!valueType.isAssignableFrom(val.getClass())) {
//                    throw new ClassCastException(String.format(
//                            "Expected value of type: %s for metadata key: %s but got value type: %s with value: '%s' " +
//                                    "instead", valueType.getName(), this.name(), val.getClass().getName(), val
//                    ));
//                }
//                return valOption;
//            }
//        }
//        return Optional.empty();
//    }
//}
