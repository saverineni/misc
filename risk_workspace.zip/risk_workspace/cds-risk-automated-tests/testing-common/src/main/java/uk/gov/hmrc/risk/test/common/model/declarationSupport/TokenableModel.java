package uk.gov.hmrc.risk.test.common.model.declarationSupport;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by developer on 23/02/18.
 */
@Slf4j
public abstract class TokenableModel {


    @SneakyThrows
    public Map<String, String> mapValues() {
        Class<? extends TokenableModel> type = this.getClass();
        log.debug("Mapping values for type: {}", type);
        Map<String, String> itemParams = new HashMap<>();


        Field[] fields = type.getDeclaredFields();
        for (Field f : fields) {
            if (!f.getName().startsWith("$")) {
                f.setAccessible(true);
                Object value = f.get(this);
                if (value != null) {
                    log.debug("Type of field: {}, {}", f.getName(), value.getClass());
                    itemParams.put(f.getName(), (String) value);
                }
            }
        }
        return itemParams;
    }

}
