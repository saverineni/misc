package uk.gov.hmrc.risk.test.common.service.docker;

import lombok.RequiredArgsConstructor;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Predicate;

/**
 * Created by James Philipps on 07/08/17.
 */
@RequiredArgsConstructor
public class ContainerFilter implements Predicate<ContainerAccessor> {

    public static ContainerFilter not(ContainerFilter wrappedFilter) {
        return new ContainerFilter(c -> !wrappedFilter.test(c));
    }

    public static ContainerFilter hasState(ContainerState... states) {
        final Set<ContainerState> stateSet = new HashSet<>(Arrays.asList(states));
        return new ContainerFilter(c -> stateSet.contains(c.getState()));
    }

    public static ContainerFilter hasName(String name, boolean ignoreCase) {
        return new ContainerFilter(
                ignoreCase ?
                        c -> c.getName().equalsIgnoreCase(name.trim()) :
                        c -> c.getName().equals(name.trim())
        );
    }

    public static ContainerFilter hasId(String name) {
        return new ContainerFilter(
                c -> c.getId().equalsIgnoreCase(name.trim())
        );
    }

    public static ContainerFilter hasPortPrefix(int portPrefix) {
        return new ContainerFilter(
                c -> c.getPublicPorts().stream()
                        .map(p -> p.toString())
                        .anyMatch(p -> p.startsWith(Integer.toString(portPrefix)))
        );
    }

    public static ContainerFilter hasPublicPort(int port) {
        return new ContainerFilter(
                c -> c.getPublicPorts().stream().anyMatch(p -> p == port)
        );
    }

    private final Predicate<ContainerAccessor> predicate;

    @Override
    public boolean test(ContainerAccessor containerAccessor) {
        return predicate.test(containerAccessor);
    }
}
