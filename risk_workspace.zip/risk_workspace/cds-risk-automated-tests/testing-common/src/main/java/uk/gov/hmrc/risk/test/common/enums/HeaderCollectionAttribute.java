package uk.gov.hmrc.risk.test.common.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum HeaderCollectionAttribute implements Attribute {

    ADDITIONAL_INFORMATION_CODEHEADER("additionalInformation_CodeHeader"),
    ADDITIONAL_INFORMATION_TEXTHEADER("additionalInformation_TextHeader"),
    ADDITIONAL_DOCUMENTS_TYPETHEADER("additionalDocuments_TypeHeader"),

    CONTAINER_CODE_HEADER("container_code_header"),
    SEAL_ID_HEADER("seal_id_header"),
    COUNTRY_ROUTE_HEADER("country_route_header");


    public final String method;

    @Override
    public String toString() {
        return method;
    }
}
