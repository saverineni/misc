package uk.gov.hmrc.risk.test.common.service.declarationSupport;

import lombok.RequiredArgsConstructor;

import static uk.gov.hmrc.risk.test.common.util.IOUtils.readFromClasspath;

@RequiredArgsConstructor
public class DeclarationCollectionTemplates {

    public String getAdditionalDocumentsTemplate() {
        return getTemplate("AdditionalDocumentsTemplate");
    }

    public String getAdditionalInformationTemplate() {
        return getTemplate("AdditionalInformationTemplate");
    }

    public String getContainersTemplate() {
        return getTemplate("ContainersTemplate");
    }

    public String getCountryRegionsTemplate() {
        return getTemplate("CountryRegionsTemplate");
    }

    public String getCustomsOfficesTemplate() {
        return getTemplate("CustomsOfficesTemplate");
    }

    public String getLocationsTemplate() {
        return getTemplate("LocationsTemplate");
    }

    public String getPartiesTemplate() {
        return getTemplate("PartiesTemplate");
    }

    private String getTemplate(String fileName) {
        return readFromClasspath("risking-testing-common/declaration-collection-templates/" + fileName+ ".xml");
    }
}
