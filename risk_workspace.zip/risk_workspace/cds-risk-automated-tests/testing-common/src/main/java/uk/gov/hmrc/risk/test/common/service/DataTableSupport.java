package uk.gov.hmrc.risk.test.common.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import uk.gov.hmrc.risk.test.common.dao.DataTableDao;
import uk.gov.hmrc.risk.test.common.dao.DataTableDao.DataTableVersion;
import uk.gov.hmrc.risk.test.common.dao.DataTableDao.DataType;
import uk.gov.hmrc.risk.test.common.model.dataService.DataTableCreationModel;
import uk.gov.hmrc.risk.test.common.model.dataService.DataTableDetailsModel;
import uk.gov.hmrc.risk.test.common.model.dataService.DataTableEditModel;

import java.util.List;
import java.util.Map;

import static uk.gov.hmrc.risk.test.common.service.RestSupport.DEFAULT_AUTH_HEADER;
import static uk.gov.hmrc.risk.test.common.service.RestSupport.statusCode2xx;

/**
 * Created by James Philipps on 12/04/17.
 */
@Slf4j
@RequiredArgsConstructor
public class DataTableSupport {

    private final RestSupport restSupport;
    private final DataTableDao dataTableDao;
    private final ObjectMapper jsonMapper;
    private final DataTableSupportConfig config;

    @SneakyThrows
    public String createDataTable(DataTableCreationModel model, List<String> data) {
        String requestJson = jsonMapper.writeValueAsString(model);
        log.debug("Data table creation json: {}", requestJson);
        log.debug("Sending create data table request..");

        Request request = Request.Post(config.getDataTablesUrl())
                .addHeader(RestSupport.AUTH_HEADER_NAME, model.getUserPid())
                .bodyByteArray(requestJson.getBytes(), ContentType.APPLICATION_JSON);

        Map<String, String> createResponseJson = restSupport.getResponseAsJson(request, Map.class, statusCode2xx());
        String tableUuid = createResponseJson.get("uuid");

        if (data.size() > 0) {
            DataTableEditModel editModel = DataTableEditModel.builder()
                    .tableName(model.getTableName())
                    .userPid(model.getUserPid())
                    .dataTableUuid(tableUuid)
                    .addedElements(data)
                    .reason(model.getReason())
                    .description(model.getDescription())
                    .tags(model.getTags())
                    .build();

            editDataTable_data(editModel);
        }

        return tableUuid;
    }

    @SneakyThrows
    public void editDataTable_data(DataTableEditModel model) {
        String requestJson = jsonMapper.writeValueAsString(model);
        log.debug("Editing table with uuid: {}", model.getDataTableUuid());
        log.debug("Data table edit json: {}", requestJson);

        Request request = Request.Put(config.getDataTablesUrl() + "/" + model.getDataTableUuid() + "/data")
                .addHeader(RestSupport.AUTH_HEADER_NAME, model.getUserPid())
                .bodyByteArray(requestJson.getBytes(), ContentType.APPLICATION_JSON);

        restSupport.getResponse(request, statusCode2xx());
    }


    @SneakyThrows
    public void editDataTable(DataTableEditModel model) {
        String requestJson = jsonMapper.writeValueAsString(model);
        log.debug("Editing table with uuid: {}", model.getDataTableUuid());
        log.debug("Data table edit json: {}", requestJson);

        Request request = Request.Put(config.getDataTablesUrl() + "/" + model.getDataTableUuid())
                .addHeader(RestSupport.AUTH_HEADER_NAME, model.getUserPid())
                .bodyByteArray(requestJson.getBytes(), ContentType.APPLICATION_JSON);

        restSupport.getResponse(request, statusCode2xx());
    }

    @SneakyThrows
    public DataTableDetailsModel getDataTableDetails(String uuid) {
        String url = config.dataTablesUrl + "/" + uuid + "/detail";

        Request request = Request.Get(url).addHeader(DEFAULT_AUTH_HEADER);
        String response = restSupport.getResponseAsString(request, statusCode2xx());
        return jsonMapper.readValue(response, DataTableDetailsModel.class);
    }

    public List<DataTableVersion> getDataTableVersions(String tableUuid) {
        return dataTableDao.getDataTableVersions(getDataTableId(tableUuid));
    }

    public void deleteDataTables() {
        dataTableDao.deleteAll();
    }

    public void deleteDataTable(String uuid) {
        dataTableDao.delete(getDataTableId(uuid));
    }

    private String getDataTableId(String uuid) {
        return dataTableDao.getDataTableByUuid(uuid)
                .orElseThrow(() -> new IllegalArgumentException("No data table found with uuid: " + uuid))
                .getTableId();
    }

    public void addDataType(DataType dataType) {
        dataTableDao.addDataType(dataType);
    }

    public List<DataType> getDataTypes() {
        return dataTableDao.getDataTypes();
    }

    @Builder
    @Getter
    public static class DataTableSupportConfig {
        private String dataTablesUrl;
    }
}
