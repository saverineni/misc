package uk.gov.hmrc.risk.test.common.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.hmrc.risk.test.common.model.publishService.PublishEventModel;
import uk.gov.hmrc.risk.test.common.util.JmsUtils;

import javax.jms.Message;
import javax.jms.MessageListener;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;


@Slf4j
@RabbitListener(queues = "risk.publish.this")
public class PublishEventSubscriber implements MessageListener {

    private final ObjectMapper jsonMapper;

    private ReadWriteLock publishResultLock = new ReentrantReadWriteLock();
    private PublishEventModel published;

    @Autowired
    public PublishEventSubscriber(ObjectMapper jsonMapper) {
        this.jsonMapper = jsonMapper;
    }

    @Override
    @SneakyThrows
    public void onMessage(Message msg) {
        synchronized (publishResultLock) {
            String json = JmsUtils.extractMessageBody(msg);
            System.out.println("Publish event received: " + json);
            published = jsonMapper.readValue(json, PublishEventModel.class);
        }
    }

    @SneakyThrows
    public PublishEventModel getPublishEvent(int timeoutSeconds) {
        for (int i = 0; i < timeoutSeconds * 10; i++) {
            synchronized (publishResultLock) {
                if (published != null) {
                    return published;
                }
            }
            Thread.sleep(100);
        }
        return published;
    }

    public void forgetLastEvent() {
        published = null;
    }
}
