package uk.gov.hmrc.risk.test.common.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum DomainAttribute implements Attribute {

    Country("country"),
    ConsignorAddress("consignorAddress_domain"),
    ConsignorCity("consignorCity_domain"),
    ConsignorCountry("consignorCountry_domain"),
    ConsignorName("consignorName_domain"),
    ConsignorEori("consignorEori_domain"),
    DestinationCountry("destinationCountry_domain"),
    DispatchCountry("dispatchCountry_domain"),

    EORI("eori"),
    Trader("trader"),

    ConsginorCountry("consignorCountry_Header")
    ;

    public final String method;

    @Override
    public String toString() {
        return method;
    }
}
