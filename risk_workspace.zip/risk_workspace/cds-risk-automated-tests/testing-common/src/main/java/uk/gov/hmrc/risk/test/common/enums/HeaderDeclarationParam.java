package uk.gov.hmrc.risk.test.common.enums;

import lombok.AllArgsConstructor;

/**
 * Created by developer on 31/08/17.
 */
@AllArgsConstructor
public enum HeaderDeclarationParam implements DeclarationParam{

    ID("id"),
    DECLARATION_REFERENCE("declarationReference"),

    ADDITIONAL_INFO_CODE("additionalInfoCode_Header"),
    ADDITIONAL_INFO_TEXT("additionalInfoText_Header"),

    ADDITIONAL_ACTOR_ID_HEADER("additionalActorId_Header"),
    ADDITIONAL_ACTOR_ROLE_HEADER("additionalActorRole_Header"),

    VAT_DECLARING_PARTY_ID_HEADER("vatDeclaringPartyId_Header"),
    VAT_DECLARING_PARTY_ROLE_HEADER("vatDeclaringPartyRole_Header"),

    CONSIGNOR_TYPE("consignorType_Header"),
    CONSIGNOR_NAME("consignorName_Header"),
    CONSIGNOR_ADDRESS_COUNTRY("consignorCountry_Header"),
    CONSIGNOR_ADDRESS_CITY("consignorCity_Header"),
    CONSIGNOR_ADDRESS_STREET("consignorAddress_Header"),
    CONSIGNOR_ADDRESS_POSTCODE("consignorPostcode_Header"),
    CONSIGNOR_EORI("consignorEori_Header"),

    CONSIGNEE_TYPE("consigneeType"),
    CONSIGNEE_NAME("consigneeName"),
    CONSIGNEE_ADDRESS_COUNTRY("consigneeCountryCode"),
    CONSIGNEE_ADDRESS_CITY("consigneeCity"),
    CONSIGNEE_ADDRESS_STREET("consigneeAddress"),
    CONSIGNEE_ADDRESS_POSTCODE("consigneePostcode"),
    CONSIGNEE_EORI("consigneeEori"),

    CONSIGNMENT_REF("consignmentReference"),
    COUNTRY_ROUTE("countryRoute"),

    CONTAINER_CODE("containerCode"),

    DECLARATION_TYPE("tradeMovementType"),
    DECLARATION_SUBTYPE("tradeMovementSubType"),

    DECLARANT_NAME("declarantName"),
    DECLARANT_ADDRESS("declarantAddress"),
    DECLARANT_CITY("declarantCity"),
    DECLARANT_POSTCODE("declarantPostcode"),
    DECLARANT_COUNTRY_CODE("declarantCountryCode"),
    DECLARANT_EORI("declarantEori"),

    DISPATCH_COUNTRY("dispatchCountry_Header"),

    DESTINATION_COUNTRY("destinationCountry"),

    DOCUMENT_TYPE("documentType"),


    FREIGHT_CHARGE("freightCharge"),
    FREIGHT_CHARGE_CURRENCY("freightChargeCurrency"),

    GOODS_LOCATION("goodsLocation"),

    INVOICE_AMOUNT("invoiceTotal_Header"),
    INVOICE_CURRENCY("invoiceCurrency_Header"),
    ITEM_COUNT("itemCount"),
    INLAND_MODE_OF_TRANSPORT("inlandModeOfTransport"),      //transport Role

    MODE_OF_ENTRY("modeOfEntry"),
    MODE_OF_TRANSPORT("modeOfTransport"),

    ORIGIN_COUNTRY("originCountry"),
    OFFICE_OF_EXIT("officeOfExit"),

    PACKAGE_COUNT("packageCount_Header"),
    PAYING_AGENT("payingAgentEori"),

    REP_CITY("representativeCity"),
    REP_COUNTRY("representativeCountry"),
    REP_EORI("representativeEori"),
    REP_NAME("representativeName"),
    REP_ADDRESS("representativeAddress"),
    REP_POSTCODE("representativePostcode"),
    REP_FUNCTION("representativeFunction"),

    SPECIFIC_CIRCUMSTANCE("specificCircumstance"),
    SEAL_ID("sealId"),

    SUPERVISING_OFFICE_NAME("supervisingOfficeName"),
    SUPERVISING_OFFICE_EORI("supervisingOfficeEori"),

    GOODSlOCATION_CITY("goodsLocationCity"),
    GOODSlOCATION_COUNTRY("goodsLocationCountry"),
    GOODSlOCATION_ID("goodsLocationID"),
    GOODSlOCATION_NAME("goodsLocationName"),
    GOODSlOCATION_POSTCODE("goodsLocationPostcode"),
    GOODSlOCATION_ADDRESS("goodsLocationAddress"),


    TOTAL_GROSS_MASS("totalGrossMass_Header"),
    TRANSPORT_COUNTRY("transportCountry"),
    TRANSPORT_IDENTIFIER("transportIdentifier"),
    TRANSPORT_ON_ARRIVAL_TYPE("transportOnArrivalType"),

    TRANSPORT_MOP("transportMOP"),
    TRADERS_OWN_REF("tradersOwnReference"),
    TRANSPORT_MODE("transportMode"),
    UNIQUE_CONSIGNMENT_REFERENCE("uniqueConsignmentReference"),
    WAREHOUSE_ID("warehouseId"),
    WAREHOUSE_TYPE("warehouseType"),


    EXPORTER_STREET_NUMBER("exporterAddress_Header"),
    EXPORTER_CITY_NAME("exporterCity_Header"),
    EXPORTER_COUNTRY("exporterCountry_Header"),
    EXPORTER_ID("exporterId_Header"),
    EXPORTER_NAME("exporterName_Header"),
    EXPORTER_POSTCODE("exporterPostcode_Header"),

    IMPORTER_STREET_NUMBER("importerAddress_Header"),
    IMPORTER_CITY_NAME("importerCity_Header"),
    IMPORTER_COUNTRY("importerCountry_Header"),
    IMPORTER_EORI("importerEori_Header"),
    IMPORTER_NAME("importerName_Header"),
    IMPORTER_POSTCODE("importerPostcode_Header"),
    PLACE_OF_LOADING("placeOfLoading"),
    TRANSACTION_NATURE("transactionNature"),

    BUYER_TYPE("buyerType"),
    BUYER_NAME("buyerName"),
    BUYER_ADDRESS_COUNTRY("buyerCountryCode"),
    BUYER_ADDRESS_CITY("buyerCity"),
    BUYER_ADDRESS_STREET("buyerAddress"),
    BUYER_ADDRESS_POSTCODE("buyerPostcode"),
    BUYER_ID("buyerId"),

    SELLER_TYPE("sellerType"),
    SELLER_NAME("sellerName"),
    SELLER_ADDRESS_COUNTRY("sellerCountryCode"),
    SELLER_ADDRESS_CITY("sellerCity"),
    SELLER_ADDRESS_STREET("sellerAddress"),
    SELLER_ADDRESS_POSTCODE("sellerPostcode"),
    SELLER_ID("sellerId"),
    GOODS_SHIPPED_CONTAINER_INDICATOR_HEADER("goodsShippedByContainerIndicator"),

    VALUATION_ADJUSTMENTS_TYPE("valuationAdjustmentsType"),
    VALUATION_ADJUSTMENTS_TYPE2("valuationAdjustmentsType2"),
    VALUATION_ADJUSTMENTS_TYPE3("valuationAdjustmentsType3"),
    VALUATION_ADJUSTMENTS_TYPE4("valuationAdjustmentsType4"),
    DELIVERY_TERMS_TYPE("deliveryTermsType"),
    DELIVERY_TERMS_LOCATION_ID("deliveryTermsLocationID_Header"),
    DELIVERY_TERMS_LOCATION_NAME("deliveryTermsLocationName_Header"),
    INTERNAL_CURRENCY_UNIT("internalCurrencyUnit"),
    EXCHANGE_RATE("exchangeRate");

    private String paramText;
    @Override
    public String toString() {
        return paramText;
    }

}
