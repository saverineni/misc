package uk.gov.hmrc.risk.test.common.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.InputStream;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;

import static java.util.stream.Collectors.toMap;
import static org.apache.commons.lang.StringUtils.substringAfter;
import static uk.gov.hmrc.risk.test.common.service.RestSupport.statusCode2xx;

/**
 * Created by James Philipps on 13/06/17.
 */
@Slf4j
public class RiskingServiceSupport {

    private final RestSupport restSupport;
    private final ObjectMapper jsonMapper;
    private final RiskingServiceSupportConfig config;

    @Autowired
    public RiskingServiceSupport(RestSupport restSupport, ObjectMapper jsonMapper, RiskingServiceSupportConfig config) {
        this.restSupport = restSupport;
        this.jsonMapper = jsonMapper;
        this.config = config;
    }

    public Map<String, Number> getMetricsPrefixedWith(String metricPrefix) {
        Request request = Request.Get(config.getMetricsUrl());

        Map<String, Number> response = restSupport.getResponseAsJson(request, Map.class);


        return response.entrySet().stream()
                .filter(e -> e.getKey().startsWith(metricPrefix))
                .collect(toMap(
                        e -> substringAfter(e.getKey(), metricPrefix + "."),
                        Map.Entry::getValue));

    }

    public String submitDeclarationViaHttp(String declarationXml) {
        log.debug("Submitting declaration via http..");
        log.debug("Declaration:\n{}", declarationXml);

        Request request = Request.Post(config.getSubmitDeclarationUrl())
                .bodyByteArray(declarationXml.getBytes(), ContentType.APPLICATION_XML);

        return restSupport.getResponseAsString(request, statusCode2xx());
    }

    public RiskingSystemTime getTime() {
        log.debug("Sending get time request..");
        Request request = Request.Get(config.getTimeUrl());
        Map<String, Object> json = restSupport.getResponseAsJson(request, Map.class, statusCode2xx());

        return Boolean.parseBoolean(json.get("overriden").toString()) ?
                new RiskingSystemTime(Optional.of(
                        ZonedDateTime.ofInstant(Instant.parse(json.get("time").toString()), ZoneId.of("UTC"))
                )) :
                new RiskingSystemTime(Optional.empty());
    }

    public void getRiskingServiceLogBasedOnDescription(String descriptionToSearchFor) {

        Request request = Request.Get(config.getLogfile());

        String logFile = restSupport.getResponseAsString(request, statusCode2xx());

        log.debug("Risking Service LogFile for: " + config.getLogfile());


        int iStartOfTest = logFile.indexOf(descriptionToSearchFor);

        if (iStartOfTest > 0) {
            String logForTest = logFile.substring(iStartOfTest);
            log.debug(logForTest);
        } else {
            log.debug("log details for rule: " + descriptionToSearchFor + " NOT Found.");
        }
    }

    public void setTime(int day, int month, int year, int hour, int minute, int second) {
        String timestamp = DateTimeFormatter.ISO_INSTANT.format(
                ZonedDateTime.of(year, month, day, hour, minute, second, 0, ZoneId.of("UTC"))
        );

        log.debug("Sending system time set request..");
        doSetTime(Collections.singletonMap("time", timestamp));
    }

    public void useRealSystemTime() {
        log.debug("Sending system time clear request..");
        doSetTime(Collections.emptyMap());
    }

    @SneakyThrows
    public boolean waitForPackageVersionChange(int timeoutInMilliseconds, String currentPackage) {
        int counter = 0;
        boolean versionChanged = false;
        String latestVersion = null;
        while ((!versionChanged) && counter < timeoutInMilliseconds) {
            latestVersion = getLatestPackageVersion();
            versionChanged = currentPackage.equals(latestVersion);
            Thread.sleep(100);
            counter += 100;
        }
        if (! versionChanged) {
            log.info("Active package has not refreshed in {}ms. Expecting {}, but was {}", timeoutInMilliseconds, currentPackage, latestVersion);
        }
        return versionChanged;
    }

    public String getLatestPackageVersion() {
        Request request = Request.Get(config.getPackageVersionUrl());

        return restSupport.getResponseAsString(request, statusCode2xx());
    }

    @SneakyThrows
    private void doSetTime(Map<String, String> requestProps) {
        String requestJson = jsonMapper.writeValueAsString(requestProps);
        log.debug("System time json:\n {}", requestJson);

        Request request = Request.Post(config.getTimeUrl())
                .bodyByteArray(requestJson.getBytes(), ContentType.APPLICATION_JSON);

        restSupport.getResponse(request, statusCode2xx());
    }

    @SneakyThrows
    public PrivateKey getPrivateKey() {
        InputStream stream = getClass().getResourceAsStream("/risking-testing-common/private_key.der");
        byte[] keyBytes = IOUtils.toByteArray(stream);

        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        return kf.generatePrivate(spec);
    }

    @Getter
    @AllArgsConstructor
    public static class RiskingSystemTime {
        private Optional<ZonedDateTime> timeUtc;

        public boolean isOverriden() {
            return timeUtc.isPresent();
        }
    }

    @Builder
    @Getter
    public static class RiskingServiceSupportConfig {
        private String timeUrl, submitDeclarationUrl, logfile, packageVersionUrl;
        private String metricsUrl;
    }
}
