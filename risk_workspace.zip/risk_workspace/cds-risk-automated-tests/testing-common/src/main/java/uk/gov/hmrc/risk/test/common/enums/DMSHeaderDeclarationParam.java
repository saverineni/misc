package uk.gov.hmrc.risk.test.common.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum DMSHeaderDeclarationParam implements DmsDeclarationParam{

    FUNCTIONAL_REF_ID("FunctionalReferenceID"),
    FUNCTIONAL_DATE_TIME("AcceptanceDateTime");

    private String paramText;

    @Override
    public String toString() {
        return paramText;
    }

}
