package uk.gov.hmrc.risk.test.common.dao;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/**
 * Created by James Philipps on 12/04/17.
 */
@Slf4j
public class DataTableDao extends JdbcDaoSupport {

    private static final String QUERY_DATA_TABLE_SELECT = "SELECT table_id, name, description, uuid, updated_timestamp, " +
            "updater_pid, creator_pid, created_timestamp,data_type FROM data_tables";
    private static final String QUERY_DATA_TYPE_SELECT = "SELECT type_id, data_type_name, pattern, uuid FROM data_types";
    private static final String QUERY_DATA_TABLE_VERSION_SELECT = "SELECT table_id, table_version_id, table_version_uuid, " +
            "creator_pid, created_timestamp FROM data_table_versions ";

    public DataTableDao(JdbcTemplate jdbcTemplate) {
        setJdbcTemplate(jdbcTemplate);
    }

    public List<DataType> getDataTypes() {
        return getJdbcTemplate().
                query(
                        QUERY_DATA_TYPE_SELECT,
                        rs -> {
                            return mapResultSetToList(rs, rs1 -> toDataType(rs1));
                        }
                );
    }


    public Optional<DataType> getDataType(String typeId) {
        return getJdbcTemplate().
                query(
                        QUERY_DATA_TYPE_SELECT + " WHERE type_id=?", new String[]{typeId},
                        rs -> rs.next() ? Optional.of(toDataType(rs)) : Optional.empty()
                );
    }

    public Optional<DataType> getDataType(DataTypeName name) {
        return getJdbcTemplate().
                query(
                        QUERY_DATA_TYPE_SELECT + " WHERE data_type_name=?", new String[]{name.toString()},
                        rs -> rs.next() ? Optional.of(toDataType(rs)) : Optional.empty()
                );
    }

    public void addDataType(DataType dataType) {
        getJdbcTemplate().update("INSERT INTO data_types(uuid, data_type_name) VALUES(?,?)",
                dataType.getUuid(), dataType.getName());
    }

    public List<DataTable> getDataTables() {
        return getJdbcTemplate().
                query(
                        QUERY_DATA_TABLE_SELECT,
                        rs -> {
                            return mapResultSetToList(rs, rs1 -> toDataTable(rs1));
                        }
                );
    }

    public Optional<DataTable> getDataTable(String tableId) {
        return getJdbcTemplate().
                query(
                        QUERY_DATA_TABLE_SELECT + " WHERE table_id=?", new String[]{tableId},
                        rs -> rs.next() ? Optional.of(toDataTable(rs)) : Optional.empty()
                );
    }

    public List<DataTableVersion> getDataTableVersions(String tableId) {
        return getJdbcTemplate().
                query(
                        QUERY_DATA_TABLE_VERSION_SELECT + " WHERE table_id=?", new String[]{tableId},
                        rs -> {
                            return mapResultSetToList(rs, rs1 -> toDataTableVersion(rs1));
                        }
                );
    }

    public Optional<DataTable> getDataTableByUuid(String uuid) {
        return getJdbcTemplate().
                query(
                        QUERY_DATA_TABLE_SELECT + " WHERE uuid=?", new String[]{uuid},
                        rs -> rs.next() ? Optional.of(toDataTable(rs)) : Optional.empty()
                );
    }

    //removed the foreign key stuff
    @Transactional
    public void deleteAll() {
        List<String> tablesInOrder = Arrays.asList("data_table_tags_aud", "tags_aud", "data_items_aud",
                "data_tables_aud", "table_locations_aud", "data_table_location_aud", "data_table_tags", "data_items",
                "tags", "table_locations", "data_tables", "publish_event", "revinfo");

        for (String table : tablesInOrder) {
            if (tableExists(table)) {
                runUpdateStatementAndLogNumberOfRowsAffected("DELETE FROM " + table);
            } else {
                log.warn("Expected to delete from table: '{}' but table does not exist!", table);
            }
        }
    }

    public boolean tableExists(String name) {
        try {
            getJdbcTemplate().query("SELECT 1 FROM " + name + " LIMIT 1;", rs -> null);
            return true;
        } catch (BadSqlGrammarException e) {
            return false;// Table doesn't exist
        }
    }

    public void delete(String tableId) {
        List<String> tableVersionIds = getJdbcTemplate().
                query(
                        "SELECT table_version_id FROM data_table_versions WHERE table_id=?", new String[]{tableId},
                        rs -> {
                            return mapResultSetToList(rs, rs1 -> extractStr(rs1, 1));
                        }
                );

        getJdbcTemplate().update("DELETE FROM data_items WHERE table_version_id IN ?", tableVersionIds);
        getJdbcTemplate().update("DELETE FROM data_table_versions WHERE table_id=?", tableId);
        getJdbcTemplate().update("DELETE FROM data_table_tags where data_table_id=?", tableId);
        getJdbcTemplate().update("DELETE FROM table_locations where table_id=?", tableId);
        getJdbcTemplate().update("DELETE FROM data_tables where table_id=?", tableId);
    }

    private void runUpdateStatementAndLogNumberOfRowsAffected(String statement) {
        logger.info("Statement: " + statement + "affected " + getJdbcTemplate().update(statement) + " rows");
    }

    @SneakyThrows
    private DataType toDataType(ResultSet rs) {
        return new DataType(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
    }

    @SneakyThrows
    private DataTable toDataTable(ResultSet rs) {
        DataType dt = getDataType(rs.getString(9)).get();
        return new DataTable(
                rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
                rs.getString(6), rs.getString(7), rs.getString(8), dt
        );
    }

    @SneakyThrows
    private DataTableVersion toDataTableVersion(ResultSet rs) {
        return new DataTableVersion(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
    }

    @SneakyThrows
    private <T> List<T> mapResultSetToList(ResultSet rs, MapFunc<T> mapFunc) {
        List<T> l = new ArrayList<>();
        while (rs.next()) {
            l.add(mapFunc.map(rs));
        }
        return l;
    }

    @SneakyThrows
    private String extractStr(ResultSet rs, int i) {
        return rs.getString(i);
    }

    @Getter
    @Builder
    public static class DataTable {
        private String tableId, uuid, name, description, updaterPid, creatorPid, createdTimestamp, updatedTimestamp;
        private DataType dataType;

    }


    @Getter
    @Builder
    public static class DataTableVersion {
        private String tableId, tableVersionId, tableVersionUuid, creatorPid, createdTimestamp;
    }

    @Getter
    @Builder
    public static class DataType {
        String typeId, name, pattern, uuid;
    }

    @AllArgsConstructor
    public enum DataTypeName {
        CommodityCode("Commodity Code"),
        FreeText("Free Text"),
        PartCommodityCodePart("Commodity Code");

        private String dataTypeName;

        @Override
        public String toString() {
            return dataTypeName;
        }
    }

    private interface MapFunc<T> {
        T map(ResultSet rs);
    }

}