package uk.gov.hmrc.risk.test.common.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Created by James Philipps on 12/04/17.
 */
@Getter
@RequiredArgsConstructor
public enum RuleStatus {
    DRAFT("draft"), ACTIVE("active"), COMMIT("commit"), ARCHIVE("archive");
    private final String value;
}
