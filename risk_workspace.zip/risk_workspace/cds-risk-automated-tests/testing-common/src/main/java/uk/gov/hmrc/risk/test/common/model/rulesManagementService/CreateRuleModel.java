package uk.gov.hmrc.risk.test.common.model.rulesManagementService;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Builder
@Data
public class CreateRuleModel {

    private String description, startDateTime, endDateTime, regimeUuid, securityStatusUuid, operationName;
    private boolean fallback;
    private String reason, ruleType;
    private List<String> locationUuids;
    private List<Query> query;
    private QueryOptions queryOptions;
    private RatDefinition ratDefinition;
    private RuleOutputs ruleOutputs;
    private BaseLocation baseLocation;

    @Builder
    @Data
    public static class Query {
        private String attribute, trackId, value, conditionType;
        private String operator;
        private List<Query> query;
    }

    @Builder
    @Data
    public static class QueryOptions {
        private String declarationType, transportMode;
        private List<String> declarationSubTypes;
    }

    @Builder
    @Data
    public static class RatDefinition {
        private Boolean firstCountLimitEnabled;
        private HitRate hitRate;
    }

    @Builder
    @Data
    public static class HitRate {
        private String frequency;
        private Integer limit;
    }

    @Builder
    @Data
    public static class RuleOutputs {
        private String actionType;
        private Boolean blockingRelease;
        private String holdNarrative;
        private Integer holdPercentage;
        private String releaseNarrative;
        private Integer releasePercentage;
        private String informationNarrative;
        public String informationNarrativeAssignee;
        private Boolean secretTask;
        private String selfClosingTaskType;
        private Integer timeToClose;
        private String assigneeId;
        private String alvsCheckCode;
        private String alvsDepartmentCode;
    }

    @Builder
    @Data
    public static class BaseLocation {
        private String locationUuid;
        private String locationName;
    }
}
