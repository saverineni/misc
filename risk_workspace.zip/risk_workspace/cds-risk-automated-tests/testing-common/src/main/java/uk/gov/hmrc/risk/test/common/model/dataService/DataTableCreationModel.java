package uk.gov.hmrc.risk.test.common.model.dataService;

import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * Created by James Philipps on 13/04/17.
 */
@Builder
@Data
public class DataTableCreationModel {
    private String tableName, description, dataTypeUuid, userPid, creationShareType, tableType;
    private String userBaseLocation;
//    private List<String> locationUuids;
    private List<String> tags;
    private String reason;
    private List<TableShares> tableShares;

    @Builder
    @Data
    public static class TableShares {

        private String shareType;   //creator, user, owner
        private List<String> locationUuids;
    }
}


