package uk.gov.hmrc.risk.test.common.enums;

public enum Matcher {

    //Matcher class matchers
    equalTo, lessThan, lessThanOrEqualTo, greaterThan, greaterThanOrEqualTo,
    containsString, startsWith,

    //CdsRiskMatcher class matchers
    collectionContainsString, collectionStartsWith, collectionEqualTo, collectionMatchesPattern, matchesPattern
}
