package uk.gov.hmrc.risk.test.common.enums;

public enum SensitivityLevel {

    Restricted,
    Sensitive,
    Unrestricted
}
