package uk.gov.hmrc.risk.test.common.util;

import lombok.Getter;
import lombok.Setter;
import uk.gov.hmrc.risk.test.common.enums.DeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.DmsDeclarationParam;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by James Philipps on 13/04/17.
 */
@Getter
@Setter
public class DeTokenizer {

    private String tokenPrefix = "#";
    private String tokenSuffix = "#";

    private boolean removingNonReplacedTokens = true;

    public Set<String> getTokens(String source) {
        Set<String> tokens = new HashSet<>();
        Matcher m = Pattern.compile(token("(.+?)")).matcher(source);
        while (m.find()) {
            tokens.add(m.group(1));
        }
        return tokens;
    }

    public String replaceTokens(String source, Map<DeclarationParam, String> tokenValues) {

        String result = source;
        for (Map.Entry<DeclarationParam, String> entry : tokenValues.entrySet()) {
            result = result.replaceAll(token(entry.getKey().toString()), entry.getValue());
        }

        if (removingNonReplacedTokens) {
            result = result.replaceAll(token(".+?"), "");
        }

        return result;
    }

    public String replaceTokensStrings(String source, Map<String, String> tokenValues) {

        String result = source;
        for (Map.Entry<String, String> entry : tokenValues.entrySet()) {
            result = result.replaceAll(token(entry.getKey()), entry.getValue());
        }

        if (removingNonReplacedTokens) {
            result = result.replaceAll(token(".+?"), "");
        }

        return result;
    }

    public String replaceDmsDecTokens(String source, Map<DmsDeclarationParam, String> tokenValues) {

        String result = source;
        for (Map.Entry<DmsDeclarationParam, String> entry : tokenValues.entrySet()) {
            result = result.replaceAll(token(entry.getKey().toString()), entry.getValue());
        }

        if (removingNonReplacedTokens) {
            result = result.replaceAll(token(".+?"), "");
        }

        return result;
    }

    private String token(String namePattern) {
        return Pattern.quote(tokenPrefix) + namePattern + Pattern.quote(tokenSuffix);
    }
}
