package uk.gov.hmrc.risk.test.common.model.darService;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class DarDataTableTagsModel {

    private String type, packageUuid, tableUuid, tagUuid, tagName;

    public static DarDataTableTagsModel create(String[] line) {
        return new DarDataTableTagsModel(
                line[0],          // type
                line[1],          // packageUuid
                line[2],          // tableUuid
                line[3],          // tagUuid
                line[4]);         // tagName
    }

    private DarDataTableTagsModel(String type, String packageUuid, String tableUuid, String tagUuid, String tagName) {
        this.type = type;
        this.packageUuid = packageUuid;
        this.tableUuid = tableUuid;
        this.tagUuid = tagUuid;
        this.tagName = tagName;
    }
}
