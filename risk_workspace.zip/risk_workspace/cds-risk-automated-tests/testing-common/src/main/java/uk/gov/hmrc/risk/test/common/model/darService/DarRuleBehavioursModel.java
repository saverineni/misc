package uk.gov.hmrc.risk.test.common.model.darService;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class DarRuleBehavioursModel {

    private String type, packageUuid, ruleUuid, ruleVersion;
    private String darActionType, narrative, isSecretTask, releasePercentage, holdPercentage;
    private String assignee;
    private String email;
    private String checkCode,depCode;

    public static DarRuleBehavioursModel create(String[] line) {
        return new DarRuleBehavioursModel(
                line[0],          // type
                line[1],          // packageUuid
                line[2],          // ruleUuid
                line[3],          // ruleVersion
                line[4],          // darActionType
                line[5],          // narrative
                line[6],          // isSecretTask
                line[7],          // releasePercentage
                line[8],          // holdPercentage
                line[9],          // assignee
                line[10],         // email
                line[11],         // checkCode
                line[12]);        // deptCode

    }

    private DarRuleBehavioursModel(String type, String packageUuid, String ruleUuid, String ruleVersion,
                                   String darActionType, String narrative, String isSecretTask, String releasePercentage,
                                   String holdPercentage, String assignee, String email, String checkCode,String depCode) {
        this.type = type;
        this.packageUuid = packageUuid;
        this.ruleUuid = ruleUuid;
        this.ruleVersion = ruleVersion;
        this.darActionType = darActionType;
        this.narrative = narrative;
        this.isSecretTask = isSecretTask;
        this.releasePercentage = releasePercentage;
        this.holdPercentage = holdPercentage;
        this.assignee = assignee;
        this.email = email;
        this.checkCode=checkCode;
        this.depCode=depCode;
    }
}
