package uk.gov.hmrc.risk.test.common.model.darService;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class DarDataTableAuditModel {

    private String type, eventTime, packageUuid, tableUuid, tableName, tableDescription, tableType, tableLastChangedBy;
    private String numberOfDataItems, numberOfLocations, numberOfTags, lastChangeTime;

    public static DarDataTableAuditModel create(String[] line) {
        return new DarDataTableAuditModel(
                line[0],          // type
                line[1],          // timestamp
                line[2],          // packageUuid
                line[3],          // tableUuid
                line[4],          // tableName
                line[5],          // tableDescription
                line[6],          // tableType
                line[7],          // tableLastChangedBy
                line[8],          // numberOfDataItems
                line[9],          // numberOfTags
                line[10],         // numberOfLocations
                line[11]);        // lastChangeTime
    }

    private DarDataTableAuditModel(String type, String eventTime, String packageUuid, String tableUuid, String tableName,
                                   String tableDescription, String tableType, String tableLastChangedBy,
                                   String numberOfDataItems, String numberOfTags, String numberOfLocations,
                                   String lastChangeTime) {
        this.type = type;
        this.eventTime = eventTime;
        this.packageUuid = packageUuid;
        this.tableUuid = tableUuid;
        this.tableName = tableName;
        this.tableDescription = tableDescription;
        this.tableType = tableType;
        this.tableLastChangedBy = tableLastChangedBy;
        this.numberOfDataItems = numberOfDataItems;
        this.numberOfTags = numberOfTags;
        this.numberOfLocations = numberOfLocations;
        this.lastChangeTime = lastChangeTime;
    }
}
