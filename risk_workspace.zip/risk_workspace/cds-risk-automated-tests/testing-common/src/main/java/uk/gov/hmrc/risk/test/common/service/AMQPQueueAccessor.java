package uk.gov.hmrc.risk.test.common.service;

import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.Header;
import org.apache.http.client.fluent.Request;
import org.apache.http.message.BasicHeader;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import javax.jms.BytesMessage;
import javax.jms.TextMessage;
import java.io.ByteArrayOutputStream;
import java.net.URLEncoder;
import java.util.Map;

import static uk.gov.hmrc.risk.test.common.service.RestSupport.statusCode2xx;


/**
 * Created by James Philipps on 12/04/17.
 */
@Slf4j
@RequiredArgsConstructor
public class AMQPQueueAccessor {

    private final int DEFAULT_TIMEOUT = 10;

    private final RestSupport restSupport;
    private final RabbitTemplate rabbitTemplate;
    private final QueueConfiguration config;

    public void send(String xml) {
        rabbitTemplate.convertAndSend(xml);
    }

    public String receive() {
        return receive(DEFAULT_TIMEOUT);
    }

    @Synchronized
    public String receive(int timeoutInSeconds) {
        try {
            rabbitTemplate.setReceiveTimeout(timeoutInSeconds * 1000);
            String response = extractMessageBody(rabbitTemplate.receive());
            log.debug("Receive from queue. Response: {}", response);
            return response;
        } finally {
            rabbitTemplate.setReceiveTimeout(timeoutInSeconds * 1000);
        }
    }

    @SneakyThrows
    public void purge() {
        String purgeUrl = "http://" + config.getHost() + ":" + config.getManagementPort() + "/api/queues/" +
                URLEncoder.encode(config.getVirtualHost() , "UTF-8") + "/" + config.getName() + "/contents";

        Header auth = getAuthHeader();

        log.info("Purging queue: '{}'", config.getName());
        log.info("Url: '{}' ", purgeUrl);
        log.info("Auth Header: '{}' ", auth);

        Request request = Request.Delete(purgeUrl).addHeader(auth);
        restSupport.getResponseAsString(request, statusCode2xx());
    }

    @SneakyThrows
    public int getNumberOfReadyMessages() {
        String purgeUrl = "http://" + config.getHost() + ":" + config.getManagementPort() + "/api/queues/" +
                URLEncoder.encode(config.getVirtualHost() , "UTF-8") + "/" + config.getName();

        Header auth = getAuthHeader();

        log.debug("Purging queue: '{}'", config.getName());
        log.debug("Url: '{}' ", purgeUrl);
        log.debug("Auth Header: '{}' ", auth);

        Request request = Request.Delete(purgeUrl).addHeader(auth);
        Map<String, String> response = restSupport.getResponseAsJson(request, Map.class, statusCode2xx());
        return Integer.parseInt(response.get("messages_ready"));
    }

    private Header getAuthHeader() {
        String plainCreds = config.getUser() + ":" + config.getPassword();
        byte[] plainCredsBytes = plainCreds.getBytes();
        byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
        String base64Creds = new String(base64CredsBytes);

        return new BasicHeader("Authorization", "Basic " + base64Creds);
    }

    @SneakyThrows
    private String extractMessageBody(Message message) {
        if (message == null) {
            return null;
        }

        if (BytesMessage.class.isAssignableFrom(message.getClass())) {
            return readBytesMessage((BytesMessage) message);
        }
        if (TextMessage.class.isAssignableFrom(message.getClass())) {
            return ((TextMessage) message).getText();
        }
        throw new IllegalArgumentException("Don't know how to extract message body from class: " +
                message.getClass().getName());
    }

    @SneakyThrows
    private String readBytesMessage(BytesMessage message) {
        final int byteBufferSize = 16384;

        ByteArrayOutputStream buffer = new ByteArrayOutputStream();

        int nRead;
        byte[] data = new byte[byteBufferSize];

        while ((nRead = message.readBytes(data, byteBufferSize)) != -1) {
            buffer.write(data, 0, nRead);
        }

        buffer.flush();
        return new String(buffer.toByteArray(), "UTF-8");
    }

    @Builder
    @Getter
    public static class QueueConfiguration {
        private String host;
        private int port;
        private int managementPort;
        private String virtualHost;
        private String user;
        private String password;
        private String name;
    }
}
