package uk.gov.hmrc.risk.test.common.util;

import java.util.Collection;
import java.util.Map;

/**
 * Created by James Philipps on 04/08/17.
 */
public class DataUtils {

    public static boolean isNullOrEmpty(String s) {
        return s == null || s.trim().length() == 0;
    }

    public static boolean isNullOrEmpty(Collection<?> v) {
        return v == null || v.size() == 0;
    }

    public static boolean isNullOrEmpty(Map<?, ?> v) {
        return v == null || v.size() == 0;
    }
}
