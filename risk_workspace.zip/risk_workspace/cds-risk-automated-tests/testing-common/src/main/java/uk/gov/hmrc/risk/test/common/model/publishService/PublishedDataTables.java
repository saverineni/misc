package uk.gov.hmrc.risk.test.common.model.publishService;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;
import lombok.ToString;

import java.util.List;
import java.util.UUID;

@Data
@ToString
public class PublishedDataTables {

    private UUID packageVersion;
    private UUID publishEventId;
    private List<JsonNode> dataTables;

    @JsonCreator
    public PublishedDataTables(@JsonProperty("packageVersion") String packageVersion,
                               @JsonProperty("publishEventId") String publishEventId,
                               @JsonProperty("timestamp") String timestamp,
                               @JsonProperty("dataTables") List<JsonNode> dataTables
                               ) {
        this.packageVersion = packageVersion != null ? UUID.fromString(packageVersion) : null;
        this.publishEventId = publishEventId != null ? UUID.fromString(publishEventId) : null;
        this.dataTables = dataTables;
    }
}