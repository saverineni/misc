package uk.gov.hmrc.risk.test.common.service.docker;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.spotify.docker.client.DockerClient;
import com.spotify.docker.client.DockerClient.ListContainersParam;
import com.spotify.docker.client.messages.Container;
import com.spotify.docker.client.messages.ContainerConfig;
import com.spotify.docker.client.messages.ContainerCreation;
import com.spotify.docker.client.messages.HostConfig;
import lombok.*;
import lombok.Builder.Default;
import lombok.extern.slf4j.Slf4j;

import java.util.*;
import java.util.stream.Collectors;

import static uk.gov.hmrc.risk.test.common.util.DataUtils.isNullOrEmpty;

/**
 * Created by James Philipps on 15/06/17.
 */
@Slf4j
@RequiredArgsConstructor
public class GenericDockerSupport {

    private final DockerSupportConfig config;

    private DockerClient dockerClient;

    public Optional<ContainerAccessor> getContainerByNameOnPortPrefix(String name, int portPrefix) {
        return getContainers().filter(ContainerFilter.hasName(name, false), ContainerFilter.hasPortPrefix(portPrefix)).first();
    }

    @SneakyThrows
    public ContainerListing getContainers() {
        List<Container> containers = getDockerClient().listContainers(ListContainersParam.allContainers());
        return new ContainerListing(
                containers.stream()
                        .map(c -> new ContainerAccessor(config, dockerClient, c))
                        .collect(Collectors.toList())
        );
    }

    public void pull(String registryUri, String name, String tag) {
        pull(String.format("%s/%s:%s", registryUri, name, tag));
    }

    @SneakyThrows
    public void pull(String image) {
        log.debug("Pulling image: {}", image);
        getDockerClient().pull(image);
        log.debug("Pull complete");
    }

    @SneakyThrows
    public String createContainer(ContainerCreationConfig creationConfig) {
        creationConfig.validate();

        log.debug("Creating container using config: {}", creationConfig);

        ContainerConfig.Builder configBuilder = ContainerConfig.builder()
                .image(creationConfig.getSourceImage());

        List<String> environmentVariables = new ArrayList<>();
        if (!isNullOrEmpty(creationConfig.getEnvironmentVariables())) {
            environmentVariables.addAll(
                    creationConfig.getEnvironmentVariables().entrySet().stream()
                            .map(e -> String.format("%s=%s", e.getKey(), e.getValue()))
                            .collect(Collectors.toList())
            );
        }

        if (!isNullOrEmpty(creationConfig.getSpringPropertyOverrides())) {
            String json = new ObjectMapper().writeValueAsString(creationConfig.getSpringPropertyOverrides());
            environmentVariables.add("SPRING_APPLICATION_JSON=" + json);
        }

        if (!isNullOrEmpty(creationConfig.getExtraHosts())) {
            configBuilder.hostConfig(
                    HostConfig.builder()
                            .extraHosts(
                                    creationConfig.getExtraHosts().stream()
                                            .map(HostFileEntry::toEntry)
                                            .collect(Collectors.toList())
                            )
                            .build()
            );
        }

        ContainerConfig config = configBuilder
                .env(environmentVariables)
                .build();

        ContainerCreation container = creationConfig.getName() != null ?
                getDockerClient().createContainer(config, creationConfig.getName()) :
                getDockerClient().createContainer(config);

        log.debug("Created container with id: {}", container.id());

        return container.id();
    }

    @SneakyThrows
    private DockerClient getDockerClient() {
        if (dockerClient == null) {
            List<String> potentialHostUris = new ArrayList<>();
            if (isLocalhost()) {
                // Attempt a socket connection to the local daemon first
                potentialHostUris.add("unix:///var/run/docker.sock");
            }
            // Attempt a connection via the docker remote protocol
            potentialHostUris.add(String.format("http://%s:2375", config.getHost()));

            for (String uri : potentialHostUris) {
                log.debug("Attempting to create DockerClient using URI: '{}'", uri);
                try {
                    dockerClient = config.getDockerClientProvider().newClient(uri);
                    log.debug("Created a DockerClient using URI: {}", uri);
                    break;
                } catch (Exception e) {
                    log.warn("Failed to create DockerClient using uri: '{}'", uri);
                    log.debug("", e);
                }
            }
            if (dockerClient == null) {
                throw new IllegalArgumentException("Unable to create a DockerClient using provided host parameter!");
            }
        }
        return dockerClient;
    }

    private boolean isLocalhost() {
        Set<String> localhostUris = new HashSet<>(Arrays.asList("localhost", "127.0.0.1"));
        return localhostUris.contains(config.getHost().trim().toLowerCase());
    }

    @Builder
    @Getter
    public static class DockerSupportConfig {
        private String host;

        @Default
        private DockerClientProvider dockerClientProvider = new DefaultDockerClientProvider();
        @Default
        private HostConnectivityChecker hostConnectivityChecker = new DefaultHostConnectivityChecker();

        @Default
        private int containerStopForceTimeSeconds = 10;
    }

    @Getter
    @Builder
    @ToString
    @AllArgsConstructor
    public static class ContainerCreationConfig {
        private String sourceImage;
        private String name;
        private Map<String, String> environmentVariables;
        private Map<String, String> springPropertyOverrides;
        private List<HostFileEntry> extraHosts;
        private List<PortMapping> portMappings;

        public void validate() {
            Set<String> missingfields = new HashSet<>();
            if (isNullOrEmpty(sourceImage)) {
                missingfields.add(sourceImage);
            }

            if (missingfields.size() > 0) {
                throw new IllegalArgumentException("Invalid ContainerCreationConfig. Required fields missing: " +
                        missingfields.toString());
            }
        }

    }

    @Data
    @RequiredArgsConstructor
    public static class PortMapping {
        private final int internalPort, externalPort;
    }

    @Getter
    @ToString
    @RequiredArgsConstructor
    public static class HostFileEntry {
        private final String name, ip;

        public String toEntry() {
            return String.format("%s:%s", name, ip);
        }
    }


}
