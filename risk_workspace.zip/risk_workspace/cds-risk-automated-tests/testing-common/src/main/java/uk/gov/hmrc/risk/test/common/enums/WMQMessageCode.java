package uk.gov.hmrc.risk.test.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum WMQMessageCode {

    MQ_CLEARED ("AMQ8022I:"),
    MQ_ALREADY_EMPTY ("AMQ8148E:");

    String code;
}
