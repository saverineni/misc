package uk.gov.hmrc.risk.test.common.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableList;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.fluent.Request;
import uk.gov.hmrc.risk.test.common.enums.DarEventType;
import uk.gov.hmrc.risk.test.common.model.darService.*;

import java.io.StringReader;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toList;

@Slf4j
@RequiredArgsConstructor
public class DARServiceSupport {

    private final ObjectMapper jsonMapper;
    private final RestSupport restSupport;
    private final DockerSupport dockerSupport;

    private final DARServiceSupportConfig config;

    public ZonedDateTime getFormattedTimestamp(String timestamp) {
        String basePattern = "yyyy-MM-dd'T'HH:mm:ss";
        DateTimeFormatter formatter =
                new DateTimeFormatterBuilder().appendPattern(basePattern)
                        .appendFraction(ChronoField.NANO_OF_SECOND, 0, 9, true)
                        .appendZoneOrOffsetId()
                        .toFormatter();
        return ZonedDateTime.parse(timestamp, formatter);
    }

    private List<String> findDataItemsFor(String packageId, String tableUuid, List<String> fileLines) {

        Optional<String[]> result = parseCsvRows(fileLines)
                .filter(
                        byRowType("DATA_TABLE_ITEMS")
                                .and(byPackageId(packageId))
                                .and(byParentId(tableUuid))
                )
                .map(r -> Arrays.copyOfRange(r, 4, r.length))
                .findFirst();

        return result.map(Arrays::asList)
                .orElse(ImmutableList.of());
    }

    public List<DarRuleAuditModel> parseRuleAuditEvents() {
        String path = getDAREventFilePath(DarEventType.RULE_AUDIT);
        List<String> fileContents = dockerSupport.getDARClientPublishingContainer().getFileContents(path);
        return parseCsvRows(fileContents)
                .map(DarRuleAuditModel::create)
                .collect(toList());
    }

    public List<DarRuleDataTablesModel> parseRuleDataTableEvents() {
        String path = getDAREventFilePath(DarEventType.RULE_DATA_TABLES);
        List<String> fileContents = dockerSupport.getDARClientPublishingContainer().getFileContents(path);
        return parseCsvRows(fileContents)
                .map(DarRuleDataTablesModel::create)
                .collect(toList());
    }

    public List<DarRuleLocationsModel> parseRuleLocationsEvents() {
        String path = getDAREventFilePath(DarEventType.RULE_LOCATIONS);
        List<String> fileContents = dockerSupport.getDARClientPublishingContainer().getFileContents(path);
        return parseCsvRows(fileContents)
                .map(DarRuleLocationsModel::create)
                .collect(toList());
    }

    public List<DarRuleBehavioursModel> parseRuleBehavioursEvents() {
        String path = getDAREventFilePath(DarEventType.RULE_BEHAVIOURS);
        List<String> fileContents = dockerSupport.getDARClientPublishingContainer().getFileContents(path);
        return parseCsvRows(fileContents)
                .map(DarRuleBehavioursModel::create)
                .collect(toList());
    }

    public List<DarDataTableAuditModel> parseDataTableAuditEvents() {
        String path = getDAREventFilePath(DarEventType.DATA_TABLE_AUDIT);
        List<String> fileContents = dockerSupport.getDARClientPublishingContainer().getFileContents(path);
        List<DarDataTableAuditModel> collect = parseCsvRows(fileContents)
                .map(DarDataTableAuditModel::create)
                .collect(toList());
        return  collect;
    }

    public List<DarDataTableItemsModel> parseDataTableItemsEvents() {
        String path = getDAREventFilePath(DarEventType.DATA_TABLE_ITEMS);
        List<String> fileContents = dockerSupport.getDARClientPublishingContainer().getFileContents(path);
        return parseCsvRows(fileContents)
                .map(DarDataTableItemsModel::create)
                .collect(toList());
    }

    public List<DarDataTableTagsModel> parseDataTableTagsEvents() {
        String path = getDAREventFilePath(DarEventType.DATA_TABLE_TAGS);
        List<String> fileContents = dockerSupport.getDARClientPublishingContainer().getFileContents(path);
        return parseCsvRows(fileContents)
                .map(DarDataTableTagsModel::create)
                .collect(toList());
    }

    public List<DarDataTableLocationsModel> parseDataTableLocationsEvents() {
        String path = getDAREventFilePath(DarEventType.DATA_TABLE_LOCATIONS);
        List<String > fileContents = dockerSupport.getDARClientPublishingContainer().getFileContents(path);
        return parseCsvRows(fileContents)
                .map(DarDataTableLocationsModel::create)
                .collect(toList());
    }

    public List<DarErrorModel> parseErrorEvents() {
        String path = getDAREventFilePath(DarEventType.DECLARATION_RISKING_ERROR);
        List<String > fileContents = dockerSupport.getDARClientAuditContainer().getFileContents(path);
        return parseCsvRows(fileContents)
                .map(DarErrorModel::create)
                .collect(toList());
    }

    public List<DarDeclarationRiskedModel> parseDeclarationRisk() {
        String path = getDAREventFilePath(DarEventType.DECLARATION_RISKED);
        List<String> fileContents = dockerSupport.getDARClientAuditContainer().getFileContents(path);

        System.out.println("fileContents = " + fileContents);

        return parseCsvRows(fileContents)
                .map(DarDeclarationRiskedModel::create)
                .collect(toList());
    }

    public List<DarDeclarationRiskedEventModel> parseDeclarationRiskedEvent() {
        String path = getDAREventFilePath(DarEventType.DECLARATION_RISK_RESULT);
        List<String> fileContents = dockerSupport.getDARClientAuditContainer().getFileContents(path);
        return parseCsvRows(fileContents)
                .map(DarDeclarationRiskedEventModel::create)
                .collect(toList());
    }
    @SneakyThrows
    private <T> List<T> oldParseEvents(List<String> fileLines, Class<T> clazz) {
        List<T> events = new ArrayList<>();

        for (String line : fileLines) {
            events.add(jsonMapper.readValue(line, clazz));
        }
        return events;
    }

    public String getDAREventFilePath(DarEventType eventType) {

        Request request = Request.Get(config.getEventFilePathUrl().replace("{eventType}", eventType.toString()));
        return restSupport.getResponseAsString(request);
    }

    private Stream<String[]> parseCsvRows(List<String> fileLines) {
        return fileLines.stream()
                .filter(l -> !Strings.isNullOrEmpty(l))
                .map(this::toCsvArray);
    }

    @SneakyThrows
    private String[] toCsvArray(String line) {
        CSVReader reader = new CSVReaderBuilder(new StringReader(line))
                .withCSVParser(new CSVParserBuilder().build())
                .build();

        return reader.readNext();
    }

    private Predicate<String[]> byRowType(String type) {
        return (row) -> row[0].equals(type);
    }

    private Predicate<String[]> byPackageId(String packageId) {
        return (row) -> row[1].equals(packageId);
    }

    private Predicate<String[]> byParentId(String parentId) {
        return (row) -> row[2].equals(parentId);
    }

    @Builder
    @Getter
    public static class DARServiceSupportConfig {
        String logFileUrl, eventFilePathUrl;
    }
}
