package uk.gov.hmrc.risk.test.common.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import uk.gov.hmrc.risk.test.common.model.publishService.PublishEventModel;
import uk.gov.hmrc.risk.test.common.model.publishService.PublishedDataTables;
import uk.gov.hmrc.risk.test.common.model.publishService.PublishedRules;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

@AllArgsConstructor
@Slf4j
public class CacheLoaderSupport {
    public static final String LATEST_PUB_EVENT_SQL =
            "select * from publish_events order by event_timestamp desc limit 1";
    public static final String SPECIFIC_PUB_EVENT_SQL =
            "select * from publish_events where publish_event_id = ? ";
    public static final String DATA_PACKAGE_SQL =
            "select body from published_packages where package_uuid = ? ";

    @Getter
    private JdbcTemplate jdbcTemplate;
    private ObjectMapper objectMapper;

    public void clearDown() {
        jdbcTemplate.update("delete from publish_events");
        jdbcTemplate.update("delete from published_packages");
    }

    public PublishEventModel getPublishEvent(UUID publishEventId) {
        return getPublishEvent(publishEventId.toString());
    }

    public PublishEventModel getPublishEvent(String publishEventId) {
        return queryForPublishEvent(SPECIFIC_PUB_EVENT_SQL, publishEventId);
    }

    public PublishedRules getPublishedRules(String packageId) {
        return queryForDataPackage(packageId, PublishedRules.class);
    }
    public PublishedDataTables getPublishedDataTables(String packageId) {
        return queryForDataPackage(packageId, PublishedDataTables.class);
    }

    private PublishEventModel queryForPublishEvent(String sql, Object ... args) {
        try {
            return jdbcTemplate.queryForObject(sql, new PublishEventMapper(), args);
        } catch (DataAccessException e) {
            log.info("Failed to retrieve Publish Event from DB. msg:{}", e.getMessage());
        }
        return null;
    }
    @SneakyThrows
    private <T> T queryForDataPackage(String packageId, Class<T> packageType) {
        try {
            String s = jdbcTemplate.queryForObject(DATA_PACKAGE_SQL, String.class, packageId);
            return objectMapper.readValue(s, packageType);
        } catch (DataAccessException e) {
            log.info("Failed to retrieve Data Package for id '{}' from DB. msg:{}", packageId, e.getMessage());
        }
        return null;
    }

    public UUID getPublishEventId(UUID expectedPublishEventId, int secondsToWait) {
        PublishEventModel latestPublishEvent = getLatestPublishEvent(expectedPublishEventId, secondsToWait);
        return null != latestPublishEvent ? latestPublishEvent.getPublishEventId() : null;
    }

    @SneakyThrows
    public PublishEventModel getLatestPublishEvent(UUID expectedPublishEventId, int secondsToWait) {
        long quitTime = System.currentTimeMillis() + (1000 * secondsToWait);
        while (quitTime > System.currentTimeMillis()) {
            PublishEventModel latestPublishEvent = getLatestPublishEvent(secondsToWait);
            if (latestPublishEvent != null && expectedPublishEventId.equals(latestPublishEvent.getPublishEventId())) {
                return latestPublishEvent;
            }
            Thread.sleep(100);
        }
        log.info("Failed to find latest publish event with expect id of {}, within time of {} seconds",
                expectedPublishEventId, secondsToWait);
        return null;
    }
    @SneakyThrows
    public PublishEventModel getLatestPublishEvent(int secondsToWait) {
        long quitTime = System.currentTimeMillis() + (1000 * secondsToWait);
        while (quitTime > System.currentTimeMillis()) {
            PublishEventModel publishEventModel = queryForPublishEvent(LATEST_PUB_EVENT_SQL, null);
            if (publishEventModel != null){
                return publishEventModel;
            }
            Thread.sleep(100);
        }
        log.info("Failed to find any latest publish event, within time of {} seconds", secondsToWait);
        return null;
    }

    private static class PublishEventMapper implements RowMapper<PublishEventModel> {
        @Override
        public PublishEventModel mapRow(ResultSet rs, int i) throws SQLException {
            return new PublishEventModel(
                    rs.getString("publish_event_id"),
                    rs.getString("message_id"),
                    rs.getString("event_timestamp"),
                    rs.getString("rules_package"),
                    rs.getString("data_table_package"),
                    null, null);
        }
    }
}
