package uk.gov.hmrc.risk.test.common.model.dataService;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Getter;

import java.util.List;

/**
 * Created by James Philipps on 13/04/17.
 */
@Getter
@Builder
public class DataTableEditModel {
    private String userPid, dataTableUuid, tableName, description;
    private int opLockVersion;
    private List<String> addedElements, removedElements, tags;
    private String reason;

    public static class DataTableEditModelBuilder{
        private List<String> addedElements = ImmutableList.of();
        private List<String> removedElements = ImmutableList.of();
        private List<String> tags = ImmutableList.of();
    }
}
