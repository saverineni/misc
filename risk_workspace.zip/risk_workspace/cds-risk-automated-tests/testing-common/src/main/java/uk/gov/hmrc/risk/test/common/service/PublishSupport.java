package uk.gov.hmrc.risk.test.common.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.fluent.Request;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import uk.gov.hmrc.risk.rulesengine.publishing.DataTablePackage;
import uk.gov.hmrc.risk.rulesengine.publishing.PublishEventFullDto;
import uk.gov.hmrc.risk.rulesengine.publishing.RulePackage;
import uk.gov.hmrc.risk.test.common.model.publishService.PublishEventModel;

import java.net.URI;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static uk.gov.hmrc.risk.test.common.service.RestSupport.statusCode2xx;

@Slf4j
@RequiredArgsConstructor
public class PublishSupport {

    private final RestSupport restSupport;
    private final ObjectMapper jsonMapper;

    private final PublishServiceConfig config;
    private final PublishEventSubscriber publishEventSubscriber;
//    private final AMQPQueueAccessor queueAccessor;
    private final RabbitTemplate publishTemplate;

    private final String defaultSuperAdminPID = "1234560";

    @SneakyThrows
    public void republish(String publishEventUuid) {
        log.info("Retrieving rule and data packages for republish");
        RulePackage rulePackage = retrievePublishedPackage(config.getRuleServicePublishUrl(), publishEventUuid, RulePackage.class);
        log.info("Rule package retrieved");
        DataTablePackage dataPackage = retrievePublishedPackage(config.getDataServicePublishUrl(), publishEventUuid, DataTablePackage.class);
        log.info("Data package retrieved");

        PublishEventFullDto event = PublishEventFullDto.builder()
                .messageId(UUID.randomUUID())
                .publishEventId(UUID.fromString(publishEventUuid))
                .rulePackage(rulePackage)
                .dataTablePackage(dataPackage)
                .timestamp(Instant.now())
                .build();

        String publishMessage = jsonMapper.writeValueAsString(event);

        publishTemplate.convertAndSend(publishMessage);
    }

    @SneakyThrows
    private <T> T retrievePublishedPackage(String url, String publishUuid, Class<T> responseType) {
        URI uri = new URIBuilder(url)
                .addParameter("eventUuid", publishUuid)
                .build();


        Request request = Request.Get(uri)
                .addHeader(RestSupport.AUTH_HEADER_NAME, defaultSuperAdminPID);

        return restSupport.getResponseAsJson(request, responseType);
    }

    @SneakyThrows
    public List<String> findPublishIdsForReasonPrefix(String publishReasonPrefix) {
        return findPublishIds(config.getPublishRequestUrl()+"/history?page=0&size=100")
                        .filter(history -> history.getReason().startsWith(publishReasonPrefix))
                        .filter(history -> history.getPublishUuid() != null)
                        .map(PublishHistoryDto::getPublishUuid)
                        .collect(Collectors.toList());
    }

    @SneakyThrows
    public List<PublishHistoryDto> findPublishHistory() {
        return findPublishIds(config.getPublishRequestUrl()+"/history?page=0&size=100")
                .filter(history -> history.getPublishUuid() != null)
                .collect(Collectors.toList());
    }

    @SneakyThrows
    public List<String> findAllAvailablePublishIds() {
        return findPublishIds(config.getPublishRequestUrl()+"/history?page=0&size=100")
                .filter(history -> history.getPublishUuid() != null)
                .map(PublishHistoryDto::getPublishUuid)
                .collect(Collectors.toList());
    }

    @SneakyThrows
    private Stream<PublishHistoryDto> findPublishIds(String url) {
        URI uri = new URIBuilder(url)
                .build();

        Request request = Request.Get(uri)
                .addHeader(RestSupport.AUTH_HEADER_NAME, defaultSuperAdminPID);

        RestPageImpl<PublishHistoryDto> historyEntries =
                restSupport.getTypedResponseAsJson(request, new TypeReference<RestPageImpl<PublishHistoryDto>>() {});

        return historyEntries.getContent()
                .stream();
    }

    public PublishEventFullDto sendPublishRequest() {
        return sendPublishRequest("Default test reason", defaultSuperAdminPID);
    }

    public PublishEventFullDto sendPublishRequest(String reason) {
        return sendPublishRequest(reason, defaultSuperAdminPID);
    }

    @SneakyThrows
    public PublishEventFullDto sendPublishRequest(String reason, String userPid) {

        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("publishReason", reason);
        String jsonBody = jsonMapper.writeValueAsString(jsonMap);

        log.info("Sending publish request: {}", jsonBody);

        Request request = Request.Post(config.getPublishRequestUrl())
                .bodyByteArray(jsonBody.getBytes(), ContentType.APPLICATION_JSON)
                .addHeader(RestSupport.AUTH_HEADER_NAME, userPid)
                .addHeader("userPid", userPid) // TODO Remove once publishing service released with new header
                ;

        return restSupport.getResponseAsJson(request, PublishEventFullDto.class, statusCode2xx());
//        log.debug("Response: " + response);
    }

    public void setPublishInterval(int intervalInSeconds) {
        setPublishInterval(intervalInSeconds, "Default reason", defaultSuperAdminPID);
    }

    @SneakyThrows
    public void setPublishInterval(int intervalInSeconds, String reason, String userPid) {
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("interval", intervalInSeconds);
        jsonMap.put("reason", reason);
        String requestJson = jsonMapper.writeValueAsString(jsonMap);

        log.debug("Set publish interval json: {}", requestJson);
        log.debug("Setting publish interval to: {}", intervalInSeconds);

        Request request = Request.Post(config.getChangePublishIntervalUrl())
                .bodyByteArray(requestJson.getBytes(), ContentType.APPLICATION_JSON)
                .addHeader(RestSupport.AUTH_HEADER_NAME, userPid)
                .addHeader("userPid", userPid) // TODO Remove once publishing service released with new header
                ;

        restSupport.getResponse(request, statusCode2xx(), true);
    }


    public String getTimeToNextScheduledEvent() {
        return getTimeToNextScheduledEvent(defaultSuperAdminPID);
    }

    public String getTimeToNextScheduledEvent(String userPid) {
        log.info("Sending nextPublish request...");

        Request request = Request.Get(config.getNextPublishUrl())
                .addHeader(RestSupport.AUTH_HEADER_NAME, userPid)
                .addHeader("userPid", userPid) // TODO Remove once publishing service released with new header
                ;
        Map<String, String> json = restSupport.getResponseAsJson(request, Map.class, statusCode2xx());
        return json.get("nextPublishTimestamp");
    }

    public PublishEventModel getPublishEvent(int timeoutInSeconds) {
        return publishEventSubscriber.getPublishEvent(timeoutInSeconds);
    }

    public void forgetLastEvent() {
        publishEventSubscriber.forgetLastEvent();
    }

    @Builder
    @Getter
    public static class PublishServiceConfig {
        private String publishRequestUrl, changePublishIntervalUrl, nextPublishUrl;
        private String ruleServicePublishUrl, dataServicePublishUrl;
//        private String routingKey, exchangeName;
    }
}
