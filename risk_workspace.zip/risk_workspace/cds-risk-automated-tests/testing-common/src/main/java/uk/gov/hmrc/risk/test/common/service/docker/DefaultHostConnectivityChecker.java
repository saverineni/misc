package uk.gov.hmrc.risk.test.common.service.docker;

import java.io.IOException;
import java.net.Socket;

/**
 * Created by James Philipps on 08/08/17.
 */
public class DefaultHostConnectivityChecker implements HostConnectivityChecker {

    public boolean canConnect(String host, int port) {
        try {
            new Socket(host, port);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

}
