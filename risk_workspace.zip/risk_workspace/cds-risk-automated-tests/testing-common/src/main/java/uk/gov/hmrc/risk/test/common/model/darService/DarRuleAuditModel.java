package uk.gov.hmrc.risk.test.common.model.darService;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class DarRuleAuditModel {

    private String type, eventTime, packageUuid, ruleUuid, ruleDescription, ruleName, ruleType, ruleVersionId;
    private String ruleStatus, regimeCode, declarationType, modeOfTransport, creatorPid, createdTimestamp, updatorPid;
    private String lastUpdateTimestamp, startDate, endDate, ratLimit, ratFrequency, drlDef, numberOfLocations;
    private String numberOfDataTables, numberOfBehaviours;

    public static DarRuleAuditModel create(String[] line) {
        return new DarRuleAuditModel(
                line[0],          // type
                line[1],          // eventTime
                line[2],          // packageUuid
                line[3],          // ruleUuid
                line[4],          // ruleDescription
                line[5],          // ruleName
                line[6],          // ruleType
                line[7],          // ruleVersionId
                line[8],          // ruleStatus
                line[9],          // regimeCode
                line[10],         // declarationType
                line[11],         // modeOfTransport
                line[12],         // creatorPid
                line[13],         // createdTimestamp
                line[14],         // updatorPid
                line[15],         // lastUpdateTimestamp
                line[16],         // startDate
                line[17],         // endDate
                line[18],         // ratLimit
                line[19],         // ratFrequency
                line[20],         // drlDef
                line[21],         // numberOfLocations
                line[22],         // numberOfDataTables
                line[23]);         // numberOfBehaviours
    }

    private DarRuleAuditModel(String type, String eventTime, String packageUuid, String ruleUuid, String ruleDescription,
                              String ruleName, String ruleType, String ruleVersionId, String ruleStatus,
                              String regimeCode, String declarationType, String modeOfTransport, String creatorPid,
                              String createdTimestamp, String updatorPid, String lastUpdateTimestamp,
                              String startDate, String endDate, String ratLimit, String ratFrequency, String drlDef,
                              String numberOfLocations, String numberOfDataTables, String numberOfBehaviours) {
        this.type = type;
        this.eventTime = eventTime;
        this.packageUuid = packageUuid;
        this.ruleUuid = ruleUuid;
        this.ruleDescription = ruleDescription;
        this.ruleName = ruleName;
        this.ruleType = ruleType;
        this.ruleVersionId = ruleVersionId;
        this.ruleStatus = ruleStatus;
        this.regimeCode = regimeCode;
        this.declarationType = declarationType;
        this.modeOfTransport = modeOfTransport;
        this.creatorPid = creatorPid;
        this.createdTimestamp = createdTimestamp;
        this.updatorPid = updatorPid;
        this.lastUpdateTimestamp = lastUpdateTimestamp;
        this.startDate = startDate;
        this.endDate = endDate;
        this.ratLimit = ratLimit;
        this.ratFrequency = ratFrequency;
        this.drlDef = drlDef;
        this.numberOfLocations = numberOfLocations;
        this.numberOfDataTables = numberOfDataTables;
        this.numberOfBehaviours = numberOfBehaviours;
    }
}
