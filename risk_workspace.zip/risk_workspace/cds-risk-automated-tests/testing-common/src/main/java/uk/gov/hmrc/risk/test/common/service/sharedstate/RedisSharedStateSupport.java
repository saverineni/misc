package uk.gov.hmrc.risk.test.common.service.sharedstate;

import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.Set;

/**
 * Created by James Philipps on 12/04/17.
 */
@Slf4j
@RequiredArgsConstructor
public class RedisSharedStateSupport implements SharedStateSupport{

    private final RedisSharedStateSupportConfig config;

    public void clearAllKeys() {
        config.getRedisTemplate().delete(getKeys());
    }

    public Set<String> getKeys() {
        return config.getRedisTemplate().keys("*");
    }

    @Builder
    @Getter
    public static class RedisSharedStateSupportConfig {
        private RedisTemplate redisTemplate;
    }
}
