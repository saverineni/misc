package uk.gov.hmrc.risk.test.common.enums;

import lombok.AllArgsConstructor;

/**
 * Created by developer on 31/08/17.
 */
@AllArgsConstructor
public enum ItemCollectionDeclarationParam implements DeclarationParam {

    ID("id"),
    ADDITIONAL_INFORMATION_CODE_ITEM("additionalInformation_CodeItem"),
    ADDITIONAL_INFORMATION_TEXT_ITEM("additionalInformation_TextItem"),
    ADDITIONAL_DOCUMENTS_TYPE_ITEM("additionalDocuments_TypeItem"),
    ADDITIONAL_INFORMATION_LANGUAGE_ITEM("additionalInformation_LanguageItem"),
    ADDITIONAL_DOCUMENTS_ID_ITEM("additionalDocuments_IdItem"),
    ADDITIONAL_DOCUMENTS_QUANTITY_ITEM("additionalDocuments_QuantityItem"),
    ADDITIONAL_DOCUMENTS_STATUS_ITEM("additionalDocuments_StatusItem"),

    ADDITIONAL_ACTOR_ID_ITEM("additionalActorId_Item"),
    ADDITIONAL_ACTOR_ROLE_ITEM("additionalActorRole_Item"),

    VAT_DECLARING_PARTY_ID_ITEM("vatDeclaringPartyId_Item"),
    VAT_DECLARING_PARTY_ROLE_ITEM("vatDeclaringPartyRole_Item"),

    PACKAGE_COUNT_ITEM("packaging_CountItem"),
    PACKAGE_MARKS_ITEM("packaging_MarksItem"),
    PACKAGE_TYPE_ITEM("packaging_TypeItem"),

    VALUATION_ADJJUSTMENTS_CODE_ITEM("valuationAdjustments_CodeItem"),
    CONTAINERS_ID_ITEM("containers_IdItem"),

    DECLARED_DUTY_TAX_FEES_BASE_AMOUNT_ITEM("declaredDutyTaxFees_BaseAmountItem"),
    DECLARED_DUTY_TAX_FEES_BASE_QUANTITY_ITEM("declaredDutyTaxFees_BaseQuantityItem"),
    DECLARED_DUTY_TAX_FEES_PAYMENT_METHOD_ITEM("declaredDutyTaxFees_PaymentMethodItem"),
    DECLARED_DUTY_TAX_FEES_PERCENTAGE_ADJUSTMENT_ITEM("declaredDutyTaxFees_PercentageAdjustmentItem"),
    DECLARED_DUTY_TAX_FEES_PREFERENCE_CODE_ITEM("declaredDutyTaxFees_PreferenceCodeItem"),
    DECLARED_DUTY_TAX_FEES_QUOTO_CODE_ITEM("declaredDutyTaxFees_QuotaCodeItem"),
    DECLARED_DUTY_TAX_FEES_TAX_AMOUNT_ITEM("declaredDutyTaxFees_TaxAmountItem"),
    DECLARED_DUTY_TAX_FEES_TAX_REVENUE_ITEM("declaredDutyTaxFees_TaxRevenueItem"),
    DECLARED_DUTY_TAX_FEES_TAX_TYPE_ITEM("declaredDutyTaxFees_TaxTypeItem"),
    DECLARED_DUTY_TAX_FEES_VAT_VALUE_ITEM("declaredDutyTaxFees_VatValueItem"),

    PREVIOUS_DOCUMENTS_CLASS_ITEM("previousDocuments_ClassItem"),
    PREVIOUS_DOCUMENTS_ID_ITEM("previousDocuments_IdItem"),
    PREVIOUS_DOCUMENTS_TYPE_ITEM("previousDocuments_TypeItem"),
    NAT_CLASSIFICATION_ITEM("natClassifications_Id"),
    TARIC_CLASSIFICATION_ITEM("taricClassifications_Id"),
    MONETARY_AMOUNT_ADJUSTMENT("monetaryAmountAdjustment"),
    VALUATION_ADJUSTMENTS_AMOUNT_ITEM ("valuationAdjustAmount_Item"),
    VALUATION_ADJUSTMENTS_CURRENCY_ITEM ("valuationAdjustCurrency_Item");



    private String paramText;

    @Override
    public String toString() {
        return paramText;
    }

    @AllArgsConstructor
    public enum Second implements DeclarationParam {

        PACKAGE_COUNT_ITEM("packaging_CountItem2"),
        PACKAGE_MARKS_ITEM("packaging_MarksItem2"),
        PACKAGE_TYPE_ITEM("packaging_TypeItem2"),

        ADDITIONAL_INFORMATION_CODE_ITEM("additionalInformation_CodeItem2"),
        ADDITIONAL_INFORMATION_TEXT_ITEM("additionalInformation_TextItem2"),
        VALUATION_ADJUSTMENTS_AMOUNT_ITEM ("valuationAdjustAmount2_Item"),
        VALUATION_ADJUSTMENTS_CURRENCY_ITEM ("valuationAdjustCurrency2_Item");


        private String paramText;

        @Override
        public String toString() {
            return paramText;
        }
    }

}
