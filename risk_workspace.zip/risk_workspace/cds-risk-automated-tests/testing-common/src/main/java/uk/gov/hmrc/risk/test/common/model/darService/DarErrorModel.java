package uk.gov.hmrc.risk.test.common.model.darService;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class DarErrorModel {

    private String type;
    private String time;
    private String riskResponseId;
    private String declarationId;
    private String declarationVersion;
    private String rulesPackage;
    private String errorMessage;
    private String exceptionType;
    private String soapErrorType;

    public DarErrorModel(String type, String time, String riskResponseId, String declarationId, String declarationVersion, String rulesPackage, String errorMessage, String exceptionType, String soapErrorType) {
        this.type = type;
        this.time = time;
        this.riskResponseId = riskResponseId;
        this.declarationId = declarationId;
        this.declarationVersion = declarationVersion;
        this.rulesPackage = rulesPackage;
        this.errorMessage = soapErrorType;
        this.exceptionType = exceptionType;
        this.soapErrorType = errorMessage;
    }

    public static DarErrorModel create(String[] line) {
        return new DarErrorModel(
                line[0],          // type
                line[1],          // timestamp
                line[2],          // responseId
                line[3],          // declarationId
                line[4],          // declaration version
                line[5],          // rules package
                line[6],
                line[7],          // rules package
                line[8]            // count of risk results
        );
    }
}
