package uk.gov.hmrc.risk.test.common.service.declarationSupport;

import lombok.RequiredArgsConstructor;

import static uk.gov.hmrc.risk.test.common.util.IOUtils.readFromClasspath;

@RequiredArgsConstructor
public class ItemColllectionsTemplates {

    public String getAdditionalDocumentsTemplate() {
        return getTemplate("AdditionalDocumentsTemplate");
    }

    public String getAdditionalInformationTemplate() {
        return getTemplate("AdditionalInformationTemplate");
    }

    public String getContainersTemplate() {
        return getTemplate("ContainersTemplate");
    }

    public String getCountryRegionsTemplate() {
        return getTemplate("CountryRegionsTemplate");
    }

    public String getDeclaredDutyTaxFeesTemplate() {
        return getTemplate("DeclaredDutyTaxFeesTemplate");
    }

    public String getItemTemplate() {
        return getTemplate("ItemTemplate");
    }

    public String getPackagingTemplate() {
        return getTemplate("PackagingTemplate");
    }

    public String getPartiesTemplate() {
        return getTemplate("PartiesTemplate");
    }

    public String getPreviousDocumentsTemplate() {
        return getTemplate("PreviousDocumentsTemplate");
    }

    public String getValuationAdjustmentsTemplate() {
        return getTemplate("ValuationAdjustmentsTemplate");
    }

    private String getTemplate(String fileName) {
        return readFromClasspath("risking-testing-common/item-collection-templates/" + fileName+ ".xml");
    }
}
