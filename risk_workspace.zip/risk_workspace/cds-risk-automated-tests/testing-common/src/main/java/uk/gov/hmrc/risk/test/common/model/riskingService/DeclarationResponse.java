package uk.gov.hmrc.risk.test.common.model.riskingService;

import com.google.common.collect.ImmutableList;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import static java.util.function.Function.identity;

@Data
@Slf4j
public class DeclarationResponse {

    private List<String> declarationId;
    private String requestId;
    private String responseId;
    private String xmlBody;
    private List<String> reportBackElements;
    private String controlType;
    private String controlAgent;
    private List<String> controlTypeList;
    private String riskAssessmentResults_Expression;
    private boolean blockingRelease;
    private List<Boolean> blockingReleaseList;
    private String faultCode;
    private String faultString;
    private String narrativeText;
    private List<String> workBasket;
    private List<String> narrativeTextList;
    private List<List<String>> matchReasons;
    private String timestamp;
    private String alvsCheckCode;
    private String alvsDepartmentCode;

    private List<String> conclusion;
//    private List<String> controlAgent;
    private List<String> totalScore;
    private List<Boolean> isTimed;
    private List<String> timeToClose;
    private List<Boolean> isSelfClosing;
    private List<Boolean> isSecret;
    private List<Boolean> involvesNotifyingDeclarant;
    private List<Boolean> isMachine;
    private List<String> sourceId;
    private List<String> controlMeans;
    private List<String> description;
    private List<String> directive;
    private List<String> profileId;
    private List<String> score;
    private List<String> riskAssement;

    public DeclarationResponse(String declarationResponseXML) {
        this(declarationResponseXML, false, identity());
    }

    public DeclarationResponse(String declarationResponseXML, Function<String, String> mapFunction) {
        this(declarationResponseXML, false, mapFunction);
    }

    public DeclarationResponse(String declarationResponseXML, boolean errorExpected) {
        this(declarationResponseXML, errorExpected, identity());
    }

    //TODO remove single fields where list exists
    public DeclarationResponse(String declarationResponseXML, boolean errorExpected, Function<String, String> mapFunction) {

        xmlBody = declarationResponseXML;

        requestId = getTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResponse/request/id");
        responseId = getTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResponse/id");

        reportBackElements = getAllTagValuesFromXMLResponse(declarationResponseXML, "//controlInstructions/reportBackElements");

        narrativeText = mapFunction.apply(getTagValuesFromXMLResponse(declarationResponseXML, "//controlInstructions/extensions[type=\"Narrative\"]/value"));
        narrativeTextList = getAllTagValuesFromXMLResponse(declarationResponseXML, "//controlInstructions/extensions[type=\"Narrative\"]/value");

        alvsCheckCode = getTagValuesFromXMLResponse(declarationResponseXML, "//controlInstructions/extensions[type=\"CheckCode\"]/value");
        alvsDepartmentCode = getTagValuesFromXMLResponse(declarationResponseXML, "//controlInstructions/extensions[type=\"DepartmentCode\"]/value");

        controlType = getTagValuesFromXMLResponse(declarationResponseXML, "//controlType");

        controlTypeList = getAllTagValuesFromXMLResponse(declarationResponseXML, "//controlType");
        controlAgent = getTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults/controlAgent");

        riskAssessmentResults_Expression = getTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults");
        blockingRelease = Boolean.parseBoolean(getTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults/isBlockingRelease"));
        blockingReleaseList = getAllBooleanTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults/isBlockingRelease");
        faultCode = getTagValuesFromXMLResponse(declarationResponseXML, "//faultcode");
        faultString = getTagValuesFromXMLResponse(declarationResponseXML, "//faultstring");


        timestamp = getTagValuesFromXMLResponse(declarationResponseXML, "//timeStamp");
        matchReasons = createMatchReasons(declarationResponseXML, mapFunction);

        extractManualInterventionfields(declarationResponseXML);

        if (! errorExpected) {
            Assertions.assertThat(faultString).isNullOrEmpty();
            Assertions.assertThat(faultCode).isNullOrEmpty();
        }
    }

    private void extractManualInterventionfields(String declarationResponseXML){

        declarationId = getAllTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResponse/extensions[type=\"declarationID\"]/value");
        workBasket = getAllTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults/controlInstructions/extensions[type=\"Workbasket\"]/value");
        conclusion = getAllTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults/conclusion");
        totalScore = getAllTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults/totalScore");
        isTimed = getAllBooleanTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults/controlInstructions/extensions[type=\"IsTimed\"]/value");
        timeToClose = getAllTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults/controlInstructions/extensions[type=\"TimeToClose\"]/value");
        isSelfClosing = getAllBooleanTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults/controlInstructions/extensions[type=\"IsSelfClosing\"]/value");
        isSecret = getAllBooleanTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults/controlInstructions/extensions[type=\"IsSecret\"]/value");
        involvesNotifyingDeclarant = getAllBooleanTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults/controlInstructions/involvesNotifyingDeclarant");
        isMachine = getAllBooleanTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults/controlInstructions/source/isMachine");
        sourceId = getAllTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults/controlInstructions/source/id");
        controlMeans = getAllTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults/controlInstructions/controlMeans");
        description = getAllTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults/controlInstructions/identifiedRisks/description");
        directive = getAllTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults/controlInstructions/identifiedRisks/directive");
        profileId = getAllTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults/controlInstructions/identifiedRisks/profileId");
        score = getAllTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults/controlInstructions/identifiedRisks/score");
        riskAssement = getAllTagValuesFromXMLResponse(declarationResponseXML, "//riskAssessmentResults");

    }

    private List<List<String>> createMatchReasons(String declarationResponseXml) {
        return createMatchReasons(declarationResponseXml, identity());
    }

    private List<List<String>> createMatchReasons(String declarationResponseXml, Function<String, String> mapFunction) {
        List<String> reasons = getAllTagValuesFromXMLResponse(declarationResponseXml, "//controlInstructions/extensions[type=\"Description\"]/value");
        List<List<String>> result = new ArrayList<>();
        reasons.forEach(reason -> {
            reason = mapFunction.apply(reason);
            reason = reason.replace("\nMatch reasons:\n- ", "");
            reason = reason.replace("\n", "");
            result.add( Arrays.asList(reason.split("- ", -1)) );
        });
        return result;
    }

    public static List<Boolean> getAllBooleanTagValuesFromXMLResponse(String xml, String xpath) {

        return getAllTagValuesFromXMLResponse(xml, xpath).stream()
                .map(string -> Boolean.parseBoolean(string))
                .collect(Collectors.toList());
    }

    public static List<String> getAllTagValuesFromXMLResponse(String xml, String xpath) {
        List<String> values = new ArrayList<>();
        DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();

        try {
            String xString = xml.replaceAll("[^\\x20-\\x7e\\x0A]", "");
            DocumentBuilder builder = domFactory.newDocumentBuilder();
            Document dDoc = builder.parse( new InputSource( new StringReader( xString )) );

            XPath xPath = XPathFactory.newInstance().newXPath();
            NodeList nodeList = (NodeList) xPath.evaluate("Envelope".concat(xpath), dDoc, XPathConstants.NODESET);

            if (nodeList == null){
                log.debug("no match found for expression " + xpath);
                return ImmutableList.of();
            }

            for (int i = 0; i < nodeList.getLength(); i++) {
                values.add(nodeList.item(i).getTextContent());
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

        return values;
    }

    public static String getTagValuesFromXMLResponse(String xml, String expression) {
        String nodeValue = null;
        DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();

        try {

            String xString = xml.replaceAll("[^\\x20-\\x7e\\x0A]", "");
            DocumentBuilder builder = domFactory.newDocumentBuilder();
            Document dDoc = builder.parse( new InputSource( new StringReader( xString )) );


            XPath xPath = XPathFactory.newInstance().newXPath();
            Node node = (Node) xPath.evaluate("Envelope".concat(expression), dDoc, XPathConstants.NODE);

            if (node == null){
                log.debug("no match found for expression " + expression);
                return "";
            }

            nodeValue = node.getTextContent();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return nodeValue;
    }
}
