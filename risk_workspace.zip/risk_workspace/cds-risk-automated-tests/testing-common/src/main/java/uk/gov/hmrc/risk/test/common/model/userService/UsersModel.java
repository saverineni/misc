package uk.gov.hmrc.risk.test.common.model.userService;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Builder
@Data
public class UsersModel {

    private boolean first, last;
    private int size, number, totalPages, totalElements, numberOfElements;
    private List<Sort> sort;
    private List<Content> content;

    @Builder
    @Data
    public static class Sort {
        private String direction, property, nullHandling;
        private boolean ignoreCase, ascending, descending;
        private List<Content> content;
    }

    @Builder
    @Data
    public static class Content {
        private String baseLocationUuid, pid, firstName, lastName, location, hmrcDepartment, jobTitle, email;
        private String alternativeEmail, mobileNumber, highestLevelRole, status, lastLogin, userType, reason;
        private int locationCount, opLockVersion;
        private boolean riskUser, inactive, superAdmin, admin, ruleManager, scValidated;
        private BaseLocation baseLocation;
        private MetaData metaData;
        private List<String> permissions;
    }

    @Builder
    @Data
    public static class BaseLocation {
        private String locationName, locationUuid, locationFullName, locationType;
        private List<String> ports;
    }

    @Builder
    @Data
    public static class MetaData {
        private List<String> actions;
    }
}
