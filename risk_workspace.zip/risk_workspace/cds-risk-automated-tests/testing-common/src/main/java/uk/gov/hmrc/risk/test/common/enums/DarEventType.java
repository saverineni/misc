package uk.gov.hmrc.risk.test.common.enums;

/**
 * Created by developer on 29/06/17.
 */
public enum DarEventType {

    DECLARATION_RISKED,
    DECLARATION_RISKING_ERROR,
    DECLARATION_RISK_RESULT,
    PUBLISH,
    RULE_AUDIT,
    RULE_DATA_TABLES,
    RULE_BEHAVIOURS,
    RULE_LOCATIONS,
    DATA_TABLE_AUDIT,
    DATA_TABLE_ITEMS,
    DATA_TABLE_LOCATIONS,
    DATA_TABLE_TAGS,
    UNKNOWN;
}
