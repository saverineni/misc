package uk.gov.hmrc.risk.test.common.model.rulesService;

import lombok.Builder;
import lombok.Data;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel.GlobalDefinition;
import uk.gov.hmrc.risk.test.common.enums.Attribute;
import uk.gov.hmrc.risk.test.common.enums.DeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.Matcher;
import uk.gov.hmrc.risk.test.common.enums.MatcherType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static uk.gov.hmrc.risk.test.common.util.IOUtils.readFromClasspath;

/**
 * Created by James Philipps on 01/09/17.
 */
public final class RuleDefinitionConstants {

    private RuleDefinitionConstants() {
    }

    public static RuleDefinitionModel defaultModel() {
        return fromClasspathTemplate("risking-testing-common/DrlTemplate.drl");
    }

    public static RuleDefinitionModel defaultDataTableModel() {
        return fromClasspathTemplate("risking-testing-common/DrlDataTableTemplate.drl");
    }

    public static RuleDefinitionModel fromClasspathTemplate(String path) {
        return RuleDefinitionModel.parse(readFromClasspath(path));
    }

    public static String dataTableReference(String dataTableUUid) {
        return "datatable_" + dataTableUUid.replace("-", "");
    }

    public static GlobalDefinition globalDataTable(String dataTableUuid) {
        return new GlobalDefinition("Collection<String>", "datatable_" + dataTableUuid.replace("-", ""));
    }

    public static String declarationWrapper(String checks) {
        return String.format("declaration: DeclarationWrapper(%s)", checks);
    }

    public static String goodsItemsWrapper(String checks) {
        return String.format("goodsItem: GoodsItemWrapper(%s) from goodsItems", checks);
    }

    public static String whenCreator(List<Condition> declarationConditions, List<Condition> goodsItemConditions) {
        List<String> declarationChecks = new ArrayList<>();
        List<String> goodsItemChecks = new ArrayList<>();

        declarationConditions.forEach(condition -> declarationChecks.add(chooseCheck(condition)));
        goodsItemConditions.forEach(condition -> goodsItemChecks.add(chooseCheck(condition)));

        StringBuilder sb = new StringBuilder();

        if ( declarationConditions.isEmpty() ) {
            if ( goodsItemConditions.isEmpty() ) {
                throw new IllegalArgumentException("Both lists cannot be empty");
            } else {
                sb.append( declarationWrapper( goodsItemVariable() ) + "\n");
                sb.append( goodsItemsWrapper( String.join(" &&\n", goodsItemChecks)));
            }
        } else {
            if ( goodsItemConditions.isEmpty() ) {
                sb.append( declarationWrapper(String.join(" &&\n", declarationChecks)));
            } else {
                sb.append( declarationWrapper(
                        String.join( " &&\n", declarationChecks) + " &&\n" + goodsItemVariable() + "\n")
                );
                sb.append( goodsItemsWrapper( String.join( " &&\n", goodsItemChecks) ));
            }
        }

        String toResult = sb.toString();

        return toResult;

    }

    private static String chooseCheck(Condition con) {
        if (con.value.contains("datatable_")) {
            return dtCheck(con);
        }
        if (con.value.contains("BigDecimal")) {
            return intCheck(con);
        }
        return strCheck(con);
    }

    public static String dtCheck(Condition condition) {
        return condition.positive ?
                String.format("check( %s(), %s.%s(%s))",
                    condition.attribute, condition.matcherClass, condition.matcher, condition.value):
                String.format("check( %s(), Matchers.not(%s.%s(%s)))",
                        condition.attribute, condition.matcherClass, condition.matcher, condition.value);
    }

    public static String strCheck(Condition condition) {
        return condition.positive ?
                String.format("check( %s(), %s.%s(\"%s\"))",
                        condition.attribute, condition.matcherClass, condition.matcher, condition.value) :
                String.format("check( %s(), Matchers.not(%s.%s(\"%s\")))",
                        condition.attribute, condition.matcherClass, condition.matcher, condition.value);
    }

    public static String intCheck(Condition condition) {
        return condition.positive ?
                String.format("check( %s(), %s.%s(%s))",
                        condition.attribute, condition.matcherClass, condition.matcher, condition.value) :
                String.format("check( %s(), Matchers.not(%s.%s(%s)))",
                        condition.attribute, condition.matcherClass, condition.matcher, condition.value);
    }

    public static String value(String dataTableUuid) {
        return String.format("value: String() from %s", dataTableUuid.replace("-", ""));
    }

    public static String goodsItemVariable() {
        return "goodsItems: goodsItems()";
    }

    public static String thenCreator(Source source, List<Condition> conditions) {
        List<String> clauses = new ArrayList<>();
        String clausesString = ".ruleClauses(\n";

        conditions.forEach(condition -> clauses.add( chooseClause(condition)) );

        clausesString = clausesString.concat( String.join(",\n", clauses) );
        clausesString = clausesString.concat(")\n");

        return riskingResultString( source, clausesString );
    }

    private static String chooseClause(Condition con) {
        if (con.value.contains("datatable_")) {
            return dtClause(con);
        }
        if (con.value.contains("BigDecimal")) {
            return intClause(con);
        }
        return strClause(con);
    }

    private static String dtClause(Condition con) {
        return con.isPositive() ?
                String.format("clause(%s.%s(), %s.%s(%s), MatcherInfo.dataTableOf(MatcherType.%s, \"%s\"))",
                con.source, con.attribute, con.matcherClass,
                con.matcher, con.value, con.matcherType, con.value) :

                String.format("clause(%s.%s(), Matchers.not(%s.%s(%s)), MatcherInfo.dataTableOf(MatcherType.%s, \"%s\", true))",
                        con.source, con.attribute, con.matcherClass,
                        con.matcher, con.value, con.matcherType, con.value);
    }

    private static String intClause(Condition condition) {
        return condition.isPositive() ?
                String.format("clause(%s.%s(), %s.%s(%s), MatcherInfo.of(MatcherType.%s, %s))",
                        condition.source, condition.attribute, condition.matcherClass,
                        condition.matcher, condition.value, condition.matcherType, condition.value) :

                String.format("clause(%s.%s(), Matchers.not(%s.%s(%s)), MatcherInfo.of(MatcherType.%s, %s, true))",
                        condition.source, condition.attribute, condition.matcherClass,
                        condition.matcher, condition.value, condition.matcherType, condition.value);
    }

    private static String strClause(Condition condition) {
        return condition.isPositive() ?
                String.format("clause(%s.%s(), %s.%s(\"%s\"), MatcherInfo.of(MatcherType.%s, \"%s\"))",
                condition.source, condition.attribute, condition.matcherClass,
                condition.matcher, condition.value, condition.matcherType, condition.value) :

                String.format("clause(%s.%s(), Matchers.not(%s.%s(\"%s\")), MatcherInfo.of(MatcherType.%s, \"%s\", true))",
                        condition.source, condition.attribute, condition.matcherClass,
                        condition.matcher, condition.value, condition.matcherType, condition.value);
    }

    private static String riskingResultString(Source source, String clausesString) {
        return String.format(
                "riskingResult.ruleFired(\n" +
                        "RuleFiredEvent.builder()\n" +
                        ".droolsRule(drools.getRule())\n" +
                        ".source(%s)\n" +
                        "%s" +
                        ".build()\n"+
                        ");", source, clausesString);
    }

    public static List<Condition> conditions (Condition... conditions) {
        return new ArrayList<>( Arrays.asList(conditions) );
    }

    @Builder
    @Data
    public static class Condition {
        public Source source;
        public Attribute attribute;
        public DeclarationParam declarationParam;
        public String declarationValue;
        public MatcherClass matcherClass;
        public Matcher matcher;
        public MatcherType matcherType;
        public String value;
        @Builder.Default
        public boolean positive = true;

        public void setValue(int value) {
            this.value = String.format("new BigDecimal(\"%s\")", value);
        }

        public void setValue(String value) {
            this.value = value;
        }

        public static class ConditionBuilder {
            public ConditionBuilder value(int value) {
                this.value = String.format("new BigDecimal(\"%s\")", value);
                return this;
            }

            public ConditionBuilder value(String value) {
                this.value = value;
                return this;
            }
        }
    }

    public enum MatcherClass {
        Matchers, CdsRiskMatchers
    }

    public enum Source {
        goodsItem, declaration
    }
}
