package uk.gov.hmrc.risk.test.common.service.docker;

import lombok.RequiredArgsConstructor;

import java.util.Arrays;

/**
 * Created by James Philipps on 07/08/17.
 */
@RequiredArgsConstructor
public enum ContainerState {
    RUNNING("running"),
    EXITED("exited"),
    UNKNOWN("UNKNOWN");

    private final String value;

    public static ContainerState fromString(String s) {
        return Arrays.asList(values()).stream()
                .filter(v -> v.value.equalsIgnoreCase(s.trim()))
                .findFirst().orElse(UNKNOWN);
    }
}
