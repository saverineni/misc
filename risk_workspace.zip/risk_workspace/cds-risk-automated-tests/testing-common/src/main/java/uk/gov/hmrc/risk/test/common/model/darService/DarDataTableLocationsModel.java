package uk.gov.hmrc.risk.test.common.model.darService;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class DarDataTableLocationsModel {

    private String type, packageUuid, tableUuid, locationUuid, locationName, shareType;

    public static DarDataTableLocationsModel create(String[] line) {
        return new DarDataTableLocationsModel(
                line[0],          // type
                line[1],          // packageUuid
                line[2],          // tableUuid
                line[3],          // locationUuid
                line[4],          // locationName
                line[5]);         // shareType
    }

    private DarDataTableLocationsModel(String type, String packageUuid, String tableUuid, String locationUuid,
                                       String locationName, String shareType) {
        this.type = type;
        this.packageUuid = packageUuid;
        this.tableUuid = tableUuid;
        this.locationUuid = locationUuid;
        this.locationName = locationName;
        this.shareType = shareType;
    }
}
