//package uk.gov.hmrc.risk.test.common.model.darService;
//
///**
// * Created by developer on 29/06/17.
// */
//
//import com.fasterxml.jackson.annotation.JsonCreator;
//import com.fasterxml.jackson.annotation.JsonProperty;
//import lombok.Builder;
//import lombok.Data;
//
//import java.util.List;
//
//@Data
//@Builder
//public class DarEventBodyContainer {
//    private String riskResponseId;
//    private String declarationId;
//    private String rulesPackage;
//    private String declarationType;
//    private String declarationSubType;
//    private List<Result>   results;
//
//    @JsonCreator
//    public DarEventBodyContainer(
//            @JsonProperty("riskResponseId") String riskResponseId,
//            @JsonProperty("declarationId") String declarationId,
//            @JsonProperty("rulesPackage") String rulesPackage,
//            @JsonProperty("declarationType") String declarationType,
//            @JsonProperty("declarationSubType") String declarationSubType,
//            @JsonProperty("results") List<Result> results
//    ) {
//        this.riskResponseId = riskResponseId;
//        this.declarationId = declarationId;
//        this.rulesPackage = rulesPackage;
//        this.declarationType = declarationType;
//        this.declarationSubType = declarationSubType;
//        this.results = results;
//    }
//
//    @Data
//    @Builder
//    public static class Result {
//
//         private String controlType;
//    }
//}
