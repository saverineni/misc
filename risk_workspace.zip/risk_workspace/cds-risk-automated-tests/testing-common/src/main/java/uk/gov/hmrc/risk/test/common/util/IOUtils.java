package uk.gov.hmrc.risk.test.common.util;

import lombok.SneakyThrows;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Created by James Philipps on 12/04/17.
 */
public class IOUtils {


    @SneakyThrows
    public static String readFromClasspath(String classpath) {
        return readInputStream(IOUtils.class.getClassLoader().getResourceAsStream(classpath));
    }

    @SneakyThrows
    public static String readFromFile(Path file) {
        return new String(Files.readAllBytes(file));
    }

    @SneakyThrows
    public static String readInputStream(InputStream in) {
        return in != null ?
                new String(readInputStreamAsBytes(in), "UTF-8") :
                "";
    }

    @SneakyThrows
    public static byte[] readInputStreamAsBytes(InputStream in) {
        final int byteBufferSize = 16384;

        ByteArrayOutputStream buffer = new ByteArrayOutputStream();

        int nRead;
        byte[] data = new byte[byteBufferSize];

        while ((nRead = in.read(data)) > 0) {
            buffer.write(data, 0, nRead);
        }

        buffer.flush();
        return buffer.toByteArray();
    }

}
