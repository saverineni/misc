package uk.gov.hmrc.risk.test.common.model.declarationSupport;

import lombok.Builder;
import lombok.Data;

@Data
@Builder(toBuilder = true)
public class DeclarationModel  extends TokenableModel {

    private String id, reference;
    private String modeOfEntry, goodsItemCount, declarationType, declarationSubType;
    private String additionalInformation;
    private String additionalDocuments;
    private String totalGrossMass, packageCount;
    private String invoiceAmount, invoiceCurrency;
    private String parties, consigmentParties;
    private String customsOffices;
    private String specificCircumstance, submitterReference;
    private String containers;
    private String postalCharges, postalChargesCurrency;
    private String countryRegions, locations;
    private String transportMode, transportType, transportRole, transportNationality, transportId;
    private String ucrId, ucrTraderAssignedRef;
    private String freightPaymetMethod;
    private String goodsItems;
    private String goodsLocationName, goodsLocationID;

    @Builder
    @Data
    public static class AdditionalDocuments extends TokenableModel {
        private String identifier, type;
    }

    @Builder
    @Data
    public static class AdditionalInformation extends TokenableModel {
        private String code, text;
    }

    @Builder
    @Data
    public static class Parties extends TokenableModel {
        private String type, status, partyName;

        private String addressCityName, addressStreetAndNumber, addressZipCode;
        private String addressCountry;

        private String idType, eori;
    }

    @Builder
    @Data
    public static class CustomsOffices extends TokenableModel {

        private String type, officeIdType, officeIdNumber;
    }

    @Builder
    @Data
    public static class Containers extends TokenableModel {

        private String containerCode, sealId;
    }

    @Builder
    @Data
    public static class CountryRegions extends TokenableModel {

        private String type, country;
    }
    @Builder
    @Data
    public static class Locations extends TokenableModel {

        private String type, premisesID, locationName;
        private String premisesCity, premisesAddress, premisesPostcode;
        private String premisesCountry;
    }

}
