package uk.gov.hmrc.risk.test.common.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum ItemCollectionAttribute implements Attribute {

    ADDITIONAL_INFORMATION_CODE_ITEM("additionalInformation_CodeItem"),
    ADDITIONAL_INFORMATION_TEXT_ITEM("additionalInformation_TextItem"),
    ADDITIONAL_DOCUMENTS_TYPE_ITEM("additionalDocuments_TypeItem"),

    PACKAGE_COUNT_ITEM("packaging_CountItem"),
    PACKAGE_MARKS_ITEM("packaging_MarksItem"),
    PACKAGE_TYPE_ITEM("packaging_TypeItem");

    public final String method;

    @Override
    public String toString() {
        return method;
    }
}
