package uk.gov.hmrc.risk.test.common.model.userService;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Builder
@Data
public class CreateUserModel {

    private String pid, password, userType, jobTitle, baseLocationUuid, mobileNumber, alternativeEmail, scClearanceLevel, scClearanceExpiryDate;
    private boolean scValidatedscValidated;
    private List<AdditionalLocationRoles> additionalLocationRoles;

    @Builder
    @Data
    public static class AdditionalLocationRoles {
        private String locationName, locationFullName, locationUuid, roleName;
        private List<Roles> roles;
        private MetaData metaData;
    }

    @Builder
    @Data
    public static class Roles {
        private String roleName;
    }

    @Builder
    @Data
    public static class MetaData {
        private List<String> actions;
    }
}
