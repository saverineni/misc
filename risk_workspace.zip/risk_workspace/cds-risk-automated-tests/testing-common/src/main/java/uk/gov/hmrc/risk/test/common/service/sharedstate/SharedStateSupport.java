package uk.gov.hmrc.risk.test.common.service.sharedstate;

import java.util.Set;

/**
 * Created by James Philipps on 26/04/17.
 */
public interface SharedStateSupport {

    void clearAllKeys();

    Set<String> getKeys();

}
