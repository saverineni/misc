package uk.gov.hmrc.risk.test.common.model.darService;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class DarDataTableItemsModel {

    private String type, packageUuid, tableUuid, value;

    public static DarDataTableItemsModel create(String[] line) {
        return new DarDataTableItemsModel(
                line[0],          // type
                line[1],          // packageUuid
                line[2],          // tableUuid
                line[3]);         // value
    }

    private DarDataTableItemsModel(String type, String packageUuid, String tableUuid, String value) {
        this.type = type;
        this.packageUuid = packageUuid;
        this.tableUuid = tableUuid;
        this.value = value;
    }
}
