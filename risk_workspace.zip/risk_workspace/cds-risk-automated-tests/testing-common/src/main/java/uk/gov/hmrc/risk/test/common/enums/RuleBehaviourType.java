package uk.gov.hmrc.risk.test.common.enums;

import com.fasterxml.jackson.annotation.JsonCreator;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Created by James Philipps on 23/05/17.
 */
public enum RuleBehaviourType {
    DEFAULT, PRE_CLEARANCE,POST_CLEARANCE;

    private static final Map<String, RuleBehaviourType> MAP = Arrays.asList(values()).stream()
            .collect(Collectors.toMap(v -> v.name(), v -> v));

    @JsonCreator
    public static RuleBehaviourType fromString(String val) {
        return Optional.ofNullable(val)
                .flatMap(v -> Optional.ofNullable(MAP.get(v.trim().toUpperCase())))
                .orElseThrow(() ->
                        new IllegalArgumentException("Unable to parse RuleBehaviourType from: '" + val.trim() + "'")
                );
    }
}
