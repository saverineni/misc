package uk.gov.hmrc.risk.test.common.model.rulesManagementService;

import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * Created by developer on 25/07/18.
 */
@Builder
@Data
public class CreateDataTableModel {

    private List<String> tags, locationUuids;
    private MetaData metaData;
    private String tableType, tableName, description, dataTypeUuid, reason;

    @Builder
    @Data
    public static class MetaData {
        private List<String> actions;
    }
}
