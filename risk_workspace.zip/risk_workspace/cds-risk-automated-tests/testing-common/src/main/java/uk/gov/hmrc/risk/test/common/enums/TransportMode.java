package uk.gov.hmrc.risk.test.common.enums;

/**
 * Created by developer on 17/10/17.
 */
public enum TransportMode {
    Air, Maritime, All
}
