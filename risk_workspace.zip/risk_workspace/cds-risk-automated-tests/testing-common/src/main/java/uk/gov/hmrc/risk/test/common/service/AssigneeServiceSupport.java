package uk.gov.hmrc.risk.test.common.service;

import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.fluent.Request;

import java.util.Map;

import static uk.gov.hmrc.risk.test.common.service.RestSupport.statusCode2xx;


@Slf4j
@RequiredArgsConstructor
public class AssigneeServiceSupport {

    private final RestSupport restSupport;

    private final AssigneeServiceConfig config;

    public Map<String, String> refreshAssigneeCache() {
        log.info("Sending assignee message..");

        Request request = Request.Post(config.getAssigneeUrl());

        Map<String, String> response;
        response = restSupport.getResponseAsJson(request, Map.class, statusCode2xx());
        log.info("Response: " + response);
        return response;
    }

    @Builder
    @Getter
    public static class AssigneeServiceConfig {
        private String assigneeUrl;
    }

}
