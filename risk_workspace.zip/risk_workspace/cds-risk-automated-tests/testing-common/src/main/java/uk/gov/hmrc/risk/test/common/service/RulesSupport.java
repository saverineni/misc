package uk.gov.hmrc.risk.test.common.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import uk.gov.hmrc.risk.devlocal.model.RuleDefinitionModel;
import uk.gov.hmrc.risk.test.common.dao.RuleDao;
import uk.gov.hmrc.risk.test.common.enums.RuleStatus;
import uk.gov.hmrc.risk.test.common.model.rulesService.RuleCreationModel;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static uk.gov.hmrc.risk.test.common.service.RestSupport.DEFAULT_AUTH_HEADER;
import static uk.gov.hmrc.risk.test.common.service.RestSupport.statusCode2xx;

/**
 * Created by James Philipps on 12/04/17.
 */
@Slf4j
@RequiredArgsConstructor
public class RulesSupport {

    private final RestSupport restSupport;
    private final RuleDao ruleDao;
    private final ObjectMapper jsonMapper;
    private final RulesSupportConfig config;

    @SneakyThrows
    public String createRule(RuleCreationModel model, String authorizationToken) {
        String requestJson = jsonMapper.writeValueAsString(model);
        log.debug("Rule Creation json:\n {}", requestJson);
        log.debug("Sending create request..");

        Request request = Request.Post(config.getCreateRuleUrl())
                .addHeader("Authorization", authorizationToken)
                .bodyByteArray(requestJson.getBytes(), ContentType.APPLICATION_JSON);

        Map<String, String> json = restSupport.getResponseAsJson(request, Map.class, statusCode2xx());

        String uniqueId = json.get("uniqueId");

        return uniqueId;
    }

    @SneakyThrows
    public void updateRule(String ruleUuid, String requestJson, String authorizationToken) {
        String url = config.updateRule2 + "/" + ruleUuid;

        log.debug("Rule update json:\n {}", requestJson);
        log.debug("Sending update request..");

        Request request = Request.Put(url).addHeader("Authorization", authorizationToken)
                .bodyByteArray(requestJson.getBytes(), ContentType.APPLICATION_JSON);

        restSupport.getResponseAsJson(request, Map.class, statusCode2xx());

        updateState(ruleUuid, "2", RuleStatus.COMMIT, authorizationToken);
    }

    @SneakyThrows
    public String createActiveRule(RuleCreationModel model, String authorizationToken) {
        String uniqueIdAtCreation = createRule(model, authorizationToken);

        if (model.getUniqueId() == null) {
            model.setUniqueId(uniqueIdAtCreation);
        }

        updateState(uniqueIdAtCreation, "1", RuleStatus.COMMIT, authorizationToken);

        // Setting the returned uniqueid on the rule metadata. We don't know this until the rule has been created ...
        ruleDao.setBody(
                uniqueIdAtCreation,
                ruleDao.getBody(uniqueIdAtCreation)
                        .replaceAll("#UniqueId#", uniqueIdAtCreation.concat("-1"))
        );
        return model.getUniqueId();
    }

    @SneakyThrows
    public void updateState(String ruleId, String ruleVersion, RuleStatus state, String authorizationToken) {
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("action", state.toString());
        jsonMap.put("reason", "Default test reason");
        String body = jsonMapper.writeValueAsString(jsonMap);

        String url = config.createRuleUrl2 + "/" + ruleId + "/" + ruleVersion;

        Request request = Request.Put(url).addHeader("Authorization", authorizationToken)
                .bodyString(body, ContentType.APPLICATION_JSON);

        restSupport.getResponseAsJson(request, Map.class, statusCode2xx());
    }

    @SneakyThrows
    private String readFromClasspath(String classpath) {
        InputStream in = getClass().getClassLoader().getResourceAsStream(classpath);
        try (BufferedReader buffer = new BufferedReader(new InputStreamReader(in))) {
            return buffer.lines().collect(Collectors.joining("\n"));
        }
    }

    public void deleteAllRules() {
        ruleDao.deleteAll();
    }

    public void deleteRuleById(String uniqueId) {
        ruleDao.deleteById(uniqueId);
    }

    public void deleteRuleByName(String namePattern) {
        ruleDao.deleteByName(namePattern);
    }

//    public void setRuleStatus(String uniqueId, RuleStatus ruleStatus) {
//        ruleDao.setStatus(uniqueId, ruleStatus);
//    }

    public RuleDefinitionModel getRule(String uniqueId) {
        return RuleDefinitionModel.parse(ruleDao.getBody(uniqueId));
    }

    public void saveRule(String uniqueId, RuleDefinitionModel model) {
        ruleDao.setBody(uniqueId, model.toString());
    }

    public Map<String, String> getRegimeCodes() {
        log.debug("Sending regime codes request..");
        return ((List<Map<String, String>>) restSupport
                .getResponseAsJson(Request.Get(config.getRegimeCodesUrl()).addHeader(DEFAULT_AUTH_HEADER),
                        List.class, statusCode2xx()))
                .stream()
                .collect(Collectors.toMap(r -> r.get("regimeCodeName"), r -> r.get("regimeCodeUuid")));
    }

    public List<Map<String, String>> getListOfRegimeUIDs() {

        log.info("\n Getting List of Regime Code UIDs: ");
        log.info("GET Request: " + config.getRegimeCodesUrl());

        return ((List<Map<String, String>>) restSupport
                .getResponseAsJson(Request.Get(config.getRegimeCodesUrl()).addHeader(DEFAULT_AUTH_HEADER),
                        List.class, statusCode2xx()));
    }

    public Map<String, String> getSensitivityLevels() {
        log.debug("Sending sensitivity levels request..");
        return ((List<Map<String, String>>) restSupport
                .getResponseAsJson(Request.Get(config.getSensitivityLevelsUrl()).addHeader(DEFAULT_AUTH_HEADER),
                        List.class, statusCode2xx()))
                .stream()
                .collect(Collectors.toMap(r -> r.get("sensitivityLevelName"), r -> r.get("sensitivityLevelUuid")));
    }



    @Builder
    @Getter
    public static class RulesSupportConfig {
        private String createRuleUrl;
        private String createRuleUrl2;
        private String updateRule2;
        private String regimeCodesUrl;
        private String sensitivityLevelsUrl;
    }
}
