package uk.gov.hmrc.risk.test.common.service.docker;

import lombok.Getter;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Created by James Philipps on 07/08/17.
 */
@Getter
public class ContainerListing {

    private final List<ContainerAccessor> containers;

    public ContainerListing(List<ContainerAccessor> containers) {
        this.containers = containers != null ? containers : Collections.emptyList();
    }

    public ContainerListing filter(ContainerFilter... filters) {
        Stream<ContainerAccessor> stream = containers.stream();
        for (ContainerFilter filter : filters) {
            stream = stream.filter(filter);
        }
        return new ContainerListing(stream.collect(Collectors.toList()));
    }

    public Optional<ContainerAccessor> first() {
        return containers.size() > 0 ? Optional.ofNullable(containers.get(0)) : Optional.empty();
    }
}
