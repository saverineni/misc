package uk.gov.hmrc.risk.test.common.service;

import lombok.RequiredArgsConstructor;
import lombok.Synchronized;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.util.Properties;


@Slf4j
@RequiredArgsConstructor
public class RabbitQueueSupport {

    private final int DEFAULT_TIMEOUT = 10;

    private final RabbitTemplate rabbitTemplate;
    private final AmqpAdmin rabbitAdmin;
    private final TopicExchange exchange;
    private final String routingKey;
    private final Queue queue;

    public void send(String message) {
        rabbitTemplate.convertAndSend(exchange.getName(), routingKey, message);
    }

    public String receive() {
        return receive(DEFAULT_TIMEOUT);
    }

    @Synchronized
    public String receive(int timeoutInSeconds) {
        return (String)rabbitTemplate.receiveAndConvert(queue.getName(), timeoutInSeconds * 1000);
    }

    public void purge() {
        rabbitAdmin.purgeQueue(queue.getName(), false);
    }

    public int getNumberOfMessages() {
        Properties props = rabbitAdmin.getQueueProperties(queue.getName());
        return Integer.parseInt(props.get("QUEUE_MESSAGE_COUNT").toString());
    }
}
