package uk.gov.hmrc.risk.test.common.service.docker;

import com.spotify.docker.client.DockerClient;
import com.spotify.docker.client.DockerClient.ListContainersParam;
import com.spotify.docker.client.messages.Container;
import com.spotify.docker.client.messages.ExecCreation;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import uk.gov.hmrc.risk.test.common.service.docker.GenericDockerSupport.DockerSupportConfig;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by James Philipps on 07/08/17.
 */
@Slf4j
@AllArgsConstructor
public class ContainerAccessor {

    private DockerSupportConfig config;
    private DockerClient dockerClient;
    private Container container;

    public String getId() {
        return container.id();
    }

    public String getName() {
        return getName(true);
    }

    private String getName(boolean refreshFirst) {
        if (refreshFirst) {
            refresh();
        }
        return container.names().get(0);
    }

    public List<String> getNames() {
        return getNames(true);
    }

    private List<String> getNames(boolean refreshFirst) {
        if (refreshFirst) {
            refresh();
        }
        return container.names();
    }

    public ContainerState getState() {
        return getState(true);
    }

    private ContainerState getState(boolean refreshFirst) {
        if (refreshFirst) {
            refresh();
        }
        return ContainerState.fromString(container.state());
    }

    public Set<Integer> getPublicPorts() {
        return container.ports().stream()
                .filter(p -> p.publicPort() > 0)
                .map(p -> p.publicPort())
                .collect(Collectors.toSet());
    }

    @SneakyThrows
    public void start() {
        log.debug("Starting container: {}", getId());
        if (getState() == ContainerState.RUNNING) {
            log.debug("Container already running. No action taken");
        } else {
            try {
                dockerClient.startContainer(getId());
            } catch (Exception e) {
                throw new ContainerStartException(getId(), getName(), "Could not start container", e);
            }
        }
    }

    @SneakyThrows
    public void stop() {
        log.debug("Stopping container: {}", getId());
        if (getState() != ContainerState.RUNNING) {
            log.debug("Container not running. No action taken");
        } else {
            try {
                dockerClient.stopContainer(getId(), config.getContainerStopForceTimeSeconds());
            } catch (Exception e) {
                throw new ContainerStopException(getId(), getName(), "Could not stop container", e);
            }
        }
    }

    @SneakyThrows
    public void remove(boolean forceStop) {
        if (getState() == ContainerState.RUNNING) {
            if (forceStop) {
                stop();
            } else {
                throw new ContainerRemovalException(getId(), getName(),
                        "Container is still running and force stop was false. Cannot remove container", null);
            }
        }

        try {
            dockerClient.removeContainer(getId());
        } catch (Exception e) {
            throw new ContainerRemovalException(getId(), getName(), "Could not remove container", e);
        }
    }

    public boolean checkConnectivity(int timeoutSeconds) {
        final int MAX_BACKOFF_MS = 1000;
        final long startTime = System.currentTimeMillis();
        final HostConnectivityChecker hostConnectivityChecker = config.getHostConnectivityChecker();

        // First, wait until container is in running state
        int backoffMs = 100;
        while (getState() != ContainerState.RUNNING && !timeoutExpired(startTime, timeoutSeconds)) {
            log.debug("Waiting for container to enter RUNNING state..");
            sleep(backoffMs);
            backoffMs = recalculateBackoffTime(backoffMs, MAX_BACKOFF_MS);
        }

        if (getState() == ContainerState.RUNNING) {
            log.debug("Container entered RUNNING state");

            // If there are ports, attempt to connect to one to verify the container is listening
            if (container.ports().size() > 0) {

                String host = dockerClient.getHost();
                Integer port = container.ports().get(0).publicPort();

                backoffMs = 100;
                while (!timeoutExpired(startTime, timeoutSeconds)) {
                    log.debug("Connectivity test for {}:{}..", host, port);
                    if (hostConnectivityChecker.canConnect(host, port)) {
                        return true;
                    } else {
                        log.debug("Failed. Backing off for {}ms..", backoffMs);
                        sleep(backoffMs);
                        backoffMs = recalculateBackoffTime(backoffMs, MAX_BACKOFF_MS);
                    }
                }

            } else {
                log.debug("Connectivity test on a container with no ports. Assuming container is now up");
                return true;
            }
        } else {
            log.warn("Container did not enter RUNNING state within the specified time!");
        }

        return false;
    }

    private int recalculateBackoffTime(int currentBackoff, int maxBackoff) {
        int newBackoff = currentBackoff * 2;
        return newBackoff <= maxBackoff ? newBackoff : maxBackoff;
    }

    @SneakyThrows
    private void refresh() {
        container = dockerClient.listContainers(ListContainersParam.allContainers()).stream()
                .filter(c -> c.id().equalsIgnoreCase(getId()))
                .findFirst()
                .orElseThrow(() -> new ContainerRefreshException(getId(), getName(false),
                        String.format("Container: %s seems to have vanished!", getId()), null
                ));
    }

    private boolean timeoutExpired(long startTime, int timeoutSeconds) {
        return System.currentTimeMillis() > startTime + (timeoutSeconds * 1000);
    }

    @SneakyThrows
    private void sleep(long lengthMs) {
        Thread.sleep(lengthMs);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ContainerAccessor that = (ContainerAccessor) o;

        return container != null ? container.id().equals(that.container.id()) : that.container == null;

    }

    @Override
    public int hashCode() {
        return container != null ? container.id().hashCode() : 0;
    }

    @Override
    public String toString() {
        refresh();
        return String.format("ContainerAccessor{ id='%s', name='%s', state='%s' publicPorts='%s' }", getId(),
                getName(false), getState(false), getPublicPorts());
    }

    @SneakyThrows
    public List<String> getFileContents(String internalFilePath){

        ExecCreation creation = dockerClient.execCreate(getId(),
                new String[]{"bash", "-c","cat " + internalFilePath},
                new DockerClient.ExecCreateParam[] {
                        DockerClient.ExecCreateParam.attachStdout()
                }
        );

        final String execOutput = dockerClient
                .execStart(creation.id())
                .readFully();

        System.out.println("output: "  + execOutput);

        return Arrays.asList(
                execOutput.split(System.lineSeparator())
        );

    }

    @Getter
    public static class ContainerAccessorException extends RuntimeException {
        private final String containerId;
        private final String containerName;

        public ContainerAccessorException(String containerId, String containerName, String message, Throwable cause) {
            super(message, cause);
            this.containerId = containerId;
            this.containerName = containerName;
        }
    }

    public static class ContainerRefreshException extends ContainerAccessorException {
        public ContainerRefreshException(String containerId, String containerName, String message, Throwable cause) {
            super(containerId, containerName, message, cause);
        }
    }

    public static class ContainerRemovalException extends ContainerAccessorException {
        public ContainerRemovalException(String containerId, String containerName, String message, Throwable cause) {
            super(containerId, containerName, message, cause);
        }
    }

    public static class ContainerStartException extends ContainerAccessorException {
        public ContainerStartException(String containerId, String containerName, String message, Throwable cause) {
            super(containerId, containerName, message, cause);
        }
    }

    public static class ContainerStopException extends ContainerAccessorException {
        public ContainerStopException(String containerId, String containerName, String message, Throwable cause) {
            super(containerId, containerName, message, cause);
        }
    }
}
