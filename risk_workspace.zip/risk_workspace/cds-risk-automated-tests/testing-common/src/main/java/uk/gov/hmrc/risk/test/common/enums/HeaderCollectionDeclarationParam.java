package uk.gov.hmrc.risk.test.common.enums;

import lombok.AllArgsConstructor;

/**
 * Created by developer on 31/08/17.
 */
@AllArgsConstructor
public enum HeaderCollectionDeclarationParam implements DeclarationParam {

    ID("id"),
    ADDITIONAL_INFORMATION_CODEHEADER("additionalInformation_CodeHeader"),
    ADDITIONAL_INFORMATION_TEXTHEADER("additionalInformation_TextHeader"),
    ADDITIONAL_DOCUMENTS_TYPETHEADER("additionalDocuments_TypeHeader"),
    ADDITIONAL_DOCUMENTS_IDHEADER("additionalDocuments_IdHeader"),

    CONTAINER_ID_HEADER("containers_IdHeader"),
    SEAL_ID_HEADER("seal_id_header"),
    COUNTRY_ROUTE_HEADER("country_route_header"),

    STORAGE_LOCATIONS_ID_HEADER("storageLocations_IdHeader"),
    STORAGE_LOCATIONS_NAME_HEADER("storageLocations_NameHeader"),
    STORAGE_ADDRESSES_ADDRESS_HEADER("storageAddresses_AddressHeader"),
    STORAGE_ADDRESSES_CITY_HEADER("storageAddresses_CityHeader"),
    STORAGE_ADDRESSES_COUNTRY_HEADER("storageAddresses_CountryHeader"),
    STORAGE_ADDRESSES_POSTCODE_HEADER("storageAddresses_PostcodeHeader"),
    AUTHORIZATION_TYPE("liableParties_AuthorisationTypeHeader"),
    VALUATION_ADJUST_CODE_HEADER("valuationAdjustCode_Header"),
    VALUATION_ADJUST_AMOUNT_HEADER("valuationAdjustAmount_Header"),
    VALUATION_ADJUST_CURRENCY_HEADER("valuationAdjustCurrency_Header");






    private String paramText;

    @Override
    public String toString() {
        return paramText;
    }

    @AllArgsConstructor
    public enum Second implements DeclarationParam {

        ADDITIONAL_INFORMATION_CODEHEADER("additionalInformation_CodeHeader2"),
        ADDITIONAL_INFORMATION_TEXTHEADER("additionalInformation_TextHeader2"),
        VALUATION_ADJUST_CODE_HEADER("valuationAdjustCode2_Header"),
        VALUATION_ADJUST_AMOUNT_HEADER("valuationAdjustAmount2_Header"),
        VALUATION_ADJUST_CURRENCY_HEADER("valuationAdjustCurrency2_Header");




        private String paramText;

        @Override
        public String toString() {
            return paramText;
        }
    }

}
