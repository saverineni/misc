package uk.gov.hmrc.risk.test.common.service.declarationSupport;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.w3c.dom.Document;
import uk.gov.hmrc.risk.test.common.enums.DMSHeaderDeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.DeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.DmsDeclarationParam;
import uk.gov.hmrc.risk.test.common.enums.HeaderDeclarationParam;
import uk.gov.hmrc.risk.test.common.model.declarationSupport.TokenableModel;
import uk.gov.hmrc.risk.test.common.util.DeTokenizer;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPathFactory;
import java.util.*;

import static uk.gov.hmrc.risk.test.common.util.IOUtils.readFromClasspath;

/**
 * Created by James Philipps on 13/04/17.
 */
@RequiredArgsConstructor
public class DeclarationSupport {

    private final DeTokenizer deTokenizer;

    private DocumentBuilderFactory documentBuilderFactory;
    private XPathFactory xPathFactory;

    public DeclarationSupport() {
        deTokenizer = new DeTokenizer();
        deTokenizer.setTokenPrefix("#");
        deTokenizer.setTokenSuffix("#");
        deTokenizer.setRemovingNonReplacedTokens(true);
    }

    public String getDeclaredDutyTaxFees() {
        return readFromClasspath("risking-testing-common/item-collection-templates/DeclaredDutyTaxFeesTemplate.xml");
    }
    public String getAdditionalDocuments() {
        return readFromClasspath("risking-testing-common/item-collection-templates/AdditionalDocumentsTemplate.xml");
    }

    public String getDefaultDeclarationTemplate() {
        return readFromClasspath("risking-testing-common/SoapDeclarationTemplateNewUCCVersion.xml");
    }

    public String getInternalDeclarationTemplate() {
        return readFromClasspath("risking-testing-common/InternalDeclarationTemplate.xml");
    }

    public String getDefaultMultiItemDeclarationTemplate() {
        return readFromClasspath("risking-testing-common/SoapDeclarationTemplateNewUCCVersionMultiItems.xml");
    }

    public String getDefaultNewDeclarationTemplate() {
        return readFromClasspath("risking-testing-common/SoapDeclarationTemplateTest.xml");
    }

    public String getDefaultDynamicCollectionDeclarationTemplate() {
        return readFromClasspath("risking-testing-common/SoapDeclarationTemplateNewUCCVersionDynamicCollections.xml");
    }

    public String getDmsTemplateForIMA() {
        return readFromClasspath("risking-testing-common/SoapDeclarationTemplateIMA.xml");
    }

    public String getDmsTemplateForIMZ() {
        return readFromClasspath("risking-testing-common/SoapDeclarationTemplateIMZ.xml");
    }

    public String getDmsTemplateForEXA() {
        return readFromClasspath("risking-testing-common/SoapDeclarationTemplateEXA.xml");
    }

    public String getDmsTemplateForEXZ() {
        return readFromClasspath("risking-testing-common/SoapDeclarationTemplateEXZ.xml");
    }

    public String getTemplateWithMultipleAdditionalInfo() {
        return readFromClasspath("risking-testing-common/SoapDeclarationTemplateWithMultipleAdditionalInfo.xml");
    }

    public String getTemplateWithNoAdditionalInfo() {
        return readFromClasspath("risking-testing-common/SoapDeclarationTemplateWithNoAdditionalInfo.xml");
    }

    public String createDeclaration(String template, List<TokenableModel> models) {
        StringBuilder sb = new StringBuilder();
        models.forEach( model -> {
            sb.append(createDeclaration(template, model));
        });
        return sb.toString();
    }

    public String createDeclaration(String template, TokenableModel model) {
        return deTokenizer.replaceTokensStrings(template, model.mapValues()).concat("\n\n");
    }

    public String createDeclaration(String template, Map<DeclarationParam, String> tokens) {
        if (! tokens.containsKey(HeaderDeclarationParam.ID)) {
            tokens.put(HeaderDeclarationParam.ID, UUID.randomUUID().toString());
        }

        if (! tokens.containsKey(HeaderDeclarationParam.DECLARATION_REFERENCE)) {
            tokens.put(HeaderDeclarationParam.DECLARATION_REFERENCE, UUID.randomUUID().toString());
        }

        String declarationType = tokens.get(HeaderDeclarationParam.DECLARATION_TYPE);
        if (declarationType != null) {
            if (declarationType.equalsIgnoreCase("IM"))
            {
                tokens.put(HeaderDeclarationParam.CONSIGNOR_TYPE, "CZ");
//                tokens.put(HeaderDeclarationParam.CONSIGNEE_TYPE, "IM");
            }
            else
            {
//                tokens.put(HeaderDeclarationParam.CONSIGNOR_TYPE, "EX");
                tokens.put(HeaderDeclarationParam.CONSIGNEE_TYPE, "CN");
            }
        }

        return deTokenizer.replaceTokens(template, tokens);
    }

    public String createDeclarationForImportAndExports(String template, Map<DmsDeclarationParam, String> tokens) {
        if (! tokens.containsKey(DMSHeaderDeclarationParam.FUNCTIONAL_REF_ID)) {
            tokens.put(DMSHeaderDeclarationParam.FUNCTIONAL_REF_ID, UUID.randomUUID().toString());
        }
        return deTokenizer.replaceDmsDecTokens(template, tokens);
    }

    public Set<String> getAvailableReplacementTokens(String template) {
        return deTokenizer.getTokens(template);
    }

    public Optional<String> getDeclarationIdFromRequest(String requestXml) {
        try {
            return Optional.of(evaluateXpath(requestXml, "/RiskAssessmentRequest/id"));
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    public Optional<String> getDeclarationIdFromResponse(String requestXml) {
        try {
            return Optional.of(evaluateXpath(requestXml, "/RiskAssessmentResponseDossier/id"));
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    @SneakyThrows
    public String evaluateXpath(String xml, String xPath) {
        if (documentBuilderFactory == null) {
            documentBuilderFactory = DocumentBuilderFactory.newInstance();
        }
        if (xPathFactory == null) {
            xPathFactory = XPathFactory.newInstance();
        }

        Document doc = documentBuilderFactory.newDocumentBuilder().parse(xml);
        return xPathFactory.newXPath().compile(xPath).evaluate(doc);
    }

}
