package uk.gov.hmrc.risk.test.common.enums;


public interface DeclarationParam {

    @Override
    public String toString();
}
