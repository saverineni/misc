package uk.gov.hmrc.risk.test.common.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import uk.gov.hmrc.risk.test.common.model.publishService.PublishEventModel;

import java.util.UUID;

@AllArgsConstructor
@Deprecated
public class RedisSupport {
    public static final String LATEST_PUBLISH_EVENT_KEY = "latest-publish-event";

    private RedisTemplate redisTemplate;
    private ObjectMapper objectMapper;

    @SneakyThrows
    public PublishEventModel getPublishEvent(UUID publishEventId) {
        return getPublishEvent(publishEventId.toString());
    }

    @SneakyThrows
    public PublishEventModel getPublishEvent(String publishEventId) {
        return get(publishEventId, PublishEventModel.class);
    }

    @SneakyThrows
    public <T> T get(String key, Class<T> clazz) {
        String json = get(key);

        return objectMapper.readValue(json, clazz);
    }

    @SneakyThrows
    public String get(String key) {
        ValueOperations<String, String> ops = redisTemplate.opsForValue();

        return ops.get(key);
    }

    @SneakyThrows
    public UUID getPublishEventId(UUID expectedPublishEventId, int timeoutSeconds) {
        PublishEventModel latestPublishEvent = getLatestPublishEvent(expectedPublishEventId, timeoutSeconds);
        return null != latestPublishEvent ? latestPublishEvent.getPublishEventId() : null;
    }
    @SneakyThrows
    public PublishEventModel getLatestPublishEvent(UUID expectedPublishEventId, int timeoutSeconds) {
        for (int i = 0; i < timeoutSeconds * 10; i++) {
            PublishEventModel latestPublishEvent = getLatestPublishEvent(timeoutSeconds);
            if (latestPublishEvent != null && expectedPublishEventId.equals(latestPublishEvent.getPublishEventId())) {
                return latestPublishEvent;
            }
            Thread.sleep(100);
        }
        return null;
    }
    @SneakyThrows
    public PublishEventModel getLatestPublishEvent(int timeoutSeconds) {
        for (int i = 0; i < timeoutSeconds * 10; i++) {
            PublishEventModel publishEventModel = get(LATEST_PUBLISH_EVENT_KEY, PublishEventModel.class);
            if (publishEventModel != null){
                return publishEventModel;
            }
            Thread.sleep(100);
        }
        return null;
    }
}
