//package uk.gov.hmrc.risk.test.common.model;
//
//import lombok.AllArgsConstructor;
//import lombok.Builder;
//import lombok.Builder.Default;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//import uk.gov.hmrc.risk.test.common.enums.Attribute;
//import uk.gov.hmrc.risk.test.common.enums.Matcher;
//import uk.gov.hmrc.risk.test.common.enums.RuleMetadata;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.Optional;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
//import java.util.stream.Collectors;
//
//import static uk.gov.hmrc.risk.test.common.util.IOUtils.readFromClasspath;
//
///**
// * Created by James Philipps on 12/04/17.
// */
//
//// DEPRECATED
//    // Use the version of this class in the risking-dev-local project. This model is used in many different projects
//    // so it made sense to keep it in one place. For static methods, see the new class in this package:
//    // RuleDefinitionConstants
//@Builder
//@Getter
//@Deprecated
//@NoArgsConstructor
//@AllArgsConstructor
//public class RuleDefinitionModel {
//
//    public static RuleDefinitionModel defaultModel() {
//        return fromClasspathTemplate("risking-testing-common/DrlTemplate.drl");
//    }
//
//    public static RuleDefinitionModel defaultDataTableModel() {
//        return fromClasspathTemplate("risking-testing-common/DrlDataTableTemplate.drl");
//    }
//
//    public static RuleDefinitionModel fromClasspathTemplate(String path) {
//        return parse(readFromClasspath(path));
//    }
//
//    public static GlobalDefinition globalDataTable(String dataTableUuid) {
//        return new GlobalDefinition("Collection", "datatable_" + dataTableUuid.replace("-", ""));
//    }
//
//    public static RuleDefinitionModel parse(String definition) {
//        Pattern packagePattern = Pattern.compile("package +(.*)");
//        Pattern importPattern = Pattern.compile("import +([^;]*);");
//        Pattern globalPattern = Pattern.compile("global +([^ ]*) +([^;]*);");
//        Pattern rulePattern = Pattern.compile("rule +\"([^\"]*)\"");
//        Pattern metaDataPattern = Pattern.compile("@([^(]+)\\(\"?([^)\"]+)\"?\\)?");
//        Pattern metaDataMarkerPattern = Pattern.compile("@([^(]+)");
//
//        boolean inRuleDef = false, inWhenDef = false, inThenDef = false;
//
//        List<String> lines = Arrays.asList(definition.split("\n")).stream()
//                .map(String::toString)
//                .collect(Collectors.toList());
//        List<String> whenLines = new ArrayList<>();
//        List<String> thenLines = new ArrayList<>();
//
//        RuleDefinitionModel model = RuleDefinitionModel.builder().build();
//        RuleDefinition currentRuleDefinition = null;
//
//        for (String line : lines) {
//            Matcher m;
//            String trimmedLine = line.trim();
//
//            if (trimmedLine.isEmpty()) {
//                continue;
//            }
//            if ("when".equalsIgnoreCase(trimmedLine)) {
//                inWhenDef = true;
//                continue;
//            }
//            if ("thenCreator".equalsIgnoreCase(trimmedLine)) {
//                inWhenDef = false;
//                inThenDef = true;
//                continue;
//            }
//            if ("end".equalsIgnoreCase(trimmedLine)) {
//                currentRuleDefinition.whenDef = whenLines.stream().collect(Collectors.joining("\n"));
//                currentRuleDefinition.thenDef = thenLines.stream().collect(Collectors.joining("\n"));
//                whenLines.clear();
//                thenLines.clear();
//                currentRuleDefinition = null;
//                inRuleDef = false;
//                continue;
//            }
//            if (inRuleDef) {
//                if (inWhenDef) {
//                    whenLines.add(line);
//                    continue;
//                }
//                if (inThenDef) {
//                    thenLines.add(line);
//                    continue;
//                }
//
//                m = metaDataPattern.matcher(trimmedLine);
//                if (m.find()) {
//                    RuleMetadata key = RuleMetadata.fromString(m.group(1));
//                    Optional<Object> value = m.groupCount() > 1 ? Optional.of(m.group(2)) : Optional.empty();
//                    currentRuleDefinition.metadata.put(key, new MetadataDefinition(key, value));
//                    continue;
//                }
//
//                m = metaDataMarkerPattern.matcher(trimmedLine);
//                if (m.find()) {
//                    RuleMetadata key = RuleMetadata.fromString(m.group(1));
//                    currentRuleDefinition.metadata.put(key, new MetadataDefinition(key, Optional.empty()));
//                    continue;
//                }
//            }
//
//            m = packagePattern.matcher(trimmedLine);
//            if (m.find()) {
//                model.packageDef = m.group(1);
//                continue;
//            }
//
//            m = importPattern.matcher(trimmedLine);
//            if (m.find()) {
//                model.imports.add(new ImportDefinition(m.group(1)));
//                continue;
//            }
//
//            m = globalPattern.matcher(trimmedLine);
//            if (m.find()) {
//                model.globals.add(new GlobalDefinition(m.group(1), m.group(2)));
//                continue;
//            }
//
//            m = rulePattern.matcher(trimmedLine);
//            if (m.find()) {
//                currentRuleDefinition = RuleDefinition.builder()
//                        .name(m.group(1))
//                        .build();
//                model.ruleDefinitions.add(currentRuleDefinition);
//                inRuleDef = true;
//                continue;
//            }
//        }
//        return model;
//    }
//
//    private String packageDef;
//
//    @Default
//    private List<ImportDefinition> imports = new ArrayList<>();
//    @Default
//    private List<GlobalDefinition> globals = new ArrayList<>();
//    @Default
//    private List<RuleDefinition> ruleDefinitions = new ArrayList<>();
//
//    public RuleDefinitionModel setPackageDef(String packageDef) {
//        this.packageDef = packageDef;
//        return this;
//    }
//
//    public RuleDefinitionModel addImport(String importScope) {
//        return addImport(new ImportDefinition(importScope));
//    }
//
//    public RuleDefinitionModel addImport(ImportDefinition importDefinition) {
//        this.imports.add(importDefinition);
//        return this;
//    }
//
//    public RuleDefinitionModel addGlobal(String type, String name) {
//        return addGlobal(new GlobalDefinition(type, name));
//    }
//
//    public RuleDefinitionModel addGlobal(GlobalDefinition globalDefinition) {
//        this.globals.add(globalDefinition);
//        return this;
//    }
//
//    @Override
//    public String toString() {
//        StringBuilder sb = new StringBuilder();
//        sb.append("package ").append(packageDef).append("\n").append("\n");
//        imports.stream().forEach(i -> sb.append(i));
//        sb.append("\n");
//        globals.stream().forEach(g -> sb.append(g));
//        sb.append("\n");
//        ruleDefinitions.forEach(r -> sb.append(r).append("\n\n"));
//        return sb.toString();
//    }
//
//    @Builder
//    @Getter
//    @NoArgsConstructor
//    @AllArgsConstructor
//    public static class RuleDefinition {
//
//        public static String declarationWrapper(String checks) {
//            return "declaration: DeclarationWrapper(" +
//                    checks +
//                    ")";
//        }
//
//        public static String goodsItemsWrapper(String checks) {
//            return "goodsItem: GoodsItemWrapper(" +
//                    checks +
//                    ") from goodsItems";
//        }
//
//        public static String dtCheck(Attribute attribute, Matcher matcher) {
//            return "strCheck(" + attribute + "()," + matcher + "(value))";
//        }
//
//        public static String strCheck(Attribute attribute, Matcher matcher, String value) {
//            return strCheck(attribute, matcher, value, true);
//        }
//
//        public static String strCheck(Attribute attribute, Matcher matcher, String value, Boolean positive) {
//            if (positive) {
//                return "strCheck(" + attribute + "()," + matcher + "(\"" + value + "\"))";
//            } else {
//                return "strCheck(" + attribute + "(),not(" + matcher + "(\"" + value + "\")))";
//            }
//        }
//
//        public static String thenCreator(String source) {
//            return "riskingResult.ruleFired(drools.getRule(), " + source + ");";
//        }
//
//        public static String value(String dataTableUuid) {
//            return "value: String() from datatable_" + dataTableUuid.replace("-", "");
//        }
//
//        public static String goodsItemVariable() {
//            return "goodsItems: goodsItems()";
//        }
//
//        @Default
//        private Map<RuleMetadata, MetadataDefinition> metadata = new HashMap<>();
//
//        private String name, whenDef, thenDef;
//
//        public RuleDefinition setName(String name) {
//            this.name = name;
//            return this;
//        }
//
//        public RuleDefinition setWhenDef(String whenDef) {
//            this.whenDef = whenDef;
//            return this;
//        }
//
//        public RuleDefinition setThenDef(String thenDef) {
//            this.thenDef = thenDef;
//            return this;
//        }
//
//        public RuleDefinition addMetadata(RuleMetadata key, Object value) {
//            addMetadata(new MetadataDefinition(key, Optional.ofNullable(value)));
//            return this;
//        }
//
//        public RuleDefinition addMetadata(MetadataDefinition metadataDefinition) {
//            if (metadata == null) {
//                metadata = new HashMap<>();
//            }
//            metadata.put(metadataDefinition.getKey(), metadataDefinition);
//            return this;
//        }
//
//        @Override
//        public String toString() {
//            StringBuilder sb = new StringBuilder();
//            sb.append("rule \"").append(name).append("\"\n");
//            metadata.values().stream().forEach(m -> sb.append("\t").append(m));
//            sb.append("\twhen\n\t").append(whenDef.replace("\n", "\n\t")).append("\n");
//            sb.append("\tthen\n\t").append(thenDef.replace("\n", "\n\t")).append("\n");
//            sb.append("end");
//            return sb.toString();
//        }
//    }
//
//    @Getter
//    @Setter
//    @AllArgsConstructor
//    public static class ImportDefinition {
//        private String target;
//
//        @Override
//        public String toString() {
//            return "import " + target + ";\n";
//        }
//    }
//
//    @Getter
//    @Setter
//    @AllArgsConstructor
//    public static class GlobalDefinition {
//        private String type, name;
//
//        @Override
//        public String toString() {
//            return "global " + type + " " + name + ";\n";
//        }
//    }
//
//    @Getter
//    @NoArgsConstructor
//    public static class MetadataDefinition {
//        private RuleMetadata key;
//        private Optional<Object> value;
//        private Class<?> valueType;
//
//        public MetadataDefinition(RuleMetadata key, Optional<Object> value) {
//            this.key = key;
//            this.value = value;
//            this.valueType = classFromValue(value.toString());
//        }
//
//        private static Class<?> classFromValue(String val) {
//            try {
//                Boolean.parseBoolean(val);
//                return Boolean.class;
//            } catch (Exception e) {
//            }
//            try {
//                Integer.parseInt(val);
//                return Integer.class;
//            } catch (Exception e) {
//            }
//            try {
//                Long.parseLong(val);
//                return Long.class;
//            } catch (Exception e) {
//            }
//
//            return String.class;
//        }
//
//        @Override
//        public String toStringl() {
//            return key.toMetadata(value) + "\n";
//        }
//    }
//}
