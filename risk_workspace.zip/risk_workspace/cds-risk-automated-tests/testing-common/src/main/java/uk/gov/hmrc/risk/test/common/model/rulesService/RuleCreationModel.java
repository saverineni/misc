package uk.gov.hmrc.risk.test.common.model.rulesService;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;
import uk.gov.hmrc.risk.test.common.enums.RuleBehaviourType;

import java.util.List;


@Builder
@Data
public class RuleCreationModel {
    private String description, definition, startDateTime, creatorPid, ruleType, regimeCodeUuid, sensitivityLevelUuid, securityStatusUuid;
    private String uniqueId, reason;
    private List<String> locationUuids, dataTableUuids;
    private JsonContainer json;


    @Builder
    @Data
    public static class JsonContainer {
        boolean valid;
        private String description, route, startDateTime, regimeUuid, sensitivityLevelUuid;
        private List<QueryContainerJson> query;

        @JsonProperty("ruleOutputBehaviours")
        private List<BehaviourContainer> behaviours;
    }

    @Builder
    @Data
    public static class QueryContainerJson {
        private String operator;
        private List<QueryJson> query;
    }

    @Builder
    @Data
    public static class QueryJson {
        private String attribute, operator, value;
    }

    @Builder
    @Data
    public static class BehaviourContainer {
        @JsonProperty("behaviourType")
        private RuleBehaviourType behaviourType;
        @JsonProperty("actionType")
        private String controlType;
        @JsonProperty("actionNarrative")
        private String narrative;
    }
}
