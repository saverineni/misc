package uk.gov.hmrc.risk.test.common.model.rulesManagementService;

import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * Created by developer on 25/07/18.
 */
@Builder
@Data
public class EditDataTableItemsModel {

    private String opLockVersion, reason;
    private List<String> addedElements, removedElements;
}
