package uk.gov.hmrc.risk.test.common.model.declarationSupport;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class ItemModel extends TokenableModel {

    private String methodOfPayment, preference, statisticalAmount, invoiceAmount, previousProcedure, requestedProcedure;
    private String specialProcedures, sequenceNumber, declaredCustomsValue, valuationMethod;
    private String goodsDescription, dangerousGoodsCode, unDangerousGoodsCode;
    private String containers;
    private String customsValueAmount;
    private String packaging;
    private String additionalDocuments;
    private String countryRegions;
    private String additionalInformation;
    private String declaredDutyTaxFees;
    private String commodities;
    private String parties;
    private String previousDocuments;
    private String valuationAdjustments;

    @Builder
    @Data
    public static class Packaging extends TokenableModel {
        private String marksNumbers, quantity, type;
    }

    @Builder
    @Data
    public static class AdditionalDocuments extends TokenableModel {
        private String identifier, quantity, type;
    }

    @Builder
    @Data
    public static class AdditionalInformation extends TokenableModel {
        private String code, language, text;
    }

    @Builder
    @Data
    public static class CountryRegions extends TokenableModel {
        private String country, subRole, type;
    }

    @Builder
    @Data
    public static class DeclaredDutyTaxFees extends TokenableModel {
        private String type, adValoremBase, specificBase, rate, totalAmount, payableAmount, methodOfPayment;
        private String preference, quotaOrderNumber;
    }

    @Builder
    @Data
    public static class CommodityClassifications extends TokenableModel {
        private String identifier, type;
    }

    @Builder
    @Data
    public static class Containers extends TokenableModel {
        private String sequenceNumber, id, type;
    }

    @Builder
    @Data
    public static class Parties extends TokenableModel {
        private String type, partyName;

        private String addressCityName, addressStreetAndNumber, addressZipCode;
        private String addressCountry;

        private String idType, eori;
    }

    @Builder
    @Data
    public static class PreviousDocuments extends TokenableModel {
        private String type, sequenceNumber, lineNumber, category, id;
    }

    @Builder
    @Data
    public static class ValuationAdjustments extends TokenableModel {
        private String type, sequenceNumber, amount;
    }


}