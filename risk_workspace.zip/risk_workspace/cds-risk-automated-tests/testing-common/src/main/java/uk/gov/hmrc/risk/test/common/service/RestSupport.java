package uk.gov.hmrc.risk.test.common.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.fluent.Request;
import org.apache.http.message.BasicHeader;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;

import static uk.gov.hmrc.risk.test.common.util.IOUtils.readInputStream;

@Slf4j
public class RestSupport {

    public static final String AUTH_HEADER_NAME = HttpHeaders.AUTHORIZATION;
    public static final BasicHeader DEFAULT_AUTH_HEADER = new BasicHeader(AUTH_HEADER_NAME, "7777777");

    public static StatusCodeMatcher statusCode1xx() {
        return new StatusCodeMatcher(startsWith("1"), "1xx");
    }

    public static StatusCodeMatcher statusCode2xx() {
        return new StatusCodeMatcher(startsWith("2"), "2xx");
    }

    public static StatusCodeMatcher statusCode3xx() {
        return new StatusCodeMatcher(startsWith("3"), "3xx");
    }

    public static StatusCodeMatcher statusCode4xx() {
        return new StatusCodeMatcher(startsWith("4"), "4xx");
    }

    public static StatusCodeMatcher statusCode5xx() {
        return new StatusCodeMatcher(startsWith("5"), "5xx");
    }

    public static StatusCodeMatcher statusCode(int statusCode) {
        return new StatusCodeMatcher(i -> i == statusCode, Integer.toString(statusCode));
    }

    private static MatchFunction startsWith(String chars) {
        return (i -> Integer.toString(i).startsWith(chars));
    }

    private final ObjectMapper jsonMapper;

    public RestSupport(ObjectMapper jsonMapper) {
        this.jsonMapper = jsonMapper;
    }

    @SneakyThrows
    public <T> T getResponseAsJson(Request request, Class<T> targetClass) {
        return getResponseAsJson(request, targetClass, null);
    }

    @SneakyThrows
    public <T> T getTypedResponseAsJson(Request request, TypeReference<T> typeRef) {
        return getResponseAsJson(request, typeRef, null);
    }

    @SneakyThrows
    public <T> T getResponseAsJson(Request request, Class<T> targetClass, StatusCodeMatcher expectedStatusCode) {
        return jsonMapper.readValue(getResponseAsString(request, expectedStatusCode), targetClass);
    }

    @SneakyThrows
    public <T> T getResponseAsJson(Request request, TypeReference<T> typeRef, StatusCodeMatcher expectedStatusCode) {
        return jsonMapper.readValue(getResponseAsString(request, expectedStatusCode), typeRef);
    }

    @SneakyThrows
    public String getResponseAsString(Request request) {
        return getResponseAsString(request, null);
    }

    public String getResponseAsString(Request request, StatusCodeMatcher expectedStatusCode) {
        return getResponseAsString(request, expectedStatusCode, true);
    }

    @SneakyThrows
    public String getResponseAsString(Request request, StatusCodeMatcher expectedStatusCode, boolean logResponse) {
        return responseBody(getResponse(request, expectedStatusCode, logResponse));
    }

    @SneakyThrows
    public HttpResponse getResponse(Request request) {
        return getResponse(request, null, true);
    }

    public HttpResponse getResponse(Request request, StatusCodeMatcher expectedStatusCode) {
        return getResponse(request, expectedStatusCode, true);
    }

    @SneakyThrows
    public HttpResponse getResponse(Request request, StatusCodeMatcher expectedStatusCode, boolean logResponse) {
        log.info("Request: {}", request.toString());

        return expectStatusCode(
                request.execute().returnResponse(),
                expectedStatusCode,
                logResponse
        );
    }

    private HttpResponse expectStatusCode(HttpResponse response, StatusCodeMatcher matcher) {
        return expectStatusCode(response, matcher, true);
    }

    private HttpResponse expectStatusCode(HttpResponse response, StatusCodeMatcher matcher, boolean logResponse) {
        if (logResponse) {
            logResponse(response);
        }

        int statusCode = response.getStatusLine().getStatusCode();
        if (matcher != null && !matcher.matches(statusCode)) {
            throw new StatusCodeException(matcher.getDescription(), Integer.toString(statusCode));
        }
        return response;
    }

    private void logResponse(HttpResponse response) {
        StatusLine status = response.getStatusLine();
        log.info("Response Status - Code: {}, Reason: {}", status.getStatusCode(), status.getReasonPhrase());
        log.info("Response body: {}", responseBody(response));
    }

    @SneakyThrows
    private String responseBody(HttpResponse response) {
        return response.getEntity() != null ?
                readInputStream(response.getEntity().getContent()) :
                "";
    }

    @RequiredArgsConstructor
    public static class StatusCodeException extends RuntimeException {
        private final String expectedCode, actualCode;

        @Override
        public String getMessage() {
            return "Http Status code: " + actualCode + " was not equal to expected code: " + expectedCode;
        }
    }

    @Getter
    @RequiredArgsConstructor
    public static class StatusCodeMatcher extends BaseMatcher<Integer> {

        final MatchFunction matchFunction;
        final String description;

        @Override
        public boolean matches(Object o) {
            return matchFunction.match((Integer) o);
        }

        @Override
        public void describeTo(Description description) {
            description.appendText(this.description);
        }
    }

    private interface MatchFunction {
        boolean match(int statusCode);
    }
}
