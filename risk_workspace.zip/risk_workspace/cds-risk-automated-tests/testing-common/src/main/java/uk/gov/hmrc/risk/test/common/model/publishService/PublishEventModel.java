package uk.gov.hmrc.risk.test.common.model.publishService;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.ToString;

import java.util.UUID;

@Data
@ToString
public class PublishEventModel {

    private UUID publishEventId;
    private UUID messageId;
    private String timestamp;
    private UUID dataTablePackageId;
    private UUID rulePackageId;
    private PublishedRules rulePackage;
    private PublishedDataTables dataTablePackage;

    @JsonCreator
    public PublishEventModel(@JsonProperty("publishEventId") String publishEventId,
                             @JsonProperty("messageId") String messageId,
                             @JsonProperty("timestamp") String timestamp,
                             @JsonProperty("rulePackageId") String rulePackageId,
                             @JsonProperty("dataTablePackageId") String dataTablePackageId,
                             @JsonProperty("rulePackage") PublishedRules rulePackage,
                             @JsonProperty("dataTablePackage") PublishedDataTables dataTablePackage
                             ) {
        this.publishEventId = publishEventId != null ? UUID.fromString(publishEventId) : null;
        this.messageId = messageId != null ? UUID.fromString(messageId) : null;
        this.timestamp = timestamp;
        this.dataTablePackageId = dataTablePackageId  != null ? UUID.fromString(dataTablePackageId) : null;
        this.rulePackageId = rulePackageId  != null ? UUID.fromString(rulePackageId) : null;
        this.rulePackage = rulePackage;
        this.dataTablePackage = dataTablePackage;
    }
}