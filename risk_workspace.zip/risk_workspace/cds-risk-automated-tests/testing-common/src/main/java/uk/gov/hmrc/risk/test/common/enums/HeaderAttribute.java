package uk.gov.hmrc.risk.test.common.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum HeaderAttribute implements Attribute{

    CONSIGNEE_CITY("consigneeCity"),
    CONSIGNEE_NAME("consigneeName"),
    CONSIGNEE_EORI("consigneeEori"),
    CONSIGNEE_POSTCODE("consigneePostcode"),
    CONSIGNEE_ADDRESS("consigneeAddress"),
    CONSIGNEE_COUNTRY("consigneeCountry"),

    CONSIGNOR_EORI("consignorEori"),
    CONSIGNOR_NAME("consignorName"),
    CONSIGNOR_ADDRESS("consignorAddress"),
    CONSIGNOR_POSTCODE("consignorPostcode"),
    CONSIGNOR_CITY("consignorCity"),
    CONSIGNOR_COUNTRY("consignorCountry"),

    DECLARANT_EORI("declarantEori"),
    DECLARANT_NAME("declarantName"),
    DECLARANT_ADDRESS("declarantAddress"),
    DECLARANT_CITY("declarantCity"),
    DECLARANT_POSTCODE("declarantPostcode"),
    DECLARANT_COUNTRY("declarantCountry"),

    REPRESENTATIVE_NAME("representativeName"),
    REPRESENTATIVE_EORI("representativeEori"),
    REPRESENTATIVE_ADDRESS("representativeAddress"),
    REPRESENTATIVE_CITY("representativeCity"),
    REPRESENTATIVE_POSTCODE("representativePostcode"),
    REPRESENTATIVE_COUNTRY("representativeCountry"),

    DISPATCH_COUNTRY("dispatchCountry"),
    ORIGIN_COUNTRY("originCountry"),
    DESTINATION_COUNTRY("destinationCountry"),
    TRANSPORT_MODE("transportMode"),
    GOODS_LOCATION("goodsLocation"),
    MODE_OF_ENTRY("modeOfEntry"),
    DECLARATION_TYPE("declarationType"),
    DECLARATION_SUBTYPE("declarationSubType"),
    PAYING_AGENT_EORI("payingAgentEori"),

    EXPORTER_NAME("exporterName"),
    EXPORTER_ID("exporterEori"),
    EXPORTER_ADDRESS("exporterAddress"),
    EXPORTER_CITY("exporterCity"),
    EXPORTER_POSTCODE("exporterPostcode"),
    EXPORTER_COUNTRY("exporterCountry"),

    IMPORTER_EORI("importerEori"),
    IMPORTER_ADDRESS("importerAddress"),
    IMPORTER_CITY("importerCity"),
    IMPORTER_POSTCODE("importerPostcode"),
    IMPORTER_COUNTRY("importerCountry"),
    IMPORTER_NAME("importerName");

    public final String method;

    @Override
    public String toString() {
        return method;
    }
}
