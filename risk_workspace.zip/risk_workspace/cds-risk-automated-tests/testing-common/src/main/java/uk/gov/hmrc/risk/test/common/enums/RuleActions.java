package uk.gov.hmrc.risk.test.common.enums;

public enum RuleActions {
    suspend, reinstate, archive,silence;
}
