package uk.gov.hmrc.risk.test.common.service;

import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.fluent.Request;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static uk.gov.hmrc.risk.test.common.service.RestSupport.DEFAULT_AUTH_HEADER;
import static uk.gov.hmrc.risk.test.common.service.RestSupport.statusCode2xx;

/**
 * Created by James Philipps on 12/04/17.
 */
@Slf4j
@RequiredArgsConstructor
public class LocationsSupport {

    private final RestSupport restSupport;
    private final LocationsSupportConfig config;

    public Map<String, String> getLocations() {
        log.debug("Sending locations codes request..");

        return ((List<Map<String, String>>) restSupport
                .getResponseAsJson(Request.Get(config.getLocationsUrl()).addHeader(DEFAULT_AUTH_HEADER),
                        List.class, statusCode2xx()))
                .stream()
                .collect(Collectors.toMap(r -> r.get("name"), r -> r.get("uniqueId")));
    }

    public List<Map<String, String>> getListOfLocationUIDs() {

        String url = config.getLocationsUrl();
        log.info("\n Getting List of Location UIDs: ");
        log.info("GET Request: " + url);

        return ((List<Map<String, String>>) restSupport
                .getResponseAsJson(Request.Get(config.getLocationsUrl()).addHeader(DEFAULT_AUTH_HEADER),
                        List.class, statusCode2xx()));
    }

    @Builder
    @Getter
    public static class LocationsSupportConfig {
        private String locationsUrl;
    }
}
