package specs

import geb.driver.CachingDriverFactory
import geb.spock.GebReportingSpec
import jodd.log.LoggerFactory
import spock.lang.Stepwise

import java.util.logging.Logger

class BaseGebSpec extends GebReportingSpec {

    //private static final Logger logger = LoggerFactory.getLogger(BaseGebSpec.class) as Logger


    def setup() {
        if(!this.getClass().isAnnotationPresent(Stepwise.class)) {
            CachingDriverFactory.clearCacheAndQuitDriver()
        }
    }

//    def cleanup() {
//        browser.close()
//    }

    private static String getEnv() {
        def env = System.getProperty("geb.env")
        if (env != null) {
            return env
        }
        System.getProperty("defaultEnvironment")
    }
}
