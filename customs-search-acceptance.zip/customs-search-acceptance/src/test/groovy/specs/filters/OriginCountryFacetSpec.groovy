package specs.filters

import geb.module.FormElement
import pages.DeclarationSearchPage
import pages.SignInPage
import specs.BaseGebSpec
import spock.lang.Shared

class OriginCountryFacetSpec extends BaseGebSpec {

    @Shared recordCount
    static final String FACET_HEADER_TEXT = "Select Country of Origin"
    static final String COUNTRY_CODE_NL = "NL"
    static final String COUNTRY_CODE_MX = "MX"
    static final String COUNTRY_CODE_UNKNOWN = "Unknown"

    def "Check Country of Origin facet can be launched and correct fields are present"() {
        given: "I have logged in"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I click on the Country of Origin filter"

            decSearchPage.filterFields.selectOriginCountryFilter()

        then: "the Country of origin filter should should load and display all relevant controls"

            decSearchPage.facetOverlay.headerText.text() == FACET_HEADER_TEXT
            decSearchPage.facetOverlay.searchBar.isDisplayed()
            decSearchPage.facetOverlay.cancelButton.isDisplayed()
            decSearchPage.facetOverlay.applyFiltersButton.isDisplayed()
            decSearchPage.facetOverlay.applyFiltersButton.module(FormElement).isDisabled()
    }

    def "Verify happy path of applying filter for a single country code"() {
        given: "I login and have launched the Country of Origin facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectOriginCountryFilter()

        when: "I select country code NL and apply the filter"

            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_NL)
            decSearchPage.facetOverlay.applyFiltersButton.click()

        then: "the NL chip is visible outside the facet along with the correct results count"

            decSearchPage.selectedFilterFields.filterLabel.text() == "Country of Origin"
            decSearchPage.selectedFilterFields.isChipVisible(COUNTRY_CODE_NL)
            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 100"
    }

    def "Verify happy path of applying filter for multiple country codes"() {
        given: "I login and have launched the Country of Origin facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectOriginCountryFilter()

        when: "I select country codes NL and MX and apply the filter"

            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_NL)
            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_MX)

        decSearchPage.facetOverlay.applyFiltersButton.click()

        then: "the search applied is OR'd with the correct results count displayed along with chips NL and MX visible outside the facet"

            decSearchPage.selectedFilterFields.filterLabel.text() == "Country of Origin"
            decSearchPage.selectedFilterFields.isChipVisible(COUNTRY_CODE_NL)
            decSearchPage.selectedFilterFields.isChipVisible(COUNTRY_CODE_MX)
            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 102"
    }

    def "Check links are disabled and chips appear within facet upon country code selections"() {
        given: "I login and have launched the Country of Origin facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectOriginCountryFilter()

        when: "I select the country codes NL and MX"

            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_NL)
            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_MX)

        then: "the selected country code links are disabled, the correct chips appear and Apply Filters button is enabled"

            decSearchPage.facetOverlay.isFacetLinkDisabled(COUNTRY_CODE_NL)
            decSearchPage.facetOverlay.isFacetLinkDisabled(COUNTRY_CODE_MX)
            decSearchPage.facetOverlay.isChipVisible(COUNTRY_CODE_NL)
            decSearchPage.facetOverlay.isChipVisible(COUNTRY_CODE_NL)
            decSearchPage.facetOverlay.applyFiltersButton.module(FormElement).isEnabled()
    }

    def "Ensure country code links are re-enabled when chips are cancelled within facet"() {
        given: "I have selected NL and MX within the Origin Country facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectOriginCountryFilter()
            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_NL)
            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_MX)

        when: "I remove the chips for all selected country codes"

            decSearchPage.facetOverlay.cancelAllChips()

        then: "the all country code links in the list should be clickable and Apply Filters button should be disabled"

            decSearchPage.facetOverlay.allFacetLinksEnabled()
            decSearchPage.facetOverlay.applyFiltersButton.module(FormElement).isDisabled()
    }

    def "Verify cancelling chip outside the facet updates search results and removes chip from facet"() {
        given: "I have applied filter for NL and MX within the Origin Country facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectOriginCountryFilter()
            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_NL)
            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_MX)
            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_UNKNOWN)
            decSearchPage.facetOverlay.applyFiltersButton.click()

        when: "I remove the NL chip from outside the facet"

            decSearchPage.selectedFilterFields.chipsVisibleCancel.first().click()

        then: "then the search results will be updated"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 10"

        and: "the Origin Country facet will the Unknown and MX chips"

            decSearchPage.filterFields.selectOriginCountryFilter()
            decSearchPage.facetOverlay.chipsVisible.size() == 2
            decSearchPage.facetOverlay.isChipVisible(COUNTRY_CODE_MX)
            decSearchPage.facetOverlay.isChipVisible(COUNTRY_CODE_UNKNOWN)
    }

    def "Filter for a country code with partial lower case text"() {
        given: "I login and have launched the Country of Origin facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectOriginCountryFilter()

        when: "I enter partial lowercase text that would match multiple country codes"

            decSearchPage.facetOverlay.searchBar.value("c")

        then: "the country code list will contain two country codes"

            decSearchPage.facetOverlay.totalVisibleLinks() == 2
    }

    def "Filter for a country code with upper case text"() {
        given: "I login and have launched the Country of Origin facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectOriginCountryFilter()

        when: "I enter uppercase text that would match a single country code"

            decSearchPage.facetOverlay.searchBar.value("BR")

        then: "the country code list will contain a single country code"

            decSearchPage.facetOverlay.totalVisibleLinks() == 1
    }

    def "Filter for Unknown country codes with camel case text"() {
        given: "I login and have launched the Country of Origin facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectOriginCountryFilter()

        when: "I enter 'Unk' that would match on Unknown country codes"

            decSearchPage.facetOverlay.searchBar.value("Unk")

        then: "the country code list will contain only the Unknown country codes"

            decSearchPage.facetOverlay.totalVisibleLinks() == 1
    }

    def "Filter for a country code that does not exist"() {
        given: "I login and have launched the Country of Origin facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectOriginCountryFilter()

        when: "I enter a country code that does not exist"

            decSearchPage.facetOverlay.searchBar.value("ZZ")

        then: "a no results found message will be displayed"

            decSearchPage.facetOverlay.linkTextListVisible.text() == "No results found"
    }

    def "Verify the Cancel button closes the facet"() {
        given: "I login and have launched the Country of Origin facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.searchFields.searchFor("")
            recordCount = decSearchPage.searchFields.recordsFoundMessage.text()
            decSearchPage.filterFields.selectOriginCountryFilter()

        when: "I click the Cancel button"

            decSearchPage.facetOverlay.cancelButton.click()

        then: "the Origin Country facet will close without applying a search"

            decSearchPage.facetOverlay.isFacetDisabled()
            decSearchPage.searchFields.recordsFoundMessage.text() == recordCount
    }

    def "Verify the Cancel button clears the facet from previous selections if Apply Filters not applied"() {
        given: "I login and have launched the Country of Origin facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectOriginCountryFilter()

        when: "I select some country codes, click the Cancel button and relaunch the facet"

            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_NL)
            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_MX)
            decSearchPage.facetOverlay.cancelButton.click()
            decSearchPage.filterFields.selectOriginCountryFilter()

        then: "all links should be clickable and no chips should appear"

            decSearchPage.facetOverlay.allFacetLinksEnabled()
    }

    def "Verify the Country of Origin facet is disabled when there are no country codes available for selection"() {
        given: "I have logged in and search with Entry Date from todays date"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.entryDateFilterLink.click()
            decSearchPage.entryDateFilter.fromTodaysDate()

        when: "I click the Entry Date Apply Filters button"

            decSearchPage.entryDateFilter.applyFiltersButton.click()

        then: "the Country of Origin filter link should be disabled"

            decSearchPage.filterFields.isOriginCountryFilterDisabled()
    }

    //TODO check counts in facet
}
