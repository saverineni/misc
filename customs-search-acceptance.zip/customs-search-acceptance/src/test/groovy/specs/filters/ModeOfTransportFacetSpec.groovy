package specs.filters

import geb.module.FormElement
import pages.DeclarationSearchPage
import pages.SignInPage
import specs.BaseGebSpec
import spock.lang.Shared

class ModeOfTransportFacetSpec  extends BaseGebSpec {
    @Shared
    static final String FACET_HEADER_TEXT = "Select Mode of Transport"
    static final String TRANSPORT_CODE_ZERO = "0"
    static final String TRANSPORT_CODE_THREE = "3"


    def "Check Mode of Transport facet can be launched and correct fields are present"() {

        given: "I have logged in"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I click on the Mode Of Transport link"

            decSearchPage.filterFields.modeofTransportFilterLink.click()

        then: "the Mode of Transport filter should should load and display all relevant controls"

            decSearchPage.facetOverlay.headerText.text() == FACET_HEADER_TEXT
            decSearchPage.facetOverlay.searchBar.isDisplayed()
            decSearchPage.facetOverlay.cancelButton.isDisplayed()
            decSearchPage.facetOverlay.applyFiltersButton.isDisplayed()
            decSearchPage.facetOverlay.applyFiltersButton.module(FormElement).isDisabled()
    }

    def "Verify happy path of applying filter for a single transport code"() {
        given: "I login and have launched the Mode of Transport facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectModeofTransportFilter()

        when: "I select transport code 0 and apply the filter"

            decSearchPage.facetOverlay.clickLinkFor(TRANSPORT_CODE_THREE)
            decSearchPage.facetOverlay.applyFiltersButton.click()

        then: "the zero chip is visible outside the facet along with the correct results count"

            decSearchPage.selectedFilterFields.filterLabel.text() == "Mode of Transport"
            decSearchPage.selectedFilterFields.isChipVisible(TRANSPORT_CODE_THREE)
            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 40"
    }

    def "Verify happy path of applying filter for multiple mode of transport codes"() {
        given: "I login and have launched the Mode of Transport facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectModeofTransportFilter()

        when: "I select mode of transport codes 0 and 3 and apply the filter"

            decSearchPage.facetOverlay.clickLinkFor(TRANSPORT_CODE_ZERO)
            decSearchPage.facetOverlay.clickLinkFor(TRANSPORT_CODE_THREE)
            decSearchPage.facetOverlay.applyFiltersButton.click()

        then: "the search applied is OR'd with the correct results count displayed along with chips 0 and 3 visible outside the facet"

            decSearchPage.selectedFilterFields.filterLabel.text() == "Mode of Transport"
            decSearchPage.selectedFilterFields.isChipVisible(TRANSPORT_CODE_ZERO)
            decSearchPage.selectedFilterFields.isChipVisible(TRANSPORT_CODE_THREE)
            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 90"
    }

    def "Verify cancelling chip outside the facet updates search results and removes chip from facet"() {
        given: "I have applied filter for 0 and 3 within the Mode of Transport facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectModeofTransportFilter()
            decSearchPage.facetOverlay.clickLinkFor(TRANSPORT_CODE_ZERO)
            decSearchPage.facetOverlay.clickLinkFor(TRANSPORT_CODE_THREE)
            decSearchPage.facetOverlay.applyFiltersButton.click()

        when: "I remove the 0 chip from outside the facet"

            decSearchPage.selectedFilterFields.chipsVisibleCancel.first().click()

        then: "then the search results will be updated"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 40"

        and: "the Mode of Transport facet will only show the 3 chip"

            decSearchPage.filterFields.selectModeofTransportFilter()
            decSearchPage.facetOverlay.chipsVisible.size() == 1
            decSearchPage.facetOverlay.isChipVisible(TRANSPORT_CODE_THREE)
    }

    def "Verify the Mode of Transport facet is disabled when there are no mode of transport codes available for selection"() {
        given: "I have logged in and search with Entry Date from today's date"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.entryDateFilterLink.click()
            decSearchPage.entryDateFilter.fromTodaysDate()

        when: "I click the Entry Date Apply Filters button"

            decSearchPage.entryDateFilter.applyFiltersButton.click()

        then: "the mode of transport filter link should be disabled"

            decSearchPage.filterFields.isModeOfTransportFilterDisabled()
    }

    def "Verify filter can be used for a numeric Mode of Transport code"() {
        given: "I login and have launched the Mode of Transport facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectModeofTransportFilter()

        when: "I filter for Mode of Transport 9"

            decSearchPage.facetOverlay.searchBar.value("9")

        then: "the Mode of Transport list will contain one code"

            decSearchPage.facetOverlay.totalVisibleLinks() == 1
    }

}
