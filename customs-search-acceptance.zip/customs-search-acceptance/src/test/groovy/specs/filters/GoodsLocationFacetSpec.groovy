package specs.filters

import geb.module.FormElement
import pages.DeclarationSearchPage
import pages.SignInPage
import specs.BaseGebSpec

class GoodsLocationFacetSpec extends BaseGebSpec {

    static final String FACET_HEADER_TEXT = "Select Goods Location"
    static final String GOODS_LOCATION_PHD = "PHD"
    static final String GOODS_LOCATION_ELF = "ELF"

    def "Check Goods Location facet can be launched and correct fields are present"() {
        given: "I have logged in"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I click on the Goods Location filter"

            decSearchPage.filterFields.selectGoodsLocationFilter()

        then: "the Goods Location filter should should load and display all relevant controls"

            decSearchPage.facetOverlay.headerText.text() == FACET_HEADER_TEXT
            decSearchPage.facetOverlay.searchBar.isDisplayed()
            decSearchPage.facetOverlay.cancelButton.isDisplayed()
            decSearchPage.facetOverlay.applyFiltersButton.isDisplayed()
            decSearchPage.facetOverlay.applyFiltersButton.module(FormElement).isDisabled()
    }

    def "Verify happy path of applying filter for a single goods location"() {
        given: "I login and have launched the Goods Location facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectGoodsLocationFilter()

        when: "I select goods location PHD and apply the filter"

            decSearchPage.facetOverlay.clickLinkFor(GOODS_LOCATION_PHD)
            decSearchPage.facetOverlay.applyFiltersButton.click()

        then: "the PHD chip is visible outside the facet along with the correct results count"

            decSearchPage.selectedFilterFields.filterLabel.text() == "Goods Location"
            decSearchPage.selectedFilterFields.isChipVisible(GOODS_LOCATION_PHD)
            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 10"
    }

    def "Verify happy path of applying filter for multiple goods locations"() {
        given: "I login and have launched the Goods Location facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectGoodsLocationFilter()

        when: "I select goods locations PHD and ELF and apply the filter"

            decSearchPage.facetOverlay.clickLinkFor(GOODS_LOCATION_PHD)
            decSearchPage.facetOverlay.clickLinkFor(GOODS_LOCATION_ELF)
            decSearchPage.facetOverlay.applyFiltersButton.click()

        then: "the search applied is OR'd with the correct results count displayed along with chips PHD and ELF visible outside the facet"

            decSearchPage.selectedFilterFields.filterLabel.text() == "Goods Location"
            decSearchPage.selectedFilterFields.isChipVisible(GOODS_LOCATION_PHD)
            decSearchPage.selectedFilterFields.isChipVisible(GOODS_LOCATION_ELF)
            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 35"
    }

    def "Verify cancelling chip outside the facet updates search results and removes chip from facet"() {
        given: "I have applied filter for PHD and ELF within the Goods Location facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectGoodsLocationFilter()
            decSearchPage.facetOverlay.clickLinkFor(GOODS_LOCATION_PHD)
            decSearchPage.facetOverlay.clickLinkFor(GOODS_LOCATION_ELF)
            decSearchPage.facetOverlay.applyFiltersButton.click()

        when: "I remove the PHD chip from outside the facet"

            decSearchPage.selectedFilterFields.chipsVisibleCancel.first().click()

        then: "then the search results will be updated"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 10"

        and: "the Goods Location facet will only display the ELF chip"

            decSearchPage.filterFields.selectGoodsLocationFilter()
            decSearchPage.facetOverlay.chipsVisible.size() == 1
            decSearchPage.facetOverlay.isChipVisible(GOODS_LOCATION_PHD)
    }

    def "Verify the Goods Location facet is disabled when there are no goods locations available for selection"() {
        given: "I have logged in and search with Entry Date from todays date"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.entryDateFilterLink.click()
            decSearchPage.entryDateFilter.fromTodaysDate()

        when: "I click the Entry Date Apply Filters button"

            decSearchPage.entryDateFilter.applyFiltersButton.click()

        then: "the Goods Location filter link should be disabled"

            decSearchPage.filterFields.isGoodsLocationFilterDisabled()
    }

    //TODO searching for blank goods location
}
