package specs.filters

import geb.module.FormElement
import pages.DeclarationSearchPage
import pages.SignInPage
import specs.BaseGebSpec
import spock.lang.Shared

class EntryDateFilterSpec extends BaseGebSpec {

    private static final String SEARCH_TERM = "786"
    private static final String FROM_DATE = "01/01/2016"
    private static final String TO_DATE = "30/11/2016"
    @Shared String resultsCount


    def "Check all Entry Date fields are visible"() {
        given: "I have logged in"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I click on the Entry Date link"

            decSearchPage.filterFields.entryDateFilterLink.click()

        then: "all the Entry Date filter fields will be visible and Apply Filters button is disabled by default"

            decSearchPage.entryDateFilter.fromDateField.isDisplayed()
            decSearchPage.entryDateFilter.toDateField.isDisplayed()
            decSearchPage.entryDateFilter.clearButton.isDisplayed()
            decSearchPage.entryDateFilter.applyFiltersButton.isDisplayed()
            decSearchPage.entryDateFilter.applyFiltersButton.module(FormElement).isDisabled()
    }

    def "Verify user can enter dates directly into Entry Date fields with slashes and apply a search"() {
        given: "I have logged in"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I enter a From and To Entry Date and apply the filter"

            decSearchPage.filterFields.entryDateFilterLink.click()
            decSearchPage.entryDateFilter.fromDateField.value(FROM_DATE)
            decSearchPage.entryDateFilter.toDateField.value(TO_DATE)
            decSearchPage.entryDateFilter.applyFiltersButton.click()

        then: "correct number of results will be shown"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 45"
    }

    def "Verify user can enter dates directly into Entry Date fields with dashes and apply a search"() {
        given: "I have logged in"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I enter a From and To Entry Date and apply the filter"

            decSearchPage.filterFields.entryDateFilterLink.click()
            decSearchPage.entryDateFilter.fromDateField.value(FROM_DATE.replace("/", "-"))
            decSearchPage.entryDateFilter.toDateField.value(TO_DATE.replace("/", "-"))
            decSearchPage.entryDateFilter.applyFiltersButton.click()

        then: "correct number of results will be shown"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 45"
    }

    //TODO tests failing. Suspect due to browser version on our VMs
//    def "Verify user can search with From Entry Date only and apply a search"() {
//        given: "I have logged in"
//
//            def signinPage = to SignInPage
//            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
//
//        when: "I enter a From Entry Date only and apply the filter"
//
//            decSearchPage.filterFields.entryDateFilterLink.click()
//            decSearchPage.entryDateFilter.fromDateField.value(FROM_DATE)
//            decSearchPage.entryDateFilter.applyFiltersButton.click()
//
//        then: "correct number of results will be shown"
//
//            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 50"
//    }
//
//    def "Verify user can search with To Entry Date only and apply a search"() {
//        given: "I have logged in"
//
//            def signinPage = to SignInPage
//            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
//
//        when: "I enter a To Entry Date only and apply the filter"
//
//            decSearchPage.filterFields.entryDateFilterLink.click()
//            decSearchPage.entryDateFilter.toDateField.value(TO_DATE)
//            decSearchPage.entryDateFilter.applyFiltersButton.click()
//
//        then: "correct number of results will be shown"
//
//            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 45"
//    }

    def "Verify Clear button clears and resets the search made"() {
        given: "I have searched for declarations via a valid search with Entry Dates"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.searchFields.searchFor(SEARCH_TERM)
            resultsCount = decSearchPage.searchFields.recordsFoundMessage.text()
            decSearchPage.filterFields.entryDateFilterLink.click()
            decSearchPage.entryDateFilter.fromDateField.value(FROM_DATE)
            decSearchPage.entryDateFilter.toDateField.value(TO_DATE)
            decSearchPage.entryDateFilter.applyFiltersButton.click()

        when: "I click the Clear button within the Entry Dates filter section"

            decSearchPage.entryDateFilter.clearButton.click()

        then: "both date fields will be cleared and search results are reset with correct results shown"

            decSearchPage.entryDateFilter.fromDateField.text() == ""
            decSearchPage.entryDateFilter.fromDateField.text() == ""
            decSearchPage.searchFields.recordsFoundMessage.text() == resultsCount
    }

    def "Verify the Customs Declaration Search nav bar link clears the current search completely"() {
        given: "I have searched for declarations via a valid search with Entry Dates"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.searchFields.searchFor(SEARCH_TERM)
            resultsCount = decSearchPage.searchFields.recordsFoundMessage.text()
            decSearchPage.filterFields.entryDateFilterLink.click()
            decSearchPage.entryDateFilter.fromDateField.value(FROM_DATE)
            decSearchPage.entryDateFilter.toDateField.value(TO_DATE)
            decSearchPage.entryDateFilter.applyFiltersButton.click()

        when: "I click the Customs Declaration Search nav bar link"

            decSearchPage.navFields.customsSearchLink.click()

        then: "the user is navigated back to home where previous search is completely cleared and Entry Date fields are collapsed"

            baseUrl == driver.currentUrl
            decSearchPage.entryDateFilter.isDateFieldsPanelExpanded()
    }

    def "Verify user cannot search where From date is greater than To date"() {
        given: "I have logged in"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I enter a From date which is greater than the To Date"

            decSearchPage.filterFields.entryDateFilterLink.click()
            decSearchPage.entryDateFilter.fromDateField.value(TO_DATE)
            decSearchPage.entryDateFilter.toDateField.value(FROM_DATE)
            decSearchPage.entryDateFilter.applyFiltersButton.click()

        then: "an error will appear and the Apply Filters button should remain disabled"

            decSearchPage.entryDateFilter.infoMessage.text() == "`From date` must precede `To date`"
            decSearchPage.entryDateFilter.applyFiltersButton.module(FormElement).isDisabled()
    }

    //TODO enter dates via picker...required?-
    //TODO Incorrect format date?
    //TODO error handling scenarios
}
