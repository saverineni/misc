package specs.filters

import geb.module.FormElement
import pages.DeclarationSearchPage
import pages.SignInPage
import specs.BaseGebSpec

class DispatchCountryFacetSpec extends BaseGebSpec {

    static final String FACET_HEADER_TEXT = "Select Country of Dispatch"
    static final String COUNTRY_CODE_NL = "NL"
    static final String COUNTRY_CODE_MX = "MX"

    def "Check Country of Dispatch facet can be launched and correct fields are present"() {
        given: "I have logged in"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I click on the Country of Dispatch filter"

            decSearchPage.filterFields.selectDispatchCountryFilter()

        then: "the Country of Dispatch filter should should load and display all relevant controls"

            decSearchPage.facetOverlay.headerText.text() == FACET_HEADER_TEXT
            decSearchPage.facetOverlay.searchBar.isDisplayed()
            decSearchPage.facetOverlay.cancelButton.isDisplayed()
            decSearchPage.facetOverlay.applyFiltersButton.isDisplayed()
            decSearchPage.facetOverlay.applyFiltersButton.module(FormElement).isDisabled()
    }

    def "Verify happy path of applying filter for a single country code"() {
        given: "I login and have launched the Country of Dispatch facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectDispatchCountryFilter()

        when: "I select country code NL and apply the filter"

            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_NL)
            decSearchPage.facetOverlay.applyFiltersButton.click()

        then: "the NL chip is visible outside the facet along with the correct results count"

            decSearchPage.selectedFilterFields.filterLabel.text() == "Country of Dispatch"
            decSearchPage.selectedFilterFields.isChipVisible(COUNTRY_CODE_NL)
            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 100"
    }

    def "Verify happy path of applying filter for multiple country codes"() {
        given: "I login and have launched the Country of Dispatch facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectDispatchCountryFilter()

        when: "I select country codes NL and MX and apply the filter"

            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_NL)
            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_MX)
            decSearchPage.facetOverlay.applyFiltersButton.click()

        then: "the search applied is OR'd with the correct results count displayed along with chips NL and MX visible outside the facet"

            decSearchPage.selectedFilterFields.filterLabel.text() == "Country of Dispatch"
            decSearchPage.selectedFilterFields.isChipVisible(COUNTRY_CODE_NL)
            decSearchPage.selectedFilterFields.isChipVisible(COUNTRY_CODE_MX)
            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 102"
    }

    def "Verify cancelling chip outside the facet updates search results and removes chip from facet"() {
        given: "I have applied filter for NL and MX within the Dispatch Country facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectDispatchCountryFilter()
            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_NL)
            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_MX)
            decSearchPage.facetOverlay.applyFiltersButton.click()

        when: "I remove the NL chip from outside the facet"

            decSearchPage.selectedFilterFields.chipsVisibleCancel.first().click()

        then: "then the search results will be updated"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-2 of 2"

        and: "the Dispatch Country facet will only the MX chip"

            decSearchPage.filterFields.selectDispatchCountryFilter()
            decSearchPage.facetOverlay.chipsVisible.size() == 1
            decSearchPage.facetOverlay.isChipVisible(COUNTRY_CODE_MX)
    }

    def "Verify the Country of Dispatch facet is disabled when there are no country codes available for selection"() {
        given: "I have logged in and search with Entry Date from todays date"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.entryDateFilterLink.click()
            decSearchPage.entryDateFilter.fromTodaysDate()

        when: "I click the Entry Date Apply Filters button"

            decSearchPage.entryDateFilter.applyFiltersButton.click()

        then: "the Country of Dispatch filter link should be disabled"

            decSearchPage.filterFields.isDispatchCountryFilterDisabled()
    }
}
