package specs.filters

import data.UiMessages
import geb.module.FormElement
import pages.DeclarationSearchPage
import pages.SignInPage
import specs.BaseGebSpec

class CommodityCodeFilterSpec extends BaseGebSpec {

    static final String FACET_HEADER_TEXT = "Select Commodity Code"
    static final String COMMODITY_CODE_3009400000 = "3009400000"
    static final String COMMODITY_CODE_3009400001 = "3009400001"
    static final String INVALID_COMMODITY_CODE_3009400000 = "9999999999"

    def "Check Commodity Code facet can be launched and correct fields are present"() {
        given: "I have logged in"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I click on the Commodity Code filter"

            decSearchPage.filterFields.selectCommodityCodeFilter()

        then: "the Commodity Code filter should load and display all relevant controls"

            decSearchPage.facetOverlay.headerText.text() == FACET_HEADER_TEXT
            decSearchPage.facetOverlay.commodityCodeInfoText.text() == UiMessages.commodityCodeFacetDefaultMessage
            decSearchPage.facetOverlay.searchBar.isDisplayed()
            decSearchPage.facetOverlay.cancelButton.isDisplayed()
            decSearchPage.facetOverlay.applyFiltersButton.isDisplayed()
            decSearchPage.facetOverlay.applyFiltersButton.module(FormElement).isDisabled()
    }

    def "Verify happy path of applying filter for a single Commodity code"() {
        given: "I login and launch the Commodity Code facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectCommodityCodeFilter()

        when: "I filter for Commodity Code '3009400000' and select and apply filter"

            decSearchPage.facetOverlay.searchBar.value(COMMODITY_CODE_3009400001)
            decSearchPage.facetOverlay.clickLinkFor(COMMODITY_CODE_3009400001)
            decSearchPage.facetOverlay.applyFiltersButton.click()

        then: "the '3009400000' chip is visible outside the facet along with the correct results count"

            decSearchPage.selectedFilterFields.filterLabel.text() == "Commodity Code"
            decSearchPage.selectedFilterFields.isChipVisible(COMMODITY_CODE_3009400001)
            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-1 of 1"
    }

    def "Verify happy path of applying filter for multiple Commodity codes"() {
        given: "I login and launch the Commodity Code facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectCommodityCodeFilter()

        when: "I filter for partial Commodity Code '3009'"

            def partialCommodityCode = COMMODITY_CODE_3009400000[0..3]
            decSearchPage.facetOverlay.searchBar.value(partialCommodityCode)

        and: "I select all Commodity Codes found and apply filter"

            decSearchPage.facetOverlay.clickLinkFor(COMMODITY_CODE_3009400000)
            decSearchPage.facetOverlay.clickLinkFor(COMMODITY_CODE_3009400001)
            decSearchPage.facetOverlay.applyFiltersButton.click()

        then: "the chips '3009400000' and '3009400001' are visible outside the facet along with the correct results count"

            decSearchPage.selectedFilterFields.filterLabel.text() == "Commodity Code"
            decSearchPage.selectedFilterFields.isChipVisible(COMMODITY_CODE_3009400000)
            decSearchPage.selectedFilterFields.isChipVisible(COMMODITY_CODE_3009400001)
            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-3 of 3"
    }

    def "Verify a Commodity code that exists within multiple lines of the same declaration returns correct declaration count"() {
        given: "I login and launch the Commodity Code facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectCommodityCodeFilter()

        when: "I filter for Commodity Code '3009400000'"

            decSearchPage.facetOverlay.searchBar.value(COMMODITY_CODE_3009400000)

        then: "the '3009400000' chip is visible outside the facet along with the correct results count"

            decSearchPage.facetOverlay.linkTextListVisible.first().text() == COMMODITY_CODE_3009400000 + " (3)"
    }

    def "Ensure typing upto 3 digits for a Commodity Code does not envoke a Commodity Code lookup" () {
        given: "I login and launch the Commodity Code facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectCommodityCodeFilter()

        when: "I filter for partial Commodity Code '300'"

            def partialCommodityCode = COMMODITY_CODE_3009400000[0..2]
            decSearchPage.facetOverlay.searchBar.value(partialCommodityCode)

        then: "the default info message 'Enter at least 4 numbers to bring back results' is displayed within the facet"

            decSearchPage.facetOverlay.commodityCodeInfoText.text() == UiMessages.commodityCodeFacetDefaultMessage
    }

    def "Ensure searching for a full Commodity Code that does not exist displays correct info message" () {
        given: "I login and launch the Commodity Code facet"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectCommodityCodeFilter()

        when: "I filter for Commodity Code '9999999999' that does not exist"

            decSearchPage.facetOverlay.searchBar.value(INVALID_COMMODITY_CODE_3009400000)

        then: "a 'No results found' message is displayed within the facet"

            decSearchPage.facetOverlay.commodityCodeInfoText.text() == UiMessages.commodityCodeFacetNotFoundMessage
    }

    def "Verify cancelling chip outside the facet updates search results and removes chip from facet"() {
        given: "I have filtered for '3009' within the Commodity Code facet and applied the filter"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.filterFields.selectCommodityCodeFilter()
            def partialCommodityCode = COMMODITY_CODE_3009400000[0..3]
            decSearchPage.facetOverlay.searchBar.value(partialCommodityCode)
            decSearchPage.facetOverlay.clickLinkFor(COMMODITY_CODE_3009400000)
            decSearchPage.facetOverlay.clickLinkFor(COMMODITY_CODE_3009400001)
            decSearchPage.facetOverlay.applyFiltersButton.click()

        when: "I remove the '3009400000' chip from outside the facet"

            decSearchPage.selectedFilterFields.chipsVisibleCancel.first().click()

        then: "then the search results will be updated"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-1 of 1"

        and: "the Commodity Code facet will only contain the '3009400001' chip"

            decSearchPage.filterFields.selectCommodityCodeFilter()
            decSearchPage.facetOverlay.chipsVisible.size() == 1
            decSearchPage.facetOverlay.isChipVisible(COMMODITY_CODE_3009400001)
    }

}
