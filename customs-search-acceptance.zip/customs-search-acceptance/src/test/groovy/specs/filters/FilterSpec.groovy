package specs.filters

import pages.DeclarationSearchPage
import pages.SignInPage
import specs.BaseGebSpec

class FilterSpec extends BaseGebSpec {

    def "Check Entry Date filter link exists"() {
        when: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        then: "the Entry Date filter link should be visible"

            decSearchPage.filterFields.entryDateFilterLink.isDisplayed()
            decSearchPage.filterFields.entryDateFilterLink.text() == "Entry Date"
    }

    def "Check Clearance Date filter link exists"() {
        when: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        then: "the Clearance Date filter link should be visible"

            decSearchPage.filterFields.clearanceDateFilterLink.isDisplayed()
            decSearchPage.filterFields.clearanceDateFilterLink.text() == "Clearance Date"
    }

    def "Check Country of Origin facet link exists"() {
        when: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        then: "the Country of Origin facet link should be visible"

            decSearchPage.filterFields.originCountryFilterLink.isDisplayed()
            decSearchPage.filterFields.originCountryFilterLink.text() == "Country of Origin"
    }

    def "Check Country of Dispatch facet link exists"() {
        when: "I have logged in successfully and I am on the Declaration Search page"

        def signinPage = to SignInPage
        DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        then: "the Country of Origin facet link should be visible"

        decSearchPage.filterFields.dispatchCountryFilterLink.isDisplayed()
        decSearchPage.filterFields.dispatchCountryFilterLink.text() == "Country of Dispatch"
    }

    def "Check Country of Destination facet link exists"() {
        when: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        then: "the Country of Destination facet link should be visible"

            decSearchPage.filterFields.destinationCountryFilterLink.isDisplayed()
            decSearchPage.filterFields.destinationCountryFilterLink.text() == "Country of Destination"
    }

    def "Check Mode Of Transport facet link exists"() {
        when: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        then: "the Country of Destination facet link should be visible"

            decSearchPage.filterFields.modeofTransportFilterLink.isDisplayed()
            decSearchPage.filterFields.modeofTransportFilterLink.text() == "Mode of Transport"
    }

    def "Check Goods Location facet link exists"() {
        when: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        then: "the Goods Location facet link should be visible"

            decSearchPage.filterFields.goodsLocationFilterLink.isDisplayed()
            decSearchPage.filterFields.goodsLocationFilterLink.text() == "Goods Location"
    }

    def "Ensure facets are disabled when no results are found"() {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I do a free text search which returns no results"

            decSearchPage.searchFields.searchFor("garbage")

        then: "then all facets should be disabled"

            decSearchPage.filterFields.entryDateFilterLink.isDisplayed()
            decSearchPage.filterFields.isOriginCountryFilterDisabled()
            decSearchPage.filterFields.isDispatchCountryFilterDisabled()
            decSearchPage.filterFields.isDestinationCountryFilterDisabled()
            decSearchPage.filterFields.isModeOfTransportFilterDisabled()
            decSearchPage.filterFields.isGoodsLocationFilterDisabled()
    }

    //TODO should Entry Date disable if no results are found?
}
