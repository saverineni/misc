package specs.filters

import geb.module.FormElement
import pages.DeclarationSearchPage
import pages.SignInPage
import specs.BaseGebSpec
import spock.lang.Shared

class ClearanceDateFilterSpec extends BaseGebSpec {

    private static final String SEARCH_TERM = "726"
    private static final String FROM_DATE = "01/06/2016"
    private static final String TO_DATE = "01/12/2016"
    @Shared String resultsCount

    def "Check all Entry Date fields are visible"() {
        given: "I have logged in"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I click on the Entry Date link"

            decSearchPage.filterFields.clearanceDateFilterLink.click()

        then: "all the Entry Date filter fields will be visible and Apply Filters button is disabled by default"

            decSearchPage.clearanceDateFilter.fromDateField.isDisplayed()
            decSearchPage.clearanceDateFilter.toDateField.isDisplayed()
            decSearchPage.clearanceDateFilter.clearButton.isDisplayed()
            decSearchPage.clearanceDateFilter.applyFiltersButton.isDisplayed()
            decSearchPage.clearanceDateFilter.applyFiltersButton.module(FormElement).isDisabled()
    }

    def "Verify user can enter dates directly into Clearance Date fields with slashes and apply a search"() {
        given: "I have logged in"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I enter a From and To Clearance Date and apply the filter"

            decSearchPage.filterFields.clearanceDateFilterLink.click()
            decSearchPage.clearanceDateFilter.fromDateField.value(FROM_DATE)
            decSearchPage.clearanceDateFilter.toDateField.value(TO_DATE)
            decSearchPage.clearanceDateFilter.applyFiltersButton.click()

        then: "correct number of results will be shown"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 38"
    }

    def "Verify user can enter dates directly into Clearance Date fields with dashes and apply a search"() {
        given: "I have logged in"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I enter a From and To Clearance Date and apply the filter"

            decSearchPage.filterFields.clearanceDateFilterLink.click()
            decSearchPage.clearanceDateFilter.fromDateField.value(FROM_DATE.replace("/", "-"))
            decSearchPage.clearanceDateFilter.toDateField.value(TO_DATE.replace("/", "-"))
            decSearchPage.clearanceDateFilter.applyFiltersButton.click()

        then: "correct number of results will be shown"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 38"
    }

    def "Verify Clear button clears and resets the search made"() {
        given: "I have searched for declarations via a valid search with Entry Dates"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.searchFields.searchFor(SEARCH_TERM)
            resultsCount = decSearchPage.searchFields.recordsFoundMessage.text()
            decSearchPage.filterFields.clearanceDateFilterLink.click()
            decSearchPage.clearanceDateFilter.fromDateField.value(FROM_DATE)
            decSearchPage.clearanceDateFilter.toDateField.value(TO_DATE)
            decSearchPage.clearanceDateFilter.applyFiltersButton.click()

        when: "I click the Clear button within the Entry Dates filter section"

            decSearchPage.clearanceDateFilter.clearButton.click()

        then: "both date fields will be cleared and search results are reset with correct results shown"

            decSearchPage.clearanceDateFilter.fromDateField.text() == ""
            decSearchPage.clearanceDateFilter.fromDateField.text() == ""
            decSearchPage.searchFields.recordsFoundMessage.text() == resultsCount
    }

    def "Verify the Customs Declaration Search nav bar link clears the current search completely"() {
        given: "I have searched for declarations via a valid search with Entry Dates"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.searchFields.searchFor(SEARCH_TERM)
            resultsCount = decSearchPage.searchFields.recordsFoundMessage.text()
            decSearchPage.filterFields.clearanceDateFilterLink.click()
            decSearchPage.clearanceDateFilter.fromDateField.value(FROM_DATE)
            decSearchPage.clearanceDateFilter.toDateField.value(TO_DATE)
            decSearchPage.clearanceDateFilter.applyFiltersButton.click()

        when: "I click the Customs Declaration Search nav bar link"

            decSearchPage.navFields.customsSearchLink.click()

        then: "the user is navigated back to home where previous search is completely cleared and Entry Date fields are collapsed"

            baseUrl == driver.currentUrl
            decSearchPage.clearanceDateFilter.isDateFieldsPanelExpanded()
    }

    def "Verify user cannot search where From date is greater than To date"() {
        given: "I have logged in"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I enter a From date which is greater than the To Date"

            decSearchPage.filterFields.clearanceDateFilterLink.click()
            decSearchPage.clearanceDateFilter.fromDateField.value(TO_DATE)
            decSearchPage.clearanceDateFilter.toDateField.value(FROM_DATE)
            decSearchPage.clearanceDateFilter.applyFiltersButton.click()

        then: "an error will appear and the Apply Filters button should remain disabled"

            decSearchPage.clearanceDateFilter.infoMessage.text() == "`From date` must precede `To date`"
            decSearchPage.clearanceDateFilter.applyFiltersButton.module(FormElement).isDisabled()
    }
}
