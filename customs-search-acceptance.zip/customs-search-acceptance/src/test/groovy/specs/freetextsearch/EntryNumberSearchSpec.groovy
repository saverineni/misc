package specs.freetextsearch

import data.UiMessages
import pages.SignInPage
import specs.BaseGebSpec
import spock.lang.Shared

class EntryNumberSearchSpec extends BaseGebSpec {

    private static final String ENTRY_NUMBER = "IM001A"
    private static final String CASE_INSENSITIVE_ENTRY_NUMBER = "iM001a"

    def "Search for a valid Entry Number that exists within multiple declarations" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Entry Number 'IM001A'"

            decSearchPage.searchFields.searchFor(ENTRY_NUMBER)

        then: "seven declarations are found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-7 of 7"

        and: "all results on the page contain 'IM001A' in the header"

            decSearchPage.resultFields.checkResultsForEntryNumber(ENTRY_NUMBER)
            decSearchPage.resultFields.noOfResultsForEntryNumber() > 1
    }

    def "Search for a partial Entry Number" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I search for a partial Entry Number 'IM001'"

            def partialEntryNumber = ENTRY_NUMBER[0..4]
            decSearchPage.searchFields.searchFor(partialEntryNumber)

        then: "then no results should be returned"

            decSearchPage.searchFields.recordsFoundMessage.text() == UiMessages.noResultsFound
    }

    def "Search for concatenated Entry Numbers" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I search for concatenated Entry Numbers 'IM001A IM001A'"

            def concatEntryNumber = ENTRY_NUMBER + " " + ENTRY_NUMBER
            decSearchPage.searchFields.searchFor(concatEntryNumber)

        then: "then no results should be returned"

            decSearchPage.searchFields.recordsFoundMessage.text() == UiMessages.noResultsFound
    }

    def "Verify a case insensitive typed Entry Number returns correct declarations" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Entry Number 'iM001a'"

            decSearchPage.searchFields.searchFor(CASE_INSENSITIVE_ENTRY_NUMBER)

        then: "multiple results are returned all with the same Entry Number in the header"

            decSearchPage.resultFields.checkResultsForEntryNumber(ENTRY_NUMBER)
            decSearchPage.resultFields.noOfResultsForEntryNumber() > 1
    }

}
