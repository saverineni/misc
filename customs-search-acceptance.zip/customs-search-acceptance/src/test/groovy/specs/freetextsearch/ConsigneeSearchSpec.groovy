package specs.freetextsearch

import pages.SignInPage
import specs.BaseGebSpec
import spock.lang.Shared

class ConsigneeSearchSpec extends BaseGebSpec {

    @Shared lineConsigneeResults = "110098765321\nItem Consignee Name\nOL16 2JU"
    private static final String HEADER_CONSIGNEE_NO = "110098765123"
    private static final String HEADER_CONSIGNEE_NAME = "Consignee Name"
    @Shared camelCaseHeaderConsigneeName = "CoNsIgNeE NaMe"
    private static final String HEADER_CONSIGNEE_POSTCODE = "RM10 9IM"
    private static final String LINE_CONSIGNEE_NO = "110098765321"
    private static final String LINE_CONSIGNEE_NAME = "Item Consignee Name"
    @Shared camelCaseLineConsigneeName = "item consignee NAme"
    private static final String LINE_CONSIGNEE_POSTCODE = "OL16 2JU"

    def "Search for a valid Consignee No that exists within the header of a single declaration" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Consignee No '110098765123'"

            decSearchPage.searchFields.searchFor(HEADER_CONSIGNEE_NO)

        then: "six declarations are found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-6 of 6"

        and: "the declaration details page contains Consignee No 110098765123 at header level"

        //TODO once DeclarationDetailsPage selectors are ready
        //decSearchPage.resultFields.consigneeNoHeaderCell.text() == HEADER_CONSIGNEE_NO
    }

    def "Search for a valid Consignee Name that exists within the header of a single declaration" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Consignee Name 'Consignee Name'"

            decSearchPage.searchFields.searchFor(HEADER_CONSIGNEE_NAME)

        then: "six declarations are found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-6 of 6"

        and: "the Consignee Name appears at the header level"

        //TODO once DeclarationDetailsPage selectors are ready
        //decSearchPage.resultFields.consigneeNameHeaderCell.text() == HEADER_CONSIGNEE_NAME
    }

    def "Search for a valid Consignee Postcode that exists within the header of a single declaration" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Consignee Postcode 'RM10 9IM'"

            decSearchPage.searchFields.searchFor(HEADER_CONSIGNEE_POSTCODE)

        then: "six declarations are found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-6 of 6"

        and: "the Consignee Postcode appears at the header level"

        //TODO once DeclarationDetailsPage selectors are ready
        //decSearchPage.resultFields.consigneePostcodeHeaderCell.text() == HEADER_CONSIGNEE_POSTCODE
    }

    def "Search for a valid Consignee No that exists within the line of a single declaration" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Consignee No '110098765321'"

            decSearchPage.searchFields.searchFor(LINE_CONSIGNEE_NO)

        then: "one declaration is found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-1 of 1"

        and: "the Consignee No appears at the line level"
            //TODO once DeclarationDetailsPage selectors are ready
            //decSearchPage.resultFields.expandFirstDeclaration()
            //decSearchPage.resultFields.consigneeLineCells.text() == lineConsigneeResults
    }

    def "Search for a valid Consignee Name that exists within the line of a single declaration" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Consignee Name 'Item Consignee Name'"

            decSearchPage.searchFields.searchFor(LINE_CONSIGNEE_NAME)

        then: "one declaration is found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-1 of 1"

        and: "the Consignee Name appears at the line level"
            //TODO once DeclarationDetailsPage selectors are ready
            //decSearchPage.resultFields.expandFirstDeclaration()
            //decSearchPage.resultFields.consigneeLineCells.text() == lineConsigneeResults
    }

    def "Search for a valid Consignee Postcode that exists within the line of a single declaration" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Consignee Postcode 'OL16 2JU'"

            decSearchPage.searchFields.searchFor(LINE_CONSIGNEE_POSTCODE)

        then: "one declaration is found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-1 of 1"

        and: "the Consignee Postcode appears at the line level"
            //TODO once DeclarationDetailsPage selectors are ready
            //decSearchPage.resultFields.expandFirstDeclaration()
            //decSearchPage.resultFields.consigneeLineCells.text() == lineConsigneeResults
    }

    //TODO once above tests are fixed
//    def "Search for a valid Consignee Name that exists within the header typed with nixture of any case of letters of a single declaration" () {
//        given: "I have logged in successfully and I am on the Declaration Search page"
//
//        def signinPage = to SignInPage
//        def decSearchPage = signinPage.signInFields.signInAsSuperUser()
//
//        when: "I search for a valid Consignee Name that exists"
//
//        decSearchPage.searchFields.searchFor(camelCaseHeaderConsigneeName)
//
//        then: "the Consignee Name appears at the header level"
//
//        decSearchPage.resultFields.consigneeNameHeaderCell.text() == HEADER_CONSIGNEE_NAME
//    }
//
//    def "Search for a valid Consignee Name that exists within the line and typed with any case of letters of a single declaration" () {
//        given: "I have logged in successfully and I am on the Declaration Search page"
//
//        def signinPage = to SignInPage
//        def decSearchPage = signinPage.signInFields.signInAsSuperUser()
//
//        when: "I search for a valid Consignee Name that exists"
//
//        decSearchPage.searchFields.searchFor(camelCaseLineConsigneeName)
//
//        then: "the Consignee Name appears at the line level"
//
//        decSearchPage.resultFields.expandFirstDeclaration()
//        decSearchPage.resultFields.consigneeLineCells.text() == lineConsigneeResults
//    }
}
