package specs.freetextsearch

import data.UiMessages
import pages.SignInPage
import specs.BaseGebSpec
import spock.lang.Shared

class CpcSearchSpec extends BaseGebSpec {

    private static final String CPC = "0611786"

    def "Search for a valid Customs Procedure Code that exists within multiple declarations" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Customs Procedure Code '0611786'"

            decSearchPage.searchFields.searchFor(CPC)

        then: "two declarations are found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-2 of 2"

        and: "multiple results are returned that contain the Customs Procedure Code at line level"

            decSearchPage.resultFields.selectFirstDeclarationDetailsLink()
            //TODO once DeclarationDetailsPage selectors are ready
            //decSearchPage.resultFields.expandAllDeclarations()
            //decSearchPage.resultFields.allCpcLineCells.first().text() == CPC
            //decSearchPage.resultFields.checkResultsForCPC(CPC)
            //decSearchPage.resultFields.noOfResultsForCPC() > 1
    }

    def "Search for a partial Customs Procedure Code" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I search for partial Customs Procedure Code '06117'"

            def partialCpc = CPC[0..5]
            decSearchPage.searchFields.searchFor(partialCpc)

        then: "then no results should be returned"

            decSearchPage.searchFields.recordsFoundMessage.text() == UiMessages.noResultsFound
    }

    def "Search for concatenated Customs Procedure Codes" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I search for concatenated Customs Procedure Codes '0611786 0611786'"

            def concatCpc = CPC + " " + CPC
            decSearchPage.searchFields.searchFor(concatCpc)

        then: "then no results should be returned"

            decSearchPage.searchFields.recordsFoundMessage.text() == UiMessages.noResultsFound
    }
}
