package specs.freetextsearch

import data.UiMessages
import pages.SignInPage
import specs.BaseGebSpec

class CommoditySearchSpec extends BaseGebSpec {

    private final static String COMMODITY_CODE = "8542199999"

    def "Search for a valid Commodity Code that exists within multiple declarations" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Commodity Code '8542199999'"

            decSearchPage.searchFields.searchFor(COMMODITY_CODE)

        then: "two declarations are found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-2 of 2"

        and: "the declaration details page contains commodity code 8542199999 at line level"

            decSearchPage.resultFields.selectFirstDeclarationDetailsLink()
        //TODO once DeclarationDetailsPage selectors are ready
//            decSearchPage.resultFields.expandAllDeclarations()
//            decSearchPage.resultFields.allCommodityCodeLineCells.first().text() == COMMODITY_CODE
//            decSearchPage.resultFields.checkResultsForCommodityCode(COMMODITY_CODE)
//            decSearchPage.resultFields.noOfResultsForCommodityCode() > 1
    }

    def "Search for a partial Commodity Code" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I search for a partial Commodity Code '8542'"

            def partialCommodityCode = COMMODITY_CODE[0..4]
            decSearchPage.searchFields.searchFor(partialCommodityCode)

        then: "then no results should be returned"

            decSearchPage.searchFields.recordsFoundMessage.text() == UiMessages.noResultsFound
    }

    def "Search for concatenated Commodity Codes" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I search for concatenated Commodity Codes '8542199999 8542199999'"

            def concatCommodityCode = COMMODITY_CODE + " " + COMMODITY_CODE
            decSearchPage.searchFields.searchFor(concatCommodityCode)

        then: "then no results should be returned"

            decSearchPage.searchFields.recordsFoundMessage.text() == UiMessages.noResultsFound
    }
}
