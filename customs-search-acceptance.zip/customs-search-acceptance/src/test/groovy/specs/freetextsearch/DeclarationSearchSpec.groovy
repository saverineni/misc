package specs.freetextsearch

import data.UiMessages
import pages.DeclarationSearchPage
import pages.SignInPage
import specs.BaseGebSpec
import spock.lang.Shared

class DeclarationSearchSpec extends BaseGebSpec {

    //TODO commented out till we clarify what the search results card needs to display
    //@Shared headerColumnNames = "[Declaration ID, EPU, Entry Number, Entry Date, Route of Entry, Country of Dispatch, Country of Destination, Consignee Number, Consignee Name, Consignee Postcode, Consignor Number, Consignor Name, Consignor Postcode, Goods Location, Mode of Transport]"
    //@Shared headerResults = "[100000000000000007786, 786, IM001A, 2017-12-01 13:30:19.85, 1, PK, GB, 110098765123, Consignee Name, RM10 9IM, , , , DOV, 2]"
    @Shared headerColumnNames = "[Declaration ID, EPU, Entry Number, Entry Date, Route of Entry, Country of Dispatch, Country of Destination, Goods Location, Mode of Transport]"
    @Shared headerResults = "[100000000000000007786, 786, IM001A, 2017-12-01 13:30:19.85, 1, PK, GB, DOV, 2]"
    //TODO need to move test to details page
    //@Shared lineColumnNames = "Item Number\nRoute of Entry\nCountry of Dispatch\nCountry of Destination\nClearance Date\nCPC\nCountry of Origin\nCommodity Code\nConsignee\nConsignor"
    //@Shared lineResults = "1\n3\nPK\nGB\n2017-12-10 08:10:49.33\n0611786\nZD\n020230\n110098765321\nItem Consignee Name\nOL16 2JU"
    private static final String DECLARATION_ID = "100000000000000007786"
    private static final String INVALID_DECLARATION_ID = "999990000000000099999"
    private static final String SEARCH_TERM_PARAM = "?searchTerm="

    def "Happy path - Check header is correct for valid Declaration ID"() {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Declaration ID '100000000000000007786'"

            decSearchPage.searchFields.searchFor(DECLARATION_ID)

        then: "the correct column headings, data and links are displayed within the card"

            decSearchPage.resultFields.firstCardDeclarationDetailsLink.text() == "DECLARATION DETAILS"
            decSearchPage.resultFields.allFirstCardHeaderLabels*.text().toString() == headerColumnNames
            decSearchPage.resultFields.allFirstCardHeaderResults*.text().toString() == headerResults
    }

    //TODO need to move test to details page
//    def "Check the line is correct for a valid Declaration ID"() {
//        given: "I have logged in successfully and I am on the Declaration Search page"
//
//            def signinPage = to SignInPage
//            def decSearchPage = signinPage.signInFields.signInAsSuperUser()
//
//        when: "I search for a valid Declaration ID that exists"
//
//            decSearchPage.searchFields.searchFor(DECLARATION_ID)
//
//        then: "the correct line column headings and information is displayed"
//
//            decSearchPage.resultFields.expandFirstDeclaration()
//            decSearchPage.lineResultFields.lineColumnHeadings.text() == lineColumnNames
//            decSearchPage.lineResultFields.lineColumnResults.text() == lineResults
//    }

    def "Customs Declaration Search nav bar link resets search and returns user to Home"() {
        given: "I have logged in successfully and searched for a valid declaration"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.searchFields.searchFor(DECLARATION_ID)

        when: "I click the Customs Declaration Search nav bar link"

            decSearchPage.navFields.customsSearchLink.click()

        then: "I am returned back to Home with the previous search cleared"

            currentUrl == baseUrl
            decSearchPage.searchFields.declarationIDField.text().isEmpty()
            decSearchPage.searchFields.declarationIDField.isFocused()
    }

    def "Check results are returned without entering a search term"() {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I do not enter a search term and click the Search button"

            decSearchPage.searchFields.searchFor("")

        then: "random declarations are returned and an empty freeText parameter is used in URL"

            decSearchPage.searchFields.recordsFoundMessage.text().contains("Showing 1-8 of")
            currentUrl == baseUrl + SEARCH_TERM_PARAM
    }

    def "Search for a Declaration ID that does not exist"() {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Declaration ID '999990000000000099999' that does NOT exists"

            decSearchPage.searchFields.searchFor(INVALID_DECLARATION_ID)

        then: "an error will appear on screen"

            decSearchPage.searchFields.recordsFoundMessage.text() == UiMessages.noResultsFound
    }

    def "Ensure Search button is enabled by default"() {
        when: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        then: "the search button is enabled by default"

            decSearchPage.searchFields.isSearchButtonEnabled()
    }

    //TODO logout
}
