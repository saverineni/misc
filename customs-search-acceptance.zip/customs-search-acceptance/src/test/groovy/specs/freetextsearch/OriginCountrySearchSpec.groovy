package specs.freetextsearch

import data.UiMessages
import pages.SignInPage
import specs.BaseGebSpec
import spock.lang.Shared

class OriginCountrySearchSpec extends BaseGebSpec {

    private static final String ORIGIN_COUNTRY_CODE = "ZD"

    def "Search for a valid Origin Country Code that exists within multiple declarations"() {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Origin Country Code 'ZD'"

            decSearchPage.searchFields.searchFor(ORIGIN_COUNTRY_CODE)

        then: "six declarations are found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-6 of 6"

        and: "multiple results are returned that contain the Origin Country Code at line level"

            decSearchPage.resultFields.selectFirstDeclarationDetailsLink()
            //TODO once DeclarationDetailsPage selectors are ready
            //decSearchPage.resultFields.expandFirstDeclaration()
            //decSearchPage.resultFields.allOriginCountryCodeLineCells.first().text() == ORIGIN_COUNTRY_CODE
            //decSearchPage.resultFields.checkResultsForOriginCountryCode(ORIGIN_COUNTRY_CODE)
            //decSearchPage.resultFields.noOfResultsForOriginCountryCode() > 1
    }

    def "Ensure all results returned for a valid Origin Country Code that exists but in lower case"() {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Origin Country Code 'zd' in lower case"

            decSearchPage.searchFields.searchFor(ORIGIN_COUNTRY_CODE.toLowerCase())

        then: "six declarations are found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-6 of 6"
    }

    def "Search for a partial Origin Country Code"() {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I search for a partial Origin Country Code 'N'"

            def partialOriginCountryCode = ORIGIN_COUNTRY_CODE[0..0]
            decSearchPage.searchFields.searchFor(partialOriginCountryCode)

        then: "then no results should be returned"

            decSearchPage.searchFields.recordsFoundMessage.text() == UiMessages.noResultsFound
    }

    def "Search for concatenated Origin Country Codes"() {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I search for a concatenated Origin Country Codes 'NL NL'"

            def concatOriginCountryCode = ORIGIN_COUNTRY_CODE + " " + ORIGIN_COUNTRY_CODE
            decSearchPage.searchFields.searchFor(concatOriginCountryCode)

        then: "then no results should be returned"

            decSearchPage.searchFields.recordsFoundMessage.text() == UiMessages.noResultsFound
    }
}