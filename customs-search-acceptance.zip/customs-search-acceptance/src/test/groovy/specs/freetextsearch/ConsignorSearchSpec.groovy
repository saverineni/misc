package specs.freetextsearch

import pages.SignInPage
import specs.BaseGebSpec
import spock.lang.Shared

class ConsignorSearchSpec extends BaseGebSpec {

    @Shared lineConsignorResults = "210098765321\nItem Consignor Name\nM6 5RY"
    private static final String HEADER_CONSIGNOR_NO = "210098765123"
    private static final String HEADER_CONSIGNOR_NAME = "Consignor Name"
    private static final String HEADER_CONSIGNOR_POSTCODE = "RM10 9EX"
    @Shared ignorecaseheaderConsignorPostcode = "rM10 9Ex"
    private static final String LINE_CONSIGNOR_NO = "210098765321"
    private static final String LINE_CONSIGNOR_NAME = "Item Consignor Name"
    @Shared ignorecaselineConsignorName = "iTeM CoNsIgNoR nAmE"
    private static final String LINE_CONSIGNOR_POSTCODE = "M6 5RY"

    def "Search for a valid Consignor No that exists within the header of a single declaration" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Consignor No '210098765123'"

            decSearchPage.searchFields.searchFor(HEADER_CONSIGNOR_NO)

        then: "one declaration is found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-1 of 1"

        and: "the Consignee No appears at the header level"

        //TODO once DeclarationDetailsPage selectors are ready
        //decSearchPage.resultFields.consignorNoHeaderCell.text() == HEADER_CONSIGNOR_NO
    }

    def "Search for a valid Consignor Name that exists within the header of a single declaration" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Consignor Name 'Consignor Name'"

            decSearchPage.searchFields.searchFor(HEADER_CONSIGNOR_NAME)

        then: "one declaration is found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-1 of 1"

        then: "the Consignee Name appears at the header level"

            //TODO once DeclarationDetailsPage selectors are ready
            //decSearchPage.resultFields.consignorNameHeaderCell.text() == HEADER_CONSIGNOR_NAME
    }

    def "Search for a valid Consignor Postcode that exists within the header of a single declaration" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Consignor Postcode 'RM10 9EX'"

            decSearchPage.searchFields.searchFor(HEADER_CONSIGNOR_POSTCODE)

        then: "one declaration is found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-1 of 1"

        and: "the Consignee Name appears at the header level"
            //TODO once DeclarationDetailsPage selectors are ready
            //decSearchPage.resultFields.consignorPostcodeHeaderCell.text() == HEADER_CONSIGNOR_POSTCODE
    }

    def "Search for a valid Consignor No that exists within the line of a single declaration" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Consignor No '210098765321'"

            decSearchPage.searchFields.searchFor(LINE_CONSIGNOR_NO)

        then: "one declaration is found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-1 of 1"

        then: "the Consignee No appears at the line level"
            //TODO once DeclarationDetailsPage selectors are ready
            //decSearchPage.resultFields.expandFirstDeclaration()
            //decSearchPage.resultFields.consignorLineCells.text() == lineConsignorResults
    }

    def "Search for a valid Consignor Name that exists within the line of a single declaration" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Consignor Name 'Item Consignor Name'"

            decSearchPage.searchFields.searchFor(LINE_CONSIGNOR_NAME)

        then: "one declaration is found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-1 of 1"

        and: "the Consignee No appears at the line level"

            //TODO once DeclarationDetailsPage selectors are ready
            //decSearchPage.resultFields.expandFirstDeclaration()
            //decSearchPage.resultFields.consignorLineCells.text() == lineConsignorResults
    }

    def "Search for a valid Consignor Postcode that exists within the line of a single declaration" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for Consignor Postcode 'M6 5RY'"

            decSearchPage.searchFields.searchFor(LINE_CONSIGNOR_POSTCODE)

        then: "one declaration is found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-1 of 1"

        and: "the Consignee No appears at the line level"
            //TODO once DeclarationDetailsPage selectors are ready
            //decSearchPage.resultFields.expandFirstDeclaration()
            //decSearchPage.resultFields.consignorLineCells.text() == lineConsignorResults
    }

    //TODO once above tests are fixed
//    def "Search for a valid Consignor Postcode that exists within the header and typed in mixture of any cases of a single declaration" () {
//        given: "I have logged in successfully and I am on the Declaration Search page"
//
//        def signinPage = to SignInPage
//        def decSearchPage = signinPage.signInFields.signInAsSuperUser()
//
//        when: "I search for a valid Consignor Postcode that exists"
//
//        decSearchPage.searchFields.searchFor(ignorecaseheaderConsignorPostcode)
//
//        then: "the Consignee Name appears at the header level"
//
//        decSearchPage.resultFields.consignorPostcodeHeaderCell.text() == HEADER_CONSIGNOR_POSTCODE
//    }
//
//    def "Search for a valid Consignor Name that exists within the line typed with a mixture of cases of a single declaration" () {
//        given: "I have logged in successfully and I am on the Declaration Search page"
//
//        def signinPage = to SignInPage
//        def decSearchPage = signinPage.signInFields.signInAsSuperUser()
//
//        when: "I search for a valid Consignor Name that exists"
//
//        decSearchPage.searchFields.searchFor(ignorecaselineConsignorName)
//
//        then: "the Consignee No appears at the line level"
//
//        decSearchPage.resultFields.expandFirstDeclaration()
//        decSearchPage.resultFields.consignorLineCells.text() == lineConsignorResults
//    }



}