package specs.freetextsearch

import pages.DeclarationSearchPage
import pages.SignInPage
import specs.BaseGebSpec
import spock.lang.Shared

class BookmarksSpec extends BaseGebSpec {

    @Shared searchTermParam = "?searchTerm="
    @Shared consigneePostcodeWithSpecialChars = "<RM10> 9'M/"
    @Shared consigneePostcodeEncodedSpecialChars = "%3CRM10%3E%209%27M%2F"
    @Shared consigneePostcodeNonEncoded = "RM109TT"
    @Shared consigneeNameWithSpecialChars = ";/:@&?=<>#%{}|^~[]"
    @Shared consigneeNameEncodedSpecialChars = "%3B%2F%3A%40%26%3F%3D%3C%3E%23%25%7B%7D%7C%5E~%5B%5D"
    @Shared consigneeNameNonEncoded = "Dennis"

    def "Search for a Consignee Postcode at Header level that contains special characters"() {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I perform a free text search for Consignee Postcode with special characters in the header of a declaration"

            decSearchPage.searchFields.searchFor(consigneePostcodeWithSpecialChars)

        then: "a declaration will be found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-1 of 1"
    }

    def "Simulate use of a bookmark by navigating to an encoded URL related to Header level search"() {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.searchFields.isSearchButtonEnabled()

        when: "I navigate to URL where the Consignee Postcode is encoded at Header level"

            go(baseUrl + searchTermParam + consigneePostcodeEncodedSpecialChars)

        then: "a declaration will be found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-1 of 1"
    }

    def "Simulate use of a bookmark by navigating to a non-encoded URL related to Header level search"() {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.searchFields.isSearchButtonEnabled()

        when: "I navigate to URL where the Consignee Name is not encoded at Header level"

            go(baseUrl + searchTermParam + consigneeNameNonEncoded)

        then: "a declaration will be found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-1 of 1"
    }

    def "Search for a Consignee Name at Line level that contains special characters"() {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I perform a free text search for Consignee Name with special characters in the header of a declaration"

            decSearchPage.searchFields.searchFor(consigneeNameWithSpecialChars)

        then: "a declaration will be found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-1 of 1"
    }

    def "Simulate use of a bookmark by navigating to an encoded URL related to Line level search"() {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.searchFields.isSearchButtonEnabled()

        when: "I navigate to URL where the Consignee Name is encoded at Line level"

            go(baseUrl + searchTermParam + consigneeNameEncodedSpecialChars)
            decSearchPage.resultFields.expandFirstDeclaration()

        then: "a declaration will be found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-1 of 1"
    }

    def "Simulate use of a bookmark by navigating to a non-encoded URL related to Line level search"() {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()
            decSearchPage.searchFields.isSearchButtonEnabled()

        when: "I navigate to URL where the Consignee Postcode is encoded at Line level"

            go(baseUrl + searchTermParam + consigneePostcodeNonEncoded)

        then: "a declaration will be found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-1 of 1"
    }

    def "When signed out attempt to navigate to a bookmarked URL"() {
        given: "I am on the Sign in page and I navigate to a bookmarked URL when not signed in"

            def signinPage = to SignInPage
            go(baseUrl + searchTermParam + consigneePostcodeEncodedSpecialChars)

        when: "I sign in successfully"

            DeclarationSearchPage decSearchPage = signinPage.signInFields.signInAsSuperUser()

        then: "the original bookmarked search is executed and results displayed on screen"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-1 of 1"

    }

    //TODO urls with porameters which show chips
}
