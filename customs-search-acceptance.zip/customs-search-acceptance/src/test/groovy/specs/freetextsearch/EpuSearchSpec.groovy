package specs.freetextsearch

import data.UiMessages
import pages.SignInPage
import specs.BaseGebSpec
import spock.lang.Shared


class EpuSearchSpec extends BaseGebSpec {

    private static final String EPU = "786"

    def "Search for a valid EPU that exists within multiple declarations" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I free text search for EPU '786'"

            decSearchPage.searchFields.searchFor(EPU)

        then: "seven declarations are found"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-7 of 7"

        and: "all results on the page contain '786' in the header"

            decSearchPage.resultFields.checkResultsForEPU(EPU)
            decSearchPage.resultFields.noOfResultsForEpu() > 1
    }

    def "Search for a partial EPU" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I search for a partial EPU '78'"

            def partialEpu = EPU[0..1]
            decSearchPage.searchFields.searchFor(partialEpu)

        then: "then no results should be returned"

            decSearchPage.searchFields.recordsFoundMessage.text() == UiMessages.noResultsFound

    }

    def "Search for concatenated EPUs" () {
        given: "I have logged in successfully and I am on the Declaration Search page"

            def signinPage = to SignInPage
            def decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I search for concatenated EPUs '786 786'"

            def concatEpu = EPU + " " + EPU
            decSearchPage.searchFields.searchFor(concatEpu)

        then: "then no results should be returned"

            decSearchPage.searchFields.recordsFoundMessage.text() == UiMessages.noResultsFound
    }

}
