package specs

import pages.DeclarationSearchPage
import pages.SignInPage
import specs.BaseGebSpec
import spock.lang.Shared
import spock.lang.Stepwise

@Stepwise
class SmokeTestSpec extends BaseGebSpec {

    @Shared DeclarationSearchPage decSearchPage
    private static final String ENTRY_DATE_FROM = "1-1-17"
    private static final String ENTRY_DATE_TO = "1-3-17"
    private static final String CLEARANCE_DATE_FROM = "1-4-17"
    private static final String CLEARANCE_DATE_TO = "31-12-17"
    private static final String COUNTRY_CODE_NL = "NL"
    private static final String COUNTRY_CODE_GR = "GR"
    private static final String COUNTRY_CODE_PL = "PL"
    private static final String COUNTRY_CODE_GB = "GB"
    private static final String COUNTRY_CODE_IE = "IE"
    private static final String COUNTRY_CODE_LB = "LB"
    private static final String MODE_OF_TRANSPORT_CODE_0 = "0"
    private static final String MODE_OF_TRANSPORT_CODE_3 = "3"
    private static final String MODE_OF_TRANSPORT_CODE_5 = "5"
    private static final String MODE_OF_TRANSPORT_CODE_7 = "7"
    private static final String GOODS_LOCATION_CODE_UNKNOWN = "Unknown"
    private static final String GOODS_LOCATION_CODE_EXE = "EXE"

    def "Sign in and search for declarations using Entry Date filter"() {
        given: "I am logged in to Search"

            def signinPage = to SignInPage
            decSearchPage = signinPage.signInFields.signInAsSuperUser()

        when: "I apply the Entry Date Filter for date range 1-1-17 to 1-3-17"

            decSearchPage.filterFields.entryDateFilterLink.click()
            decSearchPage.entryDateFilter.fromDateField.value(ENTRY_DATE_FROM)
            decSearchPage.entryDateFilter.toDateField.value(ENTRY_DATE_TO)
            decSearchPage.entryDateFilter.applyFiltersButton.click()

        then: "correct number of results will be shown"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 72"
    }

    def "Search for declarations using Clearance Date"() {
        when: "I apply the Clearance Date Filter for date range 1-4-17 to 31-12-17"

            decSearchPage.filterFields.clearanceDateFilterLink.click()
            decSearchPage.clearanceDateFilter.fromDateField.value(CLEARANCE_DATE_FROM)
            decSearchPage.clearanceDateFilter.toDateField.value(CLEARANCE_DATE_TO)
            decSearchPage.clearanceDateFilter.applyFiltersButton.click()

        then: "correct number of results will be shown"

            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 60"
    }

    def "Search for declarations using Country of Origin facet"() {
        when: "I launch the Origin Country facet, select NL and apply the filter"

            decSearchPage.filterFields.selectOriginCountryFilter()
            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_NL)
            decSearchPage.facetOverlay.applyFiltersButton.click()

        then: "correct number of results will be shown"

            decSearchPage.selectedFilterFields.latestFilterAppliedText() == "Country of Origin"
            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 30"
    }

    def "Search for declarations using Country of Dispatch facet"() {
        when: "I launch the Dispatch Country facet, select GR and PL and apply the filter"

            decSearchPage.filterFields.selectDispatchCountryFilter()
            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_GR)
            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_PL)
            decSearchPage.facetOverlay.applyFiltersButton.click()

        then: "correct number of results will be shown"

            decSearchPage.selectedFilterFields.latestFilterAppliedText() == "Country of Dispatch"
            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 20"
    }

    def "Search for declarations using Country of Destination facet"() {
        when: "I launch the Dispatch Destination facet, select GB, LB and IE and apply the filter"

            decSearchPage.filterFields.selectDestinationCountryFilter()
            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_GB)
            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_LB)
            decSearchPage.facetOverlay.clickLinkFor(COUNTRY_CODE_IE)
            decSearchPage.facetOverlay.applyFiltersButton.click()

        then: "correct number of results will be shown"

            decSearchPage.selectedFilterFields.latestFilterAppliedText() == "Country of Destination"
            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 15"
    }

    def "Search for declarations using Mode of Transport facet"() {
        when: "I launch the Mode of Transport facet and select codes 0, 3, 7 and 1 and apply the filter"

            decSearchPage.filterFields.selectModeofTransportFilter()
            decSearchPage.facetOverlay.clickLinkFor(MODE_OF_TRANSPORT_CODE_0)
            decSearchPage.facetOverlay.clickLinkFor(MODE_OF_TRANSPORT_CODE_3)
            decSearchPage.facetOverlay.clickLinkFor(MODE_OF_TRANSPORT_CODE_5)
            decSearchPage.facetOverlay.clickLinkFor(MODE_OF_TRANSPORT_CODE_7)
            decSearchPage.facetOverlay.applyFiltersButton.click()

        then: "correct number of results will be shown"

            decSearchPage.selectedFilterFields.latestFilterAppliedText() == "Mode of Transport"
            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-10 of 12"
    }

    def "Search for declarations using Goods Location facet"() {
        when: "I select launch the Goods Locations facet, select Unknown and EXE and apply the filter"

            decSearchPage.filterFields.selectGoodsLocationFilter()
            decSearchPage.facetOverlay.clickLinkFor(GOODS_LOCATION_CODE_UNKNOWN)
            decSearchPage.facetOverlay.clickLinkFor(GOODS_LOCATION_CODE_EXE)
            decSearchPage.facetOverlay.applyFiltersButton.click()

        then: "correct number of results will be shown"

            decSearchPage.selectedFilterFields.latestFilterAppliedText() == "Goods Location"
            decSearchPage.searchFields.recordsFoundMessage.text() == "Showing 1-6 of 6"
    }
}