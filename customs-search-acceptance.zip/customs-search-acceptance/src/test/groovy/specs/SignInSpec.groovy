package specs

import data.UiMessages
import pages.DeclarationSearchPage
import pages.SignInPage

class SignInSpec extends BaseGebSpec {

    def "Sign in with valid credentials where user has full access"() {
        given: "I navigate to the Login page"

            def signinPage = to SignInPage

        when: "I enter valid login credentials"

            signinPage.signInFields.signInAsSuperUser()

        then: "I will be navigated to the Search Declarations page"

            at DeclarationSearchPage
    }

    def "Attempt login without entering any credentials"() {
        when: "I navigate to the Login page"

            def signinPage = to SignInPage

        then: "The sign in button will be disabled by default"

            signinPage.signInFields.isSignInButtonDisabled()
    }

    def "Attempt to sign in with invalid credentials"() {
        given: "I navigate to the Login page"

            def signinPage = to SignInPage

        when: "I enter invalid login credentials"

            signinPage.signInFields.signInAsInvalidUser()

        then: "I will be presented with an error on page"

            signinPage.signInFields.invalidCredentialsMessage.text() == UiMessages.signInPageLoginFailed
    }

    def "Attempt to navigate to search home page without sign in"() {
        when: "I navigate to the search home page directly (base URL) without signing in"

            go()

        then: "I am presented with the sign in page"

            at SignInPage
    }

    //TODO - needs to be done when users and roles stories come into play
    def "Login with valid credentials where user does not have access to Search facility"() {}

}
