package config

class ApplicationConfiguration {

    private static final String CONFIG_PROPERTIES = "/config.properties"
    private static Properties config
    private static InputStream is = null

    static {
        if (config == null) {
            config = new Properties()
            is = ApplicationConfiguration.class.getResourceAsStream(CONFIG_PROPERTIES)
        }
    }

    static Properties getConfig() {
        try {
            config.load(is)
        } catch (IOException e) {
            e.printStackTrace()
        } catch (NullPointerException e) {
            e.printStackTrace()
        }
        return config
    }

    static String getValue(String key) {
        return getConfig().getProperty(key)
    }
}

