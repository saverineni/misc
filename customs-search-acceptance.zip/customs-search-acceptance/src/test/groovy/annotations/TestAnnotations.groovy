package annotations

import java.lang.annotation.*

@Retention(RetentionPolicy.RUNTIME)
@Target([ElementType.TYPE, ElementType.METHOD])
@Inherited
@interface dev {}

@Retention(RetentionPolicy.RUNTIME)
@Target([ElementType.TYPE, ElementType.METHOD])
@Inherited
@interface qa {}

//@Retention(RetentionPolicy.RUNTIME)
//@Target([ElementType.TYPE, ElementType.METHOD])
//@Inherited
//@interface updates_database {}


