package data

class LoginCredentials {
    static superUserPID = "dev"
    static superUserPassword = "dev"
    static invalidUserPID = "test"
    static invalidUserPassword = "test"
}
