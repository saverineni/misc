package data

class UiMessages {
    static signInPageLoginFailed = "You have entered invalid credentials"
    static noResultsFound = "No results found for search criteria."
    static commodityCodeFacetDefaultMessage = "Enter at least 4 numbers to bring back results"
    static commodityCodeFacetNotFoundMessage = "No results found"
}
