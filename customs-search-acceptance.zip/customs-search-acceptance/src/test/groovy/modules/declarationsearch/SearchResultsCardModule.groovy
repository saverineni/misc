package modules.declarationsearch

import geb.Module
import org.openqa.selenium.By
import pages.DeclarationDetailsPage

class SearchResultsCardModule extends Module {
    static content = {
        resultsSection (wait: true) {$("div", class: "search-results-cards")}
        allResults(wait: true) {resultsSection.$("cds-declaration-card")}
        allLines {allResults.$("cds-declaration-lines")}
        firstResultCard {resultsSection.$("mat-card").first()}
        allFirstCardHeaderLabels {firstResultCard.$("h4", class: "declaration-data-grid__header")}
        allFirstCardHeaderResults {firstResultCard.$("div", class: "declaration-data-grid__value")}

        firstCardDeclarationDetailsLink {firstResultCard.$("button").first()}

        firstCardLineExpansion {firstResultCard.$("mat-card-footer").first()}
        allCardsLineExpansion {allResults.$("mat-card-footer")}
//        recordsFound(wait: true) { $("p",  class: "search-results-message")}
//        notFoundMessage(wait: true) {$("p", class: "no-search-results")}

        //Header fields
        allEntryNumberHeaderCells {resultsSection.$("cds-declaration-card > mat-card > cds-declaration-data-grid > div > mat-grid-list > div > mat-grid-tile:nth-child(3) > figure > div > div")}
        allEpuHeaderCells {resultsSection.$("cds-declaration-card > mat-card > cds-declaration-data-grid > div > mat-grid-list > div > mat-grid-tile:nth-child(2) > figure > div > div")}
        consigneeNoHeaderCell {firstResultCard.$(By.cssSelector("div[data-declaration-header-field='consigneeTurn']"))}
        consigneeNameHeaderCell {firstResultCard.$(By.cssSelector("div[data-declaration-header-field='consigneeName']"))}
        consigneePostcodeHeaderCell {firstResultCard.$(By.cssSelector("div[data-declaration-header-field='consigneePostcode']"))}
        consignorNoHeaderCell {firstResultCard.$(By.cssSelector("div[data-declaration-header-field='consignorTurn']"))}
        consignorNameHeaderCell {firstResultCard.$(By.cssSelector("div[data-declaration-header-field='consignorName']"))}
        consignorPostcodeHeaderCell {firstResultCard.$(By.cssSelector("div[data-declaration-header-field='consignorPostcode']"))}

        //Line fields
        allCpcLineCells {resultsSection.$("mat-cell", class: "mat-cell cdk-column-cpc")}
        allCommodityCodeLineCells {resultsSection.$("mat-cell", class: "mat-cell cdk-column-commodityCode")}
        allOriginCountryCodeLineCells {resultsSection.$("mat-cell", class: "mat-cell cdk-column-originCountry")}
        consigneeLineCells {resultsSection.$("mat-cell", class: "mat-cell cdk-column-consignee").last()}
        consignorLineCells {resultsSection.$("mat-cell", class: "mat-cell cdk-column-consignor").last()}
    }

    DeclarationDetailsPage selectFirstDeclarationDetailsLink() {
        firstCardDeclarationDetailsLink.click()
        waitFor { browser.at(DeclarationDetailsPage) }
    }

    def expandAllDeclarations() {
        waitFor {
            allCardsLineExpansion.every { it.click() }
        }
    }

    def expandFirstDeclaration() {
        firstCardLineExpansion.click()
    }

    boolean checkResultsForEPU (String epu) {
        return allEpuHeaderCells.every {
            it.text() == epu
        }
    }

    int noOfResultsForEpu () {
        return allEpuHeaderCells.size()
    }

    boolean checkResultsForEntryNumber (String entryNumber) {
        return allEntryNumberHeaderCells.every {
            it.text() == entryNumber
        }
    }

    int noOfResultsForEntryNumber () {
        return allEntryNumberHeaderCells.size()
    }

    boolean checkResultsForCPC (String cpc) {
        return allCpcLineCells.every {
            it.text() == cpc
        }
    }

    int noOfResultsForCPC () {
        return allCpcLineCells.size()
    }

    boolean checkResultsForCommodityCode (String commodityCode) {
        return allCommodityCodeLineCells.every {
            it.text() == commodityCode
        }
    }

    int noOfResultsForCommodityCode () {
        return allCommodityCodeLineCells.size()
    }

    boolean checkResultsForOriginCountryCode (String originCountryCode) {
        return allOriginCountryCodeLineCells.first().text() == originCountryCode
    }

    int noOfResultsForOriginCountryCode () {
        return allOriginCountryCodeLineCells.size()
    }
}
