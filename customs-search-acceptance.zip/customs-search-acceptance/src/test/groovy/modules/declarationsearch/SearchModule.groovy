package modules.declarationsearch

import geb.Module
import geb.module.FormElement

class SearchModule extends Module {
    static content = {
        searchSection(wait: true) {$("cds-search-form")}
        declarationIDField {searchSection.$("input", name: "searchTerm")}
        searchButton { searchSection.$("button").has("span")}
        recordsFoundMessage(wait: true) {$("p")}
    }

    def searchFor(String searchTerm) {
        declarationIDField.value(searchTerm)
        searchButton.click()
        waitFor { recordsFoundMessage }
        //declarationIDField << Keys.ENTER
    }

    boolean isSearchButtonEnabled() {
        return searchButton.module(FormElement).isEnabled()
    }
}
