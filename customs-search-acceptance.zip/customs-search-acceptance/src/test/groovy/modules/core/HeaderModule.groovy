package modules.core

import geb.Module

class HeaderModule extends Module {
    static content = {
        headerSection {$("cds-header")}
        signOutButton { headerSection.$("button").has("span")}
    }
}
