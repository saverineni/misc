package modules.core

import geb.Module

class NavbarModule extends Module {
    static content = {
        navSection {$("cds-navbar")}
        customsSearchLink {navSection.$("span")}
    }
}
