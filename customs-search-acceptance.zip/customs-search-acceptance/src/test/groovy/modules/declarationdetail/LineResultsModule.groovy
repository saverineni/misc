package modules.declarationdetail

import geb.Module

class LineResultsModule extends Module {
    static content = {
        lineResultsSection(wait: true) {$("cds-declaration-lines")}
        lineTable {lineResultsSection.$("mat-table")}
        lineColumnHeadings {lineResultsSection.$("mat-header-row")}
        lineColumnResults {lineResultsSection.$("mat-row")}
    }
}
