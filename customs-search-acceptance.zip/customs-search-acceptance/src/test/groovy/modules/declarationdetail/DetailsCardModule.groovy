package modules.declarationdetail

import geb.Module

class DetailsCardModule extends Module {
    static content = {

    }
}
