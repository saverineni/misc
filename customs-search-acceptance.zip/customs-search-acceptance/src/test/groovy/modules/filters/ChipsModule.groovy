package modules.filters

import geb.Module

class ChipsModule extends Module {
    static content = {
        chipsSection {$("cds-selected-facets")}
        filterLabel {chipsSection.$("label")}
        chipsVisible {chipsSection.$("mat-chip")}
        chipsVisibleCancel {chipsVisible.$("mat-icon")}
    }

    boolean isChipVisible(String chipText) {
        return chipsVisible.findAll { it -> it.text().contains(chipText)}
    }

    String latestFilterAppliedText() {
        waitFor {
            return filterLabel.last().text()
        }
    }
}
