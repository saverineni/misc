package modules.filters

import geb.Module

class FacetModule extends Module {
    static content = {
        facet(required: false) {$("mat-dialog-container")}
        headerText {facet.$("h2")}
        commodityCodeInfoText {facet.$("p")}
        searchBar {facet.$("input", class: "faceted-search__filter")}
        linkTextList {facet.$("div > mat-dialog-content > div > div > a")}
        linkTextListVisible {facet.$("div > mat-dialog-content > div > div")}
        linksSelected(required: false) {linkTextListVisible.$("a", class: "faceted-search__link ng-star-inserted faceted-search__link--selected")}
        chipsVisible {facet.$("mat-chip")}
        chipsVisibleCancel {chipsVisible.$("mat-icon")}
        cancelButton {facet.$("button", class: "faceted-search__cancel")}
        applyFiltersButton {facet.$("button", class: "faceted-search__apply-filters")}
    }

     Integer totalVisibleLinks() {
         if (linkTextListVisible.text() == "No results found") {
             return 0
         } else {
             return linkTextListVisible.text().count("\n") + 1
         }
    }

    boolean isFacetDisabled() {
        waitFor { return !facet.isDisplayed() }
    }

    def clickLinkFor(String linkText) {
        linkTextList.findAll { it -> it.text().startsWith(linkText)}.click()
    }

    boolean isFacetLinkDisabled(String linkText) {
        return linksSelected.findAll { it -> it.text().startsWith(linkText)}
    }

    boolean allFacetLinksEnabled() {
        waitFor {linksSelected.isEmpty()}
    }

    boolean isChipVisible(String chipText) {
        return chipsVisible.findAll { it -> it.text().startsWith(chipText)}
    }

    def cancelAllChips() {
        chipsVisibleCancel.every {it.click()}
    }
}