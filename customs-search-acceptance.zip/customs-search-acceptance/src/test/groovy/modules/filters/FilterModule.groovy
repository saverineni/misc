package modules.filters

import geb.Module
import org.openqa.selenium.By

class FilterModule extends Module {
    static content = {
        filterSection(wait: true) {$("div", class: "search-filter")}
        entryDateFilterLink {filterSection.$("div", class: "entry-date")}
        clearanceDateFilterLink {filterSection.$("div", class: "clearance-date")}
        originCountryFilterLink {filterSection.$(By.cssSelector("div[data-links-id='originCountryCode']"))}
        originCountryFilterLinkDisabled {originCountryFilterLink.$("a", class: "links__facet links__facet-disabled")}
        dispatchCountryFilterLink {filterSection.$(By.cssSelector("div[data-links-id='dispatchCountryCode']"))}
        dispatchCountryFilterLinkDisabled {dispatchCountryFilterLink.$("a", class: "links__facet links__facet-disabled")}
        destinationCountryFilterLink {filterSection.$(By.cssSelector("div[data-links-id='destinationCountryCode']"))}
        destinationCountryFilterLinkDisabled {destinationCountryFilterLink.$("a", class: "links__facet links__facet-disabled")}
        modeofTransportFilterLink {filterSection.$(By.cssSelector("div[data-links-id='transportModeCode']"))}
        modeofTransportFilterLinkDisabled {modeofTransportFilterLink.$("a", class: "links__facet links__facet-disabled")}
        goodsLocationFilterLink {filterSection.$(By.cssSelector("div[data-links-id='goodsLocation']"))}
        goodsLocationFilterLinkDisabled {goodsLocationFilterLink.$("a", class: "links__facet links__facet-disabled")}
        commodityCodeFilterLink {filterSection.$(By.cssSelector("div[data-links-id='commodityCode']"))}
        facetContainer {$("mat-dialog-container")}
    }

    def selectOriginCountryFilter() {
        originCountryFilterLink.click()
        waitFor { facetContainer }
    }

    def selectDispatchCountryFilter() {
        dispatchCountryFilterLink.click()
        waitFor { facetContainer }
    }

    def selectDestinationCountryFilter() {
        destinationCountryFilterLink.click()
        waitFor { facetContainer }
    }

    def selectModeofTransportFilter() {
        modeofTransportFilterLink.click()
        waitFor { facetContainer }
    }

    def selectGoodsLocationFilter() {
        goodsLocationFilterLink.click()
        waitFor { facetContainer }
    }

    def selectCommodityCodeFilter() {
        commodityCodeFilterLink.click()
        waitFor { facetContainer }
    }

    boolean isOriginCountryFilterDisabled() {
        return originCountryFilterLinkDisabled
    }

    boolean isDispatchCountryFilterDisabled() {
        return dispatchCountryFilterLinkDisabled
    }

    boolean isDestinationCountryFilterDisabled() {
        return destinationCountryFilterLinkDisabled
    }

    boolean isModeOfTransportFilterDisabled() {
        return modeofTransportFilterLinkDisabled
    }

    boolean isGoodsLocationFilterDisabled() {
        return goodsLocationFilterLinkDisabled
    }
}
