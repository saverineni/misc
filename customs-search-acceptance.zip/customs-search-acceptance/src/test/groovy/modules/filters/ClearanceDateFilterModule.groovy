package modules.filters

import geb.Module

class ClearanceDateFilterModule extends Module {
    static content = {
        dateFilter { $("div", class: "clearance-date") }
        fromDateField {dateFilter.$("input", class: "date-range__from-input")}
        toDateField {dateFilter.$("input", class: "date-range__to-input")}
        clearButton {dateFilter.$("button", class: "date-range__button date-range__clear-button")}
        applyFiltersButton {dateFilter.$("button", class: "date-range__button date-range__apply-filters-button")}
        infoMessage {dateFilter.$("span", class: "date-range__info-message")}
        dateFieldsPanelNotExpanded {dateFilter.$("div", class: "mat-expansion-panel-content ng-trigger ng-trigger-bodyExpansion")}
    }

    def fromTodaysDate() {
        def date = new Date().format("dd/MM/yyyy")
        fromDateField.click()
        fromDateField.value(date.toString())
    }

    boolean isDateFieldsPanelExpanded() {
        return !dateFieldsPanelNotExpanded.isEmpty()
    }
}

