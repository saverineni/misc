package enums

enum LoginType {
    FULL_ACCESS,
    PARTIAL_ACCESS,
    NO_ACCESS,
    INVALID
}