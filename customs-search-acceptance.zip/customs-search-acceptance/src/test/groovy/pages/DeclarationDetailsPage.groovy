package pages

class DeclarationDetailsPage extends BasePage {

    static at = {
        title == "Customs Declaration Search"
    }
}
