package pages

import geb.Page
import modules.core.HeaderModule
import modules.core.NavbarModule
import modules.declarationdetail.LineResultsModule
import modules.filters.ChipsModule
import modules.declarationsearch.SearchResultsCardModule
import modules.declarationsearch.SearchModule
import modules.filters.ClearanceDateFilterModule
import modules.filters.EntryDateFilterModule
import modules.filters.FacetModule
import modules.filters.FilterModule

class BasePage extends Page {
    static content = {
        headerFields { module HeaderModule }
        navFields {module NavbarModule}
        searchFields {module SearchModule}
        filterFields {module FilterModule }
        selectedFilterFields {module ChipsModule }
        entryDateFilter {module EntryDateFilterModule}
        clearanceDateFilter {module ClearanceDateFilterModule}
        facetOverlay {module FacetModule}
        resultFields {module SearchResultsCardModule}
        lineResultFields {module LineResultsModule}
    }
}
