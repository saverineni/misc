package pages

class DeclarationSearchPage extends BasePage {

    static at = {
        title == "Customs Declaration Search"
    }
}
