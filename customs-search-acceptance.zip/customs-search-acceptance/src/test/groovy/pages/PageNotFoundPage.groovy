package pages

import geb.Page

class PageNotFoundPage extends Page {
    static at = {$("h1", class: "not-found__heading").text() == "404 the requested URL was not found"}
}
