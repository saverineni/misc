package pages

import data.LoginCredentials
import geb.Module
import geb.Page
import geb.module.FormElement

class SignInPage extends Page {

    static url = "/signin"
    static at = {
        title == "Customs Declaration Search"
        signInFields.signInLabel == "Sign In"
    }

    static content = {
        signInFields {module SignInFieldsModule}
    }
}

class SignInFieldsModule extends Module {

    static content = {
        fieldsSection(wait : true) {$("fieldset")}
        pidField { fieldsSection.$("input", name: "pid")}
        passwordField { fieldsSection.$("input", name: "password")}
        signInButton { fieldsSection.$("button").has("span")}
        signInLabel { fieldsSection.$("legend").text()}
        invalidCredentialsMessage { $("mat-error").has("span")}
    }

    DeclarationSearchPage signInAsSuperUser() {
        pidField.value(LoginCredentials.superUserPID)
        passwordField.value(LoginCredentials.superUserPassword)
        signInButton.click()
        waitFor { browser.at(DeclarationSearchPage) }
    }

    def signInAsInvalidUser() {
        pidField.value(LoginCredentials.invalidUserPID)
        passwordField.value(LoginCredentials.invalidUserPassword)
        signInButton.click()
        waitFor { invalidCredentialsMessage }
    }

    boolean isSignInButtonDisabled() {
        return signInButton.module(FormElement).isDisabled()
    }
}
