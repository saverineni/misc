import config.ApplicationConfiguration
import pages.PageNotFoundPage

import static config.ApplicationConfiguration.getValue

reportsDir = new File("target/test-reports/geb")
reportOnTestFailureOnly = false
baseNavigatorWaiting = true
atCheckWaiting = true
cacheDriverPerThread = true
quitCachedDriverOnShutdown = true

unexpectedPages = [PageNotFoundPage]

waiting {
    timeout = 10
    retryInterval = 1
    includeCauseInMessage = true
}

baseUrl = "http://10.102.83.196:8001/"

driver = DriverFactory.createDriver(System.getProperty("browser", getValue('browserName')))

environments {
    dev {
        baseUrl = "http://10.102.83.180:8001/"
    }
    qa {
        baseUrl = "http://10.102.83.196:8001/"
    }
}


