import annotations.dev
import annotations.qa

def environments = [dev: dev, qa: qa]

def genEnv = System.getProperty("geb.env")

//if (gebEnv) {
//    runner {
//        include environments[genEnv]
//    }
//}
