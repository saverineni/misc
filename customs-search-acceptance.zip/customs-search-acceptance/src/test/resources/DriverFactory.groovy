import config.ApplicationConfiguration
import org.openqa.selenium.chrome.ChromeDriver
import org.openqa.selenium.chrome.ChromeOptions
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.firefox.FirefoxProfile
import org.openqa.selenium.remote.CapabilityType
import org.openqa.selenium.remote.DesiredCapabilities

import static config.ApplicationConfiguration.getValue

class DriverFactory {
    static def createDriver(String browser) {
        switch (browser) {
            case "chrome":
                return { createChromeDriver() }
            case "firefox":
                return { createFirefoxDriver() }
            default:
                throw new IllegalArgumentException("Cannot create driver from browser type [$browser]")
        }
    }

    private static FirefoxDriver createFirefoxDriver() {
        FirefoxProfile profile = new FirefoxProfile()
        profile.setAcceptUntrustedCertificates(false)
        return new FirefoxDriver(profile)
    }

    private static ChromeDriver createChromeDriver() {

        System.out.println('********' + getValue('chromeDriverPath'))

            if (isWindows()) {
                def chromeDriver = new File('test/drivers/windows/chrome/chromedriver.exe')
                downloadAndExtractDriver(chromeDriver, "http://chromedriver.storage.googleapis.com/2.35/chromedriver_win32.zip")
                System.setProperty('webdriver.chrome.driver', chromeDriver.absolutePath)
            } else if (isMac()) {
                def chromeDriver = new File('test/drivers/mac/chrome/chromedriver.exe')
                downloadAndExtractDriver(chromeDriver, "http://chromedriver.storage.googleapis.com/2.35/chromedriver_mac64.zip")
                System.setProperty('webdriver.chrome.driver', chromeDriver.absolutePath)
            } else if (isLinux()) {
                def chromeDriver = new File(getValue('chromeDriverPath'))
                System.setProperty('webdriver.chrome.driver', chromeDriver.absolutePath)
            }

        ChromeOptions options = new ChromeOptions()
        options.addArguments(getValue('headless'))
        options.addArguments("sandbox")
        return new ChromeDriver(options)
    }

    private static void downloadAndExtractDriver(File file, String path) {
        if (!file.exists()) {
            def ant = new AntBuilder()
            ant.get(src: path, dest: 'driver.zip')
            ant.unzip(src: 'driver.zip', dest: file.parent)
            ant.delete(file: 'driver.zip')
            ant.chmod(file: path, perm: '700')
        }
    }

    private static String getOSName() {
        return System.getProperty("os.name").toLowerCase()
    }

    private static boolean isWindows() {
        return (getOSName().indexOf("win") >= 0)
    }

    private static boolean isMac() {
        return (getOSName().indexOf("mac") >= 0)
    }

    private static boolean isLinux() {
        return (getOSName().indexOf("linux") >= 0)
    }
}