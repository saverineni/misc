Running locally: 
        mvn -Dwebdriver.chrome.driver=test/drivers/linux/chrome/chromedriver -Dtest=SignInSpec test
Running on Jenkins: 
                mvn -Dtest=SignInSpec test