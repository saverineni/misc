import org.elasticsearch.client.RestHighLevelClient
import org.apache.http.entity.StringEntity
import org.apache.http.message.BasicHeader

import static org.apache.http.entity.ContentType.APPLICATION_JSON
import static org.apache.http.HttpHeaders.CONTENT_TYPE

createIndex = { clientBuilder, indexName ->
    def waitingForElasticSearch = true
    RestHighLevelClient pingClient = new RestHighLevelClient(clientBuilder)

    while (waitingForElasticSearch) {
        try {
            pingClient.ping()
            waitingForElasticSearch = false
        } catch (e) {
            Thread.sleep(1000)
        }
    }

    response = pingClient.getLowLevelClient().performRequest("HEAD", "/" + indexName)
    int statusCode = response.getStatusLine().getStatusCode()
    println 'Index exists :' + statusCode

    if (statusCode == 200) {
        println 'Deleting existing index...' + indexName
        pingClient.getLowLevelClient().performRequest("DELETE", indexName)
    }

    println 'Creating new index' + indexName
    
    def mappingFile = this.getClass().getResourceAsStream('/BOOT-INF/classes/elasticsearch-mappings/declarationMappings.json').text

    pingClient.getLowLevelClient().performRequest(
        "PUT",
        indexName,
        [:],
        new StringEntity(mappingFile, APPLICATION_JSON),
        new BasicHeader(CONTENT_TYPE, 'application/json'))

    pingClient.close()
}
