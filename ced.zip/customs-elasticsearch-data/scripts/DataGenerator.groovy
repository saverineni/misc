import org.apache.http.HttpHost
import org.elasticsearch.action.bulk.BulkRequest
import org.elasticsearch.action.index.IndexRequest
import org.elasticsearch.client.RestClient
import org.elasticsearch.client.RestHighLevelClient
import org.elasticsearch.client.RestClientBuilder
import org.elasticsearch.common.xcontent.XContentType
import org.apache.http.client.config.RequestConfig
import org.apache.http.HttpHost

@GrabResolver(name = 'artifactory', root = 'https://artifactory.dataengineering.apps.hmrci/artifactory/maven-release/')
@Grapes([
  @Grab(group = 'uk.gov.gsi.hmrc.cds.search', module = 'customs-search-index-manager', version = '1.0.+'),
  @Grab(group = 'org.elasticsearch.client', module = 'elasticsearch-rest-high-level-client', version = '6.0.0'),
  @GrabExclude('net.sf.jopt-simple:jopt-simple')
])
import java.util.concurrent.Executors


elasticSearchHost = args[0]
elasticSearchPort = args[1] as Integer
indexName = 'customs_declarations'
recordCount = args[2] as Integer
batchSize = args[3] as Integer
threadCount = args[4] as Integer 

evaluate(new File('Countries.groovy'))
evaluate(new File('FieldValues.groovy'))
evaluate(new File('IndexCreator.groovy'))
evaluate(new File('DataGeneratorStats.groovy'))

template = {
    def consignor = consignorGenerator()
    def consignee = consigneeGenerator()
    [
        'declarationId'     : declarationId(),
        'entryNumber'       : entryNumber(),
        'entryDate'         : '2018-04-01 16:00:00.00',
        'epuNumber'         : epuNumber(),
        'route'             : 'F',
        'goodsLocation'     : 'LCY',
        'transportModeCode' : 'tmc',
        'dispatchCountry'   : '',
        'consignorTurn'     : consignor.turn,
        'consignorName'     : consignor.name,
        'consignorPostcode' : consignor.postcode,
        'consigneeTurn'     : consignee.turn,
        'consigneeName'     : consignee.name,
        'consigneePostcode' : consignee.postcode,
        'destinationCountry': 'TV',
        'lines'             : lines().collect {
            def lineConsignee = consignee
            def lineConsignor = consignor
            if (it % 2 == 0) {
                lineConsignor = consignorGenerator()
                lineConsignee = consigneeGenerator()
            }
            def originCountry = country()

            [
                'itemNumber'            : it + 1,
                'commodityCode'         : commodityCode(),
                'originCountryCode'     : originCountry.code,
                'originCountry'     : originCountry,
                'cpc'                   : cpc(),
                'dispatchCountryCode'   : 'dispatch-country-code',
                'destinationCountryCode': 'destination-country-code',
                'clearanceDate'         : 'clearance-date',
                'itemConsignorTurn'     : lineConsignor.turn,
                'itemConsignorName'     : lineConsignor.name,
                'itemConsignorPostcode' : lineConsignor.postcode,
                'itemRoute'             : 'item-route',
                'itemConsigneeTurn'     : lineConsignee.turn,
                'itemConsigneeName'     : lineConsignee.name,
                'itemConsigneePostcode' : lineConsignee.postcode
            ]
        }
    ]
}


restClientBuilder = RestClient.builder(new HttpHost(elasticSearchHost, elasticSearchPort))
  .setRequestConfigCallback({ requestConfigBuilder ->
      requestConfigBuilder.setConnectTimeout(5000)
                          .setSocketTimeout(60000)
    } as RestClientBuilder.RequestConfigCallback)
  .setMaxRetryTimeoutMillis(60000)

createIndex(restClientBuilder, indexName)

startTime = new Date()

println 'Starting data generation...'
println(startTime)

def threadPool = Executors.newFixedThreadPool(threadCount)

(0..<recordCount).collate(batchSize).collect {

    threadPool.submit { ->
        println it[0]
        RestHighLevelClient client = new RestHighLevelClient(restClientBuilder)
        BulkRequest request = new BulkRequest()
        it.each {
            def jsonOutput = template()
            request.add(new IndexRequest(indexName, "declaration", jsonOutput.declarationId)
                    .source(groovy.json.JsonOutput.toJson(jsonOutput).bytes, XContentType.JSON))
        }
        client.bulk(request).toString()
        client.close()
        println(new Date())
    }
}.each { it.get() }

endTime = new Date()
println 'Started  ' + startTime
println 'Finished' + endTime

threadPool.shutdown()

runTimeSeconds = Math.round((endTime.time - startTime.time) / 1000)

logToStatsIndex(restClientBuilder, [
    startTime:startTime.toString(),
    endTime: endTime.toString(),
    runTimeSeconds: runTimeSeconds,
    recordCount: recordCount,
    batchSize: batchSize,
    threadCount: threadCount
])
