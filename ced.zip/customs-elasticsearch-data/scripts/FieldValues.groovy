import java.util.Random
import java.util.concurrent.atomic.AtomicInteger

Random rand = new Random()
AtomicInteger counter = new AtomicInteger()

declarationId = { '' + (2000000000000000 + counter.getAndIncrement()) }

countryCount = countries.size()

entryNumber = { (100000 + rand.nextInt(900000)) + 'a' }

epuNumber = { (100 + rand.nextInt(900)) + '' }

consignorGenerator = {
  def value = rand.nextInt(1000000)
  [
    turn: (100000000000 + value) + '',
    name: "Consignor_$value",
    postcode: "PC_$value"
  ]
}

consigneeGenerator = {
  def value = rand.nextInt(1000000)
  [
    turn: (200000000000 + value) + '',
    name: "Consignor_$value",
    postcode: "PC_$value"
  ]
}

commodityCode = {
  def value = rand.nextInt(10000)
  if (value) {
    100000000 + value + ''
  } else {
    ''
  }
}

country = { countries[rand.nextInt(countryCount)] }

cpc = { (1000000 + rand.nextInt(400)) + '' }

lines = { (0..rand.nextInt(5)) }
