import org.elasticsearch.client.RestHighLevelClient
import org.elasticsearch.action.index.IndexRequest
import org.elasticsearch.common.xcontent.XContentType

def indexName = 'data_generator_stats'

logToStatsIndex = { clientBuilder, stats -> 
    RestHighLevelClient client = new RestHighLevelClient(clientBuilder)       
    
    response = client.getLowLevelClient().performRequest("HEAD", "/" + indexName)
    int statusCode = response.getStatusLine().getStatusCode()
    println 'Index exists :' + statusCode

    if (statusCode == 404) {
        println 'Create index ' + indexName
        client.getLowLevelClient().performRequest("PUT", indexName)
    }
        
    client.index(new IndexRequest(indexName, "stats").source(groovy.json.JsonOutput.toJson(stats).bytes, XContentType.JSON))
    client.close()  
}