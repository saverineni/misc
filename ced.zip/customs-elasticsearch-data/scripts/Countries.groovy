countries = [:]

new File("resources/countries.csv").splitEachLine(",") { country ->
  def index = country[0] as Integer

  countries[index - 1] = [ code: country[1], name: country[2], description: "${country[1]} - ${country[2]}" ]
}
