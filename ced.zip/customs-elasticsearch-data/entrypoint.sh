#!/bin/sh

groovy -Djavax.net.ssl.trustStore=/etc/certs/cacerts DataGenerator.groovy $ELASTIC_SEARCH_HOST $ELASTIC_SEARCH_PORT $RECORDS $BATCH_SIZE $THREAD_COUNT