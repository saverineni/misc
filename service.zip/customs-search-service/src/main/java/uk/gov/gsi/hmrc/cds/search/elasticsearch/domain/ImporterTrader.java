package uk.gov.gsi.hmrc.cds.search.elasticsearch.domain;

import lombok.Builder;
import lombok.Data;


@Data
@Builder
public class ImporterTrader {
    private String importer_trader_turn;
    private String name;
    private String simplified_procedure_authorisations;
    private String trader_name_abbreviated;
    private String current_ind;

}
