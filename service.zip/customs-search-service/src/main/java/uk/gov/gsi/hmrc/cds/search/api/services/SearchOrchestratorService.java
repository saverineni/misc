package uk.gov.gsi.hmrc.cds.search.api.services;

import org.elasticsearch.action.search.SearchResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationResponse;
import uk.gov.gsi.hmrc.cds.search.common.exception.DeclarationNotFoundException;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.Declaration;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.SearchResult;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchService;


@Component
public class SearchOrchestratorService {

    @Autowired
    private SearchResponseMapperService searchResponseMapperService;

    @Autowired
    private SearchService searchService;

    public DeclarationResponse fetchDeclarationById(String declarationId) {
        SearchResponse searchResponse = searchService.getDeclaration (declarationId);
        SearchResult searchResult = searchResponseMapperService.mapResponse(searchResponse);

        if(!searchResult.getHits().isEmpty()) {
            Declaration declaration = searchResult.getHits().get(0).getDeclaration();
            return DeclarationResponse.of(declaration);
        }else{
            throw new DeclarationNotFoundException ( String.format("DeclarationId %s not found",declarationId) );
        }

    }

}
