package uk.gov.gsi.hmrc.cds.search.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.security.core.Authentication;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Date;

public class JwtTokenGenerator {

    private final int tokenExpirationInSeconds;
    private final String secret;
    private final SignatureAlgorithm hashingAlgorithm;
    private final Clock clock;

    public JwtTokenGenerator(int tokenExpirationInSeconds, String secret, SignatureAlgorithm hashingAlgorithm, Clock clock) {
        this.tokenExpirationInSeconds = tokenExpirationInSeconds;
        this.secret = secret;
        this.hashingAlgorithm = hashingAlgorithm;
        this.clock = clock;
    }

    public String createToken(Authentication authentication) {

        String principal = authentication.getPrincipal().toString();
        Claims claims = Jwts.claims().setSubject(principal);
        return Jwts.builder()
                .setClaims(claims)
                .setExpiration(getTokenExpiration())
                .signWith(hashingAlgorithm, secret)
                .compact();
    }

    private Date getTokenExpiration() {
        return Date.from(LocalDateTime.now(clock).plusSeconds(tokenExpirationInSeconds).toInstant(ZoneOffset.UTC));
    }
}
