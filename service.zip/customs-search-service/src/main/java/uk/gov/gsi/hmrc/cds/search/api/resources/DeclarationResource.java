package uk.gov.gsi.hmrc.cds.search.api.resources;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;

import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationResponse;
import uk.gov.gsi.hmrc.cds.search.api.services.SearchOrchestratorService;

@RestController
@RequestMapping({ "", "/api" })
public class DeclarationResource {

    @Autowired
    SearchOrchestratorService searchOrchestratorService;

    @GetMapping("/declaration")
    public DeclarationResponse getDeclarationData(@RequestParam String declarationId) {
        if (Strings.isNullOrEmpty ( declarationId )) {
            throw new IllegalArgumentException ( "declarationId is mandatory" );
        }
        return searchOrchestratorService.fetchDeclarationById ( declarationId );
    }

}