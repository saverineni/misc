package uk.gov.gsi.hmrc.cds.search.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;

@Configuration
@Profile({"test","dev"})
@EnableWebSecurity
public class InMemorySecurityConfig extends SecurityConfig {

    @Override
    protected void configureGlobalSecurity(AuthenticationManagerBuilder auth) {
        // use default provider
    }

    @Override
    public void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.inMemoryAuthentication()
                .withUser("dev").password("dev").roles("USER")
            .and()
                .withUser("superdev").password("superdev").roles("USER","SUPERUSER");
    }

    @Bean
    @Override
    public UserDetailsService userDetailsServiceBean() throws Exception {
        return super.userDetailsServiceBean();
    }
}