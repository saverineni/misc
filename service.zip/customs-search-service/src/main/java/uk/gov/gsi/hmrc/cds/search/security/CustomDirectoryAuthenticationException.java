package uk.gov.gsi.hmrc.cds.search.security;

import org.springframework.security.core.AuthenticationException;

public class CustomDirectoryAuthenticationException extends AuthenticationException {
    private static final long serialVersionUID = 1L;
    
    private final String dataCode;

    CustomDirectoryAuthenticationException(String dataCode, String message,
                                           Throwable cause) {
        super(message, cause);
        this.dataCode = dataCode;
    }

    public String getDataCode() {
        return dataCode;
    }
}