package uk.gov.gsi.hmrc.cds.search.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.ldap.userdetails.InetOrgPersonContextMapper;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import uk.gov.gsi.hmrc.cds.search.security.AuthenticationTokenRequestFilter;
import uk.gov.gsi.hmrc.cds.search.security.HmrcActiveDirectoryLdapAuthenticationProvider;
import uk.gov.gsi.hmrc.cds.search.security.JwtAuthenticationSuccessHandler;
import uk.gov.gsi.hmrc.cds.search.security.JwtTokenGenerator;

import java.time.Clock;

@Configuration
@Profile({"stride", "prod"})
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Value("${app.ad-domain}")
    private String adDomain;

    @Value("${app.ad-server}")
    private String adServer;

    @Value("${app.ldap-search-base}")
    private String ldapSearchBase;

    @Value("${app.ldap-search-filter}")
    private String ldapSearchFilter;

    @Autowired
    Environment environment;
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    protected void configureGlobalSecurity(AuthenticationManagerBuilder auth) {
        auth.authenticationProvider(activeDirectoryLdapAuthenticationProvider());
    }

    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        httpSecurity
                .csrf().disable()
                .authorizeRequests()
                .antMatchers("/declaration/**").permitAll()
                .antMatchers("/api/declaration/**").permitAll()
                .antMatchers("/swagger*").permitAll()
                .antMatchers("/swagger-resources/**").permitAll()
                .antMatchers("/webjars/**").permitAll()
                .antMatchers("/v2/api-docs").permitAll()
                .anyRequest().authenticated()
                .and()
                .addFilterBefore(authenticationTokenRequestFilter(), UsernamePasswordAuthenticationFilter.class);
    }

    private AuthenticationTokenRequestFilter authenticationTokenRequestFilter() {
        AuthenticationTokenRequestFilter authenticationTokenRequestFilter = new AuthenticationTokenRequestFilter("/authentication/token", authenticationManager, objectMapper);
        authenticationTokenRequestFilter.setAuthenticationSuccessHandler(authenticationSuccessHandler());
        return authenticationTokenRequestFilter;
    }

    private AuthenticationSuccessHandler authenticationSuccessHandler() {
        return new JwtAuthenticationSuccessHandler(objectMapper, jwtTokenGenerator());
    }

    @Bean
    public JwtTokenGenerator jwtTokenGenerator() {
        return new JwtTokenGenerator(
                environment.getProperty("jwt.expiration.seconds", Integer.class),
                environment.getProperty("jwt.secret"),
                jwtHashingAlgorithm(),
                clock());
    }

    private SignatureAlgorithm jwtHashingAlgorithm() {
        return SignatureAlgorithm.HS512;
    }

    private Clock clock() {
        return Clock.systemUTC();
    }

    @Bean
    @Profile({"stride", "prod"})
    public HmrcActiveDirectoryLdapAuthenticationProvider activeDirectoryLdapAuthenticationProvider() {
        HmrcActiveDirectoryLdapAuthenticationProvider provider = new HmrcActiveDirectoryLdapAuthenticationProvider(adDomain, adServer, ldapSearchBase);
        provider.setSearchFilter(ldapSearchFilter);
        provider.setUserDetailsContextMapper(new InetOrgPersonContextMapper());
        return provider;
    }
}
