package uk.gov.gsi.hmrc.cds.search.elasticsearch.domain;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OriginCountry {
    private String iso_country_code_alpha_2;
    private String country_name;
}
