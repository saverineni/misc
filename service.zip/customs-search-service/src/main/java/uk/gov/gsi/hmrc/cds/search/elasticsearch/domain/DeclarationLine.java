package uk.gov.gsi.hmrc.cds.search.elasticsearch.domain;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DeclarationLine {
    private String entry_reference;
    private String item_number;
    private String entry_number; // Not in datavault
    private String entry_date; // Not in datavault
    private String route; // Not in datavault
    private String dispatch_country; // Not in datavault
    private String destination_country; // Not in datavault
    private String clearance_datetime;
    private OriginCountry originCountry;
    private CustomsProcedureCode customsProcedureCode;
    private Commodity commodity;
    private ImporterTrader importerTrader;
    private String item_consignee_nad_name;
    private String item_consignee_nad_postcode;
    private String item_consignor_trader_turn; // Not in datavault
    private String item_consignor_nad_name;
    private String item_consignor_nad_postcode; // Not in datavault, MSS: NXINA / IINA.ITEMNADPOSTCODE where NXINA / IINA.ITEMNADTYPE == 1
}
