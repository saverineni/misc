package uk.gov.gsi.hmrc.cds.search.api.resources;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import uk.gov.gsi.hmrc.cds.search.common.domain.ErrorResponse;
import uk.gov.gsi.hmrc.cds.search.common.exception.DeclarationNotFoundException;

@ControllerAdvice
@Slf4j
public class ErrorHandler {

	@ExceptionHandler(IllegalArgumentException.class)
	@ResponseBody
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ErrorResponse handle(IllegalArgumentException exception) {
		return ErrorResponse.of(null, exception.getMessage());
	}

	@ExceptionHandler(DeclarationNotFoundException.class)
	@ResponseBody
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ErrorResponse handle(DeclarationNotFoundException exception) {
		return ErrorResponse.of(null, exception.getMessage());
	}

	@ExceptionHandler(Exception.class)
	@ResponseBody
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ErrorResponse handle(Exception exception) {
		log.error("Unhandled exception occurred:" , exception);
		return ErrorResponse.of(null, exception.getMessage());
	}
}
