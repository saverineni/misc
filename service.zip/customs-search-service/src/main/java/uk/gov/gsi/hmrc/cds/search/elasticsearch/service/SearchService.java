package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.IdsQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.connection.ESConnection;

import java.io.IOException;

@Slf4j
@Service
public class SearchService {

    @Autowired
    private ESConnection connection;

    @Value("${elasticsearch.alias}")
    private String elasticSearchAlias;

    public SearchResponse getDeclaration(String documentId) {

        IdsQueryBuilder idsQueryBuilder = QueryBuilders.idsQuery().addIds(documentId);
        return searchES (idsQueryBuilder);
    }

    private SearchResponse searchES(QueryBuilder queryBuilder) {
        SearchResponse searchResponse = null;
        try(RestHighLevelClient client = connection.getRestClientInstance()) {

            SearchRequest searchRequest = new SearchRequest(elasticSearchAlias);
            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(queryBuilder);
            searchRequest.source(searchSourceBuilder);

            searchResponse = client.search(searchRequest);

        }catch(IOException e){
            log.error(String.format("Exception occurred: %s" , e));
            throw new RuntimeException (e.getMessage ());
        }

        return searchResponse;
    }
}
