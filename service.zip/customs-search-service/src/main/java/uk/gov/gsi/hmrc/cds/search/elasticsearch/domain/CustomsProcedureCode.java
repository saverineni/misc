package uk.gov.gsi.hmrc.cds.search.elasticsearch.domain;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CustomsProcedureCode {
    private String customs_procedure_code;

}
