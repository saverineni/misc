package uk.gov.gsi.hmrc.cds.search.common.domain;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.EqualsAndHashCode;

@EqualsAndHashCode
public class ErrorResponse {

    private ErrorMessage error;

    public ErrorResponse() {
    }

    public ErrorResponse(ErrorMessage error) {
        this.error = error;
    }

    public ErrorMessage getError() {
        return error;
    }

    public static ErrorResponse of(String errorType, String message) {
        ErrorMessage errorMessage = new ErrorMessage(errorType, message);
        return new ErrorResponse(errorMessage);
    }

    @EqualsAndHashCode
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class ErrorMessage {
        @JsonInclude(JsonInclude.Include.NON_NULL)
        private String type;
        private String message;

        public ErrorMessage() {
        }

        public ErrorMessage(String type, String message) {
            this.type = type;
            this.message = message;
        }

        public String getType() {
            return type;
        }

        public String getMessage() {
            return message;
        }
    }

}
