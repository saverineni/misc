package uk.gov.gsi.hmrc.cds.search.elasticsearch.domain;

import com.google.common.collect.Lists;

import java.util.List;


public class SearchResult {

    private long resultCount;
    private List<SearchHit> hits = Lists.newArrayList();

    public List<SearchHit> getHits() {
        return hits;
    }

    public void addSearchHits(List<SearchHit> hits) {
        this.hits.addAll(hits);
    }

    public long getResultCount() {
        return resultCount;
    }

    public void setResultCount(long resultCount) {
        this.resultCount = resultCount;
    }

}
