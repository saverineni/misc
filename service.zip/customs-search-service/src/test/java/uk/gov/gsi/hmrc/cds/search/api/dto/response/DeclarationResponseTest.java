package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import org.junit.Assert;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.Declaration;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.DeclarationLine;

import java.util.List;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;

public class DeclarationResponseTest {

    @Test
    public void returnsNullWhenDeclarationisNull() {
        DeclarationResponse actualResponse = DeclarationResponse.of(null);
        Assert.assertNull(actualResponse);
    }

    @Test
    public void returnsDeclarationResponseHeaderWithLines() {
        DeclarationLine declarationLine = DeclarationLine.builder().entry_number("1234").build();
        Declaration declaration = createDeclaration(asList(declarationLine));
        DeclarationResponse actualResponse = DeclarationResponse.of(declaration);
        Assert.assertEquals(1, actualResponse.getLines().size());
    }

    @Test
    public void returnsDeclarationResponseHeaderWhenNullLines() {
        Declaration declaration = createDeclaration(null);
        DeclarationResponse actualResponse = DeclarationResponse.of(declaration);
        Assert.assertEquals(0, actualResponse.getLines().size());
    }

    @Test
    public void returnsDeclarationResponseHeaderWhenEmptyLines() {
        Declaration declaration = createDeclaration(emptyList());
        DeclarationResponse actualResponse = DeclarationResponse.of(declaration);
        Assert.assertEquals(0, actualResponse.getLines().size());
    }

    private Declaration createDeclaration(List<DeclarationLine> declarationLines) {
        return Declaration.builder()
                .entry_number("entry_number")
                .lines(declarationLines)
                .build();
    }

}
