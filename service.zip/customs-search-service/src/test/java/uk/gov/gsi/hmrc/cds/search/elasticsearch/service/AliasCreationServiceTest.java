package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import ch.qos.logback.classic.spi.LoggingEvent;
import ch.qos.logback.core.Appender;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.jayway.restassured.http.ContentType;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatcher;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import uk.gov.gsi.hmrc.cds.search.config.TestConfig;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.mockito.Matchers.argThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static uk.gov.gsi.hmrc.cds.search.utils.TestHelper.CONTENT_TYPE_FIELD;
import static uk.gov.gsi.hmrc.cds.search.utils.TestHelper.createAliasQuery;


@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest(classes = TestConfig.class)
public class AliasCreationServiceTest {

    private WireMockServer wireMockServer;
    private Appender mockAppender = mock(Appender.class);

    @Autowired
    private AliasCreationService service;


    @Value("${elasticsearch.host}")
    private String elasticSearchHost;

    @Value("${elasticsearch.port}")
    private int elasticSearchPort;

    @Value("${elasticsearch.alias}")
    private String elasticSearchAlias;

    @Value("${elasticsearch.index}")
    private String elasticSearchIndex;


    @Before
    public void setup() {
        createMockLogAppender();

        wireMockServer = new WireMockServer ( elasticSearchPort );
        wireMockServer.start ();

        configureFor ( elasticSearchHost, elasticSearchPort );
    }

    private void createMockLogAppender() {
        ch.qos.logback.classic.Logger root = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(ch.qos.logback.classic.Logger.ROOT_LOGGER_NAME);
        when(mockAppender.getName()).thenReturn("MOCK");
        root.addAppender(mockAppender);
    }

    @After
    public void destroy() {
        wireMockServer.stop ();
    }


    @Test
    public void createsAliasForAnExistingIndex() throws Exception {

        givenThat ( post
                ( urlEqualTo
                        ( "/_aliases" ) )
                .withHeader ( CONTENT_TYPE_FIELD, com.github.tomakehurst.wiremock.client.WireMock.equalTo ( ContentType.JSON.toString () ) )
                .withRequestBody ( equalToJson ( createAliasQuery ( elasticSearchIndex, elasticSearchAlias ) ) )
                .willReturn ( aResponse ().withStatus ( 200 )
                        .withHeader ( HttpHeaders.CONTENT_TYPE, ContentType.JSON.toString () )));

        service.createAlias();

        verifyTheLogMessage("Created elasticsearch alias:" + elasticSearchAlias);
    }


    @Test
    public void doesNotCreateAliasForNonExistingIndex() throws Exception {

        givenThat ( post
                ( urlEqualTo
                        ( "/_aliases" ) )
                .withHeader ( CONTENT_TYPE_FIELD, com.github.tomakehurst.wiremock.client.WireMock.equalTo ( ContentType.JSON.toString () ) )
                .withRequestBody ( equalToJson ( createAliasQuery ( "non-existing-index", elasticSearchAlias ) ) )
                .willReturn ( aResponse ().withStatus ( 404 )
                        .withHeader ( HttpHeaders.CONTENT_TYPE, ContentType.JSON.toString () )));

        service.createAlias();

        verifyTheLogMessage("Exception occurred:");
    }

    private void verifyTheLogMessage(final String message) {
        org.mockito.Mockito.verify(mockAppender).doAppend(argThat(new ArgumentMatcher() {
            @Override
            public boolean matches(final Object argument) {
                return ((LoggingEvent)argument).getFormattedMessage().contains(message);
            }
        }));
    }




}

