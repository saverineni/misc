package uk.gov.gsi.hmrc.cds.search.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.security.core.Authentication;

import java.time.*;
import java.util.Date;


public class JwtTokenGeneratorTest {
    private static final String PRINCIPAL = "1234";
    private static final int TOKEN_EXPIRATION_IN_SECONDS = 3;
    private static final String SECRET = "SECRET";
    private static final SignatureAlgorithm HASHING_ALGORITHM = SignatureAlgorithm.HS512;
    private static final Clock CLOCK = Clock.fixed(Instant.now(), ZoneId.of("UTC"));
    JwtTokenGenerator jwtTokenGenerator = new JwtTokenGenerator(TOKEN_EXPIRATION_IN_SECONDS, SECRET, HASHING_ALGORITHM, CLOCK);
    Authentication authentication = Mockito.mock(Authentication.class);

    @Test
    public void generateJwtToken() {
        Mockito.when(authentication.getPrincipal()).thenReturn(PRINCIPAL);
        String token = jwtTokenGenerator.createToken(authentication);

        Assert.assertThat(token, Matchers.is(expectedToken()));
    }

    private String expectedToken() {
        Claims claims = Jwts.claims().setSubject(PRINCIPAL);
        return Jwts.builder()
                .setClaims(claims)
                .setExpiration(Date.from(LocalDateTime.now(CLOCK).plusSeconds(TOKEN_EXPIRATION_IN_SECONDS).toInstant(ZoneOffset.UTC)))
                .signWith(HASHING_ALGORITHM, SECRET)
                .compact();
    }
}