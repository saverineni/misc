package uk.gov.gsi.hmrc.cds.search.api.resources;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.authentication.FormAuthConfig;
import org.apache.http.HttpStatus;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import uk.gov.gsi.hmrc.cds.search.run.CustomsSearchServiceApplication;

import static com.jayway.restassured.RestAssured.form;
import static org.hamcrest.Matchers.is;
import static uk.gov.gsi.hmrc.cds.search.utils.TestHelper.*;

@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest(
    classes = CustomsSearchServiceApplication.class,
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT
)
public class DocumentationResourceIntegrationTest {

    @Value("${local.server.port}")
    private int port;

    @Before
    public void setup() {
        RestAssured.port = this.port;
        RestAssured.authentication = form(DEV_USER, DEV_USER_PASSWORD,
                new FormAuthConfig(LOGIN_URL, USERNAME, PASSWORD));
    }

    @Test
    public void shouldGetApplicationDocumentAsHTMLAndWithStatus_OK() throws Exception {
        RestAssured
            .given()
                .accept("application/json")
            .expect()
                .body("info.description", is("Api Documentation"))
            .when()
                .get("/v2/api-docs")
            .then().statusCode(HttpStatus.SC_OK);
    }
}
