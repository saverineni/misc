package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line.group;

import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line.DeclarationLineTaxlineDataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubTaxLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatTaxLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLineTaxLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLineTaxLineGroup;

import static org.apache.spark.sql.functions.collect_list;
import static org.apache.spark.sql.functions.struct;

@Component
public class DeclarationLineTaxLineGroupDataset {

    private final DeclarationLineTaxlineDataset declarationLineTaxlineDataset;

    @Autowired
    public DeclarationLineTaxLineGroupDataset(DeclarationLineTaxlineDataset declarationLineTaxlineDataset) {
        this.declarationLineTaxlineDataset = declarationLineTaxlineDataset;
    }

    public Dataset<DeclarationLineTaxLineGroup> build() {
        Dataset<DeclarationLineTaxLine> declarationLineTaxLineDataset = this.declarationLineTaxlineDataset.build();

        Dataset<DeclarationLineTaxLineGroup> taxLineGroupDataset = declarationLineTaxLineDataset
                .groupBy(declarationLineTaxLineDataset.col(HubDeclarationLine.PRIMARY_COLUMN))
                .agg(
                        collect_list(
                                struct(
                                        declarationLineTaxLineDataset.col(HubTaxLine.PRIMARY_COLUMN),
                                        declarationLineTaxLineDataset.col(HubTaxLine.TAX_LINE_SEQUENCE_NUMBER),
                                        declarationLineTaxLineDataset.col(DeclarationLineTaxLine.GENERATION_NUMBER),
                                        declarationLineTaxLineDataset.col(SatTaxLine.WAIVED_TAX_COLUMN),
                                        declarationLineTaxLineDataset.col(SatTaxLine.PAYMENT_METHOD_CODE_COLUMN),
                                        declarationLineTaxLineDataset.col(SatTaxLine.TAX_AMOUNT_COLUMN),
                                        declarationLineTaxLineDataset.col(SatTaxLine.TAX_TYPE_CODE_COLUMN)
                                )
                        ).alias(DeclarationLineTaxLineGroup.ALIAS))
                .as(DeclarationLineTaxLineGroup.declarationLineTaxLineGroupEncoder)
                .persist();

        declarationLineTaxLineDataset.unpersist();

        return taxLineGroupDataset;
    }
}
