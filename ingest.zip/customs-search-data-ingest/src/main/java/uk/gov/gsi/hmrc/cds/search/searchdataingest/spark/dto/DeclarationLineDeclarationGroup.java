package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto;

import com.google.common.collect.Lists;
import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.DeclarationHeader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group.DeclarationHeaderTraderGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLine;

import java.io.Serializable;
import java.util.List;

@Data
@Builder
public class DeclarationLineDeclarationGroup implements Serializable {
    public static Encoder<DeclarationLineDeclarationGroup> declarationLineDeclarationGroupEncoder = Encoders.bean(DeclarationLineDeclarationGroup.class);
    private String hub_declaration_key;
    private String entry_reference;
    private List<DeclarationLine> lines = Lists.newArrayList();

    public static final String ALIAS = "lines";


}
