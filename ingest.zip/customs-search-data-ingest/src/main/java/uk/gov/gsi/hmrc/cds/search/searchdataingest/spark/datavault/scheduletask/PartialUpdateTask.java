package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.scheduletask;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SearchDocumentJob;

//@Component
public class PartialUpdateTask {

    @Autowired
    private SearchDocumentJob declarationDocumentJob;

    //    @Scheduled(initialDelay = 5000, fixedRate = 20000)
    @Scheduled(cron = "${spark.partial.update.cron}")
    public void partialUpdate() {
        declarationDocumentJob.declarationDocument();
    }
}
