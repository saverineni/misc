package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.consignor;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;

@Data
public class DeclarationHeaderConsignorTrader implements Serializable {
    public static Encoder<DeclarationHeaderConsignorTrader> declarationHeaderConsignorTraderEncoder = Encoders.bean(DeclarationHeaderConsignorTrader.class);
    private String hub_declaration_key;
    private ConsignorTrader consignorTrader;

    public static final String ALIAS = "consignorTrader";

}
