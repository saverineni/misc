package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.valueAt;

@Data
@Builder
public class LinkDeclarationLineImporterTrader implements Serializable, BaseEntity {

    private String link_declaration_line_importer_trader_key;
    private String hub_declaration_line_key;
    private String hub_trader_key;
    private String entry_reference;
    private String item_number;
    private String turn;
    private String link_load_datetime;
    private String link_record_source;


    public static LinkDeclarationLineImporterTrader mapper(String line) {
        List<String> columns = parseLine(line);

        return LinkDeclarationLineImporterTrader.builder()
                .link_declaration_line_importer_trader_key(valueAt(columns, 0))
                .hub_declaration_line_key(valueAt(columns, 1))
                .hub_trader_key(valueAt(columns, 2))
                .entry_reference(valueAt(columns, 3))
                .item_number(valueAt(columns, 4))
                .turn(valueAt(columns, 5))
                .link_load_datetime(valueAt(columns, 6))
                .link_record_source(valueAt(columns, 7))
                .build();
    }

    public static final String PRIMARY_COLUMN = "link_declaration_line_importer_trader_key";

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            "hub_trader_key",
            "hub_declaration_line_key"
    );
}
