package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;

@Data
public class DeclarationHeaderCurrencyGroup implements Serializable {

    public static Encoder<DeclarationHeaderCurrencyGroup> declarationHeaderCurrencyGroupEncoder = Encoders.bean(DeclarationHeaderCurrencyGroup.class);
    private String hub_declaration_key;
    private String invoice_currency_iso_code;
    private String freight_currency_iso_code;

}
