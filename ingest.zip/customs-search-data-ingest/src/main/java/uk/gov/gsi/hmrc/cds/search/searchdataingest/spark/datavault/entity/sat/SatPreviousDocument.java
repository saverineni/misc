package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;

@Data
@Builder
public class SatPreviousDocument implements Serializable, BaseEntity {

    private String hub_previous_document_key;
    private String sat_hash_diff;
    private String sat_load_datetime;
    private String sat_load_end_datetime;
    private String sat_record_source;
    private String previous_document_reference;

    public static SatPreviousDocument mapper(String line) {
        List<String> columns = parseLine(line);

        return SatPreviousDocument.builder()
                .hub_previous_document_key(columns.get(0))
                .sat_hash_diff(columns.get(1))
                .sat_load_datetime(columns.get(2))
                .sat_load_end_datetime(columns.get(3))
                .sat_record_source(columns.get(4))
                .previous_document_reference(columns.get(5))
                .build();
    }

    public static final String PREVIOUS_DOCUMENT_REFERENCE = "previous_document_reference";

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            "previous_document_reference"
    );
}
