package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.country;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;


@Data
@Builder
public class DeclarationTransportCountry implements Serializable {

    private String iso_country_code_alpha_2;
    private String country_name;

    public static final String TRANSPORT_ISO_COUNTRY_CODE = "transport_iso_country_code_alpha_2";

}
