package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.declarant;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;

@Data
public class DeclarationHeaderDeclarantTrader implements Serializable {
    public static Encoder<DeclarationHeaderDeclarantTrader> declarationHeaderDeclarantTraderEncoder = Encoders.bean(DeclarationHeaderDeclarantTrader.class);
    private String hub_declaration_key;
    private DeclarantTrader declarantTrader;

    public static final String ALIAS = "declarantTrader";

}
