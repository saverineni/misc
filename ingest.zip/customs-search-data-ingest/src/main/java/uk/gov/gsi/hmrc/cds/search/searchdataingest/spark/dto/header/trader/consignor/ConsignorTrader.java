package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.consignor;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;


@Data
public class ConsignorTrader implements Serializable {
    public static Encoder<ConsignorTrader> consignorTraderEncoder = Encoders.bean(ConsignorTrader.class);
    private String consignor_trader_turn;
    private String name;
    private String simplified_procedure_authorisations;
    private String trader_name_abbreviated;
    private String current_ind;

    public static final String CONSIGNOR_TRADER_TURN = "consignor_trader_turn";


}
