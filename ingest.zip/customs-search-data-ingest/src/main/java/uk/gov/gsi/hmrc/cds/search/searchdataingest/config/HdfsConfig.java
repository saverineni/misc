package uk.gov.gsi.hmrc.cds.search.searchdataingest.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

@Configuration
public class HdfsConfig {

    @Autowired
    Environment environment;

    @Value("${hdfs.namenode}")
    private String hdfsNamenode;

    @Value("${hdfs.namenode.port:8020}")
    private String hdfsNamenodePort;

    @Bean
    public String datafileRelativePath() {
        return environment.getProperty("hdfs.data.vault.datafile.relative.path", "");
    }

    @Bean
    public String hdfsDataVaultBasePath() {
        return environment.getProperty("hdfs.data.vault.base.path");
    }

    @Bean
    public String dataVaultHDFSBasePath() {
        return String.format("hdfs://%s:%s/%s", hdfsNamenode, hdfsNamenodePort, hdfsDataVaultBasePath());
    }

}
