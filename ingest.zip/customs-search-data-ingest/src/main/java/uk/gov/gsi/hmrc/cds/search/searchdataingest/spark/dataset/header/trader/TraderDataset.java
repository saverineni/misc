package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.header.trader;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import org.apache.spark.sql.Column;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatTrader;

import static org.apache.spark.sql.functions.struct;

public interface TraderDataset {
    String[] hubTraderDatasetColumns = Iterables.toArray(
            Iterables.concat(
                    Lists.newArrayList(HubDeclaration.PRIMARY_COLUMN, HubTrader.PRIMARY_COLUMN),
                    HubTrader.SELECT_COLUMNS
            )
            , String.class);

    String[] headerTraderDatasetColumns = Iterables.toArray(
            Iterables.concat(
                    HubTrader.SELECT_COLUMNS,
                    SatTrader.SELECT_COLUMNS
            )
            , String.class);

    String[] linkTraderDatasetColumns = Iterables.toArray(
            Iterables.concat(
                    Lists.newArrayList(HubTrader.PRIMARY_COLUMN),
                    HubTrader.SELECT_COLUMNS
            )
            , String.class);

    default Column traderDetails(String traderTurnName) {
        return struct(
                traderTurnName,
                SatTrader.selectColumns
        );
    }
}
