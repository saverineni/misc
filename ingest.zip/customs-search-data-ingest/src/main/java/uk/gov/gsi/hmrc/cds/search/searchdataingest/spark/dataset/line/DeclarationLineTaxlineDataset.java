package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubTaxLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatTaxLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationLineTaxLineReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatTaxLineReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLineTaxLine;

@Component
public class DeclarationLineTaxlineDataset {
    private static final String DECLARATION_LINE_KEY = HubDeclarationLine.PRIMARY_COLUMN;
    private static String[] datasetColumns = Iterables.toArray(
            Iterables.concat(
                    Lists.newArrayList(HubTaxLine.PRIMARY_COLUMN,DeclarationLineTaxLine.GENERATION_NUMBER),
                    HubTaxLine.SELECT_COLUMNS,
                    SatTaxLine.SELECT_COLUMNS
            )
            , String.class);

    private final SatTaxLineReader satTaxLineReader;
    private final LinkDeclarationLineTaxLineReader linkDeclarationLineTaxLineReader;

    @Autowired
    public DeclarationLineTaxlineDataset(SatTaxLineReader satTaxLineReader,LinkDeclarationLineTaxLineReader linkDeclarationLineTaxLineReader) {
        this.satTaxLineReader = satTaxLineReader;
        this.linkDeclarationLineTaxLineReader = linkDeclarationLineTaxLineReader;
    }

    public Dataset<DeclarationLineTaxLine> build() {
        Dataset linkDeclarationLineTaxLineDataset = linkDeclarationLineTaxLineReader.linkDeclarationLineTaxLineDataset();
        Dataset<SatTaxLine> satTaxLineDataset = satTaxLineReader.satTaxLineDataset();

        Dataset<DeclarationLineTaxLine> declarationLineTaxLineDataset = linkDeclarationLineTaxLineDataset
                .join(satTaxLineDataset, HubTaxLine.joinColumns)
                .withColumnRenamed(SatTaxLine.GENERATION_NUMBER_COLUMN, DeclarationLineTaxLine.GENERATION_NUMBER)
                .select(DECLARATION_LINE_KEY, datasetColumns)
                .as(DeclarationLineTaxLine.declarationLineTaxLineEncoder);

        linkDeclarationLineTaxLineDataset.unpersist();
        satTaxLineDataset.unpersist();

        return declarationLineTaxLineDataset;
    }
}
