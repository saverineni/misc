package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationConsignorTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.LINK_DECLARATION_CONSIGNOR_TRADER;

@Component
public class LinkDeclarationConsignorTraderReader extends DataVaultReader {
    private static final Encoder<LinkDeclarationConsignorTrader> linkDeclarationConsignorTraderEncoder = Encoders.bean(LinkDeclarationConsignorTrader.class);

    public Dataset<LinkDeclarationConsignorTrader> linkDeclarationConsignorTraderDataset() {
        String dataFilePath = String.format("%s/%s", LINK_DECLARATION_CONSIGNOR_TRADER.tableName(), datafileRelativePath);
        String linkDeclarationConsignorTraderFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<LinkDeclarationConsignorTrader> linkDeclarationConsignorTraderJavaRDD = sparkSession
                .read()
                .textFile(linkDeclarationConsignorTraderFilePath)
                .javaRDD()
                .map((Function<String, LinkDeclarationConsignorTrader>) LinkDeclarationConsignorTrader::mapper)
                .cache();

        return sparkSession
                .createDataFrame(linkDeclarationConsignorTraderJavaRDD, LinkDeclarationConsignorTrader.class)
                .as(linkDeclarationConsignorTraderEncoder)
                .cache();
    }

}
