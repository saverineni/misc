package uk.gov.gsi.hmrc.cds.search.searchdataingest.elasticsearch;

import com.google.common.collect.ImmutableMap;
import org.apache.spark.sql.Dataset;
import org.elasticsearch.spark.rdd.api.java.JavaEsSpark;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SearchDocumentJob;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.Declaration;

import java.util.Map;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.config.ESConfig.MAPPING_ID_KEY;

@Component
public class ESIngester {
    private static final Map<String, String> ES_CONFIG = ImmutableMap.of(MAPPING_ID_KEY, Declaration.DECLARATION_ID_FIELD);
    private final SearchDocumentJob searchDocumentJob;
    private String elasticsearchIndex;

    @Autowired
    public ESIngester(SearchDocumentJob searchDocumentJob, @Value("${es.resource}") String elasticsearchIndex) {
        this.searchDocumentJob = searchDocumentJob;
        this.elasticsearchIndex = elasticsearchIndex;
    }

    public void ingest() {
        Dataset<String> declarationDocumentDataset = searchDocumentJob.declarationDocument();
        JavaEsSpark.saveJsonToEs(declarationDocumentDataset.toJavaRDD(), elasticsearchIndex, ES_CONFIG);
    }
}
