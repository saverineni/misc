package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.SAT_DOCUMENT;

@Component
public class SatDocumentReader extends DataVaultReader {
    private static final Encoder<SatDocument> satDocumentEncoder = Encoders.bean(SatDocument.class);

    public Dataset<SatDocument> satDocumentDataset() {
        String dataFilePath = String.format("%s/%s", SAT_DOCUMENT.tableName(), datafileRelativePath);
        String satDocumentFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<SatDocument> satDocumentJavaRDD = sparkSession
                .read()
                .textFile(satDocumentFilePath)
                .javaRDD()
                .map((Function<String, SatDocument>) SatDocument::mapper)
                .cache();

        return sparkSession
                .createDataFrame(satDocumentJavaRDD, SatDocument.class)
                .as(satDocumentEncoder)
                .cache();
    }

}
