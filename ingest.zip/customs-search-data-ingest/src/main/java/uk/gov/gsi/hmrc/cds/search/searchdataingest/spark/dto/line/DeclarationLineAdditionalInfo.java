package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;


@Data
public class DeclarationLineAdditionalInfo implements Serializable {

    public static final Encoder<DeclarationLineAdditionalInfo> declarationLineAdditionalInfoEncoder = Encoders.bean(DeclarationLineAdditionalInfo.class);

    private String hub_additional_info_key;
    private String additional_information_sequence_number;
    private String sat_additional_info_generation_number;
    private String additional_information_statement;
    private String additional_information_statement_type;
    private String item_additional_information_statement;

    public static final String GENERATION_NUMBER = "sat_additional_info_generation_number";
}
