package uk.gov.gsi.hmrc.cds.search.searchdataingest;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.elasticsearch.ESIngester;

import javax.annotation.PostConstruct;

@SpringBootApplication
@Slf4j
public class SearchDataIngestApplication {

    @Autowired
    private ESIngester esIngester;

    public static void main(String[] args) {
        SpringApplication.run(SearchDataIngestApplication.class, args).close();
    }

    @PostConstruct
    public void triggerDVReader() {
        log.info("Starting ingestion job");
        try {
            esIngester.ingest();
            log.info("Job finished without errors");
        } catch (Exception e) {
            log.error("Job finished with errors", e);
        }
    }
}
