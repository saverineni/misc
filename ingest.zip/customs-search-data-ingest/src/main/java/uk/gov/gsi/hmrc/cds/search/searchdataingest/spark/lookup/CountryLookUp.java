package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.lookup;

import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import scala.Tuple2;
import scala.reflect.ClassTag$;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub.HubCountryReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatCountryReader;

import java.util.Map;

@Component
public class CountryLookUp {

    private static final String COUNTRIES_VIEW = "countries";
    private static final String COUNTRIES_SQL = "select iso_country_code_alpha_2, country_name from countries";

    private final SparkSession sparkSession;
    private final HubCountryReader hubCountryReader;
    private final SatCountryReader satCountryReader;

    @Autowired
    public CountryLookUp(SparkSession sparkSession,HubCountryReader hubCountryReader,SatCountryReader satCountryReader) {
        this.sparkSession = sparkSession;
        this.hubCountryReader = hubCountryReader;
        this.satCountryReader = satCountryReader;
    }

    public Broadcast<Map<String, String>> countriesMap() {

        Dataset hubCountryDataset = hubCountryReader.hubCountryDataset();
        Dataset satCountryDataset = satCountryReader.satCountryDataset();

        Dataset countriesAll = hubCountryDataset.join(satCountryDataset, HubCountry.joinColumns);
        countriesAll.createOrReplaceTempView(COUNTRIES_VIEW);

        Dataset<Row> countries = sparkSession.sql(COUNTRIES_SQL);
        Map<String, String> countriesAsMap = countries
                .toJavaRDD()
                .mapToPair(row -> new Tuple2<>(row.getString(0), row.getString(1)))
                .collectAsMap();
        return sparkSession.sparkContext().broadcast(countriesAsMap, ClassTag$.MODULE$.apply(Map.class));
    }
}
