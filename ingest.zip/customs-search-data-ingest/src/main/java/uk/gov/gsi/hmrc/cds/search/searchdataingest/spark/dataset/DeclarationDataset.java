package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset;

import com.google.common.collect.Iterables;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.DeclarationLineDeclarationGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.Declaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.entity.DeclarationHeader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader.DeclarationHeaderReader;

@Component
public class DeclarationDataset {
    private static final String LEFT_OUTER_JOIN = "left_outer";
    private static Column[] selectColumns = Iterables.toArray(Declaration.selectColumns, Column.class);

    private DeclarationHeaderReader declarationHeaderReader;
    private DeclarationLineGroupDataset declarationLineGroupDataset;

    @Autowired
    public DeclarationDataset(DeclarationHeaderReader declarationHeaderReader, DeclarationLineGroupDataset declarationLineGroupDataset) {
        this.declarationHeaderReader = declarationHeaderReader;
        this.declarationLineGroupDataset = declarationLineGroupDataset;
    }

    public Dataset<Declaration> build() {
        Dataset<DeclarationHeader> declarationHeaderDataset = declarationHeaderReader.declarationHeaderDataset();
        Dataset<DeclarationLineDeclarationGroup> lineDeclarationGroupNewDataset = declarationLineGroupDataset.build();

        return lineDeclarationGroupNewDataset
                .join(declarationHeaderDataset, DeclarationHeader.joinColumns, LEFT_OUTER_JOIN)
                .select(selectColumns)
                .as(Declaration.declarationEncoder);
    }
}
