package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.importer.ImporterTrader;

import java.io.Serializable;
import java.util.List;

import static org.apache.spark.sql.functions.column;


@Data
@Builder
public class DeclarationLine implements Serializable {

    public static final Encoder<DeclarationLine> declarationLineEncoder = Encoders.bean(DeclarationLine.class);

    private String hub_declaration_line_key;
    private String entry_reference;
    private String item_number;
    private String clearance_datetime;
    private String item_statistical_value;
    private String customs_duty_paid;
    private String vat_paid;
    private String ec_supplementary_1;
    private String item_customs_value;
    private String item_net_mass;
    private String item_supplementary_units;
    private String goods_description;
    private String item_customs_check_code;
    private String item_mic_code;
    private String item_profile_id;
    private String item_consignor_nad_name;
    private String item_consignee_nad_name;
    private String item_consignee_nad_postcode;
    private String vat_value;
    private String item_price_declared;


    private DeclarationLineCommodity commodity;
    private DeclarationLineOriginCountry originCountry;
    private DeclarationCustomsProcedureCode customsProcedureCode;
    private ImporterTrader importerTrader;
    private List<DeclarationLineDocument> documents = Lists.newArrayList();
    private List<DeclarationLineTaxLine> taxLines = Lists.newArrayList();
    private List<DeclarationLineAdditionalInfo> additionalInfo = Lists.newArrayList();
    private List<DeclarationLinePreviousDocument> previousDocuments = Lists.newArrayList();

    public static List<Column> columns = ImmutableList.of(
            column("entry_reference"),
            column("item_number"),
            column("clearance_datetime"),
            column("item_statistical_value"),
            column("customs_duty_paid"),
            column("vat_paid"),
            column("ec_supplementary_1"),
            column("item_customs_value"),
            column("item_net_mass"),
            column("item_supplementary_units"),
            column("goods_description"),
            column("item_customs_check_code"),
            column("item_mic_code"),
            column("item_profile_id"),
            column("item_consignor_nad_name"),
            column("item_consignee_nad_name"),
            column("item_consignee_nad_postcode"),
            column("vat_value"),
            column("item_price_declared"),
            column("customsProcedureCode"),
            column("documents"),
            column("taxLines"),
            column("additionalInfo"),
            column("previousDocuments"),
            column("commodity"),
            column("originCountry"),
            column("importerTrader")
    );

    public static List<String> columnNames = ImmutableList.of(
            "entry_reference",
            "item_number",
            "clearance_datetime",
            "item_statistical_value",
            "customs_duty_paid",
            "vat_paid",
            "ec_supplementary_1",
            "item_customs_value",
            "item_net_mass",
            "item_supplementary_units",
            "goods_description",
            "item_customs_check_code",
            "item_mic_code",
            "item_profile_id",
            "item_consignor_nad_name",
            "item_consignee_nad_name",
            "item_consignee_nad_postcode",
            "vat_value",
            "item_price_declared",
            "customsProcedureCode",
            "documents",
            "taxLines",
            "additionalInfo",
            "previousDocuments",
            "commodity",
            "originCountry",
            "importerTrader"
    );

}
