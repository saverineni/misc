package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import scala.collection.mutable.Seq;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;

@Data
@Builder
public class HubPreviousDocument implements Serializable, BaseEntity {

    private String hub_previous_document_key;
    private String entry_reference;
    private String item_number;
    private String previous_document_sequence_number;
    private String hub_load_datetime;
    private String hub_record_source;

    public static HubPreviousDocument mapper(String line) {
        List<String> columns = parseLine(line);

        return HubPreviousDocument.builder()
                .hub_previous_document_key(columns.get(0))
                .entry_reference(columns.get(1))
                .item_number(columns.get(2))
                .previous_document_sequence_number(columns.get(3))
                .hub_load_datetime(columns.get(4))
                .hub_record_source(columns.get(5))
                .build();
    }

    public static final String PRIMARY_COLUMN = "hub_previous_document_key";
    public static final String PREVIOUS_DOCUMENT_SEQUENCE_NUMBER = "previous_document_sequence_number";

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            "previous_document_sequence_number"
    );

    public static Seq<String> joinColumns = joinExpression(PRIMARY_COLUMN);

}
