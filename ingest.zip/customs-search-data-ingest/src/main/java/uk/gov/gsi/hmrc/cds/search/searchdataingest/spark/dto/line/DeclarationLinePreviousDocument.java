package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;


@Data
public class DeclarationLinePreviousDocument implements Serializable {

    public static final Encoder<DeclarationLinePreviousDocument> declarationLinePreviousDocumentEncoder = Encoders.bean(DeclarationLinePreviousDocument.class);
    
    private String hub_previous_document_key;
    private String previous_document_sequence_number;
    private String previous_document_reference;
}
