package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;

@Data
@Builder
public class HubCustomsProcedureCode implements Serializable, BaseEntity {

    private String hub_customs_procedure_code_key;
    private String customs_procedure_code;
    private String hub_load_datetime;
    private String hub_record_source;

    public static HubCustomsProcedureCode mapper(String line) {
        List<String> columns = parseLine(line);

        return HubCustomsProcedureCode.builder()
                .hub_customs_procedure_code_key(columns.get(0))
                .customs_procedure_code(columns.get(1))
                .hub_load_datetime(columns.get(2))
                .hub_record_source(columns.get(3))
                .build();
    }

    public static final String PRIMARY_COLUMN = "hub_customs_procedure_code_key";

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            "customs_procedure_code"
    );

}
