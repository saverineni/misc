package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineTaxLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.LINK_DECLARATION_LINE_TAX_LINE;

@Component
public class LinkDeclarationLineTaxLineReader extends DataVaultReader {
    private static final Encoder<LinkDeclarationLineTaxLine> linkDeclarationLineTaxLineEncoder = Encoders.bean(LinkDeclarationLineTaxLine.class);

    public Dataset<LinkDeclarationLineTaxLine> linkDeclarationLineTaxLineDataset() {
        String dataFilePath = String.format("%s/%s", LINK_DECLARATION_LINE_TAX_LINE.tableName(), datafileRelativePath);
        String linkDeclarationLineTaxLineFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<LinkDeclarationLineTaxLine> linkDeclarationLineTaxLineJavaRDD = sparkSession
                .read()
                .textFile(linkDeclarationLineTaxLineFilePath)
                .javaRDD()
                .map((Function<String, LinkDeclarationLineTaxLine>) LinkDeclarationLineTaxLine::mapper)
                .cache();

        return sparkSession
                .createDataFrame(linkDeclarationLineTaxLineJavaRDD, LinkDeclarationLineTaxLine.class)
                .as(linkDeclarationLineTaxLineEncoder)
                .cache();
    }

}
