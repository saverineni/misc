package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineOriginCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationLineOriginCountryReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLineOriginCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLineOriginCountryGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.lookup.CountryLookUp;

import java.util.Map;

import static org.apache.spark.sql.functions.column;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLineOriginCountry.DeclarationLineOriginCountryBuilderGroup;

@Component
public class DeclarationLineOriginCountryDataset {

    private static final String DECLARATION_LINE_KEY = HubDeclarationLine.PRIMARY_COLUMN;

    private final CountryLookUp countryLookUp;
    private final LinkDeclarationLineOriginCountryReader linkDeclarationLineOriginCountryReader;

    @Autowired
    public DeclarationLineOriginCountryDataset(CountryLookUp countryLookUp,LinkDeclarationLineOriginCountryReader linkDeclarationLineOriginCountryReader){
        this.countryLookUp = countryLookUp;
        this.linkDeclarationLineOriginCountryReader = linkDeclarationLineOriginCountryReader;
    }

    public Dataset<DeclarationLineOriginCountryGroup> build() {

        Broadcast<Map<String, String>> countriesBroadcast = countryLookUp.countriesMap();
        Map<String, String> countriesMap = countriesBroadcast.value();

        Dataset<DeclarationLineOriginCountryGroup> linkDeclarationLineOriginCountryDataset = linkDeclarationLineOriginCountryReader.
                linkDeclarationLineOriginCountryDataset()
                .select(column(DECLARATION_LINE_KEY), column(LinkDeclarationLineOriginCountry.ISO_COUNTRY_CODE_COLUMN))
                .withColumnRenamed(LinkDeclarationLineOriginCountry.ISO_COUNTRY_CODE_COLUMN, DeclarationLineOriginCountry.ISO_COUNTRY_CODE)
                .as(DeclarationLineOriginCountry.declarationLineOriginCountryBuilderGroupEncoder)
                .map((MapFunction<DeclarationLineOriginCountryBuilderGroup, DeclarationLineOriginCountryGroup>) value -> DeclarationLineOriginCountryGroup.mapper(value, countriesMap), DeclarationLineOriginCountryGroup.declarationLineOriginCountryGroupEncoder)
                .persist();

        return linkDeclarationLineOriginCountryDataset;

    }
}
