package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.entity;

import lombok.Data;
import scala.collection.mutable.Seq;

import java.io.Serializable;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.entity.BaseEntity.joinExpression;

@Data
public class DeclarationHeader implements Serializable, BaseEntity {
    private static final long serialVersionUID = 1L;

    public static final String PRIMARY_COLUMN = "declarationId";

    private String declarationId;
    private String epuNumber;
    private String entryNumber;
    private String entryDate;
    private String route;
    private String dispatchCountry;
    private String destinationCountry;
    private String consigneeTurn;
    private String consignorTurn;
    private String goodsLocation;
    private String transportModeCode;
    private String consigneeName;
    private String consigneePostcode;
    private String consignorName;
    private String consignorPostcode;

    public static Seq<String> joinColumns = joinExpression(PRIMARY_COLUMN);
}
