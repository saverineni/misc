package uk.gov.gsi.hmrc.cds.search.searchdataingest.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.spark.sql.SparkSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.entity.DeclarationHeader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.entity.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader.DeclarationHeaderReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader.DeclarationLineReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader.ResourceService;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader.SqlReader;

@Configuration
@ComponentScan(basePackages = {
        "uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader"
})
@Slf4j
public class SparkReaderConfig {
    private static final String MSS_DECLARATION_HEADERS_SQL = "sql/mss/declarationHeaders.sql";
    private static final String MSS_DECLARATION_LINES_SQL = "sql/mss/declarationLines.sql";

    @Autowired
    private SparkSession sparkSession;
    @Autowired
    private ResourceService resourceService;

    @Value("${hive.mss.database.name}")
    private String databaseName;

    @Bean
    public DeclarationHeaderReader declarationHeaderReader() {
        SqlReader<DeclarationHeader> headerSqlReader = new SqlReader<>(sparkSession, DeclarationHeader.class);
        return new DeclarationHeaderReader(headerSqlReader, hiveSql(MSS_DECLARATION_HEADERS_SQL));
    }

    @Bean
    public DeclarationLineReader declarationLineReader() {
        SqlReader<DeclarationLine> lineSqlReader = new SqlReader<>(sparkSession, DeclarationLine.class);
        return new DeclarationLineReader(lineSqlReader, hiveSql(MSS_DECLARATION_LINES_SQL));
    }

    private String hiveSql(String sqlTemplatePath) {
        String hiveSqlTemplate = resourceService.getResourceAsString(sqlTemplatePath);
        String defaultDatabaseName = "DATABASE_NAME";
        String hiveSql = hiveSqlTemplate.replaceAll(defaultDatabaseName, databaseName);
        log.debug("Hive Sql {}", hiveSql);
        return hiveSql;
    }
}
