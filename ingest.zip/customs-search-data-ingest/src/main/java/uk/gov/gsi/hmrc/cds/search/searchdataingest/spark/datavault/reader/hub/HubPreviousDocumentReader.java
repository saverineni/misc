package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubPreviousDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.HUB_PREVIOUS_DOCUMENT;

@Component
public class HubPreviousDocumentReader extends DataVaultReader {
    private static final Encoder<HubPreviousDocument> hubPreviousDocumentEncoder = Encoders.bean(HubPreviousDocument.class);

    public Dataset hubPreviousDocumentDataset() {
        String dataFilePath = String.format("%s/%s", HUB_PREVIOUS_DOCUMENT.tableName(), datafileRelativePath);
        String hubPreviousDocumentFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<HubPreviousDocument> hubPreviousDocumentJavaRDD = sparkSession
                .read()
                .textFile(hubPreviousDocumentFilePath)
                .javaRDD()
                .map((Function<String, HubPreviousDocument>) HubPreviousDocument::mapper)
                .cache();

        return sparkSession
                .createDataFrame(hubPreviousDocumentJavaRDD, HubPreviousDocument.class)
                .as(hubPreviousDocumentEncoder)
                .cache();
    }

}
