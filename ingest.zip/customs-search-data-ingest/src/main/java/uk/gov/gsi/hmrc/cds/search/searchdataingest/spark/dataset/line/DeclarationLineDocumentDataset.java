package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationLineDocumentReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatDocumentReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLineDocument;

@Component
public class DeclarationLineDocumentDataset {
    private static final String DECLARATION_LINE_KEY = HubDeclarationLine.PRIMARY_COLUMN;
    private static String[] datasetColumns = Iterables.toArray(
            Iterables.concat(
                    Lists.newArrayList(HubDocument.PRIMARY_COLUMN,DeclarationLineDocument.GENERATION_NUMBER),
                    HubDocument.SELECT_COLUMNS,
                    SatDocument.SELECT_COLUMNS
            )
            , String.class);

    private final SatDocumentReader satDocumentReader;
    private final LinkDeclarationLineDocumentReader linkDeclarationLineDocumentReader;

    @Autowired
    public DeclarationLineDocumentDataset(SatDocumentReader satDocumentReader,LinkDeclarationLineDocumentReader linkDeclarationLineDocumentReader) {
        this.satDocumentReader = satDocumentReader;
        this.linkDeclarationLineDocumentReader = linkDeclarationLineDocumentReader;
    }

    public Dataset<DeclarationLineDocument> build() {
        Dataset<SatDocument> satDocumentDataset = satDocumentReader.satDocumentDataset();
        Dataset linkDeclarationLineDocumentDataset = linkDeclarationLineDocumentReader.linkDeclarationLineDocumentDataset();

        Dataset<DeclarationLineDocument> declarationLineDocuments = linkDeclarationLineDocumentDataset
                .join(satDocumentDataset, HubDocument.joinColumns)
                .withColumnRenamed(SatDocument.GENERATION_NUMBER_COLUMN, DeclarationLineDocument.GENERATION_NUMBER)
                .select(DECLARATION_LINE_KEY, datasetColumns)
                .as(DeclarationLineDocument.declarationLineDocumentEncoder)
                .cache();

        linkDeclarationLineDocumentDataset.unpersist();
        satDocumentDataset.unpersist();

        return declarationLineDocuments;
    }
}
