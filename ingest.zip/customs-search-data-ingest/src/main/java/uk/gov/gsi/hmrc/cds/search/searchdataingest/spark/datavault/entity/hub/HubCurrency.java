package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import scala.collection.mutable.Seq;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;

@Data
@Builder
public class HubCurrency implements Serializable, BaseEntity {
    private String hub_currency_key;
    private String currency_iso_code;
    private String hub_load_datetime;
    private String hub_record_source;

    public static HubCurrency mapper(String line) {
        List<String> columns = parseLine(line);
        return HubCurrency.builder()
                .hub_currency_key(columns.get(0))
                .currency_iso_code(columns.get(1))
                .hub_load_datetime(columns.get(2))
                .hub_record_source(columns.get(3))
                .build();
    }

    public static final String PRIMARY_COLUMN = "hub_currency_key";

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            "currency_iso_code"
    );

    public static Seq<String> joinColumns = joinExpression(PRIMARY_COLUMN);

}
