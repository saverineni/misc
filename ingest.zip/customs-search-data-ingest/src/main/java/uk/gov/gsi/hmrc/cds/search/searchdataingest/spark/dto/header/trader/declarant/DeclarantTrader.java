package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.declarant;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;


@Data
public class DeclarantTrader implements Serializable {
    public static Encoder<DeclarantTrader> declarantTraderEncoder = Encoders.bean(DeclarantTrader.class);
    private String declarant_trader_turn;
    private String name;
    private String simplified_procedure_authorisations;
    private String trader_name_abbreviated;
    private String current_ind;

    public static final String DECLARANT_TRADER_TURN = "declarant_trader_turn";

}
