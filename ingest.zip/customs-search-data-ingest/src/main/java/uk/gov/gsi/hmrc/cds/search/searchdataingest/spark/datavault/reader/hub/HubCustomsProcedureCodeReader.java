package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubCustomsProcedureCode;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.HUB_CUSTOMS_PROCEDURE_CODE;

@Component
public class HubCustomsProcedureCodeReader extends DataVaultReader {
    private static final Encoder<HubCustomsProcedureCode> hubCustomsProcedureCodeEncoder = Encoders.bean(HubCustomsProcedureCode.class);

    public Dataset hubCustomsProcedureCodeDataset() {
        String dataFilePath = String.format("%s/%s", HUB_CUSTOMS_PROCEDURE_CODE.tableName(), datafileRelativePath);
        String hubCustomsProcedureCodeFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<HubCustomsProcedureCode> hubCustomsProcedureCodeJavaRDD = sparkSession
                .read()
                .textFile(hubCustomsProcedureCodeFilePath)
                .javaRDD()
                .map((Function<String, HubCustomsProcedureCode>) HubCustomsProcedureCode::mapper)
                .cache();

        return sparkSession
                .createDataFrame(hubCustomsProcedureCodeJavaRDD, HubCustomsProcedureCode.class)
                .as(hubCustomsProcedureCodeEncoder)
                .cache();
    }

}
