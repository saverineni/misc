package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.HUB_CURRENCY;

@Component
public class HubCurrencyReader extends DataVaultReader {
    private static final Encoder<HubCurrency> hubCurrencyEncoder = Encoders.bean(HubCurrency.class);

    public Dataset<HubCurrency> hubCurrencyDataset() {
        String dataFilePath = String.format("%s/%s", HUB_CURRENCY.tableName(), datafileRelativePath);
        String hubCurrencyFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<HubCurrency> hubCurrencyJavaRDD = sparkSession
                .read()
                .textFile(hubCurrencyFilePath)
                .javaRDD()
                .map((Function<String, HubCurrency>) HubCurrency::mapper)
                .cache();

        return sparkSession
                .createDataFrame(hubCurrencyJavaRDD, HubCurrency.class)
                .as(hubCurrencyEncoder)
                .cache();
    }

}
