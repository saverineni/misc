package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;

@Data
@Builder
public class LinkDeclarationLineTaxLine implements Serializable, BaseEntity {

    private String link_declaration_line_tax_line_key;
    private String hub_tax_line_key;
    private String hub_declaration_line_key;
    private String entry_reference;
    private String item_number;
    private String tax_line_sequence_number;
    private String link_load_datetime;
    private String link_record_source;

    public static LinkDeclarationLineTaxLine mapper(String line) {
        List<String> columns = parseLine(line);

        return LinkDeclarationLineTaxLine.builder()
                .link_declaration_line_tax_line_key(columns.get(0))
                .hub_tax_line_key(columns.get(1))
                .hub_declaration_line_key(columns.get(2))
                .entry_reference(columns.get(3))
                .item_number(columns.get(4))
                .tax_line_sequence_number(columns.get(5))
                .link_load_datetime(columns.get(6))
                .link_record_source(columns.get(7))
                .build();
    }

    public static final String PRIMARY_COLUMN = "link_declaration_line_tax_line_key";

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            "hub_tax_line_key",
            "hub_declaration_line_key"
    );
}
