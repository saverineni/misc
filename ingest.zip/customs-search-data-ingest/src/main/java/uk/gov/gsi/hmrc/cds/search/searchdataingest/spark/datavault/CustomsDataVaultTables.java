package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault;

public enum CustomsDataVaultTables {

    HUB_DECLARATION("hub_declaration"),
    SAT_DECLARATION("sat_declaration"),
    LINK_DECLARATION_IMPORTER_TRADER("link_declaration_importer_trader"),
    LINK_DECLARATION_DECLARANT_TRADER("link_declaration_declarant_trader"),
    LINK_DECLARATION_EXPORTER_TRADER("link_declaration_exporter_trader"),
    LINK_DECLARATION_CONSIGNOR_TRADER("link_declaration_consignor_trader"),
    LINK_DECLARATION_PAYING_AGENT_TRADER("link_declaration_paying_agent_trader"),
    LINK_DECLARATION_TRANSPORT_COUNTRY("link_declaration_transport_country"),
    LINK_DECLARATION_DESTINATION_COUNTRY("link_declaration_destination_country"),
    LINK_DECLARATION_INVOICE_CURRENCY("link_declaration_invoice_currency"),
    LINK_DECLARATION_FREIGHT_CURRENCY("link_declaration_freight_currency"),
    HUB_DECLARATION_LINE("hub_declaration_line"),
    SAT_DECLARATION_LINE("sat_declaration_line"),
    LINK_DECLARATION_LINE_DECLARATION("link_declaration_line_declaration"),
    LINK_DECLARATION_LINE_ORIGIN_COUNTRY("link_declaration_line_origin_country"),
    LINK_DECLARATION_LINE_COMMODITY("link_declaration_line_commodity"),
    LINK_DECLARATION_LINE_CUSTOMS_PROCEDURE_CODE("link_declaration_line_customs_procedure_code"),
    LINK_DECLARATION_LINE_TAX_LINE("link_declaration_line_tax_line"),
    LINK_DECLARATION_LINE_DOCUMENT("link_declaration_line_document"),
    LINK_DECLARATION_LINE_PREVIOUS_DOCUMENT("link_declaration_line_previous_document"),
    LINK_DECLARATION_LINE_ADDITIONAL_INFO("link_declaration_line_additional_info"),
    LINK_DECLARATION_LINE_IMPORTER_TRADER("link_declaration_line_importer_trader"),
    HUB_COMMODITY("hub_commodity"),
    SAT_COMMODITY("sat_commodity"),
    HUB_CUSTOMS_PROCEDURE_CODE("hub_customs_procedure_code"),
    HUB_TRADER("hub_trader"),
    SAT_TRADER("sat_trader"),
    HUB_DOCUMENT("hub_document"),
    SAT_DOCUMENT("sat_document"),
    HUB_PREVIOUS_DOCUMENT("hub_previous_document"),
    SAT_PREVIOUS_DOCUMENT("sat_previous_document"),
    HUB_TAX_LINE("hub_tax_line"),
    SAT_TAX_LINE("sat_tax_line"),
    HUB_ADDITIONAL_INFO("hub_additional_info"),
    SAT_ADDITIONAL_INFO("sat_additional_info"),
    HUB_CURRENCY("hub_currency"),
    SAT_CURRENCY("sat_currency"),
    HUB_COUNTRY("hub_country"),
    SAT_COUNTRY("sat_country");

    private String tableName;

    CustomsDataVaultTables(String tableName) {
        this.tableName = tableName;
    }

    public String tableName() {
        return tableName;
    }
}
