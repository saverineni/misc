package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.header.trader;

import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationImporterTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationImporterTraderReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatTraderReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.importer.DeclarationHeaderImporterTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.importer.ImporterTrader;

import static org.apache.spark.sql.functions.broadcast;
import static org.apache.spark.sql.functions.column;

@Component
@Qualifier("DeclarationHeaderImporterTraderDataset")
public class DeclarationHeaderImporterTraderDataset implements TraderDataset {

    private static final String LEFT_OUTER_JOIN = "left_outer";
    private final LinkDeclarationImporterTraderReader linkDeclarationImporterTraderReader;
    private final SatTraderReader satTraderReader;

    @Autowired
    public DeclarationHeaderImporterTraderDataset(LinkDeclarationImporterTraderReader linkDeclarationImporterTraderReader, SatTraderReader satTraderReader) {
        this.linkDeclarationImporterTraderReader = linkDeclarationImporterTraderReader;
        this.satTraderReader = satTraderReader;
    }

    public Dataset<DeclarationHeaderImporterTrader> build() {
        Dataset<LinkDeclarationImporterTrader> linkDeclarationImporterTraderDataset = linkDeclarationImporterTraderReader.linkDeclarationImporterTraderDataset();
        Dataset<SatTrader> satTraderDataset = satTraderReader.satTraderDataset();

        Dataset<DeclarationHeaderImporterTrader> headerImporterTraderDataset = linkDeclarationImporterTraderDataset
                .select(HubDeclaration.PRIMARY_COLUMN, hubTraderDatasetColumns)
                .join(broadcast(satTraderDataset), HubTrader.joinColumns, LEFT_OUTER_JOIN)
                .select(HubDeclaration.PRIMARY_COLUMN, headerTraderDatasetColumns)
                .withColumnRenamed(HubTrader.TURN_COLUMN, ImporterTrader.IMPORTER_TRADER_TURN)
                .select(
                        column(HubDeclaration.PRIMARY_COLUMN),
                        traderDetails(ImporterTrader.IMPORTER_TRADER_TURN).alias(DeclarationHeaderImporterTrader.ALIAS)
                )
                .as(DeclarationHeaderImporterTrader.declarationHeaderImporterTraderEncoder);

        linkDeclarationImporterTraderDataset.unpersist();

        return headerImporterTraderDataset;
    }
}
