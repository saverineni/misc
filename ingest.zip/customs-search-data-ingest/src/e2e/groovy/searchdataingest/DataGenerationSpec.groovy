package searchdataingest

import org.apache.http.client.fluent.Request

import groovy.json.JsonSlurper
import spock.lang.Ignore
import spock.lang.Shared
import spock.lang.Specification

class DataGenerationSpec extends Specification {
    @Shared Map jsonResponse

    def setupSpec() {
        jsonResponse = new ESClient().countResponse()
    }

    def "transformed data should be added to elasticsearch"() {
        when: 'document count is read'
        def count = jsonResponse.count

        then:
        count == 4
    }
}
