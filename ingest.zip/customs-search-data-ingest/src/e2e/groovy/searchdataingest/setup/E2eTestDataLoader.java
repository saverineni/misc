package searchdataingest.setup;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.apache.spark.sql.SparkSession;


public class E2eTestDataLoader {

    static String mssSourceFilePath = "/mss/ingestion-pipeline-output";

    public static void main(String[] args) throws Exception {
        new E2eTestDataLoader().ingestData();
    }

    private SparkSession sparkSession = SparkSession.builder()
                                            .appName("data-ingest")
                                            .enableHiveSupport().getOrCreate();

    private String DATABASE_NAME = "search";

    public void ingestData() throws IOException {
        sparkSession.sql("DROP DATABASE IF EXISTS " + DATABASE_NAME + " CASCADE");
        sparkSession.sql("CREATE DATABASE IF NOT EXISTS " + DATABASE_NAME);
        sparkSession.sql(getDdlFor("imenselect"));
        sparkSession.sql(getDdlFor("imendetail"));
        sparkSession.sql(getDdlFor("imeiselect"));
        sparkSession.sql(getDdlFor("inad"));
        sparkSession.sql(getDdlFor("iica"));
        sparkSession.sql(getDdlFor("iina"));
        sparkSession.sql(getDdlFor("nxenselect"));
        sparkSession.sql(getDdlFor("nxendetail"));
        sparkSession.sql(getDdlFor("nxeiselect"));
        sparkSession.sql(getDdlFor("nxeidetail"));
        sparkSession.sql(getDdlFor("nxnad"));
        sparkSession.sql(getDdlFor("nxica"));
        sparkSession.sql(getDdlFor("nxina"));

        loadDataFor("imenselect");
        loadDataFor("imendetail");
        loadDataFor("imeiselect");
        loadDataFor("inad");
        loadDataFor("iica");
        loadDataFor("iina");
        loadDataFor("nxenselect");
        loadDataFor("nxendetail");
        loadDataFor("nxeiselect");
        loadDataFor("nxeidetail");
        loadDataFor("nxnad");
        loadDataFor("nxica");
        loadDataFor("nxina");
    }

    private String getDdlFor(String tableName) throws IOException {
        return IOUtils.toString(new File("/mss/ddl/" + tableName + ".sql").toURI());
    }

    private void loadDataFor(String tableName) {
        String sqlFormat = "load data local inpath '%s/%s/part-00000' overwrite into table %s.%s";
        sparkSession.sql(String.format(sqlFormat, mssSourceFilePath, tableName, DATABASE_NAME, tableName));
    }
}
