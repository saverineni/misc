package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.DatasetSuiteIT;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader.MssReaderSuiteIT;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        MssReaderSuiteIT.class,
        DatasetSuiteIT.class
})
public class SparkSuiteIntegrationTest {
}
