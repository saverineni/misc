package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset;

import org.apache.spark.api.java.function.ForeachFunction;
import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.DeclarationLineDeclarationGroup;

import java.util.Arrays;
import java.util.List;

import static org.apache.hadoop.hdfs.server.namenode.ListPathsServlet.df;
import static org.apache.spark.sql.functions.col;
import static org.apache.spark.sql.functions.explode;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

public class DeclarationLineGroupDatasetIT extends SparkTest {

    @Autowired
    DeclarationLineGroupDataset lineGroupDatasetNew;

    @Test
    public void verifyTheSchemaAndCount() {
        Dataset<DeclarationLineDeclarationGroup> dataset = lineGroupDatasetNew.build();
        String[] actualFieldNames = dataset.schema().fieldNames();
        assertThat(Arrays.asList(actualFieldNames), contains("declarationId", "lines"));

        String[] actualLineFieldNames = dataset
                .select(explode(col("lines")).as("linesAll"))
                .select(col("linesAll.*"))
                .schema()
                .fieldNames();

        assertThat(expectedDeclarationLine, contains(actualLineFieldNames));
        assertThat(dataset.count(), is(equalTo(4L))); // equal to Header count
    }

    @Test
    public void declarationLinesAreSortedByItemNumber() {
        Dataset<DeclarationLineDeclarationGroup> dataset = lineGroupDatasetNew.build();

        Dataset<DeclarationLineDeclarationGroup> lineDeclarationGroupDataset = dataset.filter(col("declarationId").equalTo("IM002"));

        lineDeclarationGroupDataset.show(false);

        Dataset<Row> rowDataset = dataset.select(explode(col("lines")).as("lines_explode"));
        rowDataset.show(false);


//        List<Row> collectAsList = dataset.filter(col("itemNumber").equalTo("1")).selectExpr("lines").collectAsList();
//
//        dataset.select(explode(col(LINES)).as(LINES_EXPLODE))
//                .select(col(ORIGIN_COUNTRY_EXPLODE_FIELD_NAME))
//                .schema().apply(ORIGIN_COUNTRY_FIELD_NAME);
//
//        System.out.println(collectAsList.get(0).size());
//
//        System.out.println(collectAsList.get(0).get(0).size());

    }
}