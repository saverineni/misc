package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatCommodity;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatCommodityReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class SatCommodityReaderTest extends SparkTest {

    @Autowired
    SatCommodityReader satCommodityReader;

    @Test
    public void buildsSatCommodityDataset() throws Exception {
        final Dataset<SatCommodity> satCommodityDataset = satCommodityReader.satCommodityDataset();
        assertThat(satCommodityDataset.count(), is(greaterThan(0l)));

        satCommodityDataset.printSchema();
        final String[] fieldNames = satCommodityDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(satCommodityStructFields));

        final String[] selectedFieldNames = satCommodityDataset.selectExpr(joinExpression(SatCommodity.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(satCommoditySelectedStructFields));
    }

    private String[] satCommodityStructFields = toArray(
            Lists.newArrayList("cc_month",
                    "cc_year",
                    "chapter_description",
                    "heading_description",
                    "hs_chapter",
                    "hs_chapter_heading",
                    "hs_heading",
                    "hs_subheading",
                    "hub_commodity_key",
                    "sat_hash_diff",
                    "sat_load_datetime",
                    "sat_load_end_datetime",
                    "sat_record_source",
                    "subheading_description")
    );

    private String[] satCommoditySelectedStructFields = toArray(
            Lists.newArrayList("cc_year",
                    "cc_month",
                    "hs_chapter",
                    "hs_heading",
                    "hs_chapter_heading",
                    "hs_subheading",
                    "chapter_description",
                    "heading_description",
                    "subheading_description")
    );
}


