package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLinePreviousDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationLinePreviousDocumentReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class LinkDeclarationLinePreviousDocumentReaderTest extends SparkTest {

    @Autowired
    LinkDeclarationLinePreviousDocumentReader linkDeclarationLinePreviousDocumentReader;

    @Test
    public void buildsLinkDeclarationLinePreviousDocumentDataset() throws Exception {
        final Dataset<LinkDeclarationLinePreviousDocument> linkDeclarationLinePreviousDocumentDataset = linkDeclarationLinePreviousDocumentReader.linkDeclarationLinePreviousDocumentDataset();
        assertThat(linkDeclarationLinePreviousDocumentDataset.count(), is(greaterThan(0l)));

        linkDeclarationLinePreviousDocumentDataset.printSchema();
        final String[] fieldNames = linkDeclarationLinePreviousDocumentDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(linkDeclarationLinePreviousDocumentStructFields));

        final String[] selectedFieldNames = linkDeclarationLinePreviousDocumentDataset.select(LinkDeclarationLinePreviousDocument.PRIMARY_COLUMN , joinExpression(LinkDeclarationLinePreviousDocument.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(linkDeclarationLinePreviousDocumentSelectedStructFields));
    }

    private String[] linkDeclarationLinePreviousDocumentStructFields = toArray(
            Lists.newArrayList("entry_reference",
                    "hub_declaration_line_key",
                    "hub_previous_document_key",
                    "item_number",
                    "link_declaration_line_previous_document_key",
                    "link_load_datetime",
                    "link_record_source",
                    "previous_document_sequence_number")
    );

    private String[] linkDeclarationLinePreviousDocumentSelectedStructFields = toArray(
            Lists.newArrayList("link_declaration_line_previous_document_key",
                    "hub_declaration_line_key",
                    "hub_previous_document_key")
    );
}

