package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class SqlReaderTest {

    public class TestEntity {}

    private static final String SQL = "sql";

    @Rule
    public ExpectedException exception = ExpectedException.none();

    SparkSession sparkSession = mock(SparkSession.class);
    SqlReader<TestEntity> reader = new SqlReader<>(sparkSession, TestEntity.class);

    @Test
    public void shouldReturnDataSetForGivenSql() {
        Dataset<TestEntity> expectedResult = mock(Dataset.class);
        Dataset<Row> row = mock(Dataset.class);

        when(sparkSession.sql(SQL)).thenReturn(row);
        when(row.as(Encoders.bean(TestEntity.class))).thenReturn(expectedResult);

        Dataset<TestEntity> result = reader.buildDataset(SQL);

        assertThat(result, is(expectedResult));
    }

    @Test
    public void shouldThrowCustomNullPointerExceptionForNullSQL() {
        exception.expect(NullPointerException.class);
        exception.expectMessage("Hive sql cannot be null");

        reader.buildDataset(null);
    }
}
