package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader;


import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        DeclarationHeaderReaderIT.class,
        DeclarationLineReaderIT.class
})
public class MssReaderSuiteIT {

}
