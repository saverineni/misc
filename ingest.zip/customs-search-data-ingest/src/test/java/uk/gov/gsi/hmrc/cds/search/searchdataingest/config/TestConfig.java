package uk.gov.gsi.hmrc.cds.search.searchdataingest.config;

import com.google.common.io.Resources;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({
        SparkConfig.class,
        ReaderConfig.class,
        DatasetConfig.class
})
public class TestConfig {

    @Bean
    public String datafileRelativePath() {
        return "data";
    }

    @Bean
    public String dataVaultHDFSBasePath() {
        return Resources.getResource("dv").getPath();
    }
}
