package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

import org.apache.spark.sql.Dataset;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.entity.DeclarationLine;

public class DeclarationLineReaderIT extends SparkTest {

    @Autowired
    private DeclarationLineReader declarationLineReader;

    private static final String IMPORT_HEADER_ID = "IM001";
    private static final int IMPORT_ITEM_NO = 1;

    private static final String EXPORT_HEADER_ID = "EX002";
    private static final int EXPORT_ITEM_NO = 2;

    private Dataset<DeclarationLine> declarationLineDataset;

    @Before
    public void setUp() {
        declarationLineDataset = declarationLineReader.declarationLineDataset();
    }

    @Test
    public void loadingLines() {
        assertThat(declarationLineDataset.count(), is(equalTo(6L)));
    }

    @Test
    public void mappingImportLine() {
        DeclarationLine line = getLine(IMPORT_HEADER_ID, IMPORT_ITEM_NO);
        assertThat(line.getDeclarationId(), is(equalTo(IMPORT_HEADER_ID)));
        assertThat(line.getItemNumber(), is(IMPORT_ITEM_NO));
        assertThat(line.getDispatchCountryCode(), is("COUNTRY01"));
        assertThat(line.getDestinationCountryCode(), is(nullValue()));
        assertThat(line.getClearanceDate(), is("2018-02-01 00:00:00.00"));
        assertThat(line.getCpc(), is("CPC01"));
        assertThat(line.getOriginCountryCode(), is("COUNTRY99"));
        assertThat(line.getCommodityCode(), is("COMMODITY01"));
        assertThat(line.getItemConsigneeTurn(), is("ITEMCONSIGNEE01"));
        assertThat(line.getItemConsignorTurn(), is("ITEMCONSIGNOR01"));
        assertThat(line.getItemRoute(), is("ITEMROE-IM001-01"));
        assertThat(line.getItemConsigneeName(), is("ITEMCONSIGNEENAME-IM001-01"));
        assertThat(line.getItemConsigneePostcode(), is("ITEMCONSIGNEEPOSTCODE-IM001-01"));
        assertThat(line.getItemConsignorName(), is("ITEMCONSIGNORNAME-IM001-01"));
        assertThat(line.getItemConsignorPostcode(), is("ITEMCONSIGNORPOSTCODE-IM001-01"));
    }

    @Test
    public void mappingExportLine() {
        DeclarationLine line = getLine(EXPORT_HEADER_ID, EXPORT_ITEM_NO);
        assertThat(line.getDeclarationId(), is(equalTo(EXPORT_HEADER_ID)));
        assertThat(line.getItemNumber(), is(EXPORT_ITEM_NO));
        assertThat(line.getDispatchCountryCode(), is("ITEMDISPATCHCOUNTRY03"));
        assertThat(line.getDestinationCountryCode(), is("ITEMDESTCOUNTRY03"));
        assertThat(line.getClearanceDate(), is("2018-02-02 00:00:00.00"));
        assertThat(line.getCpc(), is("CPC03"));
        assertThat(line.getOriginCountryCode(), is("COUNTRY97"));
        assertThat(line.getCommodityCode(), is("COMMODITY03"));
        assertThat(line.getItemConsigneeTurn(), is("ITEMCONSIGNEE03"));
        assertThat(line.getItemConsignorTurn(), is("ITEMCONSIGNOR03"));
        assertThat(line.getItemRoute(), is("ITEMROE-EX002-02"));
        assertThat(line.getItemConsigneeName(), is("ITEMCONSIGNEENAME-EX002-02"));
        assertThat(line.getItemConsigneePostcode(), is("ITEMCONSIGNEEPOSTCODE-EX002-02"));
        assertThat(line.getItemConsignorName(), is("ITEMCONSIGNORNAME-EX002-02"));
        assertThat(line.getItemConsignorPostcode(), is("ITEMCONSIGNORPOSTCODE-EX002-02"));
    }

    private DeclarationLine getLine(String id, int itemNo) {
        Dataset<DeclarationLine> filter = declarationLineDataset.filter((DeclarationLine l) -> l.getDeclarationId().equals(id) && l.getItemNumber() == itemNo);
        assertThat(filter.count(), is(1L));
        return filter.first();
    }
}