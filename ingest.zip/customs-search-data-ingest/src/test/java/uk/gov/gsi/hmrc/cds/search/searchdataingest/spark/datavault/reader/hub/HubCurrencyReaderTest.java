package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub.HubCurrencyReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class HubCurrencyReaderTest extends SparkTest {

    @Autowired
    HubCurrencyReader hubCurrencyReader;

    @Test
    public void buildsHubCurrencyDataset() throws Exception {
        final Dataset<HubCurrency> hubCurrencyDataset = hubCurrencyReader.hubCurrencyDataset();
        assertThat(hubCurrencyDataset.count(), is(greaterThan(0l)));

        hubCurrencyDataset.printSchema();
        final String[] fieldNames = hubCurrencyDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(hubCurrencyStructFields));

        final String[] selectedFieldNames = hubCurrencyDataset.select(HubCurrency.PRIMARY_COLUMN , joinExpression(HubCurrency.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(hubCurrencySelectedStructFields));
    }

    private static String[] hubCurrencyStructFields = toArray(
            Lists.newArrayList("currency_iso_code",
                    "hub_currency_key",
                    "hub_load_datetime",
                    "hub_record_source")
    );

    private static String[] hubCurrencySelectedStructFields = toArray(
            Lists.newArrayList("hub_currency_key",
                    "currency_iso_code")
    );
}

