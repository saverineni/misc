package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader;

import org.apache.spark.sql.Dataset;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.entity.DeclarationHeader;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.nullValue;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class DeclarationHeaderReaderIT extends SparkTest {

    @Autowired
    private DeclarationHeaderReader declarationHeaderReader;

    private static final String IMPORT_HEADER_ID = "IM001";
    private static final String EXPORT_HEADER_ID = "EX002";

    private Dataset<DeclarationHeader> declarationHeaderDataset;

    @Before
    public void setUp() {
        declarationHeaderDataset = declarationHeaderReader.declarationHeaderDataset();
    }

    @Test
    public void loadingHeaders() {
        assertThat(declarationHeaderDataset.count(), is(4L));
    }

    @Test
    public void mappingImportHeader() {
        DeclarationHeader header = getHeader(IMPORT_HEADER_ID);
        assertThat(header.getDeclarationId(), is(equalTo(IMPORT_HEADER_ID)));
        assertThat(header.getEpuNumber(), is("EPU01"));
        assertThat(header.getEntryNumber(), is("ENTRY001"));
        assertThat(header.getEntryDate(), is("2018-01-01 00:00:00.00"));
        assertThat(header.getRoute(), is("ROE01"));
        assertThat(header.getDispatchCountry(), is("COUNTRY01"));
        assertThat(header.getDestinationCountry(), is(nullValue()));
        assertThat(header.getConsigneeTurn(), is("CONSIGNEE01"));
        assertThat(header.getConsignorTurn(), is("CONSIGNOR01"));
        assertThat(header.getGoodsLocation(), is("GOODSLOC01"));
        assertThat(header.getTransportModeCode(), is("TRANSPORTMODE01"));
        assertThat(header.getConsigneeName(), is("CONSIGNEENAME01"));
        assertThat(header.getConsigneePostcode(), is("CONSIGNEEPOSTCODE01"));
        assertThat(header.getConsignorName(), is("CONSIGNORNAME01"));
        assertThat(header.getConsignorPostcode(), is("CONSIGNORPOSTCODE01"));
    }

    @Test
    public void mappingExportHeader() {
        DeclarationHeader header = getHeader(EXPORT_HEADER_ID);
        assertThat(header.getDeclarationId(), is(equalTo(EXPORT_HEADER_ID)));
        assertThat(header.getEpuNumber(), is("EPU02"));
        assertThat(header.getEntryNumber(), is("ENTRY002"));
        assertThat(header.getEntryDate(), is("2018-01-02 00:00:00.00"));
        assertThat(header.getGoodsLocation(), is("GOODSLOC02"));
        assertThat(header.getRoute(), is("ROE02"));
        assertThat(header.getDispatchCountry(), is("COUNTRY02"));
        assertThat(header.getDestinationCountry(), is("DESTCOUNTRY02"));
        assertThat(header.getConsigneeTurn(), is("CONSIGNEE02"));
        assertThat(header.getConsignorTurn(), is("CONSIGNOR02"));
        assertThat(header.getTransportModeCode(), is("TRANSPORTMODE02"));
        assertThat(header.getConsigneeName(), is("CONSIGNEENAME02"));
        assertThat(header.getConsigneePostcode(), is("CONSIGNEEPOSTCODE02"));
        assertThat(header.getConsignorName(), is("CONSIGNORNAME02"));
        assertThat(header.getConsignorPostcode(), is("CONSIGNORPOSTCODE02"));
    }

    private DeclarationHeader getHeader(String id) {
        Dataset<DeclarationHeader> filter = declarationHeaderDataset.filter((DeclarationHeader h) -> h.getDeclarationId().equals(id));
        assertThat(filter.count(), is(1L));
        return filter.first();
    }
}
