package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationDestinationCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationDestinationCountryReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;

public class LinkDeclarationDestinationCountryReaderTest extends SparkTest {

    @Autowired
    LinkDeclarationDestinationCountryReader linkDeclarationDestinationCountryReader;

    @Test
    public void buildsLinkDeclarationDeclarantTraderDataset() throws Exception {
        final Dataset<LinkDeclarationDestinationCountry> linkDeclarationDestinationCountryDataset = linkDeclarationDestinationCountryReader.linkDeclarationDestinationCountryDataset();
        assertThat(linkDeclarationDestinationCountryDataset.count(), is(greaterThan(0l)));

        linkDeclarationDestinationCountryDataset.printSchema();
        final String[] fieldNames = linkDeclarationDestinationCountryDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(linkDeclarationDestinationCountryStructFields));

        final String[] selectedFieldNames = linkDeclarationDestinationCountryDataset.select(LinkDeclarationDestinationCountry.PRIMARY_COLUMN , joinExpression(LinkDeclarationDestinationCountry.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(linkDeclarationDestinationCountrySelectedStructFields));
    }

    private String[] linkDeclarationDestinationCountryStructFields = toArray(
            Lists.newArrayList("entry_reference",
                    "hub_country_key",
                    "hub_declaration_key",
                    "iso_country_code_alpha_2",
                    "link_declaration_destination_country_key",
                    "link_load_datetime",
                    "link_record_source")
    );

    private String[] linkDeclarationDestinationCountrySelectedStructFields = toArray(
            Lists.newArrayList("link_declaration_destination_country_key",
                    "hub_declaration_key",
                    "hub_country_key")
    );
}
