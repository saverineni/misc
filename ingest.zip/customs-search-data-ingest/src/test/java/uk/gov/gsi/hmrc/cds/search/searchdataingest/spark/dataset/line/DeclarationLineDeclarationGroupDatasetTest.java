package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.DeclarationLineDeclarationGroupDataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.DeclarationStructure;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.DeclarationLineDeclarationGroup;

import java.util.Arrays;

import static org.apache.spark.sql.functions.*;
import static org.apache.spark.sql.functions.not;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertEquals;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.TestConstants.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class DeclarationLineDeclarationGroupDatasetTest extends SparkTest implements DeclarationStructure {

    @Autowired
    private DeclarationLineDeclarationGroupDataset declarationLineDeclarationGroupDataset;

    private Dataset<DeclarationLineDeclarationGroup> dataset;

    @Before
    public void build(){
        dataset = declarationLineDeclarationGroupDataset.build();
    }

    @After
    public void cleanup() {
        dataset.unpersist();
    }

    @Test
    public void validateDeclarationLineDeclarationGroupFields() {
        final String[] fieldNames = dataset.schema().fieldNames();

        long linesCount = dataset.select(size(column(LINES))
                                .as(LINES_LIST))
                                .agg(sum(column(LINES_LIST)))
                                .first().getAs(0);

        assertThat(Arrays.asList(fieldNames), contains(declarationLineDeclarationGroupStructFields));
        assertThat(linesCount, is(equalTo(DECLARATION_LINE_COUNT)));

    }

    @Test
    public void validateDeclarationLineFields() {
        String[] fieldNames = dataset.select(explode(col(LINES)).as(LINES_EXPLODE))
                .select(col(LINES_EXPLODE_ALL_FIELDS))
                .schema().fieldNames();

        assertThat(Arrays.asList(fieldNames), contains(declarationLineDeclarationStructFields));
    }

    @Test
    public void validateDeclarationLineDocumentGroupFields() {
        final StructField lineDocumentStructFieldType = dataset.select(explode(col(LINES)).as(LINES_EXPLODE))
                                                            .select(explode(col(DOCUMENT_EXPLODE_FIELD_NAME)).as(STRUCT_ELEMENT_FIELD_NAME))
                                                            .schema().apply(STRUCT_ELEMENT_FIELD_NAME);

        assertEquals(new StructField(STRUCT_ELEMENT_FIELD_NAME, DataTypes.createStructType(declarationLineDocumentStructType()), TRUE,
                Metadata.empty()), lineDocumentStructFieldType);


        long linesDocumentCount = dataset
                .select(explode(col(LINES)).as(LINES_EXPLODE))
                .select(size(column(DOCUMENT_EXPLODE_FIELD_NAME)).as(LINES_DOCUMENTS_LIST))
                        .agg(sum(column(LINES_DOCUMENTS_LIST)))
                        .first().getAs(0);

        assertThat(linesDocumentCount, is(equalTo(DECLARATION_LINE_DOCUMENT_COUNT)));
    }

    @Test
    public void validateDeclarationLineAdditionalInfoGroupFields() {
        final StructField lineAdditionalInfoStructFieldType = dataset.select(explode(col(LINES)).as(LINES_EXPLODE))
                .select(explode(col(ADDITONAL_INFO_EXPLODE_FIELD_NAME)).as(STRUCT_ELEMENT_FIELD_NAME))
                .schema().apply(STRUCT_ELEMENT_FIELD_NAME);

        assertEquals(new StructField(STRUCT_ELEMENT_FIELD_NAME, DataTypes.createStructType(declarationLineAdditionalInfoStructType()), TRUE,
                Metadata.empty()), lineAdditionalInfoStructFieldType);


        long linesAdditionalInfoCount = dataset
                .select(explode(col(LINES)).as(LINES_EXPLODE))
                .select(size(column(ADDITONAL_INFO_EXPLODE_FIELD_NAME)).as(LINES_ADDITIONAL_INFO_LIST))
                .agg(sum(column(LINES_ADDITIONAL_INFO_LIST)))
                .first().getAs(0);

        assertThat(linesAdditionalInfoCount, is(equalTo(DECLARATION_LINE_ADDITIONAL_INFO_COUNT)));
    }

    @Test
    public void validateDeclarationLineTaxLineGroupFields() {

        final StructField lineTaxLineStructFieldType = dataset.select(explode(col(LINES)).as(LINES_EXPLODE))
                .select(explode(col(TAX_LINES_EXPLODE_FIELD_NAME)).as(STRUCT_ELEMENT_FIELD_NAME))
                .schema().apply(STRUCT_ELEMENT_FIELD_NAME);

        assertEquals(new StructField(STRUCT_ELEMENT_FIELD_NAME, DataTypes.createStructType(declarationLineTaxLineStructType()), TRUE,
                Metadata.empty()), lineTaxLineStructFieldType);


        long linesTaxLineCount = dataset
                .select(explode(col(LINES)).as(LINES_EXPLODE))
                .filter(column(TAX_LINES_EXPLODE_FIELD_NAME).isNotNull())
                .select(size(column(TAX_LINES_EXPLODE_FIELD_NAME)).as(LINES_TAX_LINE_LIST))
                .agg(sum(column(LINES_TAX_LINE_LIST)))
                .first().getAs(0);


        assertThat(linesTaxLineCount, is(equalTo(DECLARATION_LINE_TAX_LINES_COUNT)));
    }


    @Test
    public void validateDeclarationLinePreviousDocumentGroupFields() {
        final StructField linePreviousDocumentsStructFieldType = dataset.select(explode(col(LINES)).as(LINES_EXPLODE))
                .select(explode(col(PREVIOUS_DOCUMENTS_EXPLODE_FIELD_NAME)).as(STRUCT_ELEMENT_FIELD_NAME))
                .schema().apply(STRUCT_ELEMENT_FIELD_NAME);

        assertEquals(new StructField(STRUCT_ELEMENT_FIELD_NAME, DataTypes.createStructType(declarationLinePreviousDocumentsStructType()), TRUE,
                Metadata.empty()), linePreviousDocumentsStructFieldType);


        long linesPreviousDocumentsCount = dataset
                .select(explode(col(LINES)).as(LINES_EXPLODE))
                .select(size(column(PREVIOUS_DOCUMENTS_EXPLODE_FIELD_NAME)).as(LINES_PREVIOUS_DOCUMENTS_LIST))
                .agg(sum(column(LINES_PREVIOUS_DOCUMENTS_LIST)))
                .first().getAs(0);

        assertThat(linesPreviousDocumentsCount, is(equalTo(DECLARATION_LINE_PREV_DOCUMENT_COUNT)));
    }

    @Test
    public void validateDeclarationLineCommodityGroupFields() {
        final StructField lineCommodityStructFieldType = dataset.select(explode(col(LINES)).as(LINES_EXPLODE))
                .select(col(COMMODITY_EXPLODE_FIELD_NAME))
                .schema().apply(COMMODITY);

        assertEquals(new StructField(COMMODITY, DataTypes.createStructType(declarationLineCommodityStructType()), TRUE,
                Metadata.empty()), lineCommodityStructFieldType);

       long lineCommodityCount = dataset
                .select(explode(col(LINES)).as(LINES_EXPLODE))
               .select(COMMODITY_HUB_KEY_FIELD_NAME).count();

        assertThat(lineCommodityCount, is(equalTo(DECLARATION_LINE_COUNT)));
    }

    @Test
    public void validateDeclarationLineOriginCountryGroupFields() {
        final StructField lineOriginCountryStructFieldType = dataset.select(explode(col(LINES)).as(LINES_EXPLODE))
                .select(col(ORIGIN_COUNTRY_EXPLODE_FIELD_NAME))
                .schema().apply(ORIGIN_COUNTRY_FIELD_NAME);

        assertEquals(new StructField(ORIGIN_COUNTRY_FIELD_NAME, DataTypes.createStructType(declarationLineOriginCountryStructType()), TRUE,
                Metadata.empty()), lineOriginCountryStructFieldType);

        long lineOriginCountryCount = dataset
                .select(explode(col(LINES)).as(LINES_EXPLODE))
                .filter(not(column(ORIGIN_COUNTRY_NAME_FIELD_NAME).equalTo(NULL_ESCAPE)))
                .select(ORIGIN_COUNTRY_NAME_FIELD_NAME).count();

        assertThat(lineOriginCountryCount, is(equalTo(DECLARATION_LINE_COUNT)));
    }

    @Test
    public void validateDeclarationLineImporterTradeGroupFields() {
        final StructField lineImporterTraderStructFieldType = dataset.select(explode(col(LINES)).as(LINES_EXPLODE))
                .select(col(IMPORTER_TRADER_EXPLODE_FIELD_NAME))
                .schema().apply(TRADER_IMPORTER_FIELD_NAME);

        assertEquals(new StructField(TRADER_IMPORTER_FIELD_NAME, DataTypes.createStructType(declarationLineImporterTraderGroupStructType()), TRUE,
                Metadata.empty()), lineImporterTraderStructFieldType);

        long lineImporterTraderCount = dataset
                .select(explode(col(LINES)).as(LINES_EXPLODE))
                .filter(not(column(DECLARATION_LINE_IMPORTER_TRADER_FIELD_NAME).equalTo(NULL_ESCAPE)))
                .select(DECLARATION_LINE_IMPORTER_TRADER_FIELD_NAME).count();

        assertThat(lineImporterTraderCount, is(equalTo(IMPORT_DECLARATION_LINES_COUNT)));
    }


    private static String[] declarationLineDeclarationGroupStructFields = toArray(
            Lists.newArrayList(
                    "hub_declaration_key",
                    "entry_reference",
                    "lines")
    );

    private static String[] declarationLineDeclarationStructFields = toArray(
            Lists.newArrayList(
                    "hub_declaration_line_key",
                    "entry_reference",
                    "item_number",
                    "clearance_datetime",
                    "item_statistical_value",
                    "customs_duty_paid",
                    "vat_paid",
                    "ec_supplementary_1",
                    "item_customs_value",
                    "item_net_mass",
                    "item_supplementary_units",
                    "goods_description",
                    "item_customs_check_code",
                    "item_mic_code",
                    "item_profile_id",
                    "item_consignor_nad_name",
                    "item_consignee_nad_name",
                    "item_consignee_nad_postcode",
                    "vat_value",
                    "item_price_declared",
                    "customsProcedureCode",
                    "documents",
                    "taxLines",
                    "additionalInfo",
                    "previousDocuments",
                    "commodity",
                    "originCountry",
                    "importerTrader")
    );

}
