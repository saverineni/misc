package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset;

import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.Declaration;

import static org.apache.spark.sql.functions.col;
import static org.apache.spark.sql.functions.explode;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

public class DeclarationDatasetIT extends SparkTest {

    @Autowired
    private DeclarationDataset declarationDataset;

    @Test
    public void verifySchemaAndCount() {
        Dataset<Declaration> dataset = declarationDataset.build();
        dataset.printSchema();
        String[] actualFieldNames = dataset.schema().fieldNames();
        assertThat(expectedDeclarationFieldNames, contains(actualFieldNames));

        String[] actualLineFieldNames = dataset
                .select(explode(col("lines")).as("linesAll"))
                .select(col("linesAll.*"))
                .schema()
                .fieldNames();

        assertThat(expectedDeclarationLine, contains(actualLineFieldNames));
        assertThat(dataset.count(), is(equalTo(4L))); // equal to Header count
    }
}