package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineTaxLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationLineTaxLineReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class LinkDeclarationLineTaxLineReaderTest extends SparkTest {

    @Autowired
    LinkDeclarationLineTaxLineReader linkDeclarationLineTaxLineReader;

    @Test
    public void buildsLinkDeclarationLineTaxLineDataset() throws Exception {
        final Dataset<LinkDeclarationLineTaxLine> linkDeclarationLineTaxLineDataset = linkDeclarationLineTaxLineReader.linkDeclarationLineTaxLineDataset();
        assertThat(linkDeclarationLineTaxLineDataset.count(), is(greaterThan(0l)));

        linkDeclarationLineTaxLineDataset.printSchema();
        final String[] fieldNames = linkDeclarationLineTaxLineDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(linkDeclarationLineTaxLineStructFields));

        final String[] selectedFieldNames = linkDeclarationLineTaxLineDataset.select(LinkDeclarationLineTaxLine.PRIMARY_COLUMN , joinExpression(LinkDeclarationLineTaxLine.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(linkDeclarationLineTaxLineSelectedStructFields));
    }

    private String[] linkDeclarationLineTaxLineStructFields = toArray(
            Lists.newArrayList("entry_reference",
                    "hub_declaration_line_key",
                    "hub_tax_line_key",
                    "item_number",
                    "link_declaration_line_tax_line_key",
                    "link_load_datetime",
                    "link_record_source",
                    "tax_line_sequence_number")
    );

    private String[] linkDeclarationLineTaxLineSelectedStructFields = toArray(
            Lists.newArrayList("link_declaration_line_tax_line_key",
                    "hub_tax_line_key",
                    "hub_declaration_line_key")
    );
}


