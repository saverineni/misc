package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatDocumentReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class SatDocumentReaderTest extends SparkTest {

    @Autowired
    SatDocumentReader satDocumentReader;

    @Test
    public void buildsSatDocumentDataset() throws Exception {
        final Dataset<SatDocument> satDocumentDataset = satDocumentReader.satDocumentDataset();
        assertThat(satDocumentDataset.count(), is(greaterThan(0l)));

        satDocumentDataset.printSchema();
        final String[] fieldNames = satDocumentDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(satDocumentStructFields));

        // TODO - We need to assert selected columns for Sat Document Reader later.

    }

    private String[] satDocumentStructFields = toArray(
            Lists.newArrayList("generation_number",
                    "hub_document_key",
                    "item_document_code",
                    "item_document_reference",
                    "item_document_status",
                    "sat_hash_diff",
                    "sat_load_datetime",
                    "sat_load_end_datetime",
                    "sat_record_source")
    );

}

