package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset;

public interface DeclarationConstants {

    Boolean TRUE = true;

    /*
        Declaration Header constants
    */

    // Currency fields
    String FREIGHT_CURRENCY_FIELD_NAME = "freightCurrency";
    String INVOICE_CURRENCY_FIELD_NAME = "invoiceCurrency";
    String CURRENCY_ISO_CODE_FIELD_NAME = "currency_iso_code";
    String CURRENCY_FIELD_NAME = "currency_name";

    // Country fields
    String DESTINATION_COUNTRY_FIELD_NAME = "destinationCountry";
    String TRANSPORT_COUNTRY_FIELD_NAME = "transportCountry";
    String COUNTRY_ISO_CODE_FIELD_NAME = "iso_country_code_alpha_2";
    String COUNTRY_FIELD_NAME = "country_name";

    // Trader Fields
    String TRADER_CURRENT_IND = "current_ind";
    String TRADER_NAME = "name";
    String TRADER_NAME_ABBREVIATED = "trader_name_abbreviated";
    String TRADER_PROCEDURE_AUTHORISATIONS = "simplified_procedure_authorisations";

    String TRADER_CONSIGNOR_FIELD_NAME = "consignorTrader";
    String TRADER_DECLARANT_FIELD_NAME = "declarantTrader";
    String TRADER_EXPORTER_FIELD_NAME = "exporterTrader";
    String TRADER_IMPORTER_FIELD_NAME = "importerTrader";
    String TRADER_PAYING_AGENT_FIELD_NAME = "payingAgentTrader";

    String IMPORTER_TRADER_TURN = "importer_trader_turn";
    String CONSIGNOR_TRADER_TURN = "consignor_trader_turn";
    String DECLARANT_TRADER_TURN = "declarant_trader_turn";
    String EXPORTER_TRADER_TURN = "exporter_trader_turn";
    String PAYING_AGENT_TRADER_TURN = "paying_agent_trader_turn";

    String DECLARATION_FREIGHT_CURRENCY_FIELD_NAME = "declarationCurrency.freightCurrency.currency_name";
    String DECLARATION_INVOICE_CURRENCY_FIELD_NAME = "declarationCurrency.invoiceCurrency.currency_name";

    String DECLARATION_DESTINATION_COUNTRY_FIELD_NAME = "declarationCountry.destinationCountry.country_name";
    String DECLARATION_TRANSPORT_COUNTRY_FIELD_NAME = "declarationCountry.transportCountry.country_name";

    String DECLARATION_CONSIGNOR_TRADER_FIELD_NAME = "declarationTrader.consignorTrader.consignor_trader_turn";
    String DECLARATION_DECLARANT_TRADER_FIELD_NAME = "declarationTrader.declarantTrader.declarant_trader_turn";
    String DECLARATION_EXPORTER_TRADER_FIELD_NAME = "declarationTrader.exporterTrader.exporter_trader_turn";
    String DECLARATION_IMPORTER_TRADER_FIELD_NAME = "declarationTrader.importerTrader.importer_trader_turn";
    String DECLARATION_PAYING_AGENT_TRADER_FIELD_NAME = "declarationTrader.payingAgentTrader.paying_agent_trader_turn";



    /*
        Declaration Line constants
    */

    // Line fields

    String LINES = "lines";
    String LINES_LIST = "lines_list";
    String LINES_EXPLODE = "lines_explode";
    String LINES_EXPLODE_ALL_FIELDS = "lines_explode.*";

    String LINES_DOCUMENTS_LIST = "documents_list";
    String LINES_ADDITIONAL_INFO_LIST = "additional_info_list";
    String LINES_TAX_LINE_LIST = "tax_line_list";
    String LINES_PREVIOUS_DOCUMENTS_LIST = "previous_documents_list";

    String STRUCT_ELEMENT_FIELD_NAME = "element";
    String DOCUMENT_EXPLODE_FIELD_NAME = LINES_EXPLODE + ".documents";
    String ADDITONAL_INFO_EXPLODE_FIELD_NAME = LINES_EXPLODE + ".additionalInfo";
    String TAX_LINES_EXPLODE_FIELD_NAME = LINES_EXPLODE + ".taxLines";
    String PREVIOUS_DOCUMENTS_EXPLODE_FIELD_NAME = LINES_EXPLODE +".previousDocuments";
    String COMMODITY_EXPLODE_FIELD_NAME = LINES_EXPLODE + ".commodity";
    String ORIGIN_COUNTRY_EXPLODE_FIELD_NAME = LINES_EXPLODE + ".originCountry";
    String IMPORTER_TRADER_EXPLODE_FIELD_NAME = LINES_EXPLODE + ".importerTrader";


    String COMMODITY_HUB_KEY_FIELD_NAME = COMMODITY_EXPLODE_FIELD_NAME + ".hub_commodity_key";

    // Line Document fields

    String HUB_DOCUMENT_KEY_FIELD_NAME = "hub_document_key";
    String DOCUMENT_SEQ_NUMBER_FIELD_NAME = "document_sequence_number";
    String SAT_DOCUMENT_GEN_NUMBER_FIELD_NAME = "sat_document_generation_number";
    String ITEM_DOCUMENT_CODE_FIELD_NAME = "item_document_code";
    String ITEM_DOCUMENT_STATUS_FIELD_NAME = "item_document_status";
    String ITEM_DOCUMENT_REF_FIELD_NAME = "item_document_reference";

    // Line Additional info fields
    String HUB_ADDITONAL_INFO_KEY_FIELD_NAME = "hub_additional_info_key";
    String ADDITIONAL_INFO_SEQ_NUMBER_FIELD_NAME = "additional_information_sequence_number";
    String SAT_ADDITIONAL_INFO_GEN_NUMBER_FIELD_NAME = "sat_additional_info_generation_number";
    String ADDITIONAL_INFO_STATEMENT_FIELD_NAME = "additional_information_statement";
    String ADDITIONAL_INFO_STATEMENT_TYPE_FIELD_NAME = "additional_information_statement_type";
    String ITEM_ADDITIONAL_INFO_STATEMENT_FIELD_NAME = "item_additional_information_statement";

    // Line Tax line fields
    String HUB_TAX_LINE_KEY_FIELD_NAME = "hub_tax_line_key";
    String TAX_LINE_SEQ_NUMBER_FIELD_NAME = "tax_line_sequence_number";
    String SAT_TAX_LINE_GEN_NUMBER_FIELD_NAME = "sat_tax_line_generation_number";
    String WAIVED_TAX_FIELD_NAME = "waived_tax";
    String PAYMENT_METHOD_CODE_FIELD_NAME = "method_of_payment_code";
    String TAX_AMOUNT_FIELD_NAME = "tax_amount";
    String TAX_TYPE_CODE_FIELD_NAME = "tax_type_code";

    // Previous documents fields
    String HUB_PREVIOUS_DOCUMENT_KEY_FIELD_NAME = "hub_previous_document_key";
    String PREVIOUS_DOCUMENT_SEQ_NUMBER_FIELD_NAME = "previous_document_sequence_number";
    String PREVIOUS_DOCUMENT_REF_FIELD_NAME = "previous_document_reference";

    // Line Commodity fields

    String COMMODITY = "commodity";
    String HUB_COMMODITY_KEY_FIELD_NAME = "hub_commodity_key";
    String COMMODITY_CODE_FIELD_NAME = "commodity_code";
    String CC_YEAR_FIELD_NAME = "cc_year";
    String CC_MONTH_FIELD_NAME = "cc_month";
    String HS_CHAPTER_FIELD_NAME = "hs_chapter";
    String HS_HEADING_FIELD_NAME = "hs_heading";
    String HS_CHAPTER_HEADING_FIELD_NAME = "hs_chapter_heading";
    String HS_SUBHEADING_FIELD_NAME = "hs_subheading";
    String CHAPTER_DESCRIPTION_FIELD_NAME = "chapter_description";
    String HEADING_DESCRIPTION_FIELD_NAME = "heading_description";
    String SUBHEADING_DESCRIPTION_FIELD_NAME = "subheading_description";

    // Line Origin Country fields

    String ORIGIN_COUNTRY_FIELD_NAME = "originCountry";
    String ORIGIN_COUNTRY_NAME_FIELD_NAME = "lines_explode.originCountry.country_name";

    // Line Importer Trader fiels
    String DECLARATION_LINE_IMPORTER_TRADER_FIELD_NAME = LINES_EXPLODE + ".importerTrader.importer_trader_turn";

}
