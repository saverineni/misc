# Customs Data Spark Job


## Testing
Run `./setup.sh` before running unit tests.
