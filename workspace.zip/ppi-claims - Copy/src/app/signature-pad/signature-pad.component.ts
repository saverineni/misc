import {Component, OnInit, ViewChild} from '@angular/core';
import {SignaturePad} from 'angular2-signaturepad/signature-pad';


@Component({
  selector: 'app-signature-pad',
  templateUrl: './signature-pad.component.html',
  styleUrls: ['./signature-pad.component.css']
})
export class SignaturePadComponent implements OnInit {

  @ViewChild(SignaturePad) signaturePad : SignaturePad;

  public signaturePadOptions = {
    'minWidth': 1,
    penColor: 'rgb(255,255,255)',
    backgroundColor: 'rgb(1,1,255)',
    canvasWidth: 300,
    canvasHeight: 100
  };
  constructor() {
  }

  ngOnInit() {
  }

  drawClear() {
    this.signaturePad.clear();
  }

  drawComplete() {
    const base64 = this.signaturePad.toDataURL('image/jpeg', 10);
    console.log(base64);
  }

  drawStart() {
    console.log('begin drawing');
  }

}
