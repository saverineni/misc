import {Component, OnInit, ViewChild} from '@angular/core';
import {SignaturePad} from 'angular2-signaturepad/signature-pad';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {HttpService} from "../service/http.service";
import * as moment from 'moment';
import {Customer} from "../model/customer.model";


@Component({
  selector: 'app-signature-pad',
  templateUrl: './signature-pad.component.html',
  styleUrls: ['./signature-pad.component.css']
})
export class SignaturePadComponent implements OnInit {
  DATE_FORMAT = 'DD-MM-YYYY';
  @ViewChild(SignaturePad) signaturePad: SignaturePad;
  public signaturePadOptions = {
    'minWidth': 1,
    penColor: 'rgb(255,255,255)',
    backgroundColor: 'rgb(1,1,255)',
    canvasWidth: 400,
    canvasHeight: 100
  };

  public ownerForm: FormGroup;
  private dialogConfig;


  constructor(private service: HttpService) {
  }

  ngOnInit() {
    this.ownerForm = new FormGroup({
      firstName: new FormControl('', [Validators.required, Validators.maxLength(60)]),
      lastName: new FormControl('', [Validators.required, Validators.maxLength(60)]),
      dateOfBirth: new FormControl(new Date())
    });

    this.dialogConfig = {
      height: '200px',
      width: '400px',
      disableClose: true,
      data: {}
    }
  }


  drawClear() {
    this.signaturePad.clear();
  }

  drawComplete() {
    const base64 = this.signaturePad.toDataURL('image/jpeg', 10);
    console.log(base64);
  }

  drawStart() {
    console.log('begin drawing');
  }

  public hasError = (controlName: string, errorName: string) => {
    return this.ownerForm.controls[controlName].hasError(errorName);
  }

  public createOwner = (ownerFormValue) => {
    const base64Signature = this.signaturePad.toDataURL('image/jpeg', 10);
    if (this.ownerForm.valid) {

      let dob = moment(ownerFormValue.dateOfBirth).format('DD-MM-YYYY');

      let customer: Customer = {
        'firstName': ownerFormValue.firstName,
        'lastName': ownerFormValue.lastName,
        'dateOfBirth': dob,
        'signature': base64Signature
      };

      this.executePPiCreation(customer);
    }
  }

  private executePPiCreation = (customerDetails) => {
    console.log('form valid JSOn : ' + JSON.stringify(customerDetails));
    let apiUrl = 'ppi-claims-api';
    this.service.create(apiUrl, customerDetails)
      .subscribe(response => {
        //  this.openPDF(response, 'abc.pdf');
          var file = new Blob([response.body], {type: 'application/pdf'});
          var fileURL = URL.createObjectURL(file);
          window.open(fileURL);
        },
        (error => {
          console.log('error : ' + error);
          // this.errorService.dialogConfig = { ...this.dialogConfig };
          // this.errorService.handleError(error);
        })
      )
  }

}
