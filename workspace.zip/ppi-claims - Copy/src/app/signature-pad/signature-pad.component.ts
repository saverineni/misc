import {Component, OnInit, ViewChild} from '@angular/core';
import {SignaturePad} from 'angular2-signaturepad/signature-pad';
import {FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";
import {HttpService} from "../service/http.service";
import * as moment from 'moment';
import {Customer} from "../model/customer.model";

@Component({
  selector: 'app-signature-pad',
  templateUrl: './signature-pad.component.html',
  styleUrls: ['./signature-pad.component.css']
})
export class SignaturePadComponent implements OnInit {
  private DATE_FORMAT = 'DD-MM-YYYY';
  private firstName = new FormControl('', [Validators.required, Validators.maxLength(20)]);
  private lastName = new FormControl('', [Validators.required, Validators.maxLength(20)]);
  private dateOfBirth = new FormControl(new Date());

  @ViewChild(SignaturePad) signaturePad: SignaturePad;

  public signaturePadOptions = {
    'minWidth': 1,
    'maxWidth': 1,
    backgroundColor: 'rgb(255,250,205)',
    canvasWidth: 400,
    canvasHeight: 100
  };

  public customerForm: FormGroup;

  constructor(private service: HttpService, private builder: FormBuilder) {
  }

  ngOnInit() {
    this.customerForm = this.builder.group({
      firstName: this.firstName,
      lastName: this.lastName,
      dateOfBirth: this.dateOfBirth
    });
  }

  drawClear() {
    this.signaturePad.clear();
  }

  public hasError = (controlName: string, errorName: string) => {
    return this.customerForm.controls[controlName].hasError(errorName);
  }

  public isSignatureEmpty() {
    return this.signaturePad.isEmpty();
  }

  public createPPIClaim(customerFormValue) {
    const base64Signature = this.signaturePad.toDataURL('image/jpeg',);
    if (this.customerForm.valid && !this.isSignatureEmpty()) {

      let dob = moment(customerFormValue.dateOfBirth).format(this.DATE_FORMAT);

      let customer: Customer = {
        'firstName': customerFormValue.firstName,
        'lastName': customerFormValue.lastName,
        'dateOfBirth': dob,
        'signature': base64Signature
      };

      this.executePPiCreation(customer);
    }
  }

  private executePPiCreation = (customerDetails) => {
    let apiUrl = 'ppi-claims-api';

    let observer = {
      next: function (response) {
        let file = new Blob([response.body], {type: 'application/pdf'});
        let fileURL = URL.createObjectURL(file);
        window.open(fileURL);
      },
      error: function (error) {
        console.error(`Got ${error.status}: ${error.description}`);
      }
    };

    this.service
      .create(apiUrl, customerDetails)
      .subscribe(observer);
  }

}
