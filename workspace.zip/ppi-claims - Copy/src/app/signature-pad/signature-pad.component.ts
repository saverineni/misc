import {Component, OnInit, ViewChild} from '@angular/core';
import {SignaturePad} from 'angular2-signaturepad/signature-pad';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {HttpService} from "../service/http.service";
import * as moment from 'moment';
import {Customer} from "../model/customer.model";


@Component({
  selector: 'app-signature-pad',
  templateUrl: './signature-pad.component.html',
  styleUrls: ['./signature-pad.component.css']
})
export class SignaturePadComponent implements OnInit {
  DATE_FORMAT = 'DD-MM-YYYY';

  @ViewChild(SignaturePad) signaturePad: SignaturePad;

  public signaturePadOptions = {
    'minWidth': 1,
    'maxWidth': 1,
    // penColor: 'rgb(255,255,255)',
    backgroundColor: 'rgb(255,255,224)',
    canvasWidth: 400,
    canvasHeight: 100
  };

  public customerForm: FormGroup;

  constructor(private service: HttpService) {
  }

  ngOnInit() {
    this.customerForm = new FormGroup({
      firstName: new FormControl('', [Validators.required, Validators.maxLength(60)]),
      lastName: new FormControl('', [Validators.required, Validators.maxLength(60)]),
      dateOfBirth: new FormControl(new Date())
    });
  }

  drawClear() {
    this.signaturePad.clear();
  }

  public hasError = (controlName: string, errorName: string) => {
    return this.customerForm.controls[controlName].hasError(errorName);
  }

  public hasSignatureError() {
    return this.signaturePad.isEmpty();
  }

  public createPPIClaim(customerFormValue) {

    console.log('SERVER');
    const base64Signature = this.signaturePad.toDataURL('image/jpeg', 10);
    if (this.customerForm.valid && !this.hasSignatureError()) {

      let dob = moment(customerFormValue.dateOfBirth).format(this.DATE_FORMAT);

      let customer: Customer = {
        'firstName': customerFormValue.firstName,
        'lastName': customerFormValue.lastName,
        'dateOfBirth': dob,
        'signature': base64Signature
      };

      this.executePPiCreation(customer);
    }
  }

  private executePPiCreation = (customerDetails) => {
    let apiUrl = 'ppi-claims-api';
    this.service.create(apiUrl, customerDetails)
      .subscribe(response => {
          var file = new Blob([response.body], {type: 'application/pdf'});
          var fileURL = URL.createObjectURL(file);
          window.open(fileURL);
        },
        (error => {
          console.log('error : ' + error);
          // this.errorService.dialogConfig = { ...this.dialogConfig };
          // this.errorService.handleError(error);
        })
      )
  }

}
