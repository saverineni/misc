import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {AppComponent} from './app.component';
import {MatStepperModule} from '@angular/material';
import {HttpClientModule} from '@angular/common/http';
import {ReactiveFormsModule} from '@angular/forms';
import {MatNativeDateModule} from '@angular/material';
import {DemoMaterialModule} from '../material-module';
import { SignaturePadModule } from 'angular2-signaturepad';
import { SignaturePadComponent } from './signature-pad/signature-pad.component';
import { MaterialModule } from './material/material.module';
import {FlexLayoutModule} from '@angular/flex-layout';
import {HttpService} from "./service/http.service";
import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { HomeComponent } from './home/home.component';
import { NavbarComponent } from './navbar/navbar.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { routing }           from './app.routing';

@NgModule({
  declarations: [
    AppComponent,
    SignaturePadComponent,
    HomeComponent,
    NavbarComponent,
    NotFoundComponent
  ],
  imports: [
    BrowserModule,
    MatStepperModule,
    BrowserAnimationsModule,
    HttpClientModule,
    DemoMaterialModule,
    MatNativeDateModule,
    ReactiveFormsModule,
    SignaturePadModule,
    MaterialModule,
    FlexLayoutModule,
    MatFormFieldModule,
    MatInputModule,
    routing
  ],
  providers: [ HttpService],
  bootstrap: [AppComponent]
})
export class AppModule {
}
