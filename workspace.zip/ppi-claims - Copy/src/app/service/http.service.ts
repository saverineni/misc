import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class HttpService {

  constructor(private http: HttpClient) {
  }

  public create(route: string, body) {
    return this.http.post('http://localhost:8080/ppi-claims-api', body,
      {
        responseType: 'blob',
        observe: 'response',
        'headers': {'Content-Type': 'application/json'},
      }
    );
  }
}
