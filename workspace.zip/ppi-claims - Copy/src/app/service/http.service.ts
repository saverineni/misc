import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';

@Injectable()
export class HttpService {

  constructor(private http: HttpClient) {
  }

  public create(route: string, body) {
    return this.http.post('http://localhost:8080/ppi-claims-api', body,
      {
        responseType: 'blob',
        observe: 'response',
        'headers': {'Content-Type': 'application/json'},
      }
    );
    //return this.http.post<any>(this.createCompleteRoute(route, environment.urlAddress), body, this.generateHeaders());
  }


  private generateHeaders() {
    return {
      headers: new HttpHeaders({'Content-Type': 'application/json'})
    }
  }

  private createCompleteRoute(route: string, urlAddress: string) {
    return `${urlAddress}/${route}`;
  }
}
