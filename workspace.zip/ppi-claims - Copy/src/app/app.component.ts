import {Component, OnInit, ViewChild} from '@angular/core';
import {AbstractControl, FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms'
import {SignaturePad} from "../../node_modules/angular2-signaturepad/signature-pad";
import {MatStepper} from '@angular/material/stepper';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  public signaturePadOptions = {
    'minWidth': 1,
    'maxWidth': 1,
    backgroundColor: 'rgb(255,250,205)',
    canvasWidth: 400,
    canvasHeight: 100
  };

  @ViewChild(SignaturePad) signaturePad: SignaturePad;

  isLinear = true;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;
  formGroup: FormGroup;

  favoriteBank: string;
  banks: string[] = ['Hsbc', 'Barclays', 'Lloyds', 'Co-operative'];

  constructor(private _formBuilder: FormBuilder) {
  }

  private firstLine = new FormControl('', [Validators.required, Validators.maxLength(20)]);
  private city = new FormControl('', [Validators.required, Validators.maxLength(20)]);
  private postcode = new FormControl('', [Validators.required, Validators.maxLength(20)]);


  private firstName = new FormControl('', [Validators.required, Validators.maxLength(20)]);
  private lastName = new FormControl('', [Validators.required, Validators.maxLength(20)]);
  private dateOfBirth = new FormControl(new Date());

  get formArray(): AbstractControl | null {
    return this.formGroup.get('formArray');
  }


  ngOnInit() {
    this.formGroup = this._formBuilder.group({
      formArray: this._formBuilder.array([

        this.firstFormGroup = this._formBuilder.group({
          firstName: this.firstName,
          lastName: this.lastName,
          dateOfBirth: this.dateOfBirth
        }),

        this.secondFormGroup = this._formBuilder.group({
          firstLine: this.firstLine,
          city: this.city,
          postcode: this.postcode
        }),

        this.thirdFormGroup = this._formBuilder.group({
          bank: ['', Validators.required]
        })
      ])
    });

  }

  drawClear() {
    this.signaturePad.clear();
  }

  goNext(stepper: MatStepper) {
    this.firstLine.setValue("1 windsor drive");
    this.city.setValue("Altrincham");
    this.postcode.setValue("WA14 5AN");
    stepper.next();
  }

  onSubmit() {
    const base64Signature = this.signaturePad.toDataURL('image/jpeg',);
    this.formGroup.value['signature'] = base64Signature;
    let jsonObject = JSON.parse('{}');

    jsonObject.personalDetails = this.formGroup.value.formArray[0];
    jsonObject.addressDetails = this.formGroup.value.formArray[1];
    jsonObject.lenderDetails = this.formGroup.value.formArray[2];
    jsonObject.signature = base64Signature;

    console.log(JSON.stringify(jsonObject));
  }


}
