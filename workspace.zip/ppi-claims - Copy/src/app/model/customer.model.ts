export interface Customer{
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  signature: string;
}
