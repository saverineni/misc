package com.leadx.ppiclaims;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PPIClaimsApplication {
    public static void main(String[] args) {
        SpringApplication.run(PPIClaimsApplication.class, args);
    }
}