package com.leadx.ppiclaims.services;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.leadx.ppiclaims.resources.FormData;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Base64;

@Service
public class PDFGeneratorService {

    public ByteArrayInputStream generatePDFStream(FormData formData) throws DocumentException, SQLException, IOException {

        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        PdfWriter.getInstance(document, out);
        document.open();
        document.addTitle("My first PDF");
        document.add(new Paragraph(formData.getFirstName()));
        document.add(new Paragraph(formData.getLastName()));
        document.add(new Paragraph(formData.getDateOfBirth().toString()));

        Base64.Decoder decoder = Base64.getDecoder();
        byte[] decodedByte = decoder.decode(formData.getSignature().split(",")[1]);

        Image image = Image.getInstance(decodedByte);
        image.scaleAbsolute(100, 50);
        document.add(image);

        document.close();

        return new ByteArrayInputStream(out.toByteArray());
    }
}
