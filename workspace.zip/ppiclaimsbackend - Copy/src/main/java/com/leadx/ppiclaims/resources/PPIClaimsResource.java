package com.leadx.ppiclaims.resources;


import com.itextpdf.text.DocumentException;
import com.leadx.ppiclaims.services.PDFGeneratorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.SQLException;

@Component
@RequestMapping("/ppi-claims-api")
public class PPIClaimsResource {

    @Autowired
    private PDFGeneratorService service;

    @PostMapping
    public ResponseEntity<InputStreamResource> createPDF(@RequestBody FormData formData) throws DocumentException, IOException, SQLException {

        ByteArrayInputStream byteArrayInputStream = service.generatePDFStream(formData);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "inline; filename=citiesreport.pdf");

        return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF)
                .body(new InputStreamResource(byteArrayInputStream));


    }

}

