package com.leadx.ppiclaims.resources;


import com.itextpdf.text.DocumentException;
import com.leadx.ppiclaims.services.PDFGeneratorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;

import static org.springframework.http.MediaType.APPLICATION_PDF_VALUE;

@CrossOrigin(maxAge = 3600)
@Component
@RequestMapping("/ppi-claims-api")
public class PPIClaimsResource {

    @Autowired
    private PDFGeneratorService service;

    @PostMapping(produces = APPLICATION_PDF_VALUE)
    public ResponseEntity<InputStreamResource> createPDF(@RequestBody FormData formData) throws DocumentException, IOException, SQLException {

        ByteArrayInputStream byteArrayInputStream = service.generatePDFStream(formData);

        HttpHeaders headers = new HttpHeaders();
        headers.setAccessControlExposeHeaders(Arrays.asList(HttpHeaders.CONTENT_DISPOSITION));

        return ResponseEntity.ok()
                .headers(headers)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + formData.getFirstName() + ".pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(new InputStreamResource(byteArrayInputStream));

    }

}

