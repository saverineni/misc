package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHit;
import org.hamcrest.Matcher;

import static org.hamcrest.Matchers.arrayContainingInAnyOrder;
import static org.junit.Assert.assertThat;

public class SearchResponseAssert {

    @SafeVarargs
    public static void assertSearchHits(SearchResponse searchResponse, Matcher<SearchHit>... searchHits) {
        assertThat(describeActual(searchResponse.getHits().getHits()), searchResponse.getHits().getHits(),
                arrayContainingInAnyOrder(searchHits));
    }

    private static String describeActual(SearchHit[] hits) {
        return "\nActual hits were:" + Stream.of(hits)
                .map(hit -> hit.getSourceAsMap().get("declarationId"))
                .map(String.class::cast)
                .collect(Collectors.joining(","));
    }

}
