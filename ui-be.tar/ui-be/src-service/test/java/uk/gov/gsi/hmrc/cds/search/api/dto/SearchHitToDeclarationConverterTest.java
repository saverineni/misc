package uk.gov.gsi.hmrc.cds.search.api.dto;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.elasticsearch.common.bytes.BytesArray;
import org.elasticsearch.search.SearchHit;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchHitToDeclarationConverter;

import java.io.IOException;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SearchHitToDeclarationConverterTest {

    public static final String JSON = "{}";
    private SearchHit searchHit = new SearchHit(1);

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private Declaration declaration;

    private SearchHitToDeclarationConverter converter;

    @Before
    public void setUp() {
        searchHit.sourceRef(new BytesArray(JSON));
        converter = new SearchHitToDeclarationConverter(objectMapper);
    }

    @Test
    public void returnsDeclaration() throws Exception {
        when(objectMapper.readValue(JSON, Declaration.class)).thenReturn(declaration);
        Declaration actual = converter.convert(searchHit);
        assertThat(actual, is(declaration));
    }

    @Test
    public void throwsRuntimeExceptionOnJsonParseError() throws Exception {
        when(objectMapper.readValue(JSON, Declaration.class)).thenThrow(new IOException("message"));
        try {
            converter.convert(searchHit);
            fail();
        } catch(RuntimeException e) {
            assertThat(e.getMessage(), is("message"));
        }
    }

}
