package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;

import java.util.Arrays;
import java.util.List;

import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.junit.Before;
import org.junit.Test;

import static org.elasticsearch.common.xcontent.XContentType.JSON;
import static org.junit.Assert.assertEquals;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchHitMatchers.declarationId;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchResponseAssert.assertSearchHits;

import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLine;

public class SearchClientDispatchCountryIT extends CustomsSearchESIntegTestCase {

    private static final String CUSTOMS_INDEX = "SearchServiceDispatchCountryIntegrationTest".toLowerCase();
    private static final String IN_CODE = "IN"; // dispatchCountry
    private static final String NZ_CODE = "NZ"; // dispatchCountry
    private static final String MX_CODE = "MX"; // dispatchCountry
    private static final String CA_CODE = "CA"; // originCountry
    private static final String CH_CODE = "CH"; // originCountry
    private static final String EPU = "EPU";

    private ObjectMapper objectMapper = new ObjectMapper();

    @Before
    public void setUp() throws Exception {
        super.setUp(CUSTOMS_INDEX);
        createCustomsIndexWithDocuments();
    }

    @Test
    public void searchWithBlankDispatchCountryFacet() {
        SearchResponse searchResponse = this.service.declarationSearch(dispatchCountriesSearchCriteria(Arrays.asList("")));
        assertSearchHits(searchResponse, declarationId("dec-id-5"));
    }

    @Test
    public void searchWithOneDispatchCountryFacet() {
        SearchResponse searchResponse = this.service.declarationSearch(dispatchCountriesSearchCriteria(Arrays.asList(IN_CODE)));
        assertSearchHits(searchResponse,
                declarationId("dec-id-1"),
                declarationId("dec-id-2"),
                declarationId("dec-id-9"));
    }

    @Test
    public void searchWithTwoDispatchCountryFacets() {
        SearchResponse searchResponse = this.service.declarationSearch(dispatchCountriesSearchCriteria(Arrays.asList(IN_CODE, NZ_CODE)));

        assertSearchHits(searchResponse,
                declarationId("dec-id-1"),
                declarationId("dec-id-2"),
                declarationId("dec-id-3"),
                declarationId("dec-id-4"),
                declarationId("dec-id-9"));
    }

    @Test
    public void searchWithOneDispatchCountryFacetWithSearchTerm() {
        SearchCriteria searchCriteria = dispatchCountriesSearchCriteria(Arrays.asList(NZ_CODE));
        searchCriteria.setSearchTerm(EPU);
        SearchResponse searchResponse = this.service.declarationSearch(searchCriteria);

        assertSearchHits(searchResponse,
                declarationId("dec-id-3"),
                declarationId("dec-id-4"));
    }

    @Test
    public void nonMatchingTwoDispatchCountryFacetTwoOriginCountryFacetWithSearchTerm() {
        SearchResponse searchResponse = setDispatchAndOriginCountries(Arrays.asList(IN_CODE, CA_CODE), Arrays.asList(IN_CODE, NZ_CODE));
        assertEquals(searchResponse.getHits().getHits().length, 0);
    }

    @Test
    public void matchingTwoDispatchCountryFacetTwoOriginCountryFacetWithSearchTerm() {
        SearchResponse searchResponse = setDispatchAndOriginCountries(Arrays.asList(IN_CODE, MX_CODE), Arrays.asList(CA_CODE, CH_CODE ));
        assertSearchHits(searchResponse,
                declarationId("dec-id-7"),
                declarationId("dec-id-8"),
                declarationId("dec-id-9"));
    }

    @Test
    public void multipleOriginCountriesWithSingleDispatchCountry() {
        SearchResponse searchResponse = setDispatchAndOriginCountries(Arrays.asList(IN_CODE), Arrays.asList(CA_CODE, CH_CODE ));
        assertSearchHits(searchResponse, declarationId("dec-id-9"));
    }

    @Test
    public void searchWithOneDispatchCountryFacetAndOneOriginCountryFacet() {
        SearchResponse searchResponse = setDispatchAndOriginCountries(Arrays.asList(MX_CODE), Arrays.asList(CH_CODE ));
        assertSearchHits(searchResponse, declarationId("dec-id-8"));

    }

    private SearchResponse setDispatchAndOriginCountries(List<String> dispatchCountries, List<String> originCountries) {
        SearchCriteria searchCriteria = dispatchCountriesSearchCriteria(dispatchCountries);
        searchCriteria.setSearchTerm(EPU);
        searchCriteria.setOriginCountryCode(originCountries);
        return this.service.declarationSearch(searchCriteria);
    }

    private SearchCriteria dispatchCountriesSearchCriteria(List<String> distpachCountryCodes) {
        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDispatchCountryCode(distpachCountryCodes);
        return searchCriteria;
    }

    private void createCustomsIndexWithDocuments() throws Exception {
        createIndex(CUSTOMS_INDEX);

        BulkRequest request = new BulkRequest();
        addDeclaration(request, newDeclaration("dec-id-1", IN_CODE));
        addDeclaration(request, newDeclaration("dec-id-2", IN_CODE));
        addDeclaration(request, newDeclaration("dec-id-3", NZ_CODE));
        addDeclaration(request, newDeclaration("dec-id-4", NZ_CODE));
        addDeclaration(request, newDeclaration("dec-id-5", ""));
        addDeclaration(request, newDeclaration("dec-id-6", null));
        addDeclaration(request, newDeclarationWithOriginCountryDispatchCountry("dec-id-7", CA_CODE, MX_CODE));
        addDeclaration(request, newDeclarationWithOriginCountryDispatchCountry("dec-id-8", CH_CODE, MX_CODE));
        addDeclaration(request, newDeclarationWithOriginCountryDispatchCountry("dec-id-9", CA_CODE, IN_CODE));

        client.bulk(request);

        refresh(CUSTOMS_INDEX);
    }

    private void addDeclaration(BulkRequest request, Declaration declaration) throws JsonProcessingException {
        request.add(new IndexRequest(CUSTOMS_INDEX, DECLARATION_TYPE, declaration.getDeclarationId())
                .source(objectMapper.writer().writeValueAsString(declaration), JSON));
    }


    private Declaration newDeclaration(String id, String dispatchCountryCode) {
        return Declaration.builder()
                .declarationId(id)
                .epuNumber(EPU)
                .dispatchCountry(Country.builder().code(dispatchCountryCode).build()).build();
    }

    private Declaration newDeclarationWithOriginCountryDispatchCountry(String id, String originCountryCode, String dispatchCountryCode) {
        return Declaration.builder()
                .declarationId(id)
                .epuNumber(EPU)
                .dispatchCountry(Country.builder().code(dispatchCountryCode).build())
                .lines(
                        Lists.newArrayList(
                                DeclarationLine.builder()
                                        .originCountry(Country.builder().code(originCountryCode).build())
                                        .build()
                        )
                )
                .build();
    }

}
