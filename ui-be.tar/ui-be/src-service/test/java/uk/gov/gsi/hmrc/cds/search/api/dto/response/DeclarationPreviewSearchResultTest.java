package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import org.junit.Test;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;

import uk.gov.gsi.hmrc.cds.search.api.dto.Country;

public class DeclarationPreviewSearchResultTest {

    private static final String DECLARATION_ID = "id";
    private static final String IMPORT_EXPORT_INDICATOR = "export";
    private static final String DECLARATION_SOURCE = "source";
    private static final String ENTRY_DATE = "date";
    private static final String ROUTE = "route";
    private static final String GOODS_LOCATION = "goods";
    private static final Country DISPATCH_COUNTRY = Country.builder().code("dispatch").build();
    private static final Country DESTINATION_COUNTRY = Country.builder().code("destination").build();
    private static final String TRANSPORT_MODE_CODE = "transport";

    private final Declaration declaration = Declaration.builder()
            .declarationId(DECLARATION_ID)
            .importExportIndicator(IMPORT_EXPORT_INDICATOR)
            .declarationSource(DECLARATION_SOURCE)
            .entryDate(ENTRY_DATE)
            .route(ROUTE)
            .goodsLocation(GOODS_LOCATION)
            .dispatchCountry(DISPATCH_COUNTRY)
            .destinationCountry(DESTINATION_COUNTRY)
            .transportModeCode(TRANSPORT_MODE_CODE)
            .lines(emptyList())
            .build();

    private final DeclarationPreview preview = DeclarationPreview.builder()
            .declarationId(DECLARATION_ID)
            .importExportIndicator(IMPORT_EXPORT_INDICATOR)
            .declarationSource(DECLARATION_SOURCE)
            .entryDate(ENTRY_DATE)
            .route(ROUTE)
            .goodsLocation(GOODS_LOCATION)
            .dispatchCountry(DISPATCH_COUNTRY)
            .destinationCountry(DESTINATION_COUNTRY)
            .transportModeCode(TRANSPORT_MODE_CODE)
            .lineCount(0)
            .build();

    @Test
    public void fromDeclarationSearchResultShouldReturnDeclarationPreviewSearchResult() {
        DeclarationSearchResult result = DeclarationSearchResult.builder().declarations(asList(declaration, declaration)).build();
        DeclarationPreviewSearchResult previewResult = DeclarationPreviewSearchResult.builder().declarations(asList(preview, preview)).build();
        assertThat(DeclarationPreviewSearchResult.fromDeclarationSearchResult(result), is(equalTo(previewResult)));
    }

    @Test
    public void fromDeclarationSearchResultShouldHandleNull() {
        DeclarationPreviewSearchResult result = DeclarationPreviewSearchResult.fromDeclarationSearchResult(null);
        assertThat(result, is(notNullValue()));
    }

}