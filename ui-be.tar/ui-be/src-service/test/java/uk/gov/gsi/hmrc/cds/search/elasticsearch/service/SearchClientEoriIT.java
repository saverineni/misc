package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.junit.Before;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;

import static org.elasticsearch.common.xcontent.XContentType.JSON;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchHitMatchers.fieldValue;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchResponseAssert.assertSearchHits;
import static uk.gov.gsi.hmrc.cds.search.utils.TestHelper.*;

public class SearchClientEoriIT extends CustomsSearchESIntegTestCase {

    private static final String CUSTOMS_INDEX = "SearchClientEoriIT".toLowerCase();

    private static final String VALID_DECLARATION_ID_1 = "219-249099X-2013-07-14";
    private static final String VALID_DECLARATION_ID_2 = "219-249099X-2013-07-15";
    private static final String VALID_DECLARATION_ID_3 = "219-249099X-2013-07-16";

    @Before
    public void setUp() throws Exception {
        super.setUp(CUSTOMS_INDEX);
        createCustomsIndexWithDocuments();
    }

    @Test
    public void searchWithNoEori() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(""));
        assertThat(searchResponse.getHits().totalHits, is(3L));
    }

    private SearchCriteria newSearchCriteria(String eori) {
        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setEori(eori);
        return searchCriteria;
    }

    @Test
    public void searchByConsigneeNumberAtHeaderLevel() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("976072558688"));
        assertSearchHits(searchResponse, fieldValue("$.consigneeTurn", "976072558688"));
        assertSearchHits(searchResponse, fieldValue("$.consignee.eori", "976072558688"));
    }

    @Test
    public void searchByConsigneeNumberAtLineLevel() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("731411813911"));
        assertSearchHits(searchResponse, fieldValue("$.lines[0].itemConsigneeTurn", "731411813911"));
        assertSearchHits(searchResponse, fieldValue("$.lines[0].itemConsignee.eori", "731411813911"));
    }

    @Test
    public void searchByConsignorNumberAtHeaderLevel() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("1261170936"));
        assertSearchHits(searchResponse, fieldValue("$.consignorTurn", "1261170936"));
        assertSearchHits(searchResponse, fieldValue("$.consignor.eori", "1261170936"));
    }

    @Test
    public void searchByConsignorNumberAtLineLevel() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("1933705"));
        assertSearchHits(searchResponse, fieldValue("$.lines[0].itemConsignorTurn", "1933705"));
        assertSearchHits(searchResponse, fieldValue("$.lines[0].itemConsignor.eori", "1933705"));
    }

    @Test
    public void searchByDeclarantEORIAtHeaderLevel() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("733139107726"));
        assertSearchHits(searchResponse, fieldValue("$.declarant.eori", "733139107726"));
    }

    private void createCustomsIndexWithDocuments() throws Exception {
        createIndex(CUSTOMS_INDEX);

        BulkRequest request = new BulkRequest();

        addDeclaration(request, VALID_SEARCH_INGEST_DECLARATION_FILE_1, VALID_DECLARATION_ID_1);
        addDeclaration(request, VALID_SEARCH_INGEST_DECLARATION_FILE_2, VALID_DECLARATION_ID_2);
        addDeclaration(request, VALID_SEARCH_INGEST_DECLARATION_FILE_3, VALID_DECLARATION_ID_3);

        client.bulk(request);

        refresh(CUSTOMS_INDEX);
    }

    private void addDeclaration(BulkRequest request, String validSearchIngestDeclarationFile, String validDeclarationId) {
        request.add(new IndexRequest(CUSTOMS_INDEX, DECLARATION_TYPE, validDeclarationId)
                .source(getFileContent(validSearchIngestDeclarationFile), JSON));
    }

}
