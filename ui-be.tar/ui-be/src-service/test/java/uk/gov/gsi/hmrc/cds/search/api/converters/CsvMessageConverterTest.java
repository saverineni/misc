package uk.gov.gsi.hmrc.cds.search.api.converters;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.MediaType;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.Trader;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

public class CsvMessageConverterTest {

    private CsvMessageConverter converter = new CsvMessageConverter();
    private String headerLine = Stream.of(CsvMessageConverter.HEADERS).collect(Collectors.joining(","));

    @Mock
    private HttpOutputMessage mockHttpOutputMessage;

    private HttpHeaders headers;

    @Before
    public void setup() {
        initMocks(this);
        headers = new HttpHeaders();
    }

    @Test
    public void shouldAddMediaTypeHeader() throws IOException {
        whenGivenOutput();
        converter.writeInternal(DeclarationSearchResult.builder().build(), mockHttpOutputMessage);

        assertThat(headers.getContentType(), is(equalTo(MediaType.valueOf("text/csv"))));
    }

    @Test
    public void shouldReturnHeaderLineWithNoResults() throws IOException {
        ByteArrayOutputStream output = whenGivenOutput();
        converter.writeInternal(DeclarationSearchResult.builder().build(), mockHttpOutputMessage);

        assertThat(output.toString(), is(equalTo(headerLine + "\n")));
    }

    @Test
    public void shouldReturnHeaderLineWithResults() throws IOException {
        ByteArrayOutputStream output = whenGivenOutput();
        DeclarationSearchResult result = DeclarationSearchResult.builder()
                .declarations(asList(
                    Declaration.builder().build(),
                    Declaration.builder()
                            .declarationId("Declaration ID")
                            .declarationSource("Declaration Source")
                            .importExportIndicator("Import/Export")
                            .epuNumber("Epu Number")
                            .entryNumber("Entry Number")
                            .entryDate("Entry Date")
                            .route("Route")
                            .dispatchCountry(Country.builder().code("Dispatch Country").build())
                            .destinationCountry(Country.builder().code("Destination Country").build())
                            .consignee(Trader.builder().eori("Consignee EORI").name("Consignee Name").postcode("Consignee Postcode").build())
                            .consignor(Trader.builder().eori("Consignor EORI").name("Consignor Name").postcode("Consignor Postcode").build())
                            .declarant(Trader.builder().eori("Declarant EORI").name("Declarant Name").postcode("Declarant Postcode").build())
                            .consigneeTurn("Consignee EORI")
                            .consignorTurn("Consignor EORI")
                            .goodsLocation("Goods Location")
                            .transportModeCode("Transport Mode")
                            .consigneeName("Consignee Name")
                            .consigneePostcode("Consignee Postcode")
                            .consignorName("Consignor Name")
                            .consignorPostcode("Consignor Postcode")
                            .declarationType("Declaration Type")
                            .build()
                ))
                .build();
        converter.writeInternal(result, mockHttpOutputMessage);

        assertThat(output.toString(), is(equalTo(
                headerLine + "\n" +
                        ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,\n" +
                        "Declaration ID,Import/Export,Declaration Source,Declaration Type,Epu Number,Entry Number,Entry Date,Route," +
                        "Goods Location,Dispatch Country,Destination Country,Consignee EORI,Consignee Name,Consignee Postcode," +
                        "Consignor EORI,Consignor Name,Consignor Postcode,Declarant EORI,Declarant Name,Declarant Postcode," +
                        "Consignee EORI,Consignee Name,Consignee Postcode,Consignor EORI,Consignor Name,Consignor Postcode" +
                        ",,,,,Transport Mode,,,,,,\n"
        )));
    }

    private ByteArrayOutputStream whenGivenOutput() throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        when(mockHttpOutputMessage.getBody()).thenReturn(output);
        when(mockHttpOutputMessage.getHeaders()).thenReturn(headers);
        return output;
    }

}
