package uk.gov.gsi.hmrc.cds.search.api.resources;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Hits;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.ElasticDeclarationSearchService;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.*;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@WebMvcTest(value = DeclarationResource.class, secure = false)
@ActiveProfiles("test")
public class DeclarationResourceIntegrationTest {

    private static final String EPU_NUMBER = "EPU_NUMBER";
    private static final String DECLARATION_ID_1 = "DECLARATION_ID_1";
    private static final String DECLARATION_ID_2 = "DECLARATION_ID_2";

    @MockBean
    private ElasticDeclarationSearchService elasticDeclarationSearchService;

    @Autowired
    private MockMvc mockMvc;

    private ResultActions resultActions;

    @Test
    public void getDeclarationDefinitionOk() throws Exception {
        this.mockMvc
                .perform(get("/declarations/definition").accept("application/json"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.definitions[0].id", is("declarationId")))
                .andExpect(jsonPath("$.definitions[0].header", is(true)))
                .andExpect(jsonPath("$.definitions[0].label", is("Declaration ID")))
                .andExpect(jsonPath("$.definitions[0].type", is("string")))
                .andExpect(jsonPath("$.definitions[0].path", is("")))
                .andExpect(jsonPath("$.definitions[6].type", is("timestamp")))
                .andExpect(jsonPath("$.definitions[10].path", is(".code")))
                .andExpect(jsonPath("$.definitions", hasSize(37)));
    }

    @Test
    public void getDeclarationItemDefinitionOk() throws Exception {
        this.mockMvc
                .perform(get("/declarations/items/definition").accept("application/json"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.definitions[0].id", is("itemRoute")))
                .andExpect(jsonPath("$.definitions[0].header", is(false)))
                .andExpect(jsonPath("$.definitions[0].label", is("Route of Entry")))
                .andExpect(jsonPath("$.definitions[0].type", is("string")))
                .andExpect(jsonPath("$.definitions[0].path", is("")))
                .andExpect(jsonPath("$.definitions[3].type", is("timestamp")))
                .andExpect(jsonPath("$.definitions[1].path", is(".code")))
                .andExpect(jsonPath("$.definitions", hasSize(19)));
    }

    @Test
    public void searchForMultipleDeclarationsWithResponseTypeObject() throws Exception {
        givenDeclarationSearchResult(asList(getDeclarationResponse(DECLARATION_ID_1), getDeclarationResponse(DECLARATION_ID_2)));
        whenISearchForDeclarationSearchResult(EPU_NUMBER);
        thenTheDeclarationSearchResponseIsAppropriate(2, DECLARATION_ID_1, EPU_NUMBER);
    }

    @Test
    public void searchWithAnEmptySearchTermOk() throws Exception {
        whenISearchForDeclarationSearchResult("");
        resultActions.andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setSearchTerm("");
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchForDeclarationId() throws Exception {
        givenDeclarationResult("declarationId", true);
        this.mockMvc
                .perform(get("/declarations/declarationId")
                        .accept(APPLICATION_JSON))
                        .andExpect(status().isOk());
        verify(elasticDeclarationSearchService).fetchDeclarationById("declarationId");
    }

    @Test
    public void declarationIdNotFound() throws Exception {
        givenDeclarationResult("unknown", false);
        this.mockMvc
                .perform(get("/declarations/unknown")
                        .accept(APPLICATION_JSON))
                        .andExpect(status().isNotFound());
        verify(elasticDeclarationSearchService).fetchDeclarationById("unknown");
    }

    @Test
    public void searchWithNoParametersOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest())
                .andExpect(status().isOk());
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(new SearchCriteria());
    }

    @Test
    public void searchWithAllParametersOk() throws Exception {
        this.mockMvc.perform(buildGetRequest()
                .param("pageSize", "5")
                .param("pageNumber", "1")
                .param("searchTerm", "term")
                .param("eori", "0123456789")
                .param("originCountryCode", "GB")
                .param("dispatchCountryCode", "GB")
                .param("destinationCountryCode", "GB")
                .param("transportModeCode", "01")
                .param("commodityCode", "0123456789")
                .param("goodsLocation", "ABC")
                .param("entryDateFrom", "2018-01-01")
                .param("entryDateTo", "2018-12-31")
                .param("clearanceDateFrom", "2018-01-01")
                .param("clearanceDateTo", "2018-12-31"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setPageSize(5);
        searchCriteria.setPageNumber(1);
        searchCriteria.setSearchTerm("term");
        searchCriteria.setEori("0123456789");
        searchCriteria.setOriginCountryCode(singletonList("GB"));
        searchCriteria.setDispatchCountryCode(singletonList("GB"));
        searchCriteria.setDestinationCountryCode(singletonList("GB"));
        searchCriteria.setTransportModeCode(singletonList("01"));
        searchCriteria.setCommodityCode(singletonList("0123456789"));
        searchCriteria.setGoodsLocation(singletonList("ABC"));
        searchCriteria.setEntryDateFrom(LocalDate.of(2018, 1, 1));
        searchCriteria.setEntryDateTo(LocalDate.of(2018, 12, 31));
        searchCriteria.setClearanceDateFrom(LocalDate.of(2018, 1, 1));
        searchCriteria.setClearanceDateTo(LocalDate.of(2018, 12, 31));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchForDeclarationsAsCsvOk() throws Exception {
        this.mockMvc
                .perform(get("/declarations").accept("text/csv"))
                .andExpect(status().isOk());
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(new SearchCriteria());
    }

    @Test
    public void searchWithEoriOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest()
                        .param("eori", "0123456789")
                )
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setEori("0123456789");
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithPageNumberOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest()
                        .param("originCountryCode", "GB")
                        .param("pageNumber", "1")
                )
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setPageNumber(1);
        searchCriteria.setOriginCountryCode(singletonList("GB"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithAnOriginCountryCodeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("originCountryCode", "GB"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setOriginCountryCode(singletonList("GB"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithMultipleOriginCountryCodesOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest()
                        .param("originCountryCode", "")
                        .param("originCountryCode", "GB")
                        .param("originCountryCode", "FR")
                        )
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setOriginCountryCode(asList("", "GB", "FR"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithEmptyOriginCountryCodeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("originCountryCode", ""))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setOriginCountryCode(singletonList(""));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithADispatchCountryCodeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("dispatchCountryCode", "GB"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDispatchCountryCode(singletonList("GB"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithMultipleDispatchCountryCodesOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest()
                        .param("dispatchCountryCode", "")
                        .param("dispatchCountryCode", "GB")
                        .param("dispatchCountryCode", "FR")
                )
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDispatchCountryCode(asList("", "GB", "FR"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithEmptyDispatchCountryCodeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("dispatchCountryCode", ""))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDispatchCountryCode(singletonList(""));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithADestinationCountryCodeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("destinationCountryCode", "GB"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDestinationCountryCode(singletonList("GB"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithMultipleDestinationCountryCodesOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest()
                        .param("destinationCountryCode", "")
                        .param("destinationCountryCode", "GB")
                        .param("destinationCountryCode", "FR")
                )
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDestinationCountryCode(asList("", "GB", "FR"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithEmptyDestinationCountryCodeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("destinationCountryCode", ""))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDestinationCountryCode(singletonList(""));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithATransportModeCodeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("transportModeCode", "01"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setTransportModeCode(singletonList("01"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithMultipleTransportModeCodesOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest()
                        .param("transportModeCode", "")
                        .param("transportModeCode", "01")
                        .param("transportModeCode", "02")
                )
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setTransportModeCode(asList("", "01", "02"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithEmptyTransportModeCodeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("transportModeCode", ""))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setTransportModeCode(singletonList(""));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithEmptyGoodsLocationOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("goodsLocation", ""))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setGoodsLocation(singletonList(""));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithAGoodsLocationOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("goodsLocation", "ABC"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setGoodsLocation(singletonList("ABC"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithMultipleGoodsLocationsOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest()
                        .param("goodsLocation", "ABC")
                        .param("goodsLocation", "DEF")
                )
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setGoodsLocation(asList("ABC", "DEF"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithEmptyCommodityCodeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("commodityCode", ""))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setCommodityCode(singletonList(""));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithAEmptyCommodityCodeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("commodityCode", "0123456789"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setCommodityCode(singletonList("0123456789"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithMultipleEmptyCommodityCodesOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest()
                        .param("commodityCode", "0123456789")
                        .param("commodityCode", "9876543210")
                )
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setCommodityCode(asList("0123456789", "9876543210"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }


    @Test
    public void searchWithAnEntryDateFromOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("entryDateFrom", "2018-01-01"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setEntryDateFrom(LocalDate.of(2018, 1, 1));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithAnEntryDateToOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("entryDateTo", "2018-12-31"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setEntryDateTo(LocalDate.of(2018, 12, 31));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithAClearanceDateFromOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("clearanceDateFrom", "2018-01-01"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setClearanceDateFrom(LocalDate.of(2018, 1, 1));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithAClearanceDateToOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("clearanceDateTo", "2018-12-31"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setClearanceDateTo(LocalDate.of(2018, 12, 31));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchForZeroResults() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("pageSize", "0"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setPageSize(0);
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithUnrecognisedParameter() throws Exception {
    	resultActions = this.mockMvc
    			.perform(get("/declarations")
    					.param("unrecognised", "true")
    					.accept(APPLICATION_JSON));
    	resultActions.andExpect(status().isBadRequest());
    	verifyZeroInteractions(elasticDeclarationSearchService);
    }
    
    @Test
    public void noMatchingDeclarations() throws Exception {
        givenDeclarationSearchResult(emptyList());
        whenISearchForDeclarationSearchResult(EPU_NUMBER);
        resultActions
                .andExpect(status().isOk())
                .andExpect(content().json("{ \"hits\": {\"total\": 0 },\"declarations\": []}"));
    }

    @Test
    public void searchWithEmptyDeclarationTypeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("declarationType", ""))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDeclarationType(singletonList(""));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithADeclarationTypeOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("declarationType", "X"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDeclarationType(singletonList("X"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithMultipleDeclarationTypesOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest()
                        .param("declarationType", "X")
                        .param("declarationType", "Y")
                )
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDeclarationType(asList("X", "Y"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithEmptyDeclarationSourceOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("declarationSource", ""))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDeclarationSource(singletonList(""));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithADeclarationSourceOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest().param("declarationSource", "CHIEF"))
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDeclarationSource(singletonList("CHIEF"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    @Test
    public void searchWithMultipleDeclarationSourcesOk() throws Exception {
        this.mockMvc
                .perform(buildGetRequest()
                        .param("declarationSource", "CHIEF")
                        .param("declarationSource", "CDS")
                )
                .andExpect(status().isOk());

        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDeclarationSource(asList("CHIEF", "CDS"));
        verify(elasticDeclarationSearchService).fetchDeclarationSearchResult(searchCriteria);
    }

    private void thenTheDeclarationSearchResponseIsAppropriate(int size, String entryReference, String epuNumber) throws Exception {
        resultActions
                .andExpect(jsonPath("$.declarations", hasSize(size)))
                .andExpect(jsonPath("$.declarations[0].declarationId", is(entryReference)))
                .andExpect(jsonPath("$.declarations[0].epuNumber", is(epuNumber)))
                .andExpect(jsonPath("$.declarations[1].declarationId", is(DECLARATION_ID_2)))
                .andExpect(jsonPath("$.declarations[1].epuNumber", is(EPU_NUMBER)))
                .andExpect(jsonPath("$.hits.total", is(size)));
    }

    private void whenISearchForDeclarationSearchResult(String searchTerm) throws Exception {
        resultActions = this.mockMvc
                .perform(buildGetRequest()
                        .param("searchTerm", searchTerm)
                );
    }

    private MockHttpServletRequestBuilder buildGetRequest() {
        return get("/declarations")
                .accept(APPLICATION_JSON);
    }

    private void givenDeclarationSearchResult(List<Declaration> declarationResponses) {
        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setSearchTerm(EPU_NUMBER);
        when(elasticDeclarationSearchService.fetchDeclarationSearchResult(searchCriteria)).thenReturn(
                DeclarationSearchResult.builder()
                        .hits(new Hits(declarationResponses.size()))
                        .declarations(declarationResponses)
                        .build()
        );
    }

    private void givenDeclarationResult(String decId, Boolean found) {
        Optional<Declaration> result = Optional.empty();
        if (found) {
            result = Optional.of(Declaration.builder().build());
        }
        when(elasticDeclarationSearchService.fetchDeclarationById(decId)).thenReturn(result);
    }

    private Declaration getDeclarationResponse(String declarationId) {
        return Declaration.builder()
                .declarationId(declarationId)
                .epuNumber(EPU_NUMBER)
                .build();
    }


}
