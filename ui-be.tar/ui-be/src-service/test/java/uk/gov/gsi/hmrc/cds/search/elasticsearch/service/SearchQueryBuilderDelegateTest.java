package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.junit.Ignore;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;

import java.time.LocalDate;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;
import static uk.gov.gsi.hmrc.cds.search.utils.TestHelper.SEARCH_QUERY_FACETS_FILE;
import static uk.gov.gsi.hmrc.cds.search.utils.TestHelper.SEARCH_QUERY_PAGINATION_FILE;
import static uk.gov.gsi.hmrc.cds.search.utils.TestHelper.getFileContent;

public class SearchQueryBuilderDelegateTest {

    private SearchQueryBuilderDelegate queryBuilderDelegate = new SearchQueryBuilderDelegate();
    private final SearchCriteria searchCriteria = new SearchCriteria();

    private static final String SEARCH_TERM = "122";
    private static final String EORI = "582109443894367";
    private static final String IN_CODE = "IN";
    private static final String NZ_CODE = "NZ";
    private static final String CA_CODE = "CA";
    private static final String CH_CODE = "CH";
    private static final String ABC_GOODS_LOCATION = "ABC";
    private static final String DEF_GOODS_LOCATION = "DEF";
    private static final String COMMODITY_CODE_1 = "0123456789";
    private static final String COMMODITY_CODE_2 = "9876543210";
    private static final String DEC_TYPE = "X";
    private static final String DEC_SOURCE = "DMS";
    private static final LocalDate FROM_DATE = LocalDate.of(2018, 1, 6);
    private static final LocalDate TO_DATE = LocalDate.of(2018, 1, 6);

    @Test
    public void facetFieldNameForLineFacets() {
        assertEquals(queryBuilderDelegate.getFacetFieldName("originCountryCode"), "lines.originCountryCode.prefix");
    }

    @Test
    public void facetFieldNameForOtherFacets() {
        assertEquals(queryBuilderDelegate.getFacetFieldName("dispatchCountryCode"), "dispatchCountryCode.prefix");
    }

    @Test
    @Ignore("Code needs refactoring to allow easier testing without resorting to checking json created by the ESClient")
    public void getQueryBuilderWithPagination() {
        final BoolQueryBuilder query = QueryBuilders.boolQuery().must(QueryBuilders.matchAllQuery());
        setSearchCriteria();
        assertEquals(queryBuilderDelegate.getQueryBuilderWithPagination(searchCriteria,query).toString(), getFileContent(SEARCH_QUERY_PAGINATION_FILE));
    }

    @Test
    @Ignore("Code needs refactoring to allow easier testing without resorting to checking json created by the ESClient")
    public void getQueryBuilderWithFacets() {
        final BoolQueryBuilder query = QueryBuilders.boolQuery().must(QueryBuilders.matchAllQuery());
        setSearchCriteria();
        assertEquals(queryBuilderDelegate.getQueryBuilderWithFacets(searchCriteria,query,"originCountryCode").toString(), getFileContent(SEARCH_QUERY_FACETS_FILE));
    }


    private void setSearchCriteria() {
        searchCriteria.setSearchTerm(SEARCH_TERM);
        searchCriteria.setEori(EORI);
        searchCriteria.setOriginCountryCode(asList(IN_CODE,NZ_CODE));
        searchCriteria.setDestinationCountryCode(asList(CA_CODE));
        searchCriteria.setDispatchCountryCode(asList(CH_CODE));
        searchCriteria.setGoodsLocation(asList(ABC_GOODS_LOCATION,DEF_GOODS_LOCATION));
        searchCriteria.setCommodityCode(asList(COMMODITY_CODE_1,COMMODITY_CODE_2));
        searchCriteria.setEntryDateFrom(FROM_DATE);
        searchCriteria.setEntryDateTo(TO_DATE);
        searchCriteria.setClearanceDateFrom(FROM_DATE);
        searchCriteria.setClearanceDateTo(TO_DATE);
        searchCriteria.setDeclarationType(asList(DEC_TYPE));
        searchCriteria.setDeclarationSource(asList(DEC_SOURCE));
    }

}
