package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.apache.http.Header;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.message.BasicHeader;
import org.apache.http.ssl.SSLContexts;
import org.elasticsearch.client.ResponseException;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.junit.After;
import org.mockito.Mock;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.connection.headers.ESHeaders;

import javax.net.ssl.SSLContext;
import java.io.File;

import static java.lang.String.format;
import static java.util.Collections.emptyMap;
import static org.apache.http.entity.ContentType.APPLICATION_JSON;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;
import static uk.gov.gsi.hmrc.cds.search.utils.TestHelper.SEARCH_MAPPINGS_FILE;
import static uk.gov.gsi.hmrc.cds.search.utils.TestHelper.getFileContent;

public abstract class CustomsSearchESIntegTestCase {

    private final static BasicHeader CONTENT_TYPE_HEADER =
            new BasicHeader("Content-Type", APPLICATION_JSON.toString());

    static final String DECLARATION_TYPE = "declaration";
    static final String ES_HOST = "localhost";
    static final int ES_PORT = 19200;

    SearchClient service;

    @Mock
    private ESHeaders esHeaders;
    private SearchQueryBuilderDelegate searchQueryBuilder = new SearchQueryBuilderDelegate();
    RestHighLevelClient client;


    void setUp(String index) {
        initMocks(this);
        when(esHeaders.getHeaders()).thenReturn( new Header[] {});
        this.client = esRestHighlevelClient();
        service = new SearchClient(this.client, index, esHeaders,searchQueryBuilder);
    }

    private RestHighLevelClient esRestHighlevelClient() {
        try {
            SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(
                    keystoreFile(),"password".toCharArray(),
                    new TrustSelfSignedStrategy()
                ).build();
            return new RestHighLevelClient(RestClient.builder(new HttpHost(ES_HOST, ES_PORT, "https")).setHttpClientConfigCallback(
                    httpClientConfig -> httpClientConfig.setDefaultCredentialsProvider(esCredentialsProvider()).setSSLContext(sslContext)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private File keystoreFile() {
        return new File(this.getClass().getClassLoader().getResource("ssl-certs/e2e.jks").getFile());
    }

    private CredentialsProvider esCredentialsProvider() {
        CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
        credentialsProvider.setCredentials(
                AuthScope.ANY, new UsernamePasswordCredentials("elastic", "elastic"));

        return credentialsProvider;
    }

    void createIndex(String indexName) throws Exception {
        try {
            client.getLowLevelClient().performRequest("DELETE", indexName);
        } catch (ResponseException e) {
            // expect index not to be there most of the time
            if (e.getResponse().getStatusLine().getStatusCode() != 404) {
                e.printStackTrace();
            }
        }
        client.getLowLevelClient()
                .performRequest(
                        "PUT",
                        indexName,
                        emptyMap(),
                        new StringEntity(getFileContent(SEARCH_MAPPINGS_FILE)),
                        CONTENT_TYPE_HEADER);
    }

    void refresh(String indexName) throws Exception {
        client.getLowLevelClient().performRequest("POST", format("/%s/_refresh", indexName), CONTENT_TYPE_HEADER);
    }

    @After
    public void cleanUp() throws Exception {
        this.client.close();
    }

}
