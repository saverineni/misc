package uk.gov.gsi.hmrc.cds.search.api.resources;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import uk.gov.gsi.hmrc.cds.search.security.jwt.JwtTokenService;


@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@WebMvcTest(controllers = AuthenticationResource.class, secure = false)
public class AuthenticationResourceIntegrationTest {
    private static final String REQUEST_BODY = "{\"pid\": \"dev\",\"password\": \"d3v\"}";
    private static final String TOKEN = "the-token";

    @Autowired
    private MockMvc mvc;
    @MockBean
    private AuthenticationManager authenticationManager;
    @MockBean
    private JwtTokenService jwtTokenService;

    private Authentication authentication = mock(Authentication.class);

    @Test
    public void shouldGetJwtTokenResponseForValidLoginCredentialsAndAuthority() throws Exception {
        List<GrantedAuthority> grantedAuthorities = Arrays.asList(
                () -> "not-for-search",
                () -> "auth2"
        );

        when((Object)authentication.getAuthorities()).thenReturn(grantedAuthorities);
        when(authenticationManager.authenticate(Mockito.any(UsernamePasswordAuthenticationToken.class))).thenReturn(authentication);
        when(jwtTokenService.createToken(authentication)).thenReturn(TOKEN);

        mvc.perform(post("/authentication/token").contentType("application/json")
                                                 .content(REQUEST_BODY))
                .andExpect(jsonPath("$.token", is(TOKEN)))
                .andExpect(status().isOk());
    }

    @Test
    public void shouldValidateTheLoginCredentials() throws Exception {
        ArgumentCaptor<UsernamePasswordAuthenticationToken> usernameAndPasswordCaptor =
                ArgumentCaptor.forClass(UsernamePasswordAuthenticationToken.class);
        when(authenticationManager.authenticate(usernameAndPasswordCaptor.capture())).thenReturn(authentication);

        mvc.perform(post("/authentication/token").contentType("application/json")
                                                 .content(REQUEST_BODY));

        UsernamePasswordAuthenticationToken usernameAndPassword = usernameAndPasswordCaptor.getValue();
        assertThat(usernameAndPassword.getPrincipal(), is("dev"));
        assertThat(usernameAndPassword.getCredentials(), is("d3v"));
    }

    @Test
    public void throwsAuthenticationExceptionWhenGetJwtTokenRequestBodyEmpty() throws Exception {
        mvc.perform(get("/authentication/token").accept("application/json"))
                .andExpect(status().isMethodNotAllowed());
    }

    @Test
    public void invalidGrantedAuthoritiesReturnsForbiddenStatus() throws Exception {
        List<GrantedAuthority> grantedAuthorities = Arrays.asList(
                    () -> "not-for-search"
                );

        when((Object)authentication.getAuthorities()).thenReturn(grantedAuthorities);
        when(authenticationManager.authenticate(Mockito.any(UsernamePasswordAuthenticationToken.class))).thenReturn(authentication);

        mvc.perform(post("/authentication/token").contentType("application/json").content(REQUEST_BODY))
                .andExpect(status().isForbidden());
    }

    @Test
    public void invalidCredendialsReturnsUnauthorizedStatus() throws Exception {
        when(authenticationManager.authenticate(Mockito.any(UsernamePasswordAuthenticationToken.class)))
                .thenThrow(new BadCredentialsException("test"));

        mvc.perform(post("/authentication/token").contentType("application/json").content(REQUEST_BODY))
                .andExpect(status().isUnauthorized());
    }
}