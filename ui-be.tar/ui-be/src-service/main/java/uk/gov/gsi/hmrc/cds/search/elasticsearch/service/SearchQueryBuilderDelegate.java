package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import lombok.RequiredArgsConstructor;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;

import java.time.LocalDateTime;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.stream.Stream;

import static org.elasticsearch.index.query.QueryBuilders.*;
import static org.elasticsearch.search.aggregations.AggregationBuilders.terms;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.helper.SearchQueryBuilderUtils.*;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.helper.SearchQueryBuilderUtils.FieldMapping.getFieldCardinality;

@Component
@RequiredArgsConstructor
public class SearchQueryBuilderDelegate {

    public String getFacetFieldName(String facetType) {
        return LINE_FACETS.contains(facetType) ? "lines." + facetType + ".prefix" : facetType + ".prefix";
    }

    public SearchSourceBuilder getQueryBuilderWithPagination(SearchCriteria searchCriteria, BoolQueryBuilder query) {
        final SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        final SearchSourceBuilder searchSourceBuilderWithQuery = searchSourceBuilder.query(getQueryBuilder(searchCriteria, query));
        int offSet = (searchCriteria.getPageNumber() - 1) * searchCriteria.getPageSize();
        searchSourceBuilderWithQuery.from(offSet);
        searchSourceBuilderWithQuery.size(searchCriteria.getPageSize());
        return searchSourceBuilderWithQuery;
    }

    public SearchSourceBuilder getQueryBuilderWithFacets(SearchCriteria searchCriteria, BoolQueryBuilder query ,String facetType) {
        final SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        final Entry<String,Integer> entry = getFieldCardinality(facetType);
        searchSourceBuilder.query(getQueryBuilder(searchCriteria, query)).size(0);
        searchSourceBuilder
                .aggregation(
                        terms(FACETS).field(entry.getKey()).size(entry.getValue().intValue())
                );
        return searchSourceBuilder;
    }

    /*
     * This method is used to build search query on all search criteria fields including query facets
     */
    private QueryBuilder getQueryBuilder(SearchCriteria searchCriteria, BoolQueryBuilder query) {
        buildTermQuery(query,searchCriteria.optionalSearchTerm(),ALL_SEARCH_FIELDS);
        buildTermQuery(query,searchCriteria.optionalEori(),EORI_FIELDS);

        buildDateRangeQuery(query, ENTRY_DATE, searchCriteria.optionalEntryDateTimeFrom(), searchCriteria.optionalEntryDateTimeTo());
        buildDateRangeQuery(query, CLEARANCE_DATE, searchCriteria.optionalClearanceDateTimeFrom(), searchCriteria.optionalClearanceDateTimeTo());

        buildTermsQuery(searchCriteria, query);

        return query;
    }

    private void buildTermsQuery(SearchCriteria searchCriteria, BoolQueryBuilder query) {
        buildTermListQuery(query, searchCriteria.getOriginCountryCode().stream(), LINES_ORIGIN_COUNTRY_CODE);
        buildTermListQuery(query, searchCriteria.getDispatchCountryCode().stream(), DISPATCH_COUNTRY_CODE);
        buildTermListQuery(query, searchCriteria.getDestinationCountryCode().stream(), DESTINATION_COUNTRY_CODE);
        buildTermListQuery(query, searchCriteria.getTransportModeCode().stream(), TRANSPORT_MODE_CODE);
        buildTermListQuery(query, searchCriteria.getGoodsLocation().stream(), GOODS_LOCATION);
        buildTermListQuery(query, searchCriteria.getCommodityCode().stream(), LINES_COMMODITY_CODE);
        buildTermListQuery(query, searchCriteria.getDeclarationType().stream(), DECLARATION_TYPE);
        buildTermListQuery(query, searchCriteria.getDeclarationSource().stream(), DECLARATION_SOURCE);
    }

    private BoolQueryBuilder shouldArray(BoolQueryBuilder query, String value, String term) {
        return query.should(termQuery(term, value));
    }

    /*
     * This method is used for collections of String data type fields
     * viz  origin country, dispatch country, destination country,
     *      transport mode, goods location, commodity code
     *      declaration type, declaration source.
     */
    private void buildTermListQuery(BoolQueryBuilder query, Stream<String> stream, String facetType) {
        BoolQueryBuilder queryBuilder = boolQuery();
        stream.map(facetId -> shouldArray(queryBuilder, facetId, facetType)).reduce(query, BoolQueryBuilder::must);
    }

    /*
     * This method is used for String data type fields. Ex: search term, eori etc
     */
    private void buildTermQuery(BoolQueryBuilder query, Optional<String> term , String[] fields ) {
        term.map(it -> query.must(multiMatchQuery(it, fields)));
    }

    /*
     * This method is used for Date data type fields. Ex: entry date, clearance date etc
     */
    private void buildDateRangeQuery(BoolQueryBuilder query, String field, Optional<LocalDateTime> from, Optional<LocalDateTime> to) {
        if (from.isPresent() || to.isPresent()) {
            RangeQueryBuilder rangeQuery = rangeQuery(field);
            RangeQueryBuilder rangeWithFrom = from.map(dateTime ->
                    rangeQuery.gte(dateTime.format(esDateTimeFormatter))
            ).orElse(rangeQuery);
            RangeQueryBuilder rangeWithTo = to.map(dateTime ->
                    rangeWithFrom.lte(dateTime.format(esDateTimeFormatter))
            ).orElse(rangeWithFrom);
            query.must(rangeWithTo);
        }
    }
}