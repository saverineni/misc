package uk.gov.gsi.hmrc.cds.search.api.dto;

import lombok.Data;

@Data
public class SearchUserInfo {

    private String pid;
    private String firstName;
    private String lastName;
    private String department;

}
