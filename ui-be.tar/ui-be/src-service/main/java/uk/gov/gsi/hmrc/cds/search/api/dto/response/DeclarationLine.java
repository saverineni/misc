package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.Trader;
import uk.gov.gsi.hmrc.cds.search.api.dto.ViewDefinition;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeclarationLine {
    private int itemNumber;
    @ViewDefinition(id = "itemRoute", order = 1, label = "Route of Entry")
    private String itemRoute;
    @ViewDefinition(id = "itemDispatchCountry", order = 2, label = "Country of Dispatch", path = ".code")
    private Country itemDispatchCountry;
    @ViewDefinition(id = "itemDestinationCountry", order = 3, label = "Country of Destination", path = ".code")
    private Country itemDestinationCountry;
    @ViewDefinition(id = "clearanceDate", order = 4, label = "Clearance Date", type = "timestamp")
    private String clearanceDate;
    @ViewDefinition(id = "cpc", order = 5, label = "CPC")
    private String cpc;
    @ViewDefinition(id = "originCountry", order = 6, label = "Country of Origin", path = ".code")
    private Country originCountry;
    @ViewDefinition(id = "commodityCode", order = 7, label = "Commodity Code")
    private String commodityCode;
    @ViewDefinition(id = "itemConsignee", order = 8, label = "Consignee EORI", path = ".eori")
    @ViewDefinition(id = "itemConsignee", order = 9, label = "Consignee Name", path = ".name")
    @ViewDefinition(id = "itemConsignee", order = 10, label = "Consignee Postcode", path = ".postcode")
    private Trader itemConsignee;
    @ViewDefinition(id = "itemConsignor", order = 11, label = "Consignor EORI", path = ".eori")
    @ViewDefinition(id = "itemConsignor", order = 12, label = "Consignor Name", path = ".name")
    @ViewDefinition(id = "itemConsignor", order = 13, label = "Consignor Postcode", path = ".postcode")
    private Trader itemConsignor;
    @ViewDefinition(id = "itemConsigneeTurn", order = 14, label = "Consignee EORI")
    private String itemConsigneeTurn;
    @ViewDefinition(id = "itemConsigneeName", order = 15, label = "Consignee Name")
    private String itemConsigneeName;
    @ViewDefinition(id = "itemConsigneePostcode", order = 16, label = "Consignee Postcode")
    private String itemConsigneePostcode;
    @ViewDefinition(id = "itemConsignorTurn", order = 17, label = "Consignor EORI")
    private String itemConsignorTurn;
    @ViewDefinition(id = "itemConsignorName", order = 18, label = "Consignor Name")
    private String itemConsignorName;
    @ViewDefinition(id = "itemConsignorPostcode", order = 19, label = "Consignor Postcode")
    private String itemConsignorPostcode;
}
