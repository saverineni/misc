package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.Trader;
import uk.gov.gsi.hmrc.cds.search.api.dto.ViewDefinition;

import java.util.List;

import static java.util.Collections.emptyList;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Declaration {
    @ViewDefinition(id = "declarationId", order = 1, label = "Declaration ID", header = true)
    private String declarationId;
    @ViewDefinition(id = "importExportIndicator", order = 2, label = "Import/Export", header = true)
    private String importExportIndicator;
    @ViewDefinition(id = "declarationSource" , order = 3, label = "Declaration Source", header = true)
    private String declarationSource;
    @ViewDefinition(id = "declarationType" , order = 4, label = "Declaration Type", header = true)
    private String declarationType;
    @ViewDefinition(id = "epuNumber" , order = 5, label = "EPU")
    private String epuNumber;
    @ViewDefinition(id = "entryNumber" , order = 6, label = "Entry Number")
    private String entryNumber;
    @ViewDefinition(id = "entryDate" , order = 7, label = "Entry Date", type = "timestamp")
    private String entryDate;
    @ViewDefinition(id = "route" , order = 8, label = "Route of Entry")
    private String route;
    @ViewDefinition(id = "goodsLocation" , order = 9, label = "Goods Location")
    private String goodsLocation;
    @ViewDefinition(id = "dispatchCountry" , order = 10, label = "Country of Dispatch", path = ".code")
    private Country dispatchCountry;
    @ViewDefinition(id = "destinationCountry" , order = 11, label = "Country of Destination", path = ".code")
    private Country destinationCountry;
    @ViewDefinition(id = "consignee", order = 12, label = "Consignee EORI", path = ".eori")
    @ViewDefinition(id = "consignee", order = 13, label = "Consignee Name", path = ".name")
    @ViewDefinition(id = "consignee", order = 14, label = "Consignee Postcode", path = ".postcode")
    private Trader consignee;
    @ViewDefinition(id = "consignor", order = 15, label = "Consignor EORI", path = ".eori")
    @ViewDefinition(id = "consignor", order = 16, label = "Consignor Name", path = ".name")
    @ViewDefinition(id = "consignor", order = 17, label = "Consignor Postcode", path = ".postcode")
    private Trader consignor;
    @ViewDefinition(id = "declarant", order = 18, label = "Declarant EORI", path = ".eori")
    @ViewDefinition(id = "declarant", order = 19, label = "Declarant Name", path = ".name")
    @ViewDefinition(id = "declarant", order = 20, label = "Declarant Postcode", path = ".postcode")
    private Trader declarant;
    @ViewDefinition(id = "consigneeTurn" , order = 21, label = "Consignee EORI")
    private String consigneeTurn;
    @ViewDefinition(id = "consigneeName" , order = 22, label = "Consignee Name")
    private String consigneeName;
    @ViewDefinition(id = "consigneePostcode" , order = 23, label = "Consignee Postcode")
    private String consigneePostcode;
    @ViewDefinition(id = "consignorTurn" , order = 24, label = "Consignor EORI")
    private String consignorTurn;
    @ViewDefinition(id = "consignorName" , order = 25, label = "Consignor Name")
    private String consignorName;
    @ViewDefinition(id = "consignorPostcode" , order = 26, label = "Consignor Postcode")
    private String consignorPostcode;
    @ViewDefinition(id = "declarantTurn" , order = 27, label = "Declarant EORI")
    private String declarantTurn;
    @ViewDefinition(id = "declarantName" , order = 28, label = "Declarant Name")
    private String declarantName;
    @ViewDefinition(id = "declarantPostcode" , order = 29, label = "Declarant Postcode")
    private String declarantPostcode;
    @ViewDefinition(id = "declarantRepresentation" , order = 30, label = "Declarant Representation")
    private String declarantRepresentation;
    @ViewDefinition(id = "transportModeCode" , order = 31, label = "Mode of Transport")
    private String transportModeCode;
    @ViewDefinition(id = "inlandTransportMode" , order = 32, label = "Inland Mode of Transport")
    private String inlandTransportMode;
    @ViewDefinition(id = "placeOfLoading" , order = 33, label = "Place of Loading")
    private String placeOfLoading;
    @ViewDefinition(id = "transportId" , order = 34, label = "Transport ID")
    private String transportId;
    @ViewDefinition(id = "totalPackages" , order = 35, label = "Total Packages")
    private String totalPackages;
    @ViewDefinition(id = "invoiceCurrency" , order = 36, label = "Invoice Currency")
    private String invoiceCurrency;
    @ViewDefinition(id = "invoiceTotal" , order = 37, label = "Invoice Total")
    private String invoiceTotal;

    private List<DeclarationLine> lines;

    public List<DeclarationLine> getLines() {
        return lines == null ? emptyList() : lines;
    }

}
