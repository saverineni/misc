package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.Facet;

@Component
public class BucketToFacetConverter implements Converter<Terms.Bucket, Facet> {

    @Override
    public Facet convert(Terms.Bucket bucket) {
        return Facet.builder()
                .id(bucket.getKeyAsString())
                .count(bucket.getDocCount())
                .build();
    }

}
