package uk.gov.gsi.hmrc.cds.search.api.dto.authentication;

import lombok.Data;

@Data
public class LoginRequest {
    private String pid;
    private String password;
}