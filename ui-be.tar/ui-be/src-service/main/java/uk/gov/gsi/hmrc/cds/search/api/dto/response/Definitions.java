package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import uk.gov.gsi.hmrc.cds.search.api.dto.ViewDefinition;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Definitions {
    private List<ViewDefinition> definitions;
}
