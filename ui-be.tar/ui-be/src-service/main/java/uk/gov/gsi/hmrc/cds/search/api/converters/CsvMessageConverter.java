package uk.gov.gsi.hmrc.cds.search.api.converters;

import com.opencsv.CSVWriter;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.converter.AbstractHttpMessageConverter;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.Trader;
import uk.gov.gsi.hmrc.cds.search.api.dto.ViewDefinition;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;

@Component
@Slf4j
public class CsvMessageConverter extends AbstractHttpMessageConverter<DeclarationSearchResult> {

    private static final String CONVERTER_MEDIA_TYPE = "text/csv";

    static final String[] HEADERS = ViewDefinition.Utils.orderedViewDefinitionFields(Declaration.class)
            .flatMap(field -> Stream.of(field.getAnnotationsByType(ViewDefinition.class)))
            .map(ViewDefinition::label)
            .toArray(String[]::new);

    public CsvMessageConverter() {
        super(MediaType.valueOf(CONVERTER_MEDIA_TYPE));
    }

    @Override
    protected boolean supports(Class<?> aClass) {
        return DeclarationSearchResult.class.isAssignableFrom(aClass);
    }

    @Override
    protected DeclarationSearchResult readInternal(Class<? extends DeclarationSearchResult> aClass, HttpInputMessage httpInputMessage)
            throws IOException, HttpMessageNotReadableException {
        throw new HttpMessageNotReadableException("Not supported");
    }

    private String[] asOrderedStringValues(Declaration declaration) {
        return ViewDefinition.Utils.orderedViewDefinitionFields(Declaration.class)
                .flatMap(field -> {
                    field.setAccessible(true);
                    try {
                        if (field.getType() == String.class) {
                            return Stream.of((String) field.get(declaration));
                        } else if (field.getType() == Country.class) {
                            return Optional.ofNullable((Country) field.get(declaration))
                                    .map(c -> Stream.of(c.getCode())).orElse(Stream.of(""));
                        } else if (field.getType() == Trader.class) {
                            return Optional.ofNullable((Trader) field.get(declaration))
                                    .map(t -> Stream.of(t.getEori(), t.getName(), t.getPostcode())).orElse(Stream.of("", "", ""));
                        } else {
                            return Stream.empty();
                        }
                    } catch (IllegalAccessException e) {
                        log.error("Unable to access view definition field for declaration", e);
                        return Stream.empty();
                    }
                })
                .toArray(String[]::new);
    }

    @Override
    protected void writeInternal(DeclarationSearchResult searchResult, HttpOutputMessage httpOutputMessage) throws HttpMessageNotWritableException {
        httpOutputMessage.getHeaders().add(HttpHeaders.CONTENT_TYPE, CONVERTER_MEDIA_TYPE);

        try (final Writer writer = new OutputStreamWriter(httpOutputMessage.getBody())) {

            try (CSVWriter csvWriter = new CSVWriter(writer,
                    CSVWriter.DEFAULT_SEPARATOR,
                    CSVWriter.NO_QUOTE_CHARACTER,
                    CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                    CSVWriter.DEFAULT_LINE_END)) {

                csvWriter.writeNext(HEADERS);

                List<String[]> declarationHeaders = searchResult.getDeclarations().stream()
                        .map(this::asOrderedStringValues)
                        .collect(Collectors.toList());
                csvWriter.writeAll(declarationHeaders);
            }
        } catch (Exception ex) {
            logger.error("Unable to output declarations in CSV format.", ex);
        }
    }
}
