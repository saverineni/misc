package search.manage

import org.apache.http.client.fluent.Executor
import org.apache.http.client.fluent.Request
import org.apache.http.impl.client.BasicResponseHandler

import groovy.json.JsonSlurper

class ManageResource {
    private static httpClient = { -> new search.NoSslHttpClient().httpClient() }

    static GET(type) {
        Executor executor = Executor.newInstance(httpClient())
        def response = executor.execute(Request.Get("https://localhost:18010/manage/$type")).returnResponse()

        [
            status: response.statusLine.statusCode,
            json: { -> ManageResource.asJson(response) }
        ]
    }

    private static asJson(response) {
        def responseString = new BasicResponseHandler().handleResponse(response)
        new JsonSlurper().parseText(responseString)
    }
}
