package search.declarations

import org.apache.http.auth.AuthScope
import org.apache.http.auth.UsernamePasswordCredentials
import org.apache.http.client.CredentialsProvider
import org.apache.http.impl.client.BasicCredentialsProvider

import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import org.apache.http.HttpHost
import org.apache.http.entity.StringEntity
import org.apache.http.message.BasicHeader
import org.elasticsearch.client.RestClient
import org.elasticsearch.client.RestHighLevelClient
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.ssl.SSLContexts;

import static java.util.Collections.emptyMap
import static org.apache.http.entity.ContentType.APPLICATION_JSON
import static org.apache.http.HttpHeaders.CONTENT_TYPE

class DeclarationsIndex {
	static final MAPPINGS_FILE = "/searchingestion/mapping.json"
	static final DECLARATIONS_DIR = "/declarations"
	static final CONTENT_TYPE_HEADER = new BasicHeader(CONTENT_TYPE, "application/json")

	def recreateAndPopulateIndex() {
		def sslContext =  SSLContexts.custom().loadTrustMaterial(new TrustSelfSignedStrategy()).build();
        CredentialsProvider credentialsProvider = new BasicCredentialsProvider()
        credentialsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials("elastic", "elastic"))
        def client = new RestHighLevelClient(
                RestClient.builder(new HttpHost("localhost", 19200, 'https'))
                          .setHttpClientConfigCallback({ httpClientBuilder ->
                                httpClientBuilder.setDefaultCredentialsProvider(credentialsProvider).setSSLContext(sslContext)
                          })
                ).getLowLevelClient()
                
		try {
			client.performRequest("DELETE", "customs_search_service")
		} catch (Exception e) {
			// will throw exception if index not present
		}

		client.performRequest("PUT",
				"customs_search_service",
				emptyMap(),
				new StringEntity(getMappingsJson(), APPLICATION_JSON),
				CONTENT_TYPE_HEADER)

        new File(getClass().getResource(DECLARATIONS_DIR).toURI()).listFiles().each {
            def declarationId = it.name - '.json'
    		client.performRequest("PUT",
    				"/customs_search_service/declaration/$declarationId",
    				emptyMap(),
    				new StringEntity(it.text, APPLICATION_JSON),
    				CONTENT_TYPE_HEADER)
		}

		client.performRequest("POST",
				"/customs_search_service/_refresh", CONTENT_TYPE_HEADER)
	}

	def getApiFormatDeclaration(String fileName) {
		new JsonSlurper().parseText(getFileContent(fileName))
	}

	def getDeclarationDefinition() {
		new JsonSlurper().parseText(getFileContent('/declaration-definition.json'))
	}

	def getDeclarationPreviewDefinition() {
		new JsonSlurper().parseText(getFileContent('/declaration-preview-definition.json'))
	}

	def getDeclarationItemsDefinition() {
		new JsonSlurper().parseText(getFileContent('/declaration-items-definition.json'))
	}

	String getFileContent(String fileName) {
		new File(getClass().getResource(fileName).toURI()).text
	}

	String getMappingsJson() {
		getFileContent(MAPPINGS_FILE)
	}
}
