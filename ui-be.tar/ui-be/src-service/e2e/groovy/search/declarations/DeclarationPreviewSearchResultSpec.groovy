package search.declarations

import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

class DeclarationPreviewSearchResultSpec extends Specification {

    @Shared expectedDeclaration


    def setupSpec() {
        def index = new DeclarationsIndex()
        index.recreateAndPopulateIndex()
        expectedDeclaration = index.getApiFormatDeclaration('/2000000000000001-preview.json')
    }

    def 'Response status should be OK'() {
        when:
        def response = SearchResource.authenticatedGet('search', ['searchTerm': [expectedDeclaration.declarationId]])

        then:
        response.statusLine.statusCode == 200
    }

    def 'should not accept unknown parameters'() {
        when:
        def response = SearchResource.authenticatedGet('search', ['unknown': [expectedDeclaration.declarationId]])

        then:
        response.statusLine.statusCode == 400
    }

    def 'unauthenticated request should give unauthorized'() {
        when:
        def response = SearchResource.unauthenticatedGet('search', ['searchTerm': ['']])

        then:
        response.statusLine.statusCode == 401
    }

    def 'declaration preview without lines should have correct count'() {
        when:
        def response = SearchResource.authenticatedGet('search', ['searchTerm': ['2000000000000004']])
        def result = SearchResource.asJson(response)

        then:
        result.declarations[0].lineCount == 0
    }

    @Unroll
    def 'valid search term for #field gives the correct declaration response'(String searchTerm, String field) {
        given:
        def response = SearchResource.authenticatedGet('search', ['searchTerm': [searchTerm]])
        def result = SearchResource.asJson(response)

        expect:
        result.declarations == [expectedDeclaration]

        where:
        searchTerm                  | field
        '2000000000000001'          | 'declarationId'
        '219'                       | 'epuNumber'
        '249099X'                   | 'entryNumber'
        'Header%20NAD%20NAME'       | 'consigneeName'
        'hN4%200Pc'                 | 'consigneePostcode'
        'HEADer%20Consignor%20naME' | 'consignorName'
        'Ab4%206cd'                 | 'consignorPostcode'
        '976072558688'              | 'consigneeTurn'
        '582109443894367'           | 'consignorTurn'
        '551030'                    | 'line.commodityCode'
        'Pg'                        | 'line.originCountry.code.codeText'
        '4000C36'                   | 'line.cpc'
        'item%20NAD%20NaMe'         | 'line.itemConsigneeName'
        'In4%200Pc'                 | 'line.itemConsigneePostcode'
        'Item-conSignor-NAME'       | 'line.itemConsignorName'
        'ITem-Consignor-Postcode'   | 'line.itemConsignorPostcode'
        '731411813911'              | 'line.itemConsigneeTurn'
        'item-consignor-turn'       | 'line.itemConsignorTurn'
    }

    def 'first page of results should be returned for no search term'() {
        given:
        def response = SearchResource.authenticatedGet('search', [])
        def result = SearchResource.asJson(response)

        expect:
        result.hits.total == 5
    }

    def 'first page of results should be returned for empty search term'() {
        given:
        def response = SearchResource.authenticatedGet('search', ['searchTerm': ['']])
        def result = SearchResource.asJson(response)

        expect:
        result.hits.total == 5
    }

    def 'first page of results number determined by pageSize parameter'() {
        given:
        def response = SearchResource.authenticatedGet('search', ['pageSize': ['2']])
        def result = SearchResource.asJson(response)

        expect:
        result.declarations.size() == 2
    }

    def 'search for 0 pageSize returns no results'() {
        given:
        def response = SearchResource.authenticatedGet('search', ['pageSize': ['0']])
        def result = SearchResource.asJson(response)

        expect:
        result.declarations.size() == 0
    }

    def 'no matching declarations returns an empty result'() {
        given: 'user signed in successfully'

        when:
        def response = SearchResource.authenticatedGet('search', ['searchTerm': ['INVALID_DEC_ID']])

        then:
        response.statusLine.statusCode == 200
        SearchResource.asJson(response) == [
                hits        : [
                        total: 0
                ],
                declarations: []
        ]
    }

    @Unroll
    def 'search for #params returns matching declarations'(params, expectedDeclarationIds) {
        given:
        def response = SearchResource.authenticatedGet('search', params)

        expect:
        response.statusLine.statusCode == 200
        SearchResource.asDeclarationIds(response).sort() == expectedDeclarationIds

        where:
        params                                                                        | expectedDeclarationIds
        ['originCountryCode': ['PG']]                                                 | ['2000000000000001']
        ['originCountryCode': ['PI', 'PH']]                                           | ['2000000000000002', '2000000000000003', '2000000000000005']

        ['dispatchCountryCode': ['dispatch-country-code2']]                           | ['2000000000000002']
        ['destinationCountryCode': ['TX']]                                            | ['2000000000000003', '2000000000000004']
        ['transportModeCode': ['tme']]                                                | ['2000000000000003', '2000000000000004']
        ['entryDateFrom': ['2018-01-03']]                                             | ['2000000000000003', '2000000000000004']
        ['entryDateTo': ['2018-01-02']]                                               | ['2000000000000001', '2000000000000002', '2000000000000005']
        ['entryDateFrom': ['2018-01-02'], 'entryDateTo': ['2018-01-03']]              | ['2000000000000002', '2000000000000003', '2000000000000005']
        ['entryDateFrom': ['2018-01-02'], 'entryDateTo': ['2018-01-02']]              | ['2000000000000002', '2000000000000005']
        ['clearanceDateFrom': ['2018-01-02']]                                         | ['2000000000000002', '2000000000000003']
        ['clearanceDateTo': ['2018-01-02']]                                           | ['2000000000000001', '2000000000000002']
        ['clearanceDateFrom': ['2018-01-02'], 'clearanceDateTo': ['2018-01-02']]      | ['2000000000000002']
        ['clearanceDateFrom': ['2018-01-08'], 'clearanceDateTo': ['2018-01-10']]      | ['2000000000000003']
        ['searchTerm': ['220'], 'dispatchCountryCode': ['dispatch-country-code2']]    | ['2000000000000002']

        ['entryDateFrom'    : ['2018-01-02'], 'entryDateTo': ['2018-01-02'],
         'originCountryCode': ['PH']]                                                 | ['2000000000000002', '2000000000000005']

        ['goodsLocation': ['LCX']]                                                    | ['2000000000000002']
        ['goodsLocation': ['LCZ']]                                                    | ['2000000000000003', '2000000000000004']
        ['goodsLocation': ['LCY', 'LCZ']]                                             | ['2000000000000001', '2000000000000003', '2000000000000004']

        ['commodityCode': ['551030']]                                                 | ['2000000000000001']
        ['declarationType': ['X']]                                                    | ['2000000000000001']
        ['declarationType': ['Y']]                                                    | ['2000000000000002']

        ['searchTerm'            : ['220'], 'originCountryCode': ['PH'],
         'dispatchCountryCode'   : ['dispatch-country-code2'], 'commodityCode': ['551031'],
         'destinationCountryCode': ['TW'], 'transportModeCode': ['tmd'],
         'goodsLocation'         : ['LCX'], 'declarationType': ['Y'],
         'entryDateFrom'         : ['2018-01-02'], 'entryDateTo': ['2018-01-02'],
         'clearanceDateFrom'     : ['2018-01-02'], 'clearanceDateTo': ['2018-01-02']] | ['2000000000000002']
    }

    String getFileContent(String fileName) {
        new File(getClass().getResource(fileName).toURI()).text
    }
}
