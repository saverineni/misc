package search.declarations

import spock.lang.Shared
import spock.lang.Specification

class DeclarationDefinitionSpec extends Specification {

    @Shared index

    def setupSpec() {
        index = new DeclarationsIndex()
    }

    def 'returns the expected definition'() {
        when:
        def expected = index.getDeclarationDefinition()
        def response = SearchResource.authenticatedGetDefinition()
        def result = SearchResource.asJson(response)

        then:
        result == expected
    }

    def 'returns the expected preview definition'() {
        when:
        def expected = index.getDeclarationPreviewDefinition()
        def response = SearchResource.authenticatedGetPreviewsDefinition()
        def result = SearchResource.asJson(response)

        then:
        result == expected
    }

    def 'returns the expected items definition'() {
        when:
        def expected = index.getDeclarationItemsDefinition()
        def response = SearchResource.authenticatedGetItemsDefinition()
        def result = SearchResource.asJson(response)

        then:
        result == expected
    }

}
