import { Injectable } from '@angular/core';

@Injectable()
export class HttpNotificationService {
  private _waiting: boolean = false;

  waiting() {
    return this._waiting;
  }

  requesting() {
    this._waiting = true;
  }

  complete() {
    this._waiting = false;
  }
}
