import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {By} from '@angular/platform-browser';
import {CdsNavbarComponent} from './cds-navbar.component';
import {NavigationService} from '../../declaration/search/navigation.service';
import {MatIconModule} from "@angular/material";
import {SignInRouterService} from "../../authentication/sign-in/sign-in-router.service";
import {AuthenticationService} from "../../authentication/authentication.service";
import { TogglePanelService } from '../../declaration/search/search-filter/toggle-panel.service';
import { TogglePanel } from '../../declaration/search/search-filter/toggle-panel';

describe('CdsNavbarComponent', () => {
  let component: CdsNavbarComponent;
  let fixture: ComponentFixture<CdsNavbarComponent>;

  let navigationService = {
    navigateToSearch: (bool) => {},
    navigateToHelp: () => {}
  } as NavigationService;

  let authenticationService = {
    signOut: () => { }
  } as AuthenticationService;

  let signInRouterService = {
    navigateToSignIn: () => { }
  } as SignInRouterService;

  let togglePanelService = {
    update: (togglePanel) => {}
  } as TogglePanelService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        MatIconModule
      ],
      declarations: [ CdsNavbarComponent ],
      providers: [ { provide: NavigationService, useValue: navigationService },
                   { provide: AuthenticationService, useValue: authenticationService },
                   { provide: SignInRouterService, useValue: signInRouterService },
                   { provide: TogglePanelService, useValue: togglePanelService }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CdsNavbarComponent);
    component = fixture.componentInstance;
    navigationService = TestBed.get(NavigationService);
    togglePanelService = TestBed.get(TogglePanelService);
    spyOn(navigationService, 'navigateToSearch');
    spyOn(navigationService, 'navigateToHelp');
    spyOn(togglePanelService, 'update');
  });

  describe('signed in', () => {

    beforeEach(() => {
      component.homeLabel = 'home label';
      component.isSignInPage = false; // hidden = false; show; (logged in)
      fixture.detectChanges();
    });

    describe('home link', () => {
      it('should have a menu item labelled with homeLabel', () => {
        const homeLabels = fixture.debugElement.queryAll(By.css(".nav__home-label"))
          .map(navItemLabelElement => navItemLabelElement.nativeElement.textContent);
        expect(homeLabels).toEqual(['home label']);
      });

      it('should have a menu item with home icon', () => {
        const homeIcon = fixture.debugElement.queryAll(By.css(".nav__home-icon"))
        expect(homeIcon).toBeTruthy();
      });

      it('should call navigation and toggle panel services when nav button is clicked', () => {
        fixture.debugElement.query(By.css('.nav__home-link')).nativeElement.click();
        fixture.detectChanges();
        expect(navigationService.navigateToSearch).toHaveBeenCalledWith(true);
        expect(togglePanelService.update).toHaveBeenCalledWith(new TogglePanel());
      });
    });

    describe('sign out link', () => {
      let authenticationService;
      let signInRouterService;
      let navigationService;
      let signOutLink;

      beforeEach(() => {
        authenticationService = TestBed.get(AuthenticationService);
        signInRouterService = TestBed.get(SignInRouterService);
        navigationService = TestBed.get(NavigationService);
        spyOn(authenticationService, 'signOut');
        spyOn(signInRouterService, 'navigateToSignIn');
        signOutLink = fixture.debugElement.query(By.css('.nav__sign-out-link'));
      });

      it('should display the sign out link', () => {
        expect(signOutLink != null).toBeTruthy();
      });

      describe('click', () => {

        beforeEach(() => {
          signOutLink.nativeElement.click();
        });

        it('should sign out with the authentication service on click', () => {
          expect(authenticationService.signOut).toHaveBeenCalled();
        });

        it('should clear the search criteria and params using navigation service on click', () => {
          expect(navigationService.navigateToSearch).toHaveBeenCalled();
        });

        it('should route to the sign in page', () => {
          expect(signInRouterService.navigateToSignIn).toHaveBeenCalled();
        });
      });
    });

    describe('help link', () => {

      it('should have a menu item labelled with helpLabel', () => {
        const helpLabels = fixture.debugElement.queryAll(By.css(".nav__help-label"))
          .map(navItemLabelElement => navItemLabelElement.nativeElement.textContent);
        expect(helpLabels).toEqual(['Help']);
      });

      it('should have a menu item with help icon', () => {
        const helpIcon = fixture.debugElement.queryAll(By.css(".nav__help-icon"))
        expect(helpIcon).toBeTruthy();
      });

      it('should call navigation service when help button is clicked', () => {
        fixture.debugElement.query(By.css('.nav__help-link')).nativeElement.click();
        fixture.detectChanges();
        expect(navigationService.navigateToHelp).toHaveBeenCalledWith();
      });

      it('on click should change background color', () => {
        const helpElement = fixture.debugElement.query(By.css('.nav__help')).nativeElement;
        helpElement.click();
        fixture.detectChanges();
        expect(helpElement.style.backgroundColor).toBe('rgb(12, 107, 88)');
      });
    });


  });

  describe('not signed in',() => {
    beforeEach(() => {
      component.isSignInPage = true;
      fixture.detectChanges();
    });

    it('should not display the homeLabel', () => {
      let hiddenLabel = fixture.debugElement.query(By.css('.nav__menu--hidden'));
      expect(hiddenLabel).toBeTruthy();
    });
  });

});
