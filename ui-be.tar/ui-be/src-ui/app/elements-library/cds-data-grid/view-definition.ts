import * as moment from 'moment';

export class ViewDefinition {
  private static TIMESTAMP_FORMAT: string = 'DD-MM-YYYY HH:mm';

  readonly id: string;
  readonly label: string;
  readonly path: string = '';
  readonly type: string = 'string';
  readonly header: boolean = false;

  getValue: (any) => (string) = (data) => {
    const pathArray = (this.id + this.path).split('.');
    const value = pathArray.reduce((object, path) => object[path] ? object[path] : '', data);
    return this.format(value);
  };

  constructor(definition: {
    id: string,
    label: string,
    path?: string,
    type?: string,
    header?: boolean
  }) {
    this.id = definition.id;
    this.label = definition.label;
    this.path = definition.path || this.path;
    this.type = definition.type || this.type;
    this.header = definition.header || this.header;
  }

  toCell(data, cellIndex, headerCellCount, columnCount) {
    let colspan = 1;
    if (this.header && cellIndex === headerCellCount - 1) {
      const remainder = columnCount + 1 - (headerCellCount % columnCount);
      colspan = headerCellCount % columnCount === 0 ? 1 : remainder;
    }

    return new Cell(
      this.id,
      this.label,
      this.getValue(data),
      colspan,
      this.header
    )
  }

  private format(data: string): string {
    if (this.type === 'timestamp') {
      const formatted = moment(data).format(ViewDefinition.TIMESTAMP_FORMAT);
      return formatted !== 'Invalid date' ? formatted : data;
    } else {
      return data;
    }
  }

  static objectsToViewDefinition = (result: any) => {
    return result.definitions.map(obj => 
      new ViewDefinition({ id: obj.id, label: obj.label, path: obj.path, type: obj.type, header: obj.header })
    );
  };

}

export class Cell {
  constructor(
    readonly id: string,
    readonly label: string,
    readonly value: any,
    readonly colspan: number,
    readonly header: boolean
  ) {}
}