import { ViewDefinition } from './view-definition';

describe('ViewDefinition', () => {

    it('should have default properties', () => {
        const definition = new ViewDefinition({ id: 'idField',  label: 'ID' });

        expect(definition.type).toEqual('string');
        expect(definition.header).toBe(false);
    });

    it('should override default properties', () => {
        const definition = new ViewDefinition({ id: 'idField',  label: 'ID', type: 'timestamp', header: true });

        expect(definition.type).toEqual('timestamp');
        expect(definition.header).toBe(true);
    });
   
    it('should be able to automatically find an object value based on an id', () => {
        const object = { idField: 'objectId' };
        const definition = new ViewDefinition({ id: 'idField',  label: 'ID' });

        expect(definition.getValue(object)).toEqual('objectId');
    });

    it('should be able to find an object value by recursively following path', () => {
        const object = { codeObject: { valueObject: { nestedValue: 'value' } } };
        const definition = new ViewDefinition({ id: 'codeObject',  label: 'ID', path: '.valueObject.nestedValue' });

        expect(definition.getValue(object)).toEqual('value');
    });

    it('should return a blank string if object path cannot be fully resolved', () => {
        const object = { codeObject: { valueObject: undefined } };
        const object2 = { codeObject: undefined };
        const definition = new ViewDefinition({ id: 'codeObject',  label: 'ID', path: '.valueObject.nestedValue' });

        expect(definition.getValue(object)).toEqual('');
        expect(definition.getValue(object2)).toEqual('');
    });

    it('should be able to format an object value based on the type', () => {
        const object = { timestampField: '2018-01-30 23:20:34.222' };
        const definition = new ViewDefinition({ id: 'timestampField',  label: 'Date', type: 'timestamp' });

        expect(definition.getValue(object)).toEqual('30-01-2018 23:20');
    });

    it('should return original value if format unsuccessful', () => {
        const object = { timestampField: 'test' };
        const definition = new ViewDefinition({ id: 'timestampField',  label: 'Date', type: 'timestamp' });

        expect(definition.getValue(object)).toEqual('test');
    });

    it('should calculate the correct colspan for the cell', () => {
        const object = { idField: 'objectId' };
        const headerDefinition = new ViewDefinition({ id: 'idField',  label: 'ID', header: true });

        expect(headerDefinition.toCell(object, 0, 1, 4).colspan).toBe(4);
        expect(headerDefinition.toCell(object, 1, 2, 4).colspan).toBe(3);
        expect(headerDefinition.toCell(object, 2, 3, 4).colspan).toBe(2);
        expect(headerDefinition.toCell(object, 3, 4, 4).colspan).toBe(1);
        expect(headerDefinition.toCell(object, 4, 5, 4).colspan).toBe(4);
        expect(headerDefinition.toCell(object, 5, 6, 4).colspan).toBe(3);
        expect(headerDefinition.toCell(object, 6, 7, 4).colspan).toBe(2);
        expect(headerDefinition.toCell(object, 7, 8, 4).colspan).toBe(1);
    });

    it('should have a colspan of 1 for non-header cells', () => {
        const object = { idField: 'objectId' };
        const nonHeaderDefinition = new ViewDefinition({ id: 'idField',  label: 'ID', header: false });
        expect(nonHeaderDefinition.toCell(object, 0, 1, 4).colspan).toBe(1);
    });

    it('should map to an array of view definition', () => {
        let definitions = {
            "definitions": [
              {
                "header": true,
                "label": "Declaration ID",
                "type": "string",
                "path": "",
                "id": "declarationId"
              },
              {
                "header": false,
                "label": "Country of Dispatch",
                "type": "string",
                "path": ".code",
                "id": "dispatchCountry"
              }
            ]
          };

        let result = ViewDefinition.objectsToViewDefinition(definitions)
        expect(result.length).toBe(2);
        expect(result[0].header).toBe(true);
        expect(result[1].header).toBe(false);
        expect(result[0].label).toEqual("Declaration ID");
        expect(result[1].label).toEqual("Country of Dispatch");
        expect(result[0].type).toEqual("string");
        expect(result[1].type).toEqual("string");
        expect(result[0].path).toEqual("");
        expect(result[1].path).toEqual(".code");
        expect(result[0].id).toEqual("declarationId");
        expect(result[1].id).toEqual("dispatchCountry");
        expect(result[0].getValue).toBeTruthy();
        expect(result[1].getValue).toBeTruthy();
        expect(result[0].toCell).toBeTruthy();
        expect(result[1].toCell).toBeTruthy();
    });

});