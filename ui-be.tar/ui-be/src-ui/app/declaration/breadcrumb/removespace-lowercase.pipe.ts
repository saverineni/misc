import {Pipe, PipeTransform} from "@angular/core";

@Pipe({
  name: "removeSpaceLowercase"
})
export class RemovespaceLowercasePipe implements PipeTransform{
  transform(value: string, args?: any): string {
    return (value) ? value.replace(/\s/g, '').toLowerCase() : '';
  }
}
