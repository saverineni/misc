import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { map, mergeMap } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { Declaration } from './declaration';
import { LinesSelection } from './lines-selection';
import { ResourceService } from '../../resource/resource.service';
import { ActivatedRoute } from '@angular/router/src/router_state';
import { ParamMap } from '@angular/router';
import { ViewDefinition } from '../../elements-library/cds-data-grid/view-definition';

@Injectable()
export class DeclarationService {

  constructor(private http: HttpClient,
              private resourceService: ResourceService) {}
  
  declarationDefinition(): Observable<ViewDefinition[]> {
    return this.http
      .get('/api/declarations/definition')
      .pipe(
        map(ViewDefinition.objectsToViewDefinition)
      );
  }

  declarationItemDefinition(): Observable<ViewDefinition[]> {
    return this.http
      .get('/api/declarations/items/definition')
      .pipe(
        map(ViewDefinition.objectsToViewDefinition)
      );
  }

  declarationForRoute(route: ActivatedRoute): Observable<Declaration> {
    return this.resourceService.handleNotFound(
        route,
        (params: ParamMap) => this.getDeclaration(params.get('id'))
      );
  }

  private getDeclaration(id: string): Observable<Declaration> {
    return this.http
      .get(`/api/declarations/${id}`)
      .pipe(
        map(searchResult => searchResult as Declaration)
      );
  }

  itemsForRoute(route: ActivatedRoute): Observable<LinesSelection> {
    return this.declarationForRoute(route).pipe(
      map(declaration => new LinesSelection(declaration.lines, declaration.declarationId,
        declaration.importExportIndicator, declaration.declarationSource, declaration.declarationType)),
      mergeMap(linesSelection => route.paramMap.pipe(
        map(paramMap => {
          linesSelection.selectedItemNumber = +paramMap.get('number');
          if (linesSelection.isSelectionValid()) {
            return linesSelection;
          } else {
            this.resourceService.notFound(route);
            of({});
          }
        })
      ))
    );
  }
}
