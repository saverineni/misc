import { DeclarationLine } from "./declaration-line";

export class LinesSelection {

  selectedItemNumber: number;

  readonly lines: Array<DeclarationLine>;

  constructor(
    _lines: Array<DeclarationLine>,
    readonly declarationId: string,
    readonly importExportIndicator: string,
    readonly declarationSource: string,
    readonly declarationType: string
  ) {
    this.lines = _lines.map(line => {
        const newLine = Object.assign(new DeclarationLine(), line);
        newLine.declarationId = declarationId;
        newLine.importExportIndicator = importExportIndicator;
        newLine.declarationSource = declarationSource;
        newLine.declarationType = declarationType;
        return newLine;
      })
      .sort((a, b) => a.itemNumber - b.itemNumber);
  }

  isSelectionValid() {
    return this.lines.find(it => it.itemNumber == this.selectedItemNumber) !== undefined;
  }
}
