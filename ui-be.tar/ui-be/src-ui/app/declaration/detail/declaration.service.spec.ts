import { TestBed, getTestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { DeclarationService } from './declaration.service';
import { Declaration } from './declaration';
import { ResourceService } from '../../resource/resource.service';
import { ActivatedRoute } from '@angular/router';
import { ParamMap, Params } from '@angular/router/src/shared';
import { of } from 'rxjs/internal/observable/of';
import { Observable } from 'rxjs';
import { DeclarationLine } from './declaration-line';
import { LinesSelection } from './lines-selection';

describe('DeclarationService', () => {
  let declarationService: DeclarationService;
  let httpMock: HttpTestingController;
  let resourceService: ResourceService;

  const DECLARATION_ID = 'dec-id';
  const IMPORT_EXPORT_INDICATOR = 'import';
  const DECLARATION_SOURCE = 'mss';
  const DECLARATION_TYPE = 'X';

  let handledRoute;
  let paramHandler: (params: ParamMap) => Observable<any>;
  let declarationResult;

  beforeEach(() => {
    declarationResult = new Declaration();
    resourceService = {
      handleNotFound: (route, handler) => {
        handledRoute = route;
        paramHandler = handler;

        return of(declarationResult);
      },
      notFound: (route) => {}
    } as ResourceService;

    spyOn(resourceService, 'notFound');

    TestBed.configureTestingModule({
      providers: [
        DeclarationService,
        { provide: ResourceService, useValue: resourceService }],
      imports: [HttpClientTestingModule]
    });
    httpMock = getTestBed().get(HttpTestingController);
    declarationService = getTestBed().get(DeclarationService);
  });

  let activatedRoute: ActivatedRoute;
  let paramMap: ParamMap;
  const SELECTED_LINE = 2;

  beforeEach(() => {
    const params = {
      id: DECLARATION_ID,
      number: SELECTED_LINE
    }
    paramMap = { get: (param) => params[param] } as ParamMap
    spyOn(paramMap, 'get').and.callThrough();
  });

  describe('declaration definition request', () => {
    let testRequest;

    beforeEach(() => {
      declarationService.declarationDefinition().toPromise();
      testRequest = httpMock.expectOne('/api/declarations/definition');
      testRequest.flush({
        "definitions": []
      });
    });

    it('should make a get request', () => {
      expect(testRequest.request.method).toBe("GET");
    });
  });

  describe('declaration items definition request', () => {
    let testRequest;

    beforeEach(() => {
      declarationService.declarationItemDefinition().toPromise();
      testRequest = httpMock.expectOne('/api/declarations/items/definition');
      testRequest.flush({
        "definitions": []
      });
    });

    it('should make a get request', () => {
      expect(testRequest.request.method).toBe("GET");
    });
  });

  describe('declaration for route request', () => {
    let serviceResult: Observable<Declaration>;

    beforeEach(() => {
      activatedRoute = {} as ActivatedRoute;
      serviceResult = declarationService.declarationForRoute(activatedRoute);
    });

    it('should call resource service with the given route', () => {
      serviceResult.toPromise();
      expect(handledRoute).toBe(activatedRoute);
    });

    it('should return the result of the resource service', (done) => {
      serviceResult.subscribe(
        success => {
          expect(success).toBe(declarationResult);
          done();
        },
        done.fail
      );
    });

    describe('param handler', () => {
      let testRequest;
      let handlerResult: Declaration;

      beforeEach((done) => {
        paramHandler(paramMap).subscribe(
          success => {
            handlerResult = success;
            done();
          },
          done.fail
        );

        testRequest = httpMock.expectOne(`/api/declarations/${DECLARATION_ID}`);
        testRequest.flush({
          declarationId: DECLARATION_ID,
          destinationCountry: {
            code: 'country-code'
          },
          lines: [ { itemNumber: 1 }]
        });
      });

      it('should get the id param from the param map', () => {
        expect(paramMap.get).toHaveBeenCalledWith('id');
      });

      it('should get the declaration by id', () => {
        expect(testRequest.request.method).toBe("GET");
      });

      it('should return the declaration', () => {
        expect(handlerResult.declarationId).toEqual(DECLARATION_ID);
        expect(handlerResult.destinationCountry.code).toEqual('country-code');
        expect(handlerResult.lines.length).toEqual(1);
        expect(handlerResult.lines[0].itemNumber).toEqual(1);
      });
    });
  });

  describe('items for route', () => {
    let lines;

    function line(itemNumber) {
      const line = new DeclarationLine();
      line.itemNumber = itemNumber;
      line.itemConsigneeName = `name ${itemNumber}`;

      return line;
    }

    beforeEach(() => {
      activatedRoute = { paramMap: of(paramMap) } as ActivatedRoute;

      lines = [];
      declarationResult.declarationId = DECLARATION_ID;
      declarationResult.importExportIndicator = IMPORT_EXPORT_INDICATOR;
      declarationResult.declarationSource = DECLARATION_SOURCE;
      declarationResult.declarationType = DECLARATION_TYPE;
      declarationResult.lines = lines;

      const declarationObservable = of(declarationResult);
      spyOn(declarationService, 'declarationForRoute').and.returnValue(declarationObservable);
    });

    it('should get the declaration for the route', () => {
      declarationService.itemsForRoute(activatedRoute).toPromise();
      expect(declarationService.declarationForRoute).toHaveBeenCalledWith(activatedRoute);
    });

    describe('item number is present', () => {
      beforeEach(() => {
        lines.push(line(1));
        lines.push(line(2));
      });

      it('should create the lines selection with the declaration lines and id', (done) => {
        declarationService.itemsForRoute(activatedRoute).subscribe(
          result => {
            expect(result.lines).toEqual(new LinesSelection(lines, DECLARATION_ID, IMPORT_EXPORT_INDICATOR, DECLARATION_SOURCE, DECLARATION_TYPE).lines);
            expect(result.declarationId).toEqual(DECLARATION_ID);
            done();
          },
          done.fail
        );
      });

      it('should have line number from the route set to the returned object', (done) => {
        declarationService.itemsForRoute(activatedRoute).subscribe(
          result => {
            expect(result.selectedItemNumber).toEqual(SELECTED_LINE);
            done();
          },
          done.fail
        );
      });
    });

    describe('item number not present', () => {
      beforeEach(() => {
        lines.push(line(1));
        lines.push(line(3));
      });

      it('should call not found', (done) => {
        declarationService.itemsForRoute(activatedRoute).subscribe(
          result => {
            expect(resourceService.notFound).toHaveBeenCalledWith(activatedRoute);
            done();
          },
          done.fail
        );
      });
    });
  });
});
