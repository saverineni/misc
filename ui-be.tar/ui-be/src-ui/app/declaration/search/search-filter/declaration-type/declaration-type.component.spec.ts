import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {DeclarationTypeComponent} from './declaration-type.component';
import {FlexLayoutModule} from "@angular/flex-layout";
import {MAT_CHECKBOX_CLICK_ACTION, MatCheckboxChange, MatCheckboxModule, MatExpansionModule} from "@angular/material";
import {FormsModule} from "@angular/forms";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {SearchCriteriaService} from "../../search-criteria.service";
import {of} from "rxjs/index";
import {SearchCriteria} from "../../search-criteria";
import {By} from "@angular/platform-browser";
import {DebugElement} from "@angular/core";
import {TogglePanel} from '../toggle-panel';
import {TogglePanelService} from '../toggle-panel.service';

describe('DeclarationTypeComponent', () => {
  let component: DeclarationTypeComponent;
  let fixture: ComponentFixture<DeclarationTypeComponent>;
  let searchCriteriaService: SearchCriteriaService;
  let searchCriteria: SearchCriteria;
  let filterExpansionPanel;
  let togglePanelService: TogglePanelService;
  let togglePanel: TogglePanel;


  beforeEach(async(() => {
    searchCriteria = new SearchCriteria();
    togglePanel = new TogglePanel();

    searchCriteriaService = {
      searchCriteria: of(searchCriteria),
      updatePartial: (params) => { }
    } as SearchCriteriaService;

    togglePanelService = {
      togglePanel: of(togglePanel),
      update: (togglePanel) => {}
    } as TogglePanelService;

    spyOn(searchCriteriaService, 'updatePartial');
    spyOn(togglePanelService, 'update');

    TestBed.configureTestingModule({
      providers: [
        { provide: SearchCriteriaService, useValue: searchCriteriaService },
        { provide: TogglePanelService, useValue: togglePanelService },
        { provide: MAT_CHECKBOX_CLICK_ACTION, useValue: 'check'}
      ],
      imports: [
        MatCheckboxModule,
        FlexLayoutModule,
        MatExpansionModule,
        BrowserAnimationsModule,
        FormsModule
      ],
      declarations: [ DeclarationTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeclarationTypeComponent);
    component = fixture.componentInstance;
    searchCriteriaService = TestBed.get(SearchCriteriaService);
    togglePanelService = TestBed.get(TogglePanelService);
    filterExpansionPanel = fixture.debugElement.query(By.css('.declaration-type__header'));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('within expansion panel', () => {

    const checkboxChange = new MatCheckboxChange();

    let importAll: DebugElement;
    let exportAll: DebugElement;

    let applyFiltersButton: DebugElement;
    let clearButton: DebugElement;
    let importValues;
    let exportValues;

    beforeEach(() => {
      filterExpansionPanel.nativeElement.click();
      importAll = fixture.debugElement.query(By.css('.declaration-type__import-all-checkbox'));



      exportAll = fixture.debugElement.query(By.css('.declaration-type__export-all-checkbox'));
      applyFiltersButton = fixture.debugElement.query(By.css('.declaration-type__apply-filters'));
      clearButton = fixture.debugElement.query(By.css('.declaration-type__clear'));

      importValues = [ 'X', 'Y', 'Z'];
      exportValues = [ 'D', 'F', 'K'];

      fixture.detectChanges();
    });

    it('all imports checkboxes are displayed initially', () => {
      let importX = fixture.debugElement.query(By.css('.declaration-type__import-X'));
      let importY = fixture.debugElement.query(By.css('.declaration-type__import-Y'));
      let importZ = fixture.debugElement.query(By.css('.declaration-type__import-Z'));
      expect(importAll.nativeElement.textContent.trim()).toBe('Import (All)');
      expect(importX.nativeElement.textContent.trim()).toBe('X');
      expect(importY.nativeElement.textContent.trim()).toBe('Y');
      expect(importZ.nativeElement.textContent.trim()).toBe('Z');
    });

    it('all exports checkboxes are displayed initially', () => {
      let exportD = fixture.debugElement.query(By.css('.declaration-type__export-D'));
      let exportF = fixture.debugElement.query(By.css('.declaration-type__export-F'));
      let exportK = fixture.debugElement.query(By.css('.declaration-type__export-K'));
      expect(exportAll.nativeElement.textContent.trim()).toBe('Export (All)');
      expect(exportD.nativeElement.textContent.trim()).toBe('D');
      expect(exportF.nativeElement.textContent.trim()).toBe('F');
      expect(exportK.nativeElement.textContent.trim()).toBe('K');
    });

    it('all checkboxes should be deselected initially', () => {
      expect(component.importSelectAll).toEqual(false);
      expect(component.exportSelectAll).toEqual(false);
      component.importsAndExports.forEach( (item) => {
          expect(item.checked).toEqual(false);
      });
    });

    it('apply filters button should be disabled initially', () => {
      expect(applyFiltersButton.nativeElement.disabled).toBe(true);
    });

    it('should call toggle panel service',() => {
      expect(togglePanelService.update).toHaveBeenCalled();
    });

    describe('imports and exports', () => {

      it('import-all checkbox selects all imports',  () => {
        selectItem(importAll);

        component.imports.forEach( (item) => {
          expect(item.checked).toEqual(true);
        });
      });

      it('export-all checkbox selects all exports',  () => {
        selectItem(exportAll);

        component.exports.forEach( (item) => {
          expect(item.checked).toEqual(true);
        });
      });

      it('enables apply-filter button on selecting all imports',  () => {
        selectItem(importAll);
        expect(applyFiltersButton.nativeElement.disabled).toBe(false);
      });

      it('enables apply-filter button on selecting all exports',  () => {
        selectItem(exportAll);
        expect(applyFiltersButton.nativeElement.disabled).toBe(false);
      });

    });

    describe('on apply filters', () => {

      let searchCriteria: any;


      describe('importall selected', () => {

        beforeEach(() => {

          searchCriteria = {};
          searchCriteria['declarationType'] = importValues;
          searchCriteria.pageNumber = undefined;
          searchCriteria.pageSize = undefined;

          selectItem(importAll);
          fixture.detectChanges();
        });

        it('should call update on service', () => {
          applyFiltersButton.nativeElement.click();
          expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteria);
        });

      });

      describe('exportall selected', () => {

        beforeEach(() => {

          searchCriteria = {};
          searchCriteria['declarationType'] = exportValues;
          searchCriteria.pageNumber = undefined;
          searchCriteria.pageSize = undefined;

          selectItem(exportAll);
          fixture.detectChanges();
        });

        it('should call update on service', () => {
          applyFiltersButton.nativeElement.click();
          expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteria);
        });

      });

    });

    describe('on clear', () => {

      let searchCriteria: any;
      beforeEach(() => {

        searchCriteria = {};
        searchCriteria['declarationType'] = null;
        searchCriteria.pageNumber = undefined;
        searchCriteria.pageSize = undefined;

        fixture.detectChanges();
      });

      it('deselects imports and exports', () => {

        selectItem(importAll);
        selectItem(exportAll);
        clearButton.nativeElement.click();
        component.importsAndExports.forEach( (item) => {
          expect(item.checked).toEqual(false);
        });
        expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteria);
      });

      it('should call update partial ', () => {

        selectItem(importAll);
        selectItem(exportAll);
        clearButton.nativeElement.click();
        expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteria);
      });

      it('no item elected', () => {
        searchCriteria['declarationType'] = null;
        clearButton.nativeElement.click();
        expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteria);
      });
    });

    function selectItem(item: DebugElement) {
      checkboxChange.checked = true;
      item.nativeElement.click();
      item.triggerEventHandler("change", checkboxChange);
      fixture.detectChanges();
    }
  });
});
