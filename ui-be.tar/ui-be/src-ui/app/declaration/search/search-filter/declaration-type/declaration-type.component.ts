import {ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, ViewChild} from '@angular/core';
import {SearchCriteria} from "../../search-criteria";
import {SearchCriteriaService} from "../../search-criteria.service";
import {TogglePanelService} from "../toggle-panel.service";
import {TogglePanel} from "../toggle-panel";

@Component({
  selector: 'cds-declaration-type-filter',
  templateUrl: './declaration-type.component.html',
  styleUrls: ['./declaration-type.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DeclarationTypeComponent implements OnInit {

  imports: Array<any> = [];
  exports: Array<any> = [];
  selectedItems: Set<string> = new Set();
  importSelectAll: boolean = false;
  exportSelectAll: boolean = false;
  importsAndExports: Array<any> = [];

  private closePanel: boolean;
  private openPanel: boolean;
  private togglePanelSubscription;
  private static SEARCH_PARAM: string = 'declarationType';
  private subscription;
  private searchCriteria: SearchCriteria = null;

  @ViewChild('decTypePanel') panel;

  constructor(private searchCriteriaService: SearchCriteriaService,
              private changeDetectorRef: ChangeDetectorRef,
              private togglePanelService: TogglePanelService) {

    this.imports=[
      {name : "X", checked : false},
      {name : "Y", checked : false},
      {name : "Z", checked : false}
    ];
    this.exports=[
      {name : "D", checked : false},
      {name : "F", checked : false},
      {name : "K", checked : false}
    ];
    this.importsAndExports = [...this.imports, ...this.exports];
  }

  ngOnInit() {
    this.subscription = this.searchCriteriaService.searchCriteria.subscribe(
      newCriteria  => {
        this.searchCriteria = newCriteria;
        this.selectItems();
        this.toggleExpansionPanel();
        this.changeDetectorRef.detectChanges();
      }
    );

    this.togglePanelSubscription = this.togglePanelService.togglePanel.subscribe(
      (data: TogglePanel) => {
        this.openPanel = data.isOpened(DeclarationTypeComponent.SEARCH_PARAM);
        this.closePanel = data.isEmpty();
        this.toggleExpansionPanel();
      });
  }

  private toggleExpansionPanel() {
    if (this.anyItemSelected() || this.openPanel){
      this.panel.open();
    } else if(this.closePanel || this.panel.expanded) {
      this.clearAndClose();
    }
  }

  onExpand() {
    const togglePanel = new TogglePanel();
    togglePanel[DeclarationTypeComponent.SEARCH_PARAM] = true;
    this.togglePanelService.update(togglePanel);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();

    if(this.togglePanelSubscription) {
      this.togglePanelSubscription.unsubscribe();
    }
  }

  selectImportAll(event) {
    this.importSelectAll = event.checked;
    this.imports.forEach( (imp) => { imp.checked = this.importSelectAll;} );
  }

  selectExportAll(event) {
    this.exportSelectAll = event.checked;
    this.exports.forEach( (exp) => { exp.checked = this.exportSelectAll;} );
  }

  selectDeselectImportsAll() {
    this.importSelectAll = this.imports.filter(imp => imp.checked).length == this.imports.length ? true : false;
  }

  selectDeselectExportsAll() {
    this.exportSelectAll = this.exports.filter(exp => exp.checked).length == this.imports.length ? true : false;
  }

  onClear() {
    this.clearImportsExports()
    this.onApplyFilters();
  }

  onApplyFilters() {
    let updates: any = {
      pageNumber: undefined,
      pageSize: undefined
    };

    if (this.anyItemSelected()) {
      updates[DeclarationTypeComponent.SEARCH_PARAM] = Array.from(this.importsAndExports.filter(item => item.checked)
        .map( (item) => item.name));
    } else {
      updates[DeclarationTypeComponent.SEARCH_PARAM] = null;
    }

    this.searchCriteriaService.updatePartial(updates);
  }

  clearAndClose() {
    this.clearImportsExports();
    this.panel.close();
  }

  private selectItems() {
    if (this.searchCriteria[DeclarationTypeComponent.SEARCH_PARAM]) {
      this.selectedItems = new Set<string>(this.searchCriteria[DeclarationTypeComponent.SEARCH_PARAM]);
      if(this.importsAndExports) {
        this.importsAndExports.forEach(item => {
          if (this.selectedItems.has(item.name as string)) {
            item.checked = true;
          }
        });
        this.selectDeselectImportsAll();
        this.selectDeselectExportsAll();
      }
    } else {
      this.clearAndClose();
    }
  }

  anyItemSelected() {
    return  this.importsAndExports.filter(item => item.checked).length > 0;
  }

  isSearchCriteriaPopulated() {
    return  this.searchCriteria.declarationType;
  }

  private clearImportsExports() {
    this.importsAndExports.forEach((item) => {
      item.checked = false;
    });
    this.importSelectAll = false;
    this.exportSelectAll = false;
  }

}
