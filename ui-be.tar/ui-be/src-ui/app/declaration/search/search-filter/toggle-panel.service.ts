import { Injectable } from '@angular/core';
import { TogglePanel } from './toggle-panel';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable()
export class TogglePanelService {

  private _currentTogglePanel: TogglePanel = new TogglePanel();
  private togglePanelSource = new BehaviorSubject(this._currentTogglePanel);
  private _togglePanelUpdates = this.togglePanelSource.asObservable();

  get togglePanel(): Observable<any> {
    return this._togglePanelUpdates;
  }

  update(togglePanel: TogglePanel) {
    this._currentTogglePanel = togglePanel;
    this.togglePanelSource.next(Object.assign(new TogglePanel(), togglePanel));
  }
}
