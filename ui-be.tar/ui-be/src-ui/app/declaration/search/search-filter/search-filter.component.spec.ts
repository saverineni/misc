import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {SearchFilterComponent} from './search-filter.component';
import {By} from "@angular/platform-browser";
import {Component, DebugElement, Directive, EventEmitter, Input, Output} from "@angular/core";
import {FlexLayoutModule} from "@angular/flex-layout";
import {MatDividerModule} from "@angular/material";
import {SearchCriteriaService} from '../search-criteria.service';
import {Observable, of, Subscription} from 'rxjs';
import {SearchCriteria} from '../search-criteria';
import { TogglePanelService } from './toggle-panel.service';

@Directive({
  selector: 'cds-search-form'
})

export class SearchFormStub { }
@Component({
  selector: 'cds-search-field-filter',
  template: '<div></div>'
})
export class SearchFieldComponentStub {
  @Input() label: string;
  @Input() placeholder: string;
  @Input() searchParamField: string;
  @Input() toolTipTextValue: string;
}

@Component({
  selector: 'cds-declaration-type-filter',
  template: '<div></div>'
})
export class DeclarationTypeComponentStub {
}

@Directive({
  selector: 'cds-checkboxes'
})
class CheckboxesComponentStub {
  @Input() data: Array<string>;
  @Input() label: string;
  @Input() searchParamField: string;
}

@Directive({
  selector: 'cds-date-range-filter'
})
export class DateRangeFilterStub {
  @Input() label: string;
  @Input() fromField: string;
  @Input() toField: string;
}

@Directive({
  selector: 'cds-links-facet'
})
class LinksFacetStub {
  @Input() label: string;
  @Input() searchParam: string;
  @Input() facetSearch: any;
}

@Directive({
  selector: 'cds-chips'
})
class ChipsComponentStub {
  @Input() id: string;
  @Input() chips: Array<string>;
  @Output() onRemove: EventEmitter<string> = new EventEmitter();
}

describe('SearchFilterComponent', () => {
  let component: SearchFilterComponent;
  let fixture: ComponentFixture<SearchFilterComponent>;
  let filter: DebugElement;

  let togglePanelService: TogglePanelService;
  let searchCriteriaService: SearchCriteriaService;
  let testObservable: Observable<SearchCriteria>;
  let testSubscription: Subscription;
  let successHandler;

  beforeEach(async(() => {
    testObservable = of();
    testSubscription = new Subscription();

    spyOn(testObservable, 'subscribe').and.callFake(
      success => {
        successHandler = success;
        return testSubscription;
      }
    );
    spyOn(testSubscription, 'unsubscribe');

    searchCriteriaService = {
      searchCriteria: testObservable,
      updatePartial: (searchCriteria) => { },
      replace: (searchCriteria) => { }
    } as SearchCriteriaService;

    spyOn(searchCriteriaService, 'updatePartial');
    spyOn(searchCriteriaService, 'replace');

    TestBed.configureTestingModule({
      imports: [ FlexLayoutModule, MatDividerModule ],
      declarations: [SearchFilterComponent, SearchFormStub, DateRangeFilterStub, LinksFacetStub, ChipsComponentStub, SearchFieldComponentStub, DeclarationTypeComponentStub , CheckboxesComponentStub],
      providers: [
        {provide: SearchCriteriaService, useValue: searchCriteriaService}, TogglePanelService
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    togglePanelService = TestBed.get(TogglePanelService);
    fixture = TestBed.createComponent(SearchFilterComponent);
    component = fixture.componentInstance;
    filter = fixture.debugElement.query(By.css('.search-filter'));
  });

  it('should create', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('should contain the filters label', () => {
    fixture.detectChanges();
    let label = filter.query(By.css('.search-filter__label')).nativeElement;
    expect(label.innerText).toBe('Filters');
  });

  it('should not display the search term field', () => {
    fixture.detectChanges();
    let searchForm = filter.query(By.css('.search-filter__search-form'));
    expect(searchForm).toBeNull();
  });

  describe('on initialisation', () => {
    it('should subscribe to search criteria updates', () => {
      fixture.detectChanges();
      expect(successHandler).toBeTruthy();
    });
  });

  describe('clear all', () => {
    beforeEach(() => {
      fixture.detectChanges();
    });

    describe('when there are no search terms', () => {

      it('is not active', () => {
        const clearAllActive = fixture.debugElement.query(By.css('.search-filter__clear-all--active'));
        expect(clearAllActive).toBeNull();
      });

      it('clear-all label should be present', () => {
        const clearAllActive = fixture.debugElement.query(By.css('.search-filter__clear-all'));
        expect(clearAllActive).toBeTruthy();
      });

    });

    describe('when there are search terms', () => {
      beforeEach(() => {
        const searchCriteria = new SearchCriteria();
        searchCriteria.searchTerm = 'term';
        searchCriteria.eori = 'eori value';
        searchCriteria.declarationType = ['X', 'Y', 'Z'];

        successHandler(searchCriteria);
        fixture.detectChanges();
      });

      it('should be active', () => {
        const clearAllActive = fixture.debugElement.query(By.css('.search-filter__clear-all--active'));
        expect(clearAllActive).toBeTruthy();
      });

      describe('when clicked', () => {
        beforeEach(() => {
          spyOn(togglePanelService, 'update');
          const clearAll = fixture.debugElement.query(By.css('.search-filter__clear-all'));
          clearAll.nativeElement.click();
        });

        it('should clear the search criteria but not the search term', () => {
          const searchCriteria = new SearchCriteria();
          searchCriteria.searchTerm = 'term';
          expect(searchCriteriaService.replace).toHaveBeenCalledWith(searchCriteria);
        });

        it('should call the toggle service', () => {
          expect(togglePanelService.update).toHaveBeenCalled();
        });

      });
    })
  });

  describe('any changes to input properties should update', () => {
    let links: DebugElement[];
    let facetChips: DebugElement[];

    beforeEach(() => {
      fixture.detectChanges();
      links = fixture.debugElement.queryAll(By.directive(LinksFacetStub));
      facetChips = fixture.debugElement.queryAll(By.directive(ChipsComponentStub));
    });

    [{
      label: 'Country of Origin',
      searchParam: 'originCountryCode'
    },
    {
      label: 'Country of Dispatch',
      searchParam: 'dispatchCountryCode'
    },
    // Commented out for now
    // {
    //   label: 'Country of Destination',
    //   searchParam: 'destinationCountryCode'
    // },
    {
      label: 'Mode of Transport',
      searchParam: 'transportModeCode'
    },
    {
      label: 'Goods Location',
      searchParam: 'goodsLocation'
    },
    {
      label: 'Commodity Code',
      searchParam: 'commodityCode',
      facetSearch: {
        length: 4,
        type: 'numbers'
      }
    }].forEach((expectedFacet: any, index) => {
      let linkFacet: LinksFacetStub;
      let chipsComponent: ChipsComponentStub;
      describe(`${expectedFacet.label} link gets added`, () => {

        beforeEach(() => {
          linkFacet = links[index].injector.get(LinksFacetStub);
        });

        it('with the correct label', () => {
          expect(linkFacet.label).toBe(expectedFacet.label);
        });

        it('with correct searchParam', () => {
          expect(linkFacet.searchParam).toBe(expectedFacet.searchParam);
        });

        it('with correct facet search info', () => {
          expect(linkFacet.facetSearch).toEqual(expectedFacet.facetSearch);
        });
      });

      describe(`${expectedFacet.label} chips gets added`, () => {
        let searchCriteria: SearchCriteria;

        beforeEach(() => {
          searchCriteria = new SearchCriteria();
          searchCriteria[expectedFacet.searchParam] = ['code1', ''];
          successHandler(searchCriteria);
          fixture.detectChanges();
        });

        beforeEach(() => {
          chipsComponent = facetChips[index].injector.get(ChipsComponentStub);
        });

        it('should have the correct id set', () => {
          expect(chipsComponent.id).toEqual(expectedFacet.searchParam);
        });

        it('should have the chips mapped from the searchCriteria', () => {
          expect(chipsComponent.chips).toEqual(['code1', 'Unknown']);
        });

        it('should update the chips on criteria update', () => {
          searchCriteria[expectedFacet.searchParam] = ['new chip'];
          successHandler(searchCriteria);
          fixture.detectChanges();
          chipsComponent = facetChips[index].injector.get(ChipsComponentStub);

          expect(chipsComponent.chips).toEqual(['new chip']);
        });

        it('should update search criteria on chip remove', () => {
          searchCriteria[expectedFacet.searchParam] = ['chip1', 'chip-remove', 'chip2'];
          successHandler(searchCriteria);
          chipsComponent = facetChips[index].injector.get(ChipsComponentStub);
          chipsComponent.onRemove.emit('chip-remove');

          const expectedSearchCriteria = {};
          expectedSearchCriteria[expectedFacet.searchParam] = ['chip1', 'chip2'];
          expectedSearchCriteria['pageNumber'] = undefined;
          expectedSearchCriteria['pageSize'] = undefined;
          expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(expectedSearchCriteria);
        });

        it('should update search criteria on chip remove for Unknown chip', () => {
          searchCriteria[expectedFacet.searchParam] = ['', 'chip1'];
          successHandler(searchCriteria);
          chipsComponent = facetChips[index].injector.get(ChipsComponentStub);
          chipsComponent.onRemove.emit('Unknown');

          const expectedSearchCriteria = {};
          expectedSearchCriteria[expectedFacet.searchParam] = ['chip1'];
          expectedSearchCriteria['pageNumber'] = undefined;
          expectedSearchCriteria['pageSize'] = undefined;
          expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(expectedSearchCriteria);
        });

        it('should update search criteria with null when no chip', () => {
          searchCriteria[expectedFacet.searchParam] = ['chip'];
          successHandler(searchCriteria);
          chipsComponent = facetChips[index].injector.get(ChipsComponentStub);
          chipsComponent.onRemove.emit('chip');

          const expectedSearchCriteria = {};
          expectedSearchCriteria[expectedFacet.searchParam] = null;
          expectedSearchCriteria['pageNumber'] = undefined;
          expectedSearchCriteria['pageSize'] = undefined;
          expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(expectedSearchCriteria);
        });
      });
    });
  });

  describe('when scrolled', () => {

    beforeEach(() => {
      component.scrolled = true;
      fixture.detectChanges();
    });

    it('should display the search term field', () => {
      let searchForm = filter.query(By.css('.search-filter__search-form')).nativeElement;
      expect(searchForm).toBeTruthy();
    });

    it('should not display the filters label', () => {
      let label = filter.query(By.css('.search-filter__label'));
      expect(label).toBeNull();
    });

  });

  describe('on destroy', () => {
    it('should unsubscribe from criteria events', () => {
      fixture.detectChanges();
      fixture.destroy();
      expect(testSubscription.unsubscribe).toHaveBeenCalled();
    });
  });
});
