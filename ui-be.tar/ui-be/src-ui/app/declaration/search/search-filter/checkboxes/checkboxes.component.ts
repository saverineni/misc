import { Component, OnInit , Input , ViewChild , ChangeDetectorRef } from '@angular/core';
import { SearchCriteria } from "../../search-criteria";
import { SearchCriteriaService } from "../../search-criteria.service";
import { TogglePanelService } from "../toggle-panel.service";
import { TogglePanel } from "../toggle-panel";

export interface SelectedCheckbox {
  id: string,
  selected: boolean
}

@Component({
  selector: 'cds-checkboxes',
  templateUrl: './checkboxes.component.html',
  styleUrls: ['./checkboxes.component.scss']
})
export class CheckboxesComponent implements OnInit {

  @Input() data: Array<string>;
  @Input() label: string;
  @Input() searchParamField: string;
  @ViewChild('checkboxesPanel') panel;

  private closePanel: boolean;
  private openPanel: boolean;
  private newSearchCriteria: SearchCriteria;
  selectedCheckboxes: Array<SelectedCheckbox> = [];

  constructor(private searchCriteriaService: SearchCriteriaService,
              private changeDetectorRef: ChangeDetectorRef,
              private togglePanelService: TogglePanelService) {}

  ngOnInit() {
    this.searchCriteriaService.searchCriteria.subscribe(
      (searchCriteria: SearchCriteria)  => {
        this.selectedCheckboxes = [];
        this.newSearchCriteria = searchCriteria;
        if(this.newSearchCriteria[this.searchParamField]) {
          const updatedData: Array<string> = this.newSearchCriteria[this.searchParamField];
          updatedData.forEach(checkbox => 
            this.selectedCheckboxes.push({id: checkbox, selected: true} as SelectedCheckbox));
        }
        this.toggleExpansionPanel();
        this.changeDetectorRef.detectChanges();
    });

    this.togglePanelService.togglePanel.subscribe(
      (panelData: TogglePanel) => {
        this.openPanel = panelData.isOpened(this.searchParamField);
        this.closePanel = panelData.isEmpty();
        this.toggleExpansionPanel();
    });
  }

  onExpand() {
    const togglePanel = new TogglePanel();
    togglePanel[this.searchParamField] = true;
    this.togglePanelService.update(togglePanel);
  }

  onClear() {
    this.selectedCheckboxes = []; 
    this.onApplyFilters();
  }

  onClick(event,checkboxId) {
    let index = this.selectedCheckboxes.findIndex(it => it.id == checkboxId);
    const newIndex = index >= 0 ? index : this.selectedCheckboxes.length;
    this.selectedCheckboxes[newIndex] = {id: checkboxId , selected: event.checked} as SelectedCheckbox;
  }

  check(checkboxId) {    
    const checkbox = this.selectedCheckboxes.find(it => it.id == checkboxId);
    return checkbox != undefined ? checkbox.selected : false;
  }

  anyItemSelected() {
    return this.newSearchCriteria[this.searchParamField] || this.selectedCheckboxes.filter(item => item.selected).length > 0;
  }

  onApplyFilters() {
    let updates: any = { pageNumber: undefined, pageSize: undefined };
    const searchFieldData = this.selectedCheckboxes.filter(item => item.selected).map(item => item.id);
    updates[this.searchParamField] = searchFieldData.length > 0 ? searchFieldData : null;
    this.searchCriteriaService.updatePartial(updates);
  }

  private toggleExpansionPanel() {
    if (this.anyItemSelected() || this.openPanel){
      this.panel.open();
    } else if(this.closePanel || this.panel.expanded) {
      this.selectedCheckboxes = [];
      this.panel.close();
    }
  }

}
