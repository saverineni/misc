export class TogglePanel {
    eori: boolean;
    entryDate: boolean;
    clearanceDate: boolean;
    declarationType: boolean;
    declarationSource: boolean;

    isEmpty(): boolean {
        return Object.getOwnPropertyNames(this)
                     .find(property  => this[property] != undefined) == undefined;
    }

    isOpened(property) : boolean {
        return this[property] != undefined && this[property] == true;
    }
}
