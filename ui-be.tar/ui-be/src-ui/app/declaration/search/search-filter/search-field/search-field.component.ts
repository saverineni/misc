import {Component, Input, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {SearchCriteriaService} from "../../search-criteria.service";
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {SearchCriteria} from '../../search-criteria';
import {TogglePanel} from '../toggle-panel';
import {camelCase} from 'lodash';
import {TogglePanelService} from '../toggle-panel.service';

@Component({
  selector: 'cds-search-field-filter',
  templateUrl: './search-field.component.html',
  styleUrls: ['./search-field.component.scss']
})
export class SearchFieldComponent implements OnInit, OnDestroy {
  private static EMPTY_VALUE = '';

  private searchParam:string;
  private closePanel: boolean;
  private openPanel: boolean;
  private togglePanelField;
  private togglePanelSubscription;
  searchParam$: Observable<string>;

  @Input() label: string;
  @Input() placeholder: string;
  @Input() searchParamField: string;
  @Input() toolTipTextValue: string;

  @ViewChild('panel') panel;
  @ViewChild('searchFieldInput') searchFieldInput;

  constructor(private searchCriteriaService: SearchCriteriaService,
              private togglePanelService: TogglePanelService) { }

  ngOnInit() {
    this.togglePanelField = camelCase(this.label);
    this.searchParam$ = this.searchCriteriaService.searchCriteria.pipe(
      map((data: SearchCriteria) => {
        this.searchParam = data[this.searchParamField] || SearchFieldComponent.EMPTY_VALUE;
        this.closePanel = data.isEmpty();
        this.toggleExpansionPanel();
        return this.searchParam;
      })
    );

    this.togglePanelSubscription = this.togglePanelService.togglePanel.subscribe(
      (data: TogglePanel) => {
        this.openPanel = data.isOpened(this.togglePanelField);
        this.closePanel = data.isEmpty();
        this.toggleExpansionPanel();
      });
  }

  private toggleExpansionPanel() {
    if ((this.searchParam && this.searchParam != SearchFieldComponent.EMPTY_VALUE) || this.openPanel){
      this.panel.open();
    } else if(this.closePanel || this.panel.expanded) {
      this.clearValue();
      this.panel.close();
    }
  }

  clearValue() {
    this.searchFieldInput.nativeElement.value = SearchFieldComponent.EMPTY_VALUE;
  }

  onClear() {
    this.clearValue();
    if (this.searchParam != this.searchFieldInput.nativeElement.value) {
      this.onSearch(null);
    }
    this.searchFieldInput.nativeElement.focus();
  }

  onSearch(value) {
    let updates: any = {
      pageNumber: undefined,
      pageSize: undefined
    };

    if (value != null && value.trim() == SearchFieldComponent.EMPTY_VALUE) {
      updates[this.searchParamField] = null;
    } else {
      updates[this.searchParamField] = value;
    }

    this.searchCriteriaService.updatePartial(updates);
  }

  onExpand() {
    const togglePanel = new TogglePanel();
    togglePanel[this.togglePanelField] = true;
    this.togglePanelService.update(togglePanel);
  }

  ngOnDestroy(): void {
    if(this.togglePanelSubscription) {
      this.togglePanelSubscription.unsubscribe();
    }
  }
}
