import {ChangeDetectionStrategy, Component, Input, OnInit, ChangeDetectorRef} from '@angular/core';
import {DeclarationPreview} from '../declaration-preview';
import {Cell} from '../../../elements-library/cds-data-grid/view-definition';
import { of, Observable } from 'rxjs';
import { DefinitionService } from '../definition.service';
import { map } from 'rxjs/operators';

@Component({
  selector: 'cds-declaration-card',
  templateUrl: './declaration-card.component.html',
  styleUrls: ['./declaration-card.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DeclarationCardComponent implements OnInit {
  @Input() declaration: DeclarationPreview;

  columnCount = 3;

  cells$: Observable<Cell[]>;

  constructor(private definitionService: DefinitionService) {}

  ngOnInit() {
    this.cells$ = this.definitionService.getDeclarationPreviewDefinition().pipe(
      map(viewDefinitions => {
        const cells: Cell[] = [];
        const headerCount = viewDefinitions.filter(def => def.header).length;

        for (let i = 0; i < viewDefinitions.length; i++) {
          const definition = viewDefinitions[i];
          cells.push(definition.toCell(this.declaration, i, headerCount, this.columnCount));
        }

        return cells;
      })
    );
  }

}
