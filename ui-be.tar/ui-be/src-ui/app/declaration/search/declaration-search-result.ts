import { DeclarationPreview } from "./declaration-preview";

export class DeclarationSearchResult {
  hits: Hits;
  declarations: Array<DeclarationPreview> = [];
}

export class Hits {
  total: number;
}
