import {Injectable} from "@angular/core";
import {MatPaginatorIntl} from "@angular/material";

@Injectable()
export class SearchPaginatorIntl extends MatPaginatorIntl {
  itemsPerPageLabel = 'Declarations per page';
}
