import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable, throwError, of } from 'rxjs';
import { catchError, timeout } from 'rxjs/operators';
import { OperationErrorNotifier } from './operation-error-notifier';
import { CacheService } from "../authentication/cache.service";
import { SignInRouterService } from "../authentication/sign-in/sign-in-router.service";


@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {

  private clientErrors = [401,403];

  constructor(private operationErrorNotifier: OperationErrorNotifier,
    private cacheService: CacheService,
    private signInRouterService: SignInRouterService,
    private router: Router) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(
      timeout(5000),
      catchError(err => {
        if (err instanceof HttpErrorResponse) {
          if(this.clientErrors.find(status => status === err.status) != undefined ){
            this.cacheService.clear();
            this.signInRouterService.navigateToSignIn(this.router.routerState.snapshot);
          } else if(this.cacheService.getUser() !== null){
            this.router.navigate(['error']);
          } else {
            this.operationErrorNotifier.notifyUser('Server error');
          }
        } else { // timeout
          this.router.navigate(['error']);
        }
        return throwError(err);
      })
    );
  }
}
