export class BuildInfo {
    version: string;
    environment: string;
}