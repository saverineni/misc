export class AuthenticationResult {
    constructor(readonly authorised: boolean,readonly forbidden: boolean = false) {}
}
