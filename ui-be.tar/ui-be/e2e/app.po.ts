import { browser, by, element } from 'protractor';

export class AppPage {
  navigateTo() {
    return browser.get('/').then(() => browser.waitForAngular());
  }

  pageHeading() {
    return element(by.css('app-root h1')).getText();
  }

  componentHeading() {
    return element(by.css('main h1')).getText();
  }

  getOperationError() {
    return element(by.css('.operation-error')).getText();
  }

  getCurrentUrl() {
    return browser.getCurrentUrl();
  }

  getCurrentTitle() {
    return browser.getTitle();
  }

  printOnlyDisplayed() {
    return element(by.css('.print-only')).isDisplayed();
  }
}
