declare namespace jasmine {
    interface Matchers<T> {
        isDeclarationPreviewWithData(expected: object): boolean;
        isDeclarationHeaderWithData(expected: object): boolean;
        isDeclarationItemWithData(expected: object): boolean;
    }
}