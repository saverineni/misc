import { browser, by, element } from 'protractor';
import { DataGridElement } from '../DataGridElement';

export class DeclarationDetailPage {

  navigateTo(id) {
    return browser.get(`/declarations/${id}`).then(() => browser.waitForAngular());
  }

  isCurrentPage() {
    return element(by.css('.declaration-detail')).isPresent();
  }

  getDeclarationId() {
    return element(by.css('.declaration-detail__declarations')).getAttribute('data-declaration-id');
  }

  clickSearchResultsBreadcrumb() {
    return element(by.css('.breadcrumb-container__breadcrumb-link[data-breadcrumb="searchresults"]')).click();
  }

  declarationDetailBreadcrumbIsPresent() {
    return element(by.css('.breadcrumb-container__breadcrumb-link[data-breadcrumb="declarationdetail"]')).isPresent();
  }

  clickItemDetailButton() {
    return element(by.css('.declaration-detail__item-details-button')).click();
  }

  getItemDetailButtonText() {
    return element(by.css('.declaration-detail__item-details-button')).getText();
  }

  isItemDetailButtonEnabled() {
    return element(by.css('.declaration-detail__item-details-button')).isEnabled();
  }

  getImportDeclaration() {
    return element(by.css('.declaration-detail__declarations--import'));
  }

  getExportDeclaration() {
    return element(by.css('.declaration-detail__declarations--export'));
  }

  getDataGridElement(): DataGridElement {
    return new DataGridElement(element(by.css('.declaration-detail__declarations')));
  }

}
