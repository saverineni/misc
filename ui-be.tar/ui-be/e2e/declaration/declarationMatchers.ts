import * as moment from 'moment';

type FieldDefinition = { viewField: string; value: any; };
type DeclarationFieldDefinitions = (declaration: any) => FieldDefinition[];

const previewFields: DeclarationFieldDefinitions = declaration => [
    { viewField: 'declarationId', value: declaration.declarationId },
    { viewField: 'epuNumber', value: declaration.epuNumber },
    { viewField: 'entryNumber', value: declaration.entryNumber },
    { viewField: 'entryDate', value: moment(declaration.entryDate).format('DD-MM-YYYY HH:mm') },
    { viewField: 'goodsLocation', value: declaration.goodsLocation },
    { viewField: 'transportModeCode', value: declaration.transportModeCode },
    { viewField: 'route', value: declaration.route },
    { viewField: 'dispatchCountry', value: declaration.dispatchCountry.code },
    { viewField: 'destinationCountry', value: declaration.destinationCountry.code }
];

const headerFields: DeclarationFieldDefinitions = (declaration) => previewFields(declaration).concat([
    { viewField: 'consigneeTurn', value: declaration.consigneeTurn },
    { viewField: 'consigneeName', value: declaration.consigneeName },
    { viewField: 'consigneePostcode', value: declaration.consigneePostcode },
    { viewField: 'consignorTurn', value: declaration.consignorTurn },
    { viewField: 'consignorName', value: declaration.consignorName },
    { viewField: 'consignorPostcode', value: declaration.consignorPostcode }
]);

const itemFields: DeclarationFieldDefinitions = declarationLine => [
    { viewField:'itemRoute', value: declarationLine.itemRoute },
    { viewField:'itemDispatchCountry', value: declarationLine.itemDispatchCountry.code },
    { viewField:'itemDestinationCountry', value: declarationLine.itemDestinationCountry.code },
    { viewField:'clearanceDate', value: moment(declarationLine.clearanceDate).format('DD-MM-YYYY HH:mm') },
    { viewField:'cpc', value: declarationLine.cpc },
    { viewField:'originCountry', value: declarationLine.originCountry.code },
    { viewField:'commodityCode', value: declarationLine.commodityCode },
    { viewField:'itemConsigneeTurn', value: declarationLine.itemConsigneeTurn },
    { viewField:'itemConsigneeName', value: declarationLine.itemConsigneeName },
    { viewField:'itemConsigneePostcode', value: declarationLine.itemConsigneePostcode },
    { viewField:'itemConsignorTurn', value: declarationLine.itemConsignorTurn },
    { viewField:'itemConsignorName', value: declarationLine.itemConsignorName },
    { viewField:'itemConsignorPostcode', value: declarationLine.itemConsignorPostcode }
];

function newResult(): jasmine.CustomMatcherResult {
    return {
        pass: false,
        message: ''
    }
};

const removeNullsAndNewLines = value => value ? value.replace(/null(\s)?/mg, '').trim(): '';

function compareFields(fieldDefinitions: DeclarationFieldDefinitions) {
    return (util, customEqualityTesters) => {
        const isEqual = (a, b) => util.equals(a, b, customEqualityTesters);
        return {
            compare: (actual: any, expected: any): jasmine.CustomMatcherResult => {
                if (expected === undefined) {
                    expected = {};
                }

                const result = newResult();

                if (actual === undefined) {
                    result.message = `Could not check actual element as it was undefined`;
                } else {
                    result.pass = Promise.all(
                        fieldDefinitions(expected).map(field =>
                            actual.fieldTextOf(field.viewField)
                                .then(value => {
                                    const expectedValue = removeNullsAndNewLines(field.value);
                                    if (isEqual(value, expectedValue)) {
                                        return true;
                                    } else {
                                        result.message += `Expected ${field.viewField} field to be ${expectedValue} but was ${value}\n`;
                                        return false;
                                    }
                                }).then(value => value,
                                    error => {
                                        console.error(error);
                                        result.message += 'Error comparing field: ' + JSON.stringify(field);
                                        return false;
                                    }
                                )
                            )
                        )
                        .then(
                            values => values.every(isEqual => isEqual),
                            () => false
                        ) as any;
                }

                return result;
            }
        }
    }
}

const declarationMatchers: jasmine.CustomMatcherFactories = {
    "isDeclarationPreviewWithData": compareFields(previewFields),
    "isDeclarationHeaderWithData": compareFields(headerFields),
    "isDeclarationItemWithData": compareFields(itemFields)
};

export { declarationMatchers };
