import {UserDetails} from "./user-details.po";
import {Wiremock} from "./wiremock";
import {SignInScenario} from "./sign-in/sign-in-scenario";

describe('user details', () => {
  let userDetails: UserDetails;

  beforeEach((done) => {
    userDetails = new UserDetails();
    Wiremock.reset().then(done);
  });

  describe('signed in', () => {
    beforeEach((done) => {
      new SignInScenario().givenUserIsSignedIn().then(done, done);
    });

    it("should display the user's full name", () => {
      expect(userDetails.getFullName()).toEqual("Search User");
    });

    it("should display the user's department information", () => {
      expect(userDetails.getDeparment()).toEqual("Operations Unit");
    });

    it("should display the user icon", () => {
      expect(userDetails.isUserIconDisplayed()).toBeTruthy();
    });

  });
});
