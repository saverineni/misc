package contracttests.wiremock;

import spock.lang.Specification

class WiremockContractUrlsSpec extends Specification {
    WiremockContractUrls contractUrls = new WiremockContractUrls()

    def 'should load the wiremock url path mappings'() {
        given:
        def urls = contractUrls.load(mockWiremockUrl())

        expect:
        urls == [
            [url: 'url1', method: 'GET'],
            [url: 'url2', method: 'POST']
        ]
    }

    private mockWiremockUrl() {
        this.getClass().getResource("/contracttests/wiremock").toString()
    }
}
