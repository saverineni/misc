package contracttests.swagger

import groovy.json.JsonSlurper
import spock.lang.Specification

class SwaggerSchemaSpec extends Specification {

    def 'should give map of resource to schema definition'() {
        given:
        SwaggerSchema swaggerSchema = swaggerSchema('simpleSchemaPaths.json')

        when:
        def pathDefinitions = swaggerSchema.pathDefinitions

        then:
        pathDefinitions == [
            '/path-one': [ method: 'GET', response: '#/definitions/One' ],
            '/post-resource': [ method: 'POST', response: '#/definitions/PostData' ],
            '/path-two': [ method: 'GET', response: '#/definitions/Two' ],
        ]
    }

    def 'should give map of resource to schema definition excluding actuator paths'() {
        given:
        SwaggerSchema swaggerSchema = swaggerSchema('schemaPathsWithActuator.json')

        when:
        def pathDefinitions = swaggerSchema.pathDefinitions

        then:
        pathDefinitions == [
            '/path-two': [ method: 'GET', response: '#/definitions/Two' ]
        ]
    }

    def 'should re-format path with string path variables'() {
        given:
        SwaggerSchema swaggerSchema = swaggerSchema('schemaPathsWithVariables.json')

        when:
        Map pathDefinitions = swaggerSchema.pathDefinitions

        then:
        pathDefinitions.containsKey('/path-one/firstParam/secondParam')
    }

    def 'should substitute integer path variables'() {
        given:
        SwaggerSchema swaggerSchema = swaggerSchema('schemaPathsWithVariables.json')

        when:
        Map pathDefinitions = swaggerSchema.pathDefinitions

        then:
        pathDefinitions.containsKey('/path-two/1/secondParam')
    }

    def 'should convert swagger schema to valid json schema, removing property format attributes'() {
        given:
        SwaggerSchema swaggerSchema = swaggerSchema('schemaWithPropertyFormats.json')
        def validJsonSchema = new JsonSlurper().parseText(swaggerSchema.validJsonSchema)

        when:
        def formats = [:]
        def propertiesWithFormat = validJsonSchema.definitions.each { key, value ->
            value.get('properties').each { name, definition ->
                if (definition.format) {
                    formats[name] = definition.format
                }
            }
        }

        then:
        formats.size() == 0
    }

    private swaggerSchema(String resource) {
        new SwaggerSchema(this.getClass().getResource(resource).text)
    }
}