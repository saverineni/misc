package contracttests.schema

import contracttests.request.RequestContent
import groovy.json.JsonSlurper
import spock.lang.Specification
import spock.util.mop.ConfineMetaClassChanges

@ConfineMetaClassChanges([RequestContent])
class SchemaLoaderSpec extends Specification {
    static URL = 'http://test_url'

    SchemaLoader loader = new SchemaLoader()

    def setup() {
        GroovyMock(RequestContent, global: true)
    }

    def "Should add additionalProperties field with value false to each of the definition"() {
        given:
        def expectedSchema = loadResource("expectedSchema.json")
        RequestContent.GET(URL) >> loadResource("schema.json")

        when:
        def actualSchema = loader.loadSchema(URL)

        then:
        jsonAsMap(actualSchema) == jsonAsMap(expectedSchema)

    }

    def "Shouldn't add additionalProperties field to the definition if it already exists"() {
        given:
        def expectedSchema = loadResource("schemaWithAdditionalProperties.json")
        RequestContent.GET(URL) >> expectedSchema

        when:
        def actualSchema = loader.loadSchema(URL)

        then:
        jsonAsMap(actualSchema) == jsonAsMap(expectedSchema)

    }

    private jsonAsMap(String actualSchema) {
        new JsonSlurper().parseText(actualSchema)
    }

    private loadResource(name) {
        this.getClass().getResource(name).text
    }

}
