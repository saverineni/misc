package contracttests.schema;

import org.apache.http.client.HttpResponseException

import contracttests.request.RequestContent
import contracttests.request.ResourceNotFoundException
import contracttests.schema.ClientDataValidator
import contracttests.schema.SchemaValidator
import spock.lang.Specification;
import spock.util.mop.ConfineMetaClassChanges

@ConfineMetaClassChanges([RequestContent, SchemaValidator])
class ClientDataValidatorSpec extends Specification {
    static final HOST = 'host_url'
    static final PATH = '/path'
    static final DEFINITION = [ method: 'GET', response: 'definition' ]

    SchemaValidator schemaValidator = GroovyMock()
    ClientDataValidator validator = new ClientDataValidator(schemaValidator: schemaValidator, host: HOST)

    def setup() {
        GroovyMock(RequestContent, global: true)
    }

    def 'should validate response data against a given schema and definition'() {
        given:
        def json = 'json'
        RequestContent.GET("$HOST$PATH") >> json
        schemaValidator.isValidForDefinition(DEFINITION.response, json) >> true

        when:
        def result = validator.validateResourceForDefinition(PATH, DEFINITION)

        then:
        result == true
    }

    def 'should give true for resource not found'() {
        given:
        RequestContent.GET("$HOST$PATH") >> { throw new ResourceNotFoundException() }

        when:
        def result = validator.validateResourceForDefinition(PATH, DEFINITION)

        then:
        result == true
    }

    def 'should give true for null definition - needs fixing!'() {
        when:
        def result = validator.validateResourceForDefinition(PATH, null)

        then:
        result == true
    }

    def 'should throw exception if not handled'() {
        given:
        RequestContent.GET("$HOST$PATH") >> { throw new Exception() }

        when:
        def result = validator.validateResourceForDefinition(PATH, DEFINITION)

        then:
        thrown(Exception)
    }

    def 'until implemented should return true for non-GET definitions'() {
        given:
        def definition = [ method: 'POST', response: 'definition' ]

        when:
        def result = validator.validateResourceForDefinition('/post-resource', definition)

        then:
        result == true
    }
}
