package contracttests.contract;

import com.github.tomakehurst.wiremock.junit.WireMockRule

import org.junit.Rule

import static com.github.tomakehurst.wiremock.client.WireMock.*

import spock.lang.Specification

class WiremockSwaggerContractSpec extends Specification {

    @Rule
    WireMockRule wireMockRule = new WireMockRule(8080)

    WiremockSwaggerContract contract

    def setup() {
        wireMockRule.resetAll()
        wireMockRule.stubFor(get(urlEqualTo('/schema')).willReturn(aResponse().withBody(loadResource('matchedSwaggerSchema.json'))))

        def schemaUrl = wireMockRule.url('/schema')
        def dataUrl = wireMockRule.url('')

        contract = new WiremockSwaggerContract(schemaUrl: schemaUrl, dataUrl: dataUrl.take(dataUrl.length() - 1))
    }

    def 'should give true for valid schema and wiremock mappings'() {
        given:
        wireMockRule.stubFor(get(urlEqualTo('/items/id/type')).willReturn(aResponse().withBody(loadResource('validItem.json'))).withName('contract test1'))
        wireMockRule.stubFor(get(urlEqualTo('/by-number/1')).willReturn(aResponse().withBody(loadResource('validItem.json'))).withName('contract test2'))
        wireMockRule.stubFor(get(urlEqualTo('/items')).willReturn(aResponse().withBody(loadResource('validItems.json'))).withName('contract test3'))

        expect:
        contract.contractValid() == true

        and:
        wireMockRule.verify(getRequestedFor(urlEqualTo('/items/id/type')))
        wireMockRule.verify(getRequestedFor(urlEqualTo('/by-number/1')))
        wireMockRule.verify(getRequestedFor(urlEqualTo('/items')))
    }

    def 'should give false for valid schema and wiremock mappings for wrong http method'() {
        given:
        wireMockRule.stubFor(get(urlEqualTo('/items/id/type')).willReturn(aResponse().withBody(loadResource('validItem.json'))).withName('contract test1'))
        // omit name so schema not checked
        wireMockRule.stubFor(get(urlEqualTo('/by-number/1')).willReturn(aResponse().withBody(loadResource('validItem.json'))))
        wireMockRule.stubFor(post(urlEqualTo('/by-number/1')).withName('contract test2'))
        wireMockRule.stubFor(get(urlEqualTo('/items')).willReturn(aResponse().withBody(loadResource('validItems.json'))).withName('contract test3'))

        expect:
        contract.contractValid() == false
    }

    def 'should give false for missing wiremock mapping'() {
        given:
        wireMockRule.stubFor(get(urlEqualTo('/items/id/type')).willReturn(aResponse().withBody(loadResource('validItem.json'))).withName('contract test1'))
        wireMockRule.stubFor(get(urlEqualTo('/by-number/1')).willReturn(aResponse().withBody(loadResource('validItem.json'))).withName('contract test2'))
        wireMockRule.stubFor(get(urlEqualTo('/items')).willReturn(aResponse().withBody(loadResource('validItems.json'))).withName('contract test3'))
        wireMockRule.stubFor(get(urlEqualTo('/not-in-schema')).willReturn(aResponse().withBody(loadResource('validItems.json'))).withName('contract test4'))

        expect:
        contract.contractValid() == false

        and:
        wireMockRule.verify(getRequestedFor(urlEqualTo('/items/id/type')))
        wireMockRule.verify(getRequestedFor(urlEqualTo('/by-number/1')))
        wireMockRule.verify(getRequestedFor(urlEqualTo('/items')))
    }

    def 'should give true for valid schema and url pattern wiremock mappings'() {
        given:
        wireMockRule.stubFor(get(urlPathMatching('/items/\\w+/type')).willReturn(aResponse().withBody(loadResource('validItem.json'))).withName('contract test1'))
        wireMockRule.stubFor(get(urlPathMatching('/by-number/\\d+')).willReturn(aResponse().withBody(loadResource('validItem.json'))).withName('contract test2'))
        wireMockRule.stubFor(get(urlEqualTo('/items')).willReturn(aResponse().withBody(loadResource('validItems.json'))).withName('contract test3'))

        expect:
        contract.contractValid() == true
    }

    def 'should give true for schema definitions without data definitions'() {
        when:
        wireMockRule.stubFor(get(urlEqualTo('/items/id/type')).willReturn(aResponse().withStatus(404)))
        wireMockRule.stubFor(get(urlEqualTo('/by-number/1')).willReturn(aResponse().withStatus(404)))
        wireMockRule.stubFor(get(urlEqualTo('/items')).willReturn(aResponse().withBody(loadResource('validItems.json'))))

        then:
        contract.contractValid() == true
    }

    def 'should give false for data not conforming to the schema'() {
        when:
        wireMockRule.stubFor(get(urlEqualTo('/items')).willReturn(aResponse().withBody(loadResource('invalidJson.json'))))
        wireMockRule.stubFor(get(urlEqualTo('/items/id/type')).willReturn(aResponse().withBody(loadResource('validItem.json'))))
        wireMockRule.stubFor(get(urlEqualTo('/by-number/1')).willReturn(aResponse().withBody(loadResource('validItem.json'))))

        then:
        contract.contractValid() == false
    }

    private loadResource(String fileName) {
        this.getClass().getResource(fileName).text
    }
}
