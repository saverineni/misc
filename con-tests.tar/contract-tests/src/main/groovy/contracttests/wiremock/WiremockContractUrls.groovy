package contracttests.wiremock

import contracttests.request.RequestContent
import groovy.json.JsonSlurper

class WiremockContractUrls {

    def load(wiremockUrl) {
        def response = new JsonSlurper().parseText(RequestContent.GET("$wiremockUrl/__admin/mappings"))
        response.mappings.findAll { it.name ==~ /contract.+/ }
                         .collect { it.request }
                         .collect { req ->
                             [ url: { if (req.url) req.url else req.urlPathPattern }(),
                               method: req.method ] }
    }
}
