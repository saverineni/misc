package contracttests.contract

import contracttests.schema.SchemaLoader
import contracttests.swagger.SwaggerApi
import contracttests.swagger.SwaggerSchema
import contracttests.wiremock.WiremockContractUrls
import groovy.util.logging.Slf4j

@Slf4j
class WiremockSwaggerContract {
    String schemaUrl
    String dataUrl

    static void main(String[] args) {
        def api = new WiremockSwaggerContract(
            schemaUrl: args[0],
            dataUrl: args[1]
        )

        if (api.contractValid()) {
            log.info('Contracts validated successfully')
            System.exit(0)
        } else {
            log.error('Contracts not valid')
            System.exit(1)
        }
    }

    boolean contractValid() {
        log.info("Loading schema from $schemaUrl, data url is $dataUrl")
        def swaggerSchema = loadSwaggerSchema()
        log.debug("Swagger schema processed. New JSON $swaggerSchema.validJsonSchema")

        def dataHasSchemaPath = dataPathDefinedInSchema(swaggerSchema)

        def swaggerApi = new SwaggerApi()
        def dataConformsToSchema = swaggerApi.dataConformsToSchema(swaggerSchema, dataUrl)

        return dataHasSchemaPath && dataConformsToSchema
    }

    private dataPathDefinedInSchema(SwaggerSchema swaggerSchema) {
        WiremockContractUrls wiremock = new WiremockContractUrls()
        def wiremockUrls = wiremock.load(dataUrl)
        log.info('Loaded contract urls from wiremock {}', wiremockUrls)
        Map schemaPathDefs = swaggerSchema.pathDefinitions

        def pathMissingFromSchema = wiremockUrls.collect { urlDef ->
                schemaPathDefs.find {
                    (it.key == urlDef.url || it.key ==~ urlDef.url) &&
                        it.value.method.equalsIgnoreCase(urlDef.method)
                } == null
            }.find { it }

        if (pathMissingFromSchema) {
            log.error('''
!!Data path not defined in the loaded schema!!
contractPaths: {}
schemaPaths: {}''', wiremockUrls, schemaPathDefs)
            return false
        }

        return true
    }

    private SwaggerSchema loadSwaggerSchema() {
        new SwaggerSchema(new SchemaLoader().loadSchema(schemaUrl))
    }
}
