package contracttests.swagger

import contracttests.schema.ClientDataValidator
import contracttests.schema.SchemaLoader
import contracttests.schema.SchemaValidator
import groovy.util.logging.Slf4j

@Slf4j
class SwaggerApi {
    def dataConformsToSchema(SwaggerSchema swaggerSchema, String dataUrl) {
        def dataValidator = toClientDataValidator(swaggerSchema, dataUrl)

        !swaggerSchema.pathDefinitions
                      .collect(dataValidator.validateResourceForDefinition)
                      .contains(false)
    }

    private ClientDataValidator toClientDataValidator(swaggerSchema, dataUrl) {
        def schemaValidator = new SchemaValidator(swaggerSchema.validJsonSchema)

        new ClientDataValidator(schemaValidator: schemaValidator, host: dataUrl)
    }
}
