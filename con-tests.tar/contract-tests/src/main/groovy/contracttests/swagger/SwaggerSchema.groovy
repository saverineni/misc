package contracttests.swagger

import groovy.json.JsonOutput
import groovy.json.JsonSlurper

class SwaggerSchema {
    private final String schemaJson

    SwaggerSchema(String schemaJson) {
        this.schemaJson = schemaJson
    }

    def getPathDefinitions() {
        schemaAsMap.paths
                   .findAll { !it.key.startsWith('/actuator') }
                   .collectEntries { [(toValidPath(it)): getPathDefinition(it)] }
    }

    def getValidJsonSchema() {
        def validSchema = schemaAsMap
        validSchema.definitions.each {
            it.value.properties.each {
                it.value.remove('format')
            }
        }

        JsonOutput.toJson(validSchema)
    }

    private getSchemaAsMap() {
        new JsonSlurper().parseText(schemaJson)
    }

    private toValidPath(pathEntry) {
        pathEntry.key.replaceAll(/\/\{(\w+)\}/) {
            def pathVariable = it[1]
            def variableType = variableType(pathVariable, pathEntry.value)
            if (variableType == 'integer') {
                '/1'
            } else {
                "/$pathVariable"
            }
        }
    }

    private variableType(pathVariable, pathDefinition) {
        pathDefinition.'get'
                      ?.parameters
                      .find { it.name == pathVariable && it.in == 'path' }
                      ?.type
    }

    private getPathDefinition(schemaEntry) {
        def method = schemaEntry.value.iterator().next().key

        [
            method: method.toUpperCase(),
            response: schemaEntry.value."${method}".responses.'200'.schema.'$ref'
        ]
    }
}
