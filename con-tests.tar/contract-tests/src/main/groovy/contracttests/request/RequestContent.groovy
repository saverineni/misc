package contracttests.request

import groovy.json.JsonSlurper

class RequestContent {

    static String GET(String url) {
        try {
            def result = url.toURL().text

            if (result == null) {
                throw new ResourceNotFoundException()
            }

            return result
        } catch (FileNotFoundException e) {
            throw new ResourceNotFoundException(e)
        }
    }
}
