package contracttests.request

class ResourceNotFoundException extends RuntimeException {
    ResourceNotFoundException() {
        super()
    }
    ResourceNotFoundException(Throwable cause) {
        super(cause)
    }
}