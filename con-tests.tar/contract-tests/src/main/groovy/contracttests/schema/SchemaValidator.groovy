package contracttests.schema

import com.fasterxml.jackson.databind.ObjectMapper
import com.github.fge.jsonschema.main.JsonSchema
import com.github.fge.jsonschema.main.JsonSchemaFactory
import com.github.fge.jsonschema.core.report.ProcessingReport

import groovy.transform.Immutable
import groovy.util.logging.Slf4j

@Immutable
@Slf4j
class SchemaValidator {
    private final ObjectMapper mapper = new ObjectMapper()

    String jsonSchema

    def isValid(String json) {
        parsedJsonSchema.validate(toJsonNode(json)).success
    }

    private JsonSchema getParsedJsonSchema() {
        JsonSchemaFactory.byDefault().getJsonSchema(toJsonNode(jsonSchema))
    }

    def isValidForDefinition(String definition, String json) {
        isSuccessful(
            parsedJsonSchemaForDefinition(definition).validate(toJsonNode(json))
        )
    }

    private JsonSchema parsedJsonSchemaForDefinition(definition) {
        JsonSchemaFactory.byDefault()
            .getJsonSchema(toJsonNode(jsonSchema), definition.replaceFirst(/^#/, ''))
    }

    private toJsonNode(json) {
        mapper.readTree(json)
    }

    private isSuccessful(ProcessingReport result) {
        result.each {
            if (result.success) {
                log.warn(it.message)
            } else {
                log.error(it.message)
            }
        }

        result.success
    }
}
