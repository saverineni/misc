package contracttests.schema

import contracttests.request.RequestContent
import contracttests.request.ResourceNotFoundException
import groovy.util.logging.Slf4j

@Slf4j
class ClientDataValidator {
    SchemaValidator schemaValidator
    String host

    def validateResourceForDefinition = { resource, definition ->
        log.info("Loading data for $resource. Validating against definition: $definition")

        if (definition == null || definition['method'] != 'GET') {
            log.warn("unhandled definition type for $resource")
            return true
        }

        try {
            def json = RequestContent.GET("$host$resource")

            schemaValidator.isValidForDefinition(definition.response, json)
        } catch (ResourceNotFoundException e) {
            log.warn("!!!!!! Resource not found for: $resource !!!!!!")
            return true
        }
    }
}
