package contracttests.schema

import contracttests.request.RequestContent
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import groovy.util.logging.Slf4j

@Slf4j
class SchemaLoader {

    def loadSchema(String url){
        def schema = new JsonSlurper().parseText(RequestContent.GET(url))

        schema.definitions.each { key,value ->
            if(!value.additionalProperties) {
                value.additionalProperties = false
            }
        }

        def updatedSchema = JsonOutput.toJson(schema)
        log.debug("Schema loaded and updated to disallow additional properties: $updatedSchema")

        return updatedSchema
    }

}
