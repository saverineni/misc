#!/bin/bash
mvn clean install

docker run -d -p 9082:8080 --name contract_test_data --rm cdsdar/customs-search-ui_contract

java -jar target/contract-tests-0.1.0-SNAPSHOT-jar-with-dependencies.jar $1 http://localhost:9082

docker stop contract_test_data
