#!/usr/bin/env bash

# test/resources/mss/random directory has been populated with data using data population tool
# DATABASE_NAME=random (data population tool data)
# DATABASE_NAME=search (hand crafted data)

DATABASE_NAME=search
DIR=$(cd `dirname $0` && pwd)
DDL_FILE_BASE_PATH="src/test/resources/mss/$DATABASE_NAME/ddl"
DATA_FILE_BASE_PATH="src/test/resources/mss/$DATABASE_NAME/ingestion-pipeline-output"
DATA_FILE_ABSOLUTE_PATH=$DIR/$DATA_FILE_BASE_PATH
GREEN=`tput setaf 2`
RED=`tput setaf 1`
NC=`tput sgr0` # No Color

function log() {
    echo "${GREEN}$1${NC}"
}

function error() {
    echo "${RED}$1${NC}"
}

function ddlFor() {
    cat $DDL_FILE_BASE_PATH/$1.sql | sed -e "s/DATABASE_NAME/$DATABASE_NAME/g"
}

log "creating database '$DATABASE_NAME'"
hive -e "DROP DATABASE IF EXISTS $DATABASE_NAME CASCADE;
CREATE DATABASE IF NOT EXISTS $DATABASE_NAME;"

log ''
log "creating tables imenselect, imendetail, imeiselect, inad, iica, iina, nxenselect, nxendetail, nxeiselect, nxeidetail, nxnad, nxica, nxina ..."
hive -e "
$(ddlFor 'imenselect');
$(ddlFor 'imendetail');
$(ddlFor 'imeiselect');
$(ddlFor 'inad');
$(ddlFor 'iica');
$(ddlFor 'iina');
$(ddlFor 'nxenselect');
$(ddlFor 'nxendetail');
$(ddlFor 'nxeiselect');
$(ddlFor 'nxeidetail');
$(ddlFor 'nxnad');
$(ddlFor 'nxica');
$(ddlFor 'nxina');
"

log ''
log "loading test data into hive tables..."
hive -e "
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/imenselect/part-00000' overwrite into table $DATABASE_NAME.imenselect;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/imendetail/part-00000' overwrite into table $DATABASE_NAME.imendetail;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/imeiselect/part-00000' overwrite into table $DATABASE_NAME.imeiselect;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/inad/part-00000' overwrite into table $DATABASE_NAME.inad;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/iica/part-00000' overwrite into table $DATABASE_NAME.iica;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/iina/part-00000' overwrite into table $DATABASE_NAME.iina;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxenselect/part-00000' overwrite into table $DATABASE_NAME.nxenselect;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxendetail/part-00000' overwrite into table $DATABASE_NAME.nxendetail;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxeiselect/part-00000' overwrite into table $DATABASE_NAME.nxeiselect;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxeidetail/part-00000' overwrite into table $DATABASE_NAME.nxeidetail;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxnad/part-00000' overwrite into table $DATABASE_NAME.nxnad;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxica/part-00000' overwrite into table $DATABASE_NAME.nxica;
load data local inpath '$DATA_FILE_ABSOLUTE_PATH/nxina/part-00000' overwrite into table $DATABASE_NAME.nxina;
"

log ""
log 'done'