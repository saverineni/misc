CREATE TABLE search.nxnad(
  iekey string,
  hdrnadtype string,
  hdrnadname string,
  hdrnadpostcode string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
