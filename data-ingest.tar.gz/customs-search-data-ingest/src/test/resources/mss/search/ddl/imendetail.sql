CREATE TABLE search.imendetail(
  iekey string,
  gdslocn string,
  trptmodecode string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
