CREATE TABLE search.nxeidetail(
  iekey string,
  ieitno int,
  generationno int,
  itemdispcntry string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
