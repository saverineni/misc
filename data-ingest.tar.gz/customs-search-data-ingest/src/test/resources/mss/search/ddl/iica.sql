CREATE TABLE search.iica(
  iekey string,
  ieitno int,
  roe string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
