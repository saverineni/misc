CREATE TABLE search.nxendetail(
  iekey string,
  generationno int,
  trptmodecode string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
