CREATE TABLE search.iina(
  iekey string,
  ieitno int,
  itemnadtype string,
  itemnadname string,
  itemnadpostcode string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
