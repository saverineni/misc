CREATE TABLE IF NOT EXISTS DATABASE_NAME.inad(
  iekey string,
  clrncdate string,
  hdrnadtype string,
  hdrnadcity string,
  hdrnadcntry string,
  hdrnadlng string,
  hdrnadname string,
  hdrnadpostcode string,
  hdrnadstreet string,
  da_iv_id string,
  edh_da_file_date string,
  standard_edh_da_file_date string,
  edh_da_sequence_number string,
  edh_da_load_date string,
  edh_da_health_warning string,
  edh_da_purge_date string,
  standard_clrncdate string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE