CREATE TABLE IF NOT EXISTS DATABASE_NAME.iina(
  iekey string,
  ieitno string,
  clrncdate string,
  itemnadtype string,
  itemnadcity string,
  itemnadcntry string,
  itemnadlng string,
  itemnadname string,
  itemnadpostcode string,
  itemnadstreet string,
  da_iv_id string,
  edh_da_file_date string,
  standard_edh_da_file_date string,
  edh_da_sequence_number string,
  edh_da_load_date string,
  edh_da_health_warning string,
  edh_da_purge_date string,
  standard_clrncdate string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE