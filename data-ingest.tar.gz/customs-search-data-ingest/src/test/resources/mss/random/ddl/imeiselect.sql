CREATE TABLE IF NOT EXISTS DATABASE_NAME.imeiselect(
 iekey string,
 ieitno int,
 clrncdate string,
 cmdtycode string,
 cpc string,
 origcntry string,
 tariffchap string,
 itemimptrturncc string,
 itemimptrturn string,
 itemcnsgrturncc string,
 itemcnsgrturn string,
 itemdispcntry string,
 da_iv_id string,
 edh_da_file_date string,
 standard_edh_da_file_date string,
 edh_da_sequence_number string,
 edh_da_load_date string,
 edh_da_health_warning string,
 edh_da_purge_date string,
 standard_clrncdate string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE