###### Pre-requisite: VM with apache big-top installed
 
## Generating data population tool data
```
    Currently, the data population tool is the only means to generate MSS mock data.
    The FAST-P environments are injected with 20000 MSS declarations using data population tool.
    The Dev spark job injects the above 20000 declarations into elasticsearch (dev) via jenkins pipeline.
```
    

#### Test data directories
- The test data directory ```test/resources/mss/search```  contains hand crafted data.
- The test data directory ```test/resources/mss/random```  contains data generated using data population tool.

#### Random data generation using data population tool
- Change Directory to ```cds-data-population-tool``` project
- Build fat jar ```sbt -J-Xmx2G -J-Xss2M assembly``` 
- Fat jar location ```target/cds-data-population-tool-assembly-1.0.<build-no>-SNAPSHOT.jar```
- Execute the spark job to generate the desired import and export declarations
    
```
    spark-submit 
                --class "uk.gov.gsi.hmrc.cds.data.populationtool.SparkMSSGenerator" 
                --master local 
                <cds-data-population-tool-fat-jar-location> 
                <number-of-imports> 
                <number-of-exports> 
                <location-to-write-data-file>

    
    [example]
    spark-submit --class "uk.gov.gsi.hmrc.cds.data.populationtool.SparkMSSGenerator" --master local file:////home/developer/Dev/Workspace/CDS/cds-data-population-tool/target/cds-data-population-tool-assembly-1.0.328-SNAPSHOT.jar 20 20 file:///home/developer/Dev/Workspace/CDS/customs-search-data-ingest/src/test/resources/mss/random/
```

#### Local Hive database set up 
- The ```DATABASE_NAME``` can either be ```search``` or ```random```
- The local data setup script ```data-setup.sh``` is used to create a local hive database.

