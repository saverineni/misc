package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark;

import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import uk.gov.gsi.hmrc.cds.search.searchdataingest.config.TestConfig;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestConfig.class)
public abstract class SparkTest implements DatasetSchema {}
