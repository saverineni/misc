package uk.gov.gsi.hmrc.cds.search.searchdataingest.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = {
        "uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset",
})
public class DatasetConfig {
}
