package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark;

import static java.util.Arrays.asList;

import java.io.File;

import org.apache.spark.sql.SparkSession;

import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader.ResourceService;

public class HiveDatabaseSetup {

    private SparkSession sparkSession;
    private ResourceService resourceService;

    public HiveDatabaseSetup(SparkSession sparkSession, ResourceService resourceService) {
        this.sparkSession = sparkSession;
        this.resourceService = resourceService;
    }

    private File mssSourceFilePath = new File("src/test/resources/mss/search/ingestion-pipeline-output");

    public void setUp() {

        String mssSourceFilePathAbsolutePath = mssSourceFilePath.getAbsolutePath();

        sparkSession.sql(String.format("DROP DATABASE IF EXISTS search CASCADE"));
        sparkSession.sql(String.format("CREATE DATABASE IF NOT EXISTS search"));

        asList("imenselect","imendetail","imeiselect","inad","iica","iina","nxenselect","nxendetail","nxeiselect","nxeidetail","nxnad","nxica","nxina", "ctry").forEach(table -> {
            sparkSession.sql(getDdlFor(table));
            loadDataFor(mssSourceFilePathAbsolutePath, table);
        });
    }

    private String getDdlFor(String tableName) {
        return resourceService.getResourceAsString(String.format("mss/search/ddl/%s.sql", tableName));
    }

    private void loadDataFor(String sourceFilePath, String tableName) {
        String loadfileTemplate = "load data local inpath '%s/%s/part-00000' overwrite into table search.%s";
        sparkSession.sql(String.format(loadfileTemplate, sourceFilePath, tableName, tableName));
    }
}
