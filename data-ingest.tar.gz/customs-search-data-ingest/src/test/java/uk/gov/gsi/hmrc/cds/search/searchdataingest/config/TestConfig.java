package uk.gov.gsi.hmrc.cds.search.searchdataingest.config;

import java.io.File;

import javax.annotation.PostConstruct;

import org.apache.spark.sql.SparkSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.HiveDatabaseSetup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader.ResourceService;

@Configuration
@Import({
    SparkReaderConfig.class,
    DatasetConfig.class
})
public class TestConfig {
    public static final String TEST_HIVE_METASTORE_DB = "target/hive/metastore_db";
    public static final String TEST_HIVE_WAREHOUSE = "target/hive/spark-warehouse";

    /**
     * Default spark session using pre-populated embedded hive metastore and spark-warehouse
     */
    @Bean
    public SparkSession sparkSession() {
        String hiveMetastoreDbAbsolutePath = new File(TEST_HIVE_METASTORE_DB).getAbsolutePath();
        String hiveWarehouseAbsolutePath = new File(TEST_HIVE_WAREHOUSE).getAbsolutePath();
        return SparkSession
                .builder()
                .appName("customs-search-data-ingest")
                .master("local")
                .config("spark.sql.warehouse.dir", hiveWarehouseAbsolutePath)
                .config("javax.jdo.option.ConnectionURL", String.format("jdbc:derby:%s;create=true", hiveMetastoreDbAbsolutePath))
                .enableHiveSupport()
                .getOrCreate();
    }

    @Autowired
    private ResourceService resourceService;

    @PostConstruct
    public void dbSetup() {
        HiveDatabaseSetup hiveDatabaseSetup = new HiveDatabaseSetup(sparkSession(), resourceService);
        hiveDatabaseSetup.setUp();
    }
}
