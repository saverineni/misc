package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset;

import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.SparkSession;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.Country;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.Declaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.DeclarationLineDeclarationGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.entity.DeclarationHeader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader.DeclarationHeaderReader;


public class DeclarationDatasetTest extends SparkTest {
    private static final String CONSIGNEE_NAME = "consignee";
    private static final String CONSIGNEE_POSTCODE = "consignee postcode";
    private static final String CONSIGNEE_TURN = "consignee turn";
    private static final String CONSIGNOR_NAME = "consignor name";
    private static final String CONSIGNOR_POSTCODE = "consignor postcode";
    private static final String CONSIGNOR_TURN = "consignor turn";
    private static final String DECLARATION_ID = "declaration id";
    private static final String DESTINATION_COUNTRY = "destination country";
    private static final String DISPATCH_COUNTRY = "dispatch country";
    private static final String ENTRY_DATE = "entry date";
    private static final String ENTRY_NUMBER = "entry number";
    private static final String EPU_NUMBER = "epu number";
    private static final String GOODS_LOCATION = "goods location";
    private static final String ROUTE = "route";
    private static final String TRANSPORT_MODE_CODE = "transport mode code";
    private static final String SOURCE_MSS = "CHIEF";
    private static final String IMPORT_TYPE = "Import";
    private static final String SEQUENCE_ID = "1";

    DeclarationHeaderReader declarationHeaderReader = mock(DeclarationHeaderReader.class);
    DeclarationLineGroupDataset declarationLineGroupDataset = mock(DeclarationLineGroupDataset.class);

    DeclarationDataset declarationDataset = new DeclarationDataset(declarationHeaderReader, declarationLineGroupDataset);

    @Autowired
    SparkSession spark;

    @Test
    public void shouldJoinTheHeadersAndLinesAsDeclarationDataset() {
        givenDeclarationHeaders();
        givenDeclarationLineGroups();

        Dataset<Declaration> result = declarationDataset.build();

        assertThat(result.count(), is(3L));
    }

    @Test
    public void shouldAddTheLinesToTheHeaderAsADeclaration() {
        givenDeclarationHeaders();
        givenDeclarationLineGroups();

        Dataset<Declaration> result = declarationDataset.build();

        Declaration declaration = result.first();
        assertThat(declaration.getDeclarationSource(), is(SOURCE_MSS));
        assertThat(declaration.getImportExportIndicator(), is(IMPORT_TYPE));
        assertThat(declaration.getDeclarationId(), is("declaration1"));
        assertThat(declaration.getLines().size(), is(3));
        assertThat(declaration.getLines().get(0).getDeclarationId(), is("declaration1"));
    }

    @Test
    public void shouldPopulateTheDeclarationFromHeaderAndLines() {
        givenDatasetWith(populatedDeclarationHeader());
        givenDatasetWith(newDeclarationLineDeclarationGroup(DECLARATION_ID, 1, SEQUENCE_ID));

        Dataset<Declaration> result = declarationDataset.build();

        Declaration declaration = result.first();
        assertThat(declaration, is(expectedDeclaration()));
    }

    @Test
    public void shouldJoinTheCorrectSequenceNumbersBetweenHeaderAndLines() {
        givenDatasetWith(
                newDeclarationHeader("1", "1"),
                newDeclarationHeader("2", "3")
        );
        givenDatasetWith(
                newDeclarationLineDeclarationGroup("declaration1", 1, "2"),
                newDeclarationLineDeclarationGroup("declaration2", 2, "2"),
                newDeclarationLineDeclarationGroup("declaration2", 3, "3")
        );

        Dataset<Declaration> result = declarationDataset.build();

        Declaration declaration1 = result.first();
        Declaration declaration2 = result.collectAsList().get(1);

        assertThat(declaration1.getDeclarationId(), is("declaration1"));
        assertThat(declaration1.getLines(), nullValue());

        assertThat(declaration2.getDeclarationId(), is("declaration2"));
        assertThat(declaration2.getLines(), hasSize(3));
    }

    private DeclarationHeader populatedDeclarationHeader() {
        Country dispatchCountry = new Country();
        dispatchCountry.setCode(DISPATCH_COUNTRY);
        Country destinationCountry = new Country();
        destinationCountry.setCode(DESTINATION_COUNTRY);

        DeclarationHeader declarationHeader = new DeclarationHeader();
        declarationHeader.setDeclarationSource(SOURCE_MSS);
        declarationHeader.setImportExportIndicator(IMPORT_TYPE);
        declarationHeader.setSequenceId(SEQUENCE_ID);
        declarationHeader.setConsigneeName(CONSIGNEE_NAME);
        declarationHeader.setConsigneePostcode(CONSIGNEE_POSTCODE);
        declarationHeader.setConsigneeTurn(CONSIGNEE_TURN);
        declarationHeader.setConsignorName(CONSIGNOR_NAME);
        declarationHeader.setConsignorPostcode(CONSIGNOR_POSTCODE);
        declarationHeader.setConsignorTurn(CONSIGNOR_TURN);
        declarationHeader.setDeclarationId(DECLARATION_ID);
        declarationHeader.setDestinationCountry(destinationCountry);
        declarationHeader.setDispatchCountry(dispatchCountry);
        declarationHeader.setEntryDate(ENTRY_DATE);
        declarationHeader.setEntryNumber(ENTRY_NUMBER);
        declarationHeader.setEpuNumber(EPU_NUMBER);
        declarationHeader.setGoodsLocation(GOODS_LOCATION);
        declarationHeader.setRoute(ROUTE);
        declarationHeader.setTransportModeCode(TRANSPORT_MODE_CODE);

        return declarationHeader;
    }

    private Declaration expectedDeclaration() {
        Country dispatchCountry = new Country();
        dispatchCountry.setCode(DISPATCH_COUNTRY);
        Country destinationCountry = new Country();
        destinationCountry.setCode(DESTINATION_COUNTRY);

        Declaration declaration = new Declaration();
        declaration.setDeclarationSource(SOURCE_MSS);
        declaration.setImportExportIndicator(IMPORT_TYPE);
        declaration.setSequenceId(SEQUENCE_ID);
        declaration.setConsigneeName(CONSIGNEE_NAME);
        declaration.setConsigneePostcode(CONSIGNEE_POSTCODE);
        declaration.setConsigneeTurn(CONSIGNEE_TURN);
        declaration.setConsignorName(CONSIGNOR_NAME);
        declaration.setConsignorPostcode(CONSIGNOR_POSTCODE);
        declaration.setConsignorTurn(CONSIGNOR_TURN);
        declaration.setDeclarationId(DECLARATION_ID);
        declaration.setDestinationCountry(destinationCountry);
        declaration.setDispatchCountry(dispatchCountry);
        declaration.setEntryDate(ENTRY_DATE);
        declaration.setEntryNumber(ENTRY_NUMBER);
        declaration.setEpuNumber(EPU_NUMBER);
        declaration.setGoodsLocation(GOODS_LOCATION);
        declaration.setRoute(ROUTE);
        declaration.setTransportModeCode(TRANSPORT_MODE_CODE);
        declaration.setLines(lines(DECLARATION_ID, 1, SEQUENCE_ID));
        return declaration;
    }

    private void givenDeclarationHeaders() {
        givenDatasetWith(
            newDeclarationHeader("1", "1"),
            newDeclarationHeader("2", "1"),
            newDeclarationHeader("3", "1")
        );
    }

    private void givenDatasetWith(DeclarationHeader... headers) {
        Dataset<DeclarationHeader> headerDataset = spark.createDataset(asList(headers), Encoders.bean(DeclarationHeader.class));
        when(declarationHeaderReader.declarationHeaderDataset()).thenReturn(headerDataset);
    }

    private DeclarationHeader newDeclarationHeader(String number, String sequenceId) {
        DeclarationHeader declarationHeader = new DeclarationHeader();
        declarationHeader.setDeclarationSource(SOURCE_MSS);
        declarationHeader.setImportExportIndicator(IMPORT_TYPE);
        declarationHeader.setDeclarationId("declaration" + number);
        declarationHeader.setSequenceId(sequenceId);

        return declarationHeader;
    }

    private void givenDeclarationLineGroups() {
        givenDatasetWith(
            newDeclarationLineDeclarationGroup("declaration1", 3, "1"),
            newDeclarationLineDeclarationGroup("declaration2", 2, "1")
        );
    }

    private void givenDatasetWith(DeclarationLineDeclarationGroup... lines) {
        Dataset<DeclarationLineDeclarationGroup> linesDataSet = spark.createDataset(asList(lines), Encoders.bean(DeclarationLineDeclarationGroup.class));
        when(declarationLineGroupDataset.build()).thenReturn(linesDataSet);
    }

    private DeclarationLineDeclarationGroup newDeclarationLineDeclarationGroup(String declarationId, int lineCount, String sequenceId) {
        DeclarationLineDeclarationGroup declarationLineDeclarationGroup = new DeclarationLineDeclarationGroup();
        declarationLineDeclarationGroup.setDeclarationId(declarationId);
        declarationLineDeclarationGroup.setSequenceId(sequenceId);
        declarationLineDeclarationGroup.setLines(lines(declarationId, lineCount, sequenceId));

        return declarationLineDeclarationGroup;
    }

    private List<DeclarationLine> lines(String declarationId, int lineCount, String sequenceId) {
        return IntStream.range(0, lineCount)
                        .mapToObj(line -> declarationLine(declarationId, line, sequenceId))
                        .collect(Collectors.toList());
    }

    private DeclarationLine declarationLine(String declarationId, int lineNumber, String sequenceId) {
        DeclarationLine line = new DeclarationLine();
        line.setDeclarationId(declarationId);
        line.setItemNumber(lineNumber);
        line.setSequenceId(sequenceId);

        return line;
    }
}
