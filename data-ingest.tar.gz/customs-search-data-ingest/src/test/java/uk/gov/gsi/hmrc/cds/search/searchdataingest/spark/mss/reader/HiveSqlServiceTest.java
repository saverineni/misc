package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;

public class HiveSqlServiceTest extends SparkTest {

    @Autowired
    private HiveSqlService hiveSqlService;

    @Test
    public void shouldReplaceDatabaseNamePlaceholderInSql() {
        String result = hiveSqlService.replaceSqlPlaceholders("xxx{{DATABASE_NAME}}yyy{{DATABASE_NAME}}");
        assertThat(result, is(equalTo("xxxsearchyyysearch")));
    }

    @Test
    public void shouldRemoveWherePlaceholderInSql() {
        String result = hiveSqlService.replaceSqlPlaceholders("xxx{{IMPORTSELECT_WHERE}}yyy{{EXPORTSELECT_WHERE}}");
        assertThat(result, is(equalTo("xxxyyy")));
    }

    @Test
    public void shouldRemoveJoinPlaceholderInSql() {
        String result = hiveSqlService.replaceSqlPlaceholders("xxx{{IMPORTSELECT_JOIN}}yyy{{EXPORTSELECT_JOIN}}");
        assertThat(result, is(equalTo("xxxyyy")));
    }

    @Test
    public void shouldRemovePartitionPlaceholderInSql() {
        String result = hiveSqlService.replaceSqlPlaceholders("xxx{{EXPORTSELECT_PARTITION}}yyy{{EXPORTITEMSELECT_PARTITION}}");
        assertThat(result, is(equalTo("xxxyyy")));
    }

    @Test
    public void shouldReplaceImportWherePlaceholderInSqlWithSingleSequenceId() {
        String[] sequenceId = {"1"};
        String result = hiveSqlService.replaceSqlPlaceholders("{{DATABASE_NAME}}xxx{{IMPORTSELECT_WHERE}}yyy{{IMPORTSELECT_WHERE}}", sequenceId);
        assertThat(result, is(equalTo("searchxxxWHERE importSelect.SEQUENCEID = 1yyyWHERE importSelect.SEQUENCEID = 1")));
    }

    @Test
    public void shouldReplaceImportWherePlaceholderInSqlWithMultipleSequenceIds() {
        String[] sequenceIds = {"1", "2"};
        String result = hiveSqlService.replaceSqlPlaceholders("xxx{{IMPORTSELECT_WHERE}}yyy", sequenceIds);
        assertThat(result, is(equalTo("xxxWHERE importSelect.SEQUENCEID = 1 or importSelect.SEQUENCEID = 2yyy")));
    }

    @Test
    public void shouldReplaceExportWherePlaceholderInSqlWithSingleSequenceId() {
        String[] sequenceId = {"1"};
        String result = hiveSqlService.replaceSqlPlaceholders("{{DATABASE_NAME}}xxx{{EXPORTSELECT_WHERE}}yyy{{EXPORTSELECT_WHERE}}", sequenceId);
        assertThat(result, is(equalTo("searchxxxWHERE exportSelect.SEQUENCEID = 1yyyWHERE exportSelect.SEQUENCEID = 1")));
    }

    @Test
    public void shouldReplaceExportWherePlaceholderInSqlWithMultipleSequenceIds() {
        String[] sequenceIds = {"1", "2"};
        String result = hiveSqlService.replaceSqlPlaceholders("xxx{{EXPORTSELECT_WHERE}}yyy", sequenceIds);
        assertThat(result, is(equalTo("xxxWHERE exportSelect.SEQUENCEID = 1 or exportSelect.SEQUENCEID = 2yyy")));
    }

    @Test
    public void shouldReplaceJoinPlaceholderInSqlWithSequenceIdJoin() {
        String[] sequenceId = {"1"};
        String result = hiveSqlService.replaceSqlPlaceholders("{{DATABASE_NAME}}xxx{{EXPORTSELECT_JOIN}}yyy{{EXPORTSELECT_JOIN}}", sequenceId);
        assertThat(result, is(equalTo("searchxxxand exportSelect.SEQUENCEID = exportItemSelect.SEQUENCEIDyyyand exportSelect.SEQUENCEID = exportItemSelect.SEQUENCEID")));
    }

    @Test
    public void shouldReplaceSelectPlaceholderInSqlWithSelectSequenceId() {
        String[] sequenceId = {"1"};
        String result = hiveSqlService.replaceSqlPlaceholders("xxx{{IMPORTSELECT_SELECT}}yyy{{EXPORTSELECT_SELECT}}", sequenceId);
        assertThat(result, is(equalTo("xxximportSelect.SEQUENCEID as sequenceId,yyyexportSelect.SEQUENCEID as sequenceId,")));
    }

    @Test
    public void shouldReplacePartitionSequenceIdPlaceholderInSql() {
        String[] sequenceId = {"1"};
        String result2 = hiveSqlService.replaceSqlPlaceholders("xxx{{EXPORTSELECT_PARTITION}}yyy{{EXPORTITEMSELECT_PARTITION}}", sequenceId);
        assertThat(result2, is(equalTo("xxx, exportSelect.SEQUENCEIDyyy, exportItemSelect.SEQUENCEID")));
    }

}
