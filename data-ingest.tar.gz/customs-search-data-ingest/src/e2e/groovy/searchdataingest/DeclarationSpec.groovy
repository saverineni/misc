package searchdataingest

import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

class DeclarationSpec extends Specification {
    @Shared
    List declarations

    def setupSpec() {
        declarations = new ESClient().documents()
    }

    def declaration(declarationId) {
        declarations.find { it.declarationId == declarationId }
    }

    def 'nullable import fields should result in the expected output'() {
        when:
            def declaration = declaration('IM003')

        then:
            declaration.lines[0].originCountry == [
                    code: ''
            ]

        and:
            declaration.dispatchCountry == [
                    code: ''
            ]
    }

    def 'nullable export fields should result in the expected output'() {
        when:
            def declaration = declaration('EX003')

        then:
            declaration.lines[0].originCountry == [
                    code: ''
            ]

        and:
            declaration.dispatchCountry == [
                    code: ''
            ]

    }

    def 'import declaration with no lines should have the correct output'() {
        when:
            def declaration = declaration('IM004')

        then:
            declaration.lines == null
    }

    def 'export declaration with no lines should have the correct output'() {
        when:
            def declaration = declaration('EX004')

        then:
            declaration.lines == null
    }

    @Unroll
    def 'declaration #declarationID should have declarationSource as #expectedDeclarationSource and declarationImportExportIndicator as #expectedImportExportIndicator '() {
        when:
            def declaration = declaration(declarationID)

        then:
            declaration.declarationSource == expectedDeclarationSource
            declaration.importExportIndicator == expectedImportExportIndicator

        where:
            declarationID | expectedDeclarationSource | expectedImportExportIndicator
            'IM004'       | 'CHIEF'                   | 'Import'
            'EX004'       | 'CHIEF'                   | 'Export'
    }
}
