package searchdataingest.setup;

import static java.util.Arrays.asList;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.apache.spark.sql.SparkSession;


public class E2eTestDataLoader {

    static String mssSourceFilePath = "/mss/ingestion-pipeline-output";

    public static void main(String[] args) throws Exception {
        new E2eTestDataLoader().ingestData();
    }

    private SparkSession sparkSession = SparkSession.builder()
                                            .appName("data-ingest")
                                            .enableHiveSupport().getOrCreate();

    private String DATABASE_NAME = "search";

    public void ingestData() throws IOException {
        sparkSession.sql("DROP DATABASE IF EXISTS " + DATABASE_NAME + " CASCADE");
        sparkSession.sql("CREATE DATABASE IF NOT EXISTS " + DATABASE_NAME);
        asList("imenselect","imendetail","imeiselect","inad","iica","iina","nxenselect","nxendetail","nxeiselect","nxeidetail","nxnad","nxica","nxina", "ctry").forEach(table -> {
            sparkSession.sql(getDdlFor(table));
            loadDataFor(table);
        });
    }

    private String getDdlFor(String tableName) {
        try {
            return IOUtils.toString(new File("/mss/ddl/" + tableName + ".sql").toURI());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void loadDataFor(String tableName) {
        String sqlFormat = "load data local inpath '%s/%s/part-00000' overwrite into table %s.%s";
        sparkSession.sql(String.format(sqlFormat, mssSourceFilePath, tableName, DATABASE_NAME, tableName));
    }
}
