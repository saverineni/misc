package searchdataingest

import spock.lang.Shared
import spock.lang.Specification

class DeclarationDeltaSpec extends Specification {
    @Shared List declarations
    @Shared Map jsonResponse

    def setupSpec() {
        ESClient client = new ESClient("customs-delta")
        declarations = client.documents()
        jsonResponse = client.countResponse()
    }

    def declaration(declarationId) {
        declarations.find { it.declarationId == declarationId }
    }

    def "only delta data with sequence numbers of 2 or 3 should be added to elasticsearch"() {
        when: 'document count is read'
        def count = jsonResponse.count

        then:
        count == 4
    }

    def 'declarations with sequence number of 1 should be absent'() {
        when:
        def declarationIds = declarations.collect { it.declarationId }.sort()

        then:
        declarationIds == ['EX003', 'EX004', 'IM003', 'IM004']
    }

    def 'IM003 should have sequence 2 data'() {
        when:
        def dec = declaration('IM003')

        then:
        dec.sequenceId == '2'
        dec.goodsLocation == 'GOODSLOC03'
        dec.transportModeCode == 'TRANSPORTMODE03'
        dec.lines[0].cpc == 'CPC03'
        dec.lines[0].commodityCode == 'COMMODITY03'
    }

    def 'EX003 should have sequence 2 data'() {
        when:
        def dec = declaration('EX003')

        then:
        dec.sequenceId == '2'
        dec.goodsLocation == 'GOODSLOC03'
        dec.transportModeCode == 'TRANSPORTMODE03'
        dec.lines[0].cpc == 'CPC03'
        dec.lines[0].commodityCode == 'COMMODITY03'
    }

    def 'IM004 that has data in sequence 2 and 3 should have sequence 3 data'() {
        when:
        def dec = declaration('IM004')

        then:
        dec.sequenceId == '3'
        dec.goodsLocation == 'GOODSLOC04'
        dec.transportModeCode == 'TRANSPORTMODE04'
        dec.consigneeTurn == 'CONSIGNEE04'
        dec.consignorTurn == 'CONSIGNOR04'
    }

    def 'EX004 that has data in sequence 2 and 3 should have sequence 3 data'() {
        when:
        def dec = declaration('EX004')

        then:
        dec.sequenceId == '3'
        dec.goodsLocation == 'GOODSLOC04'
        dec.transportModeCode == 'TRANSPORTMODE04'
        dec.consigneeTurn == 'CONSIGNEE04'
        dec.consignorTurn == 'CONSIGNOR04'
    }

}
