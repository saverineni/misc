#!/bin/bash

echo "starting spark submit elasticsearch data generation job"

/wait-for-elasticsearch-and-datasetup.sh && /spark/bin/spark-submit \
  --master local \
  --conf "spark.driver.extraJavaOptions=-Des.index.name=customs -Dspring.profiles.active=e2e" \
  --conf "spark.executor.extraJavaOptions=-Des.index.name=customs -Dspring.profiles.active=e2e" \
  /app.jar | tee /var/log/e2e/spark-submit.log && /spark/bin/spark-submit \
  --master local \
  --conf "spark.driver.extraJavaOptions=-Des.index.name=customs-delta -Dspring.profiles.active=e2e" \
  --conf "spark.executor.extraJavaOptions=-Des.index.name=customs-delta -Dspring.profiles.active=e2e" \
  /app.jar --sequence.ids="2,3" | tee /var/log/e2e/spark-submit.log