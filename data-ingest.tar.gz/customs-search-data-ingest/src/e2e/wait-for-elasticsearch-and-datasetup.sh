#! /bin/bash

MAX_RETRIES=24

function checkSetup {
  echo 'Waiting data setup to complete...'

  retry_count=1

  while [ $retry_count -lt $MAX_RETRIES ]
  do
    sleep 10
    SETUP_STATUS=$(</hive-data/setup-result)
    if [ "$SETUP_STATUS" == "0" ]; then
      echo 'Data setup running spark job'
      exit 0
    else
      retry_count=$((retry_count+1))
    fi
  done

  echo 'Data setup failed'
}

function waitForElasticSearch {
  echo 'Waiting for elasticsearch to start...'

  retry_count=1

  while [ $retry_count -lt $MAX_RETRIES ]
  do
    sleep 10
    ES_STATUS=$(curl --output /dev/null -w '%{http_code}' --silent http://elasticsearch:9200)
    if [ "$ES_STATUS" == "200" ]; then
      echo 'Elasticsearch started successfuly'
      checkSetup
    else
      retry_count=$((retry_count+1))
    fi
  done

  echo 'Timed-out waiting for elasticsearch to start!'
}

waitForElasticSearch

exit 1
