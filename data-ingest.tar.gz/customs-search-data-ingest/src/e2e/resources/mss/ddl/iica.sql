CREATE TABLE search.iica(
  iekey string,
  ieitno int,
  roe string,
  sequenceid string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
