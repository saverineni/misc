CREATE TABLE search.nxica(
  iekey string,
  ieitno int,
  roe string,
  sequenceid string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
