CREATE TABLE search.imenselect(
  iekey string,
  epuno string,
  impentno string,
  standard_dtofent string,
  roe string,
  dispcntry string,
  imptrturn string,
  cnsgrturn string,
  declntype string,
  standard_clrncdate string,
  sequenceid string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
