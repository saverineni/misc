CREATE TABLE search.imeiselect(
  iekey string,
  ieitno int,
  itemdispcntry string,
  standard_clrncdate string,
  cpc string,
  origcntry string,
  cmdtycode string,
  itemimptrturn string,
  itemcnsgrturn string,
  sequenceid string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
