CREATE TABLE search.inad(
  iekey string,
  hdrnadtype string,
  hdrnadname string,
  hdrnadpostcode string,
  sequenceid string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
