CREATE TABLE search.nxeidetail(
  iekey string,
  ieitno int,
  generationno int,
  itemdispcntry string,
  sequenceid string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
