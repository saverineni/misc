CREATE TABLE search.nxenselect(
  iekey string,
  generationno int,
  epuno string,
  impentno string,
  standard_dtofent string,
  gdslocn string,
  roe string,
  dispcntry string,
  destcntry string,
  imptrturn string,
  cnsgrturn string,
  declntype string,
  standard_clrncdate string,
  sequenceid string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
