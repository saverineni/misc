CREATE TABLE search.nxendetail(
  iekey string,
  generationno int,
  trptmodecode string,
  sequenceid string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
