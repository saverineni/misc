CREATE TABLE search.imendetail(
  iekey string,
  gdslocn string,
  trptmodecode string,
  sequenceid string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
