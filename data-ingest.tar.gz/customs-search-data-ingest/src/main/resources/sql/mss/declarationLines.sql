SELECT
    importItemSelect.IEKEY as declarationId,
    {{IMPORTITEMSELECT_SELECT}}
    importItemSelect.IEITNO as itemNumber,
    IF (importItemSelect.ITEMDISPCNTRY IS NOT NULL,
        named_struct(
            "code", importItemSelect.ITEMDISPCNTRY
        ),
        named_struct("code", '')
    ) as itemDispatchCountry,
    NULL as itemDestinationCountry,
    importItemSelect.STANDARD_CLRNCDATE as clearanceDate,
    importItemSelect.CPC as cpc,
    IF (importItemSelect.ORIGCNTRY IS NOT NULL,
        named_struct(
            "code", importItemSelect.ORIGCNTRY
        ),
        named_struct("code", '')
    ) as originCountry,
    importItemSelect.CMDTYCODE as commodityCode,
    importItemSelect.ITEMIMPTRTURN as itemConsigneeTurn,
    importItemSelect.ITEMCNSGRTURN as itemConsignorTurn,
    iica.ROE as itemRoute,
    iinaConsignee.ITEMNADNAME as itemConsigneeName,
    iinaConsignee.ITEMNADPOSTCODE as itemConsigneePostcode,
    iinaConsignor.ITEMNADNAME as itemConsignorName,
    iinaConsignor.ITEMNADPOSTCODE as itemConsignorPostcode
  FROM {{DATABASE_NAME}}.IMEISELECT importItemSelect
  JOIN {{DATABASE_NAME}}.IMENSELECT importSelect on importSelect.IEKEY = importItemSelect.IEKEY
      {{IMPORTSELECT_JOIN}}
  LEFT OUTER JOIN {{DATABASE_NAME}}.IINA iinaConsignor
      on importItemSelect.IEKEY = iinaConsignor.IEKEY
      and importItemSelect.IEITNO = iinaConsignor.IEITNO
      {{IINACONSIGNOR_JOIN}}
      and iinaConsignor.ITEMNADTYPE = '1'
  LEFT OUTER JOIN {{DATABASE_NAME}}.IINA iinaConsignee
      on importItemSelect.IEKEY = iinaConsignee.IEKEY
      and importItemSelect.IEITNO = iinaConsignee.IEITNO
      {{IINACONSIGNEE_JOIN}}
      and iinaConsignee.ITEMNADTYPE = '2'
  LEFT OUTER JOIN {{DATABASE_NAME}}.IICA iica
      on importItemSelect.IEKEY = iica.IEKEY
      and importItemSelect.IEITNO = iica.IEITNO
      {{IICA_JOIN}}
  {{IMPORTITEMSELECT_WHERE}}
UNION ALL
SELECT
  declarationId,
  sequenceId,
  itemNumber,
  itemDispatchCountry,
  itemDestinationCountry,
  clearanceDate,
  cpc,
  originCountry,
  commodityCode,
  itemConsigneeTurn,
  itemConsignorTurn,
  itemRoute,
  itemConsigneeName,
  itemConsigneePostcode,
  itemConsignorName,
  itemConsignorPostcode
FROM (
  SELECT
    exportItemSelect.IEKEY as declarationId,
    {{EXPORTITEMSELECT_SELECT}}
    exportItemSelect.IEITNO as itemNumber,
    IF (exportItemDetail.ITEMDISPCNTRY IS NOT NULL,
        named_struct(
            "code", exportItemDetail.ITEMDISPCNTRY
        ),
        named_struct("code", '')
    ) as itemDispatchCountry,
    IF (exportItemSelect.ITEMDESTCNTRY IS NOT NULL,
        named_struct(
            "code", exportItemSelect.ITEMDESTCNTRY
        ),
        named_struct("code", '')
    ) as itemDestinationCountry,
    exportSelect.STANDARD_CLRNCDATE as clearanceDate,
    exportItemSelect.CPC as cpc,
    IF (exportItemSelect.ORIGCNTRY IS NOT NULL,
            named_struct(
                "code", exportItemSelect.ORIGCNTRY
            ),
            named_struct("code", '')
    ) as originCountry,
    exportItemSelect.CMDTYCODE as commodityCode,
    exportItemSelect.ITEMIMPTRTURN as itemConsigneeTurn,
    exportItemSelect.ITEMCNSGRTURN as itemConsignorTurn,
    nxica.ROE as itemRoute,
    nxinaConsignee.ITEMNADNAME as itemConsigneeName,
    nxinaConsignee.ITEMNADPOSTCODE as itemConsigneePostcode,
    nxinaConsignor.ITEMNADNAME as itemConsignorName,
    nxinaConsignor.ITEMNADPOSTCODE as itemConsignorPostcode,
    ROW_NUMBER() OVER (partition by exportItemSelect.IEKEY, exportItemSelect.IEITNO{{EXPORTITEMSELECT_PARTITION}} order by exportItemSelect.STANDARD_DTOFENT) rownum
  FROM {{DATABASE_NAME}}.NXEISELECT exportItemSelect
  JOIN {{DATABASE_NAME}}.NXEIDETAIL exportItemDetail
      on exportItemDetail.IEKEY = exportItemSelect.IEKEY
      and exportItemDetail.IEITNO = exportItemSelect.IEITNO
      and exportItemDetail.GENERATIONNO = exportItemSelect.GENERATIONNO
      {{EXPORTITEMDETAIL_JOIN}}
  JOIN {{DATABASE_NAME}}.NXENSELECT exportSelect on exportSelect.IEKEY = exportItemSelect.IEKEY
      {{EXPORTSELECT_JOIN}}
  LEFT OUTER JOIN {{DATABASE_NAME}}.NXINA nxinaConsignor
      on exportItemSelect.IEKEY = nxinaConsignor.IEKEY
      and exportItemSelect.IEITNO = nxinaConsignor.IEITNO
      {{NXINACONSIGNOR_JOIN}}
      and nxinaConsignor.ITEMNADTYPE = '1'
  LEFT OUTER JOIN {{DATABASE_NAME}}.NXINA nxinaConsignee
      on exportItemSelect.IEKEY = nxinaConsignee.IEKEY
      and exportItemSelect.IEITNO = nxinaConsignee.IEITNO
      {{NXINACONSIGNEE_JOIN}}
      and nxinaConsignee.ITEMNADTYPE = '2'
  LEFT OUTER JOIN {{DATABASE_NAME}}.NXICA nxica
      on exportItemSelect.IEKEY = nxica.IEKEY
      and exportItemSelect.IEITNO = nxica.IEITNO
      {{NXICA_JOIN}}
  {{EXPORTITEMSELECT_WHERE}}
) innerQuery
WHERE innerQuery.rownum = 1