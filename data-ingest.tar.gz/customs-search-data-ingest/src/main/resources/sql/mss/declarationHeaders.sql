SELECT
    'CHIEF' as declarationSource,
    'Import' as importExportIndicator,
    {{IMPORTSELECT_SELECT}}
    importSelect.IEKEY as declarationId,
    importSelect.EPUNO as epuNumber,
    importSelect.IMPENTNO as entryNumber,
    importSelect.STANDARD_DTOFENT as entryDate,
    importSelect.ROE as route,
    IF (importSelect.DISPCNTRY IS NOT NULL,
        named_struct(
            "code", importSelect.DISPCNTRY
        ),
        named_struct("code", '')
    ) as dispatchCountry,
    NULL as destinationCountry,
    importSelect.IMPTRTURN as consigneeTurn,
    importSelect.CNSGRTURN as consignorTurn,
    importSelect.declntype as declarationType,
    importDetail.GDSLOCN as goodsLocation,
    importDetail.TRPTMODECODE as transportModeCode,
    inadConsignee.HDRNADNAME as consigneeName,
    inadConsignee.HDRNADPOSTCODE as consigneePostcode,
    inadConsignor.HDRNADNAME as consignorName,
    inadConsignor.HDRNADPOSTCODE as consignorPostcode
  FROM {{DATABASE_NAME}}.IMENSELECT importSelect
  JOIN {{DATABASE_NAME}}.IMENDETAIL importDetail on importDetail.IEKEY = importSelect.IEKEY
      {{IMPORTDETAIL_JOIN}}
  LEFT OUTER JOIN {{DATABASE_NAME}}.INAD inadConsignor on importSelect.IEKEY = inadConsignor.IEKEY
      {{INADCONSIGNOR_JOIN}}
      and inadConsignor.HDRNADTYPE = '1'
  LEFT OUTER JOIN {{DATABASE_NAME}}.INAD inadConsignee on importSelect.IEKEY = inadConsignee.IEKEY
      {{INADCONSIGNEE_JOIN}}
      and inadConsignee.HDRNADTYPE = '2'
  {{IMPORTSELECT_WHERE}}
UNION ALL
  SELECT
    declarationSource,
    importExportIndicator,
    sequenceId,
    declarationId,
    epuNumber,
    entryNumber,
    entryDate,
    route,
    dispatchCountry,
    destinationCountry,
    consigneeTurn,
    consignorTurn,
    declarationType,
    goodsLocation,
    transportModeCode,
    consigneeName,
    consigneePostcode,
    consignorName,
    consignorPostcode
  FROM (
    SELECT
      'CHIEF' as declarationSource,
      'Export' as importExportIndicator,
      {{EXPORTSELECT_SELECT}}
      exportSelect.IEKEY as declarationId,
      exportSelect.EPUNO as epuNumber,
      exportSelect.IMPENTNO as entryNumber,
      exportSelect.STANDARD_DTOFENT as entryDate,
      exportSelect.ROE as route,
      IF (exportSelect.DISPCNTRY IS NOT NULL,
        named_struct(
            "code", exportSelect.DISPCNTRY
        ),
        named_struct("code", '')
      ) as dispatchCountry,
      IF (exportSelect.DESTCNTRY IS NOT NULL,
        named_struct(
            "code", exportSelect.DESTCNTRY
        ),
        named_struct("code", '')
      ) as destinationCountry,
      exportSelect.IMPTRTURN as consigneeTurn,
      exportSelect.CNSGRTURN as consignorTurn,
      exportSelect.declntype as declarationType,
      exportSelect.GDSLOCN as goodsLocation,
      exportDetail.TRPTMODECODE as transportModeCode,
      nxnadConsignee.HDRNADNAME as consigneeName,
      nxnadConsignee.HDRNADPOSTCODE as consigneePostcode,
      nxnadConsignor.HDRNADNAME as consignorName,
      nxnadConsignor.HDRNADPOSTCODE as consignorPostcode,
      ROW_NUMBER() OVER (partition by exportSelect.IEKEY{{EXPORTSELECT_PARTITION}} order by exportSelect.STANDARD_DTOFENT) rownum
    FROM {{DATABASE_NAME}}.NXENSELECT exportSelect
    JOIN {{DATABASE_NAME}}.NXENDETAIL exportDetail on exportDetail.IEKEY = exportSelect.IEKEY
        and exportDetail.GENERATIONNO = exportSelect.GENERATIONNO
        {{EXPORTDETAIL_JOIN}}
    LEFT OUTER JOIN {{DATABASE_NAME}}.NXNAD nxnadConsignor on exportSelect.IEKEY = nxnadConsignor.IEKEY
        {{NXNADCONSIGNOR_JOIN}}
        and nxnadConsignor.HDRNADTYPE = '1'
    LEFT OUTER JOIN {{DATABASE_NAME}}.NXNAD nxnadConsignee on exportSelect.IEKEY = nxnadConsignee.IEKEY
        {{NXNADCONSIGNEE_JOIN}}
        and nxnadConsignee.HDRNADTYPE = '2'
    {{EXPORTSELECT_WHERE}}
  ) innerQuery
  WHERE innerQuery.rownum = 1