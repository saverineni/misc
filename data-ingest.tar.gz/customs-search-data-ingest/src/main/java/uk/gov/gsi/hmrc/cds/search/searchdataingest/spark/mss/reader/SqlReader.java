package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader;

import java.util.Objects;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.SparkSession;

public class SqlReader<T> {
    private final SparkSession sparkSession;
    private final Class<T> entityClass;

    public SqlReader(SparkSession sparkSession, Class<T> entityClass) {
        this.sparkSession = sparkSession;
        this.entityClass = entityClass;
    }

    public Dataset<T> buildDataset(String hiveSql) {
        Objects.requireNonNull(hiveSql, "Hive sql cannot be null");

        return sparkSession.sql(hiveSql).as(Encoders.bean(entityClass));
    }
}
