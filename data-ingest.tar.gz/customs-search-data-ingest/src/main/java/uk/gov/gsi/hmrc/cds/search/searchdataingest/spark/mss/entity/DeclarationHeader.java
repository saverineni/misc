package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.entity;

import lombok.Data;
import scala.collection.mutable.Seq;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.Country;

import java.io.Serializable;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.entity.BaseEntity.joinExpression;

@Data
public class DeclarationHeader implements Serializable, BaseEntity {
    private static final long serialVersionUID = 1L;

    public static final String PRIMARY_COLUMN = "declarationId";
    public static final String SECONDARY_COLUMN = "sequenceId";

    private String declarationSource;
    private String importExportIndicator;
    private String declarationId;
    private String sequenceId;
    private String epuNumber;
    private String entryNumber;
    private String entryDate;
    private String route;
    private Country dispatchCountry;
    private Country destinationCountry;
    private String consigneeTurn;
    private String consignorTurn;
    private String declarationType;
    private String goodsLocation;
    private String transportModeCode;
    private String consigneeName;
    private String consigneePostcode;
    private String consignorName;
    private String consignorPostcode;

    public static Seq<String> joinColumns = joinExpression(PRIMARY_COLUMN, SECONDARY_COLUMN);
}
