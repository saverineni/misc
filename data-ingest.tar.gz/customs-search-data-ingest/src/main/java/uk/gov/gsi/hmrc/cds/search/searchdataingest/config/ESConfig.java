package uk.gov.gsi.hmrc.cds.search.searchdataingest.config;

public interface ESConfig {
    String ERROR_HANDLERS_KEY = "es.write.rest.error.handlers";
    String ERROR_HANDLERS_VALUE = "log";
    String ERROR_LOGGER_NAME_KEY = "es.write.rest.error.handler.log.logger.name";
    String ERROR_LOGGER_NAME_VALUE = "bulkErrorsLogger";
    String MAPPING_ID_KEY = "es.mapping.id";
    String MAPPING_VERSION_KEY = "es.mapping.version";
    String MAPPING_VERSION_TYPE_KEY = "es.mapping.version.type";
}
