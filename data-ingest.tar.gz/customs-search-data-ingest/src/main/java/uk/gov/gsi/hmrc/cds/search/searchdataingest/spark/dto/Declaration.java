package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import lombok.Data;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.Country;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLine;

import java.io.Serializable;
import java.util.List;

import static org.apache.spark.sql.functions.column;

@Data
public class Declaration implements Serializable {

    private static final long serialVersionUID = 1L;

    public static String DECLARATION_ID_FIELD = "declarationId";
    public static String DECLARATION_VERSION_FIELD = "sequenceId";
    public static String VERSION_CONTROL_TYPE = "external_gte";

    public static Encoder<Declaration> declarationEncoder = Encoders.bean(Declaration.class);

    private String declarationSource;
    private String importExportIndicator;
    private String declarationId;
    private String sequenceId;
    private String epuNumber;
    private String entryNumber;
    private String entryDate;
    private String route;
    private Country dispatchCountry;
    private Country destinationCountry;
    private String consigneeTurn;
    private String consignorTurn;
    private String declarationType;
    private String goodsLocation;
    private String transportModeCode;
    private String consigneeName;
    private String consigneePostcode;
    private String consignorName;
    private String consignorPostcode;
    private List<DeclarationLine> lines = Lists.newArrayList();

    public static List<Column> selectColumns = ImmutableList.of(
            column("declarationSource"),
            column("importExportIndicator"),
            column("declarationId"),
            column("sequenceId"),
            column("epuNumber"),
            column("entryNumber"),
            column("entryDate"),
            column("route"),
            column("dispatchCountry"),
            column("destinationCountry"),
            column("consigneeTurn"),
            column("consignorTurn"),
            column("declarationType"),
            column("goodsLocation"),
            column("transportModeCode"),
            column("consigneeName"),
            column("consigneePostcode"),
            column("consignorName"),
            column("consignorPostcode"),
            column("lines")
    );

}
