package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line;

import java.io.Serializable;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.Country;

@Data
public class DeclarationLine implements Serializable {
    private static final long serialVersionUID = 1L;

    private String declarationId;
    private String sequenceId;
    private int itemNumber;
    private String clearanceDate;
    private String cpc;
    private Country originCountry;
    private Country itemDispatchCountry;
    private Country itemDestinationCountry;
    private String commodityCode;
    private String itemConsigneeTurn;
    private String itemConsignorTurn;
    private String itemRoute;
    private String itemConsigneeName;
    private String itemConsigneePostcode;
    private String itemConsignorName;
    private String itemConsignorPostcode;
}
