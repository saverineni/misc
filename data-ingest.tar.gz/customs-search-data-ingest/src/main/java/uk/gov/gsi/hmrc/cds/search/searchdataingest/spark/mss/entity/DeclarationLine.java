package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.entity;

import static org.apache.spark.sql.functions.column;

import java.io.Serializable;
import java.util.List;

import org.apache.spark.sql.Column;

import com.google.common.collect.ImmutableList;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.Country;

@Data
public class DeclarationLine implements Serializable, BaseEntity {

    private static final long serialVersionUID = 1L;

    private String declarationId;
    private String sequenceId;
    private int itemNumber;
    private Country itemDispatchCountry;
    private Country itemDestinationCountry;
    private String clearanceDate;
    private String cpc;
    private Country originCountry;
    private String commodityCode;
    private String itemConsigneeTurn;
    private String itemConsignorTurn;
    private String itemRoute;
    private String itemConsigneeName;
    private String itemConsigneePostcode;
    private String itemConsignorName;
    private String itemConsignorPostcode;

    public static List<Column> columns = ImmutableList.of(
            column("itemNumber"),
            column("itemDispatchCountry"),
            column("itemDestinationCountry"),
            column("clearanceDate"),
            column("cpc"),
            column("originCountry"),
            column("commodityCode"),
            column("itemConsigneeTurn"),
            column("itemConsignorTurn"),
            column("itemRoute"),
            column("itemConsigneeName"),
            column("itemConsigneePostcode"),
            column("itemConsignorName"),
            column("itemConsignorPostcode")
    );
}
