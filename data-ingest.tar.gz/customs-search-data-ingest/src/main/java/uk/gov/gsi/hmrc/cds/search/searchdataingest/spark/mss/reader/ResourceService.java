package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.Charsets;
import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;

@Component
@Slf4j
public class ResourceService {

    public String getResourceAsString(String resourcePath) {
        try {
            InputStream resourceStream = this.getClass().getClassLoader().getResourceAsStream(resourcePath);
            return IOUtils.toString(resourceStream, Charsets.UTF_8);
        } catch (IOException | IllegalArgumentException ex) {
            log.error(String.format("Unable to read resource from path %s", resourcePath), ex);
        }
        return null;
    }

}
