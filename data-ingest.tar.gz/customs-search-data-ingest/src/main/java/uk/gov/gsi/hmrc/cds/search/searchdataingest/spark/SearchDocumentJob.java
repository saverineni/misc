package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark;

import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.DeclarationDataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.Declaration;

@Component
public class SearchDocumentJob {

    private final DeclarationDataset declarationDataset;

    public SearchDocumentJob(DeclarationDataset declarationDataset) {
        this.declarationDataset = declarationDataset;
    }

    public Dataset<String> declarationDocument() {

        Dataset<Declaration> declarationDataset = this.declarationDataset.build();
        return declarationDataset.toJSON();

    }
}
