package uk.gov.gsi.hmrc.cds.search.searchdataingest.elasticsearch;

import com.google.common.collect.ImmutableMap;
import org.apache.spark.sql.Dataset;
import org.elasticsearch.spark.rdd.api.java.JavaEsSpark;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SearchDocumentJob;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.Declaration;

import java.util.Map;

import static java.lang.String.format;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.config.ESConfig.*;

@Component
public class ESIngester {
    private static final Map<String, String> ES_CONFIG = ImmutableMap.of(
            ERROR_HANDLERS_KEY, ERROR_HANDLERS_VALUE,
            ERROR_LOGGER_NAME_KEY, ERROR_LOGGER_NAME_VALUE,
            MAPPING_ID_KEY, Declaration.DECLARATION_ID_FIELD,
            MAPPING_VERSION_KEY, Declaration.DECLARATION_VERSION_FIELD,
            MAPPING_VERSION_TYPE_KEY, Declaration.VERSION_CONTROL_TYPE
    );
    private final SearchDocumentJob searchDocumentJob;
    private final String elasticsearchResource;

    @Autowired
    public ESIngester(SearchDocumentJob searchDocumentJob, 
    		@Value("${es.index.name}") String elasticsearchIndex,
    		@Value("${es.index.type:declaration}") String elasticsearchType) {
        this.searchDocumentJob = searchDocumentJob;
        this.elasticsearchResource = format("%s/%s", elasticsearchIndex, elasticsearchType);
    }

    public void ingest() {
        Dataset<String> declarationDocumentDataset = searchDocumentJob.declarationDocument();
        JavaEsSpark.saveJsonToEs(declarationDocumentDataset.toJavaRDD(), elasticsearchResource, ES_CONFIG);
    }
}
