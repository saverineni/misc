package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto;

import java.io.Serializable;
import java.util.List;

import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import com.google.common.collect.Lists;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLine;

@Data
public class DeclarationLineDeclarationGroup implements Serializable {
    private static final long serialVersionUID = 1L;

    public static Encoder<DeclarationLineDeclarationGroup> declarationLineDeclarationGroupEncoder = Encoders.bean(DeclarationLineDeclarationGroup.class);

    private String declarationId;
    private String sequenceId;
    private List<DeclarationLine> lines = Lists.newArrayList();

    public static final String ALIAS = "lines";
}
