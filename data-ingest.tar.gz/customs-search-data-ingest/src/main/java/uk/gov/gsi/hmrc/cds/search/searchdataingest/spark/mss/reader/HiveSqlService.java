package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.lang.String.format;

@Component
@Slf4j
public class HiveSqlService {

    private static final String DATABASE_NAME_PLACEHOLDER = "{{DATABASE_NAME}}";
    private static final String SELECT_PLACEHOLDER = "{{%s_SELECT}}";
    private static final String WHERE_PLACEHOLDER = "{{%s_WHERE}}";
    private static final String JOIN_PLACEHOLDER = "{{%s_JOIN}}";
    private static final String PARTITION_PLACEHOLDER = "{{%s_PARTITION}}";

    private static final String[] SELECT_TABLES = {
            "importSelect",
            "exportSelect",
            "importItemSelect",
            "exportItemSelect"
    };

    private static final String[] IMPORT_JOIN_CLAUSE_TABLES = {
            "importDetail",
            "inadConsignor",
            "inadConsignee"
    };

    private static final String[] EXPORT_JOIN_CLAUSE_TABLES = {
            "exportDetail",
            "nxnadConsignor",
            "nxnadConsignee"
    };

    private static final String[] IMPORT_ITEM_JOIN_CLAUSE_TABLES = {
            "importSelect",
            "iinaConsignor",
            "iinaConsignee",
            "iica",
    };

    private static final String[] EXPORT_ITEM_JOIN_CLAUSE_TABLES = {
            "exportItemDetail",
            "exportSelect",
            "nxinaConsignor",
            "nxinaConsignee",
            "nxica"
    };

    private static final String[] PARTITION_OVER_TABLES = {
            "exportSelect",
            "exportItemSelect"
    };

    @Value("${hive.mss.database.name}")
    private String databaseName;

    public String replaceSqlPlaceholders(String sqlTemplate) {
        String hiveSqlTemplate = sqlTemplate.replace(DATABASE_NAME_PLACEHOLDER, databaseName);

        hiveSqlTemplate = Stream.of(SELECT_TABLES).reduce(hiveSqlTemplate, (template, tableName) ->
                template
                        .replace(format(SELECT_PLACEHOLDER, tableName.toUpperCase()), "'1' as sequenceId,")
                        .replace(format(WHERE_PLACEHOLDER, tableName.toUpperCase()), "")
        );

        hiveSqlTemplate = Stream.of(PARTITION_OVER_TABLES).reduce(hiveSqlTemplate, (template, tableName) ->
                template.replace(format(PARTITION_PLACEHOLDER, tableName.toUpperCase()), "")
        );

        String[] joinTables = ArrayUtils.addAll(
                ArrayUtils.addAll(IMPORT_JOIN_CLAUSE_TABLES, EXPORT_JOIN_CLAUSE_TABLES),
                ArrayUtils.addAll(IMPORT_ITEM_JOIN_CLAUSE_TABLES, EXPORT_ITEM_JOIN_CLAUSE_TABLES)
        );
        hiveSqlTemplate = Stream.of(joinTables).reduce(hiveSqlTemplate, (template, tableName) ->
                template.replace(format(JOIN_PLACEHOLDER, tableName.toUpperCase()), ""));

        log.debug("Hive Sql {}", hiveSqlTemplate);
        return hiveSqlTemplate;
    }

    public String replaceSqlPlaceholders(String sqlTemplate, String[] sequenceIds) {
        String hiveSqlTemplate = sqlTemplate.replace(DATABASE_NAME_PLACEHOLDER, databaseName);

        hiveSqlTemplate = Stream.of(SELECT_TABLES).reduce(hiveSqlTemplate, (template, tableName) ->
                sqlTemplateReplacement(sequenceIds, template, "WHERE", tableName, "WHERE ")
                        .replace(format(SELECT_PLACEHOLDER, tableName.toUpperCase()), format("%s.SEQUENCEID as sequenceId,", tableName))
        );

        hiveSqlTemplate = Stream.of(PARTITION_OVER_TABLES).reduce(hiveSqlTemplate, (template, tableName) ->
                template.replace(format(PARTITION_PLACEHOLDER, tableName.toUpperCase()), format(", %s.SEQUENCEID", tableName))
        );

        hiveSqlTemplate = Stream.of(IMPORT_JOIN_CLAUSE_TABLES).reduce(hiveSqlTemplate, (template, tableName) ->
                sqlTemplateReplacement(new String[]{"importSelect.SEQUENCEID"}, template, "JOIN", tableName, "and "));
        hiveSqlTemplate = Stream.of(EXPORT_JOIN_CLAUSE_TABLES).reduce(hiveSqlTemplate, (template, tableName) ->
                sqlTemplateReplacement(new String[]{"exportSelect.SEQUENCEID"}, template, "JOIN", tableName, "and "));
        hiveSqlTemplate = Stream.of(IMPORT_ITEM_JOIN_CLAUSE_TABLES).reduce(hiveSqlTemplate, (template, tableName) ->
                sqlTemplateReplacement(new String[]{"importItemSelect.SEQUENCEID"}, template, "JOIN", tableName, "and "));
        hiveSqlTemplate = Stream.of(EXPORT_ITEM_JOIN_CLAUSE_TABLES).reduce(hiveSqlTemplate, (template, tableName) ->
                sqlTemplateReplacement(new String[]{"exportItemSelect.SEQUENCEID"}, template, "JOIN", tableName, "and "));

        log.debug("Hive Sql {}", hiveSqlTemplate);
        return hiveSqlTemplate;
    }

    private String sqlTemplateReplacement(String[] sequenceIds, String template, String templateSuffix, String tableName, String replacementPrefix) {
        String sequenceSql = Stream.of(sequenceIds)
                .map(sequenceId -> format("%s.SEQUENCEID = %s", tableName, sequenceId))
                .collect(Collectors.joining(" or ", replacementPrefix, ""));
        return template.replace(format("{{%s_%s}}", tableName.toUpperCase(), templateSuffix), sequenceSql);
    }
}
