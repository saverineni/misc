package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset;

import com.google.common.collect.Iterables;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.DeclarationLineDeclarationGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.entity.DeclarationHeader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.entity.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader.DeclarationLineReader;

import static org.apache.spark.sql.functions.collect_list;
import static org.apache.spark.sql.functions.sort_array;
import static org.apache.spark.sql.functions.struct;

@Component
public class DeclarationLineGroupDataset {

    @Autowired
    private DeclarationLineReader declarationLineReader;
    private static Column[] lineColumns = Iterables.toArray(DeclarationLine.columns, Column.class);

    public Dataset<DeclarationLineDeclarationGroup> build() {
        Dataset<DeclarationLine> declarationLineDataset = declarationLineReader.declarationLineDataset();
        return declarationLineDataset
                .groupBy(declarationLineDataset.col(DeclarationHeader.PRIMARY_COLUMN), declarationLineDataset.col(DeclarationHeader.SECONDARY_COLUMN))
                .agg(
                        sort_array(
                                collect_list(
                                        struct(lineColumns)
                                )
                        )
                        .alias(DeclarationLineDeclarationGroup.ALIAS)
                )
                .as(DeclarationLineDeclarationGroup.declarationLineDeclarationGroupEncoder);
    }
}
