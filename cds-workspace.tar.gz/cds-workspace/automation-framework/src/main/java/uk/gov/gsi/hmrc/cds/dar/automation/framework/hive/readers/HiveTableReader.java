package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers;

import org.codejargon.fluentjdbc.api.FluentJdbc;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.HiveDBManager;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

import java.util.List;

/**
 * Created by smalavalli on 19/01/17.
 */
public class HiveTableReader {

    private static Logger logger = LoggerFactory.getLogger(HiveTableReader.class);

    public static <T extends HiveEntity> List<T> readTable(FluentJdbc hive, String selectAllQuery, Class<T> entityClass) {

        logger.info("Reading all data from table '{}'", entityClass.getCanonicalName());
        return HiveDBManager
                .connect(hive)
                .listResultFor(
                        selectAllQuery,
                        HiveMapper.of(entityClass)
                );
    }
}
