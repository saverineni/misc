package uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion.mss;

import org.codejargon.fluentjdbc.api.FluentJdbc;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.RemoteMachineConnector;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.HiveDBManager;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion.DataIngester;

import java.io.File;
import java.util.List;

import static java.util.stream.Collectors.toList;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.PropertyConfiguration.config;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.HiveDBManager.DEFAULT_TEST_DB;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion.mss.MSSDataIngestHelper.*;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion.mss.MSSDataIngestHelper.buildInsertQueriesFor;

/**
 * Created by smalavalli on 13/12/16.
 */
public class MSSTablesDataIngester {

    private static Logger logger = LoggerFactory.getLogger(MSSTablesDataIngester.class);

    // Headers
    private static final String IMPORT_HEADER_DATA_PATH_TEMPLATE = IMPORT_HEADER_DATA_FILES_PATH + "%s.csv";
    private static final String EXPORT_HEADER_DATA_PATH_TEMPLATE = EXPORT_HEADER_DATA_FILES_PATH + "%s.csv";

    // Lines
    private static final String IMPORT_LINE_DATA_PATH_TEMPLATE = IMPORT_LINE_DATA_FILES_PATH + "%s.csv";
    private static final String EXPORT_LINE_DATA_PATH_TEMPLATE = EXPORT_LINE_DATA_FILES_PATH + "%s.csv";

    public static Ingest connectToDB(FluentJdbc hive) {
        return new Ingest(hive);
    }

    public static class Ingest implements DataIngester{
        FluentJdbc hive;

        public Ingest(FluentJdbc hive) {
            this.hive = hive;
        }

        public void verboseIngestData() {
            ingestData();
        }

        public void quickIngestData() {
            List<File> filesToTransfer = getAllDataFilesToTransfer();
            String baseFilePathTemplate = config().getString("data.file.ftp.path.template");
            String baseFilePath = String.format(baseFilePathTemplate, DEFAULT_TEST_DB);

            logger.info("FTP path - {}", baseFilePath);

            RemoteMachineConnector
                    .connectToDockerClouderaServer()
                    .removeAndMakeDirectory(baseFilePath);
            RemoteMachineConnector
                    .connectToDockerClouderaServer()
                    .remoteFileTransfer(filesToTransfer, baseFilePath);

            List<String> tableNames = MSSDataIngestHelper.fetchIngestTableList().collect(toList());
            loadDataIntoTablesUsingHive(tableNames);
            logger.info("Data Ingestion complete");
        }

        private void ingestData() {
            ingestHeaderData();
            ingestLineData();
        }

        private void ingestHeaderData() {
            ingestImportHeader();
            ingestExportHeader();
        }

        private void ingestLineData() {
            ingestImportLine();
            ingestExportLine();
        }

        private void ingestImportHeader() {
            logger.info("Ingesting IMPORT HEADER tables...");
            ingestData(IMPORT_HEADER_TABLES_FILE_PATH, IMPORT_HEADER_DATA_PATH_TEMPLATE);
        }

        private void ingestExportHeader() {
            logger.info("Ingesting EXPORT HEADER tables...");
            ingestData(EXPORT_HEADER_TABLES_FILE_PATH, EXPORT_HEADER_DATA_PATH_TEMPLATE);
        }

        private void ingestImportLine() {
            logger.info("Ingesting IMPORT LINE tables...");
            ingestData(IMPORT_LINE_TABLES_FILE_PATH, IMPORT_LINE_DATA_PATH_TEMPLATE);
        }

        private void ingestExportLine() {
            logger.info("Ingesting EXPORT LINE tables...");
            ingestData(EXPORT_LINE_TABLES_FILE_PATH, EXPORT_LINE_DATA_PATH_TEMPLATE);
        }

        private void ingestData(String tablesFilePath, String csvDataFilePathTemplate) {
            ingestData(tablesFilePath, csvDataFilePathTemplate, DEFAULT_TEST_DB);
        }

        private void ingestData(String tablesFilePath, String csvDataFilePathTemplate, String dbName) {
            List<String> importTables = fetchIngestTableList(tablesFilePath);
            List<String> importDataInsertQueries = buildInsertQueriesFor(importTables, csvDataFilePathTemplate, dbName);
            logger.info("Data ingestion for tables {} ", importTables);
            HiveDBManager
                    .connect(hive)
                    .executeQueries(importDataInsertQueries);
        }

    }
}
