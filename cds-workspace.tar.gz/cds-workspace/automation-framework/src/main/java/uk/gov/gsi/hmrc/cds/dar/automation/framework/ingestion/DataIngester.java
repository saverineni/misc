package uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion;

import com.google.common.base.Joiner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs.HDFSFileSystemUtil;

import java.util.List;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.*;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.RemoteMachineConnector.connectToDockerClouderaServer;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs.HDFSFileSystemUtil.*;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.PropertyConfiguration.config;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.HiveDBManager.DEFAULT_TEST_DB;

/**
 * Created by smalavalli on 17/01/17.
 */
public interface DataIngester {
    Logger logger = LoggerFactory.getLogger(DataIngester.class);
//    RemoteMachineConnector.RemoteMachine connectToFASTP2 = RemoteMachineConnector.connectToFASTP2();
    String baseFilePathTemplate = config().getString("data.file.ftp.path.template");
    String baseFilePath = String.format(baseFilePathTemplate, DEFAULT_TEST_DB);

    void verboseIngestData();

    default void ingestData(List<String> tablesToIngest) {
        boolean ingestionFilesExistsInCache = JobExecutor.ingestionFilesExistsInCache(tablesToIngest);
        if (ingestionFilesExistsInCache) {

            List<String> importTableScripts = tablesToIngest.stream().map(tableName -> {
                String sourceDataPath = String.format("%s/%s", AUTOMATION_TEST_CACHE_PATH, tableName);
                return String.format("IMPORT TABLE %s.%s FROM '%s'", DEFAULT_TEST_DB, tableName, sourceDataPath);
            }).collect(Collectors.toList());


            String importTableScript = String.format("sudo su - hdfs -c \"hive -e \\\"%s\\\"\"", Joiner.on(";").join(importTableScripts));
            connectToDockerClouderaServer().executeScriptAsSudo(importTableScript);

//            loadDataIntoTablesUsingHDFSCache(tablesToIngest);
//            createTablesUsingHive(tablesToIngest);
//            loadDataIntoTablesUsingHive(tablesToIngest);
        } else {
            logger.info("Unable to perform quick data ingestion. Verbose ingestion...");
            verboseIngestData();
        }
    }

    default void loadDataIntoTablesUsingHDFSCache(List<String> tableNames) {
        tableNames.forEach(
                tableName -> HDFSFileSystemUtil
                        .copyDataAsUser(HADOOP_USER_CDSDATA)
                        .fromHDFSPath(String.format("%s/%s", AUTOMATION_TEST_CACHE_PATH, tableName))
                        .toHDFSPath(String.format("%s/%s", TEST_DB_PATH, tableName))
                        .copy());

    }

    default void loadDataIntoTablesUsingHive(List<String> tableNames) {
        String tableDataFilePathTemplate = "%s/%s.csv";
        String loadDataCommandTemplate = "load data local inpath \\\"%s\\\" overwrite into table %s.%s";
        List<String> loadDataCommandList = tableNames.stream().map(tableName -> {
            String dataFilePath = String.format(tableDataFilePathTemplate, baseFilePath, tableName);
            return String.format(loadDataCommandTemplate, dataFilePath, DEFAULT_TEST_DB, tableName);
        }).collect(toList());

        String loadDataInpathCommand = Joiner.on(";").join(loadDataCommandList);

        String scriptToLoadDataIntoTables = String.format("sudo su - hdfs -c \"hive -e '%s;'\"", loadDataInpathCommand);
        connectToDockerClouderaServer().executeScriptAsSudo(scriptToLoadDataIntoTables);
    }

    default void createTablesUsingHive(List<String> tableNames) {
        String tableSQLFilePathTemplate = "%s/%s/%s.sql";
        String hiveCommandFromFileTemplate = "hive -f %s";

        List<String> createTableCommandList = tableNames.stream().map(tableName -> {
            String sqlFilePath = String.format(tableSQLFilePathTemplate, baseFilePath, tableName, tableName);
            return String.format(hiveCommandFromFileTemplate, sqlFilePath);
        }).collect(toList());

        String sudoScriptToCreateTables = String.format("sudo su - hdfs -c \"%s;\"", Joiner.on(";").join(createTableCommandList));
        logger.info("Creating tables {} in hive", tableNames.toString());
//        connectToFASTP2.executeScriptAsSudo(sudoScriptToCreateTables);
    }

}
