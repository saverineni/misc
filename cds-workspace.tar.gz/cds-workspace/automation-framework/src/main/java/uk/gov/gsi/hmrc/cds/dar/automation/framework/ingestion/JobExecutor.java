package uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion;

import com.google.common.collect.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs.HDFSFileSystemUtil;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.HiveDBManager;

import java.util.List;

import static uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.RemoteMachineConnector.connectToDockerDataNodeAgent1;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.RemoteMachineConnector.connectToDockerClouderaServer;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs.HDFSFileSystemUtil.AUTOMATION_TEST_CACHE_PATH;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs.HDFSFileSystemUtil.HADOOP_USER_CDSDATA;

/**
 * Created by smalavalli on 11/01/17.
 */
public class JobExecutor {

    private static Logger logger = LoggerFactory.getLogger(JobExecutor.class);

    public static boolean ingestionFilesExistsInCache(List<String> tableNames) {
        List<Boolean> cacheFilesExistList = Lists.newArrayList();
        tableNames.forEach(tableName -> {
            String hdfsPath = String.format("%s/%s", HDFSFileSystemUtil.AUTOMATION_TEST_CACHE_PATH, tableName);
            cacheFilesExistList.add(HDFSFileSystemUtil.directoryContainFiles(hdfsPath));
        });
        return !cacheFilesExistList.contains(false);
    }

    public static void invalidateAllMetadataCache() {
        HDFSFileSystemUtil
                .removeDirectoryAsUser(HADOOP_USER_CDSDATA)
                .withPath(AUTOMATION_TEST_CACHE_PATH)
                .remove();
        logger.info("Invalidate cache complete.");
    }

    public static void invalidateTestDB() {
        String scriptToCreateTestDB = String.format("sudo su - cdsdata -c \"hive -e 'use default; drop database IF EXISTS %s cascade;create database IF NOT EXISTS %s'\"", HiveDBManager.DEFAULT_TEST_DB, HiveDBManager.DEFAULT_TEST_DB);
        connectToDockerClouderaServer().executeScriptAsSudo(scriptToCreateTestDB);
        logger.info("Test DB refreshed");
        invalidateImpalaMetadata(); // impala will not recognise the database, if metadata is not invalidated.
    }

    public static void invalidateImpalaMetadata() {
        String scriptToinvalidateMetadata = "sudo su - cdsdata -c \"impala-shell -q 'invalidate metadata'\"";
        connectToDockerDataNodeAgent1().executeScriptAsSudo(scriptToinvalidateMetadata);
        logger.info("Impala invalidate metadata");
    }
}
