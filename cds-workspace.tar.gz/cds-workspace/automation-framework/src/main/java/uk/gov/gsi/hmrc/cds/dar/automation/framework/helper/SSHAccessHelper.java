package uk.gov.gsi.hmrc.cds.dar.automation.framework.helper;

import com.jcraft.jsch.*;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.PropertyConfiguration.config;


/**
 * Created by smalavalli on 30/11/16.
 */
public class SSHAccessHelper {

    private static Logger logger = LoggerFactory.getLogger(SSHAccessHelper.class);

    public String accessRemoteMachineUsingSSHKeyWithPassPhrase(String host, String userName, List<String> commandList) {
        Session session = createSSHSession(host, userName);
        return accessRemoteMachine(session, commandList);
    }

    public String sudoAccessRemoteMachineUsingSSHKeyWithPassPhrase(String host, String userName, String command) {
        Session session = createSSHSession(host, userName);
        return executeSudoCommand(session, command);
    }

    public String accessRemoteMachineUsingSSHKeyWithPassPhrase(String host, String userName, String command) {
        Session session = createSSHSession(host, userName);
        return executeScript(session, command);
    }

    public String accessRemoteMachineUsingSSHKeyWithPassPhrase(String host, String userName, int sshPort, List<String> commandList) {
        Session session = createSSHSession(host, userName, sshPort);
        return accessRemoteMachine(session, commandList);
    }

    public String sudoAccessRemoteMachineUsingSSHKeyWithPassPhrase(String host, String userName, int sshPort, String command) {
        Session session = createSSHSession(host, userName, sshPort);
        return executeSudoCommand(session, command);
    }

    public String accessRemoteMachineUsingSSHKeyWithPassPhrase(String host, String userName, int sshPort, String command) {
        Session session = createSSHSession(host, userName, sshPort);
        return executeScript(session, command);
    }

    public String accessRemoteMachineUsingUsernamePassword(String host, String userName, String password, List<String> commandList) {
        Session session = null;
        logger.info("Accessing remote machine....");
        try {
            session = JavaSecureChannelSession
                    .newInstance(host, userName)
                    .withUserNamePassword(password)
                    .connect();
        } catch (JSchException e) {
            logger.error("Error connecting to remote machine {} as {}" + host, userName, e);
        }
        return accessRemoteMachine(session, commandList);
    }

    private Session createSSHSession(String host, String userName) {
        return createSSHSession(host, userName, 22);
    }

    private Session createSSHSession(String host, String userName, int sshPort) {
        Session session = null;
        String privateKey = config().getString("ssh.private.key");
        String passPhrase = config().getString("ssh.pass.phrase");

        try {
            session = JavaSecureChannelSession
                    .newInstance(host, userName, sshPort)
                    .withSSHKeyAndPassPhrase(privateKey, passPhrase)
                    .connect();
        } catch (JSchException e) {
            logger.error("Error connecting to remote machine {} on port {} as {}", host, sshPort, userName, e);
        }
        return session;
    }

    private String accessRemoteMachine(Session session, List<String> commandList) {
        String consoleOutput = null;
        try {
            consoleOutput = executeCommands(session, commandList);
        } catch (JSchException e) {
            logger.error("Error executing commands " + e);
        }
        logger.info(consoleOutput);
        return consoleOutput;

    }

    private String executeCommands(Session session, List<String> commands) throws JSchException {
        ChannelShell channelShell = null;
        String channelOutput = null;
        try {
            channelShell = getChannel(session);
            sleepFor(2000);

            logger.info("Sending commands...");
            sendCommands(channelShell, commands);

            channelOutput = readChannelOutput(channelShell);
            logger.info("Finished sending commands.");
        } finally {
            if (channelShell != null && session != null) {
                channelShell.disconnect();
                session.disconnect();
            }
        }
        return channelOutput;
    }

    private String executeSudoCommand(Session session, String script) {
        ChannelExec channelExec = null;
        String channelOutput = null;
        try {
            if (session.isConnected()) {
                channelExec = (ChannelExec) session.openChannel("exec");
                channelExec.setErrStream(System.err);
                channelExec.setPty(true);
                channelExec.setCommand("sudo -S -p '' " + script);
                InputStream in = channelExec.getInputStream();
                OutputStream outputStream = channelExec.getOutputStream();
                channelExec.connect();
                outputStream.write((config().getString("fastp.password") + "\n").getBytes());
                outputStream.flush();

                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                StringBuilder stringBuilder = new StringBuilder();
                reader.lines().forEach(stringBuilder::append);
                channelOutput = stringBuilder.toString();
            }

        } catch (Exception e) {
            logger.error("Error executing sudo command {}", script + e);
        } finally {
            if (channelExec != null) {
                channelExec.disconnect();
            }
            session.disconnect();
        }
        return channelOutput;
    }

    private String executeScript(Session session, String script) {
        ChannelExec channelExec = null;
        String channelOutput = null;
        try {
            if (session.isConnected()) {
                channelExec = (ChannelExec) session.openChannel("exec");
                channelExec.setErrStream(System.err);
                channelExec.setPty(true);
                channelExec.setCommand(script);
                InputStream in = channelExec.getInputStream();
                OutputStream outputStream = channelExec.getOutputStream();
                channelExec.connect();

                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                StringBuilder stringBuilder = new StringBuilder();
                reader.lines().forEach(stringBuilder::append);
                channelOutput = stringBuilder.toString();
            }

        } catch (Exception e) {
            logger.error("Error executing script {}", script + e);
        } finally {
            if (channelExec != null) {
                channelExec.disconnect();
            }
            session.disconnect();
        }
        return channelOutput;
    }

    private void sleepFor(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            logger.error("Thread sleep interrupted exception " + e);
        }
    }

    private void sendCommands(Channel channel, List<String> commands) {
        try {
            PrintStream out = new PrintStream(channel.getOutputStream());
            commands.forEach(out::println);
            out.println("exit");
            out.flush();
        } catch (IOException e) {
            logger.error("Error executing command " + e);
        }
    }

    private ChannelShell getChannel(Session session) throws JSchException {
        ChannelShell channelShell = null;
        if (session.isConnected()) {
            channelShell = (ChannelShell) session.openChannel("shell");
            channelShell.connect();
        }
        return channelShell;
    }

    private String readChannelOutput(Channel channel) {
        String consoleOutString = null;
        try {
            InputStream in = channel.getInputStream();
            consoleOutString = IOUtils.toString(in, "UTF-8");
        } catch (Exception e) {
            logger.error("Error while reading channel output: " + e);
        }
        return consoleOutString;
    }
}
