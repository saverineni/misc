package uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs;

import com.google.common.base.Charsets;
import com.google.common.hash.HashCode;
import com.google.common.hash.HashFunction;
import com.google.common.hash.Hashing;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

import static java.util.stream.Collectors.*;

/**
 * Created by smalavalli on 02/11/16.
 */
public class HDFSExplorer {

    public static List<String> listOfFiles(FileStatus[] fileStatuses) {
        return Arrays.stream(FileUtil.stat2Paths(fileStatuses))
                .map(Path::getName)
                .collect(toList());

    }

    public static boolean isDirectory(FileStatus fileStatus) {
        return fileStatus.isDirectory();
    }

    public static boolean isFile(FileStatus fileStatus) {
        return fileStatus.isFile();
    }

    public static String fileContent(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        IOUtils.copyBytes(inputStream, byteArrayOutputStream, 4096, false);
        return byteArrayOutputStream.toString();
    }


    public static String getMd5Hash(String value) {
        HashFunction hashFunction = Hashing.md5();
        HashCode hashCode = hashFunction.newHasher().putString(value, Charsets.UTF_8).hash();
        return hashCode.toString();
    }
}
