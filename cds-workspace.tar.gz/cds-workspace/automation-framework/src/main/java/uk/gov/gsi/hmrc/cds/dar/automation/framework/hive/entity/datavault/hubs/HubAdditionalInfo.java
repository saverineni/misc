package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.hubs;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class HubAdditionalInfo implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select hub_additional_info_key, entry_reference, item_number, additional_information_sequence_number, hub_load_datetime, hub_record_source from hub_additional_info";

    private String hub_additional_info_key;
    private String entry_reference;
    private String item_number;
    private String additional_information_sequence_number;
    private String hub_load_datetime;
    private String hub_record_source;

}
