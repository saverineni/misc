package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.hubs;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class HubDocument implements HiveEntity{

    public static final String SELECT_ALL_QUERY = "select hub_document_key, entry_reference, item_number, document_sequence_number, hub_load_datetime, hub_record_source from hub_document";

    private String hub_document_key;
    private String entry_reference;
    private String item_number;
    private String document_sequence_number;
    private String hub_load_datetime;
    private String hub_record_source;
}
