package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class Nxnad implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select iekey, generationno, hdrnadtype, hdrnadname, hdrnadstreet, hdrnadcity, hdrnadpostcode, hdrnadcntry from nxnad";

    private String iekey;
    private String generationno;
    private String hdrnadtype;
    private String hdrnadname;
    private String hdrnadstreet;
    private String hdrnadcity;
    private String hdrnadpostcode;
    private String hdrnadcntry;
}
