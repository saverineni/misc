package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.postdatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class DimAdditionalInfo implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select declaration_line_reference, entry_reference, item_number, additional_information_sequence_number, generation_number, additional_information_statement, additional_information_statement_type, item_additional_information_statement from dim_additional_info";

    private String declaration_line_reference;
    private String entry_reference;
    private String item_number;
    private String additional_information_sequence_number;
    private String generation_number;
    private String additional_information_statement;
    private String additional_information_statement_type;
    private String item_additional_information_statement;
}
