package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class Iica implements HiveEntity{
    public static final String SELECT_ALL_QUERY = "select iekey, ieitno, itecccode, mic, profid from iica";

    private String iekey;
    private String ieitno;
    private String itecccode;
    private String mic;
    private String profid;
}
