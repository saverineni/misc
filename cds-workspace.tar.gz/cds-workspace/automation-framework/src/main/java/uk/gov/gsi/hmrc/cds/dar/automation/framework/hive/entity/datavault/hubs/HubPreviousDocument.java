package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.hubs;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class HubPreviousDocument implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select hub_previous_document_key, entry_reference, item_number, previous_document_sequence_number, hub_load_datetime, hub_record_source from hub_previous_document";

    private String hub_previous_document_key;
    private String entry_reference;
    private String item_number;
    private String previous_document_sequence_number;
    private String hub_load_datetime;
    private String hub_record_source;
}
