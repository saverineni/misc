package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by developer on 08/08/17.
 */
@Data
public class LandingLineDocumentHashed implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select source, ingestion_date, item_number, document_sequence_number, generation_number, " +
                                                    "item_document_code, item_document_status, item_document_reference, entry_reference, " +
                                                    "hub_document, sat_document, link_declaration_line_document, " +
                                                    "link_declaration_line_document_hub_declaration_line " +
                                                    "from landing_line_document_hashed";

    private String source;
    private String ingestion_date;
    private String item_number;
    private String document_sequence_number;
    private String generation_number;
    private String item_document_code;
    private String item_document_status;
    private String item_document_reference;
    private String entry_reference;
    private String hub_document;
    private String sat_document;
    private String link_declaration_line_document;
    private String link_declaration_line_document_hub_declaration_line;

}
