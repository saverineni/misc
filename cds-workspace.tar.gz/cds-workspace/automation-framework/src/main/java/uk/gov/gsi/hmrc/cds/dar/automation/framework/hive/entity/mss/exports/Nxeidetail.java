package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class Nxeidetail implements HiveEntity {
    public static final String SELECT_ALL_QUERY = "select iekey, generationno, ieitno, itemprc, itemstatval, itemcstmsval, gdsdesc, ecsu1, itemprcac from nxeidetail";

    private String iekey;
    private String generationno;
    private String ieitno;
    private String itemprc;
    private String itemstatval;
    private String itemcstmsval;
    private String gdsdesc;
    private String ecsu1;
    private String itemprcac;
}
