package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by nayub on 02/03/17.
 */
@Data
public class DimEpu implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select epu_id, epu_number, epu_name, epu_description, street, city, postcode, latitude, longitude, dtifa from dim_epu";

    private String epu_id;
    private String epu_number;
    private String epu_name;
    private String epu_description;
    private String street;
    private String city;
    private String postcode;
    private String latitude;
    private String longitude;
    private String dtifa;

}