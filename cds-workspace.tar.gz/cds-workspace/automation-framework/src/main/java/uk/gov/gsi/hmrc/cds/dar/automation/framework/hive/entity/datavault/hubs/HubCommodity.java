package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.hubs;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by smalavalli on 26/01/17.
 */
@Data
public class HubCommodity implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select hub_commodity_key, commodity_code, hub_load_datetime, hub_record_source from hub_commodity";
    private String hub_commodity_key;
    private String commodity_code;
    private String hub_load_datetime;
    private String hub_record_source;
}
