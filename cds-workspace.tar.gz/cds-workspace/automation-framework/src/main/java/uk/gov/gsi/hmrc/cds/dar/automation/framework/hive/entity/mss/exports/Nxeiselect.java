package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class Nxeiselect implements HiveEntity {
    public static final String SELECT_ALL_QUERY = "select iekey, generationno, ieitno, cmdtycode, origcntry, itemdestcntry, cpc, itemcnsgrturn, itemimptrturn, itemvatval, ieitcdutypaid, itemnetmass, itemsuppunits from nxeiselect";

    private String iekey;
    private String generationno;
    private String ieitno;
    private String cmdtycode;
    private String origcntry;
    private String itemdestcntry;
    private String cpc;
    private String itemcnsgrturn;
    private String itemimptrturn;
    private String itemvatval;
    private String ieitcdutypaid;
    private String itemnetmass;
    private String itemsuppunits;

}
