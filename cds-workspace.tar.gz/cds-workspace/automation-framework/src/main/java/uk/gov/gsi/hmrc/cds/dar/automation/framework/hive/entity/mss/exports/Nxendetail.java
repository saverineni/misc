package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class Nxendetail implements HiveEntity {
    public static final String SELECT_ALL_QUERY = "select iekey, generationno, ievrno, firdan, firdanpfx, decltrep, euarrlocncode, trptmodeinld, cnsgraeocerttycd, decltaeocerttycd, statvalue, totexcise, ienetmasstot, trptcntry, trptid, trptmodecode, dtofent, invcrrn, frgtcrrn, invtotac from nxendetail";

    private String iekey;
    private String generationno;
    private String ievrno;
    private String firdan;
    private String firdanpfx;
    private String decltrep;
    private String euarrlocncode;
    private String trptmodeinld;
    private String cnsgraeocerttycd;
    private String decltaeocerttycd;
    private String statvalue;
    private String totexcise;
    private String ienetmasstot;
    private String trptcntry;
    private String trptid;
    private String trptmodecode;
    private String dtofent;
    private String invcrrn;
    private String frgtcrrn;
    private String invtotac;
}
