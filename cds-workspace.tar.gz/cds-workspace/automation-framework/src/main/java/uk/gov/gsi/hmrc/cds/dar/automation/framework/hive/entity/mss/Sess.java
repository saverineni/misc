package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by developer on 08/08/17.
 */
@Data
public class Sess implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select sessno, rolenm from sess";

    private String sessno;
    private String rolenm;
}
