package uk.gov.gsi.hmrc.cds.dar.automation.framework.connection;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.slf4j.*;
import org.slf4j.Logger;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi.PDIEnv;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi.PDIUser;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import static java.util.stream.Collectors.toList;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.PDIJobOutputParser.isJobSuccessful;

/**
 * Created by smalavalli on 28/11/16.
 */
public final class PDIConnector {
    private static Logger logger = LoggerFactory.getLogger(PDIConnector.class);
    private static final String DEFAULT_KETTLE_FILE_LOCATION_PATH = "/kettle/ingestion-prototype";
    private static final String DEFAULT_PENTAHO_REPOSITORY = "CDSDATA ETL : Landing";


    public static PDIJobManager triggerPDIJob(String kJobName) {
        return new PDIJobManager(kJobName);
    }

    public static class PDIJobManager {
        String kettleJobName = null;
        String kettleFileLocationPath = DEFAULT_KETTLE_FILE_LOCATION_PATH;
        String pentahoRepository = DEFAULT_PENTAHO_REPOSITORY;
        Map<String, String> kettleJobParams = Maps.newHashMap();
        String pdiUserName = PDIUser.CDSDATA.username();
        PDIEnv pdiEnv = PDIEnv.DEV;

        public PDIJobManager(String kettleJobName) {
            this.kettleJobName = kettleJobName;
        }

        public PDIJobManager withKettleJobName(String kJobName) {
            this.kettleJobName = kJobName;
            return this;
        }

        public PDIJobManager withKettleFileLocationPath(String kettleFileLocationPath) {
            Objects.requireNonNull(kettleFileLocationPath, "kettle job file location path cannot be empty or null");
            this.kettleFileLocationPath = kettleFileLocationPath;
            return this;
        }

        public PDIJobManager withPentahoRepository(String pentahoRepository) {
            Objects.requireNonNull(pentahoRepository, "pentaho repository name cannot be empty or null");
            this.pentahoRepository = pentahoRepository;
            return this;
        }

        public PDIJobManager withJobParams(String key, String value) {
            Objects.requireNonNull(key, "job param key cannot be empty or null");
            Objects.requireNonNull(value, "job param value cannot be empty or null");
            this.kettleJobParams.put(key, value);
            return this;
        }

        public PDIJobManager asUser(PDIUser pdiUser) {
            this.pdiUserName = pdiUser.username();
            return this;
        }

        public PDIJobManager inEnv(PDIEnv pdiEnv) {
            this.pdiEnv = pdiEnv;
            return this;
        }

        public boolean trigger() {
            Objects.requireNonNull(kettleJobName, "Kettle Job Name is required");

            List<String> commands = jobExecutionCommandList();
            String pdiJobOutput = null;
            pdiJobOutput = RemoteMachineConnector.connectToDockerPDIServer().executeCommandsInShell(commands);

            return pdiJobOutput != null && isJobSuccessful(pdiJobOutput);
        }

        private List<String> jobExecutionCommandList() {
            String kettleScriptLocationPath = "/opt/pentaho/pdi-ce-6.1.0.1-196/data-integration/";
            String changeDirToPDICommand = String.format("cd %s", kettleScriptLocationPath);
            String executeKettleJobCommand = buildKettleJobExecutionCommand();
            String lastExecutionStatusCommand = "echo $?";
            String exitCommand = "exit";

            return Lists.newArrayList(
                    changeDirToPDICommand,
                    executeKettleJobCommand,
                    lastExecutionStatusCommand,
                    exitCommand
            );
        }

        private String buildKettleJobExecutionCommand() {
            if (!kettleJobParams.isEmpty()) {
                List<String> params = kettleJobParams.entrySet()
                        .stream()
                        .map(entry -> String.format("-param:%s=%s ", entry.getKey(), entry.getValue()))
                        .collect(toList());

                String jobExecutionCommand = String.format("./kitchen.sh -rep='%s' -user=admin -dir=%s -job=%s %s -level=Rowlevel", pentahoRepository, kettleFileLocationPath, kettleJobName, Joiner.on(" ").join(params));
                logger.info("Kettle job execution command $>{}", jobExecutionCommand);
                return jobExecutionCommand;
            }
            return String.format("./kitchen.sh -file %s%s", kettleFileLocationPath, kettleJobName);
        }
    }
}
