package uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion.mss;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toList;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.ResourceManager.getResourceURI;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.ResourceManager.readResource;

/**
 * Created by smalavalli on 29/12/16.
 */
public final class MSSDataIngestHelper {

    private static Logger logger = LoggerFactory.getLogger(MSSDataIngestHelper.class);
    public static String IMPORT_HEADER_DATA_FILES_PATH = "mssdata/headers/import/";
    public static String EXPORT_HEADER_DATA_FILES_PATH = "mssdata/headers/export/";
    public static String IMPORT_LINE_DATA_FILES_PATH = "mssdata/lines/import/";
    public static String EXPORT_LINE_DATA_FILES_PATH = "mssdata/lines/export/";
    public static String IMPORT_HEADER_TABLES_FILE_PATH = "mssdata/headers/tables-import.txt";
    public static String EXPORT_HEADER_TABLES_FILE_PATH = "mssdata/headers/tables-export.txt";
    public static String IMPORT_LINE_TABLES_FILE_PATH = "mssdata/lines/tables-import.txt";
    public static String EXPORT_LINE_TABLES_FILE_PATH = "mssdata/lines/tables-export.txt";

    public static List<File> getAllDataFilesToTransfer() {

        return Stream.of(
                IMPORT_HEADER_DATA_FILES_PATH,
                EXPORT_HEADER_DATA_FILES_PATH,
                IMPORT_LINE_DATA_FILES_PATH,
                EXPORT_LINE_DATA_FILES_PATH)
                .map(filePath -> {
                    Stream<Path> pathStream = null;
                    try {
                        pathStream = Files.list(Paths.get(getResourceURI(filePath)));
                    } catch (IOException e) {
                        logger.error("Error accessing resource {} {}", filePath, e);
                    }
                    return pathStream;
                })
                .flatMap(pathStream -> pathStream)
                .map(Path::toFile)
                .collect(toList());
    }

    public static Stream<String> fetchIngestTableList() {
        List<String> headerTables = fetchHeaderTableList().collect(toList());
        List<String> lineTables = fetchLineTableList().collect(toList());

        return Stream.of(headerTables, lineTables).flatMap(Collection::stream);
    }

    public static Stream<String> fetchHeaderTableList() {
        return Stream.of(fetchImportHeaderTableList(), fetchExportHeaderTableList()).flatMap(Collection::stream);
    }

    public static Stream<String> fetchLineTableList() {
        return Stream.of(fetchImportLineTableList(), fetchExportLineTableList()).flatMap(Collection::stream);
    }

    public static List<String> fetchImportHeaderTableList() {
        return fetchIngestTableList(IMPORT_HEADER_TABLES_FILE_PATH);
    }

    public static List<String> fetchExportHeaderTableList() {
        return fetchIngestTableList(EXPORT_HEADER_TABLES_FILE_PATH);
    }

    public static List<String> fetchImportLineTableList() {
        return fetchIngestTableList(IMPORT_LINE_TABLES_FILE_PATH);
    }

    public static List<String> fetchExportLineTableList() {
        return fetchIngestTableList(EXPORT_LINE_TABLES_FILE_PATH);
    }

    public static List<String> fetchIngestTableList(String tablesFilePath) {
        BufferedReader bufferedReader = readResource(tablesFilePath);
        Objects.requireNonNull(bufferedReader, "BufferedReader cannot be null. Check resource path " + tablesFilePath);

        return bufferedReader.lines().collect(toList());
    }

    public static List<String> buildInsertQueriesFor(List<String> importTables, String csvDataFilePathTemplate, String dbName) {
        QueryBuilder queryBuilder = new QueryBuilder();
        return importTables
                .stream()
                .map(tableName -> {
                    String csvDataFilePath = String.format(csvDataFilePathTemplate, tableName);
                    return queryBuilder.buildHiveInsertSql(tableName, csvDataFilePath, dbName);
                })
                .collect(toList());
    }

}
