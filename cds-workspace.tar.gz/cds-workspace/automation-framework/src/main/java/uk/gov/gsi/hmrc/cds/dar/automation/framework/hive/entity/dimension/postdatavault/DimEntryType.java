package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.postdatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class DimEntryType implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select entry_type from dim_entry_type";

    private String entry_type;
}
