package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.hubs;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by smalavalli on 19/01/17.
 */
@Data
public class HubCountry implements HiveEntity {

    public static final String SELECT_ALL_QUERY ="select hub_country_key, iso_country_code_alpha_2, hub_load_datetime, hub_record_source from hub_country";

    private String hub_country_key;
    private String iso_country_code_alpha_2;
    private String hub_load_datetime;
    private String hub_record_source;

}
