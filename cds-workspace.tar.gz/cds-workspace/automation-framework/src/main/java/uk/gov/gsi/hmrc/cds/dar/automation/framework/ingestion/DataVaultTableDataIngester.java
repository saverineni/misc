package uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion;

import org.codejargon.fluentjdbc.api.FluentJdbc;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi.PDIStage;

import java.util.List;

import static org.junit.Assert.assertTrue;

/**
 * Created by smalavalli on 19/01/17.
 */
public class DataVaultTableDataIngester {

    public static final List<String> DATA_VAULT_TABLES_TO_INGEST = PDIStage.POPULATE_DATA_VAULT.sourceTablesInStage();

    public static Ingest connectToDB(FluentJdbc hive) {
        return new Ingest(hive);
    }

    public static class Ingest implements DataIngester {
        FluentJdbc hive;

        public Ingest(FluentJdbc hive) {
            this.hive = hive;
        }

        @Override
        public void verboseIngestData() {
            LandingHashedTableDataIngester
                    .connectToDB(hive)
                    .ingestData(LandingHashedTableDataIngester.LANDING_HASH_TABLES_TO_INGEST);

            boolean populateDVJobStatus = PDIStage.POPULATE_DATA_VAULT.triggerPDIJob();
            assertTrue(populateDVJobStatus);

        }
    }
}
