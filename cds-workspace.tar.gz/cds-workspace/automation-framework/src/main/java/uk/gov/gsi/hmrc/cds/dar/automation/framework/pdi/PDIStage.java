package uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi;

import java.util.Arrays;
import java.util.List;

/**
 * Created by smalavalli on 23/01/17.
 */
public enum PDIStage implements PDIManagedTables, PDIJob, PostTestJob {

    CREATE_ALL_LANDING() {
        @Override
        public String pdiJobName() {
            return "MAIN_create_all_landing";
        }

        @Override
        public String pdiJobLocation() {
            return LANDING_JOB_KETTLE_LOCATION;
        }

        @Override
        public String pentahoRepository() {
            return LANDING_PDI_REPOSITORY;
        }

        @Override
        public List<String> tablesInStage() {
            return Arrays.asList(
                    LANDING_CDP_HEADERS_DECLARATION,
                    LANDING_CDP_LINES_DECLARATION,
                    LANDING_CDP_TRADER,
                    LANDING_MSS_HEADERS_DECLARATION,
                    LANDING_MSS_LINE_ADDITIONAL_INFORMATION,
                    LANDING_MSS_LINE_DOCUMENT,
                    LANDING_MSS_LINE_PREVIOUS_DOCUMENT,
                    LANDING_MSS_LINE_TAX_LINE,
                    LANDING_MSS_LINES_DECLARATION,
                    LANDING_MSS_TRADER,
                    LANDING_HEADERS_DECLARATION,
                    LANDING_LINE_ADDITIONAL_INFORMATION,
                    LANDING_LINE_DOCUMENT,
                    LANDING_LINE_PREVIOUS_DOCUMENT,
                    LANDING_LINE_TAX_LINE,
                    LANDING_LINES_DECLARATION,
                    LANDING_TRADER
            );
        }

        @Override
        public List<String> sourceTablesInStage() {
            return Arrays.asList(
                    LANDING_HEADERS_DECLARATION,
                    LANDING_LINE_ADDITIONAL_INFORMATION,
                    LANDING_LINE_DOCUMENT,
                    LANDING_LINE_PREVIOUS_DOCUMENT,
                    LANDING_LINE_TAX_LINE,
                    LANDING_LINES_DECLARATION,
                    LANDING_TRADER
            );
        }
        @Override
        public List<String> tablesToCache() {
            return sourceTablesInStage();
        }
    },
    CREATE_DIMENSIONS {
        @Override
        public String pdiJobName() {
            return "MAIN_build_dimensions";
        }

        @Override
        public String pdiJobLocation() {
            return DIMENSION_KETTLE_LOCATION;
        }

        @Override
        public String pentahoRepository() {
            return LANDING_PDI_REPOSITORY;
        }

        List<String> tableList = Arrays.asList(
                DIM_COMMODITY_CODE,
                DIM_COUNTRY,
                DIM_CURRENCY,
                DIM_CUSTOMS_PROCEDURE_CODE,
                DIM_CUSTOMS_ROUTE,
                DIM_DATE,
                DIM_EPU,
                DIM_IMPORT_CLEARANCE_STATUS
        );

        @Override
        public List<String> tablesInStage() {
            return tableList;
        }

        @Override
        public List<String> sourceTablesInStage() {
            return tableList;
        }

        @Override
        public List<String> tablesToCache() {
            return sourceTablesInStage();
        }
    },
    CREATE_LANDING_HASHED_TABLES {
        @Override
        public String pdiJobName() {
            return "WRAP_create_DV_hashes";
        }

        @Override
        public String pdiJobLocation() {
            return GENERIC_DATA_MODEL_KETTLE_LOCATION;
        }

        @Override
        public String pentahoRepository() {
            return GENERIC_DATA_MODEL_PDI_REPOSITORY;
        }

        List<String> tableList = Arrays.asList(
                LANDING_HEADERS_DECLARATION_HASHED,
                LANDING_LINE_ADDITIONAL_INFORMATION_HASHED,
                LANDING_LINE_DOCUMENT_HASHED,
                LANDING_LINE_PREVIOUS_DOCUMENT_HASHED,
                LANDING_LINE_TAX_LINE_HASHED,
                LANDING_LINES_DECLARATION_HASHED,
                LANDING_TRADER_HASHED,
                DIM_COMMODITY_CODE_HASHED,
                DIM_COUNTRY_HASHED,
                DIM_CURRENCY_HASHED,
                DIM_CUSTOMS_PROCEDURE_CODE_HASHED
        );

        @Override
        public List<String> tablesInStage() {
            return tableList;
        }

        @Override
        public List<String> sourceTablesInStage() {
            return tableList;
        }

        @Override
        public List<String> tablesToCache() {
            return sourceTablesInStage();
        }
    },
    POPULATE_DATA_VAULT {
        @Override
        public String pdiJobName() {
            return "WRAP_populate_hub_sat_link";
        }

        @Override
        public String pdiJobLocation() {
            return GENERIC_DATA_MODEL_KETTLE_LOCATION;
        }

        @Override
        public String pentahoRepository() {
            return GENERIC_DATA_MODEL_PDI_REPOSITORY;
        }

        List<String> tableList = Arrays.asList(
                HUB_ADDITIONAL_INFO,
                HUB_COMMODITY,
                HUB_COUNTRY,
                HUB_CURRENCY,
                HUB_CUSTOMS_PROCEDURE_CODE,
                HUB_DECLARATION,
                HUB_DECLARATION_LINE,
                HUB_DOCUMENT,
                HUB_PREVIOUS_DOCUMENT,
                HUB_TAX_LINE,
                HUB_TRADER,
                SAT_ADDITIONAL_INFO,
                SAT_COMMODITY,
                SAT_COUNTRY,
                SAT_CURRENCY,
                SAT_DECLARATION,
                SAT_DECLARATION_LINE,
                SAT_DOCUMENT,
                SAT_PREVIOUS_DOCUMENT,
                SAT_TAX_LINE,
                SAT_TRADER,
                LINK_DECLARATION_CONSIGNOR_TRADER,
                LINK_DECLARATION_DECLARANT_TRADER,
                LINK_DECLARATION_DESTINATION_COUNTRY,
                LINK_DECLARATION_EXPORTER_TRADER,
                LINK_DECLARATION_FREIGHT_CURRENCY,
                LINK_DECLARATION_IMPORTER_TRADER,
                LINK_DECLARATION_INVOICE_CURRENCY,
                LINK_DECLARATION_PAYING_AGENT_TRADER,
                LINK_DECLARATION_TRANSPORT_COUNTRY,
                LINK_DECLARATION_LINE_ADDITIONAL_INFO,
                LINK_DECLARATION_LINE_COMMODITY,
                LINK_DECLARATION_LINE_CUSTOM_PROCEDURE_CODE,
                LINK_DECLARATION_LINE_DECLARATION,
                LINK_DECLARATION_LINE_DOCUMENT,
                LINK_DECLARATION_LINE_IMPORTER_TRADER,
                LINK_DECLARATION_LINE_ORIGIN_COUNTRY,
                LINK_DECLARATION_LINE_PREVIOUS_DOCUMENT,
                LINK_DECLARATION_LINE_TAX_LINE
        );

        @Override
        public List<String> tablesInStage() {
            return tableList;
        }

        @Override
        public List<String> sourceTablesInStage() {
            return tableList;
        }

        @Override
        public List<String> tablesToCache() {
            return sourceTablesInStage();
        }
    },
    CREATE_EXPLOITATION {
        List<String> tableList = Arrays.asList(
                FACT_CONSOLIDATED_CONSIGNMENTS_WIDE,
                FACT_DECLARATION_LINES_WIDE,
                FACT_DECLARATION_LINES_WIDE_ALL,
                FACT_DECLARATION_LINES_WIDE_EXPORT,
                FACT_DECLARATION_TAX_LINES_WIDE_EXPORT,
                FACT_DECLARATION_TAX_LINES_WIDE_IMPORT,
                FACT_DECLARATION_WIDE,
                FACT_DECLARATION_WIDE_EXPORT
        );

        @Override
        public String pdiJobName() {
            return "MAIN_create_exploitation";
        }

        @Override
        public String pdiJobLocation() {
            return EXPLOITATION_REPORT_JOB_KETTLE_LOCATION;
        }

        @Override
        public String pentahoRepository() {
            return EXPLOITATION_REPORT_PDI_REPOSITORY;
        }

        @Override
        public List<String> tablesInStage() {
            return tableList;
        }

        @Override
        public List<String> sourceTablesInStage() {
            return tableList;
        }

        @Override
        public List<String> tablesToCache() {
            return sourceTablesInStage();
        }
    }

}
