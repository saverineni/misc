package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity;

/**
 * Created by smalavalli on 19/01/17.
 */
public interface HiveEntity {
}
