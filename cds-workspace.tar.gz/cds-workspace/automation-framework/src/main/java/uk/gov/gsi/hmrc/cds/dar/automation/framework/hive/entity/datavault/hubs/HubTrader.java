package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.hubs;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by smalavalli on 22/03/17.
 */
@Data
public class HubTrader implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select hub_trader_key, turn, hub_load_datetime, hub_record_source from hub_trader";

    private String hub_trader_key;
    private String turn;
    private String hub_load_datetime;
    private String hub_record_source;
}
