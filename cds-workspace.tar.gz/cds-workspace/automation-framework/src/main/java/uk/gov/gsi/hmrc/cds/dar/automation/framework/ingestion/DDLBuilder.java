package uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion;

import com.google.common.base.Joiner;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.RemoteMachineConnector;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.PDIJobOutputParser;

import java.io.BufferedReader;
import java.io.StringReader;
import java.util.*;
import java.util.stream.Collectors;

import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.PropertyConfiguration.config;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.HiveDBManager.DEFAULT_TEST_DB;

/**
 * Created by smalavalli on 09/01/17.
 */
public class DDLBuilder {

    private static Logger logger = LoggerFactory.getLogger(DDLBuilder.class);

    public void buildCreateTableScript(String tableName) {
        String baseFilePathTemplate = config().getString("data.file.ftp.path.template");
        String baseFilePath = String.format(baseFilePathTemplate, DEFAULT_TEST_DB);

        String metadataDirectoryPath = String.format("%s/%s", baseFilePath, tableName);

        RemoteMachineConnector.RemoteMachine remoteMachine = RemoteMachineConnector.connectToFASTP2();
        remoteMachine.makeDirectory(metadataDirectoryPath);

        String describeTableCommand = String.format("hive -e 'describe %s.%s;'", DEFAULT_TEST_DB, tableName);
        String channelOutput = remoteMachine.executeCommandsInShell(Arrays.asList(describeTableCommand));
        List<String> tableDescLines = parseDescribeTableOutput(channelOutput);

        String createDDLFileScript = scriptToCreateDDLFile(tableName, tableDescLines, metadataDirectoryPath);
        remoteMachine.executeScript(createDDLFileScript);

//        String sudoScriptToChangeDirectoryPermission = String.format("sudo su - root -c \"chmod -R 777 %s\"", metadataDirectoryPath);
//        remoteMachine.executeScriptAsSudo(sudoScriptToChangeDirectoryPermission);

        logger.info("CreateTable DDl script created for table {} at location {} on FASTP-2", tableName, metadataDirectoryPath);
    }

    private String scriptToCreateDDLFile(String tableName, List<String> tableDescLines, String createTableDDLScriptPath) {
        String createTableDDLScript = buildCreateTableDDLScript(tableName, tableDescLines);

        String makeDirectoryByTableName = String.format("mkdir -p %s", createTableDDLScriptPath);
        String createDDLScriptFile = String.format("echo \"%s\" > %s/%s.sql", createTableDDLScript, createTableDDLScriptPath, tableName);
        List<String> commandList = Arrays.asList(makeDirectoryByTableName, createDDLScriptFile);
        return Joiner.on(";").join(commandList);
    }

    private String buildCreateTableDDLScript(String tableName, List<String> tableDescLines) {
        String createTableScriptTemplate = "CREATE TABLE IF NOT EXISTS %s.%s( %s )";
        return String.format(createTableScriptTemplate, DEFAULT_TEST_DB, tableName, Joiner.on(",").join(tableDescLines));
    }

    private List<String> parseDescribeTableOutput(String shellOutput) {
        BufferedReader bufferedReader = IOUtils.toBufferedReader(new StringReader(shellOutput));

        // TODO - Move PDIJobOutputParser.buildLineNumberJobOutputMap to generic parser.
        HashMap<Integer, String> lineNumberJobOutputMap = PDIJobOutputParser.buildLineNumberJobOutputMap(shellOutput);
        Optional<Integer> describeTableCursorLineNumber = lineNumberJobOutputMap.entrySet().stream()
                .filter(integerStringEntry -> integerStringEntry.getValue().contains("OK"))
                .map(Map.Entry::getKey)
                .findFirst();

        Integer linesToSkip = describeTableCursorLineNumber.orElse(4); // zero base count, so add one later.

        List<String> resultList = bufferedReader.lines().skip(linesToSkip + 1).collect(Collectors.toList());
        return resultList.stream()
                .limit(resultList.size() - 3)
                .map(s -> s.replaceAll("from deserializer", "").replaceAll("\t", " "))
                .collect(Collectors.toList());
    }
}
