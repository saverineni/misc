package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by smalavalli on 21/12/16.
 */
@Data
public class LandingLinesDeclaration implements HiveEntity {
    public static final String SELECT_ALL_QUERY = "select source, ingestion_date, entry_number, entry_date, epu_number, item_number, clearance_datetime, origin_country_code, " +
                                                    "item_statistical_value, commodity_code, customs_procedure_code, customs_duty_paid, vat_paid, vat_value, ec_supplementary_1, " +
                                                    "item_customs_value, item_net_mass, item_supplementary_units, goods_description, item_importer_turn, item_customs_check_code, " +
                                                    "item_mic_code, item_profile_id, item_consignor_nad_name, item_consignee_nad_name, item_consignee_nad_postcode, item_price_declared, " +
                                                    "entry_reference, hs_code from landing_lines_declaration ";

    private String source;
    private String ingestion_date;
    private String entry_number;
    private String entry_date;
    private String epu_number;
    private String item_number;
    private String clearance_datetime;
    private String origin_country_code;
    private String item_statistical_value;
    private String commodity_code;
    private String customs_procedure_code;
    private String customs_duty_paid;
    private String vat_paid;
    private String vat_value;
    private String ec_supplementary_1;
    private String item_customs_value;
    private String item_net_mass;
    private String item_supplementary_units;
    private String goods_description;
    private String item_importer_turn;
    private String item_customs_check_code;
    private String item_mic_code;
    private String item_profile_id;
    private String item_consignor_nad_name;
    private String item_consignee_nad_name;
    private String item_consignee_nad_postcode;
    private String item_price_declared;
    private String entry_reference;
    private String hs_code;
}