package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class Tder implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select turn, fedate, tdrnameall, tdrspauths, tdrabbrnm, currentind from tder";

    private String turn;
    private String fedate;
    private String tdrnameall;
    private String tdrspauths;
    private String tdrabbrnm;
    private String currentind;
}
