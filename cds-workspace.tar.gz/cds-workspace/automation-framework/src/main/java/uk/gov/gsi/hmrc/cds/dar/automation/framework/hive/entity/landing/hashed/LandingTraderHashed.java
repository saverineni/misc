package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by smalavalli on 22/03/17.
 */
@Data
public class LandingTraderHashed implements HiveEntity {
    public static final String SELECT_ALL_QUERY = "select source, ingestion_date, turn, fedate, name, simplified_procedure_authorisations, trader_name_abbreviated, hub_trader, sat_trader, currentind from landing_trader_hashed";

    private String source;
    private String ingestion_date;
    private String turn;
    private String fedate;
    private String name;
    private String simplified_procedure_authorisations;
    private String trader_name_abbreviated;
    private String currentind;
    private String hub_trader;
    private String sat_trader;
}
