package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class Imeidetail implements HiveEntity {
    public static final String SELECT_ALL_QUERY = "select iekey, ieitno, itemprc, itemvatval, itemstatval, itemcstmsval, ieitcdutypaid, gdsdesc, ieitvatpaid, ecsu1, itemnetmass, itemsuppunits, itemprcac from imeidetail";

    private String iekey;
    private String ieitno;
    private String itemprc;
    private String itemvatval;
    private String itemstatval;
    private String itemcstmsval;
    private String ieitcdutypaid;
    private String gdsdesc;
    private String ieitvatpaid;
    private String ecsu1;
    private String itemnetmass;
    private String itemsuppunits;
    private String itemprcac;
}
