package uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs.builder;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;

/**
 * Created by smalavalli on 01/11/16.
 */
public class PathBuilder {

    public static Builder builder(Configuration configuration) {
        return new Builder(configuration);
    }

    /**
     * Configuration built using @class HDFSConfigurationBuilder
     */
    public static class Builder {
        Configuration configuration;
        Path path;

        public Builder(Configuration configuration) {
            this.configuration = configuration;
        }

        public Builder withPath(String hdfsPath) {
            path = new Path(configuration.get(HDFSConfigurationBuilder.DEFAULT_URL_STRING), hdfsPath);
            return this;
        }

        public Path build() {
            return path;
        }
    }
}
