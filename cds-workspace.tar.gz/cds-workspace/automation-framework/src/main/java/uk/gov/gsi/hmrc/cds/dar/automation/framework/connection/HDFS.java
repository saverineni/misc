package uk.gov.gsi.hmrc.cds.dar.automation.framework.connection;

/**
 * Created by smalavalli on 22/11/16.
 */
public enum HDFS {
    NAMENODE(DOCKER_ENV.getInstance().host(), "8020");

    private String host;
    private String port;

    HDFS(String host, String port) {
        this.host = host;
        this.port = port;
    }

    public String host() {
        return host;
    }

    public String port() {
        return port;
    }
}
