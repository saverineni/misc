package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.hubs;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by smalavalli on 17/01/17.
 */
@Data
public class HubDeclaration implements HiveEntity {
    public static final String SELECT_ALL_QUERY = "select hub_declaration_key, entry_reference, hub_load_datetime, hub_record_source from hub_declaration";

    private String hub_declaration_key;
    private String entry_reference;
    private String hub_load_datetime;
    private String hub_record_source;

}
