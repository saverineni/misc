package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers;

import org.codejargon.fluentjdbc.api.FluentJdbc;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.postdatavault.*;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault.*;

import java.util.List;
import java.util.Optional;

/**
 * Created by smalavalli on 31/01/17.
 */
public class HiveDimensionTableReader {
    private static Logger logger = LoggerFactory.getLogger(HiveDimensionTableReader.class);

    public static List<DimAdditionalInfo> readAllDimAdditionalInfo(FluentJdbc hive) {
        logger.info("Reading all data from table dim_additional_info");
        return HiveTableReader.readTable(hive, DimAdditionalInfo.SELECT_ALL_QUERY, DimAdditionalInfo.class);
    }

    public static List<DimClearanceStatus> readAllDimClearanceStatus(FluentJdbc hive) {
        logger.info("Reading all data from table dim_clearance_status");
        return HiveTableReader.readTable(hive, DimClearanceStatus.SELECT_ALL_QUERY, DimClearanceStatus.class);
    }

    public static List<DimCommodityCode> readAllDimCommodityCode(FluentJdbc hive) {
        logger.info("Reading all data from table dim_commodity_code");
        return HiveTableReader.readTable(hive, DimCommodityCode.SELECT_ALL_QUERY, DimCommodityCode.class);
    }

    public static List<DimCountry> readAllDimCountry(FluentJdbc hive) {
        logger.info("Reading all data from table dim_country");
        return HiveTableReader.readTable(hive, DimCountry.SELECT_ALL_QUERY, DimCountry.class);
    }

    public static Optional<DimCountry> readAllDimCountryForCountryCode(FluentJdbc hive, String countryCode) {
        logger.info("Reading all data from table countryCode for country_iso_code '{}'", countryCode);
        List<DimCountry> dimCountry = readAllDimCountry(hive);
        return dimCountry
                .stream()
                .filter(row -> row.getCountry_iso_code().equals(countryCode))
                .findFirst();
    }


    public static List<DimCurrency> readAllDimCurrency(FluentJdbc hive) {
        logger.info("Reading all data from table dim_currency");
        return HiveTableReader.readTable(hive, DimCurrency.SELECT_ALL_QUERY, DimCurrency.class);
    }

    public static List<DimCustomsProcedureCode> readAllDimCustomsProcedureCode(FluentJdbc hive) {
        logger.info("Reading all data from table dim_customs_procedure_code");
        return HiveTableReader.readTable(hive, DimCustomsProcedureCode.SELECT_ALL_QUERY, DimCustomsProcedureCode.class);
    }

    public static List<DimCustomsRoute> readAllDimCustomsRoute(FluentJdbc hive) {
        logger.info("Reading all data from table dim_customs_route");
        return HiveTableReader.readTable(hive, DimCustomsRoute.SELECT_ALL_QUERY, DimCustomsRoute.class);
    }

    public static List<DimDan> readAllDimDan(FluentJdbc hive) {
        logger.info("Reading all data from table dim_dan");
        return HiveTableReader.readTable(hive, DimDan.SELECT_ALL_QUERY, DimDan.class);
    }

    public static List<DimDanPrefix> readAllDimDanPrefix(FluentJdbc hive) {
        logger.info("Reading all data from table dim_dan_prefix");
        return HiveTableReader.readTable(hive, DimDanPrefix.SELECT_ALL_QUERY, DimDanPrefix.class);
    }

    public static List<DimDataSource> readAllDimDataSource(FluentJdbc hive) {
        logger.info("Reading all data from table dim_data_source");
        return HiveTableReader.readTable(hive, DimDataSource.SELECT_ALL_QUERY, DimDataSource.class);
    }

    public static List<DimDate> readAllDimDate(FluentJdbc hive) {
        logger.info("Reading all data from table dim_date");
        return HiveTableReader.readTable(hive, DimDate.SELECT_ALL_QUERY, DimDate.class);
    }

    public static Optional<DimDate> readAllDimDateForDateValue(FluentJdbc hive, String date) {
        logger.info("Reading all data from table dim_date for date_value '{}'", date);
        List<DimDate> dimDate = readAllDimDate(hive);
        return dimDate
                .stream()
                .filter(row -> row.getDate_value().equals(date))
                .findFirst();
    }

    public static List<DimDeclarationMethod> readAllDimDeclarationMethod(FluentJdbc hive) {
        logger.info("Reading all data from table dim_declaration_method");
        return HiveTableReader.readTable(hive, DimDeclarationMethod.SELECT_ALL_QUERY, DimDeclarationMethod.class);
    }

    public static List<DimDocument> readAllDimDocument(FluentJdbc hive) {
        logger.info("Reading all data from table dim_document");
        return HiveTableReader.readTable(hive, DimDocument.SELECT_ALL_QUERY, DimDocument.class);
    }

    public static List<DimEcSupplementary> readAllDimEcSupplementary(FluentJdbc hive) {
        logger.info("Reading all data from table dim_ec_supplementary");
        return HiveTableReader.readTable(hive, DimEcSupplementary.SELECT_ALL_QUERY, DimEcSupplementary.class);
    }

    public static List<DimEntryType> readAllDimEntryType(FluentJdbc hive) {
        logger.info("Reading all data from table dim_entry_type");
        return HiveTableReader.readTable(hive, DimEntryType.SELECT_ALL_QUERY, DimEntryType.class);
    }

    public static List<DimEpu> readAllDimEpu(FluentJdbc hive) {
        logger.info("Reading all data from table dim_epu");
        return HiveTableReader.readTable(hive, DimEpu.SELECT_ALL_QUERY, DimEpu.class);
    }

    public static Optional<DimEpu> readAllDimEpuForEpuNumber(FluentJdbc hive, String epuNo) {
        logger.info("Reading all data from table dim_epu for epu_number '{}'", epuNo);
        List<DimEpu> dimEpu = readAllDimEpu(hive);
        return dimEpu
                .stream()
                .filter(row -> row.getEpu_number().equals(epuNo))
                .findFirst();
    }

    public static List<DimGoodsLocation> readAllDimGoodsLocation(FluentJdbc hive) {
        logger.info("Reading all data from table dim_goods_location");
        return HiveTableReader.readTable(hive, DimGoodsLocation.SELECT_ALL_QUERY, DimGoodsLocation.class);
    }

    public static List<DimImportClearanceStatus> readAllDimImportClearanceStatus(FluentJdbc hive) {
        logger.info("Reading all data from table dim_import_clearance_status");
        return HiveTableReader.readTable(hive, DimImportClearanceStatus.SELECT_ALL_QUERY, DimImportClearanceStatus.class);
    }

    public static List<DimPlaceOfLoading> readAllDimPlaceOfLoading(FluentJdbc hive) {
        logger.info("Reading all data from table dim_place_of_loading");
        return HiveTableReader.readTable(hive, DimPlaceOfLoading.SELECT_ALL_QUERY, DimPlaceOfLoading.class);
    }

    public static List<DimPlaceOfUnloading> readAllDimPlaceOfUnloading(FluentJdbc hive) {
        logger.info("Reading all data from table dim_place_of_unloading");
        return HiveTableReader.readTable(hive, DimPlaceOfUnloading.SELECT_ALL_QUERY, DimPlaceOfUnloading.class);
    }

    public static List<DimPreviousDocument> readAllDimPreviousDocument(FluentJdbc hive) {
        logger.info("Reading all data from table dim_previous_document");
        return HiveTableReader.readTable(hive, DimPreviousDocument.SELECT_ALL_QUERY, DimPreviousDocument.class);
    }

    public static List<DimRoute> readAllDimRoute(FluentJdbc hive) {
        logger.info("Reading all data from table dim_route");
        return HiveTableReader.readTable(hive, DimRoute.SELECT_ALL_QUERY, DimRoute.class);
    }

    public static List<DimSession> readAllDimSession(FluentJdbc hive) {
        logger.info("Reading all data from table dim_session");
        return HiveTableReader.readTable(hive, DimSession.SELECT_ALL_QUERY, DimSession.class);
    }

    public static List<DimTaxLine> readAllDimTaxLine(FluentJdbc hive) {
        logger.info("Reading all data from table dim_tax_line");
        return HiveTableReader.readTable(hive, DimTaxLine.SELECT_ALL_QUERY, DimTaxLine.class);
    }

    public static List<DimTrader> readAllDimTrader(FluentJdbc hive) {
        logger.info("Reading all data from table dim_trader");
        return HiveTableReader.readTable(hive, DimTrader.SELECT_ALL_QUERY, DimTrader.class);
    }

    public static List<DimTransportId> readAllDimTransportId(FluentJdbc hive) {
        logger.info("Reading all data from table dim_transport_id");
        return HiveTableReader.readTable(hive, DimTransportId.SELECT_ALL_QUERY, DimTransportId.class);
    }

    public static List<DimTransportMode> readAllDimTransportMode(FluentJdbc hive) {
        logger.info("Reading all data from table dim_transport_mode");
        return HiveTableReader.readTable(hive, DimTransportMode.SELECT_ALL_QUERY, DimTransportMode.class);
    }
}