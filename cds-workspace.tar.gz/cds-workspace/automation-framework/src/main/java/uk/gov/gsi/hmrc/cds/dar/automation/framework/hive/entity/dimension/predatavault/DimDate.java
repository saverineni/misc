package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

/**
 * Created by nayub on 02/03/17.
 */
@Data
public class DimDate implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select date_id, date_month_short, date_day_of_month, date_day_of_week, date_day_of_week_long, date_day_of_week_short, date_day_of_year, date_formatted_iso, date_month, date_month_format_yyyy_mm, date_month_long, date_quarter, date_quarter_name, date_quarter_name_full, date_value, date_week_of_year, date_year, date_is_weekend, date_week_start_date, date_year_of_week from dim_date";

    private String date_id;
    private String date_month_short;
    private String date_day_of_month;
    private String date_day_of_week;
    private String date_day_of_week_long;
    private String date_day_of_week_short;
    private String date_day_of_year;
    private String date_formatted_iso;
    private String date_month;
    private String date_month_format_yyyy_mm;
    private String date_month_long;
    private String date_quarter;
    private String date_quarter_name;
    private String date_quarter_name_full;
    private String date_value;
    private String date_week_of_year;
    private String date_year;
    private String date_is_weekend;
    private String date_week_start_date;
    private String date_year_of_week;
}