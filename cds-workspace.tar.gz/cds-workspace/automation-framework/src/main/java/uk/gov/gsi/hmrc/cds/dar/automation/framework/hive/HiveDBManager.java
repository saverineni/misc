package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive;

import org.codejargon.fluentjdbc.api.FluentJdbc;
import org.codejargon.fluentjdbc.api.mapper.Mappers;
import org.codejargon.fluentjdbc.api.query.Mapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.PropertyConfiguration;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.ResourceManager;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi.PDIStage;

import java.io.BufferedReader;
import java.util.List;
import java.util.Optional;

/**
 * Created by smalavalli on 13/12/16.
 */
public class HiveDBManager {
    private static Logger logger = LoggerFactory.getLogger(HiveDBManager.class);
    private static final String DEFAULT_TEST_DB_NAME = PropertyConfiguration.config().getString("test.db.name");
    public static final String DEFAULT_TEST_DB = Optional.ofNullable(MDC.get("db_name")).orElse(DEFAULT_TEST_DB_NAME);

    //Header
    private static final String HEADERS_DDL_CREATE_EXPORT_SQL = "mssdata/headers/DDL-Create-Export-Header.sql";
    private static final String HEADERS_DDL_CREATE_IMPORT_SQL = "mssdata/headers/DDL-Create-Import-Header.sql";
    private static final String HEADERS_DDL_PURGE_EXPORT_SQL = "mssdata/headers/DDL-Drop-Export-Header.sql";
    private static final String HEADERS_DDL_PURGE_IMPORT_SQL = "mssdata/headers/DDL-Drop-Import-Header.sql";

    //Line
    private static final String LINES_DDL_CREATE_EXPORT_SQL = "mssdata/lines/DDL-Create-Export-Line.sql";
    private static final String LINES_DDL_CREATE_IMPORT_SQL = "mssdata/lines/DDL-Create-Import-Line.sql";
    private static final String LINES_DDL_PURGE_EXPORT_SQL = "mssdata/lines/DDL-Drop-Export-Line.sql";
    private static final String LINES_DDL_PURGE_IMPORT_SQL = "mssdata/lines/DDL-Drop-Import-Line.sql";

    public static DBManager connect(FluentJdbc hive) {
        return new DBManager(hive);
    }

    public static class DBManager {
        final FluentJdbc hive;

        public DBManager(FluentJdbc hive) {
            this.hive = hive;
        }

        public void createMSSTables(String dbName) {
            logger.info("Creating Header Tables....");
            createMSSHeaderTables(dbName);
            logger.info("Creating Line Tables....");
            createMSSLineTables(dbName);
        }

        private void createMSSHeaderTables(String dbName) {
            executeQueriesInFile(HEADERS_DDL_CREATE_EXPORT_SQL, dbName);
            executeQueriesInFile(HEADERS_DDL_CREATE_IMPORT_SQL, dbName);
        }

        public void createMSSTables() {
            createMSSTables(DEFAULT_TEST_DB);
        }

        private void createMSSLineTables(String dbName) {
            executeQueriesInFile(LINES_DDL_CREATE_EXPORT_SQL, dbName);
            executeQueriesInFile(LINES_DDL_CREATE_IMPORT_SQL, dbName);
        }

        public void dropAllTables() {
            PDIStage.CREATE_ALL_LANDING.dropAllLockTables(hive); //TODO - provide clean solution.
            dropMSSTables();
            PDIStage.CREATE_DIMENSIONS.dropAllLockTables(hive);
            PDIStage.CREATE_ALL_LANDING.dropTablesInStage(hive);
            PDIStage.CREATE_LANDING_HASHED_TABLES.dropTablesInStage(hive);
            PDIStage.POPULATE_DATA_VAULT.dropTablesInStage(hive);
            PDIStage.CREATE_EXPLOITATION.dropTablesInStage(hive);
        }

        public void dropMSSTables() {
            dropMSSHeaderTables(DEFAULT_TEST_DB);
            dropMSSLineTables(DEFAULT_TEST_DB);
        }

        private void dropMSSLineTables(String dbName) {
            executeQueriesInFile(LINES_DDL_PURGE_EXPORT_SQL, dbName);
            executeQueriesInFile(LINES_DDL_PURGE_IMPORT_SQL, dbName);
        }

        private void dropMSSHeaderTables(String dbName) {
            executeQueriesInFile(HEADERS_DDL_PURGE_EXPORT_SQL, dbName);
            executeQueriesInFile(HEADERS_DDL_PURGE_IMPORT_SQL, dbName);
        }

        public void executeQuery(String query) {
            hive
                    .query()
                    .update(query)
                    .run();
        }

        public void executeQuery(String queryTemplate, String dbName) {
            hive
                    .query()
                    .update(String.format(queryTemplate, dbName))
                    .run();
        }

        public void executeQueries(List<String> queries) {
            queries
                    .stream()
                    .peek(this::executeQuery)
                    .count();

        }

        private void executeQueriesInFile(String ddlFilePath, String dbName) {
            BufferedReader tables = ResourceManager.readResource(ddlFilePath);
            tables.lines()
                    .skip(1)
                    .peek(
                            table -> {
                                logger.info(String.format(table, dbName));
                                executeQuery(table, dbName);
                            }
                    ).count();
        }

        public String rowCount(String query) {
            return hive.query()
                    .select(query)
                    .singleResult(Mappers.singleString());
        }

        public <T> List<T> listResultFor(String query, Mapper<T> mapper) {
            logger.info("Query: {}", query);

            return hive.query()
                    .select(query)
                    .listResult(mapper);
        }
    }
}
