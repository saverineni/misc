package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers;

import org.codejargon.fluentjdbc.api.mapper.ObjectMappers;
import org.codejargon.fluentjdbc.api.query.Mapper;

/**
 * Created by smalavalli on 21/12/16.
 */
public final class HiveMapper {

    private static final ObjectMappers objectMappers = ObjectMappers.builder().build();

    public static <T> Mapper<T> of(Class<T> klazz) {
        return objectMappers.forClass(klazz);
    }
}
