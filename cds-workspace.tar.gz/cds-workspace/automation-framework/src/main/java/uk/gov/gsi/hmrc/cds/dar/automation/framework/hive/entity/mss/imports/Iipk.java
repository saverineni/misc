package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class Iipk implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select iekey, ieitno, pkgkind, pkgcount, pkgmarks from iipk";

    private String iekey;
    private String ieitno;
    private String pkgkind;
    private String pkgcount;
    private String pkgmarks;
}
