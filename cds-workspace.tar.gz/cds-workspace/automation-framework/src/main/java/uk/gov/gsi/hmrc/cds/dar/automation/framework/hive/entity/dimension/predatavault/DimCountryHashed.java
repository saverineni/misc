package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class DimCountryHashed implements HiveEntity {

    public static final String SELECT_ALL_QUERY = "select country_id, country_iso_code, country_name, country_sequence_number, country_comments, hub_country, sat_country from dim_country_hashed";

    private String country_id;
    private String country_iso_code;
    private String country_name;
    private String country_sequence_number;
    private String country_comments;
    private String hub_country;
    private String sat_country;
}
