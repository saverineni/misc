package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.satellites;

import lombok.Data;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.HiveEntity;

@Data
public class SatDocument implements HiveEntity {

    public static final String SELECT_ALL_QUERY ="select hub_document_key, sat_hash_diff, sat_load_datetime, sat_load_end_datetime, sat_record_source, generation_number, item_document_code, item_document_status, item_document_reference from sat_document";

    private String hub_document_key;
    private String sat_hash_diff;
    private String sat_load_datetime;
    private String sat_load_end_datetime;
    private String sat_record_source;
    private String generation_number;
    private String item_document_code;
    private String item_document_status;
    private String item_document_reference;
}
