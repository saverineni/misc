package uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs;


import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

import static uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs.HDFSFileSystemUtil.AUTOMATION_TEST_CACHE_PATH;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.hdfs.HDFSFileSystemUtil.HADOOP_USER_CDSDATA;

/**
 * Created by smalavalli on 21/02/17.
 */
@Ignore
public class HDFSFileSystemUtilTest {
    @Test
    public void createCacheDir() throws Exception {
        HDFSFileSystemUtil
                .createDirectoryAsUser(HADOOP_USER_CDSDATA)
                .withPath("/user/cdsdata/automation_test_cache/")
                .create();
    }

    @Test
    public void removeCacheDir() throws Exception {
        HDFSFileSystemUtil
                .removeDirectoryAsUser(HADOOP_USER_CDSDATA)
                .withPath(AUTOMATION_TEST_CACHE_PATH)
                .remove();
    }

    @Test
    public void copyContentOfDirectory() throws Exception {
        String fromPath = "/user/hive/warehouse/mss_test.db/landing_headers_declaration";
        String toPath = "/user/cdsdata/automation_test_cache/landing_headers_declaration";
        HDFSFileSystemUtil
                .copyDataAsUser(HADOOP_USER_CDSDATA)
                .fromHDFSPath(fromPath)
                .toHDFSPath(toPath)
                .copy();
//        PDIStage.CREATE_ALL_LANDING.tablesInStage().forEach(
//                tableName -> HDFSFileSystemUtil
//                        .copyDataAsUser(HADOOP_USER_CDSDATA)
//                        .fromHDFSPath(String.format("/user/hive/warehouse/dv_dev.db/%s", tableName))
//                        .toHDFSPath(String.format("/user/cdsdata/automation_test_cache/%s", tableName))
//                        .copy());
    }

    @Test
    public void copyFile() throws Exception {
        String fromPath = "/user/hive/warehouse/mss_test.db/dim_country/000000_0";
        String toPath = "/user/cdsdata/automation_test_cache/dim_country/000000_0";
        HDFSFileSystemUtil
                .copyDataAsUser(HADOOP_USER_CDSDATA)
                .fromHDFSPath(fromPath)
                .toHDFSPath(toPath)
                .copy();
    }

    @Test
    public void directoryExists() throws Exception {
        boolean directoryExists = HDFSFileSystemUtil.directoryExists("/user/cdsdata/automation_test_cache");
        Assert.assertTrue(directoryExists);

    }

}