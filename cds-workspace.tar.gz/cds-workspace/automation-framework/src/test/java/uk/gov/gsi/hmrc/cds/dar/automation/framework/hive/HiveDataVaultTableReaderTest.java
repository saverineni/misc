package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive;

import org.codejargon.fluentjdbc.api.FluentJdbc;
import org.junit.Ignore;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.HiveConnector;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.hubs.HubDeclarationLine;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.links.LinkDeclarationLineOriginCountry;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveDataVaultTableReader;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

/**
 * Created by smalavalli on 21/02/17.
 */
@Ignore
public class HiveDataVaultTableReaderTest {
    private final static FluentJdbc hive = HiveConnector.connectTo_MSS_Test_DB();
    private static final String IMPORT_ENTRY_NUMBER_3C = "IM003C";
    private static final String IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3 = "3";

    @Test
    public void readLinkTable() throws Exception {
        Optional<HubDeclarationLine> hubDeclarationLineOptional = HiveDataVaultTableReader.hubDeclarationLineForEntryReferenceItemNo(hive, IMPORT_ENTRY_NUMBER_3C, IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3);
        HubDeclarationLine hubDeclarationLine = hubDeclarationLineOptional.orElse(null);
        assertThat(hubDeclarationLine, is(notNullValue()));

        Optional<LinkDeclarationLineOriginCountry> linkDeclarationLineOriginCountryOptional = HiveDataVaultTableReader.linkDeclarationLineOriginCountryForLineAndCountry(hive, hubDeclarationLine.getHub_declaration_line_key(), "DE");
        LinkDeclarationLineOriginCountry linkDeclarationLineOriginCountry = linkDeclarationLineOriginCountryOptional.orElse(null);

        assertThat(linkDeclarationLineOriginCountry, is(notNullValue()));
    }

}