package uk.gov.gsi.hmrc.cds.dar.automation.framework.hive;

import org.codejargon.fluentjdbc.api.FluentJdbc;
import org.junit.Ignore;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.HiveConnector;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi.PDIStage;

/**
 * Created by smalavalli on 21/02/17.
 */
@Ignore
public class HiveDBManagerTest {

    //TODO - add assertions
    @Test
    public void createMssTablesforDB() throws Exception {
        HiveDBManager
                .connect(HiveConnector.connectTo_MSS_SM_DB())
                .createMSSTables("mss_sm");
    }

    @Test
    public void dropAllTableforDB() throws Exception {
        HiveDBManager
                .connect(HiveConnector.connectToDataBase())
                .dropAllTables();
    }

    @Test
    public void name() throws Exception {
        FluentJdbc hive = HiveConnector.connectTo_MSS_Test_DB();
        PDIStage.POPULATE_DATA_VAULT.truncateTablesInStage(hive);

    }
}