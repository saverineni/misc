package uk.gov.gsi.hmrc.cds.dar.automation.framework.helper;

import org.junit.Ignore;
import org.junit.Test;

import static org.junit.Assert.*;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.FASTP.FASTP_2;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.PropertyConfiguration.config;

/**
 * Created by smalavalli on 21/02/17.
 */
@Ignore
public class SFTPHelperTest {
    SFTPHelper sftpHelper = new SFTPHelper();

    @Test
    public void fileDoesNotExists() throws Exception {
        String hostMachine = FASTP_2.host();
        String userName = config().getString("fastp.username");
        String ftpPath = config().getString("data.file.ftp.path");
        String landingMssHeadersDeclarationTable = "landing_mss_headers_declaration";

        String filePath = String.format("%s/%s/%s.sqls", ftpPath, landingMssHeadersDeclarationTable, landingMssHeadersDeclarationTable);
        boolean fileExists = sftpHelper.fileExists(hostMachine, userName, 22, filePath);

        assertFalse(fileExists);
    }

}