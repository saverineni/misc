package uk.gov.gsi.hmrc.cds.dar.automation.framework.connection;

import com.google.common.base.Joiner;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion.mss.MSSDataIngestHelper;

import java.util.List;

import static java.util.stream.Collectors.toList;
import static org.junit.Assert.*;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.PropertyConfiguration.config;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.HiveDBManager.DEFAULT_TEST_DB;

/**
 * Created by smalavalli on 21/02/17.
 */
@Ignore
public class RemoteMachineConnectorTest {
    private RemoteMachineConnector.RemoteMachine remoteMachine;
    private String ftpPath = config().getString("data.file.ftp.path");
    private String landingMssHeadersDeclarationTable = "landing_mss_headers_declaration";

    @Before
    public void setUp() throws Exception {
        remoteMachine = RemoteMachineConnector.connectToDockerClouderaServer();
    }

    @Test
    public void remoteConnectionToDockerDev() throws Exception {
        String baseFilePath = config().getString("data.file.ftp.path");
        String tableDataFilePathTemplate = "%s/%s.csv";
        String loadDataCommandTemplate = "load data local inpath \\\"%s\\\" into table %s.%s";
        List<String> tableNames = MSSDataIngestHelper.fetchIngestTableList().collect(toList());
        List<String> loadDataCommandList = tableNames.stream().map(tableName -> {
            String dataFilePath = String.format(tableDataFilePathTemplate, baseFilePath, tableName);
            return String.format(loadDataCommandTemplate, dataFilePath, DEFAULT_TEST_DB, tableName);
        }).collect(toList());

        String loadDataInpathCommand = Joiner.on(";").join(loadDataCommandList);

        String scriptToLoadDataIntoTables = String.format("sudo su - hdfs -c \"hive -e '%s;'\"", loadDataInpathCommand);
        remoteMachine.executeScriptAsSudo(scriptToLoadDataIntoTables);

//        remoteMachine.executeScriptAsSudo("sudo su - root -c \"touch test_root.log\"");
//        String shellOuptput = remoteMachine.executeCommandsInShell(Lists.newArrayList("sudo -i","ls -la"));
//        String shellOuptput = remoteMachine.executeCommandsInShell(Lists.newArrayList("sudo -i","sudo su - hdfs", "hdfs dfs -ls /user/hive/warehouse"));
//        System.err.println(shellOuptput);
    }

    @Test
    public void fileExists() throws Exception {
        String filePath = String.format("%s/test.log", ftpPath);

        boolean fileExists = remoteMachine.fileExists(filePath);
        assertTrue(fileExists);
    }

    @Test
    public void fileDoesNotExists() throws Exception {
        String filePath = String.format("%s/%s/%s.sqls", ftpPath, landingMssHeadersDeclarationTable, landingMssHeadersDeclarationTable);

        boolean fileExists = remoteMachine.fileExists(filePath);
        assertFalse(fileExists);
    }

}