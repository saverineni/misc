package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest;

import org.codejargon.fluentjdbc.api.FluentJdbc;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.DOCKER_MACHINE;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.connection.HiveConnector;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.runner.TestRunner;

import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.PropertyConfiguration.config;

/**
 * Created by smalavalli on 27/01/17.
 */
@RunWith(TestRunner.class)
public abstract class BaseIntegrationTest implements TestConstants {
    private static Logger logger = LoggerFactory.getLogger(BaseIntegrationTest.class);

    private final static String MDC_DB_KEY = "db_name";
    private final static String MDC_DOCKER_ENV_KEY = "docker_env";
    protected static FluentJdbc hive;
    protected static DOCKER_MACHINE envDocker;

    public static void init(String databaseName) {
        MDC.put(MDC_DB_KEY, databaseName);
        hive = HiveConnector.connectToDataBase();
        logger.info("Connected to Hive DB '{}'", databaseName);
    }

    public static void initExecutionEnv(String executionEnv) {
        switch (executionEnv) {
            case DOCKER_DEV:
                envDocker = DOCKER_MACHINE.DEV;
                break;
            case DOCKER_AUTOMATION_DEV:
                envDocker = DOCKER_MACHINE.AUTOMATION_DEV;
                break;
            case DOCKER_QA:
                envDocker = DOCKER_MACHINE.QA;
                break;
            case DOCKER_DEMO_1:
                envDocker = DOCKER_MACHINE.DEMO_1;
                break;
            case DOCKER_DEMO_2:
                envDocker = DOCKER_MACHINE.DEMO_2;
                break;
            default:
                envDocker = DOCKER_MACHINE.DEV;
                break;
        }
        MDC.put(MDC_DOCKER_ENV_KEY, envDocker.name());
        logger.info("Docker execution env - '{} ({})'", envDocker.name(), envDocker.host());
    }

    public static void init() {
        String testDbName = config().getString("test.db.name");
        String executionEnv = config().getString("execution.env");
        initExecutionEnv(executionEnv); // This has to be called before initializing the db, since the execution env has to be determined to connect to Hive Server.
        init(testDbName);
    }
}
