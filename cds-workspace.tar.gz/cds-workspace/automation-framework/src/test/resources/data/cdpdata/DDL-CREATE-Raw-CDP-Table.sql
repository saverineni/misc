# NOTE: Each DDL query SHOULD be in ONE line only. Follow the convention.
CREATE TABLE IF NOT EXISTS %s.raw_cdp_declaration(
entryno                 string
,entryversionno         string
,entrytype              string
,icscode                string
,mrn                    string
,cpc                    string
,epu                    string
,entrydate              string
,acceptancedate         string
,declarant              struct<id:string
,name:string
,street:string
,city:string
,postcode:string
,country:string>
,declaranttype          string
,masterucr              string
,declarationucr         string
,firdan                 string
,firdanprefix           string
,additionaldeclarationtype      string
,representativestatuscode       string
,nationalityofactivemeansoftransportcrossingtheborder   string
,declarationlines       array<struct<itemno:string
,commoditycode:string
,clearancedate:string
,consignor:struct<id:string
,name:string
,street:string
,city:string
,postcode:string
,country:string>
,consignee:struct<id:string
,name:string
,street:string
,city:string
,postcode:string
,country:string>
,goodslocation:string
,premisesid:string
,dispatchcountry:string
,destinationcountry:string
,itemprice:string
,itemcustomsvalue:string
,itemvatvalue:string
,customscheck:string
,itemcustomsdutypaid:string
,taxpointdate:string
,goodsdeparturedate:string
,customsroute:string
,descriptionofgoods:string
,permissiontoprogressdate:string
,typeofpackagescode:string
,numberofpackages:string
,additionalprocedure:string
,requestedprocedure:string
,previousprocedure:string
,shippingmarks:string
,documenttype:string
,previousdocument:string
,previousdocumentreference:string
,inlandmodeoftransport:string
,countryofdispatchexportcode:string>>
)
PARTITIONED BY (ingestion_date         string)
