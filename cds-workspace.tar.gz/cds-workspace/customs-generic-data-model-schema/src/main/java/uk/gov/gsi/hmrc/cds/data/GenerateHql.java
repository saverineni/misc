package uk.gov.gsi.hmrc.cds.data;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GenerateHql {

    private static Logger logger = LoggerFactory.getLogger(GenerateHql.class);

    public static void main(String args[]) {
        GenerateHql sql = new GenerateHql();
        String sqlFilePath = System.getProperty("sqlfilepath");
        sql.generateHqlFromSQL(sqlFilePath);
    }

    public void generateHqlFromSQL(String sqlFilePath) {
        logger.info("*********Started Converting SQL file to hive HQL***********");
        String filePath = FilenameUtils.getFullPath(sqlFilePath);

       try{
            new HiveGenerator().generateHiveHql(filePath, "DataVault_MySQLWB.sql");
            logger.info("*********Finished creating hive HQL***********");
        } catch (Exception e) {
            logger.error("Exception occurred " + e);
        }
    }

}