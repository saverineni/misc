package uk.gov.gsi.hmrc.cds.data;

import ch.vorburger.exec.ManagedProcessException;
import ch.vorburger.mariadb4j.DB;
import ch.vorburger.mariadb4j.DBConfigurationBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class HiveGenerator {

    public static final String CONNECTION_STRING = PropertiesFileUtil.getProperty("CONNECTION_STRING");
    public static final String DB_NAME = PropertiesFileUtil.getProperty("DB_NAME");
    public static final String USERNAME = PropertiesFileUtil.getProperty("USERNAME");
    public static final int PORT = PropertiesFileUtil.getIntProperty("PORT");
    public static final String DRIVER = PropertiesFileUtil.getProperty("DRIVER");
    private static Logger logger = LoggerFactory.getLogger(HiveGenerator.class);

    public void generateHiveHql(String resourcePath, String sqlFileName) throws ManagedProcessException, SQLException, IOException {
        DBConfigurationBuilder configBuilder = DBConfigurationBuilder.newBuilder().setPort(PORT);
        DB db = DB.newEmbeddedDB(configBuilder.build());
        db.start();
        try (Connection conn = DriverManager.getConnection(configBuilder.getURL(""), USERNAME, "")) {
            String StringSQLFile = new String(Files.readAllBytes(Paths.get(resourcePath+sqlFileName)));
            db.run(StringSQLFile, USERNAME, null, null);
            logger.info("*********Started creating HQL***********");
            new SqoopClient().runSqoop(resourcePath, sqlFileName.substring(0, sqlFileName.lastIndexOf(".")) + ".q");
        } finally {
            db.stop();
        }

    }


}