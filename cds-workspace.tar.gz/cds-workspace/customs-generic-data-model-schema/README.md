usage
  mvn clean deploy -DskipTests=true -Dsqlfilepath=/home/osboxes/Documents/
  
Notes
  This project will kick off whenever .mwb is updated and pushed. The code will generate Mysql DDl SQL script from the .mwb file and loads to in-memory database 
  then the code connects to in-memory database using sqoop and generates Hive HQL schema file and finally uploads the artifact tar.gz(.mwb file and Hive HQL file) to nexus.

  Now the sql generation part is extracted outside the this project, jenkins will call the shell script of this project directly.


Test data generation for the created Hive schema is deferred.
