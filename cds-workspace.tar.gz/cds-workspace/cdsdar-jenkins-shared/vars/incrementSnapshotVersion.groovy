#!/usr/bin/env groovy

// possible 'versionLevel' values -> 'major', 'minor', 'patch'. Default to 'patch'
def call(String version, String versionLevel = 'patch') {
    validateSnapshotVersionFormat(version)

    def SNAPSHOT = "-SNAPSHOT"
    def versionNumber = version.replace(SNAPSHOT, "")
    def versionValues = versionNumber.split('\\.')
    def majorVersion = versionValues[0].toInteger()
    def minorVersion = versionValues[1].toInteger()
    def patchVersion = versionValues[2].toInteger()

    switch (versionLevel.toLowerCase()) {
        case 'major':
            majorVersion = versionValues[0].toInteger() + 1
            break
        case 'minor':
            minorVersion = versionValues[1].toInteger() + 1
            break
        case 'patch':
            patchVersion = versionValues[2].toInteger() + 1
            break
        default:
            patchVersion = versionValues[2].toInteger() + 1
            break
    }
    return "${majorVersion}.${minorVersion}.${patchVersion}${SNAPSHOT}"
}