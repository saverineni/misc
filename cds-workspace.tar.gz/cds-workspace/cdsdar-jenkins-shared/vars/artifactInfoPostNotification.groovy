#!/usr/bin/env groovy

def call(String artifactVersion, String moduleName, String env) {
    String dashboardUrl = "http://10.102.82.66:3030/widgets/${moduleName}-${env}"
    String notificationPayloadAsJson = buildArtifactInfoNotificationJson(artifactVersion)
    log(notificationPayloadAsJson)

    def response = httpRequest url: dashboardUrl, contentType: 'APPLICATION_JSON', httpMode: 'POST', requestBody: notificationPayloadAsJson, timeout: 5
    return response
}