#!/usr/bin/env groovy

def call(String releaseBranch) {
    def matcher = (releaseBranch =~ regExReleaseBranch())
    if(!matcher.matches()) {
        throw new Exception("Invalid release branch format ${releaseBranch}, Expected Format -> release/0.0.0")
    }
    return matcher.matches()
}