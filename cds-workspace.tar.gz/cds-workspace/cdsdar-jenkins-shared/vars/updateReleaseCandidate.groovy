#!/usr/bin/env groovy

def call(String releaseBranch, String version) {
    sshagent([jenkinsCredentialCdsdataBitbucket()]) {
        script {
            updateGitBranch(releaseBranch)
            def releaseCandidateVersion = incrementReleaseCandidateVersion(version)
            sh "mvn versions:set -DnewVersion=${releaseCandidateVersion} -DoldVersion=${version} -DgenerateBackupPoms=false"
            sh "git commit -am 'JENKINS: Updated RC version' || true"
            sh "git push origin ${releaseBranch}"
        }
    }

}