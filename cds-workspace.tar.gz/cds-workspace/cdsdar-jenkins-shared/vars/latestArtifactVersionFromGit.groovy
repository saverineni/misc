#!/usr/bin/env groovy

def call(String submoduleName, String gitURL, String gitBranch) {
    def version = ''
    dir(env.WORKSPACE + "/${submoduleName}") {
        deleteDir()
        gitCheckoutRecursive(gitURL, gitBranch)
        refreshGitSubmodules(gitBranch)
        version = readProjectVersionFromPom()
    }

    return version
}