#!/usr/bin/env groovy

def call(String version) {
    validateSnapshotVersionFormat(version)

    def SNAPSHOT = "-SNAPSHOT"
    def versionNumber = version.replace(SNAPSHOT, "")
    return "release/${versionNumber}"
}