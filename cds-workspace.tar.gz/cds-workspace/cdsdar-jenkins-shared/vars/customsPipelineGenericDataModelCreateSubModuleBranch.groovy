#!/usr/bin/env groovy

def call(String customs_pipeline_generic_data_model_release_branch) {
    def customs_pipeline_submodule_generic_data_model_pdi = 'generic-data-model-pdi'
    validateReleaseBranchFormat(customs_pipeline_generic_data_model_release_branch)
    createSubModuleBranch(customs_pipeline_generic_data_model_release_branch, customs_pipeline_submodule_generic_data_model_pdi)

}
