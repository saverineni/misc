#!/usr/bin/env groovy

def call() {
    sh '''
        cat << EOF > src/test/resources/secure.properties
        ssh.private.key=$FILE
        ssh.pass.phrase=bitbucket
        fastp.username=cdsdata
        hive.server2.username=cdsdata
        hive.server2.password=pleasechangeme
        EOF
    '''
}
