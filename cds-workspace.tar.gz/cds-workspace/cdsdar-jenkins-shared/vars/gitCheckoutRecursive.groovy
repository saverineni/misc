#!/usr/bin/env groovy

def call(String gitRepository, String branch = 'develop') {
    checkout([
            $class                           : 'GitSCM',
            branches                         : [[name: '*/' + branch]],
            doGenerateSubmoduleConfigurations: false,
            extensions                       : [
                    [$class: 'SubmoduleOption', disableSubmodules: false, parentCredentials: true, recursiveSubmodules: true, reference: '', trackingSubmodules: true],
                    [$class: 'UserExclusion', excludedUsers: '''Jenkins Continuous Integration Server\nJenkins'''],
                    [$class: 'LocalBranch', localBranch: branch]
            ],
            submoduleCfg                     : [],
            userRemoteConfigs                : [[
                                                        credentialsId: jenkinsCredentialCdsdataBitbucket(),
                                                        url          : gitRepository
                                                ]]
    ])
}