#!/usr/bin/env groovy

def call(String customs_pipeline_landing_release_branch) {

    validateReleaseBranchFormat(customs_pipeline_landing_release_branch)

    for (String submodule : customsPipelineLandingSubmodules()) {
        createSubModuleBranch(customs_pipeline_landing_release_branch, submodule)
    }
}
