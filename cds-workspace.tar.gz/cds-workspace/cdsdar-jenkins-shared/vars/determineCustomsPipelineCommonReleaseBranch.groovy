#!/usr/bin/env groovy

def call() {
    def customsPipelineCommonReleaseBranch = ''
    dir(env.WORKSPACE + "/customs_pipeline_landing") {
        sshagent([jenkinsCredentialCdsdataBitbucket()]) {
            script {
                gitCheckoutRecursive("ssh://git@10.102.81.191:7999/cdsd/customs-pipeline-landing.git")
                def customs_pipeline_landing_develop_version = readProjectVersionFromPom()
                validateSnapshotVersionFormat(customs_pipeline_landing_develop_version)

                def SNAPSHOT = "-SNAPSHOT"
                def customs_pipeline_landing_rc_version = decrementSnapshotVersion(customs_pipeline_landing_develop_version).replace(SNAPSHOT, "")
                customsPipelineCommonReleaseBranch = "release/${customs_pipeline_landing_rc_version}"
            }
        }
    }
    if (customsPipelineCommonReleaseBranch == '') {
        throw new Exception("Customs Pipeline Common release branch cannot be determined. Check GIT!!")
    }
    return customsPipelineCommonReleaseBranch
}