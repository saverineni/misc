#!/usr/bin/env groovy

def call(String version) {
    return "${env.JOB_BASE_NAME}-${currentBuild.number}-v${version}"
}
