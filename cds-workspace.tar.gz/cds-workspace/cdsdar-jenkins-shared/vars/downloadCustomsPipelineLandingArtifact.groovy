#!/usr/bin/env groovy

def call(String artifactVersion) {
    log("${artifactVersion}")

    def landingArtifactURL = "http://10.102.81.194:8081/nexus/service/local/repositories/releases/content/uk/gov/gsi/hmrc/cds/data/customs-pipeline-landing/${artifactVersion}/customs-pipeline-landing-${artifactVersion}-landing.tar.gz"
    def fileName = "customs-pipeline-landing.tar.gz"

    downloadArtifact(landingArtifactURL, fileName)
}