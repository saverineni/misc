#!/usr/bin/env groovy

def call() {
    script {
        customs_pipeline_artifact_versions_json = groovy.json.JsonOutput.toJson([
                [customs_pipeline_version   : "${customs_pipeline_version}",
                 customs_pipeline_artifactId: "${customs_pipeline_artifactId}",
                 customs_pipeline_groupId   : "${customs_pipeline_groupId}"
                ],
                [customs_pipeline_landing_version   : "${customs_pipeline_landing_version}",
                 customs_pipeline_landing_artifactId: "${customs_pipeline_landing_artifactId}",
                 customs_pipeline_landing_groupId   : "${customs_pipeline_landing_groupId}"
                ],
                [customs_pipeline_generic_data_model_version   : "${customs_pipeline_generic_data_model_version}",
                 customs_pipeline_generic_data_model_artifactId: "${customs_pipeline_generic_data_model_artifactId}",
                 customs_pipeline_generic_data_model_groupId   : "${customs_pipeline_generic_data_model_groupId}"
                ],
                [customs_pipeline_exploitation_report_version   : "${customs_pipeline_exploitation_report_version}",
                 customs_pipeline_exploitation_report_artifactId: "${customs_pipeline_exploitation_report_artifactId}",
                 customs_pipeline_exploitation_report_groupId   : "${customs_pipeline_exploitation_report_groupId}"
                ]
        ]);
        echo "${customs_pipeline_artifact_versions_json}"
    }

}