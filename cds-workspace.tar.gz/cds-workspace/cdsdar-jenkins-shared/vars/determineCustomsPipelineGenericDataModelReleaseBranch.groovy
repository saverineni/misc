#!/usr/bin/env groovy

def call() {
    def customsPipelineGenericDataModelReleaseBranch = ''
    dir(env.WORKSPACE + env.customs_pipeline_generic_data_model_location) {
        sshagent([jenkinsCredentialCdsdataBitbucket()]) {
            script {
                gitCheckoutRecursive("ssh://git@10.102.81.191:7999/cdsd/customs-pipeline-generic-data-model.git")
                def customs_pipeline_generic_data_model_develop_version = readProjectVersionFromPom()
                validateSnapshotVersionFormat(customs_pipeline_generic_data_model_develop_version)

                def SNAPSHOT = "-SNAPSHOT"
                def customs_pipeline_generic_data_model_rc_version = decrementSnapshotVersion(customs_pipeline_generic_data_model_develop_version).replace(SNAPSHOT, "")
                customsPipelineGenericDataModelReleaseBranch = "release/${customs_pipeline_generic_data_model_rc_version}"
            }
        }
    }
    if (customsPipelineGenericDataModelReleaseBranch == '') {
        throw new Exception("Customs Pipeline Generic Data Model release branch cannot be determined. Check GIT!!")
    }
    return customsPipelineGenericDataModelReleaseBranch
}