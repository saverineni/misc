#!/usr/bin/env groovy

def call(String commandLine) {
    String sbtArguments = "-Dsbt.override.build.repos=true -Dsbt.ivy.home=${env.workspaceDir}/.ivy2/ -Divy.home=${env.workspaceDir}/.ivy2/"
    sh "sbt ${sbtArguments} ${commandLine}"
}