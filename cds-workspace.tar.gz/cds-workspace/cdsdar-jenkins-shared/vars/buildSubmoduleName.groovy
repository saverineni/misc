#!/usr/bin/env groovy

def call(String gitBranch, String submoduleName) {
    script {
        sh "echo ${gitBranch}"
        sh "echo ${submoduleName}"
    }
    def suffix = ''
    switch (gitBranch) {
        case 'develop':
            break
        case 'master':
            suffix = '-master'
            break
        default:
            validateReleaseBranchFormat(gitBranch)
            def matcher = gitBranch =~ regExReleaseBranch()
            suffix = "-${ matcher[0][2]}"
            break
    }
    return "${submoduleName}${suffix}"
}