#!/usr/bin/env groovy

def call() {
    return "^(\\d{1,}+\\.)+(\\d{1,}+\\.)+(\\d{1,})?(.*)"
}