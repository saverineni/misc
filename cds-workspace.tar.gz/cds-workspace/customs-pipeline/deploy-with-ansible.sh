#!/bin/bash

# The command line variable order is the same as deploy-from-nexus.sh
#---------------------------------------------------------------------------------------------------------------
#
# Parameters:
#
# $1 = VERSION
# $2 = DEPLOY_USER i.e. the user that will own the files on the box
# $3 = SERVER i.e. where to deploy to
# $4 = SYMLINK i.e. what we will link the release as (e.g. dev, qa etc)
#
#---------------------------------------------------------------------------------------------------------------
#
# Additionally, the path on disk to the ansible-deploy script git repo must be specified
DEFAULT_ANSIBLE_SCRIPT_PATH=~/dev/dev-tools

version=$1
artifact_classifier_string=$2 # comma-separated if more than one classifier e.g. bin,generic-data-model
user_to_run_as=$3
variable_host=$4
environment_name=$5

if [[ "$1" == "" || "$2" == "" || "$3" == "" || "$4" == "" || "$5" == "" ]]; then
	echo "Command line parameters missing"
	echo "Usage: $(basename $0) <version> <artifact_classifier_string> <deploy user> <server> <symlink>"
	exit 1
fi

if [[ "$5" != "" ]]; then
	ansible_deploy_scripts_path=$6
else
	ansible_deploy_scripts_path=$DEFAULT_ANSIBLE_SCRIPT_PATH
fi

ansible-playbook -e " \
pentaho_scripts_version=$version \
artifact_classifier_string=$artifact_classifier_string \
user_to_run_as=$user_to_run_as \
variable_host=$variable_host \
environment_name=$environment_name \
" -i $ansible_deploy_scripts_path/ansible/hosts --limit=$variable_host --tags standing_data_csv,pentaho_scripts $ansible_deploy_scripts_path/ansible/deploy-demo/deploy.yml
