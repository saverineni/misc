There was a need to create controlled and well determined test MSS data. In order to ease the technical requirements for the business analysts, this test data was generated in the form of an Excel spreadsheet that should then be ingested into hive tables.

This ticket tracks the progress of development of a tool that reads the aforementioned spreadsheet and save the data in hive tables in the mss_test_generated database.

# Acceptance criteria #

   - The tool can read the Excell files;
   - The tool can recreate the generated tables;
   - The tool populates the tables with the data extracted from the Excel spreadsheet.

Currently, the tool process capabilities are tied to the structure of the Excel file.

The tool read the file TEST\_DATA\_FILE, if it exists, from the TEST\_DATA\_PATH folder.
After a successfull processing, the HIVE\_DB database should have its data replaced by that of the file, and the file will have been timestamped and moved to the DATA\_ARCHIVE\_PATH folder

The process is controlled by a configuration file that, for data being dropped in fastp1 at /data/drop/mss\_test\_generated/inbox,  should look like:
~~~~~
HIVE_HOST = 10.102.83.77
HIVE_PORT = 10000
HIVE_USER = cdsdata
HIVE_PASS = cdsdata
HIVE_DB = mss_test_generated

TEST_DATA_FILE=sample_data.xlsx
TEST_DATA_PATH=/data/drop/mss_test_generated/inbox
DB_DATA_PATH=/data/mss/generated
DATA_ARCHIVE_PATH=/data/drop/mss_test_generated/archive
~~~~~

