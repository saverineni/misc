#!/bin/sh

usage() {
    echo 'usage : Script <absolute_path_to_cds_generic_data_model_blueprint_project> <absolute_path_to_pentaho_work_project>'
    exit
}

if [ "$#" -ne 13 ]
then
    usage
fi

cds_generic_data_model_blueprint_project_path=$1
pentaho_work_project_path=$2

cd $cds_generic_data_model_blueprint_project_path
mv $cds_generic_data_model_blueprint_project_path/src/main/resources/MySQLWorkBench/DataVault_MySQLWB.mwb $cds_generic_data_model_blueprint_project_path/src/main/resources/MySQLWorkBench/DataVault_MySQLWB.zip
