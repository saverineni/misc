-- --
-- Commodity Code dimension
-- --

-- DROP TABLE IF EXISTS `${EXPLOIT_DB}`.commodity_code_csv_file PURGE;
-- DROP TABLE IF EXISTS `${EXPLOIT_DB}`.${DIMENSION_NAME} PURGE;

CREATE EXTERNAL TABLE IF NOT EXISTS `${EXPLOIT_DB}`.commodity_code_csv_file
(
  cc_year    STRING,
  cc_month   STRING,
  hs_chapter STRING,
  hs_heading STRING,
  hs_chapter_heading STRING,
  hs_subheading      STRING,
  hs_code            STRING,
  cn_subheading      STRING,
  commodity_code     STRING,
  taric_subheading   STRING,
  taric_additional   STRING,
  sitc_no            STRING,
  sitc_indentations  STRING,
  sitc_conv_a        STRING,
  units              STRING,
  quantity_code      STRING,
  chapter_description STRING,
  heading_description STRING,
  subheading_description STRING,
  commodity_description STRING
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001'
LOCATION '${HDFS_DIM_DATA_PATH}/commodity_codes/';

CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.${TABLE_NAME} AS
SELECT DISTINCT
  cc_year,
  cc_month,
  hs_chapter,
  hs_heading,
  hs_chapter_heading,
  hs_subheading,
  hs_code,
  chapter_description,
  heading_description,
  subheading_description
FROM `${EXPLOIT_DB}`.commodity_code_csv_file;
