-- --
-- currency dimension
-- --

-- DROP TABLE IF EXISTS `${EXPLOIT_DB}`.currency_dimension_csv_file PURGE;
-- DROP TABLE IF EXISTS `${EXPLOIT_DB}`.${DIMENSION_NAME} PURGE;

-- External table from data CSV
-- NOTE: CSV SerDe always uses string, will cast later
CREATE EXTERNAL TABLE IF NOT EXISTS `${EXPLOIT_DB}`.currency_dimension_csv_file
(
  currency_id STRING,
  currency_iso_code STRING,
  currency_name STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
LOCATION '${HDFS_DIM_DATA_PATH}/currencies/';

-- Create dimension
-- Do not INSERT data that is already present
CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.${TABLE_NAME}
(
  currency_id STRING,
  currency_iso_code STRING,
  currency_name STRING
);
INSERT INTO `${EXPLOIT_DB}`.${TABLE_NAME}
SELECT
  c.currency_id,
  c.currency_iso_code,
  c.currency_name
FROM
  `${EXPLOIT_DB}`.currency_dimension_csv_file c
LEFT OUTER JOIN
  `${EXPLOIT_DB}`.dim_currency d_c ON c.currency_id = d_c.currency_id
WHERE d_c.currency_id IS NULL;