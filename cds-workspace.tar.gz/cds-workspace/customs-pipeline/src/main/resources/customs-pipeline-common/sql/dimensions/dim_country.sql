-- --
-- Country dimension
-- --

-- DROP TABLE IF EXISTS `${EXPLOIT_DB}`.country_dimension_csv_file PURGE;
-- DROP TABLE IF EXISTS `${EXPLOIT_DB}`.${DIMENSION_NAME} PURGE;

-- External table from data CSV
-- NOTE: CSV SerDe always uses string, will cast later
CREATE EXTERNAL TABLE IF NOT EXISTS `${EXPLOIT_DB}`.country_dimension_csv_file
(
  country_id STRING,
  country_iso_code STRING,
  country_name STRING,
  country_sequence_number STRING,
  country_comments STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
LOCATION '${HDFS_DIM_DATA_PATH}/countries/';

-- Create dimension
-- Do not INSERT data that is already present
CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.${TABLE_NAME}
(
  country_id STRING,
  country_iso_code STRING,
  country_name STRING,
  country_sequence_number STRING,
  country_comments STRING
);
INSERT INTO `${EXPLOIT_DB}`.${TABLE_NAME}
SELECT
  c.country_id,
  c.country_iso_code,
  c.country_name,
  c.country_sequence_number,
  c.country_comments
FROM
  `${EXPLOIT_DB}`.country_dimension_csv_file c
LEFT OUTER JOIN
  `${EXPLOIT_DB}`.dim_country d_c ON c.country_id = d_c.country_id
WHERE d_c.country_id IS NULL;
