-- Create a unified landing area for headers and lines independent of source.

-- Cleanup
DROP TABLE IF EXISTS `${EXPLOIT_DB}`.`landing_headers_declaration` PURGE;
DROP TABLE IF EXISTS `${EXPLOIT_DB}`.`landing_lines_declaration` PURGE;
DROP TABLE IF EXISTS `${EXPLOIT_DB}`.`landing_trader` PURGE;
DROP TABLE IF EXISTS `${EXPLOIT_DB}`.`landing_line_document` PURGE;
DROP TABLE IF EXISTS `${EXPLOIT_DB}`.`landing_line_additional_information` PURGE;
DROP TABLE IF EXISTS `${EXPLOIT_DB}`.`landing_line_tax_line` PURGE;
DROP TABLE IF EXISTS `${EXPLOIT_DB}`.`landing_line_previous_document` PURGE;


CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.`landing_headers_declaration`
AS
SELECT * FROM `${EXPLOIT_DB}`.`landing_mss_headers_declaration`
-- UNION ALL
-- SELECT * FROM `${EXPLOIT_DB}`.`landing_cdp_headers_declaration`
;

CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.`landing_lines_declaration`
AS
SELECT * FROM `${EXPLOIT_DB}`.`landing_mss_lines_declaration`
-- UNION ALL
-- SELECT * FROM `${EXPLOIT_DB}`.`landing_cdp_lines_declaration`
;

CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.`landing_trader`
AS
SELECT * FROM `${EXPLOIT_DB}`.`landing_mss_trader`
-- UNION ALL
-- SELECT * FROM `${EXPLOIT_DB}`.`landing_cdp_trader`
;

CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.`landing_line_additional_information`
AS
SELECT * FROM `${EXPLOIT_DB}`.`landing_mss_line_additional_information`
-- UNION ALL
-- SELECT * FROM `${EXPLOIT_DB}`.`landing_cdp_line_additional_information`
;

CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.`landing_line_document`
AS
SELECT * FROM `${EXPLOIT_DB}`.`landing_mss_line_document`
-- UNION ALL
-- SELECT * FROM `${EXPLOIT_DB}`.`landing_cdp_line_document`
;

CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.`landing_line_tax_line`
AS
SELECT * FROM `${EXPLOIT_DB}`.`landing_mss_line_tax_line`
-- UNION ALL
-- SELECT * FROM `${EXPLOIT_DB}`.`landing_cdp_line_tax_line`
;


CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.`landing_line_previous_document`
AS
SELECT * FROM `${EXPLOIT_DB}`.`landing_mss_line_previous_document`
-- UNION ALL
-- SELECT * FROM `${EXPLOIT_DB}`.`landing_cdp_line_previous_document`
;

