--
-- The following statements ingest data from the MSS source into table
-- landing_mss_line_add_info
--

-- Cleanup
DROP TABLE IF EXISTS `${EXPLOIT_DB}`.landing_mss_line_additional_information PURGE;

--
-- Read the additional information relating to both import and export
-- declaration lines. The generation number is defaulted to 1 for
-- imports. This will be an attribute of the satellite rathering than
-- forming part of the business key.

CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.landing_mss_line_additional_information AS
-- Import additional info
SELECT
    'mss'                                           AS source,
    from_unixtime(unix_timestamp(), 'yyyy-MM-dd')   AS ingestion_date,
    iiai.IEITNO                                     AS item_number,
    iiai.AISTMTSNO                                  AS additional_information_sequence_number,
    '1'                                             AS generation_number,
    iiai.AISTMT                                     AS additional_information_statement,
    iiai.AISTMTTYPE                                 AS additional_information_statement_type,
    iiai.ITEMAISTMT                                 AS item_additional_information_statement,
    UPPER(CONCAT(imp_s.EPUNO, '-', imp_s.IMPENTNO, '-', SUBSTR(imp_s.STANDARD_DTOFENT, 1, 10))) AS entry_reference
FROM `${MSS_DB}`.IMENSELECT imp_s JOIN `${MSS_DB}`.IIAI iiai    ON imp_s.IEKEY = iiai.IEKEY
UNION ALL
-- Export documents
SELECT
    'mss'                                           AS source,
    from_unixtime(unix_timestamp(), 'yyyy-MM-dd')   AS ingestion_date,
    nxiai.IEITNO                                    AS item_number,
    nxiai.AISTMTSNO                                 AS additional_information_sequence_number,
    exp_s.GENERATIONNO                              AS generation_number,
    nxiai.AISTMT                                    AS additional_information_statement,
    nxiai.AISTMTTYPE                                AS additional_information_statement_type,
    nxiai.ITEMAISTMT                                AS item_additional_information_statement,
    UPPER(CONCAT(exp_s.EPUNO, '-', exp_s.IMPENTNO, '-', SUBSTR(exp_s.STANDARD_DTOFENT, 1, 10))) AS entry_reference
FROM `${MSS_DB}`.NXENSELECT exp_s JOIN `${MSS_DB}`.NXIAI nxiai  ON exp_s.IEKEY = nxiai.IEKEY
                                                               AND exp_s.GENERATIONNO = nxiai.GENERATIONNO;
