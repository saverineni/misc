--
-- The following statements ingest data from the MSS source into table
-- landing_mss_line_tax_line
--

-- Cleanup
DROP TABLE IF EXISTS `${EXPLOIT_DB}`.landing_mss_line_tax_line PURGE;

--
-- Read the tax line information relating to both import and export
-- declaration lines. The generation number is defaulted to 1 for
-- imports. This will be an attribute of the satellite rathering than
-- forming part of the business key.

CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.landing_mss_line_tax_line AS
-- Import tax lines
SELECT
    'mss'                                           AS source,
    from_unixtime(unix_timestamp(), 'yyyy-MM-dd')   AS ingestion_date,
    iitl.IEITNO                                     AS item_number,
    iitl.ITLNSNO                                    AS tax_line_sequence_number,
    '1'                                             AS generation_number,
    iitl.ITLNWVDTAX                                 AS waived_tax,
    iitl.MOPCODE                                    AS method_of_payment_code,
    iitl.TAXAMT                                     AS tax_amount,
    iitl.TTYCODE                                    AS tax_type_code,
    UPPER(CONCAT(imp_s.EPUNO, '-', imp_s.IMPENTNO, '-', SUBSTR(imp_s.STANDARD_DTOFENT, 1, 10))) AS entry_reference
FROM `${MSS_DB}`.IMENSELECT imp_s JOIN `${MSS_DB}`.IITL iitl    ON imp_s.IEKEY = iitl.IEKEY
UNION ALL
-- Export tax lines
SELECT
    'mss'                                           AS source,
    from_unixtime(unix_timestamp(), 'yyyy-MM-dd')   AS ingestion_date,
    nxitl.IEITNO                                    AS item_number,
    nxitl.ITLNSNO                                   AS tax_line_sequence_number,
    exp_s.GENERATIONNO                              AS generation_number,
    nxitl.ITLNWVDTAX                                AS waived_tax,
    nxitl.MOPCODE                                   AS method_of_payment_code,
    nxitl.TAXAMT                                    AS tax_amount,
    nxitl.TTYCODE                                   AS tax_type_code,
    UPPER(CONCAT(exp_s.EPUNO, '-', exp_s.IMPENTNO, '-', SUBSTR(exp_s.STANDARD_DTOFENT, 1, 10))) AS entry_reference
FROM `${MSS_DB}`.NXENSELECT exp_s JOIN `${MSS_DB}`.NXITL nxitl  ON exp_s.IEKEY = nxitl.IEKEY
                                                               AND exp_s.GENERATIONNO = nxitl.GENERATIONNO;
