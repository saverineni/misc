-- The following statements ingest data from the MSS source into tables
-- landing_mss_headers_declaration and landing_mss_lines_declaration
--

-- Cleanup
DROP TABLE IF EXISTS `${EXPLOIT_DB}`.landing_mss_headers_declaration PURGE;
DROP TABLE IF EXISTS `${EXPLOIT_DB}`.landing_mss_lines_declaration PURGE;
DROP TABLE IF EXISTS `${EXPLOIT_DB}`.landing_mss_trader PURGE;

-- Read from the imports tables
-- HEADERS
CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.landing_mss_headers_declaration AS
SELECT
    'mss'                                         AS source,
    from_unixtime(unix_timestamp(), 'yyyy-MM-dd') AS ingestion_date,
    imp_s.IMPENTNO                                AS entry_number,
    imp_s.STANDARD_DTOFENT                        AS entry_date,
    imp_s.EPUNO                                   AS epu_number,
    imp_s.IETYPE                                  AS entry_type,
    imp_s.DECLNMTHD                               AS declaration_method,
    imp_d.TOTEXCISE                               AS total_excise,
    imp_s.IMPTRTURN                               AS importer_turn,
    imp_s.DECLTTURN                               AS declarant_turn,
    imp_s.DECLTREP                                AS declarant_representative_turn,
    imp_d.cnsgeaeocerttycd                        AS consignee_AEO_certificate_type_code,
    imp_d.decltaeocerttycd                        AS declarant_AEO_certificate_type_code,
    imp_s.ROE                                     AS route,
    'I'                                           AS declaration_import_export_indicator,
    '1'                                           AS generation_number,
    NULL                                          AS exporter_turn,
    NULL                                          AS destination_country_code,
    imp_d.ICS                                     AS import_clearance_status,
    NULL                                          AS consignor_AEO_certificate_type_code,
    imp_d.STATVALUE                               AS header_statistical_value,
    CAST(NULL AS STRING)                          AS goods_departure_datetime,
    imp_s.CSTMSVALUE                              AS customs_value,
    imp_s.IETOTDUTY                               AS total_duty,
    imp_s.IETOTVAT                                AS total_vat,
    imp_d.IENETMASSTOT                            AS net_mass_total,
    imp_d.GDSLOCN                                 AS goods_location,
    imp_s.STANDARD_ACPTNCDATE                     AS acceptance_date,
    imp_s.IMPTRTURNCC                             AS importer_turn_country_code,
    imp_s.PLAULDG                                 AS place_of_unloading_code,
    imp_d.FIRDAN                                  AS first_deferment_approval_num,
    imp_d.FIRDANPFX                               AS first_deferment_approval_num_prefix,
    imp_s.DECLNUCR                                AS declaration_ucr,
    imp_s.ITEMCNT                                 AS item_count,
    imp_s.MASTERUCR                               AS master_ucr,
    imp_s.PAYAGNTTURN                             AS paying_agent_turn,
    CAST(NULL AS STRING)                          AS place_of_loading_code,
    imp_s.SESSNO                                  AS session_num,
    sess.ROLENM                                   AS session_role_name,
    CAST(NULL AS STRING)                          AS status_of_entry,
    imp_d.TRPTCNTRY                               AS transport_country,
    imp_d.TRPTID                                  AS transport_id,
    imp_d.TRPTMODECODE                            AS transport_mode_code,
    imp_s.DISPCNTRY                               AS dispatch_country,
    imp_s.CNSGRTURN                               AS consignor_turn,
    imp_s.CNSGRTURNCC                             AS consignor_turn_country_code,
    inad_csr.HDRNADNAME                           AS consignor_nad_name,
    inad_cse.HDRNADNAME                           AS consignee_nad_name,
    inad_cse.HDRNADPOSTCODE                       AS consignee_nad_postcode,
    inad_dec.HDRNADNAME                           AS declarant_nad_name,
    ievc.CCCODE                                   AS customs_check_code,
    ievc.PROFID                                   AS profile_id,
    imp_d.FRGTCRRN                                AS freight_currency, 								 
    imp_d.INVCRRN                                 AS invoice_currency,
    imp_d.INVTOTAC                                AS invoice_total_declared,
    UPPER(CONCAT(imp_s.EPUNO, '-', imp_s.IMPENTNO, '-', SUBSTR(imp_s.STANDARD_DTOFENT, 1, 10))) AS entry_reference
FROM `${MSS_DB}`.IMENSELECT imp_s
JOIN `${MSS_DB}`.IMENDETAIL imp_d      on  imp_d.IEKEY = imp_s.IEKEY
LEFT OUTER JOIN `${MSS_DB}`.INAD inad_csr on imp_s.IEKEY = inad_csr.IEKEY and inad_csr.HDRNADTYPE = '1'
LEFT OUTER JOIN `${MSS_DB}`.INAD inad_cse on imp_s.IEKEY = inad_cse.IEKEY and inad_cse.HDRNADTYPE = '2'
LEFT OUTER JOIN `${MSS_DB}`.INAD inad_dec on imp_s.IEKEY = inad_dec.IEKEY and inad_dec.HDRNADTYPE = '3'
LEFT OUTER JOIN `${MSS_DB}`.IEVC ievc on imp_s.IEKEY = ievc.IEKEY
LEFT OUTER JOIN `${MSS_DB}`.SESS sess  on  imp_s.SESSNO = sess.SESSNO
UNION ALL
-- Read from the exports tables
-- HEADERS
SELECT
    source,
    ingestion_date,
    entry_number,
    entry_date,
    epu_number,
    entry_type,
    declaration_method,
    total_excise,
    importer_turn,
    declarant_turn,
    declarant_representative_turn,
    consignee_AEO_certificate_type_code,
    declarant_AEO_certificate_type_code,
    route,
    declaration_import_export_indicator,
    generation_number,
    exporter_turn,
    destination_country_code,
    import_clearance_status,
    consignor_AEO_certificate_type_code,
    header_statistical_value,
    goods_departure_datetime,
    customs_value,
    total_duty,
    total_vat,
    net_mass_total,
    goods_location,
    acceptance_date,
    importer_turn_country_code,
    place_of_unloading_code,
    first_deferment_approval_num,
    first_deferment_approval_num_prefix,
    declaration_ucr,
    item_count,
    master_ucr,
    paying_agent_turn,
    place_of_loading_code,
    session_num,
    session_role_name,
    status_of_entry,
    transport_country,
    transport_id,
    transport_mode_code,
    dispatch_country,
    consignor_turn,
    consignor_turn_country_code,
    consignor_nad_name,
    consignee_nad_name,
    consignee_nad_postcode,
    declarant_nad_name,
    customs_check_code,
    profile_id,
    freight_currency, 								 
    invoice_currency,
    invoice_total_declared,
    entry_reference
FROM (
    SELECT
        'mss'                                         AS source,
        from_unixtime(unix_timestamp(), 'yyyy-MM-dd') AS ingestion_date,
        exp_s.IMPENTNO                                AS entry_number,
        exp_s.STANDARD_DTOFENT                        AS entry_date,
        exp_s.EPUNO                                   AS epu_number,
        exp_s.IETYPE                                  AS entry_type,
        exp_s.DECLNMTHD                               AS declaration_method,
        exp_d.TOTEXCISE                               AS total_excise,
        CAST(NULL AS STRING)                          AS importer_turn,
        exp_s.DECLTTURN                               AS declarant_turn,
        exp_d.DECLTREP                                AS declarant_representative_turn,
        CAST(NULL AS STRING)                          AS consignee_AEO_certificate_type_code,
        exp_d.decltaeocerttycd                        AS declarant_AEO_certificate_type_code,
        exp_s.ROE                                     AS route,
        'E'                                           AS declaration_import_export_indicator,
        exp_s.generationno                            AS generation_number,
        exp_s.cnsgrturn                               AS exporter_turn,
        exp_s.DESTCNTRY                               AS destination_country_code,
        exp_s.ics                                     AS import_clearance_status,
        exp_d.cnsgraeocerttycd                        AS consignor_AEO_certificate_type_code,
        exp_d.STATVALUE                               AS header_statistical_value,
        exp_s.STANDARD_GDSDEPDT                       AS goods_departure_datetime,
        exp_s.CSTMSVALUE                              AS customs_value,
        exp_s.IETOTDUTY                               AS total_duty,
        exp_s.IETOTVAT                                AS total_vat,
        exp_d.IENETMASSTOT                            AS net_mass_total,
        exp_s.GDSLOCN                                 AS goods_location,
        exp_s.STANDARD_ACPTNCDATE                     AS acceptance_date,
        exp_s.IMPTRTURNCC                             AS importer_turn_country_code,
        CAST(NULL AS STRING)                          AS place_of_unloading_code,
        exp_d.FIRDAN                                  AS first_deferment_approval_num,
        exp_d.FIRDANPFX                               AS first_deferment_approval_num_prefix,
        exp_s.DECLNUCR                                AS declaration_ucr,
        exp_s.ITEMCNT                                 AS item_count,
        exp_s.MASTERUCR                               AS master_ucr,
        exp_s.PAYAGNTTURN                             AS paying_agent_turn,
        exp_s.PLALDG                                  AS place_of_loading_code,
        exp_s.SESSNO                                  AS session_num,
        sess.ROLENM                                   AS session_role_name,
        exp_s.SOE                                     AS status_of_entry,
        exp_d.TRPTCNTRY                               AS transport_country,
        exp_d.TRPTID                                  AS transport_id,
        exp_d.TRPTMODECODE                            AS transport_mode_code,
        CAST(NULL AS STRING)                          AS dispatch_country,
        exp_s.CNSGRTURN                               AS consignor_turn,
        exp_s.CNSGRTURNCC                             AS consignor_turn_country_code,
        CAST(NULL AS STRING)                          AS consignor_nad_name,
        CAST(NULL AS STRING)                          AS consignee_nad_name,
        CAST(NULL AS STRING)                          AS consignee_nad_postcode,
        CAST(NULL AS STRING)                          AS declarant_nad_name,
        CAST(NULL AS STRING)                          AS customs_check_code,
        CAST(NULL AS STRING)                          AS profile_id,
        exp_d.FRGTCRRN                                AS freight_currency, 								 
        exp_d.INVCRRN                                 AS invoice_currency,
        exp_d.INVTOTAC                                AS invoice_total_declared,
        UPPER(CONCAT(exp_s.EPUNO, '-', exp_s.IMPENTNO, '-', SUBSTR(exp_s.STANDARD_DTOFENT, 1, 10))) AS entry_reference,
        ROW_NUMBER() OVER (partition by exp_d.IEKEY order by exp_s.STANDARD_DTOFENT) rownum
    FROM `${MSS_DB}`.NXENSELECT exp_s
    JOIN `${MSS_DB}`.NXENDETAIL exp_d      on  exp_d.IEKEY = exp_s.IEKEY
                                        and exp_d.GENERATIONNO = exp_s.GENERATIONNO
    LEFT OUTER JOIN `${MSS_DB}`.SESS sess on exp_s.SESSNO = sess.SESSNO) x
    WHERE x.rownum=1;
    
-- LINES - Imports
CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.landing_mss_lines_declaration AS
SELECT
    'mss'                                         AS source,
    from_unixtime(unix_timestamp(), 'yyyy-MM-dd') AS ingestion_date,
    imp_s.IMPENTNO                                AS entry_number,
    imp_s.STANDARD_DTOFENT                        AS entry_date,
    imp_s.EPUNO                                   AS epu_number,
    ime_s.IEITNO                                  AS item_number,
    ime_s.STANDARD_CLRNCDATE                      AS clearance_datetime,
    ime_s.ORIGCNTRY                               AS origin_country_code,
    ime_d.ITEMSTATVAL                             AS item_statistical_value,
    ime_s.CMDTYCODE                               AS commodity_code,
    ime_s.CPC                                     AS customs_procedure_code,
    ime_d.IEITCDUTYPAID                           AS customs_duty_paid,
    ime_d.IEITVATPAID                             AS vat_paid,
    ime_d.ITEMVATVAL                              AS vat_value,
    ime_d.ECSU1                                   AS ec_supplementary_1,
    ime_d.ITEMCSTMSVAL                            AS item_customs_value,
    ime_d.ITEMNETMASS                             AS item_net_mass,
    ime_d.ITEMSUPPUNITS                           AS item_supplementary_units,
    ime_d.GDSDESC                                 AS goods_description,
    ime_s.ITEMIMPTRTURN                           AS item_importer_turn,
    iica.ITECCCODE                                AS item_customs_check_code,
    iica.MIC                                      AS item_mic_code,
    iica.PROFID                                   AS item_profile_id,
    iina1.ITEMNADNAME                             AS item_consignor_nad_name,
    iina2.ITEMNADNAME                             AS item_consignee_nad_name,
    iina2.ITEMNADPOSTCODE                         AS item_consignee_nad_postcode,
    ime_d.ITEMPRCAC                               AS item_price_declared,
    UPPER(CONCAT(imp_s.EPUNO, '-', imp_s.IMPENTNO, '-', SUBSTR(imp_s.STANDARD_DTOFENT, 1, 10))) AS entry_reference,
    CASE
        WHEN UPPER(ime_s.CMDTYCODE) = 'NULL' THEN NULL
        WHEN ime_s.CMDTYCODE IS NULL THEN NULL
        ELSE SUBSTR(regexp_replace(ime_s.CMDTYCODE, '\\s', ''), 1, 6)
    END AS hs_code
FROM ${MSS_DB}.IMEISELECT ime_s
JOIN ${MSS_DB}.IMENSELECT imp_s  on  imp_s.IEKEY  = ime_s.IEKEY
JOIN ${MSS_DB}.IMEIDETAIL ime_d  on  ime_s.IEKEY  = ime_d.IEKEY
                                and  ime_s.IEITNO = ime_d.IEITNO
LEFT OUTER JOIN ${MSS_DB}.IINA iina1  on ime_s.iekey = iina1.iekey
                                and  ime_s.ieitno = iina1.ieitno
                                and  iina1.itemnadtype = '1'
LEFT OUTER JOIN ${MSS_DB}.IINA iina2  on ime_s.iekey = iina2.iekey
                                and  ime_s.ieitno = iina2.ieitno
                                and  iina2.itemnadtype = '2'
LEFT OUTER JOIN ${MSS_DB}.IICA iica on ime_s.iekey = iica.iekey
                                and  ime_s.ieitno = iica.ieitno
UNION ALL
-- LINES - Exports
SELECT
    source,
    ingestion_date,
    entry_number,
    entry_date,
    epu_number,
    item_number,
    clearance_datetime,
    origin_country_code,
    item_statistical_value,
    commodity_code,
    customs_procedure_code,
    customs_duty_paid,
    vat_paid,
    vat_value,
    ec_supplementary_1,
    item_customs_value,
    item_net_mass,
    item_supplementary_units,
    goods_description,
    item_importer_turn,
    item_customs_check_code,
    item_mic_code,
    item_profile_id,
    item_consignor_nad_name,
    item_consignee_nad_name,
    item_consignee_nad_postcode,
    item_price_declared,
    entry_reference,
    hs_code
FROM (
SELECT
    'mss'                                         AS source,
    from_unixtime(unix_timestamp(), 'yyyy-MM-dd') AS ingestion_date,
    exp_s.IMPENTNO                                AS entry_number,
    exp_s.STANDARD_DTOFENT                        AS entry_date,
    exp_s.EPUNO                                   AS epu_number,
    exe_s.IEITNO                                  AS item_number,
    exp_s.STANDARD_CLRNCDATE                      AS clearance_datetime,
    exe_s.ORIGCNTRY                               AS origin_country_code,
    exe_d.ITEMSTATVAL                             AS item_statistical_value,
    exe_s.CMDTYCODE                               AS commodity_code,
    exe_s.CPC                                     AS customs_procedure_code,
    NULL                                          AS customs_duty_paid,
    NULL                                          AS vat_paid,
    exe_s.ITEMVATVAL                              AS vat_value,
    exe_d.ECSU1                                   AS ec_supplementary_1,
    exe_d.ITEMCSTMSVAL                            AS item_customs_value,
    exe_s.ITEMNETMASS                             AS item_net_mass,
    exe_s.ITEMSUPPUNITS                           AS item_supplementary_units,
    exe_d.GDSDESC                                 AS goods_description,
    CAST(NULL AS STRING)                          AS item_importer_turn,
    CAST(NULL AS STRING)                          AS item_customs_check_code,
    CAST(NULL AS STRING)                          AS item_mic_code,
    CAST(NULL AS STRING)                          AS item_profile_id,
    CAST(NULL AS STRING)                          AS item_consignor_nad_name,
    CAST(NULL AS STRING)                          AS item_consignee_nad_name,
    CAST(NULL AS STRING)                          AS item_consignee_nad_postcode,
    exe_d.ITEMPRCAC                               AS item_price_declared,
    UPPER(CONCAT(exp_s.EPUNO, '-', exp_s.IMPENTNO, '-', SUBSTR(exp_s.STANDARD_DTOFENT, 1, 10))) AS entry_reference,
    CASE
        WHEN UPPER(exe_s.CMDTYCODE) = 'NULL' THEN NULL
        WHEN exe_s.CMDTYCODE IS NULL THEN NULL
        ELSE SUBSTR(regexp_replace(exe_s.CMDTYCODE, '\\s', ''), 1, 6)
    END AS hs_code,
    ROW_NUMBER() OVER (PARTITION BY exp_s.IEKEY, exe_s.IEITNO ORDER BY exp_s.STANDARD_DTOFENT) rownum
FROM ${MSS_DB}.NXEISELECT exe_s
JOIN ${MSS_DB}.NXENSELECT exp_s  on  exp_s.IEKEY  = exe_s.IEKEY
                                and  exp_s.GENERATIONNO = exe_s.GENERATIONNO
JOIN ${MSS_DB}.NXEIDETAIL exe_d  on  exe_s.IEKEY  = exe_d.IEKEY
                                and  exe_s.IEITNO = exe_d.IEITNO
                                and  exe_s.GENERATIONNO = exe_d.GENERATIONNO) x
WHERE x.rownum=1;

-- Traders (TODO: should be split to different file)
CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.`landing_mss_trader` AS
SELECT
    'mss'                                         AS source,
    from_unixtime(unix_timestamp(), 'yyyy-MM-dd') AS ingestion_date,
    tder.TURN                                     AS turn,
    tder.FEDATE                                   AS fedate,
    tder.TDRNAMEALL                               AS name,
    tder.TDRSPAUTHS                               AS simplified_procedure_authorisations,
    tder.TDRABBRNM                                AS trader_name_abbreviated,
    tder.CURRENTIND                               AS currentind
FROM ${MSS_DB}.TDER tder;

