--
-- The following statements ingest data from the MSS source into table
-- landing_mss_line_previous_document
--

-- Cleanup
DROP TABLE IF EXISTS `${EXPLOIT_DB}`.landing_mss_line_previous_document PURGE;

--
-- Read the document information relating to import
-- declaration lines. The generation number is defaulted to 1 for
-- imports. This will be an attribute of the satellite rathering than
-- forming part of the business key.

CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.landing_mss_line_previous_document AS
-- Import documents
SELECT
    'mss'                                           AS source,
    from_unixtime(unix_timestamp(), 'yyyy-MM-dd')   AS ingestion_date,
    iipd.IEITNO                                     AS item_number,
    iipd.iipdDATASEQNO                              AS previous_document_sequence_number, 
    '1'                                             AS generation_number,
    iipd.PREVDOCREF                                 AS previous_document_reference,
    UPPER(CONCAT(imp_s.EPUNO, '-', imp_s.IMPENTNO, '-', SUBSTR(imp_s.STANDARD_DTOFENT, 1, 10))) AS entry_reference
FROM `${MSS_DB}`.IMENSELECT imp_s JOIN `${MSS_DB}`.iipd iipd    ON imp_s.IEKEY = iipd.IEKEY
UNION ALL
-- Export previous document lines
SELECT
    'mss'                                            AS source,
    from_unixtime(unix_timestamp(), 'yyyy-MM-dd')    AS ingestion_date,
    nxipd.IEITNO                                     AS item_number,
    nxipd.nxipdDATASEQNO                             AS previous_document_sequence_number, 
    exp_s.GENERATIONNO                               AS generation_number,
    nxipd.PREVDOCREF                                 AS previous_document_reference,
    UPPER(CONCAT(exp_s.EPUNO, '-', exp_s.IMPENTNO, '-', SUBSTR(exp_s.STANDARD_DTOFENT, 1, 10))) AS entry_reference
FROM `${MSS_DB}`.NXENSELECT exp_s JOIN `${MSS_DB}`.nxipd nxipd    ON exp_s.IEKEY = nxipd.IEKEY
													 AND exp_s.GENERATIONNO = nxipd.GENERATIONNO;