-- Note that the connection currently is to the ${HIVE_DB} DB (default 'Dev')
-- but we use fully qualified table names here to act on a different database

-- Ensure DV 'hub_${hub_name}' table exists
CREATE TABLE IF NOT EXISTS ${DV_DB}.${name}
(
    ${name}_key CHAR(32),
    --${hub_business_key_ddl},
    ${main_ddl},
    hub_load_datetime   TIMESTAMP,
    hub_record_source   STRING
)
STORED AS TEXTFILE;

-- Populate DV 'hub_${hub_name}' with new items
-- A hub is append-only so this is a simple and safe operation
INSERT INTO ${DV_DB}.${name}
-- Unsupported syntax for Hive pre-1.2.0
--(
--    hub_${hub_name}_key,
--    ${select_fields},
--    hub_load_datetime,
--    hub_record_source
--)
SELECT
    ${name},                -- DV hub_${hub_name}_key,
    ${select_fields},                -- {DV business keys},
    from_unixtime(unix_timestamp()), -- DV hub_load_datetime
    source       -- DV hub_record_source
FROM (
    SELECT
        dht.${name},
        ${select_fields_fq},
        row_number() OVER(PARTITION BY dht.${name}) AS rn
    FROM
        `${EXPLOIT_DB}`.${src_table} AS dht  -- this needs renaming
    LEFT OUTER JOIN
        ${DV_DB}.${name} hdt
        on hdt.${name}_key = dht.${name}
    WHERE
        ${name}_key IS NULL -- i.e. a new entry
) t
WHERE
    rn = 1; -- i.e. the first record found in new data for each declarant_hash

