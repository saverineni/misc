/************ Update: Tables ***************/

/******************** Add Table: hub_commodity_code ************************/

/* Build Table Structure */
CREATE TABLE hub_commodity_code
(
	hub_commodity_code_key CHAR(32) NOT NULL,
	comodity_code VARCHAR(255) NOT NULL,
	hub_load_datetime DATETIME NOT NULL,
	hub_record_source VARCHAR(255) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE hub_commodity_code ADD CONSTRAINT pkhub_commodity_code
	PRIMARY KEY (hub_commodity_code_key);


/******************** Add Table: hub_consignee ************************/

/* Build Table Structure */
CREATE TABLE hub_consignee
(
	hub_consignee_key CHAR(32) NOT NULL,
	consignee_id VARCHAR(255) NOT NULL,
	hub_load_datetime DATETIME NOT NULL,
	hub_record_source VARCHAR(255) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE hub_consignee ADD CONSTRAINT pkhub_consignee
	PRIMARY KEY (hub_consignee_key);


/******************** Add Table: hub_consignor ************************/

/* Build Table Structure */
CREATE TABLE hub_consignor
(
	hub_consignor_key CHAR(32) NOT NULL,
	consignor_id VARCHAR(255) NOT NULL,
	hub_load_datetime DATETIME NOT NULL,
	hub_record_source VARCHAR(255) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE hub_consignor ADD CONSTRAINT pkhub_consignor
	PRIMARY KEY (hub_consignor_key);


/******************** Add Table: hub_custom_procedure_code ************************/

/* Build Table Structure */
CREATE TABLE hub_custom_procedure_code
(
	hub_custom_procedure_code_key CHAR(32) NOT NULL,
	custom_procedure_code VARCHAR(255) NOT NULL,
	hub_load_datetime DATETIME NOT NULL,
	hub_record_source VARCHAR(255) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE hub_custom_procedure_code ADD CONSTRAINT pkhub_custom_procedure_code
	PRIMARY KEY (hub_custom_procedure_code_key);


/******************** Add Table: hub_declarant ************************/

/* Build Table Structure */
CREATE TABLE hub_declarant
(
	hub_declarant_key CHAR(32) NOT NULL,
	entry_number VARCHAR(255) NOT NULL,
	entry_version_number VARCHAR(255) NOT NULL,
	hub_load_datetime DATETIME NOT NULL,
	hub_record_source VARCHAR(255) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE hub_declarant ADD CONSTRAINT pkhub_declarant
	PRIMARY KEY (hub_declarant_key);


/******************** Add Table: hub_declaration ************************/

/* Build Table Structure */
CREATE TABLE hub_declaration
(
	hub_declaration_key CHAR(32) NOT NULL,
	entry_number VARCHAR(255) NOT NULL,
	entry_version_number VARCHAR(255) NOT NULL,
	hub_load_datetime DATETIME NOT NULL,
	hub_record_source VARCHAR(255) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE hub_declaration ADD CONSTRAINT pkhub_declaration
	PRIMARY KEY (hub_declaration_key);


/******************** Add Table: hub_declaration_line ************************/

/* Build Table Structure */
CREATE TABLE hub_declaration_line
(
	hub_declaration_line_key CHAR(32) NOT NULL,
	entry_number VARCHAR(255) NOT NULL,
	entry_version_number VARCHAR(255) NOT NULL,
	item_number VARCHAR(255) NOT NULL,
	hub_load_datetime DATETIME NOT NULL,
	hub_record_source VARCHAR(255) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE hub_declaration_line ADD CONSTRAINT pkhub_declaration_line
	PRIMARY KEY (hub_declaration_line_key);


/******************** Add Table: hub_entry_processing_unit ************************/

/* Build Table Structure */
CREATE TABLE hub_entry_processing_unit
(
	hub_entry_processing_unit_key CHAR(32) NOT NULL,
	entry_processing_unit_code VARCHAR(255) NOT NULL,
	hub_load_datetime DATETIME NOT NULL,
	hub_record_source VARCHAR(255) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE hub_entry_processing_unit ADD CONSTRAINT pkhub_entry_processing_unit
	PRIMARY KEY (hub_entry_processing_unit_key);


/******************** Add Table: lnk_declaration_declarant ************************/

/* Build Table Structure */
CREATE TABLE lnk_declaration_declarant
(
	lnk_declaration_declarant_key CHAR(32) NOT NULL,
	hub_declaration_key CHAR(32) NOT NULL,
	hub_declarant_key CHAR(32) NOT NULL,
	lnk_load_datetime DATETIME NOT NULL,
	lnk_record_source VARCHAR(255) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE lnk_declaration_declarant ADD CONSTRAINT pklnk_declaration_declarant
	PRIMARY KEY (lnk_declaration_declarant_key);


/******************** Add Table: lnk_declaration_declaration_line ************************/

/* Build Table Structure */
CREATE TABLE lnk_declaration_declaration_line
(
	lnk_declaration_declaration_line_key CHAR(32) NOT NULL,
	hub_declaration_key CHAR(32) NOT NULL,
	hub_declaration_line_key CHAR(32) NOT NULL,
	lnk_load_datetime DATETIME NOT NULL,
	lnk_record_source VARCHAR(255) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE lnk_declaration_declaration_line ADD CONSTRAINT pklnk_declaration_declaration_line
	PRIMARY KEY (lnk_declaration_declaration_line_key);


/******************** Add Table: lnk_declaration_entry_processing_unit ************************/

/* Build Table Structure */
CREATE TABLE lnk_declaration_entry_processing_unit
(
	lnk_declaration_declaration_line_key CHAR(32) NOT NULL,
	hub_declaration_key CHAR(32) NOT NULL,
	hub_entry_processing_unit_key CHAR(32) NOT NULL,
	lnk_load_datetime DATETIME NOT NULL,
	lnk_record_source VARCHAR(255) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE lnk_declaration_entry_processing_unit ADD CONSTRAINT pklnk_declaration_declaration_line_dup
	PRIMARY KEY (lnk_declaration_declaration_line_key);


/******************** Add Table: lnk_declaration_line_commodity_cpc ************************/

/* Build Table Structure */
CREATE TABLE lnk_declaration_line_commodity_cpc
(
	lnk_declaration_line_commodity_cpc_key CHAR(32) NOT NULL,
	hub_declaration_line_key CHAR(32) NOT NULL,
	hub_commodity_code_key CHAR(32) NOT NULL,
	hub_custom_procedure_code_key CHAR(32) NOT NULL,
	lnk_load_datetime DATETIME NOT NULL,
	lnk_record_source VARCHAR(255) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE lnk_declaration_line_commodity_cpc ADD CONSTRAINT pklnk_declaration_line_commodity_cpc
	PRIMARY KEY (lnk_declaration_line_commodity_cpc_key);


/******************** Add Table: lnk_declaration_line_consignee ************************/

/* Build Table Structure */
CREATE TABLE lnk_declaration_line_consignee
(
	lnk_declaration_line_consignee_key CHAR(32) NOT NULL,
	hub_declaration_line_key CHAR(32) NOT NULL,
	hub_consignee_key CHAR(32) NOT NULL,
	lnk_load_datetime DATETIME NOT NULL,
	lnk_record_source VARCHAR(255) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE lnk_declaration_line_consignee ADD CONSTRAINT pklnk_declaration_line_consignee
	PRIMARY KEY (lnk_declaration_line_consignee_key);


/******************** Add Table: lnk_declaration_line_consignor ************************/

/* Build Table Structure */
CREATE TABLE lnk_declaration_line_consignor
(
	lnk_declaration_line_consignor_key CHAR(32) NOT NULL,
	hub_declaration_line_key CHAR(32) NOT NULL,
	hub_consignor_key CHAR(32) NOT NULL,
	lnk_load_datetime DATETIME NOT NULL,
	lnk_record_source VARCHAR(255) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE lnk_declaration_line_consignor ADD CONSTRAINT pklnk_declaration_line_consignor
	PRIMARY KEY (lnk_declaration_line_consignor_key);


/******************** Add Table: sat_commodity_code ************************/

/* Build Table Structure */
CREATE TABLE sat_commodity_code
(
	hub_commodity_code_key CHAR(32) NOT NULL,
	sat_hash_diff CHAR(32) NOT NULL,
	sat_load_datetime DATETIME NOT NULL,
	sat_load_end_datetime DATETIME NULL,
	cc_year INT NOT NULL,
	cc_month INT NOT NULL,
	hs_chapter CHAR(2),
	hs_heading CHAR(2),
	hs_chapter_heading CHAR(4),
	hs_subheading CHAR(2),
	hs_code CHAR(6),
	chapter_description VARCHAR(255),
	heading_description VARCHAR(255),
	subheading_description VARCHAR(255)
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE sat_commodity_code ADD CONSTRAINT pksat_commodity_code
	PRIMARY KEY (hub_commodity_code_key);


/******************** Add Table: sat_consignee ************************/

/* Build Table Structure */
CREATE TABLE sat_consignee
(
	hub_consignee_key CHAR(32) NOT NULL,
	sat_hash_diff CHAR(32) NOT NULL,
	sat_load_datetime DATETIME NOT NULL,
	sat_load_end_datetime DATETIME NULL,
	name VARCHAR(255) NULL,
	street VARCHAR(255) NULL,
	city VARCHAR(255) NULL,
	postcode VARCHAR(255) NULL,
	country VARCHAR(255) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE sat_consignee ADD CONSTRAINT pksat_consignee
	PRIMARY KEY (hub_consignee_key);


/******************** Add Table: sat_consignor ************************/

/* Build Table Structure */
CREATE TABLE sat_consignor
(
	hub_consignor_key CHAR(32) NOT NULL,
	sat_hash_diff CHAR(32) NOT NULL,
	sat_load_datetime DATETIME NOT NULL,
	sat_load_end_datetime DATETIME NULL,
	name VARCHAR(255) NULL,
	street VARCHAR(255) NULL,
	city VARCHAR(255) NULL,
	postcode VARCHAR(255) NULL,
	country VARCHAR(255) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE sat_consignor ADD CONSTRAINT pksat_consignor
	PRIMARY KEY (hub_consignor_key);


/******************** Add Table: sat_custom_procedure_code ************************/

/* Build Table Structure */
CREATE TABLE sat_custom_procedure_code
(
	hub_custom_procedure_code_key CHAR(32) NOT NULL,
	sat_hash_diff CHAR(32) NOT NULL,
	sat_load_datetime DATETIME NOT NULL,
	sat_load_end_datetime DATETIME NULL,
	name VARCHAR(255) NOT NULL,
	description VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE sat_custom_procedure_code ADD CONSTRAINT pksat_custom_procedure_code
	PRIMARY KEY (hub_custom_procedure_code_key);


/******************** Add Table: sat_declarant ************************/

/* Build Table Structure */
CREATE TABLE sat_declarant
(
	hub_declarant_key CHAR(32) NOT NULL,
	sat_hash_diff CHAR(32) NOT NULL,
	sat_load_datetime DATETIME NOT NULL,
	sat_load_end_datetime DATETIME NULL,
	declarant_type VARCHAR(255) NULL,
	name VARCHAR(255) NULL,
	street VARCHAR(255) NULL,
	city VARCHAR(255) NULL,
	postcode VARCHAR(255) NULL,
	country VARCHAR(255) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE sat_declarant ADD CONSTRAINT pksat_declarant
	PRIMARY KEY (hub_declarant_key);


/******************** Add Table: sat_declaration ************************/

/* Build Table Structure */
CREATE TABLE sat_declaration
(
	hub_declaration_key CHAR(32) NOT NULL,
	sat_hash_diff CHAR(32) NOT NULL,
	sat_load_datetime DATETIME NOT NULL,
	sat_load_end_datetime DATETIME NULL,
	entry_type VARCHAR(255) NULL,
	entry_datetime DATETIME NULL,
	acceptance_datetime DATETIME NULL,
	master_ucr VARCHAR(255) NULL,
	declaration_ucr VARCHAR(255) NULL,
	fir_dan VARCHAR(255) NULL,
	fir_dan_prefix VARCHAR(255) NULL,
	additional_declaration_type VARCHAR(255) NULL,
	mrn VARCHAR(255) NULL,
	procedure_category VARCHAR(255) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE sat_declaration ADD CONSTRAINT pksat_declaration
	PRIMARY KEY (hub_declaration_key);


/******************** Add Table: sat_entry_processing_unit ************************/

/* Build Table Structure */
CREATE TABLE sat_entry_processing_unit
(
	hub_entry_processing_unit_key CHAR(32) NOT NULL,
	sat_hash_diff CHAR(32) NOT NULL,
	sat_load_datetime DATETIME NOT NULL,
	sat_load_end_datetime DATETIME NULL,
	name VARCHAR(255) NULL,
	street VARCHAR(255) NULL,
	city VARCHAR(255) NULL,
	postcode VARCHAR(255) NULL,
	country VARCHAR(255) NULL,
	latitude VARCHAR(100) NULL,
	longitude VARCHAR(100) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE sat_entry_processing_unit ADD CONSTRAINT pksat_entry_processing_unit
	PRIMARY KEY (hub_entry_processing_unit_key);


/******************** Add Table: sat_lnk_declaration_line_commodity ************************/

/* Build Table Structure */
CREATE TABLE sat_lnk_declaration_line_commodity
(
	lnk_declaration_line_commodity_cpc_key CHAR(32) NOT NULL,
	sat_hash_diff CHAR(32) NOT NULL,
	sat_load_datetime DATETIME NOT NULL,
	sat_load_end_datetime DATETIME NULL,
	goods_location VARCHAR(255) NOT NULL,
	description VARCHAR(255) NOT NULL,
	premises_id VARCHAR(255) NULL,
	item_price DECIMAL(10, 2) NOT NULL,
	item_customs_value DECIMAL(10, 2) NULL,
	item_customs_duty_paid DECIMAL(10, 2) NULL,
	item_vat_value DECIMAL(10, 2) NULL,
	clearance_date DATETIME NULL,
	tax_point_date DATETIME NULL,
	goods_depature_date DATETIME NULL,
	permission_to_progress_date DATETIME NULL,
	dispatch_country_code VARCHAR(4) NULL,
	destination_country_code VARCHAR(4) NULL,
	type_of_package_code VARCHAR(255) NULL,
	number_of_package INTEGER NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE sat_lnk_declaration_line_commodity ADD CONSTRAINT pksat_lnk_declaration_line_commodity
	PRIMARY KEY (lnk_declaration_line_commodity_cpc_key);


/******************** Add Table: sat_lnk_declaration_line_cpc ************************/

/* Build Table Structure */
CREATE TABLE sat_lnk_declaration_line_cpc
(
	lnk_declaration_line_commodity_cpc_key CHAR(32) NOT NULL,
	sat_hash_diff CHAR(32) NOT NULL,
	sat_load_datetime DATETIME NOT NULL,
	sat_load_end_datetime DATETIME NULL,
	document_type VARCHAR(255) NOT NULL,
	previous_document VARCHAR(255) NOT NULL,
	previous_document_reference VARCHAR(255) NULL,
	additional_procedure VARCHAR(255) NULL,
	requested_procedure VARCHAR(255) NULL,
	previous_procedure VARCHAR(255) NULL,
	shipping_marks VARCHAR(255) NULL
) ENGINE=InnoDB;

/* Add Primary Key */
ALTER TABLE sat_lnk_declaration_line_cpc ADD CONSTRAINT pksat_lnk_declaration_line_commodity_dup
	PRIMARY KEY (lnk_declaration_line_commodity_cpc_key);





/************ Add Foreign Keys ***************/

/* Add Foreign Key: fk_lnk_declaration_declarant_hub_declarant */
ALTER TABLE lnk_declaration_declarant ADD CONSTRAINT fk_lnk_declaration_declarant_hub_declarant
	FOREIGN KEY (hub_declarant_key) REFERENCES hub_declarant (hub_declarant_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_lnk_declaration_declarant_hub_declaration */
ALTER TABLE lnk_declaration_declarant ADD CONSTRAINT fk_lnk_declaration_declarant_hub_declaration
	FOREIGN KEY (hub_declaration_key) REFERENCES hub_declaration (hub_declaration_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_lnk_declaration_declaration_line_hub_declaration */
ALTER TABLE lnk_declaration_declaration_line ADD CONSTRAINT fk_lnk_declaration_declaration_line_hub_declaration
	FOREIGN KEY (hub_declaration_key) REFERENCES hub_declaration (hub_declaration_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_lnk_declaration_declaration_line_hub_declaration_line */
ALTER TABLE lnk_declaration_declaration_line ADD CONSTRAINT fk_lnk_declaration_declaration_line_hub_declaration_line
	FOREIGN KEY (hub_declaration_line_key) REFERENCES hub_declaration_line (hub_declaration_line_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_lnk_declaration_entry_processing_unit_hub_declaration */
ALTER TABLE lnk_declaration_entry_processing_unit ADD CONSTRAINT fk_lnk_declaration_entry_processing_unit_hub_declaration
	FOREIGN KEY (hub_declaration_key) REFERENCES hub_declaration (hub_declaration_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_lnk_declaration_epc_hub_epc */
ALTER TABLE lnk_declaration_entry_processing_unit ADD CONSTRAINT fk_lnk_declaration_epc_hub_epc
	FOREIGN KEY (hub_entry_processing_unit_key) REFERENCES hub_entry_processing_unit (hub_entry_processing_unit_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_lnk_declaration_line_commodity_cpc_hub_commodity_code */
ALTER TABLE lnk_declaration_line_commodity_cpc ADD CONSTRAINT fk_lnk_declaration_line_commodity_cpc_hub_commodity_code
	FOREIGN KEY (hub_commodity_code_key) REFERENCES hub_commodity_code (hub_commodity_code_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_lnk_declaration_line_commodity_cpc_hub_custom_procedure_code */
ALTER TABLE lnk_declaration_line_commodity_cpc ADD CONSTRAINT fk_lnk_declaration_line_commodity_cpc_hub_custom_procedure_code
	FOREIGN KEY (hub_custom_procedure_code_key) REFERENCES hub_custom_procedure_code (hub_custom_procedure_code_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_lnk_declaration_line_commodity_cpc_hub_declaration_line */
ALTER TABLE lnk_declaration_line_commodity_cpc ADD CONSTRAINT fk_lnk_declaration_line_commodity_cpc_hub_declaration_line
	FOREIGN KEY (hub_declaration_line_key) REFERENCES hub_declaration_line (hub_declaration_line_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_lnk_declaration_line_consignee_hub_consignee */
ALTER TABLE lnk_declaration_line_consignee ADD CONSTRAINT fk_lnk_declaration_line_consignee_hub_consignee
	FOREIGN KEY (hub_consignee_key) REFERENCES hub_consignee (hub_consignee_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_lnk_declaration_line_consignee_hub_declaration_line */
ALTER TABLE lnk_declaration_line_consignee ADD CONSTRAINT fk_lnk_declaration_line_consignee_hub_declaration_line
	FOREIGN KEY (hub_declaration_line_key) REFERENCES hub_declaration_line (hub_declaration_line_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_lnk_declaration_line_consignor_hub_consignor */
ALTER TABLE lnk_declaration_line_consignor ADD CONSTRAINT fk_lnk_declaration_line_consignor_hub_consignor
	FOREIGN KEY (hub_consignor_key) REFERENCES hub_consignor (hub_consignor_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_lnk_declaration_line_consignor_hub_declaration_line */
ALTER TABLE lnk_declaration_line_consignor ADD CONSTRAINT fk_lnk_declaration_line_consignor_hub_declaration_line
	FOREIGN KEY (hub_declaration_line_key) REFERENCES hub_declaration_line (hub_declaration_line_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_sat_commodity_code_hub_commodity_code */
ALTER TABLE sat_commodity_code ADD CONSTRAINT fk_sat_commodity_code_hub_commodity_code
	FOREIGN KEY (hub_commodity_code_key) REFERENCES hub_commodity_code (hub_commodity_code_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_sat_consignee_hub_consignee */
ALTER TABLE sat_consignee ADD CONSTRAINT fk_sat_consignee_hub_consignee
	FOREIGN KEY (hub_consignee_key) REFERENCES hub_consignee (hub_consignee_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_sat_consignor_hub_consignor */
ALTER TABLE sat_consignor ADD CONSTRAINT fk_sat_consignor_hub_consignor
	FOREIGN KEY (hub_consignor_key) REFERENCES hub_consignor (hub_consignor_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_sat_custom_procedure_code_hub_custom_procedure_code */
ALTER TABLE sat_custom_procedure_code ADD CONSTRAINT fk_sat_custom_procedure_code_hub_custom_procedure_code
	FOREIGN KEY (hub_custom_procedure_code_key) REFERENCES hub_custom_procedure_code (hub_custom_procedure_code_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_sat_declarant_hub_declarant */
ALTER TABLE sat_declarant ADD CONSTRAINT fk_sat_declarant_hub_declarant
	FOREIGN KEY (hub_declarant_key) REFERENCES hub_declarant (hub_declarant_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_sat_declaration_hub_declaration */
ALTER TABLE sat_declaration ADD CONSTRAINT fk_sat_declaration_hub_declaration
	FOREIGN KEY (hub_declaration_key) REFERENCES hub_declaration (hub_declaration_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_sat_entry_processing_unit_hub_entry_processing_unit */
ALTER TABLE sat_entry_processing_unit ADD CONSTRAINT fk_sat_entry_processing_unit_hub_entry_processing_unit
	FOREIGN KEY (hub_entry_processing_unit_key) REFERENCES hub_entry_processing_unit (hub_entry_processing_unit_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_sat_lnk_declaration_line_commodity */
ALTER TABLE sat_lnk_declaration_line_commodity ADD CONSTRAINT fk_sat_lnk_declaration_line_commodity
	FOREIGN KEY (lnk_declaration_line_commodity_cpc_key) REFERENCES lnk_declaration_line_commodity_cpc (lnk_declaration_line_commodity_cpc_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;

/* Add Foreign Key: fk_sat_lnk_declaration_line_cpc */
ALTER TABLE sat_lnk_declaration_line_cpc ADD CONSTRAINT fk_sat_lnk_declaration_line_cpc
	FOREIGN KEY (lnk_declaration_line_commodity_cpc_key) REFERENCES lnk_declaration_line_commodity_cpc (lnk_declaration_line_commodity_cpc_key)
	ON UPDATE NO ACTION ON DELETE NO ACTION;
