# Customs Pipeline Repo containing all submodules

This repository exists ONLY for easy of development.
This repository is not used to build and deploy to the PDI jobs 

It contains:

+ PDI jobs:
    + To take MSS and CDS data to an exploitation layer, via a Data Vault
    + To generate dimension tables
    + To import business analysis spreadsheets

There are also some tests expressed as PDI jobs.

## Testing

Current tests are implemented as PDI jobs, with another PDI job to orchestrate the running of the tests.

If jobs are created as needed in folders under *src/test* then the main TEST.kjb will automatically run them if they are named like _Test*.kjb_.

The main src/test/TEST.kjb will return a non-zero exit code and immediately abort if any test fails.
