#!/bin/bash

#---------------------------------------------------------------------------------------------------------------
#
# Parameters:
#
# $1 = VERSION
# $2 = DEPLOY_USER i.e. the user that will log onto the box as
# $3 = SERVER i.e. where to deploy to
# $4 = SYMLINK i.e. what we will link the release as (e.g. dev, qa etc)
#
#---------------------------------------------------------------------------------------------------------------

VERSION="$1"
PACKAGE_NAME="pentaho-scripts-$VERSION-bin.tar.gz"

wget http://10.102.81.194:8081/nexus/content/repositories/releases/uk/gov/gsi/hmrc/cds/data/pentaho-scripts/$VERSION/$PACKAGE_NAME

if [[ ! -e $PACKAGE_NAME ]]
then
	echo Deployment package not found
	exit 404
fi

# who we need to deploy as
DEPLOY_USER=$2
if [[ $DEPLOY_USER == "" ]]
then
	DEPLOY_USER="$USER"
fi

# where we need to deploy to (dev by default)
SERVER=$3
if [[ $SERVER == "" ]]
then
	SERVER=10.102.83.72 # dev box 1
fi

SYMLINK=$4
if [[ $SYMLINK == "" ]]
then
	SYMLINK=dev
fi

# the owner
PACKAGE_OWNER=$5
if [[ "$PACKAGE_OWNER" == "" ]]
then
    PACKAGE_OWNER=cdsdata
fi

# common for both environments
DROP_DIR=/data/drop
DEPLOY_DIR=/data/apps/$PACKAGE_OWNER/pentaho-scripts/.deploy
PDI_SERVER_HOST=10.102.83.72 # always dev box 1

#============= do the deployment ===========================
echo "Deploying to ${SERVER}:${DEPLOY_DIR}"

# scp the package across
# how to handle permissions??
scp "$PACKAGE_NAME" $DEPLOY_USER@$SERVER:$DROP_DIR

# runs everything remotely
ssh -tt $DEPLOY_USER@$SERVER PACKAGE_NAME=$PACKAGE_NAME DROP_DIR=$DROP_DIR PACKAGE_OWNER=$PACKAGE_OWNER PDI_SERVER_HOST=$PDI_SERVER_HOST DEPLOY_DIR=$DEPLOY_DIR SYMLINK=$SYMLINK 'bash -s' << 'END'

	chmod go+rw $DROP_DIR/$PACKAGE_NAME

	# sudo to cds data
	sudo -E -u $PACKAGE_OWNER -s

	# go to the deployment directory
	cd $DEPLOY_DIR

	# untar the package
	tar zxf $DROP_DIR/$PACKAGE_NAME

	# now update the symlink
	DIRECTORY_NAME=`tar ztf $DROP_DIR/$PACKAGE_NAME | head -1 | sed -e 's/\// /g' | awk '{print $1}'`
	cd ..
	rm $SYMLINK
	ln -s .deploy/$DIRECTORY_NAME $SYMLINK

	# upload any metadata files to Pentaho
    echo Enumerating metadata files at $DEPLOY_DIR/$DIRECTORY_NAME/metadata/*.xmi for upload to Pentaho
    for path in $DEPLOY_DIR/$DIRECTORY_NAME/metadata/*.xmi; do
        tmp_path=${path}.tmp
        filename=$(basename ${path});
        original_datasource_name=$(echo $filename | sed 's/.xmi//g')
        datasource_name=$SYMLINK
        sed -e s/dev/${SYMLINK}/g < ${path} > ${tmp_path}
        echo Uploading metadata file ${filename} as datasource $datasource_name
        curl -X PUT -v -include --user admin:password -F "overwrite=true" -F "metadataFile=@/${tmp_path}" http://${PDI_SERVER_HOST}:8080/pentaho/plugin/data-access/api/datasource/metadata/domain/${datasource_name}
    done

    # Create environment appropriate file
    mondrian_file=$DEPLOY_DIR/$DIRECTORY_NAME/metadata/exploitation_wide.xml
    tmp_path=${mondrian_file}.tmp
    filename=`basename ${mondrian_file}`;
    original_datasource_name=`echo $filename | sed 's/.xml//g'`
    datasource_name=$SYMLINK
    sed -e s/cds_environment_wide/${SYMLINK}_wide/g < ${mondrian_file} > ${tmp_path}

    # Upload the mondrian schema
    echo Uploading metadata file ${filename} as datasource $datasource_name
    curl -X PUT -v -include \
          -u admin:password \
          -H "Content-Type: multipart/form-data" \
          -F "overwrite=true" \
          -F "uploadInput=@/${tmp_path}" \
          -F parameters="Datasource=${SYMLINK}-fastp-impala-connection" \
          -F xmlaEnabledFlag=false \
          http://${PDI_SERVER_HOST}:8080/pentaho/plugin/data-access/api/datasource/analysis/catalog/${datasource_name}

	# test it looks ok
	if [[ -e ./$SYMLINK/bin ]]
	then
		exit 0
	else
		exit 1
	fi

	# log out
	exit $?

END

EXIT_CODE=$?
if [[ $EXIT_CODE -eq 0 ]]
then
	echo Successfully deployed new version
else
	echo Failed to deploy new version
fi

exit $EXIT_CODE
