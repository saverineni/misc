package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.datavaulthashcreation;

import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault.DimCurrencyHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveDimensionHashedTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.MD5Hasher.md5HashOf;

public class DimCurrencyHashTests extends BaseIntegrationTest {

    private static final String CURRENCY_CODE = "PKR";
    private static DimCurrencyHashed dimCurrencyHashed;

    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
        Optional<DimCurrencyHashed> dimCurrencyHashedOptional = HiveDimensionHashedTableReader.readAllDimCurrencyHashedCurrencyCode(hive, CURRENCY_CODE);
        dimCurrencyHashed = dimCurrencyHashedOptional.orElse(null);
    }

    @Test
    public void checkMD5ForHubAndSatDeclaration() {
        String hubCountryMD5 = md5HashOf(
                                    CURRENCY_CODE
                               );
        String satCountryMD5 = md5HashOf(
                                    dimCurrencyHashed.getCurrency_name()
                               );

        assertThat(MD5_HASH_LENGTH, is(equalTo(hubCountryMD5.length())));
        assertThat(hubCountryMD5, is(equalTo(dimCurrencyHashed.getHub_currency())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(satCountryMD5.length())));
        assertThat(satCountryMD5, is(equalTo(dimCurrencyHashed.getSat_currency())));
    }
}
