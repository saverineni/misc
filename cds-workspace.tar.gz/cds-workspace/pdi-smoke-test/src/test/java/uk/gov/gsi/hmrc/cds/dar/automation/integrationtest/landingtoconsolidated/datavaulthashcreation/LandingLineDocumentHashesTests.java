package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.datavaulthashcreation;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingHashedTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed.LandingHeadersDeclarationHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed.LandingLineDocument;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed.LandingLineDocumentHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.TestHelper;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.MD5Hasher.md5HashOf;

public class LandingLineDocumentHashesTests extends BaseIntegrationTest implements TestHelper {
    private static final String IMPORT_ENTRY_NUMBER_3C = "IM003C";
    private static final String IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3 = "3";
    private static final String IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3_SEQ_NO = "1";
    private String entryReference;
    private LandingLineDocumentHashed landingLineDocumentHashed;


    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
    }

    @Before
    public void dataReadersSetup() {
        Optional<LandingHeadersDeclarationHashed> landingHeadersDeclarationHashedOptional = HiveLandingHashedTableReader.landingHeadersDeclarationHashedForEntryNo(hive, IMPORT_ENTRY_NUMBER_3C);
        LandingHeadersDeclarationHashed landingHeadersDeclarationHashed = landingHeadersDeclarationHashedOptional.orElse(null);
        entryReference = buildEntryReferenceForDeclaration(landingHeadersDeclarationHashed);

        Optional<LandingLineDocumentHashed> landingLineDocumentHashedOptional = HiveLandingHashedTableReader.landingLineDocumentHashedForEntryReferenceItemNoSeqNo( hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3,
                IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3_SEQ_NO);
        landingLineDocumentHashed = landingLineDocumentHashedOptional.orElse(null);
    }

    @Test
    public void checkMD5ForHubAndSatDeclaration() {
        String hubDeclarationMD5 = md5HashOf(
                                        entryReference,
                                        IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3,
                                        IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3_SEQ_NO
                                   );
        String satDeclarationMD5 = md5HashOf(
                                        landingLineDocumentHashed.getGeneration_number(),
                                        landingLineDocumentHashed.getItem_document_code(),
                                        landingLineDocumentHashed.getItem_document_status(),
                                        Optional.ofNullable(landingLineDocumentHashed.getItem_document_reference()).orElse(NULL_ESCAPE)
                                   );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLineDocumentHashed.getHub_document().length())));
        assertThat(hubDeclarationMD5, is(equalTo(landingLineDocumentHashed.getHub_document())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLineDocumentHashed.getSat_document().length())));
        assertThat(satDeclarationMD5, is(equalTo(landingLineDocumentHashed.getSat_document())));
    }

    @Test
    public void checkMD5ForDeclarationLineDocument() {
        String linkDeclarationDocumentMD5 = md5HashOf(
                                                entryReference,
                                                IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3,
                                                IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3_SEQ_NO
                                            );
        String linkDeclarationDocumentHubDeclarationLineMD5 = md5HashOf(
                                                                    entryReference,
                                                                    IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3
                                                              );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLineDocumentHashed.getLink_declaration_line_document().length())));
        assertThat(linkDeclarationDocumentMD5, is(equalTo(landingLineDocumentHashed.getLink_declaration_line_document())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLineDocumentHashed.getLink_declaration_line_document_hub_declaration_line().length())));
        assertThat(linkDeclarationDocumentHubDeclarationLineMD5, is(equalTo(landingLineDocumentHashed.getLink_declaration_line_document_hub_declaration_line())));
    }

    @Test
    public void checkLandingLineDocumentHashedMatchesLandingLineDocument() {
        Optional<LandingLineDocument> landinglinedocument = HiveLandingTableReader.readAllLandingLineDocumentForEntryRefNoAndSeqNo(hive, entryReference,
                IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3, IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3_SEQ_NO);
        LandingLineDocument landingLineDocument = landinglinedocument.orElse(null);

        assertThat(landingLineDocumentHashed.getSource(), is(equalTo(landingLineDocument.getSource())));
        assertThat(landingLineDocumentHashed.getIngestion_date(), is(equalTo(landingLineDocument.getIngestion_date())));
        assertThat(landingLineDocumentHashed.getItem_number(), is(equalTo(landingLineDocument.getItem_number())));
        assertThat(landingLineDocumentHashed.getDocument_sequence_number(), is(equalTo(landingLineDocument.getDocument_sequence_number())));
        assertThat(landingLineDocumentHashed.getGeneration_number(), is(equalTo(landingLineDocument.getGeneration_number())));
        assertThat(landingLineDocumentHashed.getItem_document_code(), is(equalTo(landingLineDocument.getItem_document_code())));
        assertThat(landingLineDocumentHashed.getItem_document_status(), is(equalTo(landingLineDocument.getItem_document_status())));
        assertThat(landingLineDocumentHashed.getItem_document_reference(), is(equalTo(landingLineDocument.getItem_document_reference())));
        assertThat(landingLineDocumentHashed.getEntry_reference(), is(equalTo(landingLineDocument.getEntry_reference())));
    }
}