package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.rawtolanding.landingpopulation;


import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveMSSTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed.LandingLinesDeclaration;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports.Nxeidetail;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports.Nxeiselect;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports.Nxenselect;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports.Nxina;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.*;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.TestHelper;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

public class LandingLinesDeclarationTests extends BaseIntegrationTest implements TestHelper {

    private static final String IMPORT_ENTRY_NUMBER_1A = "IM001A";
    private static final String IMPORT_ENTRY_NUMBER_1A_LINE_ITEM_NO = "1";
    private static final String EXPORT_ENTRY_NUMBER_2B = "EX002B";
    private static final String EXPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO = "2";

    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
    }

    @Test
    public void checkImportLandingLinesDeclarations() {
        Optional<LandingLinesDeclaration> landinglinesdeclaration =
                HiveLandingTableReader.readAllLandingLinesDeclarationForEntryNo(hive, IMPORT_ENTRY_NUMBER_1A, IMPORT_ENTRY_NUMBER_1A_LINE_ITEM_NO);
        LandingLinesDeclaration landingLinesDeclaration = landinglinesdeclaration.orElse(null);
        assertThat(landingLinesDeclaration, is(notNullValue(LandingLinesDeclaration.class)));

        Optional<Imenselect> imenselectOptional = HiveMSSTableReader.imenselectForImportEntryNo(hive, IMPORT_ENTRY_NUMBER_1A);
        Imenselect imenselect = imenselectOptional.orElse(null);
        assertThat(imenselect, is(notNullValue(Imenselect.class)));

        Optional<Imeiselect> imeiselectByIekeyItemno = HiveMSSTableReader.imeiselectForIekeyIeitno(hive, imenselect.getIekey(), IMPORT_ENTRY_NUMBER_1A_LINE_ITEM_NO);
        Imeiselect imeiselect = imeiselectByIekeyItemno.orElse(null);
        assertThat(imeiselect, is(notNullValue(Imeiselect.class)));

        Optional<Imeidetail> imeidetailByIekeyItemno = HiveMSSTableReader.imeidetailForIekeyIeitno(hive, imenselect.getIekey(), IMPORT_ENTRY_NUMBER_1A_LINE_ITEM_NO);
        Imeidetail imeidetail = imeidetailByIekeyItemno.orElse(null);
        assertThat(imeidetail, is(notNullValue(Imeidetail.class)));

        Optional<Iina> iinaByIekeyItemno = HiveMSSTableReader.iinaForIekeyIeitno(hive, imenselect.getIekey(), IMPORT_ENTRY_NUMBER_1A_LINE_ITEM_NO);
        Iina iina = iinaByIekeyItemno.orElse(null);
        assertThat(iina, is(notNullValue(Iina.class)));

        Optional<Iipd> iipdByIekeyItemno = HiveMSSTableReader.iipdForIekeyIeitno(hive, imenselect.getIekey(), IMPORT_ENTRY_NUMBER_1A_LINE_ITEM_NO);
        Iipd iipd = iipdByIekeyItemno.orElse(null);
        assertThat(iipd, is(notNullValue(Iipd.class)));

        Optional<Iica> iicaByIekeyItemno = HiveMSSTableReader.iicaForIekeyIeitno(hive, imenselect.getIekey(), IMPORT_ENTRY_NUMBER_1A_LINE_ITEM_NO);
        Iica iica = iicaByIekeyItemno.orElse(null);
        assertThat(iica, is(notNullValue(Iica.class)));

        //keep assert order of columns in landing_lines_declaration table
        assertThat(landingLinesDeclaration.getSource(), is(equalTo(SOURCE_MSS)));
        assertThat(landingLinesDeclaration.getIngestion_date(), is(notNullValue()));
        assertThat(landingLinesDeclaration.getEntry_number(), is(equalTo(IMPORT_ENTRY_NUMBER_1A)));
        assertThat(landingLinesDeclaration.getEntry_date(), is(equalTo(imenselect.getStandard_dtofent())));
        assertThat(landingLinesDeclaration.getEpu_number(), is(equalTo(imenselect.getEpuno())));
        assertThat(landingLinesDeclaration.getItem_number(), is(equalTo(imeiselect.getIeitno())));
        assertThat(landingLinesDeclaration.getClearance_datetime(), is(equalTo(imeiselect.getStandard_clrncdate())));
        assertThat(landingLinesDeclaration.getOrigin_country_code(), is(equalTo(imeiselect.getOrigcntry())));
        assertThat(landingLinesDeclaration.getItem_statistical_value(), is(equalTo(imeidetail.getItemstatval())));
        assertThat(landingLinesDeclaration.getCommodity_code(), is(equalTo(imeiselect.getCmdtycode())));
        assertThat(landingLinesDeclaration.getCustoms_procedure_code(), is(equalTo(imeiselect.getCpc())));
        assertThat(landingLinesDeclaration.getCustoms_duty_paid(), is(equalTo(imeidetail.getIeitcdutypaid())));
        assertThat(landingLinesDeclaration.getVat_paid(), is(equalTo(imeidetail.getIeitvatpaid())));
        assertThat(landingLinesDeclaration.getVat_value(), is(equalTo(imeidetail.getItemvatval())));
        assertThat(landingLinesDeclaration.getEc_supplementary_1(), is(equalTo(imeidetail.getEcsu1())));
        assertThat(landingLinesDeclaration.getItem_customs_value(), is(equalTo(imeidetail.getItemcstmsval())));
        assertThat(landingLinesDeclaration.getItem_net_mass(), is(equalTo(imeidetail.getItemnetmass())));
        assertThat(landingLinesDeclaration.getItem_supplementary_units(), is(equalTo(imeidetail.getItemsuppunits())));
        assertThat(landingLinesDeclaration.getGoods_description(), is(equalTo(imeidetail.getGdsdesc())));
        assertThat(landingLinesDeclaration.getItem_importer_turn(), is(equalTo(imeiselect.getItemimptrturn())));
        assertThat(landingLinesDeclaration.getItem_customs_check_code(), is(equalTo(iica.getItecccode())));
        assertThat(landingLinesDeclaration.getItem_mic_code(), is(equalTo(iica.getMic())));
        assertThat(landingLinesDeclaration.getItem_profile_id(), is(equalTo(iica.getProfid())));
        if (iina.getItemnadtype().equals("1")) {
            assertThat(landingLinesDeclaration.getItem_consignor_nad_name(), is(iina.getItemnadname()));
        } else if (iina.getItemnadtype().equals("2")) {
            assertThat(landingLinesDeclaration.getItem_consignee_nad_name(), is(iina.getItemnadname()));
        }
        assertThat(landingLinesDeclaration.getItem_consignee_nad_postcode(), is(equalTo(iina.getItemnadpostcode())));
        assertThat(landingLinesDeclaration.getItem_price_declared(), is(equalTo(imeidetail.getItemprcac())));
        assertThat(landingLinesDeclaration.getEntry_reference(), is(landingLinesDeclaration.getEpu_number() + "-" +
                landingLinesDeclaration.getEntry_number() + "-" + landingLinesDeclaration.getEntry_date().substring(0,10)));
        if (landingLinesDeclaration.getHs_code().equals(null)){
            assertThat(landingLinesDeclaration.getHs_code(), is(equalTo(null)));
        } else {
            assertThat(landingLinesDeclaration.getHs_code(), is(equalTo(imeiselect.getCmdtycode().substring(0,6))));
        }
    }

    @Test
    public void checkExportLandingLinesDeclarations() {
        Optional<LandingLinesDeclaration> landinglinesdeclaration =
                HiveLandingTableReader.readAllLandingLinesDeclarationForEntryNo(hive, EXPORT_ENTRY_NUMBER_2B, EXPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO);
        LandingLinesDeclaration landingLinesDeclaration = landinglinesdeclaration.orElse(null);
        assertThat(landingLinesDeclaration, is(notNullValue(LandingLinesDeclaration.class)));

        Optional<Nxenselect> nxenselectOptional = HiveMSSTableReader.nxenselectForImportEntryNo(hive, EXPORT_ENTRY_NUMBER_2B);
        Nxenselect nxenselect = nxenselectOptional.orElse(null);
        assertThat(nxenselect, is(notNullValue(Nxenselect.class)));

        Optional<Nxeiselect> nxeiselectForIekeyIeitno = HiveMSSTableReader.nxeiselectForIekeyIeitno(hive, nxenselect.getIekey(), EXPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO);
        Nxeiselect nxeiselect = nxeiselectForIekeyIeitno.orElse(null);
        assertThat(nxeiselect, is(notNullValue(Nxeiselect.class)));

        Optional<Nxeidetail> nxeidetailForIekeyIeitno = HiveMSSTableReader.nxeidetailForIekeyIeitno(hive, nxenselect.getIekey(), EXPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO);
        Nxeidetail nxeidetail = nxeidetailForIekeyIeitno.orElse(null);
        assertThat(nxeidetail, is(notNullValue(Nxeidetail.class)));

        Optional<Nxina> nxinaForIekeyIeitno = HiveMSSTableReader.nxinaForIekeyIeitno(hive, nxenselect.getIekey(), EXPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO);
        Nxina nxina = nxinaForIekeyIeitno.orElse(null);
        assertThat(nxina, is(notNullValue(Nxina.class)));

        //keep assert order of columns in landing_lines_declaration table
        assertThat(landingLinesDeclaration.getSource(), is(equalTo(SOURCE_MSS)));
        assertThat(landingLinesDeclaration.getIngestion_date(), is(notNullValue()));
        assertThat(landingLinesDeclaration.getEntry_number(), is(equalTo(EXPORT_ENTRY_NUMBER_2B)));
        assertThat(landingLinesDeclaration.getEntry_date(), is(equalTo(nxenselect.getStandard_dtofent())));
        assertThat(landingLinesDeclaration.getEpu_number(), is(equalTo(nxenselect.getEpuno())));
        assertThat(landingLinesDeclaration.getItem_number(), is(equalTo(nxeiselect.getIeitno())));
        assertThat(landingLinesDeclaration.getClearance_datetime(), is(equalTo(nxenselect.getStandard_clrncdate())));
        assertThat(landingLinesDeclaration.getOrigin_country_code(), is(equalTo(nxeiselect.getOrigcntry())));
        assertThat(landingLinesDeclaration.getItem_statistical_value(), is(equalTo(nxeidetail.getItemstatval())));
        assertThat(landingLinesDeclaration.getCommodity_code(), is(equalTo(nxeiselect.getCmdtycode())));
        assertThat(landingLinesDeclaration.getCustoms_procedure_code(), is(equalTo(nxeiselect.getCpc())));
        assertThat(landingLinesDeclaration.getCustoms_duty_paid(), is(equalTo(null)));
        assertThat(landingLinesDeclaration.getVat_paid(), is(equalTo(null)));
        assertThat(landingLinesDeclaration.getVat_value(), is(equalTo(nxeiselect.getItemvatval())));
        assertThat(landingLinesDeclaration.getEc_supplementary_1(), is(equalTo(nxeidetail.getEcsu1())));
        assertThat(landingLinesDeclaration.getItem_customs_value(), is(equalTo(nxeidetail.getItemcstmsval())));
        assertThat(landingLinesDeclaration.getItem_net_mass(), is(equalTo(nxeiselect.getItemnetmass())));
        assertThat(landingLinesDeclaration.getItem_supplementary_units(), is(equalTo(nxeiselect.getItemsuppunits())));
        assertThat(landingLinesDeclaration.getGoods_description(), is(equalTo(nxeidetail.getGdsdesc())));
        assertThat(landingLinesDeclaration.getItem_importer_turn(), is(equalTo(null)));
        assertThat(landingLinesDeclaration.getItem_customs_check_code(), is(equalTo(null)));
        assertThat(landingLinesDeclaration.getItem_mic_code(), is(equalTo(null)));
        assertThat(landingLinesDeclaration.getItem_profile_id(), is(equalTo(null)));
        if (nxina.getItemnadtype().equals("1")) {
            assertThat(landingLinesDeclaration.getItem_consignor_nad_name(), is(equalTo(null)));
        } else if (nxina.getItemnadtype().equals("2")) {
            assertThat(landingLinesDeclaration.getItem_consignee_nad_name(), is(equalTo(null)));
        }
        assertThat(landingLinesDeclaration.getItem_consignee_nad_postcode(), is(equalTo(null)));
        assertThat(landingLinesDeclaration.getItem_price_declared(), is(equalTo(nxeidetail.getItemprcac())));
        assertThat(landingLinesDeclaration.getEntry_reference(), is(landingLinesDeclaration.getEpu_number() + "-" +
                landingLinesDeclaration.getEntry_number() + "-" + landingLinesDeclaration.getEntry_date().substring(0,10)));

        if (landingLinesDeclaration.getHs_code().equals(null)){
            assertThat(landingLinesDeclaration.getHs_code(), is(equalTo(null)));
        } else {
            assertThat(landingLinesDeclaration.getHs_code(), is(equalTo(nxeiselect.getCmdtycode().substring(0,6))));
        }
    }
}
