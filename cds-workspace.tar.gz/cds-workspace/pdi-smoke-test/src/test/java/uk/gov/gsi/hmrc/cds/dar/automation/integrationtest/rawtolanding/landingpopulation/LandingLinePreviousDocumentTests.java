package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.rawtolanding.landingpopulation;

import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports.Nxenselect;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.exports.Nxipd;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveMSSTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed.LandingLinePreviousDocument;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.Iipd;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.imports.Imenselect;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.TestHelper;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

public class LandingLinePreviousDocumentTests extends BaseIntegrationTest implements TestHelper {

    private static final String IMPORT_ENTRY_NUMBER_1A = "IM001A";
    private static final String IMPORT_ENTRY_NUMBER_1A_LINE_ITEM_NO = "1";
    private static final String EXPORT_ENTRY_NUMBER_2B = "EX002B";
    private static final String EXPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO = "2";

    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
    }

    @Test
    public void checkImportLandingLinePreviousDocument() {
        Optional<LandingLinePreviousDocument> landinglinepreviousdocument = HiveLandingTableReader.readAllLandingLinePreviousDocumentForEntryRefNo(hive, IMPORT_ENTRY_NUMBER_1A, IMPORT_ENTRY_NUMBER_1A_LINE_ITEM_NO);
        LandingLinePreviousDocument landingLinePreviousDocument = landinglinepreviousdocument.orElse(null);

        Optional<Imenselect> imenselectOptional = HiveMSSTableReader.imenselectForImportEntryNo(hive, IMPORT_ENTRY_NUMBER_1A);
        Imenselect imenselect = imenselectOptional.orElse(null);
        assertThat(imenselect, is(notNullValue(Imenselect.class)));

        Optional<Iipd> iipdByIekeyItemno = HiveMSSTableReader.iipdForIekeyIeitno(hive, imenselect.getIekey(), IMPORT_ENTRY_NUMBER_1A_LINE_ITEM_NO);
        Iipd iipd = iipdByIekeyItemno.orElse(null);
        assertThat(iipd, is(notNullValue(Iipd.class)));

        assertThat(landingLinePreviousDocument.getSource(), is(equalTo(SOURCE_MSS)));
        assertThat(landingLinePreviousDocument.getIngestion_date(), is(notNullValue()));
        assertThat(landingLinePreviousDocument.getItem_number(), is(equalTo(iipd.getIeitno())));
        assertThat(landingLinePreviousDocument.getPrevious_document_sequence_number(), is(equalTo(iipd.getIipddataseqno())));
        assertThat(landingLinePreviousDocument.getPrevious_document_reference(), is(iipd.getPrevdocref()));
        assertThat(landingLinePreviousDocument.getEntry_reference(), is(imenselect.getEpuno() + "-" +
                imenselect.getImpentno() + "-" + imenselect.getStandard_dtofent().substring(0,10)));
    }

    @Test
    public void checkExportLandingLinePreviousDocument() {
        Optional<LandingLinePreviousDocument> landinglinepreviousdocument = HiveLandingTableReader.readAllLandingLinePreviousDocumentForEntryRefNo(hive, EXPORT_ENTRY_NUMBER_2B, EXPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO);
        LandingLinePreviousDocument landingLinePreviousDocument = landinglinepreviousdocument.orElse(null);

        Optional<Nxenselect> nxenselectOptional = HiveMSSTableReader.nxenselectForImportEntryNo(hive, EXPORT_ENTRY_NUMBER_2B);
        Nxenselect nxenselect = nxenselectOptional.orElse(null);
        assertThat(nxenselect, is(notNullValue(Nxenselect.class)));

        Optional<Nxipd> nxipdByIekeyItemno = HiveMSSTableReader.nxipdForIekeyIeitno(hive, nxenselect.getIekey(), EXPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO);
        Nxipd nxipd = nxipdByIekeyItemno.orElse(null);
        assertThat(nxipd, is(notNullValue(Nxipd.class)));

        assertThat(landingLinePreviousDocument.getSource(), is(equalTo(SOURCE_MSS)));
        assertThat(landingLinePreviousDocument.getIngestion_date(), is(notNullValue()));
        assertThat(landingLinePreviousDocument.getItem_number(), is(equalTo(nxipd.getIeitno())));
        assertThat(landingLinePreviousDocument.getPrevious_document_sequence_number(), is(equalTo(nxipd.getNxipddataseqno())));
        assertThat(landingLinePreviousDocument.getPrevious_document_reference(), is(nxipd.getPrevdocref()));
        assertThat(landingLinePreviousDocument.getEntry_reference(), is(nxenselect.getEpuno() + "-" +
                nxenselect.getImpentno() + "-" + nxenselect.getStandard_dtofent().substring(0,10)));
    }
}
