package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.datavaultpopulation;

import com.google.common.base.Stopwatch;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.links.*;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.satellites.*;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault.DimCommodityCodeHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault.DimCountryHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault.DimCurrencyHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault.DimCustomsProcedureCodeHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveDataVaultTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.hubs.*;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveDimensionHashedTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion.LandingHashedTableDataIngester;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi.PDIStage;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;

import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

/**
 * Created by smalavalli on 17/01/17.
 */
public class PopulateDVTablesPDIJobTests extends BaseIntegrationTest {
    private static Logger logger = LoggerFactory.getLogger(PopulateDVTablesPDIJobTests.class);
    private final static Stopwatch stopwatch = Stopwatch.createStarted();

    @BeforeClass
    public static void testSetUp() throws Exception {
        init();
        //clean up db
        PDIStage.CREATE_ALL_LANDING.dropAllLockTables(hive); //TODO - provide clean solution.
        PDIStage.POPULATE_DATA_VAULT.dropTablesInStage(hive);
        //data set up
        LandingHashedTableDataIngester
                .connectToDB(hive)
                .ingestData(LandingHashedTableDataIngester.LANDING_HASH_TABLES_TO_INGEST);
        logger.info("DBSetup execution time: {} seconds", stopwatch.elapsed(TimeUnit.SECONDS));
        //trigger pdi job
        boolean jobStatus = PDIStage.POPULATE_DATA_VAULT.triggerPDIJob();
        assertTrue(jobStatus);
    }

    @AfterClass
    public static void cacheSourceTables() throws Exception {
        PDIStage.CREATE_ALL_LANDING.cacheSourceTables();
        PDIStage.CREATE_LANDING_HASHED_TABLES.cacheSourceTables();
        PDIStage.POPULATE_DATA_VAULT.cacheSourceTables();
        logger.info("Total Execution time: {} seconds", stopwatch.elapsed(TimeUnit.SECONDS));
    }

    @Test
    public void checkHubTableCounts() throws Exception {
        List<HubDeclaration> hubDeclarations = HiveDataVaultTableReader.readAllHubDeclaration(hive);
        List<HubDeclarationLine> hubDeclarationLines = HiveDataVaultTableReader.readAllHubDeclarationLine(hive);
        List<HubAdditionalInfo> hubAdditionalInfo = HiveDataVaultTableReader.readAllHubAdditionalInfo(hive);
        List<HubDocument> hubDocument = HiveDataVaultTableReader.readAllHubDocument(hive);
        List<HubPreviousDocument> hubPreviousDocument = HiveDataVaultTableReader.readAllHubPreviousDocument(hive);
        List<HubTaxLine> hubTaxLine = HiveDataVaultTableReader.readAllHubTaxLine(hive);
        List<HubTrader> hubTrader = HiveDataVaultTableReader.readAllHubTrader(hive);
        List<HubCommodity> hubCommodity = HiveDataVaultTableReader.readAllHubCommodity(hive);
        List<HubCountry> hubCountry = HiveDataVaultTableReader.readAllHubCountry(hive);
        List<HubCurrency> hubCurrency = HiveDataVaultTableReader.readAllHubCurrency(hive);
        List<HubCustomsProceduceCode> hubCustomsProceduceCode = HiveDataVaultTableReader.readAllHubCustomsProceduceCode(hive);
        List<DimCommodityCodeHashed> dimCommodityCodeHashed = HiveDimensionHashedTableReader.readAllDimCommodityCodeHashed(hive);
        List<DimCountryHashed> dimCountryHashed = HiveDimensionHashedTableReader.readAllDimCountryHashed(hive);
        List<DimCurrencyHashed> dimCurrencyHashed = HiveDimensionHashedTableReader.readAllDimCurrencyHashed(hive);
        List<DimCustomsProcedureCodeHashed> dimCustomsProcedureCodeHashed = HiveDimensionHashedTableReader.readAllDimCustomsProcedureCodeHashed(hive);

        assertThat(hubDeclarations.size(), is(equalTo(IMPORT_DECLARATION_HEADERS_COUNT + EXPORT_DECLARATION_HEADERS_COUNT)));
        assertThat(hubDeclarationLines.size(), is(equalTo(IMPORT_DECLARATION_LINES_COUNT + EXPORT_DECLARATION_LINES_COUNT)));
        assertThat(hubAdditionalInfo.size(), is(equalTo(IMPORT_LINES_ADDTIONAL_INFO_COUNT + EXPORT_LINES_ADDTIONAL_INFO_COUNT)));
        assertThat(hubDocument.size(), is(equalTo(IMPORT_LINES_DOCUMENT + EXPORT_LINES_DOCUMENT)));
        assertThat(hubPreviousDocument.size(), is(equalTo(IMPORT_LINES_PREV_DOCUMENT + EXPORT_LINES_PREV_DOCUMENT)));
        assertThat(hubTaxLine.size(), is(equalTo(IMPORT_LINES_TAX_LINES + EXPORT_LINES_TAX_LINES)));
        assertThat(hubTrader.size(), is(equalTo(TRADER_COUNT)));
        assertThat(hubCommodity.size(), is(equalTo(dimCommodityCodeHashed.size())));
        assertThat(hubCountry.size(), is(equalTo(dimCountryHashed.size())));
        assertThat(hubCurrency.size(), is(equalTo(dimCurrencyHashed.size())));
        assertThat(hubCustomsProceduceCode.size(), is(equalTo(dimCustomsProcedureCodeHashed.size())));
    }

    @Test
    public void checkSatTableCounts()
    {
        List<SatDeclaration> satDeclarations = HiveDataVaultTableReader.readAllSatDeclaration(hive);
        List<SatDeclarationLine> satDeclarationLines = HiveDataVaultTableReader.readAllSatDeclarationLine(hive);
        List<SatAdditionalInfo> satAdditionalInfo = HiveDataVaultTableReader.readAllSatAdditionalInfo(hive);
        List<SatDocument> satDocument = HiveDataVaultTableReader.readAllSatDocument(hive);
        List<SatPreviousDocument> satPreviousDocument = HiveDataVaultTableReader.readAllSatPreviousDocument(hive);
        List<SatTaxLine> satTaxLine = HiveDataVaultTableReader.readAllSatTaxLine(hive);
        List<SatTrader> satTrader = HiveDataVaultTableReader.readAllSatTrader(hive);
        List<SatCommodity> satCommodity = HiveDataVaultTableReader.readAllSatCommodity(hive);
        List<SatCountry> satCountry = HiveDataVaultTableReader.readAllSatCountry(hive);
        List<SatCurrency> SatCurrency = HiveDataVaultTableReader.readAllSatCurrency(hive);
        List<DimCommodityCodeHashed> dimCommodityCodeHashed = HiveDimensionHashedTableReader.readAllDimCommodityCodeHashed(hive);
        List<DimCountryHashed> dimCountryHashed = HiveDimensionHashedTableReader.readAllDimCountryHashed(hive);
        List<DimCurrencyHashed> dimCurrencyHashed = HiveDimensionHashedTableReader.readAllDimCurrencyHashed(hive);

        assertThat(satDeclarations.size(), is(equalTo(IMPORT_DECLARATION_HEADERS_COUNT + EXPORT_DECLARATION_HEADERS_COUNT)));
        assertThat(satDeclarationLines.size(), is(equalTo(IMPORT_DECLARATION_LINES_COUNT + EXPORT_DECLARATION_LINES_COUNT)));
        assertThat(satAdditionalInfo.size(), is(equalTo(IMPORT_LINES_ADDTIONAL_INFO_COUNT + EXPORT_LINES_ADDTIONAL_INFO_COUNT)));
        assertThat(satDocument.size(), is(equalTo(IMPORT_LINES_DOCUMENT + EXPORT_LINES_DOCUMENT)));
        assertThat(satPreviousDocument.size(), is(equalTo(IMPORT_LINES_PREV_DOCUMENT + EXPORT_LINES_PREV_DOCUMENT)));
        assertThat(satTaxLine.size(), is(equalTo(IMPORT_LINES_TAX_LINES + EXPORT_LINES_TAX_LINES)));
        assertThat(satTrader.size(), is(equalTo(TRADER_COUNT)));
        assertThat(satCommodity.size(), is(equalTo(dimCommodityCodeHashed.size())));
        assertThat(satCountry.size(), is(equalTo(dimCountryHashed.size())));
        assertThat(SatCurrency.size(), is(equalTo(dimCurrencyHashed.size())));
    }

    @Test
    public void checkLinkTableCounts() {
        int totalDeclarations = IMPORT_DECLARATION_HEADERS_COUNT + EXPORT_DECLARATION_HEADERS_COUNT;
        int totalDeclarationLines = IMPORT_DECLARATION_LINES_COUNT + EXPORT_DECLARATION_LINES_COUNT;

        List<LinkDeclarationConsignorTrader> linkDeclarationConsignorTrader = HiveDataVaultTableReader.readAllLinkDeclarationConsignorTrader(hive);
        List<LinkDeclarationDeclarantTrader> linkDeclarationDeclarantTrader = HiveDataVaultTableReader.readAllLinkDeclarationDeclarantTrader(hive);
        List<LinkDeclarationDestinationCountry> linkDeclarationDestinationCountry = HiveDataVaultTableReader.readAllLinkDeclarationDestinationCountry(hive);
        List<LinkDeclarationExporterTrader> linkDeclarationExporterTrader = HiveDataVaultTableReader.readAllLinkDeclarationExporterTrader(hive);
        List<LinkDeclarationFreightCurrency> linkDeclarationFreightCurrency = HiveDataVaultTableReader.readAllLinkDeclarationFreightCurrency(hive);
        List<LinkDeclarationImporterTrader> linkDeclarationImporterTrader = HiveDataVaultTableReader.readAllLinkDeclarationImporterTrader(hive);
        List<LinkDeclarationInvoiceCurrency> linkDeclarationInvoiceCurrency = HiveDataVaultTableReader.readAllLinkDeclarationInvoiceCurrency(hive);
        List<LinkDeclarationLineAdditionalInfo> linkDeclarationLineAdditionalInfo = HiveDataVaultTableReader.readAllLinkDeclarationLineAdditonalInfo(hive);
        List<LinkDeclarationLineCommodity> linkDeclarationLineCommodities = HiveDataVaultTableReader.readAllLinkDeclarationLineCommodity(hive);
        List<LinkDeclarationLineCustomsProcedureCode> linkDeclarationLineCustomsProcedureCodes = HiveDataVaultTableReader.readAllLinkDeclarationLineCustomsProcedureCode(hive);
        List<LinkDeclarationLineDeclaration> linkDeclarationLineDeclarations = HiveDataVaultTableReader.readAllLinkDeclarationLineDeclaration(hive);
        List<LinkDeclarationLineDocument> linkDeclarationLineDocument = HiveDataVaultTableReader.readAllLinkDeclarationLineDocument(hive);
        List<LinkDeclarationLineImporterTrader> linkDeclarationLineImporterTrader = HiveDataVaultTableReader.readAllLinkDeclarationLineImporterTrader(hive);
        List<LinkDeclarationLineOriginCountry> linkDeclarationLineOriginCountries = HiveDataVaultTableReader.readAllLinkDeclarationLineOriginCountry(hive);
        List<LinkDeclarationLinePreviousDocument> linkDeclarationLinePreviousDocument = HiveDataVaultTableReader.readAllLinkDeclarationLinePreviousDocument(hive);
        List<LinkDeclarationLineTaxLine> linkDeclarationLineTaxLine = HiveDataVaultTableReader.readAllLinkDeclarationLineTaxLine(hive);
        List<LinkDeclarationPayingAgentTrader> linkDeclarationPayingAgentTrader = HiveDataVaultTableReader.readAllLinkDeclarationPayingAgentTrader(hive);
        List<LinkDeclarationTransportCountry> linkDeclarationTransportCountry = HiveDataVaultTableReader.readAllLinkDeclarationTransportCountry(hive);

        assertThat(linkDeclarationConsignorTrader.size(), is(equalTo(totalDeclarations)));
        assertThat(linkDeclarationDeclarantTrader.size(), is(equalTo(totalDeclarations)));
        assertThat(linkDeclarationDestinationCountry.size(), is(equalTo(totalDeclarations)));
        assertThat(linkDeclarationExporterTrader.size(), is(equalTo(totalDeclarations)));
        assertThat(linkDeclarationFreightCurrency.size(), is(equalTo(totalDeclarations)));
        assertThat(linkDeclarationImporterTrader.size(), is(equalTo(totalDeclarations)));
        assertThat(linkDeclarationInvoiceCurrency.size(), is(equalTo(totalDeclarations)));
        assertThat(linkDeclarationLineAdditionalInfo.size(), is(equalTo(IMPORT_LINES_ADDTIONAL_INFO_COUNT + EXPORT_LINES_ADDTIONAL_INFO_COUNT)));
        assertThat(linkDeclarationLineCommodities.size(), is(equalTo(totalDeclarationLines)));
        assertThat(linkDeclarationLineCustomsProcedureCodes.size(), is(equalTo(totalDeclarationLines)));
        assertThat(linkDeclarationLineDeclarations.size(), is(equalTo(totalDeclarationLines)));
        assertThat(linkDeclarationLineDocument.size(), is(equalTo(IMPORT_LINES_DOCUMENT + EXPORT_LINES_DOCUMENT)));
        assertThat(linkDeclarationLineImporterTrader.size(), is(equalTo(totalDeclarationLines)));
        assertThat(linkDeclarationLineOriginCountries.size(), is(equalTo(totalDeclarationLines)));
        assertThat(linkDeclarationLinePreviousDocument.size(), is(equalTo(IMPORT_LINES_PREV_DOCUMENT + EXPORT_LINES_PREV_DOCUMENT)));
        assertThat(linkDeclarationLineTaxLine.size(), is(equalTo(IMPORT_LINES_TAX_LINES + EXPORT_LINES_TAX_LINES)));
        assertThat(linkDeclarationPayingAgentTrader.size(), is(equalTo(totalDeclarations)));
        assertThat(linkDeclarationTransportCountry.size(), is(equalTo(totalDeclarations)));
    }
}