package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.rawtolanding.landingpopulation;

import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveMSSTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed.LandingHeadersDeclaration;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed.LandingTrader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.mss.standingdata.Tder;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.TestHelper;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

public class LandingTraderTests extends BaseIntegrationTest implements TestHelper {

    private static final String IMPORT_ENTRY_NUMBER_1A = "IM001A";

    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
    }

    @Test
    public void checkImportLandingTrader() {
        Optional<LandingHeadersDeclaration> landingheadersdeclaration = HiveLandingTableReader.readAlllandingHeadersDeclarationForEntryNo(hive, IMPORT_ENTRY_NUMBER_1A);
        LandingHeadersDeclaration landingHeadersDeclaration = landingheadersdeclaration.orElse(null);
        String importerTurn = landingHeadersDeclaration.getImporter_turn();

        Optional<Tder> tderOptional = HiveMSSTableReader.tderForTraderTurn(hive, importerTurn);
        Tder tder = tderOptional.orElse(null);

        Optional<LandingTrader> landingTraderOptional = HiveLandingTableReader.readAllLandingTraderForTurn(hive, importerTurn);
        LandingTrader landingTrader = landingTraderOptional.orElse(null);

        assertThat(landingTrader.getSource(), is(equalTo(SOURCE_MSS)));
        assertThat(landingTrader.getIngestion_date(), is(notNullValue()));
        assertThat(landingTrader.getTurn(), is(equalTo(tder.getTurn())));
        assertThat(landingTrader.getFedate(), is(equalTo(tder.getFedate())));
        assertThat(landingTrader.getName(), is(equalTo(tder.getTdrnameall())));
        assertThat(landingTrader.getSimplified_procedure_authorisations(), is(equalTo(tder.getTdrspauths())));
        assertThat(landingTrader.getTrader_name_abbreviated(), is(equalTo(tder.getTdrabbrnm())));
        assertThat(landingTrader.getCurrentind(), is(equalTo(tder.getCurrentind())));
    }
}
