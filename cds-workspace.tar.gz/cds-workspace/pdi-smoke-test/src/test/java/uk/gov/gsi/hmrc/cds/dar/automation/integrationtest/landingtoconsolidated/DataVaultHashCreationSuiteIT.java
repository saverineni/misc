package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.datavaulthashcreation.*;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        CreateDVHashesPDIJobTests.class,
        LandingHeadersDeclarationHashesTests.class,
        LandingLinesDeclarationHashesTests.class,
        LandingLineAdditionalInfoHashesTests.class,
        LandingLineDocumentHashesTests.class,
        LandingLinePreviousDocumentHashesTests.class,
        LandingLineTaxLineHashesTests.class,
        LandingTraderHashesTests.class,
        DimCommodityCodeHashTests.class,
        DimCountryHashesTests.class,
        DimCurrencyHashTests.class,
        DimCustomsProcedureCodeHashTests.class
})

public class DataVaultHashCreationSuiteIT extends BaseIntegrationTest{

    @BeforeClass
    public static void initialise() {
        init();
    }
}
