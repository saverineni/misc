package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.datavaultpopulation;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.datavault.hubs.*;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault.*;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed.*;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveDataVaultTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveDimensionHashedTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingHashedTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.TestHelper;

import java.util.List;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

public class DVHubTests extends BaseIntegrationTest implements TestHelper {

    private static final String COUNTRY_CODE = "DE";
    private static final String COMMODITY_CODE = "230990";
    private static final String CURRENCY_CODE = "MMK";
    private static final String CUSTOMS_PROCEDURE_CODE = "6121004";
    private static final String IMPORT_ENTRY_NUMBER_3C = "IM003C";
    private static final String IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_1 = "1";
    private static final String IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_2 = "2";
    private static final String IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3 = "3";
    private static final String IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3_SEQ_NO_1 = "1";
    private static final String IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3_SEQ_NO_2 = "2";
    private static final String IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3_SEQ_NO_3 = "3";
    private String entryReference;
    private LandingHeadersDeclarationHashed landingHeadersDeclarationHashed;

    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
    }

    @Before
    public void dataReaderSetup() throws Exception {
        Optional<LandingHeadersDeclarationHashed> landingHeadersDeclarationHashedOptional = HiveLandingHashedTableReader.landingHeadersDeclarationHashedForEntryNo(hive, IMPORT_ENTRY_NUMBER_3C);
        landingHeadersDeclarationHashed = landingHeadersDeclarationHashedOptional.orElse(null);
        entryReference = buildEntryReferenceForDeclaration(landingHeadersDeclarationHashed);
    }

    @Test
    public void verifyHubDeclaration() {
        Optional<HubDeclaration> hubDeclarationOptional = HiveDataVaultTableReader.hubDeclarationForEntryReference(hive, entryReference);
        HubDeclaration hubDeclaration = hubDeclarationOptional.orElse(null);

        assertThat(hubDeclaration.getHub_declaration_key(), is(equalTo(landingHeadersDeclarationHashed.getHub_declaration())));
        assertThat(hubDeclaration.getEntry_reference(), is(equalTo(landingHeadersDeclarationHashed.getEntry_reference())));
        assertThat(hubDeclaration.getHub_load_datetime(), is(notNullValue()));
        assertThat(hubDeclaration.getHub_record_source(), is(equalTo(landingHeadersDeclarationHashed.getSource())));
    }

    @Test
    public void verifyHubDeclarationLine() {
        Optional<LandingLinesDeclarationHashed> declarationLinesHashedOptional
                = HiveLandingHashedTableReader.landingLinesDeclarationHashedForEntryNoItemNo(hive, IMPORT_ENTRY_NUMBER_3C, IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3);
        LandingLinesDeclarationHashed landingLinesDeclarationHashed = declarationLinesHashedOptional.orElse(null);
        assertThat(landingLinesDeclarationHashed, is(notNullValue()));
        entryReference = landingLinesDeclarationHashed.getEntry_reference();

        Optional<HubDeclarationLine> hubDeclarationLineOptional = HiveDataVaultTableReader.hubDeclarationLineForEntryReferenceItemNo(hive, entryReference, IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3);
        HubDeclarationLine hubDeclarationLine = hubDeclarationLineOptional.orElse(null);

        assertThat(hubDeclarationLine.getHub_declaration_line_key(), is(equalTo(landingLinesDeclarationHashed.getHub_declaration_line())));
        assertThat(hubDeclarationLine.getEntry_reference(), is(equalTo(landingLinesDeclarationHashed.getEntry_reference())));
        assertThat(hubDeclarationLine.getItem_number(), is(equalTo(landingLinesDeclarationHashed.getItem_number())));
        assertThat(hubDeclarationLine.getHub_load_datetime(), is(notNullValue()));
        assertThat(hubDeclarationLine.getHub_record_source(), is(equalTo(landingLinesDeclarationHashed.getSource())));
    }

    @Test
    public void verifyHubAddtionalInfo() {
        Optional<LandingLineAdditionalInformationHashed> landingLineAdditionalInformationHashedOptional =
                HiveLandingHashedTableReader.landingLineAdditionalInformationHashedForEntryReferenceItemNoSeqNo(
                        hive,
                        entryReference,
                        IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3,
                        IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3_SEQ_NO_1);
        LandingLineAdditionalInformationHashed landingLineAdditionalInformationHashed = landingLineAdditionalInformationHashedOptional.orElse(null);

        Optional<HubAdditionalInfo> hubAdditionalInfoOptional = HiveDataVaultTableReader.hubAdditionalInfoForEntryReferenceItemNoSeqNo(hive,
                entryReference, IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3, IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3_SEQ_NO_1);
        HubAdditionalInfo hubAdditionalInfo = hubAdditionalInfoOptional.orElse(null);

        assertThat(hubAdditionalInfo.getHub_additional_info_key(), is(equalTo(landingLineAdditionalInformationHashed.getHub_additional_info())));
        assertThat(hubAdditionalInfo.getEntry_reference(), is(equalTo(landingLineAdditionalInformationHashed.getEntry_reference())));
        assertThat(hubAdditionalInfo.getItem_number(), is(equalTo(landingLineAdditionalInformationHashed.getItem_number())));
        assertThat(hubAdditionalInfo.getAdditional_information_sequence_number(), is(equalTo(landingLineAdditionalInformationHashed.getAdditional_information_sequence_number())));
        assertThat(hubAdditionalInfo.getHub_load_datetime(), is(notNullValue()));
        assertThat(hubAdditionalInfo.getHub_record_source(), is(equalTo(landingLineAdditionalInformationHashed.getSource())));
    }

    @Test
    public void verifyHubCommodity() {
        Optional<HubCommodity> hubCommodityOptional = HiveDataVaultTableReader.hubCommodityForCommodityCode(hive, COMMODITY_CODE);
        HubCommodity hubCommodity = hubCommodityOptional.orElse(null);

        Optional<DimCommodityCodeHashed> dimCommodityCodeHashedOptional =
                HiveDimensionHashedTableReader.readAllDimCommodityCodeHashedCommodityCode(hive, COMMODITY_CODE);
        DimCommodityCodeHashed dimCommodityCodeHashed = dimCommodityCodeHashedOptional.orElse(null);

        assertThat(hubCommodity.getHub_commodity_key(), is(equalTo(dimCommodityCodeHashed.getHub_commodity())));
        assertThat(hubCommodity.getCommodity_code(), is(equalTo(dimCommodityCodeHashed.getHs_code())));
        assertThat(hubCommodity.getHub_load_datetime(), is(notNullValue()));
        assertThat(hubCommodity.getHub_record_source(), is(equalTo(SOURCE_DIM_COMMODITY_CODE)));
    }

    @Test
    public void verifyHubCountry() {
        Optional<HubCountry> hubCountryOptional = HiveDataVaultTableReader.hubCountryForCountryCode(hive, COUNTRY_CODE);
        HubCountry hubCountry = hubCountryOptional.orElse(null);

        Optional<DimCountryHashed> dimCountryHashedOptional = HiveDimensionHashedTableReader.readAllDimCountryHashedCountryCode(hive, COUNTRY_CODE);
        DimCountryHashed dimCountryHashed = dimCountryHashedOptional.orElse(null);

        assertThat(hubCountry.getHub_country_key(), is(equalTo(dimCountryHashed.getHub_country())));
        assertThat(hubCountry.getIso_country_code_alpha_2(), is(equalTo(dimCountryHashed.getCountry_iso_code())));
        assertThat(hubCountry.getHub_load_datetime(), is(notNullValue()));
        assertThat(hubCountry.getHub_record_source(), is(equalTo(SOURCE_DIM_COUNTRY)));
    }

    @Test
    public void verifyHubCurrency() {
        Optional<HubCurrency> hubCurrencyOptional = HiveDataVaultTableReader.hubCurrencyForCurrencyCode(hive, CURRENCY_CODE);
        HubCurrency hubCurrency = hubCurrencyOptional.orElse(null);

        Optional<DimCurrencyHashed> dimCurrencyHashedOptional = HiveDimensionHashedTableReader.readAllDimCurrencyHashedCurrencyCode(hive, CURRENCY_CODE);
        DimCurrencyHashed dimCurrencyHashed = dimCurrencyHashedOptional.orElse(null);

        assertThat(hubCurrency.getHub_currency_key(), is(equalTo(dimCurrencyHashed.getHub_currency())));
        assertThat(hubCurrency.getCurrency_iso_code(), is(equalTo(dimCurrencyHashed.getCurrency_iso_code())));
        assertThat(hubCurrency.getHub_load_datetime(), is(notNullValue()));
        assertThat(hubCurrency.getHub_record_source(), is(equalTo(SOURCE_DIM_CURRENCY)));
    }

    @Test
    public void verifyHubCustomsProcedureCode() {
        Optional<HubCustomsProceduceCode> hubCustomsProceduceCodeOptional = HiveDataVaultTableReader.hubCustomsProceduceCodeForCPC(hive, CUSTOMS_PROCEDURE_CODE);
        HubCustomsProceduceCode hubCustomsProceduceCode = hubCustomsProceduceCodeOptional.orElse(null);

        Optional<DimCustomsProcedureCodeHashed> dimCustomsProcedureCodeHashedOptional = HiveDimensionHashedTableReader.readAllDimCustomsProcedureCodeHashedCPC(hive, CUSTOMS_PROCEDURE_CODE);
        DimCustomsProcedureCodeHashed dimCustomsProcedureCodeHashed = dimCustomsProcedureCodeHashedOptional.orElse(null);

        assertThat(hubCustomsProceduceCode.getHub_customs_procedure_code_key(), is(equalTo(dimCustomsProcedureCodeHashed.getHub_customs_procedure_code())));
        assertThat(hubCustomsProceduceCode.getCustoms_procedure_code(), is(equalTo(dimCustomsProcedureCodeHashed.getCustoms_procedure_code())));
        assertThat(hubCustomsProceduceCode.getHub_load_datetime(), is(notNullValue()));
        assertThat(hubCustomsProceduceCode.getHub_record_source(), is(equalTo(SOURCE_DIM_CUSTOMS_PROCEDURE_CODE)));
    }

    @Test
    public void verifyHubDocument() {
        Optional<LandingLineDocumentHashed> landingLineDocumentHashedOptional = HiveLandingHashedTableReader.landingLineDocumentHashedForEntryReferenceItemNoSeqNo( hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3,
                IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3_SEQ_NO_1);
        LandingLineDocumentHashed landingLineDocumentHashed = landingLineDocumentHashedOptional.orElse(null);

        Optional<HubDocument> hubDocumentOptional = HiveDataVaultTableReader.hubDocumentForEntryReferenceItemNoSeqNo(hive,
                entryReference, IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3, IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3_SEQ_NO_1);
        HubDocument hubDocument = hubDocumentOptional.orElse(null);

        assertThat(hubDocument.getHub_document_key(), is(equalTo(landingLineDocumentHashed.getHub_document())));
        assertThat(hubDocument.getEntry_reference(), is(equalTo(landingLineDocumentHashed.getEntry_reference())));
        assertThat(hubDocument.getItem_number(), is(equalTo(landingLineDocumentHashed.getItem_number())));
        assertThat(hubDocument.getDocument_sequence_number(), is(equalTo(landingLineDocumentHashed.getDocument_sequence_number())));
        assertThat(hubDocument.getHub_load_datetime(), is(notNullValue()));
        assertThat(hubDocument.getHub_record_source(), is(equalTo(landingLineDocumentHashed.getSource())));
    }

    @Test
    public void verifyHubPreviousDocument() {
        Optional<LandingLinePreviousDocumentHashed> landingLinePreviousDocumentHashedOptional = HiveLandingHashedTableReader.landingLinePreviousDocumentHashedForEntryReferenceItemNoSeqNo( hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3,
                IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3_SEQ_NO_3);
        LandingLinePreviousDocumentHashed landingLinePreviousDocumentHashed = landingLinePreviousDocumentHashedOptional.orElse(null);

        Optional<HubPreviousDocument> hubPreviousDocumentOptional = HiveDataVaultTableReader.hubPreviousDocumentForEntryReferenceItemNoSeqNo(hive,
                entryReference, IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3, IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3_SEQ_NO_3);
        HubPreviousDocument hubPreviousDocument = hubPreviousDocumentOptional.orElse(null);

        assertThat(hubPreviousDocument.getHub_previous_document_key(), is(equalTo(landingLinePreviousDocumentHashed.getHub_previous_document())));
        assertThat(hubPreviousDocument.getEntry_reference(), is(equalTo(landingLinePreviousDocumentHashed.getEntry_reference())));
        assertThat(hubPreviousDocument.getItem_number(), is(equalTo(landingLinePreviousDocumentHashed.getItem_number())));
        assertThat(hubPreviousDocument.getPrevious_document_sequence_number(), is(equalTo(landingLinePreviousDocumentHashed.getPrevious_document_sequence_number())));
        assertThat(hubPreviousDocument.getHub_load_datetime(), is(notNullValue()));
        assertThat(hubPreviousDocument.getHub_record_source(), is(equalTo(landingLinePreviousDocumentHashed.getSource())));
    }

    @Test
    public void verifyHubTaxLine() {
        Optional<LandingLineTaxLineHashed> landingLineTaxLineHashedOptional = HiveLandingHashedTableReader.landingLineTaxLineHashedForEntryReferenceItemNoSeqNo( hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_1,
                IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3_SEQ_NO_1);
        LandingLineTaxLineHashed landingLineTaxLineHashed = landingLineTaxLineHashedOptional.orElse(null);

        Optional<HubTaxLine> hubTaxLineOptional = HiveDataVaultTableReader.hubTaxLineForEntryReferenceItemNoSeqNo(hive,
                entryReference, IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_1, IMPORT_ENTRY_NUMBER_3C_LINE_ITEM_NO_3_SEQ_NO_1);
        HubTaxLine hubTaxLine = hubTaxLineOptional.orElse(null);

        assertThat(hubTaxLine.getHub_tax_line_key(), is(equalTo(landingLineTaxLineHashed.getHub_tax_line())));
        assertThat(hubTaxLine.getEntry_reference(), is(equalTo(landingLineTaxLineHashed.getEntry_reference())));
        assertThat(hubTaxLine.getItem_number(), is(equalTo(landingLineTaxLineHashed.getItem_number())));
        assertThat(hubTaxLine.getTax_line_sequence_number(), is(equalTo(landingLineTaxLineHashed.getTax_line_sequence_number())));
        assertThat(hubTaxLine.getHub_load_datetime(), is(notNullValue()));
        assertThat(hubTaxLine.getHub_record_source(), is(equalTo(landingLineTaxLineHashed.getSource())));
    }

    @Test
    public void verifyHubTrader() {
        String importerTurn = landingHeadersDeclarationHashed.getImporter_turn();
        Optional<LandingTraderHashed> landingTraderHashedOptional = HiveLandingHashedTableReader.landingTraderHashedForTurn(hive, importerTurn);
        LandingTraderHashed landingTraderHashed = landingTraderHashedOptional.orElse(null);

        Optional<HubTrader> hubTraderOptional = HiveDataVaultTableReader.hubTraderForImporterTurn(hive, importerTurn);
        HubTrader hubTrader = hubTraderOptional.orElse(null);

        assertThat(hubTrader.getHub_trader_key(), is(equalTo(landingTraderHashed.getHub_trader())));
        assertThat(hubTrader.getTurn(), is(equalTo(landingTraderHashed.getTurn())));
        assertThat(hubTrader.getHub_load_datetime(), is(notNullValue()));
        assertThat(hubTrader.getHub_record_source(), is(equalTo(landingTraderHashed.getSource())));
    }
}