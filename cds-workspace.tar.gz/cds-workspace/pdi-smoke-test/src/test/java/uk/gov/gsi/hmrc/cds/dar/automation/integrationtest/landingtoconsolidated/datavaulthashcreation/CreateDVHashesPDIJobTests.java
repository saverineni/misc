package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.datavaulthashcreation;

import com.google.common.base.Stopwatch;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault.*;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveDimensionHashedTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveDimensionTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingHashedTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed.*;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion.LandingTableDataIngester;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi.PDIStage;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;

import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

/**
 * Created by smalavalli on 11/01/17.
 */
public class CreateDVHashesPDIJobTests extends BaseIntegrationTest {
    private static Logger logger = LoggerFactory.getLogger(CreateDVHashesPDIJobTests.class);
    private final static Stopwatch stopwatch = Stopwatch.createStarted();

    @BeforeClass
    public static void testSetUp() throws Exception {
        init();
        PDIStage.CREATE_ALL_LANDING.dropAllLockTables(hive); //TODO - provide clean solution.
        PDIStage.CREATE_LANDING_HASHED_TABLES.dropTablesInStage(hive);
        //PDIStage.CREATE_LANDING_HASHED_TABLES.invalidateSourceTableCache();
        LandingTableDataIngester
                .connectToDB(hive)
                .ingestData(LandingTableDataIngester.LANDING_TABLES_TO_INGEST);
        logger.info("DBSetup execution time: {} seconds", stopwatch.elapsed(TimeUnit.SECONDS));
        boolean jobStatus = PDIStage.CREATE_LANDING_HASHED_TABLES.triggerPDIJob();
        assertTrue(jobStatus);
    }

    @AfterClass
    public static void cacheSourceTables() throws Exception {
        PDIStage.CREATE_ALL_LANDING.cacheSourceTables();
        PDIStage.CREATE_LANDING_HASHED_TABLES.cacheSourceTables();
        logger.info("Total Execution time: {} seconds", stopwatch.elapsed(TimeUnit.SECONDS));
    }

    @Test
    public void checkLandingHashTablesCount() throws Exception {
        List<LandingHeadersDeclarationHashed> headersDeclarationHashed = HiveLandingHashedTableReader.readAllLandingHeadersDeclarationHashed(hive);
        List<LandingLinesDeclarationHashed> linesDeclarationHashed = HiveLandingHashedTableReader.readAllLandingLinesDeclarationHashed(hive);
        List<LandingLineAdditionalInformationHashed> lineAdditionalInformationHashed = HiveLandingHashedTableReader.readAllLandingLineAdditionalInformationHashed(hive);
        List<LandingLineDocumentHashed> lineDocumentHashed = HiveLandingHashedTableReader.readAllLandingLineDocumentHashed(hive);
        List<LandingLinePreviousDocumentHashed> linePreviousDocumentHashed = HiveLandingHashedTableReader.readAllLandingPreviousDocumentHashed(hive);
        List<LandingLineTaxLineHashed> lineTaxLineHashed = HiveLandingHashedTableReader.readAllLandingLineTaxLineHashed(hive);
        List<LandingTraderHashed> traderHashed = HiveLandingHashedTableReader.readAllLandingTraderHashed(hive);

        assertThat(headersDeclarationHashed, is(notNullValue()));
        assertThat(headersDeclarationHashed.size(), is(equalTo(IMPORT_DECLARATION_HEADERS_COUNT + EXPORT_DECLARATION_HEADERS_COUNT)));
        assertThat(linesDeclarationHashed, is(notNullValue()));
        assertThat(linesDeclarationHashed.size(), is(equalTo(IMPORT_DECLARATION_LINES_COUNT + EXPORT_DECLARATION_LINES_COUNT)));
        assertThat(lineAdditionalInformationHashed, is(notNullValue()));
        assertThat(lineAdditionalInformationHashed.size(), is(equalTo(IMPORT_LINES_ADDTIONAL_INFO_COUNT + EXPORT_LINES_ADDTIONAL_INFO_COUNT)));
        assertThat(lineDocumentHashed, is(notNullValue()));
        assertThat(lineDocumentHashed.size(), is(equalTo(IMPORT_LINES_DOCUMENT + EXPORT_LINES_DOCUMENT)));
        assertThat(linePreviousDocumentHashed, is(notNullValue()));
        assertThat(linePreviousDocumentHashed.size(), is(equalTo(IMPORT_LINES_PREV_DOCUMENT + EXPORT_LINES_PREV_DOCUMENT)));
        assertThat(lineTaxLineHashed, is(notNullValue()));
        assertThat(lineTaxLineHashed.size(), is(equalTo(IMPORT_LINES_TAX_LINES + EXPORT_LINES_TAX_LINES)));
        assertThat(traderHashed, is(notNullValue()));
        assertThat(traderHashed.size(), is(equalTo(TRADER_COUNT)));
    }

    @Test
    public void checkDimensionHashTableCounts() {
        List<DimCommodityCodeHashed> dimCommodityCodeHashed = HiveDimensionHashedTableReader.readAllDimCommodityCodeHashed(hive);
        List<DimCountryHashed> dimCountryHashed = HiveDimensionHashedTableReader.readAllDimCountryHashed(hive);
        List<DimCurrencyHashed> dimCurrencyHashed = HiveDimensionHashedTableReader.readAllDimCurrencyHashed(hive);
        List<DimCustomsProcedureCodeHashed> dimCustomsProcedureCodeHashed = HiveDimensionHashedTableReader.readAllDimCustomsProcedureCodeHashed(hive);
        List<DimCommodityCode> dimCommodityCode = HiveDimensionTableReader.readAllDimCommodityCode(hive);
        List<DimCurrency> dimCurrency = HiveDimensionTableReader.readAllDimCurrency(hive);
        List<DimCountry> dimCountry = HiveDimensionTableReader.readAllDimCountry(hive);
        List<DimCustomsProcedureCode> dimCustomsProcedureCode = HiveDimensionTableReader.readAllDimCustomsProcedureCode(hive);

        assertThat(dimCommodityCodeHashed.size(), is(equalTo(dimCommodityCode.size())));
        assertThat(dimCountryHashed.size(), is(equalTo(dimCountry.size())));
        assertThat(dimCurrencyHashed.size(), is(equalTo(dimCurrency.size())));
        assertThat(dimCustomsProcedureCodeHashed.size(), is(equalTo(dimCustomsProcedureCode.size())));
    }
}
