package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.datavaulthashcreation;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingHashedTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed.LandingHeadersDeclarationHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed.LandingLineTaxLine;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed.LandingLineTaxLineHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.TestHelper;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.MD5Hasher.md5HashOf;

public class LandingLineTaxLineHashesTests extends BaseIntegrationTest implements TestHelper {

    private static final String IMPORT_ENTRY_NUMBER_5E = "IM005E";
    private static final String IMPORT_ENTRY_NUMBER_5E_LINE_ITEM_NO_5 = "5";
    private static final String IMPORT_ENTRY_NUMBER_5E_LINE_ITEM_NO_5_SEQ_NO = "1";
    private String entryReference;
    private LandingLineTaxLineHashed landingLineTaxLineHashed;

    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
    }

    @Before
    public void dataReadersSetup() {
        Optional<LandingHeadersDeclarationHashed> landingHeadersDeclarationHashedOptional = HiveLandingHashedTableReader.landingHeadersDeclarationHashedForEntryNo(hive, IMPORT_ENTRY_NUMBER_5E);
        LandingHeadersDeclarationHashed landingHeadersDeclarationHashed = landingHeadersDeclarationHashedOptional.orElse(null);
        entryReference = buildEntryReferenceForDeclaration(landingHeadersDeclarationHashed);

        Optional<LandingLineTaxLineHashed> landingLineTaxLineHashedOptional = HiveLandingHashedTableReader.landingLineTaxLineHashedForEntryReferenceItemNoSeqNo( hive,
                entryReference,
                IMPORT_ENTRY_NUMBER_5E_LINE_ITEM_NO_5,
                IMPORT_ENTRY_NUMBER_5E_LINE_ITEM_NO_5_SEQ_NO);
        landingLineTaxLineHashed = landingLineTaxLineHashedOptional.orElse(null);
    }

    @Test
    public void checkMD5ForHubAndSatDeclaration() {
        String hubDeclarationMD5 = md5HashOf(
                                        entryReference,
                                        IMPORT_ENTRY_NUMBER_5E_LINE_ITEM_NO_5,
                                        IMPORT_ENTRY_NUMBER_5E_LINE_ITEM_NO_5_SEQ_NO
                                   );
        String satDeclarationMD5 = md5HashOf(
                                        landingLineTaxLineHashed.getGeneration_number(),
                                        landingLineTaxLineHashed.getWaived_tax(),
                                        landingLineTaxLineHashed.getMethod_of_payment_code(),
                                        landingLineTaxLineHashed.getTax_amount(),
                                        landingLineTaxLineHashed.getTax_type_code()
                                   );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLineTaxLineHashed.getHub_tax_line().length())));
        assertThat(hubDeclarationMD5, is(equalTo(landingLineTaxLineHashed.getHub_tax_line())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLineTaxLineHashed.getSat_tax_line().length())));
        assertThat(satDeclarationMD5, is(equalTo(landingLineTaxLineHashed.getSat_tax_line())));
    }

    @Test
    public void checkMD5ForDeclarationLineTaxLine() {
        String linkDeclarationLineTaxLineMD5 = md5HashOf(
                                                    entryReference,
                                                    IMPORT_ENTRY_NUMBER_5E_LINE_ITEM_NO_5,
                                                    IMPORT_ENTRY_NUMBER_5E_LINE_ITEM_NO_5_SEQ_NO
                                               );
        String linkDeclarationLineTaxLineHubDeclarationLineMD5 = md5HashOf(
                                                                        entryReference,
                                                                        IMPORT_ENTRY_NUMBER_5E_LINE_ITEM_NO_5
                                                                 );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLineTaxLineHashed.getLink_declaration_line_tax_line().length())));
        assertThat(linkDeclarationLineTaxLineMD5, is(equalTo(landingLineTaxLineHashed.getLink_declaration_line_tax_line())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLineTaxLineHashed.getLink_declaration_line_tax_line_hub_declaration_line().length())));
        assertThat(linkDeclarationLineTaxLineHubDeclarationLineMD5, is(equalTo(landingLineTaxLineHashed.getLink_declaration_line_tax_line_hub_declaration_line())));
    }

    @Test
    public void checkLandingLineTaxLineHashedMatchesLandingLineTaxLine() {
        Optional<LandingLineTaxLine> lineTaxLineOptional = HiveLandingTableReader.readAllLandingLineTaxLineForEntryRefNoAndSeqNo(hive, entryReference,
                IMPORT_ENTRY_NUMBER_5E_LINE_ITEM_NO_5, IMPORT_ENTRY_NUMBER_5E_LINE_ITEM_NO_5_SEQ_NO);
        LandingLineTaxLine landingLineTaxLine = lineTaxLineOptional.orElse(null);
        assertThat(landingLineTaxLine, is(notNullValue(LandingLineTaxLine.class)));

        assertThat(landingLineTaxLineHashed.getSource(), is(equalTo(landingLineTaxLine.getSource())));
        assertThat(landingLineTaxLineHashed.getIngestion_date(), is(equalTo(landingLineTaxLine.getIngestion_date())));
        assertThat(landingLineTaxLineHashed.getItem_number(), is(equalTo(landingLineTaxLine.getItem_number())));
        assertThat(landingLineTaxLineHashed.getTax_line_sequence_number(), is(equalTo(landingLineTaxLine.getTax_line_sequence_number())));
        assertThat(landingLineTaxLineHashed.getGeneration_number(), is(equalTo(landingLineTaxLine.getGeneration_number())));
        assertThat(landingLineTaxLineHashed.getWaived_tax(), is(equalTo(landingLineTaxLine.getWaived_tax())));
        assertThat(landingLineTaxLineHashed.getMethod_of_payment_code(), is(equalTo(landingLineTaxLine.getMethod_of_payment_code())));
        assertThat(landingLineTaxLineHashed.getTax_amount(), is(equalTo(landingLineTaxLine.getTax_amount())));
        assertThat(landingLineTaxLineHashed.getTax_type_code(), is(equalTo(landingLineTaxLine.getTax_type_code())));
        assertThat(landingLineTaxLineHashed.getEntry_reference(), is(equalTo(landingLineTaxLine.getEntry_reference())));
    }
}