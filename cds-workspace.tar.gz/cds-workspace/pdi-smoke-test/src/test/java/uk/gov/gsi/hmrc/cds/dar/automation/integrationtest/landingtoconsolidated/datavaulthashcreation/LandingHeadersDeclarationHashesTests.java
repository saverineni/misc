package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.datavaulthashcreation;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingHashedTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed.LandingHeadersDeclaration;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed.LandingHeadersDeclarationHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.TestHelper;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.assertThat;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.MD5Hasher.md5HashOf;

public class LandingHeadersDeclarationHashesTests extends BaseIntegrationTest implements TestHelper {

    private static final String IMPORT_ENTRY_NUMBER_1A = "IM001A";
    private LandingHeadersDeclarationHashed landingHeadersDeclarationHashed;
    private String entryReference;

    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
    }

    @Before
    public void dataReaderSetup() throws Exception {
        Optional<LandingHeadersDeclarationHashed> landingHeadersDeclarationHashedOptional =
                HiveLandingHashedTableReader.landingHeadersDeclarationHashedForEntryNo(hive, IMPORT_ENTRY_NUMBER_1A);
        landingHeadersDeclarationHashed = landingHeadersDeclarationHashedOptional.orElse(null);
        entryReference = buildEntryReferenceForDeclaration(landingHeadersDeclarationHashed);
    }

    @Test
    public void checkMD5ForHubAndSatDeclaration() {
        String hubDeclarationMD5 = md5HashOf(
                                        entryReference
                                   );
        String satDeclarationMD5 = md5HashOf(
                                        landingHeadersDeclarationHashed.getEntry_number(),
                                        landingHeadersDeclarationHashed.getEntry_date(),
                                        landingHeadersDeclarationHashed.getEpu_number(),
                                        landingHeadersDeclarationHashed.getEntry_type(),
                                        landingHeadersDeclarationHashed.getDeclaration_method(),
                                        landingHeadersDeclarationHashed.getTotal_excise(),
                                        landingHeadersDeclarationHashed.getDeclarant_representative_turn(),
                                        landingHeadersDeclarationHashed.getConsignee_aeo_certificate_type_code(),
                                        landingHeadersDeclarationHashed.getDeclarant_aeo_certificate_type_code(),
                                        landingHeadersDeclarationHashed.getRoute(),
                                        landingHeadersDeclarationHashed.getDeclaration_import_export_indicator(),
                                        landingHeadersDeclarationHashed.getGeneration_number(),
                                        landingHeadersDeclarationHashed.getImport_clearance_status(),
                                        landingHeadersDeclarationHashed.getConsignor_aeo_certificate_type_code(),
                                        landingHeadersDeclarationHashed.getHeader_statistical_value(),
                                        landingHeadersDeclarationHashed.getGoods_departure_datetime(),
                                        landingHeadersDeclarationHashed.getCustoms_value(),
                                        landingHeadersDeclarationHashed.getTotal_duty(),
                                        landingHeadersDeclarationHashed.getTotal_vat(),
                                        landingHeadersDeclarationHashed.getNet_mass_total(),
                                        landingHeadersDeclarationHashed.getGoods_location(),
                                        landingHeadersDeclarationHashed.getAcceptance_date(),
                                        landingHeadersDeclarationHashed.getImporter_turn_country_code(),
                                        landingHeadersDeclarationHashed.getPlace_of_unloading_code(),
                                        landingHeadersDeclarationHashed.getFirst_deferment_approval_num(),
                                        landingHeadersDeclarationHashed.getFirst_deferment_approval_num_prefix(),
                                        landingHeadersDeclarationHashed.getDeclaration_ucr(),
                                        landingHeadersDeclarationHashed.getItem_count(),
                                        landingHeadersDeclarationHashed.getMaster_ucr(),
                                        landingHeadersDeclarationHashed.getPaying_agent_turn(),
                                        landingHeadersDeclarationHashed.getPlace_of_loading_code(),
                                        landingHeadersDeclarationHashed.getSession_num(),
                                        landingHeadersDeclarationHashed.getSession_role_name(),
                                        landingHeadersDeclarationHashed.getStatus_of_entry(),
                                        landingHeadersDeclarationHashed.getTransport_country(),
                                        landingHeadersDeclarationHashed.getTransport_id(),
                                        landingHeadersDeclarationHashed.getTransport_mode_code(),
                                        landingHeadersDeclarationHashed.getDispatch_country(),
                                        landingHeadersDeclarationHashed.getConsignor_turn_country_code(),
                                        landingHeadersDeclarationHashed.getConsignor_nad_name(),
                                        landingHeadersDeclarationHashed.getConsignee_nad_name(),
                                        landingHeadersDeclarationHashed.getConsignee_nad_postcode(),
                                        landingHeadersDeclarationHashed.getDeclarant_nad_name(),
                                        landingHeadersDeclarationHashed.getCustoms_check_code(),
                                        landingHeadersDeclarationHashed.getProfile_id(),
                                        landingHeadersDeclarationHashed.getInvoice_total_declared()
                                );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getHub_declaration().length())));
        assertThat(hubDeclarationMD5, is(equalTo(landingHeadersDeclarationHashed.getHub_declaration())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getSat_declaration().length())));
        assertThat(satDeclarationMD5, is(equalTo(landingHeadersDeclarationHashed.getSat_declaration())));
    }

    @Test
    public void checkMD5ForDeclarationConsignorTrader() {
        String consignorTurn =  landingHeadersDeclarationHashed.getConsignor_turn();
        String linkConsignorTraderMD5 = md5HashOf(
                                            entryReference,
                                            consignorTurn
                                        );
        String linkConsignorTraderHubTraderMD5 = md5HashOf(
                                            consignorTurn
                                        );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_consignor_trader().length())));
        assertThat(linkConsignorTraderMD5, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_consignor_trader())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_consignor_trader_hub_trader().length())));
        assertThat(linkConsignorTraderHubTraderMD5, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_consignor_trader_hub_trader())));
    }

    @Test
    public void checkMD5ForDeclarationDeclarantTrader() {
        String declarantTurn =  landingHeadersDeclarationHashed.getDeclarant_turn();
        String linkDeclarantTraderMD5 = md5HashOf(
                                            entryReference,
                                            declarantTurn
                                        );
        String linkDeclarantTraderHubTraderMD5 = md5HashOf(
                                            declarantTurn
                                        );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_declarant_trader().length())));
        assertThat(linkDeclarantTraderMD5, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_declarant_trader())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_declarant_trader_hub_trader().length())));
        assertThat(linkDeclarantTraderHubTraderMD5, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_declarant_trader_hub_trader())));
    }

    @Test
    public void checkMD5ForDeclarationDestinationCountry() {
        String destinationCountryTurn =  landingHeadersDeclarationHashed.getDestination_country_code();
        String linkDestinationCountryMD5 = md5HashOf(
                                                entryReference,
                                                destinationCountryTurn
                                           );
        String linkDestinationCountryHubCountryMD5 = md5HashOf(
                                                destinationCountryTurn
                                           );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_destination_country().length())));
        assertThat(linkDestinationCountryMD5, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_destination_country())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_destination_country_hub_country().length())));
        assertThat(linkDestinationCountryHubCountryMD5, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_destination_country_hub_country())));
    }

    @Test
    public void checkMD5ForDeclarationExporterTrader() {
        String exporterTurn =  landingHeadersDeclarationHashed.getExporter_turn();
        String linkExporterTraderMD5 = md5HashOf(
                                            entryReference,
                                            exporterTurn
                                       );
        String linkExporterTraderHubTraderMD5 = md5HashOf(
                                            exporterTurn
                                       );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_exporter_trader().length())));
        assertThat(linkExporterTraderMD5, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_exporter_trader())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_exporter_trader_hub_trader().length())));
        assertThat(linkExporterTraderHubTraderMD5, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_exporter_trader_hub_trader())));
    }

    @Test
    public void checkMD5ForDeclarationFreightCurrency() {
        String freightCurrency =  landingHeadersDeclarationHashed.getFreight_currency();
        String linkFreightCurrencyMD5 = md5HashOf(
                                            entryReference,
                                            freightCurrency
                                        );
        String linkFreightCurrencyHubCurrencyMD5 = md5HashOf(
                                            freightCurrency
                                        );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_freight_currency().length())));
        assertThat(linkFreightCurrencyMD5, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_freight_currency())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_freight_currency_hub_currency().length())));
        assertThat(linkFreightCurrencyHubCurrencyMD5, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_freight_currency_hub_currency())));
    }

    @Test
    public void checkMD5ForDeclarationImporterTrader() {
        String importerTurn =  landingHeadersDeclarationHashed.getImporter_turn();
        String linkImporterTraderMD5 = md5HashOf(
                                            entryReference,
                                            importerTurn
                                       );
        String linkImporterTraderHubTraderMD5 = md5HashOf(
                                            importerTurn
                                       );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_importer_trader().length())));
        assertThat(linkImporterTraderMD5, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_importer_trader())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_importer_trader_hub_trader().length())));
        assertThat(linkImporterTraderHubTraderMD5, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_importer_trader_hub_trader())));
    }

    @Test
    public void checkMD5ForDeclarationInvoiceCurrency() {
        String invoiceCurrency =  landingHeadersDeclarationHashed.getInvoice_currency();
        String linkInvoiceCurrencyMD5 = md5HashOf(
                                            entryReference,
                                            invoiceCurrency
                                        );
        String linkInvoiceCurrencyHubCurrencyMD5 = md5HashOf(
                                            invoiceCurrency
                                        );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_invoice_currency().length())));
        assertThat(linkInvoiceCurrencyMD5, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_invoice_currency())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_invoice_currency_hub_currency().length())));
        assertThat(linkInvoiceCurrencyHubCurrencyMD5, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_invoice_currency_hub_currency())));
    }

    @Test
    public void checkMD5ForDeclarationPayingAgentTrader() {
        String payingAgentTurn =  landingHeadersDeclarationHashed.getPaying_agent_turn();
        String linkPayingAgentTraderMD5 = md5HashOf(
                                                entryReference,
                                                payingAgentTurn
                                            );
        String linkPayingAgentHubTraderMD5 = md5HashOf(
                                                payingAgentTurn
                                            );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_paying_agent_trader().length())));
        assertThat(linkPayingAgentTraderMD5, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_paying_agent_trader())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_paying_agent_trader_hub_trader().length())));
        assertThat(linkPayingAgentHubTraderMD5, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_paying_agent_trader_hub_trader())));
    }

    @Test
    public void checkMD5ForDeclarationTransportCountry() {
        String transportCountry =  landingHeadersDeclarationHashed.getTransport_country();
        String linkTrasnportCountryMD5 = md5HashOf(
                                            entryReference,
                                            transportCountry
                                         );
        String linkTransportCountryHubCountryMD5 = md5HashOf(
                                            transportCountry
                                         );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_transport_country().length())));
        assertThat(linkTrasnportCountryMD5, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_transport_country())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_transport_country_hub_country().length())));
        assertThat(linkTransportCountryHubCountryMD5, is(equalTo(landingHeadersDeclarationHashed.getLink_declaration_transport_country_hub_country())));
    }

    @Test
    public void checkLandingHeadersDeclarationsHashedMatchesLandingHeadersDeclaration() {
        Optional<LandingHeadersDeclaration> landingheadersdeclaration = HiveLandingTableReader.readAlllandingHeadersDeclarationForEntryNo(hive, IMPORT_ENTRY_NUMBER_1A);
        LandingHeadersDeclaration landingHeadersDeclaration = landingheadersdeclaration.orElse(null);
        assertThat(landingHeadersDeclaration, is(notNullValue(LandingHeadersDeclaration.class)));

        assertThat(landingHeadersDeclarationHashed.getSource(), is(equalTo(landingHeadersDeclaration.getSource())));
        assertThat(landingHeadersDeclarationHashed.getIngestion_date(), is(notNullValue())); //TODO check if these should be the same or not? i.e. is it copied over or date-stamped by job
        assertThat(landingHeadersDeclarationHashed.getEntry_number(), is(equalTo(landingHeadersDeclaration.getEntry_number())));
        assertThat(landingHeadersDeclarationHashed.getEntry_date(), is(equalTo(landingHeadersDeclaration.getEntry_date())));
        assertThat(landingHeadersDeclarationHashed.getEntry_date(), is(equalTo(landingHeadersDeclaration.getEntry_date())));
        assertThat(landingHeadersDeclarationHashed.getEpu_number(), is(equalTo(landingHeadersDeclaration.getEpu_number())));
        assertThat(landingHeadersDeclarationHashed.getEntry_type(), is(equalTo(landingHeadersDeclaration.getEntry_type())));
        assertThat(landingHeadersDeclarationHashed.getDeclaration_method(), is(equalTo(landingHeadersDeclaration.getDeclaration_method())));
        assertThat(landingHeadersDeclarationHashed.getTotal_excise(), is(equalTo(landingHeadersDeclaration.getTotal_excise())));
        assertThat(landingHeadersDeclarationHashed.getImporter_turn(), is(equalTo(landingHeadersDeclaration.getImporter_turn())));
        assertThat(landingHeadersDeclarationHashed.getDeclarant_turn(), is(equalTo(landingHeadersDeclaration.getDeclarant_turn())));
        assertThat(landingHeadersDeclarationHashed.getDeclarant_representative_turn(), is(landingHeadersDeclaration.getDeclarant_representative_turn()));
        assertThat(landingHeadersDeclarationHashed.getConsignee_aeo_certificate_type_code(), is(equalTo(landingHeadersDeclaration.getConsignee_aeo_certificate_type_code())));
        assertThat(landingHeadersDeclarationHashed.getDeclarant_aeo_certificate_type_code(), is(equalTo(landingHeadersDeclaration.getDeclarant_aeo_certificate_type_code())));
        assertThat(landingHeadersDeclarationHashed.getRoute(), is(equalTo(landingHeadersDeclaration.getRoute())));
        assertThat(landingHeadersDeclarationHashed.getDeclaration_import_export_indicator(), is(equalTo(landingHeadersDeclaration.getDeclaration_import_export_indicator())));
        assertThat(landingHeadersDeclarationHashed.getGeneration_number(), is(equalTo(landingHeadersDeclaration.getGeneration_number())));
        assertThat(landingHeadersDeclarationHashed.getExporter_turn(), is(equalTo(landingHeadersDeclaration.getExporter_turn())));
        assertThat(landingHeadersDeclarationHashed.getDestination_country_code(), is(equalTo(landingHeadersDeclaration.getDestination_country_code())));
        assertThat(landingHeadersDeclarationHashed.getImport_clearance_status(), is(equalTo(landingHeadersDeclaration.getImport_clearance_status())));
        assertThat(landingHeadersDeclarationHashed.getConsignor_aeo_certificate_type_code(), is(equalTo(landingHeadersDeclaration.getConsignor_aeo_certificate_type_code())));
        assertThat(landingHeadersDeclarationHashed.getHeader_statistical_value(), is(landingHeadersDeclaration.getHeader_statistical_value()));
        assertThat(landingHeadersDeclarationHashed.getGoods_departure_datetime(), is(equalTo(landingHeadersDeclaration.getGoods_departure_datetime())));
        assertThat(landingHeadersDeclarationHashed.getCustoms_value(), is(landingHeadersDeclaration.getCustoms_value()));
        assertThat(landingHeadersDeclarationHashed.getTotal_duty(), is(landingHeadersDeclaration.getTotal_duty()));
        assertThat(landingHeadersDeclarationHashed.getTotal_vat(), is(equalTo(landingHeadersDeclaration.getTotal_vat())));
        assertThat(landingHeadersDeclarationHashed.getNet_mass_total(), is(landingHeadersDeclaration.getNet_mass_total()));
        assertThat(landingHeadersDeclarationHashed.getGoods_location(), is(landingHeadersDeclaration.getGoods_location()));
        assertThat(landingHeadersDeclarationHashed.getAcceptance_date(), is(equalTo(landingHeadersDeclaration.getAcceptance_date())));
        assertThat(landingHeadersDeclarationHashed.getImporter_turn_country_code(), is(landingHeadersDeclaration.getImporter_turn_country_code()));
        assertThat(landingHeadersDeclarationHashed.getPlace_of_unloading_code(), is(landingHeadersDeclaration.getPlace_of_unloading_code()));
        assertThat(landingHeadersDeclarationHashed.getFirst_deferment_approval_num(), containsString(landingHeadersDeclaration.getFirst_deferment_approval_num()));
        assertThat(landingHeadersDeclarationHashed.getFirst_deferment_approval_num_prefix(), is(landingHeadersDeclaration.getFirst_deferment_approval_num_prefix()));
        assertThat(landingHeadersDeclarationHashed.getDeclaration_ucr(), is(landingHeadersDeclaration.getDeclaration_ucr()));
        assertThat(landingHeadersDeclarationHashed.getItem_count(), is(landingHeadersDeclaration.getItem_count()));
        assertThat(landingHeadersDeclarationHashed.getMaster_ucr(), is(equalTo(landingHeadersDeclaration.getMaster_ucr())));
        assertThat(landingHeadersDeclarationHashed.getPaying_agent_turn(), is(landingHeadersDeclaration.getPaying_agent_turn()));
        assertThat(landingHeadersDeclarationHashed.getPlace_of_loading_code(), is(equalTo(landingHeadersDeclaration.getPlace_of_loading_code())));
        assertThat(landingHeadersDeclarationHashed.getSession_num(), is(landingHeadersDeclaration.getSession_num()));
        assertThat(landingHeadersDeclarationHashed.getSession_role_name(), is(landingHeadersDeclaration.getSession_role_name()));
        assertThat(landingHeadersDeclarationHashed.getStatus_of_entry(), is(equalTo(landingHeadersDeclaration.getStatus_of_entry())));
        assertThat(landingHeadersDeclarationHashed.getTransport_country(), is(landingHeadersDeclaration.getTransport_country()));
        assertThat(landingHeadersDeclarationHashed.getTransport_id(), is(landingHeadersDeclaration.getTransport_id()));
        assertThat(landingHeadersDeclarationHashed.getTransport_mode_code(), is(landingHeadersDeclaration.getTransport_mode_code()));
        assertThat(landingHeadersDeclarationHashed.getDispatch_country(), is(landingHeadersDeclaration.getDispatch_country()));
        assertThat(landingHeadersDeclarationHashed.getConsignor_turn(), is(landingHeadersDeclaration.getConsignor_turn()));
        assertThat(landingHeadersDeclarationHashed.getConsignor_turn_country_code(), is(landingHeadersDeclaration.getConsignor_turn_country_code()));
        assertThat(landingHeadersDeclarationHashed.getConsignor_nad_name(), is(landingHeadersDeclaration.getConsignor_nad_name()));
        assertThat(landingHeadersDeclarationHashed.getConsignee_nad_name(), is(landingHeadersDeclaration.getConsignee_nad_name()));
        assertThat(landingHeadersDeclarationHashed.getDeclarant_nad_name(), is(landingHeadersDeclaration.getDeclarant_nad_name()));
        assertThat(landingHeadersDeclarationHashed.getConsignee_nad_postcode(),  is(equalTo(landingHeadersDeclaration.getConsignee_nad_postocde())));
        assertThat(landingHeadersDeclarationHashed.getCustoms_check_code(), is(landingHeadersDeclaration.getCustoms_check_code()));
        assertThat(landingHeadersDeclarationHashed.getProfile_id(), is(landingHeadersDeclaration.getProfile_id()));
        assertThat(landingHeadersDeclarationHashed.getFreight_currency(), is(landingHeadersDeclaration.getFreight_currency()));
        assertThat(landingHeadersDeclarationHashed.getInvoice_currency(), is(landingHeadersDeclaration.getInvoice_currency()));
        assertThat(landingHeadersDeclarationHashed.getInvoice_total_declared(), is(landingHeadersDeclaration.getInvoice_total_declared()));
        assertThat(landingHeadersDeclarationHashed.getEntry_reference(), is(equalTo(landingHeadersDeclaration.getEntry_reference())));
    }
}
