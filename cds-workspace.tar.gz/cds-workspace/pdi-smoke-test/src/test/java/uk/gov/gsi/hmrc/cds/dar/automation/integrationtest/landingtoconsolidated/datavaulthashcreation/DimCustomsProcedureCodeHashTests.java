package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.datavaulthashcreation;

import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault.DimCustomsProcedureCodeHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveDimensionHashedTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.MD5Hasher.md5HashOf;

public class DimCustomsProcedureCodeHashTests extends BaseIntegrationTest {

    private static final String CUSTOMS_PROCEDURE_CODE = "0649090";
    private static DimCustomsProcedureCodeHashed dimCustomsProcedureCodeHashed;

    @BeforeClass
    public static void setup() {
        init();
        Optional<DimCustomsProcedureCodeHashed> dimCustomsProcedureCodeHashedOptional = HiveDimensionHashedTableReader.readAllDimCustomsProcedureCodeHashedCPC(hive, CUSTOMS_PROCEDURE_CODE);
        dimCustomsProcedureCodeHashed = dimCustomsProcedureCodeHashedOptional.orElse(null);
    }

    @Test
    public void checkMD5ForHubAndSatDeclaration() {
        String hubCountryMD5 = md5HashOf(
                                    CUSTOMS_PROCEDURE_CODE
                               );

        assertThat(MD5_HASH_LENGTH, is(equalTo(hubCountryMD5.length())));
        assertThat(hubCountryMD5, is(equalTo(dimCustomsProcedureCodeHashed.getHub_customs_procedure_code())));

        //TODO implement sat check once sat_customs_procedure_code is available in data vault
    }

}
