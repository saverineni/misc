package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.datavaulthashcreation;

import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.dimension.predatavault.DimCommodityCodeHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveDimensionHashedTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.MD5Hasher.md5HashOf;

public class DimCommodityCodeHashTests extends BaseIntegrationTest {

    private static final String COMMODITY_CODE = "030492";
    private static DimCommodityCodeHashed dimCommodityCodeHashed;


    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
        Optional<DimCommodityCodeHashed> dimCommodityCodeHashedOptional = HiveDimensionHashedTableReader.readAllDimCommodityCodeHashedCommodityCode(hive, COMMODITY_CODE);
        dimCommodityCodeHashed = dimCommodityCodeHashedOptional.orElse(null);
    }

    @Test
    public void checkMD5ForHubAndSatDeclaration() {
        String hubCountryMD5 = md5HashOf(
                                    COMMODITY_CODE
                               );
        String satCountryMD5 = md5HashOf(
                                    dimCommodityCodeHashed.getCc_year(),
                                    dimCommodityCodeHashed.getCc_month(),
                                    dimCommodityCodeHashed.getHs_chapter(),
                                    dimCommodityCodeHashed.getHs_heading(),
                                    dimCommodityCodeHashed.getHs_chapter_heading(),
                                    dimCommodityCodeHashed.getHs_subheading(),
                                    dimCommodityCodeHashed.getChapter_description(),
                                    dimCommodityCodeHashed.getHeading_description(),
                                    dimCommodityCodeHashed.getSubheading_description()
                               );

        assertThat(MD5_HASH_LENGTH, is(equalTo(hubCountryMD5.length())));
        assertThat(hubCountryMD5, is(equalTo(dimCommodityCodeHashed.getHub_commodity())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(satCountryMD5.length())));
        assertThat(satCountryMD5, is(equalTo(dimCommodityCodeHashed.getSat_commodity())));
    }
}
