package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.datavaulthashcreation;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingHashedTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed.LandingTrader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed.LandingTraderHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import java.util.Optional;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.MD5Hasher.md5HashOf;

public class LandingTraderHashesTests extends BaseIntegrationTest {

    private static final String IMPORT_ENTRY_NUMBER_1A_IMPORTER_TRADER_URN = "110098765";
    private LandingTraderHashed landingTraderHashed;

    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
    }

    @Before
    public void dataReaderSetup()
    {
        Optional<LandingTraderHashed> landingTraderHashedOptional = HiveLandingHashedTableReader.landingTraderHashedForTurn(hive, IMPORT_ENTRY_NUMBER_1A_IMPORTER_TRADER_URN);
        landingTraderHashed = landingTraderHashedOptional.orElse(null);
    }

    @Test
    public void checkMD5ForHubAndSatDeclaration() {
        String hubTraderMD5 = md5HashOf(
                                    IMPORT_ENTRY_NUMBER_1A_IMPORTER_TRADER_URN
                              );
        String satTraderMD5 = md5HashOf(
                                    landingTraderHashed.getName(),
                                    landingTraderHashed.getSimplified_procedure_authorisations(),
                                    landingTraderHashed.getTrader_name_abbreviated(),
                                    landingTraderHashed.getCurrentind()
                              );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingTraderHashed.getHub_trader().length())));
        assertThat(hubTraderMD5, is(equalTo(landingTraderHashed.getHub_trader())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingTraderHashed.getSat_trader().length())));
        assertThat(satTraderMD5, is(equalTo(landingTraderHashed.getSat_trader())));
    }

    @Test
    public void checkLandingTraderHashedMatchesLandingTrader() {
        Optional<LandingTrader> landingTraderOptional = HiveLandingTableReader.readAllLandingTraderForTurn(hive, IMPORT_ENTRY_NUMBER_1A_IMPORTER_TRADER_URN);
        LandingTrader landingTrader = landingTraderOptional.orElse(null);

        assertThat(landingTraderHashed.getSource(), is(equalTo(landingTrader.getSource())));
        assertThat(landingTraderHashed.getIngestion_date(), is(equalTo(landingTrader.getIngestion_date())));
        assertThat(landingTraderHashed.getTurn(), is(equalTo(landingTrader.getTurn())));
        assertThat(landingTraderHashed.getFedate(), is(equalTo(landingTrader.getFedate())));
        assertThat(landingTraderHashed.getName(), is(equalTo(landingTrader.getName())));
        assertThat(landingTraderHashed.getSimplified_procedure_authorisations(), is(equalTo(landingTrader.getSimplified_procedure_authorisations())));
        assertThat(landingTraderHashed.getTrader_name_abbreviated(), is(equalTo(landingTrader.getTrader_name_abbreviated())));
        assertThat(landingTraderHashed.getCurrentind(), is(equalTo(landingTrader.getCurrentind())));
    }
}