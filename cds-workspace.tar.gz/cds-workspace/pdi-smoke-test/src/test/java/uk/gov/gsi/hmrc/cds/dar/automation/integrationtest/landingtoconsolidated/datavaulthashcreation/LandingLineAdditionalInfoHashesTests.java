package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.datavaulthashcreation;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingHashedTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed.LandingHeadersDeclarationHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed.LandingLineAdditionalInformation;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed.LandingLineAdditionalInformationHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.TestHelper;

import java.util.Optional;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.MD5Hasher.md5HashOf;

public class LandingLineAdditionalInfoHashesTests extends BaseIntegrationTest implements TestHelper {

    private static final String IMPORT_ENTRY_NUMBER_2B = "IM002B";
    private static final String IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_2 = "2";
    private static final String IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_2_SEQ_NO = "1";
    private String entryReference;
    private LandingLineAdditionalInformationHashed landingLineAdditionalInformationHashed;

    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
    }

    @Before
    public void dataReadersSetup()
    {
        Optional<LandingHeadersDeclarationHashed> landingHeadersDeclarationHashedOptional = HiveLandingHashedTableReader.landingHeadersDeclarationHashedForEntryNo(hive, IMPORT_ENTRY_NUMBER_2B);
        LandingHeadersDeclarationHashed landingHeadersDeclarationHashed = landingHeadersDeclarationHashedOptional.orElse(null);
        entryReference = buildEntryReferenceForDeclaration(landingHeadersDeclarationHashed);

        Optional<LandingLineAdditionalInformationHashed> landingLineAdditionalInformationHashedOptional =
                HiveLandingHashedTableReader.landingLineAdditionalInformationHashedForEntryReferenceItemNoSeqNo(
                        hive,
                        entryReference,
                        IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_2,
                        IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_2_SEQ_NO);
        landingLineAdditionalInformationHashed = landingLineAdditionalInformationHashedOptional.orElse(null);
    }

    @Test
    public void checkMD5ForHubAndSatDeclaration() {
        String hubDeclarationMD5 = md5HashOf(
                                        entryReference,
                                        IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_2,
                                        IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_2_SEQ_NO
                                   );
        String satDeclarationMD5 = md5HashOf(
                                        landingLineAdditionalInformationHashed.getGeneration_number(),
                                        landingLineAdditionalInformationHashed.getAdditional_information_statement(),
                                        landingLineAdditionalInformationHashed.getAdditional_information_statement_type(),
                                        landingLineAdditionalInformationHashed.getItem_additional_information_statement()
                                   );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLineAdditionalInformationHashed.getHub_additional_info().length())));
        assertThat(hubDeclarationMD5, is(equalTo(landingLineAdditionalInformationHashed.getHub_additional_info())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLineAdditionalInformationHashed.getSat_additional_info().length())));
        assertThat(satDeclarationMD5, is(equalTo(landingLineAdditionalInformationHashed.getSat_additional_info())));
    }

    @Test
    public void checkMD5ForDeclarationLineAddtionalInfo() {
        String linkDeclarationLineAdditionInfoMD5 = md5HashOf(
                                                        entryReference,
                                                        IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_2,
                                                        IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_2_SEQ_NO
                                                    );
        String linkDeclarationLineAdditionInfoHubDeclarationLineMD5 = md5HashOf(
                                                                            entryReference,
                                                                            IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_2
                                                                      );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLineAdditionalInformationHashed.getLink_declaration_line_additional_info().length())));
        assertThat(linkDeclarationLineAdditionInfoMD5, is(equalTo(landingLineAdditionalInformationHashed.getLink_declaration_line_additional_info())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLineAdditionalInformationHashed.getLink_declaration_line_additional_info_hub_declaration_line().length())));
        assertThat(linkDeclarationLineAdditionInfoHubDeclarationLineMD5, is(equalTo(landingLineAdditionalInformationHashed.getLink_declaration_line_additional_info_hub_declaration_line())));
    }

    @Test
    public void checkLandingLineAdditionalInformationHashedMatchesLandingLineAdditionalInformation() {
        Optional<LandingLineAdditionalInformation> landinglineaddtionalinfomation =
                HiveLandingTableReader.readAllLandingLineAdditionalInformationForEntryRefNoAndSeqNo(hive, entryReference, IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_2, IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_2_SEQ_NO);
        LandingLineAdditionalInformation landingLineAdditionalInformation = landinglineaddtionalinfomation.orElse(null);

        assertThat(landingLineAdditionalInformationHashed.getSource(), is(equalTo(landingLineAdditionalInformation.getSource())));
        assertThat(landingLineAdditionalInformationHashed.getIngestion_date(), is(equalTo(landingLineAdditionalInformation.getIngestion_date())));
        assertThat(landingLineAdditionalInformationHashed.getItem_number(), is(equalTo(landingLineAdditionalInformation.getItem_number())));
        assertThat(landingLineAdditionalInformationHashed.getAdditional_information_sequence_number(), is(equalTo(landingLineAdditionalInformation.getAdditional_information_sequence_number())));
        assertThat(landingLineAdditionalInformationHashed.getGeneration_number(), is(equalTo(landingLineAdditionalInformation.getGeneration_number())));
        assertThat(landingLineAdditionalInformationHashed.getItem_additional_information_statement(), is(equalTo(landingLineAdditionalInformation.getItem_additional_information_statement())));
        assertThat(landingLineAdditionalInformationHashed.getAdditional_information_statement_type(), is(equalTo(landingLineAdditionalInformation.getAdditional_information_statement_type())));
        assertThat(landingLineAdditionalInformationHashed.getItem_additional_information_statement(), is(equalTo(landingLineAdditionalInformation.getItem_additional_information_statement())));
        assertThat(landingLineAdditionalInformationHashed.getEntry_reference(), is(equalTo(landingLineAdditionalInformation.getEntry_reference())));
    }
}
