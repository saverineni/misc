package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.landingtoconsolidated.datavaulthashcreation;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingHashedTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.readers.HiveLandingTableReader;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.nonhashed.LandingLinesDeclaration;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.entity.landing.hashed.LandingLinesDeclarationHashed;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.MD5Hasher.md5HashOf;

public class LandingLinesDeclarationHashesTests extends BaseIntegrationTest {

    private static final String IMPORT_ENTRY_NUMBER_2B = "IM002B";
    private static final String IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_2 = "2";
    private LandingLinesDeclarationHashed landingLinesDeclarationHashed;
    private String entryReference;
    private String itemNumber;

    @BeforeClass
    public static void dbSetUp() throws Exception {
        init();
    }

    @Before
    public void dataReaderSetup() throws Exception {
        Optional<LandingLinesDeclarationHashed> landingLinesDeclarationHashedOptional = HiveLandingHashedTableReader.landingLinesDeclarationHashedForEntryNoItemNo(hive, IMPORT_ENTRY_NUMBER_2B, IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_2);
        landingLinesDeclarationHashed = landingLinesDeclarationHashedOptional.orElse(null);
        entryReference = landingLinesDeclarationHashed.getEntry_reference();
        itemNumber = landingLinesDeclarationHashed.getItem_number();
    }

    @Test
    public void checkMD5ForHubAndSatDeclaration() {
        String hubDeclarationLineMD5 = md5HashOf(
                                            entryReference,
                                            itemNumber
                                       );
        String satDeclarationLineMD5 = md5HashOf(
                                            landingLinesDeclarationHashed.getClearance_datetime(),
                                            landingLinesDeclarationHashed.getItem_statistical_value(),
                                            landingLinesDeclarationHashed.getCustoms_duty_paid(),
                                            landingLinesDeclarationHashed.getVat_paid(),
                                            landingLinesDeclarationHashed.getEc_supplementary_1(),
                                            landingLinesDeclarationHashed.getItem_customs_value(),
                                            landingLinesDeclarationHashed.getItem_net_mass(),
                                            landingLinesDeclarationHashed.getItem_supplementary_units(),
                                            landingLinesDeclarationHashed.getGoods_description(),
                                            landingLinesDeclarationHashed.getItem_customs_check_code(),
                                            landingLinesDeclarationHashed.getItem_mic_code(),
                                            landingLinesDeclarationHashed.getItem_profile_id(),
                                            landingLinesDeclarationHashed.getItem_consignor_nad_name(),
                                            landingLinesDeclarationHashed.getItem_consignee_nad_name(),
                                            landingLinesDeclarationHashed.getItem_consignee_nad_postcode(),
                                            landingLinesDeclarationHashed.getVat_value(),
                                            landingLinesDeclarationHashed.getItem_price_declared()
                                        );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLinesDeclarationHashed.getHub_declaration_line().length())));
        assertThat(hubDeclarationLineMD5, is(equalTo(landingLinesDeclarationHashed.getHub_declaration_line())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLinesDeclarationHashed.getSat_declaration_line().length())));
        assertThat(satDeclarationLineMD5, is(equalTo(landingLinesDeclarationHashed.getSat_declaration_line())));
    }

    @Test
    public void checkMD5ForDeclarationLineDeclaration() {
        String linkDecLineDeclarationMD5 = md5HashOf(
                                                entryReference,
                                                itemNumber
                                           );
        String linkDecLineDeclarationHubDeclarationMD5 = md5HashOf(
                                                            entryReference
                                                         );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_declaration().length())));
        assertThat(linkDecLineDeclarationMD5, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_declaration())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_declaration_hub_declaration().length())));
        assertThat(linkDecLineDeclarationHubDeclarationMD5, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_declaration_hub_declaration())));
    }

    @Test
    public void checkMD5ForDeclarationLineCommodity() {
        String commodityCode =  Optional.ofNullable(landingLinesDeclarationHashed.getHs_code()).orElse(NULL_ESCAPE);
        String linkDecLineCommodityMD5 = md5HashOf(
                                            entryReference,
                                            itemNumber,
                                            commodityCode
                                         );
        String linkDecLineCommodityHubCommodityMD5 = md5HashOf(
                                                        commodityCode
                                                     );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_commodity().length())));
        assertThat(linkDecLineCommodityMD5, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_commodity())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_commodity_hub_commodity().length())));
        assertThat(linkDecLineCommodityHubCommodityMD5, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_commodity_hub_commodity())));
    }

    @Test
    public void checkMD5ForDeclarationLineCustomsProcedureCode() {
        String customsProcedureCode = Optional.ofNullable(landingLinesDeclarationHashed.getCustoms_procedure_code()).orElse(NULL_ESCAPE);
        String linkDecLineCustomsProcCodeMD5 = md5HashOf(
                                                    entryReference,
                                                    itemNumber, customsProcedureCode
                                               );
        String linkDecLineCustomsProcCodeHubCustomsProcCodeMD5 = md5HashOf(
                                                                        customsProcedureCode
                                                                 );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_customs_procedure_code().length())));
        assertThat(linkDecLineCustomsProcCodeMD5, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_customs_procedure_code())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_customs_procedure_code_hub_customs_procedure_code().length())));
        assertThat(linkDecLineCustomsProcCodeHubCustomsProcCodeMD5, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_customs_procedure_code_hub_customs_procedure_code())));
    }

    @Test
    public void checkMD5ForDeclarationLineImporterTrader() {
        String itemImporterTurn = Optional.ofNullable(landingLinesDeclarationHashed.getItem_importer_turn()).orElse(NULL_ESCAPE);
        String linkDecLineImporterTraderMD5 = md5HashOf(
                                                    entryReference,
                                                    itemNumber,
                                                    itemImporterTurn
                                              );
        String linkDecLineImporterTraderHubTraderMD5 = md5HashOf(
                                                            itemImporterTurn
                                                       );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_importer_trader().length())));
        assertThat(linkDecLineImporterTraderMD5, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_importer_trader())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_importer_trader_hub_trader().length())));
        assertThat(linkDecLineImporterTraderHubTraderMD5, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_importer_trader_hub_trader())));
    }

    @Test
    public void checkMD5ForDeclarationLineOriginCountry() {
        String originCountryCode = Optional.ofNullable(landingLinesDeclarationHashed.getOrigin_country_code()).orElse(NULL_ESCAPE);
        String linkDecLineOriginCountryMD5 = md5HashOf(
                                                    entryReference,
                                                    itemNumber,
                                                    originCountryCode
                                             );
        String linkDecLineOriginCountryHubCountryMD5 = md5HashOf(
                                                            originCountryCode
                                                       );

        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_origin_country().length())));
        assertThat(linkDecLineOriginCountryMD5, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_origin_country())));
        assertThat(MD5_HASH_LENGTH, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_origin_country_hub_country().length())));
        assertThat(linkDecLineOriginCountryHubCountryMD5, is(equalTo(landingLinesDeclarationHashed.getLink_declaration_line_origin_country_hub_country())));
    }

    @Test
    public void checkLandingLinesDeclarationsHashedMatchesLandingLinesDeclaration() {
        Optional<LandingLinesDeclaration> landinglinesdeclaration = HiveLandingTableReader.readAllLandingLinesDeclarationForEntryNo(hive, IMPORT_ENTRY_NUMBER_2B, IMPORT_ENTRY_NUMBER_2B_LINE_ITEM_NO_2);
        LandingLinesDeclaration landingLinesDeclaration = landinglinesdeclaration.orElse(null);
        assertThat(landingLinesDeclaration, is(notNullValue(LandingLinesDeclaration.class)));

        assertThat(landingLinesDeclarationHashed.getSource(), is(equalTo(landingLinesDeclaration.getSource())));
        assertThat(landingLinesDeclarationHashed.getIngestion_date(), is(equalTo(landingLinesDeclaration.getIngestion_date())));
        assertThat(landingLinesDeclarationHashed.getEntry_number(), is(equalTo(landingLinesDeclaration.getEntry_number())));
        assertThat(landingLinesDeclarationHashed.getEntry_date(), is(equalTo(landingLinesDeclaration.getEntry_date())));
        assertThat(landingLinesDeclarationHashed.getEpu_number(), is(equalTo(landingLinesDeclaration.getEpu_number())));
        assertThat(landingLinesDeclarationHashed.getItem_number(), is(equalTo(landingLinesDeclaration.getItem_number())));
        assertThat(landingLinesDeclarationHashed.getClearance_datetime(), is(equalTo(landingLinesDeclaration.getClearance_datetime())));
        assertThat(landingLinesDeclarationHashed.getOrigin_country_code(), is(equalTo(landingLinesDeclaration.getOrigin_country_code())));
        assertThat(landingLinesDeclarationHashed.getItem_statistical_value(), is(equalTo(landingLinesDeclaration.getItem_statistical_value())));
        assertThat(landingLinesDeclarationHashed.getCommodity_code(), is(equalTo(landingLinesDeclaration.getCommodity_code())));
        assertThat(landingLinesDeclarationHashed.getCustoms_procedure_code(), is(equalTo(landingLinesDeclaration.getCustoms_procedure_code())));
        assertThat(landingLinesDeclarationHashed.getCustoms_duty_paid(), is(equalTo(landingLinesDeclaration.getCustoms_duty_paid())));
        assertThat(landingLinesDeclarationHashed.getVat_paid(), is(equalTo(landingLinesDeclaration.getVat_paid())));
        assertThat(landingLinesDeclarationHashed.getVat_value(), is(equalTo(landingLinesDeclaration.getVat_value())));
        assertThat(landingLinesDeclarationHashed.getEc_supplementary_1(), is(equalTo(landingLinesDeclaration.getEc_supplementary_1())));
        assertThat(landingLinesDeclarationHashed.getItem_customs_value(), is(equalTo(landingLinesDeclaration.getItem_customs_value())));
        assertThat(landingLinesDeclarationHashed.getItem_net_mass(), is(equalTo(landingLinesDeclaration.getItem_net_mass())));
        assertThat(landingLinesDeclarationHashed.getItem_supplementary_units(), is(equalTo(landingLinesDeclaration.getItem_supplementary_units())));
        assertThat(landingLinesDeclarationHashed.getGoods_description(), is(equalTo(landingLinesDeclaration.getGoods_description())));
        assertThat(landingLinesDeclarationHashed.getItem_importer_turn(), is(equalTo(landingLinesDeclaration.getItem_importer_turn())));
        assertThat(landingLinesDeclarationHashed.getItem_customs_check_code(), is(equalTo(landingLinesDeclaration.getItem_customs_check_code())));
        assertThat(landingLinesDeclarationHashed.getItem_mic_code(), is(equalTo(landingLinesDeclaration.getItem_mic_code())));
        assertThat(landingLinesDeclarationHashed.getItem_profile_id(), is(equalTo(landingLinesDeclaration.getItem_profile_id())));
        assertThat(landingLinesDeclarationHashed.getItem_consignor_nad_name(), is(landingLinesDeclaration.getItem_consignor_nad_name()));
        assertThat(landingLinesDeclarationHashed.getItem_consignee_nad_name(), is(landingLinesDeclaration.getItem_consignee_nad_name()));
        assertThat(landingLinesDeclarationHashed.getItem_consignee_nad_postcode(), is(equalTo(landingLinesDeclaration.getItem_consignee_nad_postcode())));
        assertThat(landingLinesDeclarationHashed.getItem_price_declared(), is(equalTo(landingLinesDeclaration.getItem_price_declared())));
        assertThat(landingLinesDeclarationHashed.getEntry_reference(), is(equalTo(landingLinesDeclaration.getEntry_reference())));
        assertThat(landingLinesDeclarationHashed.getHs_code(), is(equalTo(landingLinesDeclaration.getHs_code())));
    }
}