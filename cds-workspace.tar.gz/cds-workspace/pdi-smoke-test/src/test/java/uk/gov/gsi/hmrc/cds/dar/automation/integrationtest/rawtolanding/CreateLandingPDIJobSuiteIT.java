package uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.rawtolanding;

import com.google.common.base.Stopwatch;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.hive.HiveDBManager;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion.JobExecutor;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.ingestion.mss.MSSTablesDataIngester;
import uk.gov.gsi.hmrc.cds.dar.automation.framework.pdi.PDIStage;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.BaseIntegrationTest;
import uk.gov.gsi.hmrc.cds.dar.automation.integrationtest.rawtolanding.createlanding.*;

import java.util.concurrent.TimeUnit;

import static junit.framework.TestCase.assertTrue;
import static uk.gov.gsi.hmrc.cds.dar.automation.framework.helper.PropertyConfiguration.config;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        MssImportHeaderTests.class,
        MssExportHeaderTests.class,
        MssImportLinesTests.class,
        MssExportLinesTests.class,
        MssStandingDataTests.class
})
public class CreateLandingPDIJobSuiteIT extends BaseIntegrationTest{

    private static Logger logger = LoggerFactory.getLogger(MssImportHeaderTests.class);
    private final static Stopwatch stopwatch = Stopwatch.createStarted();

    @BeforeClass
    public static void testSetUp() throws Exception {
        init();
        PDIStage.CREATE_ALL_LANDING.invalidateSourceTableCache();
        if (config().getBoolean("refresh.test.db")) {
            JobExecutor.invalidateTestDB();
        } else {
            PDIStage.CREATE_ALL_LANDING.dropAllLockTables(hive); //TODO - provide clean solution.
            HiveDBManager.connect(hive).dropMSSTables();
        }
        HiveDBManager.connect(hive).createMSSTables();
        MSSTablesDataIngester
                .connectToDB(hive)
                .quickIngestData();
        logger.info("DBSetup execution time: {} seconds", stopwatch.elapsed(TimeUnit.SECONDS));
        boolean jobStatus = PDIStage.CREATE_ALL_LANDING.triggerPDIJob();
        assertTrue(jobStatus);
    }

    @AfterClass
    public static void cacheSourceTables() throws Exception {
        PDIStage.CREATE_ALL_LANDING.cacheSourceTables();
        logger.info("Total Execution time: {} seconds", stopwatch.elapsed(TimeUnit.SECONDS));
    }
}
