package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity;

import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.hasher.spark.helper.MD5Hasher.md5HashOf;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.parseLine;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.valueAt;

@Data
@Builder
public class LandingTraderHashed implements Serializable, BaseEntity {

    private String source;
    private String ingestion_date;
    private String turn;
    private String fedate;
    private String name;
    private String simplified_procedure_authorisations;
    private String trader_name_abbreviated;
    private String currentind;
    private String hub_trader;
    private String sat_trader;

    public static final Encoder<LandingTraderHashed> landingTraderHashedEncoder = Encoders.bean(LandingTraderHashed.class);

    public static LandingTraderHashed mapper(LandingTrader landingTrader) {
        return LandingTraderHashed.builder()
                .source(landingTrader.getSource())
                .ingestion_date(landingTrader.getIngestion_date())
                .turn(landingTrader.getTurn())
                .fedate(landingTrader.getFedate())
                .name(landingTrader.getName())
                .simplified_procedure_authorisations(landingTrader.getSimplified_procedure_authorisations())
                .trader_name_abbreviated(landingTrader.getTrader_name_abbreviated())
                .currentind(landingTrader.getCurrentind())
                .hub_trader(hubTraderHashed(landingTrader))
                .sat_trader(satTraderHashDifference(landingTrader))
                .build();
    }

    private static String satTraderHashDifference(LandingTrader landingTrader) {
        return md5HashOf(Arrays.asList(
                landingTrader.getName(),
                landingTrader.getSimplified_procedure_authorisations(),
                landingTrader.getTrader_name_abbreviated(),
                landingTrader.getCurrentind()
        ));
    }

    private static String hubTraderHashed(LandingTrader landingTrader) {
        return md5HashOf(landingTrader.getTurn());
    }

    public static LandingTraderHashed parse(String line) {
        List<String> columns = parseLine(line);

        return LandingTraderHashed.builder()
                .source(valueAt(columns, 0))
                .ingestion_date(valueAt(columns, 1))
                .turn(valueAt(columns, 2))
                .fedate(valueAt(columns, 3))
                .name(valueAt(columns, 4))
                .simplified_procedure_authorisations(valueAt(columns, 5))
                .trader_name_abbreviated(valueAt(columns, 6))
                .currentind(valueAt(columns, 7))
                .hub_trader(valueAt(columns, 8))
                .sat_trader(valueAt(columns, 9))
                .build();
    }
}
