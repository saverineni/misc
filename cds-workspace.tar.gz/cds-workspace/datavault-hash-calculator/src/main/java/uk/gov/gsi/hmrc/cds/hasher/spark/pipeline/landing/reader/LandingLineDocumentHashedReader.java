package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLineDocumentHashed;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables.LANDING_LINE_DOCUMENT_HASHED;

@Component
public class LandingLineDocumentHashedReader extends TableReader {

    public Dataset<LandingLineDocumentHashed> landingLineDocumentHashedDataset() {
        String dataFilePath = String.format("%s/%s", LANDING_LINE_DOCUMENT_HASHED.tableName(), datafileRelativePath);
        String landingLineDocumentHashedFilePath = String.format("%s/%s", landingHDFSAbsoluteBasePath, dataFilePath);

        JavaRDD<LandingLineDocumentHashed> landingLineDocumentHashedJavaRDD = javaSparkContext
                .textFile(landingLineDocumentHashedFilePath)
                .map(LandingLineDocumentHashed::parse);
        return sparkSession.createDataset(landingLineDocumentHashedJavaRDD.rdd(), LandingLineDocumentHashed.landingLineDocumentHashedEncoder);

    }
}
