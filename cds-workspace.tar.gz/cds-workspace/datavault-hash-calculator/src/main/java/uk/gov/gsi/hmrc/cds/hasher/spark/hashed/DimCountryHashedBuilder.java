package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.DimensionTables;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCountry;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCountryHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.reader.DimCountryReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingHeaderDeclarationHashed;

@Component
public class DimCountryHashedBuilder extends BaseHashedBuilder{

    @Autowired
    private DimCountryReader dimCountryReader;

    public Dataset<DimCountryHashed> build() {

        Dataset<DimCountry> dimCountryDataset = dimCountryReader.dimCountryDataset();

        return dimCountryDataset.map((MapFunction<DimCountry, DimCountryHashed>) DimCountryHashed::mapper, DimCountryHashed.dimCountryHashedEncoder);
    }

    public void saveAndCreateExternalTable(Dataset<DimCountryHashed> dimCountryHashedDataset) {
        String tableName = DimensionTables.DIM_COUNTRY_HASHED.tableName();
        saveDimensionDatasetAsTable(dimCountryHashedDataset, tableName);
    }
}
