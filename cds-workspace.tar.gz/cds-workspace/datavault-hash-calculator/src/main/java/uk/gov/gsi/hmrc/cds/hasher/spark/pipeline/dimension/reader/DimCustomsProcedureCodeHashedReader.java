package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.reader;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCustomsProcedureCode;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCustomsProcedureCodeHashed;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.DimensionTables.DIM_CUSTOMS_PROCEDURE_CODE;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.DimensionTables.DIM_CUSTOMS_PROCEDURE_CODE_HASHED;

@Component
public class DimCustomsProcedureCodeHashedReader extends TableReader {

    public Dataset<DimCustomsProcedureCodeHashed> dimCustomsProcedureCodeHashedDataset() {
        String dataFilePath = String.format("%s/%s", DIM_CUSTOMS_PROCEDURE_CODE_HASHED.tableName(), datafileRelativePath);
        String dimCustomsProcedureCodeHashedFilePath = String.format("%s/%s", dimensionHDFSAbsoluteBasePath, dataFilePath);

        JavaRDD<DimCustomsProcedureCodeHashed> dimCustomsProcedureCodeHashedJavaRDD = javaSparkContext
                .textFile(dimCustomsProcedureCodeHashedFilePath)
                .map(DimCustomsProcedureCodeHashed::parse);

        return sparkSession.createDataset(dimCustomsProcedureCodeHashedJavaRDD.rdd(), DimCustomsProcedureCodeHashed.dimCustomsProcedureCodeHashedEncoder);

    }
}
