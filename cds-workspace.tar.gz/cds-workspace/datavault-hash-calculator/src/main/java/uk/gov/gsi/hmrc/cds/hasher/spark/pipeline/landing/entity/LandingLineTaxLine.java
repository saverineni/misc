package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity;

import com.google.common.collect.Lists;
import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.*;

@Data
@Builder
public class LandingLineTaxLine implements Serializable, BaseEntity {

    private String source;
    private String ingestion_date;
    private String item_number;
    private String tax_line_sequence_number;
    private String generation_number;
    private String waived_tax;
    private String method_of_payment_code;
    private String tax_amount;
    private String tax_type_code;
    private String entry_reference;

    public static final Encoder<LandingLineTaxLine> landingLineTaxLineEncoder = Encoders.bean(LandingLineTaxLine.class);

    public static String[] structFields = toArray(
            Lists.newArrayList(
                    "source",
                    "ingestion_date",
                    "item_number",
                    "tax_line_sequence_number",
                    "generation_number",
                    "waived_tax",
                    "method_of_payment_code",
                    "tax_amount",
                    "tax_type_code",
                    "entry_reference"
            )
    );

    public static LandingLineTaxLine parse(String line) {
        List<String> columns = parseLine(line);

        return LandingLineTaxLine.builder()
                .source(valueAt(columns, 0))
                .ingestion_date(valueAt(columns, 1))
                .item_number(valueAt(columns, 2))
                .tax_line_sequence_number(valueAt(columns, 3))
                .generation_number(valueAt(columns, 4))
                .waived_tax(valueAt(columns, 5))
                .method_of_payment_code(valueAt(columns, 6))
                .tax_amount(valueAt(columns, 7))
                .tax_type_code(valueAt(columns, 8))
                .entry_reference(valueAt(columns, 9))
                .build();
    }
}
