package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity;

import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static uk.gov.gsi.hmrc.cds.hasher.spark.helper.MD5Hasher.md5HashOf;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.parseLine;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.valueAt;

@Data
@Builder
public class DimCountryHashed implements Serializable, BaseEntity {

    private String country_id;
    private String country_iso_code;
    private String country_name;
    private String country_sequence_number;
    private String country_comments;
    private String hub_country;
    private String sat_country;

//    public static StructType structType = DataTypes.createStructType(new StructField[]{
//            DataTypes.createStructField("country_id", DataTypes.StringType, false),
//            DataTypes.createStructField("country_iso_code", DataTypes.StringType, false),
//            DataTypes.createStructField("country_name", DataTypes.StringType, false),
//            DataTypes.createStructField("country_sequence_number", DataTypes.StringType, false),
//            DataTypes.createStructField("country_comments", DataTypes.StringType, true),
//            DataTypes.createStructField("hub_country", DataTypes.StringType, false),
//            DataTypes.createStructField("sat_country", DataTypes.StringType, false)
//    });

    public static final Encoder<DimCountryHashed> dimCountryHashedEncoder = Encoders.bean(DimCountryHashed.class);

    public static String hubCountryHashed(DimCountry dimCountry) {
        return md5HashOf(dimCountry.getCountry_iso_code());
    }

    //    TODO - null is represented as 'null' string in PDI when calculating hashes. This needs cleanup onces we stabilise the whole pipeline
    public static String satCountryHashDifference(DimCountry dimCountry) {
        return md5HashOf(Arrays.asList(
                dimCountry.getCountry_name() == null ? "null" : dimCountry.getCountry_name(),
                dimCountry.getCountry_sequence_number() == null ? "null" : dimCountry.getCountry_sequence_number(),
                dimCountry.getCountry_comments() == null ? "null" : dimCountry.getCountry_comments()
        ));
    }

    public static DimCountryHashed parse(String line) {
        List<String> columns = parseLine(line);

        return DimCountryHashed.builder()
                .country_id(valueAt(columns, 0))
                .country_iso_code(valueAt(columns, 1))
                .country_name(valueAt(columns, 2))
                .country_sequence_number(valueAt(columns, 3))
                .country_comments(valueAt(columns, 4))
                .hub_country(valueAt(columns, 5))
                .sat_country(valueAt(columns, 6))
                .build();
    }

    public static DimCountryHashed mapper(DimCountry dimCountry) {
        return DimCountryHashed.builder()
                .country_id(dimCountry.getCountry_id())
                .country_iso_code(dimCountry.getCountry_iso_code())
                .country_name(dimCountry.getCountry_name())
                .country_sequence_number(dimCountry.getCountry_sequence_number())
                .country_comments(dimCountry.getCountry_comments())
                .hub_country(hubCountryHashed(dimCountry))
                .sat_country(satCountryHashDifference(dimCountry))
                .build();
    }
}
