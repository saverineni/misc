package uk.gov.gsi.hmrc.cds.hasher.spark;

import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.hashed.*;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.*;

@Component
public class LandingHashTableGenerator {

    @Autowired
    private LandingHeaderDeclarationHashedBuilder landingHeaderDeclarationHashedBuilder;
    @Autowired
    private LandingLinesDeclarationHashedBuilder landingLinesDeclarationHashedBuilder;
    @Autowired
    private LandingLineAdditionalInformationHashedBuilder landingLineAdditionalInformationHashedBuilder;
    @Autowired
    private LandingLineDocumentHashedBuilder landingLineDocumentHashedBuilder;
    @Autowired
    private LandingLinePreviousDocumentHashedBuilder landingLinePreviousDocumentHashedBuilder;
    @Autowired
    private LandingLineTaxLineHashedBuilder landingLineTaxLineHashedBuilder;
    @Autowired
    private LandingTraderHashedBuilder landingTraderHashedBuilder;

    public void persistLandingHashTables() {
        Dataset<LandingHeaderDeclarationHashed> landingHeaderDeclarationHashedDataset = landingHeaderDeclarationHashedBuilder.build().persist();
        landingHeaderDeclarationHashedBuilder.saveAndCreateExternalTable(landingHeaderDeclarationHashedDataset);

        Dataset<LandingLinesDeclarationHashed> landingLinesDeclarationHashedDataset = landingLinesDeclarationHashedBuilder.build();
        landingLinesDeclarationHashedBuilder.saveAndCreateExternalTable(landingLinesDeclarationHashedDataset);

        Dataset<LandingLineAdditionalInformationHashed> landingLineAdditionalInformationHashedDataset = landingLineAdditionalInformationHashedBuilder.build();
        landingLineAdditionalInformationHashedBuilder.saveAndCreateExternalTable(landingLineAdditionalInformationHashedDataset);

        Dataset<LandingLineDocumentHashed> landingLineDocumentHashedDataset = landingLineDocumentHashedBuilder.build();
        landingLineDocumentHashedBuilder.saveAndCreateExternalTable(landingLineDocumentHashedDataset);

        Dataset<LandingLinePreviousDocumentHashed> landingLinePreviousDocumentHashedDataset = landingLinePreviousDocumentHashedBuilder.build();
        landingLinePreviousDocumentHashedBuilder.saveAndCreateExternalTable(landingLinePreviousDocumentHashedDataset);

        Dataset<LandingLineTaxLineHashed> landingLineTaxLineHashedDataset = landingLineTaxLineHashedBuilder.build();
        landingLineTaxLineHashedBuilder.saveAndCreateExternalTable(landingLineTaxLineHashedDataset);

        Dataset<LandingTraderHashed> landingTraderHashedDataset = landingTraderHashedBuilder.build();
        landingTraderHashedBuilder.saveAndCreateExternalTable(landingTraderHashedDataset);
    }
}
