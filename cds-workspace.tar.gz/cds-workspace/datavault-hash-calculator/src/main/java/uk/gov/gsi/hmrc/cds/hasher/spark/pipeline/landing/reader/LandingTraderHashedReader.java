package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingTraderHashed;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables.LANDING_TRADER_HASHED;

@Component
public class LandingTraderHashedReader extends TableReader {

    public Dataset<LandingTraderHashed> landingTraderHashedDataset() {
        String dataFilePath = String.format("%s/%s", LANDING_TRADER_HASHED.tableName(), datafileRelativePath);
        String landingTraderHashedFilePath = String.format("%s/%s", landingHDFSAbsoluteBasePath, dataFilePath);

        JavaRDD<LandingTraderHashed> landingTraderHashedJavaRDD = javaSparkContext
                .textFile(landingTraderHashedFilePath)
                .map(LandingTraderHashed::parse);
        return sparkSession.createDataset(landingTraderHashedJavaRDD.rdd(), LandingTraderHashed.landingTraderHashedEncoder);

    }
}
