package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.reader;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCommodityCodeHashed;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.DimensionTables.DIM_COMMODITY_CODE_HASHED;

@Component
public class DimCommodityCodeHashedReader extends TableReader {

    public Dataset<DimCommodityCodeHashed> dimCommodityCodeHashedDataset() {
        String dataFilePath = String.format("%s/%s", DIM_COMMODITY_CODE_HASHED.tableName(), datafileRelativePath);
        String dimCommodityCodeHashedFilePath = String.format("%s/%s", dimensionHDFSAbsoluteBasePath, dataFilePath);

        JavaRDD<DimCommodityCodeHashed> dimCommodityCodeHashedJavaRDD = javaSparkContext
                .textFile(dimCommodityCodeHashedFilePath)
                .map(DimCommodityCodeHashed::parse);
        return sparkSession.createDataset(dimCommodityCodeHashedJavaRDD.rdd(), DimCommodityCodeHashed.dimCommodityCodeHashedEncoder);

    }
}
