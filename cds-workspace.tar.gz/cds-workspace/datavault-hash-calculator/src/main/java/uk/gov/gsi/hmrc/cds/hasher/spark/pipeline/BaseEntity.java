package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline;

import com.google.common.collect.Iterables;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public interface BaseEntity {

    String DEFAULT_FILE_DELIMITER = "\\01";
    String NULL_ESCAPE = "\\N";

    static List<String> parseLine(String line) {
        return Arrays.asList(line.split(DEFAULT_FILE_DELIMITER));
    }

    static String valueAt(Iterable<String> columns, int index) {
        return Iterables.get(columns, index, null);
    }

    static String[] toArray(List<String> columns) {
        return Iterables.toArray(columns, String.class);
    }

    static String escapeNull(String value) {
        return Optional.ofNullable(value).orElse(NULL_ESCAPE);
    }

}
