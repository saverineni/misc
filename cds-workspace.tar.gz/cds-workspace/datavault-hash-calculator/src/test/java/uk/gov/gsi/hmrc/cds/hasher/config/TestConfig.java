package uk.gov.gsi.hmrc.cds.hasher.config;

import com.google.common.io.Resources;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ClassPathResource;

@Configuration
@Import({
        SparkConfig.class,
        ReaderConfig.class
})
public class TestConfig {

    @Bean
    public String datafileRelativePath() {
        return "data";
    }

    @Bean
    public String dataVaultHDFSBasePath() {
        return new ClassPathResource("datavault").getPath();
    }

    @Bean
    public String landingHDFSBasePath() {
        return Resources.getResource("landing").getPath();
    }

    @Bean
    public String dimensionHDFSBasePath() {
        return Resources.getResource("dimension").getPath();
//        String path = null;
//        try {
//            path = new ClassPathResource("dimension").getFile().getAbsolutePath();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return path;
    }

    @Bean
    public String landingHashedHDFSAbsoluteBasePath() {
        return Resources.getResource("landing").getPath();
    }

    @Bean
    public String landingHDFSAbsoluteBasePath() {
        return Resources.getResource("landing").getPath();
    }

    @Bean
    public String dimensionHDFSAbsoluteBasePath() {
        return Resources.getResource("dimension").getPath();
    }

    @Bean
    public String landingHashedDatabaseName() {
        return "test_landing_hashed";
    }

    @Bean
    public Boolean hiveContextAware() {
        return false;
    }

}
