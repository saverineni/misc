package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.hasher.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLineTaxLineHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader.LandingLineTaxLineHashedReader;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.toArray;

public class LandingLineTaxLineHashedBuilderTest extends SparkTest {

    @Autowired
    LandingLineTaxLineHashedBuilder landingLineTaxLineHashedBuilder;
    @Autowired
    LandingLineTaxLineHashedReader landingLineTaxLineHashedReader;

    @Test
    public void buildLandingLineTaxLineHashed() throws Exception {
        Dataset<LandingLineTaxLineHashed> dataset = landingLineTaxLineHashedBuilder.build();
        assertThat(dataset.count(), is(greaterThan(0l)));
        // TODO assert hashes

        String[] fieldNames = dataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(landingLineTaxLineHashedStructFields));

        Dataset<LandingLineTaxLineHashed> pdiHashedDataset = landingLineTaxLineHashedReader.landingLineTaxLineHashedDataset();

        List<LandingLineTaxLineHashed> actualHashed = dataset.toJavaRDD().collect();
        List<LandingLineTaxLineHashed> expectedHashed = pdiHashedDataset.toJavaRDD().collect();

        // TODO - prehaps we don't need to assert this horrible way. This is for the initial verification of all rows and columns.
        // TODO - To be cleaned up to assert one row.
        actualHashed.forEach(landingLineTaxLineHashed -> {
            LandingLineTaxLineHashed expectedLandingLineTaxLineHashed = expectedHashed.stream()
                    .filter(v1 ->
                            (v1.getEntry_reference().equals(landingLineTaxLineHashed.getEntry_reference())) &&
                                    (v1.getItem_number().equals(landingLineTaxLineHashed.getItem_number())) &&
                                    (v1.getTax_line_sequence_number().equals(landingLineTaxLineHashed.getTax_line_sequence_number()))
                    )
                    .findFirst()
                    .get();

            assertThat(landingLineTaxLineHashed.getSource(), is(equalTo(expectedLandingLineTaxLineHashed.getSource())));
            assertThat(landingLineTaxLineHashed.getIngestion_date(), is(equalTo(expectedLandingLineTaxLineHashed.getIngestion_date())));
            assertThat(landingLineTaxLineHashed.getItem_number(), is(equalTo(expectedLandingLineTaxLineHashed.getItem_number())));
            assertThat(landingLineTaxLineHashed.getTax_line_sequence_number(), is(equalTo(expectedLandingLineTaxLineHashed.getTax_line_sequence_number())));
            assertThat(landingLineTaxLineHashed.getGeneration_number(), is(equalTo(expectedLandingLineTaxLineHashed.getGeneration_number())));
            assertThat(landingLineTaxLineHashed.getWaived_tax(), is(equalTo(expectedLandingLineTaxLineHashed.getWaived_tax())));
            assertThat(landingLineTaxLineHashed.getMethod_of_payment_code(), is(equalTo(expectedLandingLineTaxLineHashed.getMethod_of_payment_code())));
            assertThat(landingLineTaxLineHashed.getTax_amount(), is(equalTo(expectedLandingLineTaxLineHashed.getTax_amount())));
            assertThat(landingLineTaxLineHashed.getTax_type_code(), is(equalTo(expectedLandingLineTaxLineHashed.getTax_type_code())));
            assertThat(landingLineTaxLineHashed.getEntry_reference(), is(equalTo(expectedLandingLineTaxLineHashed.getEntry_reference())));
            assertThat(landingLineTaxLineHashed.getHub_tax_line(), is(equalTo(expectedLandingLineTaxLineHashed.getHub_tax_line())));
            assertThat(landingLineTaxLineHashed.getSat_tax_line(), is(equalTo(expectedLandingLineTaxLineHashed.getSat_tax_line())));
            assertThat(landingLineTaxLineHashed.getLink_declaration_line_tax_line(), is(equalTo(expectedLandingLineTaxLineHashed.getLink_declaration_line_tax_line())));
            assertThat(landingLineTaxLineHashed.getLink_declaration_line_tax_line_hub_declaration_line(), is(equalTo(expectedLandingLineTaxLineHashed.getLink_declaration_line_tax_line_hub_declaration_line())));
        });
    }

    private static String[] landingLineTaxLineHashedStructFields = toArray(
            Lists.newArrayList(
                    "entry_reference",
                    "generation_number",
                    "hub_tax_line",
                    "ingestion_date",
                    "item_number",
                    "link_declaration_line_tax_line",
                    "link_declaration_line_tax_line_hub_declaration_line",
                    "method_of_payment_code",
                    "sat_tax_line",
                    "source",
                    "tax_amount",
                    "tax_line_sequence_number",
                    "tax_type_code",
                    "waived_tax")
    );


}