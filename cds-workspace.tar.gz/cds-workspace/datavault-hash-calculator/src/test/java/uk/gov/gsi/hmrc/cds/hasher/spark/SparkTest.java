package uk.gov.gsi.hmrc.cds.hasher.spark;

import org.apache.spark.sql.SQLContext;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import uk.gov.gsi.hmrc.cds.hasher.config.TestConfig;

@RunWith(SpringRunner.class)
@SpringBootTest(
        classes = {TestConfig.class}
)

public abstract class SparkTest {
    @Autowired
    public SQLContext sqlContext;
}
