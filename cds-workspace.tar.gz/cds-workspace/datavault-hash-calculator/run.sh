# creating landing and dimension data for the spark job to process and create Dv hashes

printf '********Deleting any existing data********\n\n\n'
hdfs dfs -rmr /user/osboxes

printf '********Creating landing and dimension data********\n\n\n'

hdfs dfs -mkdir -p /user/osboxes/spark/dv_v1_small/landing
hdfs dfs -mkdir -p /user/osboxes/spark/dv_v1_small/dimension

hdfs dfs -copyFromLocal ${WORKSPACE}/datavault-hash-calculator/src/test/resources/dimension/* /user/osboxes/spark/dv_v1_small/dimension
hdfs dfs -copyFromLocal ${WORKSPACE}/datavault-hash-calculator/src/test/resources/landing/* /user/osboxes/spark/dv_v1_small/landing

# Sometimes the inmemory Derby database used by Hive doesn't remove the lock after stopping
rm -rf /var/lib/hive/metastore/metastore_db/*.lck

printf '********Creating dataVault hash database********\n\n\n'
# creating DV hash database
hive -e 'drop database dv_v1_small cascade'
hive -e 'create database dv_v1_small'

printf '********Running spark process********\n\n\n'
# Running spark process
mvn clean package -DskipTests=true
spark-submit ${WORKSPACE}/datavault-hash-calculator/target/datavault-hash-calculator-1.0.0-SNAPSHOT.jar