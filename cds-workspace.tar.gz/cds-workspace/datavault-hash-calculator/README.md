Notes:
 This project creates Datavault hashes.

Usage:
    Locally execute the command 'sh run.sh'
