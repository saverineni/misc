package uk.gov.gsi.hmrc.cds.search;

import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.javanet.NetHttpTransport;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.net.URISyntaxException;

import static net.logstash.logback.encoder.org.apache.commons.lang.StringUtils.isBlank;
import static uk.gov.gsi.hmrc.cds.search.utils.FileLoaderUtils.getFileContent;

@Slf4j
public class ContractsValidator {

    public static final String MAPPINGS_JSON_PATH = "$.mappings";
    public static final String ACTUAL_SETTINGS_ANALYSIS_JSON_PATH = "$.settings.index.analysis";
    public static final String EXPECTED_SETTINGS_ANALYSIS_JSON_PATH = "$.settings.analysis";
    public static final String SETTINGS_URI = "/customs_search_service/_settings";
    public static final String MAPPINGS_URI = "/customs_search_service/_mappings";
    public static final String INGESTION_API = "INGESTION_API";
    public static final String API_ES = "API_ES";
    private static final int NUMBER_OF_ARGUMENTS = 3;
    private static HttpRequestFactory requestFactory = new NetHttpTransport().createRequestFactory();
    private ContractCheckingService contractCheckingService = new ContractCheckingService();
    private static final int PROJECT_TYPE = 0;
    private static final int ACTUAL_JSON = 1;
    private static final int EXPECTED_JSON = 2;
    private static ContractsValidator contractsValidator = new ContractsValidator();

    public static void main(String args[]) throws IOException, URISyntaxException {
        boolean isValid = contractsValidator.validateArguments(args);
        validate(isValid);
    }

    public boolean validateArguments(String[] args) throws IOException, URISyntaxException {
        if (args != null && args.length == NUMBER_OF_ARGUMENTS) {

            if (args[PROJECT_TYPE].equals(API_ES)) {
                String elasticSearchUrl = args[ACTUAL_JSON]; //schema ES
                String serviceMappingsFilePath = args[EXPECTED_JSON]; //instance json search service

                if (isBlank(elasticSearchUrl) || isBlank(serviceMappingsFilePath)) {
                    System.exit(1);
                }

                String settingsESUrl = elasticSearchUrl + SETTINGS_URI;
                String mappingsESUrl = elasticSearchUrl + MAPPINGS_URI;
                String serviceMappingsResponse = getFileContent(serviceMappingsFilePath);

                return contractsValidator.areApiAndESContractsValid(settingsESUrl, mappingsESUrl, serviceMappingsResponse);
            } else if (args[PROJECT_TYPE].equals(INGESTION_API)) {

                String ingestionJsonFile = args[ACTUAL_JSON];
                String serviceJsonFile = args[EXPECTED_JSON];

                if (isBlank(ingestionJsonFile) || isBlank(serviceJsonFile)) {
                    System.exit(1);
                }

                String ingestionJsonResponse = getFileContent(ingestionJsonFile);
                String serviceJsonResponse = getFileContent(serviceJsonFile);

                return new ContractsValidator().areIngestionAndApIContractsValid(ingestionJsonResponse, serviceJsonResponse);
            }
        } else {
            log.error("expected {} arguments but found {}", NUMBER_OF_ARGUMENTS, args.length);
            System.exit(1);
        }
        return false;
    }

    private static void validate(boolean isValid) {
        if(isValid) {
            log.info("Contracts validated successfully");
            System.exit(0);
        }
        log.error("Contracts validation failed");
        System.exit(1);
    }

    private boolean areApiAndESContractsValid(String settingsUrl, String mappingsUrl, String serviceMappingsResponse) throws IOException {
        String settingsESResponse = requestJson(settingsUrl);
        String mappingsESResponse = requestJson(mappingsUrl);

        if (isBlank(settingsESResponse) || isBlank(mappingsESResponse) || isBlank(serviceMappingsResponse)) {
            return false;
        }
        return contractCheckingService.verifyContract(settingsESResponse, serviceMappingsResponse,
                ACTUAL_SETTINGS_ANALYSIS_JSON_PATH, EXPECTED_SETTINGS_ANALYSIS_JSON_PATH) &&
                (contractCheckingService.verifyContract(mappingsESResponse, serviceMappingsResponse,
                        MAPPINGS_JSON_PATH, MAPPINGS_JSON_PATH));

    }

    private boolean areIngestionAndApIContractsValid( String ingestionJsonResponse, String serviceJsonResponse)  {
        if (isBlank(ingestionJsonResponse) || isBlank(serviceJsonResponse)) {
            return false;
        }
        return contractCheckingService.verify(ingestionJsonResponse, serviceJsonResponse);
    }

    private String requestJson(String url) throws IOException {
        HttpRequest settingsRequest = requestFactory.buildGetRequest(new GenericUrl(url));
        return settingsRequest.execute().parseAsString();
    }
}