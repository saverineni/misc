package uk.gov.gsi.hmrc.cds.search;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.utils.FileLoaderUtils;

import java.io.IOException;
import java.net.URISyntaxException;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.apache.commons.lang3.StringUtils.substring;
import static uk.gov.gsi.hmrc.cds.search.ContractsValidator.MAPPINGS_URI;
import static uk.gov.gsi.hmrc.cds.search.ContractsValidator.SETTINGS_URI;
import static uk.gov.gsi.hmrc.cds.search.utils.FileLoaderUtils.*;

public class ContractValidationIntegrationTest {

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(8080);
    private String host;
    private ContractsValidator contractsValidator = new ContractsValidator();

    @Before
    public void setUp() throws IOException, URISyntaxException {
        wireMockRule.resetAll();
        wireMockRule.stubFor(get(urlEqualTo(SETTINGS_URI)).willReturn(aResponse().withBody(getResourcesFileContent(FileLoaderUtils.API_ES_ACTUAL_SETTING_FILE))));
        wireMockRule.stubFor(get(urlEqualTo(MAPPINGS_URI)).willReturn(aResponse().withBody(getResourcesFileContent(FileLoaderUtils.API_ES_ACTUAL_MAPPING_FILE))));
        host = substring(wireMockRule.url(""), 0, -1);
    }

    @Test
    public void contractValid() throws IOException, URISyntaxException {
        String[] arguments = {  ContractsValidator.API_ES, host, API_ES_EXPECTED_VALID_MAPPING_FILE};
        Assert.assertTrue(contractsValidator.validateArguments(arguments));
    }

    @Test
    public void contractsSettingsInvalid() throws IOException, URISyntaxException {
        String[] arguments = {  ContractsValidator.API_ES, host, API_ES_EXPECTED_INVALID_SETTING_FILE};
        Assert.assertFalse(contractsValidator.validateArguments(arguments));
    }

    @Test
    public void contractsMappingsInvalid() throws IOException, URISyntaxException {
        String[] arguments = {  ContractsValidator.API_ES, host, API_ES_EXPECTED_INVALID_MAPPING_FILE};
        Assert.assertFalse(contractsValidator.validateArguments(arguments));
    }
}
