package uk.gov.gsi.hmrc.cds.search;

import org.junit.Assert;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.utils.FileLoaderUtils;

import java.io.IOException;
import java.net.URISyntaxException;

import static uk.gov.gsi.hmrc.cds.search.ContractsValidator.*;

public class ContractsCheckingServiceTest {

    @Test
    public void validateSettings() throws IOException, URISyntaxException {
        String serviceFileContents = FileLoaderUtils.getResourcesFileContent(FileLoaderUtils.API_ES_EXPECTED_VALID_MAPPING_FILE);
        String settingsESContents = FileLoaderUtils.getResourcesFileContent(FileLoaderUtils.API_ES_ACTUAL_SETTING_FILE);
        Assert.assertTrue( new ContractCheckingService().verifyContract(settingsESContents,
                serviceFileContents,
                ACTUAL_SETTINGS_ANALYSIS_JSON_PATH,
                EXPECTED_SETTINGS_ANALYSIS_JSON_PATH));
    }

    @Test
    public void validateMappings() throws IOException, URISyntaxException {
        String serviceFileContents = FileLoaderUtils.getResourcesFileContent(FileLoaderUtils.API_ES_EXPECTED_VALID_MAPPING_FILE);
        String fileContent = FileLoaderUtils.getResourcesFileContent(FileLoaderUtils.API_ES_ACTUAL_MAPPING_FILE);
        Assert.assertTrue( new ContractCheckingService().verifyContract(fileContent,
                serviceFileContents,
                MAPPINGS_JSON_PATH,
                MAPPINGS_JSON_PATH));
    }

}