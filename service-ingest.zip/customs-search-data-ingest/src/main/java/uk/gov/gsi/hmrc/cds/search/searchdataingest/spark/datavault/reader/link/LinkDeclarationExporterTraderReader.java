package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationExporterTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.LINK_DECLARATION_EXPORTER_TRADER;

@Component
public class LinkDeclarationExporterTraderReader extends DataVaultReader {
    private static final Encoder<LinkDeclarationExporterTrader> linkDeclarationExporterTraderEncoder = Encoders.bean(LinkDeclarationExporterTrader.class);

    public Dataset<LinkDeclarationExporterTrader> linkDeclarationExporterTraderDataset() {
        String dataFilePath = String.format("%s/%s", LINK_DECLARATION_EXPORTER_TRADER.tableName(), datafileRelativePath);
        String linkDeclarationExporterTraderFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<LinkDeclarationExporterTrader> linkDeclarationExporterTraderJavaRDD = sparkSession
                .read()
                .textFile(linkDeclarationExporterTraderFilePath)
                .javaRDD()
                .map((Function<String, LinkDeclarationExporterTrader>) LinkDeclarationExporterTrader::mapper)
                .cache();

        return sparkSession
                .createDataFrame(linkDeclarationExporterTraderJavaRDD, LinkDeclarationExporterTrader.class)
                .as(linkDeclarationExporterTraderEncoder)
                .cache();
    }

}
