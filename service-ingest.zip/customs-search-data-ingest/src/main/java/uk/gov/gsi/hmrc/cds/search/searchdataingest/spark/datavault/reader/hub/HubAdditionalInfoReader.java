package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubAdditionalInfo;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.HUB_ADDITIONAL_INFO;

@Component
public class HubAdditionalInfoReader extends DataVaultReader {
    private static final Encoder<HubAdditionalInfo> hubAdditionalInfoEncoder = Encoders.bean(HubAdditionalInfo.class);

    public Dataset hubAdditionalInfoDataset() {
        String dataFilePath = String.format("%s/%s", HUB_ADDITIONAL_INFO.tableName(), datafileRelativePath);
        String hubAdditionalInfoFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<HubAdditionalInfo> hubAdditionalInfoJavaRDD = sparkSession
                .read()
                .textFile(hubAdditionalInfoFilePath)
                .javaRDD()
                .map((Function<String, HubAdditionalInfo>) HubAdditionalInfo::mapper)
                .cache();

        return sparkSession
                .createDataFrame(hubAdditionalInfoJavaRDD, HubAdditionalInfo.class)
                .as(hubAdditionalInfoEncoder)
                .cache();
    }

}
