package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;

@Data
@Builder
public class LinkDeclarationInvoiceCurrency implements Serializable, BaseEntity {

    private String link_declaration_invoice_currency_key;
    private String hub_declaration_key;
    private String hub_currency_key;
    private String entry_reference;
    private String currency_iso_code;
    private String link_load_datetime;
    private String link_record_source;

    public static LinkDeclarationInvoiceCurrency mapper(String line) {
        List<String> columns = parseLine(line);

        return LinkDeclarationInvoiceCurrency.builder()
                .link_declaration_invoice_currency_key(columns.get(0))
                .hub_declaration_key(columns.get(1))
                .hub_currency_key(columns.get(2))
                .entry_reference(columns.get(3))
                .currency_iso_code(columns.get(4))
                .link_load_datetime(columns.get(5))
                .link_record_source(columns.get(6))
                .build();
    }

    public static final String PRIMARY_COLUMN = "link_declaration_invoice_currency_key";
    public static final String CURRENCY_ISO_CODE = "currency_iso_code";

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            "hub_declaration_key",
            "hub_currency_key"
    );
}
