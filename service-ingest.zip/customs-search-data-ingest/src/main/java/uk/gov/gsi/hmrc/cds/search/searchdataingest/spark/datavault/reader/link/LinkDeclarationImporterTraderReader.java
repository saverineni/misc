package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationImporterTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.LINK_DECLARATION_IMPORTER_TRADER;

@Component
public class LinkDeclarationImporterTraderReader extends DataVaultReader {
    private static final Encoder<LinkDeclarationImporterTrader> linkDeclarationImporterTraderEncoder = Encoders.bean(LinkDeclarationImporterTrader.class);

    public Dataset<LinkDeclarationImporterTrader> linkDeclarationImporterTraderDataset() {
        String dataFilePath = String.format("%s/%s", LINK_DECLARATION_IMPORTER_TRADER.tableName(), datafileRelativePath);
        String linkDeclarationImporterTraderFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<LinkDeclarationImporterTrader> linkDeclarationImporterTraderJavaRDD = sparkSession
                .read()
                .textFile(linkDeclarationImporterTraderFilePath)
                .javaRDD()
                .map((Function<String, LinkDeclarationImporterTrader>) LinkDeclarationImporterTrader::mapper)
                .cache();

        return sparkSession
                .createDataFrame(linkDeclarationImporterTraderJavaRDD, LinkDeclarationImporterTrader.class)
                .as(linkDeclarationImporterTraderEncoder)
                .cache();
    }

}
