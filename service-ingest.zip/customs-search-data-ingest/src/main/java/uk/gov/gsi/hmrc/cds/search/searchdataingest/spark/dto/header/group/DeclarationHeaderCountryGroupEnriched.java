package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group;

import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.country.DeclarationCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.country.DeclarationDestinationCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.country.DeclarationTransportCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.lookup.CountryLookUp;

import java.io.Serializable;
import java.util.Map;

@Data
@Builder
public class DeclarationHeaderCountryGroupEnriched  implements Serializable {
    public static Encoder<DeclarationHeaderCountryGroupEnriched> headerCountryGroupEnrichedEncoder = Encoders.bean(DeclarationHeaderCountryGroupEnriched.class);

    private String hub_declaration_key;
    private DeclarationCountry declarationCountry;

    public static DeclarationHeaderCountryGroupEnriched mapper(DeclarationHeaderCountryGroup headerCountryGroup, Map<String, String> countriesMap) {

        String destination_iso_country_code = headerCountryGroup.getDestination_iso_country_code_alpha_2();
        String destination_country_name = destination_iso_country_code != null ? countriesMap.get(destination_iso_country_code) : destination_iso_country_code;

        String transport_iso_country_code = headerCountryGroup.getTransport_iso_country_code_alpha_2();
        String transport_country_name = transport_iso_country_code != null ? countriesMap.get(transport_iso_country_code) : transport_iso_country_code;

        final DeclarationDestinationCountry declarationDestinationCountry = DeclarationDestinationCountry.builder().country_name(destination_country_name).iso_country_code_alpha_2(destination_iso_country_code).build();
        final DeclarationTransportCountry declarationTransportCountry = DeclarationTransportCountry.builder().country_name(transport_country_name).iso_country_code_alpha_2(transport_iso_country_code).build();

        final DeclarationCountry declarationCountry = DeclarationCountry.builder()
                                                        .destinationCountry(declarationDestinationCountry)
                                                        .transportCountry(declarationTransportCountry)
                                                        .build();

        return DeclarationHeaderCountryGroupEnriched.builder()
                .hub_declaration_key(headerCountryGroup.getHub_declaration_key())
                .declarationCountry(declarationCountry)
                .build();

    }

}
