package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group;

import com.google.common.collect.ImmutableList;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.country.DeclarationCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.currency.DeclarationCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.DeclarationTrader;

import java.io.Serializable;
import java.util.List;

@Data
public class DeclarationHeaderGroup implements Serializable {

    public static Encoder<DeclarationHeaderGroup> declarationHeaderGroupEncoder = Encoders.bean(DeclarationHeaderGroup.class);

    private String hub_declaration_key;
    private DeclarationCurrency declarationCurrency;
    private DeclarationTrader declarationTrader;
    private DeclarationCountry declarationCountry;

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
        "declarationCurrency",
        "declarationCountry",
        "declarationTrader"
    );

}
