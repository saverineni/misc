package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.HUB_DECLARATION;

@Component
public class HubDeclarationReader extends DataVaultReader {
    private static final Encoder<HubDeclaration> hubDeclarationEncoder = Encoders.bean(HubDeclaration.class);

    public Dataset<HubDeclaration> hubDeclarationDataset() {
        String dataFilePath = String.format("%s/%s", HUB_DECLARATION.tableName(), datafileRelativePath);
        String hubDeclarationFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<HubDeclaration> hubDeclarationJavaRDD = sparkSession
                .read()
                .textFile(hubDeclarationFilePath)
                .javaRDD()
                .map((Function<String, HubDeclaration>) HubDeclaration::mapper)
                .cache();

        return sparkSession
                .createDataFrame(hubDeclarationJavaRDD, HubDeclaration.class)
                .as(hubDeclarationEncoder)
                .cache();
    }

}
