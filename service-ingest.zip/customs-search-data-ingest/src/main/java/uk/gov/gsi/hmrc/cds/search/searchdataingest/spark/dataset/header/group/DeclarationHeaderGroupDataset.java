package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.header.group;

import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.country.DeclarationCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.currency.DeclarationCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group.DeclarationHeaderCountryGroupEnriched;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group.DeclarationHeaderCurrencyGroupEnriched;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group.DeclarationHeaderGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group.DeclarationHeaderTraderGroupEnriched;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.DeclarationTrader;

import static org.apache.spark.sql.functions.column;

@Component
public class DeclarationHeaderGroupDataset {

    private static final String LEFT_OUTER_JOIN = "left_outer";
    private final DeclarationHeaderCurrencyGroupDataset declarationHeaderCurrencyGroupDataset;
    private final DeclarationHeaderTraderGroupDataset declarationHeaderTraderGroupDataset;
    private final DeclarationHeaderCountryGroupDataset declarationHeaderCountryGroupDataset;

    @Autowired
    public DeclarationHeaderGroupDataset(DeclarationHeaderCurrencyGroupDataset declarationHeaderCurrencyGroupDataset,DeclarationHeaderTraderGroupDataset declarationHeaderTraderGroupDataset,DeclarationHeaderCountryGroupDataset declarationHeaderCountryGroupDataset) {
        this.declarationHeaderCountryGroupDataset = declarationHeaderCountryGroupDataset;
        this.declarationHeaderTraderGroupDataset = declarationHeaderTraderGroupDataset;
        this.declarationHeaderCurrencyGroupDataset = declarationHeaderCurrencyGroupDataset;
    }

    public Dataset<DeclarationHeaderGroup> build() {
        Dataset<DeclarationHeaderCurrencyGroupEnriched> headerCurrencyGroupDataset = declarationHeaderCurrencyGroupDataset.build();
        Dataset<DeclarationHeaderTraderGroupEnriched> headerTraderGroupDataset = declarationHeaderTraderGroupDataset.build();
        Dataset<DeclarationHeaderCountryGroupEnriched> headerCountryGroupDataset = declarationHeaderCountryGroupDataset.build();

        Dataset<DeclarationHeaderGroup> declarationHeaderGroupDataset = headerCurrencyGroupDataset
                .join(headerCountryGroupDataset, HubDeclaration.joinColumns, LEFT_OUTER_JOIN)
                .join(headerTraderGroupDataset, HubDeclaration.joinColumns, LEFT_OUTER_JOIN)
                .select(column(HubDeclaration.PRIMARY_COLUMN),
                        headerCurrencyGroupDataset.col(DeclarationCurrency.DECLARATION_CURRENCY_COLUMN),
                        headerCountryGroupDataset.col(DeclarationCountry.DECLARATION_COUNTRY_COLUMN),
                        headerTraderGroupDataset.col(DeclarationTrader.DECLARATION_TRADER_COLUMN)
                )
                .as(DeclarationHeaderGroup.declarationHeaderGroupEncoder)
                .cache();

        headerCurrencyGroupDataset.unpersist();
        headerTraderGroupDataset.unpersist();
        headerCountryGroupDataset.unpersist();

        return declarationHeaderGroupDataset;


    }
}
