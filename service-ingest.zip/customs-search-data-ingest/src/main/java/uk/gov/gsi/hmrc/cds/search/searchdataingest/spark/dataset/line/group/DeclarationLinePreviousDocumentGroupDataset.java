package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line.group;

import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line.DeclarationLinePreviousDocumentDataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubPreviousDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatPreviousDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLinePreviousDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLinePreviousDocumentGroup;

import static org.apache.spark.sql.functions.collect_list;
import static org.apache.spark.sql.functions.struct;

@Component
public class DeclarationLinePreviousDocumentGroupDataset {

    private final DeclarationLinePreviousDocumentDataset declarationLinePreviousDocumentDataset;

    @Autowired
    public DeclarationLinePreviousDocumentGroupDataset(DeclarationLinePreviousDocumentDataset declarationLinePreviousDocumentDataset) {
        this.declarationLinePreviousDocumentDataset = declarationLinePreviousDocumentDataset;
    }

    public Dataset<DeclarationLinePreviousDocumentGroup> build() {
        Dataset<DeclarationLinePreviousDocument> declarationLinePreviousDocumentDataset = this.declarationLinePreviousDocumentDataset.build();

        Dataset<DeclarationLinePreviousDocumentGroup> previousDocumentGroupDataset = declarationLinePreviousDocumentDataset
                .groupBy(declarationLinePreviousDocumentDataset.col(HubDeclarationLine.PRIMARY_COLUMN))
                .agg(
                        collect_list(
                                struct(
                                        declarationLinePreviousDocumentDataset.col(HubPreviousDocument.PRIMARY_COLUMN),
                                        declarationLinePreviousDocumentDataset.col(HubPreviousDocument.PREVIOUS_DOCUMENT_SEQUENCE_NUMBER),
                                        declarationLinePreviousDocumentDataset.col(SatPreviousDocument.PREVIOUS_DOCUMENT_REFERENCE)
                                )
                        ).alias(DeclarationLinePreviousDocumentGroup.ALIAS))
                .as(DeclarationLinePreviousDocumentGroup.declarationLinePreviousDocumentGroupEncoder)
                .persist();

        declarationLinePreviousDocumentDataset.unpersist();

        return previousDocumentGroupDataset;
    }
}
