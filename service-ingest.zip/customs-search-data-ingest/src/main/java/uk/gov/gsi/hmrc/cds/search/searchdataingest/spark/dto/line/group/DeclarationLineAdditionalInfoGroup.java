package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group;

import com.google.common.collect.Lists;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLineAdditionalInfo;

import java.io.Serializable;
import java.util.List;

@Data
public class DeclarationLineAdditionalInfoGroup implements Serializable {

    public static Encoder<DeclarationLineAdditionalInfoGroup> declarationLineAdditionalInfoGroupEncoder = Encoders.bean(DeclarationLineAdditionalInfoGroup.class);

    private String hub_declaration_line_key;
    private List<DeclarationLineAdditionalInfo> additionalInfo = Lists.newArrayList();

    public static final String ALIAS = "additionalInfo";
}
