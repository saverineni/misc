package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatCommodity;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.SAT_COMMODITY;

@Component
public class SatCommodityReader extends DataVaultReader {
    private static final Encoder<SatCommodity> satCommodityEncoder = Encoders.bean(SatCommodity.class);

    public Dataset satCommodityDataset() {
        String dataFilePath = String.format("%s/%s", SAT_COMMODITY.tableName(), datafileRelativePath);
        String satCommodityFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<SatCommodity> satCommodityJavaRDD = sparkSession
                .read()
                .textFile(satCommodityFilePath)
                .javaRDD()
                .map((Function<String, SatCommodity>) SatCommodity::mapper)
                .cache();

        return sparkSession
                .createDataFrame(satCommodityJavaRDD, SatCommodity.class)
                .as(satCommodityEncoder)
                .cache();
    }

}
