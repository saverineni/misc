package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;

@Data
@Builder
public class SatDeclaration implements Serializable, BaseEntity {

    private String hub_declaration_key;
    private String sat_hash_diff;
    private String sat_load_datetime;
    private String sat_load_end_datetime;
    private String sat_record_source;
    private String entry_number;
    private String entry_date;
    private String epu_number;
    private String entry_type;
    private String declaration_method;
    private String total_excise;
    private String declarant_representative_turn;
    private String consignee_aeo_certificate_type_code;
    private String declarant_aeo_certificate_type_code;
    private String route;
    private String declaration_import_export_indicator;
    private String generation_number;
    private String import_clearance_status;
    private String consignor_aeo_certificate_type_code;
    private String header_statistical_value;
    private String goods_departure_datetime;
    private String customs_value;
    private String total_duty;
    private String total_vat;
    private String net_mass_total;
    private String goods_location;
    private String acceptance_date;
    private String importer_turn_country_code;
    private String place_of_unloading_code;
    private String first_deferment_approval_num;
    private String first_deferment_approval_num_prefix;
    private String declaration_ucr;
    private String item_count;
    private String master_ucr;
    private String paying_agent_turn;
    private String place_of_loading_code;
    private String session_num;
    private String session_role_name;
    private String status_of_entry;
    private String transport_country;
    private String transport_id;
    private String transport_mode_code;
    private String dispatch_country;
    private String consignor_turn_country_code;
    private String consignor_nad_name;
    private String consignee_nad_name;
    private String consignee_nad_postcode;
    private String declarant_nad_name;
    private String customs_check_code;
    private String profile_id;
    private String invoice_total_declared;

    public static SatDeclaration mapper(String line) {
        List<String> columns = parseLine(line);

        return SatDeclaration.builder()
            .hub_declaration_key(columns.get(0))
            .sat_hash_diff(columns.get(1))
            .sat_load_datetime(columns.get(2))
            .sat_load_end_datetime(columns.get(3))
            .sat_record_source(columns.get(4))
            .entry_number(columns.get(5))
            .entry_date(columns.get(6))
            .epu_number(columns.get(7))
            .entry_type(columns.get(8))
            .declaration_method(columns.get(9))
            .total_excise(columns.get(10))
            .declarant_representative_turn(columns.get(11))
            .consignee_aeo_certificate_type_code(columns.get(12))
            .declarant_aeo_certificate_type_code(columns.get(13))
            .route(columns.get(14))
            .declaration_import_export_indicator(columns.get(15))
            .generation_number(columns.get(16))
            .import_clearance_status(columns.get(17))
            .consignor_aeo_certificate_type_code(columns.get(18))
            .header_statistical_value(columns.get(19))
            .goods_departure_datetime(columns.get(20))
            .customs_value(columns.get(21))
            .total_duty(columns.get(22))
            .total_vat(columns.get(23))
            .net_mass_total(columns.get(24))
            .goods_location(columns.get(25))
            .acceptance_date(columns.get(26))
            .importer_turn_country_code(columns.get(27))
            .place_of_unloading_code(columns.get(28))
            .first_deferment_approval_num(columns.get(29))
            .first_deferment_approval_num_prefix(columns.get(30))
            .declaration_ucr(columns.get(31))
            .item_count(columns.get(32))
            .master_ucr(columns.get(33))
            .paying_agent_turn(columns.get(34))
            .place_of_loading_code(columns.get(35))
            .session_num(columns.get(36))
            .session_role_name(columns.get(37))
            .status_of_entry(columns.get(38))
            .transport_country(columns.get(39))
            .transport_id(columns.get(40))
            .transport_mode_code(columns.get(41))
            .dispatch_country(columns.get(42))
            .consignor_turn_country_code(columns.get(43))
            .consignor_nad_name(columns.get(44))
            .consignee_nad_name(columns.get(45))
            .consignee_nad_postcode(columns.get(46))
            .declarant_nad_name(columns.get(47))
            .customs_check_code(columns.get(48))
            .profile_id(columns.get(49))
            .invoice_total_declared(columns.get(50))
                .build();
    }

    public static final List<String> SELECT_COLUMNS =  ImmutableList.of(
                    "entry_number",
                    "entry_date",
                    "epu_number",
                    "entry_type",
                    "declaration_method",
                    "total_excise",
                    "declarant_representative_turn",
                    "consignee_aeo_certificate_type_code",
                    "declarant_aeo_certificate_type_code",
                    "route",
                    "declaration_import_export_indicator",
                    "generation_number",
                    "import_clearance_status",
                    "consignor_aeo_certificate_type_code",
                    "header_statistical_value",
                    "goods_departure_datetime",
                    "customs_value",
                    "total_duty",
                    "total_vat",
                    "net_mass_total",
                    "goods_location",
                    "acceptance_date",
                    "importer_turn_country_code",
                    "place_of_unloading_code",
                    "first_deferment_approval_num",
                    "first_deferment_approval_num_prefix",
                    "declaration_ucr",
                    "item_count",
                    "master_ucr",
                    "paying_agent_turn",
                    "place_of_loading_code",
                    "session_num",
                    "session_role_name",
                    "status_of_entry",
                    "transport_country",
                    "transport_id",
                    "transport_mode_code",
                    "dispatch_country",
                    "consignor_turn_country_code",
                    "consignor_nad_name",
                    "consignee_nad_name",
                    "consignee_nad_postcode",
                    "declarant_nad_name",
                    "customs_check_code",
                    "profile_id",
                    "invoice_total_declared"
                );
}
