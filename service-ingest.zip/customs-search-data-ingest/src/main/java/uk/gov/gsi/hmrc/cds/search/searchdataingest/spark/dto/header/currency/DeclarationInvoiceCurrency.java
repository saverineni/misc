package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.currency;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;


@Data
@Builder
public class DeclarationInvoiceCurrency implements Serializable {

    private String currency_iso_code;
    private String currency_name;

    public static final String INVOICE_CURRENCY_ISO_CODE = "invoice_currency_iso_code";


}
