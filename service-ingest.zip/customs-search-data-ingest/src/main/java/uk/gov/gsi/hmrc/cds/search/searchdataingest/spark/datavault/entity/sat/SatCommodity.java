package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Column;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static org.apache.spark.sql.functions.column;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.valueAt;

@Data
@Builder
public class SatCommodity implements Serializable, BaseEntity {

    private String hub_commodity_key;
    private String sat_hash_diff;
    private String sat_load_datetime;
    private String sat_load_end_datetime;
    private String sat_record_source;
    private String cc_year;
    private String cc_month;
    private String hs_chapter;
    private String hs_heading;
    private String hs_chapter_heading;
    private String hs_subheading;
    private String chapter_description;
    private String heading_description;
    private String subheading_description;

    public static SatCommodity mapper(String line) {
        List<String> columns = parseLine(line);

        return SatCommodity.builder()
                .hub_commodity_key(valueAt(columns, 0))
                .sat_hash_diff(valueAt(columns, 1))
                .sat_load_datetime(valueAt(columns, 2))
                .sat_load_end_datetime(valueAt(columns, 3))
                .sat_record_source(valueAt(columns, 4))
                .cc_year(valueAt(columns, 5))
                .cc_month(valueAt(columns, 6))
                .hs_chapter(valueAt(columns, 7))
                .hs_heading(valueAt(columns, 8))
                .hs_chapter_heading(valueAt(columns, 9))
                .hs_subheading(valueAt(columns, 10))
                .chapter_description(valueAt(columns, 11))
                .heading_description(valueAt(columns, 12))
                .subheading_description(valueAt(columns, 13))
                .build();
    }
    
    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            "cc_year",
            "cc_month",
            "hs_chapter",
            "hs_heading",
            "hs_chapter_heading",
            "hs_subheading",
            "chapter_description",
            "heading_description",
            "subheading_description"
    );

    public static List<Column> columns = ImmutableList.of(
            column("cc_year"),
            column("cc_month"),
            column("hs_chapter"),
            column("hs_heading"),
            column("hs_chapter_heading"),
            column("hs_subheading"),
            column("chapter_description"),
            column("heading_description"),
            column("subheading_description")
    );

}
