package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader;

import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.consignor.ConsignorTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.declarant.DeclarantTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.exporter.ExporterTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.importer.ImporterTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.payingagent.PayingAgentTrader;

import java.io.Serializable;


@Data
@Builder
public class DeclarationTrader implements Serializable {

    private ConsignorTrader consignorTrader;
    private DeclarantTrader declarantTrader;
    private ExporterTrader exporterTrader;
    private ImporterTrader importerTrader;
    private PayingAgentTrader payingAgentTrader;

    public static final String DECLARATION_TRADER_COLUMN = "declarationTrader";


}
