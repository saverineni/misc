package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.header.group;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.header.trader.*;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub.HubDeclarationReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group.DeclarationHeaderTraderGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group.DeclarationHeaderTraderGroupEnriched;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.consignor.DeclarationHeaderConsignorTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.declarant.DeclarationHeaderDeclarantTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.exporter.DeclarationHeaderExporterTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.importer.DeclarationHeaderImporterTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.payingagent.DeclarationHeaderPayingAgentTrader;

@Component
public class DeclarationHeaderTraderGroupDataset {

    private static final String LEFT_OUTER_JOIN = "left_outer";

    private final HubDeclarationReader hubDeclarationReader;

    @Qualifier("DeclarationHeaderImporterTraderDataset")
    private final DeclarationHeaderImporterTraderDataset headerImporterTraderDataset;

    @Qualifier("DeclarationHeaderExporterTraderDataset")
    private final DeclarationHeaderExporterTraderDataset headerExporterTraderDataset;

    @Qualifier("DeclarationHeaderDeclarantTraderDataset")
    private final DeclarationHeaderDeclarantTraderDataset headerDeclarantTraderDataset;

    @Qualifier("DeclarationHeaderPayingAgentTraderDataset")
    private final DeclarationHeaderPayingAgentTraderDataset headerPayingAgentTraderDataset;

    @Qualifier("DeclarationHeaderConsignorTraderDataset")
    private final DeclarationHeaderConsignorTraderDataset headerConsignorTraderDataset;

    @Autowired
    public DeclarationHeaderTraderGroupDataset(HubDeclarationReader hubDeclarationReader,DeclarationHeaderImporterTraderDataset headerImporterTraderDataset,DeclarationHeaderExporterTraderDataset headerExporterTraderDataset,
                                               DeclarationHeaderDeclarantTraderDataset headerDeclarantTraderDataset,DeclarationHeaderPayingAgentTraderDataset headerPayingAgentTraderDataset,DeclarationHeaderConsignorTraderDataset headerConsignorTraderDataset) {
        this.hubDeclarationReader = hubDeclarationReader;
        this.headerImporterTraderDataset = headerImporterTraderDataset;
        this.headerExporterTraderDataset = headerExporterTraderDataset;
        this.headerDeclarantTraderDataset = headerDeclarantTraderDataset;
        this.headerPayingAgentTraderDataset = headerPayingAgentTraderDataset;
        this.headerConsignorTraderDataset = headerConsignorTraderDataset;
    }

    public Dataset<DeclarationHeaderTraderGroupEnriched> build() {
        Dataset<HubDeclaration> hubDeclarationDataset = hubDeclarationReader.hubDeclarationDataset();

        Dataset<DeclarationHeaderImporterTrader> importerTraderDataset = headerImporterTraderDataset.build();
        Dataset<DeclarationHeaderExporterTrader> exporterTraderDataset = headerExporterTraderDataset.build();
        Dataset<DeclarationHeaderDeclarantTrader> declarantTraderDataset = headerDeclarantTraderDataset.build();
        Dataset<DeclarationHeaderPayingAgentTrader> payingAgentTraderDataset = headerPayingAgentTraderDataset.build();
        Dataset<DeclarationHeaderConsignorTrader> consignorTraderDataset = headerConsignorTraderDataset.build();

        Dataset<DeclarationHeaderTraderGroupEnriched> headerTraderGroupEnrichedDataset = hubDeclarationDataset
                .select(HubDeclaration.PRIMARY_COLUMN)
                .join(importerTraderDataset, HubDeclaration.joinColumns, LEFT_OUTER_JOIN)
                .join(exporterTraderDataset, HubDeclaration.joinColumns, LEFT_OUTER_JOIN)
                .join(declarantTraderDataset, HubDeclaration.joinColumns, LEFT_OUTER_JOIN)
                .join(payingAgentTraderDataset, HubDeclaration.joinColumns, LEFT_OUTER_JOIN)
                .join(consignorTraderDataset, HubDeclaration.joinColumns, LEFT_OUTER_JOIN)
                .as(DeclarationHeaderTraderGroup.declarationHeaderTraderGroupEncoder)
                .map((MapFunction<DeclarationHeaderTraderGroup, DeclarationHeaderTraderGroupEnriched>) value -> DeclarationHeaderTraderGroupEnriched.mapper(value), DeclarationHeaderTraderGroupEnriched.headerTraderGroupEnrichedEncoder)
                .persist();

        importerTraderDataset.unpersist();
        exporterTraderDataset.unpersist();
        declarantTraderDataset.unpersist();
        payingAgentTraderDataset.unpersist();
        consignorTraderDataset.unpersist();

        return headerTraderGroupEnrichedDataset;
    }

}
