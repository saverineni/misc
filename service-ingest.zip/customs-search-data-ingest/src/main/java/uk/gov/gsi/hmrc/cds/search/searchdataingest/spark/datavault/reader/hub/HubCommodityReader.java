package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubCommodity;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.HUB_COMMODITY;

@Component
public class HubCommodityReader extends DataVaultReader {
    private static final Encoder<HubCommodity> hubCommodityEncoder = Encoders.bean(HubCommodity.class);

    public Dataset hubCommodityDataset() {
        String dataFilePath = String.format("%s/%s", HUB_COMMODITY.tableName(), datafileRelativePath);
        String hubCommodityFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<HubCommodity> hubCommodityJavaRDD = sparkSession
                .read()
                .textFile(hubCommodityFilePath)
                .javaRDD()
                .map((Function<String, HubCommodity>) HubCommodity::mapper)
                .cache();

        return sparkSession
                .createDataFrame(hubCommodityJavaRDD, HubCommodity.class)
                .as(hubCommodityEncoder)
                .cache();
    }

}
