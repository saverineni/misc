package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group;

import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.currency.DeclarationCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.currency.DeclarationFreightCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.currency.DeclarationInvoiceCurrency;

import java.io.Serializable;
import java.util.Map;

@Data
@Builder
public class DeclarationHeaderCurrencyGroupEnriched implements Serializable {
    public static Encoder<DeclarationHeaderCurrencyGroupEnriched> headerCurrencyGroupEnrichedEncoder = Encoders.bean(DeclarationHeaderCurrencyGroupEnriched.class);

    private String hub_declaration_key;
    private DeclarationCurrency declarationCurrency;

    public static DeclarationHeaderCurrencyGroupEnriched mapper(DeclarationHeaderCurrencyGroup headerCurrencyGroup, Map<String, String> currenciesMap) {
        String invoice_currency_iso_code = headerCurrencyGroup.getInvoice_currency_iso_code();
        String invoice_currency_name = invoice_currency_iso_code != null ? currenciesMap.get(invoice_currency_iso_code) : invoice_currency_iso_code;
        String freight_currency_iso_code = headerCurrencyGroup.getFreight_currency_iso_code();
        String freight_currency_name = freight_currency_iso_code != null ? currenciesMap.get(freight_currency_iso_code) : freight_currency_iso_code;

        final DeclarationFreightCurrency declarationFreightCurrency = DeclarationFreightCurrency.builder().currency_iso_code(freight_currency_iso_code).currency_name(freight_currency_name).build();
        final DeclarationInvoiceCurrency declarationInvoiceCurrency = DeclarationInvoiceCurrency.builder().currency_iso_code(invoice_currency_iso_code).currency_name(invoice_currency_name).build();

        final DeclarationCurrency headerDeclarationCurrency = DeclarationCurrency.builder()
                                                            .freightCurrency(declarationFreightCurrency)
                                                            .invoiceCurrency(declarationInvoiceCurrency)
                                                            .build();

        DeclarationHeaderCurrencyGroupEnriched headerCurrencyGroupEnriched = DeclarationHeaderCurrencyGroupEnriched.builder()
                .hub_declaration_key(headerCurrencyGroup.getHub_declaration_key())
                .declarationCurrency(headerDeclarationCurrency)
                .build();

        return headerCurrencyGroupEnriched;
    }
}
