package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line;

import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineCustomsProcedureCode;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationLineCustomsProcedureCodeReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationCustomsProcedureCode;

import static org.apache.spark.sql.functions.column;
import static org.apache.spark.sql.functions.struct;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationCustomsProcedureCode.DeclarationCustomsProcedureCodeGroup;

@Component
public class DeclarationLineCPCDataset {

    private static final String DECLARATION_LINE_KEY = HubDeclarationLine.PRIMARY_COLUMN;

    private final LinkDeclarationLineCustomsProcedureCodeReader linkDeclarationLineCustomsProcedureCodeReader;

    @Autowired
    public DeclarationLineCPCDataset(LinkDeclarationLineCustomsProcedureCodeReader linkDeclarationLineCustomsProcedureCodeReader) {
        this.linkDeclarationLineCustomsProcedureCodeReader = linkDeclarationLineCustomsProcedureCodeReader;
    }


    public Dataset<DeclarationCustomsProcedureCodeGroup> build(){

        Dataset<DeclarationCustomsProcedureCodeGroup> declarationCustomsProcedureCodeGroupDataset = linkDeclarationLineCustomsProcedureCodeReader.linkDeclarationLineCustomsProcedureCodeDataset()
                .select(column(DECLARATION_LINE_KEY),
                        struct(
                                column(LinkDeclarationLineCustomsProcedureCode.CPC_COLUMN)
                        ).alias(DeclarationCustomsProcedureCode.ALIAS)
                ).as(DeclarationCustomsProcedureCode.declarationCustomsProcedureCodeEncoder)
                .cache();

        return declarationCustomsProcedureCodeGroupDataset;

    }
}
