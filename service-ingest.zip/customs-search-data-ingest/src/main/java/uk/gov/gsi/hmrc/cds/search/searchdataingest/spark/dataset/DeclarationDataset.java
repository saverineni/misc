package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset;

import com.google.common.collect.Iterables;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.header.DeclarationHeaderDataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.Declaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.DeclarationLineDeclarationGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.DeclarationHeader;

@Component
public class DeclarationDataset {

    private static final String LEFT_OUTER_JOIN = "left_outer";

    private static Column[] selectColumns = Iterables.toArray(
            Declaration.columns, Column.class);

    private final DeclarationHeaderDataset declarationHeaderDataset;
    private final DeclarationLineDeclarationGroupDataset declarationLineDeclarationGroupDataset;

    @Autowired
    public DeclarationDataset(DeclarationHeaderDataset declarationHeaderDataset, DeclarationLineDeclarationGroupDataset declarationLineDeclarationGroupDataset) {
        this.declarationHeaderDataset = declarationHeaderDataset;
        this.declarationLineDeclarationGroupDataset = declarationLineDeclarationGroupDataset;
    }

    public Dataset<Declaration> build() {
        Dataset<DeclarationLineDeclarationGroup> declarationLineDeclarationGroupDataset = this.declarationLineDeclarationGroupDataset.build();
        Dataset<DeclarationHeader> declarationHeaderDataset = this.declarationHeaderDataset.build();

        Dataset<Declaration> declarationDataset = declarationLineDeclarationGroupDataset
                .join(declarationHeaderDataset, HubDeclaration.joinColumns, LEFT_OUTER_JOIN)
                .select(selectColumns)
                .as(Declaration.declarationEncoder);

        declarationLineDeclarationGroupDataset.unpersist();
        declarationHeaderDataset.unpersist();

        return declarationDataset;
    }
}
