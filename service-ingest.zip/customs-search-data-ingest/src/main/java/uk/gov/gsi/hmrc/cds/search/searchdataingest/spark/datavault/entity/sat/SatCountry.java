package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.*;

@Data
@Builder
public class SatCountry implements Serializable, BaseEntity {
    private String hub_country_key;
    private String sat_hash_diff;
    private String sat_load_datetime;
    private String sat_load_end_datetime;
    private String sat_record_source;
    private String country_name;
    private String country_sequence_number;
    private String country_comments;

    public static SatCountry mapper(String line) {
        List<String> columns = parseLine(line);
        return SatCountry.builder()
                .hub_country_key(valueAt(columns,0))
                .sat_hash_diff(columns.get(1))
                .sat_load_datetime(columns.get(2))
                .sat_load_end_datetime(columns.get(3))
                .sat_record_source(columns.get(4))
                .country_name(columns.get(5))
                .country_sequence_number(valueAt(columns,6))
                .country_comments(valueAt(columns,7))
                .build();
    }

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            "country_name",
            "country_sequence_number",
            "country_comments"
    );
}
