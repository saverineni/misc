package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import scala.collection.mutable.Seq;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;

@Data
@Builder
public class HubCountry implements Serializable, BaseEntity {
    private String hub_country_key;
    private String iso_country_code_alpha_2;
    private String hub_load_datetime;
    private String hub_record_source;

    public static HubCountry mapper(String line) {
        List<String> columns = parseLine(line);
        return HubCountry.builder()
                .hub_country_key(columns.get(0))
                .iso_country_code_alpha_2(columns.get(1))
                .hub_load_datetime(columns.get(2))
                .hub_record_source(columns.get(3))
                .build();
    }

    public static final String PRIMARY_COLUMN = "hub_country_key";

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            PRIMARY_COLUMN,
            "iso_country_code_alpha_2"
    );

    public static Seq<String> joinColumns = joinExpression(PRIMARY_COLUMN);

}
