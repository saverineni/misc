package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import lombok.Data;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.country.DeclarationCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.currency.DeclarationCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.DeclarationTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLine;

import java.io.Serializable;
import java.util.List;

import static org.apache.spark.sql.functions.column;

@Data
public class Declaration implements Serializable {

    public static Encoder<Declaration> declarationEncoder = Encoders.bean(Declaration.class);

    private String hub_declaration_key;
    private String entry_reference;
    private String entry_number;
    private String entry_date;
    private String epu_number;
    private String entry_type;
    private String declaration_method;
    private String total_excise;
    private String declarant_representative_turn;
    private String consignee_aeo_certificate_type_code;
    private String declarant_aeo_certificate_type_code;
    private String route;
    private String declaration_import_export_indicator;
    private String generation_number;
    private String import_clearance_status;
    private String consignor_aeo_certificate_type_code;
    private String header_statistical_value;
    private String goods_departure_datetime;
    private String customs_value;
    private String total_duty;
    private String total_vat;
    private String net_mass_total;
    private String goods_location;
    private String acceptance_date;
    private String importer_turn_country_code;
    private String place_of_unloading_code;
    private String first_deferment_approval_num;
    private String first_deferment_approval_num_prefix;
    private String declaration_ucr;
    private String item_count;
    private String master_ucr;
    private String paying_agent_turn;
    private String place_of_loading_code;
    private String session_num;
    private String session_role_name;
    private String status_of_entry;
    private String transport_country;
    private String transport_id;
    private String transport_mode_code;
    private String dispatch_country;
    private String consignor_turn_country_code;
    private String consignor_nad_name;
    private String consignee_nad_name;
    private String consignee_nad_postcode;
    private String declarant_nad_name;
    private String customs_check_code;
    private String profile_id;
    private String invoice_total_declared;
    private DeclarationCurrency declarationCurrency;
    private DeclarationTrader declarationTrader;
    private DeclarationCountry declarationCountry;
    private List<DeclarationLine> lines = Lists.newArrayList();

    public static List<Column> columns = ImmutableList.of(
            column("hub_declaration_key"),
            column("entry_reference"),
            column("entry_number"),
            column("entry_date"),
            column("epu_number"),
            column("entry_type"),
            column("declaration_method"),
            column("total_excise"),
            column("declarant_representative_turn"),
            column("consignee_aeo_certificate_type_code"),
            column("declarant_aeo_certificate_type_code"),
            column("route"),
            column("declaration_import_export_indicator"),
            column("generation_number"),
            column("import_clearance_status"),
            column("consignor_aeo_certificate_type_code"),
            column("header_statistical_value"),
            column("goods_departure_datetime"),
            column("customs_value"),
            column("total_duty"),
            column("total_vat"),
            column("net_mass_total"),
            column("goods_location"),
            column("acceptance_date"),
            column("importer_turn_country_code"),
            column("place_of_unloading_code"),
            column("first_deferment_approval_num"),
            column("first_deferment_approval_num_prefix"),
            column("declaration_ucr"),
            column("item_count"),
            column("master_ucr"),
            column("paying_agent_turn"),
            column("place_of_loading_code"),
            column("session_num"),
            column("session_role_name"),
            column("status_of_entry"),
            column("transport_country"),
            column("transport_id"),
            column("transport_mode_code"),
            column("dispatch_country"),
            column("consignor_turn_country_code"),
            column("consignor_nad_name"),
            column("consignee_nad_name"),
            column("consignee_nad_postcode"),
            column("declarant_nad_name"),
            column("customs_check_code"),
            column("profile_id"),
            column("invoice_total_declared"),
            column("declarationCurrency"),
            column("declarationCountry"),
            column("declarationTrader"),
            column("lines")
    );

}
