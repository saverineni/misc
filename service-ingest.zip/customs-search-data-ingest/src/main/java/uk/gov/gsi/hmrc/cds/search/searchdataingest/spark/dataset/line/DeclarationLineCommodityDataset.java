package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubCommodity;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatCommodity;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationLineCommodityReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatCommodityReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLineCommodity;

import static org.apache.spark.sql.functions.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLineCommodity.*;

@Component
public class DeclarationLineCommodityDataset {

    private static final String DECLARATION_LINE_KEY = HubDeclarationLine.PRIMARY_COLUMN;

    private static Column[] commodityColumns= Iterables.toArray(
            Iterables.concat(
                    Lists.newArrayList(
                            column(HubCommodity.PRIMARY_COLUMN)
                    ),
                    HubCommodity.columns,
                    SatCommodity.columns
            )
            , Column.class);


    private final SatCommodityReader satCommodityReader;
    private final LinkDeclarationLineCommodityReader linkDeclarationLineCommodityReader;

    @Autowired
    public DeclarationLineCommodityDataset(SatCommodityReader satCommodityReader,LinkDeclarationLineCommodityReader linkDeclarationLineCommodityReader) {
        this.satCommodityReader = satCommodityReader;
        this.linkDeclarationLineCommodityReader = linkDeclarationLineCommodityReader;
    }

    public Dataset<DeclarationLineCommodityGroup> build() {

        Dataset linkDeclarationLineCommodityDataset = linkDeclarationLineCommodityReader.linkDeclarationLineCommodityDataset();
        Dataset<SatCommodity> satCommodityDataset = satCommodityReader.satCommodityDataset();

        Dataset<DeclarationLineCommodityGroup> declarationLineCommodityGroupDataset = linkDeclarationLineCommodityDataset
                .join(satCommodityDataset, HubCommodity.joinColumns)
                .select(column(DECLARATION_LINE_KEY),
                        struct(commodityColumns)
                                .alias(DeclarationLineCommodity.ALIAS)
                ).as(DeclarationLineCommodity.declarationLineCommodityEncoder)
                .cache();

        linkDeclarationLineCommodityDataset.unpersist();
        satCommodityDataset.unpersist();

        return declarationLineCommodityGroupDataset;
    }

}
