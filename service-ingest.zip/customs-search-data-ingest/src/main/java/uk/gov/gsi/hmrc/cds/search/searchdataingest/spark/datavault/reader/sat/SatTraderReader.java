package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.SAT_TRADER;

@Component
public class SatTraderReader extends DataVaultReader {
    private static final Encoder<SatTrader> satTraderEncoder = Encoders.bean(SatTrader.class);

    public Dataset<SatTrader> satTraderDataset() {
        String dataFilePath = String.format("%s/%s", SAT_TRADER.tableName(), datafileRelativePath);
        String satTraderFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<SatTrader> satTraderJavaRDD = sparkSession
                .read()
                .textFile(satTraderFilePath)
                .javaRDD()
                .map((Function<String, SatTrader>) SatTrader::mapper)
                .cache();

        return sparkSession
                .createDataFrame(satTraderJavaRDD, SatTrader.class)
                .as(satTraderEncoder)
                .cache();
    }

}
