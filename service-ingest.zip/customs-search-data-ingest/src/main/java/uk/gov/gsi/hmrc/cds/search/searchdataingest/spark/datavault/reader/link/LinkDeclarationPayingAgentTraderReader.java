package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationPayingAgentTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.LINK_DECLARATION_PAYING_AGENT_TRADER;

@Component
public class LinkDeclarationPayingAgentTraderReader extends DataVaultReader {
    private static final Encoder<LinkDeclarationPayingAgentTrader> linkDeclarationPayingAgentTraderEncoder = Encoders.bean(LinkDeclarationPayingAgentTrader.class);

    public Dataset<LinkDeclarationPayingAgentTrader> linkDeclarationPayingAgentTraderDataset() {
        String dataFilePath = String.format("%s/%s", LINK_DECLARATION_PAYING_AGENT_TRADER.tableName(), datafileRelativePath);
        String linkDeclarationPayingAgentTraderFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<LinkDeclarationPayingAgentTrader> linkDeclarationPayingAgentTraderJavaRDD = sparkSession
                .read()
                .textFile(linkDeclarationPayingAgentTraderFilePath)
                .javaRDD()
                .map((Function<String, LinkDeclarationPayingAgentTrader>) LinkDeclarationPayingAgentTrader::mapper)
                .cache();

        return sparkSession
                .createDataFrame(linkDeclarationPayingAgentTraderJavaRDD, LinkDeclarationPayingAgentTrader.class)
                .as(linkDeclarationPayingAgentTraderEncoder)
                .cache();
    }

}
