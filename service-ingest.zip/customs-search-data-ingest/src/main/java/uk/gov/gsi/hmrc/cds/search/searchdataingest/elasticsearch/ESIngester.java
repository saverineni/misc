package uk.gov.gsi.hmrc.cds.search.searchdataingest.elasticsearch;

import com.google.common.collect.ImmutableMap;
import org.apache.spark.sql.Dataset;
import org.elasticsearch.spark.rdd.api.java.JavaEsSpark;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SearchDocumentJob;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclaration;

import java.util.Map;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.config.ESConfig.MAPPING_ID_KEY;

@Component
public class ESIngester {
    private static final Map<String, String> ES_CONFIG = ImmutableMap.of(MAPPING_ID_KEY, HubDeclaration.ENTRY_REFERENCE);
    private final SearchDocumentJob searchDocumentJob;

    @Autowired
    public ESIngester(SearchDocumentJob searchDocumentJob) {
        this.searchDocumentJob = searchDocumentJob;
    }

    public void ingest() {
        Dataset<String> declarationDocumentDataset = searchDocumentJob.declarationDocument();
        JavaEsSpark.saveJsonToEs(declarationDocumentDataset.toJavaRDD(), ES_CONFIG);
    }
}
