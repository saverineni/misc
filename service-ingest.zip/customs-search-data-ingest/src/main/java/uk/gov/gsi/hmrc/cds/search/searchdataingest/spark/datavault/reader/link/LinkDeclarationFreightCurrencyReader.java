package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationFreightCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.LINK_DECLARATION_FREIGHT_CURRENCY;

@Component
public class LinkDeclarationFreightCurrencyReader extends DataVaultReader {
    private static final Encoder<LinkDeclarationFreightCurrency> linkDeclarationFreightCurrencyEncoder = Encoders.bean(LinkDeclarationFreightCurrency.class);

    public Dataset<LinkDeclarationFreightCurrency> linkDeclarationFreightCurrencyDataset() {
        String dataFilePath = String.format("%s/%s", LINK_DECLARATION_FREIGHT_CURRENCY.tableName(), datafileRelativePath);
        String linkDeclarationFreightCurrencyFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<LinkDeclarationFreightCurrency> linkDeclarationFreightCurrencyJavaRDD = sparkSession
                .read()
                .textFile(linkDeclarationFreightCurrencyFilePath)
                .javaRDD()
                .map((Function<String, LinkDeclarationFreightCurrency>) LinkDeclarationFreightCurrency::mapper)
                .cache();

        return sparkSession
                .createDataFrame(linkDeclarationFreightCurrencyJavaRDD, LinkDeclarationFreightCurrency.class)
                .as(linkDeclarationFreightCurrencyEncoder)
                .cache();
    }

}
