package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.country;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;


@Data
@Builder
public class DeclarationDestinationCountry implements Serializable {

    private String iso_country_code_alpha_2;
    private String country_name;

    public static final String DESTINATION_ISO_COUNTRY_CODE = "destination_iso_country_code_alpha_2";

}
