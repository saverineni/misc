package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import scala.collection.JavaConversions;
import scala.collection.mutable.Seq;

import java.util.Arrays;
import java.util.List;

public interface BaseEntity {

    String DEFAULT_FILE_DELIMITER = "\\01";

    static List<String> parseLine(String line) {
        return Arrays.asList(line.split(DEFAULT_FILE_DELIMITER));
    }

    static String valueAt(Iterable<String> columns, int index) {
        return Iterables.get(columns,index, null);
    }

    static Seq<String> joinExpression(String... joinColumns) {
        return JavaConversions
                .asScalaBuffer(Lists.newArrayList(joinColumns));
    }

    static Seq<String> joinExpression(List<String> columns) {
        return JavaConversions
                .asScalaBuffer(columns);
    }

    static String[] toArray(List<String> columns) {
        return Iterables.toArray(columns, String.class);
    }


}
