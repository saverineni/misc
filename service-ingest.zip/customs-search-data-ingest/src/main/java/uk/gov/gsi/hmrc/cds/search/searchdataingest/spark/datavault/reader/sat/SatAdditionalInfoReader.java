package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatAdditionalInfo;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.SAT_ADDITIONAL_INFO;

@Component
public class SatAdditionalInfoReader extends DataVaultReader {
    private static final Encoder<SatAdditionalInfo> satAdditionalInfoEncoder = Encoders.bean(SatAdditionalInfo.class);

    public Dataset<SatAdditionalInfo> satAdditionalInfoDataset() {
        String dataFilePath = String.format("%s/%s", SAT_ADDITIONAL_INFO.tableName(), datafileRelativePath);
        String satAdditionalInfoFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<SatAdditionalInfo> satAdditionalInfoJavaRDD = sparkSession
                .read()
                .textFile(satAdditionalInfoFilePath)
                .javaRDD()
                .map((Function<String, SatAdditionalInfo>) SatAdditionalInfo::mapper)
                .cache();

        return sparkSession
                .createDataFrame(satAdditionalInfoJavaRDD, SatAdditionalInfo.class)
                .as(satAdditionalInfoEncoder)
                .cache();
    }

}
