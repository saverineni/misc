package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import scala.collection.mutable.Seq;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;

@Data
@Builder
public class SatTrader implements Serializable, BaseEntity {

    private String hub_trader_key;
    private String sat_hash_diff;
    private String sat_load_datetime;
    private String sat_load_end_datetime;
    private String sat_record_source;
    private String name;
    private String simplified_procedure_authorisations;
    private String trader_name_abbreviated;
    private String current_ind;

    public static SatTrader mapper(String line) {
        List<String> columns = parseLine(line);

        return SatTrader.builder()
                .hub_trader_key(columns.get(0))
                .sat_hash_diff(columns.get(1))
                .sat_load_datetime(columns.get(2))
                .sat_load_end_datetime(columns.get(3))
                .sat_record_source(columns.get(4))
                .name(columns.get(5))
                .simplified_procedure_authorisations(columns.get(6))
                .trader_name_abbreviated(columns.get(7))
                .current_ind(columns.get(8))
                .build();
    }

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            "name",
            "simplified_procedure_authorisations",
            "trader_name_abbreviated",
            "current_ind"
    );

    public static Seq<String> selectColumns = joinExpression(SELECT_COLUMNS);
}
