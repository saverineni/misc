package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group;

import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLineOriginCountry;

import java.io.Serializable;
import java.util.Map;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLineOriginCountry.*;

@Data
@Builder
public class DeclarationLineOriginCountryGroup implements Serializable {

    public static Encoder<DeclarationLineOriginCountryGroup> declarationLineOriginCountryGroupEncoder = Encoders.bean(DeclarationLineOriginCountryGroup.class);

    private String hub_declaration_line_key;
    private DeclarationLineOriginCountry originCountry;

    public static DeclarationLineOriginCountryGroup mapper(DeclarationLineOriginCountryBuilderGroup declarationLineOriginCountryBuilderGroup, Map<String, String> countriesMap) {
        String origin_iso_country_code = declarationLineOriginCountryBuilderGroup.getOrigin_iso_country_code_alpha_2();
        String origin_country_name = origin_iso_country_code != null ? countriesMap.get(origin_iso_country_code) : origin_iso_country_code;

        final DeclarationLineOriginCountry declarationLineOriginCountry = DeclarationLineOriginCountry.builder()
                .iso_country_code_alpha_2(origin_iso_country_code).country_name(origin_country_name).build();

        return DeclarationLineOriginCountryGroup.builder()
                .hub_declaration_line_key(declarationLineOriginCountryBuilderGroup.getHub_declaration_line_key())
                .originCountry(declarationLineOriginCountry).build();
    }

}
