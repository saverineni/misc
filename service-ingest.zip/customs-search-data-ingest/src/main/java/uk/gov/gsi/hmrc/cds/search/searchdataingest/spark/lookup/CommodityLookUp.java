package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.lookup;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import scala.Tuple2;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubCommodity;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub.HubCommodityReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatCommodityReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.lookup.domain.Commodity;

@Component
public class CommodityLookUp {

    private static final String COMMODITIES_VIEW = "commodities";
    private static final String COMMODITIES_SQL = "select hub_commodity_key, chapter_description, heading_description, subheading_description from commodities";

    private final SparkSession sparkSession;
    private final HubCommodityReader hubCommodityReader;
    private final SatCommodityReader satCommodityReader;

    public CommodityLookUp(SparkSession sparkSession,HubCommodityReader hubCommodityReader,SatCommodityReader satCommodityReader){
        this.sparkSession = sparkSession;
        this.hubCommodityReader = hubCommodityReader;
        this.satCommodityReader = satCommodityReader;
    }

    public JavaPairRDD<String, Commodity> commodityMap() {
        Dataset hubCommodityDataset = hubCommodityReader.hubCommodityDataset();
        Dataset satCommodityDataset = satCommodityReader.satCommodityDataset();

        Dataset commodityDataset = hubCommodityDataset.join(satCommodityDataset, HubCommodity.joinColumns);
        commodityDataset.createOrReplaceTempView(COMMODITIES_VIEW);

        Dataset<Row> commodities = sparkSession.sql(COMMODITIES_SQL);
        commodities.show();

        return commodities.toJavaRDD()
                .map((Function<Row, Commodity>) Commodity::mapper)
                .mapToPair(commodity -> new Tuple2<>(commodity.getHub_commodity_key(), commodity))
                .cache();
    }

}
