package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubPreviousDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatPreviousDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationLinePreviousDocumentReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatPreviousDocumentReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLinePreviousDocument;

@Component
public class DeclarationLinePreviousDocumentDataset {
    private static final String DECLARATION_LINE_KEY = HubDeclarationLine.PRIMARY_COLUMN;
    private static String[] datasetColumns = Iterables.toArray(
            Iterables.concat(
                    Lists.newArrayList(HubPreviousDocument.PRIMARY_COLUMN),
                    HubPreviousDocument.SELECT_COLUMNS,
                    SatPreviousDocument.SELECT_COLUMNS
            )
            , String.class);

    private final SatPreviousDocumentReader satPreviousDocumentReader;
    private final LinkDeclarationLinePreviousDocumentReader linkDeclarationLinePreviousDocumentReader;

    @Autowired
    public DeclarationLinePreviousDocumentDataset(SatPreviousDocumentReader satPreviousDocumentReader,LinkDeclarationLinePreviousDocumentReader linkDeclarationLinePreviousDocumentReader) {
        this.satPreviousDocumentReader = satPreviousDocumentReader;
        this.linkDeclarationLinePreviousDocumentReader = linkDeclarationLinePreviousDocumentReader;
    }

    public Dataset<DeclarationLinePreviousDocument> build() {
        Dataset linkDeclarationLinePreviousDocumentDataset = linkDeclarationLinePreviousDocumentReader.linkDeclarationLinePreviousDocumentDataset();
        Dataset<SatPreviousDocument> satPreviousDocumentDataset = satPreviousDocumentReader.satPreviousDocumentDataset();
        Dataset<DeclarationLinePreviousDocument> declarationLinePreviousDocuments = linkDeclarationLinePreviousDocumentDataset
                .join(satPreviousDocumentDataset, HubPreviousDocument.joinColumns)
                .select(DECLARATION_LINE_KEY, datasetColumns)
                .as(DeclarationLinePreviousDocument.declarationLinePreviousDocumentEncoder)
                .cache();

        linkDeclarationLinePreviousDocumentDataset.unpersist();
        satPreviousDocumentDataset.unpersist();

        return declarationLinePreviousDocuments;
    }
}
