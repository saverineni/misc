package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationDeclarantTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.LINK_DECLARATION_DECLARANT_TRADER;

@Component
public class LinkDeclarationDeclarantTraderReader extends DataVaultReader {
    private static final Encoder<LinkDeclarationDeclarantTrader> linkDeclarationDeclarantTraderEncoder = Encoders.bean(LinkDeclarationDeclarantTrader.class);

    public Dataset<LinkDeclarationDeclarantTrader> linkDeclarationDeclarantTraderDataset() {
        String dataFilePath = String.format("%s/%s", LINK_DECLARATION_DECLARANT_TRADER.tableName(), datafileRelativePath);
        String linkDeclarationDeclarantTraderFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<LinkDeclarationDeclarantTrader> linkDeclarationDeclarantTraderJavaRDD = sparkSession
                .read()
                .textFile(linkDeclarationDeclarantTraderFilePath)
                .javaRDD()
                .map((Function<String, LinkDeclarationDeclarantTrader>) LinkDeclarationDeclarantTrader::mapper)
                .cache();

        return sparkSession
                .createDataFrame(linkDeclarationDeclarantTraderJavaRDD, LinkDeclarationDeclarantTrader.class)
                .as(linkDeclarationDeclarantTraderEncoder)
                .cache();
    }

}
