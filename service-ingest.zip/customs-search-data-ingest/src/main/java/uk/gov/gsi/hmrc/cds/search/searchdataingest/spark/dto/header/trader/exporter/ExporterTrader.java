package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.exporter;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;


@Data
public class ExporterTrader implements Serializable {
    public static Encoder<ExporterTrader> exporterTraderEncoder = Encoders.bean(ExporterTrader.class);
    private String exporter_trader_turn;
    private String name;
    private String simplified_procedure_authorisations;
    private String trader_name_abbreviated;
    private String current_ind;

    public static final String EXPORTER_TRADER_TURN = "exporter_trader_turn";

}
