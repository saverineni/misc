package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.header.group;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationFreightCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationInvoiceCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub.HubDeclarationReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationFreightCurrencyReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationInvoiceCurrencyReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.currency.DeclarationFreightCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.currency.DeclarationInvoiceCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group.DeclarationHeaderCurrencyGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group.DeclarationHeaderCurrencyGroupEnriched;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.lookup.CurrencyLookUp;

import java.util.Map;

@Component
public class DeclarationHeaderCurrencyGroupDataset {

    private static final String LEFT_OUTER_JOIN = "left_outer";
    private static String[] datasetColumns = Iterables.toArray(
            Iterables.concat(
                    Lists.newArrayList(
                            DeclarationInvoiceCurrency.INVOICE_CURRENCY_ISO_CODE,
                            DeclarationFreightCurrency.FREIGHT_CURRENCY_ISO_CODE
                    )
            )
            , String.class);

    private final HubDeclarationReader hubDeclarationReader;
    private final LinkDeclarationInvoiceCurrencyReader linkDeclarationInvoiceCurrencyReader;
    private final LinkDeclarationFreightCurrencyReader linkDeclarationFreightCurrencyReader;
    private final CurrencyLookUp currencyLookUp;

    @Autowired
    public DeclarationHeaderCurrencyGroupDataset(CurrencyLookUp currencyLookUp,HubDeclarationReader hubDeclarationReader,LinkDeclarationInvoiceCurrencyReader linkDeclarationInvoiceCurrencyReader,LinkDeclarationFreightCurrencyReader linkDeclarationFreightCurrencyReader){
        this.currencyLookUp = currencyLookUp;
        this.hubDeclarationReader = hubDeclarationReader;
        this.linkDeclarationFreightCurrencyReader = linkDeclarationFreightCurrencyReader;
        this.linkDeclarationInvoiceCurrencyReader = linkDeclarationInvoiceCurrencyReader;
    }

    public Dataset<DeclarationHeaderCurrencyGroupEnriched> build() {
        Dataset<HubDeclaration> hubDeclarationDataset = hubDeclarationReader.hubDeclarationDataset();
        Dataset<LinkDeclarationInvoiceCurrency> linkDeclarationInvoiceCurrencyDataset = linkDeclarationInvoiceCurrencyReader.linkDeclarationInvoiceCurrencyDataset();
        Dataset<LinkDeclarationFreightCurrency> linkDeclarationFreightCurrencyDataset = linkDeclarationFreightCurrencyReader.linkDeclarationFreightCurrencyDataset();

        Broadcast<Map<String, String>> currenciesBroadcast = currencyLookUp.currenciesMap();
        Map<String, String> currenciesMap = currenciesBroadcast.getValue();

        Dataset headerInvoiceCurrencyDataset = linkDeclarationInvoiceCurrencyDataset
                .select(
                        linkDeclarationInvoiceCurrencyDataset.col(HubDeclaration.PRIMARY_COLUMN),
                        linkDeclarationInvoiceCurrencyDataset.col(LinkDeclarationInvoiceCurrency.CURRENCY_ISO_CODE)
                ).withColumnRenamed(LinkDeclarationInvoiceCurrency.CURRENCY_ISO_CODE, DeclarationInvoiceCurrency.INVOICE_CURRENCY_ISO_CODE);

        Dataset headerFreightCurrencyDataset = linkDeclarationFreightCurrencyDataset
                .select(
                        linkDeclarationFreightCurrencyDataset.col(HubDeclaration.PRIMARY_COLUMN),
                        linkDeclarationFreightCurrencyDataset.col(LinkDeclarationFreightCurrency.CURRENCY_ISO_CODE)
                )
                .withColumnRenamed(LinkDeclarationFreightCurrency.CURRENCY_ISO_CODE, DeclarationFreightCurrency.FREIGHT_CURRENCY_ISO_CODE);

        Dataset<DeclarationHeaderCurrencyGroupEnriched> headerCurrencyGroupEnrichedDataset = hubDeclarationDataset
                .join(headerInvoiceCurrencyDataset, HubDeclaration.joinColumns, LEFT_OUTER_JOIN)
                .join(headerFreightCurrencyDataset, HubDeclaration.joinColumns, LEFT_OUTER_JOIN)
                .select(HubDeclaration.PRIMARY_COLUMN, datasetColumns)
                .as(DeclarationHeaderCurrencyGroup.declarationHeaderCurrencyGroupEncoder)
                .map((MapFunction<DeclarationHeaderCurrencyGroup, DeclarationHeaderCurrencyGroupEnriched>) value -> DeclarationHeaderCurrencyGroupEnriched.mapper(value, currenciesMap), DeclarationHeaderCurrencyGroupEnriched.headerCurrencyGroupEnrichedEncoder)
                .persist();

        headerInvoiceCurrencyDataset.unpersist();
        headerFreightCurrencyDataset.unpersist();
        linkDeclarationInvoiceCurrencyDataset.unpersist();
        linkDeclarationFreightCurrencyDataset.unpersist();

        currenciesBroadcast.destroy();

        return headerCurrencyGroupEnrichedDataset;
    }
}
