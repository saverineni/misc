package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineCommodity;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.LINK_DECLARATION_LINE_COMMODITY;

@Component
public class LinkDeclarationLineCommodityReader extends DataVaultReader {
    private static final Encoder<LinkDeclarationLineCommodity> linkDeclarationLineCommodityEncoder = Encoders.bean(LinkDeclarationLineCommodity.class);

    public Dataset linkDeclarationLineCommodityDataset() {
        String dataFilePath = String.format("%s/%s", LINK_DECLARATION_LINE_COMMODITY.tableName(), datafileRelativePath);
        String linkDeclarationLineCommodityFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<LinkDeclarationLineCommodity> linkDeclarationLineCommodityJavaRDD = sparkSession
                .read()
                .textFile(linkDeclarationLineCommodityFilePath)
                .javaRDD()
                .map((Function<String, LinkDeclarationLineCommodity>) LinkDeclarationLineCommodity::mapper)
                .cache();

        return sparkSession
                .createDataFrame(linkDeclarationLineCommodityJavaRDD, LinkDeclarationLineCommodity.class)
                .as(linkDeclarationLineCommodityEncoder)
                .cache();
    }

}
