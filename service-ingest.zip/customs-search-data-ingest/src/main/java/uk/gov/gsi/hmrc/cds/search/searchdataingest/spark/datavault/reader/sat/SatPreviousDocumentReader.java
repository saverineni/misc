package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatPreviousDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.SAT_PREVIOUS_DOCUMENT;

@Component
public class SatPreviousDocumentReader extends DataVaultReader {
    private static final Encoder<SatPreviousDocument> satPreviousDocumentEncoder = Encoders.bean(SatPreviousDocument.class);

    public Dataset<SatPreviousDocument> satPreviousDocumentDataset() {
        String dataFilePath = String.format("%s/%s", SAT_PREVIOUS_DOCUMENT.tableName(), datafileRelativePath);
        String satPreviousDocumentFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<SatPreviousDocument> satPreviousDocumentJavaRDD = sparkSession
                .read()
                .textFile(satPreviousDocumentFilePath)
                .javaRDD()
                .map((Function<String, SatPreviousDocument>) SatPreviousDocument::mapper)
                .cache();

        return sparkSession
                .createDataFrame(satPreviousDocumentJavaRDD, SatPreviousDocument.class)
                .as(satPreviousDocumentEncoder)
                .cache();
    }

}
