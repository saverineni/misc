package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineDeclaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.LINK_DECLARATION_LINE_DECLARATION;

@Component
public class LinkDeclarationLineDeclarationReader extends DataVaultReader {
    private static final Encoder<LinkDeclarationLineDeclaration> linkDeclarationLineDeclarationEncoder = Encoders.bean(LinkDeclarationLineDeclaration.class);

    public Dataset<LinkDeclarationLineDeclaration> linkDeclarationLineDeclarationDataset() {
        String dataFilePath = String.format("%s/%s", LINK_DECLARATION_LINE_DECLARATION.tableName(), datafileRelativePath);
        String linkDeclarationLineDeclarationFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<LinkDeclarationLineDeclaration> linkDeclarationLineDeclarationJavaRDD = sparkSession
                .read()
                .textFile(linkDeclarationLineDeclarationFilePath)
                .javaRDD()
                .map((Function<String, LinkDeclarationLineDeclaration>) LinkDeclarationLineDeclaration::mapper)
                .cache();

        return sparkSession
                .createDataFrame(linkDeclarationLineDeclarationJavaRDD, LinkDeclarationLineDeclaration.class)
                .as(linkDeclarationLineDeclarationEncoder)
                .cache();
    }

}
