package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubTaxLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.HUB_TAX_LINE;

@Component
public class HubTaxLineReader extends DataVaultReader {
    private static final Encoder<HubTaxLine> hubTaxLineEncoder = Encoders.bean(HubTaxLine.class);

    public Dataset hubTaxLineDataset() {
        String dataFilePath = String.format("%s/%s", HUB_TAX_LINE.tableName(), datafileRelativePath);
        String hubTaxLineFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<HubTaxLine> hubTaxLineJavaRDD = sparkSession
                .read()
                .textFile(hubTaxLineFilePath)
                .javaRDD()
                .map((Function<String, HubTaxLine>) HubTaxLine::mapper)
                .cache();

        return sparkSession
                .createDataFrame(hubTaxLineJavaRDD, HubTaxLine.class)
                .as(hubTaxLineEncoder)
                .cache();
    }

}
