package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.HUB_TRADER;

@Component
public class HubTraderReader extends DataVaultReader {
    private static final Encoder<HubTrader> hubTraderEncoder = Encoders.bean(HubTrader.class);

    public Dataset<HubTrader> hubTraderDataset() {
        String dataFilePath = String.format("%s/%s", HUB_TRADER.tableName(), datafileRelativePath);
        String hubTraderFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<HubTrader> hubTraderJavaRDD = sparkSession
                .read()
                .textFile(hubTraderFilePath)
                .javaRDD()
                .map((Function<String, HubTrader>) HubTrader::mapper)
                .cache();

        return sparkSession
                .createDataFrame(hubTraderJavaRDD, HubTrader.class)
                .as(hubTraderEncoder)
                .cache();
    }

}
