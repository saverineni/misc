package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;

@Data
public class DeclarationCustomsProcedureCode implements Serializable {

    public static final Encoder<DeclarationCustomsProcedureCodeGroup> declarationCustomsProcedureCodeEncoder = Encoders.bean(DeclarationCustomsProcedureCodeGroup.class);

    private String customs_procedure_code;

    public static final String ALIAS = "customsProcedureCode";

    @Data
    public static class DeclarationCustomsProcedureCodeGroup implements Serializable{
        private String hub_declaration_line_key;
        private DeclarationCustomsProcedureCode customsProcedureCode;
    }
}
