package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineAdditionalInfo;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationLineAdditionalInfoReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class LinkDeclarationLineAdditionalInfoReaderTest extends SparkTest {

    @Autowired
    LinkDeclarationLineAdditionalInfoReader linkDeclarationLineAdditionalInfoReader;

    @Test
    public void buildsLinkDeclarationLineAdditionalInfoDataset() throws Exception {
        final Dataset<LinkDeclarationLineAdditionalInfo> linkDeclarationLineAdditionalInfoDataset = linkDeclarationLineAdditionalInfoReader.linkDeclarationLineAdditionalInfoDataset();
        assertThat(linkDeclarationLineAdditionalInfoDataset.count(), is(greaterThan(0l)));

        linkDeclarationLineAdditionalInfoDataset.printSchema();
        final String[] fieldNames = linkDeclarationLineAdditionalInfoDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(linkDeclarationLineAdditionalInfoStructFields));

        final String[] selectedFieldNames = linkDeclarationLineAdditionalInfoDataset.select(LinkDeclarationLineAdditionalInfo.PRIMARY_COLUMN , joinExpression(LinkDeclarationLineAdditionalInfo.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(linkDeclarationLineAdditionalInfoSelectedStructFields));
    }

    private String[] linkDeclarationLineAdditionalInfoStructFields = toArray(
            Lists.newArrayList("additional_information_sequence_number",
                    "entry_reference",
                    "hub_additional_info_key",
                    "hub_declaration_line_key",
                    "item_number",
                    "link_declaration_line_additional_info_key",
                    "link_load_datetime",
                    "link_record_source")
    );

    private String[] linkDeclarationLineAdditionalInfoSelectedStructFields = toArray(
            Lists.newArrayList("link_declaration_line_additional_info_key",
                    "hub_additional_info_key",
                    "hub_declaration_line_key")
    );
}


