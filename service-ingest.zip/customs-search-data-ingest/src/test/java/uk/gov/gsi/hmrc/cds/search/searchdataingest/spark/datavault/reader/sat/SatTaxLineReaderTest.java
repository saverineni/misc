package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatTaxLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatTaxLineReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class SatTaxLineReaderTest extends SparkTest {

    @Autowired
    SatTaxLineReader satTaxLineReader;

    @Test
    public void buildsSatTaxLineDataset() throws Exception {
        final Dataset<SatTaxLine> satTaxLineDataset = satTaxLineReader.satTaxLineDataset();
        assertThat(satTaxLineDataset.count(), is(greaterThan(0l)));

        satTaxLineDataset.printSchema();
        final String[] fieldNames = satTaxLineDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(satTaxLineStructFields));

        // TODO - We need to assert selected columns for Sat Tax Line Reader later.

    }

    private String[] satTaxLineStructFields = toArray(
            Lists.newArrayList("generation_number",
                    "hub_tax_line_key",
                    "method_of_payment_code",
                    "sat_hash_diff",
                    "sat_load_datetime",
                    "sat_load_end_datetime",
                    "sat_record_source",
                    "tax_amount",
                    "tax_type_code",
                    "waived_tax")
    );

}
