package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatAdditionalInfo;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatAdditionalInfoReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class SatAdditionalInfoReaderTest extends SparkTest {

    @Autowired
    SatAdditionalInfoReader satAdditionalInfoReader;

    @Test
    public void buildsSatAdditionalInfoDataset() throws Exception {
        final Dataset<SatAdditionalInfo> satAdditionalInfoDataset = satAdditionalInfoReader.satAdditionalInfoDataset();
        assertThat(satAdditionalInfoDataset.count(), is(greaterThan(0l)));

        satAdditionalInfoDataset.printSchema();
        final String[] fieldNames = satAdditionalInfoDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(satAdditionalInfoStructFields));

        final String[] selectedFieldNames = satAdditionalInfoDataset.selectExpr(joinExpression(SatAdditionalInfo.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(satAdditionalInfoSelectedStructFields));
    }

    private String[] satAdditionalInfoStructFields = toArray(
            Lists.newArrayList("additional_information_statement",
                    "additional_information_statement_type",
                    "generation_number",
                    "hub_additional_info_key",
                    "item_additional_information_statement",
                    "sat_hash_diff",
                    "sat_load_datetime",
                    "sat_load_end_datetime",
                    "sat_record_source")
    );

    private String[] satAdditionalInfoSelectedStructFields = toArray(
            Lists.newArrayList("generation_number",
                    "additional_information_statement",
                    "additional_information_statement_type",
                    "item_additional_information_statement")
    );
}


