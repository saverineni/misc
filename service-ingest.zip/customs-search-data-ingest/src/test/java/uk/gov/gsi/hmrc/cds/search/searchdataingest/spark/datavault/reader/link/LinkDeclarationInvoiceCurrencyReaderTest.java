package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationInvoiceCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationInvoiceCurrencyReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class LinkDeclarationInvoiceCurrencyReaderTest extends SparkTest {

    @Autowired
    LinkDeclarationInvoiceCurrencyReader linkDeclarationInvoiceCurrencyReader;

    @Test
    public void buildsLinkDeclarationInvoiceCurrencyDataset() throws Exception {
        final Dataset<LinkDeclarationInvoiceCurrency> linkDeclarationInvoiceCurrencyDataset = linkDeclarationInvoiceCurrencyReader.linkDeclarationInvoiceCurrencyDataset();
        assertThat(linkDeclarationInvoiceCurrencyDataset.count(), is(greaterThan(0l)));

        linkDeclarationInvoiceCurrencyDataset.printSchema();
        final String[] fieldNames = linkDeclarationInvoiceCurrencyDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(linkDeclarationInvoiceCurrencyStructFields));

        final String[] selectedFieldNames = linkDeclarationInvoiceCurrencyDataset.select(LinkDeclarationInvoiceCurrency.PRIMARY_COLUMN , joinExpression(LinkDeclarationInvoiceCurrency.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(linkDeclarationInvoiceCurrencySelectedStructFields));
    }

    private String[] linkDeclarationInvoiceCurrencyStructFields = toArray(
            Lists.newArrayList("currency_iso_code",
                    "entry_reference",
                    "hub_currency_key",
                    "hub_declaration_key",
                    "link_declaration_invoice_currency_key",
                    "link_load_datetime",
                    "link_record_source")
    );

    private String[] linkDeclarationInvoiceCurrencySelectedStructFields = toArray(
            Lists.newArrayList("link_declaration_invoice_currency_key",
                    "hub_declaration_key",
                    "hub_currency_key")
    );
}


