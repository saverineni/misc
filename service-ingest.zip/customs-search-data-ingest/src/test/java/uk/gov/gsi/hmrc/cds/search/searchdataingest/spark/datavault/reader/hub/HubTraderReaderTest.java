package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub.HubTraderReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;

public class HubTraderReaderTest extends SparkTest {

    @Autowired
    HubTraderReader hubTraderReader;

    @Test
    public void buildsHubTraderDataset() throws Exception {
        final Dataset<HubTrader> hubTraderDataset = hubTraderReader.hubTraderDataset();
        assertThat(hubTraderDataset.count(), is(greaterThan(0l)));

        hubTraderDataset.printSchema();
        final String[] fieldNames = hubTraderDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(hubTraderStructFields));

        final String[] selectedFieldNames = hubTraderDataset.select(HubTrader.PRIMARY_COLUMN , joinExpression(HubTrader.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(hubTraderSelectedStructFields));
    }

    private static String[] hubTraderStructFields = toArray(
            Lists.newArrayList("hub_load_datetime",
                    "hub_record_source",
                    "hub_trader_key",
                    "turn")
    );

    private static String[] hubTraderSelectedStructFields = toArray(
            Lists.newArrayList("hub_trader_key",
                    "turn")
    );
}

