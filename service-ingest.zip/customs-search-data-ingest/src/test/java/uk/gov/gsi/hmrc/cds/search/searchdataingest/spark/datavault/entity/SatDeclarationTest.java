package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity;

import org.junit.Ignore;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatDeclaration;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class SatDeclarationTest {

    @Test
    @Ignore
    public void name() throws Exception {
        List<String> collect = Arrays.stream(SatDeclaration.class.getFields()).map(Field::getName).collect(Collectors.toList());
        collect.size();
    }
}