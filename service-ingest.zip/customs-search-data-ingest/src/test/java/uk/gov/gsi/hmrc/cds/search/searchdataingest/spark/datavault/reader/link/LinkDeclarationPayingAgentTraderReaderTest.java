package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationPayingAgentTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationPayingAgentTraderReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class LinkDeclarationPayingAgentTraderReaderTest extends SparkTest {

    @Autowired
    LinkDeclarationPayingAgentTraderReader linkDeclarationPayingAgentTraderReader;

    @Test
    public void buildsLinkDeclarationPayingAgentTraderDataset() throws Exception {
        final Dataset<LinkDeclarationPayingAgentTrader> linkDeclarationPayingAgentTraderDataset = linkDeclarationPayingAgentTraderReader.linkDeclarationPayingAgentTraderDataset();
        assertThat(linkDeclarationPayingAgentTraderDataset.count(), is(greaterThan(0l)));

        linkDeclarationPayingAgentTraderDataset.printSchema();
        final String[] fieldNames = linkDeclarationPayingAgentTraderDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(linkDeclarationPayingAgentTraderStructFields));

        final String[] selectedFieldNames = linkDeclarationPayingAgentTraderDataset.select(LinkDeclarationPayingAgentTrader.PRIMARY_COLUMN , joinExpression(LinkDeclarationPayingAgentTrader.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(linkDeclarationPayingAgentTraderSelectedStructFields));
    }

    private String[] linkDeclarationPayingAgentTraderStructFields = toArray(
            Lists.newArrayList("entry_reference",
                    "hub_declaration_key",
                    "hub_trader_key",
                    "link_declaration_paying_agent_trader_key",
                    "link_load_datetime",
                    "link_record_source",
                    "turn")
    );

    private String[] linkDeclarationPayingAgentTraderSelectedStructFields = toArray(
            Lists.newArrayList("link_declaration_paying_agent_trader_key",
                    "hub_trader_key",
                    "hub_declaration_key")
    );
}



