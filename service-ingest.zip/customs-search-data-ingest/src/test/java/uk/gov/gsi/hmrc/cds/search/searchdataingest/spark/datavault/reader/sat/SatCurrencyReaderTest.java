package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatCurrencyReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class SatCurrencyReaderTest extends SparkTest {

    @Autowired
    SatCurrencyReader satCurrencyReader;

    @Test
    public void buildsSatCurrencyDataset() throws Exception {
        final Dataset<SatCurrency> satCurrencyDataset = satCurrencyReader.satCurrencyDataset();
        assertThat(satCurrencyDataset.count(), is(greaterThan(0l)));

        satCurrencyDataset.printSchema();
        final String[] fieldNames = satCurrencyDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(satCurrencyStructFields));

        final String[] selectedFieldNames = satCurrencyDataset.selectExpr(joinExpression(SatCurrency.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(satCurrencySelectedStructFields));
    }

    private String[] satCurrencyStructFields = toArray(
            Lists.newArrayList("currency_name",
                    "hub_currency_key",
                    "sat_hash_diff",
                    "sat_load_datetime",
                    "sat_load_end_datetime",
                    "sat_record_source")
    );

    private String[] satCurrencySelectedStructFields = toArray(
            Lists.newArrayList("currency_name")
    );
}

