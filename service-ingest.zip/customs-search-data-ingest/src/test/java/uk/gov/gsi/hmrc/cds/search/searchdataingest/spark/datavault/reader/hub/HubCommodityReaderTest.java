package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubCommodity;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub.HubCommodityReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class HubCommodityReaderTest extends SparkTest {

    @Autowired
    HubCommodityReader hubCommodityReader;

    @Test
    public void buildsHubCommodityDataset() throws Exception {
        final Dataset<HubCommodity> hubCommodityDataset = hubCommodityReader.hubCommodityDataset();
        assertThat(hubCommodityDataset.count(), is(greaterThan(0l)));

        hubCommodityDataset.printSchema();
        final String[] fieldNames = hubCommodityDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(hubCommodityStructFields));

        final String[] selectedFieldNames = hubCommodityDataset.select(HubCommodity.PRIMARY_COLUMN , joinExpression(HubCommodity.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(hubCommoditySelectedStructFields));
    }

    private static String[] hubCommodityStructFields = toArray(
            Lists.newArrayList(
                    "commodity_code",
                    "hub_commodity_key",
                    "hub_load_datetime",
                    "hub_record_source")
    );

    private static String[] hubCommoditySelectedStructFields = toArray(
            Lists.newArrayList("hub_commodity_key",
                    "commodity_code")
    );
}
