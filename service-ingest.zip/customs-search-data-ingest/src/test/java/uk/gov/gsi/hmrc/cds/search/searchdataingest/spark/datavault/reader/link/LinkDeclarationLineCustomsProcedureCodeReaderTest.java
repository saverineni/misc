package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineCustomsProcedureCode;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationLineCustomsProcedureCodeReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class LinkDeclarationLineCustomsProcedureCodeReaderTest extends SparkTest {

    @Autowired
    LinkDeclarationLineCustomsProcedureCodeReader linkDeclarationLineCustomsProcedureCodeReader;

    @Test
    public void buildsLinkDeclarationLineCustomsProcedureCodeDataset() throws Exception {
        final Dataset<LinkDeclarationLineCustomsProcedureCode> linkDeclarationLineCustomsProcedureCodeDataset = linkDeclarationLineCustomsProcedureCodeReader.linkDeclarationLineCustomsProcedureCodeDataset();
        assertThat(linkDeclarationLineCustomsProcedureCodeDataset.count(), is(greaterThan(0l)));

        linkDeclarationLineCustomsProcedureCodeDataset.printSchema();
        final String[] fieldNames = linkDeclarationLineCustomsProcedureCodeDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(linkDeclarationLineCustomsProcedureCodeStructFields));

        final String[] selectedFieldNames = linkDeclarationLineCustomsProcedureCodeDataset.select(LinkDeclarationLineCustomsProcedureCode.PRIMARY_COLUMN , joinExpression(LinkDeclarationLineCustomsProcedureCode.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(linkDeclarationLineCustomsProcedureCodeSelectedStructFields));
    }

    private String[] linkDeclarationLineCustomsProcedureCodeStructFields = toArray(
            Lists.newArrayList("customs_procedure_code",
                    "entry_reference",
                    "hub_customs_procedure_code_key",
                    "hub_declaration_line_key",
                    "item_number",
                    "link_declaration_line_customs_procedure_code_key",
                    "link_load_datetime",
                    "link_record_source")
    );

    private String[] linkDeclarationLineCustomsProcedureCodeSelectedStructFields = toArray(
            Lists.newArrayList("link_declaration_line_customs_procedure_code_key",
                    "hub_customs_procedure_code_key",
                    "hub_declaration_line_key")
    );
}




