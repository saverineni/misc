package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatPreviousDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatPreviousDocumentReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class SatPreviousDocumentReaderTest extends SparkTest {

    @Autowired
    SatPreviousDocumentReader satPreviousDocumentReader;

    @Test
    public void buildsSatPreviousDocumentDataset() throws Exception {
        final Dataset<SatPreviousDocument> satPreviousDocumentDataset = satPreviousDocumentReader.satPreviousDocumentDataset();
        assertThat(satPreviousDocumentDataset.count(), is(greaterThan(0l)));

        satPreviousDocumentDataset.printSchema();
        final String[] fieldNames = satPreviousDocumentDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(satPreviousDocumentStructFields));

        final String[] selectedFieldNames = satPreviousDocumentDataset.selectExpr(joinExpression(SatPreviousDocument.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(satPreviousDocumentSelectedStructFields));
    }

    private String[] satPreviousDocumentStructFields = toArray(
            Lists.newArrayList("hub_previous_document_key",
                    "previous_document_reference",
                    "sat_hash_diff",
                    "sat_load_datetime",
                    "sat_load_end_datetime",
                    "sat_record_source")
    );

    private String[] satPreviousDocumentSelectedStructFields = toArray(
            Lists.newArrayList("previous_document_reference")
    );
}




