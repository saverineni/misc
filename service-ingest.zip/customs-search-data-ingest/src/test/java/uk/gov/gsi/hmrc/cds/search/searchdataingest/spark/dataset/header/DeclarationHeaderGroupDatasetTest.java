package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.header;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.DeclarationStructure;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.TestConstants;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.header.group.DeclarationHeaderGroupDataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.country.DeclarationCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.currency.DeclarationCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group.DeclarationHeaderGroup;

import java.util.Arrays;

import static org.apache.spark.sql.functions.column;
import static org.apache.spark.sql.functions.not;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertEquals;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.TestConstants.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;


public class DeclarationHeaderGroupDatasetTest extends SparkTest implements DeclarationStructure {

    private static final boolean TRUE = true;
    private static final String DECLARATION_CURRENCY_FIELD_NAME = "declarationCurrency";
    private static final String DECLARATION_COUNTRY_FIELD_NAME = "declarationCountry";
    private static final String DECLARATION_TRADER_FIELD_NAME = "declarationTrader";


    private Dataset<DeclarationHeaderGroup> dataset;

    @Autowired
    private DeclarationHeaderGroupDataset declarationHeaderGroupDataset;

    @Before
    public void build() {
        dataset = declarationHeaderGroupDataset.build();
    }

    @After
    public void cleanup() {
        dataset.unpersist();
    }

    @Test
    public void validateDeclarationHeaderGroupFields() {
        final String[] fieldNames = dataset.schema().fieldNames();

        assertThat(Arrays.asList(fieldNames), contains(declarationHeaderGroupStructFields));
        assertThat(dataset.count(), is(equalTo(TestConstants.DECLARATION_HEADER_COUNT)));
    }

    @Test
    public void validateDeclarationHeaderCurrencyGroupStructure() {
        final StructField currencyStructFieldType = dataset.schema().apply(DeclarationCurrency.DECLARATION_CURRENCY_COLUMN);

        // validate the currency counts
        assertEquals(dataset
                .filter(not(column(DECLARATION_FREIGHT_CURRENCY_FIELD_NAME).equalTo(NULL_ESCAPE)))
                .select(DECLARATION_FREIGHT_CURRENCY_FIELD_NAME).count(),FREIGHT_CURRENCY_COUNT);

        assertEquals(dataset
                .filter(not(column(DECLARATION_INVOICE_CURRENCY_FIELD_NAME).equalTo(NULL_ESCAPE)))
                .select(DECLARATION_INVOICE_CURRENCY_FIELD_NAME).count(),INVOICE_CURRENCY_COUNT);

        assertEquals(new StructField(DECLARATION_CURRENCY_FIELD_NAME, DataTypes.createStructType(declarationHeaderCurrencyGroupStructType()), TRUE,
                Metadata.empty()), currencyStructFieldType);

    }

    @Test
    public void validateDeclarationHeaderCountryGroupStructure() {
        final StructField countryStructFieldType = dataset.schema().apply(DeclarationCountry.DECLARATION_COUNTRY_COLUMN);

        // validate the country counts
        assertEquals(dataset
                .filter(not(column(DECLARATION_DESTINATION_COUNTRY_FIELD_NAME).equalTo(NULL_ESCAPE)))
                .select(DECLARATION_DESTINATION_COUNTRY_FIELD_NAME).count(),DESTINATION_COUNTRY_COUNT);

        assertEquals(dataset
                .filter(not(column(DECLARATION_TRANSPORT_COUNTRY_FIELD_NAME).equalTo(NULL_ESCAPE)))
                .select(DECLARATION_TRANSPORT_COUNTRY_FIELD_NAME).count(),TRANSPORT_COUNTRY_COUNT);

        assertEquals(new StructField(DECLARATION_COUNTRY_FIELD_NAME, DataTypes.createStructType(declarationHeaderCountryGroupStructType()), TRUE,
                Metadata.empty()), countryStructFieldType);

    }

    @Test
    public void validateDeclarationHeaderTraderGroupStructure() {
        final StructField traderStructFieldType = dataset.schema().apply(DECLARATION_TRADER_FIELD_NAME);

        assertEquals(new StructField(DECLARATION_TRADER_FIELD_NAME, DataTypes.createStructType(declarationHeaderTraderGroupStructType()), TRUE,
                Metadata.empty()), traderStructFieldType);

        // validate the trader counts
        assertEquals(dataset
                .filter(not(column(DECLARATION_CONSIGNOR_TRADER_FIELD_NAME).equalTo(NULL_ESCAPE)))
                .select(DECLARATION_CONSIGNOR_TRADER_FIELD_NAME).count(),CONSIGNOR_TRADER_COUNT);

        assertEquals(dataset
                .filter(not(column(DECLARATION_DECLARANT_TRADER_FIELD_NAME).equalTo(NULL_ESCAPE)))
                .select(DECLARATION_DECLARANT_TRADER_FIELD_NAME).count(),DECLARANT_TRADER_COUNT);

        assertEquals(dataset
                .filter(not(column(DECLARATION_EXPORTER_TRADER_FIELD_NAME).equalTo(NULL_ESCAPE)))
                .select(DECLARATION_EXPORTER_TRADER_FIELD_NAME).count(),EXPORTER_TRADER_COUNT);

        assertEquals(dataset
                .filter(not(column(DECLARATION_IMPORTER_TRADER_FIELD_NAME).equalTo(NULL_ESCAPE)))
                .select(DECLARATION_IMPORTER_TRADER_FIELD_NAME).count(),IMPORTER_TRADER_COUNT);

        assertEquals(dataset
                .filter(not(column(DECLARATION_PAYING_AGENT_TRADER_FIELD_NAME).equalTo(NULL_ESCAPE)))
                .select(DECLARATION_PAYING_AGENT_TRADER_FIELD_NAME).count(),PAYING_AGENT_TRADER_COUNT);

    }

    private static String[] declarationHeaderGroupStructFields = toArray(
            Lists.newArrayList(
                    "hub_declaration_key",
                    "declarationCurrency",
                    "declarationCountry",
                    "declarationTrader")
    );


}
