package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineCommodity;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationLineCommodityReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class LinkDeclarationLineCommodityReaderTest extends SparkTest {

    @Autowired
    LinkDeclarationLineCommodityReader linkDeclarationLineCommodityReader;

    @Test
    public void buildsLinkDeclarationLineCommodityDataset() throws Exception {
        final Dataset<LinkDeclarationLineCommodity> linkDeclarationLineCommodityDataset = linkDeclarationLineCommodityReader.linkDeclarationLineCommodityDataset();
        assertThat(linkDeclarationLineCommodityDataset.count(), is(greaterThan(0l)));

        linkDeclarationLineCommodityDataset.printSchema();
        final String[] fieldNames = linkDeclarationLineCommodityDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(linkDeclarationLineCommodityStructFields));

        final String[] selectedFieldNames = linkDeclarationLineCommodityDataset.select(LinkDeclarationLineCommodity.PRIMARY_COLUMN , joinExpression(LinkDeclarationLineCommodity.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(linkDeclarationLineCommoditySelectedStructFields));
    }

    private String[] linkDeclarationLineCommodityStructFields = toArray(
            Lists.newArrayList("commodity_code",
                    "entry_reference",
                    "hub_commodity_key",
                    "hub_declaration_line_key",
                    "item_number",
                    "link_declaration_line_commodity_key",
                    "link_load_datetime",
                    "link_record_source")
    );

    private String[] linkDeclarationLineCommoditySelectedStructFields = toArray(
            Lists.newArrayList("link_declaration_line_commodity_key",
                    "hub_commodity_key",
                    "hub_declaration_line_key")
    );
}



