package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub.HubCountryReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class HubCountryReaderTest extends SparkTest {

    @Autowired
    HubCountryReader hubCountryReader;

    @Test
    public void buildsHubCountryDataset() throws Exception {
        final Dataset<HubCountry> hubCountryDataset = hubCountryReader.hubCountryDataset();
        assertThat(hubCountryDataset.count(), is(greaterThan(0l)));

        hubCountryDataset.printSchema();
        final String[] fieldNames = hubCountryDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(hubCountryStructFields));

        final String[] selectedFieldNames = hubCountryDataset.select(HubCountry.PRIMARY_COLUMN , joinExpression(HubCountry.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(hubCountrySelectedStructFields));
    }

    private static String[] hubCountryStructFields = toArray(
            Lists.newArrayList("hub_country_key",
                    "hub_load_datetime",
                    "hub_record_source",
                    "iso_country_code_alpha_2")
    );

    private static String[] hubCountrySelectedStructFields = toArray(
            Lists.newArrayList("hub_country_key",
                    "hub_country_key",
                    "iso_country_code_alpha_2")
    );
}

