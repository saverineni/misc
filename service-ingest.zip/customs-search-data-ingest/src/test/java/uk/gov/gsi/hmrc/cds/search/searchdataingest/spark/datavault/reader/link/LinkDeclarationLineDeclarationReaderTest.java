package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineDeclaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationLineDeclarationReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class LinkDeclarationLineDeclarationReaderTest extends SparkTest {

    @Autowired
    LinkDeclarationLineDeclarationReader linkDeclarationLineDeclarationReader;

    @Test
    public void buildsLinkDeclarationLineDeclarationDataset() throws Exception {
        final Dataset<LinkDeclarationLineDeclaration> linkDeclarationLineDeclarationDataset = linkDeclarationLineDeclarationReader.linkDeclarationLineDeclarationDataset();
        assertThat(linkDeclarationLineDeclarationDataset.count(), is(greaterThan(0l)));

        linkDeclarationLineDeclarationDataset.printSchema();
        final String[] fieldNames = linkDeclarationLineDeclarationDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(linkDeclarationLineDeclarationStructFields));

        final String[] selectedFieldNames = linkDeclarationLineDeclarationDataset.select(LinkDeclarationLineDeclaration.PRIMARY_COLUMN , joinExpression(LinkDeclarationLineDeclaration.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(linkDeclarationLineDeclarationSelectedStructFields));
    }

    private String[] linkDeclarationLineDeclarationStructFields = toArray(
            Lists.newArrayList("entry_reference",
                    "hub_declaration_key",
                    "hub_declaration_line_key",
                    "item_number",
                    "link_declaration_line_declaration_key",
                    "link_load_datetime",
                    "link_record_source")
    );

    private String[] linkDeclarationLineDeclarationSelectedStructFields = toArray(
            Lists.newArrayList("link_declaration_line_declaration_key",
                    "hub_declaration_line_key",
                    "hub_declaration_key")
    );
}

