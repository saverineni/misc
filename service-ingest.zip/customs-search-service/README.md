## Pre-requisite: [VM Docker setup](http://10.102.81.196:8090/display/CDS/Docker+setup+to+pull+image+from+Artifactory)
## Pre-requisite: [Make sure you have a valid docker instance with name es-6 is running locally. You can download the docker es image from the artifactory]

### Build:
> Build docker image from fat jar
    
    mvn clean install

### Access application in docker container
> No basic auth (default profile)

    docker run -d -p 8000:8000 --name search --link es-6:eshost artifactory.dataengineering.apps.hmrci:8001/customs-search-service:1.0.0-SNAPSHOT

> Basic auth enabled (localsecurity profile)

    docker run -d -p 8000:8000 --name search --link es-6:eshost -e "spring.profiles.active=localsecurity" --add-host IRD60016.userdomain01.domroot.internal:10.21.194.23 artifactory.dataengineering.apps.hmrci:8001/customs-search-service:1.0.0-SNAPSHOT

### Application resources:
> ##### API Documentation
>* http://localhost:8000/api/application.doc

> ##### Application health
>* http://localhost:8000/health

> ##### Elasticsearch Endpoint:
>* http://localhost:9200/customs/declaration/_search?q=_id:670-954107X-2017-08-22