package uk.gov.gsi.hmrc.cds.search.run;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.AliasCreationService;

import javax.annotation.PostConstruct;

@SpringBootApplication(
		scanBasePackages = {
				"uk.gov.gsi.hmrc.cds.search.config",
				"uk.gov.gsi.hmrc.cds.search.security",
				"uk.gov.gsi.hmrc.cds.search.common.jersey.providers",
				"uk.gov.gsi.hmrc.cds.search.api.resources",
				"uk.gov.gsi.hmrc.cds.search.api.services",
				"uk.gov.gsi.hmrc.cds.search.elasticsearch.connection",
				"uk.gov.gsi.hmrc.cds.search.elasticsearch.service"
		}
)
public class CustomsSearchServiceApplication extends SpringBootServletInitializer {

	@Autowired
	private AliasCreationService aliasCreationService;

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		return builder.sources(CustomsSearchServiceApplication.class);
	}

	public static void main(String[] args) {
		SpringApplication.run(CustomsSearchServiceApplication.class, args);
	}

	@PostConstruct
	public void createAlias() {
		aliasCreationService.createAlias();
	}

}
