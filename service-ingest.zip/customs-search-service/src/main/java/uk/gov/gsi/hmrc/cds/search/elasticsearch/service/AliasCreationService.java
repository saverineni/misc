package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.Header;
import org.apache.http.HttpStatus;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicHeader;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.connection.ESConnection;

import javax.json.Json;
import javax.json.JsonObject;
import java.io.IOException;
import java.util.Collections;

import static javax.ws.rs.HttpMethod.POST;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static org.apache.http.HttpHeaders.CONTENT_TYPE;
import static org.elasticsearch.action.admin.indices.alias.IndicesAliasesRequest.AliasActions.Type.ADD;

@Slf4j
@Service
public class AliasCreationService {

    private static final String ALIASES_ENDPOINT = "/_aliases";

    @Autowired
    private ESConnection connection;

    @Value("${elasticsearch.alias}")
    private String elasticSearchAlias;

    @Value("${elasticsearch.index}")
    private String elasticSearchIndex;


    public void createAlias() {

        try (RestHighLevelClient client = connection.getRestClientInstance()) {
            StringEntity entity = getRequestEntity();
            Header header = new BasicHeader(CONTENT_TYPE, APPLICATION_JSON);
            Response response = client.getLowLevelClient().performRequest(POST, ALIASES_ENDPOINT, Collections.emptyMap(), entity, header);
            if ((HttpStatus.SC_OK == response.getStatusLine().getStatusCode())) {
                log.info(String.format("Created elasticsearch alias:%s", elasticSearchAlias));
            }
        } catch (IOException e) {
            log.error(String.format("Exception occurred: %s", e));
        }

    }

    private StringEntity getRequestEntity() {
        JsonObject requestEntity = Json.createObjectBuilder()
                                            .add("actions", Json.createArrayBuilder().add(Json.createObjectBuilder()
                                                                .add(ADD.name().toLowerCase(), Json.createObjectBuilder().add("index", elasticSearchIndex).add("alias",                                                                                                             elasticSearchAlias)).build()).build())
                                            .build();
        return new StringEntity(requestEntity.toString(), ContentType.APPLICATION_JSON);
    }
}
