package uk.gov.gsi.hmrc.cds.search.common.exception;

public class DeclarationNotFoundException extends RuntimeException {

    public DeclarationNotFoundException() {
        super();
    }

    public DeclarationNotFoundException(String message) {
        super(message);
    }

    public DeclarationNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
