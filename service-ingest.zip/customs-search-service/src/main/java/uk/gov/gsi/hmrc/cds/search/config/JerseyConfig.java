package uk.gov.gsi.hmrc.cds.search.config;

import com.google.common.collect.ImmutableList;
import org.glassfish.jersey.filter.LoggingFilter;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.wadl.internal.WadlResource;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.resources.DocumentationResource;
import uk.gov.gsi.hmrc.cds.search.common.jersey.providers.exceptionmappers.DeclarationNotFoundExceptionMapper;
import uk.gov.gsi.hmrc.cds.search.common.jersey.providers.exceptionmappers.IllegalArgumentExceptionMapper;
import uk.gov.gsi.hmrc.cds.search.common.jersey.providers.exceptionmappers.RuntimeExceptionMapper;
import uk.gov.gsi.hmrc.cds.search.common.jersey.providers.writers.v1.DeclarationMessageBodyWriter;
import uk.gov.gsi.hmrc.cds.search.common.jersey.wadl.ExtendedWadlGeneratorConfig;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.ext.MessageBodyReader;
import javax.ws.rs.ext.MessageBodyWriter;
import java.util.List;

import static org.glassfish.jersey.server.ServerProperties.WADL_GENERATOR_CONFIG;

@Component
@ApplicationPath("${spring.jersey.application-path:/api}")
public class JerseyConfig extends ResourceConfig {

    private static final String DOCUMENTATION_APPLICATION_DOC_XML_PATH = "documentation/applicationDoc.xml";
    private static final String DOCUMENTATION_RESOURCE_DOC_XML_PATH = "documentation/resourceDoc.xml";

    public JerseyConfig() {
        this.registerProviders();
        this.registerEndpoints();
        this.registerExceptionMappers();
        this.extendedWadlGeneratorConfig();
        this.register(LoggingFilter.class);
    }

    private void registerEndpoints() {
        this.packages("uk.gov.gsi.hmrc.cds.search.api.resources");

        // Access through /<Jersey's servlet path>/application.wadl
        this.register(WadlResource.class);
        this.register(DocumentationResource.class);
    }

    private void registerProviders() {
        this.packages("uk.gov.gsi.hmrc.cds.search.common.jersey.providers");
    }

    private void registerExceptionMappers() {
        this.register(DeclarationNotFoundExceptionMapper.class);
        this.register(IllegalArgumentExceptionMapper.class);
        this.register(RuntimeExceptionMapper.class);
    }

    private void extendedWadlGeneratorConfig() {
        this.property(WADL_GENERATOR_CONFIG, new ExtendedWadlGeneratorConfig(
                DOCUMENTATION_APPLICATION_DOC_XML_PATH,
                DOCUMENTATION_RESOURCE_DOC_XML_PATH,
                getMessageBodyWriters(),
                getMessageBodyReaders())
        );
    }

    private List<Class<? extends MessageBodyWriter>> getMessageBodyWriters() {
        return ImmutableList.of(
                DeclarationMessageBodyWriter.class
        );
    }

    private List<Class<? extends MessageBodyReader>> getMessageBodyReaders() {
        return ImmutableList.of(
        );
    }
}
