package uk.gov.gsi.hmrc.cds.search.common.jersey.wadl;

import org.glassfish.jersey.server.wadl.config.WadlGeneratorConfig;
import org.glassfish.jersey.server.wadl.internal.generators.WadlGeneratorApplicationDoc;

import javax.ws.rs.ext.MessageBodyReader;
import javax.ws.rs.ext.MessageBodyWriter;
import java.util.List;

/**
 * Wadl generator config that allows the location of the applicationDoc.xml file and the resourceDoc.xml file to be specified.
 *
 * In addition it allows a list of {@link javax.ws.rs.ext.MessageBodyWriter}s to be specified which will add a schema definition
 * to each response.
 */
public class ExtendedWadlGeneratorConfig extends WadlGeneratorConfig {

    private String applicationDocUri;
    private String resourceDocUri;
    private List<Class<? extends MessageBodyWriter>> writers;
    private List<Class<? extends MessageBodyReader>> readers;

    public ExtendedWadlGeneratorConfig(String applicationDocUri, String resourceDocUri, List<Class<? extends MessageBodyWriter>> writers, List<Class<? extends MessageBodyReader>> readers) {
        this.applicationDocUri = applicationDocUri;
        this.resourceDocUri = resourceDocUri;
        this.writers = writers;
        this.readers = readers;
    }

    @Override
    public List configure() {
        return generator(WadlGeneratorApplicationDoc.class)
                    .prop("applicationDocsStream", applicationDocUri)
                .generator(ExtendedWadlGeneratorResourceDocSupport.class)
                    .prop("resourceDocStream", resourceDocUri)
                    .prop("vendorWriters", writers)
                    .prop("readers", readers)
                .descriptions();
    }
}
