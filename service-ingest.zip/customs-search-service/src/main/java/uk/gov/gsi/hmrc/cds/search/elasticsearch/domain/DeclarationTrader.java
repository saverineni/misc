package uk.gov.gsi.hmrc.cds.search.elasticsearch.domain;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;


@Data
@Builder
public class DeclarationTrader implements Serializable {

    private ImporterTrader importerTrader;

}
