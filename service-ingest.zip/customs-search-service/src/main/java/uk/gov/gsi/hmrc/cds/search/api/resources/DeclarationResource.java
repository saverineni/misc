package uk.gov.gsi.hmrc.cds.search.api.resources;

import com.google.common.base.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationResponse;
import uk.gov.gsi.hmrc.cds.search.api.services.SearchOrchestratorService;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

/**
 * Declaration Resource
 */
@Component
@Path("declaration")
public class DeclarationResource {

    protected static final String V1_DECLARATION_MEDIA_TYPE = "application/vnd.hmrc.cds.v1.declaration+json";

    @Autowired
    SearchOrchestratorService searchOrchestratorService;

    /**
     * Get declaration for given declarationId
     *
     * @response.representation.200.doc The request for the message succeeded
     * @response.representation.200.mediaType application/vnd.hmrc.cds.v1.declaration+json
     * @response.representation.404.doc The declaration not found
     * @response.representation.404.mediaType application/json
     * @response.representation.400.doc  The submitted request is invalid.
     * @response.representation.400.mediaType application/json
     * @response.representation.500.doc  Internal Server error occurred.
     * @response.representation.500.mediaType application/json
     *
     * @param declarationId DeclarationId
     * @return declaration data
     */
    @GET
    @Produces({
            V1_DECLARATION_MEDIA_TYPE
    })
    public Response getDeclarationData(@QueryParam("declarationId") String declarationId) {
        if (Strings.isNullOrEmpty ( declarationId )) {
            throw new IllegalArgumentException ( "declarationId is mandatory" );
        }
        DeclarationResponse declarationResponse = searchOrchestratorService.fetchDeclarationById ( declarationId );
        return Response.status ( Response.Status.OK ).entity ( declarationResponse).build ();
    }

}