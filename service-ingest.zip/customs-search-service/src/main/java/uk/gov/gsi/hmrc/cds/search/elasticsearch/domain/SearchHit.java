package uk.gov.gsi.hmrc.cds.search.elasticsearch.domain;


public class SearchHit {
    private float score;

    private Declaration declaration;

    public float getScore() {
        return score;
    }

    public void setScore(float score) {
        this.score = score;
    }

    public Declaration getDeclaration() {
        return declaration;
    }

    public void setDeclaration(Declaration declaration) {
        this.declaration = declaration;
    }
}
