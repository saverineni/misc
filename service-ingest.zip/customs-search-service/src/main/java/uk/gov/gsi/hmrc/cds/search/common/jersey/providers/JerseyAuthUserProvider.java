package uk.gov.gsi.hmrc.cds.search.common.jersey.providers;

import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.ext.Provider;
import java.io.IOException;
import java.security.Principal;

@Provider
@Slf4j
public class JerseyAuthUserProvider implements ContainerRequestFilter , ContainerResponseFilter{

    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {

        // We can get the principal details through different ways

        if(requestContext.getSecurityContext() != null){
            Principal principal = null;
            if((principal = requestContext.getSecurityContext().getUserPrincipal()) != null){
                log.info(String.format("Principal: %s" , principal.getName()));

            }
        }

        if(SecurityContextHolder.getContext().getAuthentication() != null) {
            Object securityPrincipal = null;
            if((securityPrincipal = SecurityContextHolder.getContext().getAuthentication().getPrincipal()) != null){
                if(securityPrincipal instanceof UserDetails){
                    log.info(String.format("Principal from security context: %s" , ((UserDetails) securityPrincipal).getUsername()));
                }
            }

        }

    }

    @Override
    public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext) throws IOException {

    }
}
