package com.leadx.ppiclaims.resources;


public class Lender {
    private String bank;

    public String getBank() {
        return bank;
    }

    public void setBank(String bank) {
        this.bank = bank;
    }

}
