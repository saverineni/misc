package com.leadx.ppiclaims.services;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.leadx.ppiclaims.resources.FormData;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Base64;

@Service
public class PDFGeneratorService {

    public ByteArrayInputStream generatePDFStream(FormData formData) throws DocumentException, SQLException, IOException {

        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        PdfWriter.getInstance(document, out);
        document.open();
        document.addTitle("My first PDF");

        PdfPTable table = new PdfPTable(2);
        table.setWidthPercentage(100);

        table.addCell("Personal Details");
        table.addCell("");
        table.addCell("first name");
        table.addCell(formData.getPersonalDetails().getFirstName());
        table.addCell("last name");
        table.addCell(formData.getPersonalDetails().getLastName());
        table.addCell("date of birth");
        table.addCell(formData.getPersonalDetails().getDateOfBirth().toString());

        table.addCell("                ");
        table.addCell("                ");
        table.addCell("Address");
        table.addCell("");
        table.addCell("first line");
        table.addCell(formData.getAddressDetails().getFirstLine());
        table.addCell("city");
        table.addCell(formData.getAddressDetails().getCity());
        table.addCell("postcode");
        table.addCell(formData.getAddressDetails().getPostcode());

        table.addCell("              ");
        table.addCell("              ");
        table.addCell("Lender");
        table.addCell("");
        table.addCell("Bank");
        table.addCell(formData.getLenderDetails().getBank());

        table.addCell("                ");
        table.addCell("                ");
        table.addCell("Signature");

        Base64.Decoder decoder = Base64.getDecoder();
        byte[] decodedByte = decoder.decode(formData.getSignature().split(",")[1]);

        Image image = Image.getInstance(decodedByte);
        image.scaleAbsolute(500, 500);
        table.addCell(image);


        document.add(table);

        document.close();

        return new ByteArrayInputStream(out.toByteArray());
    }

}
