/* sbt -- Simple Build Tool
 * Copyright 2009  Mark Harrah
 */
package xsbti;

public interface F0<T>
{
	T apply();
}
