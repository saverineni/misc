object A {
	def x(i: Int) = 3
}
