object C {
	// broken method, D doesn't exist
	def x: Int = D.i
}
