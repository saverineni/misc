object B {
	/**
	* @notparam i An argument
	*/
	def x(i: Int) = 3
}