import scala

object Foo {
	val x = "this should be long to compile or the test may fail."
}