package test6

class B extends A {
  def wibble = println("foo")
}
