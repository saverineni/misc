package test3

trait C { }
