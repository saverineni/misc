
class bad {
    public bad foo() { return 1; }
}