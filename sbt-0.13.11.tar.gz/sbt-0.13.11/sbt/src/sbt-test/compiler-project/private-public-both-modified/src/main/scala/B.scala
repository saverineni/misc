class B {
  private def foo: Int = 1
  def baz(): Unit = println(foo, A.xyz)
}
