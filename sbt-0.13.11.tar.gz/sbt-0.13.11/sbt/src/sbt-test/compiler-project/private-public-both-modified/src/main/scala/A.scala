object A {
  private def foo: Int = 1
  def bar: Int = 29
  def xyz: Int = 101
}
