object A {
  private def foo: String = "1"
  def bar: String = "29"
  def xyz: Int = 101
}
