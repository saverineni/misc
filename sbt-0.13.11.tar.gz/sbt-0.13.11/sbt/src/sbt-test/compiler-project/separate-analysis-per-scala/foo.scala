package foo

object Foo extends App {
  println("yay")
}

