package test3

trait A {
  def foo = 1
}
