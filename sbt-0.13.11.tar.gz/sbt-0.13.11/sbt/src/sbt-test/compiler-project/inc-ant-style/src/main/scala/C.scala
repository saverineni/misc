package test3

trait C {
  def abc(a: A): Int = a.foo
}
