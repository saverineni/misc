package test

class Bar {
	def f: Foo = null //we introduce dependency on Foo
}
