package test

class Box[T]

class Foo {
	def foo: Box[_] = null
}
