object A {
	def apply(x: org.junit.runners.JUnit4) = ()
}