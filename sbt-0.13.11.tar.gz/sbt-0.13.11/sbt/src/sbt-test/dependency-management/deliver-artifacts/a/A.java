public class A {
	public static final int x = 3;
}
