object D {
	val x = 3
}