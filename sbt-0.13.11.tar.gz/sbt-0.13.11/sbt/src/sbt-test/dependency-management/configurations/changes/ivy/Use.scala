object UseIvy
{
	def yi = PublishedIvy.x
}