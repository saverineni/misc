package sbt.internals.parser

import org.specs2.mutable._

trait AbstractSpec extends Specification with SplitExpression