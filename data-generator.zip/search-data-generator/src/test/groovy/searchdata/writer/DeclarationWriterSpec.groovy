package searchdata.writer;

import searchdata.cds.CdsDeclarationWriter
import searchdata.data.Declaration
import searchdata.data.Header
import searchdata.data.Line
import spock.lang.Specification

class DeclarationWriterSpec extends Specification {
    RowWriter headerWriter = Mock()
    RowWriter lineWriter = Mock()
    CdsDeclarationWriter declarationWriter = new CdsDeclarationWriter(
        headerWriter: headerWriter,
        lineWriter: lineWriter
    )
    
    def header = new Header(joinId: 123)
    
    def 'should write the declaration header to the header writer'() {
        given:
        def declaration = new Declaration(
            header: header,
            lines: []
        )
        
        when:
        declarationWriter.write(declaration)
        
        then:
        1 * headerWriter.write(header)
    }

    def 'should write the declaration lines to the line writer'() {
        given:
        def lines = [ line(1), line(2)]
        def declaration = new Declaration(
            header: header,
            lines: lines 
        )
        
        when:
        declarationWriter.write(declaration)
        
        then:
        1 * lineWriter.write(lines[0])
        1 * lineWriter.write(lines[1])
    }
    
    private line(itemNumber) {
        new Line(itemNumber: itemNumber)
    }
}
