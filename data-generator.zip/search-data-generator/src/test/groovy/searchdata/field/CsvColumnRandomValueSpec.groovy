package searchdata.field;

import static org.junit.Assert.*

import searchdata.csv.CsvReader
import spock.lang.Shared
import spock.lang.Specification

class CsvColumnRandomValueSpec extends Specification {
    @Shared
    def toChooseFrom
    
    def countries = new CsvColumnRandomValue('data/country_alpha_full.csv', 1)
    
    def setupSpec() {
        def reader = CsvReader.parse('data/country_alpha_full.csv')
        toChooseFrom = reader.columnData(1)
    }
    
    def 'should give random country from country list'() {
        when:
        def randomCountry = countries.random()
        
        then:
        toChooseFrom.contains(randomCountry)
    }
    
    // not a brilliant test but...
    def 'should give random country'() {
        expect:
        countries.random() != countries.random()
    }
}
