package searchdata.chief;

import searchdata.generator.DeclarationGenerator
import searchdata.generator.RandomDeclarationGenerator
import spock.lang.Specification
import spock.lang.Unroll

class ChiefDataCsvImportDataIntegrationSpec extends Specification {

    def setupSpec() {
        DeclarationGenerator declarationGenerator = new RandomDeclarationGenerator(numberOfDeclarations: 10)
        ChiefData generator = new ChiefData(
            outputDir: new File('target'),
            declarationGenerator: declarationGenerator
        )

        generator.writeData()
    }

    @Unroll("#table table should have #rowCount rows")
    def 'should write the correct number of header rows'(table, rowCount) {
        given:
        def headers = new File("target/${table}.csv").text.split('\\n')

        expect:
        headers.size() == rowCount

        where:
        table        | rowCount
        'imenselect' | 10
        'imendetail' | 10
        'inad'       | 30
    }

    @Unroll("#table table row should have #expectedColumns columns and between #minData and #maxData randomly populated columns")
    def 'should populate header table columns'(table, expectedColumns, minData, maxData) {
        given:
        def columns = new File("target/${table}.csv").text.split('\\n')[0].split(',')
        def populatedColumns = columns.findAll { it != '\\N' }

        expect:
        columns.size() == expectedColumns
        populatedColumns.size() >= minData
        populatedColumns.size() <= maxData

        where:
        table        | expectedColumns | minData | maxData
        'imenselect' | 50              | 12      | 15
        'imendetail' | 198             | 11      | 12
        'inad'       | 17              | 5       | 5
        'imeiselect' | 20              | 10      | 10
        'iica'       | 40              | 4       | 4
        'iina'       | 18              | 6       | 6

    }

    @Unroll("#table table should have #rowCount rows")
    def 'should write the correct number of item rows'(table, rowCount) {
        given:
        def lines = new File("target/${table}.csv").text.split('\\n')

        expect:
        lines.size() > rowCount

        where:
        table        | rowCount
        'imeiselect' | 10
        'iica'       | 10
        'iina'       | 30
    }
}
