package searchdata.sql;

import static org.junit.Assert.*

import org.junit.Test

import spock.lang.Specification

class DatabaseDdlSpec extends Specification {

    def 'should give the ddl lines for the given information'() {
        given:
        def lines = DatabaseDdl.databaseDdlScript('database_name', 'create ddl script', [ 'table1', 'table2' ])

        expect:
        lines == [
            "DROP DATABASE IF EXISTS database_name CASCADE",
            "CREATE DATABASE database_name",
            "create ddl script",
            "load data local inpath 'database_name/table1.csv' overwrite into table database_name.table1",
            "load data local inpath 'database_name/table2.csv' overwrite into table database_name.table2"
        ]
    }
}
