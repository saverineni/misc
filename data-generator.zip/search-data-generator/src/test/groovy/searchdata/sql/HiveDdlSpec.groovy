package searchdata.sql;

import static org.junit.Assert.*

import spock.lang.Specification

class HiveDdlSpec extends Specification {
    def expectedCreateTableSql = this.class.classLoader.getResourceAsStream('searchdata/ddl/expectedCreateTable.sql').text
    
    HiveDdl hiveDdl = new HiveDdl();
    
    def 'should generate the create table sql from the table definition'() {
        given:
        def writer = new StringWriter()
        
        when:
        hiveDdl.writeTable(writer, 'database.table_name', 'searchdata/ddl/tableDefinition.csv')
        
        then:
        writer.toString() == expectedCreateTableSql
    }
}
