package searchdata.generator;

import searchdata.data.Header
import searchdata.field.FieldDataGenerator
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

class LineGeneratorSpec extends Specification {
    static SEQUENCE_NUMBER = '2'
    static JOIN_ID = '123'
    static DECLARATION_ID = 'dec-id'
    static ITEM_NUMBER = 1

    @Shared lineGenerator = new LineGenerator()
    @Shared line


    def setupSpec() {
        def fieldData = new FieldDataGenerator()
        def header = new Header(
            sequenceId: SEQUENCE_NUMBER,
            joinId: JOIN_ID,
            declarationId: DECLARATION_ID,
            entryDate: fieldData.customsDate())

        line = lineGenerator.next(header, ITEM_NUMBER)
    }

    def 'should have the given sequence number'() {
        expect:
        line.sequenceId == SEQUENCE_NUMBER
    }

    def 'should have the header join id'() {
        expect:
        line.joinId == JOIN_ID
    }

    def 'should have the heade declaration id'() {
        expect:
        line.declarationId == DECLARATION_ID
    }

    def 'should have the given item number'() {
        expect:
        line.itemNumber == ITEM_NUMBER
    }

    @Unroll
    def 'should populate the #property with a random value'(property, pattern) {
        given:
        def value = line."$property"

        expect:
        value ==~ pattern

        where:
        property                     | pattern
        'clearanceDate'              | /\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}.\d{3}/
        'commodityCode'              | /\d{10}/
        'cpc'                        | /\d{4}[0-1A-Z]\d{2}/
        'packageKind'                | /(PK|CT|\\N)/
        'packageCount'               | /\d+/
        'packageMarks'               | 'SHIPPING MARKS PART1 SHIPPING'
        'goodsDescription'           | 'Description of packaged goods'
        'grossMass'                  | /\d{1,5}\.\d{2}/
        'preferenceNumber'           | /\d+/
        'netMass'                    | /\d{1,5}\.\d{2}/
        'quotaNumber'                | /[\w\d]+/
        'summaryDeclaration'         | 'YCLE201809187GB025115132109-12345'
        'supplementaryUnits'         | /(\d+|\\N)/
        'customsValueCurrency'       | /[A-Z]{2,3}/
        'customsValue'               | /\d{1,5}\.\d{2}/
        'valuationMethod'            | /(1|\\N)/
        'aIStatement'                | /(00100|\\N)/
        'statementDescription'       | 'Statement Description'
        'valuationAdjustmentCode'    | /(\\N|[A-Z]{2})/
        'valuationAdjustmentAmount'  | /\d{1,5}\.\d{2}/
        'valuationAdjustmentCurrency'| /[A-Z]{2,3}/
        'statisticalValueCurrency'   | /[A-Z]{2,3}/
        'statisticalValue'           | /\d{1,5}\.\d{2}/
        'itemRoute'                  | /.{1,2}/
    }

    @Unroll
    def 'should populate the complex data type: #type #property'(type, property, pattern) {
        given:
        def value = line."$type"."$property"

        expect:
        value ==~ pattern

        where:
        type                      | property | pattern
        'firstDestinationCountry' | 'code'   | /[A-Z]{2}/
        'itemDestinationCountry'  | 'code'   | /[A-Z]{2}/
        'itemDispatchCountry'     | 'code'   | /[A-Z]{2}/
        'originCountry'           | 'code'   | /[A-Z]{2}/
        'itemConsignee'           | 'eori'   | /\d{12}/
        'itemConsignor'           | 'eori'   | /\d{12}/
        'itemDeclarant'           | 'eori'   | /\d{12}/
    }
}
