package searchdata.generator;

import static org.junit.Assert.*

import groovy.json.JsonSlurper
import searchdata.data.Declaration
import searchdata.data.Header
import searchdata.data.Line
import spock.lang.Specification

class JsonFilesDeclarationGeneratorSpec extends Specification {

    def firstDeclaration = this.class.classLoader.getResource('searchdata/generator/declarations/declaration1.json')
    def secondDeclaration = this.class.classLoader.getResource('searchdata/generator/declarations/declaration2.json')

    DeclarationGenerator declarationGenerator = new JsonFilesDeclarationGenerator([
        firstDeclaration,
        secondDeclaration
    ])

    def 'next should give the first declaration in the directory'() {
        given:
        def declarationJson = new JsonSlurper().parse(firstDeclaration)
        def expected = declaration(declarationJson)

        when:
        def result = declarationGenerator.next()

        then:
        result == expected
    }

    def 'next should give the second declaration in the directory'() {
        given:
        def declarationJson = new JsonSlurper().parse(secondDeclaration)
        def expected = declaration(declarationJson)
        declarationGenerator.next()

        when:
        def result = declarationGenerator.next()

        then:
        result == expected
    }

    private declaration(jsonData) {
        def data = [:] + jsonData
        def lines = data.lines.collect {
            it.declarationId = jsonData.declarationId
            it.sequenceId = jsonData.sequenceId
            it.joinId = jsonData.joinId

            it
        }

        data.remove('lines')

        [ header: data, lines: lines ]
    }

    def 'has next should give true when all files not returned'() {
        given:
        declarationGenerator.next()

        expect:
        declarationGenerator.hasNext() == true
    }

    def 'has next should give false when all files  returned'() {
        given:
        declarationGenerator.next()
        declarationGenerator.next()

        expect:
        declarationGenerator.hasNext() == false
    }
}
