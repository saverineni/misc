package searchdata.generator;

import searchdata.generator.HeaderGenerator
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

class HeaderGeneratorSpec extends Specification {
    static JOIN_ID = 2
    static SEQUENCE_NUMBER = '123'
    static DATE_PATTERN = /\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}.\d{3}/

    @Shared headerGenerator = new HeaderGenerator()
    @Shared header = headerGenerator.next(JOIN_ID, SEQUENCE_NUMBER)

    def 'should have the given join id'() {
        expect:
        header.joinId == JOIN_ID + ''
    }

    def 'should have the given sequence number'() {
        expect:
        header.sequenceId == SEQUENCE_NUMBER
    }

    @Unroll
    def 'should populate the #property with a random value'(property, pattern) {
        given:
        def value = header."$property"

        expect:
        value ==~ pattern

        where:
        property                  | pattern
        'declarationSource'       | 'CDS'
        'importExportIndicator'   | 'Import'
        'declarationId'           | "${2000000000000000 + JOIN_ID}"
        'epuNumber'               | /\d{3}/
        'entryNumber'             | /\d{6}a/
        'entryDate'               | DATE_PATTERN
        'route'                   | /.{1,2}/
        'declarationType'         | /(IM|EX)[A-Z]/
        'declarantRepresentation' | /(A|B|\\N)/
        'locationName'            | /[A-Z]{3}/
        'goodsLocation'           | /[A-Z]{3}/
        'placeOfLoading'          | /[A-Z]{3}/
        'locationType'            | /(14|9)/
        'transportModeCode'       | /\d/
        'invoiceCurrency'         | /[A-Z]{2,3}/
        'invoiceTotal'            | /\d{1,6}\.\d{2}/
        'inlandTransportMode'     | /.+/
        'transportId'             | /\d{27}/
        'totalPackages'           | /\d+/
        'grossMass'               | /\d{1,5}\.\d{2}/
        'premisesId'              | '1234567GB'
        'communicationId'         | 'hmrcgwid:d9693e8d-c7ab-409d-9daf-713b6ac894b3:e87626eb-cfed-4286-b147-64f705094f31:XBADGEAUTO'
        'processingStatus'        | /(1[0-6]|[1-9])/
        'acceptanceDate'          | DATE_PATTERN
        'dutyCurrency'            | /[A-Z]{2,3}/
        'totalDuty'               | /\d{1,6}\.\d{2}/
    }

    @Unroll
    def 'should populate the complex data type #{type}.#{property}'(type, property, pattern) {
        given:
        def value = header."$type"."$property"

        expect:
        value ==~ pattern

        where:
        type                 | property | pattern
        'dispatchCountry'    | 'code'   | /[A-Z]{2}/
        'destinationCountry' | 'code'   | /[A-Z]{2}/
        'consignee'          | 'eori'   | /\d{12}/
        'consignor'          | 'eori'   | /\d{12}/
        'declarant'          | 'eori'   | /\d{12}/
    }

    def 'setting export percentage value should return a proportion of export declarations'() {
        given:
        headerGenerator.exportPercentage = 30

        when:
        def declarations = (1..100).collect { headerGenerator.next(JOIN_ID, SEQUENCE_NUMBER) }
        def exportDeclarationCount = declarations.findAll { it.importExportIndicator == 'Export' }.size()

        then:
        exportDeclarationCount > 0
        exportDeclarationCount < 40
    }

    def 'setting the declaration initial number should give the relevant declaration id'() {
        given:
        headerGenerator.declarationInitialNumber = 3

        when:
        def header = headerGenerator.next(40, '1')

        then:
        header.declarationId == '3000000000000040'

    }
}
