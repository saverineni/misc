package searchdata.generator;

import searchdata.data.Header
import searchdata.data.Line
import searchdata.field.FieldDataGenerator
import spock.lang.Specification

class RandomDeclarationGeneratorSpec extends Specification {

    HeaderGenerator headerGenerator = Mock()
    LineGenerator lineGenerator = Mock()
    FieldDataGenerator fieldData = Mock()

    RandomDeclarationGenerator generator = new RandomDeclarationGenerator(
        headerGenerator: headerGenerator,
        lineGenerator: lineGenerator,
        fieldData: fieldData,
        numberOfDeclarations: 2
    )

    def setup() {
        fieldData.lineCount() >> 2
    }

    def 'should generate a header and corresponding lines'() {
        given:
        def header = new Header()
        def line1 = new Line()
        def line2 = new Line()


        headerGenerator.next(1, '1') >> header
        lineGenerator.next(header, 1) >> line1
        lineGenerator.next(header, 2) >> line2

        when:
        def declaration = generator.next()

        then:
        declaration.header == header
        declaration.lines == [ line1, line2 ]
    }

    def 'has next should give true when calls to next is less than number of declarations'() {
        given:
        generator.next()

        expect:
        generator.hasNext() == true
    }

    def 'has next should give false when number of declarations generated'() {
        given:
        generator.next()
        generator.next()

        expect:
        generator.hasNext() == false
    }

    def 'setting the export percentage should update the header generator'() {
        when:
        generator.exportPercentage = 30

        then:
        1 * headerGenerator.setExportPercentage(30)
    }

    def 'setting the declaration initial number should update the header generator'() {
        when:
        generator.declarationInitialNumber = 3

        then:
        1 * headerGenerator.setDeclarationInitialNumber(3)
    }
}
