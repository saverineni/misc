package searchdata.csv;

import spock.lang.Specification

class CsvReaderSpec extends Specification {

    CsvReader parser = CsvReader.parse('searchdata/csv/test.csv')
    
    def 'should give list of specified column values'(column, expected) {
        given:
        def columnData = parser.columnData(column)
        
        expect:
        columnData == expected
        
        where:
        column | expected
        0      | ['1','2','3','4','5','6','7','8']
        1      | ['one','two','three','four','five','six','seven','eight']
        2      | ['uno','dos','tres','quatro','cinco','seis','siete','ocho']
    }
}
