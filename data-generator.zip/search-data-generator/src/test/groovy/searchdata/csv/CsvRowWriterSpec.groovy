package searchdata.csv;

import searchdata.csv.CsvRowWriter
import spock.lang.Shared
import spock.lang.Specification;

class CsvRowWriterSpec extends Specification {
    def writer = new StringWriter()

    def simpleRowWriter = {
        new CsvRowWriter('searchdata/csv/outputDefinition.csv', 'searchdata/csv/simpleDataMapping.properties', writer)
    }

    def 'should write the data in csv format'() {
        given:
        def data = [valueOne: 'one', valueTwo: 'two', valueThree: 'three']

        when:
        simpleRowWriter().write(data)

        then:
        writer.toString().trim() == 'one,\\N,two,\\N,\\N,three,\\N,\\N,\\N'
    }

    def 'should add hive null for null values'() {
        given:
        def data = [:]

        when:
        def row = simpleRowWriter().write(data)

        then:
        writer.toString().trim() == '\\N,\\N,\\N,\\N,\\N,\\N,\\N,\\N,\\N'
    }

    def 'should add a line feed at the endo of the line'() {
        given:
        def data = [:]

        when:
        def row = simpleRowWriter().write(data)

        then:
        writer.toString().endsWith(System.getProperty("line.separator"))
    }

    def 'should read nested object properties'() {
        given:
        CsvRowWriter nestedRowWriter = new CsvRowWriter(
            'searchdata/csv/outputDefinition.csv',
            'searchdata/csv/nestedPropertyDataMapping.properties',
            writer)
        def data = [valueOne: 'one', valueTwo: [ one: '2_one', two: [ one: '2_two_1' ]]]

        when:
        nestedRowWriter.write(data)

        then:
        writer.toString().trim() == '\\N,one,\\N,2_one,2_two_1,\\N,\\N,\\N,\\N'
    }

    def 'should not fail reading missing nested object properties'() {
        given:
        CsvRowWriter nestedRowWriter = new CsvRowWriter(
            'searchdata/csv/outputDefinition.csv',
            'searchdata/csv/nestedPropertyDataMapping.properties',
            writer)
        def data = [valueOne: 'one', valueTwo: [ one: '2_one']]

        when:
        nestedRowWriter.write(data)

        then:
        writer.toString().trim() == '\\N,one,\\N,2_one,\\N,\\N,\\N,\\N,\\N'
    }
}
