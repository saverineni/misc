package searchdata.cds;

import spock.lang.Shared
import spock.lang.Specification

class CdsDataWriteDdlIntegrationSpec extends Specification {
    static DB_NAME = 'db_name'
    static HEADERS_TABLE = 'cdap_declaration_process_consolidated'
    static LINES_TABLE = 'cdap_goodsitems_consolidated'
    
    static CREATE_TABLE_SUFFIX = "ROW FORMAT DELIMITED\nFIELDS TERMINATED BY ',';"
    static COLUMN_OUTPUT_PATTERN = /(?m)^[\w_]+\s[\w\(\)_\d,]+,?$/
    
    @Shared
    def cdsDdlLines
    @Shared
    def headerCreateTable
    @Shared
    def linesCreateTable
    @Shared
    def ddlConfig = [  ]

    def setupSpec() {
        def ddlWriter = new StringWriter()
        CdsData generator = new CdsData()
        generator.addDdls(ddlWriter, DB_NAME)
        
        cdsDdlLines = ddlWriter.toString().readLines()
        
        headerCreateTable = cdsDdlLines.take(173).join('\n')
        linesCreateTable = cdsDdlLines.takeRight(93).join('\n')
        ddlWriter.close()
    }
    
    def 'should generate the correct cds ddl script'() {
        expect:
        cdsDdlLines.size() == 266
    }

    def 'should generate the correct header sql table'() {
        expect:
        headerCreateTable.startsWith("CREATE TABLE ${DB_NAME}.${HEADERS_TABLE}")
    }

    def 'should generate the correct line sql table'() {
        expect:
        linesCreateTable.startsWith("CREATE TABLE ${DB_NAME}.${LINES_TABLE}")
    }

    def 'should generate the header hive sql to read from csv files'() {
        expect:
        headerCreateTable.endsWith(CREATE_TABLE_SUFFIX)
    }

    def 'should generate the line hive sql to read from csv files'() {
        expect:
        linesCreateTable.endsWith(CREATE_TABLE_SUFFIX)
    }
    
    def 'should add the correct number of header table columns'() {
        given:
        def columns = headerCreateTable.findAll(COLUMN_OUTPUT_PATTERN)
        
        expect:
        columns.size() == 169
    }

    def 'should add the correct number of line table columns'() {
        given:
        def columns = linesCreateTable.findAll(COLUMN_OUTPUT_PATTERN)
        
        expect:
        columns.size() == 89
    }
}
