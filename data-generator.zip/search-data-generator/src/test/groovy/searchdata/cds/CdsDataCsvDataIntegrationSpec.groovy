package searchdata.cds;

import searchdata.generator.RandomDeclarationGenerator
import spock.lang.Shared
import spock.lang.Specification

class CdsDataCsvDataIntegrationSpec extends Specification {
    @Shared
    def headers
    @Shared
    def lines

    def setupSpec() {
        def declarationGenerator = new RandomDeclarationGenerator(numberOfDeclarations: 10)
        CdsData generator = new CdsData(
            declarationGenerator: declarationGenerator,
            outputDir: new File('target')
        )

        generator.writeData()

        headers = new File("target/${CdsData.HEADER_TABLE}.csv").text.split('\\n')
        lines = new File("target/${CdsData.LINE_TABLE}.csv").text.split('\\n')
    }

    def 'should write the correct number of header rows'() {
        expect:
        headers.length == 10
    }

    def 'should write each header in the correct format'() {
        given:
        def columns = headers[0].split(',')
        def populatedColumns = columns.findAll { it != '\\N' }

        expect:
        columns.size() == 169
        populatedColumns.size() >= 25
        populatedColumns.size() <= 26
    }

    def 'should write the lines to the lines writer'() {
        expect:
        lines.length > 10
    }

    def 'should write each line in the correct format'() {
        when:
        def columns = lines[0].split(',')
        def populatedColumnCount = columns.findAll { it != '\\N' }.size()

        then:
        columns.size() == 89
        28 < populatedColumnCount  // 4 nullable columns
        populatedColumnCount <= 32
    }
}
