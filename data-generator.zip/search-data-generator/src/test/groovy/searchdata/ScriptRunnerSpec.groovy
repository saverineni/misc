package searchdata;

import org.junit.Test

import spock.lang.Specification

class ScriptRunnerSpec extends Specification {
    
    def 'script args should give empty map for single arg'() {
        given:
        def scriptArgs = ScriptRunner.scriptArgs(['justScripName'].toArray())
        
        expect:
        scriptArgs == [:]
    }

    def 'script args matching the correct format should be parsed to a map'() {
        given:
        def scriptArgs = ScriptRunner.scriptArgs(['justScripName', '--first=one', '--second=two', 'ignored'].toArray())
        
        expect:
        scriptArgs == [ first: 'one', second: 'two' ]
    }
}
