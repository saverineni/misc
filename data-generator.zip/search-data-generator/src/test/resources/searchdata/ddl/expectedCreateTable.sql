CREATE TABLE database.table_name(
column_one string,
column_two bigint,
column_three varchar(3),
column_four string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ',';
