package searchdata.data

import groovy.transform.Immutable

@Immutable
class Declaration {
    Header header
    List<Line> lines
}
