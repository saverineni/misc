package searchdata.data

import groovy.transform.EqualsAndHashCode
import groovy.transform.Immutable
import groovy.transform.ToString

@Immutable
class Header {
    String joinId
    String declarationId
    String declarationSource
    String importExportIndicator
    String sequenceId
    String epuNumber
    String entryNumber
    String entryDate
    String route
    Country dispatchCountry
    Country destinationCountry
    Trader consignee
    Trader consignor
    Trader declarant
    String declarationType
    String declarantRepresentation
    String transportModeCode
    String invoiceCurrency
    String invoiceTotal
    String inlandTransportMode
    String transportId
    String totalPackages
    String grossMass
    String premisesId
    String communicationId
    String processingStatus
    String acceptanceDate
    String locationName
    String locationType
    String dutyCurrency
    String totalDuty
    String goodsLocation
    String placeOfLoading
}
