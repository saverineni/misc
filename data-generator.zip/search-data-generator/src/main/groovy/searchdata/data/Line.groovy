package searchdata.data

import groovy.transform.Immutable

@Immutable
class Line {
    String joinId
    String declarationId
    int itemNumber
    String sequenceId
    String clearanceDate
    String commodityCode
    String cpc
    Country firstDestinationCountry
    Country itemDispatchCountry
    Country itemDestinationCountry
    Country originCountry
    Trader itemConsignee
    Trader itemConsignor
    Trader itemDeclarant
    String packageKind
    String packageCount
    String packageMarks
    String goodsDescription
    String grossMass
    String preferenceNumber
    String netMass
    String quotaNumber
    String summaryDeclaration
    String supplementaryUnits
    String customsValueCurrency
    String customsValue
    String valuationMethod
    String aIStatement
    String statementDescription
    String valuationAdjustmentCode
    String valuationAdjustmentAmount
    String valuationAdjustmentCurrency
    String statisticalValueCurrency
    String statisticalValue
    String itemRoute
}
