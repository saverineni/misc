package searchdata.data

import groovy.transform.Immutable

@Immutable
class Trader {
    String eori
    String name
    String postcode
}
