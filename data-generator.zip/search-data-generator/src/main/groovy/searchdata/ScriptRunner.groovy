package searchdata

class ScriptRunner {
    private static ARG_PATTERN = /^\-\-(\w+)=(.*)$/
    
    static main(args) {
        Binding binding = new Binding(scriptArgs(args))
        
        GroovyShell shell = new GroovyShell(binding)

        shell.evaluate(
            ScriptRunner.class.classLoader
                        .getResourceAsStream("scripts/${args[0]}.groovy").text
        )
        
        def exitCode = binding.getProperty('exitCode')
        
        if (exitCode) {
            System.exit(exitCode)
        }
    }
    
    static Map scriptArgs(args) {
        args.collect {
            it =~ ARG_PATTERN
        }.findAll {
            it
        }.collectEntries {
            [ (it[0][1]): it[0][2] ]
        }
    }
}
