package searchdata.csv;

import searchdata.writer.RowWriter

class CsvRowWriter implements RowWriter {
    private static final LINE_SEPARATOR = System.getProperty("line.separator")

    private csvColumns
    private Properties dataMapping
    private Writer writer

    CsvRowWriter(String csvDefinitionResource,
                 String dataMappingResource,
                 Writer writer) {
        csvColumns = CsvReader.parse(csvDefinitionResource).columnData(0)
        dataMapping = new Properties()
        dataMapping.load(this.class.classLoader.getResourceAsStream(dataMappingResource))

        this.writer = writer
    }

    void write(data) {
        writer.write(
            columnValues(data).join(',')
        )
        writer.write(LINE_SEPARATOR)
    }

    private columnValues(data) {
        csvColumns.collect {
            def mapping = dataMapping.get(it)
            if (mapping) {
                def match = mapping =~ /"(.+)"/
                if (match) {
                    match[0][1]
                } else {
                    getValue(mapping, data)
                }
            } else {
                '\\N'
            }
        }
    }

    private getValue(String mapping, data) {
        def index = mapping.indexOf('.')
        if (index == -1) {
            data?."$mapping" ?: '\\N'
        } else {
            def childProperty = mapping.substring(index + 1) // plus one for dot
            def childData = data."${mapping.substring(0, index)}"
            getValue(childProperty, childData)
        }
    }
}
