package searchdata.csv

import com.xlson.groovycsv.CsvParser

class CsvReader {
    List data
    
    static CsvReader parse(String resource) {
        def csv = CsvReader.class.classLoader.getResourceAsStream(resource).text
        def data = CsvParser.parseCsv(csv, readFirstLine: true).collect { it }
        
        new CsvReader(data: data)
    }
    
    def columnData(int columnIndex) {
        data*.getAt(columnIndex)*.trim()
    }
}
