package searchdata.sql

import searchdata.csv.CsvReader

class HiveDdl {

    def writeTable(Writer writer, String tableName, String definitionResource) {
        def columns = columns(definitionResource)
        writer.write(sql(tableName, columns))
    }
    
    private sql(tableName, columns) {
        """CREATE TABLE $tableName(
${columns.join(',\n')}
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ',';
"""
    }
    
    private columns(definitionResource) {
        def csvReader = CsvReader.parse(definitionResource)
        
        csvReader.data.collect {
            "${it[0]} ${it[1]}"
        }
    }
}
