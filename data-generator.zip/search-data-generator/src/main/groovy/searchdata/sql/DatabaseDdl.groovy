package searchdata.sql

class DatabaseDdl {

    static databaseDdlScript(databaseName, createDdl, tableNames) {
        def loadTables = tableNames.collect {
            "load data local inpath '${databaseName}/${it}.csv' overwrite into table ${databaseName}.${it}"
        }

        ([
            "DROP DATABASE IF EXISTS ${databaseName} CASCADE",
            "CREATE DATABASE ${databaseName}",
            createDdl
        ] + loadTables)
    }
}
