package searchdata.chief

import searchdata.csv.CsvRowWriter
import searchdata.generator.DeclarationGenerator
import searchdata.generator.RandomDeclarationGenerator
import searchdata.sql.HiveDdl
import searchdata.writer.DeclarationWriter

class ChiefData {

    static final TABLES = [
        'imendetail', 'imenselect', 'inad', 'nxendetail', 'nxenselect', 'nxnad',
        'imeiselect', 'iina', 'iica', 'nxeidetail', 'nxeiselect', 'nxica', 'nxina'
    ]

    private RandomDeclarationGenerator decGenerator = new RandomDeclarationGenerator()
    private HiveDdl hiveDdl = new HiveDdl()

    File outputDir
    DeclarationGenerator declarationGenerator

    def writeData() {
        def fileWriters = [:]

        def declarationWriter = new ChiefDeclarationWriter(
            tableWriters: createTableRowWriters(fileWriters)
        )

        addDeclarations(declarationWriter)

        fileWriters.values().each { it.close() }
    }

    private Map createTableRowWriters(Map fileWriters) {
        def tableWriters = tableWriters(fileWriters)

        // think of a better way to to do the trader mappings
        tableWriters.inad += multiRowMappings(fileWriters, 'inad', ['mapping_2', 'mapping_3'])
        tableWriters.iina += multiRowMappings(fileWriters, 'iina', ['mapping_2', 'mapping_3'])
        tableWriters.nxnad += multiRowMappings(fileWriters, 'nxnad', ['mapping_2', 'mapping_3'])
        tableWriters.nxina += multiRowMappings(fileWriters, 'nxina', ['mapping_2', 'mapping_3'])

        return tableWriters
    }

    private multiRowMappings(fileWriters, table, mappings) {
        mappings.collect {
            new CsvRowWriter(
                "chief/$table/definition.csv".toString(),
                "chief/$table/${it}.properties".toString(),
                fileWriters[table]
            )
        }
    }

    private Map tableWriters(Map fileWriters) {
        TABLES.collectEntries {
            def writer = new File(outputDir, "${it}.csv").newWriter()
            fileWriters[it] = writer
            [ (it): [ new CsvRowWriter(
                        "chief/${it}/definition.csv".toString(),
                        "chief/${it}/mapping.properties".toString(),
                        writer
                    )]
            ]
        }
    }

    // common code
    def addDeclarations(DeclarationWriter declarationWriter) {
        while(declarationGenerator.hasNext()) {
            declarationWriter.write(declarationGenerator.next())
        }
    }

    def addDdls(Writer ddlWriter, String databaseName) {
        TABLES.each {
            hiveDdl.writeTable(ddlWriter, "${databaseName}.${it}", "chief/${it}/definition.csv")
        }
    }
}
