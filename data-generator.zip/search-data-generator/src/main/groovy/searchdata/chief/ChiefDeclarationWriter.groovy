package searchdata.chief

import searchdata.csv.CsvRowWriter
import searchdata.data.Declaration
import searchdata.writer.DeclarationWriter

class ChiefDeclarationWriter implements DeclarationWriter {

    private headerTables = [
        Import: [ 'imendetail', 'imenselect', 'inad' ],
        Export: [ 'nxendetail', 'nxenselect', 'nxnad' ]
    ]


    private lineTables = [
        Import: [ 'imeiselect', 'iina', 'iica' ],
        Export: [ 'nxeiselect', 'nxeidetail', 'nxina', 'nxica' ]
    ]

    Map tableWriters

    def write(def declaration) {
        headerTables[declaration.header.importExportIndicator].each {
            tableWriters[it].each {
                it.write(declaration.header)
            }
        }
        lineTables[declaration.header.importExportIndicator].each {
            tableWriters[it].each { table ->
                declaration.lines.forEach { table.write(it) }
            }
        }
    }
}
