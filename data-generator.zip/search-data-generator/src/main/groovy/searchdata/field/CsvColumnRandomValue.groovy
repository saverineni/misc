package searchdata.field

import searchdata.csv.CsvReader

class CsvColumnRandomValue {
    private Random rand = new Random()

    private final columnValues
    private final numberOfValues
    
    CsvColumnRandomValue(String resource, int column) {
        def reader = CsvReader.parse(resource)
        columnValues = reader.columnData(column)
        numberOfValues = columnValues.size()
    }
    
    String random() {
        columnValues[rand.nextInt(numberOfValues)]
    }
}
