package searchdata.field

import java.text.DecimalFormat
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.concurrent.ThreadLocalRandom
import java.util.concurrent.atomic.AtomicInteger

import searchdata.data.Country
import searchdata.data.Trader

class FieldDataGenerator {
    private Random rand = new Random()
    AtomicInteger counter = new AtomicInteger()
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")

    private countriesRandom = new CsvColumnRandomValue('data/country_alpha_full.csv', 1)
    private currencyCodeRandom = new CsvColumnRandomValue('data/currency_codes.csv', 1)
    private cpcRandom = new CsvColumnRandomValue('data/customs_procedure_code.csv', 0)
    private routeRandom = new CsvColumnRandomValue('data/customs_route.csv', 1)
    private epuRandom = new CsvColumnRandomValue('data/epu.csv', 1)
    private goodsLocationRandom = new CsvColumnRandomValue('data/goods_location_codes.csv', 3)
    private modeOfTransportRandom = new CsvColumnRandomValue('data/mode_of_transport.csv', 0)

    def entryNumber = { (100000 + rand.nextInt(900000)) + 'a' }

    def epuNumber = {
        epuRandom.random()
    }

    def goodsLocation = {
        goodsLocationRandom.random()
    }

    def locationType = {
        [9,14][rand.nextInt(2)]
    }


    def consignor = {
        trader(2, 'Consignor')
    }

    def consignee = {
        trader(2, 'Consignee')
    }

    def declarant = {
        trader(3, 'Declarant')
    }

    private trader(multiplier, type) {
        def id = rand.nextInt(100000)
        new Trader(
            eori: (100000000000 * multiplier) + id + '',
            name: "${type}_$id",
            postcode: "PC_$id"
        )
    }

    def commodityCode = {
        def prefix = "${1000 + rand.nextInt(100)}"

        "$prefix${100000 + rand.nextInt(1000)}"
    }

    def customsDate = {

        LocalDateTime startDate = LocalDateTime.now().minusYears(6)
        long start = startDate.toEpochSecond(ZoneOffset.UTC)

        LocalDateTime endDate = LocalDateTime.now()
        long end = endDate.toEpochSecond(ZoneOffset.UTC)

        long randomEpochSecond = ThreadLocalRandom.current().longs(start, end).findAny().getAsLong()

        LocalDateTime date = LocalDateTime.ofEpochSecond(randomEpochSecond, 0, ZoneOffset.UTC)

        date.format(formatter)
    }

    def clearanceDate = { date ->
        LocalDateTime clearanceDate = LocalDateTime.parse(date, formatter).plusDays(1)
        clearanceDate.format(formatter)
    }

    def country = { new Country(code: countriesRandom.random()) }

    def cpc = { cpcRandom.random() }

    def lineCount() { rand.nextInt(10) }

    def importExport = { exportPercentage -> (rand.nextInt(100) >= exportPercentage) ? 'Import' : 'Export' }

    def declarationType = {
        if (it == 'Export') {
            ['EXD','EXF','EXK'][rand.nextInt(3)]
        } else {
            ['IMA','IMB','IMC','IMD','IME','IMF','IMY','IMZ'][rand.nextInt(8)]
        }
    }

    def transportModeCode = {
        modeOfTransportRandom.random()
    }

    def route = {
        routeRandom.random()
    }

    def declarantRepresentation = {
        [ '\\N', 'A', 'B' ][rand.nextInt(3)]
    }

    def currencyCode = {
        currencyCodeRandom.random()
    }

    def randomDecimal = { maxValue ->
        new DecimalFormat("#####0.00").format(rand.nextInt(maxValue * 100) / 100)
    }

    def transportId = {
        '234841200224554521451234567'
    }

    def numberNonZero = { maxValue ->
        rand.nextInt(maxValue) + 1
    }

    def premisesId = {
        '1234567GB'
    }

    def communicationId = {
        'hmrcgwid:d9693e8d-c7ab-409d-9daf-713b6ac894b3:e87626eb-cfed-4286-b147-64f705094f31:XBADGEAUTO'
    }

    def packageKind = {
        [ '\\N', 'PK', 'CT' ][rand.nextInt(3)]
    }

    def valuationAdjustmentCode = {
        ['\\N','AC','AD','AE','AF','AI','AL','AM','AN','AO','AR','AX','AZ','BC','BE','BF','BG','BI','BL'][rand.nextInt(19)]
    }

    def valuationMethod = {
        if (rand.nextInt(100) > 90) {
            '\\N'
        } else {
            1
        }
    }

    def supplementaryUnits = {
        if (rand.nextInt(100) > 90) {
            '\\N'
        } else {
            numberNonZero(1000)
        }
    }

    def aIStatement = {
        if (rand.nextInt(100) > 80) {
            '\\N'
        } else {
            '00100'
        }
    }
}
