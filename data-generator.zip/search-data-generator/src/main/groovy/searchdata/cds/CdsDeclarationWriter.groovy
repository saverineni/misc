package searchdata.cds

import searchdata.data.Declaration
import searchdata.writer.DeclarationWriter
import searchdata.writer.RowWriter

class CdsDeclarationWriter implements DeclarationWriter {
    RowWriter headerWriter
    RowWriter lineWriter

    def write(def declaration) {
        headerWriter.write(declaration.header)
        declaration.lines.forEach {
            lineWriter.write(it)
        }
    }
}
