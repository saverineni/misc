package searchdata.cds

import searchdata.csv.CsvRowWriter
import searchdata.generator.DeclarationGenerator
import searchdata.sql.HiveDdl
import searchdata.writer.DeclarationWriter

class CdsData {
    static HEADER_TABLE = 'cdap_declaration_process_consolidated'
    static HEADER_DEFINITION = "cds/${HEADER_TABLE}/definition.csv"
    static HEADER_MAPPING = "cds/${HEADER_TABLE}/mapping.properties"

    static LINE_TABLE = 'cdap_goodsitems_consolidated'
    static LINE_DEFINITION = "cds/${LINE_TABLE}/definition.csv"
    static LINE_MAPPING = "cds/${LINE_TABLE}/mapping.properties"

    private HiveDdl hiveDdl = new HiveDdl()

    DeclarationGenerator declarationGenerator
    File outputDir

    def writeData() {
        def headerWriter
        def lineWriter
        try {
            headerWriter = new File(outputDir, "${CdsData.HEADER_TABLE}.csv").newWriter()
            lineWriter = new File(outputDir, "${CdsData.LINE_TABLE}.csv").newWriter()

            def declarationWriter = new CdsDeclarationWriter(
                headerWriter: new CsvRowWriter(HEADER_DEFINITION, HEADER_MAPPING, headerWriter),
                lineWriter: new CsvRowWriter(LINE_DEFINITION, LINE_MAPPING, lineWriter)
            )

            addDeclarations(declarationWriter)
        } finally {
            headerWriter.close()
            lineWriter.close()
        }
    }

    def addDeclarations(DeclarationWriter declarationWriter) {
        while(declarationGenerator.hasNext()) {
            declarationWriter.write(declarationGenerator.next())
        }
    }

    def addDdls(Writer ddlWriter, String databaseName) {
        [ HEADER_TABLE, LINE_TABLE ].each {
            hiveDdl.writeTable(ddlWriter, "${databaseName}.${it}", "cds/${it}/definition.csv")
        }
    }
}
