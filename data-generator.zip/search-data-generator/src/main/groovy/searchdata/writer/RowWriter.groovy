package searchdata.writer

interface RowWriter {

    void write(data)
}
