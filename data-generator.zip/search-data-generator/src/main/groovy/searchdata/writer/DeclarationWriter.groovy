package searchdata.writer

import searchdata.data.Declaration

interface DeclarationWriter {
    def write(def declaration)
}
