package searchdata.generator

import searchdata.data.Header
import searchdata.field.FieldDataGenerator

class HeaderGenerator {
    private FieldDataGenerator fieldData = new FieldDataGenerator()

    int declarationInitialNumber = 2

    int exportPercentage

    Header next(int id, String sequenceId) {
        fieldData.with {
            def customsDate = customsDate()
            new Header(
                joinId: id,
                declarationId: decId(id),
                sequenceId: sequenceId,
                declarationSource: 'CDS',
                importExportIndicator: importExport(this.exportPercentage),
                epuNumber: epuNumber(),
                entryNumber: entryNumber(),
                entryDate: customsDate,
                route: route(),
                declarationType: declarationType(),
                declarantRepresentation: declarantRepresentation(),
                locationName: goodsLocation(),
                locationType: locationType(),
                transportModeCode: transportModeCode(),
                invoiceCurrency: currencyCode(),
                invoiceTotal: randomDecimal(1000000),
                totalPackages: numberNonZero(100),
                inlandTransportMode: transportModeCode(),
                transportId: transportId(),
                dispatchCountry: country(),
                destinationCountry: country(),
                consignee: consignee(),
                consignor: consignor(),
                declarant: declarant(),
                grossMass: randomDecimal(10000),
                premisesId: premisesId(),
                communicationId: communicationId(),
                processingStatus: numberNonZero(16),
                acceptanceDate: clearanceDate(customsDate),
                dutyCurrency: currencyCode(),
                totalDuty: randomDecimal(1000000),
                placeOfLoading: goodsLocation(),
                goodsLocation: goodsLocation()
            )
        }
    }

    private decId(id) {
        "${(1000000000000000 * declarationInitialNumber) + id}"
    }
}
