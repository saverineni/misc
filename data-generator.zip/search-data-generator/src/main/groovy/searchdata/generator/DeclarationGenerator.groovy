package searchdata.generator

import searchdata.data.Declaration

interface DeclarationGenerator {

    def next()

    boolean hasNext()
}
