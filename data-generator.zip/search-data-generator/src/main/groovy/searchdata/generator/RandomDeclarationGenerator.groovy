package searchdata.generator

import java.util.concurrent.atomic.AtomicInteger

import groovy.transform.PackageScope
import searchdata.data.Declaration
import searchdata.field.FieldDataGenerator

class RandomDeclarationGenerator implements DeclarationGenerator {
    @PackageScope
    HeaderGenerator headerGenerator = new HeaderGenerator()
    @PackageScope
    LineGenerator lineGenerator = new LineGenerator()
    @PackageScope
    FieldDataGenerator fieldData = new FieldDataGenerator()

    String sequenceId = '1'
    int numberOfDeclarations

    private AtomicInteger idGenerator = new AtomicInteger()

    Declaration next() {
        def header = headerGenerator.next(idGenerator.incrementAndGet(), sequenceId)
        new Declaration(
            header: header,
            lines: (1..fieldData.lineCount()).collect { lineGenerator.next(header, it) }
        )
    }

    boolean hasNext() {
        idGenerator.get() < numberOfDeclarations
    }

    def setExportPercentage(int percentage) {
        headerGenerator.setExportPercentage(percentage)
    }

    def setDeclarationInitialNumber(int declarationInitialNumber) {
        headerGenerator.setDeclarationInitialNumber(declarationInitialNumber)
    }
}