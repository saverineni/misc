package searchdata.generator

import groovy.json.JsonSlurper
import searchdata.data.Declaration
import searchdata.data.Header

class JsonFilesDeclarationGenerator implements DeclarationGenerator {
    def declarations
    private currentIndex = 0
    private jsonSlurper = new JsonSlurper()

    JsonFilesDeclarationGenerator(List declarations) {
        this.declarations = declarations
    }

    def next() {
        def declarationFile = declarations[currentIndex++]

        def parsedDeclaration = jsonSlurper.parse(declarationFile)

        [
            header: header(parsedDeclaration),
            lines: lines(parsedDeclaration)
        ]
    }

    private header(data) {
        def copy = [:] + data
        copy.remove('lines')

        copy
    }

    private lines(data) {
        data.lines.collect {
            it.declarationId = data.declarationId
            it.joinId = data.joinId
            it.sequenceId = data.sequenceId

            it
        }
    }

    boolean hasNext() {
        currentIndex < declarations.size()
    }
}
