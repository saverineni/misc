package searchdata.generator

import searchdata.data.Header
import searchdata.data.Line
import searchdata.field.FieldDataGenerator

class LineGenerator {
    private FieldDataGenerator fieldData = new FieldDataGenerator()

    Line next(Header header, int lineNumber) {
        fieldData.with {
            new Line(
                joinId: header.joinId,
                declarationId: header.declarationId,
                sequenceId: header.sequenceId,
                itemNumber: lineNumber,
                clearanceDate: clearanceDate(header.entryDate),
                commodityCode: commodityCode(),
                cpc: cpc(),
                firstDestinationCountry: country(),
                itemDispatchCountry: country(),
                itemDestinationCountry: country(),
                originCountry: country(),
                itemConsignee: consignee(),
                itemConsignor: consignor(),
                itemDeclarant: declarant(),
                packageKind: packageKind(),
                packageCount: numberNonZero(1000),
                packageMarks: 'SHIPPING MARKS PART1 SHIPPING',
                goodsDescription: 'Description of packaged goods',
                grossMass: randomDecimal(100000),
                preferenceNumber: numberNonZero(100),
                netMass: randomDecimal(100000),
                quotaNumber: 'quotaNumber12345',
                summaryDeclaration: 'YCLE201809187GB025115132109-12345',
                supplementaryUnits: supplementaryUnits(),
                customsValueCurrency: currencyCode(),
                customsValue: randomDecimal(100000),
                valuationMethod: valuationMethod(),
                aIStatement: aIStatement(),
                statementDescription: 'Statement Description',
                valuationAdjustmentCode: valuationAdjustmentCode(),
                valuationAdjustmentAmount: randomDecimal(100000),
                valuationAdjustmentCurrency: currencyCode(),
                statisticalValueCurrency: currencyCode(),
                statisticalValue: randomDecimal(100000),
                itemRoute: route(),
            )
        }
    }
}
