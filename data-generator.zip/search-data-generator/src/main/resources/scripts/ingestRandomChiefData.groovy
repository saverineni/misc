import searchdata.chief.ChiefData
import searchdata.generator.RandomDeclarationGenerator
import searchdata.sql.DatabaseDdl

"mkdir $databaseName".execute().waitFor()

declarationGenerator = new RandomDeclarationGenerator(numberOfDeclarations: declarationCount as Integer)
declarationGenerator.exportPercentage = 30
declarationGenerator.declarationInitialNumber = 3

chiefData = new ChiefData(
    declarationGenerator: declarationGenerator,
    outputDir: new File(databaseName)
)

chiefData.writeData()

databaseDdlFile = new File("${databaseName}Ddl.sql")
databaseDdlFile.newWriter().withCloseable {
    chiefData.addDdls(it, databaseName)
}

exitCode = 0

ddl = DatabaseDdl.databaseDdlScript(
    databaseName,
    databaseDdlFile.text,
    ChiefData.TABLES
).join(';\n') + ';'

println "running ddl: '$ddl'"
def proc = [ 'hive', '-e', "\"$ddl\"" ].execute()
proc.waitForProcessOutput(System.out, System.err)

def exitValue = proc.exitValue()
if (exitValue != 0) {
    System.err.println("Non zero exit code $exitValue")
    exitCode = exitValue
}
