import searchdata.cds.CdsData
import searchdata.generator.JsonFilesDeclarationGenerator
import searchdata.sql.DatabaseDdl

"mkdir $databaseName".execute().waitFor()

declarationGenerator = new JsonFilesDeclarationGenerator([
    this.class.getResource('/datasets/test/declaration.json')
])

cdsData = new CdsData(
    declarationGenerator: declarationGenerator,
    outputDir: new File(databaseName)
)

cdsData.writeData()

databaseDdlFile = new File('databaseDdl.sql')
databaseDdlFile.newWriter().withCloseable {
    cdsData.addDdls(it, databaseName)
}

exitCode = 0

ddl = DatabaseDdl.databaseDdlScript(
    databaseName,
    databaseDdlFile.text,
    [CdsData.HEADER_TABLE, CdsData.LINE_TABLE]
).join(';\n') + ';'

println "running ddl: '$ddl'"
def proc = [ 'hive', '-e', "\"$ddl\"" ].execute()
proc.waitForProcessOutput(System.out, System.err)

def exitValue = proc.exitValue()
if (exitValue != 0) {
    System.err.println("Non zero exit code $exitValue")
    exitCode = exitValue
}
