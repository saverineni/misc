export const environment = {
  production: false,
  client: {
    name: 'The Test Guys',
    logo: 'assets/logo.png',
  },
  postURL: 'http://localhost:5000/esign/post/index.php',
  ab: true,
};
