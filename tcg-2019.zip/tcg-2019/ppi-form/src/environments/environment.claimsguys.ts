export const environment = {
  production: true,
  client: {
    name: 'The Claims Guys',
    logo: 'assets/logo_claimsguys.png',
  },
  postURL: 'post/index.php',
  ab: false,
};
