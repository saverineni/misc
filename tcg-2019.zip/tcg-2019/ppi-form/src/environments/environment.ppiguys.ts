export const environment = {
  production: true,
  client: {
    name: 'The PPI Guys',
    logo: 'assets/logo_ppiguys.png',
  },
  postURL: 'post/index.php',
  ab: false,
};
