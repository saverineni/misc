import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IntroRoutingModule } from './intro-routing.module';
import { IntroCreditComponent } from './components/intro-credit/intro-credit.component';
import { IntroStoreComponent } from './components/intro-store/intro-store.component';
import { IntroLoanComponent } from './components/intro-loan/intro-loan.component';
import { IntroCatalogueComponent } from './components/intro-catalogue/intro-catalogue.component';
import { IntroComponent } from './pages/intro/intro.component';
import { SharedModule } from '../shared/shared.module';
import { ChipButtonComponent } from './components/chip-button/chip-button.component';

@NgModule({
  declarations: [
    IntroCreditComponent,
    IntroStoreComponent,
    IntroLoanComponent,
    IntroCatalogueComponent,
    IntroComponent,
    ChipButtonComponent
  ],
  imports: [
    CommonModule,
    IntroRoutingModule,
    SharedModule,
  ]
})
export class IntroModule { }
