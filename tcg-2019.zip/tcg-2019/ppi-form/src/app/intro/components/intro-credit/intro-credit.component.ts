import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-intro-credit',
  templateUrl: './intro-credit.component.html',
  styleUrls: ['./intro-credit.component.scss']
})
export class IntroCreditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
