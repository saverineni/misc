import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IntroCreditComponent } from './intro-credit.component';

describe('IntroCreditComponent', () => {
  let component: IntroCreditComponent;
  let fixture: ComponentFixture<IntroCreditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IntroCreditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntroCreditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
