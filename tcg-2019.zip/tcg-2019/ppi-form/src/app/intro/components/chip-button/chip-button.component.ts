import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-chip-button',
  templateUrl: './chip-button.component.html',
  styleUrls: ['./chip-button.component.scss']
})
export class ChipButtonComponent implements OnInit {

  @Input()
  active: boolean;

  constructor() { }

  ngOnInit() {
  }

}
