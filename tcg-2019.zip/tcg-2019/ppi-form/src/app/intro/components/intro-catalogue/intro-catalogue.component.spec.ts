import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IntroCatalogueComponent } from './intro-catalogue.component';

describe('IntroCatalogueComponent', () => {
  let component: IntroCatalogueComponent;
  let fixture: ComponentFixture<IntroCatalogueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IntroCatalogueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntroCatalogueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
