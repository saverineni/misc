import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-intro-catalogue',
  templateUrl: './intro-catalogue.component.html',
  styleUrls: ['./intro-catalogue.component.scss']
})
export class IntroCatalogueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
