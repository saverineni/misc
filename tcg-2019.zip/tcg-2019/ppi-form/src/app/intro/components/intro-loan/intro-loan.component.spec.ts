import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IntroLoanComponent } from './intro-loan.component';

describe('IntroLoanComponent', () => {
  let component: IntroLoanComponent;
  let fixture: ComponentFixture<IntroLoanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IntroLoanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntroLoanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
