import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-intro-loan',
  templateUrl: './intro-loan.component.html',
  styleUrls: ['./intro-loan.component.scss']
})
export class IntroLoanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
