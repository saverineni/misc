import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-intro-store',
  templateUrl: './intro-store.component.html',
  styleUrls: ['./intro-store.component.scss']
})
export class IntroStoreComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
