import { Component, OnInit } from '@angular/core';
import { IntroService } from '../../services/intro/intro.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';

@Component({
  selector: 'app-intro',
  templateUrl: './intro.component.html',
  styleUrls: ['./intro.component.scss'],
})
export class IntroComponent implements OnInit {

  public currentStep$: Observable<{ value: number }>;
  public steps$: Observable<any>;
  public complete: boolean = false;

  public testimonial = {
    name: 'Claire',
    message: 'The Claims Guys provided a quick, efficient, knowledgeable service with minimal interaction and quick results.',
    image: 'assets/testimonial.png',
  };

  constructor(
    private introService: IntroService,
    private router: Router,
  ) {}

  public ngOnInit() {
    this.currentStep$ = this.introService.currentStep$
      .pipe(map(step => ({ value: step })));
    this.steps$ = this.introService.steps$;
  }

  public choose(answer, step = null) {
    this.introService.answerStep(answer);
    if (step === 3) {
      this.complete = true;
      setTimeout(() => {
        this.go();
      }, 500);
    }
  }

  public go() {
    this.router.navigate(['welcome'], { queryParamsHandling: 'merge' });
  }

  public trackByFn(op) {
    return op.value;
  }

}
