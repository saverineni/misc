import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class IntroService {

  private _currentStep = 0;
  private _currentStep$ = new BehaviorSubject(this._currentStep);
  public currentStep$;

  private _steps = [
    {
      label: 'Credit Cards?',
      value: 0,
      choice: null
    },
    {
      label: 'Loans?',
      value: 1,
      choice: null
    },
    {
      label: 'Store Cards?',
      value: 2,
      choice: null
    },
    {
      label: 'Catalogue Accounts?',
      value: 3,
      choice: null
    },
    {
      label: 'Great. Let\'s go!',
      value: 4,
      choice: null
    },
  ];

  private _steps$ = new BehaviorSubject(this._steps);
  public steps$ = this._steps$.asObservable();

  constructor() {
    this.currentStep$ = this._currentStep$.asObservable();
  }

  public answerStep(answer: boolean) {
    this._steps[this._currentStep].choice = answer;
    this._steps$.next(this._steps);

    ++this._currentStep;
    this._currentStep$.next(this._currentStep);
  }
}
