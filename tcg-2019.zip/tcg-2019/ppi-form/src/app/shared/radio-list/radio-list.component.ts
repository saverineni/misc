import { Component, Input, EventEmitter, Output, OnInit } from '@angular/core';

@Component({
  selector: 'app-radio-list',
  templateUrl: './radio-list.component.html',
  styleUrls: ['./radio-list.component.scss']
})
export class RadioListComponent implements OnInit {

  @Input()
  heading: string;

  @Input()
  label: string;

  @Input()
  options: any[];

  @Input()
  active: number;

  @Output()
  select: EventEmitter<any>;

  public position = 0;
  public done = false;
  public inProg = false;
  public isOpen = false;

  constructor() {
    this.select = new EventEmitter();
  }

  ngOnInit() {
    this.inProg = this.options.some( option => option.selected.length > 0 );
    this.done = this.options.every( option => option.selected.length > 0 );
    this.position = this.active || 0;
  }

  toggleOpen() {
    this.isOpen = !this.isOpen;
  }

  setPosition(pos) {
    this.position = Math.min((this.options.length), pos);
  }

  selectGroupOption(value: string, position: number) {
    this.select.emit({ value, position });
    if (this.position === (this.options.length - 1)) {
      this.done = true;
    }
    this.setPosition(++position);
    this.inProg = true;
  }

  trackByFn(opt) {
    return opt.label;
  }

}
