import { InjectionToken } from '@angular/core';

export const MODAL_DATA = new InjectionToken<string>('MODAL_DATA');
