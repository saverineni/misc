import { Injectable, Injector, ComponentRef } from '@angular/core';
import { Overlay, OverlayConfig, OverlayRef } from '@angular/cdk/overlay';
import { ComponentPortal, PortalInjector, ComponentType } from '@angular/cdk/portal';
import { ModalRemote } from '../remote/modal.remote';
import { MODAL_DATA } from '../modal.tokens';

interface ModalConfig {
  panelClass?: string;
  hasBackdrop?: boolean;
  backdropClass?: string;
  data?: any;
}

const DEFAULT_CONFIG: ModalConfig = {
  hasBackdrop: true,
  backdropClass: 'modal-backdrop',
  panelClass: 'fysh-modal-panel',
};

@Injectable()
export class ModalService {

  constructor(
    private injector: Injector,
    private overlay: Overlay
  ) { }

  open(modal: ComponentType<any>, config: ModalConfig = {}) {
    const dialogConfig = { ...DEFAULT_CONFIG, ...config };
    const overlayRef = this.createOverlay(dialogConfig);
    const remote = new ModalRemote(overlayRef);

    this.attachDialogContainer(modal, overlayRef, dialogConfig, remote);
    overlayRef.backdropClick().subscribe(_ => remote.close());

    return remote;
  }

  private createOverlay(config: ModalConfig) {
    const overlayConfig = this.getOverlayConfig(config);
    return this.overlay.create(overlayConfig);
  }

  private attachDialogContainer(modal: ComponentType<any>, overlayRef: OverlayRef, config: ModalConfig, dialogRef: ModalRemote) {
    const injector = this.createInjector(config, dialogRef);

    const containerPortal = new ComponentPortal(modal, null, injector);
    const containerRef: ComponentRef<ComponentRef<any>> = overlayRef.attach(containerPortal);

    return containerRef.instance;
  }

  private createInjector(config: ModalConfig, dialogRef: ModalRemote): PortalInjector {
    const injectionTokens = new WeakMap();

    injectionTokens.set(ModalRemote, dialogRef);
    injectionTokens.set(MODAL_DATA, config.data);

    return new PortalInjector(this.injector, injectionTokens);
  }

  private getOverlayConfig(config: ModalConfig): OverlayConfig {
    const positionStrategy = this.overlay.position()
      .global()
      .centerHorizontally()
      .centerVertically();

    const overlayConfig = new OverlayConfig({
      hasBackdrop: config.hasBackdrop,
      backdropClass: config.backdropClass,
      panelClass: config.panelClass,
      scrollStrategy: this.overlay.scrollStrategies.block(),
      positionStrategy
    });

    return overlayConfig;
  }
}
