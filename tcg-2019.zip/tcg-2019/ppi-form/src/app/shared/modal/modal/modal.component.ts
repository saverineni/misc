import { Component, OnInit, Input } from '@angular/core';
import { ModalRemote } from '../remote/modal.remote';
import { ViewportRuler } from '@angular/cdk/scrolling';
import { map, startWith, tap } from 'rxjs/operators';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss'],
})
export class ModalComponent implements OnInit {

  @Input()
  title: string = 'Modal';

  constructor(
    private remote: ModalRemote,
    private ruler: ViewportRuler,
  ) {
  }

  ngOnInit() {
  }

  close() {
    this.remote.close();
  }

  public get ruler$() {
    return this.ruler
      .change(1000)
      .pipe(
        startWith(this.ruler),
        map((viewportRuler: any) => {
          return viewportRuler.getViewportSize();
        }),
      );
  }

}
