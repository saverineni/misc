import { NgModule } from '@angular/core';
import { ModalComponent } from './modal/modal.component';
import { ModalService } from './services/modal.service';
import { OverlayModule } from '@angular/cdk/overlay';
import { AngularSvgIconModule } from 'angular-svg-icon';
import { CommonModule } from '@angular/common';

@NgModule({
    declarations: [
        ModalComponent,
    ],
    imports: [
        CommonModule,
        OverlayModule,
        AngularSvgIconModule,
    ],
    exports: [
        ModalComponent,
    ],
    providers: [
        ModalService,
    ],
    entryComponents: [
        ModalComponent
    ]
})
export class ModalModule {}