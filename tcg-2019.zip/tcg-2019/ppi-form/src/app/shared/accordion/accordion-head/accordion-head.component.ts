import { Component, OnInit, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-accordion-head',
  templateUrl: './accordion-head.component.html',
  styleUrls: ['./accordion-head.component.scss']
})
export class AccordionHeadComponent implements OnInit {

  @ViewChild('contentAll')
  contentAll: ElementRef;
  public hasContent: boolean = true;

  constructor(
    private changeDetector: ChangeDetectorRef
  ) { }

  ngOnInit() {
  }

  ngAfterViewInit(): void {
    this.hasContent = this.contentAll.nativeElement && this.contentAll.nativeElement.children.length > 0;
    this.changeDetector.detectChanges();
  }

}
