import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccordionHeadComponent } from './accordion-head/accordion-head.component';
import { AccordionBodyComponent } from './accordion-body/accordion-body.component';
import { AccordionIconComponent } from './accordion-icon/accordion-icon.component';
import { AccordionComponent } from './accordion/accordion.component';
import { AngularSvgIconModule } from 'angular-svg-icon';

@NgModule({
  imports: [
    CommonModule,
    AngularSvgIconModule,
  ],
  declarations: [
    AccordionComponent,
    AccordionHeadComponent, 
    AccordionBodyComponent,
    AccordionIconComponent,
  ],
  exports: [
    AccordionComponent,
    AccordionHeadComponent,
    AccordionBodyComponent,
    AccordionIconComponent,
  ]
})
export class AccordionModule { }
