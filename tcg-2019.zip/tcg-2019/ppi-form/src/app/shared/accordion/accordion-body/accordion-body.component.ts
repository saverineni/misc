import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accordion-body',
  templateUrl: './accordion-body.component.html',
  styleUrls: ['./accordion-body.component.scss']
})
export class AccordionBodyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
