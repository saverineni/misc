import { Component, AfterViewInit, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-accordion-icon',
  templateUrl: './accordion-icon.component.html',
  styleUrls: ['./accordion-icon.component.scss']
})
export class AccordionIconComponent {

  constructor() {  }

}
