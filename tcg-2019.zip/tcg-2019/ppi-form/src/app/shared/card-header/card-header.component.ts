import { Component, OnInit, Input } from '@angular/core';
import { Interpolation } from '@angular/compiler';
import { CdkStepLabel } from '@angular/cdk/stepper';

@Component({
  selector: 'app-card-header',
  templateUrl: './card-header.component.html',
  styleUrls: ['./card-header.component.scss']
})
export class CardHeaderComponent implements OnInit {

  @Input()
  title: string;

  @Input()
  label: string;

  constructor() { }

  ngOnInit() {
  }

}
