import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-multi-select-grid',
  templateUrl: './multi-select-grid.component.html',
  styleUrls: ['./multi-select-grid.component.scss']
})
export class MultiSelectGridComponent implements OnInit {

  @Input()
  items: { label: string; active: boolean }[];

  @Output()
  select: EventEmitter<number>;

  constructor() {
    this.select = new EventEmitter();
  }

  ngOnInit() {
  }

  public toggle(position) {
    this.select.emit(position);
  }

}
