import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiSelectGridComponent } from './multi-select-grid.component';

describe('MultiSelectGridComponent', () => {
  let component: MultiSelectGridComponent;
  let fixture: ComponentFixture<MultiSelectGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultiSelectGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiSelectGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
