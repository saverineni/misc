import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButtonComponent } from './button/button.component';
import { ChipComponent } from './chip/chip.component';
import { CardComponent } from './card/card.component';
import { ToggleComponent } from './toggle/toggle.component';
import { CardHeaderComponent } from './card-header/card-header.component';
import { ChipStackComponent } from './chip-stack/chip-stack.component';
import { CardBodyComponent } from './card/card-body/card-body.component';
import { LoaderComponent } from './loader/loader.component';
import { MatInputModule, MatAutocompleteModule, MatFormFieldModule, MatRippleModule, MatCheckboxModule } from '@angular/material';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AngularSvgIconModule } from 'angular-svg-icon';
import { ActionComponent } from './action/action.component';
import { AccordionModule } from './accordion/accordion.module';
import { RadioListComponent } from './radio-list/radio-list.component';
import { RadioComponent } from './radio/radio.component';
import { RadioGroupComponent } from './radio-group/radio-group.component';
import { MultiSelectGridComponent } from './multi-select-grid/multi-select-grid.component';
import { InfoBlockComponent } from './info-block/info-block.component';
import { TestimonialComponent } from './testimonial/testimonial.component';
import { CardActionsComponent } from './card/card-actions/card-actions.component';
import { HeaderComponent } from './header/header.component';
import { CreditCardComponent } from './icons/credit-card/credit-card.component';
import { CatalogueComponent } from './icons/catalogue/catalogue.component';
import { LoansComponent } from './icons/loans/loans.component';
import { AddSquareComponent } from './add-square/add-square.component';

@NgModule({
  imports: [
    CommonModule,
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule,
    ReactiveFormsModule,
    HttpClientModule,
    AngularSvgIconModule,
    MatRippleModule,
    MatCheckboxModule,
    AccordionModule,
  ],
  declarations: [
    ButtonComponent,
    ChipComponent,
    CardComponent,
    ToggleComponent,
    CardHeaderComponent,
    ChipStackComponent,
    CardBodyComponent,
    LoaderComponent,
    ActionComponent,
    RadioComponent,
    RadioGroupComponent,
    RadioListComponent,
    MultiSelectGridComponent,
    InfoBlockComponent,
    TestimonialComponent,
    CardActionsComponent,
    HeaderComponent,
    CreditCardComponent,
    CatalogueComponent,
    LoansComponent,
    AddSquareComponent,
  ],
  exports: [
    ButtonComponent,
    ChipComponent,
    ChipStackComponent,
    CardComponent,
    CardHeaderComponent,
    CardBodyComponent,
    CardActionsComponent,
    AccordionModule,
    CardHeaderComponent,
    ToggleComponent,
    LoaderComponent,
    ActionComponent,
    RadioComponent,
    RadioGroupComponent,
    RadioListComponent,
    MultiSelectGridComponent,
    InfoBlockComponent,
    TestimonialComponent,
    HeaderComponent,
      LoansComponent,
      CatalogueComponent,
      CreditCardComponent,
      AddSquareComponent
  ]
})
export class SharedModule { }
