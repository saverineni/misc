import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { ModalService } from '../modal/services/modal.service';
import { InfoComponent } from 'src/app/modals/info/info.component';
import { HelpComponent } from 'src/app/modals/help/help.component';

interface Client {
  name: string;
  logo: string;
}


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  public client: Client = environment.client;

  constructor(
    private modalService: ModalService,
  ) { }

  ngOnInit() {
  }

  public info(): void {
    this.modalService.open(InfoComponent);
  }

  public help(): void {
    this.modalService.open(HelpComponent);
  }

}
