import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-radio-group',
  templateUrl: './radio-group.component.html',
  styleUrls: ['./radio-group.component.scss']
})
export class RadioGroupComponent {

  @Input()
  options: any[];

  @Input()
  selected: string;

  @Output()
  select: EventEmitter<any>;

  constructor() {
    this.select = new EventEmitter();
  }

  public selectChoice(radio) {
    this.select.emit(radio.value);
  }

}
