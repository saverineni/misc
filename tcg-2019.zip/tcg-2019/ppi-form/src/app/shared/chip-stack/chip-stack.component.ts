import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chip-stack',
  templateUrl: './chip-stack.component.html',
  styleUrls: ['./chip-stack.component.scss']
})
export class ChipStackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
