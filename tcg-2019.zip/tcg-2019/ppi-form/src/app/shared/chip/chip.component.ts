import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-chip',
  templateUrl: './chip.component.html',
  styleUrls: ['./chip.component.scss']
})
export class ChipComponent {

  @Input()
  selected: boolean = false;

  @Input()
  icons: string[] = [
    'assets/icons/deselected.svg',
    'assets/icons/checked.svg'
  ];

  @Input()
  type: string;


  constructor(
  ) { }




}
