export interface IToastOptions {
    date?: Date;
    timeout?: number;
    action?: () => void;
    type?: 'success' | 'danger' | 'primary' | 'warning';
}

export interface IToast extends IToastOptions {
    message: string;
}

const DEFAULT_OPTIONS: IToastOptions = {
    date: new Date(),
    timeout: 2000,
    action: null,
    type: 'primary'
}

export class Toast implements IToast, IToastOptions {
    
    message: string;

    date: Date;
    timeout: number;
    action: () => void;
    type: 'success' | 'danger' | 'primary' | 'warning';

    constructor(message: string, options: IToastOptions = null) {
        this.message = message;
        
        const {
            date, 
            timeout, 
            action
        } = {
            ...DEFAULT_OPTIONS,
            ...options
        }
        this.date = date;
        this.timeout = timeout;
        this.action = action;
    }
}

export class SuccessToast extends Toast {

    constructor(message: string, options: IToastOptions = null) {
        super(message, options);
        this.type = 'success';
    }
}

export class DangerToast extends Toast {

    constructor(message: string, options: IToastOptions = null) {
        super(message, options);
        this.type = 'danger';
    }
}

export class WarningToast extends Toast {

    constructor(message: string, options: IToastOptions = null) {
        super(message, options);
        this.type = 'warning';
    }
}