import { Component, OnInit } from '@angular/core';
import { ToastService } from '../services/toast.service';
import { Observable } from 'rxjs';
import { Toast } from '../Toast';

@Component({
  selector: 'app-toasts',
  templateUrl: './toasts.component.html',
  styleUrls: ['./toasts.component.scss']
})
export class ToastsComponent implements OnInit {

  public toasts$: Observable<Toast[]>;

  constructor(
    private toastService: ToastService,
  ) { }

  ngOnInit() {
    this.toasts$ = this.toastService.toasts$;
  }

}
