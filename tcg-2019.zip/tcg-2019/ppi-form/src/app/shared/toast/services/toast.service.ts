import { Injectable } from '@angular/core';
import { Toast } from '../Toast';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ToastService {

  private _toasts: Toast[];
  private _toasts$: BehaviorSubject<Toast[]>;
  public toasts$: Observable<Toast[]>;

  constructor() {
    this._toasts = [];
    this._toasts$ = new BehaviorSubject(this._toasts);
    this.toasts$ = this._toasts$.asObservable()
    .pipe(
      map( (toasts) => {
        return toasts.filter(x => !!x);
      })
    );
  }

  cleanToaster() {
    const toasts = this._toasts.filter( toast => !!toast );
    if (!toasts.length) {
      // only if queue is clear
      this._toasts = toasts;
      this._toasts$.next(toasts);
    }
  }

  private popToast(index) {
    const toasts = this._toasts;
    this._toasts[index] = null;
    this._toasts$.next(toasts);
    this.cleanToaster();
  }

  cookToast(index, timeout) {
    setTimeout(this.popToast.bind(this, index), timeout);
  }

  addToast(toast: Toast) {
    const toasts = this._toasts;
    const length = toasts.push(toast);
    const index = length - 1;
    this.cookToast(index, toast.timeout);
    this._toasts$.next(toasts);
  }
}
