import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-add-square',
  templateUrl: './add-square.component.html',
  styleUrls: ['./add-square.component.scss']
})
export class AddSquareComponent implements OnInit {

  @Input()
  label: string;

  constructor() { }

  ngOnInit() {
  }

}
