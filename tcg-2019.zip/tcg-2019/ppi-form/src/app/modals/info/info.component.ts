import { Component, OnInit } from '@angular/core';

import { environment } from 'src/environments/environment';

import { ModalRemote } from 'src/app/shared/modal/remote/modal.remote';

@Component({
  selector: 'app-info',
  templateUrl: './info.component.html',
  styleUrls: ['./info.component.scss']
})
export class InfoComponent implements OnInit {

  public client = environment.client;
  public year = (new Date()).getFullYear();

  constructor(
    private remote: ModalRemote
  ) { }

  ngOnInit() {
  }

  continue() {
    this.remote.close();
  }

}
