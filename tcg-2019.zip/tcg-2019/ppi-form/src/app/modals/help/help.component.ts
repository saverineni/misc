import { Component, OnInit } from '@angular/core';

import { environment } from 'src/environments/environment';

import { InfoComponent } from '../info/info.component';
import { ModalRemote } from 'src/app/shared/modal/remote/modal.remote';
import { ModalService } from 'src/app/shared/modal/services/modal.service';

@Component({
  selector: 'app-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.scss']
})
export class HelpComponent implements OnInit {

  public client = environment.client;

  public accordions = new Array(7).fill(false);

  constructor(
    private remote: ModalRemote,
    private modalService: ModalService,
  ) { }

  ngOnInit() {
  }

  toggleActive(index: number) {
    this.accordions[index] = !this.accordions[index];
  }

  infoModal() {
    this.remote.close();
    this.modalService.open(InfoComponent);
  }

}
