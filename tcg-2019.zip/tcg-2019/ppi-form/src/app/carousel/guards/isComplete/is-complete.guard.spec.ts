import { TestBed, async, inject } from '@angular/core/testing';

import { IsCompleteGuard } from './is-complete.guard';

describe('IsCompleteGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [IsCompleteGuard]
    });
  });

  it('should ...', inject([IsCompleteGuard], (guard: IsCompleteGuard) => {
    expect(guard).toBeTruthy();
  }));
});
