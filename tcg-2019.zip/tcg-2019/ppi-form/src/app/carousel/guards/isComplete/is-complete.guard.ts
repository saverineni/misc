import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';

import { Observable } from 'rxjs';

import { DataService } from 'src/app/services/data/data.service';
import { CarouselService } from '../../services/carousel/carousel.service';

@Injectable({
  providedIn: 'root'
})
export class IsCompleteGuard implements CanActivate {

  constructor(
    private dataService: DataService,
    private carouselService: CarouselService,
    private router: Router
  ) {}

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    const name = next.routeConfig.path.replace('/', '');
    const step = this.dataService.stepMap.get(name);

    if (this.carouselService.isStepActive(step)) {
      return true;
    }

    const prevStep = Math.max(1, step - 1);

    this.router.navigate(['/' + prevStep], { queryParamsHandling: 'merge' });
  }
}
