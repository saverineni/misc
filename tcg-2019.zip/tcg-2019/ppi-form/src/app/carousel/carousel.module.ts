import { NgModule, LOCALE_ID } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CarouselRoutingModule } from './carousel-routing.module';
import { AdditionalComponent } from './pages/additional/additional.component';
import { WelcomeComponent } from './pages/welcome/welcome.component';
import { HistoryComponent } from './pages/history/history.component';
import { ConfirmComponent } from './pages/confirm/confirm.component';
import { SignComponent } from './pages/sign/sign.component';
import { NavComponent } from './components/nav/nav.component';
import { MoreLendersModalComponent } from './modals/more-lenders-modal/more-lenders-modal.component';
import { FinanceModalComponent } from './modals/finance-modal/finance-modal.component';
import { ModalModule } from '../shared/modal/modal.module';
import { SharedModule } from '../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule, MatInputModule, MatDatepickerModule, MatNativeDateModule, MatAutocompleteModule, DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material';
import { AngularSvgIconModule } from 'angular-svg-icon';
import { StrlenPipe } from '../pipes/strlen/strlen.pipe';
import { MAT_MOMENT_DATE_FORMATS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { CarouselComponent } from './components/carousel/carousel.component';
import { MainComponent } from './components/main/main.component';

@NgModule({
  declarations: [
    MainComponent,
    CarouselComponent,
    WelcomeComponent,
    HistoryComponent,
    AdditionalComponent,
    ConfirmComponent,
    SignComponent,
    NavComponent,
    MoreLendersModalComponent,
    FinanceModalComponent,
    StrlenPipe,
  ],
  imports: [
    CommonModule,
    CarouselRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatAutocompleteModule,
    SharedModule,
    ModalModule,
    AngularSvgIconModule,
  ],
  entryComponents: [
    FinanceModalComponent,
    MoreLendersModalComponent,
  ],
  providers: [
    { provide: LOCALE_ID, useValue: 'en-GB' },
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
  ],
})
export class CarouselModule { }
