import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { DataService } from 'src/app/services/data/data.service';
import { map, take, tap } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class CarouselService {

  private _activeSteps: boolean[];
  private _completeSteps: boolean[];
  private _progress: BehaviorSubject<boolean[]>;
  public progress$: Observable<number>;

  private _currentStep: number = 0;
  private _currentStep$: BehaviorSubject<number>;
  public currentStep$: Observable<number>;

  public hasSeenMoreLenders = false;

  constructor(
    private router: Router,
    private dataService: DataService,
  ) {
    this._activeSteps = new Array(dataService.stepMap.size).fill(false);
    this._activeSteps[0] = true;
    this._completeSteps = new Array(dataService.stepMap.size).fill(false);
    this._progress = new BehaviorSubject(
      this._completeSteps,
    );
    this.progress$ = this._progress.asObservable()
      .pipe(
        map((complete: boolean[]) => {
          return (1 + complete.filter(x => !!x).length) / complete.length * 100;
        }),
      );

    this._currentStep = 1;
    this._currentStep$ = new BehaviorSubject(this._currentStep);
    this.currentStep$ = this._currentStep$.asObservable();
  }

  public stepName(step: number) {
    for (const [name, num] of this.dataService.stepMap) {
      if (num === step) {
        return name;
      }
    }
  }

  private validateStep(step: number): boolean {
    for (const [name, stepNo] of this.dataService.stepMap) {
      if (step === stepNo) {
        return this.dataService.form[name].valid;
      }
    }
  }

  private activateStep(step: number): void {
    const rightBound = Math.min(step, this._completeSteps.length);
    const boundStep = Math.max(1, rightBound);
    this._activeSteps[boundStep - 1] = true;
  }

  private setCompleteStepState(step: number, state: boolean): void {
    const index = step - 1;
    this._completeSteps[index] = state;
    this._progress.next(this._completeSteps);
  }

  public completeStep(step: number = null): boolean {

    if (!step) {
      step = this._currentStep;
    }

    if (this.validateStep(step)) {
      this.activateStep(step + 1);
      this.setCompleteStepState(step, true);
      return true;
    }

    this.setCompleteStepState(step, false);

    for (let i = step; i < this._activeSteps.length; ++i) {
      this._activeSteps[i] = false;
    }
    return false;
  }

  public isStepActive(step: number): boolean {
    const index = step - 1;
    return !!this._activeSteps[index];
  }

  public isStepComplete(step: number): boolean {
    const index = step - 1;
    return !!this._completeSteps[index];
  }

  public setCurrentStep(step: number): void {
    const rightBound = Math.min(step, this._completeSteps.length);
    const bounds = Math.max(1, rightBound);

    if (this.isStepActive(step)) {
      this._currentStep = bounds;
      this._currentStep$.next(bounds);
    }
  }

  public goToStep(step: number) {
    const parentUrl = this.router.url.split('/');
    parentUrl.pop();
    this.router.navigate([...parentUrl, step]);
  }

  public nextStep() {
    this.currentStep$.pipe(
      take(1),
      tap((step) => {
        this.goToStep(step + 1);
      }),
    ).subscribe();
  }

  public backStep() {
    this.currentStep$.pipe(
      take(1),
      tap((step) => {
        this.goToStep(step - 1);
      }),
    ).subscribe();
  }
}
