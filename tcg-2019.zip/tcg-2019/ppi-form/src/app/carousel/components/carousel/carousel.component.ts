import { Component, OnInit, AfterViewChecked, AfterViewInit } from '@angular/core';
import { trigger, style, transition, animate, stagger, query, group, keyframes } from '@angular/animations';

import { Observable, Subscription } from 'rxjs';

import { DangerToast } from 'src/app/shared/toast/Toast';

import { DataService } from 'src/app/services/data/data.service';
import { ToastService } from 'src/app/shared/toast/services/toast.service';
import { ModalService } from 'src/app/shared/modal/services/modal.service';
import { CarouselService } from '../../services/carousel/carousel.service';

declare const addressNow: {
  disable: () => {},
  load: () => {},
  listen: (to: string, cb: (ctrl) => void) => {},
};

@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss'],
  animations: [
    trigger('initAnim', [

      transition(':enter', [

        group([
          query('.active>.carousel-item-inner', [
            style({
              transform: 'scale(0)',
            }),

            animate('350ms', style({
              transform: 'scale(1)',
            })),

          ]),
          query('.post>.carousel-item-inner', [
            style({
              transform: 'scale(0.8) translateX(100vw)',
            }),
            stagger(200, [

              animate('500ms', keyframes([
                style({
                  transform: 'scale(0.8) translateX(100vw)',
                  offset: 0.5
                }),
                style({
                  transform: 'scale(0.8) translateX(0)',
                  offset: 1
                })
              ])),
            ])
          ])
        ])

      ]),
    ])
  ]
})
export class CarouselComponent implements OnInit, AfterViewInit, AfterViewChecked {

  public initAnimation: string = 'start';
  public loading = false;

  public currentStep: number;
  public _currentStep$: Subscription;
  public currentStep$: Observable<number>;

  public cards: any[];

  constructor(
    private dataService: DataService,
    private carouselService: CarouselService,
    private modalService: ModalService,
    private toastService: ToastService,
  ) {
    this.cards = [];
    for (const [name, step] of this.dataService.stepMap) {
      this.cards.push({
        id: step,
        name
      });
    }
  }

  ngOnInit() {
    this.currentStep$ = this.carouselService.currentStep$;

    this._currentStep$ = this.carouselService
      .currentStep$
      .subscribe(step => this.currentStep = step);
  }

  ngAfterViewInit() {
    addressNow.listen('options', function (options) {
      options.bar = options.bar || {};
      options.bar.visible = false;

      options.list = options.list || {};
      options.list.width = 280;
      options.list.height = 100;

      // disable autocomplete because addressNow lacks the functionality to react to it.
      // Also, this apparently does nothing...
      options.suppressAutocomplete = true;
    });


    addressNow.listen('load', (control) => {

      control.listen('populate', (address) => {
        let form;

        switch (this.currentStep) {
          case 1:
            form = this.dataService.form.welcome;
            form.get('line1').setValue(address.Line1);
            form.get('line2').setValue(address.Line2);
            form.get('town').setValue(address.City);
            form.get('postcode').setValue(address.PostalCode);
            form.get('fullAddress').setValue(`${address.Line1}, ${address.City}, ${address.PostalCode}`);
            break;
          case this.dataService.stepMap.get('additional'):
            form = this.dataService.form.additional;
            const currentIndex = this.dataService.formAdditionalCurrentSelectedIndex;
            const formGroup = form.get('previousAddresses').at(currentIndex);
            formGroup.get('postcode').setValue(address.PostalCode, { onlySelf: true });
            formGroup.get('line1').setValue(address.Line1);
            formGroup.get('line2').setValue(address.Line2);
            formGroup.get('town').setValue(address.City);
            formGroup.get('fullAddress').setValue(`${address.Line1}, ${address.City}, ${address.PostalCode}`, { onlySelf: true });
            break;
        }
      });
    });

    addressNow.load();
  }

  ngAfterViewChecked() {
    this.initAnimation = 'end';
  }

  public isPre(index: number, currentStep: number) {
    const step = index + 1;
    return step < currentStep;
  }

  private isPost(index: number, currentStep: number) {
    const step = index + 1;
    return step > currentStep;
  }

  public itemClasses(index: number, currentStep: number) {
    const step = index + 1;
    return {
      active: step === currentStep,
      pre: step < currentStep,
      post: step > currentStep,
    };
  }

  private distance(index: number, currentStep: number) {
    const step = index + 1;
    return this.cards.length - Math.abs((currentStep - step));
  }

  private spread(index: number, currentStep: number) {
    const step = index + 1;
    const distance = Math.abs((currentStep - step)) - 1;
    return (20 * distance);
  }

  public getStyles(index: number, currentStep: number) {
    const styles = {
      zIndex: this.distance(index, currentStep)
    };

    if (this.isPre(index, currentStep)) {
      styles['marginLeft'] = -this.spread(index, currentStep) + 'px';
    }

    if (this.isPost(index, currentStep)) {
      styles['marginLeft'] = this.spread(index, currentStep) + 'px';
    }

    return styles;
  }

  trackByFn(index, item) {
    return item.id;
  }

  public next(): void {
    let errorMessage;

    switch (this.carouselService.stepName(this.currentStep)) {
      case 'history':
        errorMessage = 'Please add at least one lender to continue.';
        break;
      default:
        errorMessage = 'Please complete required fields.';
        break;
    }

    if (!this.carouselService.completeStep(this.currentStep)) {
      this.toastService.addToast(new DangerToast(errorMessage));
      return;
    } else {
      this.carouselService.nextStep();
    }
  }

  public back(): void {
    this.carouselService.backStep();
  }

}
