import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { CarouselService } from '../../services/carousel/carousel.service';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.scss']
})
export class NavComponent implements OnInit {

  links = [
    {
      route: '/welcome',
      label: 'Welcome',
      icon: 'assets/icons/about.svg',
    },
    {
      route: '/history',
      label: 'History',
      icon: 'assets/icons/history.svg',
    },
    {
      route: '/additional',
      label: 'Additional',
      icon: 'assets/icons/additional.svg',
    },
    {
      route: '/confirm',
      label: 'Confirm',
      icon: 'assets/icons/confirm.svg',
    },
    {
      route: '/sign',
      label: 'Thank You',
      icon: 'assets/icons/sign.svg',
    },
  ];

  progress$: Observable<number>;

  constructor(
    private carouselService: CarouselService,
  ) { }

  ngOnInit() {
    this.progress$ = this.carouselService.progress$;
  }

}
