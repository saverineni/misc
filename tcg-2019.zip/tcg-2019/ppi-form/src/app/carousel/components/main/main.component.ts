import { Component, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { filter, map, mergeMap, tap } from 'rxjs/operators';

import { CarouselService } from '../../services/carousel/carousel.service';


@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnDestroy {

  public currentStep: number;
  private currentStep$: Subscription;

  public loading: boolean = false;

  public title: string = 'Check Online Now';
  public description: string = 'Help us and your Lender locate your PPI by providing a small amount of information.';
  public strapline: string = 'Let us help you get your money back.';

  constructor(
    private carouselService: CarouselService,
    private router: Router,
    activatedRoute: ActivatedRoute,
  ) {
    this.router.events.pipe(
      filter(e => e instanceof NavigationEnd),
      map(() => activatedRoute),
      map(route => {
        while (route.firstChild) {
          route = route.firstChild;
        }
        return route;
      }),
      mergeMap(route => route.data),
      tap(data => {
        this.title = data.title;
        this.description = data.description;
        this.carouselService.setCurrentStep(data.step);
      }),
    ).subscribe();

    this.currentStep$ = this.carouselService
      .currentStep$
      .subscribe(step => this.currentStep = step);
  }

  ngOnDestroy(): void {
    this.currentStep$.unsubscribe();
  }


}
