import { Component, OnInit } from '@angular/core';
import { map, startWith } from 'rxjs/operators';
import { ModalService } from 'src/app/shared/modal/services/modal.service';
import { DataService } from 'src/app/services/data/data.service';
import { FinanceModalComponent } from '../../modals/finance-modal/finance-modal.component';
import { CarouselService } from '../../services/carousel/carousel.service';
import { MoreLendersModalComponent } from '../../modals/more-lenders-modal/more-lenders-modal.component';
import { DangerToast } from '../../../shared/toast/Toast';
import { ToastService } from '../../../shared/toast/services/toast.service';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.scss'],
})
export class HistoryComponent implements OnInit {

  public lenderOptions$;
  private historyForm;

  constructor(
    private modalService: ModalService,
    private dataService: DataService,
    private carouselService: CarouselService,
    private toastService: ToastService,
  ) {
  }

  ngOnInit() {
    this.historyForm = this.dataService.form.history;
    this.lenderOptions$ = this.historyForm.valueChanges
      .pipe(
        startWith(this.dataService.lenderOptions),
        map(_ => this.dataService.lenderOptions),
        map((lenderOptions: any[]) => {
          return lenderOptions.map(lenderOption => {
            return {
              ...lenderOption,
              completeCount: this.getCompleteCount(lenderOption.type),
              incompleteCount: this.getIncompleteCount(lenderOption.type),
            };
          });
        }),
      );
  }

  public getCompleteCount(type: string) {
    return this.dataService.completedLenders(this.historyForm.get(type).value).length;
  }

  public getIncompleteCount(type: string) {
    return this.dataService.incompleteLenders(this.historyForm.get(type).value).length;
  }

  showModal(type) {
    setTimeout(() => {
      this.modalService.open(FinanceModalComponent, {
        data: {
          label: type.label,
          type: type.type,
        },
      });
    }, 250);
  }

  trackByFn(opt) {
    return opt.label;
  }

  private moreLenders(): void {
    this.modalService.open(MoreLendersModalComponent);
  }

  back() {
    this.carouselService.backStep();
  }

  submit() {

    if (this.carouselService.completeStep()) {
      if (this.carouselService.hasSeenMoreLenders) {
        this.carouselService.nextStep();
      } else {
        this.moreLenders();
      }
    } else {
      this.toastService.addToast(new DangerToast('Please add at least 1 lender'));
    }
  }

}
