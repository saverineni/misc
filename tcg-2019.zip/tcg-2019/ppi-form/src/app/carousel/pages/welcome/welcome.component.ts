import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl, FormGroupDirective, NgForm } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material';

import { environment } from 'src/environments/environment';
import { BehaviorSubject } from 'rxjs';

import { DataService } from 'src/app/services/data/data.service';
import { CarouselService } from '../../services/carousel/carousel.service';
import { ToastService } from 'src/app/shared/toast/services/toast.service';
import { DangerToast } from 'src/app/shared/toast/Toast';

class CrossFieldErrorMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    return control.dirty && form.getError('missingLines');
  }
}

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.scss'],
})
export class WelcomeComponent implements OnInit {

  @ViewChild('formRef')
  formRef: FormGroupDirective;

  public loading: boolean = false;
  public errorMatcher = new CrossFieldErrorMatcher();
  public testimonial = {
    name: 'Claire',
    message: 'The Claims Guys provided a quick, efficient, knowledgeable service with minimal interaction and quick results.',
    image: 'assets/testimonial.png',
  };

  private _selects = [
    {
      label: 'Credit Cards',
      active: false,
    },
    {
      label: 'Loans',
      active: false,
    },
    {
      label: 'Store Cards',
      active: false,
    },
    {
      label: 'Catalogue Acct.',
      active: false,
    },
  ];
  public multiSelect = new BehaviorSubject(this._selects);

  public welcomeForm: FormGroup;

  constructor(
    private dataService: DataService,
    private carouselService: CarouselService,
    private toastService: ToastService,
  ) {
  }

  ngOnInit() {
    this.welcomeForm = this.dataService.form.welcome;
  }

  submit() {
    this.formRef.onSubmit(undefined);
  }

  formSubmit() {
    const formState = this.welcomeForm.value;
    if (this.welcomeForm.valid) {
      this.loading = true;
      const formatted = this.dataService.formatAsLeadXAPIRequest();

      this.dataService.postLead(formatted)
        .then(response => {

          this.loading = false;
          const data = response.resp;

          switch (data[2]) {
            case 'SUCCESS':
              this.dataService.setLeadId(data[0]);
              this.carouselService.completeStep(1);
              this.carouselService.nextStep();
              break;
            case 'DUPLICATE':
              this.carouselService.completeStep(1);
              this.carouselService.nextStep();
              break;
            case 'BLANK':
              // if(!environment.production) {
              this.carouselService.completeStep(1);
              this.carouselService.nextStep();
              // }
              break;
            case 'ERROR':
            default:
              this.toastService.addToast(new DangerToast('Something went wrong'));
              break;
          }
        })
        .catch(err => {
          this.loading = false;
          console.error(err);
        });

    } else {
      if (formState.postcode && !formState.line1) {
        this.toastService.addToast(new DangerToast('Pick an address from the dropdown.'));
      } else {
        this.toastService.addToast(new DangerToast('Please complete all fields'));
      }
    }
  }

  multiSelectToggle(position) {
    const selects = this._selects.slice(0);
    selects[position].active = !selects[position].active;
    this.multiSelect.next(selects);
  }

  trackByFn(iteration) {
    return iteration['label'];
  }

  displayAs(option) {
    return option.title;
  }

}
