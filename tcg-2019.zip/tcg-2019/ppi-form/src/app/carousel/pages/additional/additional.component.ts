import { Component, OnInit, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { FormGroup, FormGroupDirective, FormArray } from '@angular/forms';

import { Subscription } from 'rxjs';
import { filter, tap } from 'rxjs/operators';

import { DataService } from 'src/app/services/data/data.service';
import { CarouselService } from '../../services/carousel/carousel.service';
import { DangerToast } from '../../../shared/toast/Toast';
import { ToastService } from '../../../shared/toast/services/toast.service';

declare const addressNow: any;

@Component({
  selector: 'app-additional',
  templateUrl: './additional.component.html',
  styleUrls: ['./additional.component.scss'],
})
export class AdditionalComponent implements OnInit, AfterViewInit, OnDestroy {

  @ViewChild('formRef')
  formRef: FormGroupDirective;

  private currentStep$: Subscription;

  public additionalForm: FormGroup;
  public startDate: Date;
  public maxDate: Date;
  public accordions = new Array(2).fill(false);

  constructor(
    private carouselService: CarouselService,
    private dataService: DataService,
    private toastService: ToastService,
  ) {
    this.additionalForm = this.dataService.form.additional;
  }

  get addresses() {
    return this.additionalForm.get('previousAddresses') as FormArray;
  }

  ngOnInit() {
    const maxDate = new Date();
    maxDate.setFullYear(maxDate.getFullYear() - 18);
    this.maxDate = maxDate;

    const startDate = new Date();
    startDate.setFullYear(startDate.getFullYear() - 45);
    this.startDate = startDate;
  }

  ngAfterViewInit() {

  }

  ngOnDestroy() {
    this.currentStep$.unsubscribe();
  }


  addAddress() {
    this.addresses.push(
      this.dataService.buildAddress(),
    );
    setTimeout(() => {
      // WARNING: THERE IS NO GUARANTEE THIS WILL WORK.
      // THERE IS NO WAY OF KNOWING WHEN ANGULAR'S RENDER CYCLE/DOM UPDATE HAS COMPLETED HERE.
      // addressNow Requires this method because it has no programatic way of declaring new fields.
      addressNow.load();
    }, 250);
  }

  setCurrentAddressGroup(i) {
    // This does work for addressNow to reload every time an input gets focus.
    // BUT... IT BREAKS ADDRESSNOW WHEN THERE ARE MULTIPLE STEPS
    // addressNow.load();
    this.dataService.formAdditionalCurrentSelectedIndex = i;
  }

  toggleAccordion(index: number) {
    this.accordions[index] = !this.accordions[index];
  }

  trackByFn(index, item) {
    return item.postcode;
  }

  back() {
    this.carouselService.backStep();
  }

  handleSubmit() {
    if (this.carouselService.completeStep()) {
      this.carouselService.nextStep();
    } else {
      this.toastService.addToast(new DangerToast('Please enter your Date of Birth'));
    }
  }

  submit() {
    this.formRef.onSubmit(undefined);
  }

}
