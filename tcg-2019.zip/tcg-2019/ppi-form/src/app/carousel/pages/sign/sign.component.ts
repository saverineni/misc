import { Component, OnInit, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { FormGroup, FormGroupDirective } from '@angular/forms';

import { Subscription } from 'rxjs';
import { environment } from 'src/environments/environment';

import { DataService } from 'src/app/services/data/data.service';
import { ModalService } from 'src/app/shared/modal/services/modal.service';
import { CarouselService } from '../../services/carousel/carousel.service';
import { InfoComponent } from 'src/app/modals/info/info.component';
import { DangerToast, SuccessToast } from '../../../shared/toast/Toast';
import { ToastService } from '../../../shared/toast/services/toast.service';

@Component({
  selector: 'app-sign',
  templateUrl: './sign.component.html',
  styleUrls: ['./sign.component.scss'],
})
export class SignComponent implements OnInit, AfterViewInit, OnDestroy {

  @ViewChild('formRef')
  formRef: FormGroupDirective;

  public client = environment.client;
  public signForm: FormGroup;
  public loading: boolean = false;

  private confirmCtrl;
  public confirmed: boolean = false;
  private keyFactsConfirmCtrl;
  public keyFactsConfirmed: boolean = false;
  private currentStep$: Subscription;

  public tips: string[] = [
    'Sign using your finger or stylus',
    'Keep it fully contained within the box',
    'Ensure it is a true likeness of your signature',
  ];

  constructor(
    private dataService: DataService,
    private carouselService: CarouselService,
    private modalService: ModalService,
    private toastService: ToastService,
  ) {
    this.signForm = this.dataService.form.sign;
    this.confirmCtrl = this.dataService.form.sign.get('confirm');
    this.confirmCtrl.valueChanges.subscribe(val => {
      this.confirmed = !!parseInt(val, 10);
    });
    this.keyFactsConfirmCtrl = this.dataService.form.sign.get('keyFactsConfirm');
    this.keyFactsConfirmCtrl.valueChanges.subscribe(val => {
      this.keyFactsConfirmed = !!parseInt(val, 10);
    });
  }

  toggleConfirm() {
    const confirmCtrl = this.confirmCtrl;
    if (confirmCtrl.value === '0') {
      this.modalService.open(InfoComponent);
    }
    confirmCtrl.setValue(confirmCtrl.value === '1' ? '0' : '1');
  }

  toggleKeyFactsConfirm() {
    const keyFactsConfirmCtrl = this.keyFactsConfirmCtrl;

    keyFactsConfirmCtrl.setValue(keyFactsConfirmCtrl.value === '1' ? '0' : '1');
  }

  back() {
    this.carouselService.backStep();
  }

  handleSubmit() {
    if (this.carouselService.completeStep()) {
      const formatted = this.dataService.formatAsLeadXAPIRequest();

      this.dataService.postLead(formatted)
        .then(response => {
          const data = response.resp;
          this.loading = false;
          if (data[2] === 'SUCCESS' && response.stage === 3) {
            if (!response.signature_url) {
              this.toastService.addToast(new DangerToast('Something went wrong while trying to contact DocuSign'));
              console.log(response);
              return false;
            }
            this.toastService.addToast(new SuccessToast('Success!'));
            // docusign...
            window.location.href = response.signature_url;
          } else {
            this.toastService.addToast(new DangerToast('Something went wrong!'));
          }
        })
        .catch(err => {
          console.error(err);
        });

      this.loading = true;
    } else {
      this.toastService.addToast(new DangerToast('Email and Acceptance required'));

    }
  }

  submit() {
    this.formRef.onSubmit(undefined);
  }

  ngOnInit() {
  }

  ngAfterViewInit() {

  }

  ngOnDestroy() {
    this.currentStep$.unsubscribe();
  }

  openInfoModal() {
    this.modalService.open(InfoComponent);
  }

}
