import { Component, OnInit } from '@angular/core';

import { Moment } from 'moment';
import { tap, startWith, map } from 'rxjs/operators';

import { ModalService } from 'src/app/shared/modal/services/modal.service';
import { DataService } from 'src/app/services/data/data.service';
import { CarouselService } from '../../services/carousel/carousel.service';
import { FinanceModalComponent } from '../../modals/finance-modal/finance-modal.component';

@Component({
  selector: 'app-confirm',
  templateUrl: './confirm.component.html',
  styleUrls: ['./confirm.component.scss'],
})
export class ConfirmComponent implements OnInit {

  public applicant;

  public lenderOptions$;
  public currentStep$;
  public activeStep;

  constructor(
    private modalService: ModalService,
    private dataService: DataService,
    private carouselService: CarouselService,
  ) {
  }

  ngOnInit() {
    this.applicant = {};
    this.currentStep$ = this.carouselService.currentStep$
      .pipe(
        tap(_ => {
          this.activeStep = false;
        }),
      )
      .subscribe(step => {
        if (step === this.dataService.stepMap.get('confirm')) {
          this.activeStep = true;
          const form = this.dataService.form;
          this.applicant = {
            ...form.welcome.value,
            // ...form.details.value,
            ...form.additional.value,
          };
        }
      });

    this.lenderOptions$ = this.dataService.form.history.valueChanges
      .pipe(
        startWith(this.dataService.lenderOptions),
        map(_ => this.dataService.lenderOptions),
        map((lenderOptions: any[]) => {
          return lenderOptions.map(lenderOption => {
            return {
              ...lenderOption,
              typeCount: this.getTypeCount(lenderOption.type),
              incompleteCount: this.getIncompleteCount(lenderOption.type),
            };
          });
        }),
      );
  }

  dob(dob: Moment) {
    return dob.format('DD/MM/YYYY');
  }

  public getTypeCount(type: string) {
    return this.dataService.completedLenders(this.dataService.form.history.get(type).value).length;
  }

  public getIncompleteCount(type: string) {
    return this.dataService.incompleteLenders(this.dataService.form.history.get(type).value).length;
  }

  showModal(type) {
    this.modalService.open(FinanceModalComponent, {
      data: {
        label: type.label,
        type: type.type,
      },
    });
  }

  trackByFn(opt) {
    return opt.label;
  }

  back() {
    this.carouselService.backStep();
  }

  submit() {
    if (this.carouselService.completeStep()) {
      this.carouselService.nextStep();
    }
  }

}
