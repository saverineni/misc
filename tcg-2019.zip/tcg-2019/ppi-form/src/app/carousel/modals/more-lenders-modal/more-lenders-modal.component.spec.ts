import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MoreLendersModalComponent } from './more-lenders-modal.component';

describe('MoreLendersModalComponent', () => {
  let component: MoreLendersModalComponent;
  let fixture: ComponentFixture<MoreLendersModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MoreLendersModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MoreLendersModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
