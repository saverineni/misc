import { Component, OnInit } from '@angular/core';

import { ModalRemote } from 'src/app/shared/modal/remote/modal.remote';
import { DataService } from 'src/app/services/data/data.service';
import { ToastService } from 'src/app/shared/toast/services/toast.service';
import { CarouselService } from '../../services/carousel/carousel.service';
import { DangerToast } from 'src/app/shared/toast/Toast';

@Component({
  selector: 'app-more-lenders-modal',
  templateUrl: './more-lenders-modal.component.html',
  styleUrls: ['./more-lenders-modal.component.scss']
})
export class MoreLendersModalComponent implements OnInit {

  constructor(
    private remote: ModalRemote,
    private dataService: DataService,
    private carouselService: CarouselService,
    private toastService: ToastService
  ) { }

  ngOnInit() {
    this.carouselService.hasSeenMoreLenders = true;
  }

  addLenders() {
    this.remote.close();
  }

  nextPage() {
    this.remote.close();

    if (this.carouselService.completeStep(this.dataService.stepMap.get('history'))) {
      this.carouselService.nextStep();
    } else {
      this.toastService.addToast(new DangerToast('At least 1 lender is required'));
    }
  }

}
