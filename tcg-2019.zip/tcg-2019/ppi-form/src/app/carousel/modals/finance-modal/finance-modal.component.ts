import {
  AfterViewInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  Inject,
  OnInit,
  ViewChild,
} from '@angular/core';
import { AbstractControl, FormArray, FormControl, FormGroup } from '@angular/forms';

import { BehaviorSubject, Observable } from 'rxjs';
import { map, mergeMap, startWith } from 'rxjs/operators';

import { DataService } from 'src/app/services/data/data.service';
import { ModalRemote } from 'src/app/shared/modal/remote/modal.remote';
import { MODAL_DATA } from 'src/app/shared/modal/modal.tokens';

interface FinanceModalData {
  label: string;
  type: string;
}

@Component({
  selector: 'app-finance-modal',
  templateUrl: './finance-modal.component.html',
  styleUrls: ['./finance-modal.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FinanceModalComponent implements OnInit, AfterViewInit {

  @ViewChild('scrollCheck')
  public scrollCheck;

  @ViewChild('scrollList')
  public elementList;

  private choices = [
    {
      label: 'Yes',
      value: '0',
    },
    {
      label: 'No',
      value: '1',
    },
    {
      label: 'Don\'t Know',
      value: '2',
    },
  ];

  public SOPtions = [
    {
      label: 'Did you take PPI out on this agreement?',
      selected: '',
      choices: this.choices,
    },
    {
      label: 'Were you told that your loan/credit application was more likely to be accepted if you took PPI?',
      selected: '',
      choices: this.choices,
    },
    {
      label: 'Were the costs of the PPI explained to you?',
      selected: '',
      choices: this.choices,
    },
  ];

  private type: string;
  private lenderArrayCtrl: AbstractControl;

  public title: string;

  private _hasScroll$: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public hasScroll$: Observable<any> = this._hasScroll$.asObservable();

  public lenders$: Observable<{ id: string, label: string, active: number, checks: any[] }[]>;

  public otherGroup: FormGroup = new FormGroup({
    other: new FormControl(''),
  });

  constructor(
    private dataService: DataService,
    private cdr: ChangeDetectorRef,
    private remote: ModalRemote,
    @Inject(MODAL_DATA) public data: FinanceModalData,
  ) {
  }

  ngOnInit() {
    this.title = this.data.label;
    this.type = this.data.type;
    this.lenderArrayCtrl = this.dataService.form.history
      .get(this.type);

    this.lenders$ = this.dataService.lenders$
      .pipe(
        map((allLenderTypes: Map<string, Map<string, string>>) => {
          return Array
            .from(
              allLenderTypes
                .get(this.type),
            )
            .sort((a, b) => a[0] < b[0] ? -1 : 1);
        }),
        mergeMap(filteredLenders => {
          return this.lenderArrayCtrl
            .valueChanges.pipe(
              startWith(this.lenderArrayCtrl.value),
              map(selectedLenders => {
                return filteredLenders.map(([lender, id]) => {
                  const groupCtrl: any = selectedLenders
                    .find((group: any) => {
                      return group.label === lender;
                    });

                  return {
                    id: id,
                    label: lender,
                    checks: this.SOPtions.slice(0).map((option, i) => {
                      return {
                        ...option,
                        selected: groupCtrl.checks[i],
                      };
                    }),
                    active: Math.min(
                      (groupCtrl.checks.length - 1),
                      (groupCtrl.checks.map(check => check.length > 0).lastIndexOf(true) + 1),
                    ),
                  };
                });
              }),
            );
        }),
      );
  }

  public ngAfterViewInit() {
    // const el = this.scrollCheck.nativeElement;
    // const scrollH = el.scrollHeight;
    // const clientH = el.clientHeight;
    // console.log('change', scrollH, clientH);
    // scrollH > clientH
    //   this._hasScroll$.next(true);
    //   this.cdr.detectChanges();
  }

  public scrollToBottom() {
    const el = this.scrollCheck.nativeElement;
    el.scroll({
      top: el.scrollHeight,
      behavior: 'smooth',
      block: 'end',
    });
  }

  public scrollToIndex(index: number) {
    const el = this.elementList.nativeElement.children[index];
    setTimeout(() => {
      el.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
      });
    }, 100);
  }

  public handleClick(index) {
    this.scrollToIndex(index);
  }

  // public get hasScroll() {
  //   const el = this.scrollCheck.nativeElement;
  //   const scrollH = el.scrollHeight;
  //   const clientH = el.clientHeight;
  //   console.log('change', scrollH, clientH);
  //   return scrollH > clientH;
  // }

  trackByFn(index, item) {
    return item.label;
  }

  close() {
    this.remote.close();
  }

  handleSelect(event, lender) {
    this.SOPtions[event.position].selected = event.value;
    const lenderCtrl = (<FormArray>this.lenderArrayCtrl).controls.find(control => control.value.label === lender.label);
    (<FormGroup>(<FormArray>lenderCtrl.get('checks')).at(event.position)).setValue(event.value);
  }

  addOther() {
    const val = this.otherGroup.value.other;
    if (val.length > 1) {
      this.dataService.addOtherLender(val, this.type);
      this.otherGroup.patchValue({ other: '' });
      requestAnimationFrame(() => {
        this.scrollToBottom();
      });
    }
  }

}
