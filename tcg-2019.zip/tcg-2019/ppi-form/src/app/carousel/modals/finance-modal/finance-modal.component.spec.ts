import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinanceModalComponent } from './finance-modal.component';

describe('FinanceModalComponent', () => {
  let component: FinanceModalComponent;
  let fixture: ComponentFixture<FinanceModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinanceModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinanceModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
