import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WelcomeComponent } from './pages/welcome/welcome.component';
import { HistoryComponent } from './pages/history/history.component';
import { AdditionalComponent } from './pages/additional/additional.component';
import { ConfirmComponent } from './pages/confirm/confirm.component';
import { SignComponent } from './pages/sign/sign.component';
import { IsCompleteGuard } from './guards/isComplete/is-complete.guard';
import { MainComponent } from './components/main/main.component';

const routes: Routes = [
  {
    path: '',
    component: MainComponent,
    children: [
      {
        path: 'welcome',
        component: WelcomeComponent,
        data: {
          step: 1,
          title: 'Check Online Now',
          description: 'Help us and your Lender locate your PPI by providing a small amount of information.',
        },
      },
      {
        path: 'history',
        component: HistoryComponent,
        canActivate: [IsCompleteGuard],
        data: {
          step: 2,
          title: 'Your Money',
          description: 'Tell us all of the companies you may have used. The more you select, the more we can check.',
        },
      },
      {
        path: 'additional',
        component: AdditionalComponent,
        canActivate: [IsCompleteGuard],
        data: {
          step: 3,
          title: 'More About You',
          description: 'We just need a couple more details and then we\'re almost done.',
        },
      },
      {
        path: 'confirm',
        component: ConfirmComponent,
        canActivate: [IsCompleteGuard],
        data: {
          step: 4,
          title: 'Double Check',
          description: 'Just check your details and tap \'Next\'.',
        },
      },
      {
        path: 'sign',
        component: SignComponent,
        canActivate: [IsCompleteGuard],
        data: {
          step: 5,
          title: 'Almost There',
          description: ' We\'re sending you to a page so that you can sign the form and then we can progress your PPI Check.',
        },
      },

      // alias routes to make switching steps easier
      {
        path: '1',
        redirectTo: 'welcome',
      },
      {
        path: '2',
        redirectTo: 'history',
      },
      {
        path: '3',
        redirectTo: 'additional',
      },
      {
        path: '4',
        redirectTo: 'confirm',
      },
      {
        path: '5',
        redirectTo: 'sign',
      },
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CarouselRoutingModule { }
