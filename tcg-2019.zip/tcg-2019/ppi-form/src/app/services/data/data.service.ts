import { Injectable } from '@angular/core';
import { FormGroup, FormControl, Validators, FormGroupDirective, FormArray } from '@angular/forms';

import { BehaviorSubject, of } from 'rxjs';
import { delay } from 'rxjs/operators';

import { environment } from 'src/environments/environment';

import { isPhoneNumber, fullAddress, requireOne, inFormArray, completeSOP } from 'src/lib/validators';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  public stepMap = new Map([
    ['welcome', 1],
    ['history', 2],
    ['additional', 3],
    ['confirm', 4],
    ['sign', 5],
  ]);

  private _lendersMap = new Map([
    ['loans', new Map([
      ['Barclays', '397'],
      ['Clydesdale Bank', '437'],
      ['Cooperative Bank', '440'],
      ['First Direct', '462'],
      ['Halifax', '481'],
      ['HSBC', '492'],
      ['Lloyds TSB', '510'],
      ['NatWest', '549'],
      ['Northern Rock', '556'],
      ['Welcome Finance', '616'],
      ['Yorkshire Bank', '620'],
    ])],
    ['creditCards', new Map([
      ['Bank of Scotland', '396'],
      ['Barclaycard', '629'],
      ['Capital One', '420'],
      ['Egg', '456'],
      ['Halifax', '481'],
      ['HSBC', '696'],
      ['Lloyds TSB', '510'],
      ['Marks & Spencer', '529'],
      ['MBNA', '532'],
      ['NatWest', '698'],
      ['Royal Bank of Scotland', '697'],
    ])],
    ['storeCards', new Map([
      ['Argos', '626'],
      ['Debenhams', '742'],
      ['Evans', '744'],
      ['Next', '554'],
      ['Santander Store Cards', '693'],
    ])],
    ['catalogueAccounts', new Map([
      ['JD Williams/N Brown', '794'],
      ['Littlewoods', '761'],
      ['Very Home Shopping', '767'],
    ])]
  ]);

  private _lenders = new BehaviorSubject(
    this._lendersMap
  );
  public lenders$ = this._lenders.asObservable();

  public formAdditionalCurrentSelectedIndex = 0;

  public form = {
    lead: new FormGroup({
      id: new FormControl(null),
    }),
    welcome: new FormGroup({
      forename: new FormControl('', [Validators.required]),
      surname: new FormControl('', [Validators.required]),
      number: new FormControl('', [isPhoneNumber]),
      fullAddress: new FormControl('', [Validators.required]),
      postcode: new FormControl('', [Validators.required]),
      line1: new FormControl('', [Validators.required]),
      line2: new FormControl(''),
      town: new FormControl('', [Validators.required]),
    }, { validators: fullAddress }),
    history: new FormGroup({
      loans: new FormArray([]),
      creditCards: new FormArray([]),
      storeCards: new FormArray([]),
      catalogueAccounts: new FormArray([]),
    },
      requireOne(inFormArray(completeSOP))
    ),
    additional: new FormGroup({
      dob: new FormControl('', [Validators.required]),
      previousSurname: new FormControl(''),
      previousAddresses: new FormArray([]),
    }),
    confirm: {
      valid: true,
    },
    keyFactsConfirm: {
      valid: true,
    },
    sign: new FormGroup({
      email: new FormControl('', [Validators.required, Validators.email]),
      confirm: new FormControl('0', [Validators.required, Validators.min(1)]),
      keyFactsConfirm: new FormControl('0', [Validators.required, Validators.min(1)]),
    }),
  };

  public lenderOptions = [
    {
      label: 'Loans',
      type: 'loans',
      active: false,
    },
    {
      label: 'Credit Cards',
      type: 'creditCards',
      active: false,
    },
    {
      label: 'Store Cards',
      type: 'storeCards',
      active: false,
    },
    {
      label: 'Catalogue Accounts',
      type: 'catalogueAccounts',
      active: false,
    },
  ];

  constructor() {
    this.initLenders();

  }

  public setLeadId(id: number): void {
    this.form.lead.patchValue({ id: id });
  }

  private initLenders() {
    for (const [type, list] of this._lendersMap) {
      for (const [name, id] of Array.from(list)) {
        this.addLender(type, name, id, ['', '', '']);
      }
    }
  }

  public addLender(lenderType: string, lenderName: string, lenderId: string, checks: string[]) {
    const lender: FormArray = this.form.history.get(lenderType) as FormArray;

    lender.push(new FormGroup({
      id: new FormControl(lenderId),
      label: new FormControl(lenderName),
      checks: new FormArray(
        checks.map(check => {
          return new FormControl(check);
        })
      ),
    }));
  }

  public addOtherLender(name: string, type: string) {
    this.addLender(type, name, null, ['', '', '']);
    this._lendersMap.get(type).set(name, '0');
    this._lenders.next(
      this._lendersMap
    );
  }

  public buildAddress() {
    return new FormGroup({
      postcode: new FormControl(''),
      line1: new FormControl(''),
      line2: new FormControl(''),
      town: new FormControl(''),
      fullAddress: new FormControl(''),
    });
  }

  private getLenderTypePretty(formType: string) {
    const types = new Map([
      ['loans', 'loan'],
      ['creditCards', 'credit card'],
      ['storeCards', 'store card'],
      ['catalogueAccounts', 'catalogue loan'],
    ]);

    return types.get(formType);
  }

  private getLenderId(lenderName: string, lenderType: string): string | boolean {
    const lenderCategory = this._lendersMap.get(lenderType);
    return lenderCategory.get(lenderName);
  }

  private isCompleteLender(lender) {
    return lender.checks.every(check => check.length > 0);
  }

  public completedLenders(lenders) {
    return (<any[]>lenders).filter(this.isCompleteLender);
  }

  public incompleteLenders(lenders) {
    return (<any[]>lenders).filter(lender => lender.checks.some(check => check.length > 0) && !this.isCompleteLender(lender));
  }

  private formatAgreements(history): any[] {
    const agreements = [];

    Object.entries(history).forEach(([type, lenders]) => {
      const lenderTypePretty = this.getLenderTypePretty(type);
      const actionedLenders = this.completedLenders(lenders);

      for (const lender of actionedLenders) {
        const SOPs = lender.checks.map(check => {
          switch (parseInt(check, 10)) {
            case 0:
              return 'yes';
              break;
            case 1:
              return 'no';
              break;
            case 2:
              return 'unsure';
              break;
          }
        });

        agreements.push({
          lenderId: lender.id,
          lenderName: lender.label,
          typeOfCredit: lenderTypePretty,
          sop1: SOPs[0],
          sop2: SOPs[1],
          sop3: SOPs[2],
        });
      }
    });

    return agreements;
  }

  private isMobile(number: string) {
    return /^(\+\d{2,3}|0)7\d{9}$/.exec(number) !== null;
  }

  public formatAsLeadXAPIRequest() {
    const lead = this.form.lead.value;
    const welcome = this.form.welcome.value;
    const history = this.form.history.value;
    const additional = this.form.additional.value;
    const sign = this.form.sign.value;

    const isMobile = this.isMobile(welcome.number);

    return {
      leadId: lead.id,
      claimant: {
        forename: welcome.forename,
        surname: welcome.surname,
        previousSurname: additional.previousSurname,
        dob: additional.dob ? additional.dob.format('DD/MM/YYYY') : '',
        email: sign.email,
        mobileTelephone: isMobile ? welcome.number : null,
        homeTelephone: !isMobile ? welcome.number : null,
      },
      address: {
        thoroughfare: welcome.line1,
        dependentLocality: welcome.line2,
        town: welcome.town,
        postcode: welcome.postcode,
      },
      previousAddresses: additional.previousAddresses.map(address => {
        return {
          thoroughfare: address.line1,
          dependentLocality: address.line2,
          town: address.town,
          postcode: address.postcode,
        };
      }),
      agreements: this.formatAgreements(history)
    };
  }

  postLead(lead): Promise<any> {
    if (!environment.production) {
      return of({ stage: -1, resp: [-1, '', 'SUCCESS'] })
        .pipe(
          delay(1000)
        ).toPromise();
    }

    return fetch(environment.postURL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(lead),
    }).then(response => {
      return response.json();
    });
  }
}
