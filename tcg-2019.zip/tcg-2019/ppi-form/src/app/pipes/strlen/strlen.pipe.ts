import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'strlen'
})
export class StrlenPipe implements PipeTransform {

  transform(items: any, filter?: any): any {
    if (!items) {
      return items;
    }
    return items.filter( item => item[filter || Object.keys(item)[0]].length > 0);
  }

}
