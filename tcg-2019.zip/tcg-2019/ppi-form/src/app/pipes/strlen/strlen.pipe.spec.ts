import { StrlenPipe } from './strlen.pipe';

describe('StrlenPipe', () => {
  it('create an instance', () => {
    const pipe = new StrlenPipe();
    expect(pipe).toBeTruthy();
  });
});
