import { ValidatorFn, FormGroup, ValidationErrors, AbstractControl, FormArray } from '@angular/forms';

export const requireOne = (validator: ValidatorFn, controls: string[] = null) => (
    group: FormGroup,
): ValidationErrors | null => {
    if (!controls) {
        controls = Object.keys(group.controls);
    }

    const hasAtLeastOne = group && group.controls && controls
        .some(k => !validator(group.controls[k]));

    return hasAtLeastOne ? null : {
        atLeastOne: true,
    };
};

export const inFormArray = (validator: ValidatorFn, controls: string[] = null) => (
    formArray: FormArray,
): ValidationErrors | null => {

    const hasAtLeastOne = formArray && formArray.controls
        .some((k, i) => !validator(formArray.controls[i]));

    return hasAtLeastOne ? null : {
        atLeastOne: true,
    };
};

export const fullAddress: ValidatorFn = (control: FormGroup): ValidationErrors | null => {
    const address = [
        control.get('postcode'),
        control.get('line1'),
        control.get('town'),
    ];

    return address.every(line => line.valid) ? null : { 'missingLines': true };
};

export const isPhoneNumber: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
    if (control.value === "") {
        return null;
    }
    const numRe: RegExp = /^(\+44|0)\d{10}$/;
    const isNum = numRe.test(control.value.replace(' ', ''));
    return !isNum ? { 'notNumber': { value: control.value } } : null;
};

export const completeSOP: ValidatorFn = (control: FormGroup): ValidationErrors | null => {
    const everyCheck = control.value.checks && control.value.checks.every(check => check.length > 0);
    return everyCheck ? null : { 'incompleteSOP': { value: control.value } };
};
