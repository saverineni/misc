const path = require('path');
const fs = require('fs');
const util = require('util');
const cp = require('child_process');

const exec = util.promisify(cp.exec);
const readdir = util.promisify(fs.readdir);
const lstat = util.promisify(fs.lstat);
const unlink = util.promisify(fs.unlink);
const rmdir = util.promisify(fs.rmdir);
const mkdir = util.promisify(fs.mkdir);
const copyFile = util.promisify(fs.copyFile);


let FLAGS;

const builds = [
    {
        name: 'claimsguys',
        out: path.normalize(__dirname + '/../online_assessment/'),
    },
    {
        name: 'claimsguys2',
        out: path.normalize(__dirname + '/../online_assessment/'),
    },
];

const serverPath = path.normalize(__dirname + '/server/');


function flags() {
    const flags = {
        silent: false,
        build: true,
    }
    const argsIn = process.argv.slice(2);
    if (argsIn.indexOf('--silent') !== -1) {
        flags.silent = true;
    }
    if (argsIn.indexOf('--no-build') !== -1) {
        flags.build = false;
    }
    return flags;
}

async function buildSrc(configuration) {
    if(!FLAGS.silent) {
        console.log('Building...');
    }
    const { stdout, stderr } = await exec(`cd ppi-form && npx ng build --configuration=${configuration}`);
    if(!FLAGS.silent) {
        console.log('stdout:', stdout);
        console.log('stderr:', stderr);
    }
}

async function copyDir(src, dest) {

    const entries = await readdir(src, { withFileTypes: true });

    await mkdir(dest);
    for (let entry of entries) {
        const entryName = typeof entry === 'string' ? entry : entry.name;
        const srcPath = path.join(src, entryName);
        const destPath = path.join(dest, entryName);
        if (entry.isDirectory()) {
            await copyDir(srcPath, destPath);
        } else {
            await copyFile(srcPath, destPath);
            if (!FLAGS.silent) {
                console.log(`Copied: ${srcPath.replace(__dirname, '')}`);
            }
        }
    }
}

async function removeDir(dir) {
    try {
        const files = await readdir(dir);
        await Promise.all(files.map(async (file) => {
            try {
                const p = path.join(dir, file);
                const stat = await lstat(p);
                if (stat.isDirectory()) {
                    await removeDir(p);
                } else {
                    await unlink(p);
                    if (!FLAGS.silent) {
                        console.log(`Removed file ${p.replace(__dirname, '')}`);
                    }
                }
            } catch (err) {
                console.error(err);
            }
        }));
        await rmdir(dir);
        if (!FLAGS.silent) {
            console.log(`Removed dir ${dir.replace(__dirname, '')}`);
        }
    } catch (err) {
        console.error(err);
    }
}

async function installDependencies () {
    const { stdout, stderr } = await exec(`cd ppi-form && npm install`);

    if(!FLAGS.silent) {
        console.log('stdout:', stdout);
        console.log('stderr:', stderr);
    }
}

function checkRuntimeVersion () {
    const nodeVersion = process.version.slice(1).split('.')[0];

    if (Number(nodeVersion) < 10) {
        throw new Error('Node version required for build process must be v10 or greater');
    }
}

async function main() {
    FLAGS = flags();
    
    checkRuntimeVersion();

    await installDependencies();

    for(const build of builds) {
        const buildPath = path.normalize(`${__dirname}/ppi-form/dist/${build.name}/`)

        try {
            if (FLAGS.build) {
                await buildSrc(build.name);
            }
            await removeDir(build.out);
            await copyDir(buildPath, build.out);
            await copyDir(serverPath, build.out + 'post');
        } catch (err) {
            console.log(err);
        }
    }
}

main();