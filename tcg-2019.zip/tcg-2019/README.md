# PPI Form
This is the build point for this project.

`cd` here and run `node prepare` to build and copy files to their serving directory.

This requires node.js to be installed and added to $PATH

## Build
To build everything ready for deployment there is a script next to this readme called `prepare.js`.

Run `node prepare move` to build the dist files in `ppi-guys/dist` and automatically copy the output dist files into the online_assessment folder.

If you run `node prepare` you do not need to to run `ng build` in the ppi-form directory. However, if you want to skip the front-end build steps and prepare quickly (e.g. if only making changes to the server files) run `node prepare --no-build`.

To ignore output run `node prepare --silent`.

## Structure
Folder contains `ppi-form` and `server`. 

### ppi-form
Contains the src and distribution files for the front-end.

The `dist/` folder contains the builds `testguys`, `claimsguys` and `ppiguys`.

`src` folder contains the relevant source files. Development happens here.

### server
Contains server files that generate the lead and docusign URLs.

`index.php` is the main entrypoint.

`models.php` contains the Objects used to parse and build the Lead object and querystring. 
