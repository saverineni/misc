import { browser } from 'protractor';

export class BrowserCache {

  clearLocalStorage() {
    browser.executeScript('localStorage.clear();');
  }

  makeTokenInvalid() {
    browser.executeScript("localStorage.setItem('currentUser', 'invalid token');");
  }

}
