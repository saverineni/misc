import { browser, by, element, ExpectedConditions } from 'protractor';
import { DeclarationSearchPage } from './declarationsearch/declarationsearch.po';
import { SignInPage } from './sign-in.po';
import { UserDetails } from './user-details.po';

export class SignInScenario {

  givenUserIsSignedIn() {
    const searchPage = new DeclarationSearchPage();
    const signInPage = new SignInPage();

    return searchPage.navigateTo()
      .then(() => signInPage.isCurrentPage())
      .then((isNotSignedIn) => {
        if (isNotSignedIn) {
          signInPage.completeSignInFormWithValidUser();
        }
      });
  }

  givenUserIsNotSignedIn() {
    const searchPage = new DeclarationSearchPage();
    const signInPage = new SignInPage();

    return searchPage.navigateTo()
      .then(() => searchPage.isCurrentPage())
      .then((isSignedIn) => {
        if (isSignedIn) {
          new UserDetails().signOut();
        }
      });
  }

}
