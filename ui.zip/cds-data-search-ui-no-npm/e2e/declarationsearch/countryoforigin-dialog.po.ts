import {browser, by, element} from "protractor";

export class CountryOfOriginDialogPage {
  isCurrentDialog() {
    return element(by.css('.mat-dialog-container')).isPresent();
  }

  getDialogTitle() {
    return element(by.css('.mat-dialog-title')).getText()
  }

  clickCancel() {
    return this.getCancelFilter().click();
  }

  clickApplyFilters() {
    return this.getApplyFilter().click();
  }

  isDialogCancelActionPresent() {
    return this.getCancelFilter().isPresent();
  }

  isDialogApplyFilterActionPresent() {
    return this.getApplyFilter().isPresent();
  }


  countryListCount() {
    return element.all(by.css('.mat-list-item')).count();
  }

  countrySelectedListCount() {
    return element.all(by.css('input[aria-checked="true"]')).count();
  }

  chipSelectedListCount() {
    return element.all(by.css('mat-chip')).count();
  }

  countryList() {
    return element.all(by.css('.mat-list-item')).getText();
  }

  selectCountryOfOrigin(countryCode) {
    return this.getCheckbox(countryCode).click().then(() => browser.waitForAngular());
  }

  clickChip(countryCode) {
    return element(by.css('.country-origin-chip__content__' + countryCode + ' .mat-chip-remove')).click().then(() => browser.waitForAngular());
    // return this.getChip(countryCode).click();
  }

  isCountryOfOriginChipPresent(countryCode) {
    return this.getChip(countryCode).isPresent();
  }

  isCountryOfOriginChecked(country_code) {
    return element(by.css('.country-origin-filter__content__' + country_code + ' input')).getAttribute("aria-checked");
  }

  private getCancelFilter() {
    return element(by.css('.country-origin__cancel .mat-button-wrapper'));
  }

  private getApplyFilter() {
    return element(by.css('.country-origin__apply-filters .mat-button-wrapper'));
  }

  private getCountryListSelector() {
    return element(by.css('.country-origin-filter__content'));
  }

  private getCheckbox(countryCode) {
    return element(by.css('.country-origin-filter__content__' + countryCode + ' .mat-checkbox-inner-container'));
  }

  private getChip(countryCode) {
    return element(by.css('.country-origin-chip__content__' + countryCode));
  }

}
