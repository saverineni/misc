import { browser, by, element, ElementFinder } from 'protractor';
import { DeclarationElement } from './DeclarationElement';

export class DeclarationSearchPage {
  navigateTo() {
    return browser.get('/');
  }

  isCurrentPage() {
    return element(by.css('.search-section')).isPresent();
  }

  search(searchTerm: string) {
    return this.typeIntoSearchTermField(searchTerm)
      .then(() => this.clickSearchButton());
  }

  typeIntoSearchTermField(searchTerm: string) {
    return this.getDeclarationField().sendKeys(searchTerm);
  }

  getDeclarationSearchFieldText() {
    return this.getDeclarationField().getAttribute('value');
  }

  isDeclarationSearchFieldFocused() {
    return browser.driver.switchTo().activeElement().getAttribute('name')
      .then((fieldname) => fieldname === 'freeText');
  }

  private getDeclarationField() {
    return element(by.css('.search-form__freetext-input'));
  }

  clickSearchButton() {
    return element(by.css(".search-form__button")).click();
  }

  clickHeaderExpansionPanel(row: number) {
    return element.all(by.css('.search-results-expansion-panel__header')).get(row).click();
  }

  isNoResultsFound() {
    return element(by.css('.no-search-results')).isPresent();
  }

  getResultsFoundMessage() {
    return element(by.css('.search-results-message')).getText();
  }

  getNoResultsFoundMessage() {
    return element(by.css('.no-search-results')).getText();
  }

  isResultsDisplayed() {
    return element(by.css('.search-results-cards')).isPresent();
  }

  isFiltersSectionDisplayed() {
    return element(by.css('.search-filter-section')).isPresent();
  }

  private getCountryOfOriginFilter() {
    return element(by.css('.search-filter__country-of-origin'));
  }

  isCountryOfOriginFilterDisplayed() {
    return this.getCountryOfOriginFilter().isPresent();
  }

  getItemCount(row: number) {
    return element.all(by.css('.search-results-expansion-panel__item-count')).get(row).getText();
  }

  getDeclarationElement(row: number): DeclarationElement {
    return new DeclarationElement(element.all(by.css('.search-results-cards__declarations')).get(row));
  }

  whenISearchFor(searchTerm: string) {
    return this.search(searchTerm);
  }

  whenIClickOnAHeaderExpansionPanel(index: number) {
    return this.clickHeaderExpansionPanel(index);
  }

  whenIOpenCountryOfOriginFilterDialog() {
    return this.getCountryOfOriginFilter().click();
  }
}
