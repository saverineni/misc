import { ElementFinder, by, element } from 'protractor';

export class DeclarationElement {
    constructor(private declarationElement: ElementFinder) { }

    fieldTextOf(fieldName: string) {
        return this.declarationElement.element(by.css(`.declaration-header-value[data-declaration-header-field="${fieldName}"]`)).getText();
    }

    line(index: number) {
        return this.lines().then(lines => new DeclarationLineElement(lines[index]));
    }

    lineCount() {
        return this.lines().then(lines => lines.length);
    }

    isItemsIndicatorDisabled() {
        return this.declarationElement.element(by.css('.mat-expansion-panel-header[aria-disabled="true"]')).isPresent();
    }

    private lines() {
        return this.declarationElement.all(by.css('.declaration-lines__row'));
    }
}

export class DeclarationLineElement {
    constructor(private lineElement: ElementFinder) { }

    fieldTextOf(fieldName: string) {
        return this.lineElement.element(by.css(`.declaration-lines__${fieldName}`)).getText();
    }
}
