/// <reference path="./declarationMatchers.d.ts"/>

import {DeclarationSearchPage} from './declarationsearch.po';
import {declarationMatchers} from './declarationMatchers';
import {Wiremock} from '../wiremock';
import {browser, by, element} from 'protractor';
import {AppPage} from '../app.po';
import {NavigationBar} from '../navigation-bar.po';
import {SignInPage} from '../sign-in.po';
import {SignInScenario} from '../sign-in-scenario';
import {QueryEncoder} from '@angular/http';
import {DeclarationSearchResult} from "../../src/app/declaration-search/declaration-search-result";
import {CountryOfOriginDialogPage} from "./countryoforigin-dialog.po";

const fs = require('fs');

describe('Declaration search', () => {
  let searchPage: DeclarationSearchPage;
  let countryOfOriginDialogPage: CountryOfOriginDialogPage;

  beforeAll((done) => {
    new SignInScenario().givenUserIsSignedIn()
      .then(done, done.fail);
  });

  beforeEach((done) => {
    Wiremock.reset().then(done, done.fail);

    searchPage = new DeclarationSearchPage();
    searchPage.navigateTo();
    countryOfOriginDialogPage = new CountryOfOriginDialogPage();
  });

  const DECLARATION_FILE_NAME = 'declaration-id-found-response-body.json';

  function stubAuthenticatedDeclaration(searchTerm: string) {
    return Wiremock.stubRequest({
      "priority": 1,
      "request": {
        "method": "GET",
        "url": `/declarations?searchTerm=${searchTerm}`,
        "headers": {
          "Authorization": {
            "equalTo": "Bearer " + SignInPage.DEFAULT_AUTH_TOKEN
          }
        }
      },
      "response": {
        "status": 200,
        "bodyFileName": DECLARATION_FILE_NAME
      }
    });
  }

  describe('perform search', () => {

    describe('search results with country of origin filter', () => {
      let declarationSearchResult : DeclarationSearchResult;

      beforeEach((done) => {
        declarationSearchResult = JSON.parse(fs.readFileSync(`e2e/wiremock/__files/${DECLARATION_FILE_NAME}`));
        stubAuthenticatedDeclaration('found')
          .then(() => searchPage.whenISearchFor('found'))
          .then(done, done.fail);

        jasmine.addMatchers(declarationMatchers)
      });

      describe('filter results by country of origin', () => {
        it('open country of origin filter dialog', (done) => {
          searchPage.whenIOpenCountryOfOriginFilterDialog()
            .then(() => expect(countryOfOriginDialogPage.isCurrentDialog()).toBeTruthy())
            .then(done, done.fail);
        });

        it('dialog title is displayed', (done) => {
          searchPage.whenIOpenCountryOfOriginFilterDialog().then(done, done.fail);
          expect(countryOfOriginDialogPage.getDialogTitle()).toBe("Select country of origin");
        });

        it('dialog content is displayed', (done) => {
          const COUNTRY_SH = "SH - St Helena (1)";
          const COUNTRY_GB = "GB - United Kingdom (4)";
          const COUNTRY_IN = "IN - India (5)";
          const COUNTRY_CH = "CH - Switzerland (6)";
          const COUNTRY_TR = "TR - Turkey (7)";

          const countriesList = [COUNTRY_SH,COUNTRY_GB,COUNTRY_IN,COUNTRY_CH,COUNTRY_TR];

          searchPage.whenIOpenCountryOfOriginFilterDialog().then(done, done.fail);

          countryOfOriginDialogPage.countryListCount()
            .then((count) => expect(count).toEqual(5));

          let countriesFacet = countryOfOriginDialogPage.countryList();

          expect(countriesFacet).toEqual(countriesList);

        });

        it('dialog actions are displayed', (done) => {
          searchPage.whenIOpenCountryOfOriginFilterDialog().then(done, done.fail);
          expect(countryOfOriginDialogPage.isDialogCancelActionPresent()).toBeTruthy();
          expect(countryOfOriginDialogPage.isDialogApplyFilterActionPresent()).toBeTruthy();
        });

        it('navigate back to search page when cancel button is clicked', (done) => {
          searchPage.whenIOpenCountryOfOriginFilterDialog()
            .then(() => countryOfOriginDialogPage.clickCancel())
            .then(() => expect(searchPage.isCurrentPage()).toBeTruthy())
            .then(done, done.fail);
        });

        it('navigate back to search page when apply filters button is clicked', (done) => {
          searchPage.whenIOpenCountryOfOriginFilterDialog()
            .then(() => countryOfOriginDialogPage.clickApplyFilters())
            .then(() => expect(searchPage.isCurrentPage()).toBeTruthy())
            .then(done, done.fail);
        });

        describe('country of origin dialog interactions', () => {
          it('select country of origin - IN', (done) => {
            searchPage.whenIOpenCountryOfOriginFilterDialog()
              .then(() => countryOfOriginDialogPage.selectCountryOfOrigin('IN'))
              .then(() => expect(countryOfOriginDialogPage.isCountryOfOriginChecked('IN')).toBe('true'))
              .then(() => expect(countryOfOriginDialogPage.isCountryOfOriginChipPresent('IN')).toBeTruthy())
              .then(done, done.fail);
          });

          it('select country of origin - IN and click cancel should not persist', (done) => {
            searchPage.whenIOpenCountryOfOriginFilterDialog()
              .then(() => countryOfOriginDialogPage.selectCountryOfOrigin('IN'))
              .then(() => expect(countryOfOriginDialogPage.isCountryOfOriginChecked('IN')).toBe('true'))
              .then(() => expect(countryOfOriginDialogPage.isCountryOfOriginChipPresent('IN')).toBeTruthy())
              .then(() => countryOfOriginDialogPage.clickCancel())
              .then(() => expect(searchPage.isCurrentPage()).toBeTruthy())
              .then(done, done.fail);


            searchPage.whenIOpenCountryOfOriginFilterDialog()
            .then(() => expect(countryOfOriginDialogPage.isCurrentDialog()).toBeTruthy())
            .then(() => expect(countryOfOriginDialogPage.isCountryOfOriginChecked('IN')).toBe('false'))
            .then(() => expect(countryOfOriginDialogPage.isCountryOfOriginChipPresent('IN')).toBeFalsy())
            .then(() => expect(countryOfOriginDialogPage.countrySelectedListCount()).toEqual(0))
            .then(() => expect(countryOfOriginDialogPage.chipSelectedListCount()).toEqual(0))
            .then(done, done.fail);
          });

          it('remove the country of origin chip and it should uncheck the checkbox', (done) => {
            searchPage.whenIOpenCountryOfOriginFilterDialog()
              .then(() => countryOfOriginDialogPage.selectCountryOfOrigin('IN'))
              .then(() => expect(countryOfOriginDialogPage.isCountryOfOriginChecked('IN')).toBe('true'))
              .then(() => expect(countryOfOriginDialogPage.isCountryOfOriginChipPresent('IN')).toBeTruthy())
              .then(() => countryOfOriginDialogPage.clickChip('IN'))
              .then(() => expect(countryOfOriginDialogPage.isCountryOfOriginChipPresent('IN')).toBeFalsy())
              .then(() => expect(countryOfOriginDialogPage.isCountryOfOriginChecked('IN')).toBe('false'))
              .then(done, done.fail);
          });


          it('checkbox is unchecked and it should remove the chip', (done) => {
            searchPage.whenIOpenCountryOfOriginFilterDialog()
              .then(() => countryOfOriginDialogPage.selectCountryOfOrigin('TR'))
              .then(() => expect(countryOfOriginDialogPage.isCountryOfOriginChecked('TR')).toBe('true'))
              .then(() => expect(countryOfOriginDialogPage.isCountryOfOriginChipPresent('TR')).toBeTruthy())
              .then(() => countryOfOriginDialogPage.selectCountryOfOrigin('TR'))
              .then(() => expect(countryOfOriginDialogPage.isCountryOfOriginChecked('TR')).toBe('false'))
              .then(() => expect(countryOfOriginDialogPage.isCountryOfOriginChipPresent('TR')).toBeFalsy())
              .then(done, done.fail);
          });

          //actions tests here
        });
      });

    });

  });

});

