import {DeclarationSearchPage} from './declarationsearch.po';
import {Wiremock} from '../wiremock';
import {SignInPage} from '../sign-in.po';
import { SignInScenario } from '../sign-in-scenario';
import { BrowserCache } from '../browser-cache';

describe('Interceptor', () => {
  let searchPage: DeclarationSearchPage;
  let signInPage: SignInPage;
  const browserCache = new BrowserCache();

  beforeEach((done) => {
    new SignInScenario().givenUserIsSignedIn()
      .then(done, done.fail);

    Wiremock.reset().then(done, done.fail);

    signInPage = new SignInPage();
    searchPage = new DeclarationSearchPage();
    searchPage.navigateTo();

    
  });

   describe('When signed in', () => {
    it('and token missing should redirect to signin page', (done) => {
      browserCache.clearLocalStorage();
      searchPage.whenISearchFor('made up')
        .then(() => expect(signInPage.isCurrentPage()).toBeTruthy())
        .then(done, done.fail);
    });

    it('and token is invalid should redirect to signin page', (done) => {
      browserCache.makeTokenInvalid();
      searchPage.whenISearchFor('invalidToken')
        .then(() => expect(signInPage.isCurrentPage()).toBe(true))
        .then(done, done.fail);
    });
   });

});
