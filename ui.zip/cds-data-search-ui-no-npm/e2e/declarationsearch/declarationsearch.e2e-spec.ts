/// <reference path="./declarationMatchers.d.ts"/>

import { DeclarationSearchPage } from './declarationsearch.po';
import { declarationMatchers } from './declarationMatchers';
import { Wiremock } from '../wiremock';
import { browser } from 'protractor';
import { AppPage } from '../app.po';
import { NavigationBar } from '../navigation-bar.po';
import { SignInPage } from '../sign-in.po';
import { SignInScenario } from '../sign-in-scenario';
import { UserDetails } from '../user-details.po';
import { QueryEncoder } from '@angular/http';
import { Declaration } from '../../src/app/declaration-search/declaration';
import { DeclarationSearchResult } from "../../src/app/declaration-search/declaration-search-result";
const fs = require('fs');

describe('Declaration search', () => {
  let signInPage: SignInPage;
  let searchPage: DeclarationSearchPage;

  beforeAll((done) => {
    new SignInScenario().givenUserIsSignedIn()
      .then(done, done.fail);
  });

  beforeEach((done) => {
    Wiremock.reset().then(done, done.fail);

    searchPage = new DeclarationSearchPage();
    searchPage.navigateTo();
  });

  it('should be the current page', () => {
    expect(searchPage.isCurrentPage()).toBeTruthy();
  });

  it('the page title should be set', () => {
    expect(browser.getTitle()).toEqual("Customs Declaration Search");
  });

  it('the page should not display filters section', () => {
    expect(searchPage.isFiltersSectionDisplayed()).toBeFalsy();
    expect(searchPage.isCountryOfOriginFilterDisplayed()).toBeFalsy();
  });

  it('should focus the search field', (done) => {
    expect(searchPage.isDeclarationSearchFieldFocused()).toBeTruthy()
      .then(done, done.fail);
  });

  const DECLARATION_FILE_NAME = 'declaration-id-found-response-body.json';

  function stubAuthenticatedDeclaration(searchTerm: string) {
    return Wiremock.stubRequest({
      "priority": 1,
      "request": {
        "method": "GET",
        "url": `/declarations?searchTerm=${searchTerm}`,
        "headers": {
          "Authorization": {
            "equalTo": "Bearer " + SignInPage.DEFAULT_AUTH_TOKEN
          }
        }
      },
      "response": {
        "status": 200,
        "bodyFileName": DECLARATION_FILE_NAME
      }
    });
}

  describe('perform search', () => {
    describe('no matching declaration found', () => {
      beforeEach( (done) => {
        searchPage.whenISearchFor('made-up')
          .then(done, done.fail);
      });

      it('display no results found message', (done) => {
        expect(searchPage.isNoResultsFound()).toEqual(true)
          .then(() => expect(searchPage.getNoResultsFoundMessage()).toEqual('No results found for "made-up"'))
          .then(done, done.fail);

      });

      it('filters section not displayed', () => {
        expect(searchPage.isFiltersSectionDisplayed()).toBeFalsy();
        expect(searchPage.isCountryOfOriginFilterDisplayed()).toBeFalsy();
      });

      it('updates the url in the browser', (done) => {
        expect(new AppPage().getCurrentUrl()).toMatch(/\/\?freeText=made-up$/)
          .then(done, done.fail);
      });

      it('the message does not change before a new search response', (done) => {
        searchPage.typeIntoSearchTermField('new-search')
          .then(() => expect(searchPage.getNoResultsFoundMessage()).toEqual('No results found for "made-up"'))
          .then(done, done.fail);
      });

    });

    describe('and click the home link', () => {
      beforeEach( (done) => {
        searchPage.whenISearchFor('made-up')
        .then(() => new NavigationBar().clickHome())
          .then(done, done.fail);
      });

      it('navigates to the search page', (done) => {
        expect(searchPage.isCurrentPage()).toBeTruthy()
          .then(done, done.fail);
      });

      it('clears the results', (done) => {
        expect(searchPage.isResultsDisplayed()).toEqual(false)
          .then(() => expect(searchPage.isNoResultsFound()).toEqual(false))
          .then(done, done.fail);
      });

      it('clears the declaration search field', (done) => {
        expect(searchPage.getDeclarationSearchFieldText()).toEqual('')
          .then(done, done.fail);
      });

      it('should focus the search field', (done) => {
        expect(searchPage.isDeclarationSearchFieldFocused()).toBeTruthy()
          .then(done, done.fail);
      });

    });


    it('displays declarations with no search term', (done) => {
      stubAuthenticatedDeclaration('')
        .then(() => searchPage.clickSearchButton())
        .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
        .then(done, done.fail);
    });

    describe('declaration with lines', () => {

      let declarationSearchResult : DeclarationSearchResult;
      const DECLARATION_ID = '670-954107X-2017-08-22';
      const DECLARATION_WITH_LINES_INDEX = 0;
      const DECLARATION_WITH_NO_LINES_INDEX = 1;

      beforeEach((done) => {
        declarationSearchResult = JSON.parse(fs.readFileSync(`e2e/wiremock/__files/${DECLARATION_FILE_NAME}`));
        stubAuthenticatedDeclaration('found')
          .then(() => searchPage.whenISearchFor('found'))
          .then(done, done.fail);

        jasmine.addMatchers(declarationMatchers)
      });

      it('updates the url in the browser', (done) => {
        expect(new AppPage().getCurrentUrl()).toMatch(/\/\?freeText=found$/)
          .then(done, done.fail);
      });

      it('displays first declaration if found', () => {
        expect(searchPage.isResultsDisplayed()).toEqual(true);
        expect(searchPage.getDeclarationElement(DECLARATION_WITH_LINES_INDEX))
          .isDeclarationHeaderWithData(declarationSearchResult.declarations.find(declaration => declaration.declarationId == DECLARATION_ID));
        expect(searchPage.getResultsFoundMessage()).toEqual('Showing 1-2 of 2')
      });

      it('filters section is displayed', () => {
        expect(searchPage.isFiltersSectionDisplayed()).toBeTruthy()
        expect(searchPage.isCountryOfOriginFilterDisplayed()).toBeTruthy();
      });

      it('displays the declaration item count message in the header expansion panel', () => {
        expect(searchPage.getItemCount(DECLARATION_WITH_LINES_INDEX)).toMatch(/Show\s+4\s+Items/);
      });

      it('displays declaration lines on clicking the header expansion panel', (done) => {
        searchPage.whenIClickOnAHeaderExpansionPanel(DECLARATION_WITH_LINES_INDEX)
          .then(() => expect(searchPage.getDeclarationElement(DECLARATION_WITH_LINES_INDEX).lineCount()).toEqual(4))
          .then(done, done.fail);
      });

      it('displays declaration line populated with expected data', (done) => {
        searchPage.whenIClickOnAHeaderExpansionPanel(DECLARATION_WITH_LINES_INDEX)
          .then(() => expect(searchPage.getDeclarationElement(DECLARATION_WITH_LINES_INDEX).line(0))
              .isDeclarationLineWithData(declarationSearchResult.declarations.find(declaration => declaration.declarationId == DECLARATION_ID).lines[0]))
          .then(done, done.fail);
      });

      it('should have a disabled items indicator', () => {
        expect(searchPage.getDeclarationElement(DECLARATION_WITH_NO_LINES_INDEX).isItemsIndicatorDisabled()).toBeTruthy();
      });

    });


    describe('when backend is offline', () => {
      beforeEach((done) => {
        Wiremock.reset()
          .then(() => Wiremock.givenSearchServiceIsOffline())
          .then(done, done.fail);
      });

      it('displays global error message', (done) => {
        searchPage.whenISearchFor('made up')
          .then(() => expect(new AppPage().getOperationError()).toEqual('Server error. Please contact support if this problem persists.\nOK'))
          .then(done, done.fail);
      });

      it('does not display search results', (done) => {
        searchPage.whenISearchFor('made up')
          .then(() => expect(searchPage.isNoResultsFound()).toEqual(false))
          .then(done, done.fail);
      });

      it('retries the search on clicking the search button a second time', (done) => {
        searchPage.whenISearchFor('made up')
          .then(Wiremock.reset)
          .then(() => searchPage.clickSearchButton())
          .then(() => expect(searchPage.isNoResultsFound()).toEqual(true))
          .then(done, done.fail);
      });

      it('recovers after backend is restored', (done) => {
        searchPage.whenISearchFor('made up')
          .then(Wiremock.reset)
          .then(() => searchPage.whenISearchFor('made up'))
          .then(() => expect(searchPage.isNoResultsFound()).toEqual(true))
          .then(done, done.fail);
      });

    });
  });

  describe('bookmark search', () => {
    function bookmarkUrl(params) {
      return '/?freeText=' + encodeURIComponent(params.freeText);
    }

    const bookmarkSpecialChars = ';/:@&?=<>#%{}|\^~[]` шеллы';

    it('populates the declaration search field', (done) => {
      browser.get(bookmarkUrl({freeText: 'bookmark'}))
        .then(() => expect(searchPage.getDeclarationSearchFieldText()).toEqual('bookmark'))
        .then(done, done.fail);
    });

    describe('no results found',() => {
      it('display no results found message', (done) => {
        browser.get(bookmarkUrl({freeText: 'bookmark'}));
        expect(searchPage.isNoResultsFound()).toEqual(true)
          .then(() => expect(searchPage.getNoResultsFoundMessage()).toEqual('No results found for "bookmark"'))
          .then(done, done.fail);
      });

      it('special characters are decoded in the no results found message', (done) => {
        browser.get(bookmarkUrl({freeText: bookmarkSpecialChars}));
        expect(searchPage.isNoResultsFound()).toEqual(true)
          .then(() => expect(searchPage.getNoResultsFoundMessage()).toEqual(`No results found for "${bookmarkSpecialChars}"`))
          .then(done, done.fail);
      });

    });

    describe('when results found',() => {
      it('display results', (done) => {
        stubAuthenticatedDeclaration('bookmark')
          .then(() => browser.get(bookmarkUrl({freeText: 'bookmark'})))
          .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
          .then(done, done.fail);
      });

      it('encoding of special characters is preserved on request to backend ', (done) => {
        stubAuthenticatedDeclaration(new QueryEncoder().encodeValue(bookmarkSpecialChars))
          .then(() => browser.get(bookmarkUrl({freeText: bookmarkSpecialChars})))
          .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
          .then(done, done.fail);
      });
    });
  });
});

