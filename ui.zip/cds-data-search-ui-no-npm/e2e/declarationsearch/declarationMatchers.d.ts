declare namespace jasmine {
    interface Matchers<T> {
        isDeclarationHeaderWithData(expected: object): boolean;
        isDeclarationLineWithData(expected: object): boolean;
    }
}