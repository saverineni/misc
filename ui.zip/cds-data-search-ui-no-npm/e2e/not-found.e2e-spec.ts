import { AppPage } from './app.po';
import { NotFoundPage } from './not-found.po';
import { SignInPage } from './sign-in.po';
import { browser } from 'protractor';
import { SignInScenario } from './sign-in-scenario';

describe('cds-data-search-ui Not Found', () => {
  let appPage: AppPage;
  let signInPage: SignInPage;
  let page: NotFoundPage;

  beforeAll((done) => {
    appPage = new AppPage();
    signInPage = new SignInPage();
    page = new NotFoundPage();
    new SignInScenario().givenUserIsNotSignedIn()
      .then(() => browser.get('/unknown-page'))    
      .then(done, done.fail);
  });

  it('should display the not found page when page is not recognised', () => {
    expect(appPage.componentHeading()).toEqual('404 the requested URL was not found');
  });

  it('should not change the url', () => {
    expect(page.getCurrentUrl()).toMatch(/.*\/unknown-page$/);
  });

  it('should navigate to the sign in page when the button is clicked', (done) => {
    page.clickSignIn()
      .then(() => expect(signInPage.isCurrentPage()).toEqual(true))
      .then(done, done.fail);
  });
});
