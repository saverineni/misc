export class Country {
    code: string;
    name: string;
}
