import {Component, Inject, OnInit, QueryList, ViewChildren, ViewEncapsulation} from '@angular/core';
import {MAT_DIALOG_DATA, MatCheckbox, MatDialogRef} from "@angular/material";
import {CountryFacet} from "../../countries-facet";
import {Country} from "../../country";

@Component({
  selector: 'app-country-of-origin',
  templateUrl: './country-of-origin.component.html',
  styleUrls: ['./country-of-origin.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CountryOfOriginComponent implements OnInit {

  countries: Array<CountryFacet>;

  constructor(@Inject(MAT_DIALOG_DATA) public data, public dialogRef: MatDialogRef<CountryOfOriginComponent>) {
    this.countries = data.countries;
  }

  ngOnInit() {
  }

  onDeselect(facet) {
    facet.selected = false;
  }

  onSelect(facet) {
    facet.selected = true;
  }

  selectedCountries() {
    return this.countries.filter(facet => facet.selected);
  }

}
