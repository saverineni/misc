import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {CountryOfOriginComponent} from './country-of-origin.component';
import {MatDialogModule} from "@angular/material/dialog";
import {MatCheckboxModule} from "@angular/material/checkbox";
import {CountryFacet} from "../../countries-facet";
import {Country} from "../../country";
import {MAT_DIALOG_DATA, MatCheckboxChange, MatChipsModule, MatDialogRef, MatIconModule} from "@angular/material";
import {By} from "@angular/platform-browser";
import {DebugElement} from "@angular/core/src/debug/debug_node";
import {MatListModule} from "@angular/material/list";

describe('CountryOfOriginComponent', () => {
  let component: CountryOfOriginComponent;
  let fixture: ComponentFixture<CountryOfOriginComponent>;
  let countryFacetForUK = new CountryFacet();
  let countryFacetForCH = new CountryFacet();

  beforeEach(async(() => {

    let country = new Country();

    country.code = 'GB';
    country.name = 'United Kingdom';
    countryFacetForUK.country = country;
    countryFacetForUK.count = 4;

    country = new Country();
    country.code = 'CH';
    country.name = 'Switzerland';
    countryFacetForCH.country = country;
    countryFacetForCH.count = 3;

    let countriesFacet = [countryFacetForUK, countryFacetForCH];

    TestBed.configureTestingModule({
      imports: [
        MatDialogModule,
        MatChipsModule,
        MatIconModule,
        MatListModule,
        MatCheckboxModule
      ],
      declarations: [CountryOfOriginComponent],
      providers: [
        {provide: MAT_DIALOG_DATA, useValue: { countries: countriesFacet }},
        {provide: MatDialogRef, useValue: {}}
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CountryOfOriginComponent );
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('given list of countries' , () => {

    it('should display title',() => {
      const title: HTMLElement = fixture.debugElement.query(By.css('.mat-dialog-title')).nativeElement;
      expect(title.textContent).toEqual('Select country of origin');
    });

    it('should display cancel button',() => {
      const cancelButton: DebugElement = fixture.debugElement.query(By.css('.country-origin__cancel'));
      expect(cancelButton).toBeTruthy();
    });

    it('should display apply filters button',() => {
      const applyFiltersButton: DebugElement = fixture.debugElement.query(By.css('.country-origin__apply-filters'));
      expect(applyFiltersButton).toBeTruthy();
    });

    it('should display data on load', () => {
      const countryList = fixture.debugElement.queryAll(By.css('.country-origin__link'));
      const countryNames = countryList.map(countryElement => countryElement.nativeElement.textContent)

      expect(countryNames).toEqual(['GB - United Kingdom (4)', 'CH - Switzerland (3)']);
    });

    it('should not contain any chips on load', () => {
      let chips: DebugElement[] = fixture.debugElement.queryAll(By.css('.mat-chip'));
      expect(chips.length).toBe(0);
    });

    describe('selecting country', () => {
      let chips: DebugElement[];
      beforeEach(() => {
        countryFacetForUK.selected = true;

        fixture.detectChanges();

        chips = fixture.debugElement.queryAll(By.css('.country-origin__selections-chip'));
      });

      it('should cause chips to be displayed', () => {
        expect(chips.length).toBe(1);
      });

      it('should display chips with the country details displayed', () => {
        const countryGBChip: HTMLElement = chips[0].nativeElement;
        expect(chips[0].nativeElement.textContent.trim()).toContain('GB - United Kingdom');
      });
    });

    describe('user clicks country in list',() => {

      let countryGBLink : HTMLInputElement;

      beforeEach(() => {
        countryGBLink = fixture.debugElement.query(By.css('.country-origin__link[data-country-code="GB"]')).nativeElement as HTMLInputElement;
        expect(countryGBLink).toBeTruthy();
        countryGBLink.click();
        fixture.detectChanges();
      });

      it('should update selection list when link is clicked' ,() => {
        expect(component.selectedCountries().length).toBe(1);
        expect(component.selectedCountries()).toContain(countryFacetForUK);
      });

      it('should disable country link when selected', () => {
        let disabledLink = fixture.debugElement.query(By.css('.country-origin__link--disabled[data-country-code="GB"]'));

        expect(disabledLink).toBeTruthy();
      });
    });

    describe('user clicks chips',() => {
      beforeEach(() => {
        countryFacetForUK.selected = true;
        countryFacetForCH.selected = true;
        fixture.detectChanges();

        let removeGBChip = fixture.debugElement.query(By.css('.country-origin__selections-chip[data-country-code="GB"] .country-origin__selections-remove')).nativeElement as HTMLInputElement;
        expect(removeGBChip).toBeTruthy();
        removeGBChip.click();

        fixture.detectChanges();
      });

      it('should remove the chip', () => {
        let chips = fixture.debugElement.queryAll(By.css('.country-origin__selections-chip'));

        expect(chips.length).toBe(1);
        expect(chips[0].nativeElement.getAttribute('data-country-code')).toBe('CH');
      });

      it('should re-enable country link when chip is removed' , () => {
        let gbLink = fixture.debugElement.query(By.css('.country-origin__link--disabled[data-country-code="GB"]'));

        expect(gbLink == null).toBeTruthy();
      });
    });
  });
});
