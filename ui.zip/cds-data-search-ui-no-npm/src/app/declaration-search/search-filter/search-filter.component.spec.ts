import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {SearchFilterComponent} from './search-filter.component';
import {Facets} from "../facets";
import {CountryOfOriginComponent} from "./country-of-origin/country-of-origin.component";
import {By} from "@angular/platform-browser";
import {DebugElement} from "@angular/core";
import {BrowserDynamicTestingModule} from "@angular/platform-browser-dynamic/testing";
import {MatDialog, MatDialogModule} from '@angular/material/dialog';
import {MatCheckboxModule} from "@angular/material/checkbox";
import {MatListModule} from "@angular/material/list";
import {CountryFacet} from "../countries-facet";
import {ReactiveFormsModule} from "@angular/forms";
import {MatChipsModule, MatIconModule} from "@angular/material";


describe('SearchFilterComponent', () => {
  let component: SearchFilterComponent;
  let fixture: ComponentFixture<SearchFilterComponent>;
  let filter: DebugElement;

  let dialog = {
    open(a,b) {}
  } as MatDialog;

  const originCountriesFacet = [new CountryFacet()];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MatDialogModule , MatCheckboxModule , MatListModule, MatChipsModule , MatIconModule ],
      declarations: [ SearchFilterComponent , CountryOfOriginComponent ],
      providers: [{
        provide: MatDialog,
        useValue: dialog
      }
      ]
    }).overrideModule(BrowserDynamicTestingModule, {
        set: {
          entryComponents : [CountryOfOriginComponent]
        }
      })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFilterComponent);
    component = fixture.componentInstance;
    component.facets = new Facets();
    component.facets.originCountries = originCountriesFacet;
    fixture.detectChanges();

    filter = fixture.debugElement.query(By.css('.search-filter'));
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should contain the filters label' , () => {
    let label = filter.query(By.css('.search-filter__label')).nativeElement;
    expect(label.innerText).toBe('Filters: ')
  });

  it('should contain the country of origin button' , () => {
    let countryOfOriginButton = filter.query(By.css('.search-filter__country-of-origin'));
    expect(countryOfOriginButton).toBeTruthy();
  });


  describe('click on country of origin button',() => {

    beforeEach(() => {
      spyOn(component.dialog, 'open').and.callThrough();
    });

    it(' opens the dialog window', () => {
      expect(component.dialog.open).toHaveBeenCalledTimes(0);
      let countryOfOriginButton = filter.query(By.css('.search-filter__country-of-origin'));
      countryOfOriginButton.nativeElement.click();
      fixture.detectChanges();
      expect(component.dialog.open).toHaveBeenCalledWith(CountryOfOriginComponent,{data:{countries : originCountriesFacet}});
   })
  })

});
