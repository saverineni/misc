import {Component, Input, OnInit} from '@angular/core';
import {Facets} from "../facets";
import {MatDialog, MatDialogRef} from "@angular/material";
import {CountryOfOriginComponent} from "./country-of-origin/country-of-origin.component";

@Component({
  selector: 'cds-search-filter',
  templateUrl: './search-filter.component.html',
  styleUrls: ['./search-filter.component.scss']
})
export class SearchFilterComponent implements OnInit  {

  @Input() facets: Facets;
  countryOfOriginDialogRef: MatDialogRef<CountryOfOriginComponent>

  constructor(public dialog: MatDialog) { }

  ngOnInit() {
  }

  openCountryOfOriginDialog() {
    this.countryOfOriginDialogRef = this.dialog.open(CountryOfOriginComponent , {
      data: {countries : this.facets.originCountries}
    });
  }
}
