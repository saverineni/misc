import { Component, Input, OnInit, OnChanges, Output, EventEmitter, ViewChild, ChangeDetectorRef, SimpleChanges } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DeclarationSearch } from '../declaration-search';

@Component({
  selector: 'cds-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.scss']
})
export class SearchFormComponent implements OnInit, OnChanges {
    
  @Input() declarationSearch: DeclarationSearch;
  @Output() submitSearch = new EventEmitter<DeclarationSearch>();
  @ViewChild('searchInput') searchInput;
  searchTerm;

  constructor(private route: ActivatedRoute, private cdr: ChangeDetectorRef) { }

  ngOnInit() {
    this.updateSearchTerm();
    this.route.queryParams
      .filter(queryParams => !queryParams.hasOwnProperty('freeText'))
      .subscribe(queryParams => this.focusDeclarationSearchField());
  }

  private updateSearchTerm() {
    this.searchTerm = this.declarationSearch.freeText;
  }

  ngAfterViewInit() {
    this.focusDeclarationSearchField();
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.updateSearchTerm();    
  }
  
  private focusDeclarationSearchField() {
    this.searchInput.nativeElement.focus();
    this.cdr.detectChanges();
  }

  onSubmitSearch() {
    const newSearch = Object.assign({}, this.declarationSearch) as DeclarationSearch;
    newSearch.freeText = this.searchTerm;
    this.submitSearch.emit(newSearch);
  }

}
