export interface DeclarationSearch {
    freeText:string;
}
