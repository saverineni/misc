import {Injectable} from '@angular/core';
import {DeclarationSearch} from './declaration-search';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpParams} from '@angular/common/http';
import 'rxjs/add/operator/map';
import {DeclarationSearchResult} from './declaration-search-result';
import {Declaration} from './declaration';

@Injectable()
export class SearchService {

  constructor(private http: HttpClient) {
  }

  search(search: DeclarationSearch): Observable<any> {
    return this.http.get<DeclarationSearchResult>(
      "/api/declarations",
      {
        params: new HttpParams().set('searchTerm', search.freeText)
      })
      .map(searchResult => searchResult as DeclarationSearchResult);
  }

}
