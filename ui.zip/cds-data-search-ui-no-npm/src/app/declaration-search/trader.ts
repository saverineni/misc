export interface Trader {
    number;
    name;
    postcode;
}
