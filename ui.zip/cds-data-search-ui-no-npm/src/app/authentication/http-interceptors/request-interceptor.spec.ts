import {HttpHandler, HttpRequest} from "@angular/common/http";
import {RequestInterceptor} from "./request-interceptor";
import {CacheService} from "../cache.service";
import {EmptyObservable} from "rxjs/observable/EmptyObservable";
import {SignInRouterService} from "../sign-in/sign-in-router.service";


describe('RequestInterceptor ', () => {
  let cacheService: CacheService;
  let requestInterceptor: RequestInterceptor;
  let signInRouterService: SignInRouterService;
  let request: HttpRequest<any>;
  let cloneReq: HttpRequest<any>;

  let next: HttpHandler;
  let spyHandler: jasmine.Spy;


  describe('for url ', () => {

    beforeEach(() => {
      cacheService = {
        getToken() {
          return 'token'
        }
      } as CacheService;

      signInRouterService = {
        navigateToSignIn: () => {}
      } as SignInRouterService;


      next = {
        handle: request => {
        }
      } as HttpHandler;
      spyHandler = spyOn(next, 'handle');
      requestInterceptor = new RequestInterceptor(cacheService, signInRouterService);
    });

    it('/authentication/token will not add token to the header', () => {
      request = {
        url: '/api/authentication/token'
      } as HttpRequest<any>;

      requestInterceptor.intercept(request, next)
      expect(spyHandler).toHaveBeenCalledWith(request);
    });

    it('other than /authentication/token adds token to the header', () => {
      request = {
        url: '/',
        clone() {
          return cloneReq
        }
      } as HttpRequest<any>;

      cloneReq = {
        url: '/'
      } as HttpRequest<any>;


      spyOn(request, 'clone').and.callThrough();
      requestInterceptor.intercept(request, next)

      expect(spyHandler).toHaveBeenCalledWith(cloneReq);
      expect(request.clone).toHaveBeenCalledWith({
        setHeaders: {
          Authorization: 'Bearer token'
        }
      })
    });
  });

  describe('for search ', () => {

    beforeEach(() => {
      cacheService = {
        getToken() {
          return null;
        }
      } as CacheService;

      signInRouterService = {
        navigateToSignIn: () => {}
      } as SignInRouterService;

      next = {
        handle: request => {
        }
      } as HttpHandler;

      spyOn(signInRouterService, 'navigateToSignIn');
      spyHandler = spyOn(next, 'handle');
      requestInterceptor = new RequestInterceptor(cacheService, signInRouterService);
    });

    it('redirects to signin page when token does not exits for any urls except authentication url', () => {
      request = {
        url: '/api/declarations'
      } as HttpRequest<any>;

      let observable  = requestInterceptor.intercept(request, next);
      expect(signInRouterService.navigateToSignIn).toHaveBeenCalled();
      expect(observable).toEqual(new EmptyObservable());
    });

    it('redirects to signin page when token does not exits for authentication url', () => {
      request = {
        url: '/api/authentication/token'
      } as HttpRequest<any>;

      requestInterceptor.intercept(request, next)
      expect(signInRouterService.navigateToSignIn).not.toHaveBeenCalled();
      expect(spyHandler).toHaveBeenCalledWith(request);
    });

  });


});

