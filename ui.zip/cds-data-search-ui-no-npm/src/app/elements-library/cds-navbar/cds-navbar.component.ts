import { Component, Input } from '@angular/core';

@Component({
  selector: 'cds-navbar',
  templateUrl: './cds-navbar.component.html',
  styleUrls: ['./cds-navbar.component.scss']
})
export class CdsNavbarComponent {
  @Input() homeLabel;
}
