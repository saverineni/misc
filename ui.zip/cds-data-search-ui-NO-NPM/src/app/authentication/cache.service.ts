import { Injectable } from '@angular/core';
import { User } from './user';


@Injectable()
export class CacheService {
  static TOKEN_KEY = 'currentUser';
  static USER_KEY = 'user';

  getToken(): string {
    return localStorage.getItem(CacheService.TOKEN_KEY);
  }

  setToken(token: string) {
    localStorage.setItem(CacheService.TOKEN_KEY, token);
  }

  getUser(): User {
    const userString = localStorage.getItem(CacheService.USER_KEY);
    if (userString) {
      const userObject = JSON.parse(userString)
      return new User(userObject.pid);
    } else {
      return null;
    }
  }

  setUser(user: User) {
    localStorage.setItem(CacheService.USER_KEY, JSON.stringify(user));
  }

  clear() {
    localStorage.clear();
  }
}
