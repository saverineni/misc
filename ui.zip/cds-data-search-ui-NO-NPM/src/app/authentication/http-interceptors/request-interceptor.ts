import {Injectable} from "@angular/core";
import {HttpEvent, HttpHandler, HttpInterceptor, HttpRequest} from "@angular/common/http";
import {Observable} from "rxjs/Observable";
import {CacheService} from "../cache.service";
import {EmptyObservable} from "rxjs/observable/EmptyObservable";
import {SignInRouterService} from "../sign-in/sign-in-router.service";

@Injectable()
export class RequestInterceptor implements HttpInterceptor {

  constructor(private cacheService: CacheService, private signInRouterService: SignInRouterService) {
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    if (req.url != "/api/authentication/token") {
      if (this.cacheService.getToken() == null) {
        this.signInRouterService.navigateToSignIn();
        return new EmptyObservable();
      } else {
        req = req.clone({
          setHeaders: {
            Authorization: `Bearer ${this.cacheService.getToken()}`
          }
        });
      }
    }
    return next.handle(req);
  }
}
