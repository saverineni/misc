import { Component, Input, ContentChild } from '@angular/core';

@Component({
  selector: 'cds-header',
  templateUrl: './cds-header.component.html',
  styleUrls: ['./cds-header.component.scss']
})
export class CdsHeaderComponent {
  @ContentChild('headerDetail') headerDetail: Component;

  @Input() title: string;
}
