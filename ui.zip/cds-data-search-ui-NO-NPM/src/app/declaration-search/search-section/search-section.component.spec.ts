import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { SearchSectionComponent } from './search-section.component';
import { Directive, EventEmitter, Output, Input, DebugElement } from '@angular/core';
import { SearchService } from '../search.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { SearchCriteria } from '../search-criteria';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DeclarationSearchResult, Hits } from '../declaration-search-result';
import { Declaration } from '../declaration';
import { NavigationExtras, ActivatedRoute, Router , NavigationStart , NavigationEnd } from '@angular/router';
import { ReplaySubject } from 'rxjs';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { Facets } from "../facets";
import { CountryFacet } from "../countries-facet";
import { Country } from "../country";
import { MatDividerModule } from '@angular/material';
import { SearchCriteriaService } from '../search-criteria.service';
import { Subscription } from 'rxjs/Subscription';
import { NavigationService } from '../navigation.service';

@Directive({
  selector: 'cds-search-form'
})
export class SearchFormStub {
  @Input() declarationSearch;
  @Output() submitSearch = new EventEmitter<SearchCriteria>();
}

@Directive({
  selector: 'cds-declaration-card'
})
export class DeclarationCardStub {
  @Input() declaration;
}

@Directive({
  selector: 'cds-search-filter'
})
export class SearchFilterStub {
  @Input() facets;
}

describe('SearchSectionComponent', () => {
  let component: SearchSectionComponent;
  let fixture: ComponentFixture<SearchSectionComponent>;
  let searchServiceStub;
  let searchCriteriaServiceStub;
  let testObservable: Observable<SearchCriteria>;
  let testSubscription: Subscription;
  let result: DeclarationSearchResult;
  
  beforeEach(async(() => {
    testObservable = Observable.of(new SearchCriteria());
    testSubscription = new Subscription();
    result = new DeclarationSearchResult();

    searchServiceStub = {
      search: () =>  Observable.of(result)
    };
    searchCriteriaServiceStub = { searchCriteria: testObservable };    
    spyOn(searchServiceStub, 'search').and.callThrough();

    TestBed.configureTestingModule({
      declarations: [SearchSectionComponent, SearchFormStub, DeclarationCardStub , SearchFilterStub],
      providers: [
        {provide: NavigationService, useValue: null},
        {provide: SearchService, useValue: searchServiceStub},
        {provide: SearchCriteriaService, useValue: searchCriteriaServiceStub}
      ],
      imports: [HttpClientTestingModule, MatDividerModule]
    })
    .compileComponents();
  }));
  
  let successHandler;
  
  beforeEach(() => {
    fixture = TestBed.createComponent(SearchSectionComponent);
    component = fixture.componentInstance;
    spyOn(testObservable, 'subscribe')
    .and.callFake(success => {
        successHandler = success;
        return testSubscription;
      });  
      
    spyOn(testSubscription, 'unsubscribe');

    fixture.detectChanges();
  });
  
  describe('on initialisation', () => {
    it('should subscribe to successful search criteria updates', () => {
      expect(successHandler).toBeTruthy();
    });
  });

  describe('empty search criteria', () => {
    beforeEach(() => {
      component.result = new DeclarationSearchResult();
      let criteria = new SearchCriteria();
      criteria.searchTerm = null;
      successHandler(criteria);
    });

    it('should not perform a search', () => {
      expect(searchServiceStub.search).not.toHaveBeenCalled();
    });

    it('should set the results to null', () => {
      expect(component.result).toBeNull();
    })
  });

  describe('with search criteria', () => {
    let searchCriteria: SearchCriteria;

    beforeEach(() => {
      searchCriteria = new SearchCriteria();
      searchCriteria.searchTerm = 'term';
      
      successHandler(searchCriteria);
    });

    it('should perform a search', () => {
      expect(searchServiceStub.search).toHaveBeenCalledWith(searchCriteria);
    });

    it('should set the result', () => {
      expect(component.result).toBe(result);
    });
  });

  describe('on destroy', () => {
    it('should unsubscribe from criteria events', () => {
      fixture.destroy();
      expect(testSubscription.unsubscribe).toHaveBeenCalled();
    });
  });
});

