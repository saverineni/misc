import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { SearchSectionComponent } from './search-section.component';
import { Directive, EventEmitter, Output, Input, DebugElement } from '@angular/core';
import { SearchService } from '../search.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { SearchCriteria } from '../search-criteria';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DeclarationSearchResult, Hits } from '../declaration-search-result';
import { Declaration } from '../declaration';
import { NavigationExtras, ActivatedRoute, Router , NavigationStart , NavigationEnd } from '@angular/router';
import { ReplaySubject } from 'rxjs';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { Facets } from "../facets";
import { CountryFacet } from "../countries-facet";
import { Country } from "../country";
import { MatDividerModule } from '@angular/material';

@Directive({
  selector: 'cds-search-form'
})
export class SearchFormStub {
  @Input() declarationSearch;
  @Output() submitSearch = new EventEmitter<SearchCriteria>();
}

@Directive({
  selector: 'cds-declaration-card'
})
export class DeclarationCardStub {
  @Input() declaration;
}

@Directive({
  selector: 'cds-search-filter'
})
export class SearchFilterStub {
  @Input() declarationSearch;
  @Input() facets;
}

class ActivatedRouteStub {

  private subject = new ReplaySubject<any>(0);

  readonly queryParams = this.subject.asObservable();

  setQueryParams(queryParams?: any) {
    this.subject.next(queryParams);
  };
}

class RouterStub {

  private subject = new ReplaySubject<any>();

  readonly events = this.subject.asObservable();

  setEvents(events?: any) {
    this.subject.next(events);
  };

  navigate(commands: any[], extras: NavigationExtras): Promise<boolean> {
    return Promise.resolve(true);
  }
}

describe('SearchSectionComponent', () => {
  let component: SearchSectionComponent;
  let fixture: ComponentFixture<SearchSectionComponent>;
  let newRoute;
  let newRouter;

  function nullSafeDirective(debugElement, clazz) {
    const childDebugElement = debugElement.query(By.directive(clazz));
    if (childDebugElement == null) {
      return null;
    }
    return childDebugElement.injector.get(clazz);
  }

  function getNoSearchResultsDebugElement() {
    return fixture.debugElement.query(By.css('.no-search-results'));
  }

  beforeEach(async(() => {
    newRouter = new RouterStub();
    newRoute = new ActivatedRouteStub();

    TestBed.configureTestingModule({
      declarations: [SearchSectionComponent, SearchFormStub, DeclarationCardStub , SearchFilterStub],
      providers: [
        SearchService,
        {provide: Router, useValue: newRouter},
        {provide: ActivatedRoute, useValue: newRoute}
      ],
      imports: [HttpClientTestingModule, MatDividerModule]
    })
      .compileComponents();
  }));



  beforeEach(() => {
    fixture = TestBed.createComponent(SearchSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('declaration search section', () => {
    let section : DebugElement;
    beforeEach(async(() => {
      section = fixture.debugElement.query(By.css('.search-section'));
    }));

    it('should be displayed', () => {
      expect(section).toBeTruthy();
    });

    it('should have a heading', () => {
      const heading = section.query(By.css('h1')).nativeElement;
      expect(heading.innerText).toEqual('Customs Declaration Search');
    });

    describe('search form', () => {
      it('should have a search form', () => {
        const searchForm = section.query(By.directive(SearchFormStub));
        expect(searchForm).toBeTruthy();
      });

      describe('form submission', () => {
        const term = 'free text';
        let declarationSearch: SearchCriteria;
        let routerSpy;

        beforeEach(() => {
          declarationSearch = new SearchCriteria();
          declarationSearch.searchTerm = term;
          const router = fixture.debugElement.injector.get(Router);
          routerSpy = spyOn(router, 'navigate');

          const searchForm = section.query(By.directive(SearchFormStub));
          const searchFormDirective = searchForm.injector.get(SearchFormStub);
          searchFormDirective.submitSearch.emit(declarationSearch);
        })

        it('should update query params on form submission', () => {
          expect(routerSpy).toHaveBeenCalledWith(['/'], {queryParams: declarationSearch});
        });

        it('should not update the declaration search field', () => {
          expect(component.declarationSearch.searchTerm).toEqual('');
        });

      })

    });

    describe('search results', () => {
      it('should not include search results on page load', () => {
        const searchResults = section.query(By.directive(DeclarationCardStub));
        expect(searchResults != null).toBeFalsy();
      });

      it('should not include search filters on page load', () => {
        const searchFilters = section.query(By.directive(SearchFilterStub));
        expect(searchFilters != null).toBeFalsy();
      });

      it('should display the search results message after search', () => {
        const expected = new DeclarationSearchResult();
        expected.declarations = [new Declaration(), new Declaration()]
        expected.hits = new Hits();
        expected.hits.total = 9;

        component.result = expected;
        fixture.detectChanges();

        const resultsMessage = section.query(By.css('.search-results-message')).nativeElement;
        expect(resultsMessage.innerText).toEqual('Showing 1-2 of 9');
      });

      it('should not display no results found message', () => {
        const noSearchResultsElement = getNoSearchResultsDebugElement();
        expect(noSearchResultsElement === null).toEqual(true);
      });

      it('should include search results after search', () => {
        component.result = new DeclarationSearchResult();
        component.result.declarations = [new Declaration()];
        fixture.detectChanges();

        const searchResults = section.query(By.directive(DeclarationCardStub));
        const searchResultsDirective = searchResults.injector.get(DeclarationCardStub);

        expect(searchResultsDirective.declaration).toEqual(component.result.declarations[0]);
      });


      it('should display the search filter after search', () => {
        const originCountryFacet = [
          new CountryFacet()
        ]
        const expected = new DeclarationSearchResult();
        expected.declarations = [new Declaration(), new Declaration()]
        expected.hits = new Hits();
        expected.hits.total = 9;
        expected.facets = new Facets();
        expected.facets.originCountries = originCountryFacet;

        component.result = expected;
        fixture.detectChanges();

        const searchFilters = section.query(By.directive(SearchFilterStub));
        expect(searchFilters != null).toBeTruthy();

      });

    });

    describe('No results found', () => {
      beforeEach(() => {
        const expected = new DeclarationSearchResult();
        expected.declarations = []
        expected.hits = new Hits();
        expected.hits.total = 0;
        component.result = expected;
        component.declarationSearch.searchTerm = "invalid search term";
        fixture.detectChanges();
      });

      it('should display no results found message', () => {
        const noSearchResultsElement = getNoSearchResultsDebugElement().nativeElement;
        expect(noSearchResultsElement.innerText).toBe("No results found for \"invalid search term\"");
      });
    });

    describe('perform search'  , () => {
      const expected = new DeclarationSearchResult();
      let declarationSearchValuesWhenSearchPerformed;

      function spyOnSearchService(fixture) {
        const searchService = fixture.debugElement.injector.get(SearchService);
        return spyOn(searchService, 'search')
          .and.callFake(() => {
            declarationSearchValuesWhenSearchPerformed = component.declarationSearch;
            return Observable.of(expected);
          });
      }

      describe('on bookmark request', () => {
        let searchServiceSpy;
        let queryParams: SearchCriteria;

        beforeEach(() => {
          queryParams = new SearchCriteria();
          queryParams.searchTerm = 'changed';
          searchServiceSpy = spyOnSearchService(fixture);
          newRoute.setQueryParams(queryParams);
          fixture.detectChanges();
        });

        it('should perform search on backend', () => {
          expect(searchServiceSpy).toHaveBeenCalledWith(queryParams);
        });

        it('set the search result', () => {
          expect(component.result).toBe(expected);
        });

        it('set the search field', () => {
          expect(component.declarationSearch).toEqual(queryParams);
        });

        it('set the search field after the search is performed', () => {
          expect(declarationSearchValuesWhenSearchPerformed).toEqual(new SearchCriteria());
        });
      });

      describe('on one navigation end event', () => {
        let searchServiceSpy;
        let queryParams: SearchCriteria;

        beforeEach(() => {
          queryParams = new SearchCriteria();
          queryParams.searchTerm = 'changed';
          newRoute.setQueryParams({});
          fixture.detectChanges();

          searchServiceSpy = spyOnSearchService(fixture);
          newRoute.setQueryParams(queryParams);
          newRouter.setEvents(new NavigationEnd(null,null,null));
          fixture.detectChanges();
        });

        it('should perform search on backend', () => {
          expect(searchServiceSpy).toHaveBeenCalledWith(queryParams);
        });

        it('set the search result', () => {
          expect(component.result).toBe(expected);
        });

        it('set the search field', () => {
          expect(component.declarationSearch).toEqual(queryParams);
        });

        it('set the search field after the search is performed', () => {
          expect(declarationSearchValuesWhenSearchPerformed).toEqual(new SearchCriteria());
        });
      });

      it('on subsequent navigation end events it should search once and update results' , () => {
        newRoute.setQueryParams({});
        let searchServiceSpy = spyOnSearchService(fixture);
        const firstQueryParams = new SearchCriteria();
        firstQueryParams.searchTerm = 'first';
        newRoute.setQueryParams(firstQueryParams);
        newRouter.setEvents(new NavigationEnd(null,null,null));

        fixture.detectChanges();
        expect(searchServiceSpy).toHaveBeenCalledWith(firstQueryParams);
        expect(searchServiceSpy.calls.count()).toEqual(1);
        expect(component.result).toBe(expected);

        searchServiceSpy.calls.reset();

        const secondQueryParams = {searchTerm: 'second'};
        newRoute.setQueryParams(secondQueryParams);
        newRouter.setEvents(new NavigationEnd(null,null,null));

        fixture.detectChanges();
        expect(searchServiceSpy).toHaveBeenCalledWith(secondQueryParams);
        expect(searchServiceSpy.calls.count()).toEqual(1);
        expect(component.result).toBe(expected);
      });

      it('on other navigation event' , () => {
        const queryParams = new SearchCriteria();
        queryParams.searchTerm = 'changed';
        newRoute.setQueryParams({});
        let searchServiceSpy = spyOnSearchService(fixture);
        newRoute.setQueryParams(queryParams);
        newRouter.setEvents(new NavigationStart(null,null));

        fixture.detectChanges();
        expect(searchServiceSpy).not.toHaveBeenCalled();
        expect(component.result).toBe(null);

      });

      describe('on error from search service', () => {
        let searchServiceSpy;
        let queryParams;

        beforeEach(() => {
          queryParams = new SearchCriteria();
          queryParams.searchTerm = 'changed';
          newRoute.setQueryParams({});
          const searchService = fixture.debugElement.injector.get(SearchService);
          searchServiceSpy = spyOn(searchService, 'search')
            .and.callFake(() => {
            declarationSearchValuesWhenSearchPerformed = component.declarationSearch;
            return new ErrorObservable("swallowed error");
          });

          newRoute.setQueryParams(queryParams);
          newRouter.setEvents(new NavigationEnd(null,null,null));

          component.result = expected;
          fixture.detectChanges();
        });

        it('not update the search result', () => {
          expect(component.result).toBe(expected);
        });

        it('set the search field', () => {
          expect(component.declarationSearch).toEqual(queryParams);
        });

        it('set the search field after the search is performed', () => {
          expect(declarationSearchValuesWhenSearchPerformed).toEqual(new SearchCriteria());
        });
      });
    });
  });
});

