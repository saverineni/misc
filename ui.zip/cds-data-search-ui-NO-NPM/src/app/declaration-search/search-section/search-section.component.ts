import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { SearchCriteria } from '../search-criteria';
import { SearchService } from '../search.service';
import { DeclarationSearchResult } from '../declaration-search-result';
import { ActivatedRoute, NavigationEnd } from '@angular/router';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import {concat} from 'rxjs/operators';

@Component({
  selector: 'cds-search-section',
  templateUrl: './search-section.component.html',
  styleUrls: ['./search-section.component.scss']
})
export class SearchSectionComponent implements OnInit, OnDestroy {

  result: DeclarationSearchResult = null;
  declarationSearch: SearchCriteria = new SearchCriteria();
  routerEventSubscription: Subscription;

  constructor(private searchService: SearchService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.routerEventSubscription =
      this.bookmarkQueryParams()
        .pipe(this.concatenateWithSearchQueryParams())
        .flatMap(queryParams => this.performSearch(queryParams))
        .subscribe(result => this.result = result);
  }

  private concatenateWithSearchQueryParams(): (source: Observable<{ [key: string]: any; }>) => Observable<{ [key: string]: any; }> {
    return concat(this.router.events
      .filter(navigationEvent => navigationEvent instanceof NavigationEnd)
      .flatMap(navigationEvent => this.route.queryParams.take(1)));
  }

  private bookmarkQueryParams() {
    return this.route.queryParams.take(1);
  }

  private performSearch(queryParams) {
    if (queryParams.hasOwnProperty('searchTerm')) {
      let updateSearch = (resultOrError) => this.declarationSearch = Object.assign(new SearchCriteria(), queryParams);

      return this.searchService
        .search(queryParams)
        .do(updateSearch, updateSearch)
        .onErrorResumeNext(Observable.empty());
    } else {
      this.declarationSearch = new SearchCriteria();
      return Observable.of(null);
    }
  }

  ngOnDestroy() {
    this.routerEventSubscription.unsubscribe();
  }

  onSearch(declarationSearch: SearchCriteria) {
    this.router.navigate(['/'], { queryParams: declarationSearch });
  }

}
