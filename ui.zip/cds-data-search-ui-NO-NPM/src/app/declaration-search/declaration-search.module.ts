import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchSectionComponent } from './search-section/search-section.component';
import { SearchFormComponent } from './search-form/search-form.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule } from '@angular/material/dialog';
import { MatListModule } from '@angular/material/list';
import { MatChipsModule } from '@angular/material/chips';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatExpansionModule } from '@angular/material/expansion';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { SearchService } from './search.service';
import { HttpClientModule } from '@angular/common/http';
import { DeclarationCardComponent } from './declaration-card/declaration-card.component';
import { DeclarationLinesComponent } from './declaration-card/declaration-lines/declaration-lines.component';
import { DeclarationHeaderComponent } from './declaration-card/declaration-header/declaration-header.component';
import { TraderComponent } from './declaration-card/trader/trader.component';
import { SearchFilterComponent } from './search-filter/search-filter.component';
import { FacetedSearchComponent } from './search-filter/faceted-search/faceted-search.component';
import { MatIconModule } from "@angular/material/icon";
import { MatCardModule } from '@angular/material/card';
import { MatDividerModule, MatDatepickerModule, MatFormFieldModule, MAT_DATE_LOCALE } from '@angular/material';
import { FacetNotMatchingPipe } from './facet-not-matching.pipe';
import { EntryDateComponent } from './search-filter/entry-date/entry-date.component';
import {MatMomentDateModule} from '@angular/material-moment-adapter';
import { SearchCriteriaService } from './search-criteria.service';
import { NavigationService } from './navigation.service';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    MatButtonModule,
    MatInputModule,
    MatTableModule,
    MatCheckboxModule,
    MatListModule,
    MatChipsModule,
    MatDialogModule,
    MatCardModule,
    MatIconModule,
    MatGridListModule,
    MatDividerModule,
    MatExpansionModule,
    MatDatepickerModule,
    MatMomentDateModule,
    MatFormFieldModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule
  ],
  declarations: [
    SearchSectionComponent,
    SearchFormComponent,
    DeclarationCardComponent,
    DeclarationLinesComponent,
    TraderComponent,
    SearchFilterComponent,
    FacetedSearchComponent,
    DeclarationHeaderComponent,
    FacetNotMatchingPipe,
    EntryDateComponent],
  exports: [SearchSectionComponent],
  entryComponents: [FacetedSearchComponent],
  providers: [{provide: MAT_DATE_LOCALE, useValue: 'en-GB'}, SearchService, SearchCriteriaService, NavigationService]
})
export class DeclarationSearchModule { }

