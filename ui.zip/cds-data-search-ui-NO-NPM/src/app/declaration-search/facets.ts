import { CountryFacet } from "./countries-facet";

export class Facets {
  originCountries: Array<CountryFacet>;
}
