import {Declaration} from "./declaration";
import {Facets} from "./facets";

export class DeclarationSearchResult {
  hits: Hits;
  declarations: Array<Declaration> = [];
  facets: Facets;
}

export class Hits {
  total: number;
}
