export class SearchCriteria {
    searchTerm: string = "";
    originCountryCode: Array<string>;
    entryDateFrom: string;
    entryDateTo: string;
}
