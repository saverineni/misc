export class SearchCriteria {
  searchTerm: string;
  originCountryCode: Array<string>;
  entryDateFrom: string;
  entryDateTo: string;

  isEmpty(): boolean {
    return this.searchTerm == null && 
      this.originCountryCode == null &&
      this.entryDateFrom == null &&
      this.entryDateTo == null;
  }
}
