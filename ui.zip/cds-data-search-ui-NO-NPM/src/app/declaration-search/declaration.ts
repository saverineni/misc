import { DeclarationLine } from "./declaration-line";

export class Declaration {
    declarationId: string;
    epuNumber: string;
    entryNumber: string;
    entryDate: string;
    route: string;
    dispatchCountry: string;
    destinationCountry: string;
    consigneeTurn: string;
    consignorTurn: string;
    goodsLocation: string;
    transportModeCode: string;
    consigneeName: string;
    consigneePostcode: string;
    consignorName: string;
    consignorPostcode: string;
    lines: Array<DeclarationLine>;
}
