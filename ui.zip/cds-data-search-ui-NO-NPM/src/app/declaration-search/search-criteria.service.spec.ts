import { TestBed, inject, getTestBed } from '@angular/core/testing';
import { SearchCriteriaService } from './search-criteria.service';
import { SearchCriteria } from './search-criteria';

describe('SearchCriteriaService', () => {
  let service: SearchCriteriaService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SearchCriteriaService]
    });

    service = TestBed.get(SearchCriteriaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should give the search criteria observable',(done) => {
    service.searchCriteria.subscribe(
      data => {
        expect(data).toEqual(new SearchCriteria());
        done();
      },
      done.fail
    );
  });

  describe('update', () => {
    let updatedCriteria;
    let criteriaSentToSubscribers;
    let newDataSent = false;

    beforeEach(() => {
      updatedCriteria = new SearchCriteria();
      updatedCriteria.searchTerm = 'term';
      service.update(updatedCriteria);
    });

    beforeEach((done) => {
      service.searchCriteria.subscribe(
        data => {
          criteriaSentToSubscribers = data;
          newDataSent = true;
          done();
        },
        done.fail
      );
    });

    it('should send updated criteria to subscribers', () => {
      expect(criteriaSentToSubscribers).toEqual(updatedCriteria);
    });

    it('should send a copy of the new search criteria, not the the updated original', () => {
      expect(criteriaSentToSubscribers).not.toBe(updatedCriteria);
    });

    describe('without property change', () => {
      beforeEach(() => {
        newDataSent = false;
        service.update(criteriaSentToSubscribers);
      });

      it('should not send the same criteria to subscribers', () => {
        expect(newDataSent).toBeFalsy();
      });
    });
  });
});
