import { TestBed, inject, getTestBed } from '@angular/core/testing';
import { SearchCriteriaService } from './search-criteria.service';
import { SearchCriteria } from './search-criteria';

describe('SearchCriteriaService', () => {
  let service: SearchCriteriaService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SearchCriteriaService]
    });

    service = TestBed.get(SearchCriteriaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should give the search criteria observable',(done) => {
    service.searchCriteria.subscribe(
      data => {
        expect(data).toEqual(new SearchCriteria());
        done();
      },
      done.fail
    );
  });

  describe('update search criteria', () => {
    let updatedCriteria;
    beforeEach(() => {
      updatedCriteria = new SearchCriteria();
      updatedCriteria.searchTerm = 'term';
      service.update(updatedCriteria);
    });

    it('should send out the updated search criteria', (done) => {
      service.searchCriteria.subscribe(
        data => {
          expect(data).toEqual(updatedCriteria);
          done();
        },
        done.fail
      );
    });
  });
});
