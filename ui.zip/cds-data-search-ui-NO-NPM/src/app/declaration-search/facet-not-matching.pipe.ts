import { Pipe, PipeTransform } from '@angular/core';
import { CountryFacet } from './countries-facet';

@Pipe({
  name: 'facetNotMatching'
})
export class FacetNotMatchingPipe implements PipeTransform {
  static matching(facet: CountryFacet, filter: string): boolean {
    return this.nullSafeFacetData(facet).startsWith(filter.toUpperCase());
  }

  transform(facet: CountryFacet, filter: string): boolean {
    const isFiltered = filter != null && filter != '';
    return isFiltered && !FacetNotMatchingPipe.matching(facet, filter);
  }

  private static nullSafeFacetData(facet: CountryFacet) : string {
    return facet.country.code == null ? '' : facet.country.code.toUpperCase();
  }
}
