import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { SearchCriteria } from '../../search-criteria';
import { MatDatepickerInputEvent } from '@angular/material';
import * as moment from 'moment';

@Component({
  selector: 'cds-entry-date-filter',
  templateUrl: './entry-date.component.html',
  styleUrls: ['./entry-date.component.scss']
})
export class EntryDateComponent implements OnInit {
  DATE_FORMAT = "YYYY-MM-DD";

  @Input() declarationSearch: SearchCriteria;
  @Output() submitSearch = new EventEmitter<SearchCriteria>();

  entryDateFrom: string = null;
  entryDateTo: string = null;

  constructor() { }

  ngOnInit() {
  }

  onCancel() {
    this.entryDateFrom = null;
    this.entryDateTo = null;
    this.onApplyFilters(null);
  }

  onApplyFilters(event: MatDatepickerInputEvent<Date>) {
    const newSearch = Object.assign({}, this.declarationSearch) as SearchCriteria;
    
    if (this.entryDateFrom !== null) {
      newSearch.entryDateFrom = moment(this.entryDateFrom).format(this.DATE_FORMAT);
    } else {
      newSearch.entryDateFrom = null;
    }
    if (this.entryDateTo !== null) {
      newSearch.entryDateTo = moment(this.entryDateTo).format(this.DATE_FORMAT);
    } else {
      newSearch.entryDateTo = null;
    }
    
    this.submitSearch.emit(newSearch);
  }

}
