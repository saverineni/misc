import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EntryDateComponent } from './entry-date.component';
import { By } from '@angular/platform-browser';
import { MAT_DATE_LOCALE, MatDatepickerModule, MatFormFieldModule, MatExpansionModule, MatInputModule } from '@angular/material';
import {FormsModule} from "@angular/forms";
import {MatMomentDateModule} from "@angular/material-moment-adapter";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import { SearchCriteriaService } from '../../search-criteria.service';
import { SearchCriteria } from '../../search-criteria';
import * as moment from 'moment';

describe('EntryDateComponent', () => {
  let component: EntryDateComponent;
  let fixture: ComponentFixture<EntryDateComponent>;
  let searchCriteriaService: SearchCriteriaService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MatDatepickerModule, MatMomentDateModule, FormsModule, BrowserAnimationsModule, MatFormFieldModule,
        MatExpansionModule, MatInputModule],
      declarations: [ EntryDateComponent ],
      providers: [
        {provide: MAT_DATE_LOCALE, useValue: 'en-GB'}, SearchCriteriaService
      ]
    })
    .compileComponents();
  }));

  let filterExpansionPanel;

  beforeEach(() => {
    fixture = TestBed.createComponent(EntryDateComponent);
    component = fixture.componentInstance;
    searchCriteriaService = TestBed.get(SearchCriteriaService);
    filterExpansionPanel = fixture.debugElement.query(By.css('.entry-date__header'));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('within expansion panel', () => {

    let fromInput;
    let toInput;
    let applyFiltersButton;
    let cancelButton;
    let fromDate = '1-1-2015';
    let toDate = '1-2-2015';

    beforeEach(() => {
      fromInput = fixture.debugElement.query(By.css('.entry-date__from-input'));
      toInput = fixture.debugElement.query(By.css('.entry-date__to-input'));
      applyFiltersButton = fixture.debugElement.query(By.css('.entry-date__apply-filters-button'));
      cancelButton = fixture.debugElement.query(By.css('.entry-date__cancel-button'));
      filterExpansionPanel.nativeElement.click();
      fixture.detectChanges();
    });

    describe('entry date inputs', () => {

      it('from input should be bound to the from model', () => {
        fromInput.nativeElement.value = fromDate;
        fromInput.nativeElement.dispatchEvent(new Event("input"));
        fixture.detectChanges();
        expect(moment(component.entryDateFrom).format("YYYY-MM-DD")).toEqual("2015-01-01");
      });

      it('to input should be bound to the to model', () => {
        toInput.nativeElement.value = toDate;
        toInput.nativeElement.dispatchEvent(new Event("input"));
        fixture.detectChanges();
        expect(moment(component.entryDateTo).format("YYYY-MM-DD")).toEqual("2015-02-01");
      });

    });

    describe('entry date input validation', () => {


      it('error message is hidden on page load', () => {
        let errorMessage = fixture.debugElement.query(By.css('.entry-date__error-message'));
        expect(errorMessage).toBeFalsy();
      });


      it('error message is displayed when from date is after to date', () => {
        fromInput.nativeElement.value = toDate;
        fromInput.nativeElement.dispatchEvent(new Event("input"));

        toInput.nativeElement.value = fromDate;
        toInput.nativeElement.dispatchEvent(new Event("input"));
        fixture.detectChanges();

        let errorMessage = fixture.debugElement.query(By.css('.entry-date__error-message'));
        expect(errorMessage.nativeElement.hasAttribute('hidden')).toBe(false);
      });


    });

    describe('apply filters button', () => {

      it('should start disabled', () => {
        expect(applyFiltersButton.nativeElement.disabled).toBe(true);
      });

      it('should enable when a valid date is entered into the from input', () => {
        fromInput.nativeElement.value = fromDate;
        fromInput.nativeElement.dispatchEvent(new Event("input"));
        fixture.detectChanges();
        expect(applyFiltersButton.nativeElement.disabled).toBe(false);
      });

      it('should enable when a valid date is entered into the to input', () => {
        toInput.nativeElement.value = toDate;
        toInput.nativeElement.dispatchEvent(new Event("input"));
        fixture.detectChanges();
        expect(applyFiltersButton.nativeElement.disabled).toBe(false);
      });

      it('should remain disabled when an invalid date is entered into the from input', () => {
        fromInput.nativeElement.value = 'invalid';
        fromInput.nativeElement.dispatchEvent(new Event("input"));
        fixture.detectChanges();
        expect(applyFiltersButton.nativeElement.disabled).toBe(true);
      });

      it('should remain disabled when an invalid date is entered into the to input', () => {
        toInput.nativeElement.value = 'invalid';
        toInput.nativeElement.dispatchEvent(new Event("input"));
        fixture.detectChanges();
        expect(applyFiltersButton.nativeElement.disabled).toBe(true);
      });

      it('should remained disabled when from date is after to date', () => {
        fromInput.nativeElement.value = toDate;
        fromInput.nativeElement.dispatchEvent(new Event("input"));

        toInput.nativeElement.value = fromDate;
        toInput.nativeElement.dispatchEvent(new Event("input"));
        fixture.detectChanges();

        expect(applyFiltersButton.nativeElement.disabled).toBe(true);
      });

    });

    describe('submit filters',  () => {
      beforeEach ( () => {
        spyOn(searchCriteriaService, 'update');
        fromInput.nativeElement.value = fromDate;
        fromInput.nativeElement.dispatchEvent(new Event("input"));
        toInput.nativeElement.value = toDate;
        toInput.nativeElement.dispatchEvent(new Event("input"));
        fixture.detectChanges();
      });

      it('should update the search criteria service when apply filters clicked', () => {
        applyFiltersButton.nativeElement.click();
        let searchCriteria = new SearchCriteria();
        searchCriteria.entryDateFrom = '2015-01-01';
        searchCriteria.entryDateTo = '2015-02-01';
        expect(searchCriteriaService.update).toHaveBeenCalledWith(searchCriteria);
      });

      it('clears the dates and should update the search criteria service when cancel clicked', () => {
        cancelButton.nativeElement.click();
        let searchCriteria = new SearchCriteria();
        searchCriteria.entryDateFrom = null;
        searchCriteria.entryDateTo = null;
        expect(searchCriteriaService.update).toHaveBeenCalledWith(searchCriteria);
      });

    });

  });

  describe('entry date filter expansion panel', () => {

    it('should not start expanded', () => {
      expect(filterExpansionPanel.nativeElement.classList).not.toContain('mat-expanded');
    });

    it('should be expanded when clicked', () => {
      filterExpansionPanel.nativeElement.click();
      fixture.detectChanges();
      expect(filterExpansionPanel.nativeElement.classList).toContain('mat-expanded');
    });

    it('should collapse when clicked again', () => {
      filterExpansionPanel.nativeElement.click();
      filterExpansionPanel.nativeElement.click();
      fixture.detectChanges();
      expect(filterExpansionPanel.nativeElement.classList).not.toContain('mat-expanded');
    });

  });

});
