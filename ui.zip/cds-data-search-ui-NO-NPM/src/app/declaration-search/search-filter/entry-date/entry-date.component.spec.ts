import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EntryDateComponent } from './entry-date.component';
import { By } from '@angular/platform-browser';
import { MAT_DATE_LOCALE, MatDatepickerModule, MatFormFieldModule, MatExpansionModule, MatInputModule } from '@angular/material';
import {FormsModule} from "@angular/forms";
import {MatMomentDateModule} from "@angular/material-moment-adapter";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import { SearchCriteriaService } from '../../search-criteria.service';

describe('EntryDateComponent', () => {
  let component: EntryDateComponent;
  let fixture: ComponentFixture<EntryDateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MatDatepickerModule, MatMomentDateModule, FormsModule, BrowserAnimationsModule, MatFormFieldModule,
        MatExpansionModule, MatInputModule],
      declarations: [ EntryDateComponent ],
      providers: [
        {provide: MAT_DATE_LOCALE, useValue: 'en-GB'}, SearchCriteriaService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EntryDateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  function getEntryDateFilterExpansionPanel() {
    return fixture.debugElement.query(By.css('.entry-date__header'));
  };

  describe('entry date filter expansion panel', () => {

    it('should not be expanded', () => {
      expect(getEntryDateFilterExpansionPanel().nativeElement.classList).not.toContain('mat-expanded');
    });

    it('should be expanded when clicked', () => {
      getEntryDateFilterExpansionPanel().nativeElement.click();
      fixture.detectChanges();
      expect(getEntryDateFilterExpansionPanel().nativeElement.classList).toContain('mat-expanded');
    });

    it('should collapse when clicked again', () => {
      getEntryDateFilterExpansionPanel().nativeElement.click();
      getEntryDateFilterExpansionPanel().nativeElement.click();
      fixture.detectChanges();
      expect(getEntryDateFilterExpansionPanel().nativeElement.classList).not.toContain('mat-expanded');
    });
      
  });

});
