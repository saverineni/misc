import {Component, Input, OnInit} from '@angular/core';
import {Facets} from "../facets";
import {MatDialog, MatDialogRef} from "@angular/material";
import {FacetedSearchComponent} from "./faceted-search/faceted-search.component";
import {SearchCriteria} from '../search-criteria';


@Component({
  selector: 'cds-search-filter',
  templateUrl: './search-filter.component.html',
  styleUrls: ['./search-filter.component.scss']
})

export class SearchFilterComponent  {
  
  @Input() facets: Facets;

  countryOfOriginDialogRef: MatDialogRef<FacetedSearchComponent>

  constructor(public dialog: MatDialog) { }

  openCountryOfOriginDialog() {
    this.countryOfOriginDialogRef = this.dialog.open(
      FacetedSearchComponent,
      {
        data: {countries: this.facets.originCountries},
        width: "50vw"
      }
    );
  }

}
