import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {SearchFilterComponent} from './search-filter.component';
import {Facets} from "../facets";
import {FacetedSearchComponent} from "./faceted-search/faceted-search.component";
import {By} from "@angular/platform-browser";
import {DebugElement, Directive, Input} from "@angular/core";
import {BrowserDynamicTestingModule} from "@angular/platform-browser-dynamic/testing";
import {MatDialog, MatDialogModule} from '@angular/material/dialog';
import {MatListModule} from "@angular/material/list";
import {CountryFacet} from "../countries-facet";
import {MatChipsModule, MatFormFieldModule, MatIconModule} from "@angular/material";
import {FacetNotMatchingPipe} from '../facet-not-matching.pipe';
import {FormsModule} from "@angular/forms";
import {FlexLayoutModule} from "@angular/flex-layout";
import {MatInputModule} from "@angular/material/input";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {SearchCriteria} from '../search-criteria';

@Directive({
  selector: 'cds-entry-date-filter'
})
export class EntryDateFilterStub {}

describe('SearchFilterComponent', () => {
  let component: SearchFilterComponent;
  let fixture: ComponentFixture<SearchFilterComponent>;
  let filter: DebugElement;

  let dialog = {
    open(a, b) { }
  } as MatDialog;

  const originCountriesFacet = [new CountryFacet()];
  const declarationSearch = new SearchCriteria();

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MatDialogModule, MatListModule, MatChipsModule, MatIconModule , MatInputModule, BrowserAnimationsModule , FlexLayoutModule, FormsModule],
      declarations: [SearchFilterComponent, FacetedSearchComponent , FacetNotMatchingPipe, EntryDateFilterStub],
      providers: [{
        provide: MatDialog,
        useValue: dialog
      }]
    }).overrideModule(BrowserDynamicTestingModule, {
      set: {
        entryComponents: [FacetedSearchComponent]
      }
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFilterComponent);
    component = fixture.componentInstance;
    component.facets = new Facets();
    component.facets.originCountries = originCountriesFacet;
    fixture.detectChanges();

    filter = fixture.debugElement.query(By.css('.search-filter'));
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should contain the filters label', () => {
    let label = filter.query(By.css('.search-filter__label')).nativeElement;
    expect(label.innerText).toBe('Filters')
  });

  it('should contain the country of origin button', () => {
    let countryOfOriginButton = filter.query(By.css('.search-filter__country-of-origin'));
    expect(countryOfOriginButton).toBeTruthy();
  });

  describe('click on country of origin button', () => {
    beforeEach(() => {
      spyOn(component.dialog, 'open').and.callThrough();
    });

    it('opens the dialog window', () => {
      expect(component.dialog.open).toHaveBeenCalledTimes(0);
      let countryOfOriginButton = filter.query(By.css('.search-filter__country-of-origin'));
      countryOfOriginButton.nativeElement.click();
      fixture.detectChanges();
      expect(component.dialog.open).toHaveBeenCalledWith(
        FacetedSearchComponent,
        {
          data: {
            countries: originCountriesFacet,
          },
          width: "50vw"
        });
    });
  });
});
