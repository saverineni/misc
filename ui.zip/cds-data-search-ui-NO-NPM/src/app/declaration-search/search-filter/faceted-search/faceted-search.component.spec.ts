import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {FacetedSearchComponent} from './faceted-search.component';
import {MatDialogModule} from "@angular/material/dialog";
import {CountryFacet} from "../../countries-facet";
import {Country} from "../../country";
import {MAT_DIALOG_DATA, MatChipsModule, MatDialogRef, MatFormFieldModule, MatIconModule} from "@angular/material";
import {By} from "@angular/platform-browser";
import {DebugElement} from "@angular/core/src/debug/debug_node";
import {MatListModule} from "@angular/material/list";
import {FacetNotMatchingPipe} from '../../facet-not-matching.pipe';
import {FormsModule} from "@angular/forms";
import {FlexLayoutModule} from "@angular/flex-layout";
import {MatInputModule} from "@angular/material/input";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";


function newFacet(code, count) {
  let facet = new CountryFacet();
  let country = new Country();

  country.code = code;
  facet.country = country;
  facet.count = count;

  return facet;
}

const countryNames = ['GB (4)', 'CH (3)', 'AB (1)', 'AD (1)', 'EF (1)'];

describe('FacetedSearchComponent', () => {
  let component: FacetedSearchComponent;
  let fixture: ComponentFixture<FacetedSearchComponent>;
  let countryFacetForUK: CountryFacet;
  let countryFacetForCH: CountryFacet;
  let matDialogRef: MatDialogRef<any>;
  let countriesFacet: Array<CountryFacet>;

  beforeEach(async(() => {
    countryFacetForUK = newFacet('GB', 4);;
    countryFacetForCH = newFacet('CH', 3);

    matDialogRef = {close: () => {}} as MatDialogRef<any>;
    spyOn(matDialogRef, 'close');

    countriesFacet = [ countryFacetForUK, countryFacetForCH, newFacet('AB', 1), newFacet('AD', 1), newFacet('EF', 1) ];

    TestBed.configureTestingModule({
      imports: [
        MatDialogModule,
        MatChipsModule,
        MatIconModule,
        MatListModule,
        MatInputModule,
        FlexLayoutModule,
        BrowserAnimationsModule,
        FormsModule
      ],
      declarations: [FacetedSearchComponent , FacetNotMatchingPipe],
      providers: [
        {provide: MAT_DIALOG_DATA, useValue: { countries: countriesFacet }},
        {provide: MatDialogRef, useValue: matDialogRef}
      ]
    })
    .compileComponents();
  }));

  let displayedCountryNames;

  beforeEach(() => {
    fixture = TestBed.createComponent(FacetedSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    displayedCountryNames = () => {
      const countryList = fixture.debugElement.queryAll(By.css('.faceted-search__link'));
      return countryList.map(countryElement => countryElement.nativeElement.textContent);
    }
  });

  describe('given list of countries' , () => {

    it('should display title',() => {
      const title: HTMLElement = fixture.debugElement.query(By.css('.faceted-search__title')).nativeElement;
      expect(title.textContent).toEqual('Select country of origin');
    });

    it('should display cancel button',() => {
      const cancelButton: DebugElement = fixture.debugElement.query(By.css('.faceted-search__cancel'));
      expect(cancelButton).toBeTruthy();
    });

    it('should display apply filters button',() => {
      const applyFiltersButton: DebugElement = fixture.debugElement.query(By.css('.faceted-search__apply-filters'));
      expect(applyFiltersButton).toBeTruthy();
    });

    it('should display data on load', () => {
      expect(displayedCountryNames()).toEqual(countryNames);
    });

    it('should not contain any chips on load', () => {
      let chips: DebugElement[] = fixture.debugElement.queryAll(By.css('.mat-chip'));
      expect(chips.length).toBe(0);
    });

    it('should have a label for free text search field', () => {
      const searchTerm = fixture.debugElement.query(By.css('.faceted-search__filter'));
      expect(searchTerm.nativeElement.labels[0].textContent).toEqual("Search for a Country");
    });

    describe('selecting country', () => {
      let chips: DebugElement[];
      beforeEach(() => {
        countryFacetForUK.selected = true;

        fixture.detectChanges();

        chips = fixture.debugElement.queryAll(By.css('.faceted-search__selection'));
      });

      it('should cause chips to be displayed', () => {
        expect(chips.length).toBe(1);
      });

      it('should display chips with the country details displayed', () => {
        const countryGBChip: HTMLElement = chips[0].nativeElement;
        expect(chips[0].nativeElement.textContent.trim()).toContain('GB');
      });
    });

    describe('clicking cancel', () => {
      let cancelButton;

      beforeEach(() => {
        countryFacetForUK.selected = true;
        fixture.detectChanges();
        cancelButton = fixture.debugElement.query(By.css('.faceted-search__cancel')).nativeElement as HTMLInputElement;
        cancelButton.click();
        fixture.detectChanges();
      });

      it('unselects countries', () => {
        expect(component.selectedCountries().length).toBe(0);
      });

      it('closes dialog', () => {
        expect(matDialogRef.close).toHaveBeenCalled();
      });
    });

    describe('user clicks country in list',() => {

      let countryGBLink : HTMLInputElement;

      beforeEach(() => {
        countryGBLink = fixture.debugElement.query(By.css('.faceted-search__link[data-facet-id="GB"]')).nativeElement as HTMLInputElement;
        expect(countryGBLink).toBeTruthy();
        countryGBLink.click();
        fixture.detectChanges();
      });

      it('should update selection list when link is clicked' ,() => {
        expect(component.selectedCountries().length).toBe(1);
        expect(component.selectedCountries()).toContain(countryFacetForUK);
      });

      it('should disable country link when selected', () => {
        let disabledLink = fixture.debugElement.query(By.css('.faceted-search__link--selected[data-facet-id="GB"]'));

        expect(disabledLink).toBeTruthy();
      });
    });

    describe('user clicks chips',() => {
      beforeEach(() => {
        countryFacetForUK.selected = true;
        countryFacetForCH.selected = true;
        fixture.detectChanges();

        let removeGBChip = fixture.debugElement.query(By.css('.faceted-search__selection[data-facet-id="GB"] .faceted-search__selection-remove')).nativeElement as HTMLInputElement;
        expect(removeGBChip).toBeTruthy();
        removeGBChip.click();

        fixture.detectChanges();
      });

      it('should remove the chip', () => {
        let chips = fixture.debugElement.queryAll(By.css('.faceted-search__selection'));

        expect(chips.length).toBe(1);
        expect(chips[0].nativeElement.getAttribute('data-facet-id')).toBe('CH');
      });

      it('should re-enable country link when chip is removed' , () => {
        let gbLink = fixture.debugElement.query(By.css('.faceted-search__link--selected[data-facet-id="GB"]'));

        expect(gbLink == null).toBeTruthy();
      });
    });

    describe('filter selection list', () => {
      let facetFilter;

      describe('no search results',() => {
        beforeEach(() => {
          fixture.detectChanges();

          facetFilter = fixture.debugElement.query(By.css('.faceted-search__filter')).nativeElement;
          facetFilter.value = 'zzz';
          facetFilter.dispatchEvent(new Event('input'));
          fixture.detectChanges();
        });

        it('displays the no results found message',() => {
          const noResults = fixture.debugElement.query(By.css('.faceted-search__no-results-found')).nativeElement;
          expect(noResults.textContent).toBe('No results found');
        });

        it('hides all the facets',() => {
          const hiddenCountryList = fixture.debugElement.queryAll(By.css('.faceted-search__link--hidden'));
          expect(hiddenCountryList.length).toEqual(5);
        });
      });

      describe('has search results',() => {
        beforeEach(() => {
          fixture.detectChanges();

          facetFilter = fixture.debugElement.query(By.css('.faceted-search__filter')).nativeElement;
          facetFilter.value = 'A';
          facetFilter.dispatchEvent(new Event('input'));
          fixture.detectChanges();
        });

        it('should only show items that start with the search term', () => {
          const hiddenCountryList = fixture.debugElement.queryAll(By.css('.faceted-search__link--hidden'));
          const hiddenCountryNames = hiddenCountryList.map(countryElement => countryElement.nativeElement.textContent);

          expect(hiddenCountryNames).toEqual(['GB (4)', 'CH (3)', 'EF (1)']);
        });

        it('should not display no results found message',() => {
          const noResults = fixture.debugElement.query(By.css('.faceted-search__no-results-found'));
          expect(noResults == null).toBeTruthy();
        });

        describe('and remove the term', () => {

          it('should display all the results', () => {
            facetFilter.value = '';
            facetFilter.dispatchEvent(new Event('keyup'));
            fixture.detectChanges();

            expect(displayedCountryNames()).toEqual(countryNames);
          });
        });
      });
    });
  });
});
