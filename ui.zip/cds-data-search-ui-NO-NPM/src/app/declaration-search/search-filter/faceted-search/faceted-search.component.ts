import {Component, Inject, ViewEncapsulation} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material";
import {CountryFacet} from "../../countries-facet";
import {FacetNotMatchingPipe} from "../../facet-not-matching.pipe";

@Component({
  selector: 'app-country-of-origin',
  templateUrl: './faceted-search.component.html',
  styleUrls: ['./faceted-search.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FacetedSearchComponent {

  countries: Array<CountryFacet>;
  filter: string = '';

  constructor(@Inject(MAT_DIALOG_DATA) data, private dialogRef: MatDialogRef<FacetedSearchComponent>) {
    this.countries = data.countries;
  }

  onDeselect(facet) {
    facet.selected = false;
  }

  onSelect(facet) {
    facet.selected = true;
  }

  selectedCountries() {
    return this.countries.filter(facet => facet.selected);
  }

  cancel() {
    this.countries.forEach(facet => facet.selected = false);
    this.dialogRef.close();
  }

  nonMatching(filter) {
    return this.countries.find(facet => FacetNotMatchingPipe.matching(facet, filter)) === undefined;
  }

}
