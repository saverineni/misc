import {Injectable} from '@angular/core';
import {SearchCriteria} from './search-criteria';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpParams} from '@angular/common/http';
import 'rxjs/add/operator/map';
import {DeclarationSearchResult} from './declaration-search-result';
import {Declaration} from './declaration';

@Injectable()
export class SearchService {

  constructor(private http: HttpClient) {
  }

  search(search: SearchCriteria): Observable<any> {
    return this.http.get<DeclarationSearchResult>(
      "/api/declarations",
      {
        params: new HttpParams().set('searchTerm', search.searchTerm)
      })
      .map(searchResult => searchResult as DeclarationSearchResult);
  }

}
