import { Injectable } from '@angular/core';
import { SearchCriteria } from './search-criteria';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class SearchCriteriaService {

  private searchCriteriaSource = new BehaviorSubject(new SearchCriteria());
  private _searchCriteria = this.searchCriteriaSource.asObservable();

  get searchCriteria(): Observable<any> {
    return this._searchCriteria;
  }
}
