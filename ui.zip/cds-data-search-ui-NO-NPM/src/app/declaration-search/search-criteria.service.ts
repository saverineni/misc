import { Injectable } from '@angular/core';
import { SearchCriteria } from './search-criteria';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { isEqual } from 'lodash';

@Injectable()
export class SearchCriteriaService {

  private _currentCriteria: SearchCriteria = new SearchCriteria();
  private searchCriteriaSource = new BehaviorSubject(this._currentCriteria);
  private _searchCriteriaUpdates = this.searchCriteriaSource.asObservable();

  get searchCriteria(): Observable<any> {
    return this._searchCriteriaUpdates;
  }

  update(searchCriteria: SearchCriteria) {
    if (!isEqual(this._currentCriteria, searchCriteria)) {
      this._currentCriteria = searchCriteria;
      this.searchCriteriaSource.next(Object.assign(new SearchCriteria(), searchCriteria));
    }
  }
}
