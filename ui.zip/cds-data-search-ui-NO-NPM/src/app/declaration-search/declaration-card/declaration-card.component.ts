import { Component, Input, OnInit } from '@angular/core';
import { DeclarationSearchResult } from '../declaration-search-result';
import { Declaration } from '../declaration';
import { SearchCriteria } from '../search-criteria';

@Component({
  selector: 'cds-declaration-card',
  templateUrl: './declaration-card.component.html',
  styleUrls: ['./declaration-card.component.scss']
})
export class DeclarationCardComponent implements OnInit {

  @Input() declaration: Declaration;

  panelAction: string;

  ngOnInit() {
    this.panelAction = 'Show';
  }

}
