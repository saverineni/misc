import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {DeclarationCardComponent} from './declaration-card.component';
import {By} from '@angular/platform-browser';
import {DeclarationSearchResult} from '../declaration-search-result';
import {Declaration} from '../declaration';
import {Component, Directive, Input} from '@angular/core';
import {DeclarationLine} from "../declaration-line";
import { SearchCriteria } from '../search-criteria';
import {MatCardModule, MatDividerModule, MatExpansionModule} from '@angular/material';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

@Directive({
  selector: 'cds-declaration-header'
})
export class DeclarationHeaderStub {
  @Input() declaration: Declaration;
}

@Directive({
  selector: 'cds-declaration-lines'
})
export class DeclarationLinesStub {
  @Input() declaration: Declaration;
}

@Component({
  selector: 'cds-trader',
  template :'{{ trader?.number }}-{{trader?.name}}-{{trader?.postcode}}'
})
export class TraderComponentStub {
  @Input() trader;
}

// Required this test component because SearchResultsComponent implements OnChanges
// https://medium.com/@christophkrautz/testing-ngonchanges-in-angular-components-bbb3b4650ee8
@Component({
  template: '<cds-declaration-card [declaration]="declaration"></cds-declaration-card>'
})
class TestHostComponent {
  declaration: Declaration;
}

describe('DeclarationCardComponent', () => {
  let component: TestHostComponent;
  let fixture: ComponentFixture<TestHostComponent>;
  let declaration;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MatCardModule, MatDividerModule, MatExpansionModule, BrowserAnimationsModule],
      declarations: [
        DeclarationCardComponent, DeclarationHeaderStub, DeclarationLinesStub,
        TraderComponentStub , TestHostComponent
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestHostComponent);
    component = fixture.componentInstance;
    declaration = new Declaration();

    component.declaration = declaration;
    fixture.detectChanges();
  });

  beforeEach(() => {
    declaration.declarationId = 'declarationId';
    declaration.epuNumber = 'epuNumber';
    declaration.entryNumber = 'entryNumber';
    declaration.entryDate = 'entryDate';
    declaration.route = 'route';
    declaration.dispatchCountry = 'dispatchCountry';
    declaration.destinationCountry = 'destinationCountry';
    declaration.consigneeTurn = 'consigneeTurn';
    declaration.consignorTurn = 'consignorTurn';
    declaration.goodsLocation = 'goodsLocation';
    declaration.transportModeCode = 'transportModeCode';
    declaration.consigneeName = 'consigneeName';
    declaration.consigneePostcode = 'consigneePostcode';
    declaration.consignorName = 'consignorName';
    declaration.consignorPostcode = 'consignorPostcode';
    declaration.lines = [ new DeclarationLine() ];
    fixture.detectChanges();
  });

  it('should display the declarations', () => {
    expect(fixture.debugElement.query(By.css('.search-results-cards__declarations')) === null).toEqual(false);
  });

  function getDeclarationHeaderExpansionPanel() {
    return fixture.debugElement.query(By.css('.search-results-expansion-panel__header'));
  };

  describe('declaration header expansion panel', () => {

    it('should not be expanded', () => {
      expect(getDeclarationHeaderExpansionPanel().nativeElement.classList).not.toContain('mat-expanded');
    });

    describe('item count', () => {
      it('null items', () => {
        declaration.lines = null;
        fixture.detectChanges();
        const itemCount = fixture.debugElement.query(By.css('.search-results-expansion-panel__item-count'));
        expect(itemCount.nativeElement.innerText).toEqual('0 Items');
      });

      it('0 items', () => {
        declaration.lines = [];
        fixture.detectChanges();
        const itemCount = fixture.debugElement.query(By.css('.search-results-expansion-panel__item-count'));
        expect(itemCount.nativeElement.innerText).toEqual('0 Items');
      });

      it('1 item', () => {
        declaration.lines = [ {} ];
        fixture.detectChanges();
        const itemCount = fixture.debugElement.query(By.css('.search-results-expansion-panel__item-count'));
        expect(itemCount.nativeElement.innerText).toEqual('Show 1 Item');
      });

      it('2 items', () => {
        declaration.lines = [ {}, {} ];
        fixture.detectChanges();
        const itemCount = fixture.debugElement.query(By.css('.search-results-expansion-panel__item-count'));
        expect(itemCount.nativeElement.innerText).toEqual('Show 2 Items');
      });
    });

  });

  describe('declaration header expansion panel after clicking the header', () => {

    beforeEach(() => {
      getDeclarationHeaderExpansionPanel().nativeElement.click();
      fixture.detectChanges();
    });

    it('should be expanded', () => {
      expect(getDeclarationHeaderExpansionPanel().nativeElement.classList).toContain('mat-expanded');
    });

    it('item count', () => {
      declaration.lines = [ {} ];
      fixture.detectChanges();
      const itemCount = fixture.debugElement.query(By.css('.search-results-expansion-panel__item-count'));
      expect(itemCount.nativeElement.innerText).toEqual('Hide 1 Item');
    });

    it('should collapse when clicked', () => {
      getDeclarationHeaderExpansionPanel().nativeElement.click();
      fixture.detectChanges();
      expect(getDeclarationHeaderExpansionPanel().nativeElement.classList).not.toContain('mat-expanded');
    });

  });

});
