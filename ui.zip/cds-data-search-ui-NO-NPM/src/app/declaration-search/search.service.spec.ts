import {getTestBed, TestBed} from '@angular/core/testing';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {SearchService} from './search.service';
import {SearchCriteria} from './search-criteria';
import {DeclarationSearchResult, Hits} from './declaration-search-result';
import {Declaration} from './declaration';


describe('SearchService', () => {
  let httpMock: HttpTestingController;
  let service: SearchService;
  const declarationSearch: SearchCriteria = new SearchCriteria();

  beforeEach(() => {
    declarationSearch.searchTerm = "123-456";
    TestBed.configureTestingModule({
      providers: [SearchService],
      imports: [HttpClientTestingModule]
    });
    httpMock = getTestBed().get(HttpTestingController);
    service = getTestBed().get(SearchService);
  });

  function mockRequest() {
    return httpMock.expectOne(`/api/declarations?searchTerm=${declarationSearch.searchTerm}`);
  }

  it('should submit search request', () => {
    service.search(declarationSearch).toPromise();
    const testRequest = mockRequest();
    testRequest.flush({});
    expect(testRequest.request.method).toBe("GET");
  });

  it('should throw error on 500', (done) => {
    const errorEvent = new ErrorEvent('');
    service.search(declarationSearch).subscribe(
      result => done.fail('expect error'),
      error => {
        expect(error.error).toBe(errorEvent);
        done();
      });
    const testRequest = mockRequest();
    testRequest.error(errorEvent, {status: 500});
  });

  it('should return Declaration search result', () => {
    let actual: DeclarationSearchResult = null;
    service.search(declarationSearch).subscribe(result => actual = result);
    const testRequest = mockRequest();
    testRequest.flush({hits: new Hits(), declarations: Array.of(new Declaration())}, {status: 200, statusText: ''});
    expect(actual.declarations.length).toEqual(1);
  });

  it('should parse the json response', () => {
    const declaration = new Declaration();
    declaration.declarationId = declarationSearch.searchTerm;
    const hits = new Hits();
    hits.total = 1;

    let actual: DeclarationSearchResult = null;
    service.search(declarationSearch).subscribe(result => actual = result);
    const testRequest = mockRequest();
    testRequest.flush({hits, declarations: Array.of(declaration)}, {status: 200, statusText: ''});
    expect(actual.declarations[0]).toEqual(declaration);
    expect(actual.hits).toEqual(hits);
  });

  afterEach(() => {
    httpMock.verify();
  });
});
