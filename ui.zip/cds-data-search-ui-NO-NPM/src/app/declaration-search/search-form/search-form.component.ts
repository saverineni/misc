import { Component, Input, OnInit, OnChanges, Output, EventEmitter, ViewChild, ChangeDetectorRef, SimpleChanges } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SearchCriteria } from '../search-criteria';

@Component({
  selector: 'cds-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.scss']
})
export class SearchFormComponent implements OnInit, OnChanges {

  @Input() declarationSearch: SearchCriteria;
  @Output() submitSearch = new EventEmitter<SearchCriteria>();
  @ViewChild('searchInput') searchInput;
  searchTerm;

  constructor(private route: ActivatedRoute, private cdr: ChangeDetectorRef) { }

  ngOnInit() {
    this.updateSearchTerm();
    this.route.queryParams
      .filter(queryParams => !queryParams.hasOwnProperty('searchTerm'))
      .subscribe(queryParams => this.focusDeclarationSearchField());
  }

  private updateSearchTerm() {
    this.searchTerm = this.declarationSearch.searchTerm;
  }

  ngAfterViewInit() {
    this.focusDeclarationSearchField();
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.updateSearchTerm();
  }

  private focusDeclarationSearchField() {
    this.searchInput.nativeElement.focus();
    this.cdr.detectChanges();
  }

  onSubmitSearch() {
    const newSearch = Object.assign(new SearchCriteria(), this.declarationSearch);
    newSearch.searchTerm = this.searchTerm;
    this.submitSearch.emit(newSearch);
  }
}
