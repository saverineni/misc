import { Component, Input, OnInit, OnChanges, Output, EventEmitter, ViewChild, ChangeDetectorRef, SimpleChanges } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SearchCriteria } from '../search-criteria';
import { SearchCriteriaService } from '../search-criteria.service';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';

@Component({
  selector: 'cds-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.scss']
})
export class SearchFormComponent implements OnInit, OnDestroy, OnChanges {
  @ViewChild('searchInput') searchInput;
  searchTerm;
  private searchCriteria;
  private subscription;

  constructor(
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef,
    private searchCriteriaService: SearchCriteriaService) { }

  ngOnInit() {
    this.subscription = this.searchCriteriaService.searchCriteria.subscribe(
      data => {
        this.searchCriteria = data;
        this.searchTerm = this.searchCriteria.searchTerm;
      }
    );
    this.route.queryParams
      .filter(queryParams => !queryParams.hasOwnProperty('searchTerm'))
      .subscribe(queryParams => this.focusDeclarationSearchField());
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.searchTerm = this.searchCriteria.searchTerm;
  }

  ngAfterViewInit() {
    this.focusDeclarationSearchField();
  }

  private focusDeclarationSearchField() {
    this.searchInput.nativeElement.focus();
    this.cdr.detectChanges();
  }

  onSubmitSearch() {
    if (this.searchTerm == null) {
      this.searchTerm = '';
    }
    this.searchCriteria.searchTerm = this.searchTerm;
    this.searchCriteriaService.update(this.searchCriteria);
  }
}
