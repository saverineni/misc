import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {FlexLayoutModule} from '@angular/flex-layout';
import {FormsModule} from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import {By} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ActivatedRoute} from '@angular/router';
import {ReplaySubject} from 'rxjs';
import {SearchFormComponent} from './search-form.component';
import { SearchCriteria } from '../search-criteria';

class ActivatedRouteStub {

  private subject = new ReplaySubject<any>();

  readonly queryParams = this.subject.asObservable();

  setQueryParams(queryParams?: any) {
    this.subject.next(queryParams);
  };
}


describe('SearchFormComponent', () => {
  let component: SearchFormComponent;
  let fixture: ComponentFixture<SearchFormComponent>;
  let newRoute;

  beforeEach(async(() => {
    newRoute = new ActivatedRouteStub();

    TestBed.configureTestingModule({
      declarations: [SearchFormComponent],
      providers: [
        {provide: ActivatedRoute, useValue: newRoute}
      ],
      imports: [
        FlexLayoutModule,
        MatButtonModule,
        MatInputModule,
        BrowserAnimationsModule,
        FormsModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFormComponent);
    component = fixture.componentInstance;
    component.declarationSearch = new SearchCriteria();
    fixture.detectChanges();
  });

  describe('search form', () => {
    let form;
    beforeEach(async(() => {
      form = fixture.debugElement.query(By.css('.search-form'));
    }));

    it('should be displayed', () => {
      expect(form).toBeTruthy();
    });

    describe('Free text search field', () => {
      const expected = 'expected-term';
      let searchTerm;
      beforeEach(() => {
        searchTerm = form.query(By.css('.search-form__searchterm-input'));
      });

      it('should have a free text search field', () => {
        expect(searchTerm).toBeTruthy();
      });

      it('should have focus', () => {
        const focusedElement = form.query(By.css(":focus")).nativeElement;
        expect(searchTerm.nativeElement).toBe(focusedElement);
      });

      it('should have a label for free text search field', () => {
        expect(searchTerm.nativeElement.labels[0].textContent).toEqual("Declaration Search");
      });

      it('should be bound to the model', () => {
        const searchTermField = searchTerm.nativeElement;
        searchTermField.value = expected;
        searchTermField.dispatchEvent(new Event("input"));
        fixture.detectChanges();

        expect(component.searchTerm).toEqual(expected);
      });

      it('should be populated declaration search term on init', () => {
        component.declarationSearch = new SearchCriteria();
        component.declarationSearch.searchTerm = expected;

        component.ngOnInit();

        expect(component.searchTerm).toEqual(expected);
      })

      it('should have focus after angular router navigation back to home', () => {
        form.query(By.css('.search-form__button')).nativeElement.focus();

        newRoute.setQueryParams({});

        const focusedElement = form.query(By.css(":focus")).nativeElement;
        expect(searchTerm.nativeElement).toBe(focusedElement);
      });

      it('should not acquire focus after other angular router navigation', () => {
        const searchButton = form.query(By.css('.search-form__button')).nativeElement;
        searchButton.focus();

        newRoute.setQueryParams({searchTerm: ''});

        const focusedElement = form.query(By.css(":focus")).nativeElement;
        expect(searchButton).toBe(focusedElement);
      });
    });

    describe('search button', () => {

      let searchbutton;
      let searchTermField;
      beforeEach(() => {
        searchbutton = form.query(By.css('.search-form__button'));
        searchTermField = form.query(By.css('.search-form__searchterm-input')).nativeElement;
        fixture.detectChanges();
      });

      it('should have a button', () => {
        expect(searchbutton).toBeTruthy();
      });

      it('enabled on page load', () => {
        expect(searchbutton.nativeElement.disabled).toEqual(false);
      });

    });

    describe('submit form', () => {
      let published = null;

      function subscribeToSubmit() {
        component.submitSearch.subscribe(search => {
          published = search;
        });
      };

      const searchTerm = "search term";
      beforeEach(() => {
        subscribeToSubmit();
        component.searchTerm = searchTerm;
      });

      it('should emit event when i click search button', () => {
        form.query(By.css('.search-form__button')).nativeElement.click();
        expect(published.searchTerm).toEqual(searchTerm);
      });

      it('should emit event on submit event', () => {
        form.nativeElement.dispatchEvent(new Event("submit"));
        expect(published.searchTerm).toEqual(searchTerm);
      });
    });
  });
});
