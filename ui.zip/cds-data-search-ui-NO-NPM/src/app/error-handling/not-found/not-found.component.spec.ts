import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { NotFoundComponent } from './not-found.component';
import { UserService } from '../../authentication/user.service';
import { By } from '@angular/platform-browser';
import { Component } from '@angular/core';
import { Location } from "@angular/common";
import { Router } from '@angular/router';

class UserServiceStub {
  signedIn: false;

  isSignedIn() {
    return this.signedIn;
  }

  setSignedIn(signedId) {
    this.signedIn = signedId;
  }
}

@Component({
  template: `SignIn`
})
class SignInComponentStub {}

describe('NotFoundComponent', () => {
  let component: NotFoundComponent;
  let fixture: ComponentFixture<NotFoundComponent>;
  let userService = new UserServiceStub();
  let location;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes([{path: 'signin', component: SignInComponentStub}])],
      providers: [ { provide: UserService, useValue: userService } ],
      declarations: [ NotFoundComponent, SignInComponentStub ]
    })
    .compileComponents();

    location = TestBed.get(Location);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotFoundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  function signInButton(fixture) {
    return fixture.debugElement.query(By.css('.not-found__sign-in-button'));
  }  

  describe('given not signed in',  () => {
    beforeEach(() => {
      userService.setSignedIn(false);
      fixture.detectChanges();
    });

    it('then the not signed in message is displayed', () => {
      expect(fixture.debugElement.query(By.css('.not-found__unauthenticated-message')) != null).toEqual(true);
    });

    it('then the signed in message is not displayed', () => {
      expect(fixture.debugElement.query(By.css('.not-found__authenticated-message')) == null).toEqual(true);
    });
    
    it('then the sign in button is displayed', () => {
      expect(signInButton(fixture) != null).toEqual(true);
    });

    describe('and I click the sign in button',  () => {
      beforeEach(fakeAsync(() => {
        signInButton(fixture).nativeElement.click();
        tick();
      }));

      it('then the sign in page is the current page', () => {
        expect(location.path()).toBe('/signin');
      });
    });

  });

  describe('given signed in',  () => {
    beforeEach(() => {
      userService.setSignedIn(true);
      fixture.detectChanges();
    });

    it('then the signed in message is displayed', () => {
      expect(fixture.debugElement.query(By.css('.not-found__authenticated-message')) != null).toEqual(true);
    });

    it('then the not signed in message is not displayed', () => {
      expect(fixture.debugElement.query(By.css('.not-found__unauthenticated-message')) == null).toEqual(true);
    });

    it('then the sign in button is not displayed', () => {
      expect(signInButton(fixture) == null).toEqual(true);
    });
    
  });

});
