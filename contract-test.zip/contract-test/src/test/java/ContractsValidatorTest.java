import org.json.JSONException;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;

public class ContractsValidatorTest {


    @Test
    public void validateSettings() throws IOException, JSONException {
        String fileContent = FileLoaderUtils.getFileContent(FileLoaderUtils.ACTUAL_SETTINGS_FILE);
        ContractsValidator.validateSettingsContract(fileContent);

    }
}