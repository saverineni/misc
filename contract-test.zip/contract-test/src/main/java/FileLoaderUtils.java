import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileLoaderUtils {

    public static final String EXPECTED_MAPPINGS_FILE = "expected/mappings.json";
    public static final String ACTUAL_SETTINGS_FILE = "actual/settings.json";

    public static String getFileContent(String file) {
        String response = "";
        try {
            Path path = Paths.get(FileLoaderUtils.class.getClassLoader().getResource(file).toURI());
            response = org.apache.commons.io.FileUtils.readFileToString(path.toFile(), "UTF-8");
        } catch (IOException | URISyntaxException e) {
            e.printStackTrace();
        }
        return response;
    }
}