

import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import org.json.JSONException;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Map;

class ContractsValidator {

    private static String mappingsUrl;
    private static String settingsUrl;
    public static void main(String args[]) throws IOException, JSONException {
        String elasticSearchUrl = args[0];
        settingsUrl = elasticSearchUrl + "/customs_search_service/_settings";
        mappingsUrl = elasticSearchUrl + "/customs_search_service/_mappings";
        validateContracts(settingsUrl);
    }

    static void validateContracts(String settingsUrl) throws IOException, JSONException {
        HttpRequestFactory requestFactory = new NetHttpTransport().createRequestFactory();
        HttpRequest settingsRequest = requestFactory.buildGetRequest(new GenericUrl(settingsUrl));
        String actualJsonSettingsResponse = settingsRequest.execute().parseAsString();
        validateSettingsContract(actualJsonSettingsResponse);
    }

    static void validateSettingsContract(String actualJsonSettingsResponse) throws IOException, JSONException {
        String actualSettingAnalysisContents = loadActualSettingAnalysisContents(actualJsonSettingsResponse);
        String expectedSettingsAnalysisContents = loadExpectedSettingContents();
        JSONAssert.assertEquals(expectedSettingsAnalysisContents, actualSettingAnalysisContents, JSONCompareMode.LENIENT);
    }

    private static String loadActualSettingAnalysisContents(String actualJsonSettingsResponse) throws IOException {
        Gson gson = new GsonBuilder().create();
        Type type = new TypeToken<Map<String, Object>>(){}.getType();
        Map<String, Object> mappingsMap = gson.fromJson(actualJsonSettingsResponse, type);

        String indexNameKey = (String) mappingsMap.keySet().toArray()[0];
        Map<String, Object> indexNameMap = (Map<String, Object>) mappingsMap.get(indexNameKey);
        String settingsJson = gson.toJson(indexNameMap);

        String jsonPath = "$.settings.index.analysis";
        DocumentContext jsonContext = JsonPath.parse(settingsJson);
        Map<String, Object> settingsAnalysisJson = jsonContext.read(jsonPath);
        return gson.toJson(settingsAnalysisJson);
    }


    private static String loadExpectedSettingContents() throws IOException {
        String fileContent = FileLoaderUtils.getFileContent(FileLoaderUtils.EXPECTED_MAPPINGS_FILE);
        Gson gson = new GsonBuilder().create();
        String jsonPath = "$.settings.analysis";
        DocumentContext jsonContext = JsonPath.parse(fileContent);
        Map<String, Object> settingsAnalysisJson = jsonContext.read(jsonPath);
        return gson.toJson(settingsAnalysisJson);
    }


}