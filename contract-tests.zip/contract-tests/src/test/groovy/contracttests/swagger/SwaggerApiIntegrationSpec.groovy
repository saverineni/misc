package contracttests.swagger

import static com.github.tomakehurst.wiremock.client.WireMock.*

import org.junit.Rule

import com.github.tomakehurst.wiremock.junit.WireMockRule

import contracttests.JsonRequest
import contracttests.Validator
import contracttests.schema.SchemaLoader
import contracttests.schema.SchemaValidator
import contracttests.swagger.SwaggerApi
import contracttests.swagger.SwaggerSchema
import spock.lang.Specification

class SwaggerApiIntegrationSpec extends Specification {

    @Rule
    WireMockRule wireMockRule = new WireMockRule(8080)


    def 'Get requests'() {
        given:
        wireMockRule.stubFor(get(urlEqualTo('/schema')).willReturn(aResponse().withBody(loadResource('integrationTestSchema.json'))))
        wireMockRule.stubFor(get(urlEqualTo('/declarations')).willReturn(aResponse().withBody(loadResource('validJson.json'))))

        when:
        SwaggerApi contract = new SwaggerApi()

        then:
        contract.isContractValid(wireMockRule.url('/schema'), wireMockRule.url('')) == true
    }

    private loadResource(String fileName) {
        this.getClass().getResource(fileName).text
    }
}