package contracttests.swagger

import groovy.json.JsonSlurper
import spock.lang.Specification

class SwaggerSchemaSpec extends Specification {

    def 'should give map of resource to schema definition'() {
        given:
        SwaggerSchema swaggerSchema = swaggerSchema('simpleSchemaPaths.json')

        when:
        def pathDefinitions = swaggerSchema.pathDefinitions

        then:
        pathDefinitions == [
                '/path-one': '#/definitions/One',
                '/path-two': '#/definitions/Two'
        ]
    }

    def 'should give map of resource to schema definition excluding actuator paths'() {
        given:
        SwaggerSchema swaggerSchema = swaggerSchema('schemaPathsWithActuator.json')

        when:
        def pathDefinitions = swaggerSchema.pathDefinitions

        then:
        pathDefinitions == [
                '/path-two': '#/definitions/Two'
        ]
    }

    private swaggerSchema(String resource) {
        def testSchema = this.getClass().getResource(resource).text
        def schemaJson = new JsonSlurper().parseText(testSchema)
        new SwaggerSchema(schemaJson)
    }
}