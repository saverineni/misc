package contracttests.swagger

import groovy.json.JsonSlurper
import spock.lang.Specification

class SwaggerSchemaSpec extends Specification {

    def 'should give map of resource to schema definition'() {
        given:
        SwaggerSchema swaggerSchema = swaggerSchema('simpleSchemaPaths.json')

        when:
        def pathDefinitions = swaggerSchema.pathDefinitions

        then:
        pathDefinitions == [
                '/path-one': '#/definitions/One',
                '/path-two': '#/definitions/Two'
        ]
    }

    def 'should give map of resource to schema definition excluding actuator paths'() {
        given:
        SwaggerSchema swaggerSchema = swaggerSchema('schemaPathsWithActuator.json')

        when:
        def pathDefinitions = swaggerSchema.pathDefinitions

        then:
        pathDefinitions == [
                '/path-two': '#/definitions/Two'
        ]
    }

    def 'should convert swagger schema to valid json schema, removing property format attributes'() {
        given:
        SwaggerSchema swaggerSchema = swaggerSchema('schemaWithPropertyFormats.json')
        def validJsonSchema = new JsonSlurper().parseText(swaggerSchema.validJsonSchema)

        when:
        def formats = [:]
        def propertiesWithFormat = validJsonSchema.definitions.each { key, value ->
            value.get('properties').each { name, definition ->
                if (definition.format) {
                    formats[name] = definition.format
                }
            }
        }

        then:
        formats.size() == 0
    }

    private swaggerSchema(String resource) {
        new SwaggerSchema(this.getClass().getResource(resource).text)
    }
}