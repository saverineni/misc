package contracttests

import groovy.json.JsonSlurper
import spock.lang.Specification

class ServiceSchemaValidatorSpec extends Specification {

    def schemaData = new JsonSlurper().parseText(loadResource('/validationSchema.json'))
    ServiceSchemaValidator validator = new ServiceSchemaValidator(schemaData)

    def 'Should validate json against the schema'() {
        expect:
        validator.isValid(loadResource('/validJson.json'))
    }

    def 'should not validate json with extra properties'() {
        expect:
        false == validator.isValid(loadResource('/extraProperties.json'))
    }

    def 'should validate json against definition reference'() {
        expect:
        validator.isValidForDefinition('#/definitions/first', new JsonSlurper().parseText(loadResource('/definitionFirst.json')))
    }

    private loadResource(name) {
        this.getClass().getResource(name).text
    }

}
