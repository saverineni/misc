package contracttests

import groovy.json.JsonSlurper
import spock.lang.Specification
import spock.util.mop.ConfineMetaClassChanges

@ConfineMetaClassChanges([JsonRequest])
class ServiceSchemaLoaderSpec extends Specification {
    static URL = 'http://test_url'

    ServiceSchemaLoader loader = new ServiceSchemaLoader()

    def setup() {
        GroovyMock(JsonRequest, global: true)
    }

    def "Should add additionalProperties field with value false to each of the definition"() {
        given:
        def expectedSchema = loadResource("/expectedSchema.json")
        JsonRequest.GET(URL) >> jsonAsMap(loadResource("/schema.json"))

        when:
        def actualSchema = loader.loadSchema(URL)

        then:
        actualSchema == jsonAsMap(expectedSchema)

    }

    def "Shouldn't add additionalProperties field to the definition if it already exists"() {
        given:
        def expectedSchema = loadResource("/schemaWithAdditionalProperties.json")
        JsonRequest.GET(URL) >> jsonAsMap(expectedSchema)

        when:
        def actualSchema = loader.loadSchema(URL)

        then:
        actualSchema == jsonAsMap(expectedSchema)

    }

    private jsonAsMap(String actualSchema) {
        new JsonSlurper().parseText(actualSchema)
    }

    private loadResource(name) {
        this.getClass().getResource(name).text
    }

}
