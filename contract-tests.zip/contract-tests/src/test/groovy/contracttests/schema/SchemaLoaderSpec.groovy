package contracttests.schema

import contracttests.JsonRequest
import groovy.json.JsonSlurper
import spock.lang.Specification
import spock.util.mop.ConfineMetaClassChanges

@ConfineMetaClassChanges([JsonRequest])
class SchemaLoaderSpec extends Specification {
    static URL = 'http://test_url'

    SchemaLoader loader = new SchemaLoader()

    def setup() {
        GroovyMock(JsonRequest, global: true)
    }

    def "Should add additionalProperties field with value false to each of the definition"() {
        given:
        def expectedSchema = loadResource("expectedSchema.json")
        JsonRequest.GET(URL) >> loadResource("schema.json")

        when:
        def actualSchema = loader.loadSchema(URL)

        then:
        jsonAsMap(actualSchema) == jsonAsMap(expectedSchema)

    }

    def "Shouldn't add additionalProperties field to the definition if it already exists"() {
        given:
        def expectedSchema = loadResource("schemaWithAdditionalProperties.json")
        JsonRequest.GET(URL) >> expectedSchema

        when:
        def actualSchema = loader.loadSchema(URL)

        then:
        jsonAsMap(actualSchema) == jsonAsMap(expectedSchema)

    }

    private jsonAsMap(String actualSchema) {
        new JsonSlurper().parseText(actualSchema)
    }

    private loadResource(name) {
        this.getClass().getResource(name).text
    }

}
