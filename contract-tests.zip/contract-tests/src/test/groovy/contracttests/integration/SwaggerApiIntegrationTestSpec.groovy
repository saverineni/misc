import com.github.tomakehurst.wiremock.junit.WireMockRule
import contracttests.JsonRequest
import contracttests.ServiceSchemaLoader
import contracttests.ServiceSchemaValidator
import contracttests.swagger.SwaggerSchema
import org.junit.Rule
import spock.lang.Specification

import static com.github.tomakehurst.wiremock.client.WireMock.*

class SwaggerApiIntegrationTestSpec extends Specification {

    @Rule
    WireMockRule wireMockRule = new WireMockRule(8080)


    def 'Get requests'() {
        given:
        wireMockRule.stubFor(get(urlEqualTo('/schema')).willReturn(aResponse().withBody(loadResource('/contracttests/integration/swaggerSchema.json'))))
        wireMockRule.stubFor(get(urlEqualTo('/declarations')).willReturn(aResponse().withBody(loadResource('/contracttests/integration/properJson.json'))))

        when:
        def schema = new ServiceSchemaLoader().loadSchema(wireMockRule.url('/schema'))
        def validDefinitions = new SwaggerSchema(schema).pathDefinitions.collect { path, definition ->
            def json = JsonRequest.GET(wireMockRule.url(path))

            new ServiceSchemaValidator(schema).isValidForDefinition(definition, json)
        }

        then:
        validDefinitions.size() == 1
        validDefinitions.every { it == true }
    }

    private loadResource(String fileName) {
        this.getClass().getResource(fileName).text
    }
}