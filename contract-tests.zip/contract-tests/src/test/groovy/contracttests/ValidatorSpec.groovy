package contracttests;

import contracttests.schema.SchemaValidator
import spock.lang.Specification;
import spock.util.mop.ConfineMetaClassChanges

@ConfineMetaClassChanges([JsonRequest, SchemaValidator])
class ValidatorSpec extends Specification {
    static final HOST = 'host_url'
    static final PATH = 'path'
    static final DEFINITION = 'definition'

    SchemaValidator schemaValidator = GroovyMock()
    Validator validator = new Validator(schemaValidator: schemaValidator, host: HOST)

    def setup() {
        GroovyMock(JsonRequest, global: true)
    }

    def 'should validate response data against a given schema and definition'() {
        given:
        def json = 'json'
        JsonRequest.GET("$HOST/$PATH") >> json
        schemaValidator.isValidForDefinition(DEFINITION, json) >> true

        when:
        def result = validator.validate(PATH, DEFINITION)

        then:
        result == true
    }

}
