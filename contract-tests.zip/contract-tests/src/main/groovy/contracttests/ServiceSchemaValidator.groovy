package contracttests

import com.fasterxml.jackson.databind.ObjectMapper
import com.github.fge.jsonschema.core.report.ProcessingReport
import com.github.fge.jsonschema.main.JsonSchemaFactory

import groovy.transform.Immutable

@Immutable
class ServiceSchemaValidator {
    Map jsonSchema

    def isValid(String json) {
        def jsonNode = new ObjectMapper().readTree(json)
        def jsonSchemaNode = new ObjectMapper().valueToTree(jsonSchema)

        def schema = JsonSchemaFactory.byDefault().getJsonSchema(jsonSchemaNode)

        schema.validate(jsonNode).success
    }

    def isValidForDefinition(String definition, Map json) {
        def jsonNode = new ObjectMapper().valueToTree(json)
        def jsonSchemaNode = new ObjectMapper().valueToTree(jsonSchema)

        def schema = JsonSchemaFactory.byDefault().getJsonSchema(jsonSchemaNode, definition.replaceFirst(/^#/, ''))

        schema.validate(jsonNode).success
    }
}
