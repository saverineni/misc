package contracttests

import contracttests.schema.SchemaValidator

class Validator {
    SchemaValidator schemaValidator
    String host

    def validate = { path, definition ->
        def json = JsonRequest.GET("$host/$path")

        schemaValidator.isValidForDefinition(definition, json)
    }
}
