package contracttests.swagger

import contracttests.Validator
import contracttests.schema.SchemaLoader
import contracttests.schema.SchemaValidator

class SwaggerApi {

    def isContractValid(String schemaUrl, String dataUrl) {
        def schema = new SchemaLoader().loadSchema(schemaUrl)
        def swaggerSchema = new SwaggerSchema(schema)
        def schemaValidator = new SchemaValidator(swaggerSchema.validJsonSchema)
        def validator = new Validator(schemaValidator: schemaValidator, host: dataUrl)

        def validDefinitions = swaggerSchema.pathDefinitions.collect validator.validate

        !validDefinitions.contains(false)
    }
}
