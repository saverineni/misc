package contracttests.swagger

import groovy.json.JsonSlurper;

class PathsValidator {

    def validatePaths(String schema) {
        def json = new JsonSlurper().parseText(schema)
        def schemaPaths = json.paths



    }

}