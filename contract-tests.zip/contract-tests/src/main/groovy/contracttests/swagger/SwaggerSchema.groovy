package contracttests.swagger

class SwaggerSchema {
    private final Map data

    SwaggerSchema(Map data) {
        this.data = data
    }

    def getPathDefinitions() {
        data.paths.findAll{ !it.key.startsWith('/actuator') }
                  .collectEntries{ [(it.key): it.value.'get'.responses.'200'.schema.'$ref']}
    }
}
