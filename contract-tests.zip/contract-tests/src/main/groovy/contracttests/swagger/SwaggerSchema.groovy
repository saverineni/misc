package contracttests.swagger

import groovy.json.JsonOutput
import groovy.json.JsonSlurper

class SwaggerSchema {
    private final String schemaJson

    SwaggerSchema(String schemaJson) {
        this.schemaJson = schemaJson
    }

    def getPathDefinitions() {
        schemaAsMap.paths.findAll{ !it.key.startsWith('/actuator') }
                  .collectEntries{ [(it.key): it.value.'get'.responses.'200'.schema.'$ref']}
    }

    def getValidJsonSchema() {
        def validSchema = schemaAsMap
        validSchema.definitions.each {
            def properties = it.value.properties
            properties.each {
                it.value.remove('format')
            }
        }

        JsonOutput.toJson(validSchema)
    }

    private getSchemaAsMap() {
        new JsonSlurper().parseText(schemaJson)
    }
}
