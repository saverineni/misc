package contracttests.schema

import contracttests.JsonRequest
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

class SchemaLoader {

    def loadSchema(String url){
        def schema =  new JsonSlurper().parseText(JsonRequest.GET(url))

        schema.definitions.each { key,value ->
            if(!value.additionalProperties) {
                value.additionalProperties = false
            }
        }

        JsonOutput.toJson(schema)
    }

}
