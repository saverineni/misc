package contracttests

class ServiceSchemaLoader {

    def loadSchema(String url){
        def schema = JsonRequest.GET(url)

        schema.definitions.each{key,value ->
            if(!value.additionalProperties) {
                value.additionalProperties = false
            }
        }
        schema
    }

}
