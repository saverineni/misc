package contracttests

import groovy.json.JsonSlurper
import org.apache.http.client.fluent.Request

class JsonRequest {

    static Map GET(String url) {
        String response = Request.Get(url).execute().returnContent().asString()
        new JsonSlurper().parseText(response)
    }
}
