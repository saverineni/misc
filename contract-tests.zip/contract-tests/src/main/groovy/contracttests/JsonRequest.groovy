package contracttests

import org.apache.http.client.fluent.Request

import groovy.json.JsonSlurper

class JsonRequest {

    static String GET(String url) {
        Request.Get(url).execute().returnContent().asString()
    }
}
