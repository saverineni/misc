#!/bin/bash

samba-tool group add E2E_SEARCH

# add users
samba-tool user add dev Dev_1234567 --use-username-as-cn --given-name="Search" --surname="Dev User" --department="Operations Unit"
samba-tool user add not_search Dev_1234567 --use-username-as-cn --given-name="Not Search" --surname="Unauthorised User" --department="Other Unit"

# add users to groups
samba-tool group addmembers E2E_SEARCH dev
