#!/usr/bin/dumb-init /bin/sh

echo 'Checking vault status'
vault status

echo 'Creating kv secret engine'
vault secrets enable -path=dec--cds--data--nonlive kv

echo 'Adding secrets'

# searchservice
vault kv put dec--cds--data--nonlive/e2e/apps/searchservice \
	jwt.secret="secret" \
	elasticsearch.username="elastic" \
	elasticsearch.password="elastic"

echo 'Vault configuration complete'

exit 0