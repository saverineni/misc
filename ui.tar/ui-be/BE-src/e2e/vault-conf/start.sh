#!/usr/bin/dumb-init /bin/sh

# Start Vault as a service
/usr/bin/supervisord -c  /etc/supervisor/conf.d/supervisord.conf