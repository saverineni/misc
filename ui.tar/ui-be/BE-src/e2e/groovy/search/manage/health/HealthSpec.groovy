package search.manage.health

import search.manage.ManageResource
import spock.lang.Shared
import spock.lang.Specification

class HealthSpec extends Specification {

    @Shared response

    def setupSpec() {
        response = ManageResource.GET('health')
    }

    def 'the health resource should be available'() {
        expect:
        response.status == 200
    }

    def 'the health status should be UP'() {
        expect:
        response.json().status == 'UP'
    }
}
