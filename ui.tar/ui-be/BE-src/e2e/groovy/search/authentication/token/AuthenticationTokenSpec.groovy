package search.authentication.token

import groovy.json.JsonSlurper
import org.apache.http.HttpResponse
import org.apache.http.util.EntityUtils
import search.Authenticator
import spock.lang.Ignore
import spock.lang.Shared
import spock.lang.Specification

class AuthenticationTokenSpec extends Specification {
    Authenticator authenticator = new search.Authenticator()

    def 'valid username results in 200 with appropriate user details.'() {
        given: 'I attempt to sign in with a valid user'
        def tokenResponse = authenticator.authenticate()

        when: 'I get the valid user details'
        def userDetails = new String(tokenResponse.token.tokenize(".")[1].decodeBase64())
        Map jsonResponse = new JsonSlurper().parseText(userDetails).user

        then:
        jsonResponse == [
            pid: 'dev',
            firstName: 'Search',
            lastName: 'Dev User',
            department: 'Operations Unit'
        ]
        tokenResponse.timeToLive == 3600
    }

    def 'valid username without permissions to view search data gives unauthorised response'() {
        when: 'I attempt to sign in with an unknown user'
        def response = authenticator.postAuthenticationToken('not_search', 'Dev_1234567')

        then: 'I get an unuathorised response'
        response.statusLine.statusCode == 403
    }

    def 'unknown username results in 401 with appropriate message.'() {
        when: 'I attempt to sign in with an unknown user'
        def response = authenticator.postAuthenticationToken('unknown', 'password')

        then: 'I get an appropriate response'
        response.statusLine.statusCode == 401
    }
}
