package search.declarations

import groovy.json.JsonSlurper
import org.apache.http.HttpResponse
import org.apache.http.client.fluent.Executor
import org.apache.http.client.fluent.Request
import org.apache.http.impl.client.BasicResponseHandler

class SearchResource {
    private static authToken = { -> new search.Authenticator().authenticate().token }
    private static httpClient = { -> new search.NoSslHttpClient().httpClient() }

    static HttpResponse unauthenticatedGet(path='declarations', params) {
        getDeclarationsWith(path, params, false)
    }

    static HttpResponse unauthenticatedGetById(path='declarations', decId) {
        getDeclarations(path, "/$decId", false)
    }

    static HttpResponse authenticatedGet(path='declarations', params, accept='application/json') {
        getDeclarationsWith(path, params, true, accept)
    }

    static HttpResponse authenticatedGetById(path='declarations', decId) {
        getDeclarations(path, "/$decId", true)
    }

    static HttpResponse authenticatedGetDefinition() {
        getDeclarations('declarations/definition', '', true)
    }

    static HttpResponse authenticatedGetPreviewsDefinition() {
        getDeclarations('search/definition', '', true)
    }

    static HttpResponse authenticatedGetItemsDefinition() {
        getDeclarations('declarations/items/definition', '', true)
    }

    private static getDeclarationsWith(path, params, authenticated, accept='application/json') {
        def queryString = params.collect { name, values ->
            values.collect { "${name}=${it}" }.join("&")
        }.join('&')
        if (queryString.length() > 0) {
            queryString = '?' + queryString
        }
        getDeclarations(path, queryString, authenticated, 'correlationID-value', accept)
    }

    static HttpResponse authenticatedGetByIdWithHeaders(path='declarations', decId, correlationID) {
        getDeclarations(path, "/$decId", true, correlationID)
    }

    private static getDeclarations(path, queryString, authenticated, correlationID='correlationID-value', accept='application/json') {
        def uri = new URI("https://localhost:18000/$path$queryString")
        def request = Request.Get(uri).addHeader("Accept", accept)
        if (authenticated) {
            request.addHeader("X-Correlation-ID", "$correlationID")
            request.addHeader("Authorization", "Bearer ${authToken()}")
        }

        Executor executor = Executor.newInstance(httpClient())
        return executor.execute(request).returnResponse()
    }

    static Object asJson(HttpResponse response) {
        def responseString = new BasicResponseHandler().handleResponse(response)
        new JsonSlurper().parseText(responseString)
    }

    static List asDeclarationIds(HttpResponse response) {
        asJson(response).declarations.collect { declaration -> declaration.declarationId }
    }
}
