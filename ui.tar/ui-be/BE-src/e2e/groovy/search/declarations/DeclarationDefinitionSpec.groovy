package search.declarations

import spock.lang.Specification

class DeclarationDefinitionSpec extends Specification {

    def 'returns the expected definition'() {
        when:
        def expected = DeclarationsIndex.getDeclarationDefinition()
        def response = SearchResource.authenticatedGetDefinition()
        def result = SearchResource.asJson(response)

        then:
        result == expected
    }

    def 'returns the expected preview definition'() {
        when:
        def expected = DeclarationsIndex.getDeclarationPreviewDefinition()
        def response = SearchResource.authenticatedGetPreviewsDefinition()
        def result = SearchResource.asJson(response)

        then:
        result == expected
    }

    def 'returns the expected items definition'() {
        when:
        def expected = DeclarationsIndex.getDeclarationItemsDefinition()
        def response = SearchResource.authenticatedGetItemsDefinition()
        def result = SearchResource.asJson(response)

        then:
        result == expected
    }

}
