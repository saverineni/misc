package search.declarations

import spock.lang.Specification

class DeclarationResultCSVSpec extends Specification {

    def setupSpec() {
        DeclarationsIndex.recreateAndPopulateIndexForEmptyData()
    }

    def 'declarations as csv for more than the max limit'() {
        when:
        def response = SearchResource.authenticatedGet('declarations', ['searchTerm': [''], 'pageSize': ['11']], 'text/csv')

        then:
        response.statusLine.statusCode == 400
    }

    def 'declarations as csv for the max limit'() {
        when:
        def response = SearchResource.authenticatedGet('declarations', ['searchTerm': [''], 'pageSize': ['10']], 'text/csv')

        then:
        response.statusLine.statusCode == 200
    }

}
