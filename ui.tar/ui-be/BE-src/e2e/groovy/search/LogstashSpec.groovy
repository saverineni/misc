package search

import java.time.ZonedDateTime

import org.apache.http.client.fluent.Executor
import org.apache.http.client.fluent.Request

import groovy.json.JsonSlurper
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

class LogstashSpec extends Specification {
    private static httpClient = { -> new search.NoSslHttpClient().httpClient() }

    @Shared
    Map jsonResponse

    def setupSpec() {
        def request = Request.Get('https://localhost:19200/logs/_search')

        Executor executor = Executor.newInstance(httpClient())
        def response = executor.execute(request).returnContent()

        jsonResponse = new JsonSlurper().parseText(response.asString())
    }

    def 'should pipe log messages to logstash'() {
        given: 'logstash is configured to pipe to elastic search'
        when: 'the application is started'

        then:
        jsonResponse.hits.total > 0

    }

    @Unroll
    def 'should add the #property property to the hits'(property, check) {
        when:
        def values = jsonResponse.hits.hits*._source."$property"

        then:
        values.every check

        and:
        noExceptionThrown()

        where:
        property           | check
        'app_identifier'   | { it == 'customs-search-service' }
        'container_id'     | { it ==~ /[0-9a-z]{12}/ }
        'client_timestamp' | { ZonedDateTime.parse(it) }
    }

}
