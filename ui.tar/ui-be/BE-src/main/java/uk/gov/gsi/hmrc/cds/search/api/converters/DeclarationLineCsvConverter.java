package uk.gov.gsi.hmrc.cds.search.api.converters;

import com.opencsv.CSVWriter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.converter.AbstractHttpMessageConverter;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.ViewDefinition;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLine;

import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static uk.gov.gsi.hmrc.cds.search.api.converters.CsvConverterUtils.mapToStream;

@Component
@Slf4j
public class DeclarationLineCsvConverter extends AbstractHttpMessageConverter<Declaration> {

    private static final String CONVERTER_MEDIA_TYPE = "text/csv";

    private static final Stream<String> DEC_HEADERS = Stream.concat(Stream.of("Item Number"), ViewDefinition.Utils.orderedViewDefinitionFields(Declaration.class)
            .flatMap(field -> Stream.of(field.getAnnotationsByType(ViewDefinition.class)))
            .filter(ViewDefinition::header)
            .map(ViewDefinition::label));

    private static final Stream<String> LINE_HEADERS = ViewDefinition.Utils.orderedViewDefinitionFields(DeclarationLine.class)
            .flatMap(field -> Stream.of(field.getAnnotationsByType(ViewDefinition.class)))
            .map(ViewDefinition::label);

    static final String[] HEADERS = Stream.concat(DEC_HEADERS, LINE_HEADERS).toArray(String[]::new);

    public DeclarationLineCsvConverter() {
        super(MediaType.valueOf(CONVERTER_MEDIA_TYPE));
    }

    @Override
    protected boolean supports(Class<?> aClass) {
        return Declaration.class.isAssignableFrom(aClass);
    }

    @Override
    protected Declaration readInternal(Class<? extends Declaration> aClass, HttpInputMessage httpInputMessage)
            throws HttpMessageNotReadableException {
        throw new HttpMessageNotReadableException("Not supported");
    }

    private String[] asOrderedStringValues(Declaration declaration, DeclarationLine declarationLine) {
        Stream<String> header = Stream.concat(Stream.of(declarationLine.getItemNumber() + ""),
                ViewDefinition.Utils.orderedViewDefinitionFields(Declaration.class)
                        .filter(field -> Stream.of(field.getAnnotationsByType(ViewDefinition.class)).allMatch(ViewDefinition::header))
                        .flatMap(field -> mapToStream(field, declaration)));

        return Stream.concat(header, ViewDefinition.Utils.orderedViewDefinitionFields(DeclarationLine.class)
                .flatMap(field -> mapToStream(field, declarationLine)))
                .toArray(String[]::new);
    }

    @Override
    protected void writeInternal(Declaration declaration, HttpOutputMessage httpOutputMessage) throws HttpMessageNotWritableException {
        httpOutputMessage.getHeaders().add(HttpHeaders.CONTENT_TYPE, CONVERTER_MEDIA_TYPE);

        try (final Writer writer = new OutputStreamWriter(httpOutputMessage.getBody())) {

            try (CSVWriter csvWriter = new CSVWriter(writer,
                    CSVWriter.DEFAULT_SEPARATOR,
                    CSVWriter.NO_QUOTE_CHARACTER,
                    CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                    CSVWriter.DEFAULT_LINE_END)) {

                csvWriter.writeNext(HEADERS);

                List<String[]> declarationLines = declaration.getLines().stream()
                        .sorted(Comparator.comparing(DeclarationLine::getItemNumber))
                        .map(line -> asOrderedStringValues(declaration, line))
                        .collect(Collectors.toList());
                csvWriter.writeAll(declarationLines);
            }
        } catch (Exception ex) {
            logger.error("Unable to output declaration lines in CSV format.", ex);
        }
    }
}
