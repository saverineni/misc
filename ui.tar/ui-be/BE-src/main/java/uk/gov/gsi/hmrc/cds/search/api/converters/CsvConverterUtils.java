package uk.gov.gsi.hmrc.cds.search.api.converters;

import lombok.extern.slf4j.Slf4j;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.Trader;

import java.lang.reflect.Field;
import java.util.Optional;
import java.util.stream.Stream;

@Slf4j
class CsvConverterUtils {

    static Stream<? extends String> mapToStream(Field field, Object hostObject) {
        field.setAccessible(true);
        try {
            return getStream(field, field.get(hostObject));
        } catch (IllegalAccessException e) {
            log.error("Unable to access view definition field for object " + hostObject.getClass().getSimpleName(), e);
            return Stream.empty();
        }
    }

    private static Stream<? extends String> getStream(Field field, Object value) {
        if (field.getType() == String.class) {
            return Stream.of((String) value);
        } else if (field.getType() == Country.class) {
            return Optional.ofNullable((Country) value)
                    .map(c -> Stream.of(c.getCode())).orElse(Stream.of(""));
        } else if (field.getType() == Trader.class) {
            return Optional.ofNullable((Trader) value)
                    .map(t -> Stream.of(t.getEori(), t.getName(), t.getPostcode())).orElse(Stream.of("", "", ""));
        } else {
            return Stream.of("");
        }
    }

}
