package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.connection.headers.ESHeaders;

import java.io.IOException;
import java.util.Optional;

@Service
public class SearchClient {

    private final RestHighLevelClient client;
    private final String searchAlias;
    private final ESHeaders esHeaders;
    private final SearchQueryBuilderDelegate searchQueryBuilder;

    public SearchClient(RestHighLevelClient client,
                        @Value("${elasticsearch.alias}") String searchAlias,
                        ESHeaders esHeaders,
                        SearchQueryBuilderDelegate searchQueryBuilder) {
        this.client = client;
        this.searchAlias = searchAlias;
        this.esHeaders = esHeaders;
        this.searchQueryBuilder = searchQueryBuilder;
    }

    SearchResponse getDeclarationById(String declarationId) {
        try {
            final SearchRequest searchRequest = new SearchRequest(searchAlias);
            final SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();

            searchSourceBuilder.query(QueryBuilders.matchQuery("_id", declarationId));
            searchRequest.source(searchSourceBuilder);

            return client.search(searchRequest, esHeaders.getHeaders());
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    public SearchResponse declarationSearch(SearchCriteria searchCriteria) {
        try{
            final SearchRequest searchRequest = new SearchRequest(searchAlias);
            BoolQueryBuilder query = QueryBuilders.boolQuery().must(QueryBuilders.matchAllQuery());

            searchRequest.source(searchQueryBuilder.getQueryBuilderWithPagination(searchCriteria, query));

            return client.search(searchRequest, esHeaders.getHeaders());
        }catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    SearchResponse facetSearch(SearchCriteria searchCriteria, String facetType, Optional<String> prefix) {
        try{
            final SearchRequest searchRequest = new SearchRequest(searchAlias);
            BoolQueryBuilder query = QueryBuilders.boolQuery().must(QueryBuilders.matchAllQuery());

            prefix.ifPresent(p -> query.must(QueryBuilders.matchQuery(searchQueryBuilder.getFacetFieldName(facetType), p)));
            searchRequest.source(searchQueryBuilder.getQueryBuilderWithFacets(searchCriteria, query , facetType));

            return client.search(searchRequest, esHeaders.getHeaders());
        }catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


}
