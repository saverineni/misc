package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import lombok.Value;

@Value
public class Hits {
    long total;
}
