package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.search.SearchHit;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;

import java.io.IOException;

import static java.lang.String.format;

@Component
@RequiredArgsConstructor
@Slf4j
public class SearchHitToDeclarationConverter implements Converter<SearchHit, Declaration> {

    private final ObjectMapper objectMapper;

    @Override
    public Declaration convert(SearchHit esSearchHit) {
        try {
            return objectMapper.readValue(esSearchHit.getSourceAsString(), Declaration.class);
        } catch (IOException e) {
            log.error(format("Error converting search hit: %s" , e));
            throw new RuntimeException(e.getMessage());
        }
    }
}
