package uk.gov.gsi.hmrc.cds.search.elasticsearch.helper;

import java.time.format.DateTimeFormatter;
import java.util.AbstractMap.SimpleEntry;
import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;
import java.util.stream.Stream;

public class SearchQueryBuilderUtils {

    public static final String LINES_ORIGIN_COUNTRY_CODE = "lines.originCountry.code";
    public static final String DISPATCH_COUNTRY_CODE = "dispatchCountry.code";
    public static final String DESTINATION_COUNTRY_CODE = "destinationCountry.code";
    public static final String TRANSPORT_MODE_CODE = "transportModeCode";
    public static final String DECLARATION_TYPE = "declarationType";
    public static final String DECLARATION_SOURCE = "declarationSource";
    public static final String GOODS_LOCATION = "goodsLocation";
    public static final String LINES_COMMODITY_CODE = "lines.commodityCode";
    public static final String LINES_CPC = "lines.cpc";
    public static final String ENTRY_DATE = "entryDate";
    public static final String CLEARANCE_DATE = "lines.clearanceDate";

    public static final String FACETS = "facets";
    /**
     * This is necessary to ensure we retrieve all countries from the aggregation, if the total number of possible
     * countries exceeds this number there will be some entries missing from the resulting aggregation.
     */
    public static final int COUNTRY_CARDINALITY = 400;
    public static final int TRANSPORT_MODE_CARDINALITY = 10;
    public static final int GOODS_LOCATION_CARDINALITY = 400;
    private static final int COMMODITY_CODE_CARDINALITY = 1000;
    private static final int CPC_CODE_CARDINALITY = 1000;
    private static final int DECLARATION_TYPE_CARDINALITY = 100;
    public static final DateTimeFormatter esDateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
    public static final List<String> LINE_FACETS = Arrays.asList("originCountryCode", "commodityCode" , "cpc");

    public static final String[] SEARCH_TERM_FIELDS = {
            "declarationId",
            "epuNumber",
            "entryNumber",
            "consignee.name",
            "consignee.postcode",
            "consignor.name",
            "consignor.postcode",
            LINES_COMMODITY_CODE,
            "lines.originCountry.code.codeText",
            LINES_CPC,
            "lines.itemConsignee.name",
            "lines.itemConsignee.postcode",
            "lines.itemConsignor.name",
            "lines.itemConsignor.postcode"
    };

    public static final String[] EORI_FIELDS = {
            "consignee.eori",
            "consignor.eori",
            "declarant.eori",
            "lines.itemConsignee.eori",
            "lines.itemConsignor.eori",
            "lines.itemDeclarant.eori"
    };

    public static final String[] ALL_SEARCH_FIELDS = Stream.of(SEARCH_TERM_FIELDS, EORI_FIELDS)
            .flatMap(Stream::of)
            .toArray(String[]::new);

    public enum FieldMapping {
        ORIGIN_COUNTRY_CODE_FIELD("originCountryCode", LINES_ORIGIN_COUNTRY_CODE, COUNTRY_CARDINALITY),
        DISPATCH_COUNTRY_CODE_FIELD("dispatchCountryCode", DISPATCH_COUNTRY_CODE, COUNTRY_CARDINALITY),
        DESTINATION_COUNTRY_CODE_FIELD("destinationCountryCode", DESTINATION_COUNTRY_CODE, COUNTRY_CARDINALITY),
        COMMODITY_CODE_FIELD("commodityCode", LINES_COMMODITY_CODE, COMMODITY_CODE_CARDINALITY),
        TRANSPORT_MODE_CODE_FIELD("transportModeCode", TRANSPORT_MODE_CODE, TRANSPORT_MODE_CARDINALITY),
        GOODS_LOCATION_FIELD("goodsLocation", GOODS_LOCATION, GOODS_LOCATION_CARDINALITY),
        CPC_CODE_FIELD("cpc", LINES_CPC, CPC_CODE_CARDINALITY),
        DECLARATION_TYPE_FIELD("declarationType", DECLARATION_TYPE, DECLARATION_TYPE_CARDINALITY);


        private String facetType;
        private String field;
        private int cardinality;

        FieldMapping(String facetType, String field, int cardinality) {
            this.facetType = facetType;
            this.field = field;
            this.cardinality = cardinality;
        }

        public String getFacetType() {
            return facetType;
        }

        public String getField() {
            return field;
        }

        public int getCardinality() {
            return cardinality;
        }

        public static Entry<String,Integer> getFieldCardinality(String facetType) {
             return Arrays.stream(FieldMapping.values())
                    .filter(mapping -> mapping.getFacetType().equalsIgnoreCase(facetType))
                    .findFirst()
                    .map(field -> new SimpleEntry<>(field.getField(), Integer.valueOf(field.getCardinality())))
                    .orElse(null);
        }
    }
}
