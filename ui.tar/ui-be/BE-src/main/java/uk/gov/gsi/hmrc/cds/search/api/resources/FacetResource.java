package uk.gov.gsi.hmrc.cds.search.api.resources;

import lombok.RequiredArgsConstructor;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.FacetSearchResult;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.ElasticDeclarationSearchService;

import java.util.Optional;

@RestController
@RequiredArgsConstructor
public class FacetResource extends RequestBinder {

    private final ElasticDeclarationSearchService elasticDeclarationSearchService;

    @GetMapping(value = {"/facets/{facetType}/{prefix}", "/facets/{facetType}"})
    public FacetSearchResult getFacetSearchResult(@PathVariable("facetType") String facetType,
                                                  @PathVariable("prefix") Optional<String> prefix,
                                                  SearchCriteria searchCriteria,
                                                  BindingResult errors) {
        if (errors.getSuppressedFields().length > 0) {
            throw new UnsupportedRequestParameterException(errors.getSuppressedFields());
        }

        if (!ALLOWED_FACET_TYPES.contains(facetType)) {
            throw new UnsupportedRequestParameterException(new String[]{facetType});
        }

        return elasticDeclarationSearchService.fetchFacetSearchResult(searchCriteria, facetType, prefix);
    }

}
