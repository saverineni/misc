package uk.gov.gsi.hmrc.cds.search.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.lang.annotation.*;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@Repeatable(ViewDefinition.ViewDefinitions.class)
public @interface ViewDefinition {
    @JsonIgnore
    int order();
    @JsonProperty
    String id();
    @JsonProperty
    String label();
    @JsonProperty
    boolean header() default false;
    @JsonProperty
    String type() default "string";
    @JsonProperty
    String path() default "";

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.FIELD)
    @interface ViewDefinitions {
        ViewDefinition[] value();
    }

    final class Utils {
        public static Stream<Field> orderedViewDefinitionFields(Class<?> clazz) {
            return Arrays.stream(clazz.getDeclaredFields())
                    .filter(field -> field.getAnnotationsByType(ViewDefinition.class).length > 0)
                    .sorted((a, b) -> {
                        int aOrder = a.getAnnotationsByType(ViewDefinition.class)[0].order();
                        int bOrder = b.getAnnotationsByType(ViewDefinition.class)[0].order();
                        return Integer.compare(aOrder, bOrder);
                    });
        }

        public static List<ViewDefinition> orderedViewDefinitions(Class<?> clazz) {
            return orderedViewDefinitionFields(clazz)
                    .flatMap(field -> Stream.of(field.getAnnotationsByType(ViewDefinition.class)))
                    .collect(Collectors.toList());
        }
    }
}
