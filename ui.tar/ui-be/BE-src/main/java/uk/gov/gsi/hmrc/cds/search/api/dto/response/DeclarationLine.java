package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.Trader;
import uk.gov.gsi.hmrc.cds.search.api.dto.ViewDefinition;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeclarationLine {
    private int itemNumber;

    @ViewDefinition(id = "itemRoute", order = 1, label = "Route of Entry")
    private String itemRoute;
    @ViewDefinition(id = "cpc", order = 2, label = "CPC")
    private String cpc;
    @ViewDefinition(id = "acceptanceDate", order = 3, label = "Acceptance Date", type = "timestamp")
    private String acceptanceDate;
    @ViewDefinition(id = "clearanceDate", order = 4, label = "Clearance Date", type = "timestamp")
    private String clearanceDate;

    @ViewDefinition(id = "originCountry", order = 5, label = "Country of Origin", path = ".code")
    private Country originCountry;
    @ViewDefinition(id = "itemDispatchCountry", order = 6, label = "Country of Dispatch", path = ".code")
    private Country itemDispatchCountry;
    @ViewDefinition(id = "firstDestinationCountry", order = 7, label = "Country Of First Destination", path = ".code")
    private Country firstDestinationCountry;
    @ViewDefinition(id = "itemDestinationCountry", order = 8, label = "Country Of Final Destination", path = ".code")
    private Country itemDestinationCountry;

    @ViewDefinition(id = "containerId", order = 9, label = "Container Number")
    private String containerId;
    @ViewDefinition(id = "packageKind", order = 10, label = "Package Kind")
    private String packageKind;
    @ViewDefinition(id = "packageMarks", order = 11, label = "Package Marks")
    private String packageMarks;
    @ViewDefinition(id = "packageCount", order = 12, label = "Package Count")
    private String packageCount;
    @ViewDefinition(id = "goodsDescription", order = 13, label = "Goods Description")
    private String goodsDescription;
    @ViewDefinition(id = "grossMass", order = 14, label = "Gross Mass (Kg)")
    private String grossMass;
    @ViewDefinition(id = "netMass", order = 15, label = "Net Mass (Kg)")
    private String netMass;
    @ViewDefinition(id = "quotaNumber", order = 16, label = "Quota Number")
    private String quotaNumber;
    @ViewDefinition(id = "preference", order = 17, label = "Preference Number")
    private String preference;
    @ViewDefinition(id = "summaryDeclaration", order = 18, label = "Summary Declaration")
    private String summaryDeclaration;
    @ViewDefinition(id = "supplementaryUnits", order = 19, label = "Supplementary Units")
    private String supplementaryUnits;
    @ViewDefinition(id = "aiStatement", order = 20, label = "AI Statement")
    private String aiStatement;
    @ViewDefinition(id = "statementDescription", order = 21, label = "Statement Description")
    private String statementDescription;

    @ViewDefinition(id = "invoiceCurrency", order = 22, label = "Customs Value (currency)")
    private String invoiceCurrency;
    @ViewDefinition(id = "itemPrice", order = 23, label = "Customs Value")
    private String itemPrice;
    @ViewDefinition(id = "statisticalValueCurrency", order = 24, label = "Statistical Value (currency)")
    private String statisticalValueCurrency;
    @ViewDefinition(id = "statisticalValue", order = 25, label = "Statistical Value")
    private String statisticalValue;
    @ViewDefinition(id = "commodityCode", order = 26, label = "Commodity Code")
    private String commodityCode;

    @ViewDefinition(id = "valuationMethod", order = 27, label = "Valuation Method")
    private String valuationMethod;
    @ViewDefinition(id = "valuationAdjustmentCode", order = 28, label = "Valuation Adjustment Code")
    private String valuationAdjustmentCode;
    @ViewDefinition(id = "valuationAdjustmentCurrency", order = 29, label = "Valuation Adjustment Currency")
    private String valuationAdjustmentCurrency;
    @ViewDefinition(id = "valuationAdjustmentAmount", order = 30, label = "Valuation Adjustment Amount")
    private String valuationAdjustmentAmount;

    @ViewDefinition(id = "taxTypeCode", order = 31, label = "Tax Type Code")
    private String taxTypeCode;
    @ViewDefinition(id = "taxBaseUnit", order = 32, label = "Tax Base (Unit)")
    private String taxBaseUnit;
    @ViewDefinition(id = "taxBaseQualifier", order = 33, label = "Tax Base (Qualifier)")
    private String taxBaseQualifier;
    @ViewDefinition(id = "taxBaseQuantity", order = 34, label = "Tax Base (Quantity)")
    private String taxBaseQuantity;

    @ViewDefinition(id = "rate", order = 35, label = "Tax Rate")
    private String rate;
    @ViewDefinition(id = "rateCurrency", order = 36, label = "Tax Rate (currency)")
    private String rateCurrency;
    @ViewDefinition(id = "amount", order = 37, label = "Tax Amount")
    private String amount;
    @ViewDefinition(id = "amountType", order = 38, label = "Tax Amount (type)")
    private String amountType;
    @ViewDefinition(id = "methodOfPayment", order = 39, label = "Method Of Payment Code")
    private String methodOfPayment;
    @ViewDefinition(id = "totalDutyCurrency", order = 40, label = "Total Duty (currency)")
    private String totalDutyCurrency;
    @ViewDefinition(id = "totalDuty", order = 41, label = "Total Duty")
    private String totalDuty;

    @ViewDefinition(id = "itemConsignee", order = 42, label = "Consignee EORI", path = ".eori")
    @ViewDefinition(id = "itemConsignee", order = 43, label = "Consignee Name", path = ".name")
    @ViewDefinition(id = "itemConsignee", order = 44, label = "Consignee Postcode", path = ".postcode")
    private Trader itemConsignee;
    @ViewDefinition(id = "itemConsignor", order = 45, label = "Consignor EORI", path = ".eori")
    @ViewDefinition(id = "itemConsignor", order = 46, label = "Consignor Name", path = ".name")
    @ViewDefinition(id = "itemConsignor", order = 47, label = "Consignor Postcode", path = ".postcode")
    private Trader itemConsignor;
    @ViewDefinition(id = "itemDeclarant", order = 48, label = "Declarant EORI", path = ".eori")
    @ViewDefinition(id = "itemDeclarant", order = 49, label = "Declarant Name", path = ".name")
    @ViewDefinition(id = "itemDeclarant", order = 50, label = "Declarant Postcode", path = ".postcode")
    private Trader itemDeclarant;
}
