package uk.gov.gsi.hmrc.cds.search.filter;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.UUID;

@Slf4j
@Component
@Order(1)
public class CorrelationIdFilter implements Filter {

    static final String CORRELATION_ID_HEADER = "X-Correlation-ID";
    public static final String MDC_CORRELATION_ID = "correlationId";

    @Override
    public void init(FilterConfig filterConfig) {}

    @Override
    public void doFilter(ServletRequest request,
                         ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {
        try {
            populateMDCWithCorrelationId(request);
            chain.doFilter(request, response);
        }finally {
            MDC.remove(MDC_CORRELATION_ID);
        }
    }

     void populateMDCWithCorrelationId(ServletRequest request)  {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        String correlationId= getCorrelationIdOrCreateIfMissing(httpRequest);

        MDC.put(MDC_CORRELATION_ID, correlationId);
        log.debug("Correlation ID found: {}", correlationId);
    }

    private String getCorrelationIdOrCreateIfMissing(HttpServletRequest httpRequest) {
        String correlationId = httpRequest.getHeader(CORRELATION_ID_HEADER);

        if (correlationId == null) {
            return UUID.randomUUID().toString();
        }
        return correlationId;
    }

    @Override
    public void destroy() {}


}
