package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.Trader;
import uk.gov.gsi.hmrc.cds.search.api.dto.ViewDefinition;

import java.util.List;

import static java.util.Collections.emptyList;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Declaration {

    @ViewDefinition(id = "declarationId", order = 1, label = "Declaration ID", header = true)
    private String declarationId;
    @ViewDefinition(id = "importExportIndicator", order = 2, label = "Import/Export", header = true)
    private String importExportIndicator;
    @ViewDefinition(id = "declarationSource", order = 3, label = "Declaration Source", header = true)
    private String declarationSource;
    @ViewDefinition(id = "declarationType", order = 4, label = "Declaration Type", header = true)
    private String declarationType;
    @ViewDefinition(id = "declarationStatus", order = 5, label = "Declaration Status")
    private String declarationStatus;
    @ViewDefinition(id = "epuNumber", order = 6, label = "EPU")
    private String epuNumber;
    @ViewDefinition(id = "entryNumber", order = 7, label = "Entry Number")
    private String entryNumber;
    @ViewDefinition(id = "entryDate", order = 8, label = "Entry Date", type = "timestamp")
    private String entryDate;
    @ViewDefinition(id = "acceptanceDate", order = 9, label = "Acceptance Date", type = "timestamp")
    private String acceptanceDate;
    @ViewDefinition(id = "route", order = 10, label = "Route of Entry")
    private String route;
    @ViewDefinition(id = "goodsLocation", order = 11, label = "Goods Location")
    private String goodsLocation;
    @ViewDefinition(id = "dispatchCountry", order = 12, label = "Country of Dispatch", path = ".code")
    private Country dispatchCountry;
    @ViewDefinition(id = "destinationCountry", order = 13, label = "Country of Destination", path = ".code")
    private Country destinationCountry;
    @ViewDefinition(id = "placeOfLoading", order = 14, label = "Place of Loading")
    private String placeOfLoading;
    @ViewDefinition(id = "transportModeCode", order = 15, label = "Mode of Transport")
    private String transportModeCode;
    @ViewDefinition(id = "inlandTransportMode", order = 16, label = "Inland Mode of Transport")
    private String inlandTransportMode;
    @ViewDefinition(id = "transportId", order = 17, label = "Transport ID")
    private String transportId;
    @ViewDefinition(id = "containerId", order = 18, label = "Container Number")
    private String containerId;
    @ViewDefinition(id = "premisesId", order = 19, label = "Premises ID")
    private String premisesId;
    @ViewDefinition(id = "totalPackages", order = 20, label = "Total Packages")
    private String totalPackages;
    @ViewDefinition(id = "grossMass", order = 21, label = "Gross Mass")
    private String grossMass;
    @ViewDefinition(id = "invoiceCurrency", order = 22, label = "Invoice Currency")
    private String invoiceCurrency;
    @ViewDefinition(id = "invoiceTotal", order = 23, label = "Invoice Total")
    private String invoiceTotal;

    @ViewDefinition(id = "consignee", order = 24, label = "Consignee EORI", path = ".eori")
    @ViewDefinition(id = "consignee", order = 25, label = "Consignee Name", path = ".name")
    @ViewDefinition(id = "consignee", order = 26, label = "Consignee Postcode", path = ".postcode")
    private Trader consignee;
    @ViewDefinition(id = "consignor", order = 27, label = "Consignor EORI", path = ".eori")
    @ViewDefinition(id = "consignor", order = 28, label = "Consignor Name", path = ".name")
    @ViewDefinition(id = "consignor", order = 29, label = "Consignor Postcode", path = ".postcode")
    private Trader consignor;
    @ViewDefinition(id = "declarant", order = 30, label = "Declarant EORI", path = ".eori")
    @ViewDefinition(id = "declarant", order = 31, label = "Declarant Name", path = ".name")
    @ViewDefinition(id = "declarant", order = 32, label = "Declarant Postcode", path = ".postcode")
    private Trader declarant;

    @ViewDefinition(id = "declarantRepresentation", order = 33, label = "Declarant Representation")
    private String declarantRepresentation;
    @ViewDefinition(id = "communicationId", order = 34, label = "Communication ID")
    private String communicationId;

    private List<DeclarationLine> lines;

    public List<DeclarationLine> getLines() {
        return lines == null ? emptyList() : lines;
    }

}
