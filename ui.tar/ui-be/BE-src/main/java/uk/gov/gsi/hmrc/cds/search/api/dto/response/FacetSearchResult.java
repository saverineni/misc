package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import lombok.Builder;
import lombok.Value;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.Facet;

import java.util.List;

@Value
@Builder
public class FacetSearchResult {
    private List<Facet> facets;
}


