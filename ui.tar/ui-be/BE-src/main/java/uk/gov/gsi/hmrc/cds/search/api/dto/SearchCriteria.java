package uk.gov.gsi.hmrc.cds.search.api.dto;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;

@Data
public class SearchCriteria {

    public static final int DEFAULT_PAGE_SIZE = 10;
    public static final int DEFAULT_PAGE_NUMBER = 1;

    private Integer pageSize = DEFAULT_PAGE_SIZE;
    private Integer pageNumber = DEFAULT_PAGE_NUMBER;

    private String searchTerm;
    private String eori;
    private List<String> originCountryCode;
    private List<String> dispatchCountryCode;
    private List<String> destinationCountryCode;
    private List<String> transportModeCode;
    private List<String> goodsLocation;
    private List<String> commodityCode;
    private List<String> cpc;
    private List<String> declarationType;
    private List<String> declarationSource;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate entryDateFrom;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate entryDateTo;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate clearanceDateFrom;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate clearanceDateTo;

    public Optional<String> optionalSearchTerm() {
        return optionalField(searchTerm);
    }

    public Optional<String> optionalEori() {
        return optionalField(eori);
    }

    private Optional<String> optionalField(String optional) {
        return Optional.ofNullable(optional)
                .map(String::trim)
                .filter(t -> !t.isEmpty());
    }

    public List<String> getOriginCountryCode() {
        return emptyListWhenNullBlankStringWhenEmpty(originCountryCode);
    }

    public List<String> getDispatchCountryCode() {
        return emptyListWhenNullBlankStringWhenEmpty(dispatchCountryCode);
    }

    public List<String> getDestinationCountryCode() {
        return emptyListWhenNullBlankStringWhenEmpty(destinationCountryCode);
    }

    public List<String> getTransportModeCode() {
        return emptyListWhenNullBlankStringWhenEmpty(transportModeCode);
    }

    public List<String> getGoodsLocation() {
        return emptyListWhenNullBlankStringWhenEmpty(goodsLocation);
    }

    public List<String> getCommodityCode() {
        return emptyListWhenNullBlankStringWhenEmpty(commodityCode);
    }

    public List<String> getCpc() {
        return emptyListWhenNullBlankStringWhenEmpty(cpc);
    }

    public List<String> getDeclarationType() {
        return emptyListWhenNullBlankStringWhenEmpty(declarationType);
    }

    public List<String> getDeclarationSource() {
        return emptyListWhenNullBlankStringWhenEmpty(declarationSource);
    }

    /**
     * Spring converts a single empty string parameter to an empty list
     * there is no easy hook to override this default behaviour.
     */
    private List<String> emptyListWhenNullBlankStringWhenEmpty(List<String> values) {
        if (values == null) {
            return emptyList();
        }
        if (values.isEmpty()) {
            return singletonList("");
        }
        return values;
    }

    public Optional<LocalDateTime> optionalEntryDateTimeFrom() {
        return Optional.ofNullable(entryDateFrom)
                .map(date -> LocalDateTime.of(date, LocalTime.MIN));
    }

    public Optional<LocalDateTime> optionalEntryDateTimeTo() {
        return Optional.ofNullable(entryDateTo)
                .map(date -> LocalDateTime.of(date, LocalTime.MAX));
    }

    public Optional<LocalDateTime> optionalClearanceDateTimeFrom() {
        return Optional.ofNullable(clearanceDateFrom)
                .map(date -> LocalDateTime.of(date, LocalTime.MIN));
    }

    public Optional<LocalDateTime> optionalClearanceDateTimeTo() {
        return Optional.ofNullable(clearanceDateTo)
                .map(date -> LocalDateTime.of(date, LocalTime.MAX));
    }

}
