package uk.gov.gsi.hmrc.cds.search.contracttests;

import org.junit.Test;
import org.junit.experimental.categories.Category;

import static org.junit.Assert.assertTrue;


@Category(ContractTests.class)
public class SampleTest {

    @Test
    public void a() {
        assertTrue(false);
    }
}
