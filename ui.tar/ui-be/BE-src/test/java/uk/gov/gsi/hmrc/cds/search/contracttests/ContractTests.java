package uk.gov.gsi.hmrc.cds.search.contracttests;

public interface ContractTests {
}
