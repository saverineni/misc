package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Arrays;

import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.junit.Before;
import org.junit.Test;

import static org.elasticsearch.common.xcontent.XContentType.JSON;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchHitMatchers.declarationId;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchResponseAssert.assertSearchHits;

import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;

public class SearchClientDestinationCountryIT extends CustomsSearchESIntegTestCase {
    private static final String CUSTOMS_INDEX = "SearchServiceDestinationCountryIntegrationTest".toLowerCase();
    private static final String GB_CODE = "GB";
    private static final String FR_CODE = "FR";
    private static final String EPU = "EPU";

    private ObjectMapper objectMapper = new ObjectMapper();

    @Before
    public void setUp() throws Exception {
        super.setUp(CUSTOMS_INDEX);
        createCustomsIndexWithDocuments();
    }

    @Test
    public void searchWithBlankDestinationCountryFacet() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(""));
        assertSearchHits(searchResponse, declarationId("dec-id-5"));
    }

    @Test
    public void searchWithOneDestinationCountryFacet() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(GB_CODE));
        assertSearchHits(searchResponse,
                declarationId("dec-id-1"),
                declarationId("dec-id-2"),
                declarationId("dec-id-3"));
    }

    @Test
    public void searchWithTwoDestinationCountryFacets() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(GB_CODE, FR_CODE));

        assertSearchHits(searchResponse,
                declarationId("dec-id-1"),
                declarationId("dec-id-2"),
                declarationId("dec-id-3"),
                declarationId("dec-id-4"));
    }

    @Test
    public void searchWithOneDestinationCountryFacetWithSearchTerm() {
        SearchCriteria searchCriteria = newSearchCriteria(FR_CODE);
        searchCriteria.setSearchTerm(EPU);
        SearchResponse searchResponse = this.service.declarationSearch(searchCriteria);

        assertSearchHits(searchResponse, declarationId("dec-id-4"));
    }

    private SearchCriteria newSearchCriteria(String... destinationCountryCodes) {
        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setDestinationCountryCode(Arrays.asList(destinationCountryCodes));
        return searchCriteria;
    }

    private void createCustomsIndexWithDocuments() throws Exception {
        createIndex(CUSTOMS_INDEX);

        BulkRequest request = new BulkRequest();
        addDeclaration(request, newDeclaration("dec-id-1", GB_CODE));
        addDeclaration(request, newDeclaration("dec-id-2", GB_CODE));
        addDeclaration(request, newDeclaration("dec-id-3", GB_CODE));
        addDeclaration(request, newDeclaration("dec-id-4", FR_CODE));
        addDeclaration(request, newDeclaration("dec-id-5", ""));
        addDeclaration(request, newDeclaration("dec-id-6", null));

        client.bulk(request);

        refresh(CUSTOMS_INDEX);
    }

    private void addDeclaration(BulkRequest request, Declaration declaration) throws JsonProcessingException {
        request.add(new IndexRequest(CUSTOMS_INDEX, DECLARATION_TYPE, declaration.getDeclarationId())
                .source(objectMapper.writer().writeValueAsString(declaration), JSON));
    }


    private Declaration newDeclaration(String id, String destinationCountryCode) {
        return Declaration.builder()
                .declarationId(id)
                .epuNumber(EPU)
                .destinationCountry(Country.builder().code(destinationCountryCode).build())
                .build();
    }
}
