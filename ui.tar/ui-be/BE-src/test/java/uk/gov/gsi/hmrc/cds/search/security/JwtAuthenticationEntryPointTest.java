package uk.gov.gsi.hmrc.cds.search.security;

import javax.servlet.http.HttpServletResponse;

import org.junit.Test;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class JwtAuthenticationEntryPointTest {
    JwtAuthenticationEntryPoint entryPoint = new JwtAuthenticationEntryPoint();
    private HttpServletResponse response = mock(HttpServletResponse.class);

    @Test
    public void shouldSetResponseAsUnauthorisedOnError() throws Exception {
        entryPoint.commence(null, response , null);

        verify(response).setStatus(401);
    }
}
