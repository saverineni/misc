package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.junit.Before;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static java.util.Arrays.asList;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchSourceBuilderMatchers.*;

public class SearchQueryBuilderDelegateTest {

    private SearchQueryBuilderDelegate queryBuilderDelegate = new SearchQueryBuilderDelegate();
    private SearchCriteria searchCriteria;

    private static final String SEARCH_TERM = "122";
    private static final String EORI = "582109443894367";
    private static final String IN_CODE = "IN";
    private static final String NZ_CODE = "NZ";
    private static final String CA_CODE = "CA";
    private static final String CH_CODE = "CH";
    private static final String ABC_GOODS_LOCATION = "ABC";
    private static final String DEF_GOODS_LOCATION = "DEF";
    private static final String COMMODITY_CODE_1 = "0123456789";
    private static final String COMMODITY_CODE_2 = "9876543210";
    private static final String CPC_CODE_1 = "1111122222";
    private static final String CPC_CODE_2 = "3355116699";
    private static final List DEC_TYPE = Arrays.asList("X","Y");
    private static final String DEC_SOURCE = "DMS";
    private static final LocalDate FROM_DATE = LocalDate.of(2018, 1, 6);
    private static final LocalDate TO_DATE = LocalDate.of(2018, 1, 6);

    @Before
    public void setUp() {
        searchCriteria = new SearchCriteria();
    }

    @Test
    public void facetFieldNameForLineFacets() {
        assertEquals(queryBuilderDelegate.getFacetFieldName("originCountryCode"), "lines.originCountryCode.prefix");
        assertEquals(queryBuilderDelegate.getFacetFieldName("commodityCode"), "lines.commodityCode.prefix");
        assertEquals(queryBuilderDelegate.getFacetFieldName("cpc"), "lines.cpc.prefix");
    }

    @Test
    public void facetFieldNameForOtherFacets() {
        assertEquals(queryBuilderDelegate.getFacetFieldName("dispatchCountryCode"), "dispatchCountryCode.prefix");
    }

    @Test
    public void getQueryBuilderWithPagination() {
        final BoolQueryBuilder query = QueryBuilders.boolQuery().must(QueryBuilders.matchAllQuery());
        setSearchCriteria(searchCriteria);
        final SearchSourceBuilder searchSourceBuilder = queryBuilderDelegate.getQueryBuilderWithPagination(searchCriteria,query);
        assertBuilderForPagination(searchSourceBuilder);
    }

    @Test
    public void getQueryBuilderWithFacets() {
        final BoolQueryBuilder query = QueryBuilders.boolQuery().must(QueryBuilders.matchAllQuery());
        setSearchCriteria(searchCriteria);
        final SearchSourceBuilder searchSourceBuilder = queryBuilderDelegate.getQueryBuilderWithFacets(searchCriteria,query,"originCountryCode");
        assertBuilderForPagination(searchSourceBuilder);
        assertThat(searchSourceBuilder,facets(equalTo("lines.originCountry.code")));
    }


    private void setSearchCriteria(SearchCriteria searchCriteria) {
        searchCriteria.setSearchTerm(SEARCH_TERM);
        searchCriteria.setEori(EORI);
        searchCriteria.setOriginCountryCode(asList(IN_CODE,NZ_CODE));
        searchCriteria.setDestinationCountryCode(asList(CA_CODE));
        searchCriteria.setDispatchCountryCode(asList(CH_CODE));
        searchCriteria.setGoodsLocation(asList(ABC_GOODS_LOCATION,DEF_GOODS_LOCATION));
        searchCriteria.setCommodityCode(asList(COMMODITY_CODE_1,COMMODITY_CODE_2));
        searchCriteria.setCpc(asList(CPC_CODE_1,CPC_CODE_2));
        searchCriteria.setEntryDateFrom(FROM_DATE);
        searchCriteria.setEntryDateTo(TO_DATE);
        searchCriteria.setClearanceDateFrom(FROM_DATE);
        searchCriteria.setClearanceDateTo(TO_DATE);
        searchCriteria.setDeclarationType(DEC_TYPE);
        searchCriteria.setDeclarationSource(asList(DEC_SOURCE));
    }

    private void assertBuilderForPagination(SearchSourceBuilder searchSourceBuilder) {
        assertThat(searchSourceBuilder,query(equalTo(asList(SEARCH_TERM,EORI))));
        assertThat(searchSourceBuilder,term("lines.originCountry.code", equalTo(asList(IN_CODE,NZ_CODE))));
        assertThat(searchSourceBuilder,term("lines.commodityCode", equalTo(asList(COMMODITY_CODE_1,COMMODITY_CODE_2))));
        assertThat(searchSourceBuilder,term("lines.cpc", equalTo(asList(CPC_CODE_1,CPC_CODE_2))));

        assertThat(searchSourceBuilder,term("dispatchCountry.code", equalTo(asList(CH_CODE))));
        assertThat(searchSourceBuilder,term("destinationCountry.code", equalTo(asList(CA_CODE))));
        assertThat(searchSourceBuilder,term("goodsLocation", equalTo(asList(ABC_GOODS_LOCATION,DEF_GOODS_LOCATION))));

        assertThat(searchSourceBuilder,term("declarationType", equalTo((DEC_TYPE))));
        assertThat(searchSourceBuilder,term("declarationSource", equalTo(asList(DEC_SOURCE))));
    }

}
