package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import java.util.Optional;

import org.elasticsearch.action.search.SearchResponse;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.FacetSearchResult;

@RunWith(MockitoJUnitRunner.class)
public class ElasticDeclarationSearchClientTest {


    private static final SearchCriteria SEARCH_CRITERIA = new SearchCriteria();
    private static final String FACET_TYPE = "facetType";
    private static final Optional<String> PREFIX = Optional.of("prefix");

    static {
        SEARCH_CRITERIA.setSearchTerm("SEARCH_CRITERIA");
    }

    private static final String DECLARATION_ID = "declarationId";

    @Mock
    private SearchResponseMapperService searchResponseMapperService;

    @Mock
    private SearchClient searchClient;

    @Mock
    private SearchResponse searchResponse;

    private DeclarationSearchResult declarationSearchResult = DeclarationSearchResult.builder().build();

    private Optional<Declaration> declarationResult = Optional.of(Declaration.builder().build());

    private FacetSearchResult facetSearchResult = FacetSearchResult.builder().build();

    @InjectMocks
    private ElasticDeclarationSearchService elasticDeclarationSearchService;

    @Before
    public void setup() {
        when(searchClient.declarationSearch(SEARCH_CRITERIA)).thenReturn(searchResponse);
        when(searchClient.getDeclarationById(DECLARATION_ID)).thenReturn(searchResponse);
        when(searchClient.facetSearch(SEARCH_CRITERIA, FACET_TYPE, PREFIX)).thenReturn(searchResponse);
        when(searchResponseMapperService.mapDeclarationsResponse(searchResponse)).thenReturn(declarationSearchResult);
        when(searchResponseMapperService.mapDeclarationByIdResponse(searchResponse)).thenReturn(declarationResult);
        when(searchResponseMapperService.mapFacetsResponse(searchResponse, FACET_TYPE, PREFIX)).thenReturn(facetSearchResult);
    }

    @Test
    public void returnsDeclarationSearchResult() {
        DeclarationSearchResult actual = elasticDeclarationSearchService.fetchDeclarationSearchResult(SEARCH_CRITERIA);
        assertThat(actual, is(declarationSearchResult));
    }

    @Test
    public void returnsDeclaration() {
        Optional<Declaration> actual = elasticDeclarationSearchService.fetchDeclarationById(DECLARATION_ID);
        assertThat(actual, is(declarationResult));
    }

    @Test
    public void returnsFacets() {
        FacetSearchResult actual = elasticDeclarationSearchService.fetchFacetSearchResult(SEARCH_CRITERIA, FACET_TYPE, PREFIX);
        assertThat(actual, is(facetSearchResult));
    }

}