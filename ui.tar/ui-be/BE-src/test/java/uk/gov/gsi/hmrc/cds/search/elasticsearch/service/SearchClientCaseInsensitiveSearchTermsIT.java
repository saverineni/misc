package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Arrays;
import java.util.Collection;

import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import static org.elasticsearch.common.xcontent.XContentType.JSON;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.Trader;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLine;

@RunWith(Parameterized.class)
public class SearchClientCaseInsensitiveSearchTermsIT extends CustomsSearchESIntegTestCase {

    private static final String CUSTOMS_INDEX = "SearchClientCaseInsensitiveSearchTermsIT".toLowerCase();

    private static final String DECLARATION_ID = "219-249099X-2013-07-14";
    private static final String ENTRY_NUMBER = "120658e";
    private static final String EPU_NUMBER = "219";
    private static final String CONSIGNEE_NAME = "conSignee naMe";
    private static final String CONSIGNEE_POSTCODE = "m11 0rX";

    private static final String CONSIGNOR_NAME = "conSignor naMe";
    private static final String CONSIGNOR_POSTCODE = "b13 1aD";

    private static final String ITEM_CONSIGNEE_NAME = "IteM conSignee naMe";
    private static final String ITEM_CONSIGNEE_POSTCODE = "n25 9Qc";

    private static final String ITEM_CONSIGNOR_NAME = "iTEm conSignor naMe";
    private static final String ITEM_CONSIGNOR_POSTCODE = "l52 9aB";
    private static final String ORIGIN_COUNTRY_CODE = "uK";
    public static final long DECLARATION_COUNT = 1L;
    private final String searchTerm;
    private final Long numberOfdeclarations;

    private ObjectMapper objectMapper = new ObjectMapper();

    public SearchClientCaseInsensitiveSearchTermsIT(String searchTerm , Long numberOfdeclarations){
        this.searchTerm = searchTerm;
        this.numberOfdeclarations = numberOfdeclarations;
    }

    @Parameters(name = "{0}")
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][] {
                {"219-249099x-2013-07-14", DECLARATION_COUNT},
                {"120658E", DECLARATION_COUNT},
                {"conSignee Name", DECLARATION_COUNT},
                {"M11 0RX", DECLARATION_COUNT},
                {"consignor name", DECLARATION_COUNT},
                {"B13 1Ad", DECLARATION_COUNT},
                {"item consignee Name", DECLARATION_COUNT},
                {"N25 9qC", DECLARATION_COUNT},
                {"ITem consignor name", DECLARATION_COUNT},
                {"L52 9AB", DECLARATION_COUNT},
                {"UK", DECLARATION_COUNT}
        });
    }

    @Before
    public void setUp() throws Exception {
        super.setUp(CUSTOMS_INDEX);
        createCustomsIndexWithDocuments();
    }

    @Test
    public void caseInsensitiveSearch() {
        SearchResponse searchResponse = service.declarationSearch(newSearchCriteria(searchTerm));
        assertThat(searchResponse.getHits().totalHits, is(numberOfdeclarations));
    }


    private SearchCriteria newSearchCriteria(String searchTerm) {
        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setSearchTerm(searchTerm);
        return searchCriteria;
    }


    private void createCustomsIndexWithDocuments() throws Exception {
        createIndex(CUSTOMS_INDEX);
        BulkRequest request = new BulkRequest();
        addDeclaration(request, newDeclaration());

        client.bulk(request);
        refresh(CUSTOMS_INDEX);
    }

    private void addDeclaration(BulkRequest request, Declaration declaration) throws JsonProcessingException {
        request.add(new IndexRequest(CUSTOMS_INDEX, DECLARATION_TYPE, declaration.getDeclarationId())
                .source(objectMapper.writer().writeValueAsString(declaration), JSON));
    }

    private Declaration newDeclaration() {
        return Declaration.builder()
                .declarationId(DECLARATION_ID)
                .epuNumber(EPU_NUMBER)
                .entryNumber(ENTRY_NUMBER)
                .consignee(Trader.builder().name(CONSIGNEE_NAME).postcode(CONSIGNEE_POSTCODE).build())
                .consignor(Trader.builder().name(CONSIGNOR_NAME).postcode(CONSIGNOR_POSTCODE).build())
                .lines(
                        Arrays.asList(DeclarationLine.builder()
                                .originCountry(Country.builder().code(ORIGIN_COUNTRY_CODE).build())
                        .itemConsignee(Trader.builder().name(ITEM_CONSIGNEE_NAME).postcode(ITEM_CONSIGNEE_POSTCODE).build())
                        .itemConsignor(Trader.builder().name(ITEM_CONSIGNOR_NAME).postcode(ITEM_CONSIGNOR_POSTCODE).build())
                        .build())
                )
                .build();
    }

}
