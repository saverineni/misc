package uk.gov.gsi.hmrc.cds.search.api.converters;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.MediaType;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.Trader;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLine;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

public class DeclarationLineCsvConverterTest {

    private DeclarationLineCsvConverter converter = new DeclarationLineCsvConverter();
    private String headerLine = Stream.of(DeclarationLineCsvConverter.HEADERS).collect(Collectors.joining(","));

    @Mock
    private HttpOutputMessage mockHttpOutputMessage;

    private HttpHeaders headers;

    @Before
    public void setup() {
        initMocks(this);
        headers = new HttpHeaders();
    }

    @Test
    public void shouldAddMediaTypeHeader() throws IOException {
        whenGivenOutput();
        converter.writeInternal(Declaration.builder().build(), mockHttpOutputMessage);

        assertThat(headers.getContentType(), is(equalTo(MediaType.valueOf("text/csv"))));
    }

    @Test
    public void shouldReturnHeaderLineWithNoResults() throws IOException {
        ByteArrayOutputStream output = whenGivenOutput();
        converter.writeInternal(Declaration.builder().build(), mockHttpOutputMessage);

        assertThat(output.toString(), is(equalTo(headerLine + "\n")));
    }

    @Test
    public void shouldReturnHeaderLineWithResults() throws IOException {
        ByteArrayOutputStream output = whenGivenOutput();
        Declaration result = Declaration.builder()
                .declarationId("declarationId")
                .importExportIndicator("importExport")
                .declarationSource("declarationSource")
                .declarationType("declarationType")
                .lines(asList(
                        DeclarationLine.builder()
                                .itemNumber(1)
                                .build(),
                        DeclarationLine.builder()
                                .itemNumber(2)
                                .itemRoute("itemRoute")
                                .itemDispatchCountry(Country.builder().code("itemDispatchCountry").build())
                                .firstDestinationCountry(Country.builder().code("firstDestinationCountry").build())
                                .itemDestinationCountry(Country.builder().code("itemDestinationCountry").build())
                                .clearanceDate("clearanceDate")
                                .acceptanceDate("acceptanceDate")
                                .cpc("cpc")
                                .originCountry(Country.builder().code("originCountry").build())
                                .commodityCode("commodityCode")
                                .itemConsignee(Trader.builder().eori("itemConsigneeEori").name("itemConsigneeName").postcode("itemConsigneePostcode").build())
                                .itemConsignor(Trader.builder().eori("itemConsignorEori").name("itemConsignorName").postcode("itemConsignorPostcode").build())
                                .itemDeclarant(Trader.builder().eori("itemDeclarantEori").name("itemDeclarantName").postcode("itemDeclarantPostcode").build())
                                .packageKind("packageKind")
                                .packageCount("packageCount")
                                .packageMarks("packageMarks")
                                .goodsDescription("goodsDescription")
                                .containerId("containerId")
                                .grossMass("grossMass")
                                .preference("preference")
                                .netMass("netMass")
                                .quotaNumber("quotaNumber")
                                .summaryDeclaration("summaryDeclaration")
                                .supplementaryUnits("supplementaryUnits")
                                .itemPrice("itemPrice")
                                .invoiceCurrency("invoiceCurrency")
                                .valuationMethod("valuationMethod")
                                .aiStatement("aiStatement")
                                .statementDescription("statementDescription")
                                .valuationAdjustmentCode("valuationAdjustmentCode")
                                .valuationAdjustmentAmount("valuationAdjustmentAmount")
                                .valuationAdjustmentCurrency("valuationAdjustmentCurrency")
                                .statisticalValue("statisticalValue")
                                .statisticalValueCurrency("statisticalValueCurrency")
                                .taxTypeCode("taxTypeCode")
                                .taxBaseUnit("taxBaseUnit")
                                .taxBaseQualifier("taxBaseQualifier")
                                .taxBaseQuantity("taxBaseQuantity")
                                .rate("rate")
                                .rateCurrency("rateCurrency")
                                .amount("amount")
                                .amountType("amountType")
                                .methodOfPayment("methodOfPayment")
                                .totalDuty("totalDuty")
                                .totalDutyCurrency("totalDutyCurrency")
                                .build()
                ))
                .build();
        converter.writeInternal(result, mockHttpOutputMessage);

        assertThat(output.toString(), is(equalTo(
                headerLine + "\n" +
                        "1,declarationId,importExport,declarationSource,declarationType,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,\n" +
                        "2,declarationId,importExport,declarationSource,declarationType,itemRoute,cpc,acceptanceDate,clearanceDate," +
                        "originCountry,itemDispatchCountry,firstDestinationCountry,itemDestinationCountry,containerId,packageKind," +
                        "packageMarks,packageCount,goodsDescription,grossMass,netMass,quotaNumber,preference,summaryDeclaration," +
                        "supplementaryUnits,aiStatement,statementDescription,invoiceCurrency,itemPrice,statisticalValueCurrency," +
                        "statisticalValue,commodityCode,valuationMethod,valuationAdjustmentCode,valuationAdjustmentCurrency," +
                        "valuationAdjustmentAmount,taxTypeCode,taxBaseUnit,taxBaseQualifier,taxBaseQuantity,rate,rateCurrency,amount," +
                        "amountType,methodOfPayment,totalDutyCurrency,totalDuty,itemConsigneeEori,itemConsigneeName,itemConsigneePostcode," +
                        "itemConsignorEori,itemConsignorName,itemConsignorPostcode,itemDeclarantEori,itemDeclarantName,itemDeclarantPostcode\n"
        )));
    }

    private ByteArrayOutputStream whenGivenOutput() throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        when(mockHttpOutputMessage.getBody()).thenReturn(output);
        when(mockHttpOutputMessage.getHeaders()).thenReturn(headers);
        return output;
    }

}
