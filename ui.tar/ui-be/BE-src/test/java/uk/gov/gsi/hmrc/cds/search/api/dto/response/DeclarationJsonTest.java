package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.*;

@RunWith(SpringRunner.class)
@JsonTest
@ActiveProfiles("test")
public class DeclarationJsonTest {

    @Autowired
    private JacksonTester<Declaration> json;

    @Test
    public void deserializeEmptyDeclaration() throws Exception {
        String content = "{}";
        assertThat(this.json.parse(content)).isEqualTo(Declaration.builder().build());
    }

}