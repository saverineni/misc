package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import com.jayway.jsonpath.JsonPath;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.hamcrest.FeatureMatcher;
import org.hamcrest.Matcher;

public class SearchSourceBuilderMatchers {

    private static final String queryPath = "$.query.bool.must[*]";
    private static final String aggregationsPath = "$.aggregations.facets.terms.field";

    public static Matcher<SearchSourceBuilder> fieldValue(String jsonPath, Matcher<Object> expectedValue) {
        return new FeatureMatcher<SearchSourceBuilder, Object>(expectedValue, jsonPath, jsonPath) {

            @Override
            protected Object featureValueOf(SearchSourceBuilder searchSourceBuilder) {
                return JsonPath.read(searchSourceBuilder.toString(), jsonPath);
            }
        };
    }

    public static Matcher<SearchSourceBuilder> query(Matcher<Object> expectedValue) {
        return fieldValue(queryPath + ".multi_match.query", expectedValue);
    }

    public static Matcher<SearchSourceBuilder> term(String term,Matcher<Object> expectedValue) {
        return fieldValue(queryPath + ".bool.should[*].term['"+ term + "'].value", expectedValue);
    }

    public static Matcher<SearchSourceBuilder> facets(Matcher<Object> expectedValue) {
        return fieldValue(aggregationsPath , expectedValue);
    }
}
