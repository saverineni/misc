package uk.gov.gsi.hmrc.cds.search.api.dto;

import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;

import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

public class ViewDefinitionTest {

    @Test
    public void orderedViewDefinitionsShouldOnlyReturnViewDefinitionFields() {
        List<ViewDefinition> definitions = ViewDefinition.Utils.orderedViewDefinitions(Declaration.class);

        for (ViewDefinition definition : definitions) {
            assertThat(definition, is(notNullValue()));
        }
    }

    @Test
    public void orderedViewDefinitionsShouldReturnSortedFields() {
        List<ViewDefinition> definitions = ViewDefinition.Utils.orderedViewDefinitions(Declaration.class);

        for (int i = 0; i < definitions.size() - 1; i++) {
            assertThat(definitions.get(i).order() <= definitions.get(i + 1).order(), is(true));
        }
    }

    @Test
    public void orderedViewDefinitionsShouldReturnRepeatedFields() {
        List<ViewDefinition> definitions = ViewDefinition.Utils.orderedViewDefinitions(Declaration.class);

        assertThat(definitions.get(23).id(), is(equalTo("consignee")));
        assertThat(definitions.get(24).id(), is(equalTo("consignee")));
        assertThat(definitions.get(25).id(), is(equalTo("consignee")));
    }

}