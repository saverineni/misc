package uk.gov.gsi.hmrc.cds.search.elasticsearch.connection.headers;

import org.apache.http.Header;
import org.jboss.logging.MDC;
import org.junit.Test;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import uk.gov.gsi.hmrc.cds.search.filter.CorrelationIdFilter;

public class ESHeadersTest {

    private static final String CORRELATION_ID = "123456789";
    private static final String PID = "123456789";

    @SuppressWarnings("serial")
    SecurityContext context = new SecurityContext() {
        @Override
        public void setAuthentication(Authentication authentication) {}

        @Override
        public Authentication getAuthentication() {
            return new TestingAuthenticationToken(PID, null);
        }
    };

    ESHeaders headers = new ESHeaders();

    @Test
    public void shouldReturnTheEsRequestHeadersContainingTheCurrentCorrelationId() {
        MDC.put(CorrelationIdFilter.MDC_CORRELATION_ID, CORRELATION_ID);

        Header correlationIdHeader = headers.getHeaders()[0];

        assertThat(correlationIdHeader.getName(), is("X-Correlation-ID"));
        assertThat(correlationIdHeader.getValue(), is(CORRELATION_ID));
    }

    @Test
    public void shouldReturnTheEsRequestHeadersContainingTheLoggedInUsersPid() {
		SecurityContextHolder.setContext(context);

        Header runAsUserHeader = headers.getHeaders()[1];

        assertThat(runAsUserHeader.getName(), is("es-security-runas-user"));
        assertThat(runAsUserHeader.getValue(), is(PID));
    }
}
