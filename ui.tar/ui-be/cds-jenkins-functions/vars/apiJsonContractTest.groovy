def call(body) {
    def contractTestParams = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = contractTestParams
    body()

    try {
        sh "docker run -d -p ${contractTestParams.contractPort}:8080 --name contract_test_data --rm ${contractTestParams.contractImageName}"
        
        def constractSchemaUrl = startServiceForJsonContract(contractTestParams.apiImageName, 'contract_test_schema', contractTestParams.apiPort)

        sh "curl -k https://artifactory.dataengineering.apps.hmrci/artifactory/cdsdar-maven/uk/gov/gsi/hmrc/cds/search/contract-tests/${contractTestParams.contractTestVersion}/contract-tests-${contractTestParams.contractTestVersion}-jar-with-dependencies.jar --output contract-tests.jar"
        sh "java -jar contract-tests.jar ${constractSchemaUrl} http://localhost:${contractTestParams.contractPort}"
    }
    finally {
        sh 'docker stop contract_test_data'
        sh 'docker stop contract_test_schema'
    }
}