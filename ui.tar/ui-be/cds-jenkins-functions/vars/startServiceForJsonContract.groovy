def call(image, name, port) {
    def jsonContractUrl = "http://localhost:${port}/v2/api-docs"

    sh "docker run -d -p ${port}:8080 --name ${name} --rm -e SPRING_PROFILES_ACTIVE=contract ${image}"

    timeout(time: 1, unit: 'MINUTES') {
        waitUntil {
            script {
                try {
                    httpRequest(jsonContractUrl).status == 200
                } catch (e) {
                    println('Service not started, try again...')
                    return false
                }
            }
        }
    }

    return jsonContractUrl
}