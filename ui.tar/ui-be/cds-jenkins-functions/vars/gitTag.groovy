#!/usr/bin/env groovy

def call(String tag) {
    sshagent([jenkinsCredentialCdsdataBitbucket()]) {
        script {
            sh "git tag -a ${tag} -m 'Docker image tag: version ${tag}' || true"
            sh "git push origin tag ${tag}"
        }
    }

}