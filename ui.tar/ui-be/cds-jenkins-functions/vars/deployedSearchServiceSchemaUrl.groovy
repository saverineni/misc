import groovy.json.JsonSlurperClassic

def call(environment) {
    "https://searchservice-${environment}-cdap.nonprod.eu-west-2.aws.dat.corp.hmrc.gov.uk/v2/api-docs"
}
