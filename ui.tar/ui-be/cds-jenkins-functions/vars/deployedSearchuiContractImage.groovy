import groovy.json.JsonSlurperClassic

def call(environment) {
    def response = httpRequest("https://searchui-${environment}-cdap.nonprod.eu-west-2.aws.dat.corp.hmrc.gov.uk/build/info")
    def json = new JsonSlurperClassic().parseText(response.content)

    return "artifactory.dataengineering.apps.hmrci:8001/cdsdar/customs-search-ui:${json.version}_contract"
}
