package cds.infrastructure.shared

class SearchIngestion {
    private final pipeline

    SearchIngestion(pipeline) {
        this.pipeline = pipeline
    }

    def indexManagerAction(env, action, indexName='') {

        pipeline.runJavaJob(
                env,
                pipeline."getDockerHost_$env"(),
                'customs-search-index-manager',
                "$action $indexName".trim())
    }

    def runSparkJob(env, sparkArtifactJson, indexName) {
        pipeline.runSparkJob(
                env,
                pipeline."getDockerHost_$env"(),
                sparkArtifactJson,
                '--master yarn',
                "--spring.profiles.active=$env --es.index.name=$indexName --es.index.type=declaration")

    }
}
