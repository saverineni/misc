package cds.infrastructure.shared

import groovy.json.JsonSlurperClassic

class ArtifactTag {
    private final pipeline
    private final awsEnvTag
    private final artifactoryUrl = 'https://artifactory.dataengineering.apps.hmrci/artifactory'
    private final mavenRepo = 'cdsdar-maven'

    ArtifactTag(pipeline, awsEnvTag) {
        this.pipeline = pipeline
        this.awsEnvTag = awsEnvTag
    }

    private static final jsonFormat = '''
    {
      "groupId":"maven-groupId",
      "artifactId":"maven-artifactId",
      "version":"1.0.0"
    }
    '''

    private static final jsonValidationMessage = "required JSON format: $jsonFormat"

    def validate(String json) {
        def params = new JsonSlurperClassic().parseText(json)

        assert params.groupId != null : jsonValidationMessage
        assert params.artifactId != null : jsonValidationMessage
        assert params.version != null : jsonValidationMessage
    }

    def deleteArtifact(String json, String artifactBasePath) {
        def params = new JsonSlurperClassic().parseText(json)
        def artifactId = params.artifactId

        String url = "${artifactoryUrl}/${mavenRepo}/${artifactBasePath}/${artifactId}/${awsEnvTag}/"

        pipeline.httpDeleteRequest(url)
    }

    def createArtifactTag(String json, String artifactBasePath) {
        def params = new JsonSlurperClassic().parseText(json)
        def artifactId = params.artifactId

        String createDirectoryPath = "${artifactoryUrl}/${mavenRepo}/${artifactBasePath}/${artifactId}/${awsEnvTag}/"
        String createDirectoryJsonBody = """
        {
            "uri": "${createDirectoryPath}",
            "repo": "${mavenRepo}",
            "path": "/${artifactBasePath}/${artifactId}/${awsEnvTag}/",
            "createdBy": "jenkins",
            "children" : [ ]
        }
        """

        pipeline.httpPutRequest(createDirectoryPath, createDirectoryJsonBody)
    }

    def copyArtifact(String json, String artifactBasePath) {
        def params = new JsonSlurperClassic().parseText(json)
        def artifactId = params.artifactId
        def artifactVersion = params.version
        def copyFromPath = "${artifactId}/${artifactVersion}/${artifactId}-${artifactVersion}.jar"
        def copyToPath = "${artifactId}/${awsEnvTag}/${artifactId}-latest.jar"

        String copyArtifactUrl = "${artifactoryUrl}/api/copy/${mavenRepo}/${artifactBasePath}/${copyFromPath}?to=/${mavenRepo}/${artifactBasePath}/${copyToPath}"

        pipeline.httpPostRequest(copyArtifactUrl, '{}')

    }

    def pingArtifactory() {
        String url = 'https://artifactory.dataengineering.apps.hmrci/artifactory/api/system/ping'
        def response = pipeline.httpGetRequest(url)

        assert response.status == 200
    }
}
