package cds.infrastructure.shared

import groovy.json.JsonSlurperClassic

class Ec2DockerDeploy {
    private static final jsonValidationMessage = "required JSON format: $jsonFormat"
    
    private final pipeline
    
    final params

    Ec2DockerDeploy(pipeline, json) {
        this.pipeline = pipeline

        println(json)

        params = new JsonSlurperClassic().parseText(json)
                    
        assert params.docker_image_name != null: jsonValidationMessage
        assert params.docker_image_version != null: jsonValidationMessage
        assert params.application_name != null: jsonValidationMessage
    }

    private static final jsonFormat = '''
    {
      "docker_image_name": "imagename",
      "docker_image_version": "version",
      "application_name": "appname"
    }
    '''

    def tagForEnv(environment) {
        def imageForEnv = "${params.docker_image_name}:${environment}"

        pipeline.sh "docker pull ${builtImage}"
        pipeline.sh "docker tag ${builtImage} ${imageForEnv}"
        pipeline.sh "docker push ${imageForEnv}"
    }

    def getContractImageName() {
        "${builtImage}_contract"
    }

    private getBuiltImage() {
        "${params.docker_image_name}:${params.docker_image_version}"
    }
}
