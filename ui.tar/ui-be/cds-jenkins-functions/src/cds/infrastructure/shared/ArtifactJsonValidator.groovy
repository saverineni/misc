package cds.infrastructure.shared

import groovy.json.JsonSlurperClassic

class ArtifactJsonValidator {
    private final pipeline

    private static final jsonFormat = '''
    {
      "groupId":"maven-groupId",
      "artifactId":"maven-artifactId",
      "version":"1.0.0"
    }
    '''

    private static final jsonValidationMessage = "required JSON format: $jsonFormat"

    def validate(String json) {
        def params = new JsonSlurperClassic().parseText(json)

        assert params.groupId != null : jsonValidationMessage
        assert params.artifactId != null : jsonValidationMessage
        assert params.version != null : jsonValidationMessage
    }
}
