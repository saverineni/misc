package contracttests

import groovy.json.JsonSlurper
import org.apache.http.client.fluent.Content
import org.apache.http.client.fluent.Request
import org.apache.http.client.fluent.Response
import org.apache.http.entity.ContentType
import spock.lang.Specification
import spock.util.mop.ConfineMetaClassChanges

@ConfineMetaClassChanges([Request])
class ServiceSchemaLoaderSpec extends Specification {
    static URL = 'http://test_url'

    ServiceSchemaLoader loader = new ServiceSchemaLoader()
    Request request = Mock()
    Response response = Mock()

    def setup() {
        GroovyMock(Request, global: true)
        Request.Get(URL) >> request
        request.execute() >> response
    }

    def "Should add additionalProperties field with value false to each of the definition"() {
        given:
        def expectedSchema = loadResource("/expectedSchema.json")
        response.returnContent() >> new Content(loadResource("/schema.json").bytes, ContentType.APPLICATION_JSON)

        when:
        String actualSchema = loader.loadSchema(URL)

        then:
        jsonAsMap(actualSchema) == jsonAsMap(expectedSchema)

    }

    def "Shouldn't add additionalProperties field to the definition if it already exists"() {
        given:
        def expectedSchema = loadResource("/schemaWithAdditionalProperties.json")
        response.returnContent() >> new Content(expectedSchema.bytes, ContentType.APPLICATION_JSON)

        when:
        String actualSchema = loader.loadSchema(URL)

        then:
        jsonAsMap(actualSchema) == jsonAsMap(expectedSchema)

    }

    private jsonAsMap(String actualSchema) {
        new JsonSlurper().parseText(actualSchema)
    }

    private loadResource(name) {
        this.getClass().getResource(name).text
    }

}
