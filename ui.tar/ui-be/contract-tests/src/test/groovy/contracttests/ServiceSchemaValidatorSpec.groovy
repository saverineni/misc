package contracttests

import spock.lang.Specification

class ServiceSchemaValidatorSpec extends Specification {

    ServiceSchemaValidator validator = new ServiceSchemaValidator(loadResource('/validationSchema.json'))

    def 'Should validate json against the schema'() {
        expect:
        validator.isValid(loadResource('/validJson.json'))
    }

    def 'should not validate json with extra properties'() {
        expect:
            false == validator.isValid(loadResource('/extraProperties.json'))
    }

    def 'should validate json against definition reference'() {
        expect:
        validator.isValidForDefinition('first', loadResource('/definitionFirst.json'))
    }

    private loadResource(name) {
        this.getClass().getResource(name).text
    }

}
