package contracttests

import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import org.apache.http.client.fluent.Request

class ServiceSchemaLoader {

    def loadSchema(String url){
        String response = Request.Get(url).execute().returnContent().asString()
        def schema = new JsonSlurper().parseText(response)
        schema.definitions.each{key,value ->
            if(!value.additionalProperties) {
                value.additionalProperties = false
            }
        }
        JsonOutput.toJson(schema)
    }

}
