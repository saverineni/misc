package contracttests

import com.fasterxml.jackson.databind.ObjectMapper
import com.github.fge.jsonschema.core.report.ProcessingReport
import com.github.fge.jsonschema.main.JsonSchemaFactory

import groovy.transform.Immutable

@Immutable
class ServiceSchemaValidator {
    String jsonSchema

    def isValid(String json) {
        def jsonNode = new ObjectMapper().readTree(json)
        def jsonSchemaNode = new ObjectMapper().readTree(jsonSchema)

        def schema = JsonSchemaFactory.byDefault().getJsonSchema(jsonSchemaNode)

        schema.validate(jsonNode).success
    }

    def isValidForDefinition(String definition, String json) {
        def jsonNode = new ObjectMapper().readTree(json)
        def jsonSchemaNode = new ObjectMapper().readTree(jsonSchema)

        def schema = JsonSchemaFactory.byDefault().getJsonSchema(jsonSchemaNode, "/definitions/$definition")

        schema.validate(jsonNode).success
    }
}
