#!/bin/bash

################################################################################
## Name: mssCutOverDataIngest.sh
## Description: creates mss database with 100K imports and 20K exports .
## Usage:  ./mssCutOverDataIngest.sh 100K
################################################################################

set -o pipefail  # trace ERR through pipes
set -o errtrace  # trace ERR through 'time command' and other functions
set -o nounset   ## set -u : exit the script if you try to use an uninitialised variable
set -o errexit   ## set -e : exit the script if any statement returns a non-true return value

err_report() {
    EXIT_CODE=$?
    echo "Error $EXIT_CODE on line $1"
    exit $EXIT_CODE
}

trap 'err_report $LINENO' ERR

# properties
DATA_EXTRACT_PATH=/tmp/mssIngest
DATA_ARTIFACT=mss-cutover-synthetic-1.0.0-100k.tar.gz
ARTIFACT_URL=https://artifactory.dataengineering.apps.hmrci/artifactory/cdsdar-maven/uk/gov/gsi/hmrc/cds/search/mss-cutover-synthetic/1.0.0/$DATA_ARTIFACT

echo "*******************************************************************"
echo "** mss cutover data ingest script:"
echo "** DATA_EXTRACT_PATH=$DATA_EXTRACT_PATH"
echo "** DATA_ARTIFACT=$DATA_ARTIFACT"
echo "** ARTIFACT_URL=$ARTIFACT_URL"
echo "*******************************************************************"

#remove data artifact
echo "Deleting mss data artifact and mss data extract folder"
sudo rm -rf $DATA_EXTRACT_PATH/$DATA_ARTIFACT
sudo rm -rf $DATA_EXTRACT_PATH/mss

sudo mkdir -p $DATA_EXTRACT_PATH

# download data artifact 100K
echo "downloding data artifact..."
sudo wget $ARTIFACT_URL -P $DATA_EXTRACT_PATH

echo "Extract data artifact $DATA_EXTRACT_PATH/$DATA_ARTIFACT"
sudo tar -xvf $DATA_EXTRACT_PATH/$DATA_ARTIFACT -C $DATA_EXTRACT_PATH

echo "Ingest MSS Data into Hive database 'base_search_mssdata'"
sudo /bin/bash $DATA_EXTRACT_PATH/mss/data-setup.sh 100K
