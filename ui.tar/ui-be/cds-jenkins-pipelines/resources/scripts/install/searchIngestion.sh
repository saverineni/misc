#!/bin/bash

################################################################################
## Name: searchIngest.sh
## Description: Triggers search ingestion pipeline.
## Usage:  ./searchIngestion.sh <index-name> <action> <aws_env>
## eg) ./searchIngestion.sh index-name create-index ci
## eg) ./searchIngestion.sh index-name spark-job ci
## eg) ./searchIngestion.sh index-name switch-alias ci
## eg) ./searchIngestion.sh index-name remove-indices ci
################################################################################

set -o pipefail  # trace ERR through pipes
set -o errtrace  # trace ERR through 'time command' and other functions
set -o nounset   ## set -u : exit the script if you try to use an uninitialised variable
set -o errexit   ## set -e : exit the script if any statement returns a non-true return value

err_report() {
    EXIT_CODE=$?
    echo "Error $EXIT_CODE"
    exit $EXIT_CODE
}

trap 'err_report $LINENO' ERR

# properties
# NOW=`date '+%Y%m%d-%H%M%S'`
# INDEX_NAME="customs-$NOW"

INDEX_NAME=$1
ACTION=$2
AWS_ENV=$3
ES_HOST="searches-$AWS_ENV-cdap.nonprod.eu-west-2.aws.dat.corp.hmrc.gov.uk"
INDEX_MANAGER_ARTIFACT_BASE_PATH=/opt/search_index_manager
INDEX_MANAGER_ARTIFACT_NAME=customs-search-index-manager-latest.jar
DATA_INGEST_ARTIFACT_BASE_PATH=/opt/search_ingest
DATA_INGEST_ARTIFACT_NAME=customs-search-data-ingest-latest.jar
HIVE_DATABASE_NAME="base_search_mssdata"

# dms database for ci - doesn't exist in other environments
CDS_DATABASE_NAME="search_teams_exploitation_dms"

echo "*******************************************************************"
echo "** search ingest pipeline script:"
echo "** INDEX_NAME=$INDEX_NAME"
echo "** AWS_ENV=$AWS_ENV"
echo "** ES_HOST=$ES_HOST"
echo "** INDEX_MANAGER_ARTIFACT_BASE_PATH=$INDEX_MANAGER_ARTIFACT_BASE_PATH"
echo "** INDEX_MANAGER_ARTIFACT_NAME=$INDEX_MANAGER_ARTIFACT_NAME"
echo "** DATA_INGEST_ARTIFACT_BASE_PATH=$DATA_INGEST_ARTIFACT_BASE_PATH"
echo "** DATA_INGEST_ARTIFACT_NAME=$DATA_INGEST_ARTIFACT_NAME"
echo "** HIVE_DATABASE_NAME=$HIVE_DATABASE_NAME"
echo "*******************************************************************"
echo ""

case "$ACTION" in
  create-index)
    echo "creating index $INDEX_NAME"
    java -jar -Delasticsearch.host=$ES_HOST $INDEX_MANAGER_ARTIFACT_BASE_PATH/$INDEX_MANAGER_ARTIFACT_NAME create-index $INDEX_NAME
    break
    ;;

  chief-ingest)
    echo "ingesting data from hive db $HIVE_DATABASE_NAME in to ES instance $ES_HOST"
    spark2-submit --master yarn $DATA_INGEST_ARTIFACT_BASE_PATH/$DATA_INGEST_ARTIFACT_NAME --es.index.name=$INDEX_NAME --es.index.type=declaration --es.nodes=$ES_HOST --hdfs.namenode=hanameservice --hive.database.name=$HIVE_DATABASE_NAME
    break
    ;;

  cds-ingest)
    echo "ingesting data from hive db $CDS_DATABASE_NAME in to ES instance $ES_HOST"
    spark2-submit --master yarn $DATA_INGEST_ARTIFACT_BASE_PATH/$DATA_INGEST_ARTIFACT_NAME --es.index.name=$INDEX_NAME --es.index.type=declaration --es.nodes=$ES_HOST --hdfs.namenode=hanameservice --hive.database.name=$CDS_DATABASE_NAME --spring.profiles.active=cds
    break
    ;;

  switch-alias)
    echo "switch index alias"
    java -jar -Delasticsearch.host=$ES_HOST $INDEX_MANAGER_ARTIFACT_BASE_PATH/$INDEX_MANAGER_ARTIFACT_NAME switch-alias $INDEX_NAME
    break
    ;;

  remove-indices)
    echo "delete old indexes"
    java -jar -Delasticsearch.host=$ES_HOST $INDEX_MANAGER_ARTIFACT_BASE_PATH/$INDEX_MANAGER_ARTIFACT_NAME remove-indices
    break
    ;;

  *)
    echo "invalid $ACTION"
    break
    ;;
esac
