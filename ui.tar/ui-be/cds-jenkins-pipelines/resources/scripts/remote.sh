#!/bin/bash

run_remote() {

    USER_HOST=$1
    SCRIPT=$2
    shift 2
    ARGS=$@

    echo "************************************************"
    echo "** Running Remote:"
    echo "** USER_HOST: $USER_HOST"
    echo "** SCRIPT: $SCRIPT"
    echo "** ARGS: $ARGS"
    echo "************************************************"

    ssh -t -o StrictHostKeyChecking=no $USER_HOST "bash -s --" << EOF
        set -- $ARGS
        $(cat "$SCRIPT")
        exit $?
EOF
EXIT_CODE=$?

echo "**********************************************************"
echo "** Remote execution completed with EXIT_CODE=$EXIT_CODE"
echo "**********************************************************"

return $EXIT_CODE
}

set -o pipefail
run_remote "$@" 2>&1 | tee -a remote.out
