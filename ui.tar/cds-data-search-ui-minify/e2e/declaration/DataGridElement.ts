import { ElementFinder, by, element } from 'protractor';

export class DataGridElement {
    constructor(private dataGridElement: ElementFinder) { }

    fieldTextOf(fieldName: string) {
        return this.dataGridElement.element(by.css(`.data-grid__value[data-grid-field="${fieldName}"]`)).getText();
    }

    line(index: number) {
        return this.lines().then(lines => new DeclarationLineElement(lines[index]));
    }

    lineCount() {
        return this.lines().then(lines => lines.length);
    }

    private lines() {
        return this.dataGridElement.all(by.css('.declaration-lines__row'));
    }
}

export class DeclarationLineElement {
    constructor(private lineElement: ElementFinder) { }

    fieldTextOf(fieldName: string) {
        return this.lineElement.element(by.css(`.declaration-lines__${fieldName}`)).getText();
    }
}
