/// <reference path="../declarationMatchers.d.ts"/>

import { DeclarationDetailPage } from './declarationdetail.po';
import { DeclarationDetailScenario } from './declarationdetail-scenario';
import { declarationMatchers } from '../declarationMatchers';
import { AppPage } from '../../app.po';
import { SignInScenario } from '../../sign-in/sign-in-scenario';
import { Wiremock } from '../../wiremock';
import { DeclarationSearchPage } from '../search/declarationsearch.po';
import { NotFoundPage } from '../../not-found.po';

describe('Declaration detail', () => {
  let detailPage: DeclarationDetailPage = new DeclarationDetailPage();

  beforeAll((done) => {
    new SignInScenario().givenUserIsSignedIn().then(done, done.fail);
  });

  describe('declaration with lines', () => {

    let declarationDetail;

    beforeAll((done) => {
      declarationDetail = DeclarationDetailScenario.defaultDetailResponse();
      jasmine.addMatchers(declarationMatchers);
      Wiremock.reset()
        .then(() => DeclarationDetailScenario.stubDeclaration(DeclarationDetailScenario.TEST_ID))
        .then(() => detailPage.navigateTo(DeclarationDetailScenario.TEST_ID))
        .then(done, done.fail);
    });

    it('should be the current page', () => {
      expect(detailPage.isCurrentPage()).toBeTruthy();
    });

    it('updates the title in the browser', () => {
      expect(new AppPage().getCurrentTitle()).toEqual(`CDS - Declaration Detail`);
  });

    it('updates the url in the browser', () =>
      expect(new AppPage().getCurrentUrl()).toMatch(`\/declarations\/${DeclarationDetailScenario.TEST_ID}$`)
    );

    it('displays the declaration if found', () => {
      expect(detailPage.getDataGridElement()).isDeclarationHeaderWithData(declarationDetail);
    });

    it('displays the declaration item count in the item details button', () => {
      expect(detailPage.getItemDetailButtonText()).toEqual('ITEM DETAIL (4)');
    });

    it('has an enabled item details button', () => {
      expect(detailPage.isItemDetailButtonEnabled()).toBe(true);
    });

    it('navigates back to search when back button is clicked', (done) => {
      detailPage.clickBackToSearchResults()
        .then(() => expect(new DeclarationSearchPage().isCurrentPage()).toBe(true))
        .then(done, done.fail);
    });

  });

  describe('declaration without lines', () => {

    beforeAll((done) => {
      Wiremock.reset()
      .then(() => DeclarationDetailScenario.stubDeclarationWithoutLines())
      .then(() => detailPage.navigateTo(DeclarationDetailScenario.WITHOUT_LINES_ID))
      .then(done, done.fail);
    });

    it('displays the declaration item count in the item details button', () => {
      expect(detailPage.getItemDetailButtonText()).toEqual('ITEM DETAIL (0)');
    });

    it('has a disabled item details button', () => {
      expect(detailPage.isItemDetailButtonEnabled()).toBe(false);
    });

  });

  describe('declaration not found', () => {
    const notFoundPage = new NotFoundPage();
    let declarationUrl;

    beforeAll((done) => {
      declarationUrl = DeclarationDetailScenario.declarationUrl('dec-id');

      Wiremock.reset()
      .then(() => Wiremock.givenNotFound(declarationUrl))
      .then(() => detailPage.navigateTo('dec-id'))
      .then(done, done.fail);
    });

    it('should display the not found page', () => {
      expect(notFoundPage.isDisplayed()).toBeTruthy();
    });

    it('should not change the declaration page url', () => {
      expect(notFoundPage.getCurrentUrl()).toMatch(`${declarationUrl}$`);
    });
  });
});
