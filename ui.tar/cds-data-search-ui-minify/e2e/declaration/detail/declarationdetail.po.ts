import { browser, by, element } from 'protractor';
import { DataGridElement } from '../DataGridElement';

export class DeclarationDetailPage {

  navigateTo(id) {
    return browser.get(`/declarations/${id}`).then(() => browser.waitForAngular());
  }

  isCurrentPage() {
    return element(by.css('.declaration-detail')).isPresent();
  }

  getDeclarationId() {
    return element(by.css('.declaration-detail__declarations')).getAttribute('data-declaration-id');
  }

  clickBackToSearchResults() {
    return element(by.css('.declaration-detail__back-to-search-button')).click();
  }

  getItemDetailButtonText() {
    return element(by.css('.declaration-detail__item-details-button')).getText();
  }

  isItemDetailButtonEnabled() {
    return element(by.css('.declaration-detail__item-details-button')).isEnabled();
  }

  getDataGridElement(): DataGridElement {
    return new DataGridElement(element(by.css('.declaration-detail__declarations')));
  }

}
