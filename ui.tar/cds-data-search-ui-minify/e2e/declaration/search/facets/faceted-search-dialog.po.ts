import {browser, by, element, protractor} from "protractor";

export class FacetedSearchDialog {
  isDisplayed() {
    return element.all(by.css('.faceted-search')).then(dialogs => dialogs.length > 0);
  }

  getDialogTitle() {
    return element(by.css('.faceted-search__title')).getText()
  }

  searchFacet(id: string) {
    return this.clearFilter().then(() => this.filterElement().sendKeys(id));
  }

  clearFilter() {
    return this.filterElement().clear();
  }

  private filterElement() {
    return element(by.css('.faceted-search__filter'));
  }

  facetList() {
    return element.all(by.css('.faceted-search__link')).filter(elem => elem.getText().then(it => it != '')).getText();
  }

  noResultsFoundMessage() {
    return element(by.css('.faceted-search__no-results-found')).getText();
  }

  getFacetCountColor() {
    return element.all(by.css('.faceted-search__link__facet-count')).get(0).getCssValue('color').then(value => value)
  }

  selectFacet(id) {
    return this.getLink(id)
               .click()
               .then(() => browser.waitForAngular());
  }

  removeSelection(id) {
    let removeButton = this.getSelectedFacet(id);

    return browser.wait(protractor.ExpectedConditions.visibilityOf(removeButton), 5000)
      .then(() => removeButton.click())
      .then(() => browser.waitForAngular());
  }

  isSelectionDisplayedInList(id) {
    return this.getSelection(id).isPresent();
  }

  getSelectedFacet(id) {
    return element(by.css(
      `.faceted-search__selection[data-facet-id="${id}"] .faceted-search__selection-remove`
    ));
  }

  isFacetSelected(id) {
    return element(by.css(`.faceted-search__link--selected[data-facet-id="${id}"]`)).isPresent();
  }

  isSearchFilterFieldFocused() {
    return browser.driver.switchTo().activeElement().getAttribute('class').then((fieldname) => fieldname.startsWith('faceted-search__filter'))    
  }

  clickCancel() {
    // add sleep due to animated closure of dialog
    return this.getCancelButton().click()
    .then(() => browser.driver.sleep(500));
  }

  getCancelButton() {
    return element(by.css('.faceted-search__cancel'));
  }

  clickApplyFilters() {
    // add sleep due to animated closure of dialog
    return element(by.css('.faceted-search__apply-filters')).click()
      .then(() =>  browser.driver.sleep(500));
  }

  getLink(id) {
    return element(by.css(`.faceted-search__link[data-facet-id="${id}"]`));
  }

  private getSelection(id) {
    return element(by.css(`.faceted-search__selection[data-facet-id="${id}"]`));
  }
  
}

