import { browser, by, element } from 'protractor';
import { DataGridElement } from '../DataGridElement';

export class DeclarationSearchPage {
  navigateTo(queryString = '') {
    return browser.get(`/${queryString}`)
      .then(() => browser.waitForAngular());
  }

  refresh() {
    return browser.refresh();
  }

  urlQueryString() {
    return browser.waitForAngular()
      .then(() => browser.getCurrentUrl())
      .then(url => url.replace(/^http:\/\/\w+:\d+\/\?(.+)$/, '$1'));
  }

  isCurrentPage() {
    return element(by.css('.search-section')).isPresent();
  }

  isResultCountSectionDisplayed() {
    return element(by.css('.search-section__results-count-section')).isPresent();
  }

  resultCount() {
    const resultCountElement = element(by.css('.search-section__results-count'));
    return resultCountElement && resultCountElement.getText();
  }

  search(searchTerm: string) {
    return this.typeIntoSearchTermField(searchTerm)
      .then(() => this.clickSearchButton());
  }

  typeIntoSearchTermField(searchTerm: string) {
    return this.getDeclarationField().sendKeys(searchTerm);
  }

  getDeclarationSearchFieldText() {
    return this.getDeclarationField().getAttribute('value');
  }

  isDeclarationSearchFieldFocused() {
    return browser.driver.switchTo().activeElement().getAttribute('name')
      .then((fieldname) => fieldname === 'searchTerm');
  }

  private getDeclarationField() {
    return element(by.css('.search-form__searchterm-input'));
  }

  clickSearchButton() {
    return element(by.css(".search-form__button")).click();
  }

  isNoResultsFound() {
    return element(by.css('.search-section__no-search-results')).isPresent();
  }

  getNoResultsFoundMessage() {
    return element(by.css('.search-section__no-search-results')).getText();
  }

  isResultsDisplayed() {
    return element(by.css('.search-section__results')).isPresent();
  }

  isFiltersSectionDisplayed() {
    return element(by.css('.search-section__filters')).isPresent();
  }

  isPaginatorHeaderDisplayed() {
    return element(by.css('.search-section__paginator-header')).isPresent();
  }

  isPaginatorFooterDisplayed() {
    return element(by.css('.search-section__paginator-footer')).isPresent();
  }

  paginatorPreviousElement() {
    return element(by.css('.search-section__paginator-header .mat-paginator-navigation-previous'))
  }

  paginatorNextElement() {
    return element(by.css('.search-section__paginator-header .mat-paginator-navigation-next'))
  }

  paginatorRangeLabelText() {
    return element(by.css('.search-section__paginator-header .mat-paginator-range-label')).getText();
  }

  paginatorItemPageLabelText() {
    return element(by.css('.search-section__paginator-header .mat-select')).getAttribute('aria-label');
  }

  linksFacetFilterEnabled(dataLinkId) {
    return this.linksFacetFilter(dataLinkId).isDisplayed();
  }

  private linksFacetFilter(dataLinkId) {
    return element(by.css(`.links[data-links-id="${dataLinkId}"]`));
  }

  getDeclarationResultsCount() {
    return element.all(by.css('.search-results-cards__declarations')).count();
  }

  getDataGridElement(row: number): DataGridElement {
    return new DataGridElement(element.all(by.css('.search-results-cards__declarations')).get(row));
  }

  clickDeclarationDetail(row: number) {
    return element.all(by.css('.search-results-cards__declaration-details-button')).get(row).click();
  }

  whenISearchFor(searchTerm: string) {
    return this.search(searchTerm);
  }

}
