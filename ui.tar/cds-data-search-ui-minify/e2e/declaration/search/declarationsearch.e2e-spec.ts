/// <reference path="../declarationMatchers.d.ts"/>

import {DeclarationSearchPage} from './declarationsearch.po';
import {DeclarationDetailPage} from '../detail/declarationdetail.po';
import {declarationMatchers} from '../declarationMatchers';
import {DeclarationSearchScenario} from './declaration-search-scenario';
import {AppPage} from '../../app.po';
import {NavigationBar} from '../../navigation-bar.po';
import {SignInScenario} from '../../sign-in/sign-in-scenario';
import {Wiremock} from '../../wiremock';
import {DeclarationDetailScenario} from '../detail/declarationdetail-scenario';

describe('Declaration search', () => {
  let searchPage: DeclarationSearchPage = new DeclarationSearchPage();

  beforeAll((done) => {
    new SignInScenario().givenUserIsSignedIn()
      .then(done, done.fail);
  });

  beforeAll((done) => {
    Wiremock.reset()
      .then(() => DeclarationSearchScenario.stubPerformSearch())
      .then(() => searchPage.navigateTo())
      .then(done, done.fail);
  });

  it('should be the current page', () => {
    expect(searchPage.isCurrentPage()).toBe(true);
  });

  it('updates the title in the browser', () => {
    expect(new AppPage().getCurrentTitle()).toEqual(`CDS - Search Results`);
  });

  it('should not display result count', () => {
    expect(searchPage.isResultCountSectionDisplayed()).toBe(false);
  });

  it('should not display paginator', () => {
    expect(searchPage.isPaginatorHeaderDisplayed()).toBe(false);
    expect(searchPage.isPaginatorFooterDisplayed()).toBe(false);
  });

  [
    'originCountryCode',
    'dispatchCountryCode',
    'destinationCountryCode',
    'transportModeCode',
    'goodsLocation',
    'commodityCode'
  ].forEach(facetType => {
    it(`the page should display the enabled ${facetType} filter`, () => {
      expect(searchPage.linksFacetFilterEnabled(facetType)).toBe(true);
    });
  });

  it('should focus the search field', (done) => {
    expect(searchPage.isDeclarationSearchFieldFocused()).toBe(true)
      .then(done, done.fail);
  });

  describe('perform search', () => {
    describe('with not found search term', () => {

      beforeAll((done) => {
        searchPage.whenISearchFor('made-up')
          .then(done, done.fail);
      });

      it('should display the filters section', () => {
        expect(searchPage.isFiltersSectionDisplayed()).toBe(true);
      });

      it('should display the result count', () => {
        expect(searchPage.resultCount()).toEqual('0');
      });

      it('should display no results found message', (done) => {
        expect(searchPage.isNoResultsFound()).toEqual(true)
          .then(() => expect(searchPage.getNoResultsFoundMessage()).toEqual('No results found for search criteria.'))
          .then(done, done.fail);
      });

      [
        'originCountryCode',
        'dispatchCountryCode',
        'destinationCountryCode',
        'transportModeCode',
        'goodsLocation'
      ].forEach(facetType => {
        it(`filters section is display the enabled ${facetType} filter`, () => {
          expect(searchPage.linksFacetFilterEnabled(facetType)).toBe(true);
        });
      });

      it(`filters section is display the commodity code filter`, () => {
        expect(searchPage.linksFacetFilterEnabled('commodityCode')).toBe(true);
      });

      it('updates the url in the browser', (done) => {
        expect(new AppPage().getCurrentUrl()).toMatch(/\/\?searchTerm=made-up$/)
          .then(done, done.fail);
      });

      describe('and click the home link', () => {
        beforeAll((done) => {
          new NavigationBar().clickHome()
            .then(done, done.fail);
        });

        it('clears the results', (done) => {
          expect(searchPage.isResultsDisplayed()).toEqual(false)
            .then(() => expect(searchPage.isNoResultsFound()).toEqual(false))
            .then(done, done.fail);
        });

        it('clears the declaration search field', (done) => {
          expect(searchPage.getDeclarationSearchFieldText()).toEqual('')
            .then(done, done.fail);
        });

        it('should focus the search field', (done) => {
          expect(searchPage.isDeclarationSearchFieldFocused()).toBe(true)
            .then(done, done.fail);
        });
      });
    });

    describe('with empty search term', () => {
      it('displays declarations with no search term', (done) => {
        DeclarationSearchScenario.stubAuthenticatedSearchForTerm('')
          .then(() => searchPage.clickSearchButton())
          .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
          .then(done, done.fail);
      });

      it('displays declarations when browser is refreshed ', (done) => {
        DeclarationSearchScenario.stubAuthenticatedSearchForTerm('')
          .then(() => searchPage.refresh())
          .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
          .then(done, done.fail);
      });
    });

    describe('declaration', () => {

      let declarationSearchResult;
      const DECLARATION_ID = '670-954107X-2017-08-22';
      const DECLARATION_WITH_LINES_INDEX = 0;

      beforeAll((done) => {
        declarationSearchResult = DeclarationSearchScenario.defaultSearchResponse();
        DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found')
          .then(() => searchPage.whenISearchFor('found'))
          .then(done, done.fail);

        jasmine.addMatchers(declarationMatchers)
      });

      it('updates the url in the browser', (done) => {
        expect(new AppPage().getCurrentUrl()).toMatch(/\/\?searchTerm=found$/)
          .then(done, done.fail);
      });

      it('should display the result count', () => {
        expect(searchPage.resultCount()).toEqual('2');
      });

      it('displays first declaration if found', () => {
        expect(searchPage.isResultsDisplayed()).toEqual(true);
        expect(searchPage.getDataGridElement(DECLARATION_WITH_LINES_INDEX))
          .isDeclarationPreviewWithData(declarationSearchResult.declarations.find(declaration => declaration.declarationId == DECLARATION_ID));
      });

      it('filters section is displayed', () => {
        expect(searchPage.isFiltersSectionDisplayed()).toBe(true);
      });

      it('routes you to the declaration detail page when the button is clicked', (done) => {
        let detailPage = new DeclarationDetailPage();
        DeclarationDetailScenario.stubDeclaration(DECLARATION_ID)
          .then(() => searchPage.clickDeclarationDetail(DECLARATION_WITH_LINES_INDEX))
          .then(() => expect(detailPage.isCurrentPage()).toBe(true))
          .then(() => expect(detailPage.getDeclarationId()).toEqual(DECLARATION_ID))
          .then(() => searchPage.navigateTo())
          .then(done, done.fail);
      });

    });

    describe('when backend is offline', () => {
      beforeAll((done) => {
        Wiremock.reset()
          .then(() => DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found'))
          .then(() => Wiremock.givenSearchServiceIsOffline())
          .then(() => searchPage.whenISearchFor('found'))
          .then(done, done.fail);
      });

      it('displays global error message', () => {
        expect(new AppPage().getOperationError()).toEqual('Server error. Please contact support if this problem persists.\nOK');
      });

      it('does not display search results', () => {
        expect(searchPage.isNoResultsFound()).toEqual(false);
      });

      describe('then back online', () => {
        beforeAll((done) => {
          Wiremock.reset().then(done, done.fail);
        });

        it('retries the search on clicking the search button a second time', (done) => {
          searchPage.clickSearchButton()
            .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
            .then(done, done.fail);
        });
      });
    });
  });

  describe('bookmark search', () => {
    const bookmarkSpecialChars = ';/:@&?=<>#%{}|\^~[]` шеллы';
    const url = '?searchTerm=' + encodeURIComponent(bookmarkSpecialChars);

    beforeAll((done) => {
      DeclarationSearchScenario.stubAuthenticatedSearchForTerm(bookmarkSpecialChars)
        .then(() => searchPage.navigateTo(url))
        .then(done, done.fail)
    });

    it('populates the declaration search field', () => {
      expect(searchPage.getDeclarationSearchFieldText()).toEqual(bookmarkSpecialChars);
    });

    it('display results', () => {
      expect(searchPage.isResultsDisplayed()).toEqual(true);
    });
  });
});

