/// <reference path="../declarationMatchers.d.ts"/>

import { declarationMatchers } from '../declarationMatchers';
import { AppPage } from '../../app.po';
import { SignInScenario } from '../../sign-in/sign-in-scenario';
import { Wiremock } from '../../wiremock';
import { DeclarationSearchPage } from '../search/declarationsearch.po';
import { DeclarationItemDetailPage } from './declarationitemdetail.po';
import { DeclarationItemDetailScenario } from './declarationitemdetail-scenario';
import { DeclarationDetailScenario } from '../detail/declarationdetail-scenario';
import { NotFoundPage } from '../../not-found.po';
import { browser } from 'protractor';

describe('Declaration Item Detail', () => {
  let detailPage: DeclarationItemDetailPage = new DeclarationItemDetailPage();

  beforeAll((done) => {
    new SignInScenario().givenUserIsSignedIn().then(done, done.fail);
  });

  describe('declaration item that exists', () => {

    let declarationItemDetail;
    let itemNumber = 2;

    beforeAll((done) => {
        declarationItemDetail = DeclarationItemDetailScenario.defaultDeclarationItemDetailResponse(itemNumber);
        jasmine.addMatchers(declarationMatchers);
        Wiremock.reset()
            .then(() => DeclarationDetailScenario.stubDeclaration(DeclarationDetailScenario.TEST_ID))
            .then(() => detailPage.navigateTo(DeclarationDetailScenario.TEST_ID, itemNumber))
            .then(() => browser.driver.sleep(500))
            .then(done, done.fail);
    });

    it('should be the current page', () => {
        expect(detailPage.isCurrentPage()).toBeTruthy();
    });

    it('updates the title in the browser', () => {
        expect(new AppPage().getCurrentTitle()).toEqual(`CDS - Item Detail`);
    });

    it('updates the url in the browser', () => {
        expect(new AppPage().getCurrentUrl()).toMatch(`\/declarations\/${DeclarationDetailScenario.TEST_ID}\/items\/${itemNumber}$`)
    });

    it('uses the correct declaration id', () => {
        expect(detailPage.getDeclarationId()).toEqual(DeclarationDetailScenario.TEST_ID);
    });

    it('displays the correct item tab', () => {
        expect(detailPage.getSelectedItemNumber()).toEqual(itemNumber.toString());
    });

    it('displays the correct item tab background color', () => {
        expect(detailPage.getCurrentActiveItemTab().getCssValue('background-color')).toBe('rgba(111, 182, 168, 0.3)');
    });

    it('displays the correct declaration item values', () => {
        expect(detailPage.getDataGridElement()).isDeclarationItemWithData(declarationItemDetail);
    });

    it('displays the correct item count', () => {
        expect(detailPage.getItemResultsCount()).toEqual('4');
    });

    it('should focus on the search item filter field', () => {
        expect(detailPage.isItemFilterFieldFocused()).toBeTruthy();
    });

    describe('item switch widget', () => {

        it('should display all of the item numbers', () => {
            expect(detailPage.getItemTabNumbers()).toEqual(['1','2','3','4']);
        });

        it('should select another item when clicked', (done) => {
            detailPage.clickItemTab(4)
                .then(() => expect(detailPage.getSelectedItemNumber()).toEqual('4'))
                .then(done, done.fail);
        });
    });

    describe('filter items', () => {
        it('should select another item when item number entered', (done) => {
            detailPage.filterBy('3')
                .then(() => expect(detailPage.getSelectedItemNumber()).toEqual('3'))
                .then(done, done.fail);
        });

        it('should display no results message when item does not exist', (done) => {
            detailPage.filterBy('99')
                .then(() => expect(detailPage.hasNoResults()).toBe(true))
                .then(done, done.fail);
        });

        // unable to get it to work!!!!
        xit('should display all tabs when invalid search removed', (done) => {
            detailPage.filterBy('')
                .then(() => expect(detailPage.getItemTabNumbers()).toEqual(['1','2','3','4']))
                .then(done, done.fail);
        });
    });

    it('navigates back to search when back button is clicked', (done) => {
        detailPage.clickBackToSearchResults()
          .then(() => expect(new DeclarationSearchPage().isCurrentPage()).toBe(true))
          .then(done, done.fail);
    });
  });

  describe('non-existent declaration item', () => {
    const notFoundPage = new NotFoundPage();
    let itemNumber = 5;

    beforeAll((done) => {
        Wiremock.reset()
            .then(() => DeclarationDetailScenario.stubDeclarationWithoutLines())
            .then(() => detailPage.navigateTo(DeclarationDetailScenario.WITHOUT_LINES_ID, itemNumber))
            .then(done, done.fail);
    });

    it('should display the not found page', () => {
      expect(notFoundPage.isDisplayed()).toBeTruthy();
    });

    it('should not change the declaration item page url', () => {
      expect(notFoundPage.getCurrentUrl()).toMatch(`\/declarations\/${DeclarationDetailScenario.WITHOUT_LINES_ID}\/items\/${itemNumber}$`);
    });
  });

  describe('declaration not found', () => {
    const notFoundPage = new NotFoundPage();
    let declarationUrl;

    beforeAll((done) => {
      declarationUrl = DeclarationDetailScenario.declarationUrl('dec-id');

      Wiremock.reset()
        .then(() => Wiremock.givenNotFound(declarationUrl))
        .then(() => detailPage.navigateTo('dec-id', 1))
        .then(done, done.fail);
    });

    it('should display the not found page', () => {
      expect(notFoundPage.isDisplayed()).toBeTruthy();
    });

    it('should not change the declaration item page url', () => {
      expect(notFoundPage.getCurrentUrl()).toMatch(`${declarationUrl}/items/1$`);
    });
  });
});
