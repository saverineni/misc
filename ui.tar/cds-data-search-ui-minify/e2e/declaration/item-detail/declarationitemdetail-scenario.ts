import { SignInPage } from '../../sign-in/sign-in.po';
import { Wiremock } from '../../wiremock';
import { HttpParams } from '@angular/common/http';
const fs = require('fs');

export class DeclarationItemDetailScenario {
  private static DECLARATION_FILE_NAME = 'declaration-with-lines.json';

  static defaultDeclarationItemDetailResponse(itemNumber: number) {
    return JSON.parse(fs.readFileSync(`e2e/wiremock/__files/${this.DECLARATION_FILE_NAME}`)).lines
        .find(line => line.itemNumber === itemNumber);
  }
}