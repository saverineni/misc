describe('info endpoint', () => {
  const fetch = require('node-fetch');
  let response;

  beforeAll((done) => {
    fetch('http://localhost:56101/manage/info', {
      method: 'GET'
    })
    .then(res => res.text())
    .then(body => response = JSON.parse(body))
    .then(done, done.fail)
  });

  it('should give the build version', () =>
    expect(response.build.version).not.toBeNull()
  );

  it('should give the build artifact', () =>
    expect(response.build.artifact).not.toBeNull()
  );
});