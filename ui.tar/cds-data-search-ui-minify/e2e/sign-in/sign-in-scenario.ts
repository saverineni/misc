import { browser, by, element, ExpectedConditions } from 'protractor';
import { DeclarationSearchPage } from '../declaration/search/declarationsearch.po';
import { SignInPage } from './sign-in.po';
import { UserDetails } from '../user-details.po';

export class SignInScenario {

  givenUserIsSignedIn() {
    const searchPage = new DeclarationSearchPage();
    const signInPage = new SignInPage();

    // try to navigate to the search page to check sign-in state
    // if redirects to the sign-in page then sign-in required
    // else already signed in
    return searchPage.navigateTo()
      .then(() => signInPage.isCurrentPage())
      .then((isNotSignedIn) => {
        if (isNotSignedIn) {
          signInPage.completeSignInFormWithValidUser();
        }
      });
  }

  givenUserIsNotSignedIn() {
    const searchPage = new DeclarationSearchPage();
    const signInPage = new SignInPage();

    return searchPage.navigateTo()
      .then(() => searchPage.isCurrentPage())
      .then((isSignedIn) => {
        if (isSignedIn) {
          new UserDetails().signOut();
        }
      });
  }
}
