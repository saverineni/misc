import { browser } from "protractor";

const fetch = require('node-fetch');

export class Wiremock {
  static reset() {
    return fetch(browser.baseUrl + '/api/__admin/mappings/reset', {method: 'POST'});
  }

  static stubRequest(body) {
    return fetch(browser.baseUrl + '/api/__admin/mappings', {
      method: 'POST',
      body: JSON.stringify(body)
    });
  }

  static givenSearchServiceIsOffline() {
    return this.stubRequest({
      "priority": 1,
      "request": {
        "urlPattern": ".*"
      },
      "response": {
        "status": 502,
      }
    });
  }

  static givenNotFound(url) {
    return this.stubRequest({
      "priority": 1,
      "request": {
        "url": url
      },
      "response": {
        "status": 404,
      }
    });
  }

  static requestCountForGet(url) {
    return fetch(browser.baseUrl + '/api/__admin/requests/count', {
      method: 'POST',
      body: JSON.stringify({
        "method": "GET",
        "url": url,
        "headers": {
          "X-Correlation-ID": {
              "matches": "^[a-zA-Z0-9]*$"
          }
      }
      })
    })
    .then(res => res.text())
    .then(body => JSON.parse(body).count);
  }
}
