import { browser, by, element } from 'protractor';

export class NotFoundPage {
  getCurrentUrl() {
    return browser.getCurrentUrl();
  }

  isDisplayed() {
    return element(by.css('section.not-found')).isDisplayed();
  }

  clickSignIn() {
    return element(by.className('not-found__sign-in-button')).click();
  }
}
