import { by, element } from 'protractor';

export class UserDetails {
  isDisplayed() {
    return element(by.css('.user-details')).isPresent();
  }

  getPid() {
    return element(by.css('.user-details__pid')).getText();
  }

  signOut() {
    return element(by.css('.user-details__sign-out')).click();
  }
}
