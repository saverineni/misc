import { Component } from '@angular/core';
import { HttpNotificationService } from './http-notification.service';
import { OnInit, OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { Router, NavigationEnd, ActivatedRouteSnapshot } from '@angular/router';
import { Subscription } from 'rxjs';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  readonly homeLabel: string = "Customs Declaration Search";

  httpRequest: HttpNotificationService;
  urlSubscription: Subscription;

  constructor(private httpNotification: HttpNotificationService,
              private router: Router,
              private title: Title) {}

  private getDeepestTitle(routeSnapshot: ActivatedRouteSnapshot) {
    let title = routeSnapshot.data ? routeSnapshot.data.title : '';
    if (routeSnapshot.firstChild) {
      title = this.getDeepestTitle(routeSnapshot.firstChild) || title;
    }
    return title;
  }

  ngOnInit(): void {
    this.httpRequest = this.httpNotification;
    this.urlSubscription = this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.title.setTitle(this.getDeepestTitle(this.router.routerState.snapshot.root));
      }
    });
  }

  ngOnDestroy(): void {
    this.urlSubscription.unsubscribe();
  }
}
