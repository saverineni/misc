import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SignInComponent } from './sign-in/sign-in.component';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AuthenticationRoutingModule } from './routing/authentication-routing.module';
import { AuthenticationService } from './authentication.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CacheService } from "./cache.service";
import { UserDetailsComponent } from './user-details/user-details.component';
import { UserService } from './user.service';
import { SignInRouterService } from './sign-in/sign-in-router.service';

@NgModule({
  imports: [
    AuthenticationRoutingModule,
    CommonModule,
    FlexLayoutModule,
    MatButtonModule,
    MatInputModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule
  ],
  declarations: [SignInComponent, UserDetailsComponent],
  exports: [SignInComponent, UserDetailsComponent],
  providers: [
    AuthenticationService,
    CacheService,
    UserService,
    SignInRouterService
  ]
})
export class AuthenticationModule { }
