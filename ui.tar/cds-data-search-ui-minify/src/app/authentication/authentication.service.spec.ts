import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing'
import { AuthenticationService } from './authentication.service';
import { CacheService } from "./cache.service";
import { User } from './user';

describe('AuthenticationService', () => {
  let httpMock: HttpTestingController;
  let service: AuthenticationService;
  let cacheService: CacheService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AuthenticationService, CacheService],
      imports: [HttpClientTestingModule]
    });

    httpMock = TestBed.get(HttpTestingController);
    service = TestBed.get(AuthenticationService);
    cacheService = TestBed.get(CacheService);
    spyOn(cacheService, 'setToken');
    spyOn(cacheService, 'setUser');
  });

  describe('sign in', () => {
    const pid = '12345';
    const password = 'password';
    const mockSignInRequest = () => httpMock.expectOne('/api/authentication/token');

    it('should send the sign in credentials to the api', () => {
      service.signIn(pid, password).subscribe(() => '');
      const signInRequest = mockSignInRequest();
      signInRequest.flush({});

      expect(signInRequest.request.body).toEqual({ pid: pid, password: password });
    });

    describe('authorised response', () => {
      let signIn;

      beforeEach(() => {
        signIn = service.signIn(pid, password);
      });

      it('save the token', (done) => {
        signIn.subscribe(
          response => {
            expect(cacheService.setToken).toHaveBeenCalledWith('123.123.123');
            done();
          },
          error => done.fail('no error expected')
        );
        mockSignInRequest().flush({'token': '123.123.123'}, { status: 200, statusText: 'OK' });
      });

      it('save the pid', (done) => {
        signIn.subscribe(
          response => {
            expect(cacheService.setUser).toHaveBeenCalledWith(new User(pid));
            done();
          },
          error => done.fail('no error expected'));
        mockSignInRequest().flush({ 'token': '123.123.123' }, { status: 200, statusText: 'OK' });
      });

      it('maps to an authorised result', (done) => {
        signIn.subscribe(
          response => {
            expect(response.authorised).toBe(true);
            done();
          },
          error => done.fail('no error expected'));
        mockSignInRequest().flush({ 'token': '123.123.123' }, { status: 200, statusText: 'OK' });
      });
    });

    describe('unauthorised response', () => {
      it('should not save the token', (done) => {
        service.signIn(pid, password).subscribe(
          response => {
            expect(cacheService.setToken).not.toHaveBeenCalled();
            expect(cacheService.setUser).not.toHaveBeenCalled();
            done();
          },
          error => done.fail('no error expected'));
        mockSignInRequest().error(new ErrorEvent(''), { status: 401 });
      });

      it('maps to an unauthorised result', (done) => {
        service.signIn(pid, password).subscribe(
          response => {
            expect(response.authorised).toBe(false);
            done();
          },
          error => done.fail('no error expected'));
          mockSignInRequest().error(new ErrorEvent(''), { status: 401 });
      });
    });

    describe('other error', () => {
      const errorEvent = new ErrorEvent('');
      it('should not save the token', (done) => {
        service.signIn(pid, password).subscribe(
          success => done.fail('should have given an error'),
          error => {
            done();
          });
          mockSignInRequest().error(errorEvent, { status: 500 });
      });

      it('pass the error through', (done) => {
        service.signIn(pid, password).subscribe(
          success => done.fail('should have given an error'),
          error => {
            expect(cacheService.setToken).not.toHaveBeenCalled();
            expect(cacheService.setUser).not.toHaveBeenCalled();
            expect(error.error).toBe(errorEvent);
            done();
          }
        );
        mockSignInRequest().error(errorEvent, { status: 500 });
      });
    });
  });

  describe('sign out', () => {
    beforeEach(() => {
      spyOn(cacheService, 'clear');
    });

    it('should sign the user out', () => {
      service.signOut();
      expect(cacheService.clear).toHaveBeenCalled();
    });
  });

  describe('isAuthenticated', () => {
    let getTokenSpy;

    beforeEach(() => {
      getTokenSpy = spyOn(cacheService, 'getToken');
    });

    describe('with a token', () => {
      beforeEach(() => {
        getTokenSpy.and.returnValue('a-token');
      });

      it('should return true for a valid token', () => {
        expect(service.isAuthenticated()).toBe(true);
      });
    });

    describe('without a token', () => {
      beforeEach(() => {
        getTokenSpy.and.returnValue(null);
      });

      it('should return false', () => {
        expect(service.isAuthenticated()).toBe(false);
      });
    });
  });

});
