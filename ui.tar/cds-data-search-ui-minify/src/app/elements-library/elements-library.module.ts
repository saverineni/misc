import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CdsHeaderComponent } from './cds-header/cds-header.component';
import { CdsNavbarComponent } from './cds-navbar/cds-navbar.component';
import { RouterModule } from '@angular/router';
import { DataGridComponent } from './cds-data-grid/data-grid.component';
import { MatGridListModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    RouterModule,
    MatGridListModule
  ],
  declarations: [CdsHeaderComponent, CdsNavbarComponent, DataGridComponent],
  exports: [CdsHeaderComponent, CdsNavbarComponent, DataGridComponent]
})
export class ElementsLibraryModule { }
