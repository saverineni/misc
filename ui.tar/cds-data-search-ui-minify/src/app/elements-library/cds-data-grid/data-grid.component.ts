import {ChangeDetectionStrategy, Component, Input, ViewEncapsulation} from '@angular/core';
import {Column} from './column-definition';
import {TrackBy} from '../../track-by';
import {Observable} from 'rxjs/internal/Observable';

@Component({
  selector: 'cds-data-grid',
  templateUrl: './data-grid.component.html',
  styleUrls: ['./data-grid.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DataGridComponent {
  trackById = TrackBy.property('id');

  @Input() columnCount: number;
  @Input() columns: Observable<Column[]>;
}
