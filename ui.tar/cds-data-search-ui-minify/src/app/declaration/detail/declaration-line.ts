import { Country } from '../country';

export class DeclarationLine {
    declarationId: string;
    itemNumber: number;
    itemDispatchCountry: Country;
    itemDestinationCountry: Country;
    clearanceDate: string;
    cpc: string;
    originCountry: Country;
    commodityCode: string;
    itemConsigneeTurn: string;
    itemConsignorTurn: string;
    itemRoute: string;
    itemConsigneeName: string;
    itemConsigneePostcode: string;
    itemConsignorName: string;
    itemConsignorPostcode: string;
}
