import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeclarationDetailComponent } from './declaration-detail.component';
import { MatCardModule, MatDividerModule, MatExpansionModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Directive } from '@angular/core';
import { Input } from '@angular/core';
import { Declaration } from './declaration';
import { ActivatedRoute } from '@angular/router';
import { of, BehaviorSubject, Observable } from 'rxjs';
import { By } from '@angular/platform-browser';
import { DeclarationLine } from './declaration-line';
import { NavigationService } from '../search/navigation.service';
import { DeclarationService } from './declaration.service';
import { ColumnDefinition, Column } from '../../elements-library/cds-data-grid/column-definition';
import { RouterTestingModule } from '@angular/router/testing';

@Directive({
  selector: 'cds-data-grid'
})
export class DeclarationDataGridStub {
  @Input() columnCount: number;
  @Input() columns: Observable<Column[]>;
}

describe('DeclarationDetailComponent', () => {
  let component: DeclarationDetailComponent;
  let fixture: ComponentFixture<DeclarationDetailComponent>;
  let declaration: Declaration;
  let mockNavigationService: NavigationService;
  let mockDeclarationService: DeclarationService;
  let activatedRoute: ActivatedRoute;

  beforeEach(async(() => {
    declaration = new Declaration();
    declaration.declarationId = 'id';
    let obs: any = of(declaration);

    activatedRoute = {
      data: obs
    } as ActivatedRoute;

    mockNavigationService = {
      navigateToSearch: (x) => {}
    } as NavigationService;
    spyOn(mockNavigationService, 'navigateToSearch');

    mockDeclarationService = {
      declarationForRoute: (route) => obs
    } as DeclarationService;
    spyOn(mockDeclarationService, 'declarationForRoute').and.callThrough();

    TestBed.configureTestingModule({
      imports: [MatCardModule, MatDividerModule, MatExpansionModule, BrowserAnimationsModule, RouterTestingModule],
      declarations: [ DeclarationDetailComponent, DeclarationDataGridStub ],
      providers: [
        { provide: ActivatedRoute, useValue: activatedRoute },
        { provide: DeclarationService, useValue: mockDeclarationService },
        { provide: NavigationService, useValue: mockNavigationService }
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DeclarationDetailComponent);
    component = fixture.componentInstance;
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call the declaration service with the route', () => {
    fixture.detectChanges();
    expect(mockDeclarationService.declarationForRoute).toHaveBeenCalledWith(activatedRoute);
  });

  describe('back to search button', () => {
    it('should call the navigation service when clicked', () => {
      fixture.debugElement.query(By.css('.declaration-detail__back-to-search-button')).nativeElement.click();
      expect(mockNavigationService.navigateToSearch).toHaveBeenCalledWith(false);
    });
  });

  describe('data grid', () => {
    let dataGrid: DeclarationDataGridStub;

    beforeEach(() => {
      fixture.detectChanges();

      dataGrid = fixture.debugElement.query(By.directive(DeclarationDataGridStub)).injector.get(DeclarationDataGridStub);
    });

    it('should set the column count', () => {
      expect(dataGrid.columnCount).toBe(4);
    });

    it('should generate the grid columns', (done) => {
      dataGrid.columns.subscribe(
        columns => {
          expect(columns).toEqual(component.declarationHeaderColumnDefinitions.map(it => it.toColumn(declaration)));
          done();
        },
        done.fail
      );
    });
  });

  describe('item details button', () => {
    function getItemDetailsDisabledButton() {
      return fixture.debugElement.query(By.css('button.declaration-detail__item-details-button'));
    }

    function getItemDetailsLink() {
      return fixture.debugElement.query(By.css('a.declaration-detail__item-details-button'));
    }

    describe('with lines', () => {
      beforeEach(() => {
        declaration.lines = [new DeclarationLine(), new DeclarationLine()]
        fixture.detectChanges();
      });

      it('should have the correct link for the first items details', () => {
        let href = getItemDetailsLink().nativeElement.getAttribute('ng-reflect-router-link');
        expect(href).toEqual('/declarations/id/items/1');
      });

      it('should report the correct number of items', () => {
        expect(getItemDetailsLink().nativeElement.innerText).toEqual('ITEM DETAIL (2)');
      });

      it('should not be disabled when there are items', () => {
        expect(getItemDetailsLink() === null).toBe(false);
        expect(getItemDetailsDisabledButton() === null).toBe(true);
      });
    });

    describe('without lines', () => {
      beforeEach(() => {
        declaration.lines = [];
        fixture.detectChanges();
      });

      it('should report zero items correctly', () => {
        expect(getItemDetailsDisabledButton().nativeElement.innerText).toEqual('ITEM DETAIL (0)');
      });

      it('should be disabled when there are zero items', () => {
        expect(getItemDetailsDisabledButton().nativeElement.disabled).toBe(true);
      });
    });
  });
});
