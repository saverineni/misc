import { DeclarationLine } from "./declaration-line";

export class LinesSelection {
  
  selectedItemNumber: number;

  readonly lines: Array<DeclarationLine>;

  constructor(
    _lines: Array<DeclarationLine>,
    readonly declarationId: string
  ) {
    this.lines = _lines.map(line => {
        const newLine = Object.assign(new DeclarationLine(), line);
        newLine.declarationId = declarationId;
        return newLine;
      })
      .sort((a, b) => a.itemNumber - b.itemNumber);
  }

  isSelectionValid() {
    return this.lines.find(it => it.itemNumber == this.selectedItemNumber) !== undefined;
  }
}