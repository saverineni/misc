import { DeclarationLine } from './declaration-line';
import { LinesSelection } from './lines-selection';

describe('LineSelection', () => {
  const DECLARATION_ID ='dec-id';

  let lines: Array<DeclarationLine>;
  let linesSelection;

  function line(itemNumber) {
    const line = new DeclarationLine();
    line.itemNumber = itemNumber;
    line.itemConsigneeName = `name ${itemNumber}`;

    return line;
  }
  
  function withDecId(line) {
    const newLine = Object.assign(new DeclarationLine(), line);
    newLine.declarationId = DECLARATION_ID;
    return newLine;
  }
  
  it('should return the declaration lines with the declaration id added', () => {
    lines = [ line(1), line(2) ];
    linesSelection = new LinesSelection(lines, DECLARATION_ID);
    expect(linesSelection.lines).toEqual(lines.map(withDecId));
  });
  
  it('should sort the lines by item number', () => {
    lines = [ line(2), line(1), line(3) ];
    linesSelection = new LinesSelection(lines, DECLARATION_ID);
    expect(linesSelection.lines.map(it => it.itemNumber)).toEqual([1, 2, 3]);
  });

  it('should give true when selected item is present', () => {
    lines = [ line(1), line(4) ];
    linesSelection = new LinesSelection(lines, DECLARATION_ID);
    linesSelection.selectedItemNumber = 4;

    expect(linesSelection.isSelectionValid()).toBe(true);
  })

  it('should give false when selected item is present', () => {
    lines = [ line(1), line(4) ];
    linesSelection = new LinesSelection(lines, DECLARATION_ID);
    linesSelection.selectedItemNumber = 2;

    expect(linesSelection.isSelectionValid()).toBe(false);
  });
})