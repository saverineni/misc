import {ChangeDetectionStrategy, Component, Input} from '@angular/core';
import {DeclarationPreview} from '../declaration-preview';
import {ColumnDefinition} from '../../../elements-library/cds-data-grid/column-definition';
import { of } from 'rxjs';

@Component({
  selector: 'cds-declaration-card',
  templateUrl: './declaration-card.component.html',
  styleUrls: ['./declaration-card.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DeclarationCardComponent {
  @Input() declaration: DeclarationPreview;

  declarationHeaderColumnDefinitions = [
    new ColumnDefinition({ id: 'declarationId', label: 'Declaration ID', colspan: 3, strong: true }),
    new ColumnDefinition({ id: 'epuNumber', label: 'EPU' }),
    new ColumnDefinition({ id: 'entryNumber', label: 'Entry Number' }),
    new ColumnDefinition({ id: 'entryDate', label: 'Entry Date' }),
    new ColumnDefinition({ id: 'route', label: 'Route of Entry' }),
    new ColumnDefinition({ id: 'dispatchCountry', label: 'Country of Dispatch',
      getValue: (dec) => dec.dispatchCountry && dec.dispatchCountry.code }),
    new ColumnDefinition({ id: 'destinationCountry', label: 'Country of Destination',
      getValue: (dec) => dec.destinationCountry && dec.destinationCountry.code }),
    new ColumnDefinition({ id: 'goodsLocation', label: 'Goods Location' }),
    new ColumnDefinition({ id: 'transportModeCode', label: 'Mode of Transport' })
  ];

  declarationColumns() {
    return of(
      this.declarationHeaderColumnDefinitions.map(it => it.toColumn(this.declaration))
    );
  }
}
