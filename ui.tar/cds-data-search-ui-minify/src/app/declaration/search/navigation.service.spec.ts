import {NavigationService} from './navigation.service';
import {SearchCriteria} from './search-criteria';
import {Observable, of} from 'rxjs';
import {ActivatedRoute, convertToParamMap, ParamMap, Params, Router} from '@angular/router';
import {SearchCriteriaService} from './search-criteria.service';

describe('NavigationService', () => {
  let navigationService : NavigationService;
  let searchCriteriaServiceStub: SearchCriteriaService;
  let testSearchCriteriaObservable: Observable<SearchCriteria>;
  let testQueryParamsObservable: Observable<Params>;

  let testActivatedRoute;

  let navigateForEachHandler;
  let successSearchCriteriaHandler;
  let successQueryParamsHandler;

  let testRouter: Router;

  beforeEach(() => {
    testSearchCriteriaObservable = of(null);
      spyOn(testSearchCriteriaObservable, 'subscribe')
          .and.callFake(success => successSearchCriteriaHandler = success);
      spyOn(testSearchCriteriaObservable, 'forEach')
          .and.callFake(success => navigateForEachHandler = success);

      searchCriteriaServiceStub = {
        searchCriteria: testSearchCriteriaObservable,
        update: (criteria) => {}
      } as SearchCriteriaService;
      spyOn(searchCriteriaServiceStub, 'update');

      testQueryParamsObservable = of(null);
      spyOn(testQueryParamsObservable, 'subscribe')
          .and.callFake(success => successQueryParamsHandler = success);

      testActivatedRoute = {
        queryParamMap: testQueryParamsObservable
      } as ActivatedRoute;
  });

  describe('initially', () => {

    beforeEach(() => {
      testRouter = {
        url: '/declarations',
        navigate: (commands, extras) => {},
        navigated: false
      } as Router;

      spyOn(testRouter, 'navigate');
      navigationService = new NavigationService(searchCriteriaServiceStub, testRouter, testActivatedRoute);
    });

    describe('search criteria', () => {
      it('should not trigger on the initial load', () => {
        let searchCriteria = new SearchCriteria();
        successSearchCriteriaHandler(searchCriteria);
        expect(testRouter.navigate).not.toHaveBeenCalled();
      });
    });

    describe('query params', () => {
      it('should only trigger for the root path', () => {
        let paramMap: ParamMap = convertToParamMap({
          searchTerm: 'term'
        });
        successQueryParamsHandler(paramMap);
        expect(searchCriteriaServiceStub.update).not.toHaveBeenCalled();
      });
    });

  });

  describe('after creation', () => {

    beforeEach(() => {
      testRouter = {
        url: '/',
        navigate: (commands, extras) => {},
        navigated: true
      } as Router;

      spyOn(testRouter, 'navigate');
      navigationService = new NavigationService(searchCriteriaServiceStub, testRouter, testActivatedRoute);
    });

    describe('navigate to search', () => {

      it('should clear search criteria when clear params is true', () => {
        navigationService.navigateToSearch(true);
        let search = new SearchCriteria();
        navigateForEachHandler(search);

        expect(searchCriteriaServiceStub.update).toHaveBeenCalledWith(search);
        expect(testRouter.navigate).toHaveBeenCalledWith(['/'], { queryParams: search });
      });

      it('should route to search with current params when clear params is false', () => {
        let search = new SearchCriteria();
        search.searchTerm = 'test';
        navigationService.navigateToSearch(false);
        navigateForEachHandler(search);

        expect(searchCriteriaServiceStub.update).not.toHaveBeenCalled();
        expect(testRouter.navigate).toHaveBeenCalledWith(['/'], { queryParams: search });
      });

    });

    describe('search criteria',() => {
      it('should subscribe to successful updates', () => {
        expect(successSearchCriteriaHandler).toBeTruthy();
      });

      it('should navigate for the params' , () => {
        let searchCriteria = new SearchCriteria();
        successSearchCriteriaHandler(searchCriteria);
        expect(testRouter.navigate).toHaveBeenCalledWith(['/'],{queryParams: searchCriteria});
      });
    });

    describe('query params',() => {
      let paramMap: ParamMap;

      it('should subscribe to successful updates', () => {
        expect(successQueryParamsHandler).toBeTruthy();
      });

      it('should update the search criteria' , () => {
        paramMap = convertToParamMap({
          searchTerm: 'term',
          originCountryCode: ['AB','CD'],
          dispatchCountryCode: ['EF'],
          destinationCountryCode: ['GH'],
          transportModeCode: ['mode'],
          goodsLocation: ['gl1'],
          commodityCode: [ 'commodity', 'com2'],
          entryDateFrom: '2018-01-01',
          entryDateTo: '2018-01-02',
          clearanceDateFrom: '2018-01-01',
          clearanceDateTo: '2018-01-02',
          pageNumber: '1',
          pageSize: '10'
        });

        let searchCriteria = new SearchCriteria();
        searchCriteria.searchTerm = 'term';
        searchCriteria.originCountryCode =  ['AB','CD'];
        searchCriteria.dispatchCountryCode =  ['EF'];
        searchCriteria.destinationCountryCode =  ['GH'];
        searchCriteria.transportModeCode =  ['mode'];
        searchCriteria.goodsLocation = ['gl1'],
        searchCriteria.commodityCode = [ 'commodity', 'com2'],
        searchCriteria.entryDateFrom = '2018-01-01';
        searchCriteria.entryDateTo = '2018-01-02';
        searchCriteria.clearanceDateFrom = '2018-01-01';
        searchCriteria.clearanceDateTo = '2018-01-02';
        searchCriteria.pageNumber = 1;
        searchCriteria.pageSize = 10;

        successQueryParamsHandler(paramMap);
        expect(searchCriteriaServiceStub.update).toHaveBeenCalledWith(searchCriteria);
      });

      it('should update as null for an empty array' , () => {
        paramMap = convertToParamMap({searchTerm: 'term'});
        let searchCriteria = new SearchCriteria();
        searchCriteria.searchTerm = 'term';
        searchCriteria.entryDateFrom = null;
        searchCriteria.entryDateTo = null;
        searchCriteria.clearanceDateFrom = null;
        searchCriteria.clearanceDateTo = null;

        successQueryParamsHandler(paramMap);
        expect(searchCriteriaServiceStub.update).toHaveBeenCalledWith(searchCriteria);
      });
    });
  });
});
