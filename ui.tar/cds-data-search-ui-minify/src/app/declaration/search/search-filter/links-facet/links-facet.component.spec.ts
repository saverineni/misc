import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {LinksFacetComponent} from './links-facet.component';
import {DebugElement} from "@angular/core";
import {By} from "@angular/platform-browser";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {Facet} from '../../facets';
import {FormsModule} from "@angular/forms";
import {MatChipsModule, MatDialog, MatDialogModule, MatIconModule, MatInputModule} from "@angular/material";
import {FlexLayoutModule} from "@angular/flex-layout";
import {FacetedSearchComponent} from '../faceted-search/faceted-search.component';
import {FacetNotMatchingPipe} from '../../facet-not-matching.pipe';
import {BrowserDynamicTestingModule} from "@angular/platform-browser-dynamic/testing";
import {SearchCriteriaService} from "../../search-criteria.service";
import {FacetService} from "../../facet.service";
import {Observable, of, Subscription} from "rxjs/index";
import {SearchCriteria} from "../../search-criteria";

const LABEL = 'links label';
const SEARCH_PARAM = 'searchParam';
const FACET_SEARCH = { name: 'value' };

describe('LinksFacetComponent', () => {
  let component: LinksFacetComponent;
  let fixture: ComponentFixture<LinksFacetComponent>;
  let filter: DebugElement;
  let searchCriteriaService: SearchCriteriaService;
  let testSubscription: Subscription;
  let testObservable: Observable<SearchCriteria>;
  let successHandler;
  let facetService: FacetService;
  let facets: Array<Facet> = [];
  let facetObservable: Observable<Array<Facet>>;

  let dialog = {
    open(a, b) { },
    closeAll() {}
  } as MatDialog;

  beforeEach(async(() => {

    testObservable = of(null);
    testSubscription = new Subscription();

    spyOn(testObservable, 'subscribe').and.callFake(
      success => {
        successHandler = success;
        return testSubscription;
      }
    );
    spyOn(testSubscription, 'unsubscribe');

    searchCriteriaService = {
      searchCriteria: testObservable
    } as SearchCriteriaService;
    spyOn(searchCriteriaService, 'searchCriteria');


    facetObservable = of(facets);
    facetService = {
      getFacets: (facet, filter, criteria) => facetObservable
    } as FacetService;
    spyOn(facetService, 'getFacets').and.callThrough();

    TestBed.configureTestingModule({
      imports: [MatDialogModule, MatChipsModule, MatIconModule , MatInputModule, BrowserAnimationsModule , FlexLayoutModule, FormsModule],
      declarations: [ LinksFacetComponent, FacetedSearchComponent , FacetNotMatchingPipe ],
      providers: [
        { provide: MatDialog, useValue: dialog },
        { provide: SearchCriteriaService, useValue: searchCriteriaService },
        { provide: FacetService, useValue: facetService }
      ]
    }).overrideModule(BrowserDynamicTestingModule, {
      set: {
        entryComponents: [FacetedSearchComponent]
      }
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinksFacetComponent);
    component = fixture.componentInstance;

    filter = fixture.debugElement.query(By.css('.links'));
    component.label = LABEL;
    component.searchParam = SEARCH_PARAM;
    component.facetSearch = FACET_SEARCH;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('has facets', () => {

    it('should display the facet container with the search param as id', () => {
      let facetId = filter.nativeElement.getAttribute('data-links-id');
      expect(facetId).toBe(SEARCH_PARAM);
    });

    it('should display the facet type',() => {
      let facetType = filter.query(By.css('.links__facet'));
      expect(facetType).toBeTruthy();
    });

    it('should display the facet label',() => {
      let facetLabel = filter.query(By.css('.links__facet')).nativeElement;
      expect(facetLabel.innerText).toBe(LABEL);
    });

    describe('on initialisation', () => {
      it('should subscribe to search criteria updates', () => {
        expect(successHandler).toBeTruthy();
      });
    });

    describe('on destroy', () => {
      beforeEach(() => {
        spyOn(component.dialog, 'closeAll');

        fixture.destroy();
      });

      it('should unsubscribe from search criteria updates', () => {
        expect(testSubscription.unsubscribe).toHaveBeenCalled();
      });

      it('should close all dialogs', () => {
        expect(component.dialog.closeAll).toHaveBeenCalled();
      });
    });

    describe('click on the facet' , () => {

      beforeEach(() => {
        spyOn(component.dialog, 'open').and.callThrough();
      });

      function clickTheLinkFacet() {
        let facet = filter.query(By.css('.links__facet')).nativeElement;
        facet.click();
        fixture.detectChanges();
      }

      describe('facetSearch is defined', () => {
        beforeEach(() => {
          expect(component.dialog.open).toHaveBeenCalledTimes(0);
          clickTheLinkFacet();
        });

        it('facet service should not be called', () => {
          expect(facetService.getFacets).toHaveBeenCalledTimes(0);
        });

        it('opens the dialog window with the correct properties', () => {
          expect(component.dialog.open).toHaveBeenCalledWith(
            FacetedSearchComponent,
            {
              width: "700px",
              maxHeight: "90vh",
              minHeight: "50vh",
              data: {
                facets: undefined,
                searchParam: SEARCH_PARAM,
                facetType: LABEL,
                facetSearch: FACET_SEARCH
              }
            });
        });
      });

      describe('facetSearch is undefined', () => {
        beforeEach(() => {
          expect(component.dialog.open).toHaveBeenCalledTimes(0);
          component.facetSearch = undefined;
          fixture.detectChanges();

          clickTheLinkFacet();
        });

        it('facet service should have been called', () => {
          expect(facetService.getFacets).toHaveBeenCalledTimes(1);
        });

        it('opens the dialog window with the correct properties', () => {
          expect(component.dialog.open).toHaveBeenCalledWith(
            FacetedSearchComponent,
            {
              width: "700px",
              maxHeight: "90vh",
              minHeight: "50vh",
              data: {
                facets: facets,
                searchParam: SEARCH_PARAM,
                facetType: LABEL,
                facetSearch: undefined
              }
            });
        });
      });
    });
  });
});
