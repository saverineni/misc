import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {By} from "@angular/platform-browser";
import {ChipsComponent} from './chips.component';
import {MatChipsModule, MatIconModule} from "@angular/material";

const LABEL = 'chips label';
const ID = 'chipsId';

describe('ChipsComponent', () => {
  let component: ChipsComponent;
  let fixture: ComponentFixture<ChipsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MatChipsModule , MatIconModule],
      declarations: [ ChipsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChipsComponent);
    component = fixture.componentInstance;
    component.label = LABEL;
    component.id = ID;

    fixture.detectChanges();
  });

  it('should not display if no chip data present', () => {
    let chips = fixture.debugElement.query(By.css('.chips'));

    expect(chips == null).toBe(true);
  });

  describe('has chips', () => {
    beforeEach(() => {
      fixture = TestBed.createComponent(ChipsComponent);
      component = fixture.componentInstance;
      component.label = LABEL;
      component.id = ID;
      component.chips = [ 'chip1', 'chip2', 'chip3', 'Unknown' ];
      fixture.detectChanges();
    });

    it('should display if chips data present', () => {
      let chips = fixture.debugElement.query(By.css('.chips'));

      expect(chips != null).toBe(true);
    });

    it('should display the applied label', () => {
      let label = fixture.debugElement.query(By.css('.chips__label')).nativeElement;
      expect(label.innerText).toBe(LABEL);
    });

    it('should set chips id', () => {
      let elementWithId = fixture.debugElement.query(By.css(`.chips[data-chips-id="${ID}"]`));
      expect(elementWithId != null).toBeTruthy();
    });

    it('should display all of the chips', () => {
      const chipTexts = fixture.debugElement.queryAll(By.css('.chips__chip-text')).map(chipDebugElement =>
        chipDebugElement.nativeElement.textContent
      );
      expect(chipTexts).toEqual(component.chips);
    });

    describe('removing chip', () => {
      beforeEach(() => {
        spyOn(component.onRemove, 'emit');

        fixture.debugElement.query(By.css('.chips__chip-remove[data-chip-id="chip2"]')).nativeElement.click();
        fixture.detectChanges();
      });

      it('should emit a remove event', () => {
        expect(component.onRemove.emit).toHaveBeenCalledWith('chip2');
      });
    });
  });
});
