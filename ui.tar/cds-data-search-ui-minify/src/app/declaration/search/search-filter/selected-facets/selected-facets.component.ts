import { Component, OnInit, OnDestroy } from '@angular/core';
import { SearchCriteria } from '../../search-criteria';
import { SearchCriteriaService } from '../../search-criteria.service';
import { Subscription } from 'rxjs';
import { ChangeDetectionStrategy } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import { TrackBy } from '../../../../track-by';

@Component({
  selector: 'cds-selected-facets',
  templateUrl: './selected-facets.component.html',
  styleUrls: ['./selected-facets.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SelectedFacetsComponent implements OnInit, OnDestroy {
  private criteriaSubscription: Subscription;
  searchCriteria: SearchCriteria;
  chipFacetTypes : Array<any>;
  trackByIndex = TrackBy.index;
  unknownChipName = 'Unknown';

  constructor(private searchCriteriaService: SearchCriteriaService,
              private changeDetectorRef: ChangeDetectorRef) { }
  ngOnInit(): void {
    this.criteriaSubscription = this.searchCriteriaService.searchCriteria.subscribe(
      criteria => {
        this.searchCriteria = criteria;
        this.chipFacetTypes = [
          {
            id: 'originCountryCode',
            label: 'Country of Origin'
          },{
            id: 'dispatchCountryCode',
            label: 'Country of Dispatch'
          },{
            id: 'destinationCountryCode',
            label: 'Country of Destination'
          },{
            id: 'transportModeCode',
            label: 'Mode of Transport'
          },{
            id: 'goodsLocation',
            label: 'Goods Location'
          },{
            id: 'commodityCode',
            label: 'Commodity Code'
          }
        ];

        this.chipFacetTypes.forEach((it: any) =>
          it.chips = this.mapChipsFromSearchCriteria(this.searchCriteria[it.id])
        );

        this.changeDetectorRef.detectChanges();
      }
    );

  }

  private mapChipsFromSearchCriteria(criteria) {
    return criteria && criteria.map(id => id === '' ? this.unknownChipName : id);
  }

  hasSelectedFacets() {
    return this.searchCriteria != null
      && (this.searchCriteria.originCountryCode != null ||
          this.searchCriteria.dispatchCountryCode != null ||
          this.searchCriteria.destinationCountryCode != null ||
          this.searchCriteria.transportModeCode != null ||
          this.searchCriteria.goodsLocation != null ||
          this.searchCriteria.commodityCode != null );
  }

  removeSelectedChip(chipId, facetType) {
    const update = {};
    chipId = chipId === this.unknownChipName ? '' : chipId;
    let newSelection = this.searchCriteria[facetType].filter(id => id != chipId);
    if(newSelection.length == 0) {
      newSelection = null;
    }
    update[facetType] = newSelection;
    update['pageNumber'] = undefined;
    update['pageSize'] = undefined;
    this.searchCriteriaService.updatePartial(update);
  }


  ngOnDestroy(): void {
    this.criteriaSubscription.unsubscribe();
  }
}
