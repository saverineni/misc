import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FacetedSearchComponent, SelectableFacet } from './faceted-search.component';
import { MatDialogModule } from "@angular/material/dialog";
import { MAT_DIALOG_DATA, MatChipsModule, MatDialogRef, MatFormFieldModule, MatIconModule } from "@angular/material";
import { By } from "@angular/platform-browser";
import { DebugElement } from "@angular/core/src/debug/debug_node";
import { MatListModule } from "@angular/material/list";
import { FacetNotMatchingPipe } from '../../facet-not-matching.pipe';
import { FormsModule } from "@angular/forms";
import { FlexLayoutModule } from "@angular/flex-layout";
import { MatInputModule } from "@angular/material/input";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { SearchCriteriaService } from '../../search-criteria.service';
import { SearchCriteria } from '../../search-criteria';
import { Observable, Subscription, of } from 'rxjs';
import { FacetService } from '../../facet.service';
import { Facet } from '../../facets';

function newFacet(code, count) {
  return {
    id: code,
    count: count,
    selected: false,
    label: code === '' ? 'Unknown' : code
  };
}

const FACET1_NAME = 'facet1';
const FACET2_NAME = 'facet2';
const FACET3_NAME = 'AB_facet';
const FACET4_NAME = 'AD_facet';
const FACET5_NAME = 'facet5';
const FACET6_NAME = '';

const facetLabels = [`${FACET1_NAME} (4)`, `${FACET2_NAME} (3)`, `${FACET3_NAME} (1)`, `${FACET4_NAME} (1)`, `${FACET5_NAME} (1)`, 'Unknown (1)'];
const searchParam = 'originCountryCode';
const facetType = 'FacetType';
const FACET_SEARCH_DATA = {
  length: 2,
  type: 'type'
};

describe('FacetedSearchComponent', () => {
  let component: FacetedSearchComponent;
  let fixture: ComponentFixture<FacetedSearchComponent>;
  let matDialogRef: MatDialogRef<any>;
  let facets: Array<SelectableFacet>;
  let searchCriteriaService: SearchCriteriaService;
  let testSubscription: Subscription;
  let testObservable: Observable<SearchCriteria>;
  let successHandler;
  let facetService: FacetService;
  let facetObservable: Observable<Array<Facet>>;
  let displayedFacets;

  beforeEach(async(() => {
    matDialogRef = { close: () => { } } as MatDialogRef<any>;
    spyOn(matDialogRef, 'close');

    facets = [
      newFacet(FACET1_NAME, 4),
      newFacet(FACET2_NAME, 3),
      newFacet(FACET3_NAME, 1),
      newFacet(FACET4_NAME, 1),
      newFacet(FACET5_NAME, 1),
      newFacet(FACET6_NAME, 1)
    ];

    testObservable = of(null);
    testSubscription = new Subscription();

    spyOn(testObservable, 'subscribe').and.callFake(
      success => {
        successHandler = success;
        return testSubscription;
      }
    );
    spyOn(testSubscription, 'unsubscribe');

    searchCriteriaService = {
      searchCriteria: testObservable,
      updatePartial: (searchCriteria) => { }
    } as SearchCriteriaService;
    spyOn(searchCriteriaService, 'updatePartial');

    facetObservable = of(facets);
    facetService = {
      getFacets: (facet, filter, criteria) => facetObservable
    } as FacetService;
    spyOn(facetService, 'getFacets').and.callThrough();

    TestBed.configureTestingModule({
      imports: [
        MatDialogModule,
        MatChipsModule,
        MatIconModule,
        MatListModule,
        MatInputModule,
        FlexLayoutModule,
        BrowserAnimationsModule,
        FormsModule
      ],
      declarations: [FacetedSearchComponent, FacetNotMatchingPipe],
      providers: [
        { provide: MatDialogRef, useValue: matDialogRef },
        { provide: SearchCriteriaService, useValue: searchCriteriaService },
        { provide: FacetService, useValue: facetService },
        {
          provide: MAT_DIALOG_DATA, useValue: {
            searchParam: searchParam,
            facetType: facetType,
            facetSearch: FACET_SEARCH_DATA
          }
        }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(FacetedSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  beforeEach(() => {
    displayedFacets = () => {
      const facetElements = fixture.debugElement.queryAll(By.css('.faceted-search__link'));
      return facetElements.map(facetElement => facetElement.nativeElement.textContent);
    }
  });

  describe('no facets', () => {
    let facetFilter;

    function enterSearchTermMessageDisplayed() {
      const noResults = fixture.debugElement.query(By.css('.faceted-search__no-results-found')).nativeElement;
      expect(noResults.textContent).toBe(`Enter at least ${FACET_SEARCH_DATA.length} ${FACET_SEARCH_DATA.type} to bring back results`);
    }

    it('display a message to enter a valid search term', () =>
      enterSearchTermMessageDisplayed()
    );

    // duplicated test block
    describe('existing facet selection', () => {
      let chips: DebugElement[];
      beforeEach(() => {
        let newSearchCriteria = new SearchCriteria();
        newSearchCriteria[searchParam] = ['facet2', ''];
        successHandler(newSearchCriteria);
        fixture.detectChanges();
        chips = fixture.debugElement.queryAll(By.css('.faceted-search__selection-text'));
      });

      it('should be displayed as chips', () => {
        const chipTexts = chips.map(it => it.nativeElement.textContent.trim());
        expect(chipTexts).toEqual(['facet2', 'Unknown']);
      });
    });

    describe('and search text added', () => {
      const MINIMUM_LENGTH_FILTER = 'zz';
      const LONGER_THAN_MINIMUM_FILTER = 'fac';
      const LONGER_THAN_MINIMUM_FILTER_NO_MATCHES = 'zzz';

      let addFilterTerm;
      let searchCriteria;

      beforeEach(() => {
        addFilterTerm = (filterTerm) => {
          facetFilter = fixture.debugElement.query(By.css('.faceted-search__filter')).nativeElement;
          facetFilter.value = filterTerm;
          facetFilter.dispatchEvent(new Event('keyup'));
        };

        searchCriteria = new SearchCriteria();
        searchCriteria.searchTerm = 'term';
        successHandler(searchCriteria);
      });

      describe('then adds the required length', () => {
        beforeEach(() => addFilterTerm(MINIMUM_LENGTH_FILTER));

        it('should call the service', () => {
          expect(facetService.getFacets).toHaveBeenCalledWith(searchParam, MINIMUM_LENGTH_FILTER, searchCriteria);
        });

        it('should display the results', () => {
          expect(displayedFacets()).toEqual(facetLabels);
        });

        describe('then becomes shorter than the required length', () => {
          beforeEach(() => addFilterTerm('z'));

          it('should remove the facets', () => {
            expect(displayedFacets()).toEqual([]);
          });

          it('display a message to enter a valid search term', () =>
            enterSearchTermMessageDisplayed()
          );
        });

        describe('then adds more than the required amount', () => {
          beforeEach(() => {
            (facetService.getFacets as any).calls.reset();
            addFilterTerm(LONGER_THAN_MINIMUM_FILTER);
          });

          it('should not make another service call', () => {
            expect(facetService.getFacets).not.toHaveBeenCalled();
          });
        });
      });

      describe('adds more than the required length', () => {
        beforeEach(() => {
          addFilterTerm(LONGER_THAN_MINIMUM_FILTER);
        });

        it('should call the service', () => {
          expect(facetService.getFacets).toHaveBeenCalledWith(searchParam, 'fa', searchCriteria);
        });

        it('should display the filtered results', () => {
          // extract function for the following
          const hiddenFacetElements = fixture.debugElement.queryAll(By.css('.faceted-search__link--hidden'));
          const hiddenFacetNames = hiddenFacetElements.map(facetElement => facetElement.nativeElement.textContent);

          expect(hiddenFacetNames).toEqual(facetLabels.filter(it => !it.startsWith(LONGER_THAN_MINIMUM_FILTER)));
        });

        describe('with no filters matching', () => {
          beforeEach(() => {
            addFilterTerm(LONGER_THAN_MINIMUM_FILTER_NO_MATCHES);
            fixture.detectChanges();
          });

          it('displays the no results found message', () => {
            const noResults = fixture.debugElement.query(By.css('.faceted-search__no-results-found')).nativeElement;
            expect(noResults.textContent).toBe('No results found');
          });
        });
      });

      describe('adds less than the required length', () => {
        beforeEach(() => addFilterTerm('z'));

        it('should not call the service', () => {
          expect(facetService.getFacets).not.toHaveBeenCalled();
        });

        describe('then adds the required amount', () => {
          beforeEach(() => addFilterTerm(MINIMUM_LENGTH_FILTER));

          it('should display the results', () => {
            expect(displayedFacets()).toEqual(facetLabels);
          });
        });
      });
    });
  });
});
