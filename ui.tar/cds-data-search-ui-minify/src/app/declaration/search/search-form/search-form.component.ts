import {ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild, AfterViewInit, OnChanges, SimpleChanges} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {SearchCriteriaService} from '../search-criteria.service';
import {filter, map} from 'rxjs/operators'
import { Observable } from 'rxjs';

@Component({
  selector: 'cds-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SearchFormComponent implements OnInit {
  @ViewChild('searchInput') searchInput;

  searchTerm$: Observable<string>;

  constructor(private searchCriteriaService: SearchCriteriaService) { }

  ngOnInit() {
    this.searchTerm$ = this.searchCriteriaService.searchCriteria.pipe(
      map(data => {
        const searchTerm = data.searchTerm;
        if (searchTerm == null) {
          this.searchInput.nativeElement.focus();
        }
        return searchTerm;
      })
    );
  }

  onSubmitSearch(searchTerm) {
    if (searchTerm == null) {
      searchTerm = '';
    }
    
    this.searchCriteriaService.updatePartial({ searchTerm: searchTerm, pageNumber: undefined, pageSize: undefined });
  }
}
