import { getTestBed, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { SearchService } from './search.service';
import { SearchCriteria } from './search-criteria';
import { DeclarationSearchResult, Hits } from './declaration-search-result';
import { SearchParamsBuilder } from './search-params-builder';


describe('SearchService', () => {
  let httpMock: HttpTestingController;
  let service: SearchService;
  let searchCriteria: SearchCriteria;

  beforeEach(() => {
    searchCriteria = new SearchCriteria();

    TestBed.configureTestingModule({
      providers: [SearchService],
      imports: [HttpClientTestingModule]
    });
    httpMock = getTestBed().get(HttpTestingController);
    service = getTestBed().get(SearchService);
  });

  function mockRequest(expectedParams = {}) {
    let url = Object.getOwnPropertyNames(expectedParams)
      .reduce((url, key) => `${url}${key}=${expectedParams[key]}&`, '/api/declarations?');
    return httpMock.expectOne(url.substring(0, url.length - 1));
  }

  describe('submit search request', () => {
    let testRequest;

    beforeEach(() => {
      spyOn(SearchParamsBuilder, 'toHttpParams').and.callThrough();
      searchCriteria.searchTerm = "123-456";
      searchCriteria.originCountryCode = ['A', 'B', 'C'];

      service.search(searchCriteria).toPromise();

      testRequest = mockRequest({ searchTerm: "123-456", originCountryCode: 'A&originCountryCode=B&originCountryCode=C' });
      testRequest.flush({});
    });

    it('should as a http GET with the correct search parameters', () => {
      expect(testRequest.request.method).toBe("GET");
    });

    it('should use the search params builder', () => {
      expect(SearchParamsBuilder.toHttpParams).toHaveBeenCalledWith(searchCriteria);
    });
  });

  it('should throw error on 500', (done) => {
    const errorEvent = new ErrorEvent('');
    service.search(searchCriteria).subscribe(
      result => done.fail('expect error'),
      error => {
        expect(error.error).toBe(errorEvent);
        done();
      });
    const testRequest = mockRequest();
    testRequest.error(errorEvent, { status: 500 });
  });

  it('should return Declaration search result', () => {
    let actual: DeclarationSearchResult = null;
    service.search(searchCriteria).subscribe(result => actual = result);
    const testRequest = mockRequest();
    testRequest.flush({ hits: new Hits(), declarations: [{}] }, { status: 200, statusText: '' });
    expect(actual.declarations.length).toEqual(1);
  });

  it('should parse the json response', () => {
    const declaration: any = {};
    declaration.declarationId = searchCriteria.searchTerm;
    const hits = new Hits();
    hits.total = 1;

    let actual: DeclarationSearchResult = null;
    service.search(searchCriteria).subscribe(result => actual = result);
    const testRequest = mockRequest();
    testRequest.flush({ hits, declarations: [declaration] }, { status: 200, statusText: '' });
    expect(actual.declarations[0]).toEqual(declaration);
    expect(actual.hits).toEqual(hits);
  });

  afterEach(() => {
    httpMock.verify();
  });
});
