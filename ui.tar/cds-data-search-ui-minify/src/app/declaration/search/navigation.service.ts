import {Injectable} from '@angular/core';
import {SearchCriteriaService} from './search-criteria.service';
import {ActivatedRoute, Router} from '@angular/router';
import {SearchCriteria} from './search-criteria';

@Injectable()
export class NavigationService {

  constructor(private searchCriteriaService: SearchCriteriaService,
              private router: Router,
              private route: ActivatedRoute) {
    this.subscribeToQueryParams();
    this.subscribeToSearchCriteria();
  }

  navigateToSearch(clearParams: boolean) {
    if (clearParams) {
      this.searchCriteriaService.update(new SearchCriteria());
    }
    this.searchCriteriaService.searchCriteria.forEach(data =>
      this.router.navigate(['/'], { queryParams: data })
    );
  }

  subscribeToSearchCriteria() {
    this.searchCriteriaService.searchCriteria.subscribe(data => {
        if (this.router.navigated) {
          this.router.navigate(['/'], { queryParams: data });
        }
      }
    );
  }

  subscribeToQueryParams() {
    this.route.queryParamMap.subscribe(params => {
      if (this.router.url === '/' || this.router.url.startsWith('/?')) {
        const newSearchCriteria = new SearchCriteria();
        newSearchCriteria.searchTerm = params.get('searchTerm');

        [
          'originCountryCode',
          'dispatchCountryCode',
          'destinationCountryCode',
          'transportModeCode',
          'goodsLocation',
          'commodityCode'
        ]
        .forEach(param => {
          if (params.has(param)) {
            newSearchCriteria[param] = params.getAll(param);
          }
        });

        newSearchCriteria.entryDateFrom = params.get('entryDateFrom');
        newSearchCriteria.entryDateTo = params.get('entryDateTo');
        newSearchCriteria.clearanceDateFrom = params.get('clearanceDateFrom');
        newSearchCriteria.clearanceDateTo = params.get('clearanceDateTo');

        [
          'pageNumber',
          'pageSize'
        ]
        .forEach(param => {
          if (params.has(param)) {
            newSearchCriteria[param] = Number(params.get(param));
          }
        });

        this.searchCriteriaService.update(newSearchCriteria);
      }
    });
  }
}
