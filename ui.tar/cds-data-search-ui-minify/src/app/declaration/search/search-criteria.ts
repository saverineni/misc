export class SearchCriteria {
  searchTerm: string;
  originCountryCode: string[];
  dispatchCountryCode: string[];
  destinationCountryCode: string[];
  transportModeCode: string[];
  goodsLocation: string[];
  commodityCode: string[];
  entryDateFrom: string;
  entryDateTo: string;
  clearanceDateFrom: string;
  clearanceDateTo: string;
  pageNumber: number;
  pageSize: number;

  isEmpty(): boolean {
    return Object.getOwnPropertyNames(this)
                 .find(property  => this[property] != undefined) == undefined;
  }
}
