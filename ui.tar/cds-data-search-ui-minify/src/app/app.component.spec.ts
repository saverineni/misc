import {async, TestBed} from '@angular/core/testing';
import {By} from '@angular/platform-browser';
import {AppComponent} from './app.component';
import {Component, ContentChild, Directive, Input} from '@angular/core';
import {MatProgressSpinnerModule} from '@angular/material';
import {HttpNotificationService} from './http-notification.service';
import {RouterTestingModule} from '@angular/router/testing';

@Directive({
  selector: 'cds-header',
})
export class MockCdsHeaderComponent {
  @Input() title;
  @ContentChild('headerDetail') headerDetail;
}

@Component({
  selector: 'cds-user-details',
  template: '<span>user details</span>'
})
export class MockCdsUserDetailsComponent {}

@Directive({
  selector: 'cds-navbar',
})
export class MockCdsNavbarComponent {
  @Input() homeLabel;
}

@Directive({
  selector: 'router-outlet',
})
export class MockRouterOutlet {
}

describe('AppComponent', () => {
  let fixture;
  let httpNotificationServiceWaitingSpy;
  beforeEach(async(() => {
    let stubHttpNotificationService = { waiting: () => false };
    httpNotificationServiceWaitingSpy = spyOn(stubHttpNotificationService, 'waiting');

    TestBed.configureTestingModule({
      declarations: [
        AppComponent,
        MockCdsHeaderComponent,
        MockCdsNavbarComponent,
        MockCdsUserDetailsComponent,
        MockRouterOutlet
      ],
      imports: [
        MatProgressSpinnerModule,
        RouterTestingModule
      ],
      providers: [
        { provide: HttpNotificationService, useValue: stubHttpNotificationService }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
  }));

  describe('header', () => {
    let directive;
    let header;

    beforeEach(() => {
      directive = fixture.debugElement.query(By.directive(MockCdsHeaderComponent));
      header = directive.injector.get(MockCdsHeaderComponent);
    });

    it('should be added to the app with the title', () => {
      expect(header.title).toBe('Customs Declaration Search');
    });

    it('should be added to the app with the header detail', () => {
      expect(header.headerDetail instanceof MockCdsUserDetailsComponent).toBe(true);
    });
  });

  it('should create the app with the navbar', () => {
    const directive = fixture.debugElement.query(By.directive(MockCdsNavbarComponent));
    const navbar = directive.injector.get(MockCdsNavbarComponent);

    expect(navbar.homeLabel).toBe('Customs Declaration Search');
  });

  it('should route requests', () => {
    const directive = fixture.debugElement.query(By.directive(MockRouterOutlet));

    expect(directive).toBeTruthy();
  });

  describe('spinner', () => {
    it('should be displayed when waiting', () => {
      httpNotificationServiceWaitingSpy.and.returnValue(true);
      fixture.detectChanges();
      const waitingOverlay = fixture.debugElement.query(By.css('.waiting-overlay--show'));
      expect(waitingOverlay == null).toBeFalsy();
    });

    it('should not be displayed when not waiting', () => {
      httpNotificationServiceWaitingSpy.and.returnValue(false);
      fixture.detectChanges();
      const waitingOverlay = fixture.debugElement.query(By.css('.waiting-overlay--show'));
      expect(waitingOverlay == null).toBeTruthy();
    });
  });
});
