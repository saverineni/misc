#! /bin/bash

MAX_RETRIES=10
retry_count=1

./build-scripts/start-app-dev.sh
result=$?

if [[ $result == 0 ]]; then
  ./angular-cli.sh 'ng e2e --webdriver-update false --port 56100 --serve false'
  result=$?
fi

./build-scripts/stop-app-dev.sh

exit $result
