#!/bin/bash

DIR=$(cd `dirname $0` && pwd)

pushd $DIR/../e2e
docker-compose down
popd
