package uk.gov.gsi.hmrc.cds.search.common.json;

import com.fasterxml.jackson.databind.ObjectMapper;

public final class SystemObjectMapper {
    private static ObjectMapper instance = null;

    private SystemObjectMapper() {}

    public static synchronized ObjectMapper getInstance() {
        if (instance == null) {
            instance = new ObjectMapper();
        }
        return instance;
    }

}
