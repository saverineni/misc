package uk.gov.gsi.hmrc.cds.search.common.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;

public class ErrorResponse extends EqualsHashCodeToString {

    private ErrorMessage error;

    public ErrorResponse() {
    }

    public ErrorResponse(ErrorMessage error) {
        this.error = error;
    }

    public void setError(ErrorMessage error) {
        this.error = error;
    }

    public ErrorMessage getError() {
        return error;
    }

    public static ErrorResponse of(String errorType, String message) {
        ErrorMessage errorMessage = new ErrorMessage(errorType, message);
        return new ErrorResponse(errorMessage);
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class ErrorMessage implements Serializable {
        @JsonInclude(JsonInclude.Include.NON_NULL)
        private String type;
        private String message;

        public ErrorMessage() {
        }

        public ErrorMessage(String type, String message) {
            this.type = type;
            this.message = message;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }

}
