package uk.gov.gsi.hmrc.cds.search.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.ldap.userdetails.InetOrgPersonContextMapper;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import uk.gov.gsi.hmrc.cds.search.security.HmrcActiveDirectoryLdapAuthenticationProvider;

@Configuration
@Profile({"dev", "automationdev","qa","demo1", "pre_prod", "prod"})
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Value("${app.ad-domain}")
    private String adDomain;

    @Value("${app.ad-server}")
    private String adServer;

    @Value("${app.ldap-search-base}")
    private String ldapSearchBase;

    @Value("${app.ldap-search-filter}")
    private String ldapSearchFilter;

    @Autowired
    protected void configureGlobalSecurity(AuthenticationManagerBuilder auth) throws Exception {
        auth
                .authenticationProvider(activeDirectoryLdapAuthenticationProvider());

    }

    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        httpSecurity
                .authorizeRequests()
                .antMatchers("/login").permitAll()
                .antMatchers("/api/application.wadl").permitAll()
                .antMatchers("/api/declaration/**").hasAuthority("RES-GoogleApps_HMRC-US")
                .antMatchers("/api/application.doc").hasAuthority("RES-GSIBROWSING-STANDARD-GS")
                .anyRequest().authenticated()
                .and()
                .csrf().disable()
                .formLogin()
                .and()
                .logout().logoutRequestMatcher(new AntPathRequestMatcher("/logout", HttpMethod.GET.name()));
    }

    @Bean
    public HmrcActiveDirectoryLdapAuthenticationProvider activeDirectoryLdapAuthenticationProvider() {
        HmrcActiveDirectoryLdapAuthenticationProvider provider = new HmrcActiveDirectoryLdapAuthenticationProvider(adDomain, adServer, ldapSearchBase);
        provider.setSearchFilter(ldapSearchFilter);
        provider.setUserDetailsContextMapper(new InetOrgPersonContextMapper());
        return provider;
    }
}
