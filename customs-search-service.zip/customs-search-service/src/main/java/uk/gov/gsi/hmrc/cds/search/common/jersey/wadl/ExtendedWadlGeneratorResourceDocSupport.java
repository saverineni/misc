package uk.gov.gsi.hmrc.cds.search.common.jersey.wadl;


import com.sun.research.ws.wadl.Representation;
import com.sun.research.ws.wadl.Response;
import org.glassfish.jersey.server.model.Resource;
import org.glassfish.jersey.server.model.ResourceMethod;
import org.glassfish.jersey.server.wadl.internal.generators.resourcedoc.WadlGeneratorResourceDocSupport;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ext.MessageBodyReader;
import javax.ws.rs.ext.MessageBodyWriter;
import java.util.*;

import static java.util.Arrays.asList;
import static java.util.stream.Collectors.toSet;
import static javax.ws.rs.core.Response.Status.Family.SUCCESSFUL;
import static javax.ws.rs.core.Response.Status.fromStatusCode;

public class ExtendedWadlGeneratorResourceDocSupport extends WadlGeneratorResourceDocSupport {
    private Map<String, Class<MessageBodyWriter>> vendorWriters = new HashMap<>();
    private Map<String, Class<MessageBodyReader>> readers = new HashMap<>();

    public void setVendorWriters(Collection<Class<MessageBodyWriter>> writers) {
        writers.forEach(writer -> {
            Set<String> vendorMediaTypes = asList(writer.getAnnotation(Produces.class).value()).stream().filter(mediaType -> mediaType.matches(".*/vnd.*")).collect(toSet());
            vendorMediaTypes.forEach(vendorMediaType -> vendorWriters.put(vendorMediaType, writer));
        });
    }

    public void setReaders(Collection<Class<MessageBodyReader>> readers) {
        readers.forEach(reader -> {
            Set<String> mediaTypes = asList(reader.getAnnotation(Consumes.class).value()).stream().filter(mediaType -> mediaType.matches(".*/vnd.*")).collect(toSet());
            mediaTypes.forEach(vendorMediaType -> this.readers.put(vendorMediaType, reader));
        });
    }

    @Override
    public List<Response> createResponses(Resource resource, ResourceMethod method) {
        List<Response> responses = super.createResponses(resource, method);

        for (Response response : responses) {
            if (response.getStatus().isEmpty() || containsSuccessResponse(response)) {
                List<Representation> successRepresentations = createSuccessRepresentations(method);

                consolidateRepresentations(response, successRepresentations);
                response.getRepresentation().addAll(successRepresentations);
            }
        }

        return responses;
    }

    private boolean containsSuccessResponse(Response response) {
        return response.getStatus().stream().anyMatch(o -> fromStatusCode(o.intValue()).getFamily().equals(SUCCESSFUL));
    }

    private List<Representation> createSuccessRepresentations(ResourceMethod method) {
        List<Representation> successRepresentations = new ArrayList<>();

        Set<String> mediaTypes = method.getProducedTypes().stream().map(MediaType::toString).collect(toSet());
        Set<Class<MessageBodyWriter>> writers = mediaTypes.stream().filter(vendorWriters::containsKey).map(vendorWriters::get).collect(toSet());

        for (String mediaType : mediaTypes) {
            Representation representation = new Representation();
            representation.setMediaType(mediaType);
            representation.setId(lookupSchema(mediaType, writers));

            successRepresentations.add(representation);
        }

        return successRepresentations;
    }

    private void consolidateRepresentations(Response response, List<Representation> successRepresentations) {
        List<Representation> representations = response.getRepresentation();

        if (!representations.isEmpty() && !representations.get(0).getDoc().isEmpty()) {
            successRepresentations.forEach(successRepresentation -> successRepresentation.getDoc().addAll(representations.get(0).getDoc()));
        }

        representations.clear();
    }

    private String lookupSchema(String mediaType, Set<Class<MessageBodyWriter>> writers) {
        Optional<Class<MessageBodyWriter>> provider = writers.stream().filter(writer -> asList(writer.getAnnotation(Produces.class).value()).contains(mediaType)).findAny();
        return schemaFor(provider, Schema.class);
    }

    private static String schemaFor(Optional<Class<MessageBodyWriter>> provider, Class<Schema> annotationClass) {
        if (provider.isPresent() && provider.get().isAnnotationPresent(annotationClass)) {
            return provider.get().getAnnotation(annotationClass).value();
        }

        return null;
    }

    @Override
    public Representation createRequestRepresentation(Resource r, ResourceMethod m, MediaType mediaType) {
        Representation representation = super.createRequestRepresentation(r, m, mediaType);

        Class<MessageBodyReader> reader = readers.get(mediaType.toString());
        if (reader != null) {
            representation.setId(reader.getAnnotation(Schema.class).value());
        }

        return representation;
    }
}