package uk.gov.gsi.hmrc.cds.search.common.jersey.providers;

import uk.gov.gsi.hmrc.cds.search.common.json.SystemObjectMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;

@Provider
public class ObjectMapperContextResolver implements ContextResolver<ObjectMapper> {

    private final ObjectMapper objectMapper;

    public ObjectMapperContextResolver() {
        objectMapper = SystemObjectMapper.getInstance();
    }

    @Override
    public ObjectMapper getContext(Class<?> type) {
        return objectMapper;
    }
}
