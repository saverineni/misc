package uk.gov.gsi.hmrc.cds.search.common.exception;

public class MessageBodyReaderValidationException extends RuntimeException {
    public MessageBodyReaderValidationException(String s) {
        super(s);
    }

    public MessageBodyReaderValidationException(String s, Exception e) {
        super(s, e);
    }
}
