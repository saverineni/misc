package uk.gov.gsi.hmrc.cds.search.api.dto.response.header;

import com.google.common.collect.Lists;
import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.common.domain.EqualsHashCodeToString;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.Declaration;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.DeclarationLine;

import java.util.List;

@Data
@Builder
public class DeclarationHeaderResponse extends EqualsHashCodeToString {
    private String entry_reference;
    private String entry_number;
    private String entry_date;
    private String epu_number;
    private String entry_type;
    private String route;
    private String goods_location;
    private String dispatch_country;
    private String consignee_nad_name;
    private String consignee_nad_postcode;
    private String importer_trader_turn;

    public static DeclarationHeaderResponse of(Declaration declaration) {
        return DeclarationHeaderResponse.builder()
                .entry_reference(declaration.getEntry_reference())
                .entry_number(declaration.getEntry_number())
                .entry_date(declaration.getEntry_date())
                .epu_number(declaration.getEpu_number())
                .entry_type(declaration.getEntry_type())
                .route(declaration.getRoute())
                .goods_location(declaration.getGoods_location())
                .dispatch_country(declaration.getDispatch_country())
                .consignee_nad_name(declaration.getConsignee_nad_name())
                .consignee_nad_postcode(declaration.getConsignee_nad_postcode())
                .importer_trader_turn(declaration.getImporter_trader_turn())
                .build();
    }
}
