package uk.gov.gsi.hmrc.cds.search.config;

import org.glassfish.jersey.server.ServerProperties;
import org.glassfish.jersey.servlet.ServletContainer;
import org.glassfish.jersey.servlet.ServletProperties;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ServletConfig {

    @Value("${spring.jersey.application-path:/}")
    private String apiPath;

    @Bean
    public ServletRegistrationBean jerseyServlet() {
        ServletRegistrationBean registration = new ServletRegistrationBean(new ServletContainer(), String.format("%s/*", apiPath));
        registration.addInitParameter(ServletProperties.JAXRS_APPLICATION_CLASS, JerseyConfig.class.getName());
        registration.addInitParameter(ServerProperties.BV_SEND_ERROR_IN_RESPONSE, Boolean.TRUE.toString());
        registration.addInitParameter(ServerProperties.WADL_FEATURE_DISABLE, Boolean.FALSE.toString());

        // TODO - add ClientProperties - https://jersey.java.net/documentation/latest/appendix-properties.html
        return registration;
    }

}
