package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import com.google.common.collect.Lists;
import org.springframework.stereotype.Service;
import uk.gov.gsi.hmrc.cds.search.common.exception.DeclarationNotFoundException;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class SearchService {

    public Declaration fetchDeclarationByID(String declarationId) {
        Declaration declaration = null;
        switch (declarationId) {
            case "declarationId-1":
                DeclarationLine declarationLine = DeclarationLine.builder()
                        .clearance_datetime("20171207")
                        .entry_reference("declarationId-1")
                        .item_number("1")
                        .customs_procedure_code("CPC-1")
                        .origin_country(OriginCountry.builder()
                                .origin_iso_country_code_alpha_2("GB")
                                .origin_country_name("Great Britain")
                                .build())
                        .commodity(Commodity.builder()
                                .commodity_code("765432")
                                .chapter_description("WOODEN ARTICLES")
                                .heading_description("WOODEN ARTICLES")
                                .build())
                        .build();
                declaration = Declaration.builder()
                        .entry_reference("declarationId-1")
                        .entry_number("eno1")
                        .entry_date("01-12-2017")
                        .epu_number("678")
                        .entry_type("E")
                        .route("route1")
                        .goods_location("dover")
                        .dispatch_country("CA")
                        .consignee_nad_name("Trader1")
                        .consignee_nad_postcode("SW12BS")
                        .importer_trader_turn("12345")
                        .lines(Lists.newArrayList(declarationLine)
                        )
                        .build();
                break;
            default:
                throw new DeclarationNotFoundException("DeclarationId not found");
        }
        return declaration;
    }
}
