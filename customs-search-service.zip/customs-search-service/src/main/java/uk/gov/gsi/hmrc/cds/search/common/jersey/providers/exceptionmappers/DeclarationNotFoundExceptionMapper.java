package uk.gov.gsi.hmrc.cds.search.common.jersey.providers.exceptionmappers;

import uk.gov.gsi.hmrc.cds.search.common.domain.ErrorResponse;
import uk.gov.gsi.hmrc.cds.search.common.exception.DeclarationNotFoundException;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.util.Arrays;

@Provider
public class DeclarationNotFoundExceptionMapper implements ExceptionMapper<DeclarationNotFoundException>{

    @Override
    public Response toResponse(DeclarationNotFoundException exception) {
        return Response.
                status(Response.Status.NOT_FOUND).
                entity(Arrays.asList(ErrorResponse.of(null, exception.getMessage()))).
                build();
    }
}
