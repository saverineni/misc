package uk.gov.gsi.hmrc.cds.search.common.jersey.providers.writers.v1;

import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationResponse;
import uk.gov.gsi.hmrc.cds.search.common.jersey.wadl.Schema;
import uk.gov.gsi.hmrc.cds.search.common.json.Views;

import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyWriter;
import javax.ws.rs.ext.Provider;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import static java.nio.charset.StandardCharsets.UTF_8;
import static uk.gov.gsi.hmrc.cds.search.common.jersey.providers.writers.v1.DeclarationMessageBodyWriter.JSON_SCHEMA_PATH;
import static uk.gov.gsi.hmrc.cds.search.common.jersey.providers.writers.v1.DeclarationMessageBodyWriter.V1_DECLARATION_MEDIA_TYPE;

@Provider
@Schema(JSON_SCHEMA_PATH)
@Produces(V1_DECLARATION_MEDIA_TYPE)
public class DeclarationMessageBodyWriter implements MessageBodyWriter<DeclarationResponse>{
    protected static final String JSON_SCHEMA_PATH = "schema/v1/declaration-response.json";
    protected static final String V1_DECLARATION_MEDIA_TYPE = "application/vnd.hmrc.cds.v1.declaration+json";

    @Override
    public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {

        if (type == DeclarationResponse.class
                && mediaType.getType().equals("application")
                && mediaType.getSubtype().matches("vnd\\.hmrc\\.cds\\.v1\\.declaration\\+json")) {
            return true;
        }
        return false;
    }

    @Override
    public long getSize(DeclarationResponse declarationResponse, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
        return -1;
    }

    @Override
    public void writeTo(DeclarationResponse declarationResponse, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream) throws IOException, WebApplicationException {
        entityStream.write(declarationResponse.toJSON(Views.V1.class).getBytes(UTF_8));
    }
}
