package uk.gov.gsi.hmrc.cds.search.common.json;

public class Views {
    public static class V1{}
    public static class V2{}
    public static class V2withV1 extends V1 {}
}
