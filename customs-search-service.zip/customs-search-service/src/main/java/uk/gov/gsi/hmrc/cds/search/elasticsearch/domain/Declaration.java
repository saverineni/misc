package uk.gov.gsi.hmrc.cds.search.elasticsearch.domain;

import com.google.common.collect.Lists;
import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.common.domain.EqualsHashCodeToString;

import java.util.List;

@Data
@Builder
public class Declaration extends EqualsHashCodeToString {
    private String entry_reference;
    private String entry_number;
    private String entry_date;
    private String epu_number;
    private String entry_type;
    private String route;
    private String goods_location;
    private String dispatch_country;
    private String consignee_nad_name;
    private String consignee_nad_postcode;
    private String importer_trader_turn;
    private List<DeclarationLine> lines = Lists.newArrayList();

}
