package uk.gov.gsi.hmrc.cds.search.elasticsearch.domain;

import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.common.domain.EqualsHashCodeToString;

@Data
@Builder
public class DeclarationLine extends EqualsHashCodeToString {
    private String entry_reference;
    private String item_number;
    private String clearance_datetime;
    private OriginCountry origin_country;
    private String customs_procedure_code;
    private Commodity commodity;

}
