package uk.gov.gsi.hmrc.cds.search.api.dto.response.line;

import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.common.domain.EqualsHashCodeToString;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.OriginCountry;

@Data
@Builder
public class OriginCountryResponse extends EqualsHashCodeToString {
    private String origin_iso_country_code_alpha_2;
    private String origin_country_name;

    public static OriginCountryResponse of(OriginCountry originCountry) {
        return OriginCountryResponse.builder()
                .origin_iso_country_code_alpha_2(originCountry.getOrigin_iso_country_code_alpha_2())
                .origin_country_name(originCountry.getOrigin_country_name())
                .build();
    }
}
