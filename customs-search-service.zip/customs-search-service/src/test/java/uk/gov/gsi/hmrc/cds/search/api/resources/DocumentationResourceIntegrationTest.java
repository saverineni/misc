package uk.gov.gsi.hmrc.cds.search.api.resources;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.authentication.FormAuthConfig;
import org.apache.http.HttpStatus;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import uk.gov.gsi.hmrc.cds.search.run.CustomsSearchServiceApplication;

import static com.jayway.restassured.RestAssured.form;
import static org.hamcrest.Matchers.containsString;


@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest(
        classes = CustomsSearchServiceApplication.class,
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT
)
public class DocumentationResourceIntegrationTest {

    private static final String API_PATH = "/api";

    @Value("${local.server.port}")
    private int port;

    @Before
    public void setup() {
        RestAssured.port = this.port;
        RestAssured.authentication = form("dev", "dev", new FormAuthConfig("/login", "username", "password"));
    }

    @Test
    public void shouldGetApplicationDocumentAsHTMLAndWithStatus_OK() throws Exception {
        RestAssured.
            given().
                accept("text/html").
            expect().
                body(containsString("Custom Search Service API"), containsString("application/vnd.hmrc.cds.v1.declaration+json")).
           when()
                .get(String.format("%s/application.doc", API_PATH)).
            then().
                statusCode(HttpStatus.SC_OK);
    }

}