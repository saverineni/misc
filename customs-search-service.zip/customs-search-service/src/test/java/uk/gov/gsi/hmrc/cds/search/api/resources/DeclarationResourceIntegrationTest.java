package uk.gov.gsi.hmrc.cds.search.api.resources;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.authentication.FormAuthConfig;
import com.jayway.restassured.http.ContentType;
import org.apache.http.HttpStatus;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import uk.gov.gsi.hmrc.cds.search.run.CustomsSearchServiceApplication;

import static com.jayway.restassured.RestAssured.form;
import static org.hamcrest.Matchers.equalTo;


@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest(
        classes = CustomsSearchServiceApplication.class,
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT
)
public class DeclarationResourceIntegrationTest {

    private static final String API_PATH = "/api";
    private static final String V1_DECLARATION_MEDIA_TYPE = "application/vnd.hmrc.cds.v1.declaration+json";

    @Value("${local.server.port}")
    private int port;

    @Before
    public void setup() {
        RestAssured.port = this.port;
        RestAssured.authentication = form("superdev", "superdev", new FormAuthConfig("/login", "username", "password"));
    }

    @Test
    public void shouldGetErrorResponse_whenDeclarationNotFoundExceptionThrown() throws Exception {
        RestAssured.
                given()
                    .contentType(ContentType.JSON)
                    .queryParam("declarationId", "declarationId-notpresent")
                    .accept(V1_DECLARATION_MEDIA_TYPE)
                .expect()
                    .body(equalTo("[{\"error\":{\"message\":\"DeclarationId not found\"}}]"))
                .when()
                    .get(String.format("%s/declaration", API_PATH))
                .then()
                    .statusCode(HttpStatus.SC_NOT_FOUND);
    }

    @Test
    public void shouldGetErrorResponseWithStatus_BAD_REQUEST_whenDeclarationIdIsMissing() throws Exception {
        RestAssured.
                given()
                    .contentType(ContentType.JSON)
                    .accept(V1_DECLARATION_MEDIA_TYPE)
                    .queryParam("declarationId", "")
                .expect()
                    .body(equalTo("[{\"error\":{\"message\":\"declarationId is mandatory\"}}]"))
                .when()
                    .get(String.format("%s/declaration", API_PATH))
                .then()
                    .statusCode(HttpStatus.SC_BAD_REQUEST);
    }

    @Test
    public void givenValidDeclarationId_shouldGetV1DeclarationDataWithStatusOK() throws Exception {

        RestAssured
                .given()
                    .contentType(ContentType.JSON)
                    .queryParam("declarationId", "declarationId-1")
                    .accept(V1_DECLARATION_MEDIA_TYPE)
                .when()
                    .get(String.format("%s/declaration", API_PATH))
                .then()
                    .statusCode(HttpStatus.SC_OK)
                    .body(equalTo("{\"header\":{\"entry_reference\":\"declarationId-1\",\"entry_number\":\"eno1\",\"entry_date\":\"01-12-2017\",\"epu_number\":\"678\",\"entry_type\":\"E\",\"route\":\"route1\",\"goods_location\":\"dover\",\"dispatch_country\":\"CA\",\"consignee_nad_name\":\"Trader1\",\"consignee_nad_postcode\":\"SW12BS\",\"importer_trader_turn\":\"12345\"},\"lines\":[{\"entry_reference\":\"declarationId-1\",\"item_number\":\"1\",\"clearance_datetime\":\"20171207\",\"origin_country\":{\"origin_iso_country_code_alpha_2\":\"GB\",\"origin_country_name\":\"Great Britain\"},\"customs_procedure_code\":\"CPC-1\",\"commodity\":{\"commodity_code\":\"765432\",\"chapter_description\":\"WOODEN ARTICLES\",\"heading_description\":\"WOODEN ARTICLES\"}}]}"));

    }

    @Test
    public void givenValidDeclarationId_shouldGetForbiddenStatus() throws Exception {

        RestAssured
                .given()
                    .contentType(ContentType.JSON)
                    .queryParam("declarationId", "declarationId-1")
                    .accept(V1_DECLARATION_MEDIA_TYPE)
                .when()
                    .with()
                        .auth()
                        .form("dev", "dev", new FormAuthConfig("/login", "username", "password"))
                    .get(String.format("%s/declaration", API_PATH))
                .then()
                    .statusCode(HttpStatus.SC_FORBIDDEN);
    }
}