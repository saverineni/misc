package uk.gov.gsi.hmrc.cds.search.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@Profile({"test"})
@EnableWebSecurity
public class TestSecurityConfig extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {

        httpSecurity
                .authorizeRequests()
                .antMatchers("/login").permitAll()
                .antMatchers("/api/application.wadl").permitAll()
                .antMatchers("/api/declaration/**").hasAuthority("ROLE_SUPERUSER")
                .antMatchers("/api/application.doc").hasAuthority("ROLE_USER")
                .anyRequest().authenticated()
                .and()
                .csrf()
                .disable()
                .formLogin();
    }

    @Autowired
    public void configureGlobalSecurity(AuthenticationManagerBuilder auth) throws Exception {
        auth
                .inMemoryAuthentication().withUser("dev").password("dev").roles("USER");
        auth
                .inMemoryAuthentication().withUser("superdev").password("superdev").roles("USER","SUPERUSER");

    }

}