package uk.gov.gsi.hmrc.cds.search;

import org.apache.commons.io.FileUtils;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.utils.FileLoaderUtils;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ContractsValidatorTest {

    static final String MAPPINGS_FILE = "mapping.json";

    @Test
    public void validateSettings()  {
        String fileContent = FileLoaderUtils.getMappingsFileContent();
        ContractsValidator.validateSettings(fileContent);

    }
}
