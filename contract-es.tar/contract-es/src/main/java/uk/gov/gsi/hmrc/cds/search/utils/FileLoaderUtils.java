package uk.gov.gsi.hmrc.cds.search.utils;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileLoaderUtils {

    public static final String MAPPINGS_FILE = "mapping.json";

    public static String getMappingsFileContent() {
        String response = "";
        try {
            Path path = Paths.get(FileLoaderUtils.class.getClassLoader().getResource(MAPPINGS_FILE).toURI());
            response = org.apache.commons.io.FileUtils.readFileToString(path.toFile(), "UTF-8");
        } catch (IOException | URISyntaxException e) {
            e.printStackTrace();
        }
        return response;
    }
}

