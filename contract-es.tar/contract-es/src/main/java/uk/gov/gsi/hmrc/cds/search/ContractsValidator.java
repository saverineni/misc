package uk.gov.gsi.hmrc.cds.search;

import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.javanet.NetHttpTransport;
import uk.gov.gsi.hmrc.cds.search.utils.FileLoaderUtils;

import java.io.IOException;

class ContractsValidator {

    private static String mappingsUrl;
    private static String settingsUrl;
    public static void main(String args[]) throws IOException {
        String elasticSearchUrl = args[0];
        settingsUrl = elasticSearchUrl + "/customs_search_service/_settings";
        mappingsUrl = elasticSearchUrl + "/customs_search_service/_mappings";
        validateContracts(settingsUrl);
    }

    static void validateContracts(String settingsUrl) throws IOException {
        HttpRequestFactory requestFactory = new NetHttpTransport().createRequestFactory();
        HttpRequest settingsRequest = requestFactory.buildGetRequest(new GenericUrl(settingsUrl));
        String actualJsonSettingsResponse = settingsRequest.execute().parseAsString();

        String expectedJsonSettingsResponse = loadSettingContents();

        validateSettingsContract(actualJsonSettingsResponse);
    }

    public static void validateSettingsContract(String actualJsonSettingsResponse) {
        System.out.println(actualJsonSettingsResponse);
    }

    private static String loadSettingContents() throws IOException {
        String fileContent = FileLoaderUtils.getMappingsFileContent();
        Gson gson = new GsonBuilder().create();
//        JsonObject body = gson.fromJson(json, JsonObject.class);
//        parser.parse(fileContent);

        return "";
    }


}
