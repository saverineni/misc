package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLineTaxLine;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables.LANDING_LINE_TAX_LINE;

@Component
public class LandingLineTaxLineReader extends TableReader {

    public Dataset<LandingLineTaxLine> landingLineTaxLineDataset() {
        String dataFilePath = String.format("%s/%s", LANDING_LINE_TAX_LINE.tableName(), datafileRelativePath);
        String landingLineTaxLineFilePath = String.format("%s/%s", landingHDFSAbsoluteBasePath, dataFilePath);

        JavaRDD<LandingLineTaxLine> landingLineTaxLineJavaRDD = javaSparkContext
                .textFile(landingLineTaxLineFilePath)
                .map(LandingLineTaxLine::parse);
        return sparkSession.createDataset(landingLineTaxLineJavaRDD.rdd(), LandingLineTaxLine.landingLineTaxLineEncoder);

    }
}
