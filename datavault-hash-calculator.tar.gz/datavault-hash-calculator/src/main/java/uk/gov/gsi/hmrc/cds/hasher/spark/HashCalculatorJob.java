package uk.gov.gsi.hmrc.cds.hasher.spark;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.helper.HiveContextAwareExecutor;

@Component
public class HashCalculatorJob {

    @Autowired
    private LandingHashTableGenerator landingHashTableGenerator;
    @Autowired
    private DimensionHashTableGenerator dimensionHashTableGenerator;

    public void persistHashedTables() {
        landingHashTableGenerator.persistLandingHashTables();
        dimensionHashTableGenerator.persistDimensionHashTable();
    }

}
