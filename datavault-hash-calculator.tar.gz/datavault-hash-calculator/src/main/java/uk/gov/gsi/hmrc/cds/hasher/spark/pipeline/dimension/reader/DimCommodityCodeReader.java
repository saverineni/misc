package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.reader;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCommodityCode;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.DimensionTables.DIM_COMMODITY_CODE;

@Component
public class DimCommodityCodeReader extends TableReader {

    public Dataset<DimCommodityCode> dimCommodityCodeDataset() {
        String dataFilePath = String.format("%s/%s", DIM_COMMODITY_CODE.tableName(), datafileRelativePath);
        String dimCommodityCodeFilePath = String.format("%s/%s", dimensionHDFSAbsoluteBasePath, dataFilePath);

        JavaRDD<DimCommodityCode> dimCommodityCodeJavaRDD = javaSparkContext
                .textFile(dimCommodityCodeFilePath)
                .map(DimCommodityCode::parse);
        return sparkSession.createDataset(dimCommodityCodeJavaRDD.rdd(), DimCommodityCode.dimCommodityCodeEncoder);

    }
}
