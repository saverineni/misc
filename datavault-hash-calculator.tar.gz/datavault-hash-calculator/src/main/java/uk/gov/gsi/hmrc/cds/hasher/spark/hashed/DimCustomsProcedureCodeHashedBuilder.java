package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.DimensionTables;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCommodityCode;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCommodityCodeHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCustomsProcedureCode;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCustomsProcedureCodeHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.reader.DimCustomsProcedureCodeReader;

@Component
public class DimCustomsProcedureCodeHashedBuilder extends BaseHashedBuilder{

    @Autowired
    private DimCustomsProcedureCodeReader dimCustomsProcedureCodeReader;

    public Dataset<DimCustomsProcedureCodeHashed> build() {

        Dataset<DimCustomsProcedureCode> dimCommodityCodeDataset = dimCustomsProcedureCodeReader.dimCustomsProcedureCodeDataset();

        return dimCommodityCodeDataset.map((MapFunction<DimCustomsProcedureCode, DimCustomsProcedureCodeHashed>) DimCustomsProcedureCodeHashed::mapper, DimCustomsProcedureCodeHashed.dimCustomsProcedureCodeHashedEncoder);
    }

    public void saveAndCreateExternalTable(Dataset<DimCustomsProcedureCodeHashed> dimCommodityCodeHashedDataset) {
        String tableName = DimensionTables.DIM_CUSTOMS_PROCEDURE_CODE_HASHED.tableName();
        saveDimensionDatasetAsTable(dimCommodityCodeHashedDataset, tableName);
    }
}
