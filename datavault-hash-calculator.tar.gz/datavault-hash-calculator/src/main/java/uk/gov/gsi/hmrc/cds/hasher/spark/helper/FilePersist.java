package uk.gov.gsi.hmrc.cds.hasher.spark.helper;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.SaveMode;

public final class FilePersist {
    static String DEFAULT_FILE_DELIMITER = "\u0001";

    public static void asDelimitedFile(Dataset dataset, String filePath) {
        dataset
            .write()
            .format("com.databricks.spark.csv")
            .mode(SaveMode.Overwrite)
            .option("delimiter", DEFAULT_FILE_DELIMITER)
            .save(filePath);
    }
}
