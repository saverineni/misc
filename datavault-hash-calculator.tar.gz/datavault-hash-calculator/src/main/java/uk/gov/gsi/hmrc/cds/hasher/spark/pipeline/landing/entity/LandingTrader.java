package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity;

import com.google.common.collect.Lists;
import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.*;

@Data
@Builder
public class LandingTrader implements Serializable, BaseEntity {

    private String source;
    private String ingestion_date;
    private String turn;
    private String fedate;
    private String name;
    private String simplified_procedure_authorisations;
    private String trader_name_abbreviated;
    private String currentind;

    public static final Encoder<LandingTrader> landingTraderEncoder = Encoders.bean(LandingTrader.class);

    public static String[] structFields = toArray(
            Lists.newArrayList(
                    "source",
                    "ingestion_date",
                    "turn",
                    "fedate",
                    "name",
                    "simplified_procedure_authorisations",
                    "trader_name_abbreviated",
                    "currentind"
            )
    );

    public static LandingTrader parse(String line) {
        List<String> columns = parseLine(line);

        return LandingTrader.builder()
                .source(valueAt(columns, 0))
                .ingestion_date(valueAt(columns, 1))
                .turn(valueAt(columns, 2))
                .fedate(valueAt(columns, 3))
                .name(valueAt(columns, 4))
                .simplified_procedure_authorisations(valueAt(columns, 5))
                .trader_name_abbreviated(valueAt(columns, 6))
                .currentind(valueAt(columns, 7))
                .build();
    }
}
