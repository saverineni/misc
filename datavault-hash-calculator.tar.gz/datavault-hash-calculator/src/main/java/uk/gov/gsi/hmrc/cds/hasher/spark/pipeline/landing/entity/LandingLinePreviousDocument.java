package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity;

import com.google.common.collect.Lists;
import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.*;

@Data
@Builder
public class LandingLinePreviousDocument implements Serializable, BaseEntity {

    private String source;
    private String ingestion_date;
    private String item_number;
    private String previous_document_sequence_number;
    private String previous_document_reference;
    private String entry_reference;

    public static final Encoder<LandingLinePreviousDocument> landingLinePreviousDocumentEncoder = Encoders.bean(LandingLinePreviousDocument.class);

    public static String[] structFields = toArray(
            Lists.newArrayList(
                    "source",
                    "ingestion_date",
                    "item_number",
                    "previous_document_sequence_number",
                    "previous_document_reference",
                    "entry_reference"
            )
    );

    public static LandingLinePreviousDocument parse(String line) {
        List<String> columns = parseLine(line);

        return LandingLinePreviousDocument.builder()
                .source(valueAt(columns, 0))
                .ingestion_date(valueAt(columns, 1))
                .item_number(valueAt(columns, 2))
                .previous_document_sequence_number(valueAt(columns, 3))
                .previous_document_reference(valueAt(columns, 4))
                .entry_reference(valueAt(columns, 5))
                .build();
    }
}
