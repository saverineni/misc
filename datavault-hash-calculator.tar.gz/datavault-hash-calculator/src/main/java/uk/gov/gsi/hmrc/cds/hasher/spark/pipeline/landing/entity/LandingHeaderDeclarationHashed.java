package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity;

import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.hasher.spark.helper.MD5Hasher.md5HashOf;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.parseLine;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.valueAt;

@Data
@Builder
public class LandingHeaderDeclarationHashed implements Serializable, BaseEntity {

    private String source;
    private String ingestion_date;
    private String entry_number;
    private String entry_date;
    private String epu_number;
    private String entry_type;
    private String declaration_method;
    private String total_excise;
    private String importer_turn;
    private String declarant_turn;
    private String declarant_representative_turn;
    private String consignee_aeo_certificate_type_code;
    private String declarant_aeo_certificate_type_code;
    private String route;
    private String declaration_import_export_indicator;
    private String generation_number;
    private String exporter_turn;
    private String destination_country_code;
    private String import_clearance_status;
    private String consignor_aeo_certificate_type_code;
    private String header_statistical_value;
    private String goods_departure_datetime;
    private String customs_value;
    private String total_duty;
    private String total_vat;
    private String net_mass_total;
    private String goods_location;
    private String acceptance_date;
    private String importer_turn_country_code;
    private String place_of_unloading_code;
    private String first_deferment_approval_num;
    private String first_deferment_approval_num_prefix;
    private String declaration_ucr;
    private String item_count;
    private String master_ucr;
    private String paying_agent_turn;
    private String place_of_loading_code;
    private String session_num;
    private String session_role_name;
    private String status_of_entry;
    private String transport_country;
    private String transport_id;
    private String transport_mode_code;
    private String dispatch_country;
    private String consignor_turn;
    private String consignor_turn_country_code;
    private String consignor_nad_name;
    private String consignee_nad_name;
    private String consignee_nad_postcode;
    private String declarant_nad_name;
    private String customs_check_code;
    private String profile_id;
    private String freight_currency;
    private String invoice_currency;
    private String invoice_total_declared;
    private String entry_reference;
    private String hub_declaration;
    private String sat_declaration;
    private String link_declaration_consignor_trader;
    private String link_declaration_consignor_trader_hub_trader;
    private String link_declaration_declarant_trader;
    private String link_declaration_declarant_trader_hub_trader;
    private String link_declaration_destination_country;
    private String link_declaration_destination_country_hub_country;
    private String link_declaration_exporter_trader;
    private String link_declaration_exporter_trader_hub_trader;
    private String link_declaration_freight_currency;
    private String link_declaration_freight_currency_hub_currency;
    private String link_declaration_importer_trader;
    private String link_declaration_importer_trader_hub_trader;
    private String link_declaration_invoice_currency;
    private String link_declaration_invoice_currency_hub_currency;
    private String link_declaration_paying_agent_trader;
    private String link_declaration_paying_agent_trader_hub_trader;
    private String link_declaration_transport_country;
    private String link_declaration_transport_country_hub_country;

    public static final Encoder<LandingHeaderDeclarationHashed> landingHeaderDeclarationHashedEncoder = Encoders.bean(LandingHeaderDeclarationHashed.class);

    public static LandingHeaderDeclarationHashed mapper(LandingHeaderDeclaration landingHeaderDeclaration) {

        return LandingHeaderDeclarationHashed.builder()
                .source(landingHeaderDeclaration.getSource())
                .ingestion_date(landingHeaderDeclaration.getIngestion_date())
                .entry_number(landingHeaderDeclaration.getEntry_number())
                .entry_date(landingHeaderDeclaration.getEntry_date())
                .epu_number(landingHeaderDeclaration.getEpu_number())
                .entry_type(landingHeaderDeclaration.getEntry_type())
                .declaration_method(landingHeaderDeclaration.getDeclaration_method())
                .total_excise(landingHeaderDeclaration.getTotal_excise())
                .importer_turn(landingHeaderDeclaration.getImporter_turn())
                .declarant_turn(landingHeaderDeclaration.getDeclarant_turn())
                .declarant_representative_turn(landingHeaderDeclaration.getDeclarant_representative_turn())
                .consignee_aeo_certificate_type_code(landingHeaderDeclaration.getConsignee_aeo_certificate_type_code())
                .declarant_aeo_certificate_type_code(landingHeaderDeclaration.getDeclarant_aeo_certificate_type_code())
                .route(landingHeaderDeclaration.getRoute())
                .declaration_import_export_indicator(landingHeaderDeclaration.getDeclaration_import_export_indicator())
                .generation_number(landingHeaderDeclaration.getGeneration_number())
                .exporter_turn(landingHeaderDeclaration.getExporter_turn())
                .destination_country_code(landingHeaderDeclaration.getDestination_country_code())
                .import_clearance_status(landingHeaderDeclaration.getImport_clearance_status())
                .consignor_aeo_certificate_type_code(landingHeaderDeclaration.getConsignor_aeo_certificate_type_code())
                .header_statistical_value(landingHeaderDeclaration.getHeader_statistical_value())
                .goods_departure_datetime(landingHeaderDeclaration.getGoods_departure_datetime())
                .customs_value(landingHeaderDeclaration.getCustoms_value())
                .total_duty(landingHeaderDeclaration.getTotal_duty())
                .total_vat(landingHeaderDeclaration.getTotal_vat())
                .net_mass_total(landingHeaderDeclaration.getNet_mass_total())
                .goods_location(landingHeaderDeclaration.getGoods_location())
                .acceptance_date(landingHeaderDeclaration.getAcceptance_date())
                .importer_turn_country_code(landingHeaderDeclaration.getImporter_turn_country_code())
                .place_of_unloading_code(landingHeaderDeclaration.getPlace_of_unloading_code())
                .first_deferment_approval_num(landingHeaderDeclaration.getFirst_deferment_approval_num())
                .first_deferment_approval_num_prefix(landingHeaderDeclaration.getFirst_deferment_approval_num_prefix())
                .declaration_ucr(landingHeaderDeclaration.getDeclaration_ucr())
                .item_count(landingHeaderDeclaration.getItem_count())
                .master_ucr(landingHeaderDeclaration.getMaster_ucr())
                .paying_agent_turn(landingHeaderDeclaration.getPaying_agent_turn())
                .place_of_loading_code(landingHeaderDeclaration.getPlace_of_loading_code())
                .session_num(landingHeaderDeclaration.getSession_num())
                .session_role_name(landingHeaderDeclaration.getSession_role_name())
                .status_of_entry(landingHeaderDeclaration.getStatus_of_entry())
                .transport_country(landingHeaderDeclaration.getTransport_country())
                .transport_id(landingHeaderDeclaration.getTransport_id())
                .transport_mode_code(landingHeaderDeclaration.getTransport_mode_code())
                .dispatch_country(landingHeaderDeclaration.getDispatch_country())
                .consignor_turn(landingHeaderDeclaration.getConsignor_turn())
                .consignor_turn_country_code(landingHeaderDeclaration.getConsignor_turn_country_code())
                .consignor_nad_name(landingHeaderDeclaration.getConsignor_nad_name())
                .consignee_nad_name(landingHeaderDeclaration.getConsignee_nad_name())
                .consignee_nad_postcode(landingHeaderDeclaration.getConsignee_nad_postcode())
                .declarant_nad_name(landingHeaderDeclaration.getDeclarant_nad_name())
                .customs_check_code(landingHeaderDeclaration.getCustoms_check_code())
                .profile_id(landingHeaderDeclaration.getProfile_id())
                .freight_currency(landingHeaderDeclaration.getFreight_currency())
                .invoice_currency(landingHeaderDeclaration.getInvoice_currency())
                .invoice_total_declared(landingHeaderDeclaration.getInvoice_total_declared())
                .entry_reference(landingHeaderDeclaration.getEntry_reference())
                .hub_declaration(hubDeclarationHashed(landingHeaderDeclaration))
                .sat_declaration(satDeclarationHashDifference(landingHeaderDeclaration))
                .link_declaration_consignor_trader(linkDeclarationConsignorTraderHashed(landingHeaderDeclaration))
                .link_declaration_consignor_trader_hub_trader(consignorHubTraderHashed(landingHeaderDeclaration))
                .link_declaration_declarant_trader(linkDeclarationDeclarantTraderHashed(landingHeaderDeclaration))
                .link_declaration_declarant_trader_hub_trader(declarantHubTraderHashed(landingHeaderDeclaration))
                .link_declaration_destination_country(linkDeclarationDestinationCountryHashed(landingHeaderDeclaration))
                .link_declaration_destination_country_hub_country(destinationHubCountryHashed(landingHeaderDeclaration))
                .link_declaration_exporter_trader(linkDeclarationExporterTraderHashed(landingHeaderDeclaration))
                .link_declaration_exporter_trader_hub_trader(exporterHubTraderHashed(landingHeaderDeclaration))
                .link_declaration_freight_currency(linkDeclarationFreightCurrencyHashed(landingHeaderDeclaration))
                .link_declaration_freight_currency_hub_currency(freightHubCurrencyHashed(landingHeaderDeclaration))
                .link_declaration_importer_trader(linkDeclarationImporterTraderHashed(landingHeaderDeclaration))
                .link_declaration_importer_trader_hub_trader(importerHubTraderHashed(landingHeaderDeclaration))
                .link_declaration_invoice_currency(linkDeclarationInvoiceCurrencyHashed(landingHeaderDeclaration))
                .link_declaration_invoice_currency_hub_currency(invoiceHubCurrencyHashed(landingHeaderDeclaration))
                .link_declaration_paying_agent_trader(linkDeclarationPayingAgentTraderHashed(landingHeaderDeclaration))
                .link_declaration_paying_agent_trader_hub_trader(payingAgentHubTraderHashed(landingHeaderDeclaration))
                .link_declaration_transport_country(linkDeclarationTransportCountryHashed(landingHeaderDeclaration))
                .link_declaration_transport_country_hub_country(transportHubCountryHashed(landingHeaderDeclaration))
                .build();
    }

    private static String transportHubCountryHashed(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(landingHeaderDeclaration.getTransport_country());
    }

    private static String linkDeclarationTransportCountryHashed(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(Arrays.asList(
                landingHeaderDeclaration.getEntry_reference(),
                landingHeaderDeclaration.getTransport_country()
        ));
    }

    private static String payingAgentHubTraderHashed(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(landingHeaderDeclaration.getPaying_agent_turn());
    }

    private static String linkDeclarationPayingAgentTraderHashed(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(Arrays.asList(
                landingHeaderDeclaration.getEntry_reference(),
                landingHeaderDeclaration.getPaying_agent_turn()
        ));
    }

    private static String importerHubTraderHashed(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(landingHeaderDeclaration.getImporter_turn());
    }

    private static String linkDeclarationImporterTraderHashed(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(Arrays.asList(
                landingHeaderDeclaration.getEntry_reference(),
                landingHeaderDeclaration.getImporter_turn()
        ));
    }

    private static String exporterHubTraderHashed(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(landingHeaderDeclaration.getExporter_turn());
    }

    private static String linkDeclarationExporterTraderHashed(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(Arrays.asList(
                landingHeaderDeclaration.getEntry_reference(),
                landingHeaderDeclaration.getExporter_turn()
        ));
    }

    private static String destinationHubCountryHashed(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(landingHeaderDeclaration.getDestination_country_code());
    }

    private static String linkDeclarationDestinationCountryHashed(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(Arrays.asList(
                landingHeaderDeclaration.getEntry_reference(),
                landingHeaderDeclaration.getDestination_country_code()
        ));
    }

    private static String declarantHubTraderHashed(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(landingHeaderDeclaration.getDeclarant_turn());
    }

    private static String linkDeclarationDeclarantTraderHashed(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(Arrays.asList(
                landingHeaderDeclaration.getEntry_reference(),
                landingHeaderDeclaration.getDeclarant_turn()
        ));
    }

    private static String consignorHubTraderHashed(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(landingHeaderDeclaration.getConsignor_turn());
    }

    private static String linkDeclarationConsignorTraderHashed(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(Arrays.asList(
                landingHeaderDeclaration.getEntry_reference(),
                landingHeaderDeclaration.getConsignor_turn()
        ));
    }

    private static String invoiceHubCurrencyHashed(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(landingHeaderDeclaration.getInvoice_currency());
    }

    private static String linkDeclarationInvoiceCurrencyHashed(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(Arrays.asList(
                landingHeaderDeclaration.getEntry_reference(),
                landingHeaderDeclaration.getInvoice_currency()
        ));
    }

    private static String freightHubCurrencyHashed(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(landingHeaderDeclaration.getFreight_currency());
    }

    private static String linkDeclarationFreightCurrencyHashed(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(Arrays.asList(
                landingHeaderDeclaration.getEntry_reference(),
                landingHeaderDeclaration.getFreight_currency()
        ));
    }

    public static String hubDeclarationHashed(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(landingHeaderDeclaration.getEntry_reference());
    }

    public static String satDeclarationHashDifference(LandingHeaderDeclaration landingHeaderDeclaration) {
        return md5HashOf(Arrays.asList(
                landingHeaderDeclaration.getEntry_number(),
                landingHeaderDeclaration.getEntry_date(),
                landingHeaderDeclaration.getEpu_number(),
                landingHeaderDeclaration.getEntry_type(),
                landingHeaderDeclaration.getDeclaration_method(),
                landingHeaderDeclaration.getTotal_excise(),
                landingHeaderDeclaration.getDeclarant_representative_turn(),
                landingHeaderDeclaration.getConsignee_aeo_certificate_type_code(),
                landingHeaderDeclaration.getDeclarant_aeo_certificate_type_code(),
                landingHeaderDeclaration.getRoute(),
                landingHeaderDeclaration.getDeclaration_import_export_indicator(),
                landingHeaderDeclaration.getGeneration_number(),
                landingHeaderDeclaration.getImport_clearance_status(),
                landingHeaderDeclaration.getConsignor_aeo_certificate_type_code(),
                landingHeaderDeclaration.getHeader_statistical_value(),
                landingHeaderDeclaration.getGoods_departure_datetime(),
                landingHeaderDeclaration.getCustoms_value(),
                landingHeaderDeclaration.getTotal_duty(),
                landingHeaderDeclaration.getTotal_vat(),
                landingHeaderDeclaration.getNet_mass_total(),
                landingHeaderDeclaration.getGoods_location(),
                landingHeaderDeclaration.getAcceptance_date(),
                landingHeaderDeclaration.getImporter_turn_country_code(),
                landingHeaderDeclaration.getPlace_of_unloading_code(),
                landingHeaderDeclaration.getFirst_deferment_approval_num(),
                landingHeaderDeclaration.getFirst_deferment_approval_num_prefix(),
                landingHeaderDeclaration.getDeclaration_ucr(),
                landingHeaderDeclaration.getItem_count(),
                landingHeaderDeclaration.getMaster_ucr(),
                landingHeaderDeclaration.getPaying_agent_turn(),
                landingHeaderDeclaration.getPlace_of_loading_code(),
                landingHeaderDeclaration.getSession_num(),
                landingHeaderDeclaration.getSession_role_name(),
                landingHeaderDeclaration.getStatus_of_entry(),
                landingHeaderDeclaration.getTransport_country(),
                landingHeaderDeclaration.getTransport_id(),
                landingHeaderDeclaration.getTransport_mode_code(),
                landingHeaderDeclaration.getDispatch_country(),
                landingHeaderDeclaration.getConsignor_turn_country_code(),
                landingHeaderDeclaration.getConsignor_nad_name(),
                landingHeaderDeclaration.getConsignee_nad_name(),
                landingHeaderDeclaration.getConsignee_nad_postcode(),
                landingHeaderDeclaration.getDeclarant_nad_name(),
                landingHeaderDeclaration.getCustoms_check_code(),
                landingHeaderDeclaration.getProfile_id(),
                landingHeaderDeclaration.getInvoice_total_declared()
        ));
    }

    public static LandingHeaderDeclarationHashed parse(String line) {
        List<String> columns = parseLine(line);

        return LandingHeaderDeclarationHashed.builder()
                .source(valueAt(columns, 0))
                .ingestion_date(valueAt(columns, 1))
                .entry_number(valueAt(columns, 2))
                .entry_date(valueAt(columns, 3))
                .epu_number(valueAt(columns, 4))
                .entry_type(valueAt(columns, 5))
                .declaration_method(valueAt(columns, 6))
                .total_excise(valueAt(columns, 7))
                .importer_turn(valueAt(columns, 8))
                .declarant_turn(valueAt(columns, 9))
                .declarant_representative_turn(valueAt(columns, 10))
                .consignee_aeo_certificate_type_code(valueAt(columns, 11))
                .declarant_aeo_certificate_type_code(valueAt(columns, 12))
                .route(valueAt(columns, 13))
                .declaration_import_export_indicator(valueAt(columns, 14))
                .generation_number(valueAt(columns, 15))
                .exporter_turn(valueAt(columns, 16))
                .destination_country_code(valueAt(columns, 17))
                .import_clearance_status(valueAt(columns, 18))
                .consignor_aeo_certificate_type_code(valueAt(columns, 19))
                .header_statistical_value(valueAt(columns, 20))
                .goods_departure_datetime(valueAt(columns, 21))
                .customs_value(valueAt(columns, 22))
                .total_duty(valueAt(columns, 23))
                .total_vat(valueAt(columns, 24))
                .net_mass_total(valueAt(columns, 25))
                .goods_location(valueAt(columns, 26))
                .acceptance_date(valueAt(columns, 27))
                .importer_turn_country_code(valueAt(columns, 28))
                .place_of_unloading_code(valueAt(columns, 29))
                .first_deferment_approval_num(valueAt(columns, 30))
                .first_deferment_approval_num_prefix(valueAt(columns, 31))
                .declaration_ucr(valueAt(columns, 32))
                .item_count(valueAt(columns, 33))
                .master_ucr(valueAt(columns, 34))
                .paying_agent_turn(valueAt(columns, 35))
                .place_of_loading_code(valueAt(columns, 36))
                .session_num(valueAt(columns, 37))
                .session_role_name(valueAt(columns, 38))
                .status_of_entry(valueAt(columns, 39))
                .transport_country(valueAt(columns, 40))
                .transport_id(valueAt(columns, 41))
                .transport_mode_code(valueAt(columns, 42))
                .dispatch_country(valueAt(columns, 43))
                .consignor_turn(valueAt(columns, 44))
                .consignor_turn_country_code(valueAt(columns, 45))
                .consignor_nad_name(valueAt(columns, 46))
                .consignee_nad_name(valueAt(columns, 47))
                .consignee_nad_postcode(valueAt(columns, 48))
                .declarant_nad_name(valueAt(columns, 49))
                .customs_check_code(valueAt(columns, 50))
                .profile_id(valueAt(columns, 51))
                .freight_currency(valueAt(columns, 52))
                .invoice_currency(valueAt(columns, 53))
                .invoice_total_declared(valueAt(columns, 54))
                .entry_reference(valueAt(columns, 55))
                .hub_declaration(valueAt(columns, 56))
                .sat_declaration(valueAt(columns, 57))
                .link_declaration_consignor_trader(valueAt(columns, 58))
                .link_declaration_consignor_trader_hub_trader(valueAt(columns, 59))
                .link_declaration_declarant_trader(valueAt(columns, 60))
                .link_declaration_declarant_trader_hub_trader(valueAt(columns, 61))
                .link_declaration_destination_country(valueAt(columns, 62))
                .link_declaration_destination_country_hub_country(valueAt(columns, 63))
                .link_declaration_exporter_trader(valueAt(columns, 64))
                .link_declaration_exporter_trader_hub_trader(valueAt(columns, 65))
                .link_declaration_freight_currency(valueAt(columns, 66))
                .link_declaration_freight_currency_hub_currency(valueAt(columns, 67))
                .link_declaration_importer_trader(valueAt(columns, 68))
                .link_declaration_importer_trader_hub_trader(valueAt(columns, 69))
                .link_declaration_invoice_currency(valueAt(columns, 70))
                .link_declaration_invoice_currency_hub_currency(valueAt(columns, 71))
                .link_declaration_paying_agent_trader(valueAt(columns, 72))
                .link_declaration_paying_agent_trader_hub_trader(valueAt(columns, 73))
                .link_declaration_transport_country(valueAt(columns, 74))
                .link_declaration_transport_country_hub_country(valueAt(columns, 75))
                .build();
    }

}
