package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingHeaderDeclaration;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingHeaderDeclarationHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader.LandingHeaderDeclarationReader;

@Component
public class LandingHeaderDeclarationHashedBuilder extends BaseHashedBuilder {

    @Autowired
    private LandingHeaderDeclarationReader landingHeaderDeclarationReader;

    public Dataset<LandingHeaderDeclarationHashed> build() {
        Dataset<LandingHeaderDeclaration> landingHeaderDeclarationDataset = landingHeaderDeclarationReader.landingHeaderDeclarationDataset();

        return landingHeaderDeclarationDataset
                .map((MapFunction<LandingHeaderDeclaration, LandingHeaderDeclarationHashed>) LandingHeaderDeclarationHashed::mapper,
                        LandingHeaderDeclarationHashed.landingHeaderDeclarationHashedEncoder);
    }

    public void saveAndCreateExternalTable(Dataset<LandingHeaderDeclarationHashed> landingHeaderDeclarationHashedDataset) {
        String tableName = LandingTables.LANDING_HEADER_DECLARATION_HASHED.tableName();
        saveLandingDatasetAsTable(landingHeaderDeclarationHashedDataset, tableName);
    }
}
