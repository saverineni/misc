package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLinePreviousDocument;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables.LANDING_LINE_PREVIOUS_DOCUMENT;

@Component
public class LandingLinePreviousDocumentReader extends TableReader {

    public Dataset<LandingLinePreviousDocument> landingLinePreviousDocumentDataset() {
        String dataFilePath = String.format("%s/%s", LANDING_LINE_PREVIOUS_DOCUMENT.tableName(), datafileRelativePath);
        String landingLinePreviousDocumentFilePath = String.format("%s/%s", landingHDFSAbsoluteBasePath, dataFilePath);

        JavaRDD<LandingLinePreviousDocument> landingLinePreviousDocumentJavaRDD = javaSparkContext
                .textFile(landingLinePreviousDocumentFilePath)
                .map(LandingLinePreviousDocument::parse);
        return sparkSession.createDataset(landingLinePreviousDocumentJavaRDD.rdd(), LandingLinePreviousDocument.landingLinePreviousDocumentEncoder);
    }
}
