package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLinePreviousDocumentHashed;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables.LANDING_LINE_PREVIOUS_DOCUMENT_HASHED;

@Component
public class LandingLinePreviousDocumentHashedReader extends TableReader {

    public Dataset<LandingLinePreviousDocumentHashed> landingLinePreviousDocumentHashedDataset() {
        String dataFilePath = String.format("%s/%s", LANDING_LINE_PREVIOUS_DOCUMENT_HASHED.tableName(), datafileRelativePath);
        String landingLinePreviousDocumentHashedFilePath = String.format("%s/%s", landingHDFSAbsoluteBasePath, dataFilePath);

        JavaRDD<LandingLinePreviousDocumentHashed> landingLinePreviousDocumentHashedJavaRDD = javaSparkContext
                .textFile(landingLinePreviousDocumentHashedFilePath)
                .map(LandingLinePreviousDocumentHashed::parse);
        return sparkSession.createDataset(landingLinePreviousDocumentHashedJavaRDD.rdd(), LandingLinePreviousDocumentHashed.landingLinePreviousDocumentHashedEncoder);
    }
}
