package uk.gov.gsi.hmrc.cds.hasher.spark.helper;

import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;

import static java.util.stream.Collectors.joining;

@Slf4j
public final class DDLBuilder {
    private static final String DEFAULT_FILE_DELIMITER = "\\u0001";

    private static final String createExternalTableTemplate =
            "CREATE EXTERNAL TABLE IF NOT EXISTS %s.%s (" +
            "%s" +
            ")\n" +
            "        ROW FORMAT DELIMITED\n" +
            "        FIELDS TERMINATED BY '%s'\n" +
            "        STORED AS TEXTFILE\n" +
            "        LOCATION '%s'";

    public static String buildExternalTableScript(String dbName, String tableName, String[] fieldNames, String externalFilePath) {
        return buildExternalTableScript(dbName, tableName, fieldNames, DEFAULT_FILE_DELIMITER, externalFilePath);
    }

    private static String buildExternalTableScript(String dbName, String tableName, String[] fieldNames, String fieldDelimiter, String externalFilePath) {
        String columns = Arrays.stream(fieldNames)
                .map(s -> "`" + s + "` string")
                .collect(joining(","));

        String createExternalTableScript = String.format(createExternalTableTemplate, dbName, tableName, columns, fieldDelimiter, externalFilePath);
        log.info(createExternalTableScript);
        return createExternalTableScript;
    }
}
