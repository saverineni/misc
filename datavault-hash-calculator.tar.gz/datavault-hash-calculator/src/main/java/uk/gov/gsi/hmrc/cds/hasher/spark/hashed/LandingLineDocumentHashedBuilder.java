package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLineDocument;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLineDocumentHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader.LandingLineDocumentReader;

@Component
public class LandingLineDocumentHashedBuilder  extends BaseHashedBuilder {

    @Autowired
    private LandingLineDocumentReader landingLineDocumentReader;

    public Dataset<LandingLineDocumentHashed> build() {
        Dataset<LandingLineDocument> landingLineDocumentDataset = landingLineDocumentReader.landingLineDocumentDataset();

        return landingLineDocumentDataset.map((MapFunction<LandingLineDocument, LandingLineDocumentHashed>) LandingLineDocumentHashed::mapper, LandingLineDocumentHashed.landingLineDocumentHashedEncoder);
    }

    public void saveAndCreateExternalTable(Dataset<LandingLineDocumentHashed> landingLineDocumentHashedDataset) {
        String tableName = LandingTables.LANDING_LINE_DOCUMENT_HASHED.tableName();
        saveLandingDatasetAsTable(landingLineDocumentHashedDataset, tableName);
    }
}
