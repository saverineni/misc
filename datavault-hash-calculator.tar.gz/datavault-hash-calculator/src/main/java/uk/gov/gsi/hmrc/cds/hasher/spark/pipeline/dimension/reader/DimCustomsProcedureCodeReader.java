package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.reader;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCustomsProcedureCode;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.DimensionTables.DIM_CUSTOMS_PROCEDURE_CODE;

@Component
public class DimCustomsProcedureCodeReader extends TableReader {

    public Dataset<DimCustomsProcedureCode> dimCustomsProcedureCodeDataset() {
        String dataFilePath = String.format("%s/%s", DIM_CUSTOMS_PROCEDURE_CODE.tableName(), datafileRelativePath);
        String dimCustomsProcedureCodeFilePath = String.format("%s/%s", dimensionHDFSAbsoluteBasePath, dataFilePath);

        JavaRDD<DimCustomsProcedureCode> dimCustomsProcedureCodeJavaRDD = javaSparkContext
                .textFile(dimCustomsProcedureCodeFilePath)
                .map(DimCustomsProcedureCode::parse);

        return sparkSession.createDataset(dimCustomsProcedureCodeJavaRDD.rdd(), DimCustomsProcedureCode.dimCustomsProcedureCodeEncoder);

    }
}
