package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLinesDeclarationHashed;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables.LANDING_LINES_DECLARATION_HASHED;

@Component
public class LandingLinesDeclarationHashedReader extends TableReader {

    public Dataset<LandingLinesDeclarationHashed> landingLinesDeclarationDataset() {
        String dataFilePath = String.format("%s/%s", LANDING_LINES_DECLARATION_HASHED.tableName(), datafileRelativePath);
        String landingLinesDeclarationHashedFilePath = String.format("%s/%s", landingHDFSAbsoluteBasePath, dataFilePath);

        JavaRDD<LandingLinesDeclarationHashed> landingLinesDeclarationHashedJavaRDD = javaSparkContext
                .textFile(landingLinesDeclarationHashedFilePath)
                .map(LandingLinesDeclarationHashed::parse);
        return sparkSession.createDataset(landingLinesDeclarationHashedJavaRDD.rdd(), LandingLinesDeclarationHashed.landingLinesDeclarationHashedEncoder);

    }
}
