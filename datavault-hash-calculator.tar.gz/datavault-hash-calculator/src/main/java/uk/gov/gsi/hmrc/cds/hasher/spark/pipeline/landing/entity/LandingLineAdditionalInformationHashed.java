package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity;

import com.google.common.collect.Lists;
import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.hasher.spark.helper.MD5Hasher.md5HashOf;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.*;

@Data
@Builder
public class LandingLineAdditionalInformationHashed implements Serializable, BaseEntity {

    private String source;
    private String ingestion_date;
    private String item_number;
    private String additional_information_sequence_number;
    private String generation_number;
    private String additional_information_statement;
    private String additional_information_statement_type;
    private String item_additional_information_statement;
    private String entry_reference;
    private String hub_additional_info;
    private String sat_additional_info;
    private String link_declaration_line_additional_info;
    private String link_declaration_line_additional_info_hub_declaration_line;


    public static final Encoder<LandingLineAdditionalInformationHashed> landingLineAdditionalInformationHashedEncoder = Encoders.bean(LandingLineAdditionalInformationHashed.class);

    public static LandingLineAdditionalInformationHashed mapper(LandingLineAdditionalInformation landingLineAdditionalInformation) {
        return LandingLineAdditionalInformationHashed.builder()
                .source(landingLineAdditionalInformation.getSource())
                .ingestion_date(landingLineAdditionalInformation.getIngestion_date())
                .item_number(landingLineAdditionalInformation.getItem_number())
                .additional_information_sequence_number(landingLineAdditionalInformation.getAdditional_information_sequence_number())
                .generation_number(landingLineAdditionalInformation.getGeneration_number())
                .additional_information_statement(landingLineAdditionalInformation.getAdditional_information_statement())
                .additional_information_statement_type(landingLineAdditionalInformation.getAdditional_information_statement_type())
                .item_additional_information_statement(landingLineAdditionalInformation.getItem_additional_information_statement())
                .entry_reference(landingLineAdditionalInformation.getEntry_reference())
                .hub_additional_info(hubAdditionalInfoHashed(landingLineAdditionalInformation))
                .sat_additional_info(satAdditionalInfoHashDifference(landingLineAdditionalInformation))
                .link_declaration_line_additional_info(linkDeclarationLineAdditonalInfoHashed(landingLineAdditionalInformation))
                .link_declaration_line_additional_info_hub_declaration_line(additionalInfoHubDeclarationLineHashed(landingLineAdditionalInformation))
                .build();
    }

    private static String additionalInfoHubDeclarationLineHashed(LandingLineAdditionalInformation landingLineAdditionalInformation) {
        return md5HashOf(Arrays.asList(
                landingLineAdditionalInformation.getEntry_reference(),
                landingLineAdditionalInformation.getItem_number()
        ));
    }

    private static String linkDeclarationLineAdditonalInfoHashed(LandingLineAdditionalInformation landingLineAdditionalInformation) {
        return md5HashOf(Arrays.asList(
                landingLineAdditionalInformation.getEntry_reference(),
                landingLineAdditionalInformation.getItem_number(),
                landingLineAdditionalInformation.getAdditional_information_sequence_number()
        ));
    }

    private static String satAdditionalInfoHashDifference(LandingLineAdditionalInformation landingLineAdditionalInformation) {
        return md5HashOf(Arrays.asList(
                landingLineAdditionalInformation.getGeneration_number(),
                landingLineAdditionalInformation.getAdditional_information_statement(),
                landingLineAdditionalInformation.getAdditional_information_statement_type(),
                landingLineAdditionalInformation.getItem_additional_information_statement()
        ));
    }

    private static String hubAdditionalInfoHashed(LandingLineAdditionalInformation landingLineAdditionalInformation) {
        return md5HashOf(Arrays.asList(
                landingLineAdditionalInformation.getEntry_reference(),
                landingLineAdditionalInformation.getItem_number(),
                landingLineAdditionalInformation.getAdditional_information_sequence_number()
        ));
    }

    public static LandingLineAdditionalInformationHashed parse(String line) {
        List<String> columns = parseLine(line);

        return LandingLineAdditionalInformationHashed.builder()
                .source(valueAt(columns, 0))
                .ingestion_date(valueAt(columns, 1))
                .item_number(valueAt(columns, 2))
                .additional_information_sequence_number(valueAt(columns, 3))
                .generation_number(valueAt(columns, 4))
                .additional_information_statement(valueAt(columns, 5))
                .additional_information_statement_type(valueAt(columns, 6))
                .item_additional_information_statement(valueAt(columns, 7))
                .entry_reference(valueAt(columns, 8))
                .hub_additional_info(valueAt(columns, 9))
                .sat_additional_info(valueAt(columns, 10))
                .link_declaration_line_additional_info(valueAt(columns, 11))
                .link_declaration_line_additional_info_hub_declaration_line(valueAt(columns, 12))
                .build();
    }
}
