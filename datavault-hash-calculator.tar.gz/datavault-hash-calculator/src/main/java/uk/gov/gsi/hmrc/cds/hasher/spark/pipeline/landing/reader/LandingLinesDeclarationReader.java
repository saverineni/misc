package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLinesDeclaration;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables.LANDING_LINES_DECLARATION;

@Component
public class LandingLinesDeclarationReader extends TableReader {

    public Dataset<LandingLinesDeclaration> landingLinesDeclarationDataset() {
        String dataFilePath = String.format("%s/%s", LANDING_LINES_DECLARATION.tableName(), datafileRelativePath);
        String landingLinesDeclarationFilePath = String.format("%s/%s", landingHDFSAbsoluteBasePath, dataFilePath);

        JavaRDD<LandingLinesDeclaration> landingLinesDeclarationJavaRDD = javaSparkContext
                .textFile(landingLinesDeclarationFilePath)
                .map(LandingLinesDeclaration::parse);
        return sparkSession.createDataset(landingLinesDeclarationJavaRDD.rdd(), LandingLinesDeclaration.landingLinesDeclarationEncoder);

    }
}
