package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingTrader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingTraderHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader.LandingTraderReader;

@Component
public class LandingTraderHashedBuilder extends BaseHashedBuilder {

    @Autowired
    private LandingTraderReader landingTraderReader;

    public Dataset<LandingTraderHashed> build() {
        Dataset<LandingTrader> landingTraderDataset = landingTraderReader.landingTraderDataset();

        return landingTraderDataset.map((MapFunction<LandingTrader, LandingTraderHashed>) LandingTraderHashed::mapper, LandingTraderHashed.landingTraderHashedEncoder);
    }

    public void saveAndCreateExternalTable(Dataset<LandingTraderHashed> landingTraderHashedDataset) {
        String tableName = LandingTables.LANDING_TRADER_HASHED.tableName();
        saveLandingDatasetAsTable(landingTraderHashedDataset, tableName);
    }
}
