package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.hasher.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLineAdditionalInformationHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader.LandingLineAdditionalInformationHashedReader;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.toArray;

public class LandingLineAdditionalInformationHashedBuilderTest extends SparkTest {
    @Autowired
    LandingLineAdditionalInformationHashedBuilder landingLineAdditionalInformationHashedBuilder;
    @Autowired
    LandingLineAdditionalInformationHashedReader landingLineAdditionalInformationHashedReader;

    @Test
    public void buildLandingLineAdditionalInformationHashedDataset() throws Exception {
        Dataset<LandingLineAdditionalInformationHashed> dataset = landingLineAdditionalInformationHashedBuilder.build();
        assertThat(dataset.count(), is(greaterThan(0l)));

        String[] fieldNames = dataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(LandingLineAdditionalInformationHashedStructFields));

        Dataset<LandingLineAdditionalInformationHashed> pdiHashedDataset = landingLineAdditionalInformationHashedReader.landingLineAdditionalInformationDataset();
        List<LandingLineAdditionalInformationHashed> actualHashed = dataset.toJavaRDD().collect();
        List<LandingLineAdditionalInformationHashed> expectedHashed = pdiHashedDataset.toJavaRDD().collect();

        // TODO - prehaps we don't need to assert this horrible way. This is for the initial verification of all rows and columns.
        // TODO - To be cleaned up to assert one row.
        actualHashed.forEach(landingLineAdditionalInformationHashed -> {
            LandingLineAdditionalInformationHashed expectedLandingLineAdditionalInformationHashed = expectedHashed.stream()
                    .filter(v1 ->
                            (v1.getEntry_reference().equals(landingLineAdditionalInformationHashed.getEntry_reference())) &&
                                    (v1.getItem_number().equals(landingLineAdditionalInformationHashed.getItem_number())) &&
                                    (v1.getAdditional_information_sequence_number().equals(landingLineAdditionalInformationHashed.getAdditional_information_sequence_number()))
                    )
                    .findFirst()
                    .get();

            assertThat(landingLineAdditionalInformationHashed.getSource(), is(equalTo(expectedLandingLineAdditionalInformationHashed.getSource())));
            assertThat(landingLineAdditionalInformationHashed.getIngestion_date(), is(equalTo(expectedLandingLineAdditionalInformationHashed.getIngestion_date())));
            assertThat(landingLineAdditionalInformationHashed.getItem_number(), is(equalTo(expectedLandingLineAdditionalInformationHashed.getItem_number())));
            assertThat(landingLineAdditionalInformationHashed.getAdditional_information_sequence_number(), is(equalTo(expectedLandingLineAdditionalInformationHashed.getAdditional_information_sequence_number())));
            assertThat(landingLineAdditionalInformationHashed.getGeneration_number(), is(equalTo(expectedLandingLineAdditionalInformationHashed.getGeneration_number())));
            assertThat(landingLineAdditionalInformationHashed.getAdditional_information_statement(), is(equalTo(expectedLandingLineAdditionalInformationHashed.getAdditional_information_statement())));
            assertThat(landingLineAdditionalInformationHashed.getAdditional_information_statement_type(), is(equalTo(expectedLandingLineAdditionalInformationHashed.getAdditional_information_statement_type())));
            assertThat(landingLineAdditionalInformationHashed.getItem_additional_information_statement(), is(equalTo(expectedLandingLineAdditionalInformationHashed.getItem_additional_information_statement())));
            assertThat(landingLineAdditionalInformationHashed.getEntry_reference(), is(equalTo(expectedLandingLineAdditionalInformationHashed.getEntry_reference())));
            assertThat(landingLineAdditionalInformationHashed.getHub_additional_info(), is(equalTo(expectedLandingLineAdditionalInformationHashed.getHub_additional_info())));
            assertThat(landingLineAdditionalInformationHashed.getSat_additional_info(), is(equalTo(expectedLandingLineAdditionalInformationHashed.getSat_additional_info())));
            assertThat(landingLineAdditionalInformationHashed.getLink_declaration_line_additional_info(), is(equalTo(expectedLandingLineAdditionalInformationHashed.getLink_declaration_line_additional_info())));
            assertThat(landingLineAdditionalInformationHashed.getLink_declaration_line_additional_info_hub_declaration_line(), is(equalTo(expectedLandingLineAdditionalInformationHashed.getLink_declaration_line_additional_info_hub_declaration_line())));
        });


    }

    private static String[] LandingLineAdditionalInformationHashedStructFields = toArray(
            Lists.newArrayList(
                    "additional_information_sequence_number",
                    "additional_information_statement",
                    "additional_information_statement_type",
                    "entry_reference",
                    "generation_number",
                    "hub_additional_info",
                    "ingestion_date",
                    "item_additional_information_statement",
                    "item_number",
                    "link_declaration_line_additional_info",
                    "link_declaration_line_additional_info_hub_declaration_line",
                    "sat_additional_info",
                    "source"

            )
    );

}