package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.reader;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.hasher.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCurrency;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.toArray;

public class DimCurrencyReaderTest extends SparkTest{

    @Autowired
    DimCurrencyReader dimCurrencyReader;

    private static String[] dimCurrencyStructFields = toArray(
            Lists.newArrayList(
                    "currency_id",
                    "currency_iso_code",
                    "currency_name"
            )
    );

    @Test
    public void buildsDimCurrencyDataframe() throws Exception {
        Dataset<DimCurrency> dimCurrencyDataset = dimCurrencyReader.dimCurrencyDataset();
        assertThat(dimCurrencyDataset.count(), is(greaterThan(0l)));

        dimCurrencyDataset.printSchema();
        String[] fieldNames = dimCurrencyDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(dimCurrencyStructFields));
    }
}