package uk.gov.gsi.hmrc.cds.hasher.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = {
        "uk.gov.gsi.hmrc.cds.hasher.spark.pipeline",
        "uk.gov.gsi.hmrc.cds.hasher.spark.hashed"
})
public class ReaderConfig {
}
