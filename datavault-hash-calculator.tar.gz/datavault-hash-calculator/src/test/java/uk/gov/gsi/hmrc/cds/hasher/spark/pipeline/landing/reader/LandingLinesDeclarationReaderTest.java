package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.hasher.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLinesDeclaration;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class LandingLinesDeclarationReaderTest extends SparkTest {
    @Autowired
    LandingLinesDeclarationReader landingLinesDeclarationReader;

    @Test
    public void buildsLandingLinesDeclarationDataframe() throws Exception {
        Dataset<LandingLinesDeclaration> landingLinesDeclarationDataset = landingLinesDeclarationReader.landingLinesDeclarationDataset();
        assertThat(landingLinesDeclarationDataset.count(), is(greaterThan(0l)));

        landingLinesDeclarationDataset.printSchema();
        String[] fieldNames = landingLinesDeclarationDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(LandingLinesDeclaration.structFields));
    }


}