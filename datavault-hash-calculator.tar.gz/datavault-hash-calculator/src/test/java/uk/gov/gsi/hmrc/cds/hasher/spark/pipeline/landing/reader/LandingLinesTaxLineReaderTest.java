package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader;

import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.hasher.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLineTaxLine;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class LandingLinesTaxLineReaderTest extends SparkTest {
    @Autowired
    LandingLineTaxLineReader landingLineTaxLineReader;

    @Test
    public void buildsLandingLinesDeclarationDataframe() throws Exception {
        Dataset<LandingLineTaxLine> landingLineTaxLineDataset = landingLineTaxLineReader.landingLineTaxLineDataset();
        assertThat(landingLineTaxLineDataset.count(), is(greaterThan(0l)));

        landingLineTaxLineDataset.printSchema();
        String[] fieldNames = landingLineTaxLineDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(LandingLineTaxLine.structFields));
    }


}