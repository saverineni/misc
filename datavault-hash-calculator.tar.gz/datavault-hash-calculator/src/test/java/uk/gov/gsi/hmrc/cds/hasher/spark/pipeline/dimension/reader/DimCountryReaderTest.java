package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.reader;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.hasher.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCountry;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.toArray;

public class DimCountryReaderTest extends SparkTest{

    @Autowired
    DimCountryReader dimCountryReader;

    private static String[] dimCountryStructFields = toArray(
            Lists.newArrayList(
                    "country_comments",
                    "country_id",
                    "country_iso_code",
                    "country_name",
                    "country_sequence_number"
            )
    );

    @Test
    public void buildsDimCountryDataset() throws Exception {
        Dataset<DimCountry> dimCountryDataset = dimCountryReader.dimCountryDataset();
        assertThat(dimCountryDataset.count(), is(greaterThan(0l)));

        dimCountryDataset.show();
        String[] fieldNames = dimCountryDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(dimCountryStructFields));

    }
}