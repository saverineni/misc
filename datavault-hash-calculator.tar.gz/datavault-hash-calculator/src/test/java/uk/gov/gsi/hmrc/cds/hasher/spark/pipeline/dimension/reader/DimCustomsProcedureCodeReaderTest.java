package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.reader;

import com.google.common.collect.Lists;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.hasher.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCustomsProcedureCode;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.toArray;

public class DimCustomsProcedureCodeReaderTest extends SparkTest{
    @Autowired
    DimCustomsProcedureCodeReader dimCustomsProcedureCodeReader;

    private static String[] dimCustomsProcedureCodeStructFields = toArray(
            Lists.newArrayList(
                    "customs_procedure_code",
                    "national_coding",
                    "page",
                    "previous_procedure",
                    "previous_procedure_description",
                    "procedure",
                    "procedure_description",
                    "regime_entered_to",
                    "regime_entered_to_description",
                    "release_mechanism",
                    "release_mechanism_description",
                    "series",
                    "type_of_goods",
                    "type_of_goods_description"
            )
    );

    @Test
    public void buildsDimCommodityCodeDataframe() throws Exception {
        Dataset<DimCustomsProcedureCode> dimCustomsProcedureCodeDataset = dimCustomsProcedureCodeReader.dimCustomsProcedureCodeDataset();
        assertThat(dimCustomsProcedureCodeDataset.count(), is(greaterThan(0l)));

        dimCustomsProcedureCodeDataset.printSchema();
        String[] fieldNames = dimCustomsProcedureCodeDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(dimCustomsProcedureCodeStructFields));
    }
}