#!/usr/bin/env bash
# creating landing and dimension data for the spark job to process and create Dv hashes

# Sometimes the in-memory Derby database used by Hive doesn't remove the lock after stopping
printf '********Deleting in-memory Derby database lock file********\n'
rm -rf /var/lib/hive/metastore/metastore_db/*.lck

printf '********Deleting any existing data********\n'
hdfs dfs -rmr /user/osboxes/spark

printf '\n\n********Creating landing and dimension data********\n'

hdfs dfs -mkdir -p /user/osboxes/spark/dv_v1_small/landing
hdfs dfs -mkdir -p /user/osboxes/spark/dv_v1_small/dimension

hdfs dfs -copyFromLocal ${WORKSPACE}/datavault-hash-calculator/src/test/resources/dimension/* /user/osboxes/spark/dv_v1_small/dimension
hdfs dfs -copyFromLocal ${WORKSPACE}/datavault-hash-calculator/src/test/resources/landing/* /user/osboxes/spark/dv_v1_small/landing

printf '\n\n********Creating dataVault hash database********\n'
# creating DV hash database
hive -e 'drop database dv_v1_small cascade'
hive -e 'create database dv_v1_small'

printf '\n\n********Running spark process********\n'
# Running spark process
mvn clean package -DskipTests=true
spark-submit ${WORKSPACE}/datavault-hash-calculator/target/datavault-hash-calculator-1.0.0-SNAPSHOT.jar --spring.profiles.active=dev
