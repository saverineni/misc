Notes:
 This project creates Datavault hashes.

Usage:
    Make sure you don't run hive locally while executing the below script.
    Locally execute the command 'sh run.sh'