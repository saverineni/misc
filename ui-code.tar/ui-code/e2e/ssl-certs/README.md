# Generating certs

__Run__

```openssl req -newkey rsa:2048 -nodes -keyout e2e.key -x509 -days 3650 -out e2e.crt```

__Options__
```
Country Name (2 letter code) [AU]:GB
State or Province Name (full name) [Some-State]:
Locality Name (eg, city) []:Manchester
Organization Name (eg, company) [Internet Widgits Pty Ltd]:HMRC
Organizational Unit Name (eg, section) []:
Common Name (e.g. server FQDN or YOUR name) []:localhost
Email Address []:
```