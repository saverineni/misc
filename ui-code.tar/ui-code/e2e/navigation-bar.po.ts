import { by, element } from 'protractor';

export class NavigationBar {

  navbarLabels() {
    return element.all(by.css('.nav__home-label')).map(item => item.getText());
  }

  isNavBarLabelsExists() {
    return element.all(by.css('.nav__home-label')).count.length != 0;
  }

  isNavBarEmpty() {
    return element(by.css('.nav__menu--hidden')).isPresent();
  }

  clickHome() {
    return element(by.css('.nav__home-link')).click();
  }

  signOut() {
    return element(by.css('.nav__sign-out-link')).click();
  }

  help() {
    return element(by.css('.nav__help-link')).click();
  }
}
