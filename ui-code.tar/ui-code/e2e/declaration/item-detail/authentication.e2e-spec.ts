import { DeclarationDetailScenario } from  '../detail/declarationdetail-scenario'
import { Wiremock } from '../../wiremock';
import { SignInPage } from '../../sign-in/sign-in.po';
import { SignInScenario } from '../../sign-in/sign-in-scenario';
import { BrowserCache } from '../../browser-cache';
import { DeclarationItemDetailPage } from './declarationitemdetail.po';

describe('Declaration Item Details Authentication', () => {
  let detailPage: DeclarationItemDetailPage;
  let signInPage: SignInPage;
  const browserCache = new BrowserCache();

  beforeEach(() => {
    signInPage = new SignInPage();
    detailPage = new DeclarationItemDetailPage();
  });

  describe('When signed in with token missing', () => {
    beforeEach((done) => {
      Wiremock.reset()
        .then(() => DeclarationDetailScenario.stubDeclaration(DeclarationDetailScenario.TEST_ID))
        .then(() => new SignInScenario().givenUserIsSignedIn())
        .then(done, done.fail);
    });

    it('should redirect to signin page', (done) => {
      browserCache.clearLocalStorage()
        .then(() => detailPage.navigateTo(DeclarationDetailScenario.TEST_ID, 1))
        .then(() => expect(signInPage.isCurrentPage()).toBe(true))
        .then(done, done.fail);
    });
  });

  describe('When signed in with invalid token', () => {
    beforeEach((done) => {
      Wiremock.reset()
        .then(() => DeclarationDetailScenario.stubDeclarationWithInvalidToken(DeclarationDetailScenario.TEST_ID))
        .then(() => new SignInScenario().givenUserIsSignedIn())
        .then(done, done.fail);
    });

    it('should redirect to signin page', (done) => {
      browserCache.makeTokenInvalid()
        .then(() => detailPage.navigateTo(DeclarationDetailScenario.TEST_ID, 1))
        .then(() => expect(signInPage.isCurrentPage()).toBe(true))
        .then(() => expect(detailPage.getCurrentUrl()).toContain("signin?returnUrl=%2Fdeclarations%2F670-954107X-2017-08-22%2Fitems%2F1"))        
        .then(done, done.fail);
    });
  });
});
