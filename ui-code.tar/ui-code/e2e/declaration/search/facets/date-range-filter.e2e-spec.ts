import {DeclarationSearchPage} from '../declarationsearch.po';
import {Wiremock} from '../../../wiremock';
import {SignInScenario} from '../../../sign-in/sign-in-scenario';
import {DeclarationSearchScenario} from '../declaration-search-scenario';
import {DateRangeFilter} from "./date-range-filter.po";
import {browser} from "protractor";
import { NavigationBar } from '../../../navigation-bar.po';

describe('Date range faceted search', () => {
  const entryDateId: string = "entry";
  const clearanceDateId: string = "clearance";
  let searchPage: DeclarationSearchPage;
  let entryDateFilter: DateRangeFilter;
  let clearanceDateFilter: DateRangeFilter;
  let allDateFilters: Array<DateRangeFilter>;

  beforeAll((done) => {
    searchPage = new DeclarationSearchPage();
    entryDateFilter = new DateRangeFilter(entryDateId);
    clearanceDateFilter = new DateRangeFilter(clearanceDateId);
    allDateFilters = [entryDateFilter, clearanceDateFilter];
    new SignInScenario().givenUserIsSignedIn()
      .then(() => Wiremock.reset())
      .then(() => searchPage.navigateTo())
      .then(done, done.fail);
  });

  describe('url updated with date parameters', () => {
    beforeEach((done) => {
      DeclarationSearchScenario.stubAuthenticatedSearchForTerm('found')
        .then(() => searchPage.whenISearchFor('found'))
        .then(done, done.fail);
    });

    describe('filter results by entry dates', () => {
      const fromDate: string =  "22/10/2016";
      const toDate: string =  "24/10/2017";

      beforeEach((done) =>
        entryDateFilter.clickExpandingHeader()
          .then(done, done.fail)
      );

      it('select dates and click cancel to clear', (done) => {
        entryDateFilter.populateDateFrom(fromDate)
          .then(() => entryDateFilter.populateDateTo(toDate))
          .then(() => entryDateFilter.clickClear())
          .then(() => entryDateFilter.clickExpandingHeader())
          .then(() => expect(entryDateFilter.getDateFrom()).toEqual(""))
          .then(() => expect(entryDateFilter.getDateTo()).toEqual(""))
          .then(() => expect(browser.getCurrentUrl()).not.toContain("entryDateFrom="))
          .then(() => expect(browser.getCurrentUrl()).not.toContain("entryDateTo="))
          .then(done, done.fail);
      });

      it('input invalid dates and click cancel to clear', (done) => {
        entryDateFilter.populateDateFrom('invalid')
          .then(() => entryDateFilter.populateDateTo('invalid'))
          .then(() => entryDateFilter.clickClear())
          .then(() => entryDateFilter.clickExpandingHeader())
          .then(() => expect(entryDateFilter.getDateFrom()).toEqual(""))
          .then(() => expect(entryDateFilter.getDateTo()).toEqual(""))
          .then(() => expect(browser.getCurrentUrl()).not.toContain("entryDateFrom="))
          .then(() => expect(browser.getCurrentUrl()).not.toContain("entryDateTo="))
          .then(done, done.fail);
      });

      it('on apply filters the url should contain the dates selected in ISO format', (done) => {
        entryDateFilter.populateDateFrom(fromDate)
          .then(() => entryDateFilter.populateDateTo(toDate))
          .then(() => entryDateFilter.clickApplyFilters())
          .then(() => expect(browser.getCurrentUrl()).toContain("entryDateFrom=2016-10-22"))
          .then(() => expect(browser.getCurrentUrl()).toContain("entryDateTo=2017-10-24"))
          .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
          .then(done, done.fail);
      });

      describe('apply filters ignores other component inputs', () => {
        beforeAll((done) => {
          clearanceDateFilter.clickExpandingHeader()
            .then(() => entryDateFilter.populateDateFrom(fromDate))
            .then(() => entryDateFilter.populateDateTo(toDate))
            .then(() => clearanceDateFilter.populateDateFrom(fromDate))
            .then(() => clearanceDateFilter.populateDateTo(toDate))
            .then(() => entryDateFilter.clickApplyFilters())
            .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
            .then(done, done.fail);
        });

        it('clears the clearance date fields', () => {
          expect(clearanceDateFilter.getDateFrom()).toBe('');
          expect(clearanceDateFilter.getDateTo()).toBe('');
        });

        it('does not have clearance date url params', () => {
          expect(browser.getCurrentUrl()).not.toContain("clearanceDateFrom=");
          expect(browser.getCurrentUrl()).not.toContain("clearanceDateTo=");
        });
      });

      describe('clicking the home link should', () => {

        beforeAll((done) => {
          entryDateFilter.clickExpandingHeader()
            .then(() => entryDateFilter.populateDateFrom(fromDate))
            .then(() => entryDateFilter.populateDateTo(toDate))
            .then(() => entryDateFilter.clickApplyFilters())
            .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
            .then(() => new NavigationBar().clickHome())
            .then(done, done.fail);
        });

        it('clear the date fields', (done) => {
          entryDateFilter.clickExpandingHeader()
            .then(() => expect(entryDateFilter.getDateFrom()).toBe(''))
            .then(() => expect(entryDateFilter.getDateTo()).toBe(''))
            .then(done, done.fail);
        });

      });

    });

    describe('filter results by clearance dates', () => {
      const fromDate: string =  "22/10/2016";
      const toDate: string =  "24/10/2017";

      beforeEach((done) =>
        clearanceDateFilter.clickExpandingHeader()
          .then(done, done.fail)
      );

      it('select dates and click cancel to clear', (done) => {
        clearanceDateFilter.populateDateFrom(fromDate)
          .then(() => clearanceDateFilter.populateDateTo(toDate))
          .then(() => clearanceDateFilter.clickClear())
          .then(() => expect(clearanceDateFilter.getDateFrom()).toEqual(""))
          .then(() => expect(clearanceDateFilter.getDateTo()).toEqual(""))
          .then(() => expect(browser.getCurrentUrl()).not.toContain("clearanceDateFrom="))
          .then(() => expect(browser.getCurrentUrl()).not.toContain("clearanceDateTo="))
          .then(done, done.fail);
      });

      it('on apply filters the url should contain the dates selected in ISO format', (done) => {
        clearanceDateFilter.populateDateFrom(fromDate)
          .then(() => clearanceDateFilter.populateDateTo(toDate))
          .then(() => clearanceDateFilter.clickApplyFilters())
          .then(() => expect(browser.getCurrentUrl()).toContain("clearanceDateFrom=2016-10-22"))
          .then(() => expect(browser.getCurrentUrl()).toContain("clearanceDateTo=2017-10-24"))
          .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
          .then(done, done.fail);
      });

      describe('apply filters ignores other component inputs', () => {
        beforeAll((done) => {
          entryDateFilter.clickExpandingHeader()
            .then(() => clearanceDateFilter.populateDateFrom(fromDate))
            .then(() => clearanceDateFilter.populateDateTo(toDate))
            .then(() => entryDateFilter.populateDateFrom(fromDate))
            .then(() => entryDateFilter.populateDateTo(toDate))
            .then(() => clearanceDateFilter.clickApplyFilters())
            .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
            .then(done, done.fail);
        });

        it('clears the entry date fields', () => {
          expect(entryDateFilter.getDateFrom()).toBe('');
          expect(entryDateFilter.getDateTo()).toBe('');
        });

        it('does not have entry date url params', () => {
          expect(browser.getCurrentUrl()).not.toContain("entryDateFrom=");
          expect(browser.getCurrentUrl()).not.toContain("entryDateTo=");
        });
      });

      describe('clicking the home link should', () => {

        beforeAll((done) => {
          clearanceDateFilter.clickExpandingHeader()
            .then(() => clearanceDateFilter.populateDateFrom(fromDate))
            .then(() => clearanceDateFilter.populateDateTo(toDate))
            .then(() => clearanceDateFilter.clickApplyFilters())
            .then(() => expect(searchPage.isResultsDisplayed()).toEqual(true))
            .then(() => new NavigationBar().clickHome())
            .then(() => browser.driver.sleep(500))
            .then(done, done.fail);
        });

        it('clear the date fields', (done) => {
          clearanceDateFilter.clickExpandingHeader()
            .then(() => expect(clearanceDateFilter.getDateFrom()).toBe(''))
            .then(() => expect(clearanceDateFilter.getDateTo()).toBe(''))
            .then(done, done.fail);
        });

      });
    });
  });
});
