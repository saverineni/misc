import { Wiremock } from '../../../wiremock';
import { SignInPage } from '../../../sign-in/sign-in.po';

export class FacetedSearchScenario {

  static stubFacetRequest(searchParam, filterPrefix) {
    return this.facetRequest(searchParam, filterPrefix, {
        "status": 200,
        "bodyFileName": 'default-facets-with-filter-response.json'
      });
  }

  static stubUnauthorizeFacetRequest(searchParam, filterPrefix) {
    return this.facetRequest(searchParam, filterPrefix, {
        "status": 401
      });
  }

  private static facetRequest(searchParam, filterPrefix, response) {
    return Wiremock.stubRequest({
      "priority": 1,
      "request": {
        "method": "GET",
        "url": `/facets/${searchParam}/${filterPrefix}?searchTerm=found`,
        "headers": {
          "Authorization": {
            "equalTo": "Bearer " + SignInPage.DEFAULT_AUTH_TOKEN
          }
        }
      },
      "response": response
    })
  }
}