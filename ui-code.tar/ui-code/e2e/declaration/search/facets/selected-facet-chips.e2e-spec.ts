import {DeclarationSearchPage} from '../declarationsearch.po';
import {Wiremock} from '../../../wiremock';
import {SignInScenario} from '../../../sign-in/sign-in-scenario';
import {Chips} from "./chips.po";

describe('selected facet chips', () => {
  let searchPage;

  beforeAll((done) => {
    new SignInScenario().givenUserIsSignedIn()
      .then(done, done.fail);
  });

  beforeEach((done) => {
    searchPage = new DeclarationSearchPage();

    Wiremock.reset().then(done, done.fail);
  });

  describe('no facets selected', () => {

    beforeEach((done) => {
      searchPage.navigateTo().then(done, done.fail);
    });

    it('should display no facets', () => {
      expect(Chips.getNumberOfChipsIn('search-filter__facets')).toBe(0);
    });
  });

  [{
    name: 'Country of Origin',
    type: 'originCountryCode',
    params: [ 'AFacet', 'BFacet' ]
  },
  {
    name: 'Country of Dispatch',
    type: 'dispatchCountryCode',
    params: [ 'BFacet', 'CFacet' ]
  },
  {
    name: 'Country of Destination',
    type: 'destinationCountryCode',
    params: [ 'AFacet', 'BFacet' ]
  },
  {
    name: 'Mode of Transport',
    type: 'transportModeCode',
    params: [ 'BFacet', 'CFacet' ]
  },
  {
    name: 'Goods Location',
    type: 'goodsLocation',
    params: [ 'AFacet', 'BFacet' ]
  },
  {
    name: 'Commodity Code',
    type: 'commodityCode',
    params: [ '1234com1' , '12347890' ]
  }].forEach(test => {
    describe(`${test.name} facets selected`, () => {
      const chips = new Chips(test.type);

      beforeEach((done) => {
        let url = '?' + test.params.map(it => `${test.type}=${it}`).join('&');
        searchPage.navigateTo(url).then(done, done.fail);
      });

      it('should display the chips', () => {
        expect(chips.getTexts()).toEqual(test.params);
      });

      describe('remove facet chip', () => {
        const chipIndex = 0;
        let expectedParams;
        beforeEach((done) => {
          expectedParams = test.params.filter((el, i) => i != chipIndex);
          chips.getChipIcon(test.params[chipIndex]).getCssValue('color')
                .then(color => expect(color).toBe('rgba(16, 134, 110, 1)'));

          chips.removeChip(test.params[chipIndex])
               .then(done, done.fail);
        });

        it('should remove the chip', () => {
          expect(chips.getTexts()).toEqual(expectedParams);
        });

        it('should execute a new search', (done) => {
          let url = '/declarations?' + expectedParams.map(it => `${test.type}=${it}`).join('&');
          Wiremock.requestCountForGet(url)
                  .then(count => expect(count).toBe(1))
                  .then(done, done.fail);
        });
      });
    });
  });
});
