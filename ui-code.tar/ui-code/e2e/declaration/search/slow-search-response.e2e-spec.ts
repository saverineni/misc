
import { DeclarationSearchPage } from './declarationsearch.po';
import { DeclarationSearchScenario } from './declaration-search-scenario';
import { SignInScenario } from '../../sign-in/sign-in-scenario';
import { Wiremock } from '../../wiremock';
import { WaitingOverlay } from '../../waiting-overlay';
import { browser } from 'protractor';
import { ErrorPage } from '../../error.po';

describe('Slow declaration search', () => {
  let searchPage: DeclarationSearchPage = new DeclarationSearchPage();
  let waitingOverlay = new WaitingOverlay();
  let errorPage: ErrorPage = new ErrorPage();

  beforeAll((done) => {
    new SignInScenario().givenUserIsSignedIn()
      .then(() => browser.waitForAngular())
      .then(() => browser.driver.sleep(500))
      .then(done, done.fail);
  });

  describe('Before connection timeout', () => {
    beforeAll((done) => {
      Wiremock.reset()
        .then(() => browser.waitForAngularEnabled(false))
        .then(() => DeclarationSearchScenario.stubPerformSearchWithDelayMillis(3000))
        .then(() => searchPage.navigateTo("?searchTerm=found"))
        .then(done, done.fail);
    });
  
    afterAll((done) => browser.waitForAngularEnabled(true).then(done, done.fail));
  
    xit('should display the spinner', () => {
      expect(waitingOverlay.spinnerIsDisplayed()).toBe(true);
    });
  });

  describe('After connection timeout', () => {
    beforeAll((done) => {
      Wiremock.reset()
        .then(() => browser.waitForAngularEnabled(true))
        .then(() => DeclarationSearchScenario.stubPerformSearchWithDelayMillis(6000))
        .then(() => searchPage.navigateTo("?searchTerm=found"))
        .then(done, done.fail)
    });

    it('redirects to error page', () => {
      expect(errorPage.isCurrentPage()).toBeTruthy();
    });

    it('displays error page heading', () => {
      expect(errorPage.pageHeading()).toBe('Oops! Something went wrong.');
    });

    it('displays error incovenience message', () => {
      expect(errorPage.incovenienceMessage()).toBe(`We're sorry for the inconvenience caused. We will look in to the issue as soon as we can.`);
    });

    it('displays error help message', () => {
      expect(errorPage.helpMessage()).toBe(`Please use the ‘Customs Declaration Search’ link in the navigation bar above to return to the search landing page.`);
    });

    it('updates the title in the browser', () => {
      expect(errorPage.getCurrentTitle()).toBe(`CDS - Server Error`);
    });

    it('should not be displaying the spinner', () => {
      expect(waitingOverlay.spinnerIsDisplayed()).toBe(false);
    });
  });
  
});
