describe('health endpoint', () => {
  const https = require("https");
  const agent = new https.Agent({
    rejectUnauthorized: false
  });
  const fetch = require('node-fetch');
  let response;

  beforeAll(() => {
    response = fetch('https://localhost:8443/manage/health', {
      method: 'GET',
      agent: agent
    })
    .then(res => res.text())
    .then(body => JSON.parse(body))
  });

  it('should give the health status', (done) => {
    response.then(resp => expect(resp.status).toBe('UP'))
            .then(done, done.fail);
  });
});
