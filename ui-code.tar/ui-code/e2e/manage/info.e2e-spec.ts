describe('info endpoint', () => {
  const https = require("https");
  const agent = new https.Agent({
    rejectUnauthorized: false
  });
  const fetch = require('node-fetch');
  let response;

  beforeAll((done) => {
    fetch('https://localhost:8443/manage/info', {
      method: 'GET',
      agent: agent
    })
    .then(res => res.text())
    .then(body => response = JSON.parse(body))
    .then(done, done.fail)
  });

  it('should give the build version', () =>
    expect(response.build.version).not.toBeNull()
  );

  it('should give the build artifact', () =>
    expect(response.build.artifact).not.toBeNull()
  );
});
