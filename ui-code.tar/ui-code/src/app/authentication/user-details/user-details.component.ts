import { Component } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../user';

@Component({
  selector: 'cds-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.scss']
})
export class UserDetailsComponent{
 
  constructor(
    private userService: UserService,
  ) {}

  isSignedIn() {
    return this.userService.isSignedIn();
  }

  user(): User {
    return this.userService.getUser();
  }
}
