export class AuthenticationResult {
    constructor(readonly authorised: boolean) {}
}
