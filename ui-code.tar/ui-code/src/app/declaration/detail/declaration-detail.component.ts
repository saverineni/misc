import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Declaration } from './declaration';
import { Column, ColumnDefinition } from '../../elements-library/cds-data-grid/column-definition';
import { DeclarationService } from './declaration.service';
import { Observable } from 'rxjs/internal/Observable';
import { map, shareReplay } from 'rxjs/operators';
import { Breadcrumb } from "../breadcrumb/breadcrumb";

@Component({
  selector: 'cds-declaration-detail',
  templateUrl: './declaration-detail.component.html',
  styleUrls: ['./declaration-detail.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DeclarationDetailComponent implements OnInit {
  declarationHeaderColumnDefinitions = [
    new ColumnDefinition({ id: 'declarationId', label: 'Declaration ID', strong: true }),
    new ColumnDefinition({ id: 'importExportIndicator', label: 'Import/Export', strong: true }),
    new ColumnDefinition({ id: 'declarationSource', label: 'Declaration Source', strong: true }),
    new ColumnDefinition({ id: 'declarationType', label: 'Declaration type',  strong: true }),
    new ColumnDefinition({ id: 'epuNumber', label: 'EPU' }),
    new ColumnDefinition({ id: 'entryNumber', label: 'Entry Number' }),
    new ColumnDefinition({ id: 'entryDate', label: 'Entry Date', type: 'timestamp' }),
    new ColumnDefinition({ id: 'route', label: 'Route of Entry' }),
    new ColumnDefinition({
      id: 'dispatchCountry', label: 'Country of Dispatch',
      getValue: (dec) => dec.dispatchCountry && dec.dispatchCountry.code
    }),
    new ColumnDefinition({
      id: 'destinationCountry', label: 'Country of Destination',
      getValue: (dec) => dec.destinationCountry && dec.destinationCountry.code
    }),
    new ColumnDefinition({ id: 'consigneeTurn', label: 'Consignee EORI' }),
    new ColumnDefinition({ id: 'consigneeName', label: 'Consignee Name' }),
    new ColumnDefinition({ id: 'consigneePostcode', label: 'Consignee Postcode' }),
    new ColumnDefinition({ id: 'consignorTurn', label: 'Consignor EORI' }),
    new ColumnDefinition({ id: 'consignorName', label: 'Consignor Name' }),
    new ColumnDefinition({ id: 'consignorPostcode', label: 'Consignor Postcode' }),
    new ColumnDefinition({ id: 'goodsLocation', label: 'Goods Location' }),
    new ColumnDefinition({ id: 'transportModeCode', label: 'Mode of Transport' })
  ];

  declaration$: Observable<Declaration>;
  gridColumns$: Observable<Column[]>;
  breadcrumbs: Array<Breadcrumb>;

  constructor(private route: ActivatedRoute,
    private declarationService: DeclarationService) { }

  ngOnInit() {
    this.declaration$ = this.declarationService.declarationForRoute(this.route).pipe(shareReplay(1));
    this.gridColumns$ = this.declaration$.pipe(
      map(declaration => this.declarationHeaderColumnDefinitions.map(it => it.toColumn(declaration)))
    );
    this.breadcrumbs = [
      new Breadcrumb('Declaration Detail')
    ];
  }

}
