import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DeclarationItemDetailComponent } from './declaration-item-detail.component';
import { MatCardModule, MatDividerModule, MatTabsModule, MatInputModule, MatIconModule } from '@angular/material';
import { Directive, Input } from '@angular/core';
import { of, Observable } from 'rxjs';
import {ActivatedRoute, Router, RouterState} from '@angular/router';
import { Location } from '@angular/common';
import { DeclarationLine } from '../declaration-line';
import { By } from '@angular/platform-browser';
import { DeclarationService } from '../declaration.service';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { LinesSelection } from '../lines-selection';
import { Column } from '../../../elements-library/cds-data-grid/column-definition';
import {RouterStateSnapshot} from "@angular/router/src/router_state";
import { Breadcrumb } from '../../breadcrumb/breadcrumb';

@Directive({
  selector: 'cds-data-grid'
})
export class DeclarationDataGridStub {
  @Input() columnCount: number;
  @Input() columns: Observable<Column[]>;
}
@Directive({
  selector: 'cds-breadcrumb'
})
export class BreadCrumbStub {
  @Input() breadcrumbs = [];
}

describe('DeclarationItemDetailComponent', () => {
  let component: DeclarationItemDetailComponent;
  let fixture: ComponentFixture<DeclarationItemDetailComponent>;
  let linesSelection: LinesSelection;
  let declarationService: DeclarationService;
  let location: Location;

  let routerStateSnapshotStub = { url: '/declarations/1234/items/1'} as RouterStateSnapshot;
  let mockRouter = {
    routerState: {
      snapshot: routerStateSnapshotStub
    } as RouterState
  } as Router;

  beforeEach(async(() => {
    linesSelection = new LinesSelection([
        { itemNumber: 1, itemRoute: 'one'} as DeclarationLine,
        { itemNumber: 2, itemRoute: 'two'} as DeclarationLine,
        { itemNumber: 3, itemRoute: 'three'} as DeclarationLine
      ],
      'id', 'import', 'mss', 'X');

    linesSelection.selectedItemNumber = 2;

    let obs: any = of(linesSelection);
    declarationService = {
      itemsForRoute: (route) => obs
    } as DeclarationService;

    let mockActivatedRoute = {} as ActivatedRoute;

    TestBed.configureTestingModule({
      imports: [MatCardModule, MatDividerModule, MatTabsModule, RouterTestingModule, NoopAnimationsModule, FormsModule, MatInputModule, MatIconModule],
      declarations: [ DeclarationItemDetailComponent, DeclarationDataGridStub, BreadCrumbStub ],
      providers: [
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: DeclarationService, useValue: declarationService },
        { provide: Router, useValue: mockRouter }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeclarationItemDetailComponent);
    component = fixture.componentInstance;
    location = TestBed.get(Location);
    spyOn(location, 'replaceState');
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should have focus on the search input item', () => {
    const declarationItemDetail = fixture.debugElement.query(By.css('.declaration-item-detail'));
    const itemDetail = declarationItemDetail.nativeElement as HTMLElement;

    const itemFilter = declarationItemDetail.query(By.css('.declaration-item-detail__item-filter-input')).nativeElement as HTMLElement;
    const focusedElement = itemDetail.querySelector('[autofocus]') as HTMLElement;
    expect(itemFilter).toBe(focusedElement);
  });

  describe('data grid', () => {
    let dataGrid: DeclarationDataGridStub;

    describe('with items', () => {
      beforeEach(() => {
        dataGrid = fixture.debugElement.query(By.directive(DeclarationDataGridStub)).injector.get(DeclarationDataGridStub);
      });

      it('should be given the correct column count', () => {
        expect(dataGrid.columnCount).toEqual(4);
      });

      it('should be given the correct columns for the item', (done) => {
        const expectedItem = { declarationId: 'id', importExportIndicator: 'import', declarationSource: 'mss', declarationType: 'X', itemNumber: 2, itemRoute: 'two' };
        dataGrid.columns.subscribe(
          columns => {
            expect(columns).toEqual(component.declarationItemColumnDefinitions.map(it => it.toColumn(expectedItem)));
            done();
          },
          done.fail
        );
      });
    });
  });

  function getActiveItemNumber() {
    return fixture.debugElement.query(By.css('.declaration-item-detail__declarations'))
    .nativeElement.getAttribute('data-declaration-item-number');
  }

  function getItemTabLabels() {
    return fixture.debugElement.queryAll(By.css('.declaration-item-detail__tab-label'))
      .map(e => e.nativeElement.innerText.trim());
  }

  describe('declaration item search filter', () => {
    function filterBy(text) {
      const filterElement = fixture.debugElement.query(By.css(".declaration-item-detail__item-filter-input")).nativeElement;
      filterElement.value = text;
      filterElement.dispatchEvent(new Event('input'));

      fixture.detectChanges();
    }

    it('should select the tab for the given item number',() => {
      filterBy('3');

      // need to query tabs directly as mat-tab-group value doesn't seem to get updated
      // due to an unknown...?
      expect(component.tabs.selectedIndex).toEqual(2);
    });

    describe('no matches', () => {
      beforeEach(() => {
        filterBy('99');
      });

      it('should display message', () => {
        const messageElement = fixture.debugElement.query(By.css(".declaration-item-detail__no-results-message"));

        expect(messageElement != null).toBeTruthy();
      });

      it('should not display the tabs', () => {
        expect(getItemTabLabels()).toEqual([]);
      })

      describe('then cleared', () => {
        beforeEach(() => {
          filterBy('');
        });

        it('should display all tabs again', () => {
          expect(getItemTabLabels()).toEqual(['1', '2', '3']);
        });
      });
    });
  });

  describe('declaration item selection tabs', () => {

    it('should have the correct tab selected on load', () => {
      expect(getActiveItemNumber()).toEqual('2');
    });

    it('should have the item numbers for tab labels', () => {
      expect(getItemTabLabels()).toEqual(['1', '2', '3']);
    });

    it('should update the browser url when clicked', async(() => {
      let item3Tab = fixture.debugElement.query(By.css('.declaration-item-detail__tab-label[data-declaration-item-number="3"]'))
      item3Tab.nativeElement.click();
      fixture.detectChanges();

      fixture.whenStable().then(() => {
        expect(location.replaceState).toHaveBeenCalledWith('/declarations/id/items/3');
      });
    }));
  });

  describe('declaration item resolution', () => {
    it('should map declaration ids onto the item objects', (done) => {
      component.linesSelection$.subscribe(items => {
        expect(items.lines.map(it => it.declarationId)).toEqual(['id', 'id', 'id']);
        done();
      });
    });

    it('should map declaration import export indicators onto the item objects', (done) => {
      component.linesSelection$.subscribe(items => {
        expect(items.lines.map(it => it.importExportIndicator)).toEqual(['import', 'import', 'import']);
        done();
      });
    });

    it('should map declaration sources onto the item objects', (done) => {
      component.linesSelection$.subscribe(items => {
        expect(items.lines.map(it => it.declarationSource)).toEqual(['mss', 'mss', 'mss']);
        done();
      });
    });

    it('should map declaration type onto the item objects', (done) => {
      component.linesSelection$.subscribe(items => {
        expect(items.lines.map(it => it.declarationType)).toEqual(['X', 'X', 'X']);
        done();
      });
    });

    it('should sort the items by their item number', (done) => {
      component.linesSelection$.subscribe(items => {
        expect(items.lines.map(it => it.itemNumber)).toEqual([1, 2, 3]);
        done();
      });
    });
  });

  describe('result count', () => {
    it('should display the correct number of total items', () => {
      const itemCount = fixture.debugElement.query(By.css('.declaration-item-detail__results-count')).nativeElement.innerText.trim();
      expect(itemCount).toEqual('3');
    });
  });

  describe('get declaration detail link', () => {
    it('get declaration detail url from item detail url', () => {
      let url = component.getDeclarationDetailUrl();
      expect(url).toBe('/declarations/1234');
    })
  });

  describe('breadcrumbs', () => {
    it('initialised with valid values', () => {
      let breadcrumbs: Array<Breadcrumb> = component.breadcrumbs;
      let expectedBreadCrumbs = [
        new Breadcrumb('Declaration Detail', '/declarations/1234'),
        new Breadcrumb('Item Detail')
      ]
      expect(breadcrumbs).toEqual(expectedBreadCrumbs);
    });
  });

});
