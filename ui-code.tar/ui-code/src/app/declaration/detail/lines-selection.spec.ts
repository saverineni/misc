import { DeclarationLine } from './declaration-line';
import { LinesSelection } from './lines-selection';

describe('LineSelection', () => {
  const DECLARATION_ID ='dec-id';
  const IMPORT_EXPORT_INDICATOR = 'import';
  const DECLARATION_SOURCE = 'mss';
  const DECLARATION_TYPE = 'X';

  let lines: Array<DeclarationLine>;
  let linesSelection;

  function line(itemNumber) {
    const line = new DeclarationLine();
    line.itemNumber = itemNumber;
    line.itemConsigneeName = `name ${itemNumber}`;

    return line;
  }

  function withDeclarationFields(line) {
    const newLine = Object.assign(new DeclarationLine(), line);
    newLine.declarationId = DECLARATION_ID;
    newLine.importExportIndicator = IMPORT_EXPORT_INDICATOR;
    newLine.declarationSource = DECLARATION_SOURCE;
    newLine.declarationType = DECLARATION_TYPE;
    return newLine;
  }

  it('should return the declaration lines with the declaration id, import/export, source and type added', () => {
    lines = [ line(1), line(2) ];
    linesSelection = new LinesSelection(lines, DECLARATION_ID, IMPORT_EXPORT_INDICATOR, DECLARATION_SOURCE, DECLARATION_TYPE);
    expect(linesSelection.lines).toEqual(lines.map(withDeclarationFields));
  });

  it('should sort the lines by item number', () => {
    lines = [ line(2), line(1), line(3) ];
    linesSelection = new LinesSelection(lines, DECLARATION_ID, IMPORT_EXPORT_INDICATOR, DECLARATION_SOURCE, DECLARATION_TYPE);
    expect(linesSelection.lines.map(it => it.itemNumber)).toEqual([1, 2, 3]);
  });

  it('should give true when selected item is present', () => {
    lines = [ line(1), line(4) ];
    linesSelection = new LinesSelection(lines, DECLARATION_ID, IMPORT_EXPORT_INDICATOR, DECLARATION_SOURCE, DECLARATION_TYPE);
    linesSelection.selectedItemNumber = 4;

    expect(linesSelection.isSelectionValid()).toBe(true);
  })

  it('should give false when selected item is present', () => {
    lines = [ line(1), line(4) ];
    linesSelection = new LinesSelection(lines, DECLARATION_ID, IMPORT_EXPORT_INDICATOR, DECLARATION_SOURCE, DECLARATION_TYPE);
    linesSelection.selectedItemNumber = 2;

    expect(linesSelection.isSelectionValid()).toBe(false);
  });
})
