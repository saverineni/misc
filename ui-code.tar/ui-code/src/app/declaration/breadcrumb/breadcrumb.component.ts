import { Component, Input } from '@angular/core';
import { NavigationService } from "../search/navigation.service";
import { Breadcrumb } from "./breadcrumb";

@Component({
  selector: 'cds-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.scss']
})
export class BreadcrumbComponent {

  constructor(private navigationService: NavigationService) { }

  @Input() breadcrumbs: Array<Breadcrumb>;

  backToSearchResults() {
    this.navigationService.navigateToSearch(false);
  }
}
