import {Component, Input, OnInit, ViewChild, ViewEncapsulation} from '@angular/core';
import {PageEvent} from "@angular/material";
import {SearchCriteriaService} from "../search-criteria.service";
import {Subscription} from 'rxjs';
import {SearchCriteria} from "../search-criteria";

@Component({
  selector: 'cds-search-paginator',
  templateUrl: './search-paginator.component.html',
  styleUrls: ['./search-paginator.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SearchPaginatorComponent implements OnInit{

  @ViewChild("paginator") paginator;
  private criteriaSubscription: Subscription;
  private searchCriteria: SearchCriteria;

  @Input() totalResults;
  pageSize = 10;
  pageSizeOptions: number[] = [10, 20, 30, 40, 50];


  constructor(private searchCriteriaService: SearchCriteriaService) { }

  ngOnInit() {
    this.criteriaSubscription = this.searchCriteriaService.searchCriteria.subscribe(
      criteria => {
        this.searchCriteria = criteria;

        // MatPaginator PageIndex is zero based
        let pageNumber = this.searchCriteria.pageNumber ? this.searchCriteria.pageNumber - 1 : 0;
        let pageSize = this.searchCriteria.pageSize ? this.searchCriteria.pageSize : 10;
        this.paginator.pageIndex = pageNumber;
        this.paginator.pageSize = pageSize;
        this.pageSize = pageSize;
      }
    );
  }


  onPageChange(pageEvent: PageEvent) {
    const update = {};

    // MatPaginator PageIndex is zero based - pageIndex(0) == pageNumber(1), so add +1
    update['pageNumber'] = pageEvent.pageIndex + 1;
    update['pageSize'] = pageEvent.pageSize;

    this.searchCriteriaService.updatePartial(update);
  }

  ngOnDestroy(): void {
    this.criteriaSubscription.unsubscribe();
  }
}
