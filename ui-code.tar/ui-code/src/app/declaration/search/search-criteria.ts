export class SearchCriteria {
  pageNumber: number;
  pageSize: number;

  searchTerm: string;

  originCountryCode: string[];
  dispatchCountryCode: string[];
  destinationCountryCode: string[];
  transportModeCode: string[];
  goodsLocation: string[];
  commodityCode: string[];
  declarationType: string[];
  entryDateFrom: string;
  entryDateTo: string;
  clearanceDateFrom: string;
  clearanceDateTo: string;
  eori: string;

  isEmpty(): boolean {
    return Object.getOwnPropertyNames(this)
                 .find(property  => this[property] != undefined) == undefined;
  }

  filtersEmpty(): boolean {
    return Object.getOwnPropertyNames(this)
                  .filter(key => ['pageNumber', 'pageSize', 'searchTerm'].indexOf(key) == -1)
                  .find(property  => this[property] != undefined) == undefined;
  }
}
