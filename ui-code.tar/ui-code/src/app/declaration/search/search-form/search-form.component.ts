import {ChangeDetectionStrategy, Component, OnInit, ViewChild} from '@angular/core';
import {SearchCriteriaService} from '../search-criteria.service';
import {map} from 'rxjs/operators'
import {Observable} from 'rxjs';

@Component({
  selector: 'cds-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SearchFormComponent implements OnInit {
  @ViewChild('searchInput') searchInput;
  searchTerm$: Observable<string>;

  constructor(private searchCriteriaService: SearchCriteriaService) { }

  ngOnInit() {
    this.searchTerm$ = this.searchCriteriaService.searchCriteria.pipe(
      map(newSearchCriteria => {
        const searchTerm = newSearchCriteria.searchTerm;
        if (newSearchCriteria.isEmpty()) {
          this.searchInput.nativeElement.focus();
        }
        return searchTerm;
      })
    );
  }

  clear() {
    let searchCriteriaSearchTerm = null;
    this.searchTerm$.subscribe( searchTerm => { searchCriteriaSearchTerm = searchTerm});

    if( searchCriteriaSearchTerm === this.searchInput.nativeElement.value){
      this.onSubmitSearch(null);
    }
    this.searchInput.nativeElement.value= '';
    this.searchInput.nativeElement.focus();
  }

  onSubmitSearch(searchTerm) {
    if (searchTerm == null) {
      searchTerm = '';
    }
    this.searchCriteriaService.updatePartial({ searchTerm: searchTerm, pageNumber: undefined, pageSize: undefined });
  }
}
