import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {SearchSectionComponent} from './search-section.component';
import {DebugElement, Directive, Input} from '@angular/core';
import {SearchService} from '../search.service';
import {SearchCriteria} from '../search-criteria';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {DeclarationSearchResult} from '../declaration-search-result';
import {Observable, of, Subscription} from 'rxjs';
import {MatDividerModule, MatIconModule} from '@angular/material';
import {SearchCriteriaService} from '../search-criteria.service';
import {By} from '@angular/platform-browser';
import {Declaration} from "../../detail/declaration";
import { FormatCountPipe } from '../format-count.pipe';
import { NavigationService } from '../navigation.service';

@Directive({
  selector: 'cds-search-form'
})
export class SearchFormStub { }

@Directive({
  selector: 'cds-declaration-card'
})
export class DeclarationCardStub {
  @Input() declaration;
}

@Directive({
  selector: 'cds-search-filter'
})
export class SearchFilterStub {
}

@Directive({
  selector: 'cds-search-paginator'
})
export class SearchPaginatorStub {
  @Input() totalResults = 10;
}

describe('SearchSectionComponent', () => {
  let component: SearchSectionComponent;
  let fixture: ComponentFixture<SearchSectionComponent>;
  let searchServiceStub;
  let searchCriteriaServiceStub;
  let testObservable: Observable<SearchCriteria>;
  let testSubscription: Subscription;
  let result: DeclarationSearchResult;
  let navigationService: NavigationService;

  beforeEach(async(() => {
    testObservable = of(new SearchCriteria());
    testSubscription = new Subscription();
    result = new DeclarationSearchResult();

    searchServiceStub = {
      search: () =>  of(result),
      downloadCsv: () => of('')
    };

    navigationService = {
      navigateToSearch: (bool) => {}
    } as NavigationService;
  
    searchCriteriaServiceStub = { searchCriteria: testObservable };
    spyOn(searchServiceStub, 'search').and.callThrough();
    spyOn(searchServiceStub, "downloadCsv").and.callThrough();

    TestBed.configureTestingModule({
      declarations: [SearchSectionComponent, SearchFormStub, DeclarationCardStub , SearchFilterStub , SearchPaginatorStub, FormatCountPipe ],
      providers: [
        {provide: NavigationService, useValue: navigationService },
        {provide: SearchService, useValue: searchServiceStub},
        {provide: SearchCriteriaService, useValue: searchCriteriaServiceStub}
      ],
      imports: [HttpClientTestingModule, MatDividerModule, MatIconModule]
    })
    .compileComponents();
  }));

  let successHandler;

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchSectionComponent);
    component = fixture.componentInstance;
    navigationService = TestBed.get(NavigationService);
    spyOn(testObservable, 'subscribe')
    .and.callFake(success => {
        successHandler = success;
        return testSubscription;
      });

    spyOn(testSubscription, 'unsubscribe');
    spyOn(navigationService, 'navigateToSearch');

    fixture.detectChanges();
  });

  describe('on initialisation', () => {
    it('should subscribe to successful search criteria updates', () => {
      expect(successHandler).toBeTruthy();
    });

    it('should display help text message ', () => {
      let message = fixture.debugElement.query(By.css('.search-section__hmrc__display-text')).nativeElement;
      expect(message.innerText).toBe('Please use the search box or the filters on the left hand side to start a new search.');
    });

    it('should display the hmrc logo', () => {
      let logo = fixture.debugElement.query(By.css('.search-section__hmrc__display-logo')).nativeElement;
      expect(logo).toBeTruthy();
    });

    it('should not display the reset search button', () => {
      let resetButton = fixture.debugElement.query(By.css('.search-section__reset-button'));
      expect(resetButton).toBeFalsy();
    });
  });

  describe('empty search criteria', () => {
    beforeEach(() => {
      let criteria = new SearchCriteria();
      criteria.searchTerm = null;
      successHandler(criteria);
      fixture.detectChanges();
    });

    ['.search-section__no-search-results', '.search-section__results', '.search-section__reset' ,'.search-section__results-count-section'].forEach(elementClass => {
      it(`should not display the ${elementClass}`, () => {
        let message = fixture.debugElement.query(By.css(elementClass));
        expect(message == null).toBeTruthy();
      });
    });   
  });

  describe('results', () => {
    let search;

    beforeEach(() => {
      search = new SearchCriteria();
      search.searchTerm = '';
    });

    describe('not found', () => {

      beforeEach(() => {
        result.hits = { total: 0 };
        successHandler(search);
        fixture.detectChanges();
      });

      it('should display message', () => {
        const message = fixture.debugElement.query(By.css('.search-section__no-search-results'));
        expect(message != null).toBeTruthy();
      });

      it('should display the reset search button', () => {
        let resetButton = fixture.debugElement.query(By.css('.search-section__reset-button')).nativeElement;
        expect(resetButton).toBeTruthy();
      });

      it('should call navigation service when reset button is clicked', () => {
        fixture.debugElement.query(By.css('.search-section__reset-button')).nativeElement.click();
        fixture.detectChanges();
        expect(navigationService.navigateToSearch).toHaveBeenCalledWith(true);
      });

      it('should display the result count', () => {
        const resultCount = fixture.debugElement.query(By.css('.search-section__results-count')).nativeElement;
        expect(resultCount.innerText).toEqual('0');
      });
    
      it('should not display help text message ', () => {
        const message = fixture.debugElement.query(By.css('.search-section__hmrc__display-text'));
        expect(message).toBeNull();
      });
  
      it('should not display hmrc logo', () => {
        const logo = fixture.debugElement.query(By.css('.search-section__hmrc__display-logo'));
        expect(logo).toBeNull();
      });

      it('should not display the download csv icon', () => {
        const icon = fixture.debugElement.query(By.css('.search-section__download-csv'));
        expect(icon).toBeNull();
      });

    });

    describe('found', () => {
      let directive: DebugElement;
      let paginator;

      beforeEach(() => {
        result.hits = { total: 20000 };
        result.declarations = [new Declaration()];
        successHandler(search);
        directive = fixture.debugElement.query(By.directive(SearchPaginatorStub));
        paginator = directive.injector.get(SearchPaginatorStub);

        fixture.detectChanges();
      });

      it('should display the result count', () => {
        const resultCount = fixture.debugElement.query(By.css('.search-section__results-count')).nativeElement;
        expect(resultCount.innerText).toEqual('20K');
      });

      it('should display the results', () => {
        const message = fixture.debugElement.query(By.css('.search-section__results'));
        expect(message != null).toBeTruthy();
      });

      it('should have the paginator component', () => {
        expect(paginator).toBeTruthy();
      });

      it('should display the paginator at the header', () => {
        const paginatorHeader = fixture.debugElement.query(By.css('.search-section__paginator-header')).nativeElement;
        expect(paginatorHeader).toBeTruthy();
      });

      it('should not display help text message ', () => {
        const message = fixture.debugElement.query(By.css('.search-section__hmrc__display-text'));
        expect(message).toBeNull();
      });
  
      it('should not display hmrc logo', () => {
        const logo = fixture.debugElement.query(By.css('.search-section__hmrc__display-logo'));
        expect(logo).toBeNull();
      });

      it('should call navigation service when reset button is clicked', () => {
        fixture.debugElement.query(By.css('.search-section__reset-button')).nativeElement.click();
        fixture.detectChanges();
        expect(navigationService.navigateToSearch).toHaveBeenCalledWith(true);
      });

      it('should display the download csv icon', () => {
        const icon = fixture.debugElement.query(By.css('.search-section__download-csv'));
        expect(icon).toBeTruthy();
      });

      it('should call search service to download csv when download csv icon clicked', () => {
        fixture.debugElement.query(By.css('.search-section__download-csv')).nativeElement.click();
        const csvDownloadSearch = Object.assign(new SearchCriteria(), search);
        csvDownloadSearch.pageSize = result.hits.total;
        csvDownloadSearch.pageNumber = 1; 
        expect(searchServiceStub.downloadCsv).toHaveBeenCalledWith(csvDownloadSearch);
      });

    });

  });

  describe('with search criteria', () => {
    let searchCriteria: SearchCriteria;

    beforeEach(() => {
      searchCriteria = new SearchCriteria();
      searchCriteria.searchTerm = 'term';

      successHandler(searchCriteria);
    });

    it('should perform a search', () => {
      expect(searchServiceStub.search).toHaveBeenCalledWith(searchCriteria);
    });

    it('should set the result', () => {
      expect(component.result).toBe(result);
    });

  });

  describe('on destroy', () => {
    it('should unsubscribe from criteria events', () => {
      fixture.destroy();
      expect(testSubscription.unsubscribe).toHaveBeenCalled();
    });
  });
});

