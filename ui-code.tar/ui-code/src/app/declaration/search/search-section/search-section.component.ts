import {ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewEncapsulation} from '@angular/core';
import {SearchCriteria} from '../search-criteria';
import {SearchService} from '../search.service';
import {DeclarationSearchResult} from '../declaration-search-result';
import {Subscription} from 'rxjs';
import {SearchCriteriaService} from '../search-criteria.service';
import {TrackBy} from '../../../track-by';
import * as FileSaver from 'file-saver';
import { NavigationService } from "../navigation.service";
import * as moment from 'moment';

@Component({
  selector: 'cds-search-section',
  templateUrl: './search-section.component.html',
  styleUrls: ['./search-section.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SearchSectionComponent implements OnInit, OnDestroy {
  TIMESTAMP_FORMAT = "YYYY-MM-DD-HH-mm";

  trackByDeclarationId = TrackBy.property('declarationId');

  result: DeclarationSearchResult = null;
  searchCriteriaSubscription: Subscription;
  searchCriteria: SearchCriteria;
  hmrcLogo: string;

  constructor(private navigationService: NavigationService,
     private searchService: SearchService,
     private searchCriteriaService: SearchCriteriaService,
     private changeDetectorRef: ChangeDetectorRef) { }

  ngOnInit() {
    this.searchCriteriaSubscription =
      this.searchCriteriaService.searchCriteria.subscribe(
        newSearchCriteria => {
          this.searchCriteria = newSearchCriteria;
          if (newSearchCriteria.isEmpty()) {
            this.result = undefined;
          } else {
            this.performSearch();
          }
        }
      );

      this.hmrcLogo = '/assets/hmrc-logo-web.jpg';
    }

    private performSearch() {
      this.searchService.search(this.searchCriteria).subscribe(
        result => {
          this.result = result;
          this.changeDetectorRef.detectChanges();
        }
      );
  }

  navigateToSearch() {
    this.navigationService.navigateToSearch(true);
  }

  downloadCsv() {
    const pageSize = this.result && this.result.hits && this.result.hits.total || 0;
    const search = Object.assign(new SearchCriteria(), this.searchCriteria);
    search.pageSize = pageSize;
    search.pageNumber = 1;

    const timestamp = moment(new Date()).format(this.TIMESTAMP_FORMAT);

    this.searchService.downloadCsv(search).forEach(csv => {
      if (csv) {
        const blob = new Blob([csv], {type: "text/csv;charset=utf-8"});
        FileSaver.saveAs(blob, `declarations-${timestamp}.csv`);
      }
    });
  }

  ngOnDestroy() {
    this.searchCriteriaSubscription.unsubscribe();
  }
}
