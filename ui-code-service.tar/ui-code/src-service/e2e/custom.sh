#!/bin/bash

samba-tool group add CDS-SEARCH

# add users
samba-tool user add dev Dev_1234567 --use-username-as-cn --given-name="Search" --surname="Dev User" --department="Operations Unit"

# add users to groups
samba-tool group addmembers CDS-SEARCH dev
