package search.declarations

import spock.lang.Shared
import spock.lang.Specification

class DeclarationByIdSearchSpec extends Specification {

    @Shared expectedDeclaration

    def setupSpec() {
        def index = new DeclarationsIndex()
        index.recreateAndPopulateIndex()
        expectedDeclaration = index.getApiFormatDeclaration('/declarations/2000000000000001.json')
    }

    def 'Response status should be OK'() {
        when:
        def response = SearchResource.authenticatedGetById(expectedDeclaration.declarationId)

        then:
        response.statusLine.statusCode == 200
    }

    def 'unauthenticated request should give unauthorized'() {
        when:
        def response = SearchResource.unauthenticatedGetById(expectedDeclaration.declarationId)

        then:
        response.statusLine.statusCode == 401
    }

    def 'valid declaration id returns the correct declaration'() {
        when:
        def response = SearchResource.authenticatedGetById(expectedDeclaration.declarationId)
        def result = SearchResource.asJsonMap(response)

        then:
        result == expectedDeclaration
    }

    def 'unknown declaration id gives not found'() {
        when:
        def response = SearchResource.authenticatedGetById("unknown")

        then:
        response.statusLine.statusCode == 404
    }

}
