package search.declarations

import spock.lang.Specification

class FacetSearchResultSpec extends Specification {

    def facetResourcePath = "facets"

    def setupSpec() {
        def index = new DeclarationsIndex()
        index.recreateAndPopulateIndex()
    }

    def 'Response status should be OK'() {
        when:
        def response = SearchResource.authenticatedGet(facetResourcePath + '/originCountryCode', [])

        then:
        response.statusLine.statusCode == 200
    }

    def 'should not accept unknown facet type'() {
        when:
        def response = SearchResource.authenticatedGet(facetResourcePath + '/unknown', [])

        then:
        response.statusLine.statusCode == 400
    }

    def 'should return aggregations only for the provided header facet type'() {
        given:
        def response = SearchResource.authenticatedGet(facetResourcePath + '/goodsLocation', [])
        def result = SearchResource.asJsonMap(response)

        expect:
        result.facets == [
                [
                        id   : "LCZ",
                        count: 2
                ],
                [
                        id   : "LCX",
                        count: 1
                ],
                [
                        id   : "LCY",
                        count: 1
                ]
        ]
    }

    def 'should return aggregations only for the provided header facet type with search criteria'() {
        given:
        def response = SearchResource.authenticatedGet(facetResourcePath + '/goodsLocation', ['searchTerm': ['221']])
        def result = SearchResource.asJsonMap(response)

        expect:
        result.facets == [
                [
                        id   : "LCZ",
                        count: 2
                ]
        ]
    }

    def 'should return aggregations only for the provided line facet type'() {
        given:
        def response = SearchResource.authenticatedGet(facetResourcePath + '/originCountryCode', [])
        def result = SearchResource.asJsonMap(response)

        expect:
        result.facets == [
                [
                        id   : "PH",
                        count: 3
                ],
                [
                        id   : "PG",
                        count: 1
                ],
                [
                        id   : "PI",
                        count: 1
                ]
        ]
    }

    def 'should return aggregations only for commodity code with prefix'() {
        given:
        def response = SearchResource.authenticatedGet(facetResourcePath + '/commodityCode/5510', [])
        def result = SearchResource.asJsonMap(response)

        expect:
        result.facets == [
                [
                        id   : "551030",
                        count: 1
                ],
                [
                        id   : "551031",
                        count: 1
                ],
                [
                        id   : "551032",
                        count: 1
                ]
        ]
    }

}