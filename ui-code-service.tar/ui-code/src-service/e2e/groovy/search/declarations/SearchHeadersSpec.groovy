package search.declarations

import spock.lang.Ignore
import spock.lang.Shared
import spock.lang.Specification

import static com.github.tomakehurst.wiremock.client.WireMock.*

class SearchHeadersSpec extends Specification {

    @Shared expectedDeclaration


    def setupSpec() {
        def index = new DeclarationsIndex()
        index.recreateAndPopulateIndex()
        expectedDeclaration = index.getApiFormatDeclaration('/declarations/2000000000000001.json')
    }

    @Ignore
    def 'Verify right headers have been passed to elasticsearch'() {
        when:
        SearchResource.authenticatedGetByIdWithHeaders(expectedDeclaration.declarationId, '1e7f5db898fc9b52e4887c22765ac403')

        then:
        verify(1, postRequestedFor(urlMatching("/customs_search_service/.*"))
                .withHeader("es-security-runas-user", equalTo('dev'))
                .withHeader("X-Correlation-ID", equalTo('1e7f5db898fc9b52e4887c22765ac403')))
    }
}
