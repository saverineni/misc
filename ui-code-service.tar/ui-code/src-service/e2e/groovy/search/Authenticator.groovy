package search

import groovy.json.JsonSlurper
import org.apache.http.HttpResponse
import org.apache.http.client.fluent.Executor
import org.apache.http.client.fluent.Request
import org.apache.http.impl.client.BasicResponseHandler

import static org.apache.http.entity.ContentType.APPLICATION_JSON

class Authenticator {

	private static httpClient = { -> new search.NoSslHttpClient().httpClient() }

	String authenticate() {
		System.setProperty("https.protocols", "TLSv1.1")

		HttpResponse response = postAuthenticationToken('dev', 'Dev_1234567')

		def responseString = new BasicResponseHandler().handleResponse(response)
		Map jsonResponse = new JsonSlurper().parseText(responseString)

		jsonResponse.get("token")
	}

	HttpResponse postAuthenticationToken(String username, String password) {

		Executor executor = Executor.newInstance(httpClient())

		return executor.execute(Request.Post('https://localhost:18000/authentication/token')
				.bodyString("{\"pid\":\"${username}\",\"password\":\"${password}\"}", APPLICATION_JSON))
				.returnResponse()
	}
}
