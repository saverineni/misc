package search.authentication.token

import groovy.json.JsonSlurper
import org.apache.http.HttpResponse
import org.apache.http.util.EntityUtils
import search.Authenticator
import spock.lang.Shared
import spock.lang.Specification

class AuthenticationTokenSpec extends Specification {

	@Shared
	HttpResponse response

	@Shared
	Authenticator authenticator

	def setupSpec() {
		authenticator = new search.Authenticator()
	}

	def 'valid username results in 200 with appropriate user details.'() {
		def token

		given: 'I am a consumer of the service'

		when: 'I attempt to sign in with a valid user'
			token = authenticator.authenticate()

		then: 'I get the valid user details'
			def userDetails = new String(token.tokenize(".")[1].decodeBase64())
			Map jsonResponse = new JsonSlurper().parseText(userDetails).user
			jsonResponse.pid == 'dev'
			jsonResponse.firstName == 'Search'
			jsonResponse.lastName == 'Dev User'
			jsonResponse.department == 'Operations Unit'
	}
	
	def 'unknown username results in 401 with appropriate message.'() {
		given: 'I am a consumer of the service'
			

        when: 'I attempt to sign in with an unknown user'
        	response = authenticator.postAuthenticationToken('unknown', 'password')
			
        then: 'I get an appropriate response'
		    response.statusLine.statusCode == 401
		
			def responseString = EntityUtils.toString(response.getEntity())
			Map jsonResponse = new JsonSlurper().parseText(responseString)
			jsonResponse.message == 'Bad credentials'
    }

}
