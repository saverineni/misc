package uk.gov.gsi.hmrc.cds.search.api.dto;

import org.junit.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Optional;

import static java.util.Arrays.*;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

public class SearchCriteriaTest {

    private SearchCriteria criteria = new SearchCriteria();

    @Test
    public void optionalSearchTermShouldGiveNoneWhenSearchTermEmpty() {
        criteria.setSearchTerm(" ");
        assertThat(criteria.optionalSearchTerm(), is(Optional.empty()));
    }

    @Test
    public void optionalSearchTermShouldGiveSomeSearchTermWhenPresent() {
        criteria.setSearchTerm("a-term");
        assertThat(criteria.optionalSearchTerm(), is(Optional.of("a-term")));
    }

    @Test
    public void optionalSearchTermShouldGiveNoneWhenSearchTermNull() {
        assertThat(criteria.optionalSearchTerm(), is(Optional.empty()));
    }

    @Test
    public void optionalSearchTermShouldGiveSomeTrimmedSearchTermWhenPresent() {
        criteria.setSearchTerm("  a-term  ");
        assertThat(criteria.optionalSearchTerm(), is(Optional.of("a-term")));
    }

    @Test
    public void optionalEoriShouldGiveNoneWhenSearchTermEmpty() {
        criteria.setEori(" ");
        assertThat(criteria.optionalEori(), is(Optional.empty()));
    }

    @Test
    public void optionalEoriShouldGiveSomeSearchTermWhenPresent() {
        criteria.setEori("eori");
        assertThat(criteria.optionalEori(), is(Optional.of("eori")));
    }

    @Test
    public void optionalEoriShouldGiveNoneWhenSearchTermNull() {
        assertThat(criteria.optionalEori(), is(Optional.empty()));
    }

    @Test
    public void optionalEoriShouldGiveSomeTrimmedSearchTermWhenPresent() {
        criteria.setEori("  eori  ");
        assertThat(criteria.optionalEori(), is(Optional.of("eori")));
    }

    @Test
    public void getOriginCountryCodeShouldGiveEmptyListIfNull() {
        criteria.setOriginCountryCode(null);
        assertThat(criteria.getOriginCountryCode(), is(empty()));
    }

    @Test
    public void getOriginCountryCodeShouldGiveListOfOneEmptyStringIfEmpty() {
        criteria.setOriginCountryCode(emptyList());
        assertThat(criteria.getOriginCountryCode(), contains(""));
    }

    @Test
    public void getOriginCountryCodeShouldGiveFieldIfNotEmpty() {
        criteria.setOriginCountryCode(singletonList("code"));
        assertThat(criteria.getOriginCountryCode(), contains("code"));
    }

    @Test
    public void getDispatchCountryCodeShouldGiveEmptyListIfNull() {
        criteria.setDispatchCountryCode(null);
        assertThat(criteria.getDispatchCountryCode(), is(empty()));
    }

    @Test
    public void getDispatchCountryCodeShouldGiveListOfOneEmptyStringIfEmpty() {
        criteria.setDispatchCountryCode(emptyList());
        assertThat(criteria.getDispatchCountryCode(), contains(""));
    }

    @Test
    public void getDispatchCountryCodeShouldGiveFieldIfNotEmpty() {
        criteria.setDispatchCountryCode(singletonList("code"));
        assertThat(criteria.getDispatchCountryCode(), contains("code"));
    }

    @Test
    public void getDestinationCountryCodeShouldGiveEmptyListIfNull() {
        criteria.setDestinationCountryCode(null);
        assertThat(criteria.getDestinationCountryCode(), is(empty()));
    }

    @Test
    public void getDestinationCountryCodeShouldGiveListOfOneEmptyStringIfEmpty() {
        criteria.setDestinationCountryCode(emptyList());
        assertThat(criteria.getDestinationCountryCode(), contains(""));
    }

    @Test
    public void getDestinationCountryCodeShouldGiveFieldIfNotEmpty() {
        criteria.setDestinationCountryCode(singletonList("code"));
        assertThat(criteria.getDestinationCountryCode(), contains("code"));
    }

    @Test
    public void getTransportModeCodeShouldGiveEmptyListIfNull() {
        criteria.setTransportModeCode(null);
        assertThat(criteria.getTransportModeCode(), is(empty()));
    }

    @Test
    public void getTransportModeCodeShouldGiveListOfOneEmptyStringIfEmpty() {
        criteria.setTransportModeCode(emptyList());
        assertThat(criteria.getTransportModeCode(), contains(""));
    }

    @Test
    public void getTransportModeCodeShouldGiveFieldIfNotEmpty() {
        criteria.setTransportModeCode(singletonList("code"));
        assertThat(criteria.getTransportModeCode(), contains("code"));
    }

    @Test
    public void getGoodsLocationShouldGiveEmptyListIfNull() {
        criteria.setGoodsLocation(null);
        assertThat(criteria.getGoodsLocation(), is(empty()));
    }

    @Test
    public void getGoodsLocationShouldGiveListOfOneEmptyStringIfEmpty() {
        criteria.setGoodsLocation(emptyList());
        assertThat(criteria.getGoodsLocation(), contains(""));
    }

    @Test
    public void getGoodsLocationShouldGiveFieldIfNotEmpty() {
        criteria.setGoodsLocation(singletonList("ABC"));
        assertThat(criteria.getGoodsLocation(), contains("ABC"));
    }

    @Test
    public void getCommodityCodeShouldGiveEmptyListIfNull() {
        criteria.setCommodityCode(null);
        assertThat(criteria.getCommodityCode(), is(empty()));
    }

    @Test
    public void getCommodityCodeShouldGiveListOfOneEmptyStringIfEmpty() {
        criteria.setCommodityCode(emptyList());
        assertThat(criteria.getCommodityCode(), contains(""));
    }

    @Test
    public void getCommodityCodeShouldGiveFieldIfNotEmpty() {
        criteria.setCommodityCode(singletonList("0123456789"));
        assertThat(criteria.getCommodityCode(), contains("0123456789"));
    }

    @Test
    public void optionalEntryDateTimeFromShouldGiveNoneWhenEntryDateFromIsNull() {
        criteria.setEntryDateFrom(null);
        assertThat(criteria.optionalEntryDateTimeFrom(), is(Optional.empty()));
    }

    @Test
    public void optionalEntryDateTimeToShouldGiveNoneWhenEntryDateToIsNull() {
        criteria.setEntryDateTo(null);
        assertThat(criteria.optionalEntryDateTimeTo(), is(Optional.empty()));
    }

    @Test
    public void optionalEntryDateTimeFromShouldGiveEntryDateWithTimeWhenPresent() {
        criteria.setEntryDateFrom(LocalDate.of(2018, 1, 1));
        assertThat(criteria.optionalEntryDateTimeFrom(), is(Optional.of(LocalDateTime.of(2018, 1, 1, 0, 0, 0, 0))));
    }

    @Test
    public void optionalEntryDateTimeToShouldGiveEntryDateWithTimeWhenPresent() {
        criteria.setEntryDateTo(LocalDate.of(2018, 1, 1));
        assertThat(criteria.optionalEntryDateTimeTo(), is(Optional.of(LocalDateTime.of(2018, 1, 1, 23, 59, 59, 999_999_999))));
    }

    @Test
    public void optionalClearanceDateTimeFromShouldGiveNoneWhenEntryDateFromIsNull() {
        criteria.setClearanceDateFrom(null);
        assertThat(criteria.optionalClearanceDateTimeFrom(), is(Optional.empty()));
    }

    @Test
    public void optionalClearanceDateTimeToShouldGiveNoneWhenEntryDateToIsNull() {
        criteria.setClearanceDateTo(null);
        assertThat(criteria.optionalClearanceDateTimeTo(), is(Optional.empty()));
    }

    @Test
    public void optionalClearanceDateTimeFromShouldGiveEntryDateWithTimeWhenPresent() {
        criteria.setClearanceDateFrom(LocalDate.of(2018, 1, 1));
        assertThat(criteria.optionalClearanceDateTimeFrom(), is(Optional.of(LocalDateTime.of(2018, 1, 1, 0, 0, 0, 0))));
    }

    @Test
    public void optionalClearanceDateTimeToShouldGiveEntryDateWithTimeWhenPresent() {
        criteria.setClearanceDateTo(LocalDate.of(2018, 1, 1));
        assertThat(criteria.optionalClearanceDateTimeTo(), is(Optional.of(LocalDateTime.of(2018, 1, 1, 23, 59, 59, 999_999_999))));
    }

    @Test
    public void getDeclarationTypeShouldGiveEmptyListIfNull() {
        criteria.setDeclarationType(null);
        assertThat(criteria.getDeclarationType(), is(empty()));
    }

    @Test
    public void getDeclarationTypeShouldGiveListOfOneEmptyStringIfEmpty() {
        criteria.setDeclarationType(emptyList());
        assertThat(criteria.getDeclarationType(), contains(""));
    }

    @Test
    public void getDeclarationTypeShouldGiveFieldIfNotEmpty() {
        criteria.setDeclarationType(singletonList("X"));
        assertThat(criteria.getDeclarationType(), contains("X"));
    }

    @Test
    public void getDeclarationTypeShouldGiveMultipleValues() {
        criteria.setDeclarationType(asList("X", "Y"));
        assertThat(criteria.getDeclarationType(), contains("X","Y"));
    }

}
