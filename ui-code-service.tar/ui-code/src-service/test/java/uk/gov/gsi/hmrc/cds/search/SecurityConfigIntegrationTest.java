package uk.gov.gsi.hmrc.cds.search;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.User;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.ElasticDeclarationSearchService;
import uk.gov.gsi.hmrc.cds.search.security.jwt.JwtTokenService;

import static java.lang.String.format;
import static java.util.Collections.emptyList;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest(webEnvironment = RANDOM_PORT)
@AutoConfigureMockMvc
public class SecurityConfigIntegrationTest {

    @MockBean
    private ElasticDeclarationSearchService elasticDeclarationSearchService;

    @Autowired
    private JwtTokenService jwtTokenService;

    @Autowired
    private MockMvc mockMvc;

    private String jwtToken;

    private final String DECLARATIONS_URI = "/declarations";

    private final String FACETS_URI = "/facets/originCountryCode";


    @Before
    public void setup() {
        jwtToken = jwtTokenService.createToken(new UsernamePasswordAuthenticationToken( new User("dev", "dev", emptyList()), "dev"));
    }

    @Test
    public void getDeclarationsWithoutAuthorization() throws Exception {
        mockMvc.perform(getResourceURI(DECLARATIONS_URI))
                .andExpect(status().isUnauthorized());
    }

    @Test
    public void getDeclarationsWithAuthorization() throws Exception {
        when(elasticDeclarationSearchService.fetchDeclarationSearchResult(any(SearchCriteria.class))).thenReturn(null);

        mockMvc.perform(getResourceURI(DECLARATIONS_URI)
                .header("Authorization", format("Bearer %s", jwtToken)))
                .andExpect(status().isOk());
    }


    @Test
    public void getFacetsWithoutAuthorization() throws Exception {
        mockMvc.perform(getResourceURI(FACETS_URI))
                .andExpect(status().isUnauthorized());
    }

    @Test
    public void getFacetsWithAuthorization() throws Exception {
        when(elasticDeclarationSearchService.fetchDeclarationSearchResult(any(SearchCriteria.class))).thenReturn(null);

        mockMvc.perform(getResourceURI(FACETS_URI)
                .header("Authorization", format("Bearer %s", jwtToken)))
                .andExpect(status().isOk());
    }

    private MockHttpServletRequestBuilder getResourceURI(String uri) {
        return get(uri)
                .accept(APPLICATION_JSON)
                .param("searchTerm", "term");
    }

}