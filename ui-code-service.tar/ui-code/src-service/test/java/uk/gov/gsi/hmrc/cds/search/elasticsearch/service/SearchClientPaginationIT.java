package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Arrays;

import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.junit.Before;
import org.junit.Test;

import static org.elasticsearch.common.xcontent.XContentType.JSON;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchHitMatchers.declarationId;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchResponseAssert.assertSearchHits;

import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;

public class SearchClientPaginationIT extends CustomsSearchESIntegTestCase {
    private static final String CUSTOMS_INDEX = "SearchClientPaginationTest".toLowerCase();
    private static final String ABC_GOODS_LOCATION = "ABC";
    private static final String EPU = "EPU";

    private ObjectMapper objectMapper = new ObjectMapper();

    @Before
    public void setUp() throws Exception {
        super.setUp(CUSTOMS_INDEX);
        createCustomsIndexWithDocuments();
    }

    @Test
    public void searchByPageNumberResultsForPageSizeOne() {
        assertSearchHits(this.service.declarationSearch(newSearchCriteria(1)), declarationId("dec-id-2"));
        assertSearchHits(this.service.declarationSearch(newSearchCriteria(2)), declarationId("dec-id-5"));
        assertSearchHits(this.service.declarationSearch(newSearchCriteria(3)), declarationId("dec-id-3"));
        assertSearchHits(this.service.declarationSearch(newSearchCriteria(4)), declarationId("dec-id-1"));
        assertSearchHits(this.service.declarationSearch(newSearchCriteria(5)), declarationId("dec-id-4"));
        assertSearchHits(this.service.declarationSearch(newSearchCriteria(6)), declarationId("dec-id-6"));
    }

    @Test
    public void searchByPageNumberResultsForPageSizeTwo() {
        assertSearchHits(this.service.declarationSearch(newSearchCriteria(1,2)), declarationId("dec-id-2"), declarationId("dec-id-5"));
        assertSearchHits(this.service.declarationSearch(newSearchCriteria(2,2)), declarationId("dec-id-3"), declarationId("dec-id-1"));
        assertSearchHits(this.service.declarationSearch(newSearchCriteria(3,2)), declarationId("dec-id-4"), declarationId("dec-id-6"));
    }

    @Test
    public void searchForPageNumberResultsForPageSizeFive() {
        assertSearchHits(this.service.declarationSearch(newSearchCriteria(1,5)), declarationId("dec-id-1"), declarationId("dec-id-2"), declarationId("dec-id-3"), declarationId("dec-id-4"), declarationId("dec-id-5"));
        assertSearchHits(this.service.declarationSearch(newSearchCriteria(2,5)), declarationId("dec-id-6"));
    }

    private SearchCriteria newSearchCriteria(int pageNumber) {
        return newSearchCriteria(pageNumber, 1);
    }

    private SearchCriteria newSearchCriteria(int pageNumber, int pageSize) {
        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setSearchTerm(EPU);
        searchCriteria.setGoodsLocation(Arrays.asList(ABC_GOODS_LOCATION));
        searchCriteria.setPageNumber(pageNumber);
        searchCriteria.setPageSize(pageSize);
        return searchCriteria;
    }

    private void createCustomsIndexWithDocuments() throws Exception {
        createIndex(CUSTOMS_INDEX);

        BulkRequest request = new BulkRequest();
        addDeclaration(request, newDeclaration("dec-id-1", ABC_GOODS_LOCATION));
        addDeclaration(request, newDeclaration("dec-id-2", ABC_GOODS_LOCATION));
        addDeclaration(request, newDeclaration("dec-id-3", ABC_GOODS_LOCATION));
        addDeclaration(request, newDeclaration("dec-id-4", ABC_GOODS_LOCATION));
        addDeclaration(request, newDeclaration("dec-id-5", ABC_GOODS_LOCATION));
        addDeclaration(request, newDeclaration("dec-id-6", ABC_GOODS_LOCATION));

        client.bulk(request);

        refresh(CUSTOMS_INDEX);
    }

    private void addDeclaration(BulkRequest request, Declaration declaration) throws JsonProcessingException {
        request.add(new IndexRequest(CUSTOMS_INDEX, DECLARATION_TYPE, declaration.getDeclarationId())
                .source(objectMapper.writer().writeValueAsString(declaration), JSON));
    }

    private Declaration newDeclaration(String id, String goodsLocation) {
        return Declaration.builder()
                .declarationId(id)
                .epuNumber(EPU)
                .goodsLocation(goodsLocation)
                .build();
    }
}
