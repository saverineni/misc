package uk.gov.gsi.hmrc.cds.search.security;

import org.junit.Before;
import org.junit.Test;
import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.security.ldap.userdetails.LdapAuthority;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchUserDetails;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class SearchUserContextMapperTest {

    final static String DN = "uid=username1,ou=people,dc=example,dc=com";
    final static String USERNAME = "username1";
    final static String FIRST_NAME = "fname";
    final static String LAST_NAME = "lname";
    final static String DEPARTMENT = "UK";
    final static List AUTHORITIES = Arrays.asList(new LdapAuthority("RT_TEST",DN));
    private DirContextAdapter dirContextAdapter = new DirContextAdapter(DN);
    private SearchUserContextMapper userContextMapper = new SearchUserContextMapper();

    @Before
    public void setUp() {
        mapUserAttributes();
    }


    @Test
    public void mapUserFromContext() {
        final SearchUserDetails userDetails = userContextMapper.mapUserFromContext(dirContextAdapter,USERNAME,AUTHORITIES);
        assertThat(userDetails.getPid() , is(USERNAME));
        assertThat(userDetails.getFirstName(), is(FIRST_NAME));
        assertThat(userDetails.getLastName(), is(LAST_NAME));
        assertThat(userDetails.getDepartment() , is(DEPARTMENT));
        assertThat(userDetails.getAuthorities() , is(AUTHORITIES));
    }


    private void mapUserAttributes() {
        // Set Attributes
        dirContextAdapter.setAttributeValue("givenName",FIRST_NAME);
        dirContextAdapter.setAttributeValue("sn",LAST_NAME);
        dirContextAdapter.setAttributeValue("department",DEPARTMENT);
    }
}
