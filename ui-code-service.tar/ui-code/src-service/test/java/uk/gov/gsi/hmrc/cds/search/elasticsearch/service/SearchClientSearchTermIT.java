package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.junit.Before;
import org.junit.Test;

import static org.elasticsearch.common.xcontent.XContentType.JSON;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchHitMatchers.epuNumber;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchHitMatchers.fieldValue;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchResponseAssert.assertSearchHits;
import static uk.gov.gsi.hmrc.cds.search.utils.TestHelper.VALID_SEARCH_INGEST_DECLARATION_FILE_1;
import static uk.gov.gsi.hmrc.cds.search.utils.TestHelper.VALID_SEARCH_INGEST_DECLARATION_FILE_2;
import static uk.gov.gsi.hmrc.cds.search.utils.TestHelper.VALID_SEARCH_INGEST_DECLARATION_FILE_3;

import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.utils.TestHelper;

public class SearchClientSearchTermIT extends CustomsSearchESIntegTestCase {

    private static final String CUSTOMS_INDEX = "SearchClientSearchTermIT".toLowerCase();

    private static final String VALID_DECLARATION_ID_1 = "219-249099X-2013-07-14";
    private static final String VALID_DECLARATION_ID_2 = "219-249099X-2013-07-15";
    private static final String VALID_DECLARATION_ID_3 = "219-249099X-2013-07-16";

    private static final String EPU_NUMBER_219 = "219";
    private static final String EPU_NUMBER_220 = "220";
    private static final String DECLARATION_ID_AND_EPU = VALID_DECLARATION_ID_2 + " " + EPU_NUMBER_219;

    @Before
    public void setUp() throws Exception {
        super.setUp(CUSTOMS_INDEX);
        createCustomsIndexWithDocuments();
    }

    @Test
    public void searchWithNoTerm() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(""));
        assertThat(searchResponse.getHits().totalHits, is(3L));
    }

    @Test
    public void searchByDeclarationId() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(VALID_DECLARATION_ID_1));
        assertSearchHits(searchResponse, SearchHitMatchers.declarationId(VALID_DECLARATION_ID_1));
    }

    private SearchCriteria newSearchCriteria(String searchTerm) {
        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setSearchTerm(searchTerm);
        return searchCriteria;
    }

    @Test
    public void searchByEPU() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(EPU_NUMBER_219));
        assertSearchHits(searchResponse, epuNumber(EPU_NUMBER_219));
    }

    @Test
    public void searchByEPUReturnsMultipleDeclarations() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(EPU_NUMBER_220));
        assertSearchHits(searchResponse, epuNumber(EPU_NUMBER_220), epuNumber(EPU_NUMBER_220));
    }

    @Test
    public void searchByEPUAndDeclarationId() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(DECLARATION_ID_AND_EPU));
        assertThat(searchResponse.getHits().totalHits, is(0L));
    }

    @Test
    public void searchByEPUWithSpaces() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(" " + EPU_NUMBER_219));
        assertSearchHits(searchResponse, SearchHitMatchers.epuNumber(EPU_NUMBER_219));
    }

    @Test
    public void searchByInvalidDeclarationId() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("unknown"));
        assertThat(searchResponse.getHits().totalHits, is(0L));
    }

    @Test
    public void searchByEntryNumber() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("249099x"));
        assertSearchHits(searchResponse,
                fieldValue("$.entryNumber", "249099x"),
                fieldValue("$.entryNumber", "249099x"),
                fieldValue("$.entryNumber", "249099x"));
    }

    @Test
    public void searchByCommodityCode() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("551030"));
        assertSearchHits(searchResponse, fieldValue("$.lines[0].commodityCode", "551030"));
    }

    @Test
    public void searchByOriginCountryCode() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("PG"));
        assertSearchHits(searchResponse, fieldValue("$.lines[0].originCountry.code", "PG"));
    }

    @Test
    public void searchByCPC() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("4000C36"));
        assertSearchHits(searchResponse, fieldValue("$.lines[0].cpc", "4000C36"));
    }

    @Test
    public void searchByConsigneeNameAtHeaderLevel() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("Header NAD name"));
        assertSearchHits(searchResponse, fieldValue("$.consigneeName", "Header NAD name"));
    }

    @Test
    public void searchByConsigneePostcodeAtHeaderLevel() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("HN4 0PC"));
        assertSearchHits(searchResponse, fieldValue("$.consigneePostcode", "HN4 0PC"));
    }

    @Test
    public void searchByConsigneeNameAtLineLevel() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("Item NAD name"));
        assertSearchHits(searchResponse, fieldValue("$.lines[0].itemConsigneeName", "Item NAD name"));
    }

    @Test
    public void searchByConsigneePostcodeAtLineLevel() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("IN4 0PC"));
        assertSearchHits(searchResponse, fieldValue("$.lines[0].itemConsigneePostcode", "IN4 0PC"));
    }

    @Test
    public void searchByConsignorNameAtHeaderLevel() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("Header Consignor name"));
        assertSearchHits(searchResponse, fieldValue("$.consignorName", "Header Consignor name"));
    }

    @Test
    public void searchByConsignorPostcodeAtHeaderLevel() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("AB4 6CD"));
        assertSearchHits(searchResponse, fieldValue("$.consignorPostcode", "AB4 6CD"));
    }

    @Test
    public void searchByConsignorNameAtLineLevel() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("Item Consignor name"));
        assertSearchHits(searchResponse, fieldValue("$.lines[0].itemConsignorName", "Item Consignor name"));
    }

    @Test
    public void searchByConsignorPostcodeAtLineLevel() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("IB4 6CD"));
        assertSearchHits(searchResponse, fieldValue("$.lines[0].itemConsignorPostcode", "IB4 6CD"));
    }

    @Test
    public void searchByConsigneeNumberAtHeaderLevel() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("976072558688"));
        assertSearchHits(searchResponse, fieldValue("$.consigneeTurn", "976072558688"));
    }

    @Test
    public void searchByConsigneeNumberAtLineLevel() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("731411813911"));
        assertSearchHits(searchResponse, fieldValue("$.lines[0].itemConsigneeTurn", "731411813911"));
    }

    @Test
    public void searchByConsignorNumberAtHeaderLevel() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("1261170936"));
        assertSearchHits(searchResponse, fieldValue("$.consignorTurn", "1261170936"));
    }

    @Test
    public void searchByConsignorNumberAtLineLevel() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("1933705"));
        assertSearchHits(searchResponse, fieldValue("$.lines[0].itemConsignorTurn", "1933705"));
    }

    private void createCustomsIndexWithDocuments() throws Exception {
        createIndex(CUSTOMS_INDEX);

        BulkRequest request = new BulkRequest();

        addDeclaration(request, VALID_SEARCH_INGEST_DECLARATION_FILE_1, VALID_DECLARATION_ID_1);
        addDeclaration(request, VALID_SEARCH_INGEST_DECLARATION_FILE_2, VALID_DECLARATION_ID_2);
        addDeclaration(request, VALID_SEARCH_INGEST_DECLARATION_FILE_3, VALID_DECLARATION_ID_3);

        client.bulk(request);

        refresh(CUSTOMS_INDEX);
    }

    private void addDeclaration(BulkRequest request, String validSearchIngestDeclarationFile, String validDeclarationId) {
        request.add(new IndexRequest(CUSTOMS_INDEX, DECLARATION_TYPE, validDeclarationId)
                .source(TestHelper.getFileContent(validSearchIngestDeclarationFile), JSON));
    }

}
