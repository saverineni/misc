package uk.gov.gsi.hmrc.cds.search.api.resources;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.ElasticDeclarationSearchService;

import java.util.Optional;

import static org.mockito.Mockito.verify;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(value = FacetResource.class, secure = false)
@ActiveProfiles("test")
public class FacetResourceIntegrationTest {

    private static final String EPU_NUMBER = "EPU_NUMBER";

    @MockBean
    private ElasticDeclarationSearchService elasticDeclarationSearchService;

    @Autowired
    private MockMvc mockMvc;

    private ResultActions resultActions;

    private MultiValueMap<String, String> searchParams = new LinkedMultiValueMap<>();

    SearchCriteria searchCriteria = new SearchCriteria();

    @Test
    public void searchWithInvalidRequestParamsThrowsBadRequestException() throws Exception {
        givenSearchParams("dummy");
        whenIPerformSearch("originCountryCode", Optional.empty());
        resultActions.andExpect(status().isBadRequest());
    }

    @Test
    public void searchWithInvalidRequestPathThrowsBadRequestException() throws Exception {
        givenSearchParams("searchTerm");
        whenIPerformSearch("dummy", Optional.empty());
        resultActions.andExpect(status().isBadRequest());
    }

    @Test
    public void searchForAValidFacetType() throws Exception {
        givenSearchParams("searchTerm");
        whenIPerformSearch("originCountryCode", Optional.empty());
        verify(elasticDeclarationSearchService).fetchFacetSearchResult(searchCriteria, "originCountryCode", Optional.empty());
    }

    @Test
    public void searchForAValidFacetTypeAndPrefix() throws Exception {
        givenSearchParams("searchTerm");
        whenIPerformSearch("commodityCode", Optional.of("1234"));
        verify(elasticDeclarationSearchService).fetchFacetSearchResult(searchCriteria, "commodityCode", Optional.of("1234"));
    }

    private void givenSearchParams(String requestParam) {
        searchCriteria.setSearchTerm(EPU_NUMBER);
        searchParams.set(requestParam, EPU_NUMBER);
    }

    private void whenIPerformSearch(String facetType, Optional<String> prefix) throws Exception {
        MockHttpServletRequestBuilder requestBuilder = buildGetRequest(facetType, prefix);
        resultActions = this.mockMvc.perform(requestBuilder.params(searchParams));
    }

    private MockHttpServletRequestBuilder buildGetRequest(String facetType, Optional<String> prefix) {
        String request = prefix.isPresent() ? "/facets/" + facetType + "/" + prefix.get() : "/facets/" + facetType;
        MockHttpServletRequestBuilder requestBuilder = get(request);
        return requestBuilder.accept(APPLICATION_JSON);
    }

}
