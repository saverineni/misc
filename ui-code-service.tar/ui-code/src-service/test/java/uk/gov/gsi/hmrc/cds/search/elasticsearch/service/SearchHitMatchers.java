package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import com.jayway.jsonpath.JsonPath;

import org.elasticsearch.search.SearchHit;
import org.hamcrest.FeatureMatcher;
import org.hamcrest.Matcher;
import org.hamcrest.Matchers;

public class SearchHitMatchers {

    public static Matcher<SearchHit> fieldValue(String jsonPath, String expectedValue) {
        return new FeatureMatcher<SearchHit, String>(Matchers.is(expectedValue), jsonPath, jsonPath) {


            @Override
            protected String featureValueOf(SearchHit documentFields) {
                return JsonPath.read(documentFields.getSourceAsString(), jsonPath);
            }
        };
    }

    public static Matcher<SearchHit> declarationId(String expectedValue) {
        return fieldValue("$.declarationId", expectedValue);
    }

    public static Matcher<SearchHit> epuNumber(String expectedValue) {
        return fieldValue("$.epuNumber", expectedValue);
    }
}
