package uk.gov.gsi.hmrc.cds.search.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchUserDetails;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchUserInfo;
import uk.gov.gsi.hmrc.cds.search.security.jwt.JwtTokenService;

import java.time.*;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertThat;
import static org.mockito.MockitoAnnotations.initMocks;


public class JwtTokenServiceTest {
    private static final String PRINCIPAL = "1234";
    private static final String FIRST_NAME = "fname";
    private static final String LAST_NAME = "lname";
    private static final String DEPARTMENT = "UK";
    private static final int TOKEN_EXPIRATION_IN_SECONDS = 30;
    private static final String SECRET = "SECRET";
    private static final SignatureAlgorithm HASHING_ALGORITHM = SignatureAlgorithm.HS512;
    private static final Clock CLOCK = Clock.fixed(Instant.now(), ZoneId.of("UTC"));
    private ObjectMapper objectMapper = new ObjectMapper();
    JwtTokenService jwtTokenService = new JwtTokenService(TOKEN_EXPIRATION_IN_SECONDS, SECRET, HASHING_ALGORITHM, CLOCK, objectMapper);
    Authentication authentication = Mockito.mock(Authentication.class);
    private SearchUserDetails searchUserDetails = new SearchUserDetails();

    @Mock
    private SearchUserDetails user;

    @Before
    public void setup() {
        initMocks(this);
        searchUserDetails.setPid(PRINCIPAL);
        searchUserDetails.setFirstName(FIRST_NAME);
        searchUserDetails.setLastName(LAST_NAME);
        searchUserDetails.setDepartment(DEPARTMENT);
    }

    @Test
    public void generateJwtToken() {
        Mockito.when(authentication.getPrincipal()).thenReturn(user);
        Mockito.when(user.getPid()).thenReturn(PRINCIPAL);
        Mockito.when(user.toString()).thenReturn(searchUserDetails.toString());
        String token = jwtTokenService.createToken(authentication);
        assertThat(token, Matchers.is(expectedToken()));
    }

    @Test
    public void verifyJwtToken() {
        Mockito.when(authentication.getCredentials()).thenReturn(expectedToken());
        String subject = jwtTokenService.verifyToken(authentication);

        assertThat(subject, Matchers.is(PRINCIPAL));
    }

    @Test(expected = BadCredentialsException.class)
    public void verifyAnExpiredJwtToken() throws Exception {
        Mockito.when(authentication.getCredentials()).thenReturn(expectedToken(3));
        Thread.sleep(TimeUnit.SECONDS.toMillis(4));
        jwtTokenService.verifyToken(authentication);
    }

    @Test(expected = BadCredentialsException.class)
    public void verifyAnInvalidJwtToken() {
        Mockito.when(authentication.getCredentials()).thenReturn("1.2.3");
        jwtTokenService.verifyToken(authentication);
    }

    private String expectedToken() {
        return expectedToken(TOKEN_EXPIRATION_IN_SECONDS);
    }

    private String expectedToken(long expirationTime) {
        final Claims claims = Jwts.claims().setSubject(PRINCIPAL);
        final SearchUserInfo searchUserInfo =  new SearchUserInfo();
        searchUserInfo.setFirstName(FIRST_NAME);
        searchUserInfo.setLastName(LAST_NAME);
        searchUserInfo.setPid(PRINCIPAL);
        searchUserInfo.setDepartment(DEPARTMENT);
        claims.put("user",searchUserInfo);
        return Jwts.builder()
                .setClaims(claims)
                .setExpiration(Date.from(LocalDateTime.now(CLOCK).plusSeconds(expirationTime).toInstant(ZoneOffset.UTC)))
                .signWith(HASHING_ALGORITHM, SECRET)
                .compact();
    }
}