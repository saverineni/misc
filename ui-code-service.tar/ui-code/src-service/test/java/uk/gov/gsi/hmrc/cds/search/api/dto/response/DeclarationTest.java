package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;

import static java.util.Collections.singletonList;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

public class DeclarationTest {

    Declaration declaration = Declaration.builder().build();

    @Test
    public void getLinesShouldGiveEmptyListIfNull() {
        declaration.setLines(null);
        assertThat(declaration.getLines(), is(empty()));
    }

    @Test
    public void getLinesShouldGiveLineIfNotEmpty() {
        DeclarationLine line = DeclarationLine.builder().build();
        declaration.setLines(singletonList(line));
        assertThat(declaration.getLines(), contains(line));
    }

    @Test
    public void asDeclarationHeaderArrayShouldGiveArrayOfPropertiesAsNullOrString() {
        String[] expectedArray = new String[]{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};
        assertThat(declaration.asDeclarationHeaderArray(), is(equalTo(expectedArray)));
    }

    @Test
    public void asDeclarationHeaderArrayShouldGiveStringArrayOfProperties() {
        Declaration declaration = Declaration.builder()
                .declarationId("Declaration ID")
                .declarationSource("Declaration Source")
                .importExportIndicator("Import/Export")
                .epuNumber("EPU")
                .entryNumber("Entry Number")
                .entryDate("Entry Date")
                .route("Route of Entry")
                .dispatchCountry(Country.builder().code("Country of Dispatch").build())
                .destinationCountry(Country.builder().code("Country of Destination").build())
                .consigneeTurn("Consignee EORI")
                .consignorTurn("Consignor EORI")
                .goodsLocation("Goods Location")
                .transportModeCode("Mode of Transport")
                .consigneeName("Consignee Name")
                .consigneePostcode("Consignee Postcode")
                .consignorName("Consignor Name")
                .consignorPostcode("Consignor Postcode")
                .declarationType("Declaration Type")
                .build();
        String[] expectedArray = new String[] {
                "Declaration ID",
                "Import/Export",
                "Declaration Source",
                "EPU",
                "Entry Number",
                "Entry Date",
                "Route of Entry",
                "Country of Dispatch",
                "Country of Destination",
                "Consignee EORI",
                "Consignee Name",
                "Consignee Postcode",
                "Consignor EORI",
                "Consignor Name",
                "Consignor Postcode",
                "Goods Location",
                "Mode of Transport",
                "Declaration Type"
        };
        assertThat(declaration.asDeclarationHeaderArray(), is(equalTo(expectedArray)));
    }

}