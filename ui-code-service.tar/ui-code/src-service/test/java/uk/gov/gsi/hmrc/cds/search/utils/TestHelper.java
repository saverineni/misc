package uk.gov.gsi.hmrc.cds.search.utils;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class TestHelper {

    public static final String LOGIN_URL = "/login";
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";

    public static final String DEV_USER = "dev";
    public static final String DEV_USER_PASSWORD = "dev";

    public static final String DECLARATION_ID = "declarationId";

    public static final String VALID_DECLARATION_ID = "670-954107X-2017-08-22";

    private static final String SEARCH_INGESTION_PATH = "searchingestion";
    public static final String VALID_SEARCH_INGEST_DECLARATION_FILE_1 = SEARCH_INGESTION_PATH + File.separator + "valid-declaration-1.json";
    public static final String VALID_SEARCH_INGEST_DECLARATION_FILE_2 = SEARCH_INGESTION_PATH + File.separator + "valid-declaration-2.json";
    public static final String VALID_SEARCH_INGEST_DECLARATION_FILE_3 = SEARCH_INGESTION_PATH + File.separator + "valid-declaration-3.json";
    public static final String SEARCH_MAPPINGS_FILE = SEARCH_INGESTION_PATH + File.separator + "mapping.json";

    public static String getFileContent(String fileName) {
        String response = "";
        try {
            Path path = Paths.get(TestHelper.class.getClassLoader().getResource(fileName).toURI());
            response = FileUtils.readFileToString(path.toFile(), "UTF-8");
        } catch (IOException | URISyntaxException e) {
            e.printStackTrace();
        }

        return response;
    }

}
