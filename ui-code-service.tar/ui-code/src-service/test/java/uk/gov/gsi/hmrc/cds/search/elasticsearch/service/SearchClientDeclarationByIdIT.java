package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.junit.Before;
import org.junit.Test;

import static org.elasticsearch.common.xcontent.XContentType.JSON;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchResponseAssert.assertSearchHits;
import static uk.gov.gsi.hmrc.cds.search.utils.TestHelper.VALID_SEARCH_INGEST_DECLARATION_FILE_1;

import uk.gov.gsi.hmrc.cds.search.utils.TestHelper;

public class SearchClientDeclarationByIdIT extends CustomsSearchESIntegTestCase {

    private static final String CUSTOMS_INDEX = "SearchClientDeclarationByIdIT".toLowerCase();

    private static final String VALID_DECLARATION_ID_1 = "219-249099X-2013-07-14";

    @Before
    public void setUp() throws Exception {
        super.setUp(CUSTOMS_INDEX);
        createCustomsIndexWithDocuments();
    }

    @Test
    public void searchByDeclarationId() {
        SearchResponse searchResponse = this.service.getDeclarationById(VALID_DECLARATION_ID_1);
        assertSearchHits(searchResponse, SearchHitMatchers.declarationId(VALID_DECLARATION_ID_1));
    }

    @Test
    public void searchByInvalidDeclarationId() {
        SearchResponse searchResponse = this.service.getDeclarationById("unknown");
        assertThat(searchResponse.getHits().totalHits, is(0L));
    }

    private void createCustomsIndexWithDocuments() throws Exception {
        createIndex(CUSTOMS_INDEX);

        BulkRequest request = new BulkRequest();
        addDeclaration(request, VALID_SEARCH_INGEST_DECLARATION_FILE_1, VALID_DECLARATION_ID_1);
        client.bulk(request);

        refresh(CUSTOMS_INDEX);
    }

    private void addDeclaration(BulkRequest request, String validSearchIngestDeclarationFile, String validDeclarationId) {
        request.add(new IndexRequest(CUSTOMS_INDEX, DECLARATION_TYPE, validDeclarationId)
                .source(TestHelper.getFileContent(validSearchIngestDeclarationFile), JSON));
    }

}
