package uk.gov.gsi.hmrc.cds.search;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomsSearchServiceApplication {
	public static void main(String[] args) {
		SpringApplication.run(CustomsSearchServiceApplication.class, args);
	}
}
