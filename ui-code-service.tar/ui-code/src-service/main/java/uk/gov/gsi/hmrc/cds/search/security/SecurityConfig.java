package uk.gov.gsi.hmrc.cds.search.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.ldap.authentication.ad.ActiveDirectoryLdapAuthenticationProvider;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.util.matcher.RequestMatcher;
import uk.gov.gsi.hmrc.cds.search.security.jwt.JwtAuthenticationProcessingFilter;
import uk.gov.gsi.hmrc.cds.search.security.jwt.JwtAuthenticationProvider;
import uk.gov.gsi.hmrc.cds.search.security.jwt.JwtTokenService;
import uk.gov.gsi.hmrc.cds.search.security.jwt.SkipPathRequestMatcher;

import java.util.Arrays;
import java.util.List;

@Configuration
@Profile({"!test"})
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Value("${app.ad-domain}")
    private String adDomain;

    @Value("${app.ad-server}")
    private String adServer;

    @Value("${app.ldap-search-base}")
    private String ldapSearchBase;

    @Value("${app.ldap-search-filter}")
    private String ldapSearchFilter;

    @Autowired
    private JwtAuthenticationProvider jwtAuthenticationProvider;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private JwtTokenService jwtTokenService;

    @Autowired
    private SearchUserContextMapper searchUserContextMapper;

    @Override
    protected void configure(AuthenticationManagerBuilder auth) {
        auth.authenticationProvider(activeDirectoryLdapAuthenticationProvider())
            .authenticationProvider(jwtAuthenticationProvider);
    }

    @Bean
    public ActiveDirectoryLdapAuthenticationProvider activeDirectoryLdapAuthenticationProvider() {
        ActiveDirectoryLdapAuthenticationProvider provider = new ActiveDirectoryLdapAuthenticationProvider(adDomain, adServer, ldapSearchBase);
        provider.setSearchFilter(ldapSearchFilter);
        provider.setUserDetailsContextMapper(searchUserContextMapper);
        return provider;
    }

    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        httpSecurity.csrf().disable().authorizeRequests()
                .antMatchers("/declarations/**").permitAll()
                .antMatchers("/facets/**").permitAll()
                .antMatchers("/swagger*").permitAll()
                .antMatchers("/swagger-resources/**").permitAll()
                .antMatchers("/webjars/**").permitAll()
                .antMatchers("/v2/api-docs").permitAll()
                .antMatchers("/manage/**").permitAll()
                .anyRequest()
                .authenticated().and()
                .addFilterBefore(authenticationTokenRequestFilter(), UsernamePasswordAuthenticationFilter.class)
                .addFilterBefore(jwtAuthenticationProcessingFilter(), UsernamePasswordAuthenticationFilter.class);
    }

    private AuthenticationTokenRequestFilter authenticationTokenRequestFilter() throws Exception {
        AuthenticationTokenRequestFilter filter = new AuthenticationTokenRequestFilter("/authentication/token",
                authenticationManagerBean(), objectMapper);
        filter.setAuthenticationSuccessHandler(authenticationTokenRequestSuccessHandler());
        filter.setAuthenticationFailureHandler(new JsonResponseAuthenticationFailureHandler(objectMapper));
        return filter;
    }

    private JwtAuthenticationProcessingFilter jwtAuthenticationProcessingFilter() throws Exception {
        JwtAuthenticationProcessingFilter filter = new JwtAuthenticationProcessingFilter(skipPathRequestMatcher(),
                authenticationManagerBean());
        filter.setAuthenticationFailureHandler(new JsonResponseAuthenticationFailureHandler(objectMapper));
        return filter;
    }

    private RequestMatcher skipPathRequestMatcher() {
        List<String> skipPaths = Lists.newArrayList("/authentication/token", "/swagger*", "/swagger-resources/**",
                "/webjars/**", "/v2/api-docs", "/manage/**");
        List<String> processingPath = Arrays.asList("/declarations", "/declarations/**","/facets", "/facets/**");
        return new SkipPathRequestMatcher(skipPaths, processingPath);
    }

    private AuthenticationSuccessHandler authenticationTokenRequestSuccessHandler() {
        return new AuthenticationTokenRequestSuccessHandler(objectMapper, jwtTokenService);
    }

    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return this.authenticationManager();
    }
}
