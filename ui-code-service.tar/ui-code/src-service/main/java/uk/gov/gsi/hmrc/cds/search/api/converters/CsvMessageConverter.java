package uk.gov.gsi.hmrc.cds.search.api.converters;

import com.opencsv.CSVWriter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.converter.AbstractHttpMessageConverter;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.List;
import java.util.stream.Collectors;

@Component
@Slf4j
public class CsvMessageConverter extends AbstractHttpMessageConverter<DeclarationSearchResult> {

    private static String CONVERTER_MEDIA_TYPE = "text/csv";

    static final String[] HEADER = new String[] {
            "Declaration ID",
            "Import/Export",
            "Declaration Source",
            "EPU",
            "Entry Number",
            "Entry Date",
            "Route of Entry",
            "Country of Dispatch",
            "Country of Destination",
            "Consignee EORI",
            "Consignee Name",
            "Consignee Postcode",
            "Consignor EORI",
            "Consignor Name",
            "Consignor Postcode",
            "Goods Location",
            "Mode of Transport",
            "Declaration Type"
    };

    public CsvMessageConverter() {
        super(MediaType.valueOf(CONVERTER_MEDIA_TYPE));
    }

    @Override
    protected boolean supports(Class<?> aClass) {
        return DeclarationSearchResult.class.isAssignableFrom(aClass);
    }

    @Override
    protected DeclarationSearchResult readInternal(Class<? extends DeclarationSearchResult> aClass, HttpInputMessage httpInputMessage)
            throws IOException, HttpMessageNotReadableException {
        throw new HttpMessageNotReadableException("Not supported");
    }

    @Override
    protected void writeInternal(DeclarationSearchResult searchResult, HttpOutputMessage httpOutputMessage) throws  HttpMessageNotWritableException {
        httpOutputMessage.getHeaders().add(HttpHeaders.CONTENT_TYPE, CONVERTER_MEDIA_TYPE);

        try (final Writer writer = new OutputStreamWriter(httpOutputMessage.getBody())) {

            CSVWriter csvWriter = new CSVWriter(writer,
                    CSVWriter.DEFAULT_SEPARATOR,
                    CSVWriter.NO_QUOTE_CHARACTER,
                    CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                    CSVWriter.DEFAULT_LINE_END);

            csvWriter.writeNext(HEADER);

            List<String[]> declarationHeaders = searchResult.getDeclarations().stream()
                    .map(Declaration::asDeclarationHeaderArray)
                    .collect(Collectors.toList());
            csvWriter.writeAll(declarationHeaders);

        } catch (Exception ex) {
            logger.error("Unable to output declarations in CSV format.", ex);
        }
    }
}
