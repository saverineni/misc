package uk.gov.gsi.hmrc.cds.search.api.dto.response.facets;


import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Facet {

    private String id;
    private long count;
}
