package uk.gov.gsi.hmrc.cds.search.api.resources;

import lombok.RequiredArgsConstructor;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;
import uk.gov.gsi.hmrc.cds.search.api.exceptions.ResourceNotFoundException;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.ElasticDeclarationSearchService;

@RestController
@RequiredArgsConstructor
public class DeclarationResource extends RequestBinder {

    private final ElasticDeclarationSearchService elasticDeclarationSearchService;

    @GetMapping(value = "/declarations")
    public DeclarationSearchResult getDeclarationSearchResult(SearchCriteria searchCriteria,
    		BindingResult errors) {
    	if (errors.getSuppressedFields().length > 0) {
    		throw new UnsupportedRequestParameterException(errors.getSuppressedFields());
    	}
    	
        return elasticDeclarationSearchService.fetchDeclarationSearchResult(searchCriteria);
    }

    @GetMapping(value = "/declarations/{declarationId}")
    public Declaration getDeclarationById(@PathVariable String declarationId) {
        return  elasticDeclarationSearchService.fetchDeclarationById(declarationId)
                .orElseThrow(ResourceNotFoundException::new);
    }

}
