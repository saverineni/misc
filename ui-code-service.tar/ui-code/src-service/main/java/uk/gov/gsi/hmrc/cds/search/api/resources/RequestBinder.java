package uk.gov.gsi.hmrc.cds.search.api.resources;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.Arrays;
import java.util.List;

@Component
public class RequestBinder {

    public static final List<String> ALLOWED_FACET_TYPES = Arrays.asList("originCountryCode", "dispatchCountryCode",
            "destinationCountryCode", "transportModeCode", "goodsLocation", "commodityCode");

    @InitBinder
    protected void initBinder(WebDataBinder binder) {
        binder.setAllowedFields("pageNumber", "pageSize", "facetType", "prefix", "searchTerm", "eori",
                "originCountryCode", "dispatchCountryCode", "destinationCountryCode", "transportModeCode",
                "goodsLocation", "declarationType", "commodityCode", "entryDateFrom", "entryDateTo", "clearanceDateFrom", "clearanceDateTo");
    }


    @SuppressWarnings("serial")
    @ResponseStatus(code = HttpStatus.BAD_REQUEST)
    static class UnsupportedRequestParameterException extends RuntimeException {
        public UnsupportedRequestParameterException(String[] suppressedFields) {
            super("Unsupported request parameters: " + String.join(",", suppressedFields));
        }
    }
}
