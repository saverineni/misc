package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;

import java.util.List;
import java.util.Optional;

import static java.util.Collections.emptyList;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Declaration {
    private String declarationSource;
    private String importExportIndicator;
    private String declarationId;
    private String epuNumber;
    private String entryNumber;
    private String entryDate;
    private String route;
    private Country dispatchCountry;
    private Country destinationCountry;
    private String consigneeTurn;
    private String consignorTurn;
    private String goodsLocation;
    private String transportModeCode;
    private String consigneeName;
    private String consigneePostcode;
    private String consignorName;
    private String consignorPostcode;
    private String declarationType;
    private List<DeclarationLine> lines;

    public List<DeclarationLine> getLines() {
        return lines == null ? emptyList() : lines;
    }

    public String[] asDeclarationHeaderArray() {
        String dispatch = Optional.ofNullable(dispatchCountry).map(Country::getCode).orElse(null);
        String destination = Optional.ofNullable(destinationCountry).map(Country::getCode).orElse(null);
        return new String[]{
            declarationId,
            importExportIndicator,
            declarationSource,
            epuNumber,
            entryNumber,
            entryDate,
            route,
            dispatch,
            destination,
            consigneeTurn,
            consigneeName,
            consigneePostcode,
            consignorTurn,
            consignorName,
            consignorPostcode,
            goodsLocation,
            transportModeCode,
            declarationType
        };
    }

}
