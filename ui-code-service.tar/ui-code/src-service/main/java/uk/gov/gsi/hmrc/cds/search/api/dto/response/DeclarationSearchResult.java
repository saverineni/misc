package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import java.util.List;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class DeclarationSearchResult {
    Hits hits;
    List<Declaration> declarations;
}


