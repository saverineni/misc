package uk.gov.gsi.hmrc.cds.search.security.jwt;

import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.OrRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

import static java.util.stream.Collectors.toList;

public class SkipPathRequestMatcher implements RequestMatcher{

    private OrRequestMatcher skipRequestMatcher;
    private OrRequestMatcher processRequestMatcher;

    public SkipPathRequestMatcher(List<String> skipPaths, List<String> processPaths) {

        skipRequestMatcher = new OrRequestMatcher(
                skipPaths.stream()
                        .map(AntPathRequestMatcher::new)
                        .collect(toList())
        );

        processRequestMatcher = new OrRequestMatcher(
                processPaths.stream()
                        .map(AntPathRequestMatcher::new)
                        .collect(toList())
        );
    }


    @Override
    public boolean matches(HttpServletRequest request) {
        return !skipRequestMatcher.matches(request) && processRequestMatcher.matches(request);
    }
}
