package uk.gov.gsi.hmrc.cds.search.config;

import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ESConfig {

    @Value("${elasticsearch.host}") String elasticSearchHost;
    @Value("${elasticsearch.port}") int elasticSearchPort;
    @Value("${elasticsearch.username}") String username;
    @Value("${elasticsearch.password}") String password;
    @Value("${elasticsearch.connectTimeout}") int connectTimeout;
    @Value("${elasticsearch.socketTimeout}") int socketTimeout;
    @Value("${elasticsearch.retryTimeout}") int retryTimeout;

    @Bean
    public RestHighLevelClient esRestHighlevelClient() {
        return new RestHighLevelClient(
            RestClient.builder(new HttpHost(elasticSearchHost, elasticSearchPort))
                .setRequestConfigCallback(requestConfigBuilder ->
                        requestConfigBuilder
                                .setConnectTimeout(connectTimeout)
                                .setSocketTimeout(socketTimeout)
                )
                .setMaxRetryTimeoutMillis(retryTimeout)
                .setHttpClientConfigCallback(httpClientConfig ->
                    httpClientConfig.setDefaultCredentialsProvider(esCredentialsProvider())
                )
        );
    }

    private CredentialsProvider esCredentialsProvider() {
        CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
        credentialsProvider.setCredentials(
                AuthScope.ANY, new UsernamePasswordCredentials(username, password));

        return credentialsProvider;
    }
}
