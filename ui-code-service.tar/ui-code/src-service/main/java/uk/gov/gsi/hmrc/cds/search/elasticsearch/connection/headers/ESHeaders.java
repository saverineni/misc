package uk.gov.gsi.hmrc.cds.search.elasticsearch.connection.headers;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.slf4j.MDC;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import uk.gov.gsi.hmrc.cds.search.filter.CorrelationIdFilter;

@Slf4j
@Component
public class ESHeaders {

    private static final String X_CORRELATION_ID = "X-Correlation-ID";
    private static final String ES_RUN_AS_USER = "es-security-runas-user";

    public Header[] getHeaders() {
        return new BasicHeader[]{ correlationId(), pid() };
    }

    private BasicHeader pid() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String pid = auth.getName();

        log.debug("User run-as pid: {}", pid);
        BasicHeader userPIDHeader = new BasicHeader(ES_RUN_AS_USER, pid);
        return userPIDHeader;
    }

    private BasicHeader correlationId() {
        String correlationId = MDC.get(CorrelationIdFilter.MDC_CORRELATION_ID);
        log.debug("Request correlation id: {}", correlationId);

        BasicHeader correlationIDHeader = new BasicHeader(X_CORRELATION_ID, correlationId);
        return correlationIDHeader;
    }
}