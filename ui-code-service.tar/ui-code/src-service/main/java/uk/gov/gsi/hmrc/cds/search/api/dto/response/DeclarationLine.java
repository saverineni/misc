package uk.gov.gsi.hmrc.cds.search.api.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeclarationLine {
    private int itemNumber;
    private Country itemDispatchCountry;
    private Country itemDestinationCountry;
    private String clearanceDate;
    private String cpc;
    private Country originCountry;
    private String commodityCode;
    private String itemConsigneeTurn;
    private String itemConsignorTurn;
    private String itemRoute;
    private String itemConsigneeName;
    private String itemConsigneePostcode;
    private String itemConsignorName;
    private String itemConsignorPostcode;
}
