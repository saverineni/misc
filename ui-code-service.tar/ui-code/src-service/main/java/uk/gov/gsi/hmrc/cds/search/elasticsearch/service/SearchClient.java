package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.connection.headers.ESHeaders;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import static org.elasticsearch.index.query.QueryBuilders.multiMatchQuery;
import static org.elasticsearch.index.query.QueryBuilders.rangeQuery;
import static org.elasticsearch.search.aggregations.AggregationBuilders.terms;

@Service
public class SearchClient {

    private static final String LINES_ORIGIN_COUNTRY_CODE = "lines.originCountry.code";
    private static final String DISPATCH_COUNTRY_CODE = "dispatchCountry.code";
    private static final String DESTINATION_COUNTRY_CODE = "destinationCountry.code";
    private static final String TRANSPORT_MODE_CODE = "transportModeCode";
    private static final String GOODS_LOCATION = "goodsLocation";
    private static final String LINES_COMMODITY_CODE = "lines.commodityCode";
    private static final String ENTRY_DATE = "entryDate";
    private static final String CLEARANCE_DATE = "lines.clearanceDate";
    /**
     * This is necessary to ensure we retrieve all countries from the aggregation, if the total number of possible
     * countries exceeds this number there will be some entries missing from the resulting aggregation.
     */
    private static final int COUNTRY_CARDINALITY = 400;
    private static final int TRANSPORT_MODE_CARDINALITY = 10;
    private static final int GOODS_LOCATION_CARDINALITY = 400;
    private static final DateTimeFormatter esDateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
    public static final List<String> LINE_FACETS = Arrays.asList("originCountryCode", "commodityCode");

    private static final String[] SEARCH_TERM_FIELDS = {
            "declarationId",
            "epuNumber",
            "entryNumber",
            "consigneeName",
            "consigneePostcode",
            "consignorName",
            "consignorPostcode",
            LINES_COMMODITY_CODE,
            "lines.originCountry.code.codeText",
            "lines.cpc",
            "lines.itemConsigneeName",
            "lines.itemConsigneePostcode",
            "lines.itemConsignorName",
            "lines.itemConsignorPostcode"
    };

    private static final String[] EORI_FIELDS = {
            "consigneeTurn",
            "consignorTurn",
            "lines.itemConsigneeTurn",
            "lines.itemConsignorTurn"
    };

    private static final String[] ALL_SEARCH_FIELDS = Stream.of(SEARCH_TERM_FIELDS, EORI_FIELDS)
            .flatMap(Stream::of)
            .toArray(String[]::new);


    private final RestHighLevelClient client;
    private final String searchAlias;
    private final ESHeaders esHeaders;

    private enum FieldMapping {
        ORIGIN_COUNTRY_CODE_FIELD("originCountryCode", LINES_ORIGIN_COUNTRY_CODE, COUNTRY_CARDINALITY),
        DISPATCH_COUNTRY_CODE_FIELD("dispatchCountryCode", DISPATCH_COUNTRY_CODE, COUNTRY_CARDINALITY),
        DESTINATION_COUNTRY_CODE_FIELD("destinationCountryCode", DESTINATION_COUNTRY_CODE, COUNTRY_CARDINALITY),
        COMMODITY_CODE_FIELD("commodityCode", LINES_COMMODITY_CODE, 1000),
        TRANSPORT_MODE_CODE_FIELD("transportModeCode", TRANSPORT_MODE_CODE, TRANSPORT_MODE_CARDINALITY),
        GOODS_LOCATION_FIELD("goodsLocation", GOODS_LOCATION, GOODS_LOCATION_CARDINALITY);

        private String facetType;
        private String field;
        private int cardinality;

        FieldMapping(String facetType, String field, int cardinality) {
            this.facetType = facetType;
            this.field = field;
            this.cardinality = cardinality;
        }

        public String getFacetType() {
            return facetType;
        }

        public String getField() {
            return field;
        }

        public int getCardinality() {
            return cardinality;
        }

        public static FieldMapping retrieveFieldMapping(String facetType) {
            return Arrays.stream(FieldMapping.values()).filter(mapping -> mapping.getFacetType().equalsIgnoreCase(facetType)).findFirst().orElse(null);
        }
    }

    public SearchClient(RestHighLevelClient client,
                        @Value("${elasticsearch.alias}") String searchAlias,
                        ESHeaders esHeaders) {
        this.client = client;
        this.searchAlias = searchAlias;
        this.esHeaders = esHeaders;
    }

    public SearchResponse getDeclarationById(String declarationId) {
        try {
            SearchRequest searchRequest = new SearchRequest(searchAlias);
            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(QueryBuilders.matchQuery("_id", declarationId));
            searchRequest.source(searchSourceBuilder);
            return client.search(searchRequest, esHeaders.getHeaders());
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    public SearchResponse declarationSearch(SearchCriteria searchCriteria) {
        BoolQueryBuilder query = QueryBuilders.boolQuery().must(QueryBuilders.matchAllQuery());
        return searchES(getQueryBuilder(searchCriteria, query), searchCriteria.getPageNumber(), searchCriteria.getPageSize());
    }

    public SearchResponse facetSearch(SearchCriteria searchCriteria, String facetType, Optional<String> prefix) {
        BoolQueryBuilder query = QueryBuilders.boolQuery().must(QueryBuilders.matchAllQuery());
        if (prefix.isPresent()) {
            query.must(QueryBuilders.matchQuery(getFacetFieldName(facetType), prefix.get()));
        }
        QueryBuilder queryBuilder = getQueryBuilder(searchCriteria, query);
        return searchFacetES(queryBuilder, FieldMapping.retrieveFieldMapping(facetType));
    }

    private String getFacetFieldName(String facetType) {
        return LINE_FACETS.contains(facetType) ? "lines." + facetType + ".prefix" : facetType + ".prefix";
    }

    private QueryBuilder getQueryBuilder(SearchCriteria searchCriteria, BoolQueryBuilder query) {
        buildSearchTermQuery(query, searchCriteria);
        buildEoriQuery(query, searchCriteria);
        buildFacets(searchCriteria, query);
        buildDateRangeQuery(query, ENTRY_DATE, searchCriteria.optionalEntryDateTimeFrom(), searchCriteria.optionalEntryDateTimeTo());
        buildDateRangeQuery(query, CLEARANCE_DATE, searchCriteria.optionalClearanceDateTimeFrom(), searchCriteria.optionalClearanceDateTimeTo());
        buildDeclarationTypeQuery(query, searchCriteria.getDeclarationType().stream());
        return query;
    }

    private void buildDeclarationTypeQuery(BoolQueryBuilder query, Stream<String> stream) {
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
        stream.map(decType -> shouldArray(queryBuilder, decType, "declarationType")).reduce(query, BoolQueryBuilder::must);
    }

    private void buildFacets(SearchCriteria searchCriteria, BoolQueryBuilder query) {
        buildQueryFacets(query, searchCriteria.getOriginCountryCode().stream(), LINES_ORIGIN_COUNTRY_CODE);
        buildQueryFacets(query, searchCriteria.getDispatchCountryCode().stream(), DISPATCH_COUNTRY_CODE);
        buildQueryFacets(query, searchCriteria.getDestinationCountryCode().stream(), DESTINATION_COUNTRY_CODE);
        buildQueryFacets(query, searchCriteria.getTransportModeCode().stream(), TRANSPORT_MODE_CODE);
        buildQueryFacets(query, searchCriteria.getGoodsLocation().stream(), GOODS_LOCATION);
        buildQueryFacets(query, searchCriteria.getCommodityCode().stream(), LINES_COMMODITY_CODE);
    }

    private void buildSearchTermQuery(BoolQueryBuilder query, SearchCriteria searchCriteria) {
        searchCriteria.optionalSearchTerm().map(it -> query.must(multiMatchQuery(it, ALL_SEARCH_FIELDS)));
    }

    private void buildEoriQuery(BoolQueryBuilder query, SearchCriteria searchCriteria) {
        searchCriteria.optionalEori().map(it -> query.must(multiMatchQuery(it, EORI_FIELDS)));
    }

    private void buildQueryFacets(BoolQueryBuilder query, Stream<String> stream, String facetType) {
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
        stream.map(facetId -> shouldArray(queryBuilder, facetId, facetType)).reduce(query, BoolQueryBuilder::must);
    }

    private BoolQueryBuilder shouldArray(BoolQueryBuilder query, String value, String term) {
        return query.should(QueryBuilders.termQuery(term, value));
    }

    private void buildDateRangeQuery(BoolQueryBuilder query, String field, Optional<LocalDateTime> from, Optional<LocalDateTime> to) {
        if (from.isPresent() || to.isPresent()) {
            RangeQueryBuilder rangeQuery = rangeQuery(field);
            RangeQueryBuilder rangeWithFrom = from.map(dateTime ->
                    rangeQuery.gte(dateTime.format(esDateTimeFormatter))
            ).orElse(rangeQuery);
            RangeQueryBuilder rangeWithTo = to.map(dateTime ->
                    rangeWithFrom.lte(dateTime.format(esDateTimeFormatter))
            ).orElse(rangeWithFrom);
            query.must(rangeWithTo);
        }
    }

    private SearchResponse searchES(QueryBuilder queryBuilder, int pageNumber, int pageSize) {
        try {
            SearchRequest searchRequest = new SearchRequest(searchAlias);
            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            SearchSourceBuilder searchSourceBuilderWithQuery = searchSourceBuilder.query(queryBuilder);
            int offSet = (pageNumber - 1) * pageSize;
            searchSourceBuilderWithQuery.from(offSet);
            searchSourceBuilderWithQuery.size(pageSize);
            searchRequest.source(searchSourceBuilderWithQuery);

            return client.search(searchRequest, esHeaders.getHeaders());
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    private SearchResponse searchFacetES(QueryBuilder queryBuilder, FieldMapping fieldMapping) {
        try {
            SearchRequest searchRequest = new SearchRequest(searchAlias);
            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(queryBuilder).size(0);
            searchSourceBuilder
                    .aggregation(
                            terms("facets").field(fieldMapping.getField()).size(fieldMapping.getCardinality())
                    );
            searchRequest.source(searchSourceBuilder);
            return client.search(searchRequest, esHeaders.getHeaders());
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
    }
}
