package uk.gov.gsi.hmrc.cds.search.security.jwt;

import com.google.common.base.Splitter;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.util.matcher.RequestMatcher;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;
import static com.google.common.base.Predicates.containsPattern;


public class JwtAuthenticationProcessingFilter extends AbstractAuthenticationProcessingFilter {

    public JwtAuthenticationProcessingFilter(RequestMatcher requestMatcher, AuthenticationManager authenticationManager) {
        super(requestMatcher);
        setAuthenticationManager(authenticationManager);
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException {
        String authorization = request.getHeader("Authorization");

        try{
            checkState(
                    containsPattern("^Bearer\\s([\\w\\-=]+)\\.([\\w\\-=]+)\\.([\\w\\-=]+)$")
                            .apply(checkNotNull(authorization))
            );
        } catch(NullPointerException | IllegalStateException ex){
            throw new AuthenticationCredentialsNotFoundException("Authorization Header missing",ex);
        }

        String token = Splitter.on(" ").splitToList(authorization).get(1);

        return getAuthenticationManager().authenticate(
                new JwtAuthenticationToken(token)
        );
    }

    @Override
    protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain, Authentication authResult) throws IOException, ServletException {
        chain.doFilter(request, response);
    }
}
