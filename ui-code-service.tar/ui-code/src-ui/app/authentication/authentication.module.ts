import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SignInComponent } from './sign-in/sign-in.component';
import { MatInputModule , MatButtonModule, MatCardModule, MatIconModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AuthenticationRoutingModule } from './routing/authentication-routing.module';
import { AuthenticationService } from './authentication.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CacheService } from "./cache.service";
import { UserDetailsComponent } from './user-details/user-details.component';
import { UserService } from './user.service';
import { SignInRouterService } from './sign-in/sign-in-router.service';
import { BuildInfoService } from './build-info.service';

@NgModule({
  imports: [
    AuthenticationRoutingModule,
    CommonModule,
    FlexLayoutModule,
    MatButtonModule,
    MatInputModule,
    MatIconModule,
    MatCardModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule
  ],
  declarations: [SignInComponent, UserDetailsComponent],
  exports: [SignInComponent, UserDetailsComponent],
  providers: [
    AuthenticationService,
    CacheService,
    UserService,
    SignInRouterService,
    BuildInfoService
  ]
})
export class AuthenticationModule { }
