import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { BuildInfo } from './build-info';

@Injectable()
export class BuildInfoService {

  constructor(private http: HttpClient) {}

  get buildInfo(): Observable<BuildInfo> { 
    return this.http
    .get("/build/info")
    .pipe(
      map(buildInfo => buildInfo as BuildInfo)
    );
  }

}
