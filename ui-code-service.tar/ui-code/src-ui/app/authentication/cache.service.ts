import { Injectable } from '@angular/core';
import { User } from './user';
import { isNil } from 'lodash';


@Injectable()
export class CacheService {
  static TOKEN_KEY = 'currentUser';

  getToken(): string {
    return localStorage.getItem(CacheService.TOKEN_KEY);
  }

  setToken(token: string) {
    localStorage.setItem(CacheService.TOKEN_KEY, token);
  }

  getUser(): User {
    const token = this.getToken();
    const userPayload = !isNil(token) ? token.split(".")[1] : undefined;
    
    if (userPayload) {  
      return JSON.parse(window.atob(userPayload)).user as User;
    }
    return null;
  }

  clear() {
    localStorage.clear();
  }
}
