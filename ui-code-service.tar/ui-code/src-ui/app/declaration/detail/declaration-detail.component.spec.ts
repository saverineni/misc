import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {DeclarationDetailComponent} from './declaration-detail.component';
import {MatCardModule, MatDividerModule, MatExpansionModule, MatIconModule} from '@angular/material';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {Directive, Input, DebugElement} from '@angular/core';
import {Declaration} from './declaration';
import {ActivatedRoute} from '@angular/router';
import {Observable, of} from 'rxjs';
import {By} from '@angular/platform-browser';
import {DeclarationLine} from './declaration-line';
import {DeclarationService} from './declaration.service';
import {Column} from '../../elements-library/cds-data-grid/column-definition';
import {RouterTestingModule} from '@angular/router/testing';

@Directive({
  selector: 'cds-data-grid'
})
export class DeclarationDataGridStub {
  @Input() columnCount: number;
  @Input() columns: Observable<Column[]>;
}
@Directive({
  selector: 'cds-breadcrumb'
})
export class BreadCrumbStub {
  @Input() breadcrumbs = [];
}

describe('DeclarationDetailComponent', () => {
  let component: DeclarationDetailComponent;
  let fixture: ComponentFixture<DeclarationDetailComponent>;
  let declaration: Declaration;
  let mockDeclarationService: DeclarationService;
  let activatedRoute: ActivatedRoute;

  let importDeclarationTypeCard: DebugElement;
  let exportDeclarationTypeCard: DebugElement;

  beforeEach(async(() => {
    declaration = new Declaration();
    declaration.declarationId = 'id';
    let obs: any = of(declaration);

    activatedRoute = {
      data: obs
    } as ActivatedRoute;

    mockDeclarationService = {
      declarationForRoute: (route) => obs
    } as DeclarationService;
    spyOn(mockDeclarationService, 'declarationForRoute').and.callThrough();

    TestBed.configureTestingModule({
      imports: [MatCardModule, MatDividerModule, MatExpansionModule, BrowserAnimationsModule, RouterTestingModule, MatIconModule],
      declarations: [ DeclarationDetailComponent, DeclarationDataGridStub, BreadCrumbStub ],
      providers: [
        { provide: ActivatedRoute, useValue: activatedRoute },
        { provide: DeclarationService, useValue: mockDeclarationService }
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DeclarationDetailComponent);
    component = fixture.componentInstance;
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call the declaration service with the route', () => {
    fixture.detectChanges();
    expect(mockDeclarationService.declarationForRoute).toHaveBeenCalledWith(activatedRoute);
  });

  describe('data grid', () => {
    let dataGrid: DeclarationDataGridStub;

    beforeEach(() => {
      fixture.detectChanges();

      dataGrid = fixture.debugElement.query(By.directive(DeclarationDataGridStub)).injector.get(DeclarationDataGridStub);
    });

    it('should set the column count', () => {
      expect(dataGrid.columnCount).toBe(4);
    });

    it('should generate the grid columns', (done) => {
      dataGrid.columns.subscribe(
        columns => {
          expect(columns).toEqual(component.declarationHeaderColumnDefinitions.map(it => it.toColumn(declaration)));
          done();
        },
        done.fail
      );
    });
  });

  describe('import/export type', () => {

    function findImportExportTypes() {
      importDeclarationTypeCard = fixture.debugElement.query(By.css('.declaration-detail__declarations--import'));
      exportDeclarationTypeCard = fixture.debugElement.query(By.css('.declaration-detail__declarations--export'));  
    }

    function setImportExportType(declarationType) {
      declaration.importExportIndicator = declarationType;
      fixture.detectChanges();
    }

    it('with colour yellow for an import', () => {
      setImportExportType('Import');
      findImportExportTypes();

      expect(importDeclarationTypeCard).toBeTruthy();
      expect(exportDeclarationTypeCard).toBeFalsy();

    });

    it('with colour blue for an export', () => {
      setImportExportType('Export');        
      findImportExportTypes();

      expect(importDeclarationTypeCard).toBeFalsy();
      expect(exportDeclarationTypeCard).toBeTruthy();
    });
  });  

  describe('item details button', () => {
    function getItemDetailsDisabledButton() {
      return fixture.debugElement.query(By.css('button.declaration-detail__item-details-button'));
    }

    function getItemDetailsLink() {
      return fixture.debugElement.query(By.css('a.declaration-detail__item-details-button'));
    }

    describe('with lines', () => {
      beforeEach(() => {
        declaration.lines = [new DeclarationLine(), new DeclarationLine()]
        fixture.detectChanges();
      });

      it('should have the correct link for the first items details', () => {
        let href = getItemDetailsLink().nativeElement.getAttribute('ng-reflect-router-link');
        expect(href).toEqual('/declarations/id/items/1');
      });

      it('should report the correct number of items', () => {
        expect(getItemDetailsLink().nativeElement.innerText).toEqual('ITEM DETAIL (2)');
      });

      it('should not be disabled when there are items', () => {
        expect(getItemDetailsLink() === null).toBe(false);
        expect(getItemDetailsDisabledButton() === null).toBe(true);
      });
    });

    describe('without lines', () => {
      beforeEach(() => {
        declaration.lines = [];
        fixture.detectChanges();
      });

      it('should report zero items correctly', () => {
        expect(getItemDetailsDisabledButton().nativeElement.innerText).toEqual('ITEM DETAIL (0)');
      });

      it('should be disabled when there are zero items', () => {
        expect(getItemDetailsDisabledButton().nativeElement.disabled).toBe(true);
      });
    });
  });
});
