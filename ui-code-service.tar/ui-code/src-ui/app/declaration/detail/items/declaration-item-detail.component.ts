import { Component, OnInit, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ChangeDetectionStrategy } from '@angular/core';
import { ColumnDefinition } from '../../../elements-library/cds-data-grid/column-definition';
import { DeclarationService } from '../declaration.service';
import { Observable, of } from 'rxjs';
import { ViewEncapsulation } from '@angular/core';
import { Location } from '@angular/common';
import { TrackBy } from '../../../track-by';
import { ViewChild } from '@angular/core';
import { LinesSelection } from '../lines-selection';
import { Breadcrumb } from "../../breadcrumb/breadcrumb";

@Component({
  selector: 'cds-declaration-item-detail',
  templateUrl: './declaration-item-detail.component.html',
  styleUrls: ['./declaration-item-detail.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class DeclarationItemDetailComponent implements OnInit {
  trackByItemNumber = TrackBy.property('itemNumber');

  @ViewChild('tabs') tabs;
  @ViewChild('itemFilter') set content(content: ElementRef) {
    if (content) {
        content.nativeElement.focus();
    }
 }

  linesSelection$: Observable<LinesSelection>;
  noResults: boolean;
  breadcrumbs: Array<Breadcrumb>;

  constructor(private route: ActivatedRoute,
              private router: Router,
              private declarationService: DeclarationService,
              private location: Location) { }

  ngOnInit() {
    this.linesSelection$ = this.declarationService.itemsForRoute(this.route);

    this.breadcrumbs = [
      new Breadcrumb('Declaration Detail', this.getDeclarationDetailUrl()),
      new Breadcrumb('Item Detail')
    ]
  }

  onIndexChange(declarationId, number) {
    this.location.replaceState(`/declarations/${declarationId}/items/${number + 1}`);
  }

  onFilterInput(itemFilter, items) {
    let itemNumber = +itemFilter;
    if (!itemFilter || itemFilter === '') {
      this.noResults = false;
    } else if (!isNaN(itemNumber) && itemNumber > 0 && itemNumber <= items.length) {
      this.noResults = false;
      this.tabs.selectedIndex = itemNumber - 1;
    } else  {
      this.noResults = true;
    }
  }

  declarationItemColumnDefinitions = [
    new ColumnDefinition({ id: 'declarationId', label: 'Declaration ID', strong: true }),
    new ColumnDefinition({ id: 'importExportIndicator', label: 'Import/Export', strong: true }),
    new ColumnDefinition({ id: 'declarationSource', label: 'Declaration Source', strong: true }),
    new ColumnDefinition({ id: 'declarationType', label: 'Declaration type', strong: true }),
    new ColumnDefinition({ id: 'itemRoute', label: 'Route of Entry' }),
    new ColumnDefinition({ id: 'itemDispatchCountry', label: 'Country of Dispatch',
      getValue: (item) => item.itemDispatchCountry && item.itemDispatchCountry.code }),
    new ColumnDefinition({ id: 'itemDestinationCountry', label: 'Country of Destination',
      getValue: (item) => item.itemDestinationCountry && item.itemDestinationCountry.code }),
    new ColumnDefinition({ id: 'clearanceDate', label: 'Clearance Date', type: 'timestamp' }),
    new ColumnDefinition({ id: 'cpc', label: 'CPC' }),
    new ColumnDefinition({ id: 'originCountry', label: 'Country of Origin',
      getValue: (item) => item.originCountry && item.originCountry.code }),
    new ColumnDefinition({ id: 'commodityCode', label: 'Commodity Code' }),
    new ColumnDefinition({ id: 'itemConsigneeTurn', label: 'Consignee EORI' }),
    new ColumnDefinition({ id: 'itemConsigneeName', label: 'Consignee Name' }),
    new ColumnDefinition({ id: 'itemConsigneePostcode', label: 'Consignee Postcode' }),
    new ColumnDefinition({ id: 'itemConsignorTurn', label: 'Consignor EORI' }),
    new ColumnDefinition({ id: 'itemConsignorName', label: 'Consignor Name' }),
    new ColumnDefinition({ id: 'itemConsignorPostcode', label: 'Consignor Postcode' })
  ];

  itemColumns(item) {
    return of(this.declarationItemColumnDefinitions.map(it => it.toColumn(item)))
  }

  getDeclarationDetailUrl(): string {
    let itemDetailUrl: string = this.router.routerState.snapshot.url;
    return itemDetailUrl.replace(/\/items\/.*/, '');

  }
}
