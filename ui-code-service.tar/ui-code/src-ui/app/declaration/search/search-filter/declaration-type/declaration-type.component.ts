import {ChangeDetectorRef, Component, OnInit, ViewChild} from '@angular/core';
import {SearchCriteria} from "../../search-criteria";
import {SearchCriteriaService} from "../../search-criteria.service";
import {ClearAndClosable} from "../clear-and-closable";

@Component({
  selector: 'cds-declaration-type-filter',
  templateUrl: './declaration-type.component.html',
  styleUrls: ['./declaration-type.component.scss']
})
export class DeclarationTypeComponent implements OnInit, ClearAndClosable {

  imports: Array<any> = [];
  exports: Array<any> = [];
  selectedItems: Set<string> = new Set();
  importSelectAll: boolean = false;
  exportSelectAll: boolean = false;
  importsAndExports: Array<any> = [];

  private searchParam: string;
  private subscription;
  private searchCriteria: SearchCriteria = null;

  @ViewChild('decTypePanel') panel;

  constructor(private searchCriteriaService: SearchCriteriaService,
              private changeDetectorRef: ChangeDetectorRef) {
    this.imports=[
      {name : "X", checked : false},
      {name : "Y", checked : false},
      {name : "Z", checked : false}
    ];
    this.exports=[
      {name : "D", checked : false},
      {name : "F", checked : false},
      {name : "K", checked : false}
    ];
    this.importsAndExports = [...this.imports, ...this.exports];
    this.searchParam ='declarationType';
  }

  ngOnInit() {

    this.subscription = this.searchCriteriaService.searchCriteria.subscribe(
      newCriteria  => {
        this.searchCriteria = newCriteria;
        this.selectItems();
        this.toggleExpansionPanel();
        this.changeDetectorRef.detectChanges();
      }
    );
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  selectImportAll() {
    console.log('IMPORT ALL **********' + this.importSelectAll);
    this.imports.forEach( (imp) => { imp.checked = this.importSelectAll;} );

    this.imports.forEach( (item) => {
     // console.log(item.checked);
    });
  }

  selectExportAll() {
    this.exports.forEach( (exp) => { exp.checked = this.exportSelectAll;} );
  }

  selectDeselectImportsAll() {
    this.importSelectAll = this.imports.filter(imp => imp.checked).length == this.imports.length ? true : false;
  }

  selectDeselectExportsAll() {
    this.exportSelectAll = this.exports.filter(exp => exp.checked).length == this.imports.length ? true : false;
  }

  onClear() {
    this.clearImportsExports()
    this.onApplyFilters();
  }

  onApplyFilters(){
    const update = {};
    if (this.isItemSelected) {
      update[this.searchParam] = Array.from(this.importsAndExports.filter(item => item.checked)
        .map( (item) => item.name));
    } else {
      update[this.searchParam] = null;
    }
    update['pageNumber'] = undefined;
    update['pageSize'] = undefined;

    this.searchCriteriaService.updatePartial(update);
  }

  clearAndClose() {
    this.clearImportsExports();
    this.panel.close();
  }

  private selectItems() {
    if (this.searchCriteria[this.searchParam]) {
      this.selectedItems = new Set<string>(this.searchCriteria[this.searchParam]);
      if(this.importsAndExports) {
        this.importsAndExports.forEach(item => {
          if (this.selectedItems.has(item.name as string)) {
            item.checked = true;
          }
        });
        this.selectDeselectImportsAll();
        this.selectDeselectExportsAll();
      }
    } else {
      this.clearAndClose();
    }
  }

  private isItemSelected() {
    return  this.importsAndExports.filter(item => item.checked).length > 0;
  }

  private clearImportsExports() {
    this.importsAndExports.forEach( (item) => {
      item.checked = false;
    })
    this.importSelectAll = false;
    this.exportSelectAll = false;
  }

  private toggleExpansionPanel() {
    if (this.isItemSelected()){
      this.panel.open();
    } else if (this.panel.expanded) {
      this.panel.close();
    }
  }


}
