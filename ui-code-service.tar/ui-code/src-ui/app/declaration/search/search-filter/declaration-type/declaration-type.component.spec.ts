import {async, ComponentFixture, fakeAsync, TestBed, tick} from '@angular/core/testing';

import {DeclarationTypeComponent} from './declaration-type.component';
import {FlexLayoutModule} from "@angular/flex-layout";
import {MAT_CHECKBOX_CLICK_ACTION, MatCheckboxChange, MatCheckboxModule, MatExpansionModule} from "@angular/material";
import {FormsModule} from "@angular/forms";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {SearchCriteriaService} from "../../search-criteria.service";
import {of} from "rxjs/index";
import {SearchCriteria} from "../../search-criteria";
import {By} from "@angular/platform-browser";
import {DebugElement} from "@angular/core";

describe('DeclarationTypeComponent', () => {
  let component: DeclarationTypeComponent;
  let fixture: ComponentFixture<DeclarationTypeComponent>;
  let searchCriteriaService: SearchCriteriaService;
  let searchCriteria: SearchCriteria;
  let filterExpansionPanel;

  beforeEach(async(() => {
    searchCriteria = new SearchCriteria();
    searchCriteriaService = {
      searchCriteria: of(searchCriteria),
      updatePartial: (params) => { }
    } as SearchCriteriaService;
    spyOn(searchCriteriaService, 'updatePartial');

    TestBed.configureTestingModule({
      providers: [
        { provide: SearchCriteriaService, useValue: searchCriteriaService },
        { provide: MAT_CHECKBOX_CLICK_ACTION, useValue: 'check'}
      ],
      imports: [
        MatCheckboxModule,
        FlexLayoutModule,
        MatExpansionModule,
        BrowserAnimationsModule,
        FormsModule
      ],
      declarations: [ DeclarationTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeclarationTypeComponent);
    component = fixture.componentInstance;
    searchCriteriaService = TestBed.get(SearchCriteriaService);
    filterExpansionPanel = fixture.debugElement.query(By.css('.declaration-type__header'));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('within expansion panel', () => {

    const checkboxChange = new MatCheckboxChange();

    let importAll: DebugElement;
    let exportAll: HTMLElement;
    let importX: HTMLElement;
    let importY: HTMLElement;
    let importZ: HTMLElement;
    let exportD: HTMLElement;
    let exportF: HTMLElement;
    let exportK: HTMLElement;

    let applyFiltersButton: HTMLElement;
    let clearButton: HTMLElement;

    beforeEach(() => {
      filterExpansionPanel.nativeElement.click();
      importAll = fixture.debugElement.query(By.css('.declaration-type__import-all-checkbox'));

      applyFiltersButton = fixture.debugElement.query(By.css('.declaration-type__apply-filters-button')).nativeElement;
      clearButton = fixture.debugElement.query(By.css('.declaration-type__clear-button')).nativeElement;
      fixture.detectChanges();
    });

    it('all checkboxes are deselected', () => {
      expect(component.importSelectAll).toEqual(false);
      expect(component.exportSelectAll).toEqual(false);
      component.importsAndExports.forEach( (item) => {
          expect(item.checked).toEqual(false);
      });
    });

    fit('import all checkbox selects all imports',  () => {
      checkboxChange.checked = true;
      importAll.nativeElement.click();
      selectImportAll();
      fixture.detectChanges();

      component.imports.forEach( (item) => {
        expect(item.checked).toEqual(true);
      });
    });

    function selectImportAll() {
      importAll.triggerEventHandler("change", checkboxChange);
    }

  });
});
