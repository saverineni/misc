import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchFieldComponent } from './search-field.component';
import { SearchCriteriaService } from "../../search-criteria.service";
import {
  MatExpansionModule,
  MatIconModule,
  MatInputModule
} from "@angular/material";
import { FormsModule } from "@angular/forms";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { By } from "@angular/platform-browser";
import { SearchCriteria } from "../../search-criteria";
import { of } from "rxjs/index";
import { FlexLayoutModule } from "@angular/flex-layout";
import {Directive, Input} from "@angular/core";

const SEARCH_PARAM_FIELD = 'eori';
const PLACEHOLDER = 'placeholder text';

@Directive({
  selector: 'app-tooltip'
})
export class TooltipComponentStub {
  @Input() tooltipText: string;
}
describe('SearchFieldComponent', () => {
  let component: SearchFieldComponent;
  let fixture: ComponentFixture<SearchFieldComponent>;
  let searchCriteriaService: SearchCriteriaService;
  let searchCriteria: SearchCriteria;

  beforeEach(async(() => {
    searchCriteria = new SearchCriteria();
    searchCriteriaService = {
      searchCriteria: of(searchCriteria),
      updatePartial: (params) => { }
    } as SearchCriteriaService;
    spyOn(searchCriteriaService, 'updatePartial');

    TestBed.configureTestingModule({
      declarations: [SearchFieldComponent, TooltipComponentStub],
      providers: [
        { provide: SearchCriteriaService, useValue: searchCriteriaService }
      ],
      imports: [
        FlexLayoutModule,
        MatIconModule,
        MatIconModule,
        MatInputModule,
        BrowserAnimationsModule,
        MatExpansionModule,
        FormsModule
      ]
    })
      .compileComponents();
  }));

  let filterExpansionPanel;

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFieldComponent);
    component = fixture.componentInstance;
    component.searchParamField = SEARCH_PARAM_FIELD;
    component.placeholder = PLACEHOLDER;

    searchCriteriaService = TestBed.get(SearchCriteriaService);
    filterExpansionPanel = fixture.debugElement.query(By.css('.search-field__header'));
    spyOn(component.panel, 'close');
  });

  it('should create', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  describe('clearAndClose', () => {
    beforeEach(() => {
      inputsearchField('text');
      expect(fixture.debugElement.query(By.css('.search-field__searchfield-input')).nativeElement.value).toBe('text');
      
      component.clearAndClose();
    });

    it('should remove the input value', () => {
      expect(fixture.debugElement.query(By.css('.search-field__searchfield-input')).nativeElement.value).toBe('');
    })

    it('should close the panel', () => {
      expect(component.panel.close).toHaveBeenCalled();
    })
  });

  describe('within expansion panel', () => {

    beforeEach(() => {
      filterExpansionPanel.nativeElement.click();
    });

    describe('Free text search field', () => {
      let searchFieldInput;
      beforeEach(() => {
        fixture.detectChanges();
        searchFieldInput = fixture.debugElement.query(By.css('.search-field__searchfield-input'));
      });

      it('should have a free text search field', () => {
        expect(searchFieldInput).toBeTruthy();
      });

      it('should have a label for free text search field', () => {
        expect(searchFieldInput.nativeElement.labels[0].textContent).toEqual(PLACEHOLDER);
      });
    });

    describe('clear icon click', () => {
      describe('value not previously empty', () => {
        beforeEach(() => {
          searchCriteria.eori = '123456';
          fixture.detectChanges();
          inputsearchField('123456');
          fixture.detectChanges();
          fixture.debugElement.query(By.css('.search-field__clear-search')).nativeElement.click();
        });

        it('clears search term', () => {
          const searchFieldInput = fixture.debugElement.query(By.css('.search-field__searchfield-input'));
          expect(searchFieldInput.nativeElement.value).toEqual('');
        });

        it('should update search criteria', () => {
          let searchCriteria: any = {};
          searchCriteria[SEARCH_PARAM_FIELD] = null;
          searchCriteria.pageNumber = undefined;
          searchCriteria.pageSize = undefined;

          expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteria);
        });
      });

      describe('value previously empty', () => {
        beforeEach(() => {
          fixture.detectChanges(); // to initialise value to empty string
          inputsearchField('1');
          fixture.detectChanges();
          fixture.debugElement.query(By.css('.search-field__clear-search')).nativeElement.click();
        });

        it('clears search term', () => {
          const searchFieldInput = fixture.debugElement.query(By.css('.search-field__searchfield-input'));
          expect(searchFieldInput.nativeElement.value).toEqual('');
        });

        it('shouldnt update search criteria', () => {
          expect(searchCriteriaService.updatePartial).not.toHaveBeenCalled();
        });
      });
    });

    describe('search icon', () => {
      let searchIcon;
      beforeEach(() => {
        searchIcon = fixture.debugElement.query(By.css('.search-field__perform-search'));
        fixture.detectChanges();
      });

      it('should be displayed', () => {
        expect(searchIcon).toBeTruthy();
      });
    });


    describe('on search', () => {
      let fieldValue = '12345678';
      let form;

      beforeEach(() => {
        form = fixture.debugElement.query(By.css('.search-field__form'));
      });

      describe('with search term', () => {
        let searchCriteria: any;

        beforeEach(() => {
          inputsearchField(fieldValue);
          fixture.detectChanges();

          searchCriteria = {};
          searchCriteria[SEARCH_PARAM_FIELD] = fieldValue;
          searchCriteria.pageNumber = undefined;
          searchCriteria.pageSize = undefined;
        });

        it('should call update on service', () => {
          fixture.debugElement.query(By.css('.search-field__perform-search')).nativeElement.click();
          expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteria);
        });

        it('should update on submit event', () => {
          form.nativeElement.dispatchEvent(new Event("submit"));
          expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteria);
        });

        describe('with null search term', () => {
          beforeEach(() => {
            inputsearchField(null);
            form.nativeElement.dispatchEvent(new Event("submit"));
            searchCriteria[SEARCH_PARAM_FIELD] = null;
          });

          it('should submit empty string for null search term', () => {
            form.nativeElement.dispatchEvent(new Event("submit"));
            expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteria);
          });

          it('should close the panel', () => {
            expect(component.panel.close).toHaveBeenCalled();
          });
        });
      });
    });
  });

  function inputsearchField(searchField) {
    const searchFieldInput = fixture.debugElement.query(By.css('.search-field__searchfield-input')).nativeElement;
    searchFieldInput.value = searchField;
    searchFieldInput.dispatchEvent(new Event('input'));
  }
});
