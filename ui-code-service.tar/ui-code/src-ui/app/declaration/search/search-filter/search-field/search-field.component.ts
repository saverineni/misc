import {Component, Input, OnInit, ViewChild} from '@angular/core';
import {SearchCriteriaService} from "../../search-criteria.service";
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {ClearAndClosable} from '../clear-and-closable';
import {SearchCriteria} from '../../search-criteria';

@Component({
  selector: 'cds-search-field-filter',
  templateUrl: './search-field.component.html',
  styleUrls: ['./search-field.component.scss']
})
export class SearchFieldComponent implements OnInit, ClearAndClosable {
  private static EMPTY_VALUE = '';

  private searchParam;
  private closePanel: boolean;
  searchParam$: Observable<string>;

  @Input() label: string;
  @Input() placeholder: string;
  @Input() searchParamField: string;
  @Input() toolTipTextValue: string;

  @ViewChild('panel') panel;
  @ViewChild('searchFieldInput') searchFieldInput;

  constructor(private searchCriteriaService: SearchCriteriaService) { }

  ngOnInit() {
    this.searchParam$ = this.searchCriteriaService.searchCriteria.pipe(
      map((data: SearchCriteria) => {
        this.searchParam = data[this.searchParamField] || SearchFieldComponent.EMPTY_VALUE;
        this.closePanel = data.isEmpty();
        this.togglePanel();

        return this.searchParam;
      })
    );
  }

  private togglePanel() {
    if(this.closePanel) {
      this.panel.close();
    }else if (this.searchParam != SearchFieldComponent.EMPTY_VALUE) {
      this.panel.open();
    }
  }

  clearAndClose() {
    this.clearValue();
    this.panel.close();
  }

  private clearValue() {
    this.searchFieldInput.nativeElement.value = SearchFieldComponent.EMPTY_VALUE;
  }

  onClear() {
    this.clearValue();
    if (this.searchParam != this.searchFieldInput.nativeElement.value) {
      this.onSearch(null);
      this.searchFieldInput.nativeElement.focus();
    }
  }

  onSearch(value) {
    let updates: any = {
      pageNumber: undefined,
      pageSize: undefined
    };

    if (value != null && value.trim() == SearchFieldComponent.EMPTY_VALUE) {
      updates[this.searchParamField] = null;
    } else {
      updates[this.searchParamField] = value;
    }

    this.searchCriteriaService.updatePartial(updates);
  }
}
