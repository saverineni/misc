import {ChangeDetectionStrategy, Component, Input, OnDestroy, OnInit} from '@angular/core';
import {MatDialog} from '@angular/material';
import {Facet} from '../../facets';
import {FacetedSearchComponent} from '../faceted-search/faceted-search.component';
import {FacetService} from "../../facet.service";
import {SearchCriteriaService} from "../../search-criteria.service";
import {SearchCriteria} from "../../search-criteria";
import {Subscription} from "rxjs/index";
import { Overlay } from '@angular/cdk/overlay';

@Component({
  selector: 'cds-links-facet',
  templateUrl: './links-facet.component.html',
  styleUrls: ['./links-facet.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LinksFacetComponent implements OnInit, OnDestroy {

  private criteriaUpdatesSubscription: Subscription;
  facets: Array<Facet>;
  private searchCriteria: SearchCriteria;

  @Input() label: string;
  @Input() searchParam: string;
  @Input() facetSearch: any;

  private WIDTH = "700px";
  private MAX_HEIGHT = "90vh";
  private MIN_HEIGHT = "50vh";

  constructor(public dialog: MatDialog,
              public overlay: Overlay,
              private searchCriteriaService: SearchCriteriaService,
              private facetService: FacetService) {
  }

  ngOnInit() {
    this.criteriaUpdatesSubscription = this.searchCriteriaService.searchCriteria.subscribe(
      newCriteria => {
        this.searchCriteria = newCriteria;
      }
    );
  }

  ngOnDestroy() {
    this.criteriaUpdatesSubscription.unsubscribe();
    this.dialog.closeAll();
  }

  openDialog() {
    if (this.facetSearch) {
      this.launchDialog(undefined);
    } else {
      this.facetService.getFacets(this.searchParam, undefined, this.searchCriteria)
        .subscribe(facets => {
          this.launchDialog(facets);
        });
    }
  }

  private launchDialog(facets: Array<Facet>) {
    this.dialog.open(
      FacetedSearchComponent,
      {
        width: this.WIDTH,
        maxHeight: this.MAX_HEIGHT,
        minHeight: this.MIN_HEIGHT,
        data: {
          facets: facets,
          searchParam: this.searchParam,
          facetType: this.label,
          facetSearch: this.facetSearch
        }
      }
    );
  }
}
