export interface ClearAndClosable {
  clearAndClose(): void;
}