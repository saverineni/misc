import {FacetNotMatchingPipe} from './facet-not-matching.pipe';

describe('FacetNotMatchingPipe', () => {
  let facet;
  let pipe;

  beforeEach(() => {
    pipe = new FacetNotMatchingPipe();
    facet = { label: 'cDsSearch' };
  });

  it('should return true if it does not start with the given filter term', () => {
    expect(pipe.transform(facet, 'A')).toBeTruthy();
  });

  it('should return false if given filter term is null', () => {
    expect(pipe.transform(facet, null)).toBeFalsy();
  });

  it('should return false if given filter term is empty', () => {
    expect(pipe.transform(facet, '')).toBeFalsy();
  });

  it('should return false if starts with the given filter term', () => {
    expect(pipe.transform(facet, 'cDs')).toBeFalsy();
  });

  it('should return false if starts with the given case insensitive filter term ', () => {
    expect(pipe.transform(facet, 'CdS')).toBeFalsy();
  });

  it('should return true for empty facet data ', () => {
    facet = {};
    expect(pipe.transform(facet, 'CdS')).toBeTruthy();
  });
});
