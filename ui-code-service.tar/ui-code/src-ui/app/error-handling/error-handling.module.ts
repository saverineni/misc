import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { MatSnackBarModule, MatButtonModule } from '@angular/material';
import { HttpErrorInterceptor } from './http-error-interceptor';
import { OperationErrorNotifier } from './operation-error-notifier';
import { NotFoundComponent } from './not-found/not-found.component';
import { ServerErrorComponent } from './server-error/server-error.component';

@NgModule({
  imports: [
    CommonModule,
    MatButtonModule,
    MatSnackBarModule
  ],
  providers: [],
  declarations: [NotFoundComponent, ServerErrorComponent]
})
export class ErrorHandlingModule {

  static forRoot(): ModuleWithProviders {
    return  {
      ngModule: ErrorHandlingModule,
      providers: [
        { provide: HTTP_INTERCEPTORS, useClass: HttpErrorInterceptor, multi: true },
        OperationErrorNotifier
      ]
    };
  }
}
