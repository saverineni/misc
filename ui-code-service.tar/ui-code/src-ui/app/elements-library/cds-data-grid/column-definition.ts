import * as moment from 'moment';

export class ColumnDefinition {
  private static TIMESTAMP_FORMAT: string = 'DD-MM-YYYY HH:mm';

  readonly id: string;
  readonly label: string;
  readonly type: string = 'string';
  readonly colspan: number = 1;
  readonly strong: boolean = false;
  getValue: (any) => (string) = (data) => this.format(data[this.id]);

  constructor(definition: {
    id: string,
    label: string,
    type?: string,
    colspan?: number,
    strong?: boolean,
    getValue?: (any) => string
  }) {
    this.id = definition.id;
    this.label = definition.label;
    this.type = definition.type || this.type;
    this.colspan = definition.colspan || this.colspan;
    this.strong = definition.strong || this.strong;
    this.getValue = definition.getValue || this.getValue;
  }

  toColumn(data) {
    return new Column(
      this.id,
      this.label,
      this.getValue(data),
      this.colspan,
      this.strong
    )
  }

  private format(data: string): string {
    if (this.type === 'timestamp') {
      const formatted = moment(data).format(ColumnDefinition.TIMESTAMP_FORMAT);
      return formatted !== 'Invalid date' ? formatted : data;
    } else {
      return data;
    }
  }
}

export class Column {
  constructor(
    readonly id: string,
    readonly label: string,
    readonly value: any,
    readonly colspan: number,
    readonly strong: boolean
  ) {}
}