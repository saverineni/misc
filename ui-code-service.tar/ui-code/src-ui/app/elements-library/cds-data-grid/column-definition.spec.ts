import { ColumnDefinition } from './column-definition';

describe('ColumnDefinition', () => {

    it('should have default properties', () => {
        const definition = new ColumnDefinition({ id: 'idField',  label: 'ID' });

        expect(definition.type).toEqual('string');
        expect(definition.colspan).toBe(1);
        expect(definition.strong).toBe(false);
    });

    it('should override default properties', () => {
        const definition = new ColumnDefinition({ id: 'idField',  label: 'ID', type: 'timestamp', colspan: 3, strong: true });

        expect(definition.type).toEqual('timestamp');
        expect(definition.colspan).toBe(3);
        expect(definition.strong).toBe(true);
    });
   
    it('should be able to automatically find an object value based on an id', () => {
        const object = { idField: 'objectId' };
        const definition = new ColumnDefinition({ id: 'idField',  label: 'ID' });

        expect(definition.getValue(object)).toEqual('objectId');
    });

    it('should be able to find an object value by overriding the getValue function', () => {
        const object = { idField: 'objectId' };
        const definition = new ColumnDefinition({ id: 'notTheIdField',  label: 'ID', getValue: (object) => object.idField });

        expect(definition.getValue(object)).toEqual('objectId');
    });

    it('should be able to format an object value based on the type', () => {
        const object = { timestampField: '2018-01-30 23:20:34.222' };
        const definition = new ColumnDefinition({ id: 'timestampField',  label: 'Date', type: 'timestamp' });

        expect(definition.getValue(object)).toEqual('30-01-2018 23:20');
    });

    it('should return original value if format unsuccessful', () => {
        const object = { timestampField: 'test' };
        const definition = new ColumnDefinition({ id: 'timestampField',  label: 'Date', type: 'timestamp' });

        expect(definition.getValue(object)).toEqual('test');
    });

});