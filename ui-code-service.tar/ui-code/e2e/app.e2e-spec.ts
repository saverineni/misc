import { AppPage } from './app.po';
import { NavigationBar } from './navigation-bar.po';
import { Footer } from './footer.po';
import { SignInScenario } from './sign-in/sign-in-scenario';
import { DeclarationSearchPage } from './declaration/search/declarationsearch.po';

describe('cds-data-search-ui App', () => {
  let page: AppPage;
  let footer = new Footer();

  beforeEach(() => {
    page = new AppPage();
  });

  it('should have the correct heading', () => {
    page.navigateTo();
    expect(page.pageHeading()).toEqual('Customs Declaration Search');
  });

  it('should have nav bar with no home label', () => {
    page.navigateTo();
    expect(new NavigationBar().isNavBarLabelsExists()).toBeFalsy();
  });

  it('should not have print-only element displayed', () => {
    page.navigateTo();
    expect(page.printOnlyDisplayed()).toBe(false);
  });

  describe('footer',() => {

    it('displays the version',() => {
      expect(footer.getVerison()).toContain('VERSION ');
    });

    it('displays the feedback link',() => {
      expect(footer.isFeedbackLinkPresent()).toBeTruthy();
      expect(footer.feedbackUrl()).toBe('mailto:martin.noble@hmrc.gsi.gov.uk');
    });

    it('displays the contact link',() => {
      expect(footer.isContactLinkPresent()).toBeTruthy();
      expect(footer.contactUrl()).toBe('mailto:martin.noble@hmrc.gsi.gov.uk');
    });

    it('displays the environment',() => {
      expect(footer.getEnvironment()).toBe('YOU ARE USING THE LOCAL VERSION');
    });

    it('environment label info is present',() => {
      expect(footer.isEnvironmentLabelPresent()).toBeTruthy();
    });

  });

  describe('once signed in',() => {
    let searchPage = new DeclarationSearchPage();

    it('should have nav bar with a home label displayed', (done) => {
      new SignInScenario().givenUserIsSignedIn()
        .then(() => searchPage.navigateTo())
        .then(() => expect(new NavigationBar().navbarLabels()).toEqual(['Customs Declaration Search']))
        .then(() => expect(footer.getVerison()).toContain('VERSION '))
        .then(done, done.fail);
    });
  });

});
