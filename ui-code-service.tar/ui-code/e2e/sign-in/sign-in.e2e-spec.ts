import { SignInPage } from './sign-in.po';
import { DeclarationSearchPage } from "../declaration/search/declarationsearch.po";
import { Wiremock } from "../wiremock";
import { AppPage } from '../app.po';
import { UserDetails } from '../user-details.po';
import { NavigationBar } from '../navigation-bar.po';
import { browser } from 'protractor';

describe('Sign In', () => {
  let signInPage: SignInPage;

  beforeEach((done) => {
    const userDetails = new UserDetails();
    const navigationBar = new NavigationBar();
    signInPage = new SignInPage();
    userDetails.isDisplayed()
      .then(isDisplayed => {
        if (isDisplayed) {
          // should route to sign in
          return navigationBar.signOut();
        } else {
          return signInPage.navigateTo();
        }
      })
      .then(Wiremock.reset)
      .then(done, done.fail);
  });

  it('should be the current page', () => {
    expect(signInPage.isCurrentPage()).toBeTruthy();
  });

  it('displays the sign in card title', () => {
    expect(signInPage.getTitle()).toEqual(`Customs Declaration Search`);
  });

  it('displays the sign in card subtitle', () => {
    expect(signInPage.getSubTitle()).toEqual(`UNAUTHORISED ACCESS TO THIS COMPUTER MAY CONSTITUTE A CRIMINAL OFFENCE`);
  });

  it('displays the help message', () => {
    expect(signInPage.getHelpMessage()).toEqual(`Having trouble logging in? Please contact the Helpdesk.`);
  });

  it('helpdesk link present', () => {
    expect(signInPage.isHelpdeskLinkPresent()).toBeTruthy();
  });

  it('helpdesk link should link to hmrc IT helpdesk', ()=> {
    expect(signInPage.helpdeskLinkUrl()).toBe('http://internal.active.hmrci/section/how-do-i/get-help-it-phones-and-data/it-help/it-helpdesk');
  });

  it('customs declaration label in nav bar is hidden' ,() => {
    expect(new NavigationBar().isNavBarEmpty()).toBeTruthy();
  });

  it('updates the title in the browser', () => {
    expect(new AppPage().getCurrentTitle()).toEqual(`CDS - Sign In`);
  });

  describe('entering incorrect details', () => {
    beforeEach(() => {
      signInPage.enterPid('123456');
      signInPage.enterPassword('invalid')
    });

    it('on click sign in should display an error message', (done) => {
      signInPage.unsuccessfulSignIn()
      .then(()=> browser.driver.sleep(500))
      .then(() => expect(signInPage.errorMessage()).toContain('Invalid credentials supplied, please try again.'))
      .then(done, done.fail);
    });
  });

  describe('signing in with correct details', () => {
    let searchPage: DeclarationSearchPage;

    beforeEach((done) => {
      Wiremock.stubRequest({
          "priority": 1,
          "request": {
            "method": "POST",
            "url": "/authentication/token",
            "bodyPatterns": [{
              "equalToJson": {
                "pid": "7654321",
                "password": "Pa55word"
              }
            }]
          },
          "response": {
            "status": 200,
            "bodyFileName": "authentication/authentication-successful.json"
          }
        })
        .then(done, done.fail);
    });

    beforeEach((done) => {
      searchPage = new DeclarationSearchPage();
      signInPage.enterPid('7654321')
        .then(() => signInPage.enterPassword('Pa55word'))
        .then(signInPage.successfulSignIn)
        .then(done, done.fail);
    });

    it('should display the search page', () => {
      expect(searchPage.isCurrentPage()).toBe(true);
    });

    it('and then navigating to the sign in page should route back to the search page', (done) => {
      signInPage.navigateTo()
        .then(() => expect(searchPage.isCurrentPage()).toBe(true))
        .then(done, done.fail);
    });
  });

  describe('server error', () => {
    beforeEach((done) => {
      Wiremock.givenSearchServiceIsOffline()
        .then(done, done.fail);
    });

    beforeEach((done) => {
      signInPage.enterPid('123456')
        .then(() => signInPage.enterPassword('invalid'))
        .then(() => signInPage.unsuccessfulSignIn())
        .then(done, done.fail);
    });

    it('should display an operation error message', () => {
      expect(new AppPage().getOperationError()).toEqual('Server error. Please contact support if this problem persists.\nOK');
    });

    it('should not display a sign in error message', () => {
      expect(signInPage.errorMessagePresent()).toEqual(false);
    });
  });
});
