import { by, element } from 'protractor';

export class Footer {

  getVerison() {
    return element(by.css('.inner__copyright__version')).getText();
  }

  getEnvironment() {
    return element(by.css('.inner__copyright__environment')).getText();
  }

  isEnvironmentLabelPresent() {
    return element(by.css('.inner__copyright__environment__link')).isPresent();
  }

  isFeedbackLinkPresent() {
    return this.getFeedbackLink().isPresent();
  }

  feedbackUrl() {
    return this.getFeedbackLink().getAttribute('href').then(value => value);
  }

  isContactLinkPresent() {
    return this.getContactLink().isPresent();
  }

  contactUrl() {
    return this.getContactLink().getAttribute('href').then(value => value);
  }

  private getFeedbackLink() {
    return element(by.css('.inner__feedback'));
  }

  private getContactLink() {
    return element(by.css('.inner__contact'));
  }

}
