import {browser, by, element, ExpectedConditions} from "protractor";

export class DateRangeFilter {

  dateFilterId: string;

  constructor(dateFilterClass: string) {
    this.dateFilterId = dateFilterClass;
  }

  private getDateFromInput() {
    return element(by.css(`.${this.dateFilterId}-date .date-range__from-input`));
  }

  private getDateToInput() {
    return element(by.css(`.${this.dateFilterId}-date .date-range__to-input`));
  }

  populateDateFrom(date) {
    return browser.wait(ExpectedConditions.visibilityOf(this.getDateFromInput())).then(() => this.getDateFromInput().sendKeys(date));
  }

  getDateFrom() {
    return this.getDateFromInput().getText();
  }

  populateDateTo(date) {
    return browser.wait(ExpectedConditions.visibilityOf(this.getDateToInput())).then(() => this.getDateToInput().sendKeys(date));
  }

  getDateTo() {
    return this.getDateToInput().getText();
  }

  clickClear() {
    return element(by.css(`.${this.dateFilterId}-date .date-range__clear-button`)).click();
  }

  clickApplyFilters() {
    return element(by.css(`.${this.dateFilterId}-date .date-range__apply-filters-button`)).click();
  }

  clickExpandingHeader() {
    let header = element(by.css(`.${this.dateFilterId}-date .date-range__header`))
    return browser.wait(ExpectedConditions.elementToBeClickable(header)).then(() => header.click());
  }

  isDatePanelCollapsed() {
    return element(by.css(`.${this.dateFilterId}-date .date-range__header`)).getAttribute('aria-expanded')
          .then(value => value == "false");
  }
}
