import {browser, by, element, ExpectedConditions} from "protractor";

export class EORIFilter {

  searchFieldId: string = 'search-field';

  clickExpandingHeader() {
    let header = element(by.css(`.${this.searchFieldId}__header`))
    return browser.wait(ExpectedConditions.elementToBeClickable(header)).then(() => header.click());
  }

  isPanelCollapsed() {
    return element(by.css(`.${this.searchFieldId}__header`)).getAttribute('aria-expanded')
      .then(value => value == "false");
  }

  private getInputField() {
    return element(by.css(`.${this.searchFieldId}__searchfield-input`));
  }

  populateEori(eori) {
    return browser.wait(ExpectedConditions.visibilityOf(this.getInputField())).then(() => this.getInputField().sendKeys(eori));
  }

  clickClear() {
    return element(by.css(`.${this.searchFieldId}__clear-search`)).click();
  }

  getInputFieldText() {
    return this.getInputField().getText();
  }

  clickSearch() {
    return element(by.css(`.${this.searchFieldId}__perform-search`)).click();
  }
}
