import { SignInPage } from '../../sign-in/sign-in.po';
import { Wiremock } from '../../wiremock';
import { HttpParams } from '@angular/common/http';
const fs = require('fs');

export class DeclarationSearchScenario {
    private static DECLARATION_FILE_NAME = 'default-declarations-response.json';

    static defaultSearchResponse() {
      return JSON.parse(fs.readFileSync(`e2e/wiremock/__files/${DeclarationSearchScenario.DECLARATION_FILE_NAME}`));
    }

    static stubPerformSearch() {
      return this.stubPerformSearchWithDelayMillis(0);
    }

    static stubPerformSearchWithDelayMillis(delay) {
        return Wiremock.stubRequest({
          "priority": 1,
          "request": {
            "method": "GET",
            "urlPattern": "/declarations\\?searchTerm=found.*"
          },
          "response": {
            "status": 200,
            "bodyFileName": "default-declarations-response.json",
            "fixedDelayMilliseconds": delay
          }
       });
    }

    static stubAuthenticatedSearchForTerm(searchTerm: string) {
      return this.stubAuthenticatedSearchForParams({ searchTerm: searchTerm });
    }

    static stubAuthenticatedSearchForParams(params: any) {
      const queryString = new HttpParams({fromObject: params}).toString();

      return Wiremock.stubRequest({
        "priority": 1,
        "request": {
          "method": "GET",
          "url": `/declarations?${queryString}`,
          "headers": {
            "Authorization": {
              "equalTo": "Bearer " + SignInPage.DEFAULT_AUTH_TOKEN
            }
          }
        },
        "response": {
          "status": 200,
          "bodyFileName": DeclarationSearchScenario.DECLARATION_FILE_NAME
        }
      });
  }
}
