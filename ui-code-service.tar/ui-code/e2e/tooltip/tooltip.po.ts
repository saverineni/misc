import {browser, by, element} from "protractor";

export class ToolTip {

  toolTipCssEORI: string ='.search-filter__eori  app-tooltip .tooltip .tooltip__icon';

  getTooltipColour() {
    return element(by.css(this.toolTipCssEORI)).getCssValue('color').then(value => value)
  }

  hoverEORIToolTipIcon(){
    return browser.actions().mouseMove(element(by.css(this.toolTipCssEORI))).perform();
  }

}
