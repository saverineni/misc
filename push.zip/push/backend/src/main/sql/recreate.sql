DROP DATABASE IF EXISTS `esignature`;
CREATE DATABASE `esignature`;
USE `esignature`;
SOURCE esignature.sql;
SOURCE data.sql;
SOURCE test-data.sql;