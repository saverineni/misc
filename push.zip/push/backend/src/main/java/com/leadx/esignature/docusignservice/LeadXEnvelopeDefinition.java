package com.leadx.esignature.docusignservice;

import com.docusign.esign.model.EnvelopeDefinition;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class LeadXEnvelopeDefinition extends EnvelopeDefinition{
	@JsonProperty("disableResponsiveDocument")
	private String disableResponsiveDocument = null;

	@ApiModelProperty(example = "null", value = "Disable responsive document")
	public String getDisableResponsiveDocument() {
		return disableResponsiveDocument;
	}

	public void setDisableResponsiveDocument(String disableResponsiveDocument) {
		this.disableResponsiveDocument = disableResponsiveDocument;
	}

	public EnvelopeDefinition disableResponsiveDocument(String disableResponsiveDocument) {
		this.disableResponsiveDocument = disableResponsiveDocument;
		return this;
	}
}
