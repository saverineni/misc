package com.leadx.esignature.docusignservice.commands;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.collect.Lists.newArrayList;
import static com.leadx.esignature.AddressUtils.buildAddressMap;
import static com.leadx.esignature.AddressUtils.buildPreviousAddressMap;
import static com.leadx.esignature.Utils.*;

import java.io.IOException;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.docusign.esign.client.ApiException;
import com.docusign.esign.model.*;
import com.google.common.collect.Maps;
import com.itextpdf.text.DocumentException;
import com.leadx.esignature.Address;
import com.leadx.esignature.ClaimRequest;
import com.leadx.esignature.Claimant;
import com.leadx.esignature.docusignservice.DocuSignRequest;
import com.leadx.esignature.docusignservice.LeadXEnvelopeDefinition;

@Component
public class OnlineAssessmentGenerateUrlCommand extends BaseGenerateUrlCommand implements GenerateUrlCommand {

	@Value("${esignature.server.docusign.loaFileName}")
	private String loaFileName;

	@Value("${esignature.server.docusign.toeFileName}")
	private String toeFileName;

	public String execute(final ClaimRequest claimRequest) throws IOException, DocumentException, ApiException {
		validate(claimRequest);
		final String clientUserId = String.valueOf(claimRequest.getLeadId());
		final Claimant claimant = claimRequest.getClaimant();
		final String clientUserName = getClaimantName(claimant.getTitle(), claimant.getForename(), claimant.getSurname());
		final String clientUserEmail = claimant.getEmail();
		final int numberOfAgreements = claimRequest.getAgreements().size();

		final DocuSignRequest docuSignRequest = new DocuSignRequest.Builder()
				.setLeadId(claimRequest.getLeadId())
				.setNumberOfAgreements(numberOfAgreements)
				.createDocuSignRequest();
		docuSignRepository.saveRequest(docuSignRequest);

		LeadXEnvelopeDefinition envDef = new LeadXEnvelopeDefinition();

		final List<Document> documents = buildDocuments(buildFormData(claimRequest));
		envDef.setDocuments(documents);
		envDef.setRecipients(new Recipients());
		envDef.getRecipients().setSigners(buildSigners(clientUserId, clientUserName, clientUserEmail, numberOfAgreements, "1"));

		envDef.setEmailSubject("The Claims Guys E-Signature Pack");
		envDef.setEmailBlurb("Don’t forget to sign your Letter(s) of Authority.");

		return getUrl(clientUserId, clientUserName, clientUserEmail, docuSignRequest, envDef);
	}

	private List<Document> buildDocuments(final Map<String, Object> formData) throws IOException, DocumentException {
		final List<Document> documents = newArrayList();
		documents.add(getLoa(formData));

		return documents;
	}

	private List<Signer> buildSigners(final String clientUserId, final String clientUserName, final String clientUserEmail, final int numberOfPages, final String documentId){
		final Signer signer = generateDefaultSigner(clientUserId, clientUserName, clientUserEmail);
		signer.setRecipientId("1");
		signer.setTabs(buildTabs(numberOfPages, documentId));
		signer.setSigningGroupId("true");

		return newArrayList(signer);
	}

	private Tabs buildTabs(final int numberOfPages, final String documentId){
		final Tabs tabs = new Tabs();

		for(int pageNumber = 1; pageNumber <= numberOfPages;  pageNumber++){
			tabs.getSignHereTabs().add(addSignature(pageNumber, documentId));
		}

		return tabs;
	}

	private static SignHere addSignature(final int pageNumber, final String documentId){
		// Create a SignHere tab somewhere on the document for the signer to sign
		SignHere signHere = generateDefaultSignHere(pageNumber, documentId);
		signHere.setYPosition("593");
		signHere.setScaleValue("1.0");

		return signHere;
	}

	private Document getLoa(final Map<String, Object> formData) throws IOException, DocumentException {
		final List<Map<String, Object>> agreements = (List) formData.get("agreements");
		final ListIterator<Map<String, Object>> agreementsIterator = agreements.listIterator();
		final List<byte[]> loaDocuments = newArrayList();
		while(agreementsIterator.hasNext()){
			final Map<String, Object> agreement = agreementsIterator.next();
			final Map<String, Object> documentData = Maps.newHashMap(formData);
			documentData.remove("agreements");
			documentData.putAll(agreement);
			documentData.put("currentDate", new LocalDate().toString("dd/MMM/yyyy"));

			byte[] loaBytes = populateAcroformFields(utils.readClasspathFile(loaFileName), documentData, String.valueOf(agreementsIterator.nextIndex()));
			loaDocuments.add(loaBytes);
		}

		return generateDocument(loaDocuments, "LOA.pdf", "1");
	}

	private Map<String, Object> buildFormData(final ClaimRequest claimRequest){
		final Map<String, Object> formData = Maps.newHashMap();
		formData.putAll(buildClaimantMap(claimRequest.getClaimant()));
		formData.putAll(buildAddressMap(claimRequest.getAddress()));

		final ListIterator<Address> previousAddressIterator = claimRequest.getPreviousAddresses().listIterator();
		while(previousAddressIterator.hasNext()){
			formData.putAll(buildPreviousAddressMap(previousAddressIterator.next(), previousAddressIterator.nextIndex()));
		}

		formData.put("agreements", buildAgreements(claimRequest.getAgreements()));

		return formData;
	}

	private static void validate(final ClaimRequest claimRequest){
		checkArgument(claimRequest.getLeadId() != 0, "Lead ID should have a valid value");
		checkArgument(claimRequest.getClaimant() != null, "Claimant cannot be null");
		checkArgument(claimRequest.getAgreements().size() > 0, "At least one agreement should exist");
	}

}
