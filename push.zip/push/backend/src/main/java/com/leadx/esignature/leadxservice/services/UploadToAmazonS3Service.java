package com.leadx.esignature.leadxservice.services;

import com.amazonaws.services.s3.model.PutObjectResult;
import com.leadx.lib.s3.S3ContentType;
import com.leadx.lib.s3.S3StorageService;
import com.leadx.lib.utl.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;

@Service
public class UploadToAmazonS3Service {

    @Autowired
    private S3StorageService s3StorageService;

    @Value("${esignature.bucket}")
    private String bucket;

    public void upLoadFileS3(final File pdfFile) {

        final PutObjectResult putObjectResult = this.s3StorageService.uploadFile(pdfFile, this.bucket, pdfFile.getName(), S3ContentType.PDF);

        if (ObjectUtils.isNull(putObjectResult)) {
            throw new UploadToS3ProcessorException(String.format("Unable to upload document to amazon, File=[%s]", pdfFile.getName()));
        }
    }

    public class UploadToS3ProcessorException extends RuntimeException {
        private UploadToS3ProcessorException(final String reason) {
            super(reason);
        }
    }
}