package com.leadx.esignature.docusignservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.leadx.hibernate.domain.BaseIntegerDomain;

@Entity
@Table(name = "docusign_reminder")
public class DocuSignReminder extends BaseIntegerDomain {
	@Column(name = "FK_DocuSignRequestID")
	private int docuSignRequestId;

	private String status;

	public DocuSignReminder() {
	}

	private DocuSignReminder(int docuSignRequestId, String envelopeId) {
		this.docuSignRequestId = docuSignRequestId;
		this.status = envelopeId;
	}

	public static class Builder{
		private int docuSignRequestId;
		private String status;

		public Builder setDocuSignRequestId(int docuSignRequestId) {
			this.docuSignRequestId = docuSignRequestId;
			return this;
		}

		public Builder setStatus(String status) {
			this.status = status;
			return this;
		}

		public DocuSignReminder createDocuSignReminder() {
			return new DocuSignReminder(docuSignRequestId, status);
		}
	}

	@Override
	public boolean equals(final Object obj) {
		return deepEquals(obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

	public int getDocuSignRequestId() {
		return docuSignRequestId;
	}

	public void setDocuSignRequestId(int docuSignRequestId) {
		this.docuSignRequestId = docuSignRequestId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
