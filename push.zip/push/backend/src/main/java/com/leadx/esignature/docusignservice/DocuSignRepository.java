package com.leadx.esignature.docusignservice;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class DocuSignRepository {
	@Autowired
	private SessionFactory sessionFactory;

	@Transactional
	public void saveRequest(final DocuSignRequest docuSignRequest){
		sessionFactory.getCurrentSession().saveOrUpdate(docuSignRequest);
	}

	@Transactional
	public int saveRequestFailure(final DocuSignRequestFailure docuSignRequestFailure){
		return (int) sessionFactory.getCurrentSession().save(docuSignRequestFailure);
	}

	@Transactional
	public int saveResponse(final int documentRequestId, final String envelopeId, final String viewURL){
		final DocuSignResponse docuSignResponse = new DocuSignResponse.Builder()
				.setDocuSignRequestId(documentRequestId)
				.setEnvelopeId(envelopeId)
				.setViewURL(viewURL)
				.createDocuSignResponse();

		return (int) sessionFactory.getCurrentSession().save(docuSignResponse);
	}

	@Transactional
	public int saveReminder(final int documentRequestId, final String statusMessage){
		final DocuSignReminder docuSignReminder = new DocuSignReminder.Builder()
				.setDocuSignRequestId(documentRequestId)
				.setStatus(statusMessage)
				.createDocuSignReminder();

		return (int) sessionFactory.getCurrentSession().save(docuSignReminder);
	}

	@Transactional
	public List<DocuSignResponse> getDocuSignResponses(final int offsetDays){
		return sessionFactory.getCurrentSession().createSQLQuery(
				"SELECT d.* FROM esignature.`docusign_response` d " +
						"WHERE d.`Timestamp` BETWEEN CONCAT(DATE_SUB(CURRENT_DATE, INTERVAL :offsetDays DAY), ' ', '00:00:00') AND CONCAT(DATE_SUB(CURRENT_DATE, INTERVAL :offsetDays DAY), ' ', '23:59:59')")
				.addEntity(DocuSignResponse.class)
				.setParameter("offsetDays", offsetDays)
				.list();
	}

	public SessionFactory getSessionFactory() {
		return this.sessionFactory;
	}

	public Session getSession(){
		return getSessionFactory().getCurrentSession();
	}
}
