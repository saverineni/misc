package com.leadx.esignature.docusignservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.leadx.hibernate.domain.BaseIntegerDomain;

@Entity
@Table(name = "docusign_request_failure")
public class DocuSignRequestFailure extends BaseIntegerDomain {
	@Column(name = "FK_DocuSignRequestID")
	private int docuSignRequestId;
	private String error;

	public DocuSignRequestFailure() {
	}

	public DocuSignRequestFailure(int docuSignRequestId, String error) {
		this.docuSignRequestId = docuSignRequestId;
		this.error = error;
	}

	@Override
	public boolean equals(final Object obj) {
		return deepEquals(obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

	public int getDocuSignRequestId() {
		return docuSignRequestId;
	}

	public void setDocuSignRequestId(int docuSignRequestId) {
		this.docuSignRequestId = docuSignRequestId;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}
}
