package com.leadx.esignature;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Address {
	private String departmentName;
	private String organisationName;
	private String subBuildingName;
	private String buildingName;
	private String buildingNumber;
	private String thoroughfare;
	private String dependentLocality;
	private String town;
	private String county;
	private String postcode;

	public Address() {
	}

	private Address(String departmentName, String organisationName, String subBuildingName, String buildingName, String buildingNumber, String thoroughfare, String dependentLocality, String town, String county, String postcode) {
		this.departmentName = departmentName;
		this.organisationName = organisationName;
		this.subBuildingName = subBuildingName;
		this.buildingName = buildingName;
		this.buildingNumber = buildingNumber;
		this.thoroughfare = thoroughfare;
		this.dependentLocality = dependentLocality;
		this.town = town;
		this.county = county;
		this.postcode = postcode;
	}

	public static class Builder{
		private String departmentName;
		private String organisationName;
		private String subBuildingName;
		private String buildingName;
		private String buildingNumber;
		private String thoroughfare;
		private String dependentLocality;
		private String town;
		private String county;
		private String postcode;

		public Builder setDepartmentName(String departmentName) {
			this.departmentName = departmentName;
			return this;
		}

		public Builder setOrganisationName(String organisationName) {
			this.organisationName = organisationName;
			return this;
		}

		public Builder setSubBuildingName(String subBuildingName) {
			this.subBuildingName = subBuildingName;
			return this;
		}

		public Builder setBuildingName(String buildingName) {
			this.buildingName = buildingName;
			return this;
		}

		public Builder setBuildingNumber(String buildingNumber) {
			this.buildingNumber = buildingNumber;
			return this;
		}

		public Builder setThoroughfare(String thoroughfare) {
			this.thoroughfare = thoroughfare;
			return this;
		}

		public Builder setDependentLocality(String dependentLocality) {
			this.dependentLocality = dependentLocality;
			return this;
		}

		public Builder setTown(String town) {
			this.town = town;
			return this;
		}

		public Builder setCounty(String county) {
			this.county = county;
			return this;
		}

		public Builder setPostcode(String postcode) {
			this.postcode = postcode;
			return this;
		}

		public Address createAddress() {
			return new Address(departmentName, organisationName, subBuildingName, buildingName, buildingNumber, thoroughfare, dependentLocality, town, county, postcode);
		}
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getOrganisationName() {
		return organisationName;
	}

	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}

	public String getSubBuildingName() {
		return subBuildingName;
	}

	public void setSubBuildingName(String subBuildingName) {
		this.subBuildingName = subBuildingName;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getBuildingNumber() {
		return buildingNumber;
	}

	public void setBuildingNumber(String buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	public String getThoroughfare() {
		return thoroughfare;
	}

	public void setThoroughfare(String thoroughfare) {
		this.thoroughfare = thoroughfare;
	}

	public String getDependentLocality() {
		return dependentLocality;
	}

	public void setDependentLocality(String dependentLocality) {
		this.dependentLocality = dependentLocality;
	}

	public String getTown() {
		return town;
	}

	public void setTown(String town) {
		this.town = town;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
}
