package com.leadx.esignature.docusignservice.commands;

import java.io.IOException;

import com.docusign.esign.client.ApiException;
import com.itextpdf.text.DocumentException;
import com.leadx.esignature.ClaimRequest;

public interface GenerateUrlCommand {

	String execute(final ClaimRequest claimRequest) throws IOException, DocumentException, ApiException;
}
