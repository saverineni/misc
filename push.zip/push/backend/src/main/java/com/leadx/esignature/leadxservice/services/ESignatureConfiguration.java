package com.leadx.esignature.leadxservice.services;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.leadx.lib.s3.S3StorageService;
import com.leadx.lib.s3.S3StorageServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.File;

@Configuration
public class ESignatureConfiguration {

    @Value("${esignature.server.s3.timeout}")
    private int timeout;

    @Value("${aws.accessKey}")
    private String accessKey;
    @Value("${aws.secretKey}")
    private String secretKey;
    @Value("${esignature.pdfs.outputDirectory}")
    private String outputDirectory;

    @Autowired
    private BasicAWSCredentials awsCredentials;

    @Autowired
    private ClientConfiguration clientConfiguration;

    @Bean
    public S3StorageService s3Service() {
        return new S3StorageServiceImpl();
    }

    @Bean
    public AmazonS3 amazonS3() {
        return new AmazonS3Client(awsCredentials, clientConfiguration);
    }

    @Bean
    public BasicAWSCredentials basicAwsCredentials() {
        return new BasicAWSCredentials(this.accessKey, this.secretKey);
    }

    @Bean
    public ClientConfiguration clientConfiguration() {
        ClientConfiguration clientConfiguration = new ClientConfiguration();
        clientConfiguration.setConnectionTimeout(timeout);
        clientConfiguration.setSocketTimeout(timeout);
        return clientConfiguration;
    }

    @Bean
    public File newFile() {
        return new File(this.outputDirectory);
    }
}
