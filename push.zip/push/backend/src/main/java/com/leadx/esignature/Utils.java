package com.leadx.esignature;

import static com.google.common.collect.Lists.newArrayList;
import static com.leadx.lib.utl.ObjectUtils.isNull;
import static java.util.Arrays.asList;
import static java.util.Objects.nonNull;
import static java.util.stream.Collectors.joining;
import static org.apache.commons.lang3.StringUtils.SPACE;
import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.apache.commons.lang3.text.WordUtils.capitalizeFully;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.google.common.collect.Maps;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.AcroFields;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfSmartCopy;
import com.itextpdf.text.pdf.PdfStamper;

@Component
public class Utils {

	private static List<Integer> rbsLenderIds = newArrayList(578, 697);

	public static List<Map<String, Object>> buildAgreements(final List<Agreement> agreementList){
		final List<Map<String, Object>> agreements = newArrayList();

		agreementList.forEach(agreement -> {
			final Map<String, Object> agreementMap = Maps.newHashMap();
			agreementMap.put("agreementLender", agreement.getLenderName());

			if (rbsLenderIds.contains(agreement.getLenderId())) {
				agreementMap.put("agreementLoaTypeOfCredit", agreement.getTypeOfCredit());
			} else {
				agreementMap.put("agreementLoaTypeOfCredit", "all");
			}

			agreementMap.put("didYouTakeOutPpi", agreement.getDidYouTakeOutPpi());
			agreementMap.put("toldPpiAffectsEligibility", agreement.getToldPpiAffectsEligibility());
			agreementMap.put("costsOfPpiExplained", agreement.getCostsOfPpiExplained());

			agreements.add(agreementMap);
		});

		return agreements;
	}

	public static String getClaimantName(String... fields){
		return asList(fields).stream()
				.filter(StringUtils::isNotBlank)
				.collect(joining(SPACE));
	}

	public static Map<String, Object> buildClaimantMap(final Claimant claimant){
		final Map<String, Object> claimantData = Maps.newHashMap();
		claimantData.put("claimantForename", claimant.getForename());
		claimantData.put("claimantMiddleName", claimant.getMiddlename());
		claimantData.put("claimantSurname", claimant.getSurname());
		claimantData.put("claimantPreviousName", claimant.getPreviousSurname());
		claimantData.put("claimantEmail", claimant.getEmail());
		claimantData.put("claimantDob", claimant.getDob());
		claimantData.put("claimantTelephone", isNotBlank(claimant.getMobileTelephone()) ? claimant.getMobileTelephone() : claimant.getHomeTelephone());

		return claimantData;
	}

	public static byte[] populateAcroformFields(final byte[] pdf, final Map<String, Object> data, final String pageNumber) throws IOException, DocumentException {
		final PdfReader reader = new PdfReader(pdf);
		final ByteArrayOutputStream output = new ByteArrayOutputStream();
		final PdfStamper stamper = new PdfStamper(reader, output);

		try{
			final AcroFields form = stamper.getAcroFields();
			for (final String key : data.keySet()) {
				form.setFieldProperty(key, "textfont", getDefaultFont(), null);
				form.setField(key, nullSafeToString(data.get(key)));
				form.renameField(key, key + "-" + pageNumber); //rename the fields so that the field names are unique across the whole document. Without this, docusign does not populate the form data correctly
			}
		} finally {
			stamper.close();
		}

		return output.toByteArray();
	}

	public byte[] readClasspathFile(final String fileName){
		byte[] fileBytes = null;
		try {
			Path path = Paths.get(getClass().getClassLoader().getResource(fileName).toURI());
			fileBytes = Files.readAllBytes(path);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}

		return fileBytes;
	}

	public byte[] readFile(final String fileName){
		byte[] fileBytes = null;
		try {
			Path path = Paths.get(fileName);
			fileBytes = Files.readAllBytes(path);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return fileBytes;
	}

	public static String mergeFiles(final List<byte[]> files) throws DocumentException, IOException {
		final String tempDir = com.google.common.io.Files.createTempDir().getCanonicalPath();
		final String mergedFile = tempDir + File.separator + "LOA.pdf";
		final com.itextpdf.text.Document document = new com.itextpdf.text.Document();
		final FileOutputStream outputStream = new FileOutputStream(mergedFile);

		PdfSmartCopy writer = null;

		try {
			writer = new PdfSmartCopy(document, outputStream);
			document.open();

			for (byte[] file: files) {
				PdfReader reader = null;
				try {
					reader = new PdfReader(file);
					final int numberOfPages = reader.getNumberOfPages();
					int pageCount = 0;

					while (pageCount < numberOfPages) {
						document.newPage();
						pageCount++;

						final PdfImportedPage importedPage = writer.getImportedPage(reader, pageCount);
						writer.addPage(importedPage);
					}
				} finally {
					if(nonNull(reader)){
						reader.close();
					}
				}
			}
		} finally {
			document.close();
			if(nonNull(writer)){
				writer.close();
			}
		}

		return mergedFile;
	}

	public static String nullSafeToString(final Object object) {
		if (isNull(object)) {
			return "";
		}
		return object.toString();
	}

	public static BaseFont getDefaultFont() {
		try {
			return BaseFont.createFont("fonts/calibri.ttf", "Cp1252", true);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static String joinAddressElements(final String... elements) {
		return asList(elements).stream()
				.filter(StringUtils::isNotBlank)
				.collect(joining(","));
	}

	public static void appendIfNotBlank(List<String> listToAppendTo, final String... valuesToAppend) {
		if (containsValues(valuesToAppend)) {
			String value = mergeFields(valuesToAppend);
			listToAppendTo.add(capitalizeFully(value));
		}
	}

	public static boolean containsValues(final String... args) {
		for (String arg : args) {
			if (isNotBlank(arg)) {
				return true;
			}
		}

		return false;
	}

	public static String mergeFields(final String... args) {
		StringBuilder builder = new StringBuilder();
		for (String arg : args) {
			if (isNotBlank(arg)) {
				builder.append(arg)
						.append(" ");
			}
		}

		return builder.toString().trim();
	}
}
