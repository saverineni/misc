package com.leadx.esignature;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MedicalCondition {
	private String medicalCondition;
	private String yearOfDiagnosis;
	private String lengthOfTimeOff;

	public MedicalCondition() {
	}

	public MedicalCondition(String medicalCondition, String yearOfDiagnosis, String lengthOfTimeOff) {
		this.medicalCondition = medicalCondition;
		this.yearOfDiagnosis = yearOfDiagnosis;
		this.lengthOfTimeOff = lengthOfTimeOff;
	}

	public static class Builder{

		private String medicalCondition;
		private String yearOfDiagnosis;
		private String lengthOfTimeOff;

		public Builder setMedicalCondition(String medicalCondition) {
			this.medicalCondition = medicalCondition;
			return this;
		}

		public Builder setYearOfDiagnosis(String yearOfDiagnosis) {
			this.yearOfDiagnosis = yearOfDiagnosis;
			return this;
		}

		public Builder setLengthOfTimeOff(String lengthOfTimeOff) {
			this.lengthOfTimeOff = lengthOfTimeOff;
			return this;
		}

		public MedicalCondition createMedicalCondition() {
			return new MedicalCondition(medicalCondition, yearOfDiagnosis, lengthOfTimeOff);
		}
	}

	public String getMedicalCondition() {
		return medicalCondition;
	}

	public void setMedicalCondition(String medicalCondition) {
		this.medicalCondition = medicalCondition;
	}

	public String getYearOfDiagnosis() {
		return yearOfDiagnosis;
	}

	public void setYearOfDiagnosis(String yearOfDiagnosis) {
		this.yearOfDiagnosis = yearOfDiagnosis;
	}

	public String getLengthOfTimeOff() {
		return lengthOfTimeOff;
	}

	public void setLengthOfTimeOff(String lengthOfTimeOff) {
		this.lengthOfTimeOff = lengthOfTimeOff;
	}
}
