package com.leadx.esignature.docusignservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.leadx.esignature.ClaimRequest;

@RequestMapping(value = "/unsecure")
@Controller
public class DocuSignController {
	private static final Logger LOG = LoggerFactory.getLogger(DocuSignController.class);

	@Autowired
	private DocuSignService docuSignService;

	@ResponseBody
	@RequestMapping(value = "/createSigningURL", method = RequestMethod.POST)
	public String createSigningURL(@RequestBody final ClaimRequest claimRequest) {
		final long leadId = claimRequest.getLeadId();
		LOG.debug("Attempting to create signing URL for Lead ID: " + leadId);
		try {
			final String URL = docuSignService.createSigningURL(claimRequest);
			LOG.debug("URL successfully retrieved for Lead ID: " + leadId);
			return URL;
		} catch (final Exception e) {
			LOG.error("Unable to create signing URL for Lead ID: " + leadId, e);
			throw new RuntimeException(e.getCause());
		}
	}

	@ResponseBody
	@RequestMapping(value = "/sendReminderEmails", method = RequestMethod.POST)
	public void sendReminderEmails() throws Exception {
		LOG.info("BEGIN: Reminder emails for incomplete documents");
		docuSignService.sendReminderEmails();
		LOG.info("END: Reminder emails for incomplete documents");
	}
}
