package com.leadx.esignature.docusignservice;

import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Maps.newHashMap;
import static com.leadx.esignature.DocumentDefinition.*;
import static com.leadx.lib.utl.ObjectUtils.isNotNull;
import static java.util.Objects.isNull;
import static org.apache.commons.lang3.StringUtils.EMPTY;

import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.docusign.esign.api.EnvelopesApi;
import com.docusign.esign.client.ApiClient;
import com.docusign.esign.client.ApiException;
import com.docusign.esign.client.Configuration;
import com.docusign.esign.client.auth.OAuth;
import com.docusign.esign.model.Envelope;
import com.docusign.esign.model.Recipients;
import com.docusign.esign.model.RecipientsUpdateSummary;
import com.leadx.esignature.ClaimRequest;
import com.leadx.esignature.Utils;
import com.leadx.esignature.docusignservice.commands.GenerateUrlCommand;
import com.leadx.esignature.docusignservice.commands.LqSopPackGenerateUrlCommand;
import com.leadx.esignature.docusignservice.commands.OnlineAssessmentGenerateUrlCommand;
import com.leadx.esignature.docusignservice.commands.TcgLPackGenerateUrlCommand;

@Service
public class DocuSignService {
	private static final Logger LOG = LoggerFactory.getLogger(DocuSignService.class);

	@Value("${esignature.server.docusign.userId}")
	private String userId;

	@Value("${esignature.server.docusign.clientId}")
	private String clientId;

	@Value("${esignature.server.docusign.basePath}")
	private String basePath;

	@Value("${esignature.server.docusign.privateKey}")
	private String privateKey;

	@Value("#{'${esignature.server.docusign.reminder.daysSinceCreation}'.split(',')}")
	private List<Integer> daysSinceCreation;

	@Autowired
	private Utils utils;

	@Autowired
	private DocuSignRepository docuSignRepository;

	@Autowired
	private BeanFactory beanFactory;

	private Map<String, GenerateUrlCommand> documentDefinitionCommands = newHashMap();

	@PostConstruct
	public void init() {
		this.documentDefinitionCommands.put(ONLINE_ASSESSMENT_PACK.name(), this.beanFactory.getBean(OnlineAssessmentGenerateUrlCommand.class));
		this.documentDefinitionCommands.put(TCGL_PACK.name(), this.beanFactory.getBean(TcgLPackGenerateUrlCommand.class));
		this.documentDefinitionCommands.put(LQ_SOP_PACK.name(), this.beanFactory.getBean(LqSopPackGenerateUrlCommand.class));
	}

	public String createSigningURL(final ClaimRequest claimRequest) {

		final GenerateUrlCommand command = this.documentDefinitionCommands.get(claimRequest.getDocumentDefinition());

		if (isNotNull(command)) {
			try {
				return command.execute(claimRequest);
			} catch (final Exception e) {
				LOG.error("Failed to execute command for definition " + claimRequest.getDocumentDefinition() + ": ", e);
				return "";
			}
		} else {
			throw new IllegalArgumentException("Unable to find command for definition: " + claimRequest.getDocumentDefinition());
		}

	}

	public void sendReminderEmails() throws Exception {
		ApiClient apiClient = new ApiClient(basePath);
		final List<String> scopes = newArrayList(OAuth.Scope_SIGNATURE);

		OAuth.OAuthToken oAuthToken = apiClient.requestJWTUserToken(clientId, userId, scopes, utils.readFile(privateKey), 3600);

		// now that the API client has an OAuth token, let's use it in all DocuSign APIs
		apiClient.setAccessToken(oAuthToken.getAccessToken(), oAuthToken.getExpiresIn());
		OAuth.UserInfo userInfo = apiClient.getUserInfo(oAuthToken.getAccessToken());

		// parse first account's basePath. This step is important since the base URL may change occasionally
		final String baseURI = userInfo.getAccounts().get(0).getBaseUri();
		apiClient.setBasePath(baseURI + "/restapi");

		Configuration.setDefaultApiClient(apiClient);
		String accountId = userInfo.getAccounts().get(0).getAccountId();

		final EnvelopesApi envelopesApi = new EnvelopesApi();
		final EnvelopesApi.UpdateRecipientsOptions updateRecipientsOptions = envelopesApi.new UpdateRecipientsOptions();
		updateRecipientsOptions.setResendEnvelope("true");

		daysSinceCreation.stream()
				.flatMap(offsetDays -> docuSignRepository.getDocuSignResponses(offsetDays).stream())
				.forEach(docuSignResponse -> sendReminderEmail(accountId, docuSignResponse, envelopesApi, updateRecipientsOptions));
	}

	private void sendReminderEmail(final String accountId, final DocuSignResponse docuSignResponse, final EnvelopesApi envelopesApi,
								   final EnvelopesApi.UpdateRecipientsOptions updateRecipientsOptions) {
		final String envelopeId = docuSignResponse.getEnvelopeId();
		final int documentRequestId = docuSignResponse.getDocuSignRequestId();

		try{
			final Envelope envelope = envelopesApi.getEnvelope(accountId, envelopeId);

			if(isNull(envelope.getCompletedDateTime())){
				final Recipients recipients = getRecipients(accountId, envelopeId, envelopesApi);
				final RecipientsUpdateSummary summary = envelopesApi.updateRecipients(accountId, envelopeId, recipients, updateRecipientsOptions);
				final String status = summary.getRecipientUpdateResults().get(0).getErrorDetails().getErrorCode();
				docuSignRepository.saveReminder(documentRequestId, status);
			}
		}catch(Exception e){
			LOG.error("Following error occurred when sending reminder email for Document Request ID: " + documentRequestId, e);
			e.printStackTrace();
		}
	}

	private Recipients getRecipients(final String accountId, final String envelopeId, final EnvelopesApi envelopesApi) throws ApiException {
		final Recipients recipients = envelopesApi.listRecipients(accountId, envelopeId);
		recipients.getSigners().forEach(s -> s.setClientUserId(EMPTY)); //remove clientUserId to enable reminder emails to be sent

		return recipients;
	}
}
