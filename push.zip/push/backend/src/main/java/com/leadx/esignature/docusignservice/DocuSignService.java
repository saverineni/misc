package com.leadx.esignature.docusignservice;

import static com.google.common.collect.Lists.newArrayList;
import static com.leadx.esignature.AddressUtils.buildAddressMap;
import static com.leadx.esignature.AddressUtils.buildPreviousAddressMap;
import static com.leadx.esignature.Utils.*;
import static com.migcomponents.migbase64.Base64.encodeToString;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.StringUtils.EMPTY;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.docusign.esign.api.EnvelopesApi;
import com.docusign.esign.client.ApiClient;
import com.docusign.esign.client.ApiException;
import com.docusign.esign.client.Configuration;
import com.docusign.esign.client.auth.OAuth;
import com.docusign.esign.model.Document;
import com.docusign.esign.model.Envelope;
import com.docusign.esign.model.EnvelopeSummary;
import com.docusign.esign.model.RecipientViewRequest;
import com.docusign.esign.model.Recipients;
import com.docusign.esign.model.RecipientsUpdateSummary;
import com.docusign.esign.model.SignHere;
import com.docusign.esign.model.Signer;
import com.docusign.esign.model.Tabs;
import com.docusign.esign.model.ViewUrl;
import com.google.common.collect.Maps;
import com.itextpdf.text.DocumentException;
import com.leadx.esignature.Address;
import com.leadx.esignature.ClaimRequest;
import com.leadx.esignature.Claimant;
import com.leadx.esignature.Utils;

@Service
public class DocuSignService {
	private static final Logger LOG = LoggerFactory.getLogger(DocuSignService.class);

	@Value("${esignature.server.docusign.userId}")
	private String userId;

	@Value("${esignature.server.docusign.clientId}")
	private String clientId;

	@Value("${esignature.server.docusign.basePath}")
	private String basePath;

	@Value("${esignature.server.docusign.privateKey}")
	private String privateKey;

	@Value("${esignature.server.docusign.loaFileName}")
	private String loaFileName;

	@Value("${esignature.server.docusign.toeFileName}")
	private String toeFileName;

	@Value("${esignature.server.docusign.returnUrl}")
	private String returnUrl;

	@Value("#{'${esignature.server.docusign.reminder.daysSinceCreation}'.split(',')}")
	private List<Integer> daysSinceCreation;

	@Autowired
	private Utils utils;

	@Autowired
	private DocuSignRepository docuSignRepository;

	private static final String DOCUMENT_ID_LOA = "1";

	public String createSigningURL(final ClaimRequest claimRequest) throws IOException, DocumentException, ApiException {
		final String clientUserId = String.valueOf(claimRequest.getLeadId());
		final Claimant claimant = claimRequest.getClaimant();
		final String clientUserName = getClaimantName(claimant.getTitle(), claimant.getForename(), claimant.getSurname());
		final String clientUserEmail = claimant.getEmail();
		final int numberOfAgreements = claimRequest.getAgreements().size();

		final DocuSignRequest docuSignRequest = new DocuSignRequest.Builder()
				.setLeadId(claimRequest.getLeadId())
				.setNumberOfAgreements(numberOfAgreements)
				.createDocuSignRequest();
		docuSignRepository.saveRequest(docuSignRequest);

		LeadXEnvelopeDefinition envDef = new LeadXEnvelopeDefinition();
		envDef.setEmailSubject("The Claims Guys E-Signature Pack");
		envDef.setEmailBlurb("Don’t forget to sign your Letter(s) of Authority.");
		envDef.setRecipients(new Recipients());
		envDef.setDisableResponsiveDocument("false");

		// send the envelope (otherwise it will be "created" in the Draft folder)
		envDef.setStatus("sent");

		ApiClient apiClient = new ApiClient(basePath);
		final List<String> scopes = newArrayList(OAuth.Scope_SIGNATURE);
		String viewURL;
		try {
			// add header to track time
			apiClient.addDefaultHeader("X-DocuSign-TimeTrack", "ESignature");
			OAuth.OAuthToken oAuthToken = apiClient.requestJWTUserToken(clientId, userId, scopes, utils.readFile(privateKey), 3600);

			// now that the API client has an OAuth token, let's use it in all DocuSign APIs
			apiClient.setAccessToken(oAuthToken.getAccessToken(), oAuthToken.getExpiresIn());
			OAuth.UserInfo userInfo = apiClient.getUserInfo(oAuthToken.getAccessToken());

			// parse first account's basePath. This step is important since the base URL may change occasionally
			final String baseURI = userInfo.getAccounts().get(0).getBaseUri();
			apiClient.setBasePath(baseURI + "/restapi");

			docuSignRequest.setBaseURI(baseURI);
			docuSignRepository.saveRequest(docuSignRequest);

			Configuration.setDefaultApiClient(apiClient);
			String accountId = userInfo.getAccounts().get(0).getAccountId();

			final List<Document> documents = buildDocuments(buildFormData(claimRequest));
			envDef.setDocuments(documents);
			envDef.getRecipients().setSigners(buildSigners(clientUserId, clientUserName, clientUserEmail, numberOfAgreements));

			EnvelopesApi envelopesApi = new EnvelopesApi();
			EnvelopeSummary envelopeSummary = envelopesApi.createEnvelope(accountId, envDef);
			LOG.debug("Create Envelope - Time track logs: " + apiClient.getResponseHeaders().get("X-DocuSign-TimeTrack"));

			ViewUrl docuSignURL = envelopesApi.createRecipientView(accountId, envelopeSummary.getEnvelopeId(), buildRecipientView(returnUrl, clientUserId,
					clientUserName, clientUserEmail));
			LOG.debug("Create Recipient View - Time track logs: " + apiClient.getResponseHeaders().get("X-DocuSign-TimeTrack"));

			viewURL = docuSignURL.getUrl();
			docuSignRepository.saveResponse(docuSignRequest.getId(), envelopeSummary.getEnvelopeId(), viewURL);
		} catch (ApiException exception) {
			docuSignRepository.saveRequestFailure(new DocuSignRequestFailure(docuSignRequest.getId(), exception.getMessage()));
			throw exception;
		}

		return viewURL;
	}

	public void sendReminderEmails() throws Exception {
		ApiClient apiClient = new ApiClient(basePath);
		final List<String> scopes = newArrayList(OAuth.Scope_SIGNATURE);

		OAuth.OAuthToken oAuthToken = apiClient.requestJWTUserToken(clientId, userId, scopes, utils.readFile(privateKey), 3600);

		// now that the API client has an OAuth token, let's use it in all DocuSign APIs
		apiClient.setAccessToken(oAuthToken.getAccessToken(), oAuthToken.getExpiresIn());
		OAuth.UserInfo userInfo = apiClient.getUserInfo(oAuthToken.getAccessToken());

		// parse first account's basePath. This step is important since the base URL may change occasionally
		final String baseURI = userInfo.getAccounts().get(0).getBaseUri();
		apiClient.setBasePath(baseURI + "/restapi");

		Configuration.setDefaultApiClient(apiClient);
		String accountId = userInfo.getAccounts().get(0).getAccountId();

		final EnvelopesApi envelopesApi = new EnvelopesApi();
		final EnvelopesApi.UpdateRecipientsOptions updateRecipientsOptions = envelopesApi.new UpdateRecipientsOptions();
		updateRecipientsOptions.setResendEnvelope("true");

		daysSinceCreation.stream()
				.flatMap(offsetDays -> docuSignRepository.getDocuSignResponses(offsetDays).stream())
				.forEach(docuSignResponse -> sendReminderEmail(accountId, docuSignResponse, envelopesApi, updateRecipientsOptions));
	}

	private void sendReminderEmail(final String accountId, final DocuSignResponse docuSignResponse, final EnvelopesApi envelopesApi,
								   final EnvelopesApi.UpdateRecipientsOptions updateRecipientsOptions) {
		final String envelopeId = docuSignResponse.getEnvelopeId();
		final int documentRequestId = docuSignResponse.getDocuSignRequestId();

		try{
			final Envelope envelope = envelopesApi.getEnvelope(accountId, envelopeId);

			if(isNull(envelope.getCompletedDateTime())){
				final Recipients recipients = getRecipients(accountId, envelopeId, envelopesApi);
				final RecipientsUpdateSummary summary = envelopesApi.updateRecipients(accountId, envelopeId, recipients, updateRecipientsOptions);
				final String status = summary.getRecipientUpdateResults().get(0).getErrorDetails().getErrorCode();
				docuSignRepository.saveReminder(documentRequestId, status);
			}
		}catch(Exception e){
			LOG.error("Following error occurred when sending reminder email for Document Request ID: " + documentRequestId, e);
			e.printStackTrace();
		}
	}

	private Recipients getRecipients(final String accountId, final String envelopeId, final EnvelopesApi envelopesApi) throws ApiException {
		final Recipients recipients = envelopesApi.listRecipients(accountId, envelopeId);
		recipients.getSigners().forEach(s -> s.setClientUserId(EMPTY)); //remove clientUserId to enable reminder emails to be sent

		return recipients;
	}

	private List<Signer> buildSigners(final String clientUserId, final String clientUserName, final String clientUserEmail, final int numberOfAgreements){
		final Signer signer = new Signer();
		signer.setClientUserId(clientUserId);
		signer.setEmail(clientUserEmail);
		signer.setName(clientUserName);
		signer.setRecipientId("1");
		signer.setTabs(buildTabs(numberOfAgreements));
		signer.setSigningGroupId("true");

		return newArrayList(signer);
	}

	private Tabs buildTabs(final int numberOfPages){
		final Tabs tabs = new Tabs();

		for(int pageNumber = 1; pageNumber <= numberOfPages;  pageNumber++){
			tabs.getSignHereTabs().add(addSignature(pageNumber));
		}

		return tabs;
	}

	private List<Document> buildDocuments(final Map<String, Object> formData) throws IOException, DocumentException {
		final List<Document> documents = newArrayList();
		documents.add(getLoa(formData));

		return documents;
	}

	private Document getLoa(final Map<String, Object> formData) throws IOException, DocumentException {
		final List<Map<String, Object>> agreements = (List) formData.get("agreements");
		final ListIterator<Map<String, Object>> agreementsIterator = agreements.listIterator();
		final List<byte[]> loaDocuments = newArrayList();
		while(agreementsIterator.hasNext()){
			final Map<String, Object> agreement = agreementsIterator.next();
			final Map<String, Object> documentData = Maps.newHashMap(formData);
			documentData.remove("agreements");
			documentData.putAll(agreement);
			documentData.put("currentDate", new LocalDate().toString("dd/MMM/yyyy"));

			byte[] loaBytes = populateAcroformFields(utils.readClasspathFile(loaFileName), documentData, String.valueOf(agreementsIterator.nextIndex()));
			loaDocuments.add(loaBytes);
		}

		String mergedLoaFilename = null;
		final byte[] mergedLoa;
		try{
			mergedLoaFilename = mergeFiles(loaDocuments);
			mergedLoa = utils.readFile(mergedLoaFilename);
		}finally {
			if(nonNull(mergedLoaFilename)){
				FileUtils.deleteQuietly(new File(mergedLoaFilename).getParentFile());
			}
		}

		final Document loa = new Document();
		loa.setDocumentBase64(encodeToString(mergedLoa, false));
		loa.setDocumentId(DOCUMENT_ID_LOA);
		loa.setName("LOA.pdf");

		return loa;
	}

	private RecipientViewRequest buildRecipientView(final String returnUrl, final String clientUserId, final String clientUserName,
													final String clientUserEmail){
		RecipientViewRequest recipientView = new RecipientViewRequest();
		recipientView.setReturnUrl(returnUrl);
		recipientView.setClientUserId(clientUserId);
		recipientView.setAuthenticationMethod("email");
		recipientView.setUserName(clientUserName);
		recipientView.setEmail(clientUserEmail);
		recipientView.setRecipientId("1");

		return recipientView;
	}

	private Map<String, Object> buildFormData(final ClaimRequest claimRequest){
		final Map<String, Object> formData = Maps.newHashMap();
		formData.putAll(buildClaimantMap(claimRequest.getClaimant()));
		formData.putAll(buildAddressMap(claimRequest.getAddress()));

		final ListIterator<Address> previousAddressIterator = claimRequest.getPreviousAddresses().listIterator();
		while(previousAddressIterator.hasNext()){
			formData.putAll(buildPreviousAddressMap(previousAddressIterator.next(), previousAddressIterator.nextIndex()));
		}

		formData.put("agreements", buildAgreements(claimRequest.getAgreements()));

		return formData;
	}

	private static SignHere addSignature(final int pageNumber){
		// Create a SignHere tab somewhere on the document for the signer to sign
		SignHere signHere = new SignHere();
		signHere.setDocumentId(DOCUMENT_ID_LOA);
		signHere.setPageNumber(String.valueOf(pageNumber));
		signHere.setRecipientId("1");
		signHere.setXPosition("170");
		signHere.setYPosition("593");
		signHere.setScaleValue("1.0");

		return signHere;
	}
}
