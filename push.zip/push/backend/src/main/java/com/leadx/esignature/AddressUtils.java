package com.leadx.esignature;

import static java.util.Arrays.asList;
import static java.util.Objects.nonNull;
import static java.util.stream.Collectors.joining;
import static org.apache.commons.lang3.StringUtils.defaultString;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.text.WordUtils;

import com.google.common.collect.Maps;

public class AddressUtils {
	public static Map<String, Object> buildAddressMap(final Address address){
		final LinkedList<String> addressFields = getAddressFields(address);

		String postcode = "";
		if(nonNull(address.getPostcode())){
			postcode = address.getPostcode().toUpperCase();
		}

		Map<String, Object> addressMap = Maps.newHashMap();
		addressMap.put("claimantAddressThreeLineAddressAddressLine1", join(defaultString(addressFields.poll()), defaultString(addressFields.poll())));
		addressMap.put("claimantAddressThreeLineAddressAddressLine2", join(defaultString(addressFields.poll()), defaultString(addressFields.poll())));
		addressMap.put("claimantAddressThreeLineAddressAddressLine3", join(defaultString(addressFields.poll()), defaultString(addressFields.poll())));
		addressMap.put("claimantAddressPostcode", postcode);

		return addressMap;
	}

	public static Map<String, Object> buildPreviousAddressMap(final Address address, final int index){
		final String prefix = "previousAddress" + index;
		final LinkedList<String> addressFields = getAddressFields(address);

		String postcode = "";
		if(nonNull(address.getPostcode())){
			postcode = address.getPostcode().toUpperCase();
		}

		final String singleLineAddress = join(defaultString(addressFields.poll()), defaultString(addressFields.poll()), defaultString(addressFields.poll()),
				defaultString(addressFields.poll()), defaultString(addressFields.poll()), defaultString(addressFields.poll()));

		final Map<String, Object> addressMap = Maps.newHashMap();
		addressMap.put(prefix + "AddressOneLineAddressWithoutTownAddressLine", singleLineAddress);
		addressMap.put(prefix + "AddressPostcode", postcode);

		return addressMap;
	}

	private static LinkedList<String> getAddressFields(final Address address){
		final LinkedList<String> addressFields = new LinkedList<>();
		appendIfNotBlank(addressFields, address.getDepartmentName());
		appendIfNotBlank(addressFields, address.getOrganisationName());
		appendIfNotBlank(addressFields, address.getSubBuildingName(), address.getBuildingName());
		appendIfNotBlank(addressFields, address.getBuildingNumber(), address.getThoroughfare());
		appendIfNotBlank(addressFields, address.getDependentLocality());
		appendIfNotBlank(addressFields, address.getTown());

		return addressFields;
	}

	private static String join(String...fields){
		return asList(fields).stream()
				.filter(StringUtils::isNotBlank)
				.collect(joining(", "));
	}

	private static void appendIfNotBlank(List<String> list, final String... elements) {
		if (containsValues(elements)) {
			String value = mergeFields(elements);
			list.add(WordUtils.capitalizeFully(value) );
		}
	}

	private static boolean containsValues(final String... args) {
		for (String arg : args) {
			if (StringUtils.isNotBlank(arg)) {
				return true;
			}
		}

		return false;
	}

	private static String mergeFields(final String... args) {
		StringBuilder builder = new StringBuilder();
		for (String arg : args) {
			if (StringUtils.isNotBlank(arg)) {
				builder.append(arg)
						.append(" ");
			}
		}

		return builder.toString().trim();
	}
}
