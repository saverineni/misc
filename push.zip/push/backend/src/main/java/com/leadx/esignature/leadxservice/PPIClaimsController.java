package com.leadx.esignature.leadxservice;


import com.itextpdf.text.DocumentException;
import com.leadx.esignature.leadxservice.services.PDFGeneratorService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.ByteArrayInputStream;
import java.io.IOException;
@Controller
@RequestMapping(value = "/unsecure")
public class PPIClaimsController {

    private static final Logger LOG = LoggerFactory.getLogger(PPIClaimsController.class);

    @Autowired
    private PDFGeneratorService service;

    @ResponseBody
    @RequestMapping(value = "/ppi-claims-api", method = RequestMethod.POST)
    public ResponseEntity<InputStreamResource> createPDF(@RequestBody FormData formData) throws DocumentException, IOException {

        ByteArrayInputStream byteArrayInputStream = service.generatePDFStream(formData);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + formData.getPersonalDetails().getFirstName() + ".pdf")
                .header(HttpHeaders.CONTENT_TYPE, "application/pdf")
                .body(new InputStreamResource(byteArrayInputStream));
    }

}


