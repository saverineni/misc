package com.leadx.esignature.docusignservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;


import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.leadx.hibernate.domain.BaseIntegerDomain;

@Entity
@Table(name = "docusign_request")
public class DocuSignRequest extends BaseIntegerDomain {
	@Column(name = "FK_LeadID")
	private long leadId;

	private int numberOfAgreements;
	private String baseURI;

	public DocuSignRequest() {
	}

	private DocuSignRequest(long leadId, int numberOfAgreements, String baseURI) {
		this.leadId = leadId;
		this.numberOfAgreements = numberOfAgreements;
		this.baseURI = baseURI;
	}

	public static class Builder{
		private long leadId;
		private int numberOfAgreements;
		private String baseURI;

		public Builder setLeadId(long leadId) {
			this.leadId = leadId;
			return this;
		}

		public Builder setNumberOfAgreements(int numberOfAgreements) {
			this.numberOfAgreements = numberOfAgreements;
			return this;
		}

		public Builder setBaseURI(String baseURI) {
			this.baseURI = baseURI;
			return this;
		}

		public DocuSignRequest createDocuSignRequest() {
			return new DocuSignRequest(leadId, numberOfAgreements, baseURI);
		}
	}

	@Override
	public boolean equals(final Object obj) {
		return deepEquals(obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

	public long getLeadId() {
		return leadId;
	}

	public void setLeadId(long leadId) {
		this.leadId = leadId;
	}

	public int getNumberOfAgreements() {
		return numberOfAgreements;
	}

	public void setNumberOfAgreements(int numberOfAgreements) {
		this.numberOfAgreements = numberOfAgreements;
	}

	public String getBaseURI() {
		return baseURI;
	}

	public void setBaseURI(String baseURI) {
		this.baseURI = baseURI;
	}
}
