package com.leadx.esignature.leadxservice;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FormData {

    private PersonalDetails personalDetails;
    private Address addressDetails;
    private Lender lenderDetails;
    private String signature;

    public Lender getLenderDetails() {
        return lenderDetails;
    }

    public void setLenderDetails(Lender lenderDetails) {
        this.lenderDetails = lenderDetails;
    }

    public Address getAddressDetails() {
        return addressDetails;
    }

    public void setAddressDetails(Address addressDetails) {
        this.addressDetails = addressDetails;
    }

    public PersonalDetails getPersonalDetails() {
        return personalDetails;
    }

    public void setPersonalDetails(PersonalDetails personalDetails) {
        this.personalDetails = personalDetails;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

}
