package com.leadx.esignature.docusignservice.commands;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Maps.newHashMap;
import static com.leadx.esignature.Utils.getClaimantName;
import static com.leadx.esignature.Utils.populateAcroformFields;
import static com.leadx.lib.utl.ListUtils.first;
import static java.util.Objects.isNull;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.docusign.esign.client.ApiException;
import com.docusign.esign.model.*;
import com.itextpdf.text.DocumentException;
import com.leadx.claimant.client.ClaimantDto;
import com.leadx.claimant.client.ClaimantServiceWrapper;
import com.leadx.esignature.Agreement;
import com.leadx.esignature.ClaimRequest;
import com.leadx.esignature.docusignservice.DocuSignRequest;
import com.leadx.esignature.docusignservice.LeadXEnvelopeDefinition;
import com.leadx.web.tcg.client.TcgClaimantServiceWrapper;
import com.leadx.web.tcg.client.claimservice.AgreementDto;
import com.leadx.web.tcg.client.claimservice.ClaimDto;
import com.leadx.web.tcg.client.claimservice.CreditAgreementAndClaimDto;

@Component
public class TcgLPackGenerateUrlCommand extends BaseGenerateUrlCommand implements GenerateUrlCommand {

	@Autowired
	private ClaimantServiceWrapper claimantServiceWrapper;

	@Autowired
	private TcgClaimantServiceWrapper tcgClaimantServiceWrapper;

	public String execute(final ClaimRequest claimRequest)  throws IOException, DocumentException, ApiException {
		validate(claimRequest);

		final int claimantId = claimRequest.getClaimant().getId();
		final int claimId = first(claimRequest.getAgreements()).getClaimId();

		final ClaimantDto claimantDto = this.claimantServiceWrapper.getClaimantById(claimantId);
		final Optional<CreditAgreementAndClaimDto> creditAgreementAndClaimDto =
				this.tcgClaimantServiceWrapper.getCreditAgreementsAndClaimsForClaimant(claimantId)
						.stream()
						.filter(c -> c.getClaimDto().getClaimId() == claimId)
						.findFirst();

		if (isNull(claimantDto) || !creditAgreementAndClaimDto.isPresent()) {
			throw new IllegalArgumentException("Unable to lookup claimant/claim details for claimant ID " + claimantId + " and claim ID " + claimId);
		}

		final ClaimDto claimDto = creditAgreementAndClaimDto.get().getClaimDto();

		if (claimantId != claimDto.getClaimantId()) {
			throw new IllegalArgumentException("Claimant/Claim ID mis-match, claim " + claimDto.getClaimId() + " actually exists for claimant " + claimDto.getClaimantId());
		}

		final String clientUserId = String.valueOf(claimantId);
		final String clientUserName = getClaimantName(claimantDto.getTitle(), claimantDto.getForename(), claimantDto.getSurname());
		final String clientUserEmail = claimantDto.getEmail();

		final DocuSignRequest docuSignRequest = new DocuSignRequest.Builder()
				.setLeadId(claimantId)
				.setNumberOfAgreements(1)
				.createDocuSignRequest();
		docuSignRepository.saveRequest(docuSignRequest);

		LeadXEnvelopeDefinition envDef = new LeadXEnvelopeDefinition();

		final Agreement agreementFromRequest = first(claimRequest.getAgreements());
		final AgreementDto agreementFromDb = creditAgreementAndClaimDto.get().getAgreementDto();

		final Map<String, Object> formData = newHashMap();
		formData.put("clientName", clientUserName);
		formData.put("lenderName", agreementFromDb.getLenderName());
		formData.put("agreementNumber", agreementFromDb.getAgreementNumber());
		formData.put("claimantId", claimantId);
		formData.put("claimId", claimId);
		formData.put("currentDate", new LocalDate().toString("dd/MMM/yyyy"));
		formData.put("financialOrInsuranceProductsExperience", agreementFromRequest.getFinancialOrInsuranceProductsExperience());
		formData.put("financialOrInsuranceProductsExperienceDetails", agreementFromRequest.getFinancialOrInsuranceProductsExperienceDetails());
		formData.put("lenderCommissionForSellingPpi", agreementFromRequest.getLenderCommissionForSellingPpi());
		formData.put("lenderCommissionForSellingPpiDetails", agreementFromRequest.getLenderCommissionForSellingPpiDetails());
		formData.put("acceptingPolicyKnowingLenderCommission", agreementFromRequest.getAcceptingPolicyKnowingLenderCommission());
		formData.put("acceptingPolicyKnowingLenderCommissionDetails", agreementFromRequest.getAcceptingPolicyKnowingLenderCommissionDetails());
		formData.put("claimBenefitsOfferedInPpiPolicy", agreementFromRequest.getClaimBenefitsOfferedInPpiPolicy());
		formData.put("claimBenefitsOfferedInPpiPolicyDetails", agreementFromRequest.getClaimBenefitsOfferedInPpiPolicyDetails());
		formData.put("ppiPolicyCancellation", agreementFromRequest.getPpiPolicyCancellation());
		formData.put("ppiPolicyCancellationCantRememberDate", agreementFromRequest.getPpiPolicyCancellationCantRememberDate());
		formData.put("ppiSummaryQuestionnaireDetails", agreementFromRequest.getPpiSummaryQuestionnaireDetails());
		formData.put("ppiPolicyCancellationDate", agreementFromRequest.getPpiPolicyCancellationDate());

		final List<Document> documents = buildDocuments(formData);
		envDef.setDocuments(documents);
		envDef.setRecipients(new Recipients());
		envDef.getRecipients().setSigners(buildSigners(clientUserId, clientUserName, clientUserEmail, "1"));

		envDef.setEmailSubject("The Claims Guys Legal Pack");
		envDef.setEmailBlurb("Don’t forget to sign your Agreement to Proceed");

		return getUrl(clientUserId, clientUserName, clientUserEmail, docuSignRequest, envDef);
	}

	private List<Document> buildDocuments(final Map<String, Object> formData) throws IOException, DocumentException {
		final List<Document> documents = newArrayList();
		documents.add(getA2P(formData));
		documents.add(getPpiSummaryQuestionnaire(formData));

		return documents;
	}

	private List<Signer> buildSigners(final String clientUserId, final String clientUserName, final String clientUserEmail, final String documentId){
		final Signer signer = generateDefaultSigner(clientUserId, clientUserName, clientUserEmail);
		signer.setRecipientId("1");
		signer.setTabs(buildTabs(documentId));
		signer.setSigningGroupId("true");

		return newArrayList(signer);
	}

	private Tabs buildTabs(final String documentId){
		final Tabs tabs = new Tabs();
		tabs.getSignHereTabs().add(addSignature(3, documentId));

		return tabs;
	}

	private static SignHere addSignature(final int pageNumber, final String documentId){
		// Create a SignHere tab somewhere on the document for the signer to sign
		SignHere signHere = generateDefaultSignHere(pageNumber, documentId);
		signHere.setYPosition("430");
		signHere.setScaleValue("1.0");

		return signHere;
	}

	private Document getA2P(final Map<String, Object> formData) throws IOException, DocumentException {
		final List<byte[]> a2pDocuments = newArrayList();
		byte[] a2p1Bytes = populateAcroformFields(utils.readClasspathFile("docs/tcgl_pack/AGREEMENT_TO_PROCEED_SINGLE_P1.pdf"), formData, "1");
		byte[] a2p2Bytes = populateAcroformFields(utils.readClasspathFile("docs/tcgl_pack/AGREEMENT_TO_PROCEED_SINGLE_P2.pdf"), formData, "2");
		byte[] a2p3Bytes = populateAcroformFields(utils.readClasspathFile("docs/tcgl_pack/AGREEMENT_TO_PROCEED_SINGLE_P3.pdf"), formData, "3");
		a2pDocuments.add(a2p1Bytes);
		a2pDocuments.add(a2p2Bytes);
		a2pDocuments.add(a2p3Bytes);

		return generateDocument(a2pDocuments, "A2P.pdf", "1");
	}

	private Document getPpiSummaryQuestionnaire(final Map<String, Object> formData) throws IOException, DocumentException {
		final List<byte[]> ppiSummaryQuestionaire = newArrayList();
		byte[] ppiSummaryQuestionnaireBytes = populateAcroformFields(utils.readClasspathFile("docs/tcgl_pack/PPI_SUMMARY_QUESTIONNAIRE.pdf"), formData, "4");
		ppiSummaryQuestionaire.add(ppiSummaryQuestionnaireBytes);

		return generateDocument(ppiSummaryQuestionaire, "PPI_SUMMARY_QUESTIONNAIRE.pdf", "2");
	}

	private static void validate(final ClaimRequest claimRequest){
		checkArgument(claimRequest.getClaimant() != null, "Claimant cannot be null");
		checkArgument(claimRequest.getClaimant().getId() != 0, "Claimant ID must be supplied cannot be null");
		checkArgument(claimRequest.getAgreements().size() > 0, "At least one agreement should exist");
		checkArgument(first(claimRequest.getAgreements()).getClaimId() != 0, "Claim ID must be supplied");
	}
}
