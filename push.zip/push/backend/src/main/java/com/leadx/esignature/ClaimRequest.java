package com.leadx.esignature;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimRequest {
	private String documentDefinition;
	private long leadId;
	private Claimant claimant;
	private Address address;
	private List<Address> previousAddresses;
	private List<Agreement> agreements;

	public ClaimRequest() {
	}

	private ClaimRequest(String documentDefinition, long leadId, Claimant claimant, Address address, List<Address> previousAddresses, List<Agreement> agreements) {
		this.documentDefinition = documentDefinition;
		this.leadId = leadId;
		this.claimant = claimant;
		this.address = address;
		this.previousAddresses = previousAddresses;
		this.agreements = agreements;
	}

	public static class Builder{
		private String documentDefinition;
		private long leadId;
		private Claimant claimant;
		private Address address;
		private List<Address> previousAddresses;
		private List<Agreement> agreements;

		public Builder setDocumentDefinition(String documentDefinition) {
			this.documentDefinition = documentDefinition;
			return this;
		}

		public Builder setLeadId(long leadId) {
			this.leadId = leadId;
			return this;
		}

		public Builder setClaimant(Claimant claimant) {
			this.claimant = claimant;
			return this;
		}

		public Builder setAddress(Address address) {
			this.address = address;
			return this;
		}

		public Builder setPreviousAddresses(List<Address> previousAddresses) {
			this.previousAddresses = previousAddresses;
			return this;
		}

		public Builder setAgreements(List<Agreement> agreements) {
			this.agreements = agreements;
			return this;
		}

		public ClaimRequest createClaimRequest() {
			return new ClaimRequest(documentDefinition, leadId, claimant, address, previousAddresses, agreements);
		}
	}

	public String getDocumentDefinition() {
		return documentDefinition;
	}

	public void setDocumentDefinition(String documentDefinition) {
		this.documentDefinition = documentDefinition;
	}

	public long getLeadId() {
		return leadId;
	}

	public void setLeadId(long leadId) {
		this.leadId = leadId;
	}

	public Claimant getClaimant() {
		return claimant;
	}

	public void setClaimant(Claimant claimant) {
		this.claimant = claimant;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public List<Address> getPreviousAddresses() {
		return previousAddresses;
	}

	public void setPreviousAddresses(List<Address> previousAddresses) {
		this.previousAddresses = previousAddresses;
	}

	public List<Agreement> getAgreements() {
		return agreements;
	}

	public void setAgreements(List<Agreement> agreements) {
		this.agreements = agreements;
	}
}
