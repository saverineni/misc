package com.leadx.esignature;

import java.util.List;

import com.google.common.collect.Lists;

public class TestUtils {

	public static ClaimRequest createClaimRequest(){
		Claimant claimant = new Claimant.Builder()
				.setTitle("Mr")
				.setForename("Test")
				.setSurname("Claimant")
				.setDob("02-02-1970")
				.setHomeTelephone("01234567890")
				.setEmail("suresh.chidambaram@leadx.com")
				.createClaimant();

		Address address = new Address.Builder()
				.setBuildingNumber("10")
				.setThoroughfare("Oxford Street")
				.setTown("Oxford")
				.setPostcode("1A 1AA")
				.createAddress();

		Address prevAddress1 = new Address.Builder()
				.setBuildingNumber("20")
				.setThoroughfare("Cambridge Street")
				.setTown("Cambridge")
				.setPostcode("2A 2AA")
				.createAddress();

		Address prevAddress2 = new Address.Builder()
				.setBuildingNumber("30")
				.setThoroughfare("Manchester Street")
				.setTown("Manchester")
				.setPostcode("3A 3AA")
				.createAddress();

		List<Address> prevAddresses = Lists.newArrayList(prevAddress1, prevAddress2);

		Agreement agreement1 = new Agreement.Builder()
				.setLenderName("Barclays")
				.setTypeOfCredit("Loan")
				.createAgreement();

		Agreement agreement2 = new Agreement.Builder()
				.setLenderName("HSBC")
				.setTypeOfCredit("Credit Card")
				.createAgreement();

		List<Agreement> agreements = Lists.newArrayList(agreement1, agreement2);

		ClaimRequest claimRequest = new ClaimRequest.Builder()
				.setLeadId(123456)
				.setClaimant(claimant)
				.setAddress(address)
				.setPreviousAddresses(prevAddresses)
				.setAgreements(agreements)
				.createClaimRequest();

		return claimRequest;
	}

	public static ClaimRequest createClaimRequest(final String documentDefinitionName) {
		final ClaimRequest claimRequest = new ClaimRequest();
		claimRequest.setDocumentDefinition(documentDefinitionName);

		return claimRequest;
	}
}
