package com.leadx.esignature.docusignservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class DocuSignScheduler {
	private static final Logger LOG = LoggerFactory.getLogger(DocuSignScheduler.class);

	@Autowired
	private DocuSignService docuSignService;

	@Value("${esignature.server.docusign.reminder.enabled:true}")
	private Boolean reminderEmailEnabled;

	@Scheduled(cron="${esignature.server.docusign.reminder.cron}")
	public void triggerReminderEmail() throws Exception {
		if (this.reminderEmailEnabled) {
			LOG.info("BEGIN: Reminder emails for incomplete documents");
			this.docuSignService.sendReminderEmails();
			LOG.info("END: Reminder emails for incomplete documents");
		}
	}
}
