package com.leadx.esignature;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Agreement {
	private int claimId;
	private int lenderId;
	private String lenderName;
	private String typeOfCredit;
	private String jointApplicantTitle;
	private String jointApplicantForename;
	private String jointApplicantMiddleName;
	private String jointApplicantSurname;
	private String jointApplicantPreviousSurname;
	private String jointApplicantDob;
	private String jointApplicantEmail;
	private String didYouTakeOutPpi;
	private String toldPpiAffectsEligibility;
	private String costsOfPpiExplained;
	private Boolean financialOrInsuranceProductsExperience;
	private String financialOrInsuranceProductsExperienceDetails;
	private String lenderCommissionForSellingPpi;
	private String lenderCommissionForSellingPpiDetails;
	private Boolean acceptingPolicyKnowingLenderCommission;
	private String acceptingPolicyKnowingLenderCommissionDetails;
	private String claimBenefitsOfferedInPpiPolicy;
	private String claimBenefitsOfferedInPpiPolicyDetails;
	private String ppiPolicyCancellation;
	private Boolean ppiPolicyCancellationCantRememberDate;
	private String ppiSummaryQuestionnaireDetails;
	private String ppiPolicyCancellationDate;
	private String promisedCheaperRate;
	private String feltPressured;
	private String complaintDetails;
	private String employmentStatus;
	private String employmentSector;
	private String employmentDateFrom;
	private String employmentDateTo;
	private String entitledToSickPay;
	private String timeAtEmployer;
	private String ableToMakeRepaymentsIfSick;
	private String howAbleToMakeRepayments;
	private String amountOfInsuranceAndSavings;
	private String ableToMakeRepaymentsForPeriod;
	private String amountOfInsuranceAndSavingsDetail;

	public Agreement() {
	}

	public Agreement(int claimId, int lenderId, String lenderName, String typeOfCredit, String jointApplicantTitle, String jointApplicantForename,
			String jointApplicantMiddleName, String jointApplicantSurname, String jointApplicantPreviousSurname, String jointApplicantDob,
			String jointApplicantEmail, String didYouTakeOutPpi, String toldPpiAffectsEligibility, String costsOfPpiExplained,
			Boolean financialOrInsuranceProductsExperience, String financialOrInsuranceProductsExperienceDetails, String lenderCommissionForSellingPpi,
			String lenderCommissionForSellingPpiDetails, Boolean acceptingPolicyKnowingLenderCommission, String acceptingPolicyKnowingLenderCommissionDetails,
			String claimBenefitsOfferedInPpiPolicy, String claimBenefitsOfferedInPpiPolicyDetails, String ppiPolicyCancellation,
			Boolean ppiPolicyCancellationCantRememberDate, String ppiSummaryQuestionnaireDetails, String ppiPolicyCancellationDate, String promisedCheaperRate,
			String feltPressured, String complaintDetails, String employmentStatus, String employmentSector, String employmentDateFrom, String employmentDateTo,
			String entitledToSickPay, String timeAtEmployer, String ableToMakeRepaymentsIfSick, String howAbleToMakeRepayments,
			String amountOfInsuranceAndSavings, String ableToMakeRepaymentsForPeriod, String amountOfInsuranceAndSavingsDetail) {
		this.claimId = claimId;
		this.lenderId = lenderId;
		this.lenderName = lenderName;
		this.typeOfCredit = typeOfCredit;
		this.jointApplicantTitle = jointApplicantTitle;
		this.jointApplicantForename = jointApplicantForename;
		this.jointApplicantMiddleName = jointApplicantMiddleName;
		this.jointApplicantSurname = jointApplicantSurname;
		this.jointApplicantPreviousSurname = jointApplicantPreviousSurname;
		this.jointApplicantDob = jointApplicantDob;
		this.jointApplicantEmail = jointApplicantEmail;
		this.didYouTakeOutPpi = didYouTakeOutPpi;
		this.toldPpiAffectsEligibility = toldPpiAffectsEligibility;
		this.costsOfPpiExplained = costsOfPpiExplained;
		this.financialOrInsuranceProductsExperience = financialOrInsuranceProductsExperience;
		this.financialOrInsuranceProductsExperienceDetails = financialOrInsuranceProductsExperienceDetails;
		this.lenderCommissionForSellingPpi = lenderCommissionForSellingPpi;
		this.lenderCommissionForSellingPpiDetails = lenderCommissionForSellingPpiDetails;
		this.acceptingPolicyKnowingLenderCommission = acceptingPolicyKnowingLenderCommission;
		this.acceptingPolicyKnowingLenderCommissionDetails = acceptingPolicyKnowingLenderCommissionDetails;
		this.claimBenefitsOfferedInPpiPolicy = claimBenefitsOfferedInPpiPolicy;
		this.claimBenefitsOfferedInPpiPolicyDetails = claimBenefitsOfferedInPpiPolicyDetails;
		this.ppiPolicyCancellation = ppiPolicyCancellation;
		this.ppiPolicyCancellationCantRememberDate = ppiPolicyCancellationCantRememberDate;
		this.ppiSummaryQuestionnaireDetails = ppiSummaryQuestionnaireDetails;
		this.ppiPolicyCancellationDate = ppiPolicyCancellationDate;
		this.promisedCheaperRate = promisedCheaperRate;
		this.feltPressured = feltPressured;
		this.complaintDetails = complaintDetails;
		this.employmentStatus = employmentStatus;
		this.employmentSector = employmentSector;
		this.employmentDateFrom = employmentDateFrom;
		this.employmentDateTo = employmentDateTo;
		this.entitledToSickPay = entitledToSickPay;
		this.timeAtEmployer = timeAtEmployer;
		this.ableToMakeRepaymentsIfSick = ableToMakeRepaymentsIfSick;
		this.howAbleToMakeRepayments = howAbleToMakeRepayments;
		this.amountOfInsuranceAndSavings = amountOfInsuranceAndSavings;
		this.ableToMakeRepaymentsForPeriod = ableToMakeRepaymentsForPeriod;
		this.amountOfInsuranceAndSavingsDetail = amountOfInsuranceAndSavingsDetail;
	}

	public static class Builder{

		private int claimId;
		private int lenderId;
		private String lenderName;
		private String typeOfCredit;
		private String jointApplicantTitle;
		private String jointApplicantForename;
		private String jointApplicantMiddleName;
		private String jointApplicantSurname;
		private String jointApplicantPreviousSurname;
		private String jointApplicantDob;
		private String jointApplicantEmail;
		private String didYouTakeOutPpi;
		private String toldPpiAffectsEligibility;
		private String costsOfPpiExplained;
		private Boolean financialOrInsuranceProductsExperience;
		private String financialOrInsuranceProductsExperienceDetails;
		private String lenderCommissionForSellingPpi;
		private String lenderCommissionForSellingPpiDetails;
		private Boolean acceptingPolicyKnowingLenderCommission;
		private String acceptingPolicyKnowingLenderCommissionDetails;
		private String claimBenefitsOfferedInPpiPolicy;
		private String claimBenefitsOfferedInPpiPolicyDetails;
		private String ppiPolicyCancellation;
		private Boolean ppiPolicyCancellationCantRememberDate;
		private String ppiSummaryQuestionnaireDetails;
		private String ppiPolicyCancellationDate;
		private String promisedCheaperRate;
		private String feltPressured;
		private String complaintDetails;
		private String employmentStatus;
		private String employmentSector;
		private String employmentDateFrom;
		private String employmentDateTo;
		private String entitledToSickPay;
		private String timeAtEmployer;
		private String ableToMakeRepaymentsIfSick;
		private String howAbleToMakeRepayments;
		private String amountOfInsuranceAndSavings;
		private String ableToMakeRepaymentsForPeriod;
		private String amountOfInsuranceAndSavingsDetail;

		public Builder setClaimId(int claimId) {
			this.claimId = claimId;
			return this;
		}

		public Builder setLenderId(int lenderId) {
			this.lenderId = lenderId;
			return this;
		}

		public Builder setLenderName(String lenderName) {
			this.lenderName = lenderName;
			return this;
		}

		public Builder setTypeOfCredit(String typeOfCredit) {
			this.typeOfCredit = typeOfCredit;
			return this;
		}

		public Builder setJointApplicantTitle(String jointApplicantTitle) {
			this.jointApplicantTitle = jointApplicantTitle;
			return this;
		}

		public Builder setJointApplicantForename(String jointApplicantForename) {
			this.jointApplicantForename = jointApplicantForename;
			return this;
		}

		public Builder setJointApplicantMiddleName(String jointApplicantMiddleName) {
			this.jointApplicantMiddleName = jointApplicantMiddleName;
			return this;
		}

		public Builder setJointApplicantSurname(String jointApplicantSurname) {
			this.jointApplicantSurname = jointApplicantSurname;
			return this;
		}

		public Builder setJointApplicantPreviousSurname(String jointApplicantPreviousSurname) {
			this.jointApplicantPreviousSurname = jointApplicantPreviousSurname;
			return this;
		}

		public Builder setJointApplicantDob(String jointApplicantDob) {
			this.jointApplicantDob = jointApplicantDob;
			return this;
		}

		public Builder setJointApplicantEmail(String jointApplicantEmail) {
			this.jointApplicantEmail = jointApplicantEmail;
			return this;
		}

		public Builder setDidYouTakeOutPpi(String didYouTakeOutPpi) {
			this.didYouTakeOutPpi = didYouTakeOutPpi;
			return this;
		}

		public Builder setToldPpiAffectsEligibility(String toldPpiAffectsEligibility) {
			this.toldPpiAffectsEligibility = toldPpiAffectsEligibility;
			return this;
		}

		public Builder setCostsOfPpiExplained(String costsOfPpiExplained) {
			this.costsOfPpiExplained = costsOfPpiExplained;
			return this;
		}

		public Builder setFinancialOrInsuranceProductsExperience(Boolean financialOrInsuranceProductsExperience) {
			this.financialOrInsuranceProductsExperience = financialOrInsuranceProductsExperience;
			return this;
		}

		public Builder setFinancialOrInsuranceProductsExperienceDetails(String financialOrInsuranceProductsExperienceDetails) {
			this.financialOrInsuranceProductsExperienceDetails = financialOrInsuranceProductsExperienceDetails;
			return this;
		}

		public Builder setLenderCommissionForSellingPpi(String lenderCommissionForSellingPpi) {
			this.lenderCommissionForSellingPpi = lenderCommissionForSellingPpi;
			return this;
		}

		public Builder setLenderCommissionForSellingPpiDetails(String lenderCommissionForSellingPpiDetails) {
			this.lenderCommissionForSellingPpiDetails = lenderCommissionForSellingPpiDetails;
			return this;
		}

		public Builder setAcceptingPolicyKnowingLenderCommission(Boolean acceptingPolicyKnowingLenderCommission) {
			this.acceptingPolicyKnowingLenderCommission = acceptingPolicyKnowingLenderCommission;
			return this;
		}

		public Builder setAcceptingPolicyKnowingLenderCommissionDetails(String acceptingPolicyKnowingLenderCommissionDetails) {
			this.acceptingPolicyKnowingLenderCommissionDetails = acceptingPolicyKnowingLenderCommissionDetails;
			return this;
		}

		public Builder setClaimBenefitsOfferedInPpiPolicy(String claimBenefitsOfferedInPpiPolicy) {
			this.claimBenefitsOfferedInPpiPolicy = claimBenefitsOfferedInPpiPolicy;
			return this;
		}

		public Builder setClaimBenefitsOfferedInPpiPolicyDetails(String claimBenefitsOfferedInPpiPolicyDetails) {
			this.claimBenefitsOfferedInPpiPolicyDetails = claimBenefitsOfferedInPpiPolicyDetails;
			return this;
		}

		public Builder setPpiPolicyCancellation(String ppiPolicyCancellation) {
			this.ppiPolicyCancellation = ppiPolicyCancellation;
			return this;
		}

		public Builder setPpiPolicyCancellationCantRememberDate(Boolean ppiPolicyCancellationCantRememberDate) {
			this.ppiPolicyCancellationCantRememberDate = ppiPolicyCancellationCantRememberDate;
			return this;
		}

		public Builder setPpiSummaryQuestionnaireDetails(String ppiSummaryQuestionnaireDetails) {
			this.ppiSummaryQuestionnaireDetails = ppiSummaryQuestionnaireDetails;
			return this;
		}

		public Builder setPpiPolicyCancellationDate(String ppiPolicyCancellationDate) {
			this.ppiPolicyCancellationDate = ppiPolicyCancellationDate;
			return this;
		}

		public Builder setPromisedCheaperRate(String promisedCheaperRate) {
			this.promisedCheaperRate = promisedCheaperRate;
			return this;
		}

		public Builder setFeltPressured(String feltPressured) {
			this.feltPressured = feltPressured;
			return this;
		}

		public Builder setComplaintDetails(String complaintDetails) {
			this.complaintDetails = complaintDetails;
			return this;
		}

		public Builder setEmploymentStatus(String employmentStatus) {
			this.employmentStatus = employmentStatus;
			return this;
		}

		public Builder setEmploymentSector(String employmentSector) {
			this.employmentSector = employmentSector;
			return this;
		}

		public Builder setEmploymentDateFrom(String employmentDateFrom) {
			this.employmentDateFrom = employmentDateFrom;
			return this;
		}

		public Builder setEmploymentDateTo(String employmentDateTo) {
			this.employmentDateTo = employmentDateTo;
			return this;
		}

		public Builder setEntitledToSickPay(String entitledToSickPay) {
			this.entitledToSickPay = entitledToSickPay;
			return this;
		}

		public Builder setTimeAtEmployer(String timeAtEmployer) {
			this.timeAtEmployer = timeAtEmployer;
			return this;
		}

		public Builder setAbleToMakeRepaymentsIfSick(String ableToMakeRepaymentsIfSick) {
			this.ableToMakeRepaymentsIfSick = ableToMakeRepaymentsIfSick;
			return this;
		}

		public Builder setHowAbleToMakeRepayments(String howAbleToMakeRepayments) {
			this.howAbleToMakeRepayments = howAbleToMakeRepayments;
			return this;
		}

		public Builder setAmountOfInsuranceAndSavings(String amountOfInsuranceAndSavings) {
			this.amountOfInsuranceAndSavings = amountOfInsuranceAndSavings;
			return this;
		}

		public Builder setAbleToMakeRepaymentsForPeriod(String ableToMakeRepaymentsForPeriod) {
			this.ableToMakeRepaymentsForPeriod = ableToMakeRepaymentsForPeriod;
			return this;
		}

		public Builder setAmountOfInsuranceAndSavingsDetail(String amountOfInsuranceAndSavingsDetail) {
			this.amountOfInsuranceAndSavingsDetail = amountOfInsuranceAndSavingsDetail;
			return this;
		}

		public Agreement createAgreement() {
			return new Agreement(claimId, lenderId, lenderName, typeOfCredit, jointApplicantTitle, jointApplicantForename, jointApplicantMiddleName,
					jointApplicantSurname, jointApplicantPreviousSurname, jointApplicantDob, jointApplicantEmail, didYouTakeOutPpi, toldPpiAffectsEligibility,
					costsOfPpiExplained, financialOrInsuranceProductsExperience, financialOrInsuranceProductsExperienceDetails, lenderCommissionForSellingPpi,
					lenderCommissionForSellingPpiDetails, acceptingPolicyKnowingLenderCommission, acceptingPolicyKnowingLenderCommissionDetails,
					claimBenefitsOfferedInPpiPolicy, claimBenefitsOfferedInPpiPolicyDetails, ppiPolicyCancellation, ppiPolicyCancellationCantRememberDate,
					ppiSummaryQuestionnaireDetails, ppiPolicyCancellationDate, promisedCheaperRate, feltPressured, complaintDetails, employmentStatus,
					employmentSector, employmentDateFrom, employmentDateTo, entitledToSickPay, timeAtEmployer, ableToMakeRepaymentsIfSick,
					howAbleToMakeRepayments, amountOfInsuranceAndSavings, ableToMakeRepaymentsForPeriod, amountOfInsuranceAndSavingsDetail);
		}
	}

	public int getClaimId() {
		return claimId;
	}

	public void setClaimId(int claimId) {
		this.claimId = claimId;
	}

	public int getLenderId() {
		return lenderId;
	}

	public void setLenderId(int lenderId) {
		this.lenderId = lenderId;
	}

	public String getLenderName() {
		return lenderName;
	}

	public void setLenderName(String lenderName) {
		this.lenderName = lenderName;
	}

	public String getTypeOfCredit() {
		return typeOfCredit;
	}

	public void setTypeOfCredit(String typeOfCredit) {
		this.typeOfCredit = typeOfCredit;
	}

	public String getJointApplicantTitle() {
		return jointApplicantTitle;
	}

	public void setJointApplicantTitle(String jointApplicantTitle) {
		this.jointApplicantTitle = jointApplicantTitle;
	}

	public String getJointApplicantForename() {
		return jointApplicantForename;
	}

	public void setJointApplicantForename(String jointApplicantForename) {
		this.jointApplicantForename = jointApplicantForename;
	}

	public String getJointApplicantMiddleName() {
		return jointApplicantMiddleName;
	}

	public void setJointApplicantMiddleName(String jointApplicantMiddleName) {
		this.jointApplicantMiddleName = jointApplicantMiddleName;
	}

	public String getJointApplicantSurname() {
		return jointApplicantSurname;
	}

	public void setJointApplicantSurname(String jointApplicantSurname) {
		this.jointApplicantSurname = jointApplicantSurname;
	}

	public String getJointApplicantPreviousSurname() {
		return jointApplicantPreviousSurname;
	}

	public void setJointApplicantPreviousSurname(String jointApplicantPreviousSurname) {
		this.jointApplicantPreviousSurname = jointApplicantPreviousSurname;
	}

	public String getJointApplicantDob() {
		return jointApplicantDob;
	}

	public void setJointApplicantDob(String jointApplicantDob) {
		this.jointApplicantDob = jointApplicantDob;
	}

	public String getJointApplicantEmail() {
		return jointApplicantEmail;
	}

	public void setJointApplicantEmail(String jointApplicantEmail) {
		this.jointApplicantEmail = jointApplicantEmail;
	}

	public String getDidYouTakeOutPpi() {
		return didYouTakeOutPpi;
	}

	public void setDidYouTakeOutPpi(String didYouTakeOutPpi) {
		this.didYouTakeOutPpi = didYouTakeOutPpi;
	}

	public String getToldPpiAffectsEligibility() {
		return toldPpiAffectsEligibility;
	}

	public void setToldPpiAffectsEligibility(String toldPpiAffectsEligibility) {
		this.toldPpiAffectsEligibility = toldPpiAffectsEligibility;
	}

	public String getCostsOfPpiExplained() {
		return costsOfPpiExplained;
	}

	public void setCostsOfPpiExplained(String costsOfPpiExplained) {
		this.costsOfPpiExplained = costsOfPpiExplained;
	}

	public Boolean getFinancialOrInsuranceProductsExperience() {
		return financialOrInsuranceProductsExperience;
	}

	public void setFinancialOrInsuranceProductsExperience(Boolean financialOrInsuranceProductsExperience) {
		this.financialOrInsuranceProductsExperience = financialOrInsuranceProductsExperience;
	}

	public String getFinancialOrInsuranceProductsExperienceDetails() {
		return financialOrInsuranceProductsExperienceDetails;
	}

	public void setFinancialOrInsuranceProductsExperienceDetails(String financialOrInsuranceProductsExperienceDetails) {
		this.financialOrInsuranceProductsExperienceDetails = financialOrInsuranceProductsExperienceDetails;
	}

	public String getLenderCommissionForSellingPpi() {
		return lenderCommissionForSellingPpi;
	}

	public void setLenderCommissionForSellingPpi(String lenderCommissionForSellingPpi) {
		this.lenderCommissionForSellingPpi = lenderCommissionForSellingPpi;
	}

	public String getLenderCommissionForSellingPpiDetails() {
		return lenderCommissionForSellingPpiDetails;
	}

	public void setLenderCommissionForSellingPpiDetails(String lenderCommissionForSellingPpiDetails) {
		this.lenderCommissionForSellingPpiDetails = lenderCommissionForSellingPpiDetails;
	}

	public Boolean getAcceptingPolicyKnowingLenderCommission() {
		return acceptingPolicyKnowingLenderCommission;
	}

	public void setAcceptingPolicyKnowingLenderCommission(Boolean acceptingPolicyKnowingLenderCommission) {
		this.acceptingPolicyKnowingLenderCommission = acceptingPolicyKnowingLenderCommission;
	}

	public String getAcceptingPolicyKnowingLenderCommissionDetails() {
		return acceptingPolicyKnowingLenderCommissionDetails;
	}

	public void setAcceptingPolicyKnowingLenderCommissionDetails(String acceptingPolicyKnowingLenderCommissionDetails) {
		this.acceptingPolicyKnowingLenderCommissionDetails = acceptingPolicyKnowingLenderCommissionDetails;
	}

	public String getClaimBenefitsOfferedInPpiPolicy() {
		return claimBenefitsOfferedInPpiPolicy;
	}

	public void setClaimBenefitsOfferedInPpiPolicy(String claimBenefitsOfferedInPpiPolicy) {
		this.claimBenefitsOfferedInPpiPolicy = claimBenefitsOfferedInPpiPolicy;
	}

	public String getClaimBenefitsOfferedInPpiPolicyDetails() {
		return claimBenefitsOfferedInPpiPolicyDetails;
	}

	public void setClaimBenefitsOfferedInPpiPolicyDetails(String claimBenefitsOfferedInPpiPolicyDetails) {
		this.claimBenefitsOfferedInPpiPolicyDetails = claimBenefitsOfferedInPpiPolicyDetails;
	}

	public String getPpiPolicyCancellation() {
		return ppiPolicyCancellation;
	}

	public void setPpiPolicyCancellation(String ppiPolicyCancellation) {
		this.ppiPolicyCancellation = ppiPolicyCancellation;
	}

	public Boolean getPpiPolicyCancellationCantRememberDate() {
		return ppiPolicyCancellationCantRememberDate;
	}

	public void setPpiPolicyCancellationCantRememberDate(Boolean ppiPolicyCancellationCantRememberDate) {
		this.ppiPolicyCancellationCantRememberDate = ppiPolicyCancellationCantRememberDate;
	}

	public String getPpiSummaryQuestionnaireDetails() {
		return ppiSummaryQuestionnaireDetails;
	}

	public void setPpiSummaryQuestionnaireDetails(String ppiSummaryQuestionnaireDetails) {
		this.ppiSummaryQuestionnaireDetails = ppiSummaryQuestionnaireDetails;
	}

	public String getPpiPolicyCancellationDate() {
		return ppiPolicyCancellationDate;
	}

	public void setPpiPolicyCancellationDate(String ppiPolicyCancellationDate) {
		this.ppiPolicyCancellationDate = ppiPolicyCancellationDate;
	}

	public String getPromisedCheaperRate() {
		return promisedCheaperRate;
	}

	public void setPromisedCheaperRate(String promisedCheaperRate) {
		this.promisedCheaperRate = promisedCheaperRate;
	}

	public String getFeltPressured() {
		return feltPressured;
	}

	public void setFeltPressured(String feltPressured) {
		this.feltPressured = feltPressured;
	}

	public String getComplaintDetails() {
		return complaintDetails;
	}

	public void setComplaintDetails(String complaintDetails) {
		this.complaintDetails = complaintDetails;
	}

	public String getEmploymentStatus() {
		return employmentStatus;
	}

	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}

	public String getEmploymentSector() {
		return employmentSector;
	}

	public void setEmploymentSector(String employmentSector) {
		this.employmentSector = employmentSector;
	}

	public String getEmploymentDateFrom() {
		return employmentDateFrom;
	}

	public void setEmploymentDateFrom(String employmentDateFrom) {
		this.employmentDateFrom = employmentDateFrom;
	}

	public String getEmploymentDateTo() {
		return employmentDateTo;
	}

	public void setEmploymentDateTo(String employmentDateTo) {
		this.employmentDateTo = employmentDateTo;
	}

	public String getEntitledToSickPay() {
		return entitledToSickPay;
	}

	public void setEntitledToSickPay(String entitledToSickPay) {
		this.entitledToSickPay = entitledToSickPay;
	}

	public String getTimeAtEmployer() {
		return timeAtEmployer;
	}

	public void setTimeAtEmployer(String timeAtEmployer) {
		this.timeAtEmployer = timeAtEmployer;
	}

	public String getAbleToMakeRepaymentsIfSick() {
		return ableToMakeRepaymentsIfSick;
	}

	public void setAbleToMakeRepaymentsIfSick(String ableToMakeRepaymentsIfSick) {
		this.ableToMakeRepaymentsIfSick = ableToMakeRepaymentsIfSick;
	}

	public String getHowAbleToMakeRepayments() {
		return howAbleToMakeRepayments;
	}

	public void setHowAbleToMakeRepayments(String howAbleToMakeRepayments) {
		this.howAbleToMakeRepayments = howAbleToMakeRepayments;
	}

	public String getAmountOfInsuranceAndSavings() {
		return amountOfInsuranceAndSavings;
	}

	public void setAmountOfInsuranceAndSavings(String amountOfInsuranceAndSavings) {
		this.amountOfInsuranceAndSavings = amountOfInsuranceAndSavings;
	}

	public String getAbleToMakeRepaymentsForPeriod() {
		return ableToMakeRepaymentsForPeriod;
	}

	public void setAbleToMakeRepaymentsForPeriod(String ableToMakeRepaymentsForPeriod) {
		this.ableToMakeRepaymentsForPeriod = ableToMakeRepaymentsForPeriod;
	}

	public String getAmountOfInsuranceAndSavingsDetail() {
		return amountOfInsuranceAndSavingsDetail;
	}

	public void setAmountOfInsuranceAndSavingsDetail(String amountOfInsuranceAndSavingsDetail) {
		this.amountOfInsuranceAndSavingsDetail = amountOfInsuranceAndSavingsDetail;
	}
}
