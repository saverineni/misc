package com.leadx.esignature;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Agreement {
	private int lenderId;
	private String lenderName;
	private String typeOfCredit;
	private String jointApplicantTitle;
	private String jointApplicantForename;
	private String jointApplicantMiddleName;
	private String jointApplicantSurname;
	private String jointApplicantPreviousSurname;
	private String jointApplicantDob;
	private String jointApplicantEmail;
	private String didYouTakeOutPpi;
	private String toldPpiAffectsEligibility;
	private String costsOfPpiExplained;

	public Agreement() {
	}

	public Agreement(int lenderId, String lenderName, String typeOfCredit, String jointApplicantTitle, String jointApplicantForename,
			String jointApplicantMiddleName, String jointApplicantSurname, String jointApplicantPreviousSurname, String jointApplicantDob,
			String jointApplicantEmail, String didYouTakeOutPpi, String toldPpiAffectsEligibility, String costsOfPpiExplained) {
		this.lenderId = lenderId;
		this.lenderName = lenderName;
		this.typeOfCredit = typeOfCredit;
		this.jointApplicantTitle = jointApplicantTitle;
		this.jointApplicantForename = jointApplicantForename;
		this.jointApplicantMiddleName = jointApplicantMiddleName;
		this.jointApplicantSurname = jointApplicantSurname;
		this.jointApplicantPreviousSurname = jointApplicantPreviousSurname;
		this.jointApplicantDob = jointApplicantDob;
		this.jointApplicantEmail = jointApplicantEmail;
		this.didYouTakeOutPpi = didYouTakeOutPpi;
		this.toldPpiAffectsEligibility = toldPpiAffectsEligibility;
		this.costsOfPpiExplained = costsOfPpiExplained;
	}

	public static class Builder{

		private int lenderId;
		private String lenderName;
		private String typeOfCredit;
		private String jointApplicantTitle;
		private String jointApplicantForename;
		private String jointApplicantMiddleName;
		private String jointApplicantSurname;
		private String jointApplicantPreviousSurname;
		private String jointApplicantDob;
		private String jointApplicantEmail;
		private String didYouTakeOutPpi;
		private String toldPpiAffectsEligibility;
		private String costsOfPpiExplained;

		public Builder setLenderId(int lenderId) {
			this.lenderId = lenderId;
			return this;
		}

		public Builder setLenderName(String lenderName) {
			this.lenderName = lenderName;
			return this;
		}

		public Builder setTypeOfCredit(String typeOfCredit) {
			this.typeOfCredit = typeOfCredit;
			return this;
		}

		public Builder setJointApplicantTitle(String jointApplicantTitle) {
			this.jointApplicantTitle = jointApplicantTitle;
			return this;
		}

		public Builder setJointApplicantForename(String jointApplicantForename) {
			this.jointApplicantForename = jointApplicantForename;
			return this;
		}

		public Builder setJointApplicantMiddleName(String jointApplicantMiddleName) {
			this.jointApplicantMiddleName = jointApplicantMiddleName;
			return this;
		}

		public Builder setJointApplicantSurname(String jointApplicantSurname) {
			this.jointApplicantSurname = jointApplicantSurname;
			return this;
		}

		public Builder setJointApplicantPreviousSurname(String jointApplicantPreviousSurname) {
			this.jointApplicantPreviousSurname = jointApplicantPreviousSurname;
			return this;
		}

		public Builder setJointApplicantDob(String jointApplicantDob) {
			this.jointApplicantDob = jointApplicantDob;
			return this;
		}

		public Builder setJointApplicantEmail(String jointApplicantEmail) {
			this.jointApplicantEmail = jointApplicantEmail;
			return this;
		}

		public Builder setDidYouTakeOutPpi(String didYouTakeOutPpi) {
			this.didYouTakeOutPpi = didYouTakeOutPpi;
			return this;
		}

		public Builder setToldPpiAffectsEligibility(String toldPpiAffectsEligibility) {
			this.toldPpiAffectsEligibility = toldPpiAffectsEligibility;
			return this;
		}

		public Builder setCostsOfPpiExplained(String costsOfPpiExplained) {
			this.costsOfPpiExplained = costsOfPpiExplained;
			return this;
		}

		public Agreement createAgreement() {
			return new Agreement(lenderId, lenderName, typeOfCredit, jointApplicantTitle, jointApplicantForename, jointApplicantMiddleName,
					jointApplicantSurname, jointApplicantPreviousSurname, jointApplicantDob, jointApplicantEmail, didYouTakeOutPpi, toldPpiAffectsEligibility,
					costsOfPpiExplained);
		}
	}

	public int getLenderId() {
		return lenderId;
	}

	public void setLenderId(int lenderId) {
		this.lenderId = lenderId;
	}

	public String getLenderName() {
		return lenderName;
	}

	public void setLenderName(String lenderName) {
		this.lenderName = lenderName;
	}

	public String getTypeOfCredit() {
		return typeOfCredit;
	}

	public void setTypeOfCredit(String typeOfCredit) {
		this.typeOfCredit = typeOfCredit;
	}

	public String getJointApplicantTitle() {
		return jointApplicantTitle;
	}

	public void setJointApplicantTitle(String jointApplicantTitle) {
		this.jointApplicantTitle = jointApplicantTitle;
	}

	public String getJointApplicantForename() {
		return jointApplicantForename;
	}

	public void setJointApplicantForename(String jointApplicantForename) {
		this.jointApplicantForename = jointApplicantForename;
	}

	public String getJointApplicantMiddleName() {
		return jointApplicantMiddleName;
	}

	public void setJointApplicantMiddleName(String jointApplicantMiddleName) {
		this.jointApplicantMiddleName = jointApplicantMiddleName;
	}

	public String getJointApplicantSurname() {
		return jointApplicantSurname;
	}

	public void setJointApplicantSurname(String jointApplicantSurname) {
		this.jointApplicantSurname = jointApplicantSurname;
	}

	public String getJointApplicantPreviousSurname() {
		return jointApplicantPreviousSurname;
	}

	public void setJointApplicantPreviousSurname(String jointApplicantPreviousSurname) {
		this.jointApplicantPreviousSurname = jointApplicantPreviousSurname;
	}

	public String getJointApplicantDob() {
		return jointApplicantDob;
	}

	public void setJointApplicantDob(String jointApplicantDob) {
		this.jointApplicantDob = jointApplicantDob;
	}

	public String getJointApplicantEmail() {
		return jointApplicantEmail;
	}

	public void setJointApplicantEmail(String jointApplicantEmail) {
		this.jointApplicantEmail = jointApplicantEmail;
	}

	public String getDidYouTakeOutPpi() {
		return didYouTakeOutPpi;
	}

	public void setDidYouTakeOutPpi(String didYouTakeOutPpi) {
		this.didYouTakeOutPpi = didYouTakeOutPpi;
	}

	public String getToldPpiAffectsEligibility() {
		return toldPpiAffectsEligibility;
	}

	public void setToldPpiAffectsEligibility(String toldPpiAffectsEligibility) {
		this.toldPpiAffectsEligibility = toldPpiAffectsEligibility;
	}

	public String getCostsOfPpiExplained() {
		return costsOfPpiExplained;
	}

	public void setCostsOfPpiExplained(String costsOfPpiExplained) {
		this.costsOfPpiExplained = costsOfPpiExplained;
	}
}
