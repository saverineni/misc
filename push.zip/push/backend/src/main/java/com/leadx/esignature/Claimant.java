package com.leadx.esignature;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Claimant {
	private String title;
	private String forename;
	private String middlename;
	private String surname;
	private String previousSurname;
	private String dob;
	private String homeTelephone;
	private String mobileTelephone;
	private String email;

	public Claimant() {
	}

	private Claimant(String title, String forename, String middlename, String surname, String previousSurname,
					 String dob, String homeTelephone, String mobileTelephone, String email) {
		this.title = title;
		this.forename = forename;
		this.middlename = middlename;
		this.surname = surname;
		this.previousSurname = previousSurname;
		this.dob = dob;
		this.homeTelephone = homeTelephone;
		this.mobileTelephone = mobileTelephone;
		this.email = email;
	}

	public static class Builder{
		private String title;
		private String forename;
		private String middlename;
		private String surname;
		private String previousSurname;
		private String dob;
		private String homeTelephone;
		private String mobileTelephone;
		private String email;

		public Builder setTitle(String title) {
			this.title = title;
			return this;
		}

		public Builder setForename(String forename) {
			this.forename = forename;
			return this;
		}

		public Builder setMiddlename(String middlename) {
			this.middlename = middlename;
			return this;
		}

		public Builder setSurname(String surname) {
			this.surname = surname;
			return this;
		}

		public Builder setPreviousSurname(String previousSurname) {
			this.previousSurname = previousSurname;
			return this;
		}

		public Builder setDob(String dob) {
			this.dob = dob;
			return this;
		}

		public Builder setHomeTelephone(String homeTelephone) {
			this.homeTelephone = homeTelephone;
			return this;
		}

		public Builder setMobileTelephone(String mobileTelephone) {
			this.mobileTelephone = mobileTelephone;
			return this;
		}

		public Builder setEmail(String email) {
			this.email = email;
			return this;
		}

		public Claimant createClaimant() {
			return new Claimant(title, forename, middlename, surname, previousSurname,
					dob, homeTelephone, mobileTelephone, email);
		}
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getForename() {
		return forename;
	}

	public void setForename(String forename) {
		this.forename = forename;
	}

	public String getMiddlename() {
		return middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getPreviousSurname() {
		return previousSurname;
	}

	public void setPreviousSurname(String previousSurname) {
		this.previousSurname = previousSurname;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getHomeTelephone() {
		return homeTelephone;
	}

	public void setHomeTelephone(String homeTelephone) {
		this.homeTelephone = homeTelephone;
	}

	public String getMobileTelephone() {
		return mobileTelephone;
	}

	public void setMobileTelephone(String mobileTelephone) {
		this.mobileTelephone = mobileTelephone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
