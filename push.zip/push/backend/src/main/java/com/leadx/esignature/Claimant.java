package com.leadx.esignature;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Claimant {
	private int id;
	private String title;
	private String forename;
	private String middlename;
	private String surname;
	private String previousSurname;
	private String dob;
	private String homeTelephone;
	private String mobileTelephone;
	private String email;
	private List<MedicalCondition> medicalConditions;

	public Claimant() {
	}

	public Claimant(int id, String title, String forename, String middlename, String surname, String previousSurname, String dob, String homeTelephone,
			String mobileTelephone, String email, List<MedicalCondition> medicalConditions) {
		this.id = id;
		this.title = title;
		this.forename = forename;
		this.middlename = middlename;
		this.surname = surname;
		this.previousSurname = previousSurname;
		this.dob = dob;
		this.homeTelephone = homeTelephone;
		this.mobileTelephone = mobileTelephone;
		this.email = email;
		this.medicalConditions = medicalConditions;
	}

	public static class Builder{

		private int id;
		private String title;
		private String forename;
		private String middlename;
		private String surname;
		private String previousSurname;
		private String dob;
		private String homeTelephone;
		private String mobileTelephone;
		private String email;
		private List<MedicalCondition> medicalConditions;

		public Builder setId(int id) {
			this.id = id;
			return this;
		}

		public Builder setTitle(String title) {
			this.title = title;
			return this;
		}

		public Builder setForename(String forename) {
			this.forename = forename;
			return this;
		}

		public Builder setMiddlename(String middlename) {
			this.middlename = middlename;
			return this;
		}

		public Builder setSurname(String surname) {
			this.surname = surname;
			return this;
		}

		public Builder setPreviousSurname(String previousSurname) {
			this.previousSurname = previousSurname;
			return this;
		}

		public Builder setDob(String dob) {
			this.dob = dob;
			return this;
		}

		public Builder setHomeTelephone(String homeTelephone) {
			this.homeTelephone = homeTelephone;
			return this;
		}

		public Builder setMobileTelephone(String mobileTelephone) {
			this.mobileTelephone = mobileTelephone;
			return this;
		}

		public Builder setEmail(String email) {
			this.email = email;
			return this;
		}

		public Builder setMedicalConditions(List<MedicalCondition> medicalConditions) {
			this.medicalConditions = medicalConditions;
			return this;
		}

		public Claimant createClaimant() {
			return new Claimant(id, title, forename, middlename, surname, previousSurname, dob, homeTelephone, mobileTelephone, email, medicalConditions);
		}
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getForename() {
		return forename;
	}

	public void setForename(String forename) {
		this.forename = forename;
	}

	public String getMiddlename() {
		return middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getPreviousSurname() {
		return previousSurname;
	}

	public void setPreviousSurname(String previousSurname) {
		this.previousSurname = previousSurname;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getHomeTelephone() {
		return homeTelephone;
	}

	public void setHomeTelephone(String homeTelephone) {
		this.homeTelephone = homeTelephone;
	}

	public String getMobileTelephone() {
		return mobileTelephone;
	}

	public void setMobileTelephone(String mobileTelephone) {
		this.mobileTelephone = mobileTelephone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<MedicalCondition> getMedicalConditions() {
		return medicalConditions;
	}

	public void setMedicalConditions(List<MedicalCondition> medicalConditions) {
		this.medicalConditions = medicalConditions;
	}

	public String getFullName() {
		return this.getForename() + this.getSurname();
	}
}
