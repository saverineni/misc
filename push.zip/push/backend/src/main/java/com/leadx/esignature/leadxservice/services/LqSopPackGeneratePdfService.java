package com.leadx.esignature.leadxservice.services;

import com.docusign.esign.client.ApiException;
import com.docusign.esign.model.Document;
import com.docusign.esign.model.SignHere;
import com.docusign.esign.model.Signer;
import com.docusign.esign.model.Tabs;
import com.google.common.collect.Lists;
import com.itextpdf.text.DocumentException;
import com.leadx.claimant.client.*;
import com.leadx.esignature.Agreement;
import com.leadx.esignature.ClaimRequest;
import com.leadx.esignature.MedicalCondition;
import com.leadx.esignature.docusignservice.commands.BaseGenerateUrlCommand;
import com.leadx.web.tcg.client.TcgClaimantServiceWrapper;
import com.leadx.web.tcg.client.claimservice.AgreementDto;
import com.leadx.web.tcg.client.claimservice.ClaimDto;
import com.leadx.web.tcg.client.claimservice.CreditAgreementAndClaimDto;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Maps.newHashMap;
import static com.leadx.esignature.Utils.*;
import static com.leadx.lib.utl.ListUtils.first;
import static java.util.Objects.isNull;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

@Component
public class LqSopPackGeneratePdfService extends BaseGenerateUrlCommand {

    @Autowired
    private ClaimantServiceWrapper claimantServiceWrapper;

    @Autowired
    private AddressServiceWrapper addressServiceWrapper;

    @Autowired
    private TcgClaimantServiceWrapper tcgClaimantServiceWrapper;

    public Document createDocument(final ClaimRequest claimRequest) throws IOException, DocumentException, ApiException {
        validate(claimRequest);

        final int claimantId = claimRequest.getClaimant().getId();
        final int claimId = first(claimRequest.getAgreements()).getClaimId();

        final ClaimantDto claimantDto = this.claimantServiceWrapper.getClaimantById(claimantId);
        final Optional<CreditAgreementAndClaimDto> creditAgreementAndClaimDto =
                this.tcgClaimantServiceWrapper.getCreditAgreementsAndClaimsForClaimant(claimantId)
                        .stream()
                        .filter(c -> c.getClaimDto().getClaimId() == claimId)
                        .findFirst();


        if (isNull(claimantDto) || !creditAgreementAndClaimDto.isPresent()) {
            throw new IllegalArgumentException("Unable to lookup claimant/claim details for claimant ID " + claimantId + " and claim ID " + claimId);
        }

        final ClaimDto claimDto = creditAgreementAndClaimDto.get().getClaimDto();

        if (claimantId != claimDto.getClaimantId()) {
            throw new IllegalArgumentException("Claimant/Claim ID mis-match, claim " + claimDto.getClaimId() + " actually exists for claimant " + claimDto.getClaimantId());
        }
        final AgreementDto agreementFromDb = creditAgreementAndClaimDto.get().getAgreementDto();
        final Map<String, Object> formData = populateFormData(claimRequest, claimantId, claimId, claimantDto, agreementFromDb);

        return getLqSop(formData);
    }

    private Map<String, Object> populateFormData(ClaimRequest claimRequest, int claimantId, int claimId, ClaimantDto claimantDto, AgreementDto agreementFromDb) {

        final String clientUserName = getClaimantName(claimantDto.getTitle(), claimantDto.getForename(), claimantDto.getSurname());

        final Map<String, Object> formData = newHashMap();
        formData.put("clientName", clientUserName);
        formData.put("lenderName", agreementFromDb.getLenderName());
        formData.put("agreementNumber", agreementFromDb.getAgreementNumber());
        formData.put("productType", StringUtils.capitalize(agreementFromDb.getType()));

        final String startDate = isNotBlank(agreementFromDb.getStartDateOfCard()) && "0000-00-00" != agreementFromDb.getStartDateOfCard() ?
                agreementFromDb.getStartDateOfCard() : agreementFromDb.getStartDateOfLoan();

        formData.put("startDate", isNotBlank(startDate) && !"0000-00-00".equals(startDate) ? startDate : "");

        formData.put("claimantId", claimantId);
        formData.put("claimId", claimId);
        formData.put("currentDate", new LocalDate().toString("dd/MMM/yyyy"));
        formData.put("claimant.previousName", claimantDto.getPreviousSurname());
        formData.put("claimant.dob", claimantDto.getDob());
        formData.put("claimant.email", claimantDto.getEmail());

        if (StringUtils.isNotEmpty(claimantDto.getMobileTelephone())) {
            formData.put("claimant.telephoneNumbers", claimantDto.getMobileTelephone());
        } else {
            formData.put("claimant.telephoneNumbers", claimantDto.getHomeTelephone());
        }

        appendSop(claimRequest, formData);
        appendPageTwo(claimRequest, formData);
        appendMedicalConditions(claimRequest, formData);
        appendAddressFields(claimantId, formData);
        appendPreviousAddressFields(claimantId, formData);
        return formData;
    }

    private void appendAddressFields(final int claimantId, final Map<String, Object> formData) {
        final AddressDto addressDto = this.addressServiceWrapper.getAddressForClaimant(claimantId);

        final LinkedList<String> addressElements = Lists.newLinkedList();

        appendIfNotBlank(addressElements, addressDto.getDepartmentName());
        appendIfNotBlank(addressElements, addressDto.getOrganisationName());
        appendIfNotBlank(addressElements, addressDto.getSubBuildingName(), addressDto.getBuildingName());

        if (isNotBlank(addressDto.getDependentThoroughfare())) {
            appendIfNotBlank(addressElements, addressDto.getBuildingNumber(), addressDto.getDependentThoroughfare());
            appendIfNotBlank(addressElements, addressDto.getThoroughfare());
        } else {
            appendIfNotBlank(addressElements, addressDto.getBuildingNumber(), addressDto.getThoroughfare());
        }

        appendIfNotBlank(addressElements, addressDto.getDoubleDependentLocality());
        appendIfNotBlank(addressElements, addressDto.getDependentLocality());
        appendIfNotBlank(addressElements, addressDto.getTown());

        final String address1 = addressElements.poll();
        final String address2 = addressElements.poll();
        final String address3 = addressElements.poll();
        final String address4 = addressElements.poll();
        final String address5 = addressElements.poll();
        final String address6 = addressElements.poll();

        formData.put("claimant.address.threeLineAddress.addressLine1".toString(), joinAddressElements(address1, address2));
        formData.put("claimant.address.threeLineAddress.addressLine2".toString(), joinAddressElements(address3, address4));
        formData.put("claimant.address.threeLineAddress.addressLine3".toString(), joinAddressElements(address5, address6));

        formData.put("claimant.address.postcode".toString(), addressDto.getPostcode());
    }

    private void appendPreviousAddressFields(final int claimantId, final Map<String, Object> formData) {
        final List<PreviousAddressDto> previousAddresses = this.addressServiceWrapper.getPreviousAddresses(claimantId);

        if (previousAddresses.isEmpty()) {
            return;
        }

        int counter = 1;

        for (final PreviousAddressDto previousAddressDto : previousAddresses) {
            final String oneLineAddress = createOneLineAddress(previousAddressDto);
            final String postcode = previousAddressDto.getAddress().getPostcode();

            formData.put("previousAddress" + counter + ".address.oneLineAddress", oneLineAddress);
            formData.put("previousAddress" + counter + ".address.postcode", postcode);
            counter++;
        }
    }

    private void appendSop(final ClaimRequest claimRequest, final Map<String, Object> formData) {
        final Agreement agreement = first(claimRequest.getAgreements());
        formData.put("agreement.ppiOnAgreement", agreement.getDidYouTakeOutPpi());
        formData.put("agreement.moreLikelyToBeAccepted", agreement.getToldPpiAffectsEligibility());
        formData.put("agreement.costsOfPpiExplainedOnAgreement", agreement.getCostsOfPpiExplained());
        formData.put("agreement.promisedCheaperRate", agreement.getPromisedCheaperRate());
        formData.put("agreement.feltPressured", agreement.getFeltPressured());
    }

    private void appendPageTwo(final ClaimRequest claimRequest, final Map<String, Object> formData) {
        final Agreement agreement = first(claimRequest.getAgreements());
        formData.put("agreement.complaintDetails", agreement.getComplaintDetails());
        formData.put("agreement.employmentStatusAtTimeOfAgreement", agreement.getEmploymentStatus());
        formData.put("agreement.employmentSectorAtTimeOfAgreement", agreement.getEmploymentSector());
        formData.put("agreement.employmentDateFrom", agreement.getEmploymentDateFrom());
        formData.put("agreement.employmentDateTo", agreement.getEmploymentDateTo());
        formData.put("agreement.entitledToSickPay", agreement.getEntitledToSickPay());
        formData.put("agreement.timeAtEmployer", agreement.getTimeAtEmployer());
        formData.put("agreement.ableToMakeRepaymentsIfSick", agreement.getAbleToMakeRepaymentsIfSick());
        formData.put("agreement.howAbleToMakeRepayments", agreement.getHowAbleToMakeRepayments());
        formData.put("agreement.ableToMakeRepaymentsForPeriod", agreement.getAbleToMakeRepaymentsForPeriod());
        formData.put("agreement.amountOfInsuranceAndSavings", agreement.getAmountOfInsuranceAndSavings());
        formData.put("agreement.amountOfInsuranceAndSavingsDetail", agreement.getAmountOfInsuranceAndSavingsDetail());
    }

    private void appendMedicalConditions(final ClaimRequest claimRequest, final Map<String, Object> formData) {
        final List<MedicalCondition> medicalConditions = claimRequest.getClaimant().getMedicalConditions();

        if (medicalConditions.isEmpty()) {
            return;
        }

        int counter = 1;

        for (final MedicalCondition medicalCondition : medicalConditions) {
            formData.put("claimant.medicalCondition" + counter + ".medicalCondition", medicalCondition.getMedicalCondition());
            formData.put("claimant.medicalCondition" + counter + ".yearOfDiagnosis", medicalCondition.getYearOfDiagnosis());
            formData.put("claimant.medicalCondition" + counter + ".lengthOfTimeOff", medicalCondition.getLengthOfTimeOff());

            counter++;
        }
    }

    private String createOneLineAddress(final PreviousAddressDto previousAddressDto) {
        final AddressDto addressDto = previousAddressDto.getAddress();

        final LinkedList<String> addressElements = Lists.newLinkedList();

        appendIfNotBlank(addressElements, addressDto.getDepartmentName());
        appendIfNotBlank(addressElements, addressDto.getOrganisationName());
        appendIfNotBlank(addressElements, addressDto.getSubBuildingName(), addressDto.getBuildingName());

        if (isNotBlank(addressDto.getDependentThoroughfare())) {
            appendIfNotBlank(addressElements, addressDto.getBuildingNumber(), addressDto.getDependentThoroughfare());
            appendIfNotBlank(addressElements, addressDto.getThoroughfare());
        } else {
            appendIfNotBlank(addressElements, addressDto.getBuildingNumber(), addressDto.getThoroughfare());
        }

        appendIfNotBlank(addressElements, addressDto.getDoubleDependentLocality());
        appendIfNotBlank(addressElements, addressDto.getDependentLocality());

        final String address1 = addressElements.poll();
        final String address2 = addressElements.poll();
        final String address3 = addressElements.poll();
        final String address4 = addressElements.poll();
        final String address5 = addressElements.poll();
        final String address6 = addressElements.poll();
        final String address7 = addressElements.poll();

        return joinAddressElements(address1, address2, address3, address4, address5, address6, address7);
    }

    private List<Signer> buildSigners(final String clientUserId, final String clientUserName, final String clientUserEmail, final String documentId) {
        final Signer signer = generateDefaultSigner(clientUserId, clientUserName, clientUserEmail);
        signer.setRecipientId("1");
        signer.setTabs(buildTabs(documentId));
        signer.setSigningGroupId("true");

        return newArrayList(signer);
    }

    private Tabs buildTabs(final String documentId) {
        final Tabs tabs = new Tabs();
        tabs.getSignHereTabs().add(addSignature(1, documentId));

        return tabs;
    }

    private static SignHere addSignature(final int pageNumber, final String documentId) {
        // Create a SignHere tab somewhere on the document for the signer to sign
        SignHere signHere = generateDefaultSignHere(pageNumber, documentId);
        signHere.setYPosition("715");
        signHere.setScaleValue("1.0");

        return signHere;
    }

    private Document getLqSop(final Map<String, Object> formData) throws IOException, DocumentException {
        final List<byte[]> lqSop = newArrayList();
        byte[] lqSop1Bytes = populateAcroformFields(utils.readClasspathFile("docs/lq_sop_pack/LQ_LOA_1.pdf"), formData, "1");
        byte[] lqSop2Bytes = populateAcroformFields(utils.readClasspathFile("docs/lq_sop_pack/LQ_LOA_2.pdf"), formData, "2");
        lqSop.add(lqSop1Bytes);
        lqSop.add(lqSop2Bytes);

        return generateDocument(lqSop, "LQ_SOP.pdf", "1");
    }

    private static void validate(final ClaimRequest claimRequest) {
        checkArgument(claimRequest.getClaimant() != null, "Claimant cannot be null");
        checkArgument(claimRequest.getClaimant().getId() != 0, "Claimant ID must be supplied cannot be null");
        checkArgument(claimRequest.getAgreements().size() > 0, "At least one agreement should exist");
        checkArgument(first(claimRequest.getAgreements()).getClaimId() != 0, "Claim ID must be supplied");
    }
}
