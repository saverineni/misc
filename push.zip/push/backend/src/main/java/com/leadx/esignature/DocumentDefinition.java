package com.leadx.esignature;

public enum DocumentDefinition {

	ONLINE_ASSESSMENT_PACK,
	TCGL_PACK,
	LQ_SOP_PACK
}
