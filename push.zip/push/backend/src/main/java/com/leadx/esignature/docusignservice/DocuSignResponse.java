package com.leadx.esignature.docusignservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.leadx.hibernate.domain.BaseIntegerDomain;

@Entity
@Table(name = "docusign_response")
public class DocuSignResponse extends BaseIntegerDomain {
	@Column(name = "FK_DocuSignRequestID")
	private int docuSignRequestId;

	@Column(name = "EnvelopeID")
	private String envelopeId;

	private String viewURL;

	public DocuSignResponse() {
	}

	private DocuSignResponse(int docuSignRequestId, String envelopeId, String viewURL) {
		this.docuSignRequestId = docuSignRequestId;
		this.envelopeId = envelopeId;
		this.viewURL = viewURL;
	}

	public static class Builder{

		private int docuSignRequestId;
		private String envelopeId;
		private String viewURL;

		public Builder setDocuSignRequestId(int docuSignRequestId) {
			this.docuSignRequestId = docuSignRequestId;
			return this;
		}

		public Builder setEnvelopeId(String envelopeId) {
			this.envelopeId = envelopeId;
			return this;
		}

		public Builder setViewURL(String viewURL) {
			this.viewURL = viewURL;
			return this;
		}

		public DocuSignResponse createDocuSignResponse() {
			return new DocuSignResponse(docuSignRequestId, envelopeId, viewURL);
		}
	}

	@Override
	public boolean equals(final Object obj) {
		return deepEquals(obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

	public int getDocuSignRequestId() {
		return docuSignRequestId;
	}

	public void setDocuSignRequestId(int docuSignRequestId) {
		this.docuSignRequestId = docuSignRequestId;
	}

	public String getEnvelopeId() {
		return envelopeId;
	}

	public void setEnvelopeId(String envelopeId) {
		this.envelopeId = envelopeId;
	}

	public String getViewURL() {
		return viewURL;
	}

	public void setViewURL(String viewURL) {
		this.viewURL = viewURL;
	}
}
