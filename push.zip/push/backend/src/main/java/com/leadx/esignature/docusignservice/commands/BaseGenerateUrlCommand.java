package com.leadx.esignature.docusignservice.commands;

import static com.google.common.collect.Lists.newArrayList;
import static com.leadx.esignature.Utils.mergeFiles;
import static com.migcomponents.migbase64.Base64.encodeToString;
import static java.util.Objects.nonNull;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.docusign.esign.api.EnvelopesApi;
import com.docusign.esign.client.ApiClient;
import com.docusign.esign.client.ApiException;
import com.docusign.esign.client.Configuration;
import com.docusign.esign.client.auth.OAuth;
import com.docusign.esign.model.*;
import com.itextpdf.text.DocumentException;
import com.leadx.esignature.Utils;
import com.leadx.esignature.docusignservice.DocuSignRepository;
import com.leadx.esignature.docusignservice.DocuSignRequest;
import com.leadx.esignature.docusignservice.DocuSignRequestFailure;
import com.leadx.esignature.docusignservice.LeadXEnvelopeDefinition;

public class BaseGenerateUrlCommand {

	private static final Logger LOG = LoggerFactory.getLogger(BaseGenerateUrlCommand.class);

	@Value("${esignature.server.docusign.basePath}")
	public String basePath;

	@Value("${esignature.server.docusign.userId}")
	public String userId;

	@Value("${esignature.server.docusign.clientId}")
	public String clientId;

	@Value("${esignature.server.docusign.privateKey}")
	public String privateKey;

	@Value("${esignature.server.docusign.returnUrl}")
	public String returnUrl;

	@Autowired
	public DocuSignRepository docuSignRepository;

	@Autowired
	public Utils utils;

	public RecipientViewRequest buildRecipientView(final String returnUrl, final String clientUserId, final String clientUserName,
			final String clientUserEmail){
		RecipientViewRequest recipientView = new RecipientViewRequest();
		recipientView.setReturnUrl(returnUrl);
		recipientView.setClientUserId(clientUserId);
		recipientView.setAuthenticationMethod("email");
		recipientView.setUserName(clientUserName);
		recipientView.setEmail(clientUserEmail);
		recipientView.setRecipientId("1");

		return recipientView;
	}

	public static Signer generateDefaultSigner(final String clientUserId, final String clientUserName, final String clientUserEmail) {
		final Signer signer = new Signer();
		signer.setClientUserId(clientUserId);
		signer.setEmail(clientUserEmail);
		signer.setName(clientUserName);
		signer.setRecipientId("1");

		return signer;
	}

	public static SignHere generateDefaultSignHere(final int pageNumber, final String documentId) {
		SignHere signHere = new SignHere();
		signHere.setDocumentId(documentId);
		signHere.setPageNumber(String.valueOf(pageNumber));
		signHere.setRecipientId("1");
		signHere.setXPosition("170");

		return signHere;
	}

	public Document generateDocument(final List<byte[]> documents, final String filename, final String documentId)  throws IOException, DocumentException {
		String mergedFilename = null;
		final byte[] mergedDoc;
		try{
			mergedFilename = mergeFiles(documents);
			mergedDoc = utils.readFile(mergedFilename);
		}finally {
			if(nonNull(mergedFilename)){
				FileUtils.deleteQuietly(new File(mergedFilename).getParentFile());
			}
		}

		final Document document = new Document();
		document.setDocumentBase64(encodeToString(mergedDoc, false));
		document.setDocumentId(documentId);
		document.setName(filename);

		return document;
	}

	public String getUrl(String clientUserId, String clientUserName, String clientUserEmail, DocuSignRequest docuSignRequest, LeadXEnvelopeDefinition envDef)
			throws IOException, ApiException {
		envDef.setDisableResponsiveDocument("false");

		// send the envelope (otherwise it will be "created" in the Draft folder)
		envDef.setStatus("sent");

		ApiClient apiClient = new ApiClient(basePath);
		final List<String> scopes = newArrayList(OAuth.Scope_SIGNATURE);
		String viewURL;
		try {
			// add header to track time
			apiClient.addDefaultHeader("X-DocuSign-TimeTrack", "ESignature");
			OAuth.OAuthToken oAuthToken = apiClient.requestJWTUserToken(clientId, userId, scopes, utils.readFile(privateKey), 3600);

			// now that the API client has an OAuth token, let's use it in all DocuSign APIs
			apiClient.setAccessToken(oAuthToken.getAccessToken(), oAuthToken.getExpiresIn());
			OAuth.UserInfo userInfo = apiClient.getUserInfo(oAuthToken.getAccessToken());

			// parse first account's basePath. This step is important since the base URL may change occasionally
			final String baseURI = userInfo.getAccounts().get(0).getBaseUri();
			apiClient.setBasePath(baseURI + "/restapi");

			docuSignRequest.setBaseURI(baseURI);
			docuSignRepository.saveRequest(docuSignRequest);

			Configuration.setDefaultApiClient(apiClient);
			String accountId = userInfo.getAccounts().get(0).getAccountId();

			EnvelopesApi envelopesApi = new EnvelopesApi();
			EnvelopeSummary envelopeSummary = envelopesApi.createEnvelope(accountId, envDef);
			LOG.debug("Create Envelope - Time track logs: " + apiClient.getResponseHeaders().get("X-DocuSign-TimeTrack"));

			ViewUrl docuSignURL = envelopesApi.createRecipientView(accountId, envelopeSummary.getEnvelopeId(), buildRecipientView(returnUrl, clientUserId,
					clientUserName, clientUserEmail));
			LOG.debug("Create Recipient View - Time track logs: " + apiClient.getResponseHeaders().get("X-DocuSign-TimeTrack"));

			viewURL = docuSignURL.getUrl();
			docuSignRepository.saveResponse(docuSignRequest.getId(), envelopeSummary.getEnvelopeId(), viewURL);
		} catch (ApiException exception) {
			docuSignRepository.saveRequestFailure(new DocuSignRequestFailure(docuSignRequest.getId(), exception.getMessage()));
			throw exception;
		}

		return viewURL;
	}

}
