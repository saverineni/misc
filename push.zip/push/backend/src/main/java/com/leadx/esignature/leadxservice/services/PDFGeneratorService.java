package com.leadx.esignature.leadxservice.services;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.leadx.esignature.leadxservice.FormData;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Base64;

@Service
public class PDFGeneratorService {

    @Autowired
    private UploadToAmazonS3Service uploadToAmazonS3Service;

    @Value("${esignature.pdfs.outputDirectory}")
    private File outputDirectory;

    @Value("${aws.s3.file.name}")
    private String fileName;

    public ByteArrayInputStream generatePDFStream(FormData formData) throws DocumentException, IOException {

        Rectangle pageSize = new Rectangle(500f, 600f);
        Document document = new Document(pageSize, 36f, 36f, 70f, 70f);
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        PdfWriter.getInstance(document, out);
        document.open();
        document.addTitle("My first PDF");

        Font f = new Font(Font.FontFamily.TIMES_ROMAN, 30.0f, Font.UNDERLINE, BaseColor.RED);
        Chunk header = new Chunk("Letter of Authority", f);
        document.add(header);

        document.add(Chunk.NEWLINE);

        document.add(new Paragraph("\nThis letter  of Authority (Authority) will be sent to your lender to inform them that you give" +
                "is recorded on www.gov.uk/moj/cmr."));

        PdfPTable table = new PdfPTable(2);
        table.setWidthPercentage(100);

        table.addCell("Personal Details");
        table.addCell("");
        table.addCell("first name");
        table.addCell(formData.getPersonalDetails().getFirstName());
        table.addCell("last name");
        table.addCell(formData.getPersonalDetails().getLastName());
        table.addCell("date of birth");
        table.addCell(formData.getPersonalDetails().getDateOfBirth());

        document.add(Chunk.NEWLINE);
        table.addCell("Address");
        table.addCell("");
        table.addCell("first line");
        table.addCell(formData.getAddressDetails().getFirstLine());
        table.addCell("city");
        table.addCell(formData.getAddressDetails().getCity());
        table.addCell("postcode");
        table.addCell(formData.getAddressDetails().getPostcode());

        document.add(Chunk.NEWLINE);
        table.addCell("Lender");
        table.addCell("");
        table.addCell("Bank");
        table.addCell(formData.getLenderDetails().getBank());

        document.add(Chunk.NEWLINE);
        table.addCell("Signature");

        Base64.Decoder decoder = Base64.getDecoder();
        byte[] decodedByte = decoder.decode(formData.getSignature().split(",")[1]);

        Image image = Image.getInstance(decodedByte);
        image.scaleAbsolute(500, 500);
        table.addCell(image);
        document.add(table);
        document.close();

        byte[] byteArray = out.toByteArray();
        File pdfFile = createPdfFile(byteArray);

        uploadToAmazonS3Service.upLoadFileS3(pdfFile);
        return new ByteArrayInputStream(byteArray);
    }

    private File createPdfFile(byte[] byteArray) {

        File pdfFile = new File(this.outputDirectory, this.fileName);
        try (ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArray)) {
            FileUtils.copyInputStreamToFile(byteArrayInputStream, pdfFile);
        } catch (IOException e) {
            throw new RuntimeException(String.format("Failed to created pdf file with name %s", this.fileName), e);
        }
        return pdfFile;
    }

}
