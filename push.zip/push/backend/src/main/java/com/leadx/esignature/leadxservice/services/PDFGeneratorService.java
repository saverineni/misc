package com.leadx.esignature.leadxservice.services;

import com.docusign.esign.client.ApiException;
import com.docusign.esign.model.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.leadx.esignature.ClaimRequest;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Base64;

import static com.migcomponents.migbase64.Base64.decode;

@Service
public class PDFGeneratorService {

    @Autowired
    private LqSopPackGeneratePdfService lqSopPackGeneratePdfService;

    @Autowired
    private UploadToAmazonS3Service uploadToAmazonS3Service;

    @Value("${esignature.pdfs.outputDirectory}")
    private File outputDirectory;

    @Value("${aws.s3.file.name}")
    private String fileName;

    public ByteArrayInputStream generatePDFStream(ClaimRequest claimRequest) throws DocumentException, IOException, ApiException {

        Document document = lqSopPackGeneratePdfService.createDocument(claimRequest);

        byte[] pdfByteArray = decode(document.getDocumentBase64());
        pdfByteArray = stampImageOnPdf(claimRequest, pdfByteArray);
        File pdfFile = createPdfFile(pdfByteArray);
        uploadToAmazonS3Service.upLoadFileS3(pdfFile);
        return new ByteArrayInputStream(pdfByteArray);
    }

    private byte[] stampImageOnPdf(ClaimRequest claimRequest, byte[] byteArray) throws DocumentException, IOException {
        final ByteArrayOutputStream output = new ByteArrayOutputStream();
        final PdfReader reader = new PdfReader(byteArray);
        final PdfStamper stamper = new PdfStamper(reader, output);


        PdfContentByte content = stamper.getOverContent(1);

        Base64.Decoder decoder = Base64.getDecoder();
        byte[] decodedByte = decoder.decode(claimRequest.getSignature().split(",")[1]);

        Image image = Image.getInstance(decodedByte);
        image.scaleAbsolute(50, 50);
        image.setAbsolutePosition(130, 90);
        content.addImage(image);
        stamper.close();
        return output.toByteArray();
    }

    private File createPdfFile(byte[] byteArray) {

        File pdfFile = new File(this.outputDirectory, this.fileName);
        try (ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArray)) {
            FileUtils.copyInputStreamToFile(byteArrayInputStream, pdfFile);
        } catch (IOException e) {
            throw new RuntimeException(String.format("Failed to created pdf file with name %s", this.fileName), e);
        }
        return pdfFile;
    }

}
