package com.leadx.esignature.docusignservice;

import static com.leadx.test.MockUtils.mockAndSetOn;
import static org.hamcrest.core.Is.is;
import static org.springframework.test.util.MatcherAssertionErrors.assertThat;

import java.io.IOException;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;

import com.docusign.esign.client.ApiException;
import com.itextpdf.text.DocumentException;
import com.leadx.esignature.ClaimRequest;
import com.leadx.esignature.TestUtils;

public class DocuSignControllerUnitTest {
	private DocuSignController docuSignController;
	private DocuSignService docuSignService;

	private final Mockery context = new Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
		}
	};

	@Before
	public void setUp() {
		this.docuSignController = new DocuSignController();
		this.docuSignService = mockAndSetOn(this.context, DocuSignService.class, this.docuSignController);
	}

	@Test
	public void createSigningURL() throws DocumentException, ApiException, IOException {
		final ClaimRequest claimRequest = TestUtils.createClaimRequest();
		final String testURL = "https://www.example.com/signHere";
		this.context.checking(new Expectations() {
			{
				oneOf(docuSignService).createSigningURL(claimRequest);
				will(returnValue(testURL));
			}
		});

		final String URL = this.docuSignController.createSigningURL(claimRequest);
		assertThat(URL, is(testURL));
	}

}
