package com.leadx.esignature.docusignservice;

import static org.hamcrest.core.Is.is;
import static org.springframework.test.util.MatcherAssertionErrors.assertThat;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.NoTestData;

@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class DocuSignRepositoryIntTest extends AbstractIntegrationTest{
	@Autowired
	private DocuSignRepository docuSignRepository;

	@Test
	@NoTestData
	public void saveDocuSignRequest(){
		final long leadId = 123456L;
		final int numberOfAgreements = 3;
		final String baseURI = "Some Base URI";

		final DocuSignRequest docuSignRequest = new DocuSignRequest.Builder()
				.setLeadId(leadId)
				.setBaseURI(baseURI)
				.setNumberOfAgreements(numberOfAgreements)
				.createDocuSignRequest();

		docuSignRepository.saveRequest(docuSignRequest);

		final DocuSignRequest docuSignRequestFromDB = (DocuSignRequest) docuSignRepository.getSession().get(DocuSignRequest.class, docuSignRequest.getId());
		assertThat(docuSignRequestFromDB.getLeadId(), is(leadId));
		assertThat(docuSignRequestFromDB.getNumberOfAgreements(), is(numberOfAgreements));
		assertThat(docuSignRequestFromDB.getBaseURI(), is(baseURI));
	}

	@Test
	@NoTestData
	public void saveDocuSignResponse(){
		final int docuSignRequestId = 11111;
		final String envelopeId = "Some envelope ID";
		final String viewURL = "Some View URL";

		final int docuSignResponseId = docuSignRepository.saveResponse(docuSignRequestId, envelopeId, viewURL);

		final DocuSignResponse docuSignResponse = (DocuSignResponse) docuSignRepository.getSession().get(DocuSignResponse.class, docuSignResponseId);
		assertThat(docuSignResponse.getDocuSignRequestId(), is(docuSignRequestId));
		assertThat(docuSignResponse.getEnvelopeId(), is(envelopeId));
		assertThat(docuSignResponse.getViewURL(), is(viewURL));
	}

	@Test
	@NoTestData
	public void saveDocuSignRequestFailure() {
		final int docuSignRequestId = 11111;
		final String error = "Some error message";

		final DocuSignRequestFailure docuSignRequestFailure = new DocuSignRequestFailure(docuSignRequestId, error);
		final int docuSignRequestFailureId = docuSignRepository.saveRequestFailure(docuSignRequestFailure);

		final DocuSignRequestFailure docuSignRequestFailureFromDB = (DocuSignRequestFailure) docuSignRepository.getSession().get(DocuSignRequestFailure.class, docuSignRequestFailureId);
		assertThat(docuSignRequestFailureFromDB.getDocuSignRequestId(), is(docuSignRequestId));
		assertThat(docuSignRequestFailureFromDB.getError(), is(error));
	}

	@Test
	@NoTestData
	public void saveDocuSignReminder(){
		final int docuSignRequestId = 11111;
		final String status = "SUCCESS";

		final int docuSignReminderId = docuSignRepository.saveReminder(docuSignRequestId, status);

		final DocuSignReminder docuSignReminder = (DocuSignReminder) docuSignRepository.getSession().get(DocuSignReminder.class, docuSignReminderId);
		assertThat(docuSignReminder.getDocuSignRequestId(), is(docuSignRequestId));
		assertThat(docuSignReminder.getStatus(), is(status));
	}
}
