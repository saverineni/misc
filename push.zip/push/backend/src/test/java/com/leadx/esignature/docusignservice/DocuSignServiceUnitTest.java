package com.leadx.esignature.docusignservice;

import java.util.Map;

import org.jmock.Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.google.common.collect.Maps;
import com.leadx.esignature.ClaimRequest;
import com.leadx.esignature.TestUtils;
import com.leadx.esignature.docusignservice.commands.GenerateUrlCommand;
import com.leadx.esignature.docusignservice.commands.OnlineAssessmentGenerateUrlCommand;
import com.leadx.esignature.docusignservice.commands.TcgLPackGenerateUrlCommand;

public class DocuSignServiceUnitTest {
	private DocuSignService docuSignService;

	private final Mockery context = new Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
		}
	};

	@Before
	public void setUp() {
		this.docuSignService = new DocuSignService();

		final Map<String, GenerateUrlCommand> documentDefinitionMap = Maps.newHashMap();
		documentDefinitionMap.put("ONLINE_ASSESSMENT_PACK", new OnlineAssessmentGenerateUrlCommand());
		documentDefinitionMap.put("TCGL_PACK", new TcgLPackGenerateUrlCommand());

		ReflectionTestUtils.setField(this.docuSignService, "documentDefinitionCommands", documentDefinitionMap);
	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldFailGracefullyWhenUnknownDocumentDefinitionProvided() {
		final ClaimRequest claimRequest = TestUtils.createClaimRequest("some_random_definition");
		this.docuSignService.createSigningURL(claimRequest);
	}

	@Test
	public void shouldExecuteWhenOnlineAssessment() {
		final ClaimRequest claimRequest = TestUtils.createClaimRequest("ONLINE_ASSESSMENT_PACK");
		this.docuSignService.createSigningURL(claimRequest);
	}

	@Test
	public void shouldExecuteWhenTCGLPack() {
		final ClaimRequest claimRequest = TestUtils.createClaimRequest("TCGL_PACK");
		this.docuSignService.createSigningURL(claimRequest);
	}
}
