import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import {HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest} from '@angular/common/http';
import {Observable, throwError} from 'rxjs';
import {catchError, timeout} from 'rxjs/operators';
import {OperationErrorNotifier} from "./operation-error-notifier";

@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {

  constructor(private router: Router,
              private operationErrorNotifier: OperationErrorNotifier) {
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(
      timeout(5000),
      catchError(err => {
        if (err instanceof HttpErrorResponse) { // server down or any server error
          this.operationErrorNotifier.notifyUser('Server error');
        } else {  // server processing time out
          this.router.navigate(['server-error']);
        }
        return throwError(err);
      })
    );
  }
}
