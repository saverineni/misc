import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'sign-not-found',
  templateUrl: './not-found.component.html',
  styleUrls: ['./not-found.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NotFoundComponent {

}
