import {ModuleWithProviders, NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {HTTP_INTERCEPTORS} from '@angular/common/http';
import {MatButtonModule, MatSnackBarModule} from '@angular/material';
import {HttpErrorInterceptor} from './http-error-interceptor';
import {NotFoundComponent} from './not-found/not-found.component';
import {ServerErrorComponent} from './server-error/server-error.component';
import {OperationErrorNotifier} from "./operation-error-notifier";

@NgModule({
  imports: [
    CommonModule,
    MatButtonModule,
    MatSnackBarModule
  ],
  providers: [],
  declarations: [NotFoundComponent, ServerErrorComponent]
})
export class ErrorHandlingModule {

  static forRoot(): ModuleWithProviders {
    return {
      ngModule: ErrorHandlingModule,
      providers: [
        {provide: HTTP_INTERCEPTORS, useClass: HttpErrorInterceptor, multi: true},
        OperationErrorNotifier
      ]
    };
  }
}
