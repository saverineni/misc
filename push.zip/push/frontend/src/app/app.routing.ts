import {RouterModule} from '@angular/router';
import {SignaturePadComponent} from './signature-pad/signature-pad.component';
import {ServerErrorComponent} from "./error-handling/server-error/server-error.component";
import {NotFoundComponent} from "./error-handling/not-found/not-found.component";


export const routing = RouterModule.forRoot([
  {
    path: 'signature',
    component: SignaturePadComponent
  },

  {
    path: '',
    redirectTo: '/signature',
    pathMatch: 'full'
  },

  {
    path: 'server-error',
    component: ServerErrorComponent
  },

  {
    path: "**",
    component: NotFoundComponent
  }

]);
