package uk.gov.gsi.hmrc.cds.search.api.dto;

import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.util.Collections;
import java.util.Optional;

import org.hamcrest.Matchers;
import org.junit.Test;

public class SearchCriteriaTest {

    SearchCriteria criteria = new SearchCriteria();

    @Test
    public void optionalSearchTermShouldGiveNoneWhenSearchTermEmpty() {
        criteria.setSearchTerm(" ");
        assertThat(criteria.optionalSearchTerm(), is(Optional.empty()));
    }

    @Test
    public void optionalSearchTermShouldGiveSomeSearchTermWhenPresent() {
        criteria.setSearchTerm("a-term");
        assertThat(criteria.optionalSearchTerm(), is(Optional.of("a-term")));
    }

    @Test
    public void optionalSearchTermShouldGiveNoneWhenSearchTermNull() {
        assertThat(criteria.optionalSearchTerm(), is(Optional.empty()));
    }

    @Test
    public void optionalSearchTermShouldGiveSomeTrimmedSearchTermWhenPresent() {
        criteria.setSearchTerm("  a-term  ");
        assertThat(criteria.optionalSearchTerm(), is(Optional.of("a-term")));
    }

    @Test
    public void getOriginCountryCodeShouldGiveEmptyListIfNull() {
        criteria.setOriginCountryCode(null);
        assertThat(criteria.getOriginCountryCode(), is(empty()));
    }

    @Test
    public void getOriginCountryCodeShouldGiveListOfOneEmptyStringIfEmpty() {
        criteria.setOriginCountryCode(emptyList());
        assertThat(criteria.getOriginCountryCode(), contains(""));
    }

    @Test
    public void getOriginCountryCodeShouldGiveFieldIfNotEmpty() {
        criteria.setOriginCountryCode(singletonList("code"));
        assertThat(criteria.getOriginCountryCode(), contains("code"));
    }
}
