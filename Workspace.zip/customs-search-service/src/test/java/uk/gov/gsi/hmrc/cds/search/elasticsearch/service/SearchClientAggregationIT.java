package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.Declaration;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.connection.ESConnection;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.elasticsearch.common.xcontent.XContentType.JSON;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;
import static uk.gov.gsi.hmrc.cds.search.elasticsearch.service.TermsBucketMatchers.termsBucket;

public class SearchClientAggregationIT extends CustomsSearchESIntegTestCase {

    private static final String CUSTOMS_INDEX = "SearchServiceAggregationIntegrationTest".toLowerCase();
    public static final String GB_UNITED_KINGDOM = "GB - United Kingdom";
    public static final String FR_FRANCE = "FR - France";

    private SearchClient service;

    private ObjectMapper objectMapper = new ObjectMapper();

    public class CountryMixIn {
        @JsonIgnore(false)
        private String description;
    }

    @Before
    public void setUp() throws Exception {
        super.setUp();
        objectMapper.addMixIn(Country.class, CountryMixIn.class);
        this.service = new SearchClient(new ESConnection(ES_HOST, ES_PORT), CUSTOMS_INDEX);
        createCustomsIndexWithDocuments();
    }

    @Test
    public void matchAllReturnsAllOriginCountries() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria(""));

        Terms termsAggregation = searchResponse.getAggregations().get("originCountry");
        assertThat(termsAggregation.getBuckets(), containsInAnyOrder(
            termsBucket(GB_UNITED_KINGDOM, 3),
            termsBucket(FR_FRANCE, 2),
            termsBucket("", 1)));
    }

    @Test
    public void matchOneReturnsOnlyMatchingOriginCountries() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("dec-id-1"));

        Terms termsAggregation = searchResponse.getAggregations().get("originCountry");
        assertThat(termsAggregation.getBuckets(), contains(termsBucket(GB_UNITED_KINGDOM, 1)));
    }

    @Test
    public void matchNoneReturnsNoMatchingOriginCountries() {
        SearchResponse searchResponse = this.service.declarationSearch(newSearchCriteria("dec-id-no-match"));

        Terms termsAggregation = searchResponse.getAggregations().get("originCountry");
        assertThat(termsAggregation.getBuckets(), hasSize(0));
    }

    private SearchCriteria newSearchCriteria(String searchTerm) {
        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setSearchTerm(searchTerm);
        return searchCriteria;
    }

    private void createCustomsIndexWithDocuments() throws Exception {
        createIndex(CUSTOMS_INDEX);

        BulkRequest request = new BulkRequest();
        addDeclaration(request, newDeclaration("dec-id-1", GB_UNITED_KINGDOM));
        addDeclaration(request, newDeclaration("dec-id-2", GB_UNITED_KINGDOM));
        addDeclaration(request, newDeclaration("dec-id-3", GB_UNITED_KINGDOM, FR_FRANCE));
        addDeclaration(request, newDeclaration("dec-id-4", FR_FRANCE));
        addDeclaration(request, newDeclaration("dec-id-5", ""));
        addDeclaration(request, newDeclaration("dec-id-6"));

        client.bulk(request);

        refresh(CUSTOMS_INDEX);
    }

    private void addDeclaration(BulkRequest request, Declaration declaration) throws JsonProcessingException {
        request.add(new IndexRequest(CUSTOMS_INDEX, DECLARATION_TYPE, declaration.getDeclarationId())
                .source(objectMapper.writer().writeValueAsString(declaration), JSON));
    }

    private Declaration newDeclaration(String id, String ... originCountryDescription) {
        return Declaration.builder()
                .declarationId(id)
                .lines(
                        Stream.of(originCountryDescription)
                            .map(d -> DeclarationLine.builder()
                                .originCountry(Country.builder()
                                        .description(d)
                                        .build())
                                    .build())
                            .collect(Collectors.toList()))
                .build();
    }

}
