package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.CountryFacet;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.Facets;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.AggregationsToFacetsConverter;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.BucketToCountryFacetConverter;

import java.util.List;

import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AggregationsToFacetsConverterTest {

    @Mock
    private BucketToCountryFacetConverter countryFacetConverter;

    private AggregationsToFacetsConverter converter;

    private Aggregations aggregations;

    @Mock
    private Terms terms;

    @Before
    public void setUp() {
        when(terms.getName()).thenReturn("originCountry");

        aggregations = new Aggregations(asList(terms));
        converter = new AggregationsToFacetsConverter(countryFacetConverter);
    }

    @Test
    public void convertOne() {
        Terms.Bucket bucket = givenBucket();
        givenBuckets(bucket);
        CountryFacet expected = givenCanConvertBucket(bucket);
        Facets actual = converter.convert(aggregations);
        assertThat(actual.getOriginCountries(), contains(expected));
    }

    @Test
    public void convertMany() {
        Terms.Bucket bucket1 = givenBucket();
        Terms.Bucket bucket2 = givenBucket();

        givenBuckets(bucket1, bucket2);

        CountryFacet expected1 = givenCanConvertBucket(bucket1);
        CountryFacet expected2 = givenCanConvertBucket(bucket2);

        Facets actual = converter.convert(aggregations);
        assertThat(actual.getOriginCountries(), contains(expected1, expected2));
    }

    @Test
    public void convertsEmptyBuckets() {
        givenBuckets();
        Facets actual = converter.convert(aggregations);
        assertThat(actual.getOriginCountries(), is(empty()));
    }

    private Terms.Bucket givenBucket() {
        return mock(Terms.Bucket.class);
    }

    private void givenBuckets(Terms.Bucket... buckets) {
        @SuppressWarnings("unchecked")
        List bucketList = asList(buckets);
        when(terms.getBuckets()).thenReturn(bucketList);
    }

    private CountryFacet givenCanConvertBucket(Terms.Bucket bucket) {
        CountryFacet countryFacet = CountryFacet.builder().build();
        when(countryFacetConverter.convert(bucket)).thenReturn(countryFacet);
        return countryFacet;
    }

}