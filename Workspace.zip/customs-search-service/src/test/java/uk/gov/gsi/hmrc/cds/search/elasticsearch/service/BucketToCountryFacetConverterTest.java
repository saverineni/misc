package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.CountryFacet;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.BucketToCountryFacetConverter;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class BucketToCountryFacetConverterTest {

    @Mock
    private Terms.Bucket bucket;

    private BucketToCountryFacetConverter converter = new BucketToCountryFacetConverter();

    @Before
    public void setUp() {
        when(bucket.getKeyAsString()).thenReturn("GB - United Kingdom");
        when(bucket.getDocCount()).thenReturn(3L);
    }

    @Test
    public void convertsCountryCode() {
        CountryFacet actual = converter.convert(bucket);
        assertThat(actual.getCountry().getCode(), is("GB"));
    }

    @Test
    public void convertsCountryName() {
        CountryFacet actual = converter.convert(bucket);
        assertThat(actual.getCountry().getName(), is("United Kingdom"));
    }

    @Test
    public void convertsCount() {
        CountryFacet actual = converter.convert(bucket);
        assertThat(actual.getCount(), is(3L));
    }

    @Test
    public void convertsBlankCountry() {
        when(bucket.getKeyAsString()).thenReturn("");
        CountryFacet actual = converter.convert(bucket);
        assertThat(actual.getCountry().getCode(), is(""));
        assertThat(actual.getCountry().getName(), is(""));
    }

    @Test
    public void handlesMultipleHyphensInDescription() {
        when(bucket.getKeyAsString()).thenReturn("TC - Test - Country");
        CountryFacet actual = converter.convert(bucket);
        assertThat(actual.getCountry().getCode(), is("TC"));
        assertThat(actual.getCountry().getName(), is("Test - Country"));
    }

    @Test
    public void handlesNoNameInDescription() {
        when(bucket.getKeyAsString()).thenReturn("TC");
        CountryFacet actual = converter.convert(bucket);
        assertThat(actual.getCountry().getCode(), is("TC"));
        assertThat(actual.getCountry().getName(), is(""));
    }

    @Test
    public void handlesNoNameWithHyphenInDescription() {
        when(bucket.getKeyAsString()).thenReturn("TC - ");
        CountryFacet actual = converter.convert(bucket);
        assertThat(actual.getCountry().getCode(), is("TC"));
        assertThat(actual.getCountry().getName(), is(""));
    }

}