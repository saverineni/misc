package uk.gov.gsi.hmrc.cds.search.security.jwt;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.security.core.Authentication;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.Matchers.empty;
import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class JwtAuthenticationProviderTest {

    private static final String PRINCIPAL = "1234";
    private JwtTokenService jwtTokenService = Mockito.mock(JwtTokenService.class);
    private Authentication authentication = mock(Authentication.class);
    private final JwtAuthenticationProvider authenticationProvider = new JwtAuthenticationProvider(jwtTokenService);

    @Test
    public void shouldSupportAuthenticationForJwtAuthenticationToken() {
        assertTrue(authenticationProvider.supports(JwtAuthenticationToken.class));
    }

    @Test
    public void authenticateSuccess()  {
        when(jwtTokenService.verifyToken(authentication)).thenReturn(PRINCIPAL);
        Authentication authenticate = authenticationProvider.authenticate(authentication);
        assertThat(authenticate , instanceOf(JwtAuthenticationToken.class));
        assertTrue(authenticate.isAuthenticated());
        assertThat(authenticate.getPrincipal(), is(equalTo(PRINCIPAL)));
        assertNull(authenticate.getCredentials());
        assertThat(authenticate.getAuthorities(),is(empty()));
    }

}