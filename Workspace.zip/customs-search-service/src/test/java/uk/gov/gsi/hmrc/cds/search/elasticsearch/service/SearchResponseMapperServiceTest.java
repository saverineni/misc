package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.Aggregations;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.convert.ConversionService;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.DeclarationSearchResult;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.Facets;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.SearchResponseMapperService;

import static java.util.Collections.emptyList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SearchResponseMapperServiceTest {

    private SearchResponseMapperService mapper;

    @Mock
    private ConversionService conversionService;

    @Mock
    private SearchResponse searchResponse;

    @Before
    public void setUp() {
        mapper = new SearchResponseMapperService(conversionService);
    }

    @Test
    public void mapsAggregationsToFacets() {
        Aggregations aggregations = new Aggregations(emptyList());
        when(searchResponse.getAggregations()).thenReturn(aggregations);
        when(searchResponse.getHits()).thenReturn(new SearchHits(new SearchHit[0], 0l, 0.0f));
        Facets expected = Facets.builder().build();
        when(conversionService.convert(aggregations, Facets.class)).thenReturn(expected);

        DeclarationSearchResult actual = mapper.mapResponse(searchResponse);
        assertThat(actual.getFacets(), is(expected));
    }
}