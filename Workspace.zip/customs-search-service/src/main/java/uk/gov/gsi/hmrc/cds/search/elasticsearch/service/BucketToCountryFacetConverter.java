package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.Country;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.CountryFacet;

@Component
public class BucketToCountryFacetConverter implements Converter<Terms.Bucket, CountryFacet> {

    @Override
    public CountryFacet convert(Terms.Bucket bucket) {
        return CountryFacet.builder()
            .country(fromDescription(bucket.getKeyAsString()))
            .count(bucket.getDocCount())
            .build();
    }

    private Country fromDescription(String description) {
        String[] descriptionParts = description.split(" - ", 2);
        return Country.builder()
                .code(descriptionParts[0])
                .name(descriptionParts.length > 1 ? descriptionParts[1] : "")
                .build();
    }
}
