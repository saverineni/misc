package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import static org.elasticsearch.index.query.QueryBuilders.multiMatchQuery;
import static org.elasticsearch.search.aggregations.AggregationBuilders.terms;

import java.io.IOException;
import java.util.stream.Collectors;

import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import uk.gov.gsi.hmrc.cds.search.api.dto.SearchCriteria;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.connection.ESConnection;

@Slf4j
@Service
public class SearchClient {

    private static final String[] SEARCH_FIELDS = {
            "declarationId",
            "epuNumber",
            "entryNumber",
            "consigneeTurn",
            "consigneeName",
            "consigneePostcode",
            "consignorTurn",
            "consignorName",
            "consignorPostcode",
            "lines.commodityCode",
            "lines.originCountry.code",
            "lines.cpc",
            "lines.itemConsigneeTurn",
            "lines.itemConsigneeName",
            "lines.itemConsigneePostcode",
            "lines.itemConsignorTurn",
            "lines.itemConsignorName",
            "lines.itemConsignorPostcode",
    };

    /**
     * This is necessary to ensure we retrieve all countries from the aggregation, if the total number of possible
     * countries exceeds this number there will be some entries missing from the resulting aggregation.
     */
    private static final int COUNTRY_CARDINALITY = 400;

    private final ESConnection connection;

    private final String searchAlias;

    public SearchClient(ESConnection connection,
                        @Value("${elasticsearch.alias}") String searchAlias) {
        this.connection = connection;
        this.searchAlias = searchAlias;
    }

    public SearchResponse declarationSearch(SearchCriteria searchCriteria) {
        return searchES(getSearchTermQueryBuilder(searchCriteria));
    }

    private QueryBuilder getSearchTermQueryBuilder(SearchCriteria searchCriteria) {
        BoolQueryBuilder query = QueryBuilders.boolQuery().must(QueryBuilders.matchAllQuery());
        BoolQueryBuilder queryWithSearchTerm = searchCriteria.optionalSearchTerm()
                .map(it -> query.must(multiMatchQuery(it, SEARCH_FIELDS)))
                .orElse(query);

        return searchCriteria.getOriginCountryCode().stream().map(countryCode ->
                queryWithSearchTerm.must(QueryBuilders.termQuery("lines.originCountry.code", countryCode))
        ).reduce((first, second) -> second).orElse(queryWithSearchTerm);
    }

    private SearchResponse searchES(QueryBuilder queryBuilder) {
        try (RestHighLevelClient client = connection.getRestClientInstance()) {

            SearchRequest searchRequest = new SearchRequest(searchAlias);
            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(queryBuilder);
            searchSourceBuilder.aggregation(
                    terms("originCountry").field("lines.originCountry.description").size(COUNTRY_CARDINALITY)
            );
            searchRequest.source(searchSourceBuilder);
            return client.search(searchRequest);
        } catch (IOException e) {
            log.error(String.format("Exception occurred: %s", e));
            throw new RuntimeException(e.getMessage());
        }
    }
}
