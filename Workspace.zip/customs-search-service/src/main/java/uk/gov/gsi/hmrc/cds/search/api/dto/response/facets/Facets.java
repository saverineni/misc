package uk.gov.gsi.hmrc.cds.search.api.dto.response.facets;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class Facets {
    private List<CountryFacet> originCountries;
}
