package uk.gov.gsi.hmrc.cds.search.api.dto;

import lombok.Data;

import java.util.List;
import java.util.Optional;

import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;

@Data
public class SearchCriteria {
    private String searchTerm;
    private List<String> originCountryCode;

    public Optional<String> optionalSearchTerm() {
        return Optional.ofNullable(searchTerm)
                .map(String::trim)
                .filter(t -> !t.isEmpty());
    }

    public List<String> getOriginCountryCode() {
        if (originCountryCode == null) {
            return emptyList();
        }
        if (originCountryCode.isEmpty()) {
            // Spring converts a single empty string parameter to an empty list
            // - there is no easy hook to override this default behaviour
            return singletonList("");
        }
        return originCountryCode;
    }
}
