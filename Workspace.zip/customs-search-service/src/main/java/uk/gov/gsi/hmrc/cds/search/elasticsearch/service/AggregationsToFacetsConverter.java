package uk.gov.gsi.hmrc.cds.search.elasticsearch.service;

import lombok.RequiredArgsConstructor;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.CountryFacet;
import uk.gov.gsi.hmrc.cds.search.api.dto.response.facets.Facets;

import java.util.List;

import static java.util.stream.Collectors.toList;

@Component
@RequiredArgsConstructor
public class AggregationsToFacetsConverter implements Converter<Aggregations, Facets> {

    private final BucketToCountryFacetConverter converter;

    @Override
    public Facets convert(Aggregations aggregations) {
        Terms termsAggregation = aggregations.get("originCountry");

        List<CountryFacet> countryFacets = termsAggregation.getBuckets().stream()
                .map(converter::convert)
                .collect(toList());

        return Facets.builder().originCountries(countryFacets).build();
    }
}
