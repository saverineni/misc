SELECT
    importItemSelect.IEKEY as declarationId,
    importItemSelect.IEITNO as itemNumber,
    importItemSelect.ITEMDISPCNTRY as dispatchCountryCode,
    CAST(NULL AS STRING) as destinationCountryCode,
    importItemSelect.STANDARD_CLRNCDATE as clearanceDate,
    importItemSelect.CPC as cpc,
    IF (importItemSelect.ORIGCNTRY IS NOT NULL,
        named_struct(
            "code", importItemSelect.ORIGCNTRY,
            "name", country.CNTRYNM,
            "description", CONCAT(importItemSelect.ORIGCNTRY, " - ", country.CNTRYNM)
        ),
        named_struct("code", '', "name", '', "description", '')
    ) as originCountry,
    importItemSelect.CMDTYCODE as commodityCode,
    importItemSelect.ITEMIMPTRTURN as itemConsigneeTurn,
    importItemSelect.ITEMCNSGRTURN as itemConsignorTurn,
    iica.ROE as itemRoute,
    iinaConsignee.ITEMNADNAME as itemConsigneeName,
    iinaConsignee.ITEMNADPOSTCODE as itemConsigneePostcode,
    iinaConsignor.ITEMNADNAME as itemConsignorName,
    iinaConsignor.ITEMNADPOSTCODE as itemConsignorPostcode
  FROM DATABASE_NAME.IMEISELECT importItemSelect
  JOIN DATABASE_NAME.IMENSELECT importSelect on importSelect.IEKEY = importItemSelect.IEKEY
  LEFT OUTER JOIN DATABASE_NAME.IINA iinaConsignor
      on importItemSelect.IEKEY = iinaConsignor.IEKEY
      and importItemSelect.IEITNO = iinaConsignor.IEITNO
      and iinaConsignor.ITEMNADTYPE = '1'
  LEFT OUTER JOIN DATABASE_NAME.IINA iinaConsignee
      on importItemSelect.IEKEY = iinaConsignee.IEKEY
      and importItemSelect.IEITNO = iinaConsignee.IEITNO
      and iinaConsignee.ITEMNADTYPE = '2'
  LEFT OUTER JOIN DATABASE_NAME.IICA iica
      on importItemSelect.IEKEY = iica.IEKEY
      and importItemSelect.IEITNO = iica.IEITNO
  LEFT OUTER JOIN DATABASE_NAME.CTRY country
      on importItemSelect.ORIGCNTRY = country.CNTRYCODE
UNION ALL
SELECT
  declarationId,
  itemNumber,
  dispatchCountryCode,
  destinationCountryCode,
  clearanceDate,
  cpc,
  originCountry,
  commodityCode,
  itemConsigneeTurn,
  itemConsignorTurn,
  itemRoute,
  itemConsigneeName,
  itemConsigneePostcode,
  itemConsignorName,
  itemConsignorPostcode
FROM (
  SELECT
    exportItemSelect.IEKEY as declarationId,
    exportItemSelect.IEITNO as itemNumber,
    exportItemDetail.ITEMDISPCNTRY as dispatchCountryCode,
    exportItemSelect.ITEMDESTCNTRY as destinationCountryCode,
    exportSelect.STANDARD_CLRNCDATE as clearanceDate,
    exportItemSelect.CPC as cpc,
    IF (exportItemSelect.ORIGCNTRY IS NOT NULL,
            named_struct(
                "code", exportItemSelect.ORIGCNTRY,
                "name", country.CNTRYNM,
                "description", CONCAT(exportItemSelect.ORIGCNTRY, " - ", country.CNTRYNM)
            ),
            named_struct("code", '', "name", '', "description", '')
    ) as originCountry,
    exportItemSelect.CMDTYCODE as commodityCode,
    exportItemSelect.ITEMIMPTRTURN as itemConsigneeTurn,
    exportItemSelect.ITEMCNSGRTURN as itemConsignorTurn,
    nxica.ROE as itemRoute,
    nxinaConsignee.ITEMNADNAME as itemConsigneeName,
    nxinaConsignee.ITEMNADPOSTCODE as itemConsigneePostcode,
    nxinaConsignor.ITEMNADNAME as itemConsignorName,
    nxinaConsignor.ITEMNADPOSTCODE as itemConsignorPostcode,
    ROW_NUMBER() OVER (partition by exportItemSelect.IEKEY, exportItemSelect.IEITNO order by exportItemSelect.STANDARD_DTOFENT) rownum
  FROM DATABASE_NAME.NXEISELECT exportItemSelect
  JOIN DATABASE_NAME.NXEIDETAIL exportItemDetail
      on exportItemDetail.IEKEY = exportItemSelect.IEKEY
      and exportItemDetail.IEITNO = exportItemSelect.IEITNO
      and exportItemDetail.GENERATIONNO = exportItemSelect.GENERATIONNO
  JOIN DATABASE_NAME.NXENSELECT exportSelect on exportSelect.IEKEY = exportItemSelect.IEKEY
  LEFT OUTER JOIN DATABASE_NAME.NXINA nxinaConsignor
      on exportItemSelect.IEKEY = nxinaConsignor.IEKEY
      and exportItemSelect.IEITNO = nxinaConsignor.IEITNO
      and nxinaConsignor.ITEMNADTYPE = '1'
  LEFT OUTER JOIN DATABASE_NAME.NXINA nxinaConsignee
      on exportItemSelect.IEKEY = nxinaConsignee.IEKEY
      and exportItemSelect.IEITNO = nxinaConsignee.IEITNO
      and nxinaConsignee.ITEMNADTYPE = '2'
  LEFT OUTER JOIN DATABASE_NAME.NXICA nxica
      on exportItemSelect.IEKEY = nxica.IEKEY
      and exportItemSelect.IEITNO = nxica.IEITNO
  LEFT OUTER JOIN DATABASE_NAME.CTRY country
      on exportItemSelect.ORIGCNTRY = country.CNTRYCODE

) innerQuery
WHERE innerQuery.rownum = 1