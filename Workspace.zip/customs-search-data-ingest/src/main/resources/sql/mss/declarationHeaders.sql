SELECT
    importSelect.IEKEY as declarationId,
    importSelect.EPUNO as epuNumber,
    importSelect.IMPENTNO as entryNumber,
    importSelect.STANDARD_DTOFENT as entryDate,
    importSelect.ROE as route,
    importSelect.DISPCNTRY as dispatchCountry,
    CAST(NULL AS STRING) as destinationCountry,
    importSelect.IMPTRTURN as consigneeTurn,
    importSelect.CNSGRTURN as consignorTurn,
    importDetail.GDSLOCN as goodsLocation,
    importDetail.TRPTMODECODE as transportModeCode,
    inadConsignee.HDRNADNAME as consigneeName,
    inadConsignee.HDRNADPOSTCODE as consigneePostcode,
    inadConsignor.HDRNADNAME as consignorName,
    inadConsignor.HDRNADPOSTCODE as consignorPostcode
  FROM DATABASE_NAME.IMENSELECT importSelect
  JOIN DATABASE_NAME.IMENDETAIL importDetail on importDetail.IEKEY = importSelect.IEKEY
  LEFT OUTER JOIN DATABASE_NAME.INAD inadConsignor on importSelect.IEKEY = inadConsignor.IEKEY and inadConsignor.HDRNADTYPE = '1'
  LEFT OUTER JOIN DATABASE_NAME.INAD inadConsignee on importSelect.IEKEY = inadConsignee.IEKEY and inadConsignee.HDRNADTYPE = '2'
UNION ALL
  SELECT
    declarationId,
    epuNumber,
    entryNumber,
    entryDate,
    route,
    dispatchCountry,
    destinationCountry,
    consigneeTurn,
    consignorTurn,
    goodsLocation,
    transportModeCode,
    consigneeName,
    consigneePostcode,
    consignorName,
    consignorPostcode
  FROM (
    SELECT
      exportSelect.IEKEY as declarationId,
      exportSelect.EPUNO as epuNumber,
      exportSelect.IMPENTNO as entryNumber,
      exportSelect.STANDARD_DTOFENT as entryDate,
      exportSelect.ROE as route,
      exportSelect.DISPCNTRY as dispatchCountry,
      exportSelect.DESTCNTRY as destinationCountry,
      exportSelect.IMPTRTURN as consigneeTurn,
      exportSelect.CNSGRTURN as consignorTurn,
      exportSelect.GDSLOCN as goodsLocation,
      exportDetail.TRPTMODECODE as transportModeCode,
      nxnadConsignee.HDRNADNAME as consigneeName,
      nxnadConsignee.HDRNADPOSTCODE as consigneePostcode,
      nxnadConsignor.HDRNADNAME as consignorName,
      nxnadConsignor.HDRNADPOSTCODE as consignorPostcode,
      ROW_NUMBER() OVER (partition by exportDetail.IEKEY order by exportSelect.STANDARD_DTOFENT) rownum
    FROM DATABASE_NAME.NXENSELECT exportSelect
    JOIN DATABASE_NAME.NXENDETAIL exportDetail on exportDetail.IEKEY = exportSelect.IEKEY
                                           and exportDetail.GENERATIONNO = exportSelect.GENERATIONNO
    LEFT OUTER JOIN DATABASE_NAME.NXNAD nxnadConsignor on exportSelect.IEKEY = nxnadConsignor.IEKEY and nxnadConsignor.HDRNADTYPE = '1'
    LEFT OUTER JOIN DATABASE_NAME.NXNAD nxnadConsignee on exportSelect.IEKEY = nxnadConsignee.IEKEY and nxnadConsignee.HDRNADTYPE = '2'
  ) innerQuery
  WHERE innerQuery.rownum = 1