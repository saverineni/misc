package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark;

import lombok.Data;

@Data
public class Country {
    private String code;
    private String name;
    private String description;
}
