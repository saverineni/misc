package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader;

import org.apache.spark.sql.Dataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.entity.DeclarationLine;

/**
 * Bean created in SparkReaderConfig.
 */
public class DeclarationLineReader {

    private SqlReader<DeclarationLine> sqlReader;
    private final String hiveSql;

    public DeclarationLineReader(SqlReader<DeclarationLine> sqlReader, String hiveSql) {
        this.sqlReader = sqlReader;
        this.hiveSql = hiveSql;
    }

    public Dataset<DeclarationLine> declarationLineDataset() {
        return sqlReader.buildDataset(hiveSql);
    }

}
