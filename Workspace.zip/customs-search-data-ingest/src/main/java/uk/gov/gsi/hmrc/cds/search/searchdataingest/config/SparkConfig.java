package uk.gov.gsi.hmrc.cds.search.searchdataingest.config;

import org.apache.spark.sql.SparkSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;

@Configuration
public class SparkConfig {

    @Autowired
    private Environment env;

    @Bean
    @Lazy
    public SparkSession sparkSessionLocal() {
        return sparkBuilder()
                .config("spark.sql.warehouse.dir", env.getProperty("hive.warehouse.path"))
                .config("javax.jdo.option.ConnectionURL", String.format("jdbc:derby:;databaseName=%s;create=true", "/var/lib/hive/metastore/metastore_db"))
                .getOrCreate();
    }

    @Bean
    @Profile({"dev", "e2e", "prod"})
    @Primary
    public SparkSession sparkSession() {
        return sparkBuilder().getOrCreate();
    }

    private SparkSession.Builder sparkBuilder() {
        return SparkSession
                .builder()
                .appName(env.getProperty("app.name"))
                .master(env.getProperty("master.uri", "local"))
                .config("es.nodes", env.getProperty("es.nodes"))
                .config("es.nodes.wan.only", env.getProperty("es.nodes.wan.only"))
                .config("es.port", env.getProperty("es.port"))
                .config("es.input.json", env.getProperty("es.input.json"))
                .config("es.http.timeout", env.getProperty("es.http.timeout"))
                .enableHiveSupport();
    }

}
