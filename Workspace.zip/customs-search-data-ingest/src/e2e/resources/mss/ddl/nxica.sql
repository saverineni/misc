CREATE TABLE search.nxica(
  iekey string,
  ieitno int,
  roe string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
