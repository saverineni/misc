CREATE TABLE search.ctry(
  cntrycode string,
  cntrynm string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
