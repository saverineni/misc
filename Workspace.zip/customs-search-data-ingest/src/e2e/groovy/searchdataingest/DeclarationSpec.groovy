package searchdataingest

import spock.lang.Shared
import spock.lang.Specification

class DeclarationSpec extends Specification {
    @Shared List declarations

    def setupSpec() {
        declarations = new ESClient().documents()
    }

    def declaration(declarationId) {
        declarations.find { it.declarationId == declarationId }
    }

    def 'nullable import fields should result in the expected output'() {
        when:
        def declaration = declaration('IM003')

        then:
        declaration.lines[0].originCountry == [
                code: '',
                name: '',
                description: ''
        ]
    }

    def 'nullable export fields should result in the expected output'() {
        when:
        def declaration = declaration('EX003')

        then:
        declaration.lines[0].originCountry == [
                code: '',
                name: '',
                description: ''
        ]
    }

    def 'import declaration with no lines should have the correct output'() {
        when:
        def declaration = declaration('IM004')

        then:
        declaration.lines == null
    }

    def 'export declaration with no lines should have the correct output'() {
        when:
        def declaration = declaration('EX004')

        then:
        declaration.lines == null
    }

}
