package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.Country;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.DeclarationLineDeclarationGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.entity.DeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader.DeclarationLineReader;

import java.util.List;

import static org.apache.spark.sql.functions.col;
import static org.apache.spark.sql.functions.explode;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

public class DeclarationLineGroupDatasetTest extends SparkTest {

    private static final String DECLARATION_ID = "declarationId";
    private static final String COMMODITY_CODE = "commodity code";
    private static final String CLEARANCE_DATE = "2018-02-01 00:00:00.00";
    private static final String CPC = "cpc";
    private static final String ORIGIN_COUNTRY_CODE = "origin country";
    private static final String ORIGIN_COUNTRY_NAME = "origin country name";
    private static final String ORIGIN_COUNTRY_DESCRIPTION = "origin country description";
    private static final String DESTINATION_COUNTRY_CODE = "dest country";
    private static final String DISPATCH_COUNTRY_CODE = "dispatch country";
    private static final String ITEM_CONSIGNEE_NAME = "consignee name";
    private static final String ITEM_CONSIGNEE_TURN = "consignee turn";
    private static final String ITEM_CONSIGNEE_POSTCODE = "consignee postcode";
    private static final String ITEM_CONSIGNOR_NAME = "consignor name";
    private static final String ITEM_CONSIGNOR_TURN = "consignor turn";
    private static final String ITEM_CONSIGNOR_POSTCODE = "consignor postcode";

    @Mock
    DeclarationLineReader mockReader;

    @InjectMocks
    DeclarationLineGroupDataset declarationLineGroupDataset;

    @Autowired
    SparkSession spark;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void declarationLinesAreSortedByItemNumber() {
        givenLinesDataset(Lists.newArrayList(
                getDeclarationLine(4),
                getDeclarationLine(2),
                getDeclarationLine(3),
                getDeclarationLine(13)
        ));
        Dataset<DeclarationLineDeclarationGroup> groupedDataset = declarationLineGroupDataset.build();
        thenTheSameNumberOfLinesAreReturned(groupedDataset);
        thenTheLinesAreSorted(groupedDataset);
    }

    @Test
    public void verifyDeclarationLineIsPopulated() {
        givenLinesDataset(Lists.newArrayList(getDeclarationLine(1)));
        Dataset<DeclarationLineDeclarationGroup> groupedDataset = declarationLineGroupDataset.build();
        thenTheFieldValuesMatch(groupedDataset);
    }

    private void thenTheFieldValuesMatch(Dataset<DeclarationLineDeclarationGroup> groupedDataset) {
        assertEquals(COMMODITY_CODE, getDatasetLineField(groupedDataset, "commodityCode").get(0).get(0));
        assertEquals(CLEARANCE_DATE, getDatasetLineField(groupedDataset, "clearanceDate").get(0).get(0));
        assertEquals(CPC, getDatasetLineField(groupedDataset, "cpc").get(0).get(0));
        assertEquals(ORIGIN_COUNTRY_CODE, getDatasetLineField(groupedDataset, "originCountry.code").get(0).get(0));
        assertEquals(ORIGIN_COUNTRY_NAME, getDatasetLineField(groupedDataset, "originCountry.name").get(0).get(0));
        assertEquals(ORIGIN_COUNTRY_DESCRIPTION, getDatasetLineField(groupedDataset, "originCountry.description").get(0).get(0));
        assertEquals(DESTINATION_COUNTRY_CODE, getDatasetLineField(groupedDataset, "destinationCountryCode").get(0).get(0));
        assertEquals(DISPATCH_COUNTRY_CODE, getDatasetLineField(groupedDataset, "dispatchCountryCode").get(0).get(0));
        assertEquals(ITEM_CONSIGNEE_NAME, getDatasetLineField(groupedDataset, "itemConsigneeName").get(0).get(0));
        assertEquals(ITEM_CONSIGNEE_TURN, getDatasetLineField(groupedDataset, "itemConsigneeTurn").get(0).get(0));
        assertEquals(ITEM_CONSIGNEE_POSTCODE, getDatasetLineField(groupedDataset, "itemConsigneePostcode").get(0).get(0));
        assertEquals(ITEM_CONSIGNOR_NAME, getDatasetLineField(groupedDataset, "itemConsignorName").get(0).get(0));
        assertEquals(ITEM_CONSIGNOR_TURN, getDatasetLineField(groupedDataset, "itemConsignorTurn").get(0).get(0));
        assertEquals(ITEM_CONSIGNOR_POSTCODE, getDatasetLineField(groupedDataset, "itemConsignorPostcode").get(0).get(0));
    }

    private void thenTheSameNumberOfLinesAreReturned(Dataset<DeclarationLineDeclarationGroup> groupedDataset) {
        long lineCount = groupedDataset.select(explode(col("lines"))).count();
        assertThat(lineCount, is(4L));
    }

    private void thenTheLinesAreSorted(Dataset<DeclarationLineDeclarationGroup> groupedDataset) {
        List<Row> importLine = getDatasetLineField(groupedDataset, "itemNumber");
        assertItemNumberIncrements(importLine);
    }

    private void givenLinesDataset(List<DeclarationLine> declarationLines) {
        Dataset<DeclarationLine> dataset = spark.createDataset(declarationLines, Encoders.bean(DeclarationLine.class));
        when(mockReader.declarationLineDataset()).thenReturn(dataset);
    }

    private DeclarationLine getDeclarationLine(int itemNumber) {
        Country country = new Country();
        country.setCode(ORIGIN_COUNTRY_CODE);
        country.setName(ORIGIN_COUNTRY_NAME);
        country.setDescription(ORIGIN_COUNTRY_DESCRIPTION);

        DeclarationLine line = new DeclarationLine();
        line.setDeclarationId(DECLARATION_ID);
        line.setItemNumber(itemNumber);
        line.setCommodityCode(COMMODITY_CODE);
        line.setClearanceDate(CLEARANCE_DATE);
        line.setCpc(CPC);
        line.setOriginCountry(country);
        line.setDestinationCountryCode(DESTINATION_COUNTRY_CODE);
        line.setDispatchCountryCode(DISPATCH_COUNTRY_CODE);
        line.setItemConsigneeName(ITEM_CONSIGNEE_NAME);
        line.setItemConsigneeTurn(ITEM_CONSIGNEE_TURN);
        line.setItemConsigneePostcode(ITEM_CONSIGNEE_POSTCODE);
        line.setItemConsignorName(ITEM_CONSIGNOR_NAME);
        line.setItemConsignorTurn(ITEM_CONSIGNOR_TURN);
        line.setItemConsignorPostcode(ITEM_CONSIGNOR_POSTCODE);
        return line;
    }

    private void assertItemNumberIncrements(List<Row> lines) {
        int previousItemNumber = 0;
        for (Row line : lines) {
            int currentItemNumber = Integer.parseInt(line.getAs("itemNumber").toString());
            assertThat(currentItemNumber, is(greaterThan(previousItemNumber)));
            previousItemNumber = currentItemNumber;
        }
    }

    private List<Row> getDatasetLineField(Dataset<DeclarationLineDeclarationGroup> dataset, String fieldName) {
        return dataset
                .filter(col("declarationId").equalTo(DECLARATION_ID))
                .select(explode(col("lines")).as("linesAll"))
                .select(col("linesAll." + fieldName))
                .collectAsList();
    }

}
