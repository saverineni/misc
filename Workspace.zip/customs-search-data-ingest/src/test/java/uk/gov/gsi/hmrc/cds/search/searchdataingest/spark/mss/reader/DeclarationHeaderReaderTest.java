package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.reader;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.apache.spark.sql.Dataset;
import org.junit.Test;

import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.mss.entity.DeclarationHeader;

@SuppressWarnings("unchecked")
public class DeclarationHeaderReaderTest {

    private static final String SQL = "sql";

    SqlReader<DeclarationHeader> sqlReader = mock(SqlReader.class);
    DeclarationHeaderReader reader = new DeclarationHeaderReader(sqlReader, SQL);

    @Test
    public void invokesSparkSessionSqlWithValidSql() {
        @SuppressWarnings("rawtypes")
        Dataset dataset = mock(Dataset.class);
        when(sqlReader.buildDataset(SQL)).thenReturn(dataset);

        Dataset<DeclarationHeader> result = reader.declarationHeaderDataset();

        assertThat(result, is(dataset));
    }
}