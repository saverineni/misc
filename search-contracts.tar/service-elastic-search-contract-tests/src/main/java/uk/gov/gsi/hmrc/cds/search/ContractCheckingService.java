package uk.gov.gsi.hmrc.cds.search;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.skyscreamer.jsonassert.JSONCompareResult;

import java.lang.reflect.Type;
import java.util.Map;

import static org.skyscreamer.jsonassert.JSONCompare.compareJSON;

@Slf4j
public class ContractCheckingService {

    private static Gson gson = new GsonBuilder().create();

    public boolean verifyContract(String actualRawJSON, String expectedRawJSON, String actualJsonPath, String expectedJsonPath) {

        String expectedJson = loadExpectedJsonByPath(expectedRawJSON, expectedJsonPath);
        String actualJson = loadActualJsonByPath(actualRawJSON, actualJsonPath);

        return verify(actualJson, expectedJson);
    }

    public boolean verify(String actualJson, String expectedJson) {
        try {
            JSONCompareResult jsonCompareResult = compareJSON(expectedJson, actualJson, JSONCompareMode.LENIENT);
            if (jsonCompareResult.failed()) {
                logErrors(new ErrorMessage(expectedJson, actualJson, jsonCompareResult.getMessage()));
                return false;
            }
            return true;
        } catch (JSONException ex) {
            logErrors(new ErrorMessage(expectedJson, actualJson, ex.toString()));
            return false;
        }
    }

    private String loadExpectedJsonByPath(String jsonContent, String path) {
        DocumentContext jsonContext = JsonPath.parse(jsonContent);
        Map<String, Object> ObjectMap = jsonContext.read(path);
        return gson.toJson(ObjectMap);
    }

    private String loadActualJsonByPath(String jsonContent, String jsonPath) {
        Type type = new TypeToken<Map<String, Object>>() {
        }.getType();
        Map<String, Object> mappingsMap = gson.fromJson(jsonContent, type);

        String indexNameKey = (String) mappingsMap.keySet().toArray()[0];
        Map<String, Object> indexNameMap = (Map<String, Object>) mappingsMap.get(indexNameKey);
        String json = gson.toJson(indexNameMap);
        return loadExpectedJsonByPath(json, jsonPath);
    }

    private void logErrors(ErrorMessage errorMessage) {
        log.error(errorMessage.toString());
    }

    class ErrorMessage {
        private final String expectedJSON;
        private String actualJSON;
        private final String error;

        ErrorMessage(String expectedJSON, String  actualJSON,  String error) {
            this.expectedJSON = expectedJSON;
            this.actualJSON = actualJSON;
            this.error = error;
        }

        @Override
        public String toString() {
            return  "\n\nElasticsearch Json : \n"+this.actualJSON + "\n\n" +
            "Search service  Json : \n "+this.expectedJSON  + "\n\n" +
                    "Error :\n "+this.error + "\n\n";
        }
    }
}
