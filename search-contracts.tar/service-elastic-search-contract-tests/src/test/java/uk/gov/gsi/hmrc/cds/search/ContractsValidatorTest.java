package uk.gov.gsi.hmrc.cds.search;

import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.net.URISyntaxException;

import static uk.gov.gsi.hmrc.cds.search.utils.FileLoaderUtils.*;

public class ContractsValidatorTest {


    @Test
    public void validateIngestionApiDeclarationContracts() throws IOException, URISyntaxException {
        String[] arguments = {  ContractsValidator.INGESTION_API,
                                INGESTION_API_ACTUAL_DECLARATION_FILE,
                                INGESTION_API_EXPECTED_DECLARATION_FILE
                             };
       Assert.assertTrue(new ContractsValidator().validateArguments(arguments));
    }

    @Test
    public void validateIngestionApiDeclarationLineContracts() throws IOException, URISyntaxException {
        String[] arguments = {  ContractsValidator.INGESTION_API,
                                INGESTION_API_ACTUAL_DECLARATION_LINE_FILE,
                                INGESTION_API_EXPECTED_DECLARATION_LINE_FILE
                              };
        Assert.assertTrue(new ContractsValidator().validateArguments(arguments));
    }

}