import { Component, Input, ContentChild, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'cds-header',
  templateUrl: './cds-header.component.html',
  styleUrls: ['./cds-header.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CdsHeaderComponent {
  @ContentChild('headerDetail') headerDetail: Component;

  @Input() title: string;
}
