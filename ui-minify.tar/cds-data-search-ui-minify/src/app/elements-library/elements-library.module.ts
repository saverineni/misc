import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CdsHeaderComponent } from './cds-header/cds-header.component';
import { CdsNavbarComponent } from './cds-navbar/cds-navbar.component';
import { RouterModule } from '@angular/router';
import { DataGridComponent } from './cds-data-grid/data-grid.component';
import { MatGridListModule, MatTooltipModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CdsFooterComponent } from './cds-footer/cds-footer.component';
import { MatIconModule } from '@angular/material/icon';
import { TooltipComponent } from './cds-tooltip/cds-tooltip.component';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    RouterModule,
    MatGridListModule,
    MatIconModule,
    MatTooltipModule
  ],
  declarations: [CdsHeaderComponent, CdsNavbarComponent, DataGridComponent, CdsFooterComponent, TooltipComponent],
  exports: [CdsHeaderComponent, CdsNavbarComponent, DataGridComponent, CdsFooterComponent, TooltipComponent]
})
export class ElementsLibraryModule { }
