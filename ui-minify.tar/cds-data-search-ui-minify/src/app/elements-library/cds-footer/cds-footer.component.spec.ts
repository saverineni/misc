import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CdsFooterComponent } from './cds-footer.component';
import { By } from '@angular/platform-browser';

describe('CdsFooterComponent', () => {
  let component: CdsFooterComponent;
  let fixture: ComponentFixture<CdsFooterComponent>;
  const buildInfo = {version: '1.0.0', environment: 'local'};

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CdsFooterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CdsFooterComponent);
    component = fixture.componentInstance;
    component.buildInfo = buildInfo;
    fixture.detectChanges();
  });

  it('should display footer', () => {
    const signInPageFooter = fixture.debugElement.query(By.css('.page-footer--signin'));
    const otherPagesFooter = fixture.debugElement.query(By.css('.page-footer'));
    expect(signInPageFooter).toBeFalsy();
    expect(otherPagesFooter).toBeTruthy();
  });

  it('should display feedback link', () => {
    const feedbackLink = fixture.debugElement.query(By.css('.inner__feedback'));
    expect(feedbackLink).toBeTruthy();
    expect(feedbackLink.nativeElement.getAttribute('href')).toBe('mailto:martin.noble@hmrc.gsi.gov.uk');
    expect(feedbackLink.nativeElement.innerText).toBe('Feedback');
  });

  it('should display contact link', () => {
    const contactLink = fixture.debugElement.query(By.css('.inner__contact'));
    expect(contactLink).toBeTruthy();
    expect(contactLink.nativeElement.getAttribute('href')).toBe('mailto:martin.noble@hmrc.gsi.gov.uk');
    expect(contactLink.nativeElement.innerText).toBe('Contact');
  });

  it('should display version label', () => {
    const versionLabel = fixture.debugElement.query(By.css('.inner__copyright__version'));
    expect(versionLabel).toBeTruthy();
    expect(versionLabel.nativeElement.innerText).toBe('VERSION 1.0.0');
  });

  it('should display environment details', () => {
    const environmentDetails = fixture.debugElement.query(By.css('.inner__copyright__environment'));
    expect(environmentDetails).toBeTruthy();
    expect(environmentDetails.nativeElement.innerText).toBe('YOU ARE USING THE LOCAL VERSION');
  });
});
