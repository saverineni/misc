import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { BuildInfo } from '../../authentication/build-info';

@Component({
  selector: 'cds-footer',
  templateUrl: './cds-footer.component.html',
  styleUrls: ['./cds-footer.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CdsFooterComponent {

  @Input() buildInfo: BuildInfo;

  constructor() { }

}
