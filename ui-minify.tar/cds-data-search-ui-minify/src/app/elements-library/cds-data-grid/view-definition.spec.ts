import { ViewDefinition } from './view-definition';

describe('Cell', () => {

    it('should be able to format an object value based on the type - timestamp', () => {
        const object = { timestampField: '2018-01-30 23:20:34.222' };
        const definition = new ViewDefinition({ id: 'timestampField',  label: 'Date', type: 'TIMESTAMP' });

        expect(definition.toCell(object, 0, 0, 4).getFormattedValue()).toEqual('30-01-2018 23:20');
    });

    it('should be able to format an object value based on the type - truncated', () => {
        const object = { truncatedField: '123456789123456789201' };
        const definition = new ViewDefinition({ id: 'truncatedField',  label: 'Truncate', type: 'TRUNCATED' });

        expect(definition.toCell(object, 0, 0, 4).getFormattedValue()).toEqual('12345678912345678...');
    });

    it('should return original value if timestamp format unsuccessful', () => {
        const object = { timestampField: 'test' };
        const definition = new ViewDefinition({ id: 'timestampField',  label: 'Date', type: 'TIMESTAMP' });

        expect(definition.toCell(object, 0, 0, 4).getFormattedValue()).toEqual('test');
    });

    it('should not truncate if field is smaller than limit', () => {
        const object = { truncatedField: '12345678912345678920' };
        const definition = new ViewDefinition({ id: 'truncatedField',  label: 'Truncate', type: 'TRUNCATED' });

        expect(definition.toCell(object, 0, 0, 4).getFormattedValue()).toEqual('12345678912345678920');
    });

    it('should generate a cell id from the id and the path', () => {
        const object = { idField: 'objectId' };
        const headerDefinition = new ViewDefinition({ id: 'idField', label: 'ID', path: '.nested.nested' });

        expect(headerDefinition.toCell(object, 0, 1, 4).id).toEqual('idField-nested-nested');
    });

    it('should calculate the correct colspan for the cell', () => {
        const object = { idField: 'objectId' };
        const headerDefinition = new ViewDefinition({ id: 'idField',  label: 'ID', header: true });

        expect(headerDefinition.toCell(object, 0, 1, 4).colspan).toBe(4);
        expect(headerDefinition.toCell(object, 1, 2, 4).colspan).toBe(3);
        expect(headerDefinition.toCell(object, 2, 3, 4).colspan).toBe(2);
        expect(headerDefinition.toCell(object, 3, 4, 4).colspan).toBe(1);
        expect(headerDefinition.toCell(object, 4, 5, 4).colspan).toBe(4);
        expect(headerDefinition.toCell(object, 5, 6, 4).colspan).toBe(3);
        expect(headerDefinition.toCell(object, 6, 7, 4).colspan).toBe(2);
        expect(headerDefinition.toCell(object, 7, 8, 4).colspan).toBe(1);
    });

    it('should have a colspan of 1 for non-header cells', () => {
        const object = { idField: 'objectId' };
        const nonHeaderDefinition = new ViewDefinition({ id: 'idField',  label: 'ID', header: false });
        expect(nonHeaderDefinition.toCell(object, 0, 1, 4).colspan).toBe(1);
    });

});

describe('ViewDefinition', () => {

    it('should have default properties', () => {
        const definition = new ViewDefinition({ id: 'idField',  label: 'ID' });

        expect(definition.type).toEqual('STRING');
        expect(definition.header).toBe(false);
        expect(definition.tooltip).toEqual('');
        expect(definition.clickAction).toEqual('NONE');
    });

    it('should override default properties', () => {
        const definition = new ViewDefinition({
            id: 'idField',
            label: 'ID',
            type: 'TIMESTAMP',
            header: true,
            tooltip: 'tooltip',
            clickAction: 'COPY'
        });

        expect(definition.type).toEqual('TIMESTAMP');
        expect(definition.header).toBe(true);
        expect(definition.tooltip).toEqual('tooltip');
        expect(definition.clickAction).toEqual('COPY');
    });

    it('should be able to automatically find an object value based on an id', () => {
        const object = { idField: 'objectId' };
        const definition = new ViewDefinition({ id: 'idField',  label: 'ID' });

        expect(definition.getValue(object)).toEqual('objectId');
    });

    it('should be able to find an object value by recursively following path', () => {
        const object = { codeObject: { valueObject: { nestedValue: 'value' } } };
        const definition = new ViewDefinition({ id: 'codeObject',  label: 'ID', path: '.valueObject.nestedValue' });

        expect(definition.getValue(object)).toEqual('value');
    });

    it('should return a blank string if object path cannot be fully resolved', () => {
        const object = { codeObject: { valueObject: undefined } };
        const object2 = { codeObject: undefined };
        const definition = new ViewDefinition({ id: 'codeObject',  label: 'ID', path: '.valueObject.nestedValue' });

        expect(definition.getValue(object)).toEqual('');
        expect(definition.getValue(object2)).toEqual('');
    });

    it('should map to an array of view definition', () => {
        const definitions = {
            'definitions': [
              {
                'header': true,
                'label': 'Declaration ID',
                'type': 'STRING',
                'path': '',
                'id': 'declarationId'
              },
              {
                'header': false,
                'label': 'Country of Dispatch',
                'type': 'STRING',
                'path': '.code',
                'id': 'dispatchCountry'
              }
            ]
          };

        const result = ViewDefinition.objectsToViewDefinition(definitions);
        expect(result.length).toBe(2);
        expect(result[0].header).toBe(true);
        expect(result[1].header).toBe(false);
        expect(result[0].label).toEqual('Declaration ID');
        expect(result[1].label).toEqual('Country of Dispatch');
        expect(result[0].type).toEqual('STRING');
        expect(result[1].type).toEqual('STRING');
        expect(result[0].path).toEqual('');
        expect(result[1].path).toEqual('.code');
        expect(result[0].id).toEqual('declarationId');
        expect(result[1].id).toEqual('dispatchCountry');
        expect(result[0].getValue).toBeTruthy();
        expect(result[1].getValue).toBeTruthy();
        expect(result[0].toCell).toBeTruthy();
        expect(result[1].toCell).toBeTruthy();
    });

});
