import * as moment from 'moment';

export class Cell {
  private static TRUNCATE_LENGTH = 17;
  private static TRUNCATE_SUFFIX = '...';
  private static TIMESTAMP_FORMAT = 'DD-MM-YYYY HH:mm';

  constructor(
    readonly id: string,
    readonly label: string,
    readonly value: any,
    readonly type: string,
    readonly colspan: number,
    readonly header: boolean,
    readonly tooltip: string,
    readonly clickAction: string
  ) {}

  getFormattedValue(): string {
    return this.format(this.value);
  }

  private format(data: string): string {
    if (this.type === 'TIMESTAMP') {
      const formatted = moment(data).format(Cell.TIMESTAMP_FORMAT);
      return formatted !== 'Invalid date' ? formatted : data;
    } else if (this.type === 'TRUNCATED') {
      if (data.length > Cell.TRUNCATE_LENGTH + Cell.TRUNCATE_SUFFIX.length) {
        return data.substring(0, Cell.TRUNCATE_LENGTH).trim() + Cell.TRUNCATE_SUFFIX;
      }
    }
    return data;
  }
}

export class ViewDefinition {
  readonly id: string;
  readonly label: string;
  readonly path: string = '';
  readonly type: string = 'STRING';
  readonly header: boolean = false;
  readonly tooltip: string = '';
  readonly clickAction: string = 'NONE';

  constructor(definition: {
    id: string,
    label: string,
    path?: string,
    type?: string,
    header?: boolean,
    tooltip?: string,
    clickAction?: string
  }) {
    this.id = definition.id;
    this.label = definition.label;
    this.path = definition.path || this.path;
    this.type = definition.type || this.type;
    this.header = definition.header || this.header;
    this.tooltip = definition.tooltip || this.tooltip;
    this.clickAction = definition.clickAction || this.clickAction;
  }

  static objectsToViewDefinition = (result: any) => {
    return result.definitions.map(obj =>
      new ViewDefinition({
        id: obj.id,
        label: obj.label,
        path: obj.path,
        type: obj.type,
        header: obj.header,
        tooltip: obj.tooltip,
        clickAction: obj.clickAction
      })
    );
  }

  getValue: (any) => (string) = (data) => {
    const pathArray = (this.id + this.path).split('.');
    const value = pathArray.reduce((object, path) => object[path] ? object[path] : '', data);
    return value;
  }

  toCell(data, cellIndex, headerCellCount, columnCount) {
    let colspan = 1;
    if (this.header && cellIndex === headerCellCount - 1) {
      const remainder = columnCount + 1 - (headerCellCount % columnCount);
      colspan = headerCellCount % columnCount === 0 ? 1 : remainder;
    }

    return new Cell(
      this.id + this.path.replace(/\./g, '-'),
      this.label,
      this.getValue(data),
      this.type,
      colspan,
      this.header,
      this.tooltip,
      this.clickAction
    );
  }

}
