import {ChangeDetectionStrategy, Component, Input, ViewEncapsulation, Inject} from '@angular/core';
import {Cell} from './view-definition';
import {TrackBy} from '../../track-by';
import {Observable} from 'rxjs/internal/Observable';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'cds-data-grid',
  templateUrl: './data-grid.component.html',
  styleUrls: ['./data-grid.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DataGridComponent {
  trackById = TrackBy.property('id');

  @Input() columnCount: number;
  @Input() cells: Observable<Cell[]>;

  private dom: Document;

  constructor(@Inject(DOCUMENT) dom: Document) {
    this.dom = dom;
  }

  copy(cell) {
    if (cell.clickAction === 'COPY') {
      const textarea = this.dom.createElement('textarea');
      textarea.textContent = cell.value;
      this.dom.body.appendChild(textarea);

      const selection = this.dom.getSelection();
      const range = this.dom.createRange();
      range.selectNode(textarea);
      selection.removeAllRanges();
      selection.addRange(range);

      this.dom.execCommand('copy');
      selection.removeAllRanges();

      this.dom.body.removeChild(textarea);
    }
  }
}
