import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DataGridComponent } from './data-grid.component';
import { By } from '@angular/platform-browser';
import { MatGridListModule } from '@angular/material';
import { Cell } from './view-definition';
import { of } from 'rxjs';
import { ElementsLibraryModule } from '../elements-library.module';

describe('DataGridComponent', () => {
  let component: DataGridComponent;
  let fixture: ComponentFixture<DataGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MatGridListModule, ElementsLibraryModule]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataGridComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Cell list observable', () => {
    const cells = [
      new Cell('dataId', 'data ID', 'dataId', '', 1, true, '', ''),
      new Cell('value1', 'Value 1', 'value1', '', 3, false, '', ''),
      new Cell('value2', 'Value 2', 'value2', '', 2, false, '', 'COPY'),
    ];

    describe('table cells', () => {

      beforeEach(() => {
        component.columnCount = 3;
        component.cells = of(cells);

        fixture.detectChanges();
      });

      cells.forEach(cell => {
        describe(`the ${cell.label} table cell`, () => {
          it(`should display the ${cell.label} label`, () => {
            expect(fixture.debugElement.query(By.css(`.data-grid__header[data-grid-field="${cell.id}"]`)).nativeElement.innerText.trim())
              .toEqual(cell.label);
          });

          it(`should display the ${cell.label} value`, () => {
            expect(fixture.debugElement.query(By.css(`.data-grid__value[data-grid-field="${cell.id}"]`)).nativeElement.innerText.trim())
              .toEqual(cell.value);
          });
        });

        it(`should apply the strong styling when defined for ${cell.label}`, () => {
          expect(fixture.debugElement.query(By.css(`.data-grid__value[data-grid-field="${cell.id}"].strong`)) !== null)
            .toEqual(cell.header);
        });

        it(`should apply the copy styling when defined for ${cell.label}`, () => {
          expect(fixture.debugElement.query(By.css(`.data-grid__value[data-grid-field="${cell.id}"].copy`)) !== null)
            .toEqual(cell.clickAction === 'COPY');
        });
      });
    });

    describe('Formatted values', () => {
      beforeEach(() => {
        component.columnCount = 3;
        component.cells = of([
          new Cell('dataId', 'data ID', '2018-01-30 23:20:34.222', 'TIMESTAMP', 1, true, '', ''),
          new Cell('value1', 'Value 1', '123456789123456789201', 'TRUNCATED', 2, false, '', ''),
        ]);

        fixture.detectChanges();
      });

      it('should show the timestamp formatted value in the cell', () => {
        expect(fixture.debugElement.query(By.css(`.data-grid__value[data-grid-field="dataId"]`)).nativeElement.innerText.trim())
              .toEqual('30-01-2018 23:20');
      });

      it('should show the truncated value in the cell', () => {
        expect(fixture.debugElement.query(By.css(`.data-grid__value[data-grid-field="value1"]`)).nativeElement.innerText.trim())
              .toEqual('12345678912345678...');
      });
    });
  });
});
