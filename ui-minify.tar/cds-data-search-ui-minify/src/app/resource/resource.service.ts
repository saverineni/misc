import { Injectable } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { switchMap, catchError } from 'rxjs/operators';
import { Observable, of, OperatorFunction } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';

@Injectable()
export class ResourceService {

  constructor(private router: Router) { }

  handleNotFound<R>(
      route: ActivatedRoute,
      paramHandler: (paramMap: ParamMap) => Observable<R>): Observable<R> {
    return route.paramMap.pipe(
      switchMap(paramHandler),
      this.catchHttpErrorAndHandleNotFound(route)
    ) as Observable<R>;
  }

  private catchHttpErrorAndHandleNotFound<T, R>(activatedRoute: ActivatedRoute): OperatorFunction<T, {} | R> {
    return catchError((err, obs) => {
      if (err instanceof HttpErrorResponse && err.status === 404) {
        this.notFound(activatedRoute);
        return of();
      }

      throw err;
    });
  }

  notFound(route: ActivatedRoute) {
    this.router.navigate(['not-found'], { relativeTo: route, skipLocationChange: true });
  }
}
