import { ChangeDetectionStrategy, Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Declaration } from './declaration';
import { Cell, ViewDefinition } from '../../elements-library/cds-data-grid/view-definition';
import { DeclarationService } from './declaration.service';
import { Observable } from 'rxjs/internal/Observable';
import { map, shareReplay } from 'rxjs/operators';
import { Breadcrumb } from '../breadcrumb/breadcrumb';
import { DefinitionService } from '../search/definition.service';
import { combineLatest } from 'rxjs';
import { AuthenticationService } from '../../authentication/authentication.service';
import { SignInRouterService } from '../../authentication/sign-in/sign-in-router.service';

@Component({
  selector: 'cds-declaration-detail',
  templateUrl: './declaration-detail.component.html',
  styleUrls: ['./declaration-detail.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class DeclarationDetailComponent implements OnInit {
  columnCount = 4;

  declaration$: Observable<Declaration>;
  viewDefinitions$: Observable<ViewDefinition[]>;
  gridCells$: Observable<Cell[]>;
  breadcrumbs: Array<Breadcrumb>;

  constructor(private route: ActivatedRoute,
    private definitionService: DefinitionService,
    private declarationService: DeclarationService,
    private authenticationService: AuthenticationService,
    private signInRouterService: SignInRouterService) { }

  ngOnInit() {
    this.declaration$ = this.declarationService.declarationForRoute(this.route).pipe(shareReplay(1));

    this.gridCells$ = combineLatest(this.declaration$, this.definitionService.getDeclarationDefinition()).pipe(
      map(([declaration, viewDefinitions]) => {
        const cells: Cell[] = [];
        const headerCount = viewDefinitions.filter(def => def.header).length;

        for (let i = 0; i < viewDefinitions.length; i++) {
          const definition = viewDefinitions[i];
          cells.push(definition.toCell(declaration, i, headerCount, this.columnCount));
        }

        return cells;
      })
    );

    this.breadcrumbs = [
      new Breadcrumb('Declaration Detail')
    ];
  }

  print() {
    if (!this.authenticationService.isAuthenticated()) {
      this.signInRouterService.navigateToSignIn();
    } else {
      window.print();
    }
  }

}
