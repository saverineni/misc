import { Component, OnInit, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ChangeDetectionStrategy } from '@angular/core';
import { Cell, ViewDefinition } from '../../../elements-library/cds-data-grid/view-definition';
import { DeclarationService } from '../declaration.service';
import { Observable, of, combineLatest } from 'rxjs';
import { ViewEncapsulation } from '@angular/core';
import { Location } from '@angular/common';
import { TrackBy } from '../../../track-by';
import { ViewChild } from '@angular/core';
import { LinesSelection } from '../lines-selection';
import { Breadcrumb } from '../../breadcrumb/breadcrumb';
import { DefinitionService } from '../../search/definition.service';
import { map } from 'rxjs/operators';
import { AuthenticationService } from '../../../authentication/authentication.service';
import { SignInRouterService } from '../../../authentication/sign-in/sign-in-router.service';
import * as moment from 'moment';
import * as FileSaver from 'file-saver';
import { AttributesPicker } from '../../search/attributes-picker';
import { MatDialog } from '@angular/material';
import { ExtractCsvComponent } from '../../search/extract-csv/extract-csv.component';

@Component({
  selector: 'cds-declaration-item-detail',
  templateUrl: './declaration-item-detail.component.html',
  styleUrls: ['./declaration-item-detail.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class DeclarationItemDetailComponent implements OnInit {
  TIMESTAMP_FORMAT = 'YYYY-MM-DD-HH-mm';
  trackByItemNumber = TrackBy.property('itemNumber');

  @ViewChild('tabs') tabs;
  @ViewChild('itemFilter') set content(content: ElementRef) {
    if (content) {
        content.nativeElement.focus();
    }
 }

  columnCount = 4;

  linesSelection$: Observable<LinesSelection>;
  viewDefinitions$: Observable<ViewDefinition[]>;
  noResults: boolean;
  breadcrumbs: Array<Breadcrumb>;
  selectedHeaderFields: Array<AttributesPicker>;
  attributes: Array<AttributesPicker>;

  private WIDTH = '600px';
  private MAX_HEIGHT = '60vh';
  private MIN_HEIGHT = '30vh';

  constructor(public dialog: MatDialog,
              private route: ActivatedRoute,
              private router: Router,
              private declarationService: DeclarationService,
              private definitionService: DefinitionService,
              private authenticationService: AuthenticationService,
              private signInRouterService: SignInRouterService,
              private location: Location) { }

  ngOnInit() {
    this.linesSelection$ = this.declarationService.itemsForRoute(this.route);
    this.viewDefinitions$ = combineLatest(this.definitionService.getDeclarationDefinition(),
      this.definitionService.getDeclarationItemDefinition()).pipe(
        map(([headerDefinitions, itemDefinitions]) => {
          const declarationHeaders = headerDefinitions.filter(definition => definition.header);
          return declarationHeaders.concat(itemDefinitions);
        })
    );

    this.breadcrumbs = [
      new Breadcrumb('Declaration Detail', this.getDeclarationDetailUrl()),
      new Breadcrumb('Item Detail')
    ];
  }

  onIndexChange(declarationId, number) {
    this.location.replaceState(`/declarations/${declarationId}/items/${number + 1}`);
  }

  onFilterInput(itemFilter, items) {
    const itemNumber = +itemFilter;
    if (!itemFilter || itemFilter === '') {
      this.noResults = false;
    } else if (!isNaN(itemNumber) && itemNumber > 0 && itemNumber <= items.length) {
      this.noResults = false;
      this.tabs.selectedIndex = itemNumber - 1;
    } else  {
      this.noResults = true;
    }
  }

  itemCells(item): Observable<Cell[]> {
    return this.viewDefinitions$.pipe(
      map(viewDefinitions => {
        this.attributes = viewDefinitions.map(viewDefinition => new AttributesPicker(viewDefinition.id, viewDefinition.label));
        const cells: Cell[] = [];
        const headerCount = viewDefinitions.filter(def => def.header).length;

        for (let i = 0; i < viewDefinitions.length; i++) {
          const definition = viewDefinitions[i];
          cells.push(definition.toCell(item, i, headerCount, this.columnCount));
        }

        return cells;
      })
    );
  }

  getDeclarationDetailUrl(): string {
    const itemDetailUrl: string = this.router.routerState.snapshot.url;
    return itemDetailUrl.replace(/\/items\/.*/, '');
  }

  print() {
    if (!this.authenticationService.isAuthenticated()) {
      this.signInRouterService.navigateToSignIn();
    } else {
      window.print();
    }
  }

  downloadCsv(declarationId) {
    const dialogRef = this.dialog.open(
      ExtractCsvComponent,
      {
        width: this.WIDTH,
        maxHeight: this.MAX_HEIGHT,
        minHeight: this.MIN_HEIGHT,
        data: {
          id: 'item',
          fields: this.attributes
        }
      });

    dialogRef.afterClosed().subscribe(extractFields => {
      if (extractFields) {
        const timestamp = moment(new Date()).format(this.TIMESTAMP_FORMAT);

        this.declarationService.downloadCsv(declarationId, extractFields).forEach(csv => {
          if (csv) {
            const blob = new Blob([csv], {type: 'text/csv;charset=utf-8'});
            FileSaver.saveAs(blob, `${declarationId}-items-${timestamp}.csv`);
          }
        });
      }
    });
  }
}
