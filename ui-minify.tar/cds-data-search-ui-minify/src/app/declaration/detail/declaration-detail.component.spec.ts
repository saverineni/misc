import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {DeclarationDetailComponent} from './declaration-detail.component';
import {MatCardModule, MatDividerModule, MatExpansionModule, MatIconModule} from '@angular/material';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {Input, DebugElement, Directive} from '@angular/core';
import {Declaration} from './declaration';
import {ActivatedRoute} from '@angular/router';
import {Observable, of} from 'rxjs';
import {By} from '@angular/platform-browser';
import {DeclarationLine} from './declaration-line';
import {DeclarationService} from './declaration.service';
import {Cell} from '../../elements-library/cds-data-grid/view-definition';
import {RouterTestingModule} from '@angular/router/testing';
import { DefinitionService } from '../search/definition.service';
import { AuthenticationService } from '../../authentication/authentication.service';
import { SignInRouterService } from '../../authentication/sign-in/sign-in-router.service';

@Directive({
  selector: 'cds-data-grid'
})
export class MockDeclarationDataGridDirective {
  @Input() columnCount: number;
  @Input() cells: Observable<Cell[]>;
}
@Directive({
  selector: 'cds-breadcrumb'
})
export class MockBreadCrumbDirective {
  @Input() breadcrumbs = [];
}

describe('DeclarationDetailComponent', () => {
  let component: DeclarationDetailComponent;
  let fixture: ComponentFixture<DeclarationDetailComponent>;
  let declaration: Declaration;
  let mockDefinitionService: DefinitionService;
  let mockDeclarationService: DeclarationService;
  let activatedRoute: ActivatedRoute;

  let importDeclarationTypeCard: DebugElement;
  let exportDeclarationTypeCard: DebugElement;
  let printButton: DebugElement;
  let authenticationService: AuthenticationService;
  let mockAuthenticationService: AuthenticationService;
  let signInRouterService: SignInRouterService;

  beforeEach(async(() => {
    declaration = new Declaration();
    declaration.declarationId = 'id';
    const obsDefinition: any = of({});
    const obsDeclaration: any = of(declaration);

    mockAuthenticationService = {
      isAuthenticated: () => {}
    } as AuthenticationService;

    signInRouterService = {
      navigateToSignIn: () => {}
    } as SignInRouterService;

    activatedRoute = {
      data: obsDeclaration
    } as ActivatedRoute;

    mockDefinitionService = {
      getDeclarationDefinition: () => obsDefinition
    } as DefinitionService;

    mockDeclarationService = {
      declarationForRoute: (route) => obsDeclaration
    } as DeclarationService;

    spyOn(mockDefinitionService, 'getDeclarationDefinition').and.callThrough();
    spyOn(mockDeclarationService, 'declarationForRoute').and.callThrough();
    window.print = jasmine.createSpy().and.callThrough();

  }));

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [MatCardModule, MatDividerModule, MatExpansionModule, BrowserAnimationsModule, RouterTestingModule, MatIconModule],
      declarations: [ DeclarationDetailComponent, MockDeclarationDataGridDirective, MockBreadCrumbDirective ],
      providers: [
        { provide: ActivatedRoute, useValue: activatedRoute },
        { provide: AuthenticationService, useValue: mockAuthenticationService },
        { provide: SignInRouterService, useValue: signInRouterService },
        { provide: DefinitionService, useValue: mockDefinitionService },
        { provide: DeclarationService, useValue: mockDeclarationService }
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DeclarationDetailComponent);
    component = fixture.componentInstance;
    printButton = fixture.debugElement.query(By.css('.declaration-detail__print-button'));

    authenticationService = TestBed.get(AuthenticationService);
    signInRouterService = TestBed.get(SignInRouterService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call the declaration service with the route', () => {
    fixture.detectChanges();
    expect(mockDeclarationService.declarationForRoute).toHaveBeenCalledWith(activatedRoute);
  });

  describe('data grid', () => {
    let dataGrid: MockDeclarationDataGridDirective;

    beforeEach(() => {
      fixture.detectChanges();
      dataGrid = fixture.debugElement.query(By.directive(MockDeclarationDataGridDirective)).injector.get(MockDeclarationDataGridDirective);
    });

    it('should set the column count', () => {
      expect(dataGrid.columnCount).toBe(4);
    });

  });

  describe('import/export type', () => {

    function findImportExportTypes() {
      importDeclarationTypeCard = fixture.debugElement.query(By.css('.declaration-detail__declarations--import'));
      exportDeclarationTypeCard = fixture.debugElement.query(By.css('.declaration-detail__declarations--export'));
    }

    function setImportExportType(declarationType) {
      declaration.importExportIndicator = declarationType;
      fixture.detectChanges();
    }

    it('with colour yellow for an import', () => {
      setImportExportType('Import');
      findImportExportTypes();

      expect(importDeclarationTypeCard).toBeTruthy();
      expect(exportDeclarationTypeCard).toBeFalsy();
    });

    it('with colour blue for an export', () => {
      setImportExportType('Export');
      findImportExportTypes();

      expect(importDeclarationTypeCard).toBeFalsy();
      expect(exportDeclarationTypeCard).toBeTruthy();
    });
  });

  describe('item details button', () => {
    function getItemDetailsDisabledButton() {
      return fixture.debugElement.query(By.css('button.declaration-detail__item-details-button'));
    }

    function getItemDetailsLink() {
      return fixture.debugElement.query(By.css('a.declaration-detail__item-details-button'));
    }

    describe('with lines', () => {
      beforeEach(() => {
        declaration.lines = [new DeclarationLine(), new DeclarationLine()];
        fixture.detectChanges();
      });

      it('should have the correct link for the first items details', () => {
        const href = getItemDetailsLink().nativeElement.getAttribute('ng-reflect-router-link');
        expect(href).toEqual('/declarations/id/items/1');
      });

      it('should report the correct number of items', () => {
        expect(getItemDetailsLink().nativeElement.innerText).toEqual('ITEM DETAIL (2)');
      });

      it('should not be disabled when there are items', () => {
        expect(getItemDetailsLink() === null).toBe(false);
        expect(getItemDetailsDisabledButton() === null).toBe(true);
      });
    });

    describe('without lines', () => {
      beforeEach(() => {
        declaration.lines = [];
        fixture.detectChanges();
      });

      it('should report zero items correctly', () => {
        expect(getItemDetailsDisabledButton().nativeElement.innerText).toEqual('ITEM DETAIL (0)');
      });

      it('should be disabled when there are zero items', () => {
        expect(getItemDetailsDisabledButton().nativeElement.disabled).toBe(true);
      });
    });
  });

  describe('print', () => {

    it('should exist', () => {
      expect(printButton).toBeTruthy();
    });

    describe('for an expired/invalid token', () => {
      beforeEach(() => {
        spyOn(signInRouterService, 'navigateToSignIn').and.callThrough();
        spyOn(authenticationService, 'isAuthenticated').and.returnValue(false);

        component.print();
      });

      it('should route to sign in page', () => {
        expect(signInRouterService.navigateToSignIn).toHaveBeenCalled();
      });
    });

    describe('for a valid token', () => {
      beforeEach(() => {
        spyOn(authenticationService, 'isAuthenticated').and.returnValue(true);

        component.print();
      });

      it('should call window print', () => {
        expect(window.print).toHaveBeenCalled();
      });
    });

  });
});
