import {ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewEncapsulation} from '@angular/core';
import {SearchCriteria} from '../search-criteria';
import {SearchService} from '../search.service';
import {DeclarationSearchResult} from '../declaration-search-result';
import {Subscription} from 'rxjs';
import {SearchCriteriaService} from '../search-criteria.service';
import {TrackBy} from '../../../track-by';
import * as FileSaver from 'file-saver';
import { NavigationService } from '../navigation.service';
import * as moment from 'moment';
import { TogglePanelService } from '../search-filter/toggle-panel.service';
import { TogglePanel } from '../search-filter/toggle-panel';
import { DefinitionService } from '../definition.service';
import { MatDialog } from '@angular/material';
import { ExtractCsvComponent } from '../extract-csv/extract-csv.component';
import { ViewDefinition } from '../../../elements-library/cds-data-grid/view-definition';
import { AttributesPicker } from '../attributes-picker';

@Component({
  selector: 'cds-search-section',
  templateUrl: './search-section.component.html',
  styleUrls: ['./search-section.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SearchSectionComponent implements OnInit, OnDestroy {
  TIMESTAMP_FORMAT = 'YYYY-MM-DD-HH-mm';

  trackByDeclarationId = TrackBy.property('declarationId');

  result: DeclarationSearchResult = null;
  searchCriteriaSubscription: Subscription;
  searchCriteria: SearchCriteria;
  hmrcLogo: string;
  downloadLimit = 10001;
  viewDefinitions: ViewDefinition[];
  selectedHeaderFields: Array<AttributesPicker>;

  private WIDTH = '600px';
  private MAX_HEIGHT = '60vh';
  private MIN_HEIGHT = '30vh';

  constructor(public dialog: MatDialog,
              private navigationService: NavigationService,
              private searchService: SearchService,
              private searchCriteriaService: SearchCriteriaService,
              private togglePanelService: TogglePanelService,
              private definitionService: DefinitionService,
              private changeDetectorRef: ChangeDetectorRef) { }

  ngOnInit() {
    this.searchCriteriaSubscription =
      this.searchCriteriaService.searchCriteria.subscribe(
        newSearchCriteria => {
          this.searchCriteria = newSearchCriteria;
          if (newSearchCriteria.isEmpty()) {
            this.result = undefined;
          } else {
            this.performSearch();
          }
        }
      );
    this.hmrcLogo = '/assets/hmrc-logo-web.jpg';

    this.definitionService.getDeclarationDefinition().subscribe(
      declarationDefinitions => {
        this.viewDefinitions = declarationDefinitions;
    });
  }

  private performSearch() {
    this.searchService.search(this.searchCriteria).subscribe(
      result => {
        this.result = result;
        this.changeDetectorRef.detectChanges();
      }
    );
  }

  navigateToSearch() {
    this.navigationService.navigateToSearch(true);
    this.togglePanelService.replace(new TogglePanel());
  }

  downloadCsv() {
    const dialogRef = this.dialog.open(
      ExtractCsvComponent,
      {
        width: this.WIDTH,
        maxHeight: this.MAX_HEIGHT,
        minHeight: this.MIN_HEIGHT,
        data: {
          id: 'header',
          fields: this.viewDefinitions.map(viewDefinition => new AttributesPicker(viewDefinition.id, viewDefinition.label))
        }
      }
    );

    dialogRef.afterClosed().subscribe(extractFields => {
      if (extractFields) {
        const pageSize = this.result && this.result.hits && this.result.hits.total || 0;
        const search = Object.assign(new SearchCriteria(), this.searchCriteria);
        search.pageSize = pageSize;
        search.pageNumber = 1;

        const timestamp = moment(new Date()).format(this.TIMESTAMP_FORMAT);
        this.searchService.downloadCsv(search, extractFields).forEach(csv => {
          if (csv) {
            const blob = new Blob([csv], {type: 'text/csv;charset=utf-8'});
            FileSaver.saveAs(blob, `declarations-${timestamp}.csv`);
          }
        });
      }
    });
  }

  ngOnDestroy() {
    this.searchCriteriaSubscription.unsubscribe();
    this.dialog.closeAll();
  }

}
