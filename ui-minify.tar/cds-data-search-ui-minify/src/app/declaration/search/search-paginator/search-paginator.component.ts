import {Component, Input, OnInit, ViewChild, ViewEncapsulation, Inject, OnDestroy} from '@angular/core';
import {PageEvent} from '@angular/material';
import {SearchCriteriaService} from '../search-criteria.service';
import {Subscription} from 'rxjs';
import {SearchCriteria} from '../search-criteria';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'cds-search-paginator',
  templateUrl: './search-paginator.component.html',
  styleUrls: ['./search-paginator.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SearchPaginatorComponent implements OnInit, OnDestroy {

  @ViewChild('paginator') paginator;
  private criteriaSubscription: Subscription;
  private searchCriteria: SearchCriteria;

  @Input() totalResults;
  pageSize = 10;
  pageSizeOptions: number[] = [10, 20, 30, 40, 50];


  constructor(private searchCriteriaService: SearchCriteriaService,
              @Inject(DOCUMENT) private document: Document) { }

  ngOnInit() {
    this.criteriaSubscription = this.searchCriteriaService.searchCriteria.subscribe(
      criteria => {
        this.searchCriteria = criteria;

        // MatPaginator PageIndex is zero based
        const pageNumber = this.searchCriteria.pageNumber ? this.searchCriteria.pageNumber - 1 : 0;
        const pageSize = this.searchCriteria.pageSize ? this.searchCriteria.pageSize : 10;
        this.paginator.pageIndex = pageNumber;
        this.paginator.pageSize = pageSize;
        this.pageSize = pageSize;
      }
    );
  }


  onPageChange(pageEvent: PageEvent) {
    const update = {};

    // MatPaginator PageIndex is zero based - pageIndex(0) == pageNumber(1), so add +1
    update['pageNumber'] = pageEvent.pageIndex + 1;
    update['pageSize'] = pageEvent.pageSize;

    this.document.body.scrollTop = 0;
    this.document.documentElement.scrollTop = 0;
    this.searchCriteriaService.updatePartial(update);
  }

  ngOnDestroy(): void {
    this.criteriaSubscription.unsubscribe();
  }
}
