import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {getTestBed, TestBed} from '@angular/core/testing';

import {FacetService} from './facet.service';
import {SearchCriteria} from './search-criteria';
import {SearchParamsBuilder} from './search-params-builder';

describe('FacetService', () => {
  const FACET_TYPE = 'facet-type';
  const FILTER_BY = 'filter-by';

  let httpMock: HttpTestingController;
  let service: FacetService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FacetService],
      imports: [HttpClientTestingModule]
    });

    httpMock = getTestBed().get(HttpTestingController);
    service = getTestBed().get(FacetService);
  });

  [
    {
      filterBy: FILTER_BY,
      serviceUrl: `/api/facets/${FACET_TYPE}/${FILTER_BY}`
    },
    {
      filterBy: undefined,
      serviceUrl: `/api/facets/${FACET_TYPE}`
    }
  ].forEach((test: any) => {

    let testRequest;
    describe(`facets by type and filterBy is '${test.filterBy}'`, () => {
      const facet1 = {id: 'id1', count: 2};
      const facet2 = {id: 'id2', count: 3};
      let result;

      beforeEach((done) => {
        service.getFacets(FACET_TYPE, test.filterBy, new SearchCriteria()).subscribe(
          successfulResult => {
            result = successfulResult;
            done();
          },
          error => done.fail()
        );

        testRequest = httpMock.expectOne(test.serviceUrl);
        testRequest.flush({facets: [{id: 'id1', count: 2}, {id: 'id2', count: 3}]});
      });

      it('should load the facets from the http resource', () => {
        const expectedFacets = [facet1, facet2];

        expect(result).toEqual(expectedFacets);
      });

      it('should be a http GET call', () => {
        expect(testRequest.request.method).toBe('GET');
      });
    });

    let searchCriteria;
    describe('facets for type with search criteria', () => {
      beforeEach((done) => {
        spyOn(SearchParamsBuilder, 'toHttpParams').and.callThrough();

        searchCriteria = new SearchCriteria();
        searchCriteria.searchTerm = 'term';

        service.getFacets(FACET_TYPE, test.filterBy, searchCriteria).subscribe(done, done.fail);
        testRequest = httpMock.expectOne(`${test.serviceUrl}?searchTerm=term`);
        testRequest.flush({facets: []});
      });

      it('should add the current search criteria params to the request', () => {
        expect(testRequest.request.method).toBe('GET');
      });

      it('should use the search params builder', () => {
        expect(SearchParamsBuilder.toHttpParams).toHaveBeenCalledWith(searchCriteria);
      });
    });

    describe('with filters for current type', () => {
      const facetType = 'originCountryCode';
      const baseUrl = test.serviceUrl.replace(FACET_TYPE, facetType);

      beforeEach((done) => {
        spyOn(SearchParamsBuilder, 'toHttpParams').and.callThrough();

        searchCriteria = new SearchCriteria();
        searchCriteria.searchTerm = 'term';
        searchCriteria[facetType] = ['code'];
        searchCriteria.entryDateFrom = 'date';

        service.getFacets(facetType, test.filterBy, searchCriteria).subscribe(done, done.fail);
        testRequest = httpMock.expectOne(`${baseUrl}?searchTerm=term&entryDateFrom=date`);
        testRequest.flush({facets: []});
      });

      it('should not add search params for selected facet', () => {
        expect(testRequest.request.method).toBe('GET');
      });
    });
  });
});
