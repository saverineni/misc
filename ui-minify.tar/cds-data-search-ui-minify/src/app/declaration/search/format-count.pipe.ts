import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'formatCount'
})
export class FormatCountPipe implements PipeTransform {

  transform(value: number, args?: any): string {
    if (!value) {
      return '0';
    }

    const suffix = [' ', 'K', 'M', 'B'];
    const logBaseValue =  Math.floor(Math.log10(value));

    // Here 3 is maximum of 3 digits before the decimal point
    const base = Math.floor(logBaseValue / 3);
    if (logBaseValue >= 3 && base < suffix.length) {
      return +(value / Math.pow(10 , base * 3)).toFixed(1) + suffix[base];
    }
    return value.toString();
  }

}
