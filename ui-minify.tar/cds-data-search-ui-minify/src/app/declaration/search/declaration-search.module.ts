import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchSectionComponent } from './search-section/search-section.component';
import { SearchFormComponent } from './search-form/search-form.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule } from '@angular/material/dialog';
import { MatListModule } from '@angular/material/list';
import { MatChipsModule } from '@angular/material/chips';
import { MatInputModule } from '@angular/material/input';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatExpansionModule } from '@angular/material/expansion';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SearchService } from './search.service';
import { HttpClientModule } from '@angular/common/http';
import { DeclarationCardComponent } from './declaration-card/declaration-card.component';
import { SearchFilterComponent } from './search-filter/search-filter.component';
import { FacetedSearchComponent } from './search-filter/faceted-search/faceted-search.component';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import {
  MatDividerModule,
  MatDatepickerModule,
  MatFormFieldModule,
  MAT_DATE_LOCALE,
  MatTabsModule,
  MatPaginatorModule, MatPaginatorIntl, MatTooltipModule
} from '@angular/material';
import { FacetNotMatchingPipe } from './facet-not-matching.pipe';
import { DateRangeComponent } from './search-filter/date-range/date-range.component';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { SearchCriteriaService } from './search-criteria.service';
import { NavigationService } from './navigation.service';
import { ChipsComponent } from './search-filter/chips/chips.component';
import { LinksFacetComponent } from './search-filter/links-facet/links-facet.component';
import { FacetService } from './facet.service';
import { DeclarationDetailComponent } from '../detail/declaration-detail.component';
import { RouterModule } from '@angular/router';
import { ResourceModule } from '../../resource/resource.module';
import { DeclarationService } from '../detail/declaration.service';
import { DeclarationItemDetailComponent } from '../detail/items/declaration-item-detail.component';
import { ElementsLibraryModule } from '../../elements-library/elements-library.module';
import { SearchPaginatorComponent } from './search-paginator/search-paginator.component';
import {SearchPaginatorIntl} from './search-paginator/search-paginator';
import {BreadcrumbComponent} from '../breadcrumb/breadcrumb.component';
import {RemovespaceLowercasePipe} from '../breadcrumb/removespace-lowercase.pipe';
import {SearchFieldComponent} from './search-filter/search-field/search-field.component';
import { FormatCountPipe } from './format-count.pipe';
import { StickyPolyfillDirective } from './sticky-directive';
import { LOCATION_TOKEN } from '../../authentication/sign-in/sign-in-router.service';
import { TogglePanelService } from './search-filter/toggle-panel.service';
import { DefinitionService } from './definition.service';
import { CheckboxesComponent } from './search-filter/checkboxes/checkboxes.component';
import { NumberRangeComponent } from './search-filter/number-range/number-range.component';
import { ExtractCsvComponent } from './extract-csv/extract-csv.component';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    MatButtonModule,
    MatInputModule,
    MatTabsModule,
    MatCheckboxModule,
    MatListModule,
    MatChipsModule,
    MatDialogModule,
    MatCardModule,
    MatIconModule,
    MatGridListModule,
    MatDividerModule,
    MatExpansionModule,
    MatDatepickerModule,
    MatMomentDateModule,
    MatFormFieldModule,
    MatPaginatorModule,
    BrowserAnimationsModule,
    MatTooltipModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule,
    ResourceModule,
    ElementsLibraryModule
  ],
  declarations: [
    SearchSectionComponent,
    SearchFormComponent,
    DeclarationCardComponent,
    SearchFilterComponent,
    FacetedSearchComponent,
    FacetNotMatchingPipe,
    ChipsComponent,
    DateRangeComponent,
    NumberRangeComponent,
    LinksFacetComponent,
    DeclarationDetailComponent,
    DeclarationItemDetailComponent,
    SearchPaginatorComponent,
    BreadcrumbComponent,
    RemovespaceLowercasePipe,
    SearchFieldComponent,
    FormatCountPipe,
    StickyPolyfillDirective,
    CheckboxesComponent,
    ExtractCsvComponent],
  exports: [SearchSectionComponent],
  entryComponents: [FacetedSearchComponent , ExtractCsvComponent],
  providers: [
    { provide: MAT_DATE_LOCALE, useValue: 'en-GB' },
    { provide: LOCATION_TOKEN, useValue: window.location },
    SearchService,
    SearchCriteriaService,
    TogglePanelService,
    NavigationService,
    FacetService,
    DeclarationService,
    DefinitionService,
    {provide: MatPaginatorIntl, useClass: SearchPaginatorIntl}
  ]
})
export class DeclarationSearchModule { }

