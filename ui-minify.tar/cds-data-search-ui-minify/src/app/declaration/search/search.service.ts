import {Injectable} from '@angular/core';
import {SearchCriteria} from './search-criteria';
import {SearchParamsBuilder} from './search-params-builder';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {DeclarationSearchResult} from './declaration-search-result';
import {ViewDefinition} from '../../elements-library/cds-data-grid/view-definition';

@Injectable()
export class SearchService {

  constructor(private http: HttpClient) {}

  declarationPreviewDefinition(): Observable<ViewDefinition[]> {
    return this.http
      .get('/api/search/definition')
      .pipe(
        map(ViewDefinition.objectsToViewDefinition)
      );
  }

  search(search: SearchCriteria): Observable<DeclarationSearchResult> {
    return this.http
      .get('/api/search', { params: SearchParamsBuilder.toHttpParams(search) })
      .pipe(
        map(searchResult => searchResult as DeclarationSearchResult)
      );
  }

  downloadCsv(search: SearchCriteria, filteredFields: Array<string>): Observable<String> {
    return this.http
      .post('/api/declarations', { fields: filteredFields }, {
        headers: new HttpHeaders({ 'Accept': 'text/csv' }),
        params: SearchParamsBuilder.toHttpParams(search),
        responseType: 'text'
      });
  }
}
