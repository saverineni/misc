import { SearchCriteria } from './search-criteria';
import { SearchParamsBuilder } from './search-params-builder';
import { HttpParams } from '@angular/common/http';

describe('SearchParamsBuilder', () => {
  let searchCriteria: SearchCriteria;
  let expectedParams: HttpParams;

  beforeEach(() => {
    searchCriteria = new SearchCriteria();
  });

  afterEach(() => {
    const result = SearchParamsBuilder.toHttpParams(searchCriteria);
    expect(result).toEqual(expectedParams);
  });

  it('should add the criteria properties to the params', () => {
    searchCriteria.searchTerm = '123-456';
    searchCriteria.entryDateFrom = '2018-01-01';
    searchCriteria.entryDateTo = '2018-01-02';
    searchCriteria.originCountryCode = ['A', 'B', 'C'];
    searchCriteria.dispatchCountryCode = ['D', 'B', 'C'];
    searchCriteria.destinationCountryCode = ['A', 'B', 'C'];
    searchCriteria.transportModeCode = ['A', 'B', 'C'];
    searchCriteria.goodsLocation = ['A', 'B', 'C'];
    searchCriteria.declarationType = ['X', 'Y', 'Z'];

    expectedParams = new HttpParams({ fromObject: {
      searchTerm: '123-456',
      entryDateFrom: '2018-01-01',
      entryDateTo: '2018-01-02',
      originCountryCode: ['A', 'B', 'C'],
      dispatchCountryCode: ['D', 'B', 'C'],
      destinationCountryCode: ['A', 'B', 'C'],
      transportModeCode: ['A', 'B', 'C'],
      goodsLocation: ['A', 'B', 'C'],
      declarationType: ['X', 'Y', 'Z']
    }});
  });

  it('should not add the null criteria values to the params', () => {
    searchCriteria.searchTerm = '123-456';
    searchCriteria.entryDateTo = '2018-01-02';
    searchCriteria.originCountryCode = ['A', 'B', 'C'];
    searchCriteria.goodsLocation = ['A', 'B', 'C'];
    searchCriteria.declarationType = ['X', 'Y', 'Z'];

    expectedParams = new HttpParams({ fromObject: {
      searchTerm: '123-456',
      entryDateTo: '2018-01-02',
      originCountryCode: ['A', 'B', 'C'],
      goodsLocation: ['A', 'B', 'C'],
      declarationType: ['X', 'Y', 'Z']
    }});
  });
});
