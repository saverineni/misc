import {NavigationService} from './navigation.service';
import {SearchCriteria} from './search-criteria';
import {Observable, of} from 'rxjs';
import {ActivatedRoute, convertToParamMap, ParamMap, Params, Router} from '@angular/router';
import {SearchCriteriaService} from './search-criteria.service';

describe('NavigationService', () => {
  let navigationService: NavigationService;
  let searchCriteriaServiceStub: SearchCriteriaService;
  let testSearchCriteriaObservable: Observable<SearchCriteria>;
  let testQueryParamsObservable: Observable<Params>;

  let testActivatedRoute;

  let navigateForEachHandler;
  let successSearchCriteriaHandler;
  let successQueryParamsHandler;

  let testRouter: Router;

  beforeEach(() => {
    testSearchCriteriaObservable = of(null);
      spyOn(testSearchCriteriaObservable, 'subscribe')
          .and.callFake(success => successSearchCriteriaHandler = success);
      spyOn(testSearchCriteriaObservable, 'forEach')
          .and.callFake(success => navigateForEachHandler = success);

      searchCriteriaServiceStub = {
        searchCriteria: testSearchCriteriaObservable,
        update: (criteria) => {}
      } as SearchCriteriaService;
      spyOn(searchCriteriaServiceStub, 'update');

      testQueryParamsObservable = of(null);
      spyOn(testQueryParamsObservable, 'subscribe')
          .and.callFake(success => successQueryParamsHandler = success);

      testActivatedRoute = {
        queryParamMap: testQueryParamsObservable
      } as ActivatedRoute;
  });

  describe('initially', () => {

    beforeEach(() => {
      testRouter = {
        url: '/declarations',
        navigate: (commands, extras) => {},
        navigated: false
      } as Router;

      spyOn(testRouter, 'navigate');
      navigationService = new NavigationService(searchCriteriaServiceStub, testRouter, testActivatedRoute);
    });

    describe('search criteria', () => {
      it('should not trigger on the initial load', () => {
        const searchCriteria = new SearchCriteria();
        successSearchCriteriaHandler(searchCriteria);
        expect(testRouter.navigate).not.toHaveBeenCalled();
      });
    });

    describe('query params', () => {
      it('should only trigger for the root path', () => {
        const paramMap: ParamMap = convertToParamMap({
          searchTerm: 'term'
        });
        successQueryParamsHandler(paramMap);
        expect(searchCriteriaServiceStub.update).not.toHaveBeenCalled();
      });
    });

  });

  describe('after creation', () => {

    beforeEach(() => {
      testRouter = {
        url: '/',
        navigate: (commands, extras) => {},
        navigated: true
      } as Router;

      spyOn(testRouter, 'navigate');
      navigationService = new NavigationService(searchCriteriaServiceStub, testRouter, testActivatedRoute);
    });

    describe('navigate to search', () => {

      it('should clear search criteria when clear params is true', () => {
        navigationService.navigateToSearch(true);
        const search = new SearchCriteria();
        navigateForEachHandler(search);

        expect(searchCriteriaServiceStub.update).toHaveBeenCalledWith(search);
        expect(testRouter.navigate).toHaveBeenCalledWith(['/'], { queryParams: search });
      });

      it('should route to search with current params when clear params is false', () => {
        const search = new SearchCriteria();
        search.searchTerm = 'test';
        navigationService.navigateToSearch(false);
        navigateForEachHandler(search);

        expect(searchCriteriaServiceStub.update).not.toHaveBeenCalled();
        expect(testRouter.navigate).toHaveBeenCalledWith(['/'], { queryParams: search });
      });

    });

    describe('search criteria', () => {
      it('should subscribe to successful updates', () => {
        expect(successSearchCriteriaHandler).toBeTruthy();
      });

      it('should navigate for the params' , () => {
        const searchCriteria = new SearchCriteria();
        successSearchCriteriaHandler(searchCriteria);
        expect(testRouter.navigate).toHaveBeenCalledWith(['/'], {queryParams: searchCriteria});
      });
    });

    describe('navigate to help', () => {

      it('should navigate to help url', () => {
        navigationService.navigateToHelp();
        expect(testRouter.navigate).toHaveBeenCalledWith(['/help']);
      });

    });

    describe('query params', () => {
      let paramMap: ParamMap;

      it('should subscribe to successful updates', () => {
        expect(successQueryParamsHandler).toBeTruthy();
      });

      it('should update the search criteria' , () => {
        paramMap = convertToParamMap({
          searchTerm: 'term',
          originCountryCode: ['AB', 'CD'],
          dispatchCountryCode: ['EF'],
          destinationCountryCode: ['GH'],
          transportModeCode: ['mode'],
          goodsLocation: ['gl1'],
          commodityCode: [ 'commodity', 'com2'],
          cpc: ['1234567', '9876543'],
          entryDateFrom: '2018-01-01',
          entryDateTo: '2018-01-02',
          clearanceDateFrom: '2018-01-01',
          clearanceDateTo: '2018-01-02',
          acceptanceDateFrom: '2018-01-01',
          acceptanceDateTo: '2018-01-02',
          netMassFrom: '1.2',
          netMassTo: '2.3',
          itemPriceFrom: '2.2',
          itemPriceTo: '3.3',
          eori: '352198460269',
          declarationType: [ 'X', 'Y'],
          declarationSource: [ 'CHIEF', 'CDS'],
          processingStatus: [ '4', '12'],
          pageNumber: '1',
          pageSize: '10',
          preferenceNumber: [ '123', '234' ]
        });

        const searchCriteria = new SearchCriteria();
        searchCriteria.searchTerm = 'term';
        searchCriteria.originCountryCode =  ['AB', 'CD'];
        searchCriteria.dispatchCountryCode =  ['EF'];
        searchCriteria.destinationCountryCode =  ['GH'];
        searchCriteria.transportModeCode =  ['mode'];
        searchCriteria.goodsLocation = ['gl1'],
        searchCriteria.commodityCode = [ 'commodity', 'com2'],
        searchCriteria.cpc = [ '1234567', '9876543'],
        searchCriteria.declarationType = [ 'X', 'Y'],
        searchCriteria.declarationSource = [ 'CHIEF', 'CDS'],
        searchCriteria.processingStatus = [ '4', '12'],
        searchCriteria.entryDateFrom = '2018-01-01';
        searchCriteria.entryDateTo = '2018-01-02';
        searchCriteria.clearanceDateFrom = '2018-01-01';
        searchCriteria.clearanceDateTo = '2018-01-02';
        searchCriteria.acceptanceDateFrom = '2018-01-01';
        searchCriteria.acceptanceDateTo = '2018-01-02';
        searchCriteria.netMassFrom = '1.2';
        searchCriteria.netMassTo = '2.3';
        searchCriteria.itemPriceFrom = '2.2';
        searchCriteria.itemPriceTo = '3.3';
        searchCriteria.eori = '352198460269';
        searchCriteria.pageNumber = 1;
        searchCriteria.pageSize = 10;
        searchCriteria.preferenceNumber = [ '123', '234' ];

        successQueryParamsHandler(paramMap);
        expect(searchCriteriaServiceStub.update).toHaveBeenCalledWith(searchCriteria);
      });

      it('should update as null for an empty array' , () => {
        paramMap = convertToParamMap({searchTerm: 'term'});
        const searchCriteria = new SearchCriteria();
        searchCriteria.searchTerm = 'term';
        searchCriteria.entryDateFrom = null;  searchCriteria.entryDateTo = null;
        searchCriteria.clearanceDateFrom = null;  searchCriteria.clearanceDateTo = null;
        searchCriteria.acceptanceDateFrom = null; searchCriteria.acceptanceDateTo = null;
        searchCriteria.netMassFrom = null; searchCriteria.netMassTo = null;
        searchCriteria.itemPriceFrom = null; searchCriteria.itemPriceTo = null;
        searchCriteria.eori = null;

        successQueryParamsHandler(paramMap);
        expect(searchCriteriaServiceStub.update).toHaveBeenCalledWith(searchCriteria);
      });
    });
  });
});
