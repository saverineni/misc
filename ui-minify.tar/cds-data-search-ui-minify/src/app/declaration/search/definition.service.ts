import { Injectable } from '@angular/core';
import { ViewDefinition } from '../../elements-library/cds-data-grid/view-definition';
import { DeclarationService } from '../detail/declaration.service';
import { Observable } from 'rxjs';
import { shareReplay } from 'rxjs/operators';
import { SearchService } from './search.service';

@Injectable()
export class DefinitionService {

  constructor(private searchService: SearchService, private declarationService: DeclarationService) {
    this._declarationPreviewDefinition = this.searchService.declarationPreviewDefinition().pipe(shareReplay(1));
    this._declarationDefinition = this.declarationService.declarationDefinition().pipe(shareReplay(1));
    this._declarationItemDefinition = this.declarationService.declarationItemDefinition().pipe(shareReplay(1));
  }

  private _declarationPreviewDefinition: Observable<ViewDefinition[]>;
  private _declarationDefinition: Observable<ViewDefinition[]>;
  private _declarationItemDefinition: Observable<ViewDefinition[]>;

  getDeclarationPreviewDefinition(): Observable<ViewDefinition[]> {
    return this._declarationPreviewDefinition;
  }

  getDeclarationDefinition(): Observable<ViewDefinition[]> {
    return this._declarationDefinition;
  }

  getDeclarationItemDefinition(): Observable<ViewDefinition[]> {
    return this._declarationItemDefinition;
  }

}
