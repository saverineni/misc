import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {FacetedSearchComponent, SelectableFacet} from './faceted-search.component';
import {MatDialogModule} from '@angular/material/dialog';
import {MAT_DIALOG_DATA, MatChipsModule, MatDialogRef, MatIconModule, MatTooltipModule} from '@angular/material';
import {By} from '@angular/platform-browser';
import {DebugElement} from '@angular/core/src/debug/debug_node';
import {MatListModule} from '@angular/material/list';
import {FacetNotMatchingPipe} from '../../facet-not-matching.pipe';
import {FormsModule} from '@angular/forms';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatInputModule} from '@angular/material/input';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {SearchCriteriaService} from '../../search-criteria.service';
import {SearchCriteria} from '../../search-criteria';
import {Observable, of, Subscription} from 'rxjs';
import {FacetService} from '../../facet.service';
import {Facet} from '../../facets';
import { FormatCountPipe } from '../../format-count.pipe';

function newFacet(code, count) {
  return {
    id: code,
    count: count,
    selected: false,
    label: code === '' ? 'Unspecified' : code
  };
}

const FACET1_NAME = 'facet1';
const FACET2_NAME = 'facet2';
const FACET3_NAME = 'AB_facet';
const FACET4_NAME = 'AD_facet';
const FACET5_NAME = 'facet5';
const FACET6_NAME = '';
const FACET7_NAME = 'DE_facet';
const FACET8_NAME = 'FG_facet';
const FACET9_NAME = 'KL_facet';

const facetLabels = [`${FACET1_NAME} (4)`, `${FACET2_NAME} (3)`, `${FACET3_NAME} (1)`, `${FACET4_NAME} (1)`,
  `${FACET5_NAME} (1)`, 'Unspecified (1)', `${FACET7_NAME} (1K)`, `${FACET8_NAME} (145.7M)` , `${FACET9_NAME} (1B)`];
const searchParam = 'originCountryCode';
const facetType = 'FacetType';
const tooTipText = `hello
                          tooltip`;

describe('FacetedSearchComponent', () => {
  let component: FacetedSearchComponent;
  let fixture: ComponentFixture<FacetedSearchComponent>;
  let matDialogRef: MatDialogRef<any>;
  let facets: Array<SelectableFacet>;
  let searchCriteriaService: SearchCriteriaService;
  let testSubscription: Subscription;
  let testObservable: Observable<SearchCriteria>;
  let successHandler;
  let facetService: FacetService;
  let facetObservable: Observable<Array<Facet>>;
  let displayedFacets;

  beforeEach(async(() => {
    matDialogRef = { close: () => { } } as MatDialogRef<any>;
    spyOn(matDialogRef, 'close');

    facets = [
      newFacet(FACET1_NAME, 4),
      newFacet(FACET2_NAME, 3),
      newFacet(FACET3_NAME, 1),
      newFacet(FACET4_NAME, 1),
      newFacet(FACET5_NAME, 1),
      newFacet(FACET6_NAME, 1),
      newFacet(FACET7_NAME, 1000),
      newFacet(FACET8_NAME, 145700000),
      newFacet(FACET9_NAME, 1000000000)
    ];

    testObservable = of(null);
    testSubscription = new Subscription();

    spyOn(testObservable, 'subscribe').and.callFake(
      success => {
        successHandler = success;
        return testSubscription;
      }
    );
    spyOn(testSubscription, 'unsubscribe');

    searchCriteriaService = {
      searchCriteria: testObservable,
      updatePartial: (searchCriteria) => { }
    } as SearchCriteriaService;
    spyOn(searchCriteriaService, 'updatePartial');

    facetObservable = of(facets);
    facetService = {
      getFacets: (facet, filter, criteria) => facetObservable
    } as FacetService;
    spyOn(facetService, 'getFacets').and.callThrough();

    TestBed.configureTestingModule({
      imports: [
        MatDialogModule,
        MatChipsModule,
        MatIconModule,
        MatTooltipModule,
        MatListModule,
        MatInputModule,
        FlexLayoutModule,
        BrowserAnimationsModule,
        FormsModule
      ],
      declarations: [FacetedSearchComponent, FacetNotMatchingPipe, FormatCountPipe],
      providers: [
        { provide: MatDialogRef, useValue: matDialogRef },
        { provide: SearchCriteriaService, useValue: searchCriteriaService },
        { provide: FacetService, useValue: facetService },
        {
          provide: MAT_DIALOG_DATA, useValue: {
            facets: facets,
            searchParam: searchParam,
            facetType: facetType,
            toolTipText: tooTipText
          }
        }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(FacetedSearchComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  }));

  beforeEach(() => {
    displayedFacets = () => {
      const facetElements = fixture.debugElement.queryAll(By.css('.faceted-search__link'));
      return facetElements.map(facetElement => facetElement.nativeElement.textContent);
    };
  });

  describe('given list of facets', () => {

    describe('on initialisation', () => {
      it('should subscribe to search criteria updates', () => {
        expect(successHandler).toBeTruthy();
      });

      it('should have focus on the search input', () => {
        const facetedSearchDebugElement = fixture.debugElement.query(By.css('.faceted-search'));
        const facetedSearch = facetedSearchDebugElement.nativeElement as HTMLElement;

        const searchFilter = facetedSearchDebugElement.query(By.css('.faceted-search__filter')).nativeElement as HTMLElement;
        const focusedElement = facetedSearch.querySelector(`[cdk-focus-initial], ` + `[cdkFocusInitial]`) as HTMLElement;
        expect(searchFilter).toBe(focusedElement);
      });
    });

    describe('on destroy', () => {
      beforeEach(() => {
        fixture.destroy();
      });

      it('should unsubscribe from search criteria updates', () => {
        expect(testSubscription.unsubscribe).toHaveBeenCalled();
      });
    });

    function selectFacet(facetId) {
      const link = fixture.debugElement.query(By.css(`.faceted-search__link[data-facet-id="${facetId}"]`)).nativeElement;
      link.click();
      return link;
    }

    it('should display title', () => {
      const title: HTMLElement = fixture.debugElement.query(By.css('.faceted-search__header__title')).nativeElement;
      expect(title.textContent).toEqual(`Select ${facetType}`);
    });

    it('should display data on load', () => {
      expect(displayedFacets()).toEqual(facetLabels);
    });

    it('should not contain any chips on load', () => {
      const chips: DebugElement[] = fixture.debugElement.queryAll(By.css('.faceted-search__selection'));
      expect(chips.length).toBe(0);
    });

    it('should have a label for free text search field', () => {
      const searchTerm = fixture.debugElement.query(By.css('.faceted-search__filter'));
      expect(searchTerm.nativeElement.labels[0].textContent).toEqual(`Search for a ${facetType}`);
    });

    describe('tool tip exists', () => {

      it('should display the tool tip icon', () => {
        expect(fixture.debugElement.query(By.css('.faceted-search__header__tooltip__icon')).nativeElement.textContent).toEqual('i');
      });

      it('should display the tool tip text', () => {
        fixture.debugElement.query(By.css('.faceted-search__header__tooltip__icon')).nativeElement.dispatchEvent(new Event('mouseenter'));
        fixture.detectChanges();

        expect(fixture.debugElement.query(By.css('.faceted-search__header__tooltip__text')).nativeElement.textContent).toEqual(tooTipText);
      });
    });

    describe('existing facet selection', () => {
      let chips: DebugElement[];
      beforeEach(() => {
        const newSearchCriteria = new SearchCriteria();
        newSearchCriteria[searchParam] = ['facet2', ''];
        successHandler(newSearchCriteria);
        fixture.detectChanges();
        chips = fixture.debugElement.queryAll(By.css('.faceted-search__selection-text'));
      });

      it('should have focus on the input box', () => {
        const facetedSearchDebugElement = fixture.debugElement.query(By.css('.faceted-search'));
        const facetedSearch = facetedSearchDebugElement.nativeElement as HTMLElement;

        const searchFilter = facetedSearchDebugElement.query(By.css('.faceted-search__filter')).nativeElement as HTMLElement;
        const focusedElement = facetedSearch.querySelector(`[cdk-focus-initial], ` + `[cdkFocusInitial]`) as HTMLElement;
        expect(searchFilter).toBe(focusedElement);
      });

      it('should be displayed as chips', () => {
        const chipTexts = chips.map(it => it.nativeElement.textContent.trim());
        expect(chipTexts).toEqual(['facet2', 'Unspecified']);
      });
    });

    describe('clicking cancel', () => {
      let cancelButton;

      beforeEach(() => {
        cancelButton = fixture.debugElement.query(By.css('.faceted-search__cancel')).nativeElement as HTMLInputElement;
        cancelButton.click();
      });

      it('closes dialog', () => {
        expect(matDialogRef.close).toHaveBeenCalled();
      });

      it('should not update the criteria', () => {
        expect(searchCriteriaService.updatePartial).not.toHaveBeenCalledWith();
      });
    });

    describe('apply filters', () => {
      let applyFiltersButton;

      beforeEach(() => {
        applyFiltersButton = fixture.debugElement.query(By.css('.faceted-search__apply-filters'));
      });

      describe('disabled when selection unchanged', () => {
        it('should start disabled', () => {
          expect(applyFiltersButton.nativeElement.disabled).toBe(true);
        });

        it('should be enabled when a filter is selected', () => {
          selectFacet(FACET1_NAME);
          fixture.detectChanges();
          expect(applyFiltersButton.nativeElement.disabled).toBe(false);
        });

        it('should be disabled if the selection is the same as it started when clicking the mat icon', () => {
          selectFacet(FACET1_NAME);
          fixture.detectChanges();
          fixture.debugElement.query(
            By.css(`.faceted-search__selection[data-facet-id="${FACET1_NAME}"] .faceted-search__selection-remove`)
          ).nativeElement.click();
          fixture.detectChanges();

          expect(applyFiltersButton.nativeElement.disabled).toBe(true);
        });

        it('should be disabled if the selection is the same as it started when clicked anywhere in the text area', () => {
          selectFacet(FACET1_NAME);
          fixture.detectChanges();
          fixture.debugElement.query(
            By.css(`.faceted-search__selection[data-facet-id="${FACET1_NAME}"] .faceted-search__selection-text`)
          ).nativeElement.click();
          fixture.detectChanges();

          expect(applyFiltersButton.nativeElement.disabled).toBe(true);
        });

      });

      describe('with selection', () => {
        beforeEach(() => {
          const searchCriteria = new SearchCriteria();
          searchCriteria[searchParam] = [FACET5_NAME];
          successHandler(searchCriteria);
          selectFacet(FACET6_NAME);
          selectFacet(FACET3_NAME);
          selectFacet(FACET1_NAME);
          fixture.detectChanges();

          applyFiltersButton.nativeElement.click();
          fixture.detectChanges();
        });

        it('should call the update method of the criteria service with facets in the correct selected order', () => {
          const searchCriteria = {};
          searchCriteria[searchParam] = [FACET5_NAME, FACET6_NAME, FACET3_NAME , FACET1_NAME];
          searchCriteria['pageNumber'] = undefined;
          searchCriteria['pageSize'] = undefined;

          expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteria);
        });

        it('should close the dialog', () => {
          expect(matDialogRef.close).toHaveBeenCalled();
        });
      });

      describe('removing all selected facets', () => {
        beforeEach(() => {
          // set a current selection
          const searchCriteria = new SearchCriteria();
          searchCriteria[searchParam] = [FACET1_NAME];
          successHandler(searchCriteria);
          fixture.detectChanges();

          // remove the selection
          fixture.debugElement.query(
            By.css(`.faceted-search__selection[data-facet-id="${FACET1_NAME}"] .faceted-search__selection-remove`)
          ).nativeElement.click();

          // apply the removed filter
          fixture.detectChanges();
          applyFiltersButton.nativeElement.click();
        });

        it('should set null value to the search criteria', () => {
          const searchCriteria = {};
          searchCriteria[searchParam] = null;
          searchCriteria['pageNumber'] = undefined;
          searchCriteria['pageSize'] = undefined;
          expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteria);
        });
      });
    });

    describe('user selects facet in list', () => {
      let facet1Link: HTMLInputElement;

      beforeEach(() => {
        facet1Link = selectFacet(FACET1_NAME);
        fixture.detectChanges();
      });

      it('should disable facet link when selected', () => {
        const disabledLink = fixture.debugElement.query(By.css(`.faceted-search__link--selected[data-facet-id="${FACET1_NAME}"]`));

        expect(disabledLink).toBeTruthy();
      });

      describe('selected facet chip', () => {
        let chips: DebugElement[];
        beforeEach(() => {
          chips = fixture.debugElement.queryAll(By.css('.faceted-search__selection-text'));
        });

        it('should be displayed', () => {
          expect(chips.length).toBe(1);
        });

        it('should display the facet details', () => {
          const facet1Chip: HTMLElement = chips[0].nativeElement;
          expect(facet1Chip.textContent.trim()).toBe('facet1');
        });

        describe('user clicks chips', () => {

          describe('anywhere in the chip area' , () => {
            beforeEach(() => {
              selectFacet(FACET2_NAME);
              fixture.detectChanges();

              const removefacet1Chip = fixture.debugElement.query(By.css(
                `.faceted-search__selection[data-facet-id="${FACET1_NAME}"] .faceted-search__selection-text`)
              ).nativeElement as HTMLInputElement;
              expect(removefacet1Chip).toBeTruthy();
              removefacet1Chip.click();

              fixture.detectChanges();
            });

            it('should remove the chip', () => {
              const chipsElement = fixture.debugElement.queryAll(By.css('.faceted-search__selection'));

              expect(chipsElement.length).toBe(1);
              expect(chipsElement[0].nativeElement.getAttribute('data-facet-id')).toBe(FACET2_NAME);
            });

            it('should re-enable facet link when chip is removed', () => {
              const gbLink = fixture.debugElement.query(By.css(`.faceted-search__link--selected[data-facet-id="${FACET1_NAME}"]`));

              expect(gbLink == null).toBeTruthy();
            });
          });

          describe('on the mat icon' , () => {
            beforeEach(() => {
              selectFacet(FACET2_NAME);
              fixture.detectChanges();

              const removefacet1Chip = fixture.debugElement.query(By.css(
                `.faceted-search__selection[data-facet-id="${FACET1_NAME}"] .faceted-search__selection-remove`)
              ).nativeElement as HTMLInputElement;
              expect(removefacet1Chip).toBeTruthy();
              removefacet1Chip.click();

              fixture.detectChanges();
            });

            it('should remove the chip', () => {
              const chipsElement = fixture.debugElement.queryAll(By.css('.faceted-search__selection'));

              expect(chipsElement.length).toBe(1);
              expect(chipsElement[0].nativeElement.getAttribute('data-facet-id')).toBe(FACET2_NAME);
            });

            it('should re-enable facet link when chip is removed', () => {
              const gbLink = fixture.debugElement.query(By.css(`.faceted-search__link--selected[data-facet-id="${FACET1_NAME}"]`));

              expect(gbLink == null).toBeTruthy();
            });
          });

        });
      });
    });

    describe('filter selection list', () => {
      let facetFilter;

      afterEach(() => {
        expect(facetService.getFacets).not.toHaveBeenCalled();
      });

      describe('no search results', () => {
        beforeEach(() => {
          fixture.detectChanges();

          facetFilter = fixture.debugElement.query(By.css('.faceted-search__filter')).nativeElement;
          facetFilter.value = 'zzz';
          facetFilter.dispatchEvent(new Event('input'));
          fixture.detectChanges();
        });

        it('displays the no results found message', () => {
          const noResults = fixture.debugElement.query(By.css('.faceted-search__no-results-found')).nativeElement;
          expect(noResults.textContent).toBe('No results found.');
        });

        it('hides all the facets', () => {
          const hiddenFacetList = fixture.debugElement.queryAll(By.css('.faceted-search__link--hidden'));
          expect(hiddenFacetList.length).toEqual(9);
        });
      });

      describe('has search results', () => {
        beforeEach(() => {
          fixture.detectChanges();

          facetFilter = fixture.debugElement.query(By.css('.faceted-search__filter')).nativeElement;
          facetFilter.value = 'A';
          facetFilter.dispatchEvent(new Event('input'));
          fixture.detectChanges();
        });

        it('should only show items that start with the search term', () => {
          const hiddenFacetElements = fixture.debugElement.queryAll(By.css('.faceted-search__link--hidden'));
          const hiddenFacetNames = hiddenFacetElements.map(facetElement => facetElement.nativeElement.textContent);

          expect(hiddenFacetNames).toEqual([facetLabels[0], facetLabels[1], facetLabels[4], facetLabels[5],
            facetLabels[6], facetLabels[7], facetLabels[8]]);
        });

        it('should not display no results found message', () => {
          const noResults = fixture.debugElement.query(By.css('.faceted-search__no-results-found'));
          expect(noResults == null).toBeTruthy();
        });

        describe('and remove the term', () => {

          it('should display all the results', () => {
            facetFilter.value = '';
            facetFilter.dispatchEvent(new Event('input'));
            fixture.detectChanges();

            expect(displayedFacets()).toEqual(facetLabels);
          });
        });
      });
    });
  });
});
