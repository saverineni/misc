import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  Inject, Input,
  OnDestroy,
  OnInit,
  ViewEncapsulation
} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {FacetNotMatchingPipe} from '../../facet-not-matching.pipe';
import {SearchCriteriaService} from '../../search-criteria.service';
import {Subscription} from 'rxjs';
import {SearchCriteria} from '../../search-criteria';
import {Facet} from '../../facets';
import {TrackBy} from '../../../../track-by';
import {FacetService} from '../../facet.service';

export interface SelectableFacet extends Facet {
  label: string;
  selected: boolean;
}

@Component({
  selector: 'cds-faceted-search',
  templateUrl: './faceted-search.component.html',
  styleUrls: ['./faceted-search.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class FacetedSearchComponent implements OnInit, OnDestroy {
  private criteriaUpdatesSubscription: Subscription;
  private searchParam: string;

  trackByFacetId = TrackBy.property('id');

  facetType: string;
  facets: Array<SelectableFacet>;
  selectedFacets: Set<string> = new Set();
  toolTipText: any;
  categories: Array<string>;
  categoriesFilters: Array<string>;

  private facetSearch: any;
  private searchCriteria: SearchCriteria;
  private previousFilterValue = '';

  constructor( @Inject(MAT_DIALOG_DATA) data,
               private searchCriteriaService: SearchCriteriaService,
               private facetService: FacetService,
               private dialogRef: MatDialogRef<FacetedSearchComponent>,
               private changeDetectorRef: ChangeDetectorRef) {

    if (data.facets) {
      this.addSelectableFacets(data.facets);
    } else {
      this.facetSearch = data.facetSearch;
    }

    this.searchParam = data.searchParam;
    this.facetType = data.facetType;
    this.toolTipText = data.toolTipText;
    this.categories = data.categories;
    this.categoriesFilters = data.categoriesFilters;
  }

  private addSelectableFacets(facets) {
    this.facets = facets.map(facet => ({
      label: facet.id === '' ? 'Unspecified' : facet.id,
      selected: false,
      id: facet.id,
      count: facet.count
    } as SelectableFacet));
  }

  ngOnInit() {
    this.criteriaUpdatesSubscription = this.searchCriteriaService.searchCriteria.subscribe(
      newCriteria => {
        this.searchCriteria = newCriteria;
        this.addSelectionsToFacets();
      }
    );
  }

  private addSelectionsToFacets() {
    if (this.searchCriteria[this.searchParam]) {
      this.selectedFacets = new Set<string>(this.searchCriteria[this.searchParam]);
      if (this.facets) {
        this.markSelectedFacets();
      }
    }
    this.changeDetectorRef.detectChanges();
  }

  ngOnDestroy() {
    this.criteriaUpdatesSubscription.unsubscribe();
  }

  onDeselect(facetId) {
    this.selectedFacets.delete(facetId as string);
    this.facets.find(it => it.id === facetId).selected = false;
  }

  onSelect(facet) {
    this.selectedFacets.add(facet.id as string);
    facet.selected = true;
  }

  filtersNotChanged() {
    let currentCriteria;
    if (this.searchCriteria && this.searchCriteria[this.searchParam]) {
      currentCriteria = this.searchCriteria[this.searchParam];
    } else {
      currentCriteria = [];
    }
    return JSON.stringify(Array.from(this.selectedFacets).sort()) === JSON.stringify(Array.from(currentCriteria).sort());
  }

  applyFilters() {
    const update = {};
    if (this.selectedFacets.size > 0) {
      update[this.searchParam] = Array.from(this.selectedFacets);
    } else {
      update[this.searchParam] = null;
    }
    update['pageNumber'] = undefined;
    update['pageSize'] = undefined;

    this.searchCriteriaService.updatePartial(update);
    this.dialogRef.close();
  }

  nonMatching(filter) {
    return this.facets == null || this.facets.find(facet => FacetNotMatchingPipe.matching(facet, filter)) === undefined;
  }

  noResultsMessage() {
    if (this.facetSearch && !this.facets) {
      return `Enter at least ${this.facetSearch.length} ${this.facetSearch.type} to bring back results.`;
    } else {
      return 'No results found.';
    }
  }

  onFilterInput(filter: string) {
    if (this.facetSearch) {
      if (this.isNewFilterRequest(filter)) {
        this.facetService.getFacets(this.searchParam, filter.substring(0, this.facetSearch.length), this.searchCriteria)
          .subscribe(facets => {
            this.addSelectableFacets(facets);
            this.addSelectionsToFacets();
            this.markSelectedFacets();
            this.changeDetectorRef.detectChanges();
          }
        );
      }

      if (!this.filterLongEnough(filter)) {
        this.facets = null;
        this.changeDetectorRef.detectChanges();
      }

      this.previousFilterValue = filter;
    }
  }

  markSelectedFacets() {
    this.facets.forEach(facet => {
      if (this.selectedFacets.has(facet.id as string)) {
        facet.selected = true;
      }
    });
  }

  private isNewFilterRequest(filter) {
    return this.filterLongEnough(filter) &&
           this.previousFilterNotLongEnough() &&
           !this.previousSearchMade();
  }
  private filterLongEnough(filter) {
    return filter.length >= this.facetSearch.length;
  }

  private previousFilterNotLongEnough() {
    return this.previousFilterValue.length < this.facetSearch.length;
  }

  private previousSearchMade() {
    return this.previousFilterValue.length >= this.facetSearch.length;
  }

  filterFacets(filter: string = '') {
    return (filter === '') ? this.facets : this.facets.filter(facet => facet.label.startsWith(filter));
  }

  filterSelectedFacets(filter: string = '') {
    return (filter === '') ? this.selectedFacets : [...this.selectedFacets].filter(selectedFacet => selectedFacet.label.startsWith(filter));
  }
}
