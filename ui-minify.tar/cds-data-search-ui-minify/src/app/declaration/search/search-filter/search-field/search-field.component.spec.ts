import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SearchFieldComponent } from './search-field.component';
import { SearchCriteriaService } from '../../search-criteria.service';
import {
  MatExpansionModule,
  MatIconModule,
  MatInputModule
} from '@angular/material';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { By } from '@angular/platform-browser';
import { SearchCriteria } from '../../search-criteria';
import { of } from 'rxjs/index';
import { FlexLayoutModule } from '@angular/flex-layout';
import { Directive, Input } from '@angular/core';
import { TogglePanel } from '../toggle-panel';
import { TogglePanelService } from '../toggle-panel.service';

const SEARCH_PARAM_FIELD = 'eori';
const PLACEHOLDER = 'placeholder text';
const LABEL = 'label';

@Directive({
  selector: 'cds-tooltip'
})
export class MockTooltipDirective {
  @Input() tooltipText: string;
}
describe('SearchFieldComponent', () => {
  let component: SearchFieldComponent;
  let fixture: ComponentFixture<SearchFieldComponent>;
  let searchCriteriaService: SearchCriteriaService;
  let searchCriteria: SearchCriteria;

  let togglePanelService: TogglePanelService;
  let togglePanel: TogglePanel;

  beforeEach(async(() => {
    searchCriteria = new SearchCriteria();
    togglePanel = new TogglePanel();

    searchCriteriaService = {
      searchCriteria: of(searchCriteria),
      updatePartial: (params) => { }
    } as SearchCriteriaService;

    togglePanelService = {
      togglePanel: of(togglePanel),
      updatePartial: (t) => {},
      replace: (t) => {},
      toggle: (t, e) => {}
    } as TogglePanelService;

    spyOn(searchCriteriaService, 'updatePartial');
    spyOn(togglePanelService, 'toggle');

    TestBed.configureTestingModule({
      declarations: [SearchFieldComponent, MockTooltipDirective],
      providers: [
        { provide: SearchCriteriaService, useValue: searchCriteriaService },
        { provide: TogglePanelService, useValue: togglePanelService }
      ],
      imports: [
        FlexLayoutModule,
        MatIconModule,
        MatIconModule,
        MatInputModule,
        BrowserAnimationsModule,
        MatExpansionModule,
        FormsModule
      ]
    })
      .compileComponents();
  }));

  let filterExpansionPanel;

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFieldComponent);
    component = fixture.componentInstance;
    component.label = LABEL;
    component.searchParamField = SEARCH_PARAM_FIELD;
    component.placeholder = PLACEHOLDER;

    searchCriteriaService = TestBed.get(SearchCriteriaService);
    togglePanelService = TestBed.get(TogglePanelService);
    filterExpansionPanel = fixture.debugElement.query(By.css('.search-field__header'));
    spyOn(component.panel, 'close');
  });

  it('should create', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  describe('within expansion panel', () => {

    beforeEach(() => {
      filterExpansionPanel.nativeElement.click();
    });

    describe('Free text search field', () => {
      let searchFieldInput;
      beforeEach(() => {
        fixture.detectChanges();
        searchFieldInput = fixture.debugElement.query(By.css('.search-field__searchfield-input'));
      });

      it('should have a free text search field', () => {
        expect(searchFieldInput).toBeTruthy();
      });

      it('should have a label for free text search field', () => {
        expect(searchFieldInput.nativeElement.labels[0].textContent).toEqual(PLACEHOLDER);
      });

      it('should call toggle panel service', () => {
        expect(togglePanelService.toggle).toHaveBeenCalled();
      });
    });

    describe('clear icon click', () => {
      let searchFieldInput;
      beforeEach(() => {
        searchFieldInput = fixture.debugElement.query(By.css('.search-field__searchfield-input'));
      });

      describe('value not previously empty', () => {
        beforeEach(() => {
          searchCriteria.eori = '123456';
          fixture.detectChanges();
          inputsearchField('123456');
          fixture.detectChanges();
          fixture.debugElement.query(By.css('.search-field__clear-search')).nativeElement.click();
        });

        it('clears search term', () => {
          expect(searchFieldInput.nativeElement.value).toEqual('');
        });

        it('should update search criteria', () => {
          const searchCriteriaObject: any = {};
          searchCriteriaObject[SEARCH_PARAM_FIELD] = null;
          searchCriteriaObject.pageNumber = undefined;
          searchCriteriaObject.pageSize = undefined;

          expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteriaObject);
        });

        it('should set the field focus', () => {
          const focusedElement = fixture.debugElement.query(By.css(':focus')).nativeElement;
          expect(searchFieldInput.nativeElement).toBe(focusedElement);
        });
      });

      describe('value previously empty', () => {
        beforeEach(() => {
          fixture.detectChanges(); // to initialise value to empty string
          inputsearchField('1');
          fixture.detectChanges();
          fixture.debugElement.query(By.css('.search-field__clear-search')).nativeElement.click();
        });

        it('clears search term', () => {
          const searchFieldInputElement = fixture.debugElement.query(By.css('.search-field__searchfield-input'));
          expect(searchFieldInputElement.nativeElement.value).toEqual('');
        });

        it('shouldnt update search criteria', () => {
          expect(searchCriteriaService.updatePartial).not.toHaveBeenCalled();
        });

        it('should set the field focus', () => {
          const focusedElement = fixture.debugElement.query(By.css(':focus')).nativeElement;
          expect(searchFieldInput.nativeElement).toBe(focusedElement);
        });
      });
    });

    describe('search icon', () => {
      let searchIcon;
      beforeEach(() => {
        searchIcon = fixture.debugElement.query(By.css('.search-field__perform-search'));
        fixture.detectChanges();
      });

      it('should be displayed', () => {
        expect(searchIcon).toBeTruthy();
      });
    });


    describe('on search', () => {
      const fieldValue = '12345678';
      let form;

      beforeEach(() => {
        form = fixture.debugElement.query(By.css('.search-field__form'));
      });

      describe('with search term', () => {
        let expectedSearchCriteria: any;

        beforeEach(() => {

          searchCriteria.eori = '123456';
          fixture.detectChanges();

          inputsearchField(fieldValue);
          fixture.detectChanges();

          expectedSearchCriteria = {};
          expectedSearchCriteria[SEARCH_PARAM_FIELD] = fieldValue;
          expectedSearchCriteria.pageNumber = undefined;
          expectedSearchCriteria.pageSize = undefined;
        });

        it('should call update on service', () => {
          fixture.debugElement.query(By.css('.search-field__perform-search')).nativeElement.click();
          expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(expectedSearchCriteria);
        });

        it('should update on submit event', () => {
          form.nativeElement.dispatchEvent(new Event('submit'));
          expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(expectedSearchCriteria);
        });

        describe('with null search term', () => {
          beforeEach(() => {
            inputsearchField(null);
            form.nativeElement.dispatchEvent(new Event('submit'));
            expectedSearchCriteria[SEARCH_PARAM_FIELD] = null;
          });

          it('should submit empty string for null search term', () => {
            form.nativeElement.dispatchEvent(new Event('submit'));
            expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(expectedSearchCriteria);
          });

          it('should close the panel', () => {
            expect(component.panel.close).toHaveBeenCalled();
          });
        });
      });
    });
  });

  function inputsearchField(searchField) {
    const searchFieldInput = fixture.debugElement.query(By.css('.search-field__searchfield-input')).nativeElement;
    searchFieldInput.value = searchField;
    searchFieldInput.dispatchEvent(new Event('input'));
  }
});
