import { Injectable } from '@angular/core';
import { TogglePanel } from './toggle-panel';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable()
export class TogglePanelService {

  private _currentTogglePanel: TogglePanel = new TogglePanel();
  private togglePanelSource = new BehaviorSubject(this._currentTogglePanel);
  private _togglePanelUpdates = this.togglePanelSource.asObservable();

  get togglePanel(): Observable<any> {
    return this._togglePanelUpdates;
  }

  replace(togglePanel: TogglePanel) {
    this._currentTogglePanel = togglePanel;
    this.togglePanelSource.next(Object.assign(new TogglePanel(), this._currentTogglePanel));
  }

  updatePartial(togglePanel: TogglePanel) {
    Object.assign(this._currentTogglePanel, togglePanel);
    this.togglePanelSource.next(Object.assign(new TogglePanel(), this._currentTogglePanel));
  }

  toggle(field, expand) {
    const togglePanel = new TogglePanel();
    togglePanel[field] = expand;
    this.updatePartial(togglePanel);
  }
}
