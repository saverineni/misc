import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'cds-chips',
  templateUrl: './chips.component.html',
  styleUrls: ['./chips.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChipsComponent {
  
  @Input() id: string;
  @Input() categories: Array<string>;
  @Input() categoriesFilters: Array<string>;
  @Input() chips: Array<string>;
  @Output() remove: EventEmitter<string> = new EventEmitter();
  
  removeChip(chipId) {
    this.remove.emit(chipId);
  }

  filterChips(filter: string = '') {
    return (filter === '') ? this.chips : this.chips.filter(chip => chip.startsWith(filter));
  }
}
