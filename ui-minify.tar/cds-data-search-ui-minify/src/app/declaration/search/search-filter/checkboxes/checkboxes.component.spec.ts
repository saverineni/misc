import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CheckboxesComponent } from './checkboxes.component';
import { MAT_CHECKBOX_CLICK_ACTION, MatCheckboxChange, MatCheckboxModule, MatExpansionModule} from '@angular/material';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TogglePanelService } from '../toggle-panel.service';
import { SearchCriteriaService } from '../../search-criteria.service';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

describe('CheckboxesComponent', () => {
  let component: CheckboxesComponent;
  let fixture: ComponentFixture<CheckboxesComponent>;
  let searchCriteriaService: SearchCriteriaService;
  let togglePanelService: TogglePanelService;

  let expansionPanel: DebugElement;
  let applyFiltersButton: DebugElement;
  let clearButton: DebugElement;
  const searchField = 'searchField';
  const data = [ 'checkbox1', 'checkbox2' ];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: MAT_CHECKBOX_CLICK_ACTION, useValue: 'check'} , SearchCriteriaService , TogglePanelService
      ],
      imports: [
        MatCheckboxModule,
        MatExpansionModule,
        BrowserAnimationsModule,
        FormsModule
      ],
      declarations: [ CheckboxesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckboxesComponent);
    component = fixture.componentInstance;
    component.label = 'LABEL';
    component.data = data;
    component.searchParamField = searchField;

    searchCriteriaService = TestBed.get(SearchCriteriaService);
    togglePanelService = TestBed.get(TogglePanelService);

    expansionPanel = fixture.debugElement.query(By.css('.checkboxes__header'));
    applyFiltersButton = fixture.debugElement.query(By.css('.checkboxes__apply-filters'));
    clearButton = fixture.debugElement.query(By.css('.checkboxes__clear'));

    spyOn(searchCriteriaService, 'updatePartial');
    spyOn(component, 'onToggle');

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display label', () => {
    const headerLabel = expansionPanel.nativeElement;
    expect(headerLabel.innerText).toContain('LABEL');
  });

  describe('interactions within expansion panel', () => {

    const checkboxChange = new MatCheckboxChange();

    beforeEach(() => {
      expansionPanel.nativeElement.click();
      fixture.detectChanges();
    });

    it('should open the panel', () => {
      expect(component.onToggle).toHaveBeenCalledWith(true);
    });

    it('should display checkboxes', () => {
      const checkBoxes = fixture.debugElement.queryAll(By.css('.mat-checkbox-input'));
      expect(checkBoxes.length).toBe(2);
    });

    it('should display proper labels', () => {
      const checkBoxes = fixture.debugElement.queryAll(By.css('.mat-checkbox-label'));
      const array: Array<string> = [];
      checkBoxes.forEach(element => array.push(element.nativeElement.textContent.trim()));
      expect(array).toEqual(data);
    });

    it('should display clear button', () => {
      expect(clearButton.nativeElement.disabled).toBe(false);
    });

    it('apply filters is disabled initially', () => {
      expect(applyFiltersButton.nativeElement.disabled).toBe(true);
    });

    describe('checkbox' , () => {

      it('select will generate checked event', () => {
        const checkboxElement = findCheckBoxElement('checkbox1');

        expect(component.anyItemSelected()).toBe(false);
        itemClick(checkboxElement);

        expect(component.anyItemSelected()).toBe(true);
        expect(findCheckBox('checkbox1').selected).toBe(true);
        expect(applyFiltersButton.nativeElement.disabled).toBe(false);
      });

      it('unselect will generate unchecked event', () => {
        const checkboxElement = findCheckBoxElement('checkbox1');

        itemClick(checkboxElement, false);
        expect(component.anyItemSelected()).toBe(false);
        expect(findCheckBox('checkbox1').selected).toBe(false);
        expect(applyFiltersButton.nativeElement.disabled).toBe(true);
      });

    });

    describe('on apply filters', () => {

      let searchCriteria: any;

      beforeEach(() => {
        searchCriteria = {};
        searchCriteria[searchField] = ['checkbox1'];
        searchCriteria.pageNumber = undefined;
        searchCriteria.pageSize = undefined;

        const checkboxElement = findCheckBoxElement('checkbox1');
        itemClick(checkboxElement);

        fixture.detectChanges();
      });

      it('should call update on service', () => {
        applyFiltersButton.nativeElement.click();
        expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteria);
      });

    });

    describe('on clear', () => {

      let searchCriteria: any;
      beforeEach(() => {

        searchCriteria = {};
        searchCriteria[searchField] = null;
        searchCriteria.pageNumber = undefined;
        searchCriteria.pageSize = undefined;

        fixture.detectChanges();
      });

      it('should call update partial ', () => {
        const checkboxElement = findCheckBoxElement('checkbox1');
        itemClick(checkboxElement);

        clearButton.nativeElement.click();
        expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteria);
      });

      it('no item elected', () => {
        searchCriteria[searchField] = null;
        clearButton.nativeElement.click();
        expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteria);
      });
    });

    function itemClick(item: DebugElement , checked: boolean = true) {
      checkboxChange.checked = checked;
      item.nativeElement.click();
      item.triggerEventHandler('change', checkboxChange);
      fixture.detectChanges();
    }

    function findCheckBox(checkBoxId: string ) {
      return component.selectedCheckboxes.find(item => item.id === checkBoxId);
    }

    function findCheckBoxElement(checkBoxId: string ) {
     return fixture.debugElement.query(By.css(`.checkboxes__form-${checkBoxId}`));
    }

  });

  describe('expansion panel', () => {

    it('should not start expanded', () => {
      expect(expansionPanel.nativeElement.classList).not.toContain('mat-expanded');
    });

    describe('when clicked', () => {
      beforeEach(() => {
        expansionPanel.nativeElement.click();
        fixture.detectChanges();
      });

      it('should be expanded', () => {
        expect(expansionPanel.nativeElement.classList).toContain('mat-expanded');
      });

      it('should call toggle panel service', () => {
        expect(component.onToggle).toHaveBeenCalledWith(true);
      });

      it('should collapse when clicked again', () => {
        expansionPanel.nativeElement.click();
        fixture.detectChanges();
        expect(expansionPanel.nativeElement.classList).not.toContain('mat-expanded');
      });
    });

  });
});
