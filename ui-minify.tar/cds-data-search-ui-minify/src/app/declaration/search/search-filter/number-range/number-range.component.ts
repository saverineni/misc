import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ElementRef,
  Input,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation
} from '@angular/core';
import { SearchCriteria } from '../../search-criteria';
import { SearchCriteriaService } from '../../search-criteria.service';
import { NgModel } from '@angular/forms';
import { camelCase } from 'lodash';
import { TogglePanelService } from '../toggle-panel.service';
import { TogglePanel } from '../toggle-panel';

@Component({
  selector: 'cds-number-range-filter',
  templateUrl: './number-range.component.html',
  styleUrls: ['./number-range.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class NumberRangeComponent implements OnInit, OnDestroy {
  from = null;
  to = null;
  fromValueGreater = false;
  exceedsMaxValue = false;
  notPositive = false;

  private closePanel: boolean;
  private openPanel: boolean;

  private searchCriteriaSubscription;
  private togglePanelSubscription;
  private togglePanelField;
  private searchCriteria: SearchCriteria = null;

  @Input() maxValue: number;
  @Input() label: string;
  @Input() fromField: string;
  @Input() toField: string;
  @ViewChild('panel') panel;
  @ViewChild('fromView') fromView: NgModel;
  @ViewChild('toView') toView: NgModel;
  @ViewChild('fromView', { read: ElementRef }) fromElementRef: ElementRef;
  @ViewChild('toView', { read: ElementRef }) toElementRef: ElementRef;

  constructor(private searchCriteriaService: SearchCriteriaService,
              private togglePanelService: TogglePanelService,
              private changeDetectorRef: ChangeDetectorRef) { }

  ngOnInit() {
    this.togglePanelField = camelCase(this.label);
    this.searchCriteriaSubscription = this.searchCriteriaService.searchCriteria.subscribe(
      data  => {
        this.searchCriteria = data as SearchCriteria;
        this.from = this.searchCriteria[this.fromField];
        this.to = this.searchCriteria[this.toField];
        this.fromValueGreater = false;
        this.exceedsMaxValue = false;
        this.notPositive = false;
        this.toggleExpansionPanel();
        this.changeDetectorRef.detectChanges();
      }
    );

    this.togglePanelSubscription = this.togglePanelService.togglePanel.subscribe(
      (data: TogglePanel) => {
        this.openPanel = data.isOpened(this.togglePanelField);
        this.closePanel = data.isClosed(this.togglePanelField);
        this.toggleExpansionPanel();
      });
  }

  toggleExpansionPanel() {
    if (this.isDataExists() && !this.closePanel) {
      this.panel.open();
    } else if (!this.openPanel) {
      this.panel.close();
    }
  }

  fromMaxValue() {
    if (!this.to) {
      return this.maxValue;
    } else {
      return this.to;
    }
  }

  toMinValue() {
    if (!this.from) {
      return null;
    } else {
      return this.from;
    }
  }

  toMaxValue() {
    return this.maxValue;
  }

  onClear() {
    this.resetModel(this.fromView, this.fromElementRef);
    this.resetModel(this.toView, this.toElementRef);

    this.from = null;
    this.to = null;
    this.onApplyFilters();
  }

  ngOnDestroy(): void {
    this.searchCriteriaSubscription.unsubscribe();
    this.togglePanelSubscription.unsubscribe();
  }

  onApplyFilters() {
    this.fromValueGreater = this.fromValueGreaterThanTo();
    this.exceedsMaxValue = this.maxValue && (this.from > this.maxValue || this.to > this.maxValue);
    this.notPositive = this.from < 0 || this.to < 0;

    const updates: any = {};
    if (this.from !== null) {
      updates[this.fromField] = this.from;
    } else {
      updates[this.fromField] = null;
    }
    if (this.to !== null) {
      updates[this.toField] = this.to;
    } else {
      updates[this.toField] = null;
    }

    updates['pageNumber'] = undefined;
    updates['pageSize'] = undefined;

    if (!this.fromValueGreater && !this.exceedsMaxValue && !this.notPositive) {
      this.searchCriteriaService.updatePartial(updates);
    }
  }

  fromValueGreaterThanTo() {
    if (this.to !== 0 && !this.to) {
      return false;
    } else {
      return this.from > this.to;
    }
  }

  private resetModel(model: NgModel, elementRef: ElementRef) {
    elementRef.nativeElement.value = null;
    model.control.root.reset();
  }

  onToggle(expand: boolean) {
    this.togglePanelService.toggle(this.togglePanelField, expand);
  }

  private isDataExists() {
    return this.from || this.to;
  }

  isToValid() {
    return (this.to || this.to === 0) ? true : this.to;
  }

}
