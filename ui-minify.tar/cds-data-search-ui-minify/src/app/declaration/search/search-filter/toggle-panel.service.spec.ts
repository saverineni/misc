import { TestBed } from '@angular/core/testing';
import { TogglePanelService } from './toggle-panel.service';
import { TogglePanel } from './toggle-panel';

describe('TogglePanelService', () => {
  let service: TogglePanelService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TogglePanelService]
    });
    service = TestBed.get(TogglePanelService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should give the toggle panel observable', (done) => {
    service.togglePanel.subscribe(
      data => {
        expect(data).toEqual(new TogglePanel());
        done();
      },
      done.fail
    );
  });

  describe('update', () => {
    let updatedTogglePanel;
    let panelInfoSentToSubscribers;

    beforeEach(() => {
      updatedTogglePanel = new TogglePanel();
      updatedTogglePanel.eori = true;
      service.updatePartial(updatedTogglePanel);
    });

    beforeEach((done) => {
      service.togglePanel.subscribe(
        data => {
          panelInfoSentToSubscribers = data;
          done();
        },
        done.fail
      );
    });

    it('should send updated toggle panel to subscribers', () => {
      expect(panelInfoSentToSubscribers).toEqual(updatedTogglePanel);
    });

    describe('should send a copy of the new toggle panel, not the the updated original', () => {

      it('for a non empty toggle panel object', () => {
        expect(panelInfoSentToSubscribers).not.toBe(updatedTogglePanel);
      });

      it('for an empty toggle panel object', () => {
        updatedTogglePanel = new TogglePanel();
        service.replace(updatedTogglePanel);

        expect(panelInfoSentToSubscribers).not.toBe(updatedTogglePanel);
        expect(panelInfoSentToSubscribers).toEqual(new TogglePanel());
      });
    });

  });
});
