import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DateRangeComponent } from './date-range.component';
import { By } from '@angular/platform-browser';
import {
  MAT_DATE_LOCALE,
  MatDatepickerModule,
  MatExpansionModule,
  MatFormFieldModule,
  MatInputModule,
  MatDividerModule
} from '@angular/material';
import { FormsModule } from '@angular/forms';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SearchCriteriaService } from '../../search-criteria.service';
import * as moment from 'moment';
import { TogglePanelService } from '../toggle-panel.service';

describe('DateRangeComponent', () => {
  let component: DateRangeComponent;
  let fixture: ComponentFixture<DateRangeComponent>;
  let searchCriteriaService: SearchCriteriaService;
  let togglePanelService: TogglePanelService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MatDatepickerModule, MatMomentDateModule, FormsModule, BrowserAnimationsModule, MatFormFieldModule,
        MatExpansionModule, MatInputModule, MatDividerModule],
      declarations: [ DateRangeComponent ],
      providers: [
        {provide: MAT_DATE_LOCALE, useValue: 'en-GB'}, SearchCriteriaService , TogglePanelService
      ]
    })
    .compileComponents();
  }));

  let filterExpansionPanel;

  beforeEach(() => {
    fixture = TestBed.createComponent(DateRangeComponent);
    component = fixture.componentInstance;
    component.label = 'dateLabel';
    component.fromField = 'dateFrom';
    component.toField = 'dateTo';
    searchCriteriaService = TestBed.get(SearchCriteriaService);
    togglePanelService = TestBed.get(TogglePanelService);
    filterExpansionPanel = fixture.debugElement.query(By.css('.date-range__header'));
    spyOn(component.datePanel, 'open');
    spyOn(component.datePanel, 'close');
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('within expansion panel', () => {

    let fromInput;
    let toInput;
    let applyFiltersButton;
    let clearButton;
    const fromDate = '1-1-2015';
    const toDate = '1-2-2015';
    const tomorrow = moment(new Date()).add(1, 'days').format('DD-MM-YYYY');

    beforeEach(() => {
      fromInput = fixture.debugElement.query(By.css('.date-range__from-input'));
      toInput = fixture.debugElement.query(By.css('.date-range__to-input'));
      applyFiltersButton = fixture.debugElement.query(By.css('.date-range__apply-filters-button'));
      clearButton = fixture.debugElement.query(By.css('.date-range__clear-button'));
      filterExpansionPanel.nativeElement.click();
      fixture.detectChanges();
    });

    describe('date range inputs', () => {

      it('from input should be bound to the from model', () => {
        givenFromDate(fromDate);
        expect(moment(component.dateFrom).format('YYYY-MM-DD')).toEqual('2015-01-01');
      });

      it('to input should be bound to the to model', () => {
        givenToDate(toDate);
        expect(moment(component.dateTo).format('YYYY-MM-DD')).toEqual('2015-02-01');
      });

    });

    describe('toggle panel', () => {
      beforeEach(() => {
        givenFromDate(fromDate);
        component.toggleExpansionPanel();
      });

      it('should open the panel', () => {
        expect(component.datePanel.open).toHaveBeenCalled();
      });
    });

    describe('date range input validation', () => {

      it('when from date is after to date', () => {
        givenFromDate(toDate);
        givenToDate(fromDate);

        clickApplyFilter();

        const errorMessage = fixture.debugElement.query(By.css('.date-range__date-precedes'));
        expect(errorMessage).toBeTruthy();

      });

      it('when from date is in the future', () => {
        givenFromDate(tomorrow);

        clickApplyFilter();

        const errorMessage = fixture.debugElement.query(By.css('.date-range__future-date'));
        expect(errorMessage).toBeTruthy();

      });

      it('when to date is in the future', () => {
        givenToDate(tomorrow);
        clickApplyFilter();

        const errorMessage = fixture.debugElement.query(By.css('.date-range__future-date'));
        expect(errorMessage).toBeTruthy();
      });

      it('when from date is after to date and has future date', () => {
        givenFromDate(tomorrow);
        givenToDate(fromDate);

        clickApplyFilter();

        const datePrecedesErrorMessage = fixture.debugElement.query(By.css('.date-range__date-precedes'));
        expect(datePrecedesErrorMessage).toBeTruthy();

        const futureDateErrorMessage = fixture.debugElement.query(By.css('.date-range__date-precedes'));
        expect(futureDateErrorMessage).toBeTruthy();

      });

      function clickApplyFilter() {
        applyFiltersButton.nativeElement.click();
        fixture.detectChanges();
      }

    });

    describe('apply filters button', () => {

      it('should start disabled', () => {
        expect(applyFiltersButton.nativeElement.disabled).toBe(true);
      });

      describe('should be disabled invalid date input', () => {
        afterEach(() => {
          fixture.detectChanges();
          expect(applyFiltersButton.nativeElement.disabled).toBe(true);
        });

        it('when an invalid date (alphabets) is entered into the from input', () => {
          fromInput.nativeElement.value = 'invalid';
          fromInput.nativeElement.dispatchEvent(new Event('input'));
        });

        it('when an invalid date (alphabets) is entered into the to input', () => {
          toInput.nativeElement.value = 'invalid';
          toInput.nativeElement.dispatchEvent(new Event('input'));
        });
      });

      describe('should be enabled', () => {
        afterEach(() => {
          fixture.detectChanges();
          expect(applyFiltersButton.nativeElement.disabled).toBe(false);
        });

        it('when a valid date is entered into the from input', () => {
          fromInput.nativeElement.value = fromDate;
          fromInput.nativeElement.dispatchEvent(new Event('input'));
        });

        it('when a valid date is entered into the to input', () => {
          toInput.nativeElement.value = toDate;
          toInput.nativeElement.dispatchEvent(new Event('input'));
        });


        it('when from date is after to date', () => {
          fromInput.nativeElement.value = toDate;
          fromInput.nativeElement.dispatchEvent(new Event('input'));

          toInput.nativeElement.value = fromDate;
          toInput.nativeElement.dispatchEvent(new Event('input'));
        });

        it('when from date is in the future', () => {
          fromInput.nativeElement.value = tomorrow;
          fromInput.nativeElement.dispatchEvent(new Event('input'));
        });

        it('when to date is in the future', () => {
          toInput.nativeElement.value = tomorrow;
          toInput.nativeElement.dispatchEvent(new Event('input'));
        });
      });

    });

    describe('submit filters',  () => {
      beforeEach ( () => {
        spyOn(searchCriteriaService, 'updatePartial');
        givenFromDate(fromDate);
        givenToDate(toDate);
      });

      it('should update the search criteria service when apply filters clicked', () => {
        applyFiltersButton.nativeElement.click();
        const searchCriteria: any = {};
        searchCriteria.dateFrom = '2015-01-01';
        searchCriteria.dateTo = '2015-02-01';
        searchCriteria.pageNumber = undefined;
        searchCriteria.pageSize = undefined;
        expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteria);
      });

      it('clears the dates and should update the search criteria service when cancel clicked', () => {
        clearButton.nativeElement.click();
        const searchCriteria: any = {};
        searchCriteria.dateFrom = null;
        searchCriteria.dateTo = null;
        searchCriteria.pageNumber = undefined;
        searchCriteria.pageSize = undefined;
        expect(searchCriteriaService.updatePartial).toHaveBeenCalledWith(searchCriteria);
      });
    });

    describe('clear button', () => {
      it('should contain clear label', () => {
        const clearLabel = clearButton.nativeElement;
        expect(clearLabel.textContent).toEqual('Clear');
      });

      it('should be enabled when an invalid date (alphabets) is entered into the from input', () => {
        fromInput.nativeElement.value = 'invalid';
        fromInput.nativeElement.dispatchEvent(new Event('input'));
        fixture.detectChanges();
        expect(clearButton.nativeElement.disabled).toBe(false);
      });

      it('should clear invalid input field when clicked', () => {
        fromInput.nativeElement.value = 'invalid';
        fromInput.nativeElement.dispatchEvent(new Event('input'));
        toInput.nativeElement.value = 'invalid';
        toInput.nativeElement.dispatchEvent(new Event('input'));
        fixture.detectChanges();

        clearButton.nativeElement.click();
        expect(fromInput.nativeElement.value).toEqual('');
        expect(toInput.nativeElement.value).toEqual('');
      });
    });

    function givenFromDate(value: any) {
      fromInput.nativeElement.value = value;
      fromInput.nativeElement.dispatchEvent(new Event('input'));
      fixture.detectChanges();
    }

    function givenToDate(value: any) {
      toInput.nativeElement.value = value;
      toInput.nativeElement.dispatchEvent(new Event('input'));
      fixture.detectChanges();
    }

  });


  describe('date range filter expansion panel', () => {
    beforeEach(() => {
      spyOn(togglePanelService, 'updatePartial');
    });

    it('should not start expanded', () => {
      expect(filterExpansionPanel.nativeElement.classList).not.toContain('mat-expanded');
    });

    describe('when clicked', () => {
      beforeEach(() => {
        filterExpansionPanel.nativeElement.click();
        fixture.detectChanges();
      });

      it('should be expanded', () => {
        expect(filterExpansionPanel.nativeElement.classList).toContain('mat-expanded');
      });

      it('should call toggle panel service', () => {
        expect(togglePanelService.updatePartial).toHaveBeenCalled();
      });

      it('should collapse when clicked again', () => {
        filterExpansionPanel.nativeElement.click();
        fixture.detectChanges();
        expect(filterExpansionPanel.nativeElement.classList).not.toContain('mat-expanded');
      });
    });
  });
});
