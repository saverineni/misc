import {RemovespaceLowercasePipe} from './removespace-lowercase.pipe';

describe('RemovespaceLowercasePipe', () => {
  let pipe;

  beforeEach(() => {
    pipe = new RemovespaceLowercasePipe();
  });

  it('should transform value with space', () => {
    expect(pipe.transform('A B')).toBe('ab');
  });

  it('should transform value without space', () => {
    expect(pipe.transform('AB')).toBe('ab');
  });

  it('should transform null to empty string', () => {
    expect(pipe.transform(null)).toBe('');
  });

  it('should transform undefined to empty string', () => {
    expect(pipe.transform(undefined)).toBe('');
  });

});
