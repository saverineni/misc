import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BreadcrumbComponent } from './breadcrumb.component';
import { NavigationService } from '../search/navigation.service';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import { DebugElement } from '@angular/core';
import { RemovespaceLowercasePipe } from './removespace-lowercase.pipe';
import { Breadcrumb } from './breadcrumb';

describe('BreadcrumbComponent', () => {
  let component: BreadcrumbComponent;
  let fixture: ComponentFixture<BreadcrumbComponent>;
  let navigationService: NavigationService;

  beforeEach(async(() => {
    navigationService = {
      navigateToSearch: (x) => { }
    } as NavigationService;
    spyOn(navigationService, 'navigateToSearch');

    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [BreadcrumbComponent, RemovespaceLowercasePipe],
      providers: [
        { provide: NavigationService, useValue: navigationService }
      ]

    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BreadcrumbComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('breadcrumbs displayed', () => {

    beforeEach(() => {
      component.breadcrumbs = [
        new Breadcrumb('Test Enabled', 'url'),
        new Breadcrumb('Test Disabled')
      ];
      fixture.detectChanges();
    });


    it('when present', () => {
      const breadCrumbContainer = fixture.debugElement.query(By.css('.breadcrumb-container'));
      expect(breadCrumbContainer).toBeTruthy();
    });

    it('breadcrumb count is valid', () => {
      const breadCrumbItems = fixture.debugElement.queryAll(By.css('.breadcrumb-container__breadcrumb'));
      expect(breadCrumbItems.length).toBe(3);
    });

    describe('search results breadcrumb', () => {

      let searchResultsBreadcrumb: DebugElement;

      beforeEach(() => {
        searchResultsBreadcrumb = fixture.debugElement.query(By.css(
          '.breadcrumb-container__breadcrumb-link[data-breadcrumb="searchresults"]'
        ));
      });

      it('exists', () => {
        expect(searchResultsBreadcrumb).toBeTruthy();
      });

      it('should call the navigation service when clicked', () => {
        searchResultsBreadcrumb.nativeElement.click();

        expect(navigationService.navigateToSearch).toHaveBeenCalledWith(false);
      });
    });

    describe('enabled breadcrumb', () => {
      let otherBreadcrumb: DebugElement;

      beforeEach(() => {
        otherBreadcrumb = fixture.debugElement.query(By.css('.breadcrumb-container__breadcrumb-link[data-breadcrumb="testenabled"]'));
      });

      it('exists', () => {
        expect(otherBreadcrumb).toBeTruthy();
      });

      it('breadcrumb url value present', () => {
        expect(otherBreadcrumb.nativeElement.getAttribute('href')).toBe('/url');
      });
    });

    describe('breadcrumb disabled', () => {
      let otherBreadcrumb;

      beforeEach(() => {
        otherBreadcrumb = fixture.debugElement.query(By.css(
          '.breadcrumb-container__breadcrumb-link--disabled[data-breadcrumb="testdisabled"]'
        ));
      });

      it('is disabled', () => {
        expect(otherBreadcrumb).toBeTruthy();
      });
    });
  });

  describe('breadcrumbs not displayed', () => {
    beforeEach(() => {
      component.breadcrumbs = [];
      fixture.detectChanges();
    });

    it('when empty', () => {
      const breadCrumbContainer = fixture.debugElement.query(By.css('.breadcrumb-container'));
      expect(breadCrumbContainer).toBeFalsy();
    });
  });
});
