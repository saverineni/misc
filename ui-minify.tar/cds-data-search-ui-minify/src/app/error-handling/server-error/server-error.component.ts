import { Component } from '@angular/core';

@Component({
  selector: 'cds-server-error',
  templateUrl: './server-error.component.html',
  styleUrls: ['./server-error.component.scss']
})
export class ServerErrorComponent {

  constructor() {}

}
