import { MatSnackBar } from '@angular/material';
import { OperationErrorNotifier } from './operation-error-notifier';


describe('OperationErrorNotifier', () => {
    let notifier: OperationErrorNotifier;
    let mockSnackBar: MatSnackBar;

    beforeEach(() => {
        mockSnackBar = { open(message, action, config) {} } as MatSnackBar;
        notifier = new OperationErrorNotifier(mockSnackBar);
        const mockSnackBarSpy = spyOn(mockSnackBar, 'open');
    });

    describe('notifyUser', () => {

        beforeEach(() => {
            notifier.notifyUser('my-message');
        });

        it('opens a snack bar', () => {
           expect(mockSnackBar.open).toHaveBeenCalled();
        });

        it('displays a meaningful message', () => {
            expect(mockSnackBar.open).toHaveBeenCalledWith(
                'my-message. Please contact support if this problem persists.',
                'OK',
                { panelClass: 'operation-error' });
         });
     });
});
