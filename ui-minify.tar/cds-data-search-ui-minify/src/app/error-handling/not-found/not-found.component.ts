import { Component, ChangeDetectionStrategy } from '@angular/core';
import { UserService } from '../../authentication/user.service';

@Component({
  selector: 'cds-not-found',
  templateUrl: './not-found.component.html',
  styleUrls: ['./not-found.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NotFoundComponent {

  constructor(private userService: UserService) { }

  isSignedIn() {
    return this.userService.isSignedIn();
  }

}
