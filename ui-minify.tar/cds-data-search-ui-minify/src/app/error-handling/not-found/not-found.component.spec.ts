import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { NotFoundComponent } from './not-found.component';
import { UserService } from '../../authentication/user.service';
import { By } from '@angular/platform-browser';
import { Component } from '@angular/core';
import { Location } from '@angular/common';

class MockUserService {
  signedIn: false;

  isSignedIn() {
    return this.signedIn;
  }

  setSignedIn(signedId) {
    this.signedIn = signedId;
  }
}

@Component({
  template: `SignIn`
})
class MockSignInComponent {}

describe('NotFoundComponent', () => {
  let component: NotFoundComponent;
  let fixture: ComponentFixture<NotFoundComponent>;
  const userService = new MockUserService();
  let location;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes([{path: 'signin', component: MockSignInComponent}])],
      providers: [ { provide: UserService, useValue: userService } ],
      declarations: [ NotFoundComponent, MockSignInComponent ]
    })
    .compileComponents();

    location = TestBed.get(Location);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotFoundComponent);
    component = fixture.componentInstance;
  });

  function signInButton() {
    return fixture.debugElement.query(By.css('.not-found__sign-in-button'));
  }

  describe('given not signed in',  () => {
    beforeEach(() => {
      userService.setSignedIn(false);
      fixture.detectChanges();
    });

    it('then the not signed in message is displayed', () => {
      expect(fixture.debugElement.query(By.css('.not-found__unauthenticated-message'))).not.toBeNull();
    });

    it('then the signed in message is not displayed', () => {
      expect(fixture.debugElement.query(By.css('.not-found__authenticated-message'))).toBeNull();
    });

    it('then the sign in button is displayed', () => {
      expect(signInButton()).not.toBeNull();
    });

    describe('and I click the sign in button',  () => {
      beforeEach(fakeAsync(() => {
        signInButton().nativeElement.click();
        tick();
      }));

      it('then the sign in page is the current page', () => {
        expect(location.path()).toBe('/signin');
      });
    });

  });

  describe('given signed in',  () => {
    beforeEach(() => {
      userService.setSignedIn(true);
      fixture.detectChanges();
    });

    it('then the signed in message is displayed', () => {
      expect(fixture.debugElement.query(By.css('.not-found__authenticated-message'))).not.toBeNull();
    });

    it('then the not signed in message is not displayed', () => {
      expect(fixture.debugElement.query(By.css('.not-found__unauthenticated-message'))).toBeNull();
    });

    it('then the sign in button is not displayed', () => {
      expect(signInButton()).toBeNull();
    });

  });

});
