export class TrackBy {

  static property(propertyName): Function {
    return function(index, item) {
      return item[propertyName];
    };
  }

  static index = function(index, item) {
    return index;
  };
}
