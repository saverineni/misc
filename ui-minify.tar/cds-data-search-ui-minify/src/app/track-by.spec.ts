import { TrackBy } from './track-by';

describe('TrackBy', () => {

  it('should track by object property', () => {
    const trackByItem  = { itemId: 'id', otherPropety: 123 };
    const trackByFunction = TrackBy.property('itemId');

    expect(trackByFunction(null, trackByItem)).toBe(trackByItem.itemId);
  });

  it('should track index', () => {
    expect(TrackBy.index(143, null)).toBe(143);
  });
});
