import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {UserDetailsComponent} from './user-details.component';
import {By} from '@angular/platform-browser';
import {UserService} from '../user.service';
import {User} from '../user';
import {MatIconModule} from '@angular/material';

describe('UserDetailsComponent', () => {
  let component: UserDetailsComponent;
  let fixture: ComponentFixture<UserDetailsComponent>;

  beforeEach(async(() => {
    const testUserService = {
      isSignedIn: () => false,
      getUser: (): User => null
    } as UserService;

    TestBed.configureTestingModule({
      imports: [MatIconModule],
      declarations: [UserDetailsComponent],
      providers: [
        { provide: UserService, useValue: testUserService }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('user is not signed in', () => {
    it('should not display the user details', () => {
      const userDetails = fixture.debugElement.query(By.css('.user-details'));

      expect(userDetails == null).toBeTruthy();
    });
  });

  describe('user signed in', () => {
    const user = {pid: 'pid', firstName: 'Search', lastName: 'User' , department: 'Operations Unit'} as User;

    beforeEach(() => {
      fixture = TestBed.createComponent(UserDetailsComponent);
      component = fixture.componentInstance;
      const userService = TestBed.get(UserService);
      spyOn(userService, 'isSignedIn').and.returnValue(true);
      spyOn(userService, 'getUser').and.returnValue(user);
      fixture.detectChanges();
    });

    it('should display the user details', () => {
      const userDetails = fixture.debugElement.query(By.css('.user-details'));
      expect(userDetails != null).toBeTruthy();
    });

    it('should display the user\'s full name', () => {
      const fullName: HTMLElement = fixture.debugElement.query(By.css('.user-details__info__name')).nativeElement;
      expect(fullName.textContent).toEqual('Search User');
    });

    it('should display the user\'s department', () => {
      const department: HTMLElement = fixture.debugElement.query(By.css('.user-details__info__department')).nativeElement;
      expect(department.textContent).toEqual('Operations Unit');
    });

    it('should display the user icon', () => {
      const userIcon: HTMLElement = fixture.debugElement.query(By.css('.user-details__icon')).nativeElement;
      expect(userIcon).toBeTruthy();
    });

  });

  describe('user with null values', () => {
    const user = {pid: 'pid', lastName: null, department: ''} as User;

    beforeEach(() => {
      fixture = TestBed.createComponent(UserDetailsComponent);
      component = fixture.componentInstance;
      const userService = TestBed.get(UserService);
      spyOn(userService, 'isSignedIn').and.returnValue(true);
      spyOn(userService, 'getUser').and.returnValue(user);
      fixture.detectChanges();
    });

    it('should display the user details', () => {
      const userDetails = fixture.debugElement.query(By.css('.user-details'));
      expect(userDetails != null).toBeTruthy();
    });

    it('should display the user\'s full name', () => {
      const fullName: HTMLElement = fixture.debugElement.query(By.css('.user-details__info__name')).nativeElement;
      expect(fullName.textContent).toEqual(' ');
    });

    it('should display the user\'s department', () => {
      const department: HTMLElement = fixture.debugElement.query(By.css('.user-details__info__department')).nativeElement;
      expect(department.textContent).toEqual('');
    });

    it('should display the user icon', () => {
      const userIcon: HTMLElement = fixture.debugElement.query(By.css('.user-details__icon')).nativeElement;
      expect(userIcon).toBeTruthy();
    });

  });
});
