import {SignInRouterService} from './sign-in-router.service';
import {Router} from '@angular/router';

describe('SignInRouterService', () => {
  let service;
  const newRouter = {
    navigate(command): Promise<boolean> {
      return Promise.resolve(true);
    },
    routerState : {
      snapshot : {
        url : {
        }
      }
    }
  } as Router;
  const location = {
    assign(url): Promise<boolean> {
      return Promise.resolve(true);
    }
  } as any;

  beforeEach(() => {
    service = new SignInRouterService(newRouter, location);
    spyOn(newRouter, 'navigate');
    spyOn(location, 'assign');
  });

  describe('navigateToSignIn', () => {

    it('navigates to signin', () => {
        service.navigateToSignIn();
        expect(newRouter.navigate).toHaveBeenCalledWith(['signin'], {queryParams: {returnUrl: {}}});
      });

    describe('given router state', () => {
      it('navigates to signin with current url as a query param', () => {

        const routerStateSnapshot = {url: '/current-url'};

        service.navigateToSignIn(routerStateSnapshot);
        expect(newRouter.navigate).toHaveBeenCalledWith(['signin'], {queryParams: {returnUrl: routerStateSnapshot.url}});
      });

    });
  });

  describe('navigateToReturnUrl', () => {

    describe('given no return url' , () => {
      it('should navigate to home page', () => {
        service.navigateToReturnUrl({queryParams: {}});
        expect(location.assign).toHaveBeenCalledWith('/');
      });
    });

    describe('given return url', () => {
      it('should navigate to return url', () => {
        const url = '/current-url';
        service.navigateToReturnUrl({queryParams: {returnUrl: url}});
        expect(location.assign).toHaveBeenCalledWith(url);
      });

    });
  });

});
