import { UserService } from './user.service';
import { CacheService } from './cache.service';
import { User } from './user';

describe('UserService', () => {
  let cacheService: CacheService;
  let service: UserService;

  beforeEach(() => {
    cacheService = {
      getUser: () => null
    } as CacheService;
    service = new UserService(cacheService);
  });

  describe('cached user', () => {
    let user: User;

    beforeEach(() => {
      user = new User();
      spyOn(cacheService, 'getUser').and.returnValue(user);
    });

    it('is signed in should return true', () => {
      expect(service.getUser()).toBe(user);
    });

    it('should return the user', () => {
      expect(service.isSignedIn()).toBe(true);
    });
  });

  describe('no cached user', () => {
    it('is signed in should return false', () => {
      expect(service.isSignedIn()).toBe(false);
    });

    it('should return the null for get user', () => {
      expect(service.getUser()).toBeNull();
    });
  });
});
