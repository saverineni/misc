import { Injectable } from '@angular/core';
import { User } from './user';
import { isNil } from 'lodash';


@Injectable()
export class CacheService {
  static TOKEN_KEY = 'currentUser';
  static EXPIRATION_KEY = 'expires';

  getToken(): string {
    return localStorage.getItem(CacheService.TOKEN_KEY);
  }

  setToken(token: string) {
    localStorage.setItem(CacheService.TOKEN_KEY, token);
  }

  getExpiration(): number {
    return +localStorage.getItem(CacheService.EXPIRATION_KEY);
  }

  setExpiration(timeToLive: number) {
    localStorage.setItem(CacheService.EXPIRATION_KEY, String(timeToLive));
  }

  getUser(): User {
    const token = this.getToken();
    const userPayload = !isNil(token) ? token.split('.')[1] : undefined;

    if (userPayload) {
      return JSON.parse(window.atob(userPayload)).user as User;
    }
    return null;
  }

  clear() {
    localStorage.clear();
  }
}
