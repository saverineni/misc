import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable, EMPTY } from 'rxjs';
import { CacheService } from '../cache.service';
import { SignInRouterService } from '../sign-in/sign-in-router.service';
import {Router} from '@angular/router';

@Injectable()
export class RequestInterceptor implements HttpInterceptor {

  constructor(private cacheService: CacheService, private signInRouterService: SignInRouterService, private router: Router) {
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (req.url.includes('/build/info')) {
      return next.handle(req);
    }
    if (req.url !== '/api/authentication/token') {
      if (this.cacheService.getToken() == null) {
        this.signInRouterService.navigateToSignIn(this.router.routerState.snapshot);
        return EMPTY;
      } else {
        req = req.clone({
          setHeaders: {
            Authorization: `Bearer ${this.cacheService.getToken()}`
          }
        });
      }
    }
    return next.handle(req);
  }
}
