package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.lookup.domain;

import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Row;

import java.io.Serializable;

@Data
@Builder
public class Commodity implements Serializable {

    private String hub_commodity_key;
    private String chapter_description;
    private String heading_description;
    private String subheading_description;

    public static Commodity mapper(Row row) {
        return Commodity.builder()
                .hub_commodity_key(row.getString(0))
                .chapter_description(row.getString(1))
                .heading_description(row.getString(2))
                .subheading_description(row.getString(3))
                .build();

    }

}
