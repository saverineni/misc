package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.header.trader;

import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationPayingAgentTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationPayingAgentTraderReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatTraderReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.payingagent.DeclarationHeaderPayingAgentTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.payingagent.PayingAgentTrader;

import static org.apache.spark.sql.functions.broadcast;
import static org.apache.spark.sql.functions.column;

@Component
@Qualifier("DeclarationHeaderPayingAgentTraderDataset")
public class DeclarationHeaderPayingAgentTraderDataset implements TraderDataset {

    private static final String LEFT_OUTER_JOIN = "left_outer";
    private final LinkDeclarationPayingAgentTraderReader linkDeclarationPayingAgentTraderReader;
    private final SatTraderReader satTraderReader;

    @Autowired
    public DeclarationHeaderPayingAgentTraderDataset(LinkDeclarationPayingAgentTraderReader linkDeclarationPayingAgentTraderReader, SatTraderReader satTraderReader) {
        this.linkDeclarationPayingAgentTraderReader = linkDeclarationPayingAgentTraderReader;
        this.satTraderReader = satTraderReader;
    }

    public Dataset<DeclarationHeaderPayingAgentTrader> build() {
        Dataset<LinkDeclarationPayingAgentTrader> linkDeclarationPayingAgentTraderDataset = linkDeclarationPayingAgentTraderReader.linkDeclarationPayingAgentTraderDataset();
        Dataset<SatTrader> satTraderDataset = satTraderReader.satTraderDataset();

        Dataset<DeclarationHeaderPayingAgentTrader> headerPayingAgentTraderDataset = linkDeclarationPayingAgentTraderDataset
                .select(HubDeclaration.PRIMARY_COLUMN, hubTraderDatasetColumns)
                .join(broadcast(satTraderDataset), HubTrader.joinColumns, LEFT_OUTER_JOIN)
                .select(HubDeclaration.PRIMARY_COLUMN, headerTraderDatasetColumns)
                .withColumnRenamed(HubTrader.TURN_COLUMN, PayingAgentTrader.PAYING_AGENT_TRADER_TURN)
                .select(
                        column(HubDeclaration.PRIMARY_COLUMN),
                        traderDetails(PayingAgentTrader.PAYING_AGENT_TRADER_TURN).alias(DeclarationHeaderPayingAgentTrader.ALIAS)
                )
                .as(DeclarationHeaderPayingAgentTrader.declarationHeaderPayingAgentTraderEncoder);

        linkDeclarationPayingAgentTraderDataset.unpersist();

        return headerPayingAgentTraderDataset;
    }
}
