package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.lookup;

import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import scala.Tuple2;
import scala.reflect.ClassTag$;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub.HubCurrencyReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatCurrencyReader;

import java.util.Map;

@Component
public class CurrencyLookUp {

    private static final String CURRENCIES_VIEW = "currencies";
    public static final String CURRENCIES_SQL = "select currency_iso_code, currency_name from currencies";

    private final SparkSession sparkSession;
    private final HubCurrencyReader hubCurrencyReader;
    private final SatCurrencyReader satCurrencyReader;

    @Autowired
    public CurrencyLookUp(SparkSession sparkSession,HubCurrencyReader hubCurrencyReader,SatCurrencyReader satCurrencyReader){
        this.sparkSession = sparkSession;
        this.hubCurrencyReader = hubCurrencyReader;
        this.satCurrencyReader = satCurrencyReader;
    }

    public Broadcast<Map<String, String>> currenciesMap() {

        Dataset<HubCurrency> hubCurrencyDataset = hubCurrencyReader.hubCurrencyDataset();
        Dataset<SatCurrency> satCurrencyDataset = satCurrencyReader.satCurrencyDataset();

        //TODO - can map along with join.
        Dataset<Row> allCurrencies = hubCurrencyDataset.join(satCurrencyDataset, HubCurrency.joinColumns);
        allCurrencies.createOrReplaceTempView(CURRENCIES_VIEW);

        Dataset<Row> currencies = sparkSession.sql(CURRENCIES_SQL);
        Map<String, String> currenciesAsMap = currencies
                .toJavaRDD()
                .mapToPair(row -> new Tuple2<>(row.getString(0), row.getString(1)))
                .collectAsMap();
        return sparkSession.sparkContext().broadcast(currenciesAsMap, ClassTag$.MODULE$.apply(Map.class));
    }
}
