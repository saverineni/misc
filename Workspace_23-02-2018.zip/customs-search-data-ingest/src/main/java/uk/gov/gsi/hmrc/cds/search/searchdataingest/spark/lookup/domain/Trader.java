package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.lookup.domain;

import com.google.common.collect.ImmutableList;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;
import java.util.List;

@Data
public class Trader implements Serializable {
    public static Encoder<Trader> traderEncoder = Encoders.bean(Trader.class);

    private String turn;
    private String name;
    private String simplified_procedure_authorisations;
    private String trader_name_abbreviated;
    private String current_ind;

    public static final String PRIMARY_COLUMN = "turn";
    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            "name",
            "simplified_procedure_authorisations",
            "trader_name_abbreviated",
            "current_ind"
    );
}
