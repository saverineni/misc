package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.HUB_DOCUMENT;

@Component
public class HubDocumentReader extends DataVaultReader {
    private static final Encoder<HubDocument> hubDocumentEncoder = Encoders.bean(HubDocument.class);

    public Dataset hubDocumentDataset() {
        String dataFilePath = String.format("%s/%s", HUB_DOCUMENT.tableName(), datafileRelativePath);
        String hubDocumentFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<HubDocument> hubDocumentJavaRDD = sparkSession
                .read()
                .textFile(hubDocumentFilePath)
                .javaRDD()
                .map((Function<String, HubDocument>) HubDocument::mapper)
                .cache();

        return sparkSession
                .createDataFrame(hubDocumentJavaRDD, HubDocument.class)
                .as(hubDocumentEncoder)
                .cache();
    }

}
