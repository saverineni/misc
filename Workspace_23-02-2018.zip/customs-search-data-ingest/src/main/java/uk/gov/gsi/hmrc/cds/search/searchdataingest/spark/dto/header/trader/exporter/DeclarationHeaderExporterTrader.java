package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.exporter;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;

@Data
public class DeclarationHeaderExporterTrader implements Serializable {
    public static Encoder<DeclarationHeaderExporterTrader> declarationHeaderExporterTraderEncoder = Encoders.bean(DeclarationHeaderExporterTrader.class);
    private String hub_declaration_key;
    private ExporterTrader exporterTrader;

    public static final String ALIAS = "exporterTrader";
}
