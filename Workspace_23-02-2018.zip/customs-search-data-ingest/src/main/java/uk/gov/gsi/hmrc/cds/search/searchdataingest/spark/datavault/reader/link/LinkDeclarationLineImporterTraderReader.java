package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineImporterTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.LINK_DECLARATION_LINE_IMPORTER_TRADER;

@Component
public class LinkDeclarationLineImporterTraderReader extends DataVaultReader {
    private static final Encoder<LinkDeclarationLineImporterTrader> linkDeclarationLineImporterTraderEncoder = Encoders.bean(LinkDeclarationLineImporterTrader.class);

    public Dataset linkDeclarationLineImporterTraderDataset() {
        String dataFilePath = String.format("%s/%s", LINK_DECLARATION_LINE_IMPORTER_TRADER.tableName(), datafileRelativePath);
        String linkDeclarationLineImporterTraderFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<LinkDeclarationLineImporterTrader> linkDeclarationLineImporterTraderJavaRDD = sparkSession
                .read()
                .textFile(linkDeclarationLineImporterTraderFilePath)
                .javaRDD()
                .map((Function<String, LinkDeclarationLineImporterTrader>) LinkDeclarationLineImporterTrader::mapper)
                .cache();

        return sparkSession
                .createDataFrame(linkDeclarationLineImporterTraderJavaRDD, LinkDeclarationLineImporterTrader.class)
                .as(linkDeclarationLineImporterTraderEncoder)
                .cache();
    }

}
