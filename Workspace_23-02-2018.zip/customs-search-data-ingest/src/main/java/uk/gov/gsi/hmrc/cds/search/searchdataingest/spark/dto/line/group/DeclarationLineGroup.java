package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import lombok.Data;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.importer.ImporterTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.*;

import java.io.Serializable;
import java.util.List;

import static org.apache.spark.sql.functions.column;


@Data
public class DeclarationLineGroup implements Serializable {

    public static final Encoder<DeclarationLineGroup> declarationLineGroupEncoder = Encoders.bean(DeclarationLineGroup.class);

    private String hub_declaration_line_key;
    private String clearance_datetime;
    private String item_statistical_value;
    private String customs_duty_paid;
    private String vat_paid;
    private String ec_supplementary_1;
    private String item_customs_value;
    private String item_net_mass;
    private String item_supplementary_units;
    private String goods_description;
    private String item_customs_check_code;
    private String item_mic_code;
    private String item_profile_id;
    private String item_consignor_nad_name;
    private String item_consignee_nad_name;
    private String item_consignee_nad_postcode;
    private String vat_value;
    private String item_price_declared;


    private DeclarationLineCommodity commodity;
    private DeclarationCustomsProcedureCode customsProcedureCode;
    private DeclarationLineOriginCountry originCountry;
    private ImporterTrader importerTrader;
    private List<DeclarationLineDocument> documents = Lists.newArrayList();
    private List<DeclarationLineTaxLine> taxLines = Lists.newArrayList();
    private List<DeclarationLineAdditionalInfo> additionalInfo = Lists.newArrayList();
    private List<DeclarationLinePreviousDocument> previousDocuments = Lists.newArrayList();

}
