package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.country;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;


@Data
@Builder
public class DeclarationCountry implements Serializable {

    private DeclarationDestinationCountry destinationCountry;
    private DeclarationTransportCountry transportCountry;

    public static final String DECLARATION_COUNTRY_COLUMN = "declarationCountry";


}
