package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line.group;

import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line.DeclarationLineDocumentDataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLineDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLineDocumentGroup;

import static org.apache.spark.sql.functions.collect_list;
import static org.apache.spark.sql.functions.struct;

@Component
public class DeclarationLineDocumentGroupDataset {

    private final DeclarationLineDocumentDataset declarationLineDocumentDataset;

    @Autowired
    public DeclarationLineDocumentGroupDataset(DeclarationLineDocumentDataset declarationLineDocumentDataset) {
        this.declarationLineDocumentDataset = declarationLineDocumentDataset;
    }

    public Dataset<DeclarationLineDocumentGroup> build() {
        Dataset<DeclarationLineDocument> declarationLineDocumentDataset = this.declarationLineDocumentDataset.build();

        Dataset<DeclarationLineDocumentGroup> documentGroupDataset = declarationLineDocumentDataset.
                groupBy(declarationLineDocumentDataset.col(HubDeclarationLine.PRIMARY_COLUMN))
                .agg(
                        collect_list(
                                struct(
                                        declarationLineDocumentDataset.col(HubDocument.PRIMARY_COLUMN),
                                        declarationLineDocumentDataset.col(HubDocument.DOCUMENT_SEQUENCE_NUMBER_COLUMN),
                                        declarationLineDocumentDataset.col(DeclarationLineDocument.GENERATION_NUMBER),
                                        declarationLineDocumentDataset.col(SatDocument.ITEM_DOCUMENT_CODE_COLUMN),
                                        declarationLineDocumentDataset.col(SatDocument.ITEM_DOCUMENT_STATUS_COLUMN),
                                        declarationLineDocumentDataset.col(SatDocument.ITEM_DOCUMENT_REFERENCE_COLUMN)
                                )
                        ).alias(DeclarationLineDocumentGroup.ALIAS)
                )
                .as(DeclarationLineDocumentGroup.declarationLineDocumentGroupEncoder)
                .persist();

        declarationLineDocumentDataset.unpersist();

        return documentGroupDataset;
    }
}
