package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line;

import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.header.trader.TraderDataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineImporterTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationLineImporterTraderReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatTraderReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.importer.DeclarationHeaderImporterTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.importer.ImporterTrader;

import static org.apache.spark.sql.functions.broadcast;
import static org.apache.spark.sql.functions.column;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.importer.ImporterTrader.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.importer.ImporterTrader.lineImporterTraderEncoder;

@Component
public class DeclarationLineImporterTraderDataset implements TraderDataset {

    private static final String LEFT_OUTER_JOIN = "left_outer";
    private final LinkDeclarationLineImporterTraderReader linkDeclarationLineImporterTraderReader;
    private final SatTraderReader satTraderReader;

    @Autowired
    public DeclarationLineImporterTraderDataset(LinkDeclarationLineImporterTraderReader linkDeclarationLineImporterTraderReader, SatTraderReader satTraderReader) {
        this.linkDeclarationLineImporterTraderReader = linkDeclarationLineImporterTraderReader;
        this.satTraderReader = satTraderReader;
    }

    public Dataset<LineImporterTrader> build() {
        Dataset<LinkDeclarationLineImporterTrader> linkDeclarationLineImporterTraderDataset = linkDeclarationLineImporterTraderReader.linkDeclarationLineImporterTraderDataset();
        Dataset<SatTrader> satTraderDataset = satTraderReader.satTraderDataset();

        Dataset lineImporterTraderDataset = linkDeclarationLineImporterTraderDataset
                .join(broadcast(satTraderDataset),HubTrader.joinColumns, LEFT_OUTER_JOIN)
                .withColumnRenamed(HubTrader.TURN_COLUMN, ImporterTrader.IMPORTER_TRADER_TURN)
                .select(
                        column(HubDeclarationLine.PRIMARY_COLUMN),
                        traderDetails(ImporterTrader.IMPORTER_TRADER_TURN)
                                .alias(DeclarationHeaderImporterTrader.ALIAS)
                ).as(lineImporterTraderEncoder)
                .cache();

        lineImporterTraderDataset.unpersist();
        satTraderDataset.unpersist();

        return lineImporterTraderDataset;
    }
}
