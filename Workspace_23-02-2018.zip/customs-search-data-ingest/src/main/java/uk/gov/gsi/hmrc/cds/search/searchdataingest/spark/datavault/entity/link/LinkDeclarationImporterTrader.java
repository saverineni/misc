package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;

@Data
@Builder
public class LinkDeclarationImporterTrader implements Serializable, BaseEntity {

    private String link_declaration_importer_trader_key;
    private String hub_declaration_key;
    private String hub_trader_key;
    private String entry_reference;
    private String turn;
    private String link_load_datetime;
    private String link_record_source;

    public static LinkDeclarationImporterTrader mapper(String line) {
        List<String> columns = parseLine(line);

        return LinkDeclarationImporterTrader.builder()
                .link_declaration_importer_trader_key(columns.get(0))
                .hub_declaration_key(columns.get(1))
                .hub_trader_key(columns.get(2))
                .entry_reference(columns.get(3))
                .turn(columns.get(4))
                .link_load_datetime(columns.get(5))
                .link_record_source(columns.get(6))
                .build();
    }

    public static final String PRIMARY_COLUMN = "link_declaration_importer_trader_key";

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            "hub_declaration_key",
            "hub_trader_key"
    );
}
