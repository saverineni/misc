package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.SAT_COUNTRY;

@Component
public class SatCountryReader extends DataVaultReader {

    private static final Encoder<SatCountry> satCountryEncoder = Encoders.bean(SatCountry.class);

    public Dataset satCountryDataset() {
        String dataFilePath = String.format("%s/%s", SAT_COUNTRY.tableName(), datafileRelativePath);
        String satCountryFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<SatCountry> satCountryJavaRDD = sparkSession
                .read()
                .textFile(satCountryFilePath)
                .javaRDD()
                .map((Function<String, SatCountry>) SatCountry::mapper)
                .cache();

        return sparkSession
                .createDataFrame(satCountryJavaRDD, SatCountry.class)
                .as(satCountryEncoder)
                .cache();
    }
}
