package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.header.group;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationDestinationCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationTransportCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub.HubDeclarationReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationDestinationCountryReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationTransportCountryReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.country.DeclarationDestinationCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.country.DeclarationTransportCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group.DeclarationHeaderCountryGroup;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group.DeclarationHeaderCountryGroupEnriched;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.lookup.CountryLookUp;

import java.util.Map;

@Component
public class DeclarationHeaderCountryGroupDataset {

    private static final String LEFT_OUTER_JOIN = "left_outer";
    private static String[] datasetColumns = Iterables.toArray(
            Iterables.concat(
                    Lists.newArrayList(
                            DeclarationDestinationCountry.DESTINATION_ISO_COUNTRY_CODE,
                            DeclarationTransportCountry.TRANSPORT_ISO_COUNTRY_CODE
                    )
            )
            , String.class);

    private final CountryLookUp countryLookUp;
    private final HubDeclarationReader hubDeclarationReader;
    private final LinkDeclarationDestinationCountryReader linkDeclarationDestinationCountryReader;
    private final LinkDeclarationTransportCountryReader linkDeclarationTransportCountryReader;

    @Autowired
    public DeclarationHeaderCountryGroupDataset(CountryLookUp countryLookUp,HubDeclarationReader hubDeclarationReader,LinkDeclarationDestinationCountryReader linkDeclarationDestinationCountryReader,LinkDeclarationTransportCountryReader linkDeclarationTransportCountryReader){
        this.countryLookUp = countryLookUp;
        this.hubDeclarationReader = hubDeclarationReader;
        this.linkDeclarationDestinationCountryReader = linkDeclarationDestinationCountryReader;
        this.linkDeclarationTransportCountryReader = linkDeclarationTransportCountryReader;
    }

    public Dataset<DeclarationHeaderCountryGroupEnriched> build() {
        Dataset<HubDeclaration> hubDeclarationDataset = hubDeclarationReader.hubDeclarationDataset();
        Dataset<LinkDeclarationDestinationCountry> linkDeclarationDestinationCountryDataset = linkDeclarationDestinationCountryReader.linkDeclarationDestinationCountryDataset();
        Dataset<LinkDeclarationTransportCountry> linkDeclarationTransportCountryDataset = linkDeclarationTransportCountryReader.linkDeclarationTransportCountryDataset();

        Broadcast<Map<String, String>> countriesBroadcast = countryLookUp.countriesMap();
        Map<String, String> countriesMap = countriesBroadcast.value();

        Dataset headerDestinationCountryDataset = linkDeclarationDestinationCountryDataset
                .select(
                        linkDeclarationDestinationCountryDataset.col(HubDeclaration.PRIMARY_COLUMN),
                        linkDeclarationDestinationCountryDataset.col(LinkDeclarationDestinationCountry.COUNTRY_ISO_CODE)
                ).withColumnRenamed(LinkDeclarationDestinationCountry.COUNTRY_ISO_CODE, DeclarationDestinationCountry.DESTINATION_ISO_COUNTRY_CODE);


        Dataset headerTransportCountryDataset = linkDeclarationTransportCountryDataset
                .select(
                        linkDeclarationTransportCountryDataset.col(HubDeclaration.PRIMARY_COLUMN),
                        linkDeclarationTransportCountryDataset.col(LinkDeclarationTransportCountry.COUNTRY_ISO_CODE)
                )
                .withColumnRenamed(LinkDeclarationTransportCountry.COUNTRY_ISO_CODE, DeclarationTransportCountry.TRANSPORT_ISO_COUNTRY_CODE);


        Dataset<DeclarationHeaderCountryGroupEnriched> headerCountryGroupEnrichedDataset = hubDeclarationDataset
                .join(headerDestinationCountryDataset, HubDeclaration.joinColumns, LEFT_OUTER_JOIN)
                .join(headerTransportCountryDataset, HubDeclaration.joinColumns, LEFT_OUTER_JOIN)
                .select(HubDeclaration.PRIMARY_COLUMN, datasetColumns)
                .as(DeclarationHeaderCountryGroup.declarationHeaderCountryGroupEncoder)
                .map((MapFunction<DeclarationHeaderCountryGroup, DeclarationHeaderCountryGroupEnriched>) value -> DeclarationHeaderCountryGroupEnriched.mapper(value, countriesMap), DeclarationHeaderCountryGroupEnriched.headerCountryGroupEnrichedEncoder)
                .persist();

        headerDestinationCountryDataset.unpersist();
        headerTransportCountryDataset.unpersist();
        linkDeclarationDestinationCountryDataset.unpersist();
        linkDeclarationTransportCountryDataset.unpersist();

        countriesBroadcast.destroy();

        return headerCountryGroupEnrichedDataset;
    }
}
