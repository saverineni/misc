package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineAdditionalInfo;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.LINK_DECLARATION_LINE_ADDITIONAL_INFO;

@Component
public class LinkDeclarationLineAdditionalInfoReader extends DataVaultReader {
    private static final Encoder<LinkDeclarationLineAdditionalInfo> linkDeclarationLineAdditionalInfoEncoder = Encoders.bean(LinkDeclarationLineAdditionalInfo.class);

    public Dataset linkDeclarationLineAdditionalInfoDataset() {
        String dataFilePath = String.format("%s/%s", LINK_DECLARATION_LINE_ADDITIONAL_INFO.tableName(), datafileRelativePath);
        String linkDeclarationLineAdditionalInfoFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<LinkDeclarationLineAdditionalInfo> linkDeclarationLineAdditionalInfoJavaRDD = sparkSession
                .read()
                .textFile(linkDeclarationLineAdditionalInfoFilePath)
                .javaRDD()
                .map((Function<String, LinkDeclarationLineAdditionalInfo>) LinkDeclarationLineAdditionalInfo::mapper)
                .cache();

        return sparkSession
                .createDataFrame(linkDeclarationLineAdditionalInfoJavaRDD, LinkDeclarationLineAdditionalInfo.class)
                .as(linkDeclarationLineAdditionalInfoEncoder)
                .cache();
    }

}
