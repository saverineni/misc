package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import scala.collection.JavaConversions;
import scala.collection.mutable.Seq;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public interface BaseEntity {

    String DEFAULT_FILE_DELIMITER = "\\01";
    String HIVE_NULL_STRING = "\\N";
    String JAVA_NULL_STRING = "null";

    static List<String> parseLine(String line) {
        return Arrays
                .stream(line.split(DEFAULT_FILE_DELIMITER, -1))
                .map(s -> s.equals(HIVE_NULL_STRING) || s.equals(JAVA_NULL_STRING) ? null : s)
                .collect(Collectors.toList());
    }

    static String valueAt(Iterable<String> columns, int index) {
        return Iterables.get(columns,index, null);
    }

    static Seq<String> joinExpression(String... joinColumns) {
        return JavaConversions
                .asScalaBuffer(Lists.newArrayList(joinColumns));
    }

    static Seq<String> joinExpression(List<String> columns) {
        return JavaConversions
                .asScalaBuffer(columns);
    }

    static String[] toArray(List<String> columns) {
        return Iterables.toArray(columns, String.class);
    }


}
