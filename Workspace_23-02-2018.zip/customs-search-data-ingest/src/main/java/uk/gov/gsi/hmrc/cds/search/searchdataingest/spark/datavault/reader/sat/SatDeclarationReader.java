package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatDeclaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.SAT_DECLARATION;

@Component
public class SatDeclarationReader extends DataVaultReader {
    private static final Encoder<SatDeclaration> satDeclarationEncoder = Encoders.bean(SatDeclaration.class);

    public Dataset<SatDeclaration> satDeclarationDataset() {
        String dataFilePath = String.format("%s/%s", SAT_DECLARATION.tableName(), datafileRelativePath);
        String satDeclarationFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<SatDeclaration> satDeclarationJavaRDD = sparkSession
                .read()
                .textFile(satDeclarationFilePath)
                .javaRDD()
                .map((Function<String, SatDeclaration>) SatDeclaration::mapper)
                .cache();

        return sparkSession
                .createDataFrame(satDeclarationJavaRDD, SatDeclaration.class)
                .as(satDeclarationEncoder)
                .cache();
    }

}
