package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationInvoiceCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.LINK_DECLARATION_INVOICE_CURRENCY;

@Component
public class LinkDeclarationInvoiceCurrencyReader extends DataVaultReader {
    private static final Encoder<LinkDeclarationInvoiceCurrency> linkDeclarationInvoiceCurrencyEncoder = Encoders.bean(LinkDeclarationInvoiceCurrency.class);

    public Dataset<LinkDeclarationInvoiceCurrency> linkDeclarationInvoiceCurrencyDataset() {
        String dataFilePath = String.format("%s/%s", LINK_DECLARATION_INVOICE_CURRENCY.tableName(), datafileRelativePath);
        String linkDeclarationInvoiceCurrencyFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<LinkDeclarationInvoiceCurrency> linkDeclarationInvoiceCurrencyJavaRDD = sparkSession
                .read()
                .textFile(linkDeclarationInvoiceCurrencyFilePath)
                .javaRDD()
                .map((Function<String, LinkDeclarationInvoiceCurrency>) LinkDeclarationInvoiceCurrency::mapper)
                .cache();

        return sparkSession
                .createDataFrame(linkDeclarationInvoiceCurrencyJavaRDD, LinkDeclarationInvoiceCurrency.class)
                .as(linkDeclarationInvoiceCurrencyEncoder)
                .cache();
    }

}
