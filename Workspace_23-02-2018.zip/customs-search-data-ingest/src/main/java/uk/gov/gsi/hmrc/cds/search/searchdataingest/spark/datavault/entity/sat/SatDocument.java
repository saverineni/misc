package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;

@Data
@Builder
public class SatDocument implements Serializable, BaseEntity {

    private String hub_document_key;
    private String sat_hash_diff;
    private String sat_load_datetime;
    private String sat_load_end_datetime;
    private String sat_record_source;
    private String generation_number;
    private String item_document_code;
    private String item_document_status;
    private String item_document_reference;

    public static SatDocument mapper(String line) {
        List<String> columns = parseLine(line);

        return SatDocument.builder()
                .hub_document_key(columns.get(0))
                .sat_hash_diff(columns.get(1))
                .sat_load_datetime(columns.get(2))
                .sat_load_end_datetime(columns.get(3))
                .sat_record_source(columns.get(4))
                .generation_number(columns.get(5))
                .item_document_code(columns.get(6))
                .item_document_status(columns.get(7))
                .item_document_reference(columns.get(8))
                .build();
    }

    public static final String GENERATION_NUMBER_COLUMN = "generation_number";
    public static final String ITEM_DOCUMENT_CODE_COLUMN = "item_document_code";
    public static final String ITEM_DOCUMENT_STATUS_COLUMN = "item_document_status";
    public static final String ITEM_DOCUMENT_REFERENCE_COLUMN = "item_document_reference";

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            ITEM_DOCUMENT_CODE_COLUMN,
            ITEM_DOCUMENT_STATUS_COLUMN,
            ITEM_DOCUMENT_REFERENCE_COLUMN
    );
}
