package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatCurrency;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.SAT_CURRENCY;

@Component
public class SatCurrencyReader extends DataVaultReader {
    private static final Encoder<SatCurrency> satCurrencyEncoder = Encoders.bean(SatCurrency.class);

    public Dataset<SatCurrency> satCurrencyDataset() {
        String dataFilePath = String.format("%s/%s", SAT_CURRENCY.tableName(), datafileRelativePath);
        String satCurrencyFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<SatCurrency> satCurrencyJavaRDD = sparkSession
                .read()
                .textFile(satCurrencyFilePath)
                .javaRDD()
                .map((Function<String, SatCurrency>) SatCurrency::mapper)
                .cache();

        return sparkSession
                .createDataFrame(satCurrencyJavaRDD, SatCurrency.class)
                .as(satCurrencyEncoder)
                .cache();
    }

}
