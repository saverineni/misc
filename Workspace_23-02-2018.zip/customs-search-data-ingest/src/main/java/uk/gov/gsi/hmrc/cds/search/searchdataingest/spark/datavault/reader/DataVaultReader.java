package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader;

import com.google.common.collect.Iterables;
import org.apache.spark.sql.SparkSession;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class DataVaultReader {
    @Autowired
    public SparkSession sparkSession;

    @Autowired
    public String dataVaultHDFSBasePath;

    @Autowired
    public String datafileRelativePath;

    public String[] toArray(List<String> columns) {
        return Iterables.toArray(columns, String.class);
    }

}
