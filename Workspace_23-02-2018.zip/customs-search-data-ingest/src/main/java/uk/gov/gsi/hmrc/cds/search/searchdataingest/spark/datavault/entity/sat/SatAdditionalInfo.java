package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;

@Data
@Builder
public class SatAdditionalInfo implements Serializable, BaseEntity {

    private String hub_additional_info_key;
    private String sat_hash_diff;
    private String sat_load_datetime;
    private String sat_load_end_datetime;
    private String sat_record_source;
    private String generation_number;
    private String additional_information_statement;
    private String additional_information_statement_type;
    private String item_additional_information_statement;

    public static SatAdditionalInfo mapper(String line) {
        List<String> columns = parseLine(line);

        return SatAdditionalInfo.builder()
                .hub_additional_info_key(columns.get(0))
                .sat_hash_diff(columns.get(1))
                .sat_load_datetime(columns.get(2))
                .sat_load_end_datetime(columns.get(3))
                .sat_record_source(columns.get(4))
                .generation_number(columns.get(5))
                .additional_information_statement(columns.get(6))
                .additional_information_statement_type(columns.get(7))
                .item_additional_information_statement(columns.get(8))
                .build();
    }

    public static final String GENERATION_NUMBER_COLUMN = "generation_number";
    public static final String INFO_STATEMENT_COLUMN = "additional_information_statement";
    public static final String INFO_STATEMENT_TYPE_COLUMN = "additional_information_statement_type";
    public static final String ITEM_INFO_STATEMENT_COLUMN = "item_additional_information_statement";

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            GENERATION_NUMBER_COLUMN,
            INFO_STATEMENT_COLUMN,
            INFO_STATEMENT_TYPE_COLUMN,
            ITEM_INFO_STATEMENT_COLUMN
    );
}
