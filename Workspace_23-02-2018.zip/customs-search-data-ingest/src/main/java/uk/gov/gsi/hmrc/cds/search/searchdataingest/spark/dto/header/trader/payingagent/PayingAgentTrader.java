package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.payingagent;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;


@Data
public class PayingAgentTrader implements Serializable {
    public static Encoder<PayingAgentTrader> payingAgentTraderEncoder = Encoders.bean(PayingAgentTrader.class);
    private String paying_agent_trader_turn;
    private String name;
    private String simplified_procedure_authorisations;
    private String trader_name_abbreviated;
    private String current_ind;

    public static final String PAYING_AGENT_TRADER_TURN = "paying_agent_trader_turn";

}
