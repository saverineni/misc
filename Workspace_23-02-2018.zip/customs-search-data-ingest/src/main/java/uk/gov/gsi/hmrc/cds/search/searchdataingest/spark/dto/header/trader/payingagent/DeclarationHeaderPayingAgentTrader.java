package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.payingagent;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;

@Data
public class DeclarationHeaderPayingAgentTrader implements Serializable {
    public static Encoder<DeclarationHeaderPayingAgentTrader> declarationHeaderPayingAgentTraderEncoder = Encoders.bean(DeclarationHeaderPayingAgentTrader.class);
    private String hub_declaration_key;
    private PayingAgentTrader payingAgentTrader;

    public static final String ALIAS = "payingAgentTrader";
}
