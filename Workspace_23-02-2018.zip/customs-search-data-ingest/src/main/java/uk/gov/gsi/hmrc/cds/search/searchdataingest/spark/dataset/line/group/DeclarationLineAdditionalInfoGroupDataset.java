package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line.group;

import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.line.DeclarationLineAdditionalInfoDataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubAdditionalInfo;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatAdditionalInfo;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.DeclarationLineAdditionalInfo;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.line.group.DeclarationLineAdditionalInfoGroup;

import static org.apache.spark.sql.functions.collect_list;
import static org.apache.spark.sql.functions.struct;

@Component
public class DeclarationLineAdditionalInfoGroupDataset {

    private final DeclarationLineAdditionalInfoDataset declarationLineAdditionalInfoDataset;

    @Autowired
    public DeclarationLineAdditionalInfoGroupDataset(DeclarationLineAdditionalInfoDataset declarationLineAdditionalInfoDataset){
        this.declarationLineAdditionalInfoDataset = declarationLineAdditionalInfoDataset;
    }

    public Dataset<DeclarationLineAdditionalInfoGroup> build() {
        Dataset<DeclarationLineAdditionalInfo> declarationLineAdditionalInfoDataset = this.declarationLineAdditionalInfoDataset.build();

        Dataset<DeclarationLineAdditionalInfoGroup> additionalInfoGroupDataset = declarationLineAdditionalInfoDataset
                .groupBy(declarationLineAdditionalInfoDataset.col(HubDeclarationLine.PRIMARY_COLUMN))
                .agg(
                        collect_list(
                                struct(
                                        declarationLineAdditionalInfoDataset.col(HubAdditionalInfo.PRIMARY_COLUMN),
                                        declarationLineAdditionalInfoDataset.col(HubAdditionalInfo.INFO_SEQUENCE_NUMBER_COLUMN),
                                        declarationLineAdditionalInfoDataset.col(DeclarationLineAdditionalInfo.GENERATION_NUMBER),
                                        declarationLineAdditionalInfoDataset.col(SatAdditionalInfo.INFO_STATEMENT_COLUMN),
                                        declarationLineAdditionalInfoDataset.col(SatAdditionalInfo.INFO_STATEMENT_TYPE_COLUMN),
                                        declarationLineAdditionalInfoDataset.col(SatAdditionalInfo.ITEM_INFO_STATEMENT_COLUMN)
                                )
                        ).alias(DeclarationLineAdditionalInfoGroup.ALIAS))
                .as(DeclarationLineAdditionalInfoGroup.declarationLineAdditionalInfoGroupEncoder)
                .persist();

        declarationLineAdditionalInfoDataset.unpersist();

        return additionalInfoGroupDataset;
    }
}
