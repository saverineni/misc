package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub;

import com.google.common.collect.ImmutableList;
import lombok.Builder;
import lombok.Data;
import scala.collection.mutable.Seq;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.parseLine;

@Data
@Builder
public class HubDeclaration implements Serializable, BaseEntity {

    private String hub_declaration_key;
    private String entry_reference;
    private String hub_load_datetime;
    private String hub_record_source;

    public static HubDeclaration mapper(String line) {
        List<String> columns = parseLine(line);
        return HubDeclaration.builder()
                .hub_declaration_key(columns.get(0))
                .entry_reference(columns.get(1))
                .hub_load_datetime(columns.get(2))
                .hub_record_source(columns.get(3))
                .build();
    }

    public static final String PRIMARY_COLUMN = "hub_declaration_key";
    public static final String ENTRY_REFERENCE = "entry_reference";

    public static final List<String> SELECT_COLUMNS = ImmutableList.of(
            ENTRY_REFERENCE
    );
    public static Seq<String> joinColumns = joinExpression(PRIMARY_COLUMN);


}
