package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.HUB_COUNTRY;

@Component
public class HubCountryReader extends DataVaultReader {

    private static final Encoder<HubCountry> hubCountryEncoder = Encoders.bean(HubCountry.class);

    public Dataset hubCountryDataset() {
        String dataFilePath = String.format("%s/%s", HUB_COUNTRY.tableName(), datafileRelativePath);
        String hubCountryFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<HubCountry> hubCountryJavaRDD = sparkSession
                .read()
                .textFile(hubCountryFilePath)
                .javaRDD()
                .map((Function<String, HubCountry>) HubCountry::mapper)
                .cache();

        return sparkSession
                .createDataFrame(hubCountryJavaRDD, HubCountry.class)
                .as(hubCountryEncoder)
                .cache();
    }
}
