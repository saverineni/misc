package uk.gov.gsi.hmrc.cds.search.searchdataingest.config;

import org.apache.spark.sql.SparkSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

@Configuration
public class SparkConfig {

    @Autowired
    private Environment env;

    @Value("${app.name}")
    private String appName;

    @Value("${master.uri:local}")
    private String masterUri;

    @Bean
    public SparkSession sparkSession() {
        return SparkSession
                .builder()
                .appName(appName)
                .master(masterUri)
                .config("es.nodes", env.getProperty("es.nodes"))
                .config("es.nodes.wan.only", env.getProperty("es.nodes.wan.only"))
                .config("es.port", env.getProperty("es.port"))
                .config("es.resource", env.getProperty("es.resource"))
                .config("es.input.json", env.getProperty("es.input.json"))
                .config("es.http.timeout", env.getProperty("es.http.timeout"))
                .enableHiveSupport()
                .getOrCreate();
    }

}
