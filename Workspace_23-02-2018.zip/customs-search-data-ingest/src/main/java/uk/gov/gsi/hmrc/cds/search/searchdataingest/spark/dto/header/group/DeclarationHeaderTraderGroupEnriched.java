package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group;

import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.DeclarationTrader;

import java.io.Serializable;

@Data
@Builder
public class DeclarationHeaderTraderGroupEnriched implements Serializable {

    public static Encoder<DeclarationHeaderTraderGroupEnriched> headerTraderGroupEnrichedEncoder = Encoders.bean(DeclarationHeaderTraderGroupEnriched.class);

    private String hub_declaration_key;
    private DeclarationTrader declarationTrader;

    public static DeclarationHeaderTraderGroupEnriched mapper(DeclarationHeaderTraderGroup headerTraderGroup) {

        final DeclarationTrader declarationTrader = DeclarationTrader.builder()
                                                                    .consignorTrader(headerTraderGroup.getConsignorTrader())
                                                                    .declarantTrader(headerTraderGroup.getDeclarantTrader())
                                                                    .exporterTrader(headerTraderGroup.getExporterTrader())
                                                                    .importerTrader(headerTraderGroup.getImporterTrader())
                                                                    .payingAgentTrader(headerTraderGroup.getPayingAgentTrader())
                                                                    .build();

        return DeclarationHeaderTraderGroupEnriched.builder().hub_declaration_key(headerTraderGroup.getHub_declaration_key()).declarationTrader(declarationTrader).build();
    }

}
