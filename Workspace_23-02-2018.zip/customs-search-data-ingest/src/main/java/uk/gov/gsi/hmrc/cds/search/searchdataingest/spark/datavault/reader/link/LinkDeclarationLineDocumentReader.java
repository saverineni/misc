package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineDocument;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.DataVaultReader;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.CustomsDataVaultTables.LINK_DECLARATION_LINE_DOCUMENT;

@Component
public class LinkDeclarationLineDocumentReader extends DataVaultReader {
    private static final Encoder<LinkDeclarationLineDocument> linkDeclarationLineDocumentEncoder = Encoders.bean(LinkDeclarationLineDocument.class);

    public Dataset<LinkDeclarationLineDocument> linkDeclarationLineDocumentDataset() {
        String dataFilePath = String.format("%s/%s", LINK_DECLARATION_LINE_DOCUMENT.tableName(), datafileRelativePath);
        String linkDeclarationLineDocumentFilePath = String.format("%s/%s", dataVaultHDFSBasePath, dataFilePath);

        JavaRDD<LinkDeclarationLineDocument> linkDeclarationLineDocumentJavaRDD = sparkSession
                .read()
                .textFile(linkDeclarationLineDocumentFilePath)
                .javaRDD()
                .map((Function<String, LinkDeclarationLineDocument>) LinkDeclarationLineDocument::mapper)
                .cache();

        return sparkSession
                .createDataFrame(linkDeclarationLineDocumentJavaRDD, LinkDeclarationLineDocument.class)
                .as(linkDeclarationLineDocumentEncoder)
//                .select(PRIMARY_COLUMN, toArray(SELECT_COLUMNS))
                .cache();
    }

}
