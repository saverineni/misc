package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.header;

import com.google.common.collect.Iterables;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.header.group.DeclarationHeaderGroupDataset;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatDeclaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatDeclarationReader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.DeclarationHeader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.group.DeclarationHeaderGroup;

@Component
public class DeclarationHeaderDataset {
    private static String[] declarationHeaderDatasetColumns = Iterables.toArray(
            Iterables.concat(
                    SatDeclaration.SELECT_COLUMNS,
                    DeclarationHeaderGroup.SELECT_COLUMNS

            )
    , String.class);
    private static final String LEFT_OUTER_JOIN = "left_outer";
    private final DeclarationHeaderGroupDataset declarationHeaderGroupDataset;
    private final SatDeclarationReader satDeclarationReader;

    @Autowired
    public DeclarationHeaderDataset(DeclarationHeaderGroupDataset declarationHeaderGroupDataset, SatDeclarationReader satDeclarationReader) {
        this.declarationHeaderGroupDataset = declarationHeaderGroupDataset;
        this.satDeclarationReader = satDeclarationReader;
    }

    public Dataset<DeclarationHeader> build() {
        Dataset<DeclarationHeaderGroup> declarationHeaderGroupDataset = this.declarationHeaderGroupDataset.build();
        Dataset<SatDeclaration> satDeclarationDataset = satDeclarationReader.satDeclarationDataset();

        return declarationHeaderGroupDataset
                .join(satDeclarationDataset, HubDeclaration.joinColumns, LEFT_OUTER_JOIN)
                .select(HubDeclaration.PRIMARY_COLUMN, declarationHeaderDatasetColumns)
                .as(DeclarationHeader.declarationHeaderEncoder);
    }
}
