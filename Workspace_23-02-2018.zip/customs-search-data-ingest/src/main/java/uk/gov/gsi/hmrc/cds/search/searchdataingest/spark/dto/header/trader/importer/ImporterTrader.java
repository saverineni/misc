package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.header.trader.importer;

import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;

import java.io.Serializable;


@Data
public class ImporterTrader implements Serializable {
    public static Encoder<ImporterTrader> importerTraderEncoder = Encoders.bean(ImporterTrader.class);
    public static Encoder<LineImporterTrader> lineImporterTraderEncoder = Encoders.bean(LineImporterTrader.class);

    private String importer_trader_turn;
    private String name;
    private String simplified_procedure_authorisations;
    private String trader_name_abbreviated;
    private String current_ind;

    public static final String IMPORTER_TRADER_TURN = "importer_trader_turn";

    @Data
    public static class LineImporterTrader implements Serializable {
        private String hub_declaration_line_key;
        private ImporterTrader importerTrader;
    }


}
