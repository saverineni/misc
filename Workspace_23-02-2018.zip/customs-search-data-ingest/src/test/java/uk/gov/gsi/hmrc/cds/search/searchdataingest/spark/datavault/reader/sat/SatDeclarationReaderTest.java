package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatDeclaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatDeclarationReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class SatDeclarationReaderTest extends SparkTest {

    @Autowired
    SatDeclarationReader satDeclarationReader;

    @Test
    public void buildsSatDeclarationDataset() throws Exception {
        final Dataset<SatDeclaration> satDeclarationDataset = satDeclarationReader.satDeclarationDataset();
        assertThat(satDeclarationDataset.count(), is(greaterThan(0l)));

        satDeclarationDataset.printSchema();
        final String[] fieldNames = satDeclarationDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(satDeclarationStructFields));

        final String[] selectedFieldNames = satDeclarationDataset.selectExpr(joinExpression(SatDeclaration.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(satDeclarationSelectedStructFields));

        // Test that "null" is replaced by literal null
        assertThat(satDeclarationDataset.select("master_ucr").head().get(0), nullValue());
        // Test that "\\N" is replaced by literal null
        assertThat(satDeclarationDataset.select("sat_load_end_datetime").head().get(0), nullValue());
    }

    private String[] satDeclarationStructFields = toArray(
            Lists.newArrayList("acceptance_date",
                    "consignee_aeo_certificate_type_code",
                    "consignee_nad_name",
                    "consignee_nad_postcode",
                    "consignor_aeo_certificate_type_code",
                    "consignor_nad_name",
                    "consignor_turn_country_code",
                    "customs_check_code",
                    "customs_value",
                    "declarant_aeo_certificate_type_code",
                    "declarant_nad_name",
                    "declarant_representative_turn",
                    "declaration_import_export_indicator",
                    "declaration_method",
                    "declaration_ucr",
                    "dispatch_country",
                    "entry_date",
                    "entry_number",
                    "entry_type",
                    "epu_number",
                    "first_deferment_approval_num",
                    "first_deferment_approval_num_prefix",
                    "generation_number",
                    "goods_departure_datetime",
                    "goods_location",
                    "header_statistical_value",
                    "hub_declaration_key",
                    "import_clearance_status",
                    "importer_turn_country_code",
                    "invoice_total_declared",
                    "item_count",
                    "master_ucr",
                    "net_mass_total",
                    "paying_agent_turn",
                    "place_of_loading_code",
                    "place_of_unloading_code",
                    "profile_id",
                    "route",
                    "sat_hash_diff",
                    "sat_load_datetime",
                    "sat_load_end_datetime",
                    "sat_record_source",
                    "session_num",
                    "session_role_name",
                    "status_of_entry",
                    "total_duty",
                    "total_excise",
                    "total_vat",
                    "transport_country",
                    "transport_id",
                    "transport_mode_code")
    );

    private String[] satDeclarationSelectedStructFields = toArray(
            Lists.newArrayList("entry_number",
                    "entry_date",
                    "epu_number",
                    "entry_type",
                    "declaration_method",
                    "total_excise",
                    "declarant_representative_turn",
                    "consignee_aeo_certificate_type_code",
                    "declarant_aeo_certificate_type_code",
                    "route",
                    "declaration_import_export_indicator",
                    "generation_number",
                    "import_clearance_status",
                    "consignor_aeo_certificate_type_code",
                    "header_statistical_value",
                    "goods_departure_datetime",
                    "customs_value",
                    "total_duty",
                    "total_vat",
                    "net_mass_total",
                    "goods_location",
                    "acceptance_date",
                    "importer_turn_country_code",
                    "place_of_unloading_code",
                    "first_deferment_approval_num",
                    "first_deferment_approval_num_prefix",
                    "declaration_ucr",
                    "item_count",
                    "master_ucr",
                    "paying_agent_turn",
                    "place_of_loading_code",
                    "session_num",
                    "session_role_name",
                    "status_of_entry",
                    "transport_country",
                    "transport_id",
                    "transport_mode_code",
                    "dispatch_country",
                    "consignor_turn_country_code",
                    "consignor_nad_name",
                    "consignee_nad_name",
                    "consignee_nad_postcode",
                    "declarant_nad_name",
                    "customs_check_code",
                    "profile_id",
                    "invoice_total_declared")
    );
}



