package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationConsignorTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationConsignorTraderReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;

public class LinkDeclarationConsignorTraderReaderTest extends SparkTest {

    @Autowired
    LinkDeclarationConsignorTraderReader linkDeclarationConsignorTraderReader;

    @Test
    public void buildsLinkDeclarationConsignorTraderDataset() throws Exception {
        final Dataset<LinkDeclarationConsignorTrader> linkDeclarationConsignorTraderDataset = linkDeclarationConsignorTraderReader.linkDeclarationConsignorTraderDataset();
        assertThat(linkDeclarationConsignorTraderDataset.count(), is(greaterThan(0l)));

        linkDeclarationConsignorTraderDataset.printSchema();
        final String[] fieldNames = linkDeclarationConsignorTraderDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(linkDeclarationConsignorTraderStructFields));

        final String[] selectedFieldNames = linkDeclarationConsignorTraderDataset.select(LinkDeclarationConsignorTrader.PRIMARY_COLUMN , joinExpression(LinkDeclarationConsignorTrader.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(linkDeclarationConsignorTraderSelectedStructFields));
    }

    private String[] linkDeclarationConsignorTraderStructFields = toArray(
            Lists.newArrayList("entry_reference",
                    "hub_declaration_key",
                    "hub_trader_key",
                    "link_declaration_consignor_trader_key",
                    "link_load_datetime",
                    "link_record_source",
                    "turn")
    );

    private String[] linkDeclarationConsignorTraderSelectedStructFields = toArray(
            Lists.newArrayList("link_declaration_consignor_trader_key",
                    "hub_declaration_key",
                    "hub_trader_key")
    );
}

