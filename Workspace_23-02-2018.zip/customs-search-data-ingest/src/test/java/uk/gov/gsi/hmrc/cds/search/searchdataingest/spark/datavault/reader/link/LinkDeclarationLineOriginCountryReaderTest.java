package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineOriginCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationLineOriginCountryReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class LinkDeclarationLineOriginCountryReaderTest  extends SparkTest {

    @Autowired
    LinkDeclarationLineOriginCountryReader linkDeclarationLineOriginCountryReader;

    @Test
    public void buildsLinkDeclarationLineOriginCountryDataset() throws Exception {
        final Dataset<LinkDeclarationLineOriginCountry> linkDeclarationLineOriginCountryDataset = linkDeclarationLineOriginCountryReader.linkDeclarationLineOriginCountryDataset();
        assertThat(linkDeclarationLineOriginCountryDataset.count(), is(greaterThan(0l)));

        linkDeclarationLineOriginCountryDataset.printSchema();
        final String[] fieldNames = linkDeclarationLineOriginCountryDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(linkDeclarationLineOriginCountryStructFields));

        final String[] selectedFieldNames = linkDeclarationLineOriginCountryDataset.select(LinkDeclarationLineOriginCountry.PRIMARY_COLUMN , joinExpression(LinkDeclarationLineOriginCountry.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(linkDeclarationLineOriginCountrySelectedStructFields));
    }

    private String[] linkDeclarationLineOriginCountryStructFields = toArray(
            Lists.newArrayList("entry_reference",
                    "hub_country_key",
                    "hub_declaration_line_key",
                    "iso_country_code_alpha_2",
                    "item_number",
                    "link_declaration_line_origin_country_key",
                    "link_load_datetime",
                    "link_record_source")
    );

    private String[] linkDeclarationLineOriginCountrySelectedStructFields = toArray(
            Lists.newArrayList("link_declaration_line_origin_country_key",
                    "hub_country_key",
                    "hub_declaration_line_key")
    );
}


