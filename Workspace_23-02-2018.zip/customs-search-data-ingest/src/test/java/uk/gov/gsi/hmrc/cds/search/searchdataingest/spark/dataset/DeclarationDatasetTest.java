package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dto.Declaration;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.dataset.TestConstants.DECLARATION_HEADER_COUNT;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class DeclarationDatasetTest extends SparkTest implements DeclarationStructure{

    @Autowired
    private DeclarationDataset declarationDataset;

    private Dataset<Declaration> dataset;

    @Before
    public void build(){
        dataset = declarationDataset.build();
    }

    @After
    public void cleanup() {
        dataset.unpersist();
    }

    @Test
    public void validateDeclarationFields() {
        final String[] fieldNames = dataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(declarationStructFields));

        assertThat(dataset.count(), is(equalTo(DECLARATION_HEADER_COUNT)));
    }


    private static String[] declarationStructFields = toArray(
            Lists.newArrayList(
                    "hub_declaration_key",
                    "entry_reference",
                    "entry_number",
                    "entry_date",
                    "epu_number",
                    "entry_type",
                    "declaration_method",
                    "total_excise",
                    "declarant_representative_turn",
                    "consignee_aeo_certificate_type_code",
                    "declarant_aeo_certificate_type_code",
                    "route",
                    "declaration_import_export_indicator",
                    "generation_number",
                    "import_clearance_status",
                    "consignor_aeo_certificate_type_code",
                    "header_statistical_value",
                    "goods_departure_datetime",
                    "customs_value",
                    "total_duty",
                    "total_vat",
                    "net_mass_total",
                    "goods_location",
                    "acceptance_date",
                    "importer_turn_country_code",
                    "place_of_unloading_code",
                    "first_deferment_approval_num",
                    "first_deferment_approval_num_prefix",
                    "declaration_ucr",
                    "item_count",
                    "master_ucr",
                    "paying_agent_turn",
                    "place_of_loading_code",
                    "session_num",
                    "session_role_name",
                    "status_of_entry",
                    "transport_country",
                    "transport_id",
                    "transport_mode_code",
                    "dispatch_country",
                    "consignor_turn_country_code",
                    "consignor_nad_name",
                    "consignee_nad_name",
                    "consignee_nad_postcode",
                    "declarant_nad_name",
                    "customs_check_code",
                    "profile_id",
                    "invoice_total_declared",
                    "declarationCurrency",
                    "declarationCountry",
                    "declarationTrader",
                    "lines")
    );

}
