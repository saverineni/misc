package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.hub.HubDeclaration;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.hub.HubDeclarationReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class HubDeclarationReaderTest extends SparkTest {

    @Autowired
    HubDeclarationReader hubDeclarationReader;

    @Test
    public void buildsHubDeclarationDataset() throws Exception {
        final Dataset<HubDeclaration> hubDeclarationDataset = hubDeclarationReader.hubDeclarationDataset();
        assertThat(hubDeclarationDataset.count(), is(greaterThan(0l)));

        hubDeclarationDataset.printSchema();
        final String[] fieldNames = hubDeclarationDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(hubDeclarationStructFields));

        final String[] selectedFieldNames = hubDeclarationDataset.select(HubDeclaration.PRIMARY_COLUMN , joinExpression(HubDeclaration.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(hubDeclarationSelectedStructFields));
    }

    private static String[] hubDeclarationStructFields = toArray(
            Lists.newArrayList("entry_reference",
                    "hub_declaration_key",
                    "hub_load_datetime",
                    "hub_record_source")
    );

    private static String[] hubDeclarationSelectedStructFields = toArray(
            Lists.newArrayList("hub_declaration_key",
                    "entry_reference")
    );
}
