package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationDeclarantTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationDeclarantTraderReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;

public class LinkDeclarationDeclarantTraderReaderTest extends SparkTest {

    @Autowired
    LinkDeclarationDeclarantTraderReader linkDeclarationDeclarantTraderReader;

    @Test
    public void buildsLinkDeclarationDeclarantTraderDataset() throws Exception {
        final Dataset<LinkDeclarationDeclarantTrader> linkDeclarationDeclarantTraderDataset = linkDeclarationDeclarantTraderReader.linkDeclarationDeclarantTraderDataset();
        assertThat(linkDeclarationDeclarantTraderDataset.count(), is(greaterThan(0l)));

        linkDeclarationDeclarantTraderDataset.printSchema();
        final String[] fieldNames = linkDeclarationDeclarantTraderDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(linkDeclarationDeclarantTraderStructFields));

        final String[] selectedFieldNames = linkDeclarationDeclarantTraderDataset.select(LinkDeclarationDeclarantTrader.PRIMARY_COLUMN , joinExpression(LinkDeclarationDeclarantTrader.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(linkDeclarationDeclarantTraderSelectedStructFields));
    }

    private String[] linkDeclarationDeclarantTraderStructFields = toArray(
            Lists.newArrayList("entry_reference",
                    "hub_declaration_key",
                    "hub_trader_key",
                    "link_declaration_declarant_trader_key",
                    "link_load_datetime",
                    "link_record_source",
                    "turn")
    );

    private String[] linkDeclarationDeclarantTraderSelectedStructFields = toArray(
            Lists.newArrayList("link_declaration_declarant_trader_key",
                    "hub_declaration_key",
                    "hub_trader_key")
    );
}
