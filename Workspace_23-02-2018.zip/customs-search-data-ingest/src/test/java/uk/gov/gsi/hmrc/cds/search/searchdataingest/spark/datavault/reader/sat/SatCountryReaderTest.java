package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatCountry;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatCountryReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class SatCountryReaderTest extends SparkTest {

    @Autowired
    SatCountryReader satCountryReader;

    @Test
    public void buildsSatCountryDataset() throws Exception {
        final Dataset<SatCountry> satCountryDataset = satCountryReader.satCountryDataset();
        assertThat(satCountryDataset.count(), is(greaterThan(0l)));

        satCountryDataset.printSchema();
        final String[] fieldNames = satCountryDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(satCountryStructFields));

        final String[] selectedFieldNames = satCountryDataset.selectExpr(joinExpression(SatCountry.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(satCountrySelectedStructFields));
    }

    private String[] satCountryStructFields = toArray(
            Lists.newArrayList("country_comments",
                    "country_name",
                    "country_sequence_number",
                    "hub_country_key",
                    "sat_hash_diff",
                    "sat_load_datetime",
                    "sat_load_end_datetime",
                    "sat_record_source")
    );

    private String[] satCountrySelectedStructFields = toArray(
            Lists.newArrayList("country_name",
                    "country_sequence_number",
                    "country_comments")
    );
}


