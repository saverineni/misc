package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.link.LinkDeclarationLineImporterTrader;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.link.LinkDeclarationLineImporterTraderReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class LinkDeclarationLineImporterTraderReaderTest extends SparkTest {

    @Autowired
    LinkDeclarationLineImporterTraderReader linkDeclarationLineImporterTraderReader;

    @Test
    public void buildsLinkDeclarationImporterTraderDataset() throws Exception {
        final Dataset<LinkDeclarationLineImporterTrader> linkDeclarationLineImporterTraderDataset = linkDeclarationLineImporterTraderReader.linkDeclarationLineImporterTraderDataset();
        assertThat(linkDeclarationLineImporterTraderDataset.count(), is(greaterThan(0l)));

        linkDeclarationLineImporterTraderDataset.printSchema();
        final String[] fieldNames = linkDeclarationLineImporterTraderDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(linkDeclarationLineImporterTraderStructFields));

        final String[] selectedFieldNames = linkDeclarationLineImporterTraderDataset.select(LinkDeclarationLineImporterTrader.PRIMARY_COLUMN , joinExpression(LinkDeclarationLineImporterTrader.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(linkDeclarationLineImporterTraderSelectedStructFields));
    }

    private String[] linkDeclarationLineImporterTraderStructFields = toArray(
            Lists.newArrayList("entry_reference",
                    "hub_declaration_line_key",
                    "hub_trader_key",
                    "item_number",
                    "link_declaration_line_importer_trader_key",
                    "link_load_datetime",
                    "link_record_source",
                    "turn")
    );

    private String[] linkDeclarationLineImporterTraderSelectedStructFields = toArray(
            Lists.newArrayList("link_declaration_line_importer_trader_key",
                    "hub_trader_key",
                    "hub_declaration_line_key")
    );
}

