package uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.sat.SatDeclarationLine;
import uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.reader.sat.SatDeclarationLineReader;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.joinExpression;
import static uk.gov.gsi.hmrc.cds.search.searchdataingest.spark.datavault.entity.BaseEntity.toArray;

public class SatDeclarationLineReaderTest extends SparkTest {

    @Autowired
    SatDeclarationLineReader satDeclarationLineReader;

    @Test
    public void buildsSatDeclarationLineDataset() throws Exception {
        final Dataset<SatDeclarationLine> satDeclarationLineDataset = satDeclarationLineReader.satDeclarationLineDataset();
        assertThat(satDeclarationLineDataset.count(), is(greaterThan(0l)));

        satDeclarationLineDataset.printSchema();
        final String[] fieldNames = satDeclarationLineDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(satDeclarationLineStructFields));

        final String[] selectedFieldNames = satDeclarationLineDataset.selectExpr(joinExpression(SatDeclarationLine.SELECT_COLUMNS)).schema().fieldNames();
        assertThat(Arrays.asList(selectedFieldNames), contains(satDeclarationLineSelectedStructFields));
    }

    private String[] satDeclarationLineStructFields = toArray(
            Lists.newArrayList("clearance_datetime",
                    "customs_duty_paid",
                    "ec_supplementary_1",
                    "goods_description",
                    "hub_declaration_line_key",
                    "item_consignee_nad_name",
                    "item_consignee_nad_postcode",
                    "item_consignor_nad_name",
                    "item_customs_check_code",
                    "item_customs_value",
                    "item_mic_code",
                    "item_net_mass",
                    "item_price_declared",
                    "item_profile_id",
                    "item_statistical_value",
                    "item_supplementary_units",
                    "sat_hash_diff",
                    "sat_load_datetime",
                    "sat_load_end_datetime",
                    "sat_record_source",
                    "vat_paid",
                    "vat_value")
    );

    private String[] satDeclarationLineSelectedStructFields = toArray(
            Lists.newArrayList("clearance_datetime",
                    "item_statistical_value",
                    "customs_duty_paid",
                    "vat_paid",
                    "ec_supplementary_1",
                    "item_customs_value",
                    "item_net_mass",
                    "item_supplementary_units",
                    "goods_description",
                    "item_customs_check_code",
                    "item_mic_code",
                    "item_profile_id",
                    "item_consignor_nad_name",
                    "item_consignee_nad_name",
                    "item_consignee_nad_postcode",
                    "vat_value",
                    "item_price_declared")
    );
}


