#!/bin/bash

hdfs dfs -rm -r /user/osboxes/spark/dv_v3/dv
hdfs dfs -mkdir -p /user/osboxes/spark/dv_v3/dv

APPLICATION_VERSION=$(grep -m1 '<version>' ./pom.xml | cut -c11- | rev | cut -d"<" -f2 | rev)

hdfs dfs -copyFromLocal ./src/test/resources/dv/* /user/osboxes/spark/dv_v3/dv
mvn clean package -DskipTests=true
spark-submit ./target/customs-search-data-ingest-APPLICATION_VERSION.jar