package uk.gov.gsi.hmrc.cds.search.api.resources;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.jayway.restassured.http.ContentType;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import uk.gov.gsi.hmrc.cds.search.run.CustomsSearchServiceApplication;
import uk.gov.gsi.hmrc.cds.search.security.JwtTokenService;
import uk.gov.gsi.hmrc.cds.search.utils.TestHelper;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static uk.gov.gsi.hmrc.cds.search.utils.TestHelper.*;


@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest(
        classes = CustomsSearchServiceApplication.class,
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT
)
@AutoConfigureMockMvc
public class DeclarationResourceIntegrationTest {

    private WireMockServer wireMockServer;

    @Value("${elasticsearch.host}")
    private String elasticSearchHost;

    @Value("${elasticsearch.port}")
    private int elasticSearchPort;

    @Value("${elasticsearch.query.uri}")
    private String elasticIdQuery;

    @Autowired
    MockMvc mockMvc;

    @Autowired
    private JwtTokenService jwtTokenService;

    private String jwtToken;

    @Before
    public void setup() {
        wireMockServer = new WireMockServer ( elasticSearchPort );
        wireMockServer.start ();

        configureFor ( elasticSearchHost, elasticSearchPort );
        jwtToken = jwtTokenService.createToken(new UsernamePasswordAuthenticationToken("dev", "dev"));
    }

    @After
    public void destroy() {
        wireMockServer.stop ();
    }

    @Test
    public void shouldGetErrorResponse_whenDeclarationNotFoundExceptionThrown() throws Exception {

        givenThat ( WireMock.get
                ( urlEqualTo
                        ( elasticIdQuery ) )
                .withHeader ( CONTENT_TYPE_FIELD, com.github.tomakehurst.wiremock.client.WireMock.equalTo ( ContentType.JSON.toString () ) )
                .withRequestBody ( equalToJson ( formatIdQuery ( INVALID_DECALARATION_ID ) ) )
                .willReturn ( aResponse ().withStatus ( 200 )
                        .withHeader ( HttpHeaders.CONTENT_TYPE, ContentType.JSON.toString () )
                        .withBody ( TestHelper.getFileContent ( INVALID_DECLARATION_FILE ) ) ) );

        mockMvc.perform(get("/declaration")
                .header("Authorization", String.format("Bearer %s", jwtToken))
        		.accept(MediaType.APPLICATION_JSON )
        		.param( DECLARATION_ID, INVALID_DECALARATION_ID ))
            .andExpect(status().isNotFound())
            .andExpect(content().json( getInvalidDeclarationMessage ( INVALID_DECALARATION_ID ) ) );
    }

    @Test
    public void shouldGetErrorResponseWithStatus_BAD_REQUEST_whenDeclarationIdIsMissing() throws Exception {
        mockMvc.perform(get("/declaration")
                .header("Authorization", String.format("Bearer %s", jwtToken))
        		.accept(MediaType.APPLICATION_JSON )
        		.param( DECLARATION_ID, "" ))
            .andExpect(status().isBadRequest())
            .andExpect(content().json(BAD_REQUEST_MESSAGE));
    }

    @Test
    public void givenValidDeclarationId_shouldGetV1DeclarationDataWithStatusOK() throws Exception {

        String jsonContent = TestHelper.getFileContent ( VALID_STUB_DECLARATION_FILE );

        givenEleasticSearchDeclaration(VALID_SEARCH_DECLARATION_FILE);

        mockMvc.perform(get("/declaration")
                .header("Authorization", String.format("Bearer %s", jwtToken))
                .accept(MediaType.APPLICATION_JSON )
                .param( DECLARATION_ID, VALID_DECALARATION_ID ))
            .andExpect(status().isOk())
            .andExpect(content().json(jsonContent));
    }

    @Test
    public void givenValidDeclarationId_shouldGetV1DeclarationDataWithStatusOKOnApiContext() throws Exception {

        String jsonContent = TestHelper.getFileContent ( VALID_STUB_DECLARATION_FILE );

        givenEleasticSearchDeclaration(VALID_SEARCH_DECLARATION_FILE);

        mockMvc.perform(get("/api/declaration")
                .header("Authorization", String.format("Bearer %s", jwtToken))
                .accept(MediaType.APPLICATION_JSON )
                .param( DECLARATION_ID, VALID_DECALARATION_ID ))
            .andExpect(status().isOk())
            .andExpect(content().json(jsonContent));

    }

    @Test
    public void givenValidDeclarationId_withMinimalData_shouldGetStatusOKOnApiContext() throws Exception {

        String jsonContent = TestHelper.getFileContent (VALID_STUB_DECLARATION_MINIMAL_DATA_FILE);

        givenEleasticSearchDeclaration(VALID_SEARCH_DECLARATION_MINIMAL_DATA_FILE);

        mockMvc.perform(get("/api/declaration")
                .header("Authorization", String.format("Bearer %s", jwtToken))
                .accept(MediaType.APPLICATION_JSON )
                .param( DECLARATION_ID, VALID_DECALARATION_ID ))
                .andExpect(status().isOk())
                .andExpect(content().json(jsonContent));

    }

    private void givenEleasticSearchDeclaration(String validSearchDeclarationFile) {
        givenThat ( WireMock.get
                ( urlEqualTo
                        ( elasticIdQuery ) )
                .withHeader ( CONTENT_TYPE_FIELD, com.github.tomakehurst.wiremock.client.WireMock.equalTo ( ContentType.JSON.toString () ) )
                .withRequestBody ( equalToJson ( formatIdQuery ( VALID_DECALARATION_ID ) ) )
                .willReturn ( aResponse ().withStatus ( 200 )
                        .withHeader ( HttpHeaders.CONTENT_TYPE, ContentType.JSON.toString () )
                        .withBody ( TestHelper.getFileContent (validSearchDeclarationFile) ) ) );
    }

    @Test
    public void givenValidDeclarationIdButNotLoggedIn_shouldGetUnauthorisedStatus() throws Exception {
        mockMvc.perform(get("/declaration")
        		.accept(MediaType.APPLICATION_JSON )
        		.param( DECLARATION_ID, VALID_DECALARATION_ID ))
            .andExpect(status().isUnauthorized());

    }

    @Test
    public void givenValidDeclarationId_whenESisDown_shouldGetConnectionException() throws Exception {

        String jsonContent = TestHelper.getFileContent ( IO_EXCEPTION_FILE );

        wireMockServer.stop ();
        mockMvc.perform(get("/declaration")
                .header("Authorization", String.format("Bearer %s", jwtToken))
        		.accept(MediaType.APPLICATION_JSON )
        		.param( DECLARATION_ID, VALID_DECALARATION_ID ))
            .andExpect(status().isInternalServerError())
            .andExpect(content().json(jsonContent));
    }

}