package uk.gov.gsi.hmrc.cds.search.security.jwt;

import org.junit.Test;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class SkipPathRequestMatcherTest {

    private HttpServletRequest request = mock(HttpServletRequest.class);
    private List<String> skipPaths = Arrays.asList("/login","/webjars");

    private List<String> processPaths = Arrays.asList("/declaration", "/api/declaration", "/declaration/**", "/api/declaration/**");
    private SkipPathRequestMatcher skipPathRequestMatcher = new SkipPathRequestMatcher(skipPaths,processPaths);

    @Test
    public void matchesForValidPathsDeclaration() {
        String declarationServletPath = "/declaration";
        String apiDeclarationServletPath = "/api/declaration";

        when(request.getServletPath()).thenReturn(declarationServletPath);
        assertTrue(skipPathRequestMatcher.matches(request));

        when(request.getServletPath()).thenReturn(apiDeclarationServletPath);
        assertTrue(skipPathRequestMatcher.matches(request));

        when(request.getServletPath()).thenReturn(apiDeclarationServletPath);
        when(request.getPathInfo()).thenReturn("/pathinfo/more");
        assertTrue(skipPathRequestMatcher.matches(request));

        when(request.getServletPath()).thenReturn(declarationServletPath);
        when(request.getPathInfo()).thenReturn("/pathinfo/more");
        assertTrue(skipPathRequestMatcher.matches(request));
    }


    @Test
    public void matchesForSkipPathLogin() {
        when(request.getServletPath()).thenReturn("/login");
        assertFalse(skipPathRequestMatcher.matches(request));
    }

    @Test
    public void matchesForSkipPathWebjars() {
        when(request.getServletPath()).thenReturn("/webjars");
        assertFalse(skipPathRequestMatcher.matches(request));
    }

    @Test
    public void matchesReturnFalseForUnknownPath() {
        when(request.getServletPath()).thenReturn("/unknown");
        assertFalse(skipPathRequestMatcher.matches(request));

        when(request.getServletPath()).thenReturn("/declarations");
        assertFalse(skipPathRequestMatcher.matches(request));

        when(request.getServletPath()).thenReturn("/declaration?");
        assertFalse(skipPathRequestMatcher.matches(request));
    }
}