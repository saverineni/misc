package uk.gov.gsi.hmrc.cds.search.utils;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class TestHelper {

    public static final String API_PATH = "";
    public static final String V1_DECLARATION_MEDIA_TYPE = "application/json";

    public static final String LOGIN_URL = "/login";
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";

    public static final String SUPER_USER = "superdev";
    public static final String SUPER_USER_PASSWORD = "superdev";

    public static final String DEV_USER = "dev";
    public static final String DEV_USER_PASSWORD = "dev";

    public static final String DECLARATION_ID = "declarationId";

    public static final String CONTENT_TYPE_FIELD = "content-type";

    public static final String VALID_DECALARATION_ID = "670-954107X-2017-08-22";
    public static final String INVALID_DECALARATION_ID = "declarationId-notpresent";

    public static final String BAD_REQUEST_MESSAGE = "{\"error\":{\"message\":\"declarationId is mandatory\"}}";

    private static final String SEARCH_RESPONSE_PATH = "searchresponses";
    private static final String STUB_RESPONSE_PATH = "stubresponses";

    public static final String INVALID_DECLARATION_FILE = SEARCH_RESPONSE_PATH + File.separator + "invalid-declaration.json";
    public static final String VALID_SEARCH_DECLARATION_FILE = SEARCH_RESPONSE_PATH + File.separator + "valid-declaration-id.json";
    public static final String VALID_STUB_DECLARATION_FILE = STUB_RESPONSE_PATH + File.separator + "valid-declaration-id.json";

    public static final String VALID_SEARCH_DECLARATION_MINIMAL_DATA_FILE = SEARCH_RESPONSE_PATH + File.separator + "valid-declaration-minimal-data.json";
    public static final String VALID_STUB_DECLARATION_MINIMAL_DATA_FILE = STUB_RESPONSE_PATH + File.separator + "valid-declaration-minimal-data.json";

    public static final String IO_EXCEPTION_FILE = STUB_RESPONSE_PATH + File.separator + "ioexception-response.json";

    public static String formatIdQuery(String declarationId){
        return String.format ( "{\"query\":{\"ids\":{\"type\":[],\"values\":[%s],\"boost\":1.0}}}" ,declarationId);
    }

    public static String createAliasQuery(String index, String alias){
        return String.format ( "{\"actions\":[{\"add\":{\"index\":%s,\"alias\":%s}}]}" , index, alias);
    }

    public static String getInvalidDeclarationMessage(String declarationId){
        return String.format("{\"error\":{\"message\":\"DeclarationId %s not found\"}}",declarationId);
    }

    public static String getFileContent(String fileName){
        String response = "";
        try {
            Path path = Paths.get (TestHelper.class.getClassLoader ().getResource ( fileName  ).toURI ());
            response = FileUtils.readFileToString ( path.toFile (),"UTF-8" );
        } catch (IOException | URISyntaxException e) {
            e.printStackTrace ();
        }

        return response;
    }


}
