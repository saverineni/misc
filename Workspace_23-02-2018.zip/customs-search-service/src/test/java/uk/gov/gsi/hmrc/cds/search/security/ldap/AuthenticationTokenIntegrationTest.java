package uk.gov.gsi.hmrc.cds.search.security.ldap;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import org.apache.http.HttpStatus;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import uk.gov.gsi.hmrc.cds.search.run.CustomsSearchServiceApplication;

import static org.junit.Assert.assertTrue;


@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest(
        classes = CustomsSearchServiceApplication.class,
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT
)
public class AuthenticationTokenIntegrationTest {

    @Value("${local.server.port}")
    private int port;

    @Before
    public void setup() {
        RestAssured.port = this.port;
    }

    @Test
    public void shouldGetJwtTokenResponse_forValidLoginCredentials() throws Exception {

        String token = RestAssured.
                given()
                .contentType(ContentType.JSON)
                .accept("application/json")
                .body("{\"pid\": \"dev\",\"password\": \"dev\"}")
                .when()
                .post("/authentication/token")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .contentType("application/json")
                .extract()
                .path("token");

        assertTrue(token.matches("^([\\w\\-=]+)\\.([\\w\\-=]+)\\.([\\w\\-=]+)$"));
    }

    @Test
    public void throwsAuthenticationException_whenGetJwtTokenRequestBodyEmpty() {
        RestAssured.
                given()
                .accept("application/json")
                .when()
                .get("/authentication/token")
                .then()
                .statusCode(HttpStatus.SC_FORBIDDEN);

    }

    @Test
    public void invalidCredendials_ReturnsUnAuthorizedStatus() {
        RestAssured.
                given()
                .accept("application/json")
                .when()
                .post("/authentication/token")
                .then()
                .statusCode(HttpStatus.SC_UNAUTHORIZED);

    }
}