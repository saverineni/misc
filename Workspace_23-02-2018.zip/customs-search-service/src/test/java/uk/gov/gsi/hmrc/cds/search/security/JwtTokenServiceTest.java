package uk.gov.gsi.hmrc.cds.search.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.hamcrest.Matchers;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;

import java.time.*;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.*;


public class JwtTokenServiceTest {
    private static final String PRINCIPAL = "1234";
    private static final int TOKEN_EXPIRATION_IN_SECONDS = 30;
    private static final String SECRET = "SECRET";
    private static final SignatureAlgorithm HASHING_ALGORITHM = SignatureAlgorithm.HS512;
    private static final Clock CLOCK = Clock.fixed(Instant.now(), ZoneId.of("UTC"));
    JwtTokenService jwtTokenService = new JwtTokenService(TOKEN_EXPIRATION_IN_SECONDS, SECRET, HASHING_ALGORITHM, CLOCK);
    Authentication authentication = Mockito.mock(Authentication.class);


    @Test
    public void generateJwtToken() {
        Mockito.when(authentication.getPrincipal()).thenReturn(PRINCIPAL);
        String token = jwtTokenService.createToken(authentication);

        assertThat(token, Matchers.is(expectedToken()));
    }

    @Test
    public void verifyJwtToken() {
        Mockito.when(authentication.getCredentials()).thenReturn(expectedToken());
        String subject = jwtTokenService.verifyToken(authentication);

        assertThat(subject, Matchers.is(PRINCIPAL));
    }

    @Test(expected = BadCredentialsException.class)
    public void verifyAnExpiredJwtToken() throws Exception {
        Mockito.when(authentication.getCredentials()).thenReturn(expectedToken(3));
        Thread.sleep(TimeUnit.SECONDS.toMillis(4));
        jwtTokenService.verifyToken(authentication);
    }

    @Test(expected = BadCredentialsException.class)
    public void verifyAnInvalidJwtToken() {
        Mockito.when(authentication.getCredentials()).thenReturn("1.2.3");
        jwtTokenService.verifyToken(authentication);
    }

    private String expectedToken() {
        return expectedToken(TOKEN_EXPIRATION_IN_SECONDS);
    }

    private String expectedToken(long expirationTime) {
        Claims claims = Jwts.claims().setSubject(PRINCIPAL);
        return Jwts.builder()
                .setClaims(claims)
                .setExpiration(Date.from(LocalDateTime.now(CLOCK).plusSeconds(expirationTime).toInstant(ZoneOffset.UTC)))
                .signWith(HASHING_ALGORITHM, SECRET)
                .compact();
    }
}