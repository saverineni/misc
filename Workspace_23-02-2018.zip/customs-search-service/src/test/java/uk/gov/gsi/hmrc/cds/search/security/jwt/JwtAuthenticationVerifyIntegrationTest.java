package uk.gov.gsi.hmrc.cds.search.security.jwt;

import com.github.tomakehurst.wiremock.WireMockServer;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import uk.gov.gsi.hmrc.cds.search.run.CustomsSearchServiceApplication;
import uk.gov.gsi.hmrc.cds.search.security.JwtTokenService;

import static com.github.tomakehurst.wiremock.client.WireMock.configureFor;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static uk.gov.gsi.hmrc.cds.search.utils.TestHelper.DECLARATION_ID;
import static uk.gov.gsi.hmrc.cds.search.utils.TestHelper.VALID_DECALARATION_ID;


@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest(
        classes = CustomsSearchServiceApplication.class,
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT
)
@AutoConfigureMockMvc
public class JwtAuthenticationVerifyIntegrationTest {

    @Autowired
    private JwtTokenService jwtTokenService;

    @Autowired
    MockMvc mockMvc;

    private WireMockServer wireMockServer;

    @Value("${local.server.port}")
    private int port;

    @Value("${elasticsearch.host}")
    private String elasticSearchHost;

    @Value("${elasticsearch.port}")
    private int elasticSearchPort;

    @Value("${elasticsearch.query.uri}")
    private String elasticIdQuery;
    private String jwtToken;

    @Before
    public void setup() {
        wireMockServer = new WireMockServer ( elasticSearchPort );
        wireMockServer.start ();
        configureFor ( elasticSearchHost, elasticSearchPort );

        jwtToken = jwtTokenService.createToken(new UsernamePasswordAuthenticationToken("dev", "dev"));
    }

    @After
    public void destroy() {
        wireMockServer.stop ();
    }

    @Test
    public void throwsAuthenticationException_whenJwtTokenIsInvalid() throws Exception{

        mockMvc.perform(get("/declaration")
                .header("Authorization", "Bearer 123.123.123")
                .accept(MediaType.APPLICATION_JSON )
                .param( DECLARATION_ID, VALID_DECALARATION_ID ))
                .andExpect(status().isUnauthorized());
    }

    @Test
    public void throwsAuthenticationException_whenRequestPathUnknown() throws Exception {
        mockMvc.perform(get("/unknown")
                .header("Authorization", String.format("Bearer %s", jwtToken))
                .accept(MediaType.APPLICATION_JSON )
                .param( DECLARATION_ID, VALID_DECALARATION_ID ))
                .andExpect(status().isForbidden());
    }
}