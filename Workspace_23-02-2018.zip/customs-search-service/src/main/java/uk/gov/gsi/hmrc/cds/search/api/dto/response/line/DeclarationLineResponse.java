package uk.gov.gsi.hmrc.cds.search.api.dto.response.line;

import static java.util.Objects.isNull;

import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.common.util.DataHandlers;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.DeclarationLine;

@Data
@Builder
public class DeclarationLineResponse {
    private String entry_reference;
    private String item_number;
    private String entry_number;
    private String entry_date;
    private String route;
    private String dispatch_country;
    private String destination_country;
    private String clearance_datetime;
    private OriginCountryResponse origin_country;
    private String customs_procedure_code;
    private CommodityResponse commodity;
    private String importer_trader_turn;
    private String item_consignee_nad_name;
    private String item_consignee_nad_postcode;
    private String item_consignor_trader_turn;
    private String item_consignor_nad_name;
    private String item_consignor_nad_postcode;

    public static DeclarationLineResponse of(DeclarationLine declarationLine) {
        if (isNull(declarationLine)) {
            return null;
        }
        return DeclarationLineResponse.builder()
                .entry_reference(declarationLine.getEntry_reference())
                .item_number(declarationLine.getItem_number())
                .entry_number(declarationLine.getEntry_number())
                .entry_date(declarationLine.getEntry_date())
                .route(declarationLine.getRoute())
                .dispatch_country(declarationLine.getDispatch_country())
                .destination_country(declarationLine.getDestination_country())
                .clearance_datetime(declarationLine.getClearance_datetime())
                .origin_country(OriginCountryResponse.of(declarationLine.getOriginCountry()))
                .customs_procedure_code(DataHandlers.getNestedNullable(() ->
                        declarationLine.getCustomsProcedureCode().getCustoms_procedure_code()))
                .commodity(CommodityResponse.of(declarationLine.getCommodity()))
                .importer_trader_turn(DataHandlers.getNestedNullable(() ->
                        declarationLine.getImporterTrader().getImporter_trader_turn()))
                .item_consignee_nad_name(declarationLine.getItem_consignee_nad_name())
                .item_consignee_nad_postcode(declarationLine.getItem_consignee_nad_postcode())
                .item_consignor_trader_turn(declarationLine.getItem_consignor_trader_turn())
                .item_consignor_nad_name(declarationLine.getItem_consignor_nad_name())
                .item_consignor_nad_postcode(declarationLine.getItem_consignor_nad_postcode())
                .build();
    }
}
