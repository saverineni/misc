package uk.gov.gsi.hmrc.cds.search.elasticsearch.domain;

import lombok.Builder;
import lombok.Data;


@Data
@Builder
public class DeclarationTrader {

    private ConsignorTrader consignorTrader;
    private ImporterTrader importerTrader;

}
