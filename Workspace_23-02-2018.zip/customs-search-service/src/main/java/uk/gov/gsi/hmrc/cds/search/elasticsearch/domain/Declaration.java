package uk.gov.gsi.hmrc.cds.search.elasticsearch.domain;

import java.util.List;

import com.google.common.collect.Lists;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Declaration {
    private String entry_reference;
    private String entry_number;
    private String entry_date;
    private String epu_number;
    private String entry_type;
    private String route;
    private String goods_location;
    private String dispatch_country;
    private String consignee_nad_name;
    private String consignee_nad_postcode;
    private String consignor_nad_name;
    private String consignor_nad_postcode; // Not in datavault, MSS: NXNAD / INAD.HDRNADPOSTCODE where NXNAD / INAD.HDRNADTYPE == 1
    private String transport_mode_code;
    private DeclarationTrader declarationTrader;
    private DeclarationCountry declarationCountry;
    private List<DeclarationLine> lines = Lists.newArrayList();

}
