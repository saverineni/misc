package uk.gov.gsi.hmrc.cds.search.security;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Profile;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

@Component
@Qualifier("userDetailsService")
@Profile({"test","dev"})
public class DummyUserDetailsService implements UserDetailsService {
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        if (username.equals("dev")) {
            return new User("dev","dev",true,true,true,true, AuthorityUtils.createAuthorityList("DEV"));
        }else if(username.equals("superdev")){
            return new User("superdev","superdev",true,true,true,true, AuthorityUtils.createAuthorityList("SUPERDEV", "DEV"));
        }
        return null;
    }
}
