package uk.gov.gsi.hmrc.cds.search.api.dto.response.header;

import lombok.Builder;
import lombok.Data;
import uk.gov.gsi.hmrc.cds.search.common.util.DataHandlers;
import uk.gov.gsi.hmrc.cds.search.elasticsearch.domain.Declaration;

@Data
@Builder
public class DeclarationHeaderResponse {
    private String entry_reference;
    private String entry_number;
    private String entry_date;
    private String epu_number;
    private String entry_type;
    private String route;
    private String goods_location;
    private String dispatch_country;
    private String consignee_nad_name;
    private String consignee_nad_postcode;
    private String consignor_nad_name;
    private String consignor_nad_postcode;
    private String transport_mode_code;
    private String importer_trader_turn;
    private String consignor_trader_turn;
    private String destination_country_name;

    public static DeclarationHeaderResponse of(Declaration declaration) {
        return DeclarationHeaderResponse.builder()
                .entry_reference(declaration.getEntry_reference())
                .entry_number(declaration.getEntry_number())
                .entry_date(declaration.getEntry_date())
                .epu_number(declaration.getEpu_number())
                .entry_type(declaration.getEntry_type())
                .route(declaration.getRoute())
                .goods_location(declaration.getGoods_location())
                .dispatch_country(declaration.getDispatch_country())
                .consignee_nad_name(declaration.getConsignee_nad_name())
                .consignee_nad_postcode(declaration.getConsignee_nad_postcode())
                .consignor_nad_name(declaration.getConsignor_nad_name())
                .consignor_nad_postcode(declaration.getConsignor_nad_postcode())
                .transport_mode_code(declaration.getTransport_mode_code ())
                .importer_trader_turn(DataHandlers.getNestedNullable(() ->
                        declaration.getDeclarationTrader().getImporterTrader().getImporter_trader_turn()))
                .consignor_trader_turn(DataHandlers.getNestedNullable(() ->
                        declaration.getDeclarationTrader().getConsignorTrader().getConsignor_trader_turn()))
                .destination_country_name(DataHandlers.getNestedNullable(() ->
                        declaration.getDeclarationCountry().getDestinationCountry().getCountry_name()))
                .build();
    }

}
