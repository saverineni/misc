package uk.gov.gsi.hmrc.cds.search.elasticsearch.domain;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Commodity {
    private String commodity_code;
    private String chapter_description;
    private String heading_description;
}
