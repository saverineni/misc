package uk.gov.gsi.hmrc.cds.search.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.ldap.userdetails.InetOrgPersonContextMapper;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.util.matcher.RequestMatcher;
import uk.gov.gsi.hmrc.cds.search.security.*;
import uk.gov.gsi.hmrc.cds.search.security.jwt.JwtAuthenticationProcessingFilter;
import uk.gov.gsi.hmrc.cds.search.security.jwt.JwtAuthenticationProvider;
import uk.gov.gsi.hmrc.cds.search.security.jwt.SkipPathRequestMatcher;
import uk.gov.gsi.hmrc.cds.search.security.ldap.AuthenticationTokenRequestFilter;
import uk.gov.gsi.hmrc.cds.search.security.ldap.HmrcActiveDirectoryLdapAuthenticationProvider;
import uk.gov.gsi.hmrc.cds.search.security.ldap.AuthenticationTokenRequestSuccessHandler;

import java.time.Clock;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Configuration
@Profile({"stride", "prod"})
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Value("${app.ad-domain}")
    private String adDomain;

    @Value("${app.ad-server}")
    private String adServer;

    @Value("${app.ldap-search-base}")
    private String ldapSearchBase;

    @Value("${app.ldap-search-filter}")
    private String ldapSearchFilter;

    @Autowired
    Environment environment;
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    public JwtAuthenticationProvider jwtAuthenticationProvider;

    @Autowired
    protected void configureGlobal(AuthenticationManagerBuilder auth) {
        auth.authenticationProvider(activeDirectoryLdapAuthenticationProvider())
                .authenticationProvider(jwtAuthenticationProvider);
    }

    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        httpSecurity
                .csrf().disable()
                .authorizeRequests()
                .antMatchers("/declaration/**").permitAll()
                .antMatchers("/api/declaration/**").permitAll()
                .antMatchers("/swagger*").permitAll()
                .antMatchers("/swagger-resources/**").permitAll()
                .antMatchers("/webjars/**").permitAll()
                .antMatchers("/v2/api-docs").permitAll()
                .anyRequest().authenticated()
                .and()
                .addFilterBefore(authenticationTokenRequestFilter(), UsernamePasswordAuthenticationFilter.class)
                .addFilterBefore(jwtAuthenticationProcessingFilter(), UsernamePasswordAuthenticationFilter.class);
    }

    private AuthenticationTokenRequestFilter authenticationTokenRequestFilter() {
        AuthenticationTokenRequestFilter authenticationTokenRequestFilter = new AuthenticationTokenRequestFilter("/authentication/token", authenticationManager, objectMapper);
        authenticationTokenRequestFilter.setAuthenticationSuccessHandler(authenticationTokenRequestSuccessHandler());
        return authenticationTokenRequestFilter;
    }

    private JwtAuthenticationProcessingFilter jwtAuthenticationProcessingFilter() {
        return new JwtAuthenticationProcessingFilter(skipPathRequestMatcher(), authenticationManager);
    }

    private RequestMatcher skipPathRequestMatcher() {
        List<String> skipPaths = Lists.newArrayList("/authentication/token", "/swagger*", "/swagger-resources/**", "/webjars/**", "/v2/api-docs");
        List<String> processingPath = Arrays.asList("/declaration", "/api/declaration", "/declaration/**", "/api/declaration/**");
        return new SkipPathRequestMatcher(skipPaths, processingPath);
    }

    private AuthenticationSuccessHandler authenticationTokenRequestSuccessHandler() {
        return new AuthenticationTokenRequestSuccessHandler(objectMapper, jwtTokenService());
    }

    @Bean
    public JwtTokenService jwtTokenService() {
        return new JwtTokenService(
                environment.getProperty("jwt.expiration.seconds", Integer.class),
                environment.getProperty("jwt.secret"),
                jwtHashingAlgorithm(),
                clock());
    }

    protected SignatureAlgorithm jwtHashingAlgorithm() {
        return SignatureAlgorithm.HS512;
    }

    protected Clock clock() {
        return Clock.systemUTC();
    }

    @Bean
    @Profile({"stride", "prod"})
    protected HmrcActiveDirectoryLdapAuthenticationProvider activeDirectoryLdapAuthenticationProvider() {
        HmrcActiveDirectoryLdapAuthenticationProvider provider = new HmrcActiveDirectoryLdapAuthenticationProvider(adDomain, adServer, ldapSearchBase);
        provider.setSearchFilter(ldapSearchFilter);
        provider.setUserDetailsContextMapper(new InetOrgPersonContextMapper());
        return provider;
    }

    @Bean
    protected JwtAuthenticationProvider jwtAuthenticationProvider() {
        return new JwtAuthenticationProvider(jwtTokenService());
    }
}
