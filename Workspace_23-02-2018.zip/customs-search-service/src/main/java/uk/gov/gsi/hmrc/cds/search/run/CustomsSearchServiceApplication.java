package uk.gov.gsi.hmrc.cds.search.run;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import uk.gov.gsi.hmrc.cds.search.elasticsearch.service.AliasCreationService;

@SpringBootApplication(
		scanBasePackages = {
				"uk.gov.gsi.hmrc.cds.search.config",
				"uk.gov.gsi.hmrc.cds.search.security",
				"uk.gov.gsi.hmrc.cds.search.api.resources",
				"uk.gov.gsi.hmrc.cds.search.api.services",
				"uk.gov.gsi.hmrc.cds.search.elasticsearch.connection",
				"uk.gov.gsi.hmrc.cds.search.elasticsearch.service"
		}
)
public class CustomsSearchServiceApplication {
	public static void main(String[] args) {
		SpringApplication.run(CustomsSearchServiceApplication.class, args);
	}

    @Configuration
    @Profile("!test")
    public static class IntegrationTestPostConstruct {
        @Autowired
        private AliasCreationService aliasCreationService;

        @PostConstruct
        public void createAlias() {
            aliasCreationService.createAlias();
        }
    }
}
