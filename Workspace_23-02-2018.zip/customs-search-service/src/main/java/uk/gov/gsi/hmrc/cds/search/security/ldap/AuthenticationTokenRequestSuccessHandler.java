package uk.gov.gsi.hmrc.cds.search.security.ldap;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import uk.gov.gsi.hmrc.cds.search.security.JwtTokenService;

public class AuthenticationTokenRequestSuccessHandler implements AuthenticationSuccessHandler {
    private final ObjectMapper objectMapper;
    private final JwtTokenService tokenGenerator;

    public AuthenticationTokenRequestSuccessHandler(ObjectMapper objectMapper, JwtTokenService tokenGenerator) {
        this.objectMapper = objectMapper;
        this.tokenGenerator = tokenGenerator;
    }

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException {
        response.setStatus(200);
        response.setContentType("application/json");

        writeResponse(response, authentication);
    }

    private void writeResponse(HttpServletResponse response, Authentication authentication) throws IOException {
        PrintWriter writer = response.getWriter();
        writer.write(responseJsonFor(authentication));
        writer.flush();
    }

    private String responseJsonFor(Authentication authentication) throws JsonProcessingException {
        Map<String, String> responseData = new HashMap<>();
        responseData.put("token", tokenGenerator.createToken(authentication));
        return objectMapper.writeValueAsString(responseData);
    }
}
