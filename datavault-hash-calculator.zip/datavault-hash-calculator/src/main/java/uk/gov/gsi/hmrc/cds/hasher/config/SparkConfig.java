package uk.gov.gsi.hmrc.cds.hasher.config;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import uk.gov.gsi.hmrc.cds.hasher.spark.helper.HiveContextAwareExecutor;

@Configuration
@Import(HdfsConfig.class)
public class SparkConfig {

    @Autowired
    HdfsConfig hdfsConfig;

    @Value("${app.name}")
    private String appName;

    @Value("${master.uri:local}")
    private String masterUri;

    @Value("${hadoop.user.name}")
    private String hadoopUserName;

    @Bean
    public JavaSparkContext javaSparkContext() {
        System.setProperty("HADOOP_USER_NAME", hadoopUserName);
        JavaSparkContext context = JavaSparkContext.fromSparkContext(sparkSession().sparkContext());
        return context;
    }

    @Bean
    public SparkSession sparkSession() {
        return SparkSession
                .builder()
                .appName(appName)
                .master(masterUri)
                .enableHiveSupport()
                .getOrCreate();
    }

    @Bean
    public SQLContext sqlContext() {
        return new SQLContext(javaSparkContext());
    }

    @Bean
    public HiveContextAwareExecutor hiveContextAwareExecutor() {
        return new HiveContextAwareExecutor(hdfsConfig.hiveContextAware(), sparkSession());
    }
}
