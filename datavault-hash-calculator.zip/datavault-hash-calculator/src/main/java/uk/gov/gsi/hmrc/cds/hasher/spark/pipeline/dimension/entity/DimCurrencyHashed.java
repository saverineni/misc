package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity;

import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.hasher.spark.helper.MD5Hasher.md5HashOf;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.parseLine;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.valueAt;

@Data
@Builder
public class DimCurrencyHashed implements Serializable, BaseEntity {

    private String currency_id;
    private String currency_iso_code;
    private String currency_name;
    private String hub_currency;
    private String sat_currency;

    public static final Encoder<DimCurrencyHashed> dimCurrencyHashedEncoder = Encoders.bean(DimCurrencyHashed.class);

    public static DimCurrencyHashed parse(String line) {
        List<String> columns = parseLine(line);

        return DimCurrencyHashed.builder()
                .currency_id(valueAt(columns, 0))
                .currency_iso_code(valueAt(columns, 1))
                .currency_name(valueAt(columns, 2))
                .hub_currency(valueAt(columns, 3))
                .sat_currency(valueAt(columns, 4))
                .build();
    }

    public static DimCurrencyHashed mapper(DimCurrency dimCurrency) {
        return DimCurrencyHashed.builder()
                .currency_id(dimCurrency.getCurrency_id())
                .currency_iso_code(dimCurrency.getCurrency_iso_code())
                .currency_name(dimCurrency.getCurrency_name())
                .hub_currency(md5HashOf(dimCurrency.getCurrency_iso_code()))
                .sat_currency(md5HashOf(dimCurrency.getCurrency_name()))
                .build();
    }
}
