package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity;

import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.hasher.spark.helper.MD5Hasher.md5HashOf;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.parseLine;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.valueAt;

@Data
@Builder
public class LandingLinePreviousDocumentHashed implements Serializable, BaseEntity {

    private String source;
    private String ingestion_date;
    private String item_number;
    private String previous_document_sequence_number;
    private String previous_document_reference;
    private String entry_reference;
    private String hub_previous_document;
    private String sat_previous_document;
    private String link_declaration_line_previous_document;
    private String link_declaration_line_previous_document_hub_declaration_line;

    public static final Encoder<LandingLinePreviousDocumentHashed> landingLinePreviousDocumentHashedEncoder = Encoders.bean(LandingLinePreviousDocumentHashed.class);

    public static LandingLinePreviousDocumentHashed mapper(LandingLinePreviousDocument landingLinePreviousDocument) {
        return LandingLinePreviousDocumentHashed.builder()
                .source(landingLinePreviousDocument.getSource())
                .ingestion_date(landingLinePreviousDocument.getIngestion_date())
                .item_number(landingLinePreviousDocument.getItem_number())
                .previous_document_sequence_number(landingLinePreviousDocument.getPrevious_document_sequence_number())
                .previous_document_reference(landingLinePreviousDocument.getPrevious_document_reference())
                .entry_reference(landingLinePreviousDocument.getEntry_reference())
                .hub_previous_document(hubPreviousDocumentHashed(landingLinePreviousDocument))
                .sat_previous_document(satPreviousDocumentHashDifference(landingLinePreviousDocument))
                .link_declaration_line_previous_document(linkDeclarationLinePreviousDocumentHashed(landingLinePreviousDocument))
                .link_declaration_line_previous_document_hub_declaration_line(hubDeclarationLineHashed(landingLinePreviousDocument))
                .build();
    }

    private static String hubDeclarationLineHashed(LandingLinePreviousDocument landingLinePreviousDocument) {
        return md5HashOf(Arrays.asList(
                landingLinePreviousDocument.getEntry_reference(),
                landingLinePreviousDocument.getItem_number()
        ));
    }

    private static String linkDeclarationLinePreviousDocumentHashed(LandingLinePreviousDocument landingLinePreviousDocument) {
        return md5HashOf(Arrays.asList(
                landingLinePreviousDocument.getEntry_reference(),
                landingLinePreviousDocument.getItem_number(),
                landingLinePreviousDocument.getPrevious_document_sequence_number()
        ));
    }

    private static String satPreviousDocumentHashDifference(LandingLinePreviousDocument landingLinePreviousDocument) {
        return md5HashOf(landingLinePreviousDocument.getPrevious_document_reference());
    }

    private static String hubPreviousDocumentHashed(LandingLinePreviousDocument landingLinePreviousDocument) {
        return md5HashOf(Arrays.asList(
                landingLinePreviousDocument.getEntry_reference(),
                landingLinePreviousDocument.getItem_number(),
                landingLinePreviousDocument.getPrevious_document_sequence_number()
        ));
    }


    public static LandingLinePreviousDocumentHashed parse(String line) {
        List<String> columns = parseLine(line);

        return LandingLinePreviousDocumentHashed.builder()
                .source(valueAt(columns, 0))
                .ingestion_date(valueAt(columns, 1))
                .item_number(valueAt(columns, 2))
                .previous_document_sequence_number(valueAt(columns, 3))
                .previous_document_reference(valueAt(columns, 4))
                .entry_reference(valueAt(columns, 5))
                .hub_previous_document(valueAt(columns, 6))
                .sat_previous_document(valueAt(columns, 7))
                .link_declaration_line_previous_document(valueAt(columns, 8))
                .link_declaration_line_previous_document_hub_declaration_line(valueAt(columns, 9))
                .build();
    }
}
