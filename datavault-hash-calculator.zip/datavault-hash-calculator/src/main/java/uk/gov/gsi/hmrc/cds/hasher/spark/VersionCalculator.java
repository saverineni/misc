package uk.gov.gsi.hmrc.cds.hasher.spark;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class VersionCalculator {


    public Optional<String> getApplicationVersion() {
        return getVersion(getClass().getPackage().getImplementationVersion());
    }

    public Optional<String> getVersion(String version) {
        if (StringUtils.isNotBlank(version)) {
            return Optional.of(version.split("-")[0]);
        }
        return Optional.empty();
    }
}