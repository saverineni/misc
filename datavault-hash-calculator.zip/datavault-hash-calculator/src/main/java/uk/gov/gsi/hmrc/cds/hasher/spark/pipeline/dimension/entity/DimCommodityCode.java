package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.parseLine;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.valueAt;

@Data
@Builder
@AllArgsConstructor
public class DimCommodityCode implements Serializable, BaseEntity {

    private String cc_year;
    private String cc_month;
    private String hs_chapter;
    private String hs_heading;
    private String hs_chapter_heading;
    private String hs_subheading;
    private String hs_code;
    private String chapter_description;
    private String heading_description;
    private String subheading_description;

    public static final Encoder<DimCommodityCode> dimCommodityCodeEncoder = Encoders.bean(DimCommodityCode.class);

    public static DimCommodityCode parse(String line) {
        List<String> columns = parseLine(line);

        return DimCommodityCode.builder()
                .cc_year(valueAt(columns, 0))
                .cc_month(valueAt(columns, 1))
                .hs_chapter(valueAt(columns, 2))
                .hs_heading(valueAt(columns, 3))
                .hs_chapter_heading(valueAt(columns, 4))
                .hs_subheading(valueAt(columns, 5))
                .hs_code(valueAt(columns, 6))
                .chapter_description(valueAt(columns, 7))
                .heading_description(valueAt(columns, 8))
                .subheading_description(valueAt(columns, 9))
                .build();
    }
}
