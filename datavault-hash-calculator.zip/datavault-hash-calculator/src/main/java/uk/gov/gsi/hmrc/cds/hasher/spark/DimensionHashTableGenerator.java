package uk.gov.gsi.hmrc.cds.hasher.spark;

import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.hashed.DimCommodityCodeHashedBuilder;
import uk.gov.gsi.hmrc.cds.hasher.spark.hashed.DimCountryHashedBuilder;
import uk.gov.gsi.hmrc.cds.hasher.spark.hashed.DimCurrencyHashedBuilder;
import uk.gov.gsi.hmrc.cds.hasher.spark.hashed.DimCustomsProcedureCodeHashedBuilder;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCommodityCodeHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCountryHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCurrencyHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCustomsProcedureCodeHashed;

@Component
public class DimensionHashTableGenerator {

    @Autowired
    private DimCountryHashedBuilder dimCountryHashedBuilder;

    @Autowired
    private DimCurrencyHashedBuilder dimCurrencyHashedBuilder;

    @Autowired
    private DimCommodityCodeHashedBuilder dimCommodityCodeHashedBuilder;

    @Autowired
    DimCustomsProcedureCodeHashedBuilder dimCustomsProcedureCodeHashedBuilder;

    public void persistDimensionHashTable() {
        Dataset<DimCountryHashed> dimCountryHashedDataset = dimCountryHashedBuilder.build();
        dimCountryHashedBuilder.saveAndCreateExternalTable(dimCountryHashedDataset);

        Dataset<DimCurrencyHashed> dimCurrencyHashedDataset = dimCurrencyHashedBuilder.build();
        dimCurrencyHashedBuilder.saveAndCreateExternalTable(dimCurrencyHashedDataset);

        Dataset<DimCommodityCodeHashed> dimCommodityCodeHashedDataset = dimCommodityCodeHashedBuilder.build();
        dimCommodityCodeHashedBuilder.saveAndCreateExternalTable(dimCommodityCodeHashedDataset);

        Dataset<DimCustomsProcedureCodeHashed> dimCustomsProcedureCodeHashedDataset = dimCustomsProcedureCodeHashedBuilder.build();
        dimCustomsProcedureCodeHashedBuilder.saveAndCreateExternalTable(dimCustomsProcedureCodeHashedDataset);
    }
}
