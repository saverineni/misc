package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.helper.DDLBuilder;
import uk.gov.gsi.hmrc.cds.hasher.spark.helper.FilePersist;
import uk.gov.gsi.hmrc.cds.hasher.spark.helper.HiveContextAwareExecutor;

@Component
public class BaseHashedBuilder {
    @Autowired
    private String landingHashedHDFSAbsoluteBasePath;

    @Autowired
    private String hdfsLandingHashedBasePath;

    @Autowired
    private String landingHashedDatabaseName;

    @Autowired
    private String hdfsDimensionHashedBasePath;

    @Autowired
    private String dimensionHashedHDFSAbsoluteBasePath;

    @Autowired
    private String dimensionHashedDatabaseName;

    @Autowired
    private HiveContextAwareExecutor hiveContextAwareExecutor;

    <T> void saveLandingDatasetAsTable(Dataset<T> dataset, String tableName) {
        saveDatasetAndCreateHiveTable(
                dataset,
                tableName,
                landingHashedHDFSAbsoluteBasePath,
                hdfsLandingHashedBasePath,
                landingHashedDatabaseName
        );
    }

    <T> void saveDimensionDatasetAsTable(Dataset<T> dataset, String tableName) {
        saveDatasetAndCreateHiveTable(
                dataset,
                tableName,
                dimensionHashedHDFSAbsoluteBasePath,
                hdfsDimensionHashedBasePath,
                dimensionHashedDatabaseName
        );
    }

    private <T> void saveDatasetAndCreateHiveTable(Dataset<T> dataset, String tableName, String hdfsAbsoluteBasePath, String hdfsHashedBasePath, String databaseName) {
        String hashedFilePath = String.format("%s/%s", hdfsAbsoluteBasePath, tableName);
        FilePersist.asDelimitedFile(dataset, hashedFilePath);

        String[] fieldNames = dataset.schema().fieldNames();
        String externalFilePath = String.format("%s/%s", hdfsHashedBasePath, tableName);

        String externalTableScript = DDLBuilder.buildExternalTableScript(databaseName, tableName, fieldNames, externalFilePath);
        hiveContextAwareExecutor.sql(externalTableScript);
    }

}
