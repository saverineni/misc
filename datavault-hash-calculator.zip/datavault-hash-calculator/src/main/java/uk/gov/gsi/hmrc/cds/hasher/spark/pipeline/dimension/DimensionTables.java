package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension;

public enum DimensionTables {
    DIM_COMMODITY_CODE("dim_commodity_code"),
    DIM_COMMODITY_CODE_HASHED("dim_commodity_code_hashed"),
    DIM_COUNTRY("dim_country"),
    DIM_COUNTRY_HASHED("dim_country_hashed"),
    DIM_CURRENCY("dim_currency"),
    DIM_CURRENCY_HASHED("dim_currency_hashed"),
    DIM_CUSTOMS_PROCEDURE_CODE("dim_customs_procedure_code"),
    DIM_CUSTOMS_PROCEDURE_CODE_HASHED("dim_customs_procedure_code_hashed"),
    DIM_CUSTOMS_ROUTE("dim_customs_route"),
    DIM_DATE("dim_date"),
    DIM_EPU("dim_epu");

    private String tableName;

    DimensionTables(String tableName) {
        this.tableName = tableName;
    }

    public String tableName() {
        return tableName;
    }

}
