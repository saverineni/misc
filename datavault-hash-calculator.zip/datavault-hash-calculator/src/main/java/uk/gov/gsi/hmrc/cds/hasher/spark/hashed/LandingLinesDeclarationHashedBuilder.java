package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLinesDeclaration;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLinesDeclarationHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader.LandingLinesDeclarationReader;

@Component
public class LandingLinesDeclarationHashedBuilder extends BaseHashedBuilder {

    @Autowired
    private LandingLinesDeclarationReader landingLinesDeclarationReader;

    public Dataset<LandingLinesDeclarationHashed> build() {
        Dataset<LandingLinesDeclaration> landingLinesDeclarationDataset = landingLinesDeclarationReader.landingLinesDeclarationDataset();

        return landingLinesDeclarationDataset.map((MapFunction<LandingLinesDeclaration, LandingLinesDeclarationHashed>) LandingLinesDeclarationHashed::mapper, LandingLinesDeclarationHashed.landingLinesDeclarationHashedEncoder);
    }

    public void saveAndCreateExternalTable(Dataset<LandingLinesDeclarationHashed> landingLinesDeclarationHashedDataset) {
        String tableName = LandingTables.LANDING_LINES_DECLARATION_HASHED.tableName();
        saveLandingDatasetAsTable(landingLinesDeclarationHashedDataset, tableName);
    }
}
