package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingHeaderDeclaration;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables.LANDING_HEADER_DECLARATION;

@Component
public class LandingHeaderDeclarationReader extends TableReader {

    public Dataset<LandingHeaderDeclaration> landingHeaderDeclarationDataset() {
        String dataFilePath = String.format("%s/%s", LANDING_HEADER_DECLARATION.tableName(), datafileRelativePath);
        String landingHeaderDeclarationFilePath = String.format("%s/%s", landingHDFSAbsoluteBasePath, dataFilePath);

        JavaRDD<LandingHeaderDeclaration> landingHeaderDeclarationJavaRDD = javaSparkContext
                .textFile(landingHeaderDeclarationFilePath)
                .map(LandingHeaderDeclaration::parse);
        return sparkSession.createDataset(landingHeaderDeclarationJavaRDD.rdd(), LandingHeaderDeclaration.landingHeaderDeclarationEncoder);
    }
}
