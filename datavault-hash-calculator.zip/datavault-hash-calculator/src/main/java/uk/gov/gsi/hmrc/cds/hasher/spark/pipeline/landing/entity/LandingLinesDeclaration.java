package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity;

import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.*;

@Data
@Builder
@AllArgsConstructor
public class LandingLinesDeclaration implements Serializable, BaseEntity {

    private String source;
    private String ingestion_date;
    private String entry_number;
    private String entry_date;
    private String epu_number;
    private String item_number;
    private String clearance_datetime;
    private String origin_country_code;
    private String item_statistical_value;
    private String commodity_code;
    private String customs_procedure_code;
    private String customs_duty_paid;
    private String vat_paid;
    private String vat_value;
    private String ec_supplementary_1;
    private String item_customs_value;
    private String item_net_mass;
    private String item_supplementary_units;
    private String goods_description;
    private String item_importer_turn;
    private String item_customs_check_code;
    private String item_mic_code;
    private String item_profile_id;
    private String item_consignor_nad_name;
    private String item_consignee_nad_name;
    private String item_consignee_nad_postcode;
    private String item_price_declared;
    private String entry_reference;
    private String hs_code;

    public static final Encoder<LandingLinesDeclaration> landingLinesDeclarationEncoder = Encoders.bean(LandingLinesDeclaration.class);

    public static String[] structFields = toArray(
            Lists.newArrayList(
                    "clearance_datetime",
                    "commodity_code",
                    "customs_duty_paid",
                    "customs_procedure_code",
                    "ec_supplementary_1",
                    "entry_date",
                    "entry_number",
                    "entry_reference",
                    "epu_number",
                    "goods_description",
                    "hs_code",
                    "ingestion_date",
                    "item_consignee_nad_name",
                    "item_consignee_nad_postcode",
                    "item_consignor_nad_name",
                    "item_customs_check_code",
                    "item_customs_value",
                    "item_importer_turn",
                    "item_mic_code",
                    "item_net_mass",
                    "item_number",
                    "item_price_declared",
                    "item_profile_id",
                    "item_statistical_value",
                    "item_supplementary_units",
                    "origin_country_code",
                    "source",
                    "vat_paid",
                    "vat_value"
            )
    );


    public static LandingLinesDeclaration parse(String line) {
        List<String> columns = parseLine(line);

        return LandingLinesDeclaration.builder()
                .source(valueAt(columns, 0))
                .ingestion_date(valueAt(columns, 1))
                .entry_number(valueAt(columns, 2))
                .entry_date(valueAt(columns, 3))
                .epu_number(valueAt(columns, 4))
                .item_number(valueAt(columns, 5))
                .clearance_datetime(valueAt(columns, 6))
                .origin_country_code(valueAt(columns, 7))
                .item_statistical_value(valueAt(columns, 8))
                .commodity_code(valueAt(columns, 9))
                .customs_procedure_code(valueAt(columns, 10))
                .customs_duty_paid(valueAt(columns, 11))
                .vat_paid(valueAt(columns, 12))
                .vat_value(valueAt(columns, 13))
                .ec_supplementary_1(valueAt(columns, 14))
                .item_customs_value(valueAt(columns, 15))
                .item_net_mass(valueAt(columns, 16))
                .item_supplementary_units(valueAt(columns, 17))
                .goods_description(valueAt(columns, 18))
                .item_importer_turn(valueAt(columns, 19))
                .item_customs_check_code(valueAt(columns, 20))
                .item_mic_code(valueAt(columns, 21))
                .item_profile_id(valueAt(columns, 22))
                .item_consignor_nad_name(valueAt(columns, 23))
                .item_consignee_nad_name(valueAt(columns, 24))
                .item_consignee_nad_postcode(valueAt(columns, 25))
                .item_price_declared(valueAt(columns, 26))
                .entry_reference(valueAt(columns, 27))
                .hs_code(valueAt(columns, 28))
                .build();
    }
}
