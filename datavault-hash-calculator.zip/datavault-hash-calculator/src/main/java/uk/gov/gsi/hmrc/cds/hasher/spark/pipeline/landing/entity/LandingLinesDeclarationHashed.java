package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity;

import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.hasher.spark.helper.MD5Hasher.md5HashOf;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.parseLine;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.valueAt;

@Data
@Builder
public class LandingLinesDeclarationHashed implements Serializable, BaseEntity {

    private String source;
    private String ingestion_date;
    private String entry_number;
    private String entry_date;
    private String epu_number;
    private String item_number;
    private String clearance_datetime;
    private String origin_country_code;
    private String item_statistical_value;
    private String commodity_code;
    private String customs_procedure_code;
    private String customs_duty_paid;
    private String vat_paid;
    private String vat_value;
    private String ec_supplementary_1;
    private String item_customs_value;
    private String item_net_mass;
    private String item_supplementary_units;
    private String goods_description;
    private String item_importer_turn;
    private String item_customs_check_code;
    private String item_mic_code;
    private String item_profile_id;
    private String item_consignor_nad_name;
    private String item_consignee_nad_name;
    private String item_consignee_nad_postcode;
    private String item_price_declared;
    private String entry_reference;
    private String hs_code;
    private String hub_declaration_line;
    private String sat_declaration_line;
    private String link_declaration_line_commodity;
    private String link_declaration_line_commodity_hub_commodity;
    private String link_declaration_line_customs_procedure_code;
    private String link_declaration_line_customs_procedure_code_hub_customs_procedure_code;
    private String link_declaration_line_declaration;
    private String link_declaration_line_declaration_hub_declaration;
    private String link_declaration_line_importer_trader;
    private String link_declaration_line_importer_trader_hub_trader;
    private String link_declaration_line_origin_country;
    private String link_declaration_line_origin_country_hub_country;

    public static final Encoder<LandingLinesDeclarationHashed> landingLinesDeclarationHashedEncoder = Encoders.bean(LandingLinesDeclarationHashed.class);

    public static LandingLinesDeclarationHashed mapper(LandingLinesDeclaration landingLinesDeclaration) {
        return LandingLinesDeclarationHashed.builder()
                .source(landingLinesDeclaration.getSource())
                .ingestion_date(landingLinesDeclaration.getIngestion_date())
                .entry_number(landingLinesDeclaration.getEntry_number())
                .entry_date(landingLinesDeclaration.getEntry_date())
                .epu_number(landingLinesDeclaration.getEpu_number())
                .item_number(landingLinesDeclaration.getItem_number())
                .clearance_datetime(landingLinesDeclaration.getClearance_datetime())
                .origin_country_code(landingLinesDeclaration.getOrigin_country_code())
                .item_statistical_value(landingLinesDeclaration.getItem_statistical_value())
                .commodity_code(landingLinesDeclaration.getCommodity_code())
                .customs_procedure_code(landingLinesDeclaration.getCustoms_procedure_code())
                .customs_duty_paid(landingLinesDeclaration.getCustoms_duty_paid())
                .vat_paid(landingLinesDeclaration.getVat_paid())
                .vat_value(landingLinesDeclaration.getVat_value())
                .ec_supplementary_1(landingLinesDeclaration.getEc_supplementary_1())
                .item_customs_value(landingLinesDeclaration.getItem_customs_value())
                .item_net_mass(landingLinesDeclaration.getItem_net_mass())
                .item_supplementary_units(landingLinesDeclaration.getItem_supplementary_units())
                .goods_description(landingLinesDeclaration.getGoods_description())
                .item_importer_turn(landingLinesDeclaration.getItem_importer_turn())
                .item_customs_check_code(landingLinesDeclaration.getItem_customs_check_code())
                .item_mic_code(landingLinesDeclaration.getItem_mic_code())
                .item_profile_id(landingLinesDeclaration.getItem_profile_id())
                .item_consignor_nad_name(landingLinesDeclaration.getItem_consignor_nad_name())
                .item_consignee_nad_name(landingLinesDeclaration.getItem_consignee_nad_name())
                .item_consignee_nad_postcode(landingLinesDeclaration.getItem_consignee_nad_postcode())
                .item_price_declared(landingLinesDeclaration.getItem_price_declared())
                .entry_reference(landingLinesDeclaration.getEntry_reference())
                .hs_code(landingLinesDeclaration.getHs_code())
                .hub_declaration_line(hubDeclarationLineHashed(landingLinesDeclaration))
                .sat_declaration_line(satDeclarationLineHashDifference(landingLinesDeclaration))
                .link_declaration_line_commodity(linkDeclarationLineCommodity(landingLinesDeclaration))
                .link_declaration_line_commodity_hub_commodity(hubCommodityHashed(landingLinesDeclaration))
                .link_declaration_line_customs_procedure_code(linkDeclarationLineCustomsProcedureCodeHashed(landingLinesDeclaration))
                .link_declaration_line_customs_procedure_code_hub_customs_procedure_code(hubCustomsProcedureCodeHashed(landingLinesDeclaration))
                .link_declaration_line_declaration(linkDeclarationLineDeclarationHashed(landingLinesDeclaration))
                .link_declaration_line_declaration_hub_declaration(hubDeclarationHashed(landingLinesDeclaration))
                .link_declaration_line_importer_trader(linkDeclarationLineImporterTraderHashed(landingLinesDeclaration))
                .link_declaration_line_importer_trader_hub_trader(importerHubTraderHashed(landingLinesDeclaration))
                .link_declaration_line_origin_country(linkDeclarationLineOriginCountryHashed(landingLinesDeclaration))
                .link_declaration_line_origin_country_hub_country(originCountryHubCountryHashed(landingLinesDeclaration))
                .build();

    }

    private static String originCountryHubCountryHashed(LandingLinesDeclaration landingLinesDeclaration) {
        return md5HashOf(landingLinesDeclaration.getOrigin_country_code());
    }

    private static String linkDeclarationLineOriginCountryHashed(LandingLinesDeclaration landingLinesDeclaration) {
        return md5HashOf(Arrays.asList(
                landingLinesDeclaration.getEntry_reference(),
                landingLinesDeclaration.getItem_number(),
                landingLinesDeclaration.getOrigin_country_code()
        ));
    }

    private static String importerHubTraderHashed(LandingLinesDeclaration landingLinesDeclaration) {
        return md5HashOf(landingLinesDeclaration.getItem_importer_turn());
    }

    private static String linkDeclarationLineImporterTraderHashed(LandingLinesDeclaration landingLinesDeclaration) {
        return md5HashOf(Arrays.asList(
                landingLinesDeclaration.getEntry_reference(),
                landingLinesDeclaration.getItem_number(),
                landingLinesDeclaration.getItem_importer_turn()
        ));
    }

    private static String hubDeclarationHashed(LandingLinesDeclaration landingLinesDeclaration) {
        return md5HashOf(landingLinesDeclaration.getEntry_reference());
    }

    private static String linkDeclarationLineDeclarationHashed(LandingLinesDeclaration landingLinesDeclaration) {
        return md5HashOf(Arrays.asList(
                landingLinesDeclaration.getEntry_reference(),
                landingLinesDeclaration.getItem_number()
        ));
    }

    private static String hubCustomsProcedureCodeHashed(LandingLinesDeclaration landingLinesDeclaration) {
        return md5HashOf(landingLinesDeclaration.getCustoms_procedure_code());
    }

    private static String linkDeclarationLineCustomsProcedureCodeHashed(LandingLinesDeclaration landingLinesDeclaration) {
        return md5HashOf(Arrays.asList(
                landingLinesDeclaration.getEntry_reference(),
                landingLinesDeclaration.getItem_number(),
                landingLinesDeclaration.getCustoms_procedure_code()
        ));
    }

    private static String hubCommodityHashed(LandingLinesDeclaration landingLinesDeclaration) {
        return md5HashOf(landingLinesDeclaration.getHs_code());
    }

    private static String linkDeclarationLineCommodity(LandingLinesDeclaration landingLinesDeclaration) {
        return md5HashOf(Arrays.asList(
                landingLinesDeclaration.getEntry_reference(),
                landingLinesDeclaration.getItem_number(),
                landingLinesDeclaration.getHs_code()
        ));
    }

    private static String satDeclarationLineHashDifference(LandingLinesDeclaration landingLinesDeclaration) {
        return md5HashOf(Arrays.asList(
                landingLinesDeclaration.getClearance_datetime(),
                landingLinesDeclaration.getItem_statistical_value(),
                landingLinesDeclaration.getCustoms_duty_paid(),
                landingLinesDeclaration.getVat_paid(),
                landingLinesDeclaration.getEc_supplementary_1(),
                landingLinesDeclaration.getItem_customs_value(),
                landingLinesDeclaration.getItem_net_mass(),
                landingLinesDeclaration.getItem_supplementary_units(),
                landingLinesDeclaration.getGoods_description(),
                landingLinesDeclaration.getItem_customs_check_code(),
                landingLinesDeclaration.getItem_mic_code(),
                landingLinesDeclaration.getItem_profile_id(),
                landingLinesDeclaration.getItem_consignor_nad_name(),
                landingLinesDeclaration.getItem_consignee_nad_name(),
                landingLinesDeclaration.getItem_consignee_nad_postcode(),
                landingLinesDeclaration.getVat_value(),
                landingLinesDeclaration.getItem_price_declared()
        ));
    }

    private static String hubDeclarationLineHashed(LandingLinesDeclaration landingLinesDeclaration) {
        return md5HashOf(Arrays.asList(
                landingLinesDeclaration.getEntry_reference(),
                landingLinesDeclaration.getItem_number()
        ));
    }

    public static LandingLinesDeclarationHashed parse(String line) {
        List<String> columns = parseLine(line);

        return LandingLinesDeclarationHashed.builder()
                .source(valueAt(columns, 0))
                .ingestion_date(valueAt(columns, 1))
                .entry_number(valueAt(columns, 2))
                .entry_date(valueAt(columns, 3))
                .epu_number(valueAt(columns, 4))
                .item_number(valueAt(columns, 5))
                .clearance_datetime(valueAt(columns, 6))
                .origin_country_code(valueAt(columns, 7))
                .item_statistical_value(valueAt(columns, 8))
                .commodity_code(valueAt(columns, 9))
                .customs_procedure_code(valueAt(columns, 10))
                .customs_duty_paid(valueAt(columns, 11))
                .vat_paid(valueAt(columns, 12))
                .vat_value(valueAt(columns, 13))
                .ec_supplementary_1(valueAt(columns, 14))
                .item_customs_value(valueAt(columns, 15))
                .item_net_mass(valueAt(columns, 16))
                .item_supplementary_units(valueAt(columns, 17))
                .goods_description(valueAt(columns, 18))
                .item_importer_turn(valueAt(columns, 19))
                .item_customs_check_code(valueAt(columns, 20))
                .item_mic_code(valueAt(columns, 21))
                .item_profile_id(valueAt(columns, 22))
                .item_consignor_nad_name(valueAt(columns, 23))
                .item_consignee_nad_name(valueAt(columns, 24))
                .item_consignee_nad_postcode(valueAt(columns, 25))
                .item_price_declared(valueAt(columns, 26))
                .entry_reference(valueAt(columns, 27))
                .hs_code(valueAt(columns, 28))
                .hub_declaration_line(valueAt(columns, 29))
                .sat_declaration_line(valueAt(columns, 30))
                .link_declaration_line_commodity(valueAt(columns, 31))
                .link_declaration_line_commodity_hub_commodity(valueAt(columns, 32))
                .link_declaration_line_customs_procedure_code(valueAt(columns, 33))
                .link_declaration_line_customs_procedure_code_hub_customs_procedure_code(valueAt(columns, 34))
                .link_declaration_line_declaration(valueAt(columns, 35))
                .link_declaration_line_declaration_hub_declaration(valueAt(columns, 36))
                .link_declaration_line_importer_trader(valueAt(columns, 37))
                .link_declaration_line_importer_trader_hub_trader(valueAt(columns, 38))
                .link_declaration_line_origin_country(valueAt(columns, 39))
                .link_declaration_line_origin_country_hub_country(valueAt(columns, 40))
                .build();
    }
}
