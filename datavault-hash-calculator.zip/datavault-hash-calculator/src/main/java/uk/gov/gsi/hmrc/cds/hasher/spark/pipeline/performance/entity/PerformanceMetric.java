package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.performance.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;

@Data
@Builder
@AllArgsConstructor
public class PerformanceMetric implements Serializable, BaseEntity {

    public static final Encoder<PerformanceMetric> performanceMtericEncoder = Encoders.bean(PerformanceMetric.class);

    private String app_name;
    private String release_version;
    private int batch_id;
    private String start_time;
    private String end_time;
    private String table_name;
    private int number_of_cols;
    private long number_of_rows;

}

