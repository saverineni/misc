package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.DimensionTables;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCommodityCode;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCommodityCodeHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.reader.DimCommodityCodeReader;

@Component
public class DimCommodityCodeHashedBuilder extends BaseHashedBuilder{

    @Autowired
    private DimCommodityCodeReader dimCommodityCodeReader;

    public Dataset<DimCommodityCodeHashed> build() {

        Dataset<DimCommodityCode> dimCommodityCodeDataset = dimCommodityCodeReader.dimCommodityCodeDataset();

        return dimCommodityCodeDataset.map((MapFunction<DimCommodityCode, DimCommodityCodeHashed>) DimCommodityCodeHashed::mapper, DimCommodityCodeHashed.dimCommodityCodeHashedEncoder);
    }

    public void saveAndCreateExternalTable(Dataset<DimCommodityCodeHashed> dimCommodityCodeHashedDataset) {
        String tableName = DimensionTables.DIM_COMMODITY_CODE_HASHED.tableName();
        saveDimensionDatasetAsTable(dimCommodityCodeHashedDataset, tableName);
    }
}
