package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.DimensionTables;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCountryHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCurrency;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCurrencyHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.reader.DimCurrencyReader;

@Component
public class DimCurrencyHashedBuilder extends BaseHashedBuilder{

    @Autowired
    private DimCurrencyReader dimCurrencyReader;

    public Dataset<DimCurrencyHashed> build() {
        Dataset<DimCurrency> dimCurrencyDataset = dimCurrencyReader.dimCurrencyDataset();
        return dimCurrencyDataset.map((MapFunction<DimCurrency, DimCurrencyHashed>) DimCurrencyHashed::mapper, DimCurrencyHashed.dimCurrencyHashedEncoder);
    }

    public void saveAndCreateExternalTable(Dataset<DimCurrencyHashed> dimCurrencyHashedDataset) {
        String tableName = DimensionTables.DIM_CURRENCY_HASHED.tableName();
        saveDimensionDatasetAsTable(dimCurrencyHashedDataset, tableName);
    }
}
