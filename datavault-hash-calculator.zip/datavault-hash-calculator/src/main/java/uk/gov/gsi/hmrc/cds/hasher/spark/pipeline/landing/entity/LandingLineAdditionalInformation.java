package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity;

import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.*;

@Data
@Builder
@AllArgsConstructor
public class LandingLineAdditionalInformation implements Serializable, BaseEntity {

    private String source;
    private String ingestion_date;
    private String item_number;
    private String additional_information_sequence_number;
    private String generation_number;
    private String additional_information_statement;
    private String additional_information_statement_type;
    private String item_additional_information_statement;
    private String entry_reference;

    public static String[] structFields = toArray(
            Lists.newArrayList(
                    "source",
                    "ingestion_date",
                    "item_number",
                    "additional_information_sequence_number",
                    "generation_number",
                    "additional_information_statement",
                    "additional_information_statement_type",
                    "item_additional_information_statement",
                    "entry_reference"
            )
    );

    public static final Encoder<LandingLineAdditionalInformation> landingLineAdditionalInformationEncoder = Encoders.bean(LandingLineAdditionalInformation.class);

    public static LandingLineAdditionalInformation parse(String line) {
        List<String> columns = parseLine(line);

        return LandingLineAdditionalInformation.builder()
                .source(valueAt(columns, 0))
                .ingestion_date(valueAt(columns, 1))
                .item_number(valueAt(columns, 2))
                .additional_information_sequence_number(valueAt(columns, 3))
                .generation_number(valueAt(columns, 4))
                .additional_information_statement(valueAt(columns, 5))
                .additional_information_statement_type(valueAt(columns, 6))
                .item_additional_information_statement(valueAt(columns, 7))
                .entry_reference(valueAt(columns, 8))
                .build();
    }
}
