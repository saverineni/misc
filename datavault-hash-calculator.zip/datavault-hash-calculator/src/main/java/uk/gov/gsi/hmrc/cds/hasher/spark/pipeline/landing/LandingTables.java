package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing;

public enum LandingTables {
    LANDING_HEADER_DECLARATION("landing_headers_declaration"),
    LANDING_HEADER_DECLARATION_HASHED("landing_headers_declaration_hashed"),
    LANDING_LINE_ADDITIONAL_INFORMATION("landing_line_additional_information"),
    LANDING_LINE_ADDITIONAL_INFORMATION_HASHED("landing_line_additional_information_hashed"),
    LANDING_LINE_DOCUMENT("landing_line_document"),
    LANDING_LINE_DOCUMENT_HASHED("landing_line_document_hashed"),
    LANDING_LINE_PREVIOUS_DOCUMENT("landing_line_previous_document"),
    LANDING_LINE_PREVIOUS_DOCUMENT_HASHED("landing_line_previous_document_hashed"),
    LANDING_LINE_TAX_LINE("landing_line_tax_line"),
    LANDING_LINE_TAX_LINE_HASHED("landing_line_tax_line_hashed"),
    LANDING_LINES_DECLARATION("landing_lines_declaration"),
    LANDING_LINES_DECLARATION_HASHED("landing_lines_declaration_hashed"),
    LANDING_TRADER("landing_trader"),
    LANDING_TRADER_HASHED("landing_trader_hashed");

    private String tableName;

    LandingTables(String tableName) {
        this.tableName = tableName;
    }

    public String tableName() {
        return tableName;
    }
}
