package uk.gov.gsi.hmrc.cds.hasher.spark;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.perfomancemetrics.PerformanceMetricsCreator;

import java.util.Optional;

@Component
@Slf4j
public class HashCalculatorJob {

    @Autowired
    private LandingHashTableGenerator landingHashTableGenerator;
    @Autowired
    private DimensionHashTableGenerator dimensionHashTableGenerator;
    @Autowired
    private PerformanceMetricsCreator performanceMetricsCreator;
    @Autowired
    private VersionCalculator versionCalculator;

    public static final String APP_NAME = "datavault-hash-calculator";

    public void persistHashedTables() {
        int batchId = performanceMetricsCreator.retrieveBatchId(APP_NAME);
        String release_version = getApplicationVersion();
        log.info(String.format("BATCH_ID : %s and RELEASE_VERSION : %s", batchId, release_version));
        landingHashTableGenerator.persistLandingHashTables(batchId, release_version);
        dimensionHashTableGenerator.persistDimensionHashTable(batchId, release_version);
    }

    private String getApplicationVersion() {
        Optional<String> applicationVersion = versionCalculator.getApplicationVersion();
        if (applicationVersion.isPresent()) {
            return applicationVersion.get();
        } else {
            return null;
        }
    }
}
