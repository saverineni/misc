package uk.gov.gsi.hmrc.cds.hasher.spark;

import lombok.extern.slf4j.Slf4j;
import org.apache.spark.sql.Dataset;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.hashed.*;
import uk.gov.gsi.hmrc.cds.hasher.spark.helper.HiveContextAwareExecutor;
import uk.gov.gsi.hmrc.cds.hasher.spark.perfomancemetrics.PerformanceMetricsWriter;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.*;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.performance.entity.PerformanceMetric;

import java.sql.Time;
import java.sql.Timestamp;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables.LANDING_HEADER_DECLARATION;

@Slf4j
@Component
public class LandingHashTableGenerator {

    @Autowired
    private LandingHeaderDeclarationHashedBuilder landingHeaderDeclarationHashedBuilder;
    @Autowired
    private LandingLinesDeclarationHashedBuilder landingLinesDeclarationHashedBuilder;
    @Autowired
    private LandingLineAdditionalInformationHashedBuilder landingLineAdditionalInformationHashedBuilder;
    @Autowired
    private LandingLineDocumentHashedBuilder landingLineDocumentHashedBuilder;
    @Autowired
    private LandingLinePreviousDocumentHashedBuilder landingLinePreviousDocumentHashedBuilder;
    @Autowired
    private LandingLineTaxLineHashedBuilder landingLineTaxLineHashedBuilder;
    @Autowired
    private LandingTraderHashedBuilder landingTraderHashedBuilder;
    @Autowired
    private PerformanceMetricsWriter performanceMetricsWriter;

    public void persistLandingHashTables() {
        Timestamp startLHDTimestamp = new Timestamp(System.currentTimeMillis());
        Dataset<LandingHeaderDeclarationHashed> landingHeaderDeclarationHashedDataset = landingHeaderDeclarationHashedBuilder.build();
        landingHeaderDeclarationHashedBuilder.saveAndCreateExternalTable(landingHeaderDeclarationHashedDataset);
        Timestamp endLHDTimestamp = new Timestamp(System.currentTimeMillis());
        logTimestamp(LANDING_HEADER_DECLARATION.tableName(), startLHDTimestamp, endLHDTimestamp);
        logToHive(startLHDTimestamp, endLHDTimestamp, landingHeaderDeclarationHashedDataset);


//        Timestamp startLandingLinesDeclarationHashed = new Timestamp(System.currentTimeMillis());
//        Dataset<LandingLinesDeclarationHashed> landingLinesDeclarationHashedDataset = landingLinesDeclarationHashedBuilder.build();
//        landingLinesDeclarationHashedBuilder.saveAndCreateExternalTable(landingLinesDeclarationHashedDataset);
//        Timestamp landingLinesDeclarationHashed = new Timestamp(System.currentTimeMillis());
//
//        Dataset<LandingLineAdditionalInformationHashed> landingLineAdditionalInformationHashedDataset = landingLineAdditionalInformationHashedBuilder.build();
//        landingLineAdditionalInformationHashedBuilder.saveAndCreateExternalTable(landingLineAdditionalInformationHashedDataset);
//
//        Dataset<LandingLineDocumentHashed> landingLineDocumentHashedDataset = landingLineDocumentHashedBuilder.build();
//        landingLineDocumentHashedBuilder.saveAndCreateExternalTable(landingLineDocumentHashedDataset);
//
//        Dataset<LandingLinePreviousDocumentHashed> landingLinePreviousDocumentHashedDataset = landingLinePreviousDocumentHashedBuilder.build();
//        landingLinePreviousDocumentHashedBuilder.saveAndCreateExternalTable(landingLinePreviousDocumentHashedDataset);
//
//        Dataset<LandingLineTaxLineHashed> landingLineTaxLineHashedDataset = landingLineTaxLineHashedBuilder.build();
//        landingLineTaxLineHashedBuilder.saveAndCreateExternalTable(landingLineTaxLineHashedDataset);
//
//        Dataset<LandingTraderHashed> landingTraderHashedDataset = landingTraderHashedBuilder.build();
//        landingTraderHashedBuilder.saveAndCreateExternalTable(landingTraderHashedDataset);
    }

    private <T> void logToHive(Timestamp startLHDtimestamp, Timestamp endLHDtimestamp, Dataset<T>  hashedDataset) {

        int numberOfColumns = hashedDataset.schema().fieldNames().length;
        long numberOfRows = hashedDataset.count();

        performanceMetricsWriter.createPerformanceDataset(new PerformanceMetric("datavault-hash-calculator", "release_version", "1", startLHDtimestamp.toString(),
                endLHDtimestamp.toString(), "performance_metrics", numberOfColumns, numberOfRows));
    }

    private void logTimestamp(String tableName, Timestamp start, Timestamp end) {
        log.info(String.format("%s started at %s and ended at %s ",  tableName, start, end));
    }
}
