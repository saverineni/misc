package uk.gov.gsi.hmrc.cds.hasher.spark;

import lombok.extern.slf4j.Slf4j;
import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.hashed.*;
import uk.gov.gsi.hmrc.cds.hasher.spark.perfomancemetrics.PerformanceMetricsCreator;
import uk.gov.gsi.hmrc.cds.hasher.spark.perfomancemetrics.PerformanceMetricsWriter;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.*;

import java.sql.Timestamp;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.LandingTables.LANDING_HEADER_DECLARATION;

@Slf4j
@Component
public class LandingHashTableGenerator {

    @Autowired
    private LandingHeaderDeclarationHashedBuilder landingHeaderDeclarationHashedBuilder;
    @Autowired
    private LandingLinesDeclarationHashedBuilder landingLinesDeclarationHashedBuilder;
    @Autowired
    private LandingLineAdditionalInformationHashedBuilder landingLineAdditionalInformationHashedBuilder;
    @Autowired
    private LandingLineDocumentHashedBuilder landingLineDocumentHashedBuilder;
    @Autowired
    private LandingLinePreviousDocumentHashedBuilder landingLinePreviousDocumentHashedBuilder;
    @Autowired
    private LandingLineTaxLineHashedBuilder landingLineTaxLineHashedBuilder;
    @Autowired
    private LandingTraderHashedBuilder landingTraderHashedBuilder;
    @Autowired
    private PerformanceMetricsCreator performanceMetricsCreator;


    public void persistLandingHashTables() {
        Timestamp startLHDTimestamp = new Timestamp(System.currentTimeMillis());
        Dataset<LandingHeaderDeclarationHashed> landingHeaderDeclarationHashedDataset = landingHeaderDeclarationHashedBuilder.build();
       // landingHeaderDeclarationHashedBuilder.saveAndCreateExternalTable(landingHeaderDeclarationHashedDataset);
        Timestamp endLHDTimestamp = new Timestamp(System.currentTimeMillis());
        logTimestamp(LANDING_HEADER_DECLARATION.tableName(), startLHDTimestamp, endLHDTimestamp);
        performanceMetricsCreator.createMetrics(startLHDTimestamp, endLHDTimestamp, landingHeaderDeclarationHashedDataset, "datavault-hash-calculator");


//        Timestamp startLLDecTimestamp = new Timestamp(System.currentTimeMillis());
//        Dataset<LandingLinesDeclarationHashed> landingLinesDeclarationHashedDataset = landingLinesDeclarationHashedBuilder.build();
//        landingLinesDeclarationHashedBuilder.saveAndCreateExternalTable(landingLinesDeclarationHashedDataset);
//        Timestamp endLLDecTimestamp = new Timestamp(System.currentTimeMillis());
//        logTimestamp(LANDING_HEADER_DECLARATION.tableName(), startLLDecTimestamp, endLLDecTimestamp);
//        performanceMetricsWriter.logMetrics(startLLDecTimestamp, endLLDecTimestamp, landingLinesDeclarationHashedDataset);
//
//        Timestamp startLLAITimestamp = new Timestamp(System.currentTimeMillis());
//        Dataset<LandingLineAdditionalInformationHashed> landingLineAdditionalInformationHashedDataset = landingLineAdditionalInformationHashedBuilder.build();
//        landingLineAdditionalInformationHashedBuilder.saveAndCreateExternalTable(landingLineAdditionalInformationHashedDataset);
//        Timestamp endLLAITimestamp = new Timestamp(System.currentTimeMillis());
//        logTimestamp(LANDING_HEADER_DECLARATION.tableName(), startLLAITimestamp, endLLAITimestamp);
//        performanceMetricsWriter.logMetrics(startLLAITimestamp, endLLAITimestamp, landingLineAdditionalInformationHashedDataset);
//
//
//
//        Timestamp startLLDocTimestamp = new Timestamp(System.currentTimeMillis());
//        Dataset<LandingLineDocumentHashed> landingLineDocumentHashedDataset = landingLineDocumentHashedBuilder.build();
//        landingLineDocumentHashedBuilder.saveAndCreateExternalTable(landingLineDocumentHashedDataset);
//        Timestamp endLLDocTimestamp = new Timestamp(System.currentTimeMillis());
//        logTimestamp(LANDING_HEADER_DECLARATION.tableName(), startLLDocTimestamp, endLLDocTimestamp);
//        performanceMetricsWriter.logMetrics(startLLDocTimestamp, endLLDocTimestamp, landingLineDocumentHashedDataset);


//
//        Dataset<LandingLinePreviousDocumentHashed> landingLinePreviousDocumentHashedDataset = landingLinePreviousDocumentHashedBuilder.build();
//        landingLinePreviousDocumentHashedBuilder.saveAndCreateExternalTable(landingLinePreviousDocumentHashedDataset);
//
//        Dataset<LandingLineTaxLineHashed> landingLineTaxLineHashedDataset = landingLineTaxLineHashedBuilder.build();
//        landingLineTaxLineHashedBuilder.saveAndCreateExternalTable(landingLineTaxLineHashedDataset);
//
//        Dataset<LandingTraderHashed> landingTraderHashedDataset = landingTraderHashedBuilder.build();
//        landingTraderHashedBuilder.saveAndCreateExternalTable(landingTraderHashedDataset);
    }

    private void logTimestamp(String tableName, Timestamp start, Timestamp end) {
        log.info(String.format("%s started at %s and ended at %s ",  tableName, start, end));
    }
}
