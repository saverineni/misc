package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.parseLine;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.valueAt;

@Data
@Builder
@AllArgsConstructor
public class DimCustomsProcedureCode implements Serializable, BaseEntity {

    private String customs_procedure_code;
    private String series;
    private String page;
    private String procedure;
    private String procedure_description;
    private String previous_procedure;
    private String previous_procedure_description;
    private String national_coding;
    private String type_of_goods;
    private String type_of_goods_description;
    private String release_mechanism;
    private String release_mechanism_description;
    private String regime_entered_to;
    private String regime_entered_to_description;

    public static final Encoder<DimCustomsProcedureCode> dimCustomsProcedureCodeEncoder = Encoders.bean(DimCustomsProcedureCode.class);

    public static DimCustomsProcedureCode parse(String line) {
        List<String> columns = parseLine(line);

        return DimCustomsProcedureCode.builder()
                .customs_procedure_code(valueAt(columns, 0))
                .series(valueAt(columns, 1))
                .page(valueAt(columns, 2))
                .procedure(valueAt(columns, 3))
                .procedure_description(valueAt(columns, 4))
                .previous_procedure(valueAt(columns, 5))
                .previous_procedure_description(valueAt(columns, 6))
                .national_coding(valueAt(columns, 7))
                .type_of_goods(valueAt(columns, 8))
                .type_of_goods_description(valueAt(columns, 9))
                .release_mechanism(valueAt(columns, 10))
                .release_mechanism_description(valueAt(columns, 11))
                .regime_entered_to(valueAt(columns, 12))
                .regime_entered_to_description(valueAt(columns, 13))
                .build();
    }
}
