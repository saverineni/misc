package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.List;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.parseLine;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.valueAt;

@Data
@Builder
@AllArgsConstructor
public class DimCurrency implements Serializable, BaseEntity {

    private String currency_id;
    private String currency_iso_code;
    private String currency_name;

    public static final Encoder<DimCurrency> dimCurrencyEncoder = Encoders.bean(DimCurrency.class);

    public static DimCurrency parse(String line) {
        List<String> columns = parseLine(line);

        return DimCurrency.builder()
                .currency_id(valueAt(columns, 0))
                .currency_iso_code(valueAt(columns, 1))
                .currency_name(valueAt(columns, 2))
                .build();
    }
}
