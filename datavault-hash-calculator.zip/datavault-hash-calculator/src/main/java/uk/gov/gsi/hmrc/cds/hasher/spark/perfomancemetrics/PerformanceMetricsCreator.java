package uk.gov.gsi.hmrc.cds.hasher.spark.perfomancemetrics;

import lombok.extern.slf4j.Slf4j;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.helper.HiveContextAwareExecutor;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.performance.entity.PerformanceMetric;

import java.sql.Timestamp;
import java.util.Optional;

@Slf4j
@Component
public class PerformanceMetricsCreator {

    @Autowired
    private PerformanceMetricsWriter performanceMetricsWriter;

    @Autowired
    private String landingHashedDatabaseName;

    @Autowired
    private HiveContextAwareExecutor executor;

    private static final String VERSION = "version";

    private final String selectTemplate = "select COALESCE(max(batch_id),0) as batch_id from %s where app_name='%s'";

    public <T> void createMetrics(Timestamp startLHDtimestamp, Timestamp endLHDtimestamp, Dataset<T> hashedDataset, String appName) {
        final String performanceMetrics= String.format("%s.%s",landingHashedDatabaseName,"performance_metrics");
        int numberOfColumns = hashedDataset.schema().fieldNames().length;
        long numberOfRows = hashedDataset.count();
        String version =  System.getProperty(VERSION);
        int batchId= 0;
        String query = String.format(selectTemplate,performanceMetrics,appName);
        log.info("Executing batch id query : " + query);
        Optional<Dataset<Row>> rowDataset = executor.sql(query);
        if(rowDataset.isPresent()) {
            Dataset<Row> appdataSet = rowDataset.get();
            batchId=appdataSet.select("batch_id").as(Encoders.INT()).first();
            log.info("Executing batch id query batchId: " + batchId);
        }

        PerformanceMetric performanceMetric = new PerformanceMetric(appName, version, (batchId + 1), startLHDtimestamp, endLHDtimestamp, performanceMetrics, numberOfColumns, numberOfRows);
        log.info("performanceMetric *********: " + performanceMetric);
        performanceMetricsWriter.logMetrics(performanceMetric, performanceMetrics);
    }

}
