package uk.gov.gsi.hmrc.cds.hasher.spark.perfomancemetrics;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.helper.FilePersist;
import uk.gov.gsi.hmrc.cds.hasher.spark.helper.HiveContextAwareExecutor;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.performance.entity.PerformanceMetric;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Component
public class PerformanceMetricsCreator {

    @Autowired
    private PerformanceMetricsWriter performanceMetricsWriter;

    @Autowired
    HiveContextAwareExecutor executor;

    public <T> void createMetrics(Timestamp startLHDtimestamp, Timestamp endLHDtimestamp, Dataset<T> hashedDataset, String appName) {

        int numberOfColumns = hashedDataset.schema().fieldNames().length;
        long numberOfRows = hashedDataset.count();
        String version =  System.getProperty("version");
        int batchId= 0;
        Optional<Dataset<Row>> rowDataset = executor.sql("select COALESCE(max(batch_id),0) from dev.performance_metrics where app_name='" + appName+"'");

        if(rowDataset.isPresent()) {
            Dataset<Row> appdataSet = rowDataset.get();
            batchId = appdataSet.select("batch_id").as(Encoders.INT()).collectAsList().get(0);
        }

        PerformanceMetric performanceMetric = new PerformanceMetric(appName, version, batchId + 1, startLHDtimestamp.toString(),
                endLHDtimestamp.toString(), "performance_metrics", numberOfColumns, numberOfRows);

        performanceMetricsWriter.logMetrics(performanceMetric);
    }

}
