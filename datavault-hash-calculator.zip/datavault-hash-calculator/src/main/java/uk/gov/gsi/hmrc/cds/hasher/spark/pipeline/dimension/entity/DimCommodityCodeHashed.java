package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity;

import lombok.Builder;
import lombok.Data;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static uk.gov.gsi.hmrc.cds.hasher.spark.helper.MD5Hasher.md5HashOf;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.parseLine;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.valueAt;

@Data
@Builder
public class DimCommodityCodeHashed implements Serializable, BaseEntity {

    private String cc_year;
    private String cc_month;
    private String hs_chapter;
    private String hs_heading;
    private String hs_chapter_heading;
    private String hs_subheading;
    private String hs_code;
    private String chapter_description;
    private String heading_description;
    private String subheading_description;
    private String hub_commodity;
    private String sat_commodity;

    public static final Encoder<DimCommodityCodeHashed> dimCommodityCodeHashedEncoder = Encoders.bean(DimCommodityCodeHashed.class);

    public static DimCommodityCodeHashed mapper(DimCommodityCode dimCommodityCode) {
        return DimCommodityCodeHashed.builder()
                .cc_year(dimCommodityCode.getCc_year())
                .cc_month(dimCommodityCode.getCc_month())
                .hs_chapter(dimCommodityCode.getHs_chapter())
                .hs_heading(dimCommodityCode.getHs_heading())
                .hs_chapter_heading(dimCommodityCode.getHs_chapter_heading())
                .hs_subheading(dimCommodityCode.getHs_subheading())
                .hs_code(dimCommodityCode.getHs_code())
                .chapter_description(dimCommodityCode.getChapter_description())
                .heading_description(dimCommodityCode.getHeading_description())
                .subheading_description(dimCommodityCode.getSubheading_description())
                .hub_commodity(hubCommodityHashed(dimCommodityCode))
                .sat_commodity(satCommodityHashDifference(dimCommodityCode))
                .build();
    }

    //    TODO - null is represented as 'null' string in PDI when calculating hashes. This needs cleanup onces we stabilise the whole pipeline
    private static String satCommodityHashDifference(DimCommodityCode dimCommodityCode) {
        return md5HashOf(Arrays.asList(
                dimCommodityCode.getCc_year() == null ? "null" : dimCommodityCode.getCc_year(),
                dimCommodityCode.getCc_month() == null ? "null" : dimCommodityCode.getCc_month(),
                dimCommodityCode.getHs_chapter() == null ? "null" : dimCommodityCode.getHs_chapter(),
                dimCommodityCode.getHs_heading() == null ? "null" : dimCommodityCode.getHs_heading(),
                dimCommodityCode.getHs_chapter_heading() == null ? "null" : dimCommodityCode.getHs_chapter_heading(),
                dimCommodityCode.getHs_subheading() == null ? "null" : dimCommodityCode.getHs_subheading(),
                dimCommodityCode.getChapter_description() == null ? "null" : dimCommodityCode.getChapter_description(),
                dimCommodityCode.getHeading_description() == null ? "null" : dimCommodityCode.getHeading_description(),
                dimCommodityCode.getSubheading_description() == null ? "null" : dimCommodityCode.getSubheading_description()
        ));
    }

    private static String hubCommodityHashed(DimCommodityCode dimCommodityCode) {
        return md5HashOf(dimCommodityCode.getHs_code());

    }

    public static DimCommodityCodeHashed parse(String line) {
        List<String> columns = parseLine(line);

        return DimCommodityCodeHashed.builder()
                .cc_year(valueAt(columns, 0))
                .cc_month(valueAt(columns, 1))
                .hs_chapter(valueAt(columns, 2))
                .hs_heading(valueAt(columns, 3))
                .hs_chapter_heading(valueAt(columns, 4))
                .hs_subheading(valueAt(columns, 5))
                .hs_code(valueAt(columns, 6))
                .chapter_description(valueAt(columns, 7))
                .heading_description(valueAt(columns, 8))
                .subheading_description(valueAt(columns, 9))
                .hub_commodity(valueAt(columns, 10))
                .sat_commodity(valueAt(columns, 11))
                .build();
    }
}
