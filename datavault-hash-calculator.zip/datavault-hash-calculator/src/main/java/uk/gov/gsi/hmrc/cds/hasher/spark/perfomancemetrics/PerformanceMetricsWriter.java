package uk.gov.gsi.hmrc.cds.hasher.spark.perfomancemetrics;

import lombok.extern.slf4j.Slf4j;
import org.apache.spark.sql.Dataset;
import org.springframework.stereotype.Component;
import scala.collection.JavaConversions;
import scala.collection.mutable.Seq;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.performance.entity.PerformanceMetric;

import java.util.Arrays;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.performance.entity.PerformanceMetric.performanceMetricEncoder;


@Component
public class PerformanceMetricsWriter extends TableReader {

    public <T> void logMetrics(PerformanceMetric performanceMetric, String tableName, String[] fieldNames) {
        Dataset<PerformanceMetric> performanceMetricDataset = sparkSession.createDataset(Arrays.asList(performanceMetric), performanceMetricEncoder);
        Seq<String> buffer = JavaConversions.asScalaBuffer(Arrays.asList(fieldNames));
        performanceMetricDataset.selectExpr(buffer).write().mode("append").insertInto(tableName);
    }
}