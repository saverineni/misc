package uk.gov.gsi.hmrc.cds.hasher.spark.perfomancemetrics;

import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.performance.entity.PerformanceMetric;

import java.util.Arrays;

@Component
public class PerformanceMetricsWriter extends TableReader {

    public <T> void logMetrics(PerformanceMetric performanceMetric, String tableName) {
        Dataset<PerformanceMetric> performanceMetricDataset = sparkSession.createDataset(Arrays.asList(performanceMetric), PerformanceMetric.performanceMtericEncoder);
        performanceMetricDataset.write().insertInto(tableName);
    }

}
