package uk.gov.gsi.hmrc.cds.hasher.spark.perfomancemetrics;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.helper.DDLBuilder;
import uk.gov.gsi.hmrc.cds.hasher.spark.helper.FilePersist;
import uk.gov.gsi.hmrc.cds.hasher.spark.helper.HiveContextAwareExecutor;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCountry;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.performance.entity.PerformanceMetric;

import java.util.Arrays;

import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.DimensionTables.DIM_COUNTRY;

@Component
public class PerformanceMetricsWriter extends TableReader {

    @Autowired
    private String dimensionHashedHDFSAbsoluteBasePath;

    public void createPerformanceDataset(PerformanceMetric metric) {
        Dataset<PerformanceMetric> performanceMetricDataset = sparkSession.createDataset(Arrays.asList(metric), PerformanceMetric.performanceMtericEncoder);
        savePerformanceMetricsDataset(performanceMetricDataset);

    }

    private <T> void savePerformanceMetricsDataset(Dataset<T> dataset) {
        String hashedFilePath = String.format("%s/%s", dimensionHashedHDFSAbsoluteBasePath, "performance_metrics");
        FilePersist.asDelimitedFile(dataset, hashedFilePath);
    }

}
