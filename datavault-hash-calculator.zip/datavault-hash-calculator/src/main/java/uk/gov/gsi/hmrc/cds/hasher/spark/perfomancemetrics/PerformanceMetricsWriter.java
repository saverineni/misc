package uk.gov.gsi.hmrc.cds.hasher.spark.perfomancemetrics;

import org.apache.spark.sql.Dataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.gov.gsi.hmrc.cds.hasher.spark.helper.FilePersist;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.TableReader;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.performance.entity.PerformanceMetric;

import java.util.Arrays;

@Component
public class PerformanceMetricsWriter extends TableReader {

    @Autowired
    private String dimensionHashedHDFSAbsoluteBasePath;


    public <T> void logMetrics(PerformanceMetric performanceMetric) {
        persistPerformanceDataset(performanceMetric);
    }

    private void persistPerformanceDataset(PerformanceMetric metric) {
        Dataset<PerformanceMetric> performanceMetricDataset = sparkSession.createDataset(Arrays.asList(metric), PerformanceMetric.performanceMtericEncoder);
        savePerformanceMetricsDataset(performanceMetricDataset);

    }

    private <T> void savePerformanceMetricsDataset(Dataset<T> dataset) {
        String hashedFilePath = String.format("%s/%s", dimensionHashedHDFSAbsoluteBasePath, "performance_metrics");
        FilePersist.asDelimitedFile(dataset, hashedFilePath);
    }

}
