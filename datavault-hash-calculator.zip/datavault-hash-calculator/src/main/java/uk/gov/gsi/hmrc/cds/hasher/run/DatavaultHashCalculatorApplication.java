package uk.gov.gsi.hmrc.cds.hasher.run;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import uk.gov.gsi.hmrc.cds.hasher.spark.HashCalculatorJob;

import javax.annotation.PostConstruct;

@SpringBootApplication
@ComponentScan(basePackages = {
		"uk.gov.gsi.hmrc.cds.hasher"
})
public class DatavaultHashCalculatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatavaultHashCalculatorApplication.class, args).close();
	}

	@Autowired
	HashCalculatorJob hashCalculatorJob;

	@PostConstruct
	public void runJob() {
		hashCalculatorJob.persistHashedTables();
	}
}
