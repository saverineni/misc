package uk.gov.gsi.hmrc.cds.hasher.spark.helper;

import com.google.common.base.Charsets;
import com.google.common.base.Joiner;
import com.google.common.hash.HashCode;
import com.google.common.hash.HashFunction;
import com.google.common.hash.Hashing;

import java.util.List;

public final class MD5Hasher {
    private static final String DEFAULT_DELIMITER = "|||";
    private static final String NULL_ESCAPE = "\\N";

    public static String md5HashOf(String valueToHash) {
        return Hashing.md5().newHasher().putString(useForNull(valueToHash), Charsets.UTF_8).hash().toString();
    }

    private static String useForNull(String valueToHash) {
        return (valueToHash == null) ? NULL_ESCAPE : valueToHash;
    }

    public static String md5HashOf(List<String> values) {
        String valueToHash = Joiner.on(DEFAULT_DELIMITER).useForNull(NULL_ESCAPE).join(values);
        return Hashing.md5().newHasher().putString(valueToHash, Charsets.UTF_8).hash().toString();
    }

}
