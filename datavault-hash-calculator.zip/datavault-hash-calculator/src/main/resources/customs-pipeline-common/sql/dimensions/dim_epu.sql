-- --
-- Country dimension
-- --
-- DROP TABLE IF EXISTS `${EXPLOIT_DB}`.epu_dimension_csv_file PURGE;
-- DROP TABLE IF EXISTS `${EXPLOIT_DB}`.${DIMENSION_NAME} PURGE;

-- External table from data CSV
CREATE EXTERNAL TABLE IF NOT EXISTS `${EXPLOIT_DB}`.epu_dimension_csv_file
(
  id INT,
  epu_number STRING,
  epu_name STRING,
  address STRING,
  region STRING,
  postcode STRING,
  latitude DECIMAL(10,7),
  longitude DECIMAL(10,7),
  dtifa String
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
LOCATION '${HDFS_DIM_DATA_PATH}/epu/';

-- Create dimension
-- Construct the epu_description as the concatenation of the
-- epu_code and the epu_name.
CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.${TABLE_NAME} as
SELECT
  id as epu_id,
  epu_number,
  epu_name,
  concat(cast(epu_number as string), ' - ', epu_name) as epu_description,
  address as street,
  region as city,
  postcode,
  latitude,
  longitude,
  case when dtifa = 'Yes' then true else false end as dtifa
FROM `${EXPLOIT_DB}`.epu_dimension_csv_file;
