-- --
-- ICS dimension
-- --

CREATE EXTERNAL TABLE IF NOT EXISTS `${EXPLOIT_DB}`.`import_clearance_status_codes_csv_file`
(
  ics_code CHAR(2),
  description STRING,
  update_method STRING,
  import_event STRING,
  export_event STRING,
  state STRING
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001'
LOCATION '${HDFS_DIM_DATA_PATH}/import_clearance_status_codes/'
TBLPROPERTIES ("skip.header.line.count"="1");

CREATE TABLE IF NOT EXISTS `${EXPLOIT_DB}`.`${TABLE_NAME}` AS
SELECT
  *
FROM `${EXPLOIT_DB}`.`import_clearance_status_codes_csv_file`;
