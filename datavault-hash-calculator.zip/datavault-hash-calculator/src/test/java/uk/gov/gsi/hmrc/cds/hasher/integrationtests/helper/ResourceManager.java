package uk.gov.gsi.hmrc.cds.hasher.integrationtests.helper;

import com.google.common.io.CharStreams;
import com.google.common.io.Resources;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Objects;

/**
 * Created by smalavalli on 13/12/16.
 */
public final class ResourceManager {
    private static Logger logger = LoggerFactory.getLogger(ResourceManager.class);

    public static InputStream getResourceAsInputStream(String filePath) {
        URL resource = Resources.getResource(filePath);
        InputStream inputStream = null;
        try {
            inputStream = resource.openStream();
        } catch (IOException e) {
            logger.error("Error accessing file {} ", filePath, e);
        }
        Objects.requireNonNull(inputStream, "inputStream cannot be null. Error accessing file " + filePath);

        return inputStream;
    }

    public static URI getResourceURI(String filePath) {
        URI uri = null;
        try {
            uri = Resources.getResource(filePath).toURI();
        } catch (URISyntaxException e) {
            logger.error("Error accessing file {}", filePath);
        }
        return uri;
    }


    public static BufferedReader readResource(String filePath) {
        return new BufferedReader(new InputStreamReader(getResourceAsInputStream(filePath)));
    }

    public static String getResourceAsString(String filePath) {
        String resourceAsString = null;
        try {
            resourceAsString = CharStreams.toString(new InputStreamReader(getResourceAsInputStream(filePath)));
        } catch (IOException e) {
            logger.error("Error accessing file {} ", filePath, e);
        }

        Objects.requireNonNull(resourceAsString, "InputStream cannot be null. Error accessing file " + filePath);
        return resourceAsString;
    }
}
