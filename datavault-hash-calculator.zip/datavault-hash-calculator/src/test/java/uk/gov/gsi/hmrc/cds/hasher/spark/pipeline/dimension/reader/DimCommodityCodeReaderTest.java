package uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.reader;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.hasher.spark.SparkMockTest;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCommodityCode;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.toArray;

public class DimCommodityCodeReaderTest extends SparkMockTest {
    @Autowired
    DimCommodityCodeReader dimCommodityCodeReader;

    private static String[] dimCommodityCodeStructFields = toArray(
            Lists.newArrayList(
                    "cc_month",
                    "cc_year",
                    "chapter_description",
                    "heading_description",
                    "hs_chapter",
                    "hs_chapter_heading",
                    "hs_code",
                    "hs_heading",
                    "hs_subheading",
                    "subheading_description"
            )
    );

    @Test
    public void buildsDimCommodityCodeDataframe() throws Exception {
        Dataset<DimCommodityCode> dimCommodityCodeDataset = dimCommodityCodeReader.dimCommodityCodeDataset();
        assertThat(dimCommodityCodeDataset.count(), is(greaterThan(0l)));

        dimCommodityCodeDataset.printSchema();
        String[] fieldNames = dimCommodityCodeDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(dimCommodityCodeStructFields));
    }
}