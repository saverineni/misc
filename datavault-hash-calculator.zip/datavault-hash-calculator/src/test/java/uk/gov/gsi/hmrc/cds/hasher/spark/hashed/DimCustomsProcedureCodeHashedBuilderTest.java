package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.hasher.spark.SparkMockTest;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCustomsProcedureCodeHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.readers.DimCustomsProcedureCodeHashedReader;

import java.util.List;

import static com.google.common.base.Strings.isNullOrEmpty;
import static java.util.Objects.isNull;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertTrue;

public class DimCustomsProcedureCodeHashedBuilderTest extends SparkMockTest {

    @Autowired
    DimCustomsProcedureCodeHashedBuilder dimCustomsProcedureCodeHashedBuilder;
    @Autowired
    DimCustomsProcedureCodeHashedReader dimCustomsProcedureCodeHashedReader;

    @Test
    public void buildDimCustomsProcedureCodeHashed() {
        Dataset<DimCustomsProcedureCodeHashed> dataset = dimCustomsProcedureCodeHashedBuilder.build();
        assertThat(dataset.count(), is(greaterThan(0l)));

        String[] fieldNames = dataset.schema().fieldNames();
//        assertThat(Arrays.asList(fieldNames), contains(landingHeaderDeclarationHashedStructFields));

        Dataset<DimCustomsProcedureCodeHashed> pdiHashedDataset = dimCustomsProcedureCodeHashedReader.dimCustomsProcedureCodeHashedDataset();
        List<DimCustomsProcedureCodeHashed> actualHashed = dataset.toJavaRDD().collect();
        List<DimCustomsProcedureCodeHashed> expectedHashed = pdiHashedDataset.toJavaRDD().collect();

        // TODO - prehaps we don't need to assert this horrible way. This is for the initial verification of all rows and columns.
        // TODO - To be cleaned up to assert one row.
        actualHashed.forEach(dimCustomsProcedureCodeHashed -> {

            DimCustomsProcedureCodeHashed expectedDimCustomsProcedureCodeHashed = expectedHashed.stream()
                    .filter(v1 -> (v1.getCustoms_procedure_code().equals(dimCustomsProcedureCodeHashed.getCustoms_procedure_code())))
                    .findFirst()
                    .get();

            System.out.println(dimCustomsProcedureCodeHashed.toString());
            System.out.println(expectedDimCustomsProcedureCodeHashed.toString());

            if (isNull(dimCustomsProcedureCodeHashed.getCustoms_procedure_code())) {
                assertTrue(isNullOrEmpty(expectedDimCustomsProcedureCodeHashed.getCustoms_procedure_code()));
            } else {
                assertThat(dimCustomsProcedureCodeHashed.getCustoms_procedure_code(), is((equalTo(expectedDimCustomsProcedureCodeHashed.getCustoms_procedure_code()))));
            }
            if (isNull(dimCustomsProcedureCodeHashed.getSeries())) {
                assertTrue(isNullOrEmpty(expectedDimCustomsProcedureCodeHashed.getSeries()));
            } else {
                assertThat(dimCustomsProcedureCodeHashed.getSeries(), is((equalTo(expectedDimCustomsProcedureCodeHashed.getSeries()))));
            }
            if (isNull(dimCustomsProcedureCodeHashed.getPage())) {
                assertTrue(isNullOrEmpty(expectedDimCustomsProcedureCodeHashed.getPage()));
            } else {
                assertThat(dimCustomsProcedureCodeHashed.getPage(), is((equalTo(expectedDimCustomsProcedureCodeHashed.getPage()))));
            }
            if (isNull(dimCustomsProcedureCodeHashed.getProcedure())) {
                assertTrue(isNullOrEmpty(expectedDimCustomsProcedureCodeHashed.getProcedure()));
            } else {
                assertThat(dimCustomsProcedureCodeHashed.getProcedure(), is((equalTo(expectedDimCustomsProcedureCodeHashed.getProcedure()))));
            }
            if (isNull(dimCustomsProcedureCodeHashed.getProcedure_description())) {
                assertTrue(isNullOrEmpty(expectedDimCustomsProcedureCodeHashed.getProcedure_description()));
            } else {
                assertThat(dimCustomsProcedureCodeHashed.getProcedure_description(), is((equalTo(expectedDimCustomsProcedureCodeHashed.getProcedure_description()))));
            }
            if (isNull(dimCustomsProcedureCodeHashed.getPrevious_procedure())) {
                assertTrue(isNullOrEmpty(expectedDimCustomsProcedureCodeHashed.getPrevious_procedure()));
            } else {
                assertThat(dimCustomsProcedureCodeHashed.getPrevious_procedure(), is((equalTo(expectedDimCustomsProcedureCodeHashed.getPrevious_procedure()))));
            }
            if (isNull(dimCustomsProcedureCodeHashed.getPrevious_procedure_description())) {
                assertTrue(isNullOrEmpty(expectedDimCustomsProcedureCodeHashed.getPrevious_procedure_description()));
            } else {
                assertThat(dimCustomsProcedureCodeHashed.getPrevious_procedure_description(), is((equalTo(expectedDimCustomsProcedureCodeHashed.getPrevious_procedure_description()))));
            }
            if (isNull(dimCustomsProcedureCodeHashed.getNational_coding())) {
                assertTrue(isNullOrEmpty(expectedDimCustomsProcedureCodeHashed.getNational_coding()));
            } else {
                assertThat(dimCustomsProcedureCodeHashed.getNational_coding(), is((equalTo(expectedDimCustomsProcedureCodeHashed.getNational_coding()))));
            }
            if (isNull(dimCustomsProcedureCodeHashed.getType_of_goods())) {
                assertTrue(isNullOrEmpty(expectedDimCustomsProcedureCodeHashed.getType_of_goods()));
            } else {
                assertThat(dimCustomsProcedureCodeHashed.getType_of_goods(), is((equalTo(expectedDimCustomsProcedureCodeHashed.getType_of_goods()))));
            }
            if (isNull(dimCustomsProcedureCodeHashed.getType_of_goods_description())) {
                assertTrue(isNullOrEmpty(expectedDimCustomsProcedureCodeHashed.getType_of_goods_description()));
            } else {
                assertThat(dimCustomsProcedureCodeHashed.getType_of_goods_description(), is((equalTo(expectedDimCustomsProcedureCodeHashed.getType_of_goods_description()))));
            }
            if (isNull(dimCustomsProcedureCodeHashed.getRelease_mechanism())) {
                assertTrue(isNullOrEmpty(expectedDimCustomsProcedureCodeHashed.getRelease_mechanism()));
            } else {
                assertThat(dimCustomsProcedureCodeHashed.getRelease_mechanism(), is((equalTo(expectedDimCustomsProcedureCodeHashed.getRelease_mechanism()))));
            }
            if (isNull(dimCustomsProcedureCodeHashed.getRelease_mechanism_description())) {
                assertTrue(isNullOrEmpty(expectedDimCustomsProcedureCodeHashed.getRelease_mechanism_description()));
            } else {
                assertThat(dimCustomsProcedureCodeHashed.getRelease_mechanism_description(), is((equalTo(expectedDimCustomsProcedureCodeHashed.getRelease_mechanism_description()))));
            }
            if (isNull(dimCustomsProcedureCodeHashed.getRegime_entered_to())) {
                assertTrue(isNullOrEmpty(expectedDimCustomsProcedureCodeHashed.getRegime_entered_to()));
            } else {
                assertThat(dimCustomsProcedureCodeHashed.getRegime_entered_to(), is((equalTo(expectedDimCustomsProcedureCodeHashed.getRegime_entered_to()))));
            }
            if (isNull(dimCustomsProcedureCodeHashed.getRegime_entered_to_description())) {
                assertTrue(isNullOrEmpty(expectedDimCustomsProcedureCodeHashed.getRegime_entered_to_description()));
            } else {
                assertThat(dimCustomsProcedureCodeHashed.getRegime_entered_to_description(), is((equalTo(expectedDimCustomsProcedureCodeHashed.getRegime_entered_to_description()))));
            }
            assertThat(dimCustomsProcedureCodeHashed.getHub_customs_procedure_code(), is((equalTo(expectedDimCustomsProcedureCodeHashed.getHub_customs_procedure_code()))));

        });
    }
}