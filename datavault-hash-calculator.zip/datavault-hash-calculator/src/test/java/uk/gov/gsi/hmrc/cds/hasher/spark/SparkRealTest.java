package uk.gov.gsi.hmrc.cds.hasher.spark;

import org.apache.spark.sql.SQLContext;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import uk.gov.gsi.hmrc.cds.hasher.config.TestRealConfig;

@RunWith(SpringRunner.class)
@SpringBootTest(
        classes = {TestRealConfig.class}
)
public abstract class SparkRealTest {
    @Autowired
    public SQLContext sqlContext;
}
