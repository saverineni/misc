package uk.gov.gsi.hmrc.cds.hasher.spark;

/**
 * Created by smalavalli on 20/02/17.
 */
public interface TestConstants {
    int MD5_HASH_LENGTH = 32;
    int IMPORT_DECLARATION_HEADERS_COUNT = 5;
    int TRADER_COUNT = 5;
    int EXPORT_DECLARATION_HEADERS_COUNT = 5;
    int IMPORT_DECLARATION_LINES_COUNT = 15;
    int EXPORT_DECLARATION_LINES_COUNT = 15;
    int IMPORT_LINES_ADDTIONAL_INFO_COUNT = 16;
    int EXPORT_LINES_ADDTIONAL_INFO_COUNT = 16;
    int IMPORT_LINES_DOCUMENT = 15;
    int EXPORT_LINES_DOCUMENT = 16;
    int IMPORT_LINES_PREV_DOCUMENT = 15;
    int EXPORT_LINES_PREV_DOCUMENT = 15;
    int IMPORT_LINES_TAX_LINES = 16;
    int EXPORT_LINES_TAX_LINES = 16;
    String NULL_ESCAPE = "\\N";
    String DOCKER_DEV = "dev";
    String DOCKER_AUTOMATION_DEV = "automationdev";
    String DOCKER_QA = "qa";
    String DOCKER_DEMO_1 = "demo1";
    String DOCKER_DEMO_2 = "demo2";

}
