package uk.gov.gsi.hmrc.cds.hasher.spark.hdfs.builder;

import org.apache.hadoop.conf.Configuration;

/**
 * Created by smalavalli on 01/11/16.
 */
public class HDFSConfigurationBuilder {

    public static final String DEFAULT_URL_STRING = "default-url-string";
    public static final String HDFS_PATH = "hdfs-path";

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        public static final String NAME_NODE_HOST = "name-node-host";
        public static final String NAME_NODE_PORT = "name-node-port";
        Configuration configuration = new Configuration();

        public Builder withNameNodeHost(String nameNodeHost) {
            configuration.set(NAME_NODE_HOST, nameNodeHost);
            return this;
        }

        public Builder withNameNodePort(String nameNodePort) {
            configuration.set(NAME_NODE_PORT, nameNodePort);
            return this;
        }

        public Builder withHDFSPath(String hdfsPath) {
            configuration.set(HDFS_PATH, hdfsPath);
            return this;
        }

        public Builder asUser(String user) {
            configuration.set("hadoop.job.ugi", user);
            return this;
        }

        public Configuration build() {
            String host = configuration.get(NAME_NODE_HOST);
            String port = configuration.get(NAME_NODE_PORT);
            String path = configuration.get(HDFS_PATH);
            configuration.set(DEFAULT_URL_STRING, String.format("hdfs://%s:%s", host, port));
            return configuration;
        }
    }

}
