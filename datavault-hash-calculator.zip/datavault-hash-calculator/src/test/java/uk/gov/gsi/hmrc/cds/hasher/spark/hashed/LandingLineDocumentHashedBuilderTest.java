package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.hasher.spark.SparkMockTest;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLineDocumentHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.readers.LandingLineDocumentHashedReader;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.toArray;

public class LandingLineDocumentHashedBuilderTest extends SparkMockTest {

    @Autowired
    LandingLineDocumentHashedBuilder landingLineDocumentHashedBuilder;

    @Autowired
    LandingLineDocumentHashedReader landingLineDocumentHashedReader;

    @Test
    public void buildLandingLineDocumentHashed() throws Exception {
        Dataset<LandingLineDocumentHashed> dataset = landingLineDocumentHashedBuilder.build();
        assertThat(dataset.count(), is(greaterThan(0l)));

        String[] fieldNames = dataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(landingLinesDeclarationHashedStructFields));

        Dataset<LandingLineDocumentHashed> pdiHashedDataset = landingLineDocumentHashedReader.landingLineDocumentHashedDataset();

        List<LandingLineDocumentHashed> actualHashed = dataset.toJavaRDD().collect();
        List<LandingLineDocumentHashed> expectedHashed = pdiHashedDataset.toJavaRDD().collect();

        // TODO - prehaps we don't need to assert this horrible way. This is for the initial verification of all rows and columns.
        // TODO - To be cleaned up to assert one row.
        actualHashed.forEach(landingLineDocumentHashed -> {

            LandingLineDocumentHashed expectedLandingLineDocumentHashed = expectedHashed.stream()
                    .filter(v1 ->
                            (v1.getEntry_reference().equals(landingLineDocumentHashed.getEntry_reference())) &&
                                    (v1.getItem_number().equals(landingLineDocumentHashed.getItem_number())) &&
                                    (v1.getDocument_sequence_number().equals(landingLineDocumentHashed.getDocument_sequence_number()))
                    )
                    .findFirst()
                    .get();

            assertThat(landingLineDocumentHashed.getSource(), is(equalTo(expectedLandingLineDocumentHashed.getSource())));
            assertThat(landingLineDocumentHashed.getIngestion_date(), is(equalTo(expectedLandingLineDocumentHashed.getIngestion_date())));
            assertThat(landingLineDocumentHashed.getItem_number(), is(equalTo(expectedLandingLineDocumentHashed.getItem_number())));
            assertThat(landingLineDocumentHashed.getDocument_sequence_number(), is(equalTo(expectedLandingLineDocumentHashed.getDocument_sequence_number())));
            assertThat(landingLineDocumentHashed.getGeneration_number(), is(equalTo(expectedLandingLineDocumentHashed.getGeneration_number())));
            assertThat(landingLineDocumentHashed.getItem_document_code(), is(equalTo(expectedLandingLineDocumentHashed.getItem_document_code())));
            assertThat(landingLineDocumentHashed.getItem_document_status(), is(equalTo(expectedLandingLineDocumentHashed.getItem_document_status())));
            assertThat(landingLineDocumentHashed.getItem_document_reference(), is(equalTo(expectedLandingLineDocumentHashed.getItem_document_reference())));
            assertThat(landingLineDocumentHashed.getEntry_reference(), is(equalTo(expectedLandingLineDocumentHashed.getEntry_reference())));
            assertThat(landingLineDocumentHashed.getHub_document(), is(equalTo(expectedLandingLineDocumentHashed.getHub_document())));
            assertThat(landingLineDocumentHashed.getSat_document(), is(equalTo(expectedLandingLineDocumentHashed.getSat_document())));
            assertThat(landingLineDocumentHashed.getLink_declaration_line_document(), is(equalTo(expectedLandingLineDocumentHashed.getLink_declaration_line_document())));
            assertThat(landingLineDocumentHashed.getLink_declaration_line_document_hub_declaration_line(), is(equalTo(expectedLandingLineDocumentHashed.getLink_declaration_line_document_hub_declaration_line())));
        });

    }

    public static String[] landingLinesDeclarationHashedStructFields = toArray(
            Lists.newArrayList(
                    "document_sequence_number",
                    "entry_reference",
                    "generation_number",
                    "hub_document",
                    "ingestion_date",
                    "item_document_code",
                    "item_document_reference",
                    "item_document_status",
                    "item_number",
                    "link_declaration_line_document",
                    "link_declaration_line_document_hub_declaration_line",
                    "sat_document",
                    "source"
            )
    );
}