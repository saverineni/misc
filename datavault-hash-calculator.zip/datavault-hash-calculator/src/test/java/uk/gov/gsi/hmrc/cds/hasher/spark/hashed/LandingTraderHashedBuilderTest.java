package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.hasher.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingTraderHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader.LandingTraderHashedReader;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.toArray;

public class LandingTraderHashedBuilderTest extends SparkTest {

    @Autowired
    LandingTraderHashedBuilder landingTraderHashedBuilder;
    @Autowired
    LandingTraderHashedReader landingTraderHashedReader;

    @Test
    public void buildLandingTraderHashed() throws Exception {
        Dataset<LandingTraderHashed> dataset = landingTraderHashedBuilder.build();
        assertThat(dataset.count(), is(greaterThan(0l)));
        // TODO assert hashes

        String[] fieldNames = dataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(landingTraderHashedStructFields));

        Dataset<LandingTraderHashed> pdiHashedDataset = landingTraderHashedReader.landingTraderHashedDataset();

        List<LandingTraderHashed> actualHashed = dataset.toJavaRDD().collect();
        List<LandingTraderHashed> expectedHashed = pdiHashedDataset.toJavaRDD().collect();

        // TODO - prehaps we don't need to assert this horrible way. This is for the initial verification of all rows and columns.
        // TODO - To be cleaned up to assert one row.
        actualHashed.forEach(landingTraderHashed -> {
            LandingTraderHashed expectedLandingTraderHashed = expectedHashed.stream()
                    .filter(v1 -> v1.getTurn().equals(landingTraderHashed.getTurn()))
                    .findFirst()
                    .get();

            assertThat(landingTraderHashed.getSource(), is(equalTo(expectedLandingTraderHashed.getSource())));
            assertThat(landingTraderHashed.getIngestion_date(), is(equalTo(expectedLandingTraderHashed.getIngestion_date())));
            assertThat(landingTraderHashed.getTurn(), is(equalTo(expectedLandingTraderHashed.getTurn())));
            assertThat(landingTraderHashed.getFedate(), is(equalTo(expectedLandingTraderHashed.getFedate())));
            assertThat(landingTraderHashed.getName(), is(equalTo(expectedLandingTraderHashed.getName())));
            assertThat(landingTraderHashed.getSimplified_procedure_authorisations(), is(equalTo(expectedLandingTraderHashed.getSimplified_procedure_authorisations())));
            assertThat(landingTraderHashed.getTrader_name_abbreviated(), is(equalTo(expectedLandingTraderHashed.getTrader_name_abbreviated())));
            assertThat(landingTraderHashed.getCurrentind(), is(equalTo(expectedLandingTraderHashed.getCurrentind())));
            assertThat(landingTraderHashed.getHub_trader(), is(equalTo(expectedLandingTraderHashed.getHub_trader())));
            assertThat(landingTraderHashed.getSat_trader(), is(equalTo(expectedLandingTraderHashed.getSat_trader())));
        });

    }

    public static String[] landingTraderHashedStructFields = toArray(
            Lists.newArrayList(
                    "currentind",
                    "fedate",
                    "hub_trader",
                    "ingestion_date",
                    "name",
                    "sat_trader",
                    "simplified_procedure_authorisations",
                    "source",
                    "trader_name_abbreviated",
                    "turn"
            )
    );
}