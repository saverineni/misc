package uk.gov.gsi.hmrc.cds.hasher.spark.hdfs;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.permission.FsAction;
import org.apache.hadoop.fs.permission.FsPermission;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.gov.gsi.hmrc.cds.hasher.integrationtests.connection.HDFS;
import uk.gov.gsi.hmrc.cds.hasher.spark.hdfs.builder.HDFSConfigurationBuilder;
import uk.gov.gsi.hmrc.cds.hasher.spark.hdfs.builder.HDFSFileSystemBuilder;

import java.io.IOException;
import java.util.Arrays;
import java.util.Objects;

/**
 * Created by smalavalli on 20/01/17.
 */
public class HDFSFileSystemUtil {
    private static Logger logger = LoggerFactory.getLogger(HDFSFileSystemUtil.class);
    public static final String HADOOP_USER_CDSDATA = "cdsdata";
//    public static final String AUTOMATION_TEST_CACHE_PATH = String.format("/user/cdsdata/automation_test_cache/%s", HiveDBManager.DEFAULT_TEST_DB);
//    public static final String TEST_DB_PATH = String.format("/user/hive/warehouse/%s.db", HiveDBManager.DEFAULT_TEST_DB);

    private static Configuration configuration = HDFSConfigurationBuilder.builder()
            .withNameNodeHost(HDFS.NAMENODE.host())
            .withNameNodePort(HDFS.NAMENODE.port())
            .build();

    private static final FileSystem hdfs = HDFSFileSystemBuilder.builder(configuration).getHDFSInstance();

    public static CreateDirectory createDirectoryAsUser(String hadoopUser) {
        return new CreateDirectory(hadoopUser);
    }

    public static RemoveDirectory removeDirectoryAsUser(String hadoopUser) {
        return new RemoveDirectory(hadoopUser);
    }

    public static CopyData copyDataAsUser(String hadoopUser) {
        return new CopyData(hadoopUser);
    }

    public static CopyLocalToHDFS copyLocalToHDFSAsUser(String hadoopUser) {
        return new CopyLocalToHDFS(hadoopUser);
    }

    public static class CopyLocalToHDFS implements HDFSCommandExecutor {
        private String hadoopUser;
        private String fromLocalPath;
        private String toHDFSPath;

        public CopyLocalToHDFS(String hadoopUser) {
            this.hadoopUser = hadoopUser;
        }

        public CopyLocalToHDFS fromLocalPath(String fromPath) {
            this.fromLocalPath = fromPath;
            return this;
        }

        public CopyLocalToHDFS toHDFSPath(String toPath) {
            this.toHDFSPath = toPath;
            return this;
        }

        @Override
        public void hdfsActions(Configuration configuration) throws IOException {
            Objects.requireNonNull(fromLocalPath, "From local path cannot be null");
            Objects.requireNonNull(toHDFSPath, "To path cannot be null");
            FileSystem hdfs = HDFSFileSystemBuilder.builder(configuration).getHDFSInstance();
            Path localFromPath = new Path(fromLocalPath);
            Path hdfsToPath = new Path(toHDFSPath);
            hdfs.copyFromLocalFile(localFromPath, hdfsToPath);
        }

        public void copy() {
            this.executeHDFSCommandAsUser(hadoopUser, configuration);
        }
    }

    public static class CopyData implements HDFSCommandExecutor {
        private String hadoopUser;
        private String fromHDFSPath;
        private String toHDFSPath;

        public CopyData(String hadoopUser) {
            this.hadoopUser = hadoopUser;
        }

        public CopyData fromHDFSPath(String fromPath) {
            this.fromHDFSPath = fromPath;
            return this;
        }

        public CopyData toHDFSPath(String toPath) {
            this.toHDFSPath = toPath;
            return this;
        }

        @Override
        public void hdfsActions(Configuration configuration) throws IOException {
            Objects.requireNonNull(fromHDFSPath, "From path cannot be null");
            Objects.requireNonNull(toHDFSPath, "To path cannot be null");
            FileSystem hdfs = HDFSFileSystemBuilder.builder(configuration).getHDFSInstance();
            Path hdfsFromPath = new Path(fromHDFSPath);
            Path hdfsToPath = new Path(toHDFSPath);
            if (hdfs.isFile(hdfsFromPath) && hdfs.isFile(hdfsToPath)) {
                // copy files
                FileUtil.copy(hdfs, hdfsFromPath, hdfs, hdfsToPath, false, true, configuration); // overwrites if exists
            } else {
                // copy content of the directory
                FileStatus[] fileStatuses = hdfs.listStatus(hdfsFromPath);
                Arrays.stream(fileStatuses).map(FileStatus::getPath).forEach(
                        path -> {
                            try {
                                if (hdfs.isFile(path)) {
                                    String fileName = path.getName();
                                    Path fromFilePath = new Path(fromHDFSPath, fileName);
                                    Path toFilePath = new Path(toHDFSPath, fileName);
                                    FileUtil.copy(hdfs, fromFilePath, hdfs, toFilePath, false, true, configuration); // overwrites if exists
                                }
                            } catch (IOException e) {
                                logger.error("Error copying files from '{}' to '{}' in hdfs", fromHDFSPath, toHDFSPath + e);
                            }
                        }
                );
            }
        }

        public void copy() {
            this.executeHDFSCommandAsUser(hadoopUser, configuration);
        }
    }

    public static class CreateDirectory implements HDFSCommandExecutor {
        private String hadoopUser;
        private String path;

        public CreateDirectory(String hadoopUser) {
            this.hadoopUser = hadoopUser;
        }

        public CreateDirectory withPath(String path) {
            this.path = path;
            return this;
        }

        @Override
        public void hdfsActions(Configuration configuration) throws IOException {
            Objects.requireNonNull(path, "Create path cannot be null");
            Path hdfsPath = new Path(path);
            FileSystem hdfs = HDFSFileSystemBuilder.builder(configuration).getHDFSInstance();
            FsPermission fsPermission = new FsPermission(FsAction.ALL, FsAction.ALL, FsAction.ALL);
//            hdfs.create(hdfsPath, true);
            hdfs.mkdirs(hdfsPath, fsPermission);
            hdfs.setPermission(hdfsPath, fsPermission);
//            hdfs.setOwner(hdfsPath, "cdsdata", "hive");
        }

        public void create() {
            this.executeHDFSCommandAsUser(hadoopUser, configuration);
        }
    }

    public static class RemoveDirectory implements HDFSCommandExecutor {
        private String hadoopUser;
        private String path;

        public RemoveDirectory(String hadoopUser) {
            this.hadoopUser = hadoopUser;
        }

        public RemoveDirectory withPath(String path) {
            this.path = path;
            return this;
        }

        @Override
        public void hdfsActions(Configuration configuration) throws IOException {
            Objects.requireNonNull(path, "Create path cannot be null");
            Path hdfsPath = new Path(path);
            FileSystem hdfs = HDFSFileSystemBuilder.builder(configuration).getHDFSInstance();
            FsPermission fsPermission = new FsPermission(FsAction.ALL, FsAction.ALL, FsAction.ALL);
            hdfs.delete(hdfsPath, true);
        }

        public void remove() {
            this.executeHDFSCommandAsUser(hadoopUser, configuration);
        }
    }

    public static boolean directoryExists(String hdfsPath) {
        boolean exists = false;
        try {
            exists = hdfs.isDirectory(new Path(hdfsPath));
        } catch (IOException e) {
            logger.error("HDFS directory path {} does not exist", hdfsPath);
        }
        return exists;
    }

    public static boolean directoryContainFiles(String hdfsPath) {
        boolean fileExists = false;
        if (directoryExists(hdfsPath)) {
            try {
                FileStatus[] fileStatuses = hdfs.listStatus(new Path(hdfsPath));
                fileExists = Arrays.stream(fileStatuses).count() > 0l;
            } catch (IOException e) {
                logger.error("HDFS directory path {} does not exist", hdfsPath);
            }
        }
        return fileExists;
    }
}
