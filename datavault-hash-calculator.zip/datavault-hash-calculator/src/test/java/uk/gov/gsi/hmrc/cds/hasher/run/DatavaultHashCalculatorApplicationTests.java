package uk.gov.gsi.hmrc.cds.hasher.run;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import uk.gov.gsi.hmrc.cds.hasher.run.DatavaultHashCalculatorApplication;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
		DatavaultHashCalculatorApplication.class
})

public class DatavaultHashCalculatorApplicationTests {

	@Test
	public void contextLoads() {
	}

}
