package uk.gov.gsi.hmrc.cds.hasher.spark;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import uk.gov.gsi.hmrc.cds.hasher.spark.hdfs.builder.HDFSConfigurationBuilder;
import uk.gov.gsi.hmrc.cds.hasher.spark.hdfs.builder.HDFSFileSystemBuilder;

import java.io.File;
import java.io.IOException;

@Profile({"localtest"})
public class SparkIntegrationTest extends SparkRealTest {

    private String dimensionsSourcePath = "src/test/resources/dimension/";
    private String landingSourcePath = "src/test/resources/landing/";
    private Path hdfsFolderPath = new Path("/user/osboxes/spark/test_dev.db/");

    private static Configuration configuration = HDFSConfigurationBuilder.builder()
            .withNameNodeHost("localhost")
            .withNameNodePort("8020")
            .build();


    FileSystem hdfs = HDFSFileSystemBuilder.builder(configuration).getHDFSInstance();

    @Autowired
    private HashCalculatorJob hashCalculatorJob;


    public void setup() throws IOException {
        hdfs.mkdirs(hdfsFolderPath);
        copyFilesToDir(dimensionsSourcePath, hdfs, hdfsFolderPath.toString());
        copyFilesToDir(landingSourcePath, hdfs, hdfsFolderPath.toString());
    }

    void copyFilesToDir(String srcDirPath, FileSystem fs, String destDirPath) throws IOException {
        File dir = new File(srcDirPath);
        for (File file : dir.listFiles()) {
            fs.copyFromLocalFile(new Path(file.getPath()), new Path(destDirPath, file.getName()));
        }
    }

    @After
    public void deleteResources() throws IOException {
        //  hdfs.deleteOnExit(hdfsFolderPath);
    }

    @Test
    public void sparkIntegration() throws Exception {
        System.out.print("");
        hashCalculatorJob.persistHashedTables();
    }

}