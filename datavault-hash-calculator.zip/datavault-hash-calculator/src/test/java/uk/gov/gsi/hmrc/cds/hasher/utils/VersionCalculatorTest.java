package uk.gov.gsi.hmrc.cds.hasher.utils;

import org.junit.Assert;
import org.junit.Test;
import uk.gov.gsi.hmrc.cds.hasher.spark.VersionCalculator;

import java.util.Optional;

public class VersionCalculatorTest {

    @Test
    public void applicationVersion (){
        VersionCalculator calc = new VersionCalculator();
        Assert.assertEquals(Optional.empty(), calc.getApplicationVersion());
    }

    @Test
    public void version (){
        VersionCalculator calc = new VersionCalculator();
        Assert.assertEquals(Optional.of("1.0.0"), calc.getVersion("1.0.0-SNAPSHOT"));
    }
}
