package uk.gov.gsi.hmrc.cds.hasher.integrationtests.helper;

import org.apache.commons.configuration.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

/**
 * Created by smalavalli on 29/11/16.
 */
public final class PropertyConfiguration {
    private static final Logger logger = LoggerFactory.getLogger(PropertyConfiguration.class);

    public static Configuration config() {
        CompositeConfiguration config = new CompositeConfiguration();
        config.addConfiguration(new SystemConfiguration());
        try {
            config.addConfiguration(new PropertiesConfiguration("config.properties"));
            config.addConfiguration(new PropertiesConfiguration("secure.properties"));
        } catch (ConfigurationException cex) {
            logger.error("loading of the configuration file failed " + cex);
        }
        Objects.requireNonNull(config, "git ignored file 'secure.properties' missing from test/resources");
        return config;
    }
}