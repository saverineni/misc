package uk.gov.gsi.hmrc.cds.hasher.integrationtests.connection;

/**
 * Created by smalavalli on 02/12/16.
 */
public enum FASTP {
//    FASTP_1("10.102.83.72"),
//    FASTP_2("10.102.83.77"),
//    FASTP_3("10.102.83.141"),
//    FASTP_4("10.102.83.146"),
    LOCAL("localhost", "cdsdata");

    private final String username;
    private String host;

    FASTP(String host, String username) {
        this.host = host;
        this.username = username;
    }

    public String host() {
        return host;
    }

    public String username() {
        return username;
    }
}
