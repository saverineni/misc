package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.hasher.spark.SparkTest;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.entity.LandingLinePreviousDocumentHashed;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.landing.reader.LandingLinePreviousDocumentHashedReader;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.toArray;

public class LandingLinePreviousDocumentHashedBuilderTest extends SparkTest {

    @Autowired
    LandingLinePreviousDocumentHashedBuilder landingLinePreviousDocumentHashedBuilder;

    @Autowired
    LandingLinePreviousDocumentHashedReader landingLinePreviousDocumentHashedReader;

    @Test
    public void buildLandingLinePreviousDocumentHashed() throws Exception {
        Dataset<LandingLinePreviousDocumentHashed> dataset = landingLinePreviousDocumentHashedBuilder.build();
        assertThat(dataset.count(), is(greaterThan(0l)));

        String[] fieldNames = dataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(landingLinePreviousDocumentHashedStructFields));


        Dataset<LandingLinePreviousDocumentHashed> pdiHashedDataset = landingLinePreviousDocumentHashedReader.landingLinePreviousDocumentHashedDataset();
        List<LandingLinePreviousDocumentHashed> actualHashed = dataset.toJavaRDD().collect();
        List<LandingLinePreviousDocumentHashed> expectedHashed = pdiHashedDataset.toJavaRDD().collect();

        // TODO - prehaps we don't need to assert this horrible way. This is for the initial verification of all rows and columns.
        // TODO - To be cleaned up to assert one row.
        actualHashed.forEach(landingLinePreviousDocumentHashed -> {
            LandingLinePreviousDocumentHashed expectedLandingLinePreviousDocumentHashed = expectedHashed.stream()
                    .filter(v1 ->
                            (v1.getEntry_reference().equals(landingLinePreviousDocumentHashed.getEntry_reference())) &&
                                    (v1.getItem_number().equals(landingLinePreviousDocumentHashed.getItem_number())) &&
                                    (v1.getPrevious_document_sequence_number().equals(landingLinePreviousDocumentHashed.getPrevious_document_sequence_number()))

                    )
                    .findFirst()
                    .get();

            assertThat(landingLinePreviousDocumentHashed.getSource(), is(equalTo(expectedLandingLinePreviousDocumentHashed.getSource())));
            assertThat(landingLinePreviousDocumentHashed.getIngestion_date(), is(equalTo(expectedLandingLinePreviousDocumentHashed.getIngestion_date())));
            assertThat(landingLinePreviousDocumentHashed.getItem_number(), is(equalTo(expectedLandingLinePreviousDocumentHashed.getItem_number())));
            assertThat(landingLinePreviousDocumentHashed.getPrevious_document_sequence_number(), is(equalTo(expectedLandingLinePreviousDocumentHashed.getPrevious_document_sequence_number())));
            assertThat(landingLinePreviousDocumentHashed.getPrevious_document_reference(), is(equalTo(expectedLandingLinePreviousDocumentHashed.getPrevious_document_reference())));
            assertThat(landingLinePreviousDocumentHashed.getEntry_reference(), is(equalTo(expectedLandingLinePreviousDocumentHashed.getEntry_reference())));
            assertThat(landingLinePreviousDocumentHashed.getHub_previous_document(), is(equalTo(expectedLandingLinePreviousDocumentHashed.getHub_previous_document())));
            assertThat(landingLinePreviousDocumentHashed.getSat_previous_document(), is(equalTo(expectedLandingLinePreviousDocumentHashed.getSat_previous_document())));
            assertThat(landingLinePreviousDocumentHashed.getLink_declaration_line_previous_document(), is(equalTo(expectedLandingLinePreviousDocumentHashed.getLink_declaration_line_previous_document())));
            assertThat(landingLinePreviousDocumentHashed.getLink_declaration_line_previous_document_hub_declaration_line(), is(equalTo(expectedLandingLinePreviousDocumentHashed.getLink_declaration_line_previous_document_hub_declaration_line())));
        });
    }

    private static String[] landingLinePreviousDocumentHashedStructFields = toArray(
            Lists.newArrayList(
                    "entry_reference",
                    "hub_previous_document",
                    "ingestion_date",
                    "item_number",
                    "link_declaration_line_previous_document",
                    "link_declaration_line_previous_document_hub_declaration_line",
                    "previous_document_reference",
                    "previous_document_sequence_number",
                    "sat_previous_document",
                    "source")
    );
}