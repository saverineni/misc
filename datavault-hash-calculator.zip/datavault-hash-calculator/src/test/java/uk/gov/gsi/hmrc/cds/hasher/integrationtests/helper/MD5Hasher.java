package uk.gov.gsi.hmrc.cds.hasher.integrationtests.helper;

import com.google.common.base.Charsets;
import com.google.common.base.Joiner;
import com.google.common.hash.HashCode;
import com.google.common.hash.HashFunction;
import com.google.common.hash.Hashing;

/**
 * Created by smalavalli on 16/01/17.
 */
public final class MD5Hasher {

    private static final String DEFAULT_DELIMITER = "|||";
    private static final String NULL_ESCAPE = "\\N";

    private static String md5HashOf(String value) {
        HashFunction hashFunction = Hashing.md5();
        HashCode hashCode = hashFunction.newHasher().putString(value, Charsets.UTF_8).hash();
        return hashCode.toString();
    }

    public static String md5HashOf(String... values) {
        String valueToHash = Joiner.on(DEFAULT_DELIMITER).useForNull(NULL_ESCAPE).join(values);
        return md5HashOf(valueToHash);
    }
}
