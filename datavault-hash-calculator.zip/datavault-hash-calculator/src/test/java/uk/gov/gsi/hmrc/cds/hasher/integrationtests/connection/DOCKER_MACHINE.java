package uk.gov.gsi.hmrc.cds.hasher.integrationtests.connection;

/**
 * Created by smalavalli on 15/05/16.
 */
public enum DOCKER_MACHINE {
    DEV("10.102.83.180", 2028, 2024),
    AUTOMATION_DEV("10.102.83.160", 2028, 2024),
    QA("10.102.83.196", 2028, 2024),
    DEMO_1("10.102.83.206", 2028, 2024),
    DEMO_2("10.102.82.59", 2028, 2024);

    private String host;
    private int sshPortPDIServer;
    private int sshPortClouderaServer;

    DOCKER_MACHINE(String host, int sshPortPDIServer, int sshPortClouderaServer) {
        this.host = host;
        this.sshPortPDIServer = sshPortPDIServer;
        this.sshPortClouderaServer = sshPortClouderaServer;
    }

    public String host() {
        return host;
    }

    public int sshPortPDIServer() {
        return sshPortPDIServer;
    }

    public int sshPortClouderaServer() {
        return sshPortClouderaServer;
    }
}
