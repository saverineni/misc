package uk.gov.gsi.hmrc.cds.hasher.spark.hashed;

import com.google.common.collect.Lists;
import org.apache.spark.sql.Dataset;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.gov.gsi.hmrc.cds.hasher.spark.SparkMockTest;
import uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.dimension.entity.DimCurrencyHashed;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static uk.gov.gsi.hmrc.cds.hasher.spark.pipeline.BaseEntity.toArray;

public class DimCurrencyHashedBuilderTest extends SparkMockTest {

    @Autowired
    DimCurrencyHashedBuilder dimCurrencyHashedBuilder;
    private static String[] dimCurrencyHashedStructFields = toArray(
            Lists.newArrayList(
                    "currency_id",
                    "currency_iso_code",
                    "currency_name",
                    "hub_currency",
                    "sat_currency"
            )
    );


    @Test
    public void buildsDimCurrencyHashedDataframe() throws Exception {
        Dataset<DimCurrencyHashed> dimCurrencyHashedDataset = dimCurrencyHashedBuilder.build();
        assertThat(dimCurrencyHashedDataset.count(), is(greaterThan(0l)));
        // TODO - assert hashes


        dimCurrencyHashedDataset.printSchema();
        String[] fieldNames = dimCurrencyHashedDataset.schema().fieldNames();
        assertThat(Arrays.asList(fieldNames), contains(dimCurrencyHashedStructFields));

    }
}