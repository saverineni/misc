package uk.gov.gsi.hmrc.cds.hasher.spark.helper;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class DDLBuilderTest {


    public static final String EXPECTED_SCRIPT = "CREATE EXTERNAL TABLE IF NOT EXISTS test_db.test_table (`field_1` string,`field_2` string,`field_3` string)\n" +
            "        ROW FORMAT DELIMITED\n" +
            "        FIELDS TERMINATED BY '\\u0001'\n" +
            "        STORED AS TEXTFILE\n" +
            "        LOCATION '/user/hive/test/test_db/test_table/'";

    @Test
    public void testBuildExternalTableScript() {
        DDLBuilder builder = new DDLBuilder();
        String [] fieldNames = {"field_1","field_2","field_3"};
        String buildExternalTableScript = builder.buildExternalTableScript("test_db", "test_table", fieldNames, "/user/hive/test/test_db/test_table/");
        Assert.assertEquals(EXPECTED_SCRIPT, buildExternalTableScript);
    }

}