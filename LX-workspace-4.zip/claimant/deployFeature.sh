
if [ $# -eq 0 ]; then
    echo "You must supply a environment" 
    exit
fi

pushd claimant-server
fab -f $DEPLOYMENT_SCRIPTS_HOME/java/deploy.py buildFeature
fab -f $DEPLOYMENT_SCRIPTS_HOME/java/deploy.py uploadFeature:$1
popd
