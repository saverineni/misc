package com.leadx.claimant.client;

import static com.google.common.collect.Lists.newArrayList;
import static com.leadx.test.MockUtils.mockAndSetOn;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestOperations;

import com.leadx.claimant.client.search.SearchRequestDto;
import com.leadx.claimant.client.search.SearchResultClaimantDto;
import com.leadx.lib.utl.json.JsonUtils;

@SuppressWarnings("unqualified-field-access")
public class ClaimantSearchServiceWrapperUnitTest {

	private ClaimantSearchServiceWrapper claimantSearchServiceWrapper;
	private RestOperations restOperations;
	
	private final Mockery context = new JUnit4Mockery();
	
	private static final String CLAIMANT_SEARCH_URL = "http://test.com:8080/claimant/search";
	
	@Before
	public void setup() {
		this.claimantSearchServiceWrapper = new ClaimantSearchServiceWrapper();
		this.restOperations = mockAndSetOn(this.context, RestOperations.class, this.claimantSearchServiceWrapper);
		
		ReflectionTestUtils.setField(this.claimantSearchServiceWrapper, "protocol", "http");
		ReflectionTestUtils.setField(this.claimantSearchServiceWrapper, "host", "test.com");
		ReflectionTestUtils.setField(this.claimantSearchServiceWrapper, "port", "8080");
	}
	
	@Test
	public void searchSuccess() {
		final SearchRequestDto searchRequestDto = new SearchRequestDto.Builder().setSurname("Laporte").setPhone("1234567890").createSearchRequestDto();
		final SearchResultClaimantDto searchResultClaimantDto = new SearchResultClaimantDto.Builder().setClaimantId(1111).setSurname("Laporte")
																		.setPostcode("1AA AAA").createSearchResultClaimantDto();

		final String resultString = JsonUtils.serialize(newArrayList(searchResultClaimantDto), true);
		final ResponseEntity<String> response = new ResponseEntity<>(resultString, HttpStatus.OK);

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(CLAIMANT_SEARCH_URL, searchRequestDto, String.class);
				will(returnValue(response));
			}
		});
		
		this.claimantSearchServiceWrapper.search(searchRequestDto);
	}

	@Test(expected = RuntimeException.class)
	public void searchFailure() {
		final SearchRequestDto searchRequestDto = new SearchRequestDto.Builder().setSurname("Laporte").setPhone("1234567890").createSearchRequestDto();
		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(CLAIMANT_SEARCH_URL, searchRequestDto, String.class);
			}
		});

		this.claimantSearchServiceWrapper.search(searchRequestDto);
	}
}
