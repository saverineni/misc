package com.leadx.claimant.client;

import static com.leadx.lib.utl.json.JsonUtils.serialize;
import static com.leadx.test.MockUtils.mockAndSetOn;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestOperations;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.leadx.claimant.client.reference.DebtManagementCompanyDto;
import com.leadx.claimant.client.reference.IvaCompanyDto;
import com.leadx.lib.utl.json.JsonUtils;

@SuppressWarnings("unqualified-field-access")
public class ClaimantServiceWrapperUnitTest {

	private ClaimantServiceWrapper claimantServiceWrapper;
	private RestOperations restOperations;
	
	private final Mockery context = new JUnit4Mockery();
	
	private static final int CLAIMANT_ID = 1234;
	private static final int USER_ID = 5678;
	private static final int SCHED_TASK_ID = 2222;

	private static final String LOCK_CLAIMANT_URL = "http://test.com:8080/claimant/%s/lock/user/%s/scheduledTaskId/%s";
	private static final String UNLOCK_CLAIMANT_URL = "http://test.com:8080/claimant/%s/unlock/user/%s";
	private static final String LOCK_STATUS_URL = "http://test.com:8080/claimant/%s/lock/status";
	
	@Before
	public void setup() {
		this.claimantServiceWrapper = new ClaimantServiceWrapper();
		this.restOperations = mockAndSetOn(this.context, RestOperations.class, this.claimantServiceWrapper);
		
		ReflectionTestUtils.setField(this.claimantServiceWrapper, "protocol", "http");
		ReflectionTestUtils.setField(this.claimantServiceWrapper, "host", "test.com");
		ReflectionTestUtils.setField(this.claimantServiceWrapper, "port", "8080");
	}
	
	@Test
	public void testSerializationAndDeserializationOfClaimantLockDto() {
		final ClaimantLockDto input = new ClaimantLockDto(true, USER_ID);
		
		final String serialized = JsonUtils.serialize(input, true);
		final ClaimantLockDto output = JsonUtils.deserialize(serialized, ClaimantLockDto.class);
		
		assertTrue(input.equals(output));
	}
	
	@Test
	public void shouldLockClaimant() {
		final ClaimantLockDto claimantLockDto = newClaimantLockDto(false);
		final ResponseEntity<String> response = newResponse(claimantLockDto, HttpStatus.OK);
		
		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).getForEntity(String.format(LOCK_CLAIMANT_URL, CLAIMANT_ID, USER_ID, SCHED_TASK_ID), String.class);
				will(returnValue(response));
			}
		});
		
		final ClaimantLockDto result = this.claimantServiceWrapper.lockClaimant(CLAIMANT_ID, USER_ID, SCHED_TASK_ID);
		assertTrue(claimantLockDto.equals(result));
	}
	
	@Test
	public void shouldHandleFailedLockClaimant() {
		final ClaimantLockDto claimantLockDto = newClaimantLockDto(true);
		final ResponseEntity<String> response = newResponse(claimantLockDto, HttpStatus.INTERNAL_SERVER_ERROR);
		
		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).getForEntity(String.format(LOCK_CLAIMANT_URL, CLAIMANT_ID, USER_ID, SCHED_TASK_ID), String.class);
				will(returnValue(response));
			}
		});
		
		final ClaimantLockDto result = this.claimantServiceWrapper.lockClaimant(CLAIMANT_ID, USER_ID, SCHED_TASK_ID);
		assertTrue(result.equals(new ClaimantLockDto(false, 0)));
	}
	
	@Test
	public void shouldUnlockClaimant() {
		final ClaimantUnlockDto claimantUnlockDto = newClaimantUnlockDto();
		final ResponseEntity<String> response = newResponse(claimantUnlockDto, HttpStatus.OK);
		
		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).getForEntity(String.format(UNLOCK_CLAIMANT_URL, CLAIMANT_ID, USER_ID), String.class);
				will(returnValue(response));
			}
		});
		
		final ClaimantUnlockDto result = this.claimantServiceWrapper.unlockClaimant(CLAIMANT_ID, USER_ID);
		assertTrue(claimantUnlockDto.equals(result));
	}
	
	@Test
	public void shouldHandleFailedUnlockClaimant() {
		final ClaimantUnlockDto claimantUnlockDto = newClaimantUnlockDto();
		final ResponseEntity<String> response = newResponse(claimantUnlockDto, HttpStatus.INTERNAL_SERVER_ERROR);
		
		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).getForEntity(String.format(UNLOCK_CLAIMANT_URL, CLAIMANT_ID, USER_ID), String.class);
				will(returnValue(response));
			}
		});
		
		final ClaimantUnlockDto result = this.claimantServiceWrapper.unlockClaimant(CLAIMANT_ID, USER_ID);
		assertTrue(result.equals(new ClaimantUnlockDto(0)));
	}
	
	@Test
	public void shouldGetClaimantLockStatus() {
		final ClaimantLockStatusDto claimantLockStatusDto = newClaimantLockStatusDto(true);
		final ResponseEntity<String> response = newResponse(claimantLockStatusDto, HttpStatus.OK);
		
		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).getForEntity(String.format(LOCK_STATUS_URL, CLAIMANT_ID, USER_ID), String.class);
				will(returnValue(response));
			}
		});
		
		final ClaimantLockStatusDto result = this.claimantServiceWrapper.getClaimantLockStatus(CLAIMANT_ID);
		assertTrue(claimantLockStatusDto.equals(result));
	}
	
	@Test
	public void shouldHandleFailedGetClaimantLockStatus() {
		final ClaimantLockStatusDto claimantLockStatusDto = newClaimantLockStatusDto(true);
		final ResponseEntity<String> response = newResponse(claimantLockStatusDto, HttpStatus.INTERNAL_SERVER_ERROR);
		
		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).getForEntity(String.format(LOCK_STATUS_URL, CLAIMANT_ID, USER_ID), String.class);
				will(returnValue(response));
			}
		});
		
		final ClaimantLockStatusDto result = this.claimantServiceWrapper.getClaimantLockStatus(CLAIMANT_ID);
		assertTrue(result == null);
	}

	@Test
	 public void updateClaimant(){
		final ClaimantDto claimantDto = newClaimantDto();
		final ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.OK);

		final String uri = getUri("/claimant/update/userId/{userId}");

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(uri, claimantDto, Void.class, USER_ID);
				will(returnValue(response));
			}
		});

		this.claimantServiceWrapper.updateClaimant(claimantDto, USER_ID);

	}

	@Test(expected = RuntimeException.class)
	public void updateClaimantInternalServerError(){
		final ClaimantDto claimantDto = newClaimantDto();
		final ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);

		final String uri = getUri("/claimant/update/userId/{userId}");

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(uri, claimantDto, Void.class, USER_ID);
				will(returnValue(response));
			}
		});

		this.claimantServiceWrapper.updateClaimant(claimantDto, USER_ID);

	}

	@Test
	public void updateClaimantInConfinement(){
		final ClaimantDto claimantDto = newClaimantDto();
		final ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.OK);

		final String uri = getUri("/claimant/confinement/update/userId/{userId}");

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(uri, claimantDto, Void.class, USER_ID);
				will(returnValue(response));
			}
		});

		this.claimantServiceWrapper.updateClaimantInConfinement(claimantDto, USER_ID);

	}

	@Test(expected = RuntimeException.class)
	public void updateClaimantInConfinementInternalServerError(){
		final ClaimantDto claimantDto = newClaimantDto();
		final ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);

		final String uri = getUri("/claimant/confinement/update/userId/{userId}");

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(uri, claimantDto, Void.class, USER_ID);
				will(returnValue(response));
			}
		});

		this.claimantServiceWrapper.updateClaimantInConfinement(claimantDto, USER_ID);
	}

	@Test
	public void getClaimantInteractions(){
		final ResponseEntity<ClaimantInteractionsDto> response = new ResponseEntity<>(HttpStatus.OK);

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).getForEntity(String.format("http://test.com:8080/claimant/%s/interactions", CLAIMANT_ID), ClaimantInteractionsDto.class);
				will(returnValue(response));
			}
		});

		this.claimantServiceWrapper.getClaimantInteractions(CLAIMANT_ID);

	}


	@Test
	public void getClaimantInteractionsBySources(){
		final ResponseEntity<ClaimantInteractionsDto> response = new ResponseEntity<>(HttpStatus.OK);

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).getForEntity(String.format("http://test.com:8080/claimant/%s/sources/%s/interactions/%s", CLAIMANT_ID, "PAYMENTS,SALES", 1), ClaimantInteractionsDto.class);
				will(returnValue(response));
			}
		});

		this.claimantServiceWrapper.getClaimantInteractionsBySources(CLAIMANT_ID, Lists.newArrayList("PAYMENTS", "SALES"), 1);

	}

	@Test
	public void getDebtManagementCompanies(){
		final List<DebtManagementCompanyDto> debtManagementCompanyDtoList = Lists.newArrayList(new DebtManagementCompanyDto());

		final ResponseEntity<String> response = new ResponseEntity<>(serialize(debtManagementCompanyDtoList, true), HttpStatus.OK);

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).getForEntity(String.format("http://test.com:8080/unsecure/debtManagementCompanies"), String.class);
				will(returnValue(response));
			}
		});

		this.claimantServiceWrapper.getDebtManagementCompanies();

	}

	@Test
	public void getIvaCompanies(){
		final List<IvaCompanyDto> ivaCompanyDtos = Lists.newArrayList(new IvaCompanyDto());

		final ResponseEntity<String> response = new ResponseEntity<>(serialize(ivaCompanyDtos, true), HttpStatus.OK);

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).getForEntity(String.format("http://test.com:8080/unsecure/ivaCompanies"), String.class);
				will(returnValue(response));
			}
		});

		this.claimantServiceWrapper.getIvaCompanies();

	}

	@Test
	public void lockClaimantFromDialler(){
		final ResponseEntity<String> response = new ResponseEntity<>("", HttpStatus.OK);

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(String.format("http://test.com:8080/claimant/lockFromDialler/%s/%s", 123,1),null, String.class);
				will(returnValue(response));
			}
		});
		this.claimantServiceWrapper.lockClaimantFromDialler(123,1);
	}


	@Test
	public void unlockClaimantFromDialler(){
		final ResponseEntity<String> response = new ResponseEntity<>("", HttpStatus.OK);

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(String.format("http://test.com:8080/claimant/unlockFromDialler/%s/%s", 123,1),null, String.class);
				will(returnValue(response));
			}
		});
		this.claimantServiceWrapper.unlockClaimantFromDialler(123,1);
	}

	private static ClaimantLockDto newClaimantLockDto(final boolean locked) {
		return new ClaimantLockDto(locked, USER_ID);
	}
	
	private static ClaimantUnlockDto newClaimantUnlockDto() {
		return new ClaimantUnlockDto(USER_ID);
	}
	
	private static ClaimantLockStatusDto newClaimantLockStatusDto(final boolean locked) {
		return new ClaimantLockStatusDto(locked, USER_ID);
	}

	private static ClaimantDto newClaimantDto(){
		return new ClaimantDto(11, 1231, 1, 2, "mr", "matt1", "middle1", "matty1",
				"xxx", "1980-02-21", 0, "123", "234", "5678", "2345",
				"me1@me.com", "JP467431D", false, null, 0, false, null, 0 , null, false,
				null, 0, null, false,
				null, true, null, null, null,
				Lists.newArrayList(), Lists.newArrayList(), Lists.newArrayList(), null, null, 0, null, null,
				null, null, null, null, null, Sets.newHashSet(), null, null);
	}
	
	private static ResponseEntity<String> newResponse(final Object body, final HttpStatus status) {
		return new ResponseEntity<>(JsonUtils.serialize(body, false), status);
	}

	private String getUri(String endpoint){
		return ServiceWrapper.generateUri(this.claimantServiceWrapper.protocol,
											this.claimantServiceWrapper.host,
											this.claimantServiceWrapper.port,
											endpoint);
	}

}
