package com.leadx.claimant.client;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;

@RunWith(SpringJUnit4ClassRunner.class)
@TestExecutionListeners({ DependencyInjectionTestExecutionListener.class, DirtiesContextTestExecutionListener.class })
@ContextConfiguration(locations = { "classpath:/spring/spring-claimant-client.xml" })
public class tempAddressServiceWrapperTest {
	@Autowired
	private AddressServiceWrapper asw;
	
	@Test
	@Ignore
	public void testUpdateAddress() throws Exception {
		//AddressDto addressDto = new AddressDto(43,"aaabc","b","c","d","e","f","g","h","i","j","k","l", "06/12/2012", "");
//		AddressDto addressDto = new AddressDto(45,"new1234","bc","c","d","e","f","g","h","i","j","k","l", "06/10/2014", "");
////		
//		this.asw.updateAddress(1, addressDto, 123, true);
		//this.asw.saveAddress(1, addressDto, true);
//		List<AddressDto> addresses = this.asw.getDeletedPreviousAddresses(1);
////		
//		System.out.println(addresses.get(1).getOrganisationName());
		
		
	}
	
	@Test
	@Ignore
	public void testSaveHouseMove() throws Exception {
//		AddressDto oldAddress = new AddressDto(42,"m","k","j","i","h","g","f","e","d","c","b","a", "06/12/2012");
//		AddressDto newAddress = new AddressDto(0,"n","k","j","i","h","g","f","e","d","c","b","a", "06/12/2012");
////		
//		this.asw.saveHouseMove(1, oldAddress, newAddress);
	}
	
	@Test
	@Ignore
	public void testSavePreviousAddress() throws Exception {
//		AddressDto addressDto = new AddressDto(0,"abc","def","ghi","jkl","mno","pqr","stu","vwx","yza","bcd","efg","hij", "06/12/2012", "");
//		
//		this.asw.savePreviousAddress(1, addressDto);
	}
	
	@Test
	@Ignore
	public void testDeletePreviousAddress() throws Exception {
//		this.asw.deletePreviousAddress(1, 90119);
	}
	
	@Test
	@Ignore
	public void testGetDeletedPreviousAddresses() throws Exception {
//		List<PreviousAddressDto> addresses = this.asw.getDeletedPreviousAddresses(1);
//		
//		for (PreviousAddressDto a : addresses) {
//			System.out.println(a.getAddressDto().getBuildingName());
//		}
	}
	
	@Test
	@Ignore
	public void testGetOrderedPreviousAddressesForClaimant() throws Exception {
//		List<PreviousAddressDto> addresses = this.asw.getOrderedPreviousAddressesForClaimant(12);
//		
//		for (PreviousAddressDto a : addresses) {
//			System.out.println(a.getAddressDto().getId());
//		}
	}
}