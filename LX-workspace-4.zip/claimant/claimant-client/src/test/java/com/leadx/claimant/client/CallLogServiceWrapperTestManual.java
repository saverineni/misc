package com.leadx.claimant.client;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;

import com.leadx.claimant.client.CallDisposition;
import com.leadx.claimant.client.CallLogDto;
import com.leadx.claimant.client.CallLogServiceWrapper;
import com.leadx.claimant.client.CallType;

@RunWith(SpringJUnit4ClassRunner.class)
@TestExecutionListeners({ DependencyInjectionTestExecutionListener.class, DirtiesContextTestExecutionListener.class })
@ContextConfiguration(locations = { "classpath:/spring/spring-claimant-client.xml" })
public class CallLogServiceWrapperTestManual {

	//Manually set these values before running!
	//If they are not unique, the test will fail!
	private static final int CLAIMANT_ID = 4882;
	private static final Integer USER_ID_1 = 24;
	private static final int DIALLER_REFERENCE_1 = 10001;

	@Autowired
	private CallLogServiceWrapper callLogServiceWrapper;

	@Test
	public void testSaveCallLog() throws Exception {
		final CallLogDto logDto = new CallLogDto(CLAIMANT_ID,CallDisposition.ANSWERPHONE.getName(),CallType.ASSESSMENT.getName(),DIALLER_REFERENCE_1, false, USER_ID_1);
		this.callLogServiceWrapper.saveCallLog(logDto);
	}
}