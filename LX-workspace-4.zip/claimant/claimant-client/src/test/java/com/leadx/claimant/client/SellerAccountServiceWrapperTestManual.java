package com.leadx.claimant.client;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;

import com.google.common.collect.ImmutableList;

@RunWith(SpringJUnit4ClassRunner.class)
@TestExecutionListeners({ DependencyInjectionTestExecutionListener.class, DirtiesContextTestExecutionListener.class })
@ContextConfiguration(locations = { "classpath:/spring/spring-claimant-client.xml" })
public class SellerAccountServiceWrapperTestManual {
	private static final int SELLER_ACCOUNT_ID = 9785;

	@Autowired
	private SellerAccountServiceWrapper sellerAccountServiceWrapper;

	@Test
	public void testCreateSellerAccount() {
		final ProductTypeDto selected = new ProductTypeDto(0, "ppi", true);
		final LeadTypeDto leadType = new LeadTypeDto(1, "BAU Web Lead");
		final SellerAccountDto sellerAccountDto = new SellerAccountDto(0,99,"TEST", "Test Name", "Test Display Name", "Test Source", MethodOfContact.telephone, "TEST_LOGO.swf", "test_pack", true, "test_call_reason_group", "testSmsScript", "testEmailScript", "test_email_icon.png", ImmutableList.<String>of(), selected, false, leadType);
		this.sellerAccountServiceWrapper.create(sellerAccountDto);
	}

	@Test
	public void testUpdateSellerAccount() {
		final SellerAccountDto sellerAccountDto = this.sellerAccountServiceWrapper.getById(SELLER_ACCOUNT_ID);

		sellerAccountDto.setName("Updated Seller Name");
		sellerAccountDto.setGpSellerAccount("UPDATED_SELLER");
		sellerAccountDto.setDisplayName("Updated Display Name");
		sellerAccountDto.setSourceDescription("Updated Source Description");
		sellerAccountDto.setApplicationLogo("UPDATED_LOGO.swf");
		sellerAccountDto.setPackType("updated_tcg_pack");
		sellerAccountDto.setDistributeAppointmentReminder(true);
		sellerAccountDto.setAssessmentCallReasonGroup("updated_call_reason_group");
		sellerAccountDto.setAssessmentInitialSmsMessageScript("updatedSmsScript");
		sellerAccountDto.setAssessmentInitialEmailMessageScript("updatedEmailScript");
		sellerAccountDto.setEmailIconImageName("updated_email_icon.png");

		this.sellerAccountServiceWrapper.update(sellerAccountDto);
	}

}
