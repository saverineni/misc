package com.leadx.claimant.client;

import static com.leadx.test.MockUtils.mockAndSetOn;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestOperations;

import com.leadx.lib.utl.json.JsonUtils;

@SuppressWarnings("unqualified-field-access")
public class AddressServiceWrapperUnitTest {
	private AddressServiceWrapper addressServiceWrapper;
	private RestOperations restOperations;

	private final Mockery context = new JUnit4Mockery();

	private static final int CLAIMANT_ID = 123;
	private static final int USER_ID = 345;
	private static final int ADDRESS_ID = 456;
	private static final int PREVIOUS_ADDRESS_ID = 789;


	@Before
	public void setup() {
		this.addressServiceWrapper = new AddressServiceWrapper();
		this.restOperations = mockAndSetOn(this.context, RestOperations.class, this.addressServiceWrapper);

		ReflectionTestUtils.setField(this.addressServiceWrapper, "protocol", "http");
		ReflectionTestUtils.setField(this.addressServiceWrapper, "host", "test.com");
		ReflectionTestUtils.setField(this.addressServiceWrapper, "port", "8080");
	}

	@Test
	public void saveAddress(){
		final AddressDto addressDto = newDummyAddressDto("AB12 3CD");
		final SaveAddressDto saveAddressDto = newDummySaveAddressDto(addressDto, 0);
		final ResponseEntity<Integer> response = new ResponseEntity<>(ADDRESS_ID, HttpStatus.CREATED);
		final String uri = getUri("/address/save");

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(uri, JsonUtils.serialize(saveAddressDto, true), Integer.class);
				will(returnValue(response));
			}
		});

		final int result = this.addressServiceWrapper.saveAddress(CLAIMANT_ID, addressDto, true);
		assertThat(result, is(ADDRESS_ID));
	}

	@Test(expected = RuntimeException.class)
	public void saveAddressInternalServerError(){
		final AddressDto addressDto = newDummyAddressDto("AB12 3CD");
		final SaveAddressDto saveAddressDto = newDummySaveAddressDto(addressDto, 0);
		final ResponseEntity<Integer> response = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		final String uri = getUri("/address/save");

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(uri, JsonUtils.serialize(saveAddressDto, true), Integer.class);
				will(returnValue(response));
			}
		});

		this.addressServiceWrapper.saveAddress(CLAIMANT_ID, addressDto, true);
	}

	@Test
	public void saveAddressInConfinement(){
		final AddressDto addressDto = newDummyAddressDto("AB12 3CD");
		final SaveAddressDto saveAddressDto = newDummySaveAddressDto(addressDto, 0);
		final ResponseEntity<Integer> response = new ResponseEntity<>(ADDRESS_ID, HttpStatus.CREATED);
		final String uri = getUri("/address/confinement/save");

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(uri, JsonUtils.serialize(saveAddressDto, true), Integer.class);
				will(returnValue(response));
			}
		});

		final int result = this.addressServiceWrapper.saveAddressInConfinement(CLAIMANT_ID, addressDto, true);
		assertThat(result, is(ADDRESS_ID));
	}

	@Test(expected = RuntimeException.class)
	public void saveAddressInConfinementInternalServerError(){
		final AddressDto addressDto = newDummyAddressDto("AB12 3CD");
		final SaveAddressDto saveAddressDto = newDummySaveAddressDto(addressDto, 0);
		final ResponseEntity<Integer> response = new ResponseEntity<>(ADDRESS_ID, HttpStatus.INTERNAL_SERVER_ERROR);
		final String uri = getUri("/address/confinement/save");

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(uri, JsonUtils.serialize(saveAddressDto, true), Integer.class);
				will(returnValue(response));
			}
		});

		this.addressServiceWrapper.saveAddressInConfinement(CLAIMANT_ID, addressDto, true);
	}


	@Test
	public void updateAddress(){
		final AddressDto addressDto = newDummyAddressDto("AB12 3CD");
		final SaveAddressDto saveAddressDto = newDummySaveAddressDto(addressDto, USER_ID);
		final ResponseEntity<Integer> response = new ResponseEntity<>(HttpStatus.CREATED);
		final String uri = getUri("/address/update");

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(uri, JsonUtils.serialize(saveAddressDto, true), String.class);
				will(returnValue(response));
			}
		});

		this.addressServiceWrapper.updateAddress(CLAIMANT_ID, addressDto, USER_ID, true);

	}

	@Test(expected = RuntimeException.class)
	public void updateAddressInternalServerError(){
		final AddressDto addressDto = newDummyAddressDto("AB12 3CD");
		final SaveAddressDto saveAddressDto = newDummySaveAddressDto(addressDto, USER_ID);
		final ResponseEntity<Integer> response = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		final String uri = getUri("/address/update");

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(uri, JsonUtils.serialize(saveAddressDto, true), String.class);
				will(returnValue(response));
			}
		});

		this.addressServiceWrapper.updateAddress(CLAIMANT_ID, addressDto, USER_ID, true);

	}

	@Test
	public void updateAddressInConfinement(){
		final AddressDto addressDto = newDummyAddressDto("AB12 3CD");
		final SaveAddressDto saveAddressDto = newDummySaveAddressDto(addressDto, USER_ID);
		final ResponseEntity<Integer> response = new ResponseEntity<>(HttpStatus.CREATED);
		final String uri = getUri("/address/confinement/update");

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(uri, JsonUtils.serialize(saveAddressDto, true), String.class);
				will(returnValue(response));
			}
		});

		this.addressServiceWrapper.updateAddressInConfinement(CLAIMANT_ID, addressDto, USER_ID, true);

	}

	@Test(expected = RuntimeException.class)
	public void updateAddressInConfinementInternalServerError(){
		final AddressDto addressDto = newDummyAddressDto("AB12 3CD");
		final SaveAddressDto saveAddressDto = newDummySaveAddressDto(addressDto, USER_ID);
		final ResponseEntity<Integer> response = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		final String uri = getUri("/address/confinement/update");

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(uri, JsonUtils.serialize(saveAddressDto, true), String.class);
				will(returnValue(response));
			}
		});

		this.addressServiceWrapper.updateAddressInConfinement(CLAIMANT_ID, addressDto, USER_ID, true);

	}

	@Test
	public void savePreviousAddress(){
		final AddressDto addressDto = newDummyAddressDto("AB12 3CD");
		final SavePreviousAddressDto savePreviousAddressDto = newDummySavePreviousAddressDto(addressDto, CLAIMANT_ID);
		final ResponseEntity<Integer> response = new ResponseEntity<>(HttpStatus.CREATED);
		final String uri = getUri("/address/previous/save");

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(uri, JsonUtils.serialize(savePreviousAddressDto, false), String.class);
				will(returnValue(response));
			}
		});

		this.addressServiceWrapper.savePreviousAddress(CLAIMANT_ID, addressDto);
	}

	@Test(expected = RuntimeException.class)
	public void savePreviousAddressInternalServerError(){
		final AddressDto addressDto = newDummyAddressDto("AB12 3CD");
		final SavePreviousAddressDto savePreviousAddressDto = newDummySavePreviousAddressDto(addressDto, CLAIMANT_ID);
		final ResponseEntity<Integer> response = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		final String uri = getUri("/address/previous/save");

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(uri, JsonUtils.serialize(savePreviousAddressDto, false), String.class);
				will(returnValue(response));
			}
		});

		this.addressServiceWrapper.savePreviousAddress(CLAIMANT_ID, addressDto);
	}

	@Test
	public void savePreviousAddressInConfinement(){
		final AddressDto addressDto = newDummyAddressDto("AB12 3CD");
		final SavePreviousAddressDto savePreviousAddressDto = newDummySavePreviousAddressDto(addressDto, CLAIMANT_ID);
		final ResponseEntity<Integer> response = new ResponseEntity<>(HttpStatus.CREATED);
		final String uri = getUri("/address/previous/confinement/save");

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(uri, JsonUtils.serialize(savePreviousAddressDto, false), String.class);
				will(returnValue(response));
			}
		});

		this.addressServiceWrapper.savePreviousAddressInConfinement(CLAIMANT_ID, addressDto);
	}

	@Test(expected = RuntimeException.class)
	public void savePreviousAddressInConfinementInternalServerError(){
		final AddressDto addressDto = newDummyAddressDto("AB12 3CD");
		final SavePreviousAddressDto savePreviousAddressDto = newDummySavePreviousAddressDto(addressDto, CLAIMANT_ID);
		final ResponseEntity<Integer> response = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		final String uri = getUri("/address/previous/confinement/save");

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).postForEntity(uri, JsonUtils.serialize(savePreviousAddressDto, false), String.class);
				will(returnValue(response));
			}
		});

		this.addressServiceWrapper.savePreviousAddressInConfinement(CLAIMANT_ID, addressDto);
	}

	@Test
	public void deletePreviousAddress(){
		final ResponseEntity<Integer> response = new ResponseEntity<>(HttpStatus.OK);
		final String uri = getPreviousAddressDeleteUri("/address/previous/delete", PREVIOUS_ADDRESS_ID, USER_ID);

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).getForEntity(uri, String.class);
				will(returnValue(response));
			}
		});

		this.addressServiceWrapper.deletePreviousAddress(PREVIOUS_ADDRESS_ID, USER_ID);
	}

	@Test(expected = RuntimeException.class)
	public void deletePreviousAddressInternalServerError(){
		final ResponseEntity<Integer> response = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		final String uri = getPreviousAddressDeleteUri("/address/previous/delete", PREVIOUS_ADDRESS_ID, USER_ID);

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).getForEntity(uri, String.class);
				will(returnValue(response));
			}
		});

		this.addressServiceWrapper.deletePreviousAddress(PREVIOUS_ADDRESS_ID, USER_ID);
	}

	@Test
	public void deletePreviousAddressInConfinement(){
		final ResponseEntity<Integer> response = new ResponseEntity<>(HttpStatus.OK);
		final String uri = getPreviousAddressDeleteUri("/address/previous/confinement/delete", PREVIOUS_ADDRESS_ID, USER_ID);

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).getForEntity(uri, String.class);
				will(returnValue(response));
			}
		});

		this.addressServiceWrapper.deletePreviousAddressInConfinement(PREVIOUS_ADDRESS_ID, USER_ID);
	}

	@Test(expected = RuntimeException.class)
	public void deletePreviousAddressInternalServerErrorInConfinement(){
		final ResponseEntity<Integer> response = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		final String uri = getPreviousAddressDeleteUri("/address/previous/confinement/delete", PREVIOUS_ADDRESS_ID, USER_ID);

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).getForEntity(uri, String.class);
				will(returnValue(response));
			}
		});

		this.addressServiceWrapper.deletePreviousAddressInConfinement(PREVIOUS_ADDRESS_ID, USER_ID);
	}

	private static AddressDto newDummyAddressDto(final String postcode) {
		return new AddressDto(ADDRESS_ID, "a", "1", "b", "2", "c", "d", "e", "f", "g", "h", postcode, "a", null, null);
	}

	private static SaveAddressDto newDummySaveAddressDto(final AddressDto addressDto, final int userId) {
		return new SaveAddressDto(CLAIMANT_ID, addressDto, userId, true);
	}

	private static SavePreviousAddressDto newDummySavePreviousAddressDto(final AddressDto addressDto, final int claimantId) {
		SavePreviousAddressDto savePreviousAddressDto = new SavePreviousAddressDto();
		savePreviousAddressDto.setCurrentAddressId(addressDto.getId());
		savePreviousAddressDto.setClaimantId(claimantId);
		savePreviousAddressDto.setNewAddress(addressDto);

		return savePreviousAddressDto;
	}

	private String getUri(String endpoint){
		return ServiceWrapper.generateUri(this.addressServiceWrapper.protocol,
				this.addressServiceWrapper.host,
				this.addressServiceWrapper.port,
				endpoint);
	}

	private String getPreviousAddressDeleteUri(String endpoint, int previousAddressId, int userId){
		return ServiceWrapper.generateUri(this.addressServiceWrapper.protocol,
				this.addressServiceWrapper.host,
				this.addressServiceWrapper.port,
				"%s/%s/%s", endpoint, previousAddressId, userId);
	}
}
