package com.leadx.claimant.client;

import static com.leadx.test.MockUtils.mockAndSetOn;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.concurrent.Synchroniser;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestOperations;

public class SellerAccountServiceWrapperUnitTest {

	private SellerAccountServiceWrapper sellerAccountServiceWrapper;
	private RestOperations restOperations;
	private final Synchroniser synchroniser = new Synchroniser();

	private static final String SELLER_ACCT_FREE_PPI_URL = "http://test.com:8080/selleraccount/isFreePpi/%s";
	private static final int SELLER_ACCOUNT = 1234;

	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
			setThreadingPolicy(synchroniser);
		}
	};

	@Before
	public void setup() {
		this.sellerAccountServiceWrapper = new SellerAccountServiceWrapper();
		this.restOperations = mockAndSetOn(this.context, RestOperations.class, this.sellerAccountServiceWrapper);
		ReflectionTestUtils.setField(this.sellerAccountServiceWrapper, "protocol", "http");
		ReflectionTestUtils.setField(this.sellerAccountServiceWrapper, "host", "test.com");
		ReflectionTestUtils.setField(this.sellerAccountServiceWrapper, "port", "8080");
	}

	@Test
	public void isFreePpi(){
		final ResponseEntity<Boolean> response = new ResponseEntity<>(false, HttpStatus.OK);

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).getForEntity(String.format(SELLER_ACCT_FREE_PPI_URL, SELLER_ACCOUNT), Boolean.class);
				will(returnValue(response));
			}
		});

		this.sellerAccountServiceWrapper.isFreePpi(SELLER_ACCOUNT);
	}


	@Test(expected = RuntimeException.class)
	public void isFreePpiFailure(){
		final ResponseEntity<Boolean> response = new ResponseEntity<>(false, HttpStatus.BAD_REQUEST);

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).getForEntity(String.format(SELLER_ACCT_FREE_PPI_URL, SELLER_ACCOUNT), Boolean.class);
				will(returnValue(response));
			}
		});

		this.sellerAccountServiceWrapper.isFreePpi(SELLER_ACCOUNT);
	}
}
