package com.leadx.claimant.client;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.leadx.lib.utl.JodaUtils;

@JsonAutoDetect
public class CallLogDto {

	private int claimantId;
	private String callType;
	private String callDisposition;
	private int agentUserId;
	private int diallerReferenceId;
	private String dispositionDateTime;
	private boolean inbound;
	private String callDuration;

	public CallLogDto(){}

	/**
	 *
	 * @param claimantId
	 * @param disposition
	 * @param callType
	 * @param diallerRefId
	 * @param inbound
	 * @param userId
	 */
	public CallLogDto(final int claimantId, final String disposition, final String callType, final int diallerRefId, final boolean inbound, final int userId) {
		this.claimantId = claimantId;
		this.callDisposition= disposition;
		this.callType = callType;
		this.diallerReferenceId = diallerRefId;
		this.agentUserId = userId;
		this.dispositionDateTime = JodaUtils.localDateTimeToBritishDateFormatOrNull(JodaUtils.newCurrentDateTime());
		this.inbound = inbound;
		this.callDuration = null;
	}

	public int getClaimantId() {
		return this.claimantId;
	}

	public void setClaimantId(int claimantId) {
		this.claimantId = claimantId;
	}

	public String getCallType() {
		return this.callType;
	}

	public void setCallType(String callType) {
		this.callType = callType;
	}

	public String getCallDisposition() {
		return this.callDisposition;
	}

	public void setCallDisposition(String callDisposition) {
		this.callDisposition = callDisposition;
	}

	public int getAgentUserId() {
		return this.agentUserId;
	}

	public void setAgentUserId(int agentUserId) {
		this.agentUserId = agentUserId;
	}

	public int getDiallerReferenceId() {
		return this.diallerReferenceId;
	}

	public void setDiallerReferenceId(int diallerReferenceId) {
		this.diallerReferenceId = diallerReferenceId;
	}

	public String getDispositionDateTime() {
		return this.dispositionDateTime;
	}

	public void setDispositionDateTime(String dispositionDateTime) {
		this.dispositionDateTime = dispositionDateTime;
	}

	public boolean getInbound() {
		return this.inbound;
	}

	public void setInbound(boolean inbound) {
		this.inbound = inbound;
	}

	public String getCallDuration() {
		return this.callDuration;
	}

	public void setCallDuration(String callDuration) {
		this.callDuration = callDuration;
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public boolean equals(final Object obj) {
		return deepEquals(obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	public boolean deepEquals(final Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}
}
