package com.leadx.claimant.client;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.leadx.claimant.client.annotations.Retryable;
import com.leadx.lib.utl.json.JsonUtils;

@Component
public class AddressServiceWrapper extends ServiceWrapper {
	private static final Logger LOG = LoggerFactory.getLogger(AddressServiceWrapper.class);

	@Retryable
	public AddressDto getAddressById(final int addressId) {
		final ResponseEntity<String> response = 
				this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/address/id/%s", addressId), String.class);
		
		if (response.getStatusCode() == HttpStatus.OK) {
			return response.getBody() != null ? JsonUtils.deserialize(response.getBody(), AddressDto.class) : null;
		}
		
		LOG.error("Failed to get address id {}, http error {}", addressId, response.getStatusCode());
		throw new RuntimeException("" + response.getStatusCode());
	}

	@Retryable
	public Collection<AddressDto> getAddressesByIds(final Collection<Integer> addressIds) {
		if ( addressIds.size() == 0 ) {
			return ImmutableList.of();
		}

		final ResponseEntity<String> response =
			this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/address/ids/%s",  StringUtils.join(addressIds.toArray(), ",")), String.class);

		if (response.getStatusCode() == HttpStatus.OK) {
			return addressDtosFromResponse(response);
		}

		LOG.error("Failed to get address ids {}, http error {}", addressIds, response.getStatusCode());
		throw new RuntimeException("" + response.getStatusCode());
	}

	@Retryable
	public int saveAddress(final int claimantId, final AddressDto addressDto, final boolean markPafValidated) {
		final SaveAddressDto newAddressDto = new SaveAddressDto(claimantId, addressDto, 0, markPafValidated);
		
		final ResponseEntity<Integer> response = 
				this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "%s", "/address/save"), JsonUtils.serialize(newAddressDto, true), Integer.class);
		
		if (response.getStatusCode() != HttpStatus.CREATED) {
			LOG.error("Failed to save address for claimant id {}, markAsPafValidated {}, address {}, http error {}", claimantId, markPafValidated, addressDto, response.getStatusCode());
			throw new RuntimeException("Failed to save address: " + response.getStatusCode());
		}
		
		return response.getBody();
	}

	@Retryable
	public int saveAddress(final AddressDto addressDto) {
		final ResponseEntity<Integer> response =
				this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "%s", "/address/save"), JsonUtils.serialize(addressDto, true), Integer.class);

		if (response.getStatusCode() != HttpStatus.CREATED) {
			LOG.error("Failed to save address {}, http error {}", addressDto, response.getStatusCode());
			throw new RuntimeException("Failed to save address: " + response.getStatusCode());
		}

		return response.getBody();
	}

	@Retryable
	public int saveAddressInConfinement(final int claimantId, final AddressDto addressDto, final boolean markPafValidated) {
		final SaveAddressDto newAddressDto = new SaveAddressDto(claimantId, addressDto, 0, markPafValidated);

		final ResponseEntity<Integer> response =
				this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "%s", "/address/confinement/save"), JsonUtils.serialize(newAddressDto, true), Integer.class);

		if (response.getStatusCode() != HttpStatus.CREATED) {
			LOG.error("Failed to save address for claimant id {}, markAsPafValidated {}, address {}, http error {}", claimantId, markPafValidated, addressDto, response.getStatusCode());
			throw new RuntimeException("Failed to save address: " + response.getStatusCode());
		}

		return response.getBody();
	}

	@Retryable
	public void updateAddress(final int claimantId, final AddressDto addressDto, final int userId, final boolean markPafValidated) {
		final SaveAddressDto updatedAddressDto = new SaveAddressDto(claimantId, addressDto, userId, markPafValidated);
		
		final ResponseEntity<String> response = 
				this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "%s", "/address/update"), JsonUtils.serialize(updatedAddressDto, true), String.class);

		if(response.getStatusCode() != HttpStatus.CREATED) {
			LOG.error("Failed to update address for claimant id {}, markAsPafValidated {}, userId {}, address {}, http error {}", claimantId, markPafValidated, userId, addressDto, response.getStatusCode());
			throw new RuntimeException("Failed to update address: " + response.getStatusCode());
		}
	}

	@Retryable
	public void updateAddressInConfinement(final int claimantId, final AddressDto addressDto, final int userId, final boolean markPafValidated) {
		final SaveAddressDto updatedAddressDto = new SaveAddressDto(claimantId, addressDto, userId, markPafValidated);

		final ResponseEntity<String> response =
				this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "%s", "/address/confinement/update"), JsonUtils.serialize(updatedAddressDto, true), String.class);

		if(response.getStatusCode() != HttpStatus.CREATED) {
			LOG.error("Failed to update address for claimant id {}, markAsPafValidated {}, userId {}, address {}, http error {}", claimantId, markPafValidated, userId, addressDto, response.getStatusCode());
			throw new RuntimeException("Failed to update address: " + response.getStatusCode());
		}
	}

	@Retryable
	public AddressDto getAddressForClaimant(final int claimantId) {
		final ResponseEntity<String> response =
				this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/address/claimant/%s", claimantId), String.class);
		
		if (response.getStatusCode() == HttpStatus.OK) {
			return response.getBody() != null ? JsonUtils.deserialize(response.getBody(), AddressDto.class) : null;
		}
		
		LOG.error("Failed to get address for claimant id {}", claimantId);
		throw new RuntimeException("Failed to load address for claimant: " + response.getStatusCode());
	}

	@Retryable
	public List<AddressDto> getAllAddressesForClaimant(final int claimantId) {
		final ResponseEntity<String> response =
				this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/address/claimant/%s/all", claimantId), String.class);
		
		if (response.getStatusCode() == HttpStatus.OK) {
			return addressDtosFromResponse(response);
		}
		
		LOG.warn("Failed to get all addresses for claimant id {}", claimantId);
		throw new RuntimeException("Failed to load all addresses for claimant: " + response.getStatusCode());
	}

	@Retryable
	public List<PreviousAddressDto> getPreviousAddresses(final int claimantId) {
		final ResponseEntity<String> response =
				this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/address/previous/claimant/%s", claimantId), String.class);
		
		if (response.getStatusCode() == HttpStatus.OK) {
			return previousAddressDtosFromResponse(response);
		}
		
		LOG.warn("Failed to get previous addresses for claimant id {}", claimantId);
		throw new RuntimeException("Failed to load previous addresses: " + response.getStatusCode());
	}

	@Retryable
	public List<PreviousAddressDto> getOrderedPreviousAddressesForClaimant(final int claimantId) {
		final ResponseEntity<String> response =
				this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/address/previous/ordered/claimant/%s", claimantId), String.class);
		
		if (response.getStatusCode() == HttpStatus.OK) {
			return previousAddressDtosFromResponse(response);
		}
		
		LOG.error("Failed to get ordered previous addresses for claimant id {}", claimantId);
		throw new RuntimeException("Failed to load ordered previous addresses: " + response.getStatusCode());
	}

	@Retryable
	public List<PreviousAddressDto> getDeletedPreviousAddresses(final int claimantId) {
		final ResponseEntity<String> response =
				this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/address/previous/deleted/claimant/%s", claimantId), String.class);
		
		if (response.getStatusCode() == HttpStatus.OK) {
			return previousAddressDtosFromResponse(response);
		}
		
		LOG.error("Failed to get deleted previous addresses for claimant id {}", claimantId);
		throw new RuntimeException("Failed to load previous deleted addresses: " + response.getStatusCode());
	}

	@Retryable
	public void savePreviousAddress(final int claimantId, final AddressDto addressDto) {
		final SavePreviousAddressDto addressServiceDto = new SavePreviousAddressDto();
		addressServiceDto.setCurrentAddressId(addressDto.getId());
		addressServiceDto.setClaimantId(claimantId);
		addressServiceDto.setNewAddress(addressDto);
		
		final ResponseEntity<String> response =
				this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "%s", "/address/previous/save"), JsonUtils.serialize(addressServiceDto, false), String.class);
		
		if (response.getStatusCode() != HttpStatus.CREATED) {
			LOG.error("Failed to save previous address for claimant id {}, address {}", claimantId, addressDto);
			throw new RuntimeException("Failed to save previous address: " + response.getStatusCode());
		}
	}

	@Retryable
	public void savePreviousAddressInConfinement(final int claimantId, final AddressDto addressDto) {
		final SavePreviousAddressDto addressServiceDto = new SavePreviousAddressDto();
		addressServiceDto.setCurrentAddressId(addressDto.getId());
		addressServiceDto.setClaimantId(claimantId);
		addressServiceDto.setNewAddress(addressDto);

		final ResponseEntity<String> response =
				this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "%s", "/address/previous/confinement/save"), JsonUtils.serialize(addressServiceDto, false), String.class);

		if (response.getStatusCode() != HttpStatus.CREATED) {
			LOG.error("Failed to save previous address for claimant id {}, address {}", claimantId, addressDto);
			throw new RuntimeException("Failed to save previous address: " + response.getStatusCode());
		}
	}
	
	@Retryable
	public void savePreviousAddresses(final int claimantId, final int userId, final List<AddressDto> addressDtos) {
		final List<SavePreviousAddressDto> previousAddressDtos = Lists.newArrayList();
		
		for (final AddressDto addressDto : addressDtos) {
			previousAddressDtos.add(savePreviousAddressFromAddress(claimantId, userId, addressDto));
		}
		
		final ResponseEntity<String> response =
				this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "%s", "/address/previous/save/all"), JsonUtils.serialize(previousAddressDtos, false), String.class);
		
		if (response.getStatusCode() != HttpStatus.CREATED) {
			LOG.error("Failed to save previous addresses for claimant id {}", claimantId);
			throw new RuntimeException("Failed to save previous addresses: " + response.getStatusCode());
		}
	}

	@Retryable
	public void deletePreviousAddress(final int previousAddressId, final int userId) {
		final ResponseEntity<String> response =
				this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "%s/%s/%s", "/address/previous/delete", previousAddressId, userId), String.class);
		
		if (response.getStatusCode() != HttpStatus.OK) {
			LOG.error("Failed to delete previous address for previous address id {}, user id {}", previousAddressId, userId);
			throw new RuntimeException("Failed to delete previous address: " + response.getStatusCode());
		}
	}

	@Retryable
	public void deletePreviousAddressInConfinement(final int previousAddressId, final int userId) {
		final ResponseEntity<String> response =
				this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "%s/%s/%s", "/address/previous/confinement/delete", previousAddressId, userId), String.class);

		if (response.getStatusCode() != HttpStatus.OK) {
			LOG.error("Failed to delete previous address for previous address id {}, user id {}", previousAddressId, userId);
			throw new RuntimeException("Failed to delete previous address: " + response.getStatusCode());
		}
	}

	@Retryable
	public void saveHouseMove(final int claimantId, final AddressDto oldAddress, final AddressDto newAddress) {
		final SavePreviousAddressDto savePreviousAddressDto = new SavePreviousAddressDto();
		savePreviousAddressDto.setCurrentAddressId(oldAddress.getId());
		savePreviousAddressDto.setNewAddress(newAddress);
		savePreviousAddressDto.setClaimantId(claimantId);
		
		final ResponseEntity<String> response = 
				this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "%s", "/address/houseMove"), JsonUtils.serialize(savePreviousAddressDto, false), String.class);
		
		if (response.getStatusCode() != HttpStatus.CREATED) {
			LOG.error("Failed to save house move for claimant id {}, old address {}, new address {}", claimantId, oldAddress.toString(), newAddress.toString());
			throw new RuntimeException("Failed to save house move: " + response.getStatusCode());
		}
	}

	@Retryable
	public AddressServiceDto getAllAddressDetails(final int claimantId) {
		final ResponseEntity<String> response = 
				this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/address/all/%s", claimantId), String.class);
		
		if(response.getStatusCode() == HttpStatus.OK) {
			return JsonUtils.deserialize(response.getBody(), AddressServiceDto.class);
		}
		
		LOG.error("Failed to load address details for claimant id {}", claimantId);
		throw new RuntimeException("Failed to load address details: " + response.getStatusCode());
	}

	@Retryable
	private static List<AddressDto> addressDtosFromResponse(final ResponseEntity<String> response) {
		final ObjectMapper mapper = new ObjectMapper();
		
		try {
			return mapper.readValue(response.getBody(), new TypeReference<List<AddressDto>>() { });
		}
		catch (final IOException e) {
			LOG.error("Failed to map to AddressDto object from response: " + response.getBody());
			throw new RuntimeException("Failed map to AddressDto object: " + response.getStatusCode());
		}
	}

	private static List<PreviousAddressDto> previousAddressDtosFromResponse(final ResponseEntity<String> response) {
		final ObjectMapper mapper = new ObjectMapper();
		
		try {
			return mapper.readValue(response.getBody(), new TypeReference<List<PreviousAddressDto>>() { });
		}
		catch (final IOException e) {
			LOG.error("Failed to map to PreviousAddressDto object from response: " + response.getBody());
			throw new RuntimeException("Failed map to PreviousAddressDto object: " + response.getStatusCode());
		}
	}
	
	private static SavePreviousAddressDto savePreviousAddressFromAddress(final int claimantId, final int userId, final AddressDto addressDto) {
		final SavePreviousAddressDto savePreviousAddressDto = new SavePreviousAddressDto();
		savePreviousAddressDto.setClaimantId(claimantId);
		savePreviousAddressDto.setUserId(userId);
		savePreviousAddressDto.setCurrentAddressId(0);
		savePreviousAddressDto.setPreviousAddressId(addressDto.getId());
		savePreviousAddressDto.setNewAddress(addressDto);
		
		return savePreviousAddressDto;
	}
}
