package com.leadx.claimant.client;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class ClaimantExecutorDto {

	private Integer id;
	private Integer claimantId;
	private String title;
	private String forename;
	private String middleName;
	private String surname;
	private String previousSurname;
	private String dob;
	private int addressId;
	private String homeTelephone;
	private String mobileTelephone;
	private String email;
	private String executorUpdateDateTime;
	private boolean isExecutorConfirmed;
	private String executorConfirmedUpdateDateTime;
	private String createdDateTime;
	private String timestamp;
	private boolean isDeleted;
	private int version;


	public ClaimantExecutorDto() {

	}

	public ClaimantExecutorDto(final Integer id, final Integer claimantId, final String title, final String forename, final String middleName,
							   final String surname, final String previousSurname, final String dob, final int addressId, final String homeTelephone,
							   final String mobileTelephone, final String email, final String executorUpdateDateTime, final boolean isExecutorConfirmed,
							   final String executorConfirmedUpdateDateTime, final String createdDateTime, final String timestamp, final boolean isDeleted,
	                           final int version) {

		this.id = id;
		this.claimantId = claimantId;
		this.title = title;
		this.forename = forename;
		this.middleName = middleName;
		this.surname = surname;
		this.previousSurname = previousSurname;
		this.dob = dob;
		this.addressId = addressId;
		this.homeTelephone = homeTelephone;
		this.mobileTelephone = mobileTelephone;
		this.email = email;
		this.executorUpdateDateTime = executorUpdateDateTime;
		this.isExecutorConfirmed = isExecutorConfirmed;
		this.executorConfirmedUpdateDateTime = executorConfirmedUpdateDateTime;
		this.createdDateTime = createdDateTime;
		this.timestamp = timestamp;
		this.isDeleted = isDeleted;
		this.version = version;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getClaimantId() {
		return claimantId;
	}

	public void setClaimantId(Integer claimantId) {
		this.claimantId = claimantId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getForename() {
		return forename;
	}

	public void setForename(String forename) {
		this.forename = forename;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getPreviousSurname() {
		return previousSurname;
	}

	public void setPreviousSurname(String previousSurname) {
		this.previousSurname = previousSurname;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getHomeTelephone() {
		return homeTelephone;
	}

	public void setHomeTelephone(String homeTelephone) {
		this.homeTelephone = homeTelephone;
	}

	public String getMobileTelephone() {
		return mobileTelephone;
	}

	public void setMobileTelephone(String mobileTelephone) {
		this.mobileTelephone = mobileTelephone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getExecutorUpdateDateTime() {
		return executorUpdateDateTime;
	}

	public void setExecutorUpdateDateTime(String executorUpdateDateTime) {
		this.executorUpdateDateTime = executorUpdateDateTime;
	}

	public boolean getIsExecutorConfirmed() {
		return isExecutorConfirmed;
	}

	public void setIsExecutorConfirmed(boolean executorConfirmed) {
		isExecutorConfirmed = executorConfirmed;
	}

	public String getExecutorConfirmedUpdateDateTime() {
		return executorConfirmedUpdateDateTime;
	}

	public void setExecutorConfirmedUpdateDateTime(String executorConfirmedUpdateDateTime) {
		this.executorConfirmedUpdateDateTime = executorConfirmedUpdateDateTime;
	}

	public String getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(String createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	@Override
	public boolean equals(final Object obj) {
		return EqualsBuilder.reflectionEquals(obj, this);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
