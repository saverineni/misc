package com.leadx.claimant.client;

import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class SellerAccountDto {

	private Integer id;
	private Integer accountId;
	private String gpSellerAccount;
	private String name;
	private String displayName;
	private String sourceDescription;
	private MethodOfContact methodOfContact;
	private String applicationLogo;
	private String packType;
	private boolean distributeAppointmentReminder;
	private String assessmentCallReasonGroup;
	private String assessmentInitialSmsMessageScript;
	private String assessmentInitialEmailMessageScript;
	private String emailIconImageName;
	private List<String> inboundNumbers;
	private ProductTypeDto productType;
	private boolean freePpi;
	private LeadTypeDto leadType;

	public SellerAccountDto() {}

	public SellerAccountDto(final int accountId, final String gpSellerAccount, final String name, final String displayName, final String sourceDescription,
			final MethodOfContact methodOfContact,
			final String applicationLogo, final String packType, final Boolean distributeAppointmentReminder, final String assessmentCallReasonGroup,
			final String assessmentInitialSmsMessageScript, final String assessmentInitialEmailMessageScript, final String emailIconImageName,
			final List<String> inboundNumbers, final ProductTypeDto productType, final boolean freePpi, final LeadTypeDto leadType) {

		this(0, accountId, gpSellerAccount, name, displayName, sourceDescription, methodOfContact, applicationLogo, packType, distributeAppointmentReminder,
			assessmentCallReasonGroup, assessmentInitialSmsMessageScript,assessmentInitialEmailMessageScript, emailIconImageName, inboundNumbers, productType, freePpi, leadType);
	}

	public SellerAccountDto(final int id, final int accountId, final String gpSellerAccount, final String name, final String displayName, final String sourceDescription,
							MethodOfContact methodOfContact, final String applicationLogo, final String packType, final Boolean distributeAppointmentReminder, final String assessmentCallReasonGroup,
							final String assessmentInitialSmsMessageScript, final String assessmentInitialEmailMessageScript, final String emailIconImageName,
							final List<String> inboundNumbers, final ProductTypeDto productType, boolean freePpi, final LeadTypeDto leadType) {
		this.id = id;
		this.accountId = accountId;
		this.gpSellerAccount = gpSellerAccount;
		this.name = name;
		this.displayName = displayName;
		this.sourceDescription = sourceDescription;
		this.methodOfContact = methodOfContact;
		this.applicationLogo = applicationLogo;
		this.packType = packType;
		this.distributeAppointmentReminder = distributeAppointmentReminder;
		this.assessmentCallReasonGroup = assessmentCallReasonGroup;
		this.assessmentInitialSmsMessageScript = assessmentInitialSmsMessageScript;
		this.assessmentInitialEmailMessageScript = assessmentInitialEmailMessageScript;
		this.emailIconImageName = emailIconImageName;
		this.inboundNumbers = inboundNumbers;
		this.productType = productType;
		this.freePpi = freePpi;
		this.leadType = leadType;
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(final Integer id) {
		this.id = id;
	}

	public Integer getAccountId() {
		return this.accountId;
	}

	public void setAccountId(final Integer id) {
		this.accountId = id;
	}

	public String getGpSellerAccount() {
		return this.gpSellerAccount;
	}

	public void setGpSellerAccount(final String gpSellerAccount) {
		this.gpSellerAccount = gpSellerAccount;
	}

	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public String getDisplayName() {
		return this.displayName;
	}

	public void setDisplayName(final String displayName) {
		this.displayName = displayName;
	}

	public String getSourceDescription() {
		return this.sourceDescription;
	}

	public void setSourceDescription(final String sourceDescription) {
		this.sourceDescription = sourceDescription;
	}

	public String getApplicationLogo() {
		return this.applicationLogo;
	}

	public void setApplicationLogo(final String applicationLogo) {
		this.applicationLogo = applicationLogo;
	}

	public String getPackType() {
		return this.packType;
	}

	public void setPackType(final String packType) {
		this.packType = packType;
	}

	public boolean getDistributeAppointmentReminder() {
		return this.distributeAppointmentReminder;
	}

	public void setDistributeAppointmentReminder(final boolean distributeAppointmentReminder) {
		this.distributeAppointmentReminder = distributeAppointmentReminder;
	}

	public String getAssessmentCallReasonGroup() {
		return this.assessmentCallReasonGroup;
	}

	public void setAssessmentCallReasonGroup(final String assessmentCallReasonGroup) {
		this.assessmentCallReasonGroup = assessmentCallReasonGroup;
	}

	public String getAssessmentInitialSmsMessageScript() {
		return this.assessmentInitialSmsMessageScript;
	}

	public void setAssessmentInitialSmsMessageScript(final String assessmentInitialSmsMessageScript) {
		this.assessmentInitialSmsMessageScript = assessmentInitialSmsMessageScript;
	}

	public String getAssessmentInitialEmailMessageScript() {
		return this.assessmentInitialEmailMessageScript;
	}

	public void setAssessmentInitialEmailMessageScript(final String assessmentInitialEmailMessageScript) {
		this.assessmentInitialEmailMessageScript = assessmentInitialEmailMessageScript;
	}

	public String getEmailIconImageName() {
		return this.emailIconImageName;
	}

	public void setEmailIconImageName(final String emailIconImageName) {
		this.emailIconImageName = emailIconImageName;
	}

	public List<String> getInboundNumbers() {
		return this.inboundNumbers;
	}

	public void setInboundNumbers(final List<String> inboundNumbers) {
		this.inboundNumbers = inboundNumbers;
	}

	public ProductTypeDto getProductType() {
		return this.productType;
	}

	public void setProductType(final ProductTypeDto productType) {
		this.productType = productType;
	}

	public boolean getFreePpi() {
		return this.freePpi;
	}

	public void setFreePpi(boolean freePpi) {
		this.freePpi = freePpi;
	}

	public LeadTypeDto getLeadType() {
		return leadType;
	}

	public void setLeadType(LeadTypeDto leadType) {
		this.leadType = leadType;
	}

	public MethodOfContact getMethodOfContact() {
		return this.methodOfContact;
	}

	public void setMethodOfContact(MethodOfContact methodOfContact) {
		this.methodOfContact = methodOfContact;
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public boolean equals(final Object obj) {
		return deepEquals(obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	public boolean deepEquals(final Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}
}
