package com.leadx.claimant.client;


public class SellerAccountUpdateDto {
	private String column;
	private String existingValue;
	private String newDropdownValue;

	public SellerAccountUpdateDto (final String column, final String existingValue, final String newDropdownValue) {
		this.column = column;
		this.existingValue = existingValue;
		this.newDropdownValue = newDropdownValue;
	}

	public String getColumn() {
		return this.column;
	}

	public String getExistingValue() {
		return this.existingValue;
	}

	public String getNewDropdownValue() {
		return this.newDropdownValue;
	}
}