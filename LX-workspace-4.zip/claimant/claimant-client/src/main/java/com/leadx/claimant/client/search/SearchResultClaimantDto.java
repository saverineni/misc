package com.leadx.claimant.client.search;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class SearchResultClaimantDto implements Serializable {

	private static final long serialVersionUID = -934538945823989L;

	private int claimantId;
	private String name;
	private String forename;
	private String surname;
	private String postcode;
	private String homeTelephone;
	private String mobileTelephone;
	private String dateOfBirth;
	private String email;
	private boolean hasPpiClaimsWithOpenBalance;
	private boolean hasPbaClaimsWithOpenBalance;
	private boolean hasStlClaimsWithOpenBalance;

	public static class Builder {

		private int claimantId;
		private String name;
		private String forename;
		private String surname;
		private String postcode;
		private String homeTelephone;
		private String mobileTelephone;
		private String dateOfBirth;
		private String email;
		private boolean hasPpiClaimsWithOpenBalance;
		private boolean hasPbaClaimsWithOpenBalance;
		private boolean hasStlClaimsWithOpenBalance;

		public Builder setClaimantId(int claimantId) {
			this.claimantId = claimantId;
			return this;
		}

		public Builder setName(String name) {
			this.name = name;
			return this;
		}

		public Builder setForename(String forename) {
			this.forename = forename;
			return this;
		}

		public Builder setSurname(String surname) {
			this.surname = surname;
			return this;
		}

		public Builder setPostcode(String postcode) {
			this.postcode = postcode;
			return this;
		}

		public Builder setHomeTelephone(String homeTelephone) {
			this.homeTelephone = homeTelephone;
			return this;
		}

		public Builder setMobileTelephone(String mobileTelephone) {
			this.mobileTelephone = mobileTelephone;
			return this;
		}

		public Builder setDateOfBirth(String dateOfBirth) {
			this.dateOfBirth = dateOfBirth;
			return this;
		}

		public Builder setEmail(String email) {
			this.email = email;
			return this;
		}

		public Builder setHasPpiClaimsWithOpenBalance(boolean hasPpiClaimsWithOpenBalance) {
			this.hasPpiClaimsWithOpenBalance = hasPpiClaimsWithOpenBalance;
			return this;
		}

		public Builder setHasPbaClaimsWithOpenBalance(boolean hasPbaClaimsWithOpenBalance) {
			this.hasPbaClaimsWithOpenBalance = hasPbaClaimsWithOpenBalance;
			return this;
		}

		public Builder setHasStlClaimsWithOpenBalance(boolean hasStlClaimsWithOpenBalance) {
			this.hasStlClaimsWithOpenBalance = hasStlClaimsWithOpenBalance;
			return this;
		}

		public SearchResultClaimantDto createSearchResultClaimantDto() {
			return new SearchResultClaimantDto(claimantId, name, forename, surname, postcode, homeTelephone, mobileTelephone, dateOfBirth, email,
					hasPpiClaimsWithOpenBalance, hasPbaClaimsWithOpenBalance, hasStlClaimsWithOpenBalance);
		}
	}

	public SearchResultClaimantDto() {
	}

	public SearchResultClaimantDto(int claimantId, String name, String forename, String surname, String postcode, String homeTelephone, String mobileTelephone,
			String dateOfBirth, String email, boolean hasPpiClaimsWithOpenBalance, boolean hasPbaClaimsWithOpenBalance, boolean hasStlClaimsWithOpenBalance) {
		this.claimantId = claimantId;
		this.name = name;
		this.forename = forename;
		this.surname = surname;
		this.postcode = postcode;
		this.homeTelephone = homeTelephone;
		this.mobileTelephone = mobileTelephone;
		this.dateOfBirth = dateOfBirth;
		this.email = email;
		this.hasPpiClaimsWithOpenBalance = hasPpiClaimsWithOpenBalance;
		this.hasPbaClaimsWithOpenBalance = hasPbaClaimsWithOpenBalance;
		this.hasStlClaimsWithOpenBalance = hasStlClaimsWithOpenBalance;
	}

	@Override
	public boolean equals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	public int getClaimantId() {
		return claimantId;
	}

	public void setClaimantId(int claimantId) {
		this.claimantId = claimantId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getForename() {
		return forename;
	}

	public void setForename(String forename) {
		this.forename = forename;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getHomeTelephone() {
		return homeTelephone;
	}

	public void setHomeTelephone(String homeTelephone) {
		this.homeTelephone = homeTelephone;
	}

	public String getMobileTelephone() {
		return mobileTelephone;
	}

	public void setMobileTelephone(String mobileTelephone) {
		this.mobileTelephone = mobileTelephone;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isHasPpiClaimsWithOpenBalance() {
		return hasPpiClaimsWithOpenBalance;
	}

	public void setHasPpiClaimsWithOpenBalance(boolean hasPpiClaimsWithOpenBalance) {
		this.hasPpiClaimsWithOpenBalance = hasPpiClaimsWithOpenBalance;
	}

	public boolean isHasPbaClaimsWithOpenBalance() {
		return hasPbaClaimsWithOpenBalance;
	}

	public void setHasPbaClaimsWithOpenBalance(boolean hasPbaClaimsWithOpenBalance) {
		this.hasPbaClaimsWithOpenBalance = hasPbaClaimsWithOpenBalance;
	}

	public boolean isHasStlClaimsWithOpenBalance() {
		return hasStlClaimsWithOpenBalance;
	}

	public void setHasStlClaimsWithOpenBalance(boolean hasStlClaimsWithOpenBalance) {
		this.hasStlClaimsWithOpenBalance = hasStlClaimsWithOpenBalance;
	}
}
