package com.leadx.claimant.client.reference;

public class DmIvaCompanyDto {

	protected Integer id;
	protected String name;
	protected String departmentName;
	protected String organisationName;
	protected String subBuildingName;
	protected String buildingName;
	protected String buildingNumber;
	protected String dependentThoroughfare;
	protected String thoroughfare;
	protected String doubleDependentLocality;
	protected String dependentLocality;
	protected String town;
	protected String county;
	protected String postcode;

	public DmIvaCompanyDto() {}

	public DmIvaCompanyDto(final Integer id, final String name, final String departmentName, final String organisationName, final String subBuildingName, final String buildingName, final String buildingNumber,
			final String dependentThoroughfare, final String thoroughfare, final String doubleDependentLocality, final String dependentLocality, final String town, final String county, final String postcode) {
		this.id = id;
		this.name = name;
		this.departmentName = departmentName;
		this.organisationName = organisationName;
		this.subBuildingName = subBuildingName;
		this.buildingName = buildingName;
		this.buildingNumber = buildingNumber;
		this.dependentThoroughfare = dependentThoroughfare;
		this.thoroughfare = thoroughfare;
		this.doubleDependentLocality = doubleDependentLocality;
		this.dependentLocality = dependentLocality;
		this.town = town;
		this.county = county;
		this.postcode = postcode;
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(final Integer id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepartmentName() {
		return this.departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getOrganisationName() {
		return this.organisationName;
	}

	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}

	public String getSubBuildingName() {
		return this.subBuildingName;
	}

	public void setSubBuildingName(String subBuildingName) {
		this.subBuildingName = subBuildingName;
	}

	public String getBuildingName() {
		return this.buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getBuildingNumber() {
		return this.buildingNumber;
	}

	public void setBuildingNumber(String buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	public String getDependentThoroughfare() {
		return this.dependentThoroughfare;
	}

	public void setDependentThoroughfare(String dependentThoroughfare) {
		this.dependentThoroughfare = dependentThoroughfare;
	}

	public String getThoroughfare() {
		return this.thoroughfare;
	}

	public void setThoroughfare(String thoroughfare) {
		this.thoroughfare = thoroughfare;
	}

	public String getDoubleDependentLocality() {
		return this.doubleDependentLocality;
	}

	public void setDoubleDependentLocality(String doubleDependentLocality) {
		this.doubleDependentLocality = doubleDependentLocality;
	}

	public String getDependentLocality() {
		return this.dependentLocality;
	}

	public void setDependentLocality(String dependentLocality) {
		this.dependentLocality = dependentLocality;
	}

	public String getTown() {
		return this.town;
	}

	public void setTown(String town) {
		this.town = town;
	}

	public String getCounty() {
		return this.county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getPostcode() {
		return this.postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
}