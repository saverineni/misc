package com.leadx.claimant.client;

public class CreateClaimantReferralDto {
	private ClaimantDto claimantDto;
	private int productTypeId;
	private int referrerClaimantId;
	private int createdByAgentId;
	private int diallerReferenceId;
	private String phoneNumber;
	private String scheduledDateTime;
	private String note;

	public CreateClaimantReferralDto() {
	}

	public CreateClaimantReferralDto(final ClaimantDto claimantDto, final int productTypeId, final int referrerClaimantId, final int createdByAgentId, final int diallerReferenceId, final String scheduledDateTime, final String note) {
		this.claimantDto = claimantDto;
		this.productTypeId = productTypeId;
		this.referrerClaimantId = referrerClaimantId;
		this.createdByAgentId = createdByAgentId;
		this.diallerReferenceId = diallerReferenceId;
		this.scheduledDateTime = scheduledDateTime;
		this.note = note;
	}

	public CreateClaimantReferralDto(final ClaimantDto claimantDto, final int productTypeId, final int referrerClaimantId, final int createdByAgentId, final int diallerReferenceId, final String phoneNumber, final String scheduledDateTime, final String note) {
		this.claimantDto = claimantDto;
		this.productTypeId = productTypeId;
		this.referrerClaimantId = referrerClaimantId;
		this.createdByAgentId = createdByAgentId;
		this.diallerReferenceId = diallerReferenceId;
		this.phoneNumber = phoneNumber;
		this.scheduledDateTime = scheduledDateTime;
		this.note = note;
	}

	public ClaimantDto getClaimantDto() {
		return this.claimantDto;
	}

	public int getProductTypeId() {
		return this.productTypeId;
	}

	public int getReferrerClaimantId() {
		return this.referrerClaimantId;
	}

	public int getCreatedByAgentId() {
		return this.createdByAgentId;
	}

	public int getDiallerReferenceId() {
		return this.diallerReferenceId;
	}
	
	public String getScheduledDateTime() {
		return this.scheduledDateTime;
	}
	
	public String getNote() {
		return this.note;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

}
