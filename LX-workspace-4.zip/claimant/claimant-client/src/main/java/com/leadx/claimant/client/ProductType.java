package com.leadx.claimant.client;

public enum ProductType {

	PPI(1, "ppi", "PPI"),

	PBA(2, "pba", "Packaged Bank Account"),

	STL(3, "stl", "STL"),

	INV(4, "inv", "Investment"),

	PEN(5, "pen", "Pension");

	private int id;
	private String shortName;
	private String longName;

	ProductType(final int id, final String shortName, final String longName) {
		this.id = id;
		this.shortName = shortName;
		this.longName = longName;
	}

	public int getId() {
		return this.id;
	}

	public String getShortName() {
		return this.shortName;
	}

	public String getLongName() {
		return this.longName;
	}

	public static ProductType getById(final int id) {
		for (final ProductType type : values()) {
			if (type.getId() == id) {
				return type;
			}
		}
		return null;
	}

	public static ProductType getByShortName(final String name) {
		for (final ProductType type : values()) {
			if (type.getShortName().equals(name)) {
				return type;
			}
		}
		return null;
	}

	public static ProductType getByLongName(final String name) {
		for (final ProductType type : values()) {
			if (type.getLongName().equals(name)) {
				return type;
			}
		}
		return null;
	}
}