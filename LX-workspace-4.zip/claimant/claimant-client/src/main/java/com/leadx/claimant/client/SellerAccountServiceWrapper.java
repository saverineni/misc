package com.leadx.claimant.client;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.leadx.claimant.client.annotations.Retryable;
import com.leadx.lib.utl.json.JsonUtils;

/** Wrapper around the seller account service. */
@Component
public class SellerAccountServiceWrapper extends ServiceWrapper{
	private static final Logger LOG = LoggerFactory.getLogger(SellerAccountServiceWrapper.class);

	@Retryable
	public void create(final SellerAccountDto acc) {
		final String accDtoToSend = JsonUtils.serialize(acc, true);
		final ResponseEntity<String> response = this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "/selleraccount/create"), accDtoToSend, String.class);
		if (response.getStatusCode() != HttpStatus.OK) {
			LOG.error("Failed to create seller account with id: {}, http error: {}", acc.getAccountId(), response.getStatusCode());
		}
		LOG.info("Created seller account with id: {}", acc.getAccountId());
	}

	@Retryable
	public void update(final SellerAccountDto acc) {
		final String accDtoToSend = JsonUtils.serialize(acc, true);
		final ResponseEntity<String> response = this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "/selleraccount/update"), accDtoToSend, String.class);
		if (response.getStatusCode() != HttpStatus.OK) {
			LOG.error("Failed to update seller account with id: , http error: {}", acc.getAccountId(), response.getStatusCode());
		}
		LOG.info("Updated seller account with id: {}", acc.getAccountId());
	}

	@Retryable
	public void updateColumnValueForAllSellerAccounts(final String column, final String existingValue, final String newDropdownValue) {
		final SellerAccountUpdateDto updateDto = new SellerAccountUpdateDto(column, existingValue, newDropdownValue);
		final String accDtoUpdateToSend = JsonUtils.serialize(updateDto, true);
		final ResponseEntity<String> response = this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "/selleraccount/update/all", column, existingValue, newDropdownValue), accDtoUpdateToSend, String.class);
		if (response.getStatusCode() != HttpStatus.OK) {
			LOG.error("Failed to update column, http error: " + response.getStatusCode());
		}
		LOG.info("Updated column {} from {} to {}", column, existingValue, newDropdownValue);
	}

	@Retryable
	public SellerAccountDto getById(final Integer id) {
		final ResponseEntity<SellerAccountDto> response = this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/selleraccount/id/%s", id), SellerAccountDto.class);
		if (response.getStatusCode() != HttpStatus.OK) {
			LOG.error("Failed to get seller account with id: , http error: {}", id, response.getStatusCode());
			return null;
		}
		LOG.info("Retrieved seller account with id: {}", id);
		return response.getBody();
	}

	@Retryable
	public List<SellerAccountDto> getByIds(final Collection<Integer> ids) {
		if ( ids.size() == 0 ) {
			// If there are no ids, you get a server error because the URL mapping expects a string bafter the /ids so added this check
			// to avoid this.
			return ImmutableList.of();
		}

		final ResponseEntity<String> response = this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/selleraccount/ids/%s", StringUtils.join(ids.toArray(), ",")), String.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			return sellerAccountDtosFromResponse(response);
		}

		LOG.error("Failed to get seller accounts by ids, ids {}, http error {}", StringUtils.join(ids.toArray(), ","), response.getStatusCode());
		throw new RuntimeException("Failed to get claimant ids" + response.getStatusCode());
	}

	@Retryable
	public List<SellerAccountDto> getAll() {
		final ResponseEntity<String> response = this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/selleraccount/all"), String.class);
		if (response.getStatusCode() != HttpStatus.OK){
			LOG.error("Failed to get all seller accounts");
			return Lists.newArrayList();
		}
		return SellerAccountDtosFromResponse(response);
	}

	@Retryable
	public List<SellerAccountDto> getSourcedSellerAccounts() {
		final ResponseEntity<String> response = this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/selleraccount/sourced"), String.class);
		if (response.getStatusCode() != HttpStatus.OK){
			LOG.error("Failed to get sourced seller accounts");
			return Lists.newArrayList();
		}
		return SellerAccountDtosFromResponse(response);
	}

	@Retryable
	public List<ProductTypeDto> getAllProductTypes() {
		final ResponseEntity<String> response = this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/selleraccount/producttypes"), String.class);
		if (response.getStatusCode() != HttpStatus.OK){
			LOG.error("Failed to get product types");
			return Lists.newArrayList();
		}
		return ProductTypeDtosFromResponse(response);
	}

	@Retryable
	public List<DropdownConfigurationDto> getDropdownItemsForField(final String fieldName) {
		final ResponseEntity<String> response = this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/selleraccount/dropdown/%s", fieldName), String.class);
		if (response.getStatusCode() != HttpStatus.OK){
			LOG.error("Failed to get dropdown configuration items for field name: {}", fieldName);
			return Lists.newArrayList();
		}

		return dropdownConfigurationItemsFromResponse(response);
	}

	@Retryable
	public Boolean isFreePpi(final int sellerAccountId) {
		final ResponseEntity<Boolean> response = this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/selleraccount/isFreePpi/%s", sellerAccountId), Boolean.class);
		if (response.getStatusCode() == HttpStatus.OK){
			return response.getBody();
		}

		LOG.error("Failed to verify if the seller account {} is FreePpi", sellerAccountId);
		throw new RuntimeException(String.format("Failed to verify if the seller account %s is FreePpi", sellerAccountId));
	}

	private static List<ProductTypeDto> ProductTypeDtosFromResponse(final ResponseEntity<String> response) {
		final ObjectMapper mapper = new ObjectMapper();

		try {
			return mapper.readValue(response.getBody(), new TypeReference<List<ProductTypeDto>>() { });
		}
		catch (final IOException e) {
			LOG.error("Failed to map to ProductTypeDto object from response: " + response.getBody());
			return Lists.newArrayList();
		}
	}

	private static List<SellerAccountDto> SellerAccountDtosFromResponse(final ResponseEntity<String> response) {
		final ObjectMapper mapper = new ObjectMapper();

		try {
			return mapper.readValue(response.getBody(), new TypeReference<List<SellerAccountDto>>() { });
		}
		catch (final IOException e) {
			LOG.error("Failed to map to SellerAccountDto object from response: " + response.getBody());
			return Lists.newArrayList();
		}
	}

	private static List<DropdownConfigurationDto> dropdownConfigurationItemsFromResponse(final ResponseEntity<String> response) {
		final ObjectMapper mapper = new ObjectMapper();

		try {
			return mapper.readValue(response.getBody(), new TypeReference<List<DropdownConfigurationDto>>() { });
		}
		catch (final IOException e) {
			LOG.error("Failed to map to DropdownConfigurationDto object from response: " + response.getBody());
			return Lists.newArrayList();
		}
	}

	private static List<SellerAccountDto> sellerAccountDtosFromResponse(final ResponseEntity<String> response) {
		final ObjectMapper mapper = new ObjectMapper();

		try {
			return mapper.readValue(response.getBody(), new TypeReference<Collection<SellerAccountDto>>() { });
		}
		catch (final IOException e) {
			LOG.error("Failed to map to SellerAccountDtoDto object from response: " + response.getBody());
			throw new RuntimeException("Failed map to SellerAccountDto object: " + response.getStatusCode());
		}
	}

}
