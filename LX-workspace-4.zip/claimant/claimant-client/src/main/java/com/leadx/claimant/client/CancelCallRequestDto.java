package com.leadx.claimant.client;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.leadx.services.client.TcgProduct;

@JsonAutoDetect
public class CancelCallRequestDto {

	private int claimantId;
	private int userId;
	private TcgProduct tcgProduct;

	public CancelCallRequestDto(){}

	/**
	 * @param claimantId
	 * @param userId
	 * @param tcgProduct
	 */

	public CancelCallRequestDto(final int claimantId, final int userId, final TcgProduct tcgProduct){

		this.claimantId = claimantId;
		this.userId = userId;
		this.tcgProduct = tcgProduct;

	}

	public int getClaimantId() {
		return this.claimantId;
	}

	public void setClaimantId(int claimantId) {
		this.claimantId = claimantId;
	}

	public int getUserId() {
		return this.userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public TcgProduct getTcgProduct() {
		return this.tcgProduct;
	}

	public void setTcgProduct(TcgProduct tcgProduct) {
		this.tcgProduct = tcgProduct;
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public boolean equals(final Object obj) {
		return deepEquals(obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	public boolean deepEquals(final Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}


}
