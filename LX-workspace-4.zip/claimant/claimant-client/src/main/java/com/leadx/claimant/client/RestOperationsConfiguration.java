package com.leadx.claimant.client;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component("claimantRestOperations")
public class RestOperationsConfiguration extends RestTemplate {

	@Value("${claimant.client.timeout}")
	private int timeout;

	public RestOperationsConfiguration() {
		super(new HttpComponentsClientHttpRequestFactory());
	}

	@PostConstruct
	public void configure() {
		((HttpComponentsClientHttpRequestFactory) this.getRequestFactory()).setReadTimeout(this.timeout);
	}
}
