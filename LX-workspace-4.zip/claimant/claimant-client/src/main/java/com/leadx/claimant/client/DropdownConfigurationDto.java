package com.leadx.claimant.client;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect
public class DropdownConfigurationDto {
	
	private String fieldName;
	private String fieldValue;
	
	private int fieldOrder;
	
	public DropdownConfigurationDto() {
	}
	
	public DropdownConfigurationDto(final String fieldName, final String fieldValue, final int fieldOrder) {
		this.fieldName = fieldName;
		this.fieldValue = fieldValue;
		this.fieldOrder = fieldOrder;
	}
	
	public String getFieldName() {
		return this.fieldName;
	}
	
	public String getFieldValue() {
		return this.fieldValue;
	}
	
	public int getFieldOrder() {
		return this.fieldOrder;
	}
}