package com.leadx.claimant.client;

public class ClaimantAndAddressDto {
	private ClaimantDto claimantDto;
	private AddressDto addressDto;

	public ClaimantAndAddressDto(final ClaimantDto claimantDto, final AddressDto addressDto) {
		this.claimantDto = claimantDto;
		this.addressDto = addressDto;
	}

	public ClaimantAndAddressDto() {
	}

	public ClaimantDto getClaimantDto() {
		return this.claimantDto;
	}

	public AddressDto getAddressDto() {
		return this.addressDto;
	}
}
