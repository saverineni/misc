package com.leadx.claimant.client;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

/** Result for a call to check locked status of a claimant. */
@JsonAutoDetect
public class ClaimantLockStatusDto {
	// Whether claimant is locked
	private boolean isLocked;

	// If locked who it is locked by, otherwise 0
	private int lockedByUserId;

	public ClaimantLockStatusDto(final boolean isLocked, final int lockedByUserId) {
		this.isLocked = isLocked;
		this.lockedByUserId = lockedByUserId;
	}

	public ClaimantLockStatusDto() {
	}

	public boolean getIsLocked() {
		return this.isLocked;
	}

	public int getLockedByUserId() {
		return this.lockedByUserId;
	}
	
	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public boolean equals(final Object o) {
		return EqualsBuilder.reflectionEquals(this, o);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
