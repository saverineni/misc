package com.leadx.claimant.client;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect
public class ClaimantAuthenticationDto implements Serializable {

	private static final long serialVersionUID = -5691122039638727253L;

	private int claimantId;
	private String password;

	public ClaimantAuthenticationDto() {
	}

	public ClaimantAuthenticationDto(final int claimantId, final String password) {
		this.claimantId = claimantId;
		this.password = password;
	}

	public int getClaimantId() {
		return claimantId;
	}

	public void setClaimantId(int claimantId) {
		this.claimantId = claimantId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}
	
	@Override
	public boolean equals(final Object obj) {
		return deepEquals(obj);
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	public boolean deepEquals(final Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}
	
}
