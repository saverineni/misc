package com.leadx.claimant.client;

import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

public class ClaimantDto {

	private int id;
	private int leadId;
	private int sellerAccountId;
	private int sellerCompanyId;
	private String title;
	private String forename;
	private String middleName;
	private String surname;
	private String previousSurname;
	private String dob;
	private int addressId;
	private String homeTelephone;
	private String mobileTelephone;
	private String alternativeTelephone;
	@Deprecated
	private String workTelephone;
	private String email;
	private String nationalInsuranceNumber;
	private String suppressedDateTime;
	private String createdDateTime;
	private String updateDateTime;
	private boolean lockedFromDialler;
	private String lockedFromDiallerUpdateDateTime;
	private int lockedFromDiallerUpdateUserId;
	private boolean rightToBeForgotten;
	private String rightToBeForgottenNewestClosedClaimDate;
	private int rightToBeForgottenUpdateUserId;
	private String rightToBeForgottenUpdateDateTime;
	private boolean vulnerableCustomer;
	private String vulnerableCustomerUpdateDateTime;
	private int vulnerableCustomerUpdateUserId;
	private String vulnerableCustomerReviewDate;
	private boolean incorrectAddress;
	private String incorrectAddressUpdateDateTime;
	private boolean freePpi;
	private int productTypeId; // See ProductType interface for allowable values
	private List<ClaimantOtherNameDto> otherNames; 
	private List<ClaimantAdditionalPreviousNameDto> additionalPreviousNames;
	private List<ClaimantPreviousEmailDto> previousEmails;
	private String formalDebtArrangement;
	private Set<String> formalDebtArrangementType;
	private Integer ivaCompanyId;
	private String ivaReference;
	private String informalDebtArrangement;
	private Integer debtManagementCompanyId;
	private String debtManagementReference;
	private ClaimantUnpresentedChequeDto unpresentedCheque;
	private ClaimantExecutorDto claimantExecutor;
	private Boolean hasVulnerability;
	private Set<String> vulnerabilityCategories;
	private String canStoreVulnerabilityDetail;
	private String vulnerabilityDetail;

	public ClaimantDto() {
	}

	public ClaimantDto(final int id, final int leadId, final int sellerAccountId, final int sellerCompanyId, final String title, final String forename,
					   final String middleName, final String surname, final String previous, final String dob, final int addressId,
					   final String homeTelephone, final String mobileTelephone, final String alternativeTelephone, final String workTelephone, final String email,
					   final String nationalInsuranceNumber, boolean lockedFromDialler, String lockedFromDiallerUpdateDateTime, int lockedFromDiallerUpdateUserId,
					   final boolean rightToBeForgotten, String rightToBeForgottenNewestClosedClaimDate, int rightToBeForgottenUpdateUserId, String rightToBeForgottenUpdateDateTime,
					   final boolean vulnerableCustomer, String vulnerableCustomerUpdateDateTime, int vulnerableCustomerUpdateUserId,
					   final String vulnerableCustomerReviewDate, final boolean incorrectAddress, final String incorrectAddressUpdateDateTime,
					   final boolean freePpi, final String suppressedDateTime, final String createdDateTime, final String updatedDateTime,
					   final List<ClaimantOtherNameDto> otherNames, final List<ClaimantAdditionalPreviousNameDto> additionalPreviousNames,
					   final List<ClaimantPreviousEmailDto> previousEmails, final String formalDebtArrangement, final Set<String> formalDebtArrangementType,
					   final Integer ivaCompanyId, final String ivaReference, final String informalDebtArrangement, final Integer debtManagementCompanyId, final String debtManagementReference,
					   final ClaimantUnpresentedChequeDto unpresentedCheque,
					   final ClaimantExecutorDto claimantExecutor, final Boolean hasVulnerability, final Set<String> vulnerabilityCategories,
			           final String canStoreVulnerabilityDetail, final String vulnerabilityDetail) {
		this.id = id;
		this.leadId = leadId;
		this.sellerAccountId = sellerAccountId;
		this.sellerCompanyId = sellerCompanyId;
		this.title = title;
		this.forename = forename;
		this.middleName = middleName;
		this.surname = surname;
		this.previousSurname = previous;
		this.dob = dob;
		this.addressId = addressId;
		this.homeTelephone = homeTelephone;
		this.mobileTelephone = mobileTelephone;
		this.alternativeTelephone = alternativeTelephone;
		this.workTelephone = workTelephone;
		this.email = email;
		this.nationalInsuranceNumber = nationalInsuranceNumber;
		this.lockedFromDialler = lockedFromDialler;
		this.lockedFromDiallerUpdateDateTime = lockedFromDiallerUpdateDateTime;
		this.lockedFromDiallerUpdateUserId = lockedFromDiallerUpdateUserId;
		this.rightToBeForgotten = rightToBeForgotten;
		this.rightToBeForgottenNewestClosedClaimDate = rightToBeForgottenNewestClosedClaimDate;
		this.rightToBeForgottenUpdateUserId = rightToBeForgottenUpdateUserId;
		this.rightToBeForgottenUpdateDateTime = rightToBeForgottenUpdateDateTime;
		this.vulnerableCustomer = vulnerableCustomer;
		this.vulnerableCustomerUpdateDateTime = vulnerableCustomerUpdateDateTime;
		this.vulnerableCustomerUpdateUserId = vulnerableCustomerUpdateUserId;
		this.vulnerableCustomerReviewDate = vulnerableCustomerReviewDate;
		this.incorrectAddress = incorrectAddress;
		this.incorrectAddressUpdateDateTime = incorrectAddressUpdateDateTime;
		this.freePpi = freePpi;
		this.suppressedDateTime = suppressedDateTime;
		this.createdDateTime = createdDateTime;
		this.updateDateTime = updatedDateTime;
		this.otherNames = otherNames;
		this.additionalPreviousNames = additionalPreviousNames;
		this.previousEmails = previousEmails;
		this.formalDebtArrangement = formalDebtArrangement;
		this.formalDebtArrangementType = formalDebtArrangementType;
		this.ivaCompanyId = ivaCompanyId;
		this.ivaReference = ivaReference;
		this.informalDebtArrangement = informalDebtArrangement;
		this.debtManagementCompanyId = debtManagementCompanyId;
		this.debtManagementReference = debtManagementReference;
		this.unpresentedCheque = unpresentedCheque;
		this.claimantExecutor = claimantExecutor;
		this.hasVulnerability = hasVulnerability;
		this.vulnerabilityCategories = vulnerabilityCategories;
		this.canStoreVulnerabilityDetail = canStoreVulnerabilityDetail;
		this.vulnerabilityDetail = vulnerabilityDetail;
	}

	public int getProductTypeId() {
		return this.productTypeId;
	}

	public void setProductTypeId(final int productTypeId) {
		this.productTypeId = productTypeId;
	}

	public void setId(final int id) {
		this.id = id;
	}

	public void setLeadId(final int leadId) {
		this.leadId = leadId;
	}

	public void setSellerAccountId(final int sellerAccountId) {
		this.sellerAccountId = sellerAccountId;
	}

	public void setSellerCompanyId(final int sellerCompanyId) {
		this.sellerCompanyId = sellerCompanyId;
	}

	public void setTitle(final String title) {
		this.title = title;
	}

	public void setForename(final String forename) {
		this.forename = forename;
	}

	public void setMiddleName(final String middleName) {
		this.middleName = middleName;
	}

	public void setSurname(final String surname) {
		this.surname = surname;
	}

	public void setPreviousSurname(final String previous) {
		this.previousSurname = previous;
	}

	public void setDob(final String dob) {
		this.dob = dob;
	}

	public void setAddressId(final int addressId) {
		this.addressId = addressId;
	}

	public void setHomeTelephone(final String homeTelephone) {
		this.homeTelephone = homeTelephone;
	}

	public void setMobileTelephone(final String mobileTelephone) {
		this.mobileTelephone = mobileTelephone;
	}
	
	public void setAlternativeTelephone(final String alternativeTelephone) {
		this.alternativeTelephone = alternativeTelephone;
	}

	public void setWorkTelephone(final String workTelephone) {
		this.workTelephone = workTelephone;
	}

	public void setEmail(final String email) {
		this.email = email;
	}

	public void setNationalInsuranceNumber(final String nationalInsuranceNumber) { this.nationalInsuranceNumber = nationalInsuranceNumber; }

	public void setCreatedDateTime(final String createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public void setUpdateDateTime(final String updateDateTime) {
		this.updateDateTime = updateDateTime;
	}

	public void setLockedFromDialler(final boolean lockedFromDialler) {
		this.lockedFromDialler = lockedFromDialler;
	}

	public void setLockedFromDiallerUpdateDateTime(String lockedFromDiallerUpdateDateTime) {
		this.lockedFromDiallerUpdateDateTime = lockedFromDiallerUpdateDateTime;
	}

	public void setLockedFromDiallerUpdateUserId(int lockedFromDiallerUpdateUserId) {
		this.lockedFromDiallerUpdateUserId = lockedFromDiallerUpdateUserId;
	}
	
	public void setOtherNames(List<ClaimantOtherNameDto> otherNames) {
		this.otherNames = otherNames;
	}
	
	public void setAdditionalPreviousNames(List<ClaimantAdditionalPreviousNameDto> additionalPreviousNames) {
		this.additionalPreviousNames = additionalPreviousNames;
	}

	public void setPreviousEmails(List<ClaimantPreviousEmailDto> previousEmails) {
		this.previousEmails = previousEmails;
	}

	public void setUnpresentedCheque(ClaimantUnpresentedChequeDto unpresentedCheque) {
		this.unpresentedCheque = unpresentedCheque;
	}

	public void setFreePpi(boolean freePpi) {
		this.freePpi = freePpi;
	}

	public String getUpdateDateTime() {
		return this.updateDateTime;
	}

	public int getId() {
		return this.id;
	}

	public int getLeadId() {
		return this.leadId;
	}

	public int getSellerAccountId() {
		return this.sellerAccountId;
	}

	public int getSellerCompanyId() {
		return this.sellerCompanyId;
	}

	public String getTitle() {
		return this.title;
	}

	public String getForename() {
		return this.forename;
	}

	public String getMiddleName() {
		return this.middleName;
	}

	public String getSurname() {
		return this.surname;
	}

	public String getPreviousSurname() {
		return this.previousSurname;
	}

	public String getDob() {
		return this.dob;
	}

	public int getAddressId() {
		return this.addressId;
	}

	public String getHomeTelephone() {
		return this.homeTelephone;
	}

	public String getMobileTelephone() {
		return this.mobileTelephone;
	}
	
	public String getAlternativeTelephone() {
		return this.alternativeTelephone;
	}

	public String getWorkTelephone() {
		return this.workTelephone;
	}

	public String getEmail() {
		return this.email;
	}

	public String getNationalInsuranceNumber() { return this.nationalInsuranceNumber; }

	public String getSuppressedDateTime() {
		return this.suppressedDateTime;
	}

	public String getCreatedDateTime() {
		return this.createdDateTime;
	}

	public boolean getLockedFromDialler() {
		return this.lockedFromDialler;
	}

	public String getLockedFromDiallerUpdateDateTime() {
		return this.lockedFromDiallerUpdateDateTime;
	}

	public int getLockedFromDiallerUpdateUserId() {
		return this.lockedFromDiallerUpdateUserId;
	}
	
	public List<ClaimantOtherNameDto> getOtherNames() {
		return this.otherNames;
	}
	
	public List<ClaimantAdditionalPreviousNameDto> getAdditionalPreviousNames() {
		return this.additionalPreviousNames;
	}

	public List<ClaimantPreviousEmailDto> getPreviousEmails() {
		return this.previousEmails;
	}

	public boolean getRightToBeForgotten() {
		return rightToBeForgotten;
	}

	public void setRightToBeForgotten(boolean rightToBeForgotten) {
		this.rightToBeForgotten = rightToBeForgotten;
	}

	public String getRightToBeForgottenNewestClosedClaimDate() {
		return rightToBeForgottenNewestClosedClaimDate;
	}

	public void setRightToBeForgottenNewestClosedClaimDate(String rightToBeForgottenNewestClosedClaimDate) {
		this.rightToBeForgottenNewestClosedClaimDate = rightToBeForgottenNewestClosedClaimDate;
	}

	public int getRightToBeForgottenUpdateUserId() {
		return rightToBeForgottenUpdateUserId;
	}

	public void setRightToBeForgottenUpdateUserId(int rightToBeForgottenUpdateUserId) {
		this.rightToBeForgottenUpdateUserId = rightToBeForgottenUpdateUserId;
	}

	public String getRightToBeForgottenUpdateDateTime() {
		return rightToBeForgottenUpdateDateTime;
	}

	public void setRightToBeForgottenUpdateDateTime(String rightToBeForgottenUpdateDateTime) {
		this.rightToBeForgottenUpdateDateTime = rightToBeForgottenUpdateDateTime;
	}

	public boolean getVulnerableCustomer() {
		return vulnerableCustomer;
	}

	public void setVulnerableCustomer(boolean vulnerableCustomer) {
		this.vulnerableCustomer = vulnerableCustomer;
	}

	public String getVulnerableCustomerUpdateDateTime() {
		return vulnerableCustomerUpdateDateTime;
	}

	public void setVulnerableCustomerUpdateDateTime(String vulnerableCustomerUpdateDateTime) {
		this.vulnerableCustomerUpdateDateTime = vulnerableCustomerUpdateDateTime;
	}

	public int getVulnerableCustomerUpdateUserId() {
		return vulnerableCustomerUpdateUserId;
	}

	public void setVulnerableCustomerUpdateUserId(int vulnerableCustomerUpdateUserId) {
		this.vulnerableCustomerUpdateUserId = vulnerableCustomerUpdateUserId;
	}

	public String getVulnerableCustomerReviewDate() {
		return vulnerableCustomerReviewDate;
	}

	public void setVulnerableCustomerReviewDate(String vulnerableCustomerReviewDate) {
		this.vulnerableCustomerReviewDate = vulnerableCustomerReviewDate;
	}

	public boolean getIncorrectAddress() {
		return this.incorrectAddress;
	}

	public void setIncorrectAddress(boolean incorrectAddress) {
		this.incorrectAddress = incorrectAddress;
	}

	public String getIncorrectAddressUpdateDateTime() {
		return this.incorrectAddressUpdateDateTime;
	}

	public void setIncorrectAddressUpdateDateTime(String incorrectAddressUpdateDateTime) {
		this.incorrectAddressUpdateDateTime = incorrectAddressUpdateDateTime;
	}

	public ClaimantUnpresentedChequeDto getUnpresentedCheque() {
		return unpresentedCheque;
	}

	public boolean getFreePpi() {
		return freePpi;
	}

	public void setSuppressedDateTime(final String suppressedDateTime) {
		this.suppressedDateTime = suppressedDateTime;
	}

	public String getFormalDebtArrangement() {
		return formalDebtArrangement;
	}

	public Set<String> getFormalDebtArrangementType() {
		return formalDebtArrangementType;
	}

	public Integer getIvaCompanyId() {
		return ivaCompanyId;
	}

	public String getIvaReference() {
		return ivaReference;
	}

	public String getInformalDebtArrangement() {
		return informalDebtArrangement;
	}

	public Integer getDebtManagementCompanyId() {
		return debtManagementCompanyId;
	}

	public String getDebtManagementReference() {
		return debtManagementReference;
	}

	public void setFormalDebtArrangement(String formalDebtArrangement) {
		this.formalDebtArrangement = formalDebtArrangement;
	}

	public void setFormalDebtArrangementType(Set<String> formalDebtArrangementType) {
		this.formalDebtArrangementType = formalDebtArrangementType;
	}

	public void setIvaCompanyId(Integer ivaCompanyId) {
		this.ivaCompanyId = ivaCompanyId;
	}

	public void setIvaReference(String ivaReference) {
		this.ivaReference = ivaReference;
	}

	public void setInformalDebtArrangement(String informalDebtArrangement) {
		this.informalDebtArrangement = informalDebtArrangement;
	}

	public void setDebtManagementCompanyId(Integer debtManagementCompanyId) {
		this.debtManagementCompanyId = debtManagementCompanyId;
	}

	public void setDebtManagementReference(String debtManagementReference) {
		this.debtManagementReference = debtManagementReference;
	}

	public ClaimantExecutorDto getClaimantExecutor(){
		return this.claimantExecutor;
	}

	public void setClaimantExecutor(final ClaimantExecutorDto claimantExecutor) {
		this.claimantExecutor = claimantExecutor;
	}

	public Boolean getHasVulnerability() {
		return hasVulnerability;
	}

	public void setHasVulnerability(Boolean hasVulnerability) {
		this.hasVulnerability = hasVulnerability;
	}

	public Set<String> getVulnerabilityCategories() {
		return vulnerabilityCategories;
	}

	public void setVulnerabilityCategories(Set<String> vulnerabilityCategories) {
		this.vulnerabilityCategories = vulnerabilityCategories;
	}

	public String getCanStoreVulnerabilityDetail() {
		return canStoreVulnerabilityDetail;
	}

	public void setCanStoreVulnerabilityDetail(String canStoreVulnerabilityDetail) {
		this.canStoreVulnerabilityDetail = canStoreVulnerabilityDetail;
	}

	public String getVulnerabilityDetail() {
		return vulnerabilityDetail;
	}

	public void setVulnerabilityDetail(String vulnerabilityDetail) {
		this.vulnerabilityDetail = vulnerabilityDetail;
	}

	public boolean hasExecutor() {
		return this.claimantExecutor.getTimestamp() != null;
	}

	// The returned 'claimant' from this is used to display details to portal (i.e. it's externally accessible)
	public static ClaimantDto fromName(final int id, final String title, final String forename, final String surname) {
		return new ClaimantDto(id, 0, 0, 0, title, forename, null, surname, null, null,
				0, null, null, null, null, null, null, false,
				null, 0, false, null,
				0, null, false, null,
				0, null, false, null,
				false, null, null, null, Lists.newArrayList(), Lists.newArrayList(),
				Lists.newArrayList(), null, null, 0, null, null,
				null, null, null, null, null, Sets.newHashSet(), null, null);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public boolean equals(final Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
