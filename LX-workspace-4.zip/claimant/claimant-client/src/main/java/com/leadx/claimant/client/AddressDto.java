package com.leadx.claimant.client;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.beans.BeanUtils;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect
public class AddressDto implements Serializable {
	
	private static final long serialVersionUID = 7464475411786142721L;
	
	private int id;
	private String departmentName;
	private String organisationName;
	private String subBuildingName;
	private String buildingName;
	private String buildingNumber;
	private String dependentThoroughfare;
	private String thoroughfare;
	private String doubleDependentLocality;
	private String dependentLocality;
	private String town;
	private String postcode;
	private String county;
	private String pafValidatedDate;
	private String updatedDateTime;
	private int version;
	
	public AddressDto() {
	}
	
	public AddressDto(final int id, final String departmentName, final String organisationName,
						final String subBuildingName, final String buildingName, final String buildingNumber, 
						final String dependentThoroughfare, final String thoroughfare, final String doubleDependentLocality,
						final String dependentLocality, final String town, final String postcode, final String county, 
						final String pafValidatedDate, final String updatedDateTime) {
		this.id = id;
		this.departmentName = departmentName;
		this.organisationName = organisationName;
		this.subBuildingName = subBuildingName;
		this.buildingName = buildingName;
		this.buildingNumber = buildingNumber;
		this.dependentThoroughfare = dependentThoroughfare;
		this.thoroughfare = thoroughfare;
		this.doubleDependentLocality = doubleDependentLocality;
		this.dependentLocality = dependentLocality;
		this.town = town;
		this.postcode = postcode;
		this.county = county;
		this.pafValidatedDate = pafValidatedDate;
		this.updatedDateTime = updatedDateTime;
	}

	public int getId() {
		return this.id;
	}
	
	public void setId(final int id) {
		this.id = id;
	}

	public String getDepartmentName() {
		return this.departmentName;
	}
	
	public void setDepartmentName(final String departmentName) {
		this.departmentName = departmentName;
	}

	public String getOrganisationName() {
		return this.organisationName;
	}
	
	public void setOrganisationName(final String organisationName) {
		this.organisationName = organisationName;
	}

	public String getSubBuildingName() {
		return this.subBuildingName;
	}
	
	public void setSubBuildingName(final String subBuildingName) {
		this.subBuildingName = subBuildingName;
	}

	public String getBuildingName() {
		return this.buildingName;
	}
	
	public void setBuildingName(final String buildingName) {
		this.buildingName = buildingName;
	}

	public String getBuildingNumber() {
		return this.buildingNumber;
	}
	
	public void setBuildingNumber(final String buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	public String getDependentThoroughfare() {
		return this.dependentThoroughfare;
	}
	
	public void setDependentThoroughfare(final String dependentThoroughfare) {
		this.dependentThoroughfare = dependentThoroughfare;
	}

	public String getThoroughfare() {
		return this.thoroughfare;
	}
	
	public void setThoroughfare(final String thoroughfare) {
		this.thoroughfare = thoroughfare;
	}

	public String getDoubleDependentLocality() {
		return this.doubleDependentLocality;
	}
	
	public void setDoubleDependentLocality(final String doubleDependentLocality) {
		this.doubleDependentLocality = doubleDependentLocality;
	}

	public String getDependentLocality() {
		return this.dependentLocality;
	}
	
	public void setDependentLocality(final String dependentLocality) {
		this.dependentLocality = dependentLocality;
	}

	public String getTown() {
		return this.town;
	}
	
	public void setTown(final String town) {
		this.town = town;
	}

	public String getPostcode() {
		return this.postcode;
	}
	
	public void setPostcode(final String postcode) {
		this.postcode = postcode;
	}

	public String getCounty() {
		return this.county;
	}
	
	public void setCounty(final String county) {
		this.county = county;
	}

	public String getPafValidatedDate() {
		return this.pafValidatedDate;
	}
	
	public void setPafValidatedDate(final String pafValidatedDate) {
		this.pafValidatedDate = pafValidatedDate;
	}
	
	public String getUpdatedDateTime() {
		return this.updatedDateTime;
	}
	
	public void setUpdatedDateTime(final String updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

	public int getVersion() {
		return this.version;
	}

	public void setVersion(final int version) {
		this.version = version;
	}
	
	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}
	
	@Override
	public boolean equals(final Object obj) {
		return deepEquals(obj);
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	public boolean deepEquals(final Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}

	public AddressDto copy() {
		try {
			final AddressDto clone = new AddressDto();
			BeanUtils.copyProperties(this, clone, new String[] { "id", "objVersion" });
			return clone;
		}
		catch (final Exception e) {
			throw new RuntimeException("Couldn't clone address", e);
		}
	}
	
	public AddressDto merge(final AddressDto addressDto) {
		this.id = addressDto.getId();
		this.departmentName = addressDto.getDepartmentName();
		this.organisationName = addressDto.getOrganisationName();
		this.subBuildingName = addressDto.getSubBuildingName();
		this.buildingName = addressDto.getBuildingName();
		this.buildingNumber = addressDto.getBuildingNumber();
		this.dependentThoroughfare = addressDto.getDependentThoroughfare();
		this.thoroughfare = addressDto.getThoroughfare();
		this.doubleDependentLocality = addressDto.getDoubleDependentLocality();
		this.dependentLocality = addressDto.getDependentLocality();
		this.town = addressDto.getTown();
		this.postcode = addressDto.getPostcode();
		this.county = addressDto.getCounty();
		this.pafValidatedDate = addressDto.getPafValidatedDate();
		this.updatedDateTime = addressDto.getUpdatedDateTime();
		this.version = addressDto.getVersion();
		
		return this;
	}
	
}
