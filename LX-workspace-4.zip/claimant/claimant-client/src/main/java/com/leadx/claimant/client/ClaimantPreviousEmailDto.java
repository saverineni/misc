package com.leadx.claimant.client;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class ClaimantPreviousEmailDto {

	private Integer id;
	private String previousEmail;
	private boolean isDeleted;
	private int version;

	public ClaimantPreviousEmailDto() {

	}

	public ClaimantPreviousEmailDto(final Integer id, final String previousEmail, final boolean isDeleted, final int version) {
		this.id = id;
		this.previousEmail = previousEmail;
		this.isDeleted = isDeleted;
		this.version = version;
	}
	
	public int getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getPreviousEmail() {
		return this.previousEmail;
	}

	public void setPreviousEmail(String previousEmail) {
		this.previousEmail = previousEmail;
	}

	public boolean getIsDeleted() {
		return this.isDeleted;
	}

	public void setIsDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	
	public int getVersion() {
		return this.version;
	}
	
	public void setVersion(int version) {
		this.version = version;
	}

	@Override
	public boolean equals(final Object obj) {
		return EqualsBuilder.reflectionEquals(obj, this);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
