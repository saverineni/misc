package com.leadx.claimant.client;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

/** Result of a claimant lock call. */
@JsonAutoDetect
public class ClaimantLockDto {
	// Did call to lock acquire a lock on the climant
	private boolean acquiredLock;

	// Who has the lock - if didn't successfully acquire the lock it will be the id the user who does have the lock
	private int lockedByUserId;

	public ClaimantLockDto(final boolean acquiredLock, final int lockedByUserId) {
		this.acquiredLock = acquiredLock;
		this.lockedByUserId = lockedByUserId;
	}

	public ClaimantLockDto() {
	}

	public boolean getAcquiredLock() {
		return this.acquiredLock;
	}

	public int getLockedByUserId() {
		return this.lockedByUserId;
	}
	
	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public boolean equals(final Object o) {
		return EqualsBuilder.reflectionEquals(this, o);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
