package com.leadx.claimant.client;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.leadx.claimant.client.annotations.Retryable;
import com.leadx.lib.utl.json.JsonUtils;

/** Wrapper around the call log service. */
@Component
public class CallLogServiceWrapper extends ServiceWrapper {
	private static final Logger LOG = LoggerFactory.getLogger(CallLogServiceWrapper.class);

	@Retryable
	public Boolean saveCallLog(final CallLogDto callLogDto) throws Exception {
		final String logDtoToSend = JsonUtils.serialize(callLogDto, true);
		final ResponseEntity<String> response = this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "/calllog/save"), logDtoToSend, String.class);
		if (response.getStatusCode() != HttpStatus.OK) {
			LOG.warn("Failed to save call log for call with claimant: {}, http error: {}", callLogDto.getClaimantId(), response.getStatusCode());
			return false;
		}

		LOG.info("Saved call log for call with claimant: {}", callLogDto.getClaimantId());
		return true;
	}

	@Retryable
	public List<CallLogDto> findCallLogsForClaimant(final int claimantId) throws Exception {
		final ResponseEntity<String> response = this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/calllog/unique/%s", claimantId), String.class);
		if (response.getStatusCode() == HttpStatus.OK){
				return callLogDtosFromResponse(response);
		}

		LOG.warn("Failed to find call logs for claimant {}, http error {}", claimantId, response.getStatusCode());
		throw new Exception("Failed to find call logs for claimant " + claimantId + ", http error " + response.getStatusCode());
	}
	
	private static List<CallLogDto> callLogDtosFromResponse(final ResponseEntity<String> response) {
		final ObjectMapper mapper = new ObjectMapper();

		try {
			return mapper.readValue(response.getBody(), new TypeReference<List<CallLogDto>>() { });
		}
		catch (final IOException e) {
			LOG.error("Failed to map to CallLogDto object from response: " + response.getBody());
			throw new RuntimeException("Failed map to CallLogDto object: " + response.getStatusCode());
		}
	}
}
