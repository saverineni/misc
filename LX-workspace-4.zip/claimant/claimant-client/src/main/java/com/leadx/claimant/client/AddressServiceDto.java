package com.leadx.claimant.client;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect
public class AddressServiceDto {
	
	private AddressDto currentAddress;
	private List<PreviousAddressDto> orderedPreviousAddresses;
	private List<PreviousAddressDto> deletedPreviousAddresses;
	
	public AddressDto getCurrentAddress() {
		return this.currentAddress;
	}

	public void setCurrentAddress(AddressDto currentAddress) {
		this.currentAddress = currentAddress;
	}

	public List<PreviousAddressDto> getOrderedPreviousAddresses() {
		return this.orderedPreviousAddresses;
	}

	public void setOrderedPreviousAddresses(List<PreviousAddressDto> orderedPreviousAddresses) {
		this.orderedPreviousAddresses = orderedPreviousAddresses;
	}

	public List<PreviousAddressDto> getDeletedPreviousAddresses() {
		return this.deletedPreviousAddresses;
	}

	public void setDeletedPreviousAddresses(List<PreviousAddressDto> deletedPreviousAddresses) {
		this.deletedPreviousAddresses = deletedPreviousAddresses;
	}
}