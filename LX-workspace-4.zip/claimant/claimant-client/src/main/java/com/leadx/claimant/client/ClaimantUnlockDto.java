package com.leadx.claimant.client;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

/** Result of a claimant unlock call. */
@JsonAutoDetect
public class ClaimantUnlockDto {
	// If last had a lock on the claimant, 0 no previous lock
	private int lockedByUserId;

	public ClaimantUnlockDto(final int lockedByUserId) {
		this.lockedByUserId = lockedByUserId;
	}

	public ClaimantUnlockDto() {
	}

	public int getLockedByUserId() {
		return this.lockedByUserId;
	}
	
	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public boolean equals(final Object o) {
		return EqualsBuilder.reflectionEquals(this, o);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
