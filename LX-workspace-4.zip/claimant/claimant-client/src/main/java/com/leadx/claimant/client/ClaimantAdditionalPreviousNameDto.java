package com.leadx.claimant.client;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class ClaimantAdditionalPreviousNameDto {
	
	private Integer id;
	private String additionalPreviousName;
	private boolean isDeleted;
	private int version;
	
	public ClaimantAdditionalPreviousNameDto() {
		
	}
	
	public ClaimantAdditionalPreviousNameDto(final Integer id, final String additionalPreviousName, final boolean isDeleted, final int version) {
		this.id = id;
		this.additionalPreviousName = additionalPreviousName;
		this.isDeleted = isDeleted;
		this.version = version;
	}
	
	public int getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getAdditionalPreviousName() {
		return this.additionalPreviousName;
	}

	public void setAdditionalPreviousName(String additionalPreviousName) {
		this.additionalPreviousName = additionalPreviousName;
	}

	public boolean getIsDeleted() {
		return this.isDeleted;
	}

	public void setIsDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	
	public int getVersion() {
		return this.version;
	}
	
	public void setVersion(int version) {
		this.version = version;
	}

	@Override
	public boolean equals(final Object obj) {
		return EqualsBuilder.reflectionEquals(obj, this);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
