package com.leadx.claimant.client.search;

import java.io.Serializable;
import java.util.Set;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class SearchRequestDto implements Serializable{

	private static final long serialVersionUID = -73597635753345L;

	private String surname;
	private String postcode;
	private String phone;
	private String email;
	private boolean productPpi;
	private boolean productPba;
	private boolean productStl;

	private String creditAgreementNumber;
	private Set<Integer> claimantIds;

	public static class Builder{
		private String surname;
		private String postcode;
		private String phone;
		private String email;
		private boolean productPpi;
		private boolean productPba;
		private boolean productStl;
		private String creditAgreementNumber;
		private Set<Integer> claimantIds;

		public Builder setSurname(String surname) {
			this.surname = surname;
			return this;
		}

		public Builder setPostcode(String postcode) {
			this.postcode = postcode;
			return this;
		}

		public Builder setPhone(String phone) {
			this.phone = phone;
			return this;
		}

		public Builder setEmail(String email) {
			this.email = email;
			return this;
		}

		public Builder setProductPpi(boolean productPpi) {
			this.productPpi = productPpi;
			return this;
		}

		public Builder setProductPba(boolean productPba) {
			this.productPba = productPba;
			return this;
		}

		public Builder setProductStl(boolean productStl) {
			this.productStl = productStl;
			return this;
		}

		public Builder setCreditAgreementNumber(String creditAgreementNumber) {
			this.creditAgreementNumber = creditAgreementNumber;
			return this;
		}

		public Builder setClaimantIds(Set<Integer> claimantIds) {
			this.claimantIds = claimantIds;
			return this;
		}

		public SearchRequestDto createSearchRequestDto() {
			return new SearchRequestDto(surname, postcode, phone, email, productPpi, productPba, productStl, creditAgreementNumber, claimantIds);
		}
	}

	public SearchRequestDto() {
	}

	public SearchRequestDto(String surname, String postcode, String phone, String email, boolean productPpi, boolean productPba, boolean productStl, String creditAgreementNumber, Set<Integer> claimantIds) {
		this.surname = surname;
		this.postcode = postcode;
		this.phone = phone;
		this.email = email;
		this.creditAgreementNumber = creditAgreementNumber;
		this.claimantIds = claimantIds;
		this.productPpi = productPpi;
		this.productPba = productPba;
		this.productStl = productStl;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isProductPpi() {
		return productPpi;
	}

	public void setProductPpi(boolean productPpi) {
		this.productPpi = productPpi;
	}

	public boolean isProductPba() {
		return productPba;
	}

	public void setProductPba(boolean productPba) {
		this.productPba = productPba;
	}

	public boolean isProductStl() {
		return productStl;
	}

	public void setProductStl(boolean productStl) {
		this.productStl = productStl;
	}

	public String getCreditAgreementNumber() {
		return creditAgreementNumber;
	}

	public void setCreditAgreementNumber(String creditAgreementNumber) {
		this.creditAgreementNumber = creditAgreementNumber;
	}

	public Set<Integer> getClaimantIds() {
		return claimantIds;
	}

	public void setClaimantIds(Set<Integer> claimantIds) {
		this.claimantIds = claimantIds;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean equals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

}
