package com.leadx.claimant.client;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect
public class SaveAddressDto implements Serializable {

	private static final long serialVersionUID = -5691222039638727253L;
	
	private int claimantId;
	private AddressDto addressDto;
	private int userId;
	private boolean markAsPafValidated;

	public SaveAddressDto() {
	}
	
	public SaveAddressDto(final int claimantId, final AddressDto addressDto, final int userId, final boolean markAsPafValidated) {
		this.claimantId = claimantId;
		this.addressDto = addressDto;
		this.userId = userId;
		this.markAsPafValidated = markAsPafValidated;
	}

	public int getClaimantId() {
		return this.claimantId;
	}

	public void setClaimantId(final int claimantId) {
		this.claimantId = claimantId;
	}

	public AddressDto getAddressDto() {
		return this.addressDto;
	}

	public void setAddressDto(final AddressDto addressDto) {
		this.addressDto = addressDto;
	}

	public int getUserId() {
		return this.userId;
	}

	public void setUserId(final int userId) {
		this.userId = userId;
	}

	public boolean getMarkAsPafValidated() {
		return this.markAsPafValidated;
	}

	public void setMarkAsPafValidated(final boolean markAsPafValidated) {
		this.markAsPafValidated = markAsPafValidated;
	}
}
