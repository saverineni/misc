package com.leadx.claimant.client;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect
public class SavePreviousAddressDto {
	
	private int claimantId;
	private int userId;
	
	private int currentAddressId;
	private int previousAddressId;
	
	private AddressDto newAddress;

	public int getClaimantId() {
		return this.claimantId;
	}

	public void setClaimantId(final int claimantId) {
		this.claimantId = claimantId;
	}

	public int getUserId() {
		return this.userId;
	}

	public void setUserId(final int userId) {
		this.userId = userId;
	}

	public int getCurrentAddressId() {
		return this.currentAddressId;
	}

	public void setCurrentAddressId(final int currentAddressId) {
		this.currentAddressId = currentAddressId;
	}

	public int getPreviousAddressId() {
		return this.previousAddressId;
	}

	public void setPreviousAddressId(final int previousAddressId) {
		this.previousAddressId = previousAddressId;
	}

	public AddressDto getNewAddress() {
		return this.newAddress;
	}

	public void setNewAddress(final AddressDto newAddress) {
		this.newAddress = newAddress;
	}
	
	
	
}