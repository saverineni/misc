package com.leadx.claimant.client.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Used to indicate that a wrapper method will be retried by the retry pointcut defined in
 * spring-claimant-client.xml. This retry uses the default RetryOperationsInterceptor, so expect
 * a failure to retry a maximum of three times with no exponential backoff.
 * 
 */
@Target({ ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface Retryable {
	//
}

