package com.leadx.claimant.client;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class ClaimantContactPreferenceDto {

	private Integer id;
	private int claimantId;
	private boolean telephoneOptIn;
	private boolean emailOptIn;
	private boolean smsOptIn;
	private boolean marketingMailingOptIn;
	private boolean cancellation;
	private int userIdUpdated;
	private int version;

	public ClaimantContactPreferenceDto(Integer id, int claimantId, boolean telephoneOptIn, boolean emailOptIn, boolean smsOptIn,
			boolean marketingMailingOptIn, boolean cancellation, int userIdUpdated, int version) {
		this.id = id;
		this.claimantId = claimantId;
		this.telephoneOptIn = telephoneOptIn;
		this.emailOptIn = emailOptIn;
		this.smsOptIn = smsOptIn;
		this.marketingMailingOptIn = marketingMailingOptIn;
		this.cancellation = cancellation;
		this.userIdUpdated = userIdUpdated;
		this.version = version;
	}

	public ClaimantContactPreferenceDto() {	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public int getClaimantId() {
		return claimantId;
	}

	public void setClaimantId(int claimantId) {
		this.claimantId = claimantId;
	}

	public boolean getTelephoneOptIn() {
		return telephoneOptIn;
	}

	public void setTelephoneOptIn(boolean telephoneOptIn) {
		this.telephoneOptIn = telephoneOptIn;
	}

	public boolean getEmailOptIn() {
		return emailOptIn;
	}

	public void setEmailOptIn(boolean emailOptIn) {
		this.emailOptIn = emailOptIn;
	}

	public boolean getSmsOptIn() {
		return smsOptIn;
	}

	public void setSmsOptIn(boolean smsOptIn) {
		this.smsOptIn = smsOptIn;
	}

	public boolean getMarketingMailingOptIn() {
		return marketingMailingOptIn;
	}

	public void setMarketingMailingOptIn(boolean marketingMailingOptIn) {
		this.marketingMailingOptIn = marketingMailingOptIn;
	}

	public boolean getCancellation() {
		return cancellation;
	}

	public void setCancellation(boolean cancellation) {
		this.cancellation = cancellation;
	}

	public int getUserIdUpdated() {
		return userIdUpdated;
	}

	public void setUserIdUpdated(int userIdUpdated) {
		this.userIdUpdated = userIdUpdated;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public boolean equals(final Object o) {
		return EqualsBuilder.reflectionEquals(this, o);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	public static class Builder {

		private Integer id;
		private int claimantId;
		private boolean telephoneOptIn;
		private boolean emailOptIn;
		private boolean smsOptIn;
		private boolean marketingMailingOptIn;
		private boolean cancellation;
		private int userIdUpdated;
		private int version;

		public Builder setId(Integer id) {
			this.id = id;
			return this;
		}

		public Builder setClaimantId(int claimantId) {
			this.claimantId = claimantId;
			return this;
		}

		public Builder setTelephoneOptIn(boolean telephoneOptIn) {
			this.telephoneOptIn = telephoneOptIn;
			return this;
		}

		public Builder setEmailOptIn(boolean emailOptIn) {
			this.emailOptIn = emailOptIn;
			return this;
		}

		public Builder setSmsOptIn(boolean smsOptIn) {
			this.smsOptIn = smsOptIn;
			return this;
		}

		public Builder setMarketingMailingOptIn(boolean marketingMailingOptIn) {
			this.marketingMailingOptIn = marketingMailingOptIn;
			return this;
		}

		public Builder setCancellation(boolean cancellation) {
			this.cancellation = cancellation;
			return this;
		}

		public Builder setUserIdUpdated(int userIdUpdated) {
			this.userIdUpdated = userIdUpdated;
			return this;
		}

		public Builder setVersion(int version) {
			this.version = version;
			return this;
		}

		public Builder allTrue() {
			this.telephoneOptIn = true;
			this.emailOptIn = true;
			this.smsOptIn = true;
			this.marketingMailingOptIn = true;
			this.cancellation = true;
			return this;
		}

		public ClaimantContactPreferenceDto createClaimantContactPreferenceDto() {
			return new ClaimantContactPreferenceDto(id, claimantId, telephoneOptIn, emailOptIn, smsOptIn, marketingMailingOptIn,
					cancellation, userIdUpdated, version);
		}
	}
}
