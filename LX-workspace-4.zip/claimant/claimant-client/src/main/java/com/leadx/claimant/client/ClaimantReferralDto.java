package com.leadx.claimant.client;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect
public class ClaimantReferralDto implements Serializable{
	private static final long serialVersionUID = -3956643185724548167L;

	private int id;
	private int productTypeId;
	private int referrerClaimantId;
	private int referralClaimantId;
	private String createdDateTime ;
	private int createdByAgentId;
	private int diallerReferenceId;
	private String referrerClaimantName;
	private String createdByAgentName;

	public ClaimantReferralDto(final int id, final int productTypeId, final int referrerClaimantId, final int referralClaimantId, final int createdByAgentId, final int diallerReferenceId) {
		this.id = id;
		this.productTypeId = productTypeId;
		this.referrerClaimantId = referrerClaimantId;
		this.referralClaimantId = referralClaimantId;
		this.createdDateTime = null;
		this.createdByAgentId = createdByAgentId;
		this.diallerReferenceId = diallerReferenceId;
	}

	/** Created datetime is generated automatically by the service so external callers shouldn't need to use this constructor */
	public ClaimantReferralDto(final int id, final int productTypeId, final int referrerClaimantId, final int referralClaimantId, final String createdDateTime, final int createdByAgentId, final int diallerReferenceId) {
		this.id = id;
		this.productTypeId = productTypeId;
		this.referrerClaimantId = referrerClaimantId;
		this.referralClaimantId = referralClaimantId;
		this.createdDateTime = createdDateTime;
		this.createdByAgentId = createdByAgentId;
		this.diallerReferenceId = diallerReferenceId;
	}

	public ClaimantReferralDto() {
	}

	public int getId() {
		return this.id;
	}

	public int getProductTypeId() {
		return this.productTypeId;
	}

	public int getReferrerClaimantId() {
		return this.referrerClaimantId;
	}

	public int getReferralClaimantId() {
		return this.referralClaimantId;
	}

	public String getCreatedDateTime() {
		return this.createdDateTime;
	}

	public int getCreatedByAgentId() {
		return this.createdByAgentId;
	}

	public int getDiallerReferenceId() {
		return this.diallerReferenceId;
	}
	
	public String getReferrerClaimantName() {
		return this.referrerClaimantName;
	}
	
	public void setReferrerClaimantName(final String referrerClaimantName) {
		this.referrerClaimantName = referrerClaimantName;
	}
	
	public String getCreatedByAgentName() {
		return this.createdByAgentName;
	}

	public void setCreatedByAgentName(final String createdByAgentName) {
		this.createdByAgentName = createdByAgentName;
	}
}
