package com.leadx.claimant.client;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect
public class AssessmentDto implements Serializable {

	private static final long serialVersionUID = 4022536363018163387L;

	private int claimantId;

	private LeadTypeDto leadType;

	private ClaimantDto claimant;
	
	private AddressDto address;
	
	private List<PreviousAddressDto> previousAddresses;
	
	private ClaimantReferralDto claimantReferralDto;
	
	private ClaimantBrandingDto claimantBranding;

	private ClaimantContactPreferenceDto claimantContactPreference;
	
	private boolean locked = false;
	private boolean claimantNotFound = false;
	
	public AssessmentDto() {}
	
	public AssessmentDto(final LeadTypeDto leadType, final ClaimantDto claimantDto, final AddressDto addressDto, final List<PreviousAddressDto> previousAddresses,
			final ClaimantReferralDto claimantReferralDto, final ClaimantBrandingDto claimantBranding,
			final ClaimantContactPreferenceDto claimantContactPreference, final boolean locked, final boolean claimantNotFound) {
		this.leadType = leadType;
		this.claimant = claimantDto;
		this.address = addressDto;
		this.previousAddresses = previousAddresses;
		this.claimantReferralDto = claimantReferralDto;
		this.claimantBranding = claimantBranding;
		this.claimantContactPreference = claimantContactPreference;
		this.locked = locked;
		this.claimantNotFound = claimantNotFound;
	}
	
	public AssessmentDto(final LeadTypeDto leadType, final ClaimantDto claimantDto, final AddressDto addressDto, final ClaimantReferralDto claimantReferralDto,
			final ClaimantBrandingDto claimantBranding, final boolean locked, final boolean claimantNotFound) {
		this.leadType = leadType;
		this.claimant = claimantDto;
		this.address = addressDto;
		this.previousAddresses = null;
		this.claimantReferralDto = claimantReferralDto;
		this.claimantBranding = claimantBranding;
		this.locked = locked;
		this.claimantNotFound = claimantNotFound;
	}
	
	public int getClaimantId() {
		return this.claimantId;
	}

	public void setClaimantId(final int claimantId) {
		this.claimantId = claimantId;
	}

	public LeadTypeDto getLeadType() {
		return leadType;
	}

	public void setLeadType(LeadTypeDto leadType) {
		this.leadType = leadType;
	}

	public ClaimantDto getClaimant() {
		return this.claimant;
	}

	public AddressDto getAddress() {
		return this.address;
	}

	public List<PreviousAddressDto> getPreviousAddresses() {
		return this.previousAddresses;
	}

	public ClaimantReferralDto getClaimantReferralDto() {
		return this.claimantReferralDto;
	}

	public ClaimantBrandingDto getClaimantBranding() {
		return this.claimantBranding;
	}

	public ClaimantContactPreferenceDto getClaimantContactPreference() {
		return claimantContactPreference;
	}

	public void setClaimantContactPreferences(ClaimantContactPreferenceDto claimantContactPreference) {
		this.claimantContactPreference = claimantContactPreference;
	}

	public boolean getLocked() {
		return this.locked;
	}

	public void setLocked(boolean locked) {
		this.locked = locked;
	}

	public boolean getClaimantNotFound() {
		return this.claimantNotFound;
	}
	
	public void setClaimantReferralDto(ClaimantReferralDto claimantReferralDto) {
		this.claimantReferralDto = claimantReferralDto;
	}
	
	public void setClaimantNotFound(boolean claimantNotFound) {
		this.claimantNotFound = claimantNotFound;
	}
	
	public static AssessmentDto lockedClaimant(final int claimantId) {
		final AssessmentDto dto = new AssessmentDto();
		dto.setClaimantId(claimantId);
		dto.setLocked(true);
		return dto;
	}

	public static AssessmentDto claimantNotFound(final int claimantId) {
		final AssessmentDto dto = new AssessmentDto();
		dto.setClaimantId(claimantId);
		dto.setClaimantNotFound(true);
		return dto;
	}
	
}
