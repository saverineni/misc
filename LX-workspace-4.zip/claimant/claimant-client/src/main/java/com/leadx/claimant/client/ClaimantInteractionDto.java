package com.leadx.claimant.client;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@JsonAutoDetect
public class ClaimantInteractionDto implements Serializable {

	private static final long serialVersionUID = -4863169032703708196L;

	private Integer id;
	private Integer claimantId;
	private Integer productId;
	private Integer userId;
	private String agentName;
	private String interactionDateTime;
	private String content;
	private String source;
	private Integer version;

	public ClaimantInteractionDto() {
	}

	public ClaimantInteractionDto(final Integer id, final Integer claimantId, final Integer productId, Integer userId, final String agentName, final String interactionDateTime,
								  final String content, final String source) {
		this(id, claimantId, productId, userId, agentName, interactionDateTime, content, source, 0);
	}

	public ClaimantInteractionDto(final Integer id, final Integer claimantId, final Integer productId, Integer userId, final String agentName, final String interactionDateTime,
			final String content, final String source, final Integer version) {
		this.id = id;
		this.claimantId = claimantId;
		this.productId = productId;
		this.userId = userId;
		this.agentName = agentName;
		this.interactionDateTime = interactionDateTime;
		this.content = content;
		this.source = source;
		this.version = version;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getClaimantId() {
		return claimantId;
	}

	public void setClaimantId(Integer claimantId) {
		this.claimantId = claimantId;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getInteractionDateTime() {
		return interactionDateTime;
	}

	public void setInteractionDateTime(String interactionDateTime) {
		this.interactionDateTime = interactionDateTime;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	@Override public boolean equals(final Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}

	@Override public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

}
