package com.leadx.claimant.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.leadx.lib.utl.json.JsonUtils;

@Component
public class ExternalServiceWrapper extends ServiceWrapper {

	private static final Logger LOG = LoggerFactory.getLogger(ExternalServiceWrapper.class);

	private static final int USER_ID = 3388;

	public void updateAddress(final int claimantId, final AddressDto addressDto) {
		final SaveAddressDto updatedAddressDto = new SaveAddressDto(claimantId, addressDto, USER_ID, true);
		
		final ResponseEntity<String> response = 
				this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "/external/address/update"), JsonUtils.serialize(updatedAddressDto, true), String.class);

		if(response.getStatusCode() != HttpStatus.CREATED) {
			LOG.error("Failed to update address from an external source for claimant id {}, address {}, http error {}", claimantId, addressDto, response.getStatusCode());
			throw new RuntimeException("Failed to update address: " + response.getStatusCode());
		}
	}

	public boolean authenticate(final int claimantId, final String password) {
		final ClaimantAuthenticationDto claimantAuthenticationDto = new ClaimantAuthenticationDto(claimantId, password);

		final ResponseEntity<String> response =
				this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "/external/authenticate"), JsonUtils.serialize(claimantAuthenticationDto, true), String.class);

		return response.getStatusCode().equals(HttpStatus.OK);
	}

	public ClaimantDto getClaimantName(final int claimantId) {
		final ResponseEntity<ClaimantDto> response =
				this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/external/claimant/name/" + claimantId), ClaimantDto.class);

		return response.getBody();
	}

	public AddressDto getClaimantAddress(final int claimantId) {
		final ResponseEntity<AddressDto> response =
				this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/external/claimant/address/" + claimantId), AddressDto.class);

		return response.getBody();
	}

	public void correctAddress(final int claimantId) {
		this.restOperations.postForLocation(generateUri(this.protocol, this.host, this.port, "/external/claimant/%s/correctAddress", claimantId), null);
	}
}
