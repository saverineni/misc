package com.leadx.claimant.client;

public enum MethodOfContact {
	telephone, post, email, esignature
}
