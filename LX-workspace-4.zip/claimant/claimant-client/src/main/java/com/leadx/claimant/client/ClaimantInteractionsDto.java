package com.leadx.claimant.client;

import com.leadx.claimant.client.ClaimantInteractionDto;

import java.util.List;

public class ClaimantInteractionsDto {

	private List<ClaimantInteractionDto> notes;
	private List<ClaimantInteractionDto> events;
	
	public ClaimantInteractionsDto() { }
	
	public ClaimantInteractionsDto(final List<ClaimantInteractionDto> notes, final List<ClaimantInteractionDto> events) {
		this.notes = notes;
		this.events = events;
	}

	public List<ClaimantInteractionDto> getNotes() {
		return this.notes;
	}

	public List<ClaimantInteractionDto> getEvents() {
		return this.events;
	}
}
