package com.leadx.claimant.client.reference;

public class IvaCompanyDto extends DmIvaCompanyDto {

	public IvaCompanyDto() {
		super();
	}

	public IvaCompanyDto(final Integer id, final String name, final String departmentName, final String organisationName, final String subBuildingName, final String buildingName, final String buildingNumber,
			final String dependentThoroughfare, final String thoroughfare, final String doubleDependentLocality, final String dependentLocality, final String town, final String county, final String postcode) {
		
		super(id, name, departmentName, organisationName, subBuildingName, buildingName, buildingNumber, dependentThoroughfare, thoroughfare, doubleDependentLocality, dependentLocality, town, county, postcode);
	}
}