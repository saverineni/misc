package com.leadx.claimant.client;

public enum CallType {

	ASSESSMENT(1, "Assessment"),

	CHASE(2, "Chase"),

	CASH_COLLECTION(3, "Cash Collection"),

	CUSTOMER_SERVICE(4, "Customer Service"),

	INCOMPLETES(5, "Incompletes"),

	FOS_TO_CLAIMANT(6, "FOS To Claimant"),

	DSAR_LOA(7, "DSAR LOA"),

	CLAIMANT_INFORMATION_REQUIRED(8, "Claimant Information Required"),

	DSAR_MIR(9, "DSAR More Info Required"),

	LENDER_QUESTIONNAIRE_PPI_CHECK(10, "Lender Questionnaire PPI Check"),

	REMEDIATION(11, "Remediation"),

	LENDER_QUESTIONNAIRE_BAU(12, "Lender Questionnaire BAU"),

	LENDER_QUESTIONNAIRE_LOA_REQUIRED(13, "Lender Questionnaire LOA Required"),
	
	LENDER_QUESTIONNAIRE_INFORMATION_REQUIRED(14, "Lender Questionnaire Information Required"),

	PLEVIN_COURTESY_CALL(15, "Plevin Courtesy Call"),

	FSCS_INCOMPLETE(16, "FSCS Incomplete"),

	PLR_CHASE_LOA(17, "PLR Chase LOA"),

	PLR_INCOMPLETE(18, "PLR Incomplete");
	
	private int id;
	private String name;

	CallType(final int id, final String name) {
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}

	public static CallType getById(final int id) {
		for (final CallType callType : values()) {
			if (callType.getId() == id) {
				return callType;
			}
		}
		return null;
	}

	public static CallType getByName(final String name) {
		for (final CallType callType : values()) {
			if (callType.getName().equals(name)) {
				return callType;
			}
		}
		return null;
	}

}
