package com.leadx.claimant.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.leadx.claimant.client.annotations.Retryable;

/** Wrapper around the call allocation group service. */
@Component
public class CallAllocationGroupServiceWrapper extends ServiceWrapper {

	private static final Logger LOG = LoggerFactory.getLogger(CallLogServiceWrapper.class);

	@Retryable
	public Boolean cancelCallAllocation(final CancelCallRequestDto cancelCallRequestDto) throws Exception {
		final ResponseEntity<CancelCallRequestDto> response = this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "/callAllocation/cancel/"), cancelCallRequestDto, CancelCallRequestDto.class);
		if (response.getStatusCode() != HttpStatus.OK) {
			LOG.warn("Failed to cancel call allocation for claimant: {}, http error: {}", cancelCallRequestDto.getClaimantId(), response.getStatusCode());
			return false;
		}
		LOG.info("Cancelled Call Allocation for claimant: {}", cancelCallRequestDto.getClaimantId());
		return true;
	}

}