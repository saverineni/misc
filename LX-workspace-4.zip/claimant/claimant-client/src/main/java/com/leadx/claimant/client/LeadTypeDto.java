package com.leadx.claimant.client;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class LeadTypeDto {

	private int id;
	private String name;

	public LeadTypeDto() {}

	public LeadTypeDto(final int id, final String name) {
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}


	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

	@Override
	public boolean equals(final Object other) {
		return deepEquals(other);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}
}
