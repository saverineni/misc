package com.leadx.claimant.client;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class ClaimantUnpresentedChequeDto implements Serializable{

	private static final long serialVersionUID = 1071044923515355907L;

	private Integer id;
	private int claimantId;
	private String dateChequeIssued;
	private String amount;
	private Integer version;

	public ClaimantUnpresentedChequeDto() {

	}

	public ClaimantUnpresentedChequeDto(final Integer id, final int claimantId, final String dateChequeIssued, final String amount, final Integer version) {
		this.id = id;
		this.claimantId = claimantId;
		this.dateChequeIssued = dateChequeIssued;
		this.amount = amount;
		this.version = version;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public int getClaimantId() {
		return claimantId;
	}

	public void setClaimantId(int claimantId) {
		this.claimantId = claimantId;
	}

	public String getDateChequeIssued() {
		return dateChequeIssued;
	}

	public void setDateChequeIssued(String dateChequeIssued) {
		this.dateChequeIssued = dateChequeIssued;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	@Override
	public boolean equals(final Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
