package com.leadx.claimant.client;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.leadx.claimant.client.search.SearchRequestDto;
import com.leadx.claimant.client.search.SearchResultClaimantDto;


/** Wrapper around the claimant search service. */
@Component
public class ClaimantSearchServiceWrapper extends ServiceWrapper{
	private static final Logger LOG = LoggerFactory.getLogger(ClaimantSearchServiceWrapper.class);

	public List<SearchResultClaimantDto> search(final SearchRequestDto searchRequestDto) {
		final ResponseEntity<String> response = this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/search"), searchRequestDto, String.class);
		if (response.getStatusCode() != HttpStatus.OK) {
			LOG.error("Failed to search claimants, http error: {}", response.getStatusCode());
		}

		LOG.info("Retrieved search results");
		return searchResultDtosFromResponse(response);
	}

	private static List<SearchResultClaimantDto> searchResultDtosFromResponse(final ResponseEntity<String> response) {
		final ObjectMapper mapper = new ObjectMapper();

		try {
			return mapper.readValue(response.getBody(), new TypeReference<List<SearchResultClaimantDto>>() { });
		}catch (final Exception exception) {
			LOG.error("Failed to map to SearchResultClaimantDto object from response: " + response.getBody());
			throw new RuntimeException(exception);
		}
	}
}
