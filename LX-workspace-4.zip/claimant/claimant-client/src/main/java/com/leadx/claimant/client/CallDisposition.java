package com.leadx.claimant.client;

public enum CallDisposition {

	ANSWERPHONE(1, "Answerphone", false),

	NO_DMC__CALLBACK(16, "No DMC - Callback", false),

	ALREADY_ARRANGED(4, "Already Arranged", true),

	NOT_INTERESTED(5, "Not Interested", true),

	SUPPRESS(6, "Suppress", true),

	DOES_NOT_QUALIFY(7, "Does not Qualify", true),

	INCORRECT_DETAILS(8, "Incorrect Details", true),

	APPLICATION_TAKEN(9, "Application Taken", true),

	CALLBACK(10, "Callback", false),

	REQUIRES_CHASE(12, "Requires Chase", false),

	CHASE_UNSUCCESSFUL(13, "Chase Unsuccessful", false),

	FORM_RETURNED(14, "Form Returned", false),

	FORM_NOT_RECIEVED(15, "Form Not Received", false),

	DUPLICATE_ASSESSMENT(17, "Duplicate Assessment", false),

	UNABLE_TO_OPEN_CLAIMANT(18, "Unable to Open Claimant", false),

	CLAIMANT_LOCKED(19, "Claimant Locked", false),

	CASH_COLLECTION_CLAIMANT_LOCKED(22, "Cash Collection Claimant Locked", false),

	CASH_COLLECTION_UNABLE_TO_OPEN_CLAIMANT(23, "Cash Collection Unable to Open Claimant", false),

	CASH_COLLECTION_ANSWERPHONE(24, "Cash Collection Answerphone", false),

	CASH_COLLECTION_CALLER_HUNG_UP(25, "Cash Collection Caller Hung Up", false),

	CASH_COLLECTION_CALLBACK(26, "Cash Collection Callback", false),

	CASH_COLLECTION_NO_DMC_CALLBACK(27, "Cash Collection No DMC - Callback", false),

	CASH_COLLECTION_PAYMENTS_COMPLETE(28, "Cash Collection Payments Complete ", true),

	CASH_COLLECTION_PAYMENT_PLAN_CHANGED(34, "Cash Collection Payment Plan Changed", true),

	CASH_COLLECTION_CUSTOMER_DETAILS_NOT_FOUND(36, "Cash Collection Customer Details Not Found", true),

	CASH_COLLECTION_ISSUE_RAISED(37, "Cash Collection Issue Raised", false),

	CASH_COLLECTION_NO_FOLLOWUP_REQUIRED(38, "Cash Collection No Follow-up Required", false),

	CALLER_HUNG_UP(39, "Caller Hung Up", false),

	FORM_UPDATED(40, "Form Updated", false),

	CUSTOMER_SERVICE_COMPLETE(41, "Customer Service Complete", true),

	CASH_COLLECTION_CALL_COMPLETE(42, "Cash Collection Call Complete", true),

	CHASE_CALLBACK(43, "Chase Callback", false),

	CHASE_CALL_COMPLETE(44, "Chase Call Complete", true),

	INCOMPLETES_CALLBACK(45, "Incompletes Callback", true),

	INCOMPLETES_NO_DMC_CALLBACK(46, "Incompletes No DMC - Callback", true),

	INCOMPLETES_ANSWERPHONE(47, "Incompletes Answerphone", false),

	INCOMPLETES_CALLER_HUNG_UP(48, "Incompletes Caller Hung Up", false),

	INCOMPLETES_CALL_COMPLETE(49, "Incompletes Call Complete", true),

	FOS_TO_CLAIMANT_CALLBACK(50, "FOS To Claimant Callback", true),

	FOS_TO_CLAIMANT_NO_DMC_CALLBACK(51, "FOS To Claimant No DMC - Callback", true),

	FOS_TO_CLAIMANT_ANSWERPHONE(52, "FOS To Claimant Answerphone", false),

	FOS_TO_CLAIMANT_CALLER_HUNG_UP(53, "FOS To Claimant Caller Hung Up", false),

	FOS_TO_CLAIMANT_CALL_COMPLETE(54, "FOS To Claimant Call Complete", true),

	DSAR_LOA_CALLBACK(55, "DSAR LOA Callback", true),

	DSAR_LOA_NO_DMC_CALLBACK(56, "DSAR LOA No DMC - Callback", true),

	DSAR_LOA_ANSWERPHONE(57, "DSAR LOA Answerphone", false),

	DSAR_LOA_CALLER_HUNG_UP(58, "DSAR LOA Caller Hung Up", false),

	DSAR_LOA_CALL_COMPLETE(59, "DSAR LOA Call Complete", true),

	DSAR_LOA_NOT_PROCEEDING(60, "DSAR LOA Not Proceeding", true),

	CLAIMANT_INFORMATION_REQUIRED_CALLBACK(61, "Claimant Information Required Callback", true),

	CLAIMANT_INFORMATION_REQUIRED_NO_DMC_CALLBACK(62, "Claimant Information Required No DMC - Callback", true),

	CLAIMANT_INFORMATION_REQUIRED_ANSWERPHONE(63, "Claimant Information Required Answerphone", false),

	CLAIMANT_INFORMATION_REQUIRED_CALLER_HUNG_UP(64, "Claimant Information Required Caller Hung Up", false),

	CLAIMANT_INFORMATION_REQUIRED_CALL_COMPLETE(65, "Claimant Information Required Call Complete", true),

	DSAR_MIR_CALLBACK(66, "DSAR MIR Callback", true),

	DSAR_MIR_NO_DMC_CALLBACK(67, "DSAR MIR No DMC - Callback", true),

	DSAR_MIR_ANSWERPHONE(68, "DSAR MIR Answerphone", false),

	DSAR_MIR_CALLER_HUNG_UP(69, "DSAR MIR Caller Hung Up", false),

	DSAR_MIR_CALL_COMPLETE(70, "DSAR MIR Call Complete", true),

	DISCONNECTED(71, "Disconnected", true),

	AUTOMATED_MESSAGE(72, "Automated Message", true),

	ASSESSMENT_WRONG_DEPARTMENT(73, "Chase Wrong Department", true),

	_CHASE_CALLBACK(74, "Chase Call Back", false),

	_CHASE_NO_DMC_CALLBACK(75, "Chase No DMC Call back", false),

	_CHASE_CALLER_HUNG_UP(76, "Chase Caller Hung Up", false),

	_REFUSED_DPA(77, "Refused DPA", false),

	_CHASE_ANSWERPHONE(78, "Chase Answerphone", false),

	_CHASE_NPW_CLAIMANT(79, "Chase NPW Claimant", false),

	_CHASE_CALL_COMPLETE(80, "Chase Call Complete", false),

	_CHASE_CUSTOMER_NOT_FOUND(81, "Chase Customer Not Found", false),

	CHASE_WRONG_DEPARTMENT(82, "Chase Wrong Department", true),

	LENDER_QUESTIONNAIRE_PPI_CHECK_CALLBACK(83, "Lender Questionnaire PPI Check Callback", true),

	LENDER_QUESTIONNAIRE_PPI_CHECK_NO_DMC_CALLBACK(84, "Lender Questionnaire PPI Check No DMC - Callback", true),

	LENDER_QUESTIONNAIRE_PPI_CHECK_ANSWERPHONE(85, "Lender Questionnaire PPI Check Answerphone", false),

	LENDER_QUESTIONNAIRE_PPI_CHECK_CALLER_HUNG_UP(86, "Lender Questionnaire PPI Check Caller Hung Up", false),

	LENDER_QUESTIONNAIRE_PPI_CHECK_CALL_COMPLETE(87, "Lender Questionnaire PPI Check Call Complete", true),

	REMEDIATION_CALLBACK(88, "Remediation Callback", true),

	REMEDIATION_NO_DMC_CALLBACK(89, "Remediation No DMC - Callback", true),

	REMEDIATION_ANSWERPHONE(90, "Remediation Answerphone", false),

	REMEDIATION_CALLER_HUNG_UP(91, "Remediation Caller Hung Up", false),

	REMEDIATION_CALL_COMPLETE(92, "Remediation Call Complete", true),

	SILENT_LINE(93, "Silent Line", true),

	LENDER_QUESTIONNAIRE_BAU_CALLBACK(94, "Lender Questionnaire BAU Callback", false),

	LENDER_QUESTIONNAIRE_BAU_NO_DMC_CALLBACK(95, "Lender Questionnaire BAU No DMC - Callback", false),

	LENDER_QUESTIONNAIRE_BAU_ANSWERPHONE(96, "Lender Questionnaire BAU Answerphone", false),

	LENDER_QUESTIONNAIRE_BAU_CALLER_HUNG_UP(97, "Lender Questionnaire BAU Caller Hung Up", false),

	LENDER_QUESTIONNAIRE_BAU_CALL_COMPLETE(98, "Lender Questionnaire BAU Call Complete", true),

	LENDER_QUESTIONNAIRE_LOA_REQUIRED_CALLBACK(99, "Lender Questionnaire LOA Required Callback", false),

	LENDER_QUESTIONNAIRE_LOA_REQUIRED_NO_DMC_CALLBACK(100, "Lender Questionnaire LOA Required No DMC - Callback", false),

	LENDER_QUESTIONNAIRE_LOA_REQUIRED_ANSWERPHONE(101, "Lender Questionnaire LOA Required Answerphone", false),

	LENDER_QUESTIONNAIRE_LOA_REQUIRED_CALLER_HUNG_UP(102, "Lender Questionnaire LOA Required Caller Hung Up", false),

	LENDER_QUESTIONNAIRE_LOA_REQUIRED_CALL_COMPLETE(103, "Lender Questionnaire LOA Required Call Complete", true),

	CASH_COLLECTION_CALL_TRANSFERRED(104, "Cash Collection Call Transferred", false),

	INCOMPLETES_CALL_TRANSFERRED(105, "Incompletes Call Transferred", false),

	FOS_TO_CLAIMANT_CALL_TRANSFERRED(106, "FOS to Claimant Call Transferred", false),

	DSAR_LOA_CALL_TRANSFERRED(107, "DSAR LOA Call Transferred", false),

	CLAIMANT_INFORMATION_REQUIRED_CALL_TRANSFERRED(108, "Claimant Information Required Call Transferred", false),

	DSAR_MIR_CALL_TRANSFERRED(109, "DSAR MIR Call Transferred", false),

	CHASE_CALL_TRANSFERRED(110, "Chase Call Transferred", false),

	LENDER_QUESTIONNAIRE_PPI_CHECK_CALL_TRANSFERRED(111, "Lender Questionnaire PPI Check Call Transferred", false),

	REMEDIATION_CALL_TRANSFERRED(112, "Remediation Call Transferred", false),

	LENDER_QUESTIONNAIRE_BAU_CALL_TRANSFERRED(113, "Lender Questionnaire BAU Call Transferred", false),

	LENDER_QUESTIONNAIRE_LOA_CALL_TRANSFERRED(114, "Lender Questionnaire LOA Call Transferred", false),

	CASH_COLLECTION_WRONG_DEPARTMENT(115, "Cash Collection Wrong Department", false),

	INCOMPLETES_WRONG_DEPARTMENT(116, "Incompletes Wrong Department", false),

	FOS_TO_CLAIMANT_WRONG_DEPARTMENT(117, "FOS to Claimant Wrong Department", false),

	DSAR_LOA_WRONG_DEPARTMENT(118, "DSAR LOA Wrong Department", false),

	CLAIMANT_INFORMATION_REQUIRED_WRONG_DEPARTMENT(119, "Claimant Information Required Wrong Department", false),

	DSAR_MIR_WRONG_DEPARTMENT(120, "DSAR MIR Wrong Department", false),

	LENDER_QUESTIONNAIRE_PPI_CHECK_WRONG_DEPARTMENT(121, "Lender Questionnaire PPI Check Wrong Department", false),

	REMEDIATION_WRONG_DEPARTMENT(122, "Remediation Wrong Department", false),

	LENDER_QUESTIONNAIRE_BAU_WRONG_DEPARTMENT(123, "Lender Questionnaire BAU Wrong Department", false),

	LENDER_QUESTIONNAIRE_LOA_WRONG_DEPARTMENT(124, "Lender Questionnaire LOA Wrong Department", false),

	ASSESSMENT_CALL_TRANSFERRED(125, "Assessment Call Transferred", false),

	CUSTOMER_SERVICES_CALL_TRANSFERRED(126, "Customer Services Call Transferred", false),

	CUSTOMER_SERVICES_WRONG_DEPARTMENT(127, "Customer Services Wrong Department", false),
	
	LENDER_QUESTIONNAIRE_INFORMATION_REQUIRED_CALLBACK(128, "Lender Questionnaire Information Required Callback", false),
	
	LENDER_QUESTIONNAIRE_INFORMATION_REQUIRED_NO_DMC_CALLBACK(129, "Lender Questionnaire Information Required No DMC - Callback", false),
	
	LENDER_QUESTIONNAIRE_INFORMATION_REQUIRED_ANSWERPHONE(130, "Lender Questionnaire Information Required Answerphone", false),
	
	LENDER_QUESTIONNAIRE_INFORMATION_REQUIRED_CALLER_HUNG_UP(131, "Lender Questionnaire Information Required Caller Hung Up", false),
	
	LENDER_QUESTIONNAIRE_INFORMATION_REQUIRED_CALL_COMPLETE(132, "Lender Questionnaire Information Required Call Complete", false),
	
	LENDER_QUESTIONNAIRE_INFORMATION_REQUIRED_CALL_TRANSFERRED(133, "Lender Questionnaire Information Required Call Transferred", false),
	
	LENDER_QUESTIONNAIRE_INFORMATION_REQUIRED_WRONG_DEPARTMENT(134, "Lender Questionnaire Information Required Wrong Department", false),

	FAILED_DPA(135, "Failed DPA", false),

	PLEVIN_CHASE_CALLBACK(136, "Plevin chase Callback", false),

	PLEVIN_CHASE_NO_DMC_CALLBACK(137, "Plevin chase No DMC - Callback", false),

	PLEVIN_CHASE_ANSWERPHONE(138, "Plevin chase Answerphone", false),

	PLEVIN_CHASE_CALLER_HUNG_UP(139, "Plevin chase Caller Hung Up", false),

	PLEVIN_CHASE_CALL_COMPLETE(140, "Plevin chase Call Complete", false),

	PLEVIN_CHASE_CALL_TRANSFERRED(141, "Plevin chase Call Transferred", false),

	PLEVIN_CHASE_WRONG_DEPARTMENT(142, "Plevin chase Wrong Department", false),

	PLEVIN_LEGAL_CALLBACK(143, "Plevin legal Callback", false),

	PLEVIN_LEGAL_NO_DMC_CALLBACK(144, "Plevin legal No DMC - Callback", false),

	PLEVIN_LEGAL_ANSWERPHONE(145, "Plevin legal Answerphone", false),

	PLEVIN_LEGAL_CALLER_HUNG_UP(146, "Plevin legal Caller Hung Up", false),

	PLEVIN_LEGAL_CALL_COMPLETE(147, "Plevin legal Call Complete", false),

	PLEVIN_LEGAL_CALL_TRANSFERRED(148, "Plevin legal Call Transferred", false),

	PLEVIN_LEGAL_WRONG_DEPARTMENT(149, "Plevin legal Wrong Department", false),

	PLEVIN_COURTESY_CALL_CALLBACK(150, "Plevin courtesy Callback", false),

	PLEVIN_COURTESY_CALL_NO_DMC_CALLBACK(151, "Plevin courtesy No DMC - Callback", false),

	PLEVIN_COURTESY_CALL_ANSWERPHONE(152, "Plevin courtesy Answerphone", false),

	PLEVIN_COURTESY_CALL_CALLER_HUNG_UP(153, "Plevin courtesy Caller Hung Up", false),

	PLEVIN_COURTESY_CALL_CALL_COMPLETE(154, "Plevin courtesy Call Complete", false),

	PLEVIN_COURTESY_CALL_CALL_TRANSFERRED(155, "Plevin courtesy Call Transferred", false),

	PLEVIN_COURTESY_CALL_WRONG_DEPARTMENT(156, "Plevin courtesy Wrong Department", false),

	PLEVIN_ELIGIBILITY_PACK_INCOMPLETES_CALLBACK(157, "Plevin eligibility pack incompletes Callback", false),

	PLEVIN_ELIGIBILITY_PACK_INCOMPLETES_NO_DMC_CALLBACK(158, "Plevin eligibility pack incompletes No DMC - Callback", false),

	PLEVIN_ELIGIBILITY_PACK_INCOMPLETES_ANSWERPHONE(159, "Plevin eligibility pack incompletes Answerphone", false),

	PLEVIN_ELIGIBILITY_PACK_INCOMPLETES_CALLER_HUNG_UP(160, "Plevin eligibility pack incompletes Caller Hung Up", false),

	PLEVIN_ELIGIBILITY_PACK_INCOMPLETES_CALL_COMPLETE(161, "Plevin eligibility pack incompletes Call Complete", false),

	PLEVIN_ELIGIBILITY_PACK_INCOMPLETES_CALL_TRANSFERRED(162, "Plevin eligibility pack incompletes Call Transferred", false),

	PLEVIN_ELIGIBILITY_PACK_INCOMPLETES_WRONG_DEPARTMENT(163, "Plevin eligibility pack incompletes Wrong Department", false),

	PLEVIN_LEGAL_PACK_INCOMPLETES_CALLBACK(164, "Plevin legal pack incompletes No DMC - Callback", false),

	PLEVIN_LEGAL_PACK_INCOMPLETES_NO_DMC_CALLBACK(165, "Plevin legal pack incompletes No DMC - Callback", false),

	PLEVIN_LEGAL_PACK_INCOMPLETES_ANSWERPHONE(166, "Plevin legal pack incompletes Answerphone", false),

	PLEVIN_LEGAL_PACK_INCOMPLETES_CALLER_HUNG_UP(167, "Plevin legal pack incompletes Caller Hung Up", false),

	PLEVIN_LEGAL_PACK_INCOMPLETES_CALL_COMPLETE(168, "Plevin legal pack incompletes Call Complete", false),

	PLEVIN_LEGAL_PACK_INCOMPLETES_CALL_TRANSFERRED(169, "Plevin legal pack incompletes Call Transferred", false),

	PLEVIN_LEGAL_PACK_INCOMPLETES_WRONG_DEPARTMENT(170, "Plevin legal pack incompletes Wrong Department", false),

	FSCS_INCOMPLETE_CALLBACK(171, "FSCS incomplete Callback", false),

	FSCS_INCOMPLETE_NO_DMC_CALLBACK(172, "FSCS incomplete No DMC - Callback", false),

	FSCS_INCOMPLETE_ANSWERPHONE(173, "FSCS incomplete Answerphone", false),

	FSCS_INCOMPLETE_CALLER_HUNG_UP(174, "FSCS incomplete Caller Hung Up", false),

	FSCS_INCOMPLETE_CALL_COMPLETE(175, "FSCS incomplete Call Complete", false),

	FSCS_INCOMPLETE_CALL_TRANSFERRED(176, "FSCS incomplete Call Transferred", false),

	FSCS_INCOMPLETE_WRONG_DEPARTMENT(177, "FSCS incomplete Wrong Department", false),

	PLR_CHASE_LOA_CALLBACK(178, "PLR Chase LOA Callback", false),

	PLR_CHASE_LOA_NO_DMC_CALLBACK(179, "PLR Chase LOA No DMC Callback", false),

	PLR_CHASE_LOA_ANSWERPHONE(180, "PLR Chase LOA Answerphone", false),

	PLR_CHASE_LOA_CALLER_HUNG_UP(181, "PLR Chase LOA Caller Hung Up", false),

	PLR_CHASE_LOA_CALL_COMPLETE(182, "PLR Chase LOA Call Complete", false),

	PLR_CHASE_LOA_CALL_TRANSFERRED(183, "PLR Chase LOA Call Transferred", false),

	PLR_CHASE_LOA_WRONG_DEPARTMENT(184, "PLR Chase LOA Wrong Department", false),

	PLR_INCOMPLETE_CALLBACK(185, "PLR Incomplete Callback", false),

	PLR_INCOMPLETE_NO_DMC_CALLBACK(186, "PLR Incomplete No DMC Callback", false),

	PLR_INCOMPLETE_ANSWERPHONE(187, "PLR Incomplete Answerphone", false),

	PLR_INCOMPLETE_CALLER_HUNG_UP(188, "PLR Incomplete Caller Hung Up", false),

	PLR_INCOMPLETE_CALL_COMPLETE(189, "PLR Incomplete Call Complete", false),

	PLR_INCOMPLETE_CALL_TRANSFERRED(190, "PLR Incomplete Call Transferred", false),

	PLR_INCOMPLETE_WRONG_DEPARTMENT(191, "PLR Incomplete Wrong Department", false);

	private int id;
	private String name;
	private boolean ceaseContact;

	CallDisposition(final int id, final String name, final boolean ceaseContact) {
		this.id = id;
		this.name = name;
		this.ceaseContact = ceaseContact;
	}

	public int getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}

	public boolean shouldCeaseContact() {
		return this.ceaseContact;
	}

	public boolean shouldStopContactFlow() {
		return !this.name.contains("No DMC") && !this.name.contains("Answerphone");
	}

	public boolean requiresClaimantSuppression() {
		return equals(SUPPRESS);
	}

	public static CallDisposition getById(final int id) {
		for (final CallDisposition disposition : values()) {
			if (disposition.getId() == id) {
				return disposition;
			}
		}
		return null;
	}

	public static CallDisposition getByName(final String name) {
		for (final CallDisposition disposition : values()) {
			if (disposition.getName().equals(name)) {
				return disposition;
			}
		}
		return null;
	}

	public boolean isCallback() {
		switch(this){
			case CALLBACK:
			case NO_DMC__CALLBACK:
			case _CHASE_CALLBACK:
			case _CHASE_NO_DMC_CALLBACK:
			case LENDER_QUESTIONNAIRE_BAU_CALLBACK:
			case LENDER_QUESTIONNAIRE_BAU_NO_DMC_CALLBACK:
			case LENDER_QUESTIONNAIRE_LOA_REQUIRED_CALLBACK:
			case LENDER_QUESTIONNAIRE_LOA_REQUIRED_NO_DMC_CALLBACK:
			case LENDER_QUESTIONNAIRE_INFORMATION_REQUIRED_CALLBACK:
			case LENDER_QUESTIONNAIRE_INFORMATION_REQUIRED_NO_DMC_CALLBACK:
				return true;
			default:
				return false;
		}
	}
}
