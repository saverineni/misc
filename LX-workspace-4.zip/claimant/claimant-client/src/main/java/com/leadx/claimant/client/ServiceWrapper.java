package com.leadx.claimant.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.client.RestOperations;

class ServiceWrapper {

	@Value("${claimant.client.protocol}")
	String protocol;

	@Value("${claimant.client.host}")
	String host;

	@Value("${claimant.client.port}")
	String port;

	@Autowired
	@Qualifier("claimantRestOperations")
	RestOperations restOperations;


	static protected String generateUri(final String protocol, final String host, final String port, final String format, final Object... args) {
		return String.format("%s://%s:%s", protocol, host, port) + String.format(format, args);
	}
}
