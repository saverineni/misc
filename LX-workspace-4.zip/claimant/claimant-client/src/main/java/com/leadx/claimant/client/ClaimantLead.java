package com.leadx.claimant.client;

import com.leadx.services.claims.client.ClaimRequest;

public class ClaimantLead {
	
	private final ClaimRequest claimRequest;
	private final int claimantId;

	public ClaimantLead() {
		claimRequest = null;
		claimantId = 0;
	}

	public ClaimantLead(final ClaimRequest claimRequest, final int claimantId) {
		this.claimRequest = claimRequest;
		this.claimantId = claimantId;
	}
	
	public ClaimRequest getClaimRequest() {
		return this.claimRequest;
	}
	
	public int getClaimantId() {
		return this.claimantId;
	}
}
