package com.leadx.claimant.client;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class ProductTypeDto {

	public static final int PPI_ID = 1;
	public static final int PBA_ID = 2;
	public static final String PPI_NAME = "ppi";
	public static final String PBA_NAME = "pba";

	private int id;
	private String name;
	private boolean selected;

	public ProductTypeDto() {}

	public ProductTypeDto(final int id, final String name, final boolean selected) {
		this.id = id;
		this.name = name;
		this.selected = selected;
	}

	public int getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}

	public boolean getSelected() {
		return this.selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

	@Override
	public boolean equals(final Object other) {
		return deepEquals(other);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}
}