package com.leadx.claimant.client;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;
import com.leadx.claimant.client.annotations.Retryable;
import com.leadx.claimant.client.reference.DebtManagementCompanyDto;
import com.leadx.claimant.client.reference.IvaCompanyDto;
import com.leadx.lib.utl.JodaUtils;
import com.leadx.lib.utl.json.JsonUtils;

/** Wrapper around the claimant service. */
@Component
public class ClaimantServiceWrapper extends ServiceWrapper {
	
	private static final Logger LOG = LoggerFactory.getLogger(ClaimantServiceWrapper.class);

	@Retryable
	public ClaimantDto getClaimantById(final int claimantId) {
		final ResponseEntity<ClaimantDto> response =
			this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/%s", claimantId), ClaimantDto.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			return response.getBody();
		}

		LOG.error("Failed to get claimant id {}, http error {}", claimantId, response.getStatusCode());
		throw new RuntimeException("Failed to get claimant id" + response.getStatusCode());
	}

	// Note that an emtpy lst will return an error and there will be no ids on the end of the url
	@Retryable
	public List<ClaimantAndAddressDto> getClaimantsAndAddressByIds(final List<Integer> claimantIds) {
		final ResponseEntity<String> response =
			this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/ids/%s/address", StringUtils.join(claimantIds.toArray(), ",")), String.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			return claimantAndAddressDtosFromResponse(response);
		}

		LOG.error("Failed to get claimant ids {}, http error {}", StringUtils.join(claimantIds.toArray(), ","), response.getStatusCode());
		throw new RuntimeException("Failed to get claimant ids" + response.getStatusCode());
	}

	@Retryable
	public Collection<ClaimantDto> getClaimantsByIds(final Collection<Integer> claimantIds) {
		final ResponseEntity<String> response =
			this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/ids/%s", StringUtils.join(claimantIds.toArray(), ",")), String.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			return claimantDtosFromResponse(response);
		}

		LOG.error("Failed to get claimant ids {}, http error {}", StringUtils.join(claimantIds.toArray(), ","), response.getStatusCode());
		throw new RuntimeException("Failed to get claimant ids" + response.getStatusCode());
	}

	@Retryable
	public List<ClaimantAndAddressDto> searchForClaimantsBySurname(final String surname) {
		final ResponseEntity<String> response =
			this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/surname/%s", surname), String.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			return claimantAndAddressDtosFromResponse(response);
		}

		LOG.error("Failed searchForClaimantBySurname {}, http error {}", surname, response.getStatusCode());
		throw new RuntimeException("Failed searchForClaimantBySurname" + response.getStatusCode());
	}

	@Retryable
	public List<ClaimantAndAddressDto> searchForClaimantsByTelephoneNumber(final String number) {
		final ResponseEntity<String> response =
			this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/telephonenumber/%s", number), String.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			return claimantAndAddressDtosFromResponse(response);
		}

		LOG.error("Failed searchForClaimantByTelephoneNumber {}, http error {}", number, response.getStatusCode());
		throw new RuntimeException("Failed searchForClaimantByTelephoneNumber" + response.getStatusCode());
	}


	@Retryable
	public List<ClaimantAndAddressDto> searchForClaimantsByPostcode(final String postcode) {
		final ResponseEntity<String> response =
			this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/postcode/%s", postcode), String.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			return claimantAndAddressDtosFromResponse(response);
		}

		LOG.error("Failed searchForClaimantByPostcode {}, http error {}", postcode, response.getStatusCode());
		throw new RuntimeException("Failed searchForClaimantByPostcode" + response.getStatusCode());
	}


	@Retryable
	public ClaimantDto createClaimant(final ClaimantDto claimantDto) {

		final ResponseEntity<ClaimantDto> response =
				this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/create"), claimantDto, ClaimantDto.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			return response.getBody();
		}

		LOG.error("Failed to create claimant, http error {}", response.getStatusCode());
		throw new RuntimeException("Failed to get create claimant. Error code " + response.getStatusCode());
	}

	@Retryable
	public void updateClaimant(final ClaimantDto claimantDto, final int userId) {

		final ResponseEntity<Void> response =
			this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/update/userId/{userId}"), claimantDto, Void.class, userId);
		if (response.getStatusCode() == HttpStatus.OK) {
			return;
		}

		LOG.error("Failed to update claimant, http error {}", response.getStatusCode());
		throw new RuntimeException("Failed to get update claimant. Error code " + response.getStatusCode());
	}

	@Retryable
	public void saveEvent(final ClaimantInteractionDto claimantInteractionDto) {

		final ResponseEntity<Void> response =
				this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/saveEvent"), claimantInteractionDto, Void.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			return;
		}

		LOG.error("Failed to save event, http error {}", response.getStatusCode());
		throw new RuntimeException("Failed to get save event for  claimant. Error code " + response.getStatusCode());
	}

	@Retryable
	public void saveNote(final ClaimantInteractionDto claimantInteractionDto) {

		final ResponseEntity<Void> response =
				this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/saveNote"), claimantInteractionDto, Void.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			return;
		}

		LOG.error("Failed to save note, http error {}", response.getStatusCode());
		throw new RuntimeException("Failed to get save note for  claimant. Error code " + response.getStatusCode());
	}

	@Retryable
	public void saveNoteWithInteractionDateTime(final ClaimantInteractionDto claimantInteractionDto) {

		final ResponseEntity<Void> response =
				this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/saveNoteWithInteractionDateTime"), claimantInteractionDto, Void.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			return;
		}

		LOG.error("Failed to save note, http error {}", response.getStatusCode());
		throw new RuntimeException("Failed to get save note for  claimant. Error code " + response.getStatusCode());
	}

	/**
	 * This is a variation of the method {@link #updateClaimant(ClaimantDto, int)}}
	 * This method does not send the update back to the logiclaim queue
	 *
	 * @param claimantDto the claimant to be updated
	 * @param userId user updating the claimant
	 */
	@Retryable
	public void updateClaimantInConfinement(final ClaimantDto claimantDto, final int userId) {

		final ResponseEntity<Void> response =
				this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/confinement/update/userId/{userId}"), claimantDto, Void.class, userId);
		if (response.getStatusCode() == HttpStatus.OK) {
			return;
		}

		LOG.error("Failed to create claimant, http error {}", response.getStatusCode());
		throw new RuntimeException("Failed to get create claimant. Error code " + response.getStatusCode());
	}


	@Retryable
	public void setClaimantOptIn(final int claimantId, final boolean optIn) {
		final ResponseEntity<String> response =
			this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/%s/optIn/%s", claimantId, optIn), String.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			return;
		}

		LOG.error("Failed save claimant optin claimant, id {}, optin {}, http error {}", claimantId, optIn, response.getStatusCode());
	}


	@Retryable
	public ClaimantReferralDto getClaimantReferralByReferreeId(final int claimantReferreeId) {
		final ResponseEntity<ClaimantReferralDto> response =
			this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/claimantReferral/referreeId/%s", claimantReferreeId), ClaimantReferralDto.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			return response.getBody();
		}

		LOG.error("Failed to get claimant referral, referree id {}, http error {}", claimantReferreeId, response.getStatusCode());
		throw new RuntimeException("Failed to get claimant referral, referree id " + claimantReferreeId + ". Error code " + response.getStatusCode());
	}


	@Retryable
	public Collection<ClaimantReferralDto> getClaimantReferralsByReferreeIds(final Collection<Integer> claimantReferreeIds) {
		if ( claimantReferreeIds.size() == 0 ) {
			return ImmutableList.of();
		}

		final ResponseEntity<String> response =
			this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/claimantReferral/referreeIds/%s", StringUtils.join(claimantReferreeIds.toArray(), ",")), String.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			return claimantReferralDtosFromResponse(response);
		}

		LOG.error("Failed to get claimant referrals, referrees id {}, http error {}", claimantReferreeIds, response.getStatusCode());
		throw new RuntimeException("Failed to get claimant referral, referree id " + claimantReferreeIds + ". Error code " + response.getStatusCode());
	}

	@Retryable
	public ClaimantReferralDto createClaimantReferral(final ClaimantDto claimantDto,
													  final int productTypeId,
													  final int referrerClaimantId,
													  final int createdByAgentId,
													  final int diallerReferenceId,
													  final LocalDateTime scheduledDateTime) {

		final CreateClaimantReferralDto createClaimantReferralDto = 
				new CreateClaimantReferralDto(claimantDto, productTypeId, referrerClaimantId, createdByAgentId, diallerReferenceId, JodaUtils.localDateTimeToBritishDateFormatOrNull(scheduledDateTime), "");

		final ResponseEntity<ClaimantReferralDto> response = this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/claimantReferral"), createClaimantReferralDto, ClaimantReferralDto.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			return response.getBody();
		}

		LOG.error("Failed to get claimant referral, referree id {}, http error {}", referrerClaimantId, response.getStatusCode());
		throw new RuntimeException("Failed to get claimant referral, referree id " + referrerClaimantId + ". Error code " + response.getStatusCode());
	}

	@Retryable
	public ClaimantLockDto lockClaimant(final int claimantId, final int userId, final int scheduledTaskId) {
		final ResponseEntity<String> response =
			this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/%s/lock/user/%s/scheduledTaskId/%s", claimantId, userId, scheduledTaskId), String.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			return JsonUtils.deserialize(response.getBody(), ClaimantLockDto.class);
		}

		LOG.error("Failed to lock claimant, id {}, http error {}", claimantId, response.getStatusCode());
		return new ClaimantLockDto(false, 0);
	}

	@Retryable
	public ClaimantUnlockDto unlockClaimant(final int claimantId, final int userId) {
		final ResponseEntity<String> response =
			this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/%s/unlock/user/%s", claimantId, userId), String.class);

		if (response.getStatusCode() == HttpStatus.OK) {
			return JsonUtils.deserialize(response.getBody(), ClaimantUnlockDto.class);
		}

		// There's nothing to be done if the unlock fails for some reason. Next time someone tries to open the claimant they will get a claimant already
		// locked error and it will have to be manually unlocked.
		LOG.error("Failed to unlock claimant, id {}, http error {}", claimantId, response.getStatusCode());
		return new ClaimantUnlockDto(0);
	}

	@Retryable
	public ClaimantLockStatusDto getClaimantLockStatus(final int claimantId) {
		final ResponseEntity<String> response =
				this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/%s/lock/status", claimantId), String.class);

		if (response.getStatusCode() == HttpStatus.OK) {
			return JsonUtils.deserialize(response.getBody(), ClaimantLockStatusDto.class);
		}

		LOG.error("Failed to get lock status claimant, id {}, http error {}", claimantId, response.getStatusCode());
		return null;
	}

	@Retryable
	public ClaimantInteractionsDto getClaimantInteractions(final int claimantId) {
		final ResponseEntity<ClaimantInteractionsDto> response =
				this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/%s/interactions", claimantId), ClaimantInteractionsDto.class);

		if (response.getStatusCode() == HttpStatus.OK) {
			return response.getBody();
		}

		LOG.error("Failed to get claimant interactions, id {}, http error {}", claimantId, response.getStatusCode());
		return null;
	}

	@Retryable
	public ClaimantInteractionsDto getClaimantInteractionsBySource(final int claimantId, final String source, final int productType) {
		final ResponseEntity<ClaimantInteractionsDto> response =
				this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/%s/%s/interactions/%s", claimantId, source, productType), ClaimantInteractionsDto.class);

		if (response.getStatusCode() == HttpStatus.OK) {
			return response.getBody();
		}

		LOG.error("Failed to get claimant interactions, id {}, http error {}", claimantId, response.getStatusCode());
		return null;
	}


	@Retryable
	public ClaimantInteractionsDto getClaimantInteractionsBySources(final int claimantId, final Collection<String> sources, final int productType) {
		final ResponseEntity<ClaimantInteractionsDto> response =
				this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/%s/sources/%s/interactions/%s", claimantId, StringUtils.join(sources.toArray(),","), productType), ClaimantInteractionsDto.class);

		if (response.getStatusCode() == HttpStatus.OK) {
			return response.getBody();
		}

		LOG.error("Failed to get claimant interactions, id {}, http error {}", claimantId, response.getStatusCode());
		return null;
	}

	@Retryable
	public String lockClaimantFromDialler(final int claimantId, final int userId){
		LOG.info("Lock Claimant from Dialler {}", claimantId);
		final ResponseEntity<String> response = this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/lockFromDialler/%s/%s", claimantId, userId), null, String.class);

		if (response.getStatusCode() != HttpStatus.OK) {
			LOG.error("Failed to lock claimant from dialler : {}, http error: {}", claimantId, response.getStatusCode());
			throw new RuntimeException("Failed to lock claimant from dialler " + claimantId);
		}

		LOG.info("Locked claimant from dialler {}", claimantId);
		return response.getBody();
	}

	@Retryable
	public String unlockClaimantFromDialler(final int claimantId, final int userId){
		LOG.info("Unlock Claimant from Dialler {}", claimantId);
		final ResponseEntity<String> response = this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "/claimant/unlockFromDialler/%s/%s", claimantId, userId), null, String.class);

		if (response.getStatusCode() != HttpStatus.OK) {
			LOG.error("Failed to unlock claimant from dialler : {}, http error: {}", claimantId, response.getStatusCode());
			throw new RuntimeException("Failed to unlock claimant from dialler " + claimantId);
		}

		LOG.info("Unlocked claimant from dialler {}", claimantId);
		return response.getBody();
	}

	public List<DebtManagementCompanyDto> getDebtManagementCompanies() {

		final ResponseEntity<String> response =
				this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/unsecure/debtManagementCompanies"), String.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			return debtManagementCompanyDtosFromResponse(response);
		}

		LOG.error("Failed to get debt management companies, http error {}",  response.getStatusCode());
		return null;
	}

	@Retryable
	public List<IvaCompanyDto> getIvaCompanies() {

		final ResponseEntity<String> response =
				this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/unsecure/ivaCompanies"), String.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			return ivaCompanyDtosFromResponse(response);
		}

		LOG.error("Failed to get iva companies, http error {}",  response.getStatusCode());
		return null;
	}

	public ClaimantContactPreferenceDto getContactPreference(final int claimantId) {
		final ResponseEntity<ClaimantContactPreferenceDto> response =
				this.restOperations.getForEntity(generateUri(this.protocol, this.host, this.port, "/contactpreference/claimant/%s", claimantId),
						ClaimantContactPreferenceDto.class);

		if (response.getStatusCode() == HttpStatus.OK) {
			return response.getBody();
		}

		LOG.error("Failed to get claimant contact preferences, http error {}",  response.getStatusCode());
		return null;
	}

	public void saveContactPreference(final ClaimantContactPreferenceDto claimantContactPreferenceDto) {
		final ResponseEntity<Void> response =
				this.restOperations.postForEntity(generateUri(this.protocol, this.host, this.port, "/contactpreference/save"),
						claimantContactPreferenceDto, Void.class);

		if (response.getStatusCode() != HttpStatus.OK) {
			LOG.error("Failed to save claimant contact preferences, http error {}",  response.getStatusCode());
			throw new RuntimeException("Failed to save claimant contact preferences. Error code " + response.getStatusCode());
		}
	}

	private static List<ClaimantReferralDto> claimantReferralDtosFromResponse(final ResponseEntity<String> response) {
		final ObjectMapper mapper = new ObjectMapper();

		try {
			return mapper.readValue(response.getBody(), new TypeReference<List<ClaimantReferralDto>>() { });
		}
		catch (final IOException e) {
			LOG.error("Failed to map to ClaimantReferralDto object from response: " + response.getBody());
			throw new RuntimeException("Failed map to ClaimantReferralDto object: " + response.getStatusCode());
		}
	}

	private static List<DebtManagementCompanyDto> debtManagementCompanyDtosFromResponse(final ResponseEntity<String> response) {
		final ObjectMapper mapper = new ObjectMapper();

		try {
			return mapper.readValue(response.getBody(), new TypeReference<List<DebtManagementCompanyDto>>() { });
		}
		catch (final IOException e) {
			LOG.error("Failed to map to DebtManagementCompanyDto object from response: " + response.getBody());
			throw new RuntimeException("Failed map to DebtManagementCompanyDto object: " + response.getStatusCode());
		}
	}

	private static List<IvaCompanyDto> ivaCompanyDtosFromResponse(final ResponseEntity<String> response) {
		final ObjectMapper mapper = new ObjectMapper();

		try {
			return mapper.readValue(response.getBody(), new TypeReference<List<IvaCompanyDto>>() { });
		}
		catch (final IOException e) {
			LOG.error("Failed to map to IvaCompanyDto object from response: " + response.getBody());
			throw new RuntimeException("Failed map to IvaCompanyDto object: " + response.getStatusCode());
		}
	}

	private static List<ClaimantAndAddressDto> claimantAndAddressDtosFromResponse(final ResponseEntity<String> response) {
		final ObjectMapper mapper = new ObjectMapper();

		try {
			return mapper.readValue(response.getBody(), new TypeReference<List<ClaimantAndAddressDto>>() { });
		}
		catch (final IOException e) {
			LOG.error("Failed to map to ClaimantAndAddressDto object from response: " + response.getBody());
			throw new RuntimeException("Failed map to ClaimantAndAddressDto object: " + response.getStatusCode());
		}
	}

	private static Collection<ClaimantDto> claimantDtosFromResponse(final ResponseEntity<String> response) {
		final ObjectMapper mapper = new ObjectMapper();

		try {
			return mapper.readValue(response.getBody(), new TypeReference<Collection<ClaimantDto>>() { });
		}
		catch (final IOException e) {
			LOG.error("Failed to map to ClaimantDto object from response: " + response.getBody());
			throw new RuntimeException("Failed map to ClaimantDto object: " + response.getStatusCode());
		}
	}

}
