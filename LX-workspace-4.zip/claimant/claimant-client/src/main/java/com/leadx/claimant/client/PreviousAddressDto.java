package com.leadx.claimant.client;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


public class PreviousAddressDto {
	
	private int id;
	private int claimantId;
	private AddressDto address;
	private boolean fromCurrent;
	private String deletedDateTime;
	private int fkUserIdDeletedBy;
	
	public PreviousAddressDto() {
	}
	
	public PreviousAddressDto(final int id, final int claimantId, final AddressDto addressId, final boolean fromCurrent, final String deletedDateTime, final int fkUserIdDeletedBy) {
		this.id = id;
		this.claimantId = claimantId;
		this.address = addressId;
		this.fromCurrent = fromCurrent;
		this.deletedDateTime = deletedDateTime;
		this.fkUserIdDeletedBy = fkUserIdDeletedBy;
	}

	public int getId() {
		return this.id;
	}

	public void setId(final int id) {
		this.id = id;
	}

	public int getClaimantId() {
		return this.claimantId;
	}

	public void setClaimantId(final int claimantId) {
		this.claimantId = claimantId;
	}

	public AddressDto getAddress() {
		return this.address;
	}

	public void setAddress(final AddressDto address) {
		this.address = address;
	}

	public boolean getFromCurrent() {
		return this.fromCurrent;
	}

	public void setFromCurrent(final boolean fromCurrent) {
		this.fromCurrent = fromCurrent;
	}

	public String getDeletedDateTime() {
		return this.deletedDateTime;
	}

	public void setDeletedDateTime(final String deletedDateTime) {
		this.deletedDateTime = deletedDateTime;
	}

	public int getFkUserIdDeletedBy() {
		return this.fkUserIdDeletedBy;
	}

	public void setFkUserIdDeletedBy(final int userIdDeletedBy) {
		this.fkUserIdDeletedBy = userIdDeletedBy;
	}
	
	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}
	
	@Override
	public boolean equals(final Object obj) {
		return deepEquals(obj);
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	public boolean deepEquals(final Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}
	
}