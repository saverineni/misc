package com.leadx.claimant.client;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class AssessmentDispositionDto {

	/**
	 * Assessment only take ASSESSMENT calls
	 */
	public static final CallType CALL_TYPE = CallType.ASSESSMENT;

	private int claimantId;
	private int dispositionId;
	private int diallerRefId;
	private boolean inbound;
	private String callReason;
	private String callReasonGroup;
	private String callbackDateTime;
	private int userId;
	private boolean newClaimant;

	public AssessmentDispositionDto() {
	}

	public int getClaimantId() {
		return this.claimantId;
	}

	public void setClaimantId(final int claimantId) {
		this.claimantId = claimantId;
	}

	public int getDispositionId() {
		return this.dispositionId;
	}

	public void setDispositionId(final int dispositionId) {
		this.dispositionId = dispositionId;
	}

	public int getDiallerRefId() {
		return this.diallerRefId;
	}

	public void setDiallerRefId(final int diallerRefId) {
		this.diallerRefId = diallerRefId;
	}

	public boolean getInbound() {
		return this.inbound;
	}

	public void setInbound(boolean inbound) {
		this.inbound = inbound;
	}

	public String getCallbackDateTime() {
		return this.callbackDateTime;
	}

	public void setCallbackDateTime(String callbackDateTime) {
		this.callbackDateTime = callbackDateTime;
	}

	public int getUserId() {
		return this.userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getCallReason() {
		return this.callReason;
	}

	public void setCallReason(String callReason) {
		this.callReason = callReason;
	}
	
	public String getCallReasonGroup() {
		return this.callReasonGroup;
	}

	public void setCallReasonGroup(String callReasonGroup) {
		this.callReasonGroup = callReasonGroup;
	}

	public boolean isNewClaimant() {
		return this.newClaimant;
	}

	public void setNewClaimant(boolean newClaimant) {
		this.newClaimant = newClaimant;
	}

	@Override
	public boolean equals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

}
