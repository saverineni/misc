DELETE FROM claimant.claimant_log;
INSERT INTO claimant.claimant_log (ID, FK_ClaimantID, FK_ScheduledTaskId, OpenedDateTime, ClosedDateTime, FK_UserID)
VALUES (10, 100, 1, '2014-10-05 12:24:00', '2014-10-05 12:25:00', 1000),
 (11, 100, 1, '2014-10-05 12:24:12', '0000-00-00 00:00:00', 1000),
 (12, 99, 1, '2014-10-05 12:26:00', '2014-10-05 12:28:00', 1000);