DELETE FROM claimant.claimant_referral;
INSERT INTO claimant.claimant_referral (ID, FK_ProductTypeId, FK_ClaimantID_Referral, FK_ClaimantID_Referrer, CreatedDateTime, FK_UserID_CreatedBy, DiallerReferenceID)
		VALUES
			(1, 1, 100, 100, '2014-09-23 12:35:00', 5, 50),
			(2, 1, 100, 100, '2014-09-23 12:40:00', 6, 51),
			(3, 1, 100, 1000, '2014-09-23 12:45:00', 7, 52);