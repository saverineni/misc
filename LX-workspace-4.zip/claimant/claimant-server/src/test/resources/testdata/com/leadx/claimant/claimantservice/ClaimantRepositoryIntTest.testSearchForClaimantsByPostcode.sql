DELETE FROM claimant;
DELETE FROM address;

INSERT INTO claimant.`claimant` SET
	ID=1,
	FK_LeadID=8000001,
	FK_AddressID=1,
	FK_AccountID_Seller=9785,
	Title='Mr',
	Forename='Jim',
	Surname='Helliwell',
	Email='jim@bobbins.com',
	HomeTelephone='02031892512',
	MobileTelephone='07796136602',
	WorkTelephone='08448714386',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;

INSERT INTO claimant.`claimant` SET
	ID=2,
	FK_LeadID=8000002,
	FK_AddressID=2,
	FK_AccountID_Seller=9785,
	Title='Mrs',
	Forename='Jessica',
	Surname='Bobbins',
	Email='jessica@bobbins.com',
	HomeTelephone='02031892512',
	MobileTelephone='07796136602',
	WorkTelephone='08448714386',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;

INSERT INTO claimant.`claimant` SET
	ID=3,
	FK_LeadID=8000004,
	FK_AddressID=3,
	Title='Mr',
	Forename='Eric',
	Surname='Helliwell',
	Email='eric@bobbins.com',
	HomeTelephone='02031892512',
	MobileTelephone='07796136602',
	WorkTelephone='08448714386',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;

INSERT INTO claimant.address (ID, DepartmentName, Postcode)
	VALUES (1, 'Dept1', 'ST7 2SH'),
	       (2, 'Dept2', 'ST6 2SH'),
	       (3, 'Dept3', 'ST7 2SH');