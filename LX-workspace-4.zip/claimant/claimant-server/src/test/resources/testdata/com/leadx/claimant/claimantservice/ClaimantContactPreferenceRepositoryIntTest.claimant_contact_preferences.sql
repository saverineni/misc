DELETE FROM `claimant`.`claimant_contact_preference`;
INSERT INTO `claimant`.`claimant_contact_preference` (`ID`, `FK_ClaimantID`, `TelephoneOptIn`, `EmailOptIn`, `SmsOptIn`, `MarketingMailingOptIn`, `Cancellation`) VALUES
(123, 12345, 1, 1, 0, 0, 0),
(321, 54321, 0, 1, 0, 1, 0),
(400, 99999, 0, 1, 0, 1, 0),
(500, 100, 0, 1, 0, 1, 0);
