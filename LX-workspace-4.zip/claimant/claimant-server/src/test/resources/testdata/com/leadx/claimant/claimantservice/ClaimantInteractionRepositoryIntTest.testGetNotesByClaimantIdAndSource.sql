INSERT INTO `claimant`.`claimant_interaction` (`FK_ClaimantID`, `Type`, `FK_UserID`, `CreatedDateTime`, `Content`, `Source`) VALUES
(123456, 'event', 3193, '2014-12-10 12:00:00', 'Test Event 1', 'SALES'),
(123456, 'note', 3193, '2014-12-10 12:00:00', 'Test Note 1', 'SALES'),
(123456, 'note', 3193, '2014-12-10 12:00:00', 'Test Note 2', 'SALES'),
(123456, 'note', 3193, '2014-12-10 12:00:00', 'Test Note 3', 'SALES'),
(123457, 'event', 3193, '2014-12-10 12:00:00', 'Test Event 2', 'SALES'),
(123457, 'note', 3193, '2014-12-10 12:00:00', 'Test Note 4', 'SALES'),
(123458, 'event', 3193, '2014-12-10 12:00:00', 'Test Event 3', 'SALES'),
(123459, 'event', 3193, '2014-12-10 12:00:00', 'Test Event 4', 'SALES'),
(123456, 'note', 3193, '2014-12-10 12:00:00', 'Payments Note 1', 'PAYMENTS');
