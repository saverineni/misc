DELETE FROM claimant_opt_in;
INSERT INTO claimant_opt_in	(FK_ClaimantID, OptIn)
VALUES (9, false),
	(10, true);