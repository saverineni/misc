DELETE FROM claimant.address_verification_failures;

INSERT INTO claimant.address_verification_failures VALUES (
1, 11166677, 22233344, 'action_required', '2016-03-02 10:00:00', 0, '0000-00-00 00:00:00', 0
);