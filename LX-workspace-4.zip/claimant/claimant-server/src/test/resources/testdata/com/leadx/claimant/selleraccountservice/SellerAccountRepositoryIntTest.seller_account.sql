DELETE FROM `claimant`.`seller_account`;
DELETE FROM `claimant`.seller_account_inbound_number;

INSERT INTO `claimant`.`seller_account` (`ID`,`FK_ProductTypeID`,`FK_AccountID`,`GpSellerAccount`, `Name`, `DisplayName`, `SourceDescription`, `ApplicationLogo`, `PackType`, `AssessmentCallReasonGroup`, `EmailIconImageName`, `AssessmentInitialSmsMessageScript`, `AssessmentInitialEmailMessageScript`,`Web`,`AccountName`,`DistributeAppointmentReminder`,`OBJ_VERSION`) VALUES
	(1,1,11,'GP_SELLER_ACC','Seller Name','Display Name','','LOGO.swf','tcg_pack','call_reason_group','email_icon.png','smsScript','emailScript','0', '','1','0'),
	(2,1,12,'GP_SELLER_ACC2','Seller Name 2','Display Name 2','Source Description 2','LOGO_2.swf','tcg_pack','call_reason_group_2','email_icon_2.png','smsScript2','emailScript2','0', '','1','0'),
	(3,2,13,'GP_SELLER_ACC3','Seller Name 3','Display Name 3','','LOGO_3.swf','tcg_pack','call_reason_group_3','email_icon_3.png','smsScript3','emailScript3','0', '','1','0'),
	(4,1,14,'GP_SELLER_ACC4','Seller Name 4','Display Name 4','Source Description 4','LOGO_4.swf','tcg_pack','call_reason_group_4','email_icon_4.png','smsScript4','emailScript4','0', '','1','0'),
	(5,1,15,'GP_SELLER_ACC5','Seller Name 5','Display Name 5','Source Description 5','LOGO_5.swf','tcg_pack','call_reason_group_5','email_icon_5.png','smsScript5','emailScript5','0', '','1','0');

INSERT INTO `claimant`.`seller_account_inbound_number` (`FK_AccountID`, `DDI`) VALUES
	(12,'02999999941'),
	(13,'02999999942'),
	(14,'02999999943');