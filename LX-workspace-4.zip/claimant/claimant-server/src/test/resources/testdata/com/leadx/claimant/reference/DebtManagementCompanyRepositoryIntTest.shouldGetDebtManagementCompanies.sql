DELETE FROM `claimant`.`debt_management_company`;
INSERT INTO `claimant`.`debt_management_company` (`ID`,`Name`,`DepartmentName`,`OrganisationName`,`SubBuildingName`,`BuildingName`,`BuildingNumber`,`DependentThoroughfare`,`Thoroughfare`,`DoubleDependentLocality`,`DependentLocality`,`Town`,`County`,`Postcode`) VALUES
(1,'Test Company','','Organisation','','','1','','TEST TERRACE','','','TEST','','WA14 4DZ'),
(2,'Campbell,Wallace,Fraser Limited','','CAMPBELL,WALLACE,FRASER LIMITED','','NATIONAL HOUSE','80-82','','WELLINGTON ROAD NORTH','','','STOCKPORT','','SK4 1HW');