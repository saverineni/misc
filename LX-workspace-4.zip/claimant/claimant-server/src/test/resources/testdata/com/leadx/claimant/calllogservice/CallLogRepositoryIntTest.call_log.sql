DELETE FROM `claimant`.`call_log`;

INSERT INTO `claimant`.`call_log` (`ID`,`FK_ClaimantID`,`FK_CallTypeID`,`FK_CallDispositionID`,`FK_UserID_Agent`,`DiallerReferenceID`,`DispositionDateTime`)
VALUES 
(1,101,1,1,1001,10001,'2011-03-15 09:00:00'),
(2,102,2,3,1002,10002,'2011-03-15 09:01:00'),
(3,103,2,3,1003,10003,'2011-03-15 09:02:00');