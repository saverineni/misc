DELETE FROM claimant.claimant;
DELETE FROM claimant.address;
DELETE FROM claimant.previous_address;