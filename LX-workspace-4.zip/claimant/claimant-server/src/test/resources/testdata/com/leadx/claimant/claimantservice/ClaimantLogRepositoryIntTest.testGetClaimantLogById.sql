DELETE FROM claimant.claimant_log;
INSERT INTO claimant.claimant_log (ID, FK_ClaimantID, FK_ScheduledTaskId, OpenedDateTime, ClosedDateTime, FK_UserID)
VALUES (10, 100, 1, '2014-10-05 12:24:12', '0000-00-00 00:00:00', 1000);