DELETE FROM `claimant`.`application_property`;
INSERT INTO `claimant`.`application_property` (`Property`, `PropertyValue`) VALUES
("Test1",""),
("Test2","Test2Result"),
("Test3","123456");