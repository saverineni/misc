INSERT INTO `claimant`.`claimant_interaction` (`FK_ClaimantID`, `Type`, `FK_UserID`, `CreatedDateTime`, `Content`) VALUES 
(123456, 'event', 3193, '2014-12-10 12:00:00', 'Test Event 1'),
(123456, 'note', 3193, '2014-12-10 12:00:00', 'Test Note 1'),
(123456, 'note', 3193, '2014-12-10 12:00:00', 'Test Note 2'),
(123456, 'note', 3193, '2014-12-10 12:00:00', 'Test Note 3'),
(123457, 'event', 3193, '2014-12-10 12:00:00', 'Test Event 2'),
(123457, 'note', 3193, '2014-12-10 12:00:00', 'Test Note 4'),
(123458, 'event', 3193, '2014-12-10 12:00:00', 'Test Event 3'),
(123459, 'event', 3193, '2014-12-10 12:00:00', 'Test Event 4');