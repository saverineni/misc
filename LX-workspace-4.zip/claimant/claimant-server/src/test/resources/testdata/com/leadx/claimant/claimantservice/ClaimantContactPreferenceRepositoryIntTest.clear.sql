DELETE FROM `claimant`.`claimant_contact_preference`;
