DELETE 
FROM `claimant`.`claimant_group_allocation`;

INSERT INTO `claimant`.`claimant_group_allocation` 
(`FK_ClaimantID`,`CallReason`,`CallReasonGroup`,`CallGroupAllocationDateTime`) 
VALUES
('12345','Chase','Combined','2015-06-06 13:15:00'),
('12346','Chase','TCG','2015-04-06 13:30:00');