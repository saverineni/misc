DELETE FROM `call_disposition`;
DELETE FROM `claimant`.`call_log`;
DELETE FROM `claimant_log`;

INSERT INTO `call_disposition` (`ID`,`UltraID`,`Name`) VALUES 
(1, '930', 'Answerphone'),
(4, '970', 'Already Arranged'),
(5, '830', 'Not Interested');

INSERT INTO `claimant`.`call_log` (`ID`,`FK_ClaimantID`,`FK_CallTypeID`,`FK_CallDispositionID`,`FK_UserID_Agent`,`DiallerReferenceID`,`DispositionDateTime`) VALUES 
(1,4882,1,1,24,10001,'2011-03-15 11:00:00'),
(2,4882,1,4,25,10002,'2011-03-15 12:00:00'),
(3,4883,1,2,25,10003,'2011-03-15 11:00:00'), -- Wrong claimant
(4,4882,1,2,25,10003,'2011-02-14 11:00:00'), -- Too early
(5,4882,1,2,25,10002,'2011-03-15 13:00:00'); -- No matching claimant_log

INSERT INTO `claimant_log` (`ID`, `FK_ClaimantID`, `OpenedDateTime`, `ClosedDateTime`, `FK_UserID`) VALUES
(1, 4882, '2011-03-15 10:30:09', '2011-03-15 11:00:09', 24),
(2, 4882, '2011-03-15 11:49:51', '2011-03-15 11:59:51', 25),
(3, 4882, '2011-03-15 10:45:00', '2011-03-15 11:00:00', 25),
(4, 4882, '2011-03-15 10:45:00', '2011-03-15 11:00:00', 25),
(5, 4882, '2011-03-15 12:45:00', '2011-03-15 13:00:11', 25); -- Outside of 10 second buffer