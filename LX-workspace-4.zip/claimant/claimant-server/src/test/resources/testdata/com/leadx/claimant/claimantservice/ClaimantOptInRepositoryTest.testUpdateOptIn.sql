DELETE FROM claimant.claimant_opt_in;
INSERT INTO claimant.claimant_opt_in	(ID, FK_ClaimantID, OptIn, OptInDateTime, OBJ_VERSION)
		VALUES (1, 9, false, '2014-09-12 13:45:00', 0);