package com.leadx.claimant.claimantservice;

import com.google.common.collect.Lists;
import com.leadx.claimant.client.ClaimantDto;

import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

public class ClaimantConverterTest {
	
	final ClaimantConverter converter = new ClaimantConverter();
	final ClaimantOtherNameConverter otherNameConverter = new ClaimantOtherNameConverter();
	final ClaimantAdditionalPreviousNameConverter previousNamesConverter = new ClaimantAdditionalPreviousNameConverter();
	final ClaimantPreviousEmailConverter previousEmailConverter = new ClaimantPreviousEmailConverter();
	final ClaimantUnpresentedChequeConverter unpresentedChequeConverter = new ClaimantUnpresentedChequeConverter();
	final ClaimantExecutorConverter executorConverter = new ClaimantExecutorConverter();
	
	@Before
	public void setUp(){
		ReflectionTestUtils.setField(this.converter, "otherNamesConverter", this.otherNameConverter);
		ReflectionTestUtils.setField(this.converter, "previousNamesConverter", this.previousNamesConverter);
		ReflectionTestUtils.setField(this.converter, "previousEmailConverter", this.previousEmailConverter);
		ReflectionTestUtils.setField(this.converter, "claimantUnpresentedChequeConverter", this.unpresentedChequeConverter);
		ReflectionTestUtils.setField(this.converter, "claimantExecutorConverter", this.executorConverter);
	}
	
	@Test
	public void testConvert() throws Exception {
		final Claimant claimant = new ClaimantBuilder().setId(99)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("matt")
				.setMiddleName("middle")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(null)
				.setAddressId(12)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("56789")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setLockedFromDiallerUpdateDateTime(new LocalDateTime(2014, 10, 13, 12, 34, 14))
				.setLockedFromDiallerUpdateUserId(5)
				.setVulnerableCustomerUpdateDateTime(new LocalDateTime(2014, 10, 13, 12, 34, 14))
				.setVulnerableCustomerUpdateUserId(5)
				.setVulnerableCustomerReviewDate(new LocalDate(2016, 05, 20))
				.setFreePpi(true)
				.createClaimant();
		final ClaimantDto dto = this.converter.convert(claimant);

		assertThat(dto.getId(), is(99));
		assertThat(dto.getLeadId(), is(123));
		assertThat(dto.getSellerAccountId(), is(1));
		assertThat(dto.getSellerCompanyId(), is(2));
		assertThat(dto.getTitle(), is("mr"));
		assertThat(dto.getForename(), is("matt"));
		assertThat(dto.getMiddleName(), is("middle"));
		assertThat(dto.getSurname(), is("matty"));
		assertThat(dto.getPreviousSurname(), is("xxx"));
		assertThat(dto.getDob(), is(nullValue()));
		assertThat(dto.getAddressId(), is(12));
		assertThat(dto.getHomeTelephone(), is("123"));
		assertThat(dto.getMobileTelephone(), is("234"));
		assertThat(dto.getAlternativeTelephone(), is("56789"));
		assertThat(dto.getWorkTelephone(), is("2345"));
		assertThat(dto.getEmail(), is("me@me.com"));
		assertThat(dto.getLockedFromDialler(), is(false));
		assertThat(dto.getLockedFromDiallerUpdateDateTime(), is("13/10/2014 12:34:14"));
		assertThat(dto.getLockedFromDiallerUpdateUserId(), is(5));
		assertThat(dto.getVulnerableCustomerReviewDate(), is ("20/05/2016"));
		assertThat(dto.getCreatedDateTime(), is(nullValue()));
		assertThat(dto.getUpdateDateTime(), is(nullValue()));
		assertThat(dto.getSuppressedDateTime(), is(nullValue()));
		assertThat(dto.getOtherNames(), is(Lists.newArrayList()));
		assertThat(dto.getAdditionalPreviousNames(), is(Lists.newArrayList()));
		assertNull(dto.getUnpresentedCheque());
		assertThat(dto.getClaimantExecutor(), is(nullValue()));
	}
	
	@Test
	public void testConvertReturnsNull() {
		final Claimant claimant = null;
		final ClaimantDto dto = this.converter.convert(claimant);
		
		assertThat(dto, is(nullValue()));
	}
}
