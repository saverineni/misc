package com.leadx.claimant.authenticationservice;

import static com.leadx.test.MockUtils.mockAndSetOn;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.security.NoSuchAlgorithmException;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.concurrent.Synchroniser;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;

import com.leadx.claimant.claimantservice.Claimant;
import com.leadx.claimant.claimantservice.ClaimantBuilder;
import com.leadx.claimant.claimantservice.ClaimantService;
import com.leadx.claimant.client.ClaimantAuthenticationDto;

public class AuthenticationServiceUnitTest {

	private AuthenticationService authenticationService;
	private ClaimantService claimantService;

	private final Synchroniser synchroniser = new Synchroniser();

	private static final int CLAIMANT_ID = 12345;
	private static final String PASSWORD = "this is a password";
	private static final String SALTED_AND_ENCRYPTED_PASSWORD = "cc374ecab2bfdc9df7b4f42943cb4857";

	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
			setThreadingPolicy(synchroniser);
		}
	};

	@Before
	public void setUp() {
		this.authenticationService = new AuthenticationService();
		this.claimantService = mockAndSetOn(this.context, ClaimantService.class, this.authenticationService);
	}

	@Test
	public void shouldAuthenticateSuccessfully() throws NoSuchAlgorithmException {
		final ClaimantAuthenticationDto claimantAuthenticationDto = new ClaimantAuthenticationDto(CLAIMANT_ID, PASSWORD);
		final Claimant claimant = createDummyClaimant(CLAIMANT_ID, SALTED_AND_ENCRYPTED_PASSWORD);

		expectGetClaimantById(CLAIMANT_ID, claimant);

		assertThat(this.authenticationService.authenticate(claimantAuthenticationDto), is(true));
	}

	@Test
	public void shouldFailAuthenticationWhenPasswordDoesntMatch() throws NoSuchAlgorithmException {
		final ClaimantAuthenticationDto claimantAuthenticationDto = new ClaimantAuthenticationDto(CLAIMANT_ID, PASSWORD);
		final Claimant claimant = createDummyClaimant(CLAIMANT_ID, "abcdefghjklmnopqrstuvwxyz");

		expectGetClaimantById(CLAIMANT_ID, claimant);

		assertThat(this.authenticationService.authenticate(claimantAuthenticationDto), is(false));
	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldHandleFailedClaimantLookup() throws NoSuchAlgorithmException {
		final ClaimantAuthenticationDto claimantAuthenticationDto = new ClaimantAuthenticationDto(CLAIMANT_ID, PASSWORD);

		expectGetClaimantById(CLAIMANT_ID, null);

		this.authenticationService.authenticate(claimantAuthenticationDto);
	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldHandleEmptyRequest() throws NoSuchAlgorithmException {
		this.authenticationService.authenticate(null);
	}

	@Test
	public void shouldHandleClaimantsThatHaveNoPasswordSet() throws NoSuchAlgorithmException {
		final ClaimantAuthenticationDto claimantAuthenticationDto = new ClaimantAuthenticationDto(CLAIMANT_ID, PASSWORD);
		final Claimant claimant = createDummyClaimant(CLAIMANT_ID, null);

		expectGetClaimantById(CLAIMANT_ID, claimant);

		assertThat(this.authenticationService.authenticate(claimantAuthenticationDto), is(false));
	}


	private void expectGetClaimantById(final int claimantId, final Claimant returnValue) {
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(claimantId);
				will(returnValue(returnValue));
			}
		});
	}

	private Claimant createDummyClaimant(final int claimantId, final String password) {
		final Claimant claimant = new ClaimantBuilder().setId(claimantId).createClaimant();

		claimant.setPassword(password);

		return claimant;
	}

}
