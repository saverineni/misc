package com.leadx.claimant.addressservice;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.leadx.claimant.client.AddressDto;

public class AddressDtoConverterTest {
	
	private AddressDtoConverter addressDtoConverter;
	
	@Before
	public void setUp() throws Exception {
		this.addressDtoConverter = new AddressDtoConverter();
	}
	
	@Test
	public final void canConvertWithAddressId() {
		final AddressDto addressDto = new AddressDto(123, "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "WA14 4DX", "k", null, null);
		
		final Address expected = new Address("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "WA14 4DX", "k");
		expected.setId(123);
		
		final Address actual = this.addressDtoConverter.convert(addressDto);
		
		assertTrue(actual.equals(expected));
	}
	
	@Test
	public final void canConvertWithoutAddressId() {
		final AddressDto addressDto = new AddressDto(0, "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "WA14 4DX", "k", null, null);
		
		final Address expected = new Address("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "WA14 4DX", "k");
		
		final Address actual = this.addressDtoConverter.convert(addressDto);
		
		assertTrue(actual.equals(expected));
		assertThat(actual.getId(), is(nullValue()));
	}
}