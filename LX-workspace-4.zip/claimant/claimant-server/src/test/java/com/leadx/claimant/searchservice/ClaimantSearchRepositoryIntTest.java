package com.leadx.claimant.searchservice;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ContextConfiguration;

import com.leadx.claimant.client.search.SearchRequestDto;
import com.leadx.claimant.client.search.SearchResultClaimantDto;
import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.RequiresTestData;

@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class ClaimantSearchRepositoryIntTest extends AbstractIntegrationTest {
	
	@Autowired
	private ClaimantSearchRepository claimantSearchRepository;

	@Autowired
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Test
	@RequiresTestData(locations = "searchClaimant")
	public void searchClaimantBySurnameOnly() throws Exception {
		final SearchRequestDto searchRequestDto = new SearchRequestDto.Builder().setSurname("Thompson").createSearchRequestDto();
		final List<SearchResultClaimantDto> result = this.claimantSearchRepository.search(searchRequestDto);

		assertEquals(result.size(), 1);
		assertEquals(result.get(0).getClaimantId(), 4444444);
	}

	@Test
	@RequiresTestData(locations = "searchClaimant")
	public void searchClaimantBySurnamePartial() throws Exception {
		final SearchRequestDto searchRequestDto = new SearchRequestDto.Builder().setSurname("Thomps").createSearchRequestDto();
		final List<SearchResultClaimantDto> result = this.claimantSearchRepository.search(searchRequestDto);

		assertEquals(result.size(), 1);
		assertEquals(result.get(0).getClaimantId(), 4444444);
	}

	@Test
	@RequiresTestData(locations = "searchClaimant")
	public void searchClaimantByPostcodeOnly() throws Exception {
		final SearchRequestDto searchRequestDto = new SearchRequestDto.Builder().setPostcode("WA14 4DZ").createSearchRequestDto();
		final List<SearchResultClaimantDto> result = this.claimantSearchRepository.search(searchRequestDto);

		assertEquals(result.size(), 1);
		assertEquals(result.get(0).getClaimantId(), 1111111);
	}

	@Test
	@RequiresTestData(locations = "searchClaimant")
	public void searchClaimantByPostcodePartial() throws Exception {
		final SearchRequestDto searchRequestDto = new SearchRequestDto.Builder().setPostcode("WA14 4").createSearchRequestDto();
		final List<SearchResultClaimantDto> result = this.claimantSearchRepository.search(searchRequestDto);

		assertEquals(result.size(), 1);
		assertEquals(result.get(0).getClaimantId(), 1111111);
	}

	@Test
	@RequiresTestData(locations = "searchClaimant")
	public void searchClaimantByEmailOnly() throws Exception {
		final SearchRequestDto searchRequestDto = new SearchRequestDto.Builder().setEmail("anna@example.org").createSearchRequestDto();
		final List<SearchResultClaimantDto> result = this.claimantSearchRepository.search(searchRequestDto);

		assertEquals(result.size(), 1);
		assertEquals(result.get(0).getClaimantId(), 3333333);
	}

	@Test
	@RequiresTestData(locations = "searchClaimant")
	public void searchClaimantBySurnameAndPostcode() throws Exception {
		final SearchRequestDto searchRequestDto = new SearchRequestDto.Builder().setSurname("Thomas").setPostcode("WW99 4ZZ").createSearchRequestDto();
		final List<SearchResultClaimantDto> result = this.claimantSearchRepository.search(searchRequestDto);

		assertEquals(result.size(), 1);
		assertEquals(result.get(0).getClaimantId(), 2222222);
	}

	@Test
	@RequiresTestData(locations = "searchClaimant")
	public void searchClaimantBySurnameAndEmail() throws Exception {
		final SearchRequestDto searchRequestDto = new SearchRequestDto.Builder().setSurname("Thompson").setEmail("laura@example.edu").createSearchRequestDto();
		final List<SearchResultClaimantDto> result = this.claimantSearchRepository.search(searchRequestDto);

		assertEquals(result.size(), 1);
		assertEquals(result.get(0).getClaimantId(), 4444444);
	}
}