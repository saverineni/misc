package com.leadx.claimant.changelogservice;

import static com.google.common.collect.Sets.newHashSet;
import static com.leadx.claimant.util.ClaimantTestUtils.*;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.util.List;

import com.leadx.claimant.reference.VulnerableDetailTriState;
import org.joda.time.LocalDate;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.leadx.claimant.addressservice.Address;
import com.leadx.claimant.addressservice.AddressService;
import com.leadx.claimant.claimantservice.Claimant;
import com.leadx.claimant.claimantservice.ClaimantBuilder;
import com.leadx.claimant.claimantservice.ClaimantService;
import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.NoTestData;

@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class ChangeLogServiceIntTest extends AbstractIntegrationTest {

	@Autowired
	ChangeLogService changeLogService;

	@Autowired
	AddressService addressService;

	@Autowired
	ClaimantService claimantService;

	@Test
	@NoTestData
	public void testSaveAddressChangeValues() throws Exception {
		final Address oldAddress = new Address("dept", "", "subbuilding", "building", "23", "deptf", "tf", "ddl", "local", "town", "postcode", "county");
		this.addressService.saveAddress(0, oldAddress, true);
		
		final Claimant claimant = new ClaimantBuilder().setId(0)
				.setLeadId(1)
				.setSellerAccountId(2)
				.setSellerCompanyId(3)
				.setTitle("testTitle")
				.setForename("testForename")
				.setMiddleName("testMid")
				.setSurname("testSurname")
				.setPreviousSurname("testPrevSurname")
				.setDob(new LocalDate("1990-07-15"))
				.setAddressId(oldAddress.getId())
				.setHomeTelephone("01234567890")
				.setMobileTelephone("07712345678")
				.setAlternativeTelephone("01234567890")
				.setWorkTelephone("")
				.setEmail("test@test.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.setOtherNames(buildOtherNames("Name1", "Name2"))
				.setAdditionalPreviousNames(buildAdditionalPreviousNames("Name1", "Name2", "Name3"))
				.setClaimantUnpresentedCheque(buildClaimantUnpresentedCheque())
				.setHasVulnerability(false)
				.setVulnerabilityCategories(newHashSet())
				.setCanStoreVulnerabilityDetail(VulnerableDetailTriState.NO)
				.setVulnerabilityDetail("")
				.createClaimant();
		this.claimantService.createClaimant(claimant);
		
		final Address newAddress = new Address("new dept", "", "subbuilding", "building", "23", "deptf", "tf", "ddl", "local", "new town", "postcode", "county");
		newAddress.setId(oldAddress.getId());

		final List<ChangeItem> items = this.changeLogService.saveChangeValues(123, oldAddress, newAddress, 44);
		assertThat(items.size(), is(3));

		assertThat(items.get(0).getField(), is("address.DepartmentName"));
		assertThat(items.get(0).getOldString(), is("dept"));
		assertThat(items.get(0).getNewString(), is("new dept"));

		assertThat(items.get(1).getField(), is("address.Town"));
		assertThat(items.get(1).getOldString(), is("town"));
		assertThat(items.get(1).getNewString(), is("new town"));

		assertThat(items.get(0).getChangeGroup(), is(items.get(1).getChangeGroup()));
		assertThat(items.get(0).getChangeGroup().getClaimantId(), is(123));
		assertThat(items.get(0).getChangeGroup().getUserId(), is(44));
	}

	@Test
	@NoTestData
	public void testSaveAddressChangeValuesForNullAddresses() throws Exception {
		final Claimant claimant = new ClaimantBuilder().setId(0)
				.setLeadId(1)
				.setSellerAccountId(2)
				.setSellerCompanyId(3)
				.setTitle("testTitle")
				.setForename("testForename")
				.setMiddleName("testMid")
				.setSurname("testSurname")
				.setPreviousSurname("testPrevSurname")
				.setDob(new LocalDate("1990-07-15"))
				.setHomeTelephone("01234567890")
				.setMobileTelephone("07712345678")
				.setAlternativeTelephone("01234567890")
				.setWorkTelephone("")
				.setEmail("test@test.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.setOtherNames(buildOtherNames("Name1", "Name2"))
				.setAdditionalPreviousNames(buildAdditionalPreviousNames("Name3", "Name4", "Name5"))
				.setClaimantUnpresentedCheque(buildClaimantUnpresentedCheque())
				.setHasVulnerability(false)
				.setVulnerabilityCategories(newHashSet())
				.setCanStoreVulnerabilityDetail(VulnerableDetailTriState.NO)
				.setVulnerabilityDetail("")
				.createClaimant();
		this.claimantService.createClaimant(claimant);
		
		final List<ChangeItem> items = this.changeLogService.saveChangeValues(123, null, null, 44);
		assertThat(items.size(), is(0));
	}

	@Test
	@NoTestData
	public void testSaveClaimantChangeValues() throws Exception {
		final Claimant oldClaimant = new ClaimantBuilder().setId(0)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("matt")
				.setMiddleName("middle")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("56789")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.setOtherNames(buildOtherNames("Name1", "Name2"))
				.setAdditionalPreviousNames(buildAdditionalPreviousNames("Name3", "Name4", "Name5"))
				.setClaimantUnpresentedCheque(buildClaimantUnpresentedCheque())
				.setHasVulnerability(false)
				.setVulnerabilityCategories(newHashSet())
				.setCanStoreVulnerabilityDetail(VulnerableDetailTriState.NO)
				.setVulnerabilityDetail("")
				.createClaimant();
		this.claimantService.createClaimant(oldClaimant);

		final Claimant newClaimant = new ClaimantBuilder().setId(0)
				.setLeadId(345)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("matt")
				.setMiddleName("guy")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("56789")
				.setWorkTelephone("2345")
				.setEmail("me2@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.setOtherNames(buildOtherNames("Name1", "Name2"))
				.setAdditionalPreviousNames(buildAdditionalPreviousNames("Name3", "Name4", "Name5"))
				.setClaimantUnpresentedCheque(buildClaimantUnpresentedCheque())
				.setHasVulnerability(false)
				.setVulnerabilityCategories(newHashSet())
				.setCanStoreVulnerabilityDetail(VulnerableDetailTriState.NO)
				.setVulnerabilityDetail("")
				.createClaimant();
		newClaimant.setId(oldClaimant.getId());

		final List<ChangeItem> items = this.changeLogService.saveChangeValues(123, oldClaimant, newClaimant, 44);
		assertThat(items.size(), is(2));

		assertThat(items.get(0).getField(), is("claimant.MiddleName"));
		assertThat(items.get(0).getOldString(), is("middle"));
		assertThat(items.get(0).getNewString(), is("guy"));

		assertThat(items.get(1).getField(), is("claimant.Email"));
		assertThat(items.get(1).getOldString(), is("me@me.com"));
		assertThat(items.get(1).getNewString(), is("me2@me.com"));
	}
}
