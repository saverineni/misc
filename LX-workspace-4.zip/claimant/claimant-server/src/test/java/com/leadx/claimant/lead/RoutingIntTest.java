package com.leadx.claimant.lead;

import static com.leadx.test.integration.TestDataRowCounter.assertRowCount;

import javax.annotation.Resource;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.RoutesBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.joda.time.DateTime;
import org.joda.time.DateTimeUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.leadx.lib.utl.SqlMap;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class RoutingIntTest {

	@Autowired
	private ProducerTemplate producerTemplate;

	@Autowired
	private CamelContext camelContext;

	@Resource(name = "claimantNamedParameterJdbcOperations")
	private NamedParameterJdbcOperations jdbcOperations;

	private static final String MOCK_FAILURE = "mock:failure";
	private MockEndpoint failureEndpoint;

	private static final String MOCK_TELEPHONY = "mock:telephony";
	private MockEndpoint telephonyEndpoint;

	private static final String MOCK_DISTRIBUTION = "mock:distribution";
	private MockEndpoint distributionEndpoint;

	@Autowired
	private RoutesBuilder routing;

	private final String VALID_MESSAGE = "{\"leadId\" : 22198639, " +
								         "\"transactionDetailId\" : 12755471, " +
								         "\"sellerAccountId\" : 11775, " +
								         "\"sellerCompanyId\" : 8, " +
								         "\"assignedClaimConsultantId\" : 0, " +
								         "\"note\" : \"Claim created from TCG website\", " +
								         "\"claimant\" : { " +
        								 	"\"title\" : \"Mr\", " +
        								 	"\"forename\" : \"test\", " +
        								 	"\"surname\" : \"person\", " +
        								 	"\"dob\" : \"1988-11-21\", " +
        								 	"\"homeTelephone\" : \"01234567890\", " +
        								 	"\"mobileTelephone\" : \"07777777777\", " +
        								 	"\"email\" : \"test@testing.co.uk\" " +
                						"}, " +
                						"\"address\" : { " +
            								 "\"departmentName\" : \"\", " +
            								 "\"organisationName\" : \"\", " +
            								 "\"buildingName\" : \"Test Building\", " +
            								 "\"thoroughfare\" : \"Test Road\", " +
            								 "\"postcode\" : \"WA14 4DL\" " +
                    					"}, " +
                    					 "\"appointment\" : { " +
                    					 	"\"madeBy\" : 0, " +
                							"\"madeByName\" : \"\", " +
                							"\"requestedDateTime\" : \"2014-10-02 09:00:00\" " +
                        				"}, " +
										"\"previousAddresses\" : [ " +
											" { " +
												"\"buildingName\" : \"test prev\", " +
												"\"postcode\" : \"wa14 4dz\" " +
											" } " +
										" ], " +
										"\"agreements\" : [] " +
                        				"}";

	@Before
	public void before() throws Exception {

		DateTimeUtils.setCurrentMillisFixed(new DateTime(2013, 8, 10, 12, 30, 45, 0).getMillis());

		this.camelContext.removeComponent("jms");
		this.camelContext.addComponent("jms", this.camelContext.getComponent("seda"));
		this.camelContext.addRoutes(this.routing);
		redirectFailuresToMockFailureEndpoint();
		redirectTelephonyToMockTelephonyEndpoint();
		redirectTelephonyToMockDistributionEndpoint();

		this.jdbcOperations.update("DELETE FROM claimant", SqlMap.create());
		this.jdbcOperations.update("DELETE FROM address", SqlMap.create());
	}

	@Test
	@DirtiesContext
	public void testFailure() throws InterruptedException {
		assertDatabaseIsEmpty();

		this.producerTemplate.sendBody("jms:leadservices-claimant-leads", "some dodgy message");

		wait(5000);

		assertRowCount(this.jdbcOperations, "claimant", 0);
		assertRowCount(this.jdbcOperations, "address", 0);

		this.failureEndpoint.setExpectedMessageCount(1);
		this.failureEndpoint.assertIsSatisfied();
	}

	@Test
	@DirtiesContext
	public void testSuccess() throws InterruptedException {
		assertDatabaseIsEmpty();

		this.producerTemplate.sendBody("jms:leadservices-claimant-leads", this.VALID_MESSAGE);

		wait(5000);

		assertRowCount(this.jdbcOperations, "claimant", 1);
		assertRowCount(this.jdbcOperations, "address", 2);

		this.telephonyEndpoint.setExpectedMessageCount(1);
		this.telephonyEndpoint.assertIsSatisfied();

		this.distributionEndpoint.setExpectedMessageCount(2);
		this.distributionEndpoint.assertIsSatisfied();
	}

	@Test
	@DirtiesContext
	public void testBatchedSuccess() throws InterruptedException {
		assertDatabaseIsEmpty();

		this.producerTemplate.sendBody("jms:leadservices-claimant-leads", this.VALID_MESSAGE);
		this.producerTemplate.sendBody("jms:leadservices-claimant-leads", this.VALID_MESSAGE);
		this.producerTemplate.sendBody("jms:leadservices-claimant-leads", this.VALID_MESSAGE);
		this.producerTemplate.sendBody("jms:leadservices-claimant-leads", this.VALID_MESSAGE);

		wait(6000);

		assertRowCount(this.jdbcOperations, "claimant", 4);
		assertRowCount(this.jdbcOperations, "address", 8);

		this.telephonyEndpoint.setExpectedMessageCount(4);
		this.telephonyEndpoint.assertIsSatisfied();

		this.distributionEndpoint.setExpectedMessageCount(8);
		this.distributionEndpoint.assertIsSatisfied();
	}

	private void assertDatabaseIsEmpty() {
		assertRowCount(this.jdbcOperations, "claimant", 0);
		assertRowCount(this.jdbcOperations, "address", 0);
	}

	private void redirectFailuresToMockFailureEndpoint() throws Exception {
		this.failureEndpoint = this.camelContext.getEndpoint(MOCK_FAILURE, MockEndpoint.class);
		this.camelContext.addRoutes(new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("jms:leadservices-claimant-leads-error").to(MOCK_FAILURE);
			}
		});
	}

	private void redirectTelephonyToMockTelephonyEndpoint() throws Exception {
		this.telephonyEndpoint = this.camelContext.getEndpoint(MOCK_TELEPHONY, MockEndpoint.class);
		this.camelContext.addRoutes(new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("jms:upload-call-to-dialler").to(MOCK_TELEPHONY);
			}
		});
	}

	private void redirectTelephonyToMockDistributionEndpoint() throws Exception {
		this.distributionEndpoint = this.camelContext.getEndpoint(MOCK_DISTRIBUTION, MockEndpoint.class);
		this.camelContext.addRoutes(new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("jms:distribution-queue-pending").to(MOCK_DISTRIBUTION);
			}
		});
	}

	private static void wait(final int periodInMs) throws InterruptedException {
		Thread.sleep(periodInMs);
	}
}
