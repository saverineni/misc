package com.leadx.claimant.callallocationservice;

import static com.leadx.test.MockUtils.mockAndSetOn;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.leadx.claimant.claimantservice.Claimant;
import com.leadx.claimant.claimantservice.ClaimantBuilder;
import com.leadx.claimant.claimantservice.ClaimantService;
import com.leadx.services.client.TCGCallCancellation;
import com.leadx.services.client.TcgCallRequest;
import com.leadx.services.client.TcgProduct;
import com.leadx.services.client.service.TelephonyService;
import com.leadx.test.integration.NoTestData;

@SuppressWarnings("unqualified-field-access")
public class TelephonyHelperUnitTest {


	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
		}
	};


	@Autowired
	protected TelephonyHelper telephonyHelper;

	protected TelephonyService telephonyService;
	protected ClaimantService claimantService;

	private static final int CLAIMANT_ID = 12345;
	private static final int USERID = 123;

	@Before
	public void setUp() {
		this.telephonyHelper = new TelephonyHelper();
		this.telephonyService = mockAndSetOn(this.context, TelephonyService.class, this.telephonyHelper);
		this.claimantService = mockAndSetOn(this.context, ClaimantService.class, this.telephonyHelper);
	}

	@Test
	@NoTestData
	public void testCreateClaimantPpiChaseCall() {
		final Claimant claimant = newDummyClaimant("0777777777");
		final TcgProduct tcgProduct = TcgProduct.PPI;

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(telephonyService).scheduleCall(with(any(TcgCallRequest.class)));

			}
		});

		this.telephonyHelper.createClaimantChaseCall(claimant, tcgProduct);
	}

	@Test
	@NoTestData
	public void testCreateClaimantPbaChaseCall() {
		final Claimant claimant = newDummyClaimant("0777777777");
		final TcgProduct tcgProduct = TcgProduct.PBA;

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(telephonyService).scheduleCall(with(any(TcgCallRequest.class)));

			}
		});

		this.telephonyHelper.createClaimantChaseCall(claimant, tcgProduct);
	}

	@Test
	@NoTestData
	public void testCreateClaimantCombinedChaseCall() {
		final Claimant claimant = newDummyClaimant("0777777777");
		final TcgProduct tcgProduct = TcgProduct.COMBINED;

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(telephonyService).scheduleCall(with(any(TcgCallRequest.class)));

			}
		});

		this.telephonyHelper.createClaimantChaseCall(claimant, tcgProduct);
	}

	@Test
	public void testCreateClaimantPpiChaseCallWithNoPhoneNumber() {
		final Claimant claimant = newDummyClaimant("");
		final TcgProduct tcgProduct = TcgProduct.PPI;

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
			}
		});

		this.telephonyHelper.createClaimantChaseCall(claimant, tcgProduct);
	}

	@Test
	public void testCreateClaimantPbaChaseCallWithNoPhoneNumber() {
		final Claimant claimant = newDummyClaimant("");
		final TcgProduct tcgProduct = TcgProduct.PBA;

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
			}
		});

		this.telephonyHelper.createClaimantChaseCall(claimant, tcgProduct);
	}

	@Test
	public void testCreateClaimantCombinedChaseCallWithNoPhoneNumber() {
		final Claimant claimant = newDummyClaimant("");
		final TcgProduct tcgProduct = TcgProduct.COMBINED;

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
			}
		});

		this.telephonyHelper.createClaimantChaseCall(claimant, tcgProduct);
	}

	@Test
	public void testCancelClaimantPpiChaseCall(){
		final TcgProduct tcgProduct = TcgProduct.PPI;

		this.context.checking(new Expectations() {
			{
				oneOf(telephonyService).cancelCall(with(any(TCGCallCancellation.class)));
			}
		});

		this.telephonyHelper.cancelClaimantChaseCall(CLAIMANT_ID, USERID, tcgProduct);
	}

	@Test
	public void testCancelClaimantPbaChaseCall(){
		final TcgProduct tcgProduct = TcgProduct.PBA;

		this.context.checking(new Expectations() {
			{
				oneOf(telephonyService).cancelCall(with(any(TCGCallCancellation.class)));
			}
		});

		this.telephonyHelper.cancelClaimantChaseCall(CLAIMANT_ID, USERID, tcgProduct);
	}

	@Test
	public void testCancelClaimantCombinedChaseCall(){
		final TcgProduct tcgProduct = TcgProduct.COMBINED;

		this.context.checking(new Expectations() {
			{
				oneOf(telephonyService).cancelCall(with(any(TCGCallCancellation.class)));
			}
		});

		this.telephonyHelper.cancelClaimantChaseCall(CLAIMANT_ID, USERID, tcgProduct);
	}

	private static Claimant newDummyClaimant(final String mobileTelephone) {
		return new ClaimantBuilder().setId(CLAIMANT_ID).setMobileTelephone(mobileTelephone).createClaimant();
	}



}
