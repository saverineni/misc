package com.leadx.claimant.calllogservice;

import static org.hamcrest.Matchers.is;
import static org.jmock.lib.legacy.ClassImposteriser.INSTANCE;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.OptimisticLockException;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.LoggerFactory;
import org.springframework.core.convert.converter.Converter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import ch.qos.logback.classic.Level;
import ch.qos.logback.core.AppenderBase;

import com.google.common.collect.ImmutableList;
import com.leadx.claimant.client.CallLogDto;
import com.leadx.lib.utl.json.JsonUtils;

public class CallLogControllerTest {

	private final Mockery context = new Mockery() {
		{
			setImposteriser(INSTANCE);
		}
	};

	private CallLogController callLogController;
	private Converter<CallLogDto, CallLog> callLogDtoConverter;
	private CallLogService callLogService;
	private List<String> errorMessages;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Before
	public void setUp() {
		this.callLogController = new CallLogController();

		this.callLogDtoConverter = this.context.mock(CallLogDtoConverter.class);
		ReflectionTestUtils.setField(this.callLogController, "callLogDtoConverter", this.callLogDtoConverter);
		this.callLogService = this.context.mock(CallLogService.class);
		ReflectionTestUtils.setField(this.callLogController, "callLogService", this.callLogService);

		// Add a log appender to capture all the error messages
		final ch.qos.logback.classic.Logger log = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(CallLogController.class);
		log.setLevel(Level.WARN);
		this.errorMessages = new ArrayList<>();

		final AppenderBase appender = new AppenderBase() {
			@Override
			protected void append(final Object eventObject) {
				CallLogControllerTest.this.errorMessages.add(eventObject.toString());
			}
		};

		appender.start();
		log.addAppender(appender);
	}


	@Test
	public void testSaveCallLog() {
		final CallLogDto callLogDto = new CallLogDto();
		callLogDto.setDiallerReferenceId(99);
		final CallLog callLog = new CallLog();
		callLog.setDiallerReferenceId(99);
		final String callLogDtoString = JsonUtils.serialize(callLogDto, true);

		this.context.checking(new Expectations() {
			{
				oneOf(CallLogControllerTest.this.callLogDtoConverter).convert(callLogDto);
				will(returnValue(callLog));
				oneOf(CallLogControllerTest.this.callLogService).saveCallLog(callLog);
				will(returnValue(true));
			}
		});

		final ResponseEntity<String> response = this.callLogController.saveCallLog(callLogDtoString);
		assertThat(response.getStatusCode(), is(HttpStatus.OK));
	}

	@Test
	public void testSaveCallLogFailed() {
		final CallLogDto callLogDto = new CallLogDto();
		callLogDto.setDiallerReferenceId(99);
		final CallLog callLog = new CallLog();
		callLog.setDiallerReferenceId(99);
		final String callLogDtoString = JsonUtils.serialize(callLogDto, true);

		this.context.checking(new Expectations() {
			{
				oneOf(CallLogControllerTest.this.callLogDtoConverter).convert(callLogDto);
				will(returnValue(callLog));
				oneOf(CallLogControllerTest.this.callLogService).saveCallLog(callLog);
				will(returnValue(false));
			}
		});

		final ResponseEntity<String> response = this.callLogController.saveCallLog(callLogDtoString);
		assertThat(response.getStatusCode(), is(HttpStatus.OK));
	}

	@Test
	public void testSaveCallLogWithException() {
		final CallLogDto callLogDto = new CallLogDto();
		callLogDto.setDiallerReferenceId(99);
		final CallLog callLog = new CallLog();
		callLog.setDiallerReferenceId(99);
		final String callLogDtoString = JsonUtils.serialize(callLogDto, true);

		this.context.checking(new Expectations() {
			{
				oneOf(CallLogControllerTest.this.callLogDtoConverter).convert(callLogDto);
				will(returnValue(callLog));
				oneOf(CallLogControllerTest.this.callLogService).saveCallLog(callLog);
				will(throwException(new OptimisticLockException()));
			}
		});

		boolean exceptionThrown = false;
		try {
			this.callLogController.saveCallLog(callLogDtoString);
		} catch ( final OptimisticLockException e ) {
			exceptionThrown = true;
		}

		assertThat(exceptionThrown, is(true));
		assertThat(this.errorMessages.size(), is(1));
		assertThat(this.errorMessages.get(0),is("[WARN] saveCallLog failed for claimant: 0 failed because of because of an optimistic locking exception."));
	}

	@Test
	public void testFindCallLogsForClaimant() throws Exception {
		final List<CallLogDto> dtos = ImmutableList.of(new CallLogDto(), new CallLogDto());
		this.context.checking(new Expectations() {
			{
				oneOf(CallLogControllerTest.this.callLogService).findCallLogsForClaimant(99);
				will(returnValue(dtos));
			}
		});

		assertThat(this.callLogService.findCallLogsForClaimant(99), is(dtos));
	}

}