package com.leadx.claimant.selleraccountservice;

import static com.leadx.test.MockUtils.mockAndSetOn;
import static org.junit.Assert.assertFalse;

import java.util.List;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.concurrent.Synchroniser;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.Lists;
import com.leadx.claimant.client.MethodOfContact;
import com.leadx.claimant.client.SellerAccountDto;

@SuppressWarnings("unqualified-field-access")
public class SellerAccountServiceUnitTest {

	private SellerAccountService sellerAccountService;
	private SellerAccountRepository sellerAccountRepository;
	private DropdownConfigurationRepository dropdownConfigurationRepository;

	private static final int SELLER_ACCOUNT_ID = 9785;
	private final Synchroniser synchroniser = new Synchroniser();

	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
			setThreadingPolicy(SellerAccountServiceUnitTest.this.synchroniser);
		}
	};

	@Before
	public void setUp() {
		this.sellerAccountService = new SellerAccountService();
		this.sellerAccountRepository = mockAndSetOn(this.context, SellerAccountRepository.class, this.sellerAccountService);
		this.dropdownConfigurationRepository = mockAndSetOn(this.context, DropdownConfigurationRepository.class, this.sellerAccountService);
	}

	@Test
	public void testCreateSellerAccount() {
		final SellerAccount sellerAccount  = newDummySellerAccount();

		this.context.checking(new Expectations() {
			{
				oneOf(sellerAccountRepository).create(sellerAccount);
			}
		});

		this.sellerAccountService.create(sellerAccount);
	}

	@Test
	public void testUpdateSellerAccount() {
		final SellerAccount sellerAccount = newDummySellerAccount();

		this.context.checking(new Expectations() {
			{
				oneOf(sellerAccountRepository).getByAccountId(sellerAccount.getAccountId());
				will(returnValue(sellerAccount));
				oneOf(sellerAccountRepository).evict(sellerAccount);
				oneOf(sellerAccountRepository).update(sellerAccount);
			}
		});

		this.sellerAccountService.update(sellerAccount);
	}

	@Test
	public void testGetById() {
		final SellerAccount sellerAccount  = newDummySellerAccount();
		this.context.checking(new Expectations() {
			{
				oneOf(sellerAccountRepository).getByAccountId(SELLER_ACCOUNT_ID);
				will(returnValue(sellerAccount));
			}
		});

		this.sellerAccountService.getByAccountId(SELLER_ACCOUNT_ID);
	}

	@Test
	public void testGetAll() {
		final List<SellerAccountDto> sellerAccountDtos = Lists.newArrayList();
		this.context.checking(new Expectations() {
			{
				oneOf(sellerAccountRepository).getAll();
				will(returnValue(sellerAccountDtos));
			}
		});

		this.sellerAccountService.getAll();
	}

	@Test
	public void testGetSourcedSellerAccounts() {
		final List<SellerAccountDto> sellerAccountDtos = Lists.newArrayList();
		this.context.checking(new Expectations() {
			{
				oneOf(sellerAccountRepository).getSourcedSellerAccounts();
				will(returnValue(sellerAccountDtos));
			}
		});

		this.sellerAccountService.getSourcedSellerAccounts();
	}

	@Test
	public void testGetDropdownItemsForField() {
		final List<DropdownConfiguration> expected = Lists.newArrayList();

		this.context.checking(new Expectations() {
			{
				oneOf(dropdownConfigurationRepository).getDropdownItemsForField("seller_gpSellerAccount");
				will(returnValue(expected));
			}
		});

		this.sellerAccountService.getDropdownItemsForField("seller_gpSellerAccount");
	}

	@Test
	public void isFreePpi() {
		final int sellerAccountId = 1234;
		final boolean freePpi = false;
		this.context.checking(new Expectations() {
			{
				oneOf(sellerAccountRepository).isFreePpi(sellerAccountId);
				will(returnValue(freePpi));
			}
		});

		boolean result = this.sellerAccountService.isFreePpi(sellerAccountId);
		assertFalse(result);
	}


	private static SellerAccount newDummySellerAccount() {
		final SellerAccount acc = new SellerAccount(SELLER_ACCOUNT_ID,"SWINTON", "Swinton", "Swinton", "Partner introduction", MethodOfContact.telephone, "SWINTON_LOGO.swf", "tcg_pack_swinton", true, "swinton", "DirectUploadClaimAppointmentSmsScript", "DirectUploadPartnerClaimAppointmentEmailScript", "swinton.jpg", false);
		final ProductType selected = new ProductType(1, "ppi");
		acc.setProductType(selected);
		return acc;
	}
}