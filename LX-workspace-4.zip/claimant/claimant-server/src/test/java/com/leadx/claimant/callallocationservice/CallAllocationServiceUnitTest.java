package com.leadx.claimant.callallocationservice;

import static com.leadx.claimant.callallocationservice.CallAllocationService.callReasonGroupForProduct;
import static com.leadx.test.MockUtils.mockAndSetOn;
import static java.util.stream.Collectors.toList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.util.Arrays;
import java.util.List;


import org.apache.commons.collections.CollectionUtils;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.joda.time.DateTime;
import org.joda.time.DateTimeUtils;
import org.joda.time.LocalDateTime;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestOperations;

import com.google.common.collect.Lists;
import com.leadx.claimant.claimantservice.Claimant;
import com.leadx.claimant.claimantservice.ClaimantBuilder;
import com.leadx.claimant.claimantservice.ClaimantService;
import com.leadx.claimincubation.client.wrappers.ClaimServiceWrapper;
import com.leadx.services.client.CallReason;
import com.leadx.services.client.TcgProduct;

@SuppressWarnings("unqualified-field-access")

public class CallAllocationServiceUnitTest {

	@Autowired
	protected CallAllocationService callAllocationService;

	private ClaimantService claimantService;

	protected ClaimantGroupAllocationRepository claimantGroupAllocationRepository;

	private ClaimServiceWrapper claimServiceWrapper;

	private RestOperations restOperations;

	private TelephonyHelper telephonyHelper;

	private static final String EXPECTED_URL = "http://test.com:8080";
	private static final ResponseEntity<String> SUCCESSFUL_RESPONSE = new ResponseEntity<String>(HttpStatus.OK);

	private static final int OFFSETDAYS = 1;
	private static final String RECENTLY_UNLOCKED_CLAIMANTS = "111,222,333";
	private static final int CLAIMANT_ID = 12345;
	private static final int USER_ID = 3388;

	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
		}
	};

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Before
	public void setUp() {

		DateTimeUtils.setCurrentMillisFixed(new DateTime(2011, 3, 15, 15, 0, 0).getMillis());
		this.callAllocationService = new CallAllocationService();
		this.claimantService = mockAndSetOn(this.context, ClaimantService.class, this.callAllocationService);
		this.claimantGroupAllocationRepository = mockAndSetOn(this.context, ClaimantGroupAllocationRepository.class, this.callAllocationService);
		this.claimServiceWrapper = mockAndSetOn(this.context, ClaimServiceWrapper.class, this.callAllocationService);
		this.restOperations = this.context.mock(RestOperations.class);
		this.callAllocationService.setRestOperations(this.restOperations);
		this.telephonyHelper = this.context.mock(TelephonyHelper.class);
		this.callAllocationService.setTelephonyHelper(this.telephonyHelper);
		ReflectionTestUtils.setField(this.callAllocationService, "tcgProtocol", "http");
		ReflectionTestUtils.setField(this.callAllocationService, "tcgHost", "test.com");
		ReflectionTestUtils.setField(this.callAllocationService, "tcgPort", "8080");

	}

	@Test
	public void testCreateTcgAllocationClaimantList() {

		this.context.checking(new Expectations() {
			{
				oneOf(restOperations).getForEntity(EXPECTED_URL + "/unsecure/claimant/generateActiveClaimsClaimantList/offsetDays/" + OFFSETDAYS + "/recentlyUnlockedClaimants/" + RECENTLY_UNLOCKED_CLAIMANTS + ".form", List.class);
				will(returnValue(SUCCESSFUL_RESPONSE));
			}
		});

		this.callAllocationService.createTcgCallAllocationClaimantList(OFFSETDAYS, RECENTLY_UNLOCKED_CLAIMANTS);
	}

	@Test
	public void testUpdateCallAllocations() {
		final List<Integer> claimantsFromTcg = Lists.newArrayList(1,2,3,4,5,6);
		final List<Integer> claimantsFromClaimIncubation = Lists.newArrayList(3,4,5,6,7,8);
		final List<Integer> expectedPpiOnly = Lists.newArrayList(1,2);
		final List<Integer> expectedPbaOnly = Lists.newArrayList(7,8);
		final List<Integer> expectedCombined = Lists.newArrayList(3,4,5,6);
		final List<Integer> recentlyUnlockedClaimants = Arrays.asList(RECENTLY_UNLOCKED_CLAIMANTS.split(","))
																	.stream()
																	.map(Integer::valueOf)
																	.collect(toList());

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getRecentlyUnlockedClaimants(OFFSETDAYS);
				will(returnValue(recentlyUnlockedClaimants));
				oneOf(claimServiceWrapper).generateActiveClaimsClaimantList(OFFSETDAYS, RECENTLY_UNLOCKED_CLAIMANTS);
				oneOf(restOperations).getForEntity(EXPECTED_URL + "/unsecure/claimant/generateActiveClaimsClaimantList/offsetDays/" + OFFSETDAYS + "/recentlyUnlockedClaimants/" + RECENTLY_UNLOCKED_CLAIMANTS + ".form",  List.class);
			}
		});

		this.callAllocationService.updateCallAllocations(OFFSETDAYS);

		final List<Integer> actualCombined = (List) CollectionUtils.intersection(claimantsFromTcg, claimantsFromClaimIncubation);
		claimantsFromTcg.removeAll(actualCombined);
		claimantsFromClaimIncubation.removeAll(actualCombined);

		assertThat(actualCombined, is(expectedCombined));
		assertThat(expectedPpiOnly, is(claimantsFromTcg));
		assertThat(expectedPbaOnly, is(claimantsFromClaimIncubation));

	}

	@Test
	public void updateCallAllocationsWhenCombinedCallExists() {
		final Claimant claimant = newDummyClaimant();
		final String existingCallReason = CallReason.CHASE;
		final String existingCallReasonGroup = callReasonGroupForProduct(TcgProduct.COMBINED);
		final ClaimantGroupAllocation existingClaimantGroupAllocation = new ClaimantGroupAllocation(CLAIMANT_ID, existingCallReason, existingCallReasonGroup);

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(claimantGroupAllocationRepository).checkClaimantCallGroupAllocationEntry(CLAIMANT_ID);
				will(returnValue(true));
				oneOf(claimantGroupAllocationRepository).getClaimantGroupAllocationByClaimantId(CLAIMANT_ID);
				will(returnValue(existingClaimantGroupAllocation));
				never(telephonyHelper);
				never(claimantGroupAllocationRepository);
			}
		});

		this.callAllocationService.updateClaimantsGroupAllocation(CLAIMANT_ID, TcgProduct.PBA);
	}

	@Test
	public void updateCallAllocationsWhenCallExistsForProduct() {
		final Claimant claimant = newDummyClaimant();
		final String existingCallReason = CallReason.CHASE;
		final String existingCallReasonGroup = callReasonGroupForProduct(TcgProduct.PBA);
		final ClaimantGroupAllocation existingClaimantGroupAllocation = new ClaimantGroupAllocation(CLAIMANT_ID, existingCallReason, existingCallReasonGroup);

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(claimantGroupAllocationRepository).checkClaimantCallGroupAllocationEntry(CLAIMANT_ID);
				will(returnValue(true));
				oneOf(claimantGroupAllocationRepository).getClaimantGroupAllocationByClaimantId(CLAIMANT_ID);
				will(returnValue(existingClaimantGroupAllocation));
				never(telephonyHelper);
				never(claimantGroupAllocationRepository);
			}
		});

		this.callAllocationService.updateClaimantsGroupAllocation(CLAIMANT_ID, TcgProduct.PBA);
	}

	@Test
	public void updateCallAllocationsWhenCallExistsForDifferentProduct() {
		final Claimant claimant = newDummyClaimant();
		final String existingCallReason = CallReason.CHASE;
		final String existingCallReasonGroup = callReasonGroupForProduct(TcgProduct.PPI);
		final ClaimantGroupAllocation existingClaimantGroupAllocation = new ClaimantGroupAllocation(CLAIMANT_ID, existingCallReason, existingCallReasonGroup);
		final ClaimantGroupAllocation newClaimantGroupAllocation = new ClaimantGroupAllocation(CLAIMANT_ID, existingCallReason, callReasonGroupForProduct(TcgProduct.COMBINED));

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(claimantGroupAllocationRepository).checkClaimantCallGroupAllocationEntry(CLAIMANT_ID);
				will(returnValue(true));
				oneOf(claimantGroupAllocationRepository).getClaimantGroupAllocationByClaimantId(CLAIMANT_ID);
				will(returnValue(existingClaimantGroupAllocation));
				oneOf(telephonyHelper).cancelClaimantChaseCall(CLAIMANT_ID, USER_ID, TcgProduct.PPI);
				oneOf(claimantGroupAllocationRepository).deleteClaimantCallGroupAllocationEntry(existingClaimantGroupAllocation);
				oneOf(claimantGroupAllocationRepository).insertClaimantCallGroupAllocationEntry(newClaimantGroupAllocation);
				oneOf(telephonyHelper).createClaimantChaseCall(claimant, TcgProduct.COMBINED);
			}
		});

		this.callAllocationService.updateClaimantsGroupAllocation(CLAIMANT_ID, TcgProduct.PBA);
	}

	@Test
	public void testAddChaseCallCombined() {
		final Claimant claimant = newDummyClaimant();

		this.context.checking(new Expectations() {
			{
				oneOf(telephonyHelper).createClaimantChaseCall(claimant, TcgProduct.COMBINED);
			}
		});

		this.callAllocationService.addChaseCall(claimant, TcgProduct.COMBINED);

	}

	@Test
	public void testAddChaseCallPpi() {
		final Claimant claimant = newDummyClaimant();

		this.context.checking(new Expectations() {
			{
				oneOf(telephonyHelper).createClaimantChaseCall(claimant, TcgProduct.PPI);
			}
		});

		this.callAllocationService.addChaseCall(claimant, TcgProduct.PPI);

	}

	@Test
	public void testAddChaseCallPba() {
		final Claimant claimant = newDummyClaimant();

		this.context.checking(new Expectations() {
			{
				oneOf(telephonyHelper).createClaimantChaseCall(claimant, TcgProduct.PBA);
			}
		});

		this.callAllocationService.addChaseCall(claimant, TcgProduct.PBA);

	}

	@Test
	public void testCancelCallAllocationPpi() {
		final Claimant claimant = newDummyClaimant();

		final ClaimantGroupAllocation claimantGroupAllocation = new ClaimantGroupAllocation(CLAIMANT_ID, "chase", "COMBINED");

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(claimantGroupAllocationRepository).getClaimantGroupAllocationByClaimantId(CLAIMANT_ID);
				will(returnValue(claimantGroupAllocation));
				oneOf(telephonyHelper).cancelClaimantChaseCall(CLAIMANT_ID, USER_ID, TcgProduct.PPI);
				oneOf(claimantGroupAllocationRepository).updateClaimantCallGroupAllocationEntry(claimantGroupAllocation);
				oneOf(telephonyHelper).createClaimantChaseCall(claimant, TcgProduct.PBA);
				oneOf(claimantGroupAllocationRepository).deleteClaimantCallGroupAllocationEntry(claimantGroupAllocation);
			}
		});

		this.callAllocationService.cancelCallAllocation(CLAIMANT_ID, USER_ID, TcgProduct.PPI);

	}

	@Test
	public void testCancelCallAllocationPba() {
		final ClaimantGroupAllocation claimantGroupAllocation = new ClaimantGroupAllocation(CLAIMANT_ID, "chase", "COMBINED");
		final Claimant claimant = newDummyClaimant();

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(claimantGroupAllocationRepository).getClaimantGroupAllocationByClaimantId(CLAIMANT_ID);
				will(returnValue(claimantGroupAllocation));
				oneOf(telephonyHelper).cancelClaimantChaseCall(CLAIMANT_ID, USER_ID, TcgProduct.PBA);
				oneOf(claimantGroupAllocationRepository).updateClaimantCallGroupAllocationEntry(claimantGroupAllocation);
				oneOf(telephonyHelper).createClaimantChaseCall(claimant, TcgProduct.PPI);
				oneOf(claimantGroupAllocationRepository).deleteClaimantCallGroupAllocationEntry(claimantGroupAllocation);
			}
		});

		this.callAllocationService.cancelCallAllocation(CLAIMANT_ID, USER_ID, TcgProduct.PBA);

	}

	@Test
	public void testAddingAnInboundCallbackToAPreExistingClaimant() {
		final Claimant claimant = newDummyClaimant();
		final LocalDateTime callbackDateTime = new LocalDateTime(2015, 9, 22, 9, 0, 0);
		final ClaimantGroupAllocation claimantGroupAllocation = new ClaimantGroupAllocation(CLAIMANT_ID, "chase", "ppi");

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(claimantGroupAllocationRepository).checkClaimantCallGroupAllocationEntry(CLAIMANT_ID);
				will(returnValue(true));
				oneOf(claimantGroupAllocationRepository).getClaimantGroupAllocationByClaimantId(CLAIMANT_ID);
				will(returnValue(claimantGroupAllocation));
				oneOf(telephonyHelper).cancelClaimantChaseCall(CLAIMANT_ID, USER_ID, TcgProduct.PPI);
				oneOf(telephonyHelper).createClaimantChaseCall(claimant, TcgProduct.PPI, callbackDateTime);
			}
		});

		this.callAllocationService.updateClaimantsGroupAllocation(CLAIMANT_ID, TcgProduct.PPI, callbackDateTime);
	}

	@Test
	public void testAddingAnInboundCallbackToANewClaimant() {
		final Claimant claimant = newDummyClaimant();
		final LocalDateTime callbackDateTime = new LocalDateTime(2015, 9, 22, 9, 0, 0);
		final ClaimantGroupAllocation claimantGroupAllocation = new ClaimantGroupAllocation(CLAIMANT_ID, "chase", "pba");

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(claimantGroupAllocationRepository).checkClaimantCallGroupAllocationEntry(CLAIMANT_ID);
				will(returnValue(false));
				oneOf(claimantGroupAllocationRepository).insertClaimantCallGroupAllocationEntry(claimantGroupAllocation);
				oneOf(telephonyHelper).cancelClaimantChaseCall(CLAIMANT_ID, USER_ID, TcgProduct.PBA);
				oneOf(telephonyHelper).createClaimantChaseCall(claimant, TcgProduct.PBA, callbackDateTime);
			}
		});

		this.callAllocationService.updateClaimantsGroupAllocation(CLAIMANT_ID, TcgProduct.PBA, callbackDateTime);
	}

	private static Claimant newDummyClaimant() {
		return new ClaimantBuilder().setId(CLAIMANT_ID).createClaimant();
	}
}
