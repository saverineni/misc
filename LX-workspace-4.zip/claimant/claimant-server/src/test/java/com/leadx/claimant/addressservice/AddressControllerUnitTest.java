package com.leadx.claimant.addressservice;

import static com.leadx.test.MockUtils.mockAndSetOn;

import java.util.Collection;
import java.util.List;

import javax.persistence.OptimisticLockException;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.concurrent.Synchroniser;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.leadx.claimant.client.AddressDto;
import com.leadx.claimant.client.PreviousAddressDto;
import com.leadx.claimant.client.SaveAddressDto;
import com.leadx.claimant.client.SavePreviousAddressDto;
import com.leadx.lib.utl.json.JsonUtils;

@SuppressWarnings({"unqualified-field-access"})
public class AddressControllerUnitTest {
	
	private AddressController addressController;
	
	private AddressService addressService;
	private AddressDtoConverter addressDtoConverter;
	private AddressConverter addressConverter;
	private AddressesConverter addressesConverter;
	private PreviousAddressConverter previousAddressConverter;
	
	private static final int ADDRESS_ID = 1234;
	private static final int PREVIOUS_ADDRESS_ID = 4321;
	private static final int CLAIMANT_ID = 4567;
	private static final int USER_ID = 1357;
	
	private final Synchroniser synchroniser = new Synchroniser();
	
	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
			setThreadingPolicy(synchroniser);
		}
	};
	
	@Before
	public void setUp() {
		this.addressController = new AddressController();
		
		this.addressService = mockAndSetOn(this.context, AddressService.class, this.addressController);
		this.addressDtoConverter = mockAndSetOn(this.context, AddressDtoConverter.class, this.addressController);
		this.addressConverter = mockAndSetOn(this.context, AddressConverter.class, this.addressController);
		this.addressesConverter = mockAndSetOn(this.context, AddressesConverter.class, this.addressController);
		this.previousAddressConverter = mockAndSetOn(this.context, PreviousAddressConverter.class, this.addressController);
	}

	@Test
	public void testGetAddressById() {
		final Address address = newDummyAddress("WA14 4DZ");
		address.setId(ADDRESS_ID);
		final AddressDto addressDto = newDummyAddressDto("WA14 4DZ");
		
		this.context.checking(new Expectations() {
			{
				oneOf(addressService).getAddressById(ADDRESS_ID);
				will(returnValue(address));
				oneOf(addressConverter).convert(address);
				will(returnValue(addressDto));
			}
		});
		
		this.addressController.getAddressById(ADDRESS_ID);
	}

	@Test
	public void testGetAddressesByIds() {
		final Address address = newDummyAddress("WA14 4DZ");
		address.setId(ADDRESS_ID);
		final Collection<Address> addresses = ImmutableList.of(address);
		final AddressDto addressDto = newDummyAddressDto("WA14 4DZ");

		this.context.checking(new Expectations() {
			{
				oneOf(addressService).getAddressesByIds(ImmutableList.of(ADDRESS_ID));
				will(returnValue(addresses));
				oneOf(addressesConverter).convert(addresses);
				will(returnValue(ImmutableList.of(addressDto)));
			}
		});

		this.addressController.getAddressesByIds("" + ADDRESS_ID);
	}
	@Test
	public void testSaveAddress() {
		final AddressDto addressDto = newDummyAddressDto("M33 4HH");
		final SaveAddressDto saveAddressDto = newDummySaveAddressDto(addressDto);
		
		
		final Address address = newDummyAddress("M33 4HH");
		address.setId(ADDRESS_ID);
		
		this.context.checking(new Expectations() {
			{
				oneOf(addressDtoConverter).convert(addressDto);
				will(returnValue(address));
				oneOf(addressService).saveAddress(CLAIMANT_ID, address, true);
			}
		});
		
		this.addressController.saveAddress(JsonUtils.serialize(saveAddressDto, true));
	}
	
	@Test(expected = OptimisticLockException.class)
	public void testSaveAddressFailure() {
		final AddressDto addressDto = newDummyAddressDto("WA14 4DZ");
		final SaveAddressDto saveAddressDto = newDummySaveAddressDto(addressDto);
		
		final Address address = newDummyAddress("M33 4HH");
		address.setId(ADDRESS_ID);
		
		this.context.checking(new Expectations() {
			{
				oneOf(addressDtoConverter).convert(addressDto);
				will(returnValue(address));
				allowing(addressService).saveAddress(CLAIMANT_ID, address, true);
				will(throwException(new OptimisticLockException()));
			}
		});
		
		this.addressController.saveAddress(JsonUtils.serialize(saveAddressDto, false));
	}

	@Test
	public void testSaveAddressInConfinement() {
		final AddressDto addressDto = newDummyAddressDto("M33 4HH");
		final SaveAddressDto saveAddressDto = newDummySaveAddressDto(addressDto);


		final Address address = newDummyAddress("M33 4HH");
		address.setId(ADDRESS_ID);

		this.context.checking(new Expectations() {
			{
				oneOf(addressDtoConverter).convert(addressDto);
				will(returnValue(address));
				oneOf(addressService).saveAddressInConfinement(CLAIMANT_ID, address, true);
			}
		});

		this.addressController.saveAddressInConfinement(JsonUtils.serialize(saveAddressDto, true));
	}

	@Test(expected = OptimisticLockException.class)
	public void testSaveAddressInConfinementFailure() {
		final AddressDto addressDto = newDummyAddressDto("WA14 4DZ");
		final SaveAddressDto saveAddressDto = newDummySaveAddressDto(addressDto);

		final Address address = newDummyAddress("M33 4HH");
		address.setId(ADDRESS_ID);

		this.context.checking(new Expectations() {
			{
				oneOf(addressDtoConverter).convert(addressDto);
				will(returnValue(address));
				allowing(addressService).saveAddressInConfinement(CLAIMANT_ID, address, true);
				will(throwException(new OptimisticLockException()));
			}
		});

		this.addressController.saveAddressInConfinement(JsonUtils.serialize(saveAddressDto, false));
	}
	
	@Test
	public void testUpdateAddress() {
		final AddressDto addressDto = newDummyAddressDto("M1 1EP");
		final SaveAddressDto saveAddressDto = newDummySaveAddressDto(addressDto);
		
		final Address address = newDummyAddress("M1 1EP");
		address.setId(ADDRESS_ID);
		
		this.context.checking(new Expectations() {
			{
				oneOf(addressDtoConverter).convert(addressDto);
				will(returnValue(address));
				oneOf(addressService).updateAddress(CLAIMANT_ID, address, USER_ID, true);
			}
		});
		
		this.addressController.updateAddress(JsonUtils.serialize(saveAddressDto, true));
	}

	@Test(expected = OptimisticLockException.class)
	public void testUpdateAddressFailure() {
		final AddressDto addressDto = newDummyAddressDto("M1 1EP");
		final SaveAddressDto saveAddressDto = newDummySaveAddressDto(addressDto);
		
		final Address address = newDummyAddress("M1 1EP");
		address.setId(ADDRESS_ID);
		
		this.context.checking(new Expectations() {
			{
				oneOf(addressDtoConverter).convert(addressDto);
				will(returnValue(address));
				allowing(addressService).updateAddress(CLAIMANT_ID, address, USER_ID, true);
				will(throwException(new OptimisticLockException()));
			}
		});
		
		this.addressController.updateAddress(JsonUtils.serialize(saveAddressDto, true));
	}

	@Test
	public void testUpdateAddressInConfinement() {
		final AddressDto addressDto = newDummyAddressDto("M1 1EP");
		final SaveAddressDto saveAddressDto = newDummySaveAddressDto(addressDto);

		final Address address = newDummyAddress("M1 1EP");
		address.setId(ADDRESS_ID);

		this.context.checking(new Expectations() {
			{
				oneOf(addressDtoConverter).convert(addressDto);
				will(returnValue(address));
				oneOf(addressService).updateAddressInConfinement(CLAIMANT_ID, address, USER_ID);
			}
		});

		this.addressController.updateAddressInConfinement(JsonUtils.serialize(saveAddressDto, true));
	}

	@Test(expected = OptimisticLockException.class)
	public void testUpdateAddressInConfinementFailure() {
		final AddressDto addressDto = newDummyAddressDto("M1 1EP");
		final SaveAddressDto saveAddressDto = newDummySaveAddressDto(addressDto);

		final Address address = newDummyAddress("M1 1EP");
		address.setId(ADDRESS_ID);

		this.context.checking(new Expectations() {
			{
				oneOf(addressDtoConverter).convert(addressDto);
				will(returnValue(address));
				allowing(addressService).updateAddressInConfinement(CLAIMANT_ID, address, USER_ID);
				will(throwException(new OptimisticLockException()));
			}
		});

		this.addressController.updateAddressInConfinement(JsonUtils.serialize(saveAddressDto, true));
	}
	
	@Test
	public void testSavePreviousAddressWithNewAddress() {
		final Address address = newDummyAddress("WA14 4DZ");
		final AddressDto addressDto = newDummyAddressDto("WA14 4DZ");
		
		final SavePreviousAddressDto savePreviousAddressDto = new SavePreviousAddressDto();
		savePreviousAddressDto.setNewAddress(addressDto);
		savePreviousAddressDto.setClaimantId(CLAIMANT_ID);
		
		this.context.checking(new Expectations() {
			{
				oneOf(addressService).savePreviousAddress(CLAIMANT_ID, address);
				atLeast(1).of(addressDtoConverter).convert(addressDto);
				will(returnValue(address));
			}
		});
		
		this.addressController.savePreviousAddress(JsonUtils.serialize(savePreviousAddressDto,false));
	}
	
	@Test
	public void testSavePreviousAddressWithCurrentAddress() {
		final Address address = newDummyAddress("WA14 4DZ");
		address.setId(ADDRESS_ID);
		final AddressDto addressDto = newDummyAddressDto("WA14 4DZ");
		
		final SavePreviousAddressDto savePreviousAddressDto = new SavePreviousAddressDto();
		savePreviousAddressDto.setCurrentAddressId(ADDRESS_ID);
		savePreviousAddressDto.setClaimantId(CLAIMANT_ID);
		
		this.context.checking(new Expectations() {
			{
				oneOf(addressService).getAddressById(ADDRESS_ID);
				will(returnValue(address));
				oneOf(addressService).savePreviousAddress(CLAIMANT_ID, address);
				atLeast(1).of(addressDtoConverter).convert(addressDto);
				will(returnValue(address));
			}
		});
		
		this.addressController.savePreviousAddress(JsonUtils.serialize(savePreviousAddressDto,false));
	}

	@Test(expected = OptimisticLockException.class)
	public void testSavePreviousAddressFailure() {
		final Address address = newDummyAddress("WA14 4DZ");
		final AddressDto addressDto = newDummyAddressDto("WA14 4DZ");
		
		final SavePreviousAddressDto savePreviousAddressDto = new SavePreviousAddressDto();
		savePreviousAddressDto.setNewAddress(addressDto);
		savePreviousAddressDto.setClaimantId(CLAIMANT_ID);
		
		this.context.checking(new Expectations() {
			{
				allowing(addressService).savePreviousAddress(CLAIMANT_ID, address);
				will(throwException(new OptimisticLockException()));
				atLeast(1).of(addressDtoConverter).convert(addressDto);
				will(returnValue(address));
			}
		});
		
		this.addressController.savePreviousAddress(JsonUtils.serialize(savePreviousAddressDto,false));
	}

	@Test
	public void testSavePreviousAddressInConfinement() {
		final Address address = newDummyAddress("WA14 4DZ");
		final AddressDto addressDto = newDummyAddressDto("WA14 4DZ");

		final SavePreviousAddressDto savePreviousAddressDto = new SavePreviousAddressDto();
		savePreviousAddressDto.setNewAddress(addressDto);
		savePreviousAddressDto.setClaimantId(CLAIMANT_ID);

		this.context.checking(new Expectations() {
			{
				oneOf(addressService).savePreviousAddressInConfinement(CLAIMANT_ID, address);
				atLeast(1).of(addressDtoConverter).convert(addressDto);
				will(returnValue(address));
			}
		});

		this.addressController.savePreviousAddressInConfinement(JsonUtils.serialize(savePreviousAddressDto,false));
	}

	@Test(expected = OptimisticLockException.class)
	public void testSavePreviousAddressInConfinementFailure() {
		final Address address = newDummyAddress("WA14 4DZ");
		final AddressDto addressDto = newDummyAddressDto("WA14 4DZ");

		final SavePreviousAddressDto savePreviousAddressDto = new SavePreviousAddressDto();
		savePreviousAddressDto.setNewAddress(addressDto);
		savePreviousAddressDto.setClaimantId(CLAIMANT_ID);

		this.context.checking(new Expectations() {
			{
				allowing(addressService).savePreviousAddressInConfinement(CLAIMANT_ID, address);
				will(throwException(new OptimisticLockException()));
				atLeast(1).of(addressDtoConverter).convert(addressDto);
				will(returnValue(address));
			}
		});

		this.addressController.savePreviousAddressInConfinement(JsonUtils.serialize(savePreviousAddressDto,false));
	}

	@Test
	public void testDeletePreviousAddress() {
		
		this.context.checking(new Expectations() {
			{
				oneOf(addressService).deletePreviousAddress(PREVIOUS_ADDRESS_ID, USER_ID);
			}
		});
		
		this.addressController.deletePreviousAddress(PREVIOUS_ADDRESS_ID, USER_ID);
	}

	@Test(expected = OptimisticLockException.class)
	public void testDeletePreviousAddressFailure() {
		
		this.context.checking(new Expectations() {
			{
				allowing(addressService).deletePreviousAddress(PREVIOUS_ADDRESS_ID, USER_ID);
				will(throwException(new OptimisticLockException()));
			}
		});
		
		this.addressController.deletePreviousAddress(PREVIOUS_ADDRESS_ID, USER_ID);
	}

	@Test
	public void testDeletePreviousAddressInConfinement() {

		this.context.checking(new Expectations() {
			{
				oneOf(addressService).deletePreviousAddressInConfinement(PREVIOUS_ADDRESS_ID, USER_ID);
			}
		});

		this.addressController.deletePreviousAddressInConfinement(PREVIOUS_ADDRESS_ID, USER_ID);
	}

	@Test(expected = OptimisticLockException.class)
	public void testDeletePreviousAddressInConfinementFailure() {

		this.context.checking(new Expectations() {
			{
				allowing(addressService).deletePreviousAddressInConfinement(PREVIOUS_ADDRESS_ID, USER_ID);
				will(throwException(new OptimisticLockException()));
			}
		});

		this.addressController.deletePreviousAddressInConfinement(PREVIOUS_ADDRESS_ID, USER_ID);
	}
	
	@Test
	public void testSaveHouseMove() {
		final Address oldAddress = newDummyAddress("WA14 4DZ");
		oldAddress.setId(ADDRESS_ID);
		
		final Address newAddress = newDummyAddress("SO53 2HX");
		final AddressDto newAddressDto = newDummyAddressDto("SO53 2HX");
		
		final SavePreviousAddressDto savePreviousAddressDto = new SavePreviousAddressDto();
		savePreviousAddressDto.setCurrentAddressId(oldAddress.getId());
		savePreviousAddressDto.setNewAddress(newAddressDto);
		savePreviousAddressDto.setClaimantId(CLAIMANT_ID);
		
		this.context.checking(new Expectations() {
			{
				oneOf(addressService).getAddressById(ADDRESS_ID);
				will(returnValue(oldAddress));
				oneOf(addressDtoConverter).convert(savePreviousAddressDto.getNewAddress());
				will(returnValue(newAddress));
				oneOf(addressService).saveHouseMove(CLAIMANT_ID, oldAddress, newAddress);
				
			}
		});
		
		this.addressController.saveHouseMove(JsonUtils.serialize(savePreviousAddressDto,false));
	}
	
	@Test(expected = OptimisticLockException.class)
	public void testSaveHouseMoveFailure() {
		final Address oldAddress = newDummyAddress("WA14 4DZ");
		oldAddress.setId(ADDRESS_ID);
		
		final Address newAddress = newDummyAddress("SO53 2HX");
		final AddressDto newAddressDto = newDummyAddressDto("SO53 2HX");
		
		final SavePreviousAddressDto savePreviousAddressDto = new SavePreviousAddressDto();
		savePreviousAddressDto.setCurrentAddressId(oldAddress.getId());
		savePreviousAddressDto.setNewAddress(newAddressDto);
		savePreviousAddressDto.setClaimantId(CLAIMANT_ID);
		
		this.context.checking(new Expectations() {
			{
				oneOf(addressService).getAddressById(ADDRESS_ID);
				will(returnValue(oldAddress));
				oneOf(addressDtoConverter).convert(savePreviousAddressDto.getNewAddress());
				will(returnValue(newAddress));
				allowing(addressService).saveHouseMove(CLAIMANT_ID, oldAddress, newAddress);
				will(throwException(new OptimisticLockException()));
				
			}
		});
		
		this.addressController.saveHouseMove(JsonUtils.serialize(savePreviousAddressDto,false));
	}
	
	@Test
	public void testGetAddressForClaimantId() {
		final Address address = newDummyAddress("X1 1YZ");
		final AddressDto addressDto = newDummyAddressDto("X1 1YZ");
		
		this.context.checking(new Expectations() {
			{
				oneOf(addressService).getAddressForClaimant(CLAIMANT_ID);
				will(returnValue(address));
				oneOf(addressConverter).convert(address);
				will(returnValue(addressDto));
			}
		});
		
		this.addressController.getAddressForClaimant(CLAIMANT_ID);
	}
	
	@Test
	public void testGetAllAddressesForClaimant() {
		final List<Address> addresses = Lists.newArrayList();
		addresses.add(newDummyAddress("A1 1AA"));
		addresses.add(newDummyAddress("B1 1BB"));
		addresses.add(newDummyAddress("C1 1CC"));
		
		final List<AddressDto> addressDtos = Lists.newArrayList();
		addressDtos.add(newDummyAddressDto("A1 1AA"));
		addressDtos.add(newDummyAddressDto("B1 1BB"));
		addressDtos.add(newDummyAddressDto("C1 1CC"));
		
		this.context.checking(new Expectations() {
			{
				oneOf(addressService).getAllAddressesForClaimant(CLAIMANT_ID);
				will(returnValue(addresses));
				exactly(3).of(addressConverter).convert(with(any(Address.class)));
				with(any(AddressDto.class));
			}
		});
		
		this.addressController.getAllAddressesForClaimant(CLAIMANT_ID);
	}
	
	@Test
	public void testGetPreviousAddresses() {
		final List<PreviousAddress> previousAddresses = Lists.newArrayList();
		previousAddresses.add(newDummyPreviousAddress("M3 3M"));
		previousAddresses.add(newDummyPreviousAddress("L3 3L"));
		
		this.context.checking(new Expectations() {
			{
				oneOf(addressService).getPreviousAddresses(CLAIMANT_ID);
				will(returnValue(previousAddresses));
				exactly(2).of(previousAddressConverter).convert(with(any(PreviousAddress.class)));
				with(any(PreviousAddressDto.class));
			}
		});
		
		this.addressController.getPreviousAddresses(CLAIMANT_ID);
	}
	
	@Test
	public void testGetOrderedPreviousAddresses() {
		final List<PreviousAddress> previousAddresses = Lists.newArrayList();
		previousAddresses.add(newDummyPreviousAddress("X1 1X"));
		previousAddresses.add(newDummyPreviousAddress("V2 2V"));
		
		this.context.checking(new Expectations() {
			{
				oneOf(addressService).getOrderedPreviousAddressesForClaimant(CLAIMANT_ID);
				will(returnValue(previousAddresses));
				exactly(2).of(previousAddressConverter).convert(with(any(PreviousAddress.class)));
				with(any(PreviousAddressDto.class));
			}
		});
		
		this.addressController.getOrderedPreviousAddressesForClaimant(CLAIMANT_ID);
	}
	
	@Test
	public void testGetDeletedPreviousAddresses() {
		final List<PreviousAddress> previousAddresses = Lists.newArrayList();
		previousAddresses.add(newDummyPreviousAddress("X1 1X"));
		previousAddresses.add(newDummyPreviousAddress("V2 2V"));
		
		this.context.checking(new Expectations() {
			{
				oneOf(addressService).getDeletedPreviousAddresses(CLAIMANT_ID);
				will(returnValue(previousAddresses));
				exactly(2).of(previousAddressConverter).convert(with(any(PreviousAddress.class)));
				with(any(PreviousAddressDto.class));
			}
		});
		
		this.addressController.getDeletedPreviousAddresses(CLAIMANT_ID);
	}
	
	@Test
	public void testGetAllAddressDetails() {
		final Address address = newDummyAddress("WA14 4DZ");
		final AddressDto addressDto = newDummyAddressDto("WA14 4DZ");
		
		final PreviousAddress previousAddress1 = newDummyPreviousAddress("M20 4TZ");
		final List<PreviousAddress> orderedPreviousAddresses = Lists.newArrayList(previousAddress1);
		
		final PreviousAddress previousAddress2 = newDummyPreviousAddress("M27 9LD");
		final List<PreviousAddress> deletedPreviousAddresses = Lists.newArrayList(previousAddress2);
		
		final PreviousAddressDto previousAddressDto1 = newDummyPreviousAddressDto("M20 4TZ");
		final PreviousAddressDto previousAddressDto2 = newDummyPreviousAddressDto("M27 9LD");

		this.context.checking(new Expectations() {
			{
				oneOf(addressService).getAddressForClaimant(CLAIMANT_ID);
				will(returnValue(address));
				oneOf(addressConverter).convert(address);
				will(returnValue(addressDto));
				oneOf(addressService).getOrderedPreviousAddressesForClaimant(CLAIMANT_ID);
				will(returnValue(orderedPreviousAddresses));
				oneOf(addressService).getDeletedPreviousAddresses(CLAIMANT_ID);
				will(returnValue(deletedPreviousAddresses));
				oneOf(previousAddressConverter).convert(previousAddress1);
				will(returnValue(previousAddressDto1));
				oneOf(previousAddressConverter).convert(previousAddress2);
				will(returnValue(previousAddressDto2));
			}
		});
		
		this.addressController.getAllAddressDetails(CLAIMANT_ID);
	}
	
	private static Address newDummyAddress(final String postcode) {
		return new Address("a", "1", "b", "2", "c", "d", "e", "f", "g", "h", postcode, "a");
	}
	
	private static AddressDto newDummyAddressDto(final String postcode) {
		return new AddressDto(ADDRESS_ID, "a", "1", "b", "2", "c", "d", "e", "f", "g", "h", postcode, "a", null, null);
	}

	private static SaveAddressDto newDummySaveAddressDto(final AddressDto addressDto) {
		return new SaveAddressDto(CLAIMANT_ID, addressDto, USER_ID, true);
	}
	
	private static PreviousAddress newDummyPreviousAddress(final String postcode) {
		return new PreviousAddress(CLAIMANT_ID, newDummyAddress(postcode), true);
	}
	
	private static PreviousAddressDto newDummyPreviousAddressDto(final String postcode) {
		return new PreviousAddressDto(PREVIOUS_ADDRESS_ID, CLAIMANT_ID, newDummyAddressDto(postcode), false, null, 0);
	}
}
