package com.leadx.claimant.claimantservice;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.leadx.claimant.client.ClaimantReferralDto;

public class ClaimantReferralConverterTest {

	@Test
	public void testConvert() throws Exception {
		final ClaimantReferralConverter converter = new ClaimantReferralConverter();
		final ClaimantReferral claimantReferral = new ClaimantReferral(10, 11, 12, 13, 14);
		claimantReferral.setId(99);
		final ClaimantReferralDto dto = converter.convert(claimantReferral);

		assertThat(dto.getDiallerReferenceId(), is(14));
		assertThat(dto.getCreatedByAgentId(), is(13));
		assertThat(dto.getCreatedDateTime(), is(notNullValue()));
		assertThat(dto.getProductTypeId(), is(10));
		assertThat(dto.getReferrerClaimantId(), is(11));
		assertThat(dto.getReferralClaimantId(), is(12));
		assertThat(dto.getId(), is(99));
	}
	
	@Test
	public void testReturnsNull() {
		final ClaimantReferralConverter converter = new ClaimantReferralConverter();
		final ClaimantReferral claimantReferral = null;
		
		final ClaimantReferralDto dto = converter.convert(claimantReferral);
		
		assertThat(dto, is(nullValue()));
	}
}