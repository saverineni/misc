package com.leadx.claimant.assessmentservice;

import static com.leadx.claimant.claimantservice.ClaimantControllerTest.newDummyClaimantAndAddress;
import static com.leadx.test.MockUtils.mockAndSetOn;

import java.util.List;

import com.leadx.claimant.reference.VulnerableDetailTriState;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.concurrent.Synchroniser;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.leadx.claimant.addressservice.Address;
import com.leadx.claimant.addressservice.AddressConverter;
import com.leadx.claimant.claimantservice.Claimant;
import com.leadx.claimant.claimantservice.ClaimantAndAddress;
import com.leadx.claimant.claimantservice.ClaimantConverter;
import com.leadx.claimant.claimantservice.ClaimantService;
import com.leadx.claimant.client.AssessmentDispositionDto;
import com.leadx.claimant.client.AssessmentDto;
import com.leadx.claimant.client.CallDisposition;
import com.leadx.claimant.client.ClaimantDto;
import com.leadx.claimant.reference.TriState;

public class AssessmentControllerTest {
	private AssessmentController assessmentController;
	private AssessmentService assessmentService;
	private ClaimantService claimantService;
	private ClaimantConverter claimantConverter;
	private AddressConverter addressConverter;

	private final Synchroniser synchroniser = new Synchroniser();

	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
			setThreadingPolicy(synchroniser);
		}
	};

	@Before
	public void setUp() {
		this.assessmentController = new AssessmentController();
		this.assessmentService = mockAndSetOn(this.context, AssessmentService.class, this.assessmentController);
		this.claimantService = mockAndSetOn(this.context, ClaimantService.class, this.assessmentController);
		this.addressConverter = mockAndSetOn(this.context, AddressConverter.class, this.assessmentController);
		this.claimantConverter = mockAndSetOn(this.context, ClaimantConverter.class, this.assessmentController);
	}

	@Test
	public void loadClaimant(){
		final int claimantId = 123;
		final int userId = 456;
		this.context.checking(new Expectations() {
			{
				oneOf(assessmentService).loadClaimant(claimantId, userId, true);
				will(returnValue(new AssessmentDto()));
			}
		});
		this.assessmentController.loadClaimant(123, 456);
	}

	@Test(expected = RuntimeException.class)
	public void loadClaimantFailure(){
		final int claimantId = 123;
		final int userId = 456;
		this.context.checking(new Expectations() {
			{
				oneOf(assessmentService).loadClaimant(claimantId, userId, true);
				will(returnValue(null));
			}
		});
		this.assessmentController.loadClaimant(123, 456);
	}

	@Test
	public void dispositionCall() throws Exception{
		final int claimantId = 123;
		final int dispositionId = 75;
		final int diallerRefId = 556677;
		final String callReason = "chase";
		final String callReasonGroup = "pba";

		final AssessmentDispositionDto assessmentDispositionDto = new AssessmentDispositionDto();
		assessmentDispositionDto.setClaimantId(claimantId);
		assessmentDispositionDto.setDispositionId(dispositionId);
		assessmentDispositionDto.setDiallerRefId(diallerRefId);
		assessmentDispositionDto.setCallReason(callReason);
		assessmentDispositionDto.setCallReasonGroup(callReasonGroup);

		final CallDisposition callDisposition = CallDisposition.getById(assessmentDispositionDto.getDispositionId());

		this.context.checking(new Expectations() {
			{
				oneOf(assessmentService).dispositionCall(assessmentDispositionDto, callDisposition);
			}
		});
		this.assessmentController.dispositionCall(assessmentDispositionDto);
	}

	@Test(expected = NullPointerException.class)
	public void dispositionCallWithNullDisposition() throws Exception{

		this.context.checking(new Expectations() {
			{
				never(assessmentService).dispositionCall(with(any(AssessmentDispositionDto.class)), with(any(CallDisposition.class)));
			}
		});
		this.assessmentController.dispositionCall(null);
	}

	@Test(expected = NullPointerException.class)
	public void dispositionCallWithInvalidCallDisposition() throws Exception{

		final int claimantId = 123;
		final int dispositionId = 2000;
		final int diallerRefId = 556677;
		final String callReason = "chase";
		final String callReasonGroup = "pba";

		final AssessmentDispositionDto assessmentDispositionDto = new AssessmentDispositionDto();
		assessmentDispositionDto.setClaimantId(claimantId);
		assessmentDispositionDto.setDispositionId(dispositionId);
		assessmentDispositionDto.setDiallerRefId(diallerRefId);
		assessmentDispositionDto.setCallReason(callReason);
		assessmentDispositionDto.setCallReasonGroup(callReasonGroup);

		this.context.checking(new Expectations() {
			{
				never(assessmentService).dispositionCall(with(any(AssessmentDispositionDto.class)), with(any(CallDisposition.class)));
			}
		});
		this.assessmentController.dispositionCall(assessmentDispositionDto);
	}

	@Test
	public void searchForClaimantByTelephoneNumber(){
		final String telephoneNumber = "07111111111";
		final ClaimantAndAddress claimantAndAddress = newDummyClaimantAndAddress("Helliwell", "M1 1AA");
		final Claimant claimant  = claimantAndAddress.getClaimant();
		final Address address = claimantAndAddress.getAddress();
		final int sellerAccountId = 2;
		final ClaimantDto claimantDto = new ClaimantDto(0, 1, sellerAccountId, 3, "Mr", "Matt",
				"Guy", "Helliwell", "previousname", "05/11/1964", 4, "1",
				"2", "3", "3", "me@me.com", "JP467431D", false,
				null, 0, false, null, 0, null, false,
				null, 0, null,
				true, "27/03/2017 10:00:00", true,
				"8/10/2014 12:34:14", "3/10/2014 11:30:00", "5/10/2014 14:22:55",
				Lists.newArrayList(), Lists.newArrayList(), Lists.newArrayList(), TriState.NO.toValue(), null, 0,null,
				TriState.NO.toValue(), null, null, null, null, false, Sets.newHashSet(), VulnerableDetailTriState.NO.toValue(), null);

		final List<ClaimantAndAddress> claimantAndAddressList = Lists.newArrayList(claimantAndAddress);

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).searchForClaimantByTelephoneNumber(telephoneNumber);
				will(returnValue(claimantAndAddressList));
				oneOf(claimantConverter).convert(claimant);
				will(returnValue(claimantDto));
				oneOf(claimantService).getSellerAccountNameById(sellerAccountId);
				oneOf(addressConverter).convert(address);
			}
		});

		this.assessmentController.searchForClaimantByTelephoneNumber(telephoneNumber);
	}

	@Test
	public void searchForClaimantByPostcode(){
		final String postcode = "M1 1AA";
		final ClaimantAndAddress claimantAndAddress = newDummyClaimantAndAddress("Helliwell", "M1 1AA");
		final Claimant claimant  = claimantAndAddress.getClaimant();
		final Address address = claimantAndAddress.getAddress();
		final int sellerAccountId = 2;
		final ClaimantDto claimantDto = new ClaimantDto(0, 1, sellerAccountId, 3, "Mr", "Matt",
				"Guy", "Helliwell", "previousname", "05/11/1964", 4, "1",
				"2", "3", "3", "me@me.com", "JP467431D", false,
				null, 0, false, null, 0, null, false,
				null, 0, null,
				true, "27/03/2017 10:00:00", true,
				"8/10/2014 12:34:14", "3/10/2014 11:30:00",
				"5/10/2014 14:22:55", Lists.newArrayList(), Lists.newArrayList(), Lists.newArrayList(), TriState.NO.toValue(), null, 0,null,
				TriState.NO.toValue(), null, null, null, null, false, Sets.newHashSet(), VulnerableDetailTriState.NO.toValue(), null);

		final List<ClaimantAndAddress> claimantAndAddressList = Lists.newArrayList(claimantAndAddress);

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).searchForClaimantByPostcode(postcode);
				will(returnValue(claimantAndAddressList));
				oneOf(claimantConverter).convert(claimant);
				will(returnValue(claimantDto));
				oneOf(claimantService).getSellerAccountNameById(sellerAccountId);
				oneOf(addressConverter).convert(address);
			}
		});

		this.assessmentController.searchForClaimantByPostcode("M1 1AA");
	}

	@Test
	public void searchForClaimantByClaimantId(){
		final int claimantId = 123;
		this.context.checking(new Expectations() {
			{
				oneOf(assessmentService).loadClaimant(claimantId, 0, false);
				will(returnValue(new AssessmentDto()));
			}
		});

		this.assessmentController.searchForClaimantByClaimantId(claimantId);
	}

	@Test(expected = RuntimeException.class)
	public void searchForClaimantByClaimantIdFailure(){
		final int claimantId = 123;
		this.context.checking(new Expectations() {
			{
				oneOf(assessmentService).loadClaimant(claimantId, 0, false);
				will(returnValue(null));
			}
		});

		this.assessmentController.searchForClaimantByClaimantId(claimantId);
	}
}
