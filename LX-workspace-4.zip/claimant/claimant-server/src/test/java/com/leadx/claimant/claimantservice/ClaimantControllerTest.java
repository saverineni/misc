package com.leadx.claimant.claimantservice;

import static com.google.common.collect.Lists.newArrayList;
import static com.leadx.claimant.claimantservice.Source.CLAIMANT;
import static com.leadx.test.MockUtils.mockAndSetOn;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.OptimisticLockException;

import com.leadx.claimant.reference.VulnerableDetailTriState;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.LoggerFactory;
import org.springframework.test.util.ReflectionTestUtils;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Sets;
import com.leadx.claimant.addressservice.Address;
import com.leadx.claimant.addressservice.AddressConverter;
import com.leadx.claimant.client.*;
import com.leadx.claimant.reference.TriState;
import com.leadx.claimant.user.User;
import com.leadx.lib.utl.JodaUtils;

import ch.qos.logback.classic.Level;
import ch.qos.logback.core.AppenderBase;

@SuppressWarnings("unqualified-field-access")
public class ClaimantControllerTest {

	private ClaimantController controller;
	private ClaimantService claimantService;
	private List<String> errorMessages;
	private ClaimantReferralConverter claimantReferralConverter;
	private ClaimantReferralsConverter claimantReferralsConverter;
	private ClaimantInteractionConverter claimantInteractionConverter;
	private ClaimantConverter claimantConverter;
	private ClaimantDtoConverter claimantDtoConverter;

	private static final int CLAIMANT_ID = 24680;

	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
		}
	};

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Before
	public void setUp() {
		this.controller = new ClaimantController();

		this.claimantService = this.context.mock(ClaimantService.class);
		ReflectionTestUtils.setField(this.controller, "claimantService", this.claimantService);

		ReflectionTestUtils.setField(this.controller, "claimantDtoConverter", new ClaimantDtoConverter());

		this.claimantReferralConverter = this.context.mock(ClaimantReferralConverter.class);
		ReflectionTestUtils.setField(this.controller, "claimantReferralConverter", this.claimantReferralConverter);

		this.claimantReferralsConverter = this.context.mock(ClaimantReferralsConverter.class);
		ReflectionTestUtils.setField(this.controller, "claimantReferralsConverter", this.claimantReferralsConverter);
		ReflectionTestUtils.setField(this.claimantReferralsConverter, "claimantReferralConverter", this.claimantReferralConverter);

		ReflectionTestUtils.setField(this.controller, "addressConverter", new AddressConverter());

		this.claimantInteractionConverter = mockAndSetOn(this.context, ClaimantInteractionConverter.class, this.controller);
		
		this.claimantConverter = mockAndSetOn(this.context, ClaimantConverter.class, this.controller);
		
		this.claimantDtoConverter = mockAndSetOn(this.context, ClaimantDtoConverter.class, this.controller);

		// Add a log appender to capture all the error messages
		final ch.qos.logback.classic.Logger log = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(ClaimantController.class);
		log.setLevel(Level.WARN);
		this.errorMessages = new ArrayList<>();

		final AppenderBase appender = new AppenderBase() {
			@Override
			protected void append(final Object eventObject) {
				ClaimantControllerTest.this.errorMessages.add(eventObject.toString());
			}
		};

		appender.start();
		log.addAppender(appender);
	}


	@Test
	public void testGetClaimantById() throws Exception {
		final Claimant expectedClaimant = new ClaimantBuilder().setId(1)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("matt")
				.setMiddleName("middle")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(0)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();
		final ClaimantDto claimantDto = new ClaimantDto();
		claimantDto.setId(1);
		claimantDto.setSurname("matty");
		
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(1);
				will(returnValue(expectedClaimant));
				
			}
		});
		
		expectConvertClaimant(expectedClaimant, claimantDto);

		final ClaimantDto result = this.controller.getClaimantById(1);
		assertThat(result.getId(), is(1));
		assertThat(result.getSurname(), is("matty"));

	}
	
	private void expectConvertClaimant(Claimant claimantToConvert, ClaimantDto convertedClaimant) {
		this.context.checking(new Expectations() {
			{
				oneOf(claimantConverter).convert(claimantToConvert);
				will(returnValue(convertedClaimant));
				
			}
		});
	}
	
	private void expectConvertClaimantDto(ClaimantDto claimantDtoToConvert, Claimant convertedClaimantDto) {
		this.context.checking(new Expectations() {
			{
				oneOf(claimantDtoConverter).convert(claimantDtoToConvert);
				will(returnValue(convertedClaimantDto));
				
			}
		});
	}

	@Test
	public void testCreateClaimant() throws Exception {
		final ClaimantDto inputClaimantDto = new ClaimantDto(0, 1, 2, 3, "Mr",
				"Matt", "Guy", "Hell", null, "05/11/1964", 4,
				"0", "1", "2", "2", "me@me.com",
				"JP467431D", false, null, 0, false, null, 0, null, false,
				null, 0, null, false,
				null, true, null, null, null,
				newArrayList(), newArrayList(), newArrayList(), TriState.NO.toValue(), null, 0,null,
				TriState.NO.toValue(), null, null, null, null, false, Sets.newHashSet(), VulnerableDetailTriState.NO.toValue(), null);

		final Claimant inputClaimant = new ClaimantBuilder().setId(0)
				.setLeadId(1)
				.setSellerAccountId(2)
				.setSellerCompanyId(3)
				.setTitle("Mr")
				.setForename("Matt")
				.setMiddleName("Guy")
				.setSurname("Hell")
				.setPreviousSurname("")
				.setDob(new LocalDate(1964, 11, 5))
				.setAddressId(4)
				.setHomeTelephone("0")
				.setMobileTelephone("1")
				.setAlternativeTelephone("2")
				.setWorkTelephone("2")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();
		final Claimant outputClaimant = new ClaimantBuilder().setId(1)
				.setLeadId(1)
				.setSellerAccountId(2)
				.setSellerCompanyId(3)
				.setTitle("Mr")
				.setForename("Matt")
				.setMiddleName("Guy")
				.setSurname("Hell")
				.setPreviousSurname("")
				.setDob(new LocalDate(1964, 11, 5))
				.setAddressId(4)
				.setHomeTelephone("0")
				.setMobileTelephone("1")
				.setAlternativeTelephone("2")
				.setWorkTelephone("2")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();
		
		final ClaimantDto claimantDto = new ClaimantDto();
		claimantDto.setId(1);
		
		expectConvertClaimantDto(inputClaimantDto, inputClaimant);
		
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).createClaimant(inputClaimant);
				will(returnValue(outputClaimant));
			}
		});
		
		expectConvertClaimant(outputClaimant, claimantDto);

		final ClaimantDto createdClaimantDto = this.controller.createClaimant(inputClaimantDto);
		assertThat(createdClaimantDto.getId(), is(1));
	}

	@Test
	public void testUpdateClaimant() throws Exception {
		final ClaimantDto inputClaimantDto = new ClaimantDto(0, 1, 2, 3, "Mr",
				"Matt", "Guy", "Hell", null, "05/11/1964", 4,
				"0", "1", "2", "2", "me@me.com",
				"JP467431D", false, null, 0, false, null, 0, null, false,
				null, 0, null,
				false, null, true, null,
				null, null, newArrayList(), newArrayList(), newArrayList(), TriState.NO.toValue(), null, 0,null,
				TriState.NO.toValue(), null, null, null, null, false, Sets.newHashSet(), VulnerableDetailTriState.NO.toValue(), null);

		final Claimant inputClaimant = new ClaimantBuilder().setId(0)
				.setLeadId(1)
				.setSellerAccountId(2)
				.setSellerCompanyId(3)
				.setTitle("Mr")
				.setForename("Matt")
				.setMiddleName("Guy")
				.setSurname("Hell")
				.setPreviousSurname("")
				.setDob(new LocalDate(1964, 11, 5))
				.setAddressId(4)
				.setHomeTelephone("0")
				.setMobileTelephone("1")
				.setAlternativeTelephone("2")
				.setWorkTelephone("2")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();
		
		expectConvertClaimantDto(inputClaimantDto, inputClaimant);
		
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).updateClaimant(inputClaimant, 7);
			}
		});

		this.controller.updateClaimant(inputClaimantDto, 7);
	}

	@Test
	public void testSyncClaimantToLogiClaimGet() throws Exception {
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).syncClaimantToLogiClaim(CLAIMANT_ID);
			}
		});

		this.controller.syncClaimantToLogiClaim(CLAIMANT_ID);
	}

	@Test
	public void testSyncClaimantToLogiClaimPost() throws Exception {
		final String claimantIdList = "123 345";
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).syncClaimantToLogiClaim(123);
				oneOf(claimantService).syncClaimantToLogiClaim(345);
			}
		});

		this.controller.syncClaimantToLogiClaim(claimantIdList);
	}

	@Test
	public void testUpdateClaimantInConfinement() throws Exception {
		final ClaimantDto inputClaimantDto = new ClaimantDto(0, 1, 2, 3, "Mr",
				"Matt", "Guy", "Hell", null, "05/11/1964", 4,
				"0", "1", "2", "2", "me@me.com",
				"JP467431D", false, null, 0, false, null, 0, null, false,
				null, 0, null,
				false, null, true, null,
				null, null, newArrayList(), newArrayList(), newArrayList(), TriState.NO.toValue(), null, 0,null,
				TriState.NO.toValue(), null, null, null, null, false, Sets.newHashSet(), VulnerableDetailTriState.NO.toValue(), null);

		final Claimant inputClaimant = new ClaimantBuilder().setId(0)
				.setLeadId(1)
				.setSellerAccountId(2)
				.setSellerCompanyId(3)
				.setTitle("Mr")
				.setForename("Matt")
				.setMiddleName("Guy")
				.setSurname("Hell")
				.setPreviousSurname("")
				.setDob(new LocalDate(1964, 11, 5))
				.setAddressId(4)
				.setHomeTelephone("0")
				.setMobileTelephone("1")
				.setAlternativeTelephone("2")
				.setWorkTelephone("2")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();
		
		expectConvertClaimantDto(inputClaimantDto, inputClaimant);
		
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).updateClaimantInConfinement(inputClaimant, 7);
			}
		});

		this.controller.updateClaimantInConfinement(inputClaimantDto, 7);
	}

	@Test
	public void testSetClaimantOptIn() throws Exception {
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).setClaimantOptIn(10, true);
			}
		});

		this.controller.setClaimantOptIn(10, true);
	}

	@Test
	public void testCreateClaimantReferral() throws Exception {
		final Claimant inputClaimant = new ClaimantBuilder().setId(0)
				.setLeadId(1)
				.setSellerAccountId(2)
				.setSellerCompanyId(3)
				.setTitle("Mr")
				.setForename("Matt")
				.setMiddleName("Guy")
				.setSurname("Hell")
				.setPreviousSurname("")
				.setDob(new LocalDate(1964, 11, 5))
				.setAddressId(4)
				.setHomeTelephone("0")
				.setMobileTelephone("1")
				.setAlternativeTelephone("2")
				.setWorkTelephone("2")
				.setEmail("me@me.com").setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();

		final ClaimantDto inputClaimantDto = new ClaimantDto(0, 1, 2, 3, "Mr",
				"Matt", "Guy", "Hell", null, "05/11/1964", 4,
				"0", "1", "2", "2", "me@me.com",
				"JP467431D", false, null, 0,
				false, null, 0,
				null, false, null, 0,
				null, false, null, true,
				null, null, null, newArrayList(), newArrayList(), newArrayList(),
				TriState.NO.toValue(), null, 0,null,
				TriState.NO.toValue(), null, null,
				null, null, false, Sets.newHashSet(), VulnerableDetailTriState.NO.toValue(), null);

		final ClaimantReferral referral = new ClaimantReferral();
		final String timeStamp = "15/11/2014 15:23:45";
		
		expectConvertClaimantDto(inputClaimantDto, inputClaimant);
		
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).createClaimantAndClaimantReferral(inputClaimant, ProductType.PPI.getId(), 100, 101, 102, JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(timeStamp), "note");
				will(returnValue(referral));
				oneOf(claimantReferralConverter).convert(referral);
			}
		});

		final CreateClaimantReferralDto inputDto = new CreateClaimantReferralDto(inputClaimantDto, ProductType.PPI.getId(), 100, 101, 102, timeStamp, "note");

		this.controller.createClaimantReferral(inputDto);
	}

	@Test
	public void testCreateProductReferral() throws Exception {
		final int claimantId = 111;
		final String phoneNumber = "07777777777";
		final int agentId = 222;
		final int diallerReferenceId = 333;
		final String note = "This is a note";
		final ClaimantReferral referral = new ClaimantReferral(ProductType.PPI.getId(), claimantId, claimantId, agentId, diallerReferenceId);
		final String timeStamp = "15/11/2014 15:23:45";
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).createProductReferral(claimantId, phoneNumber, ProductType.PPI.getId(), agentId, diallerReferenceId, JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(timeStamp), note);
				will(returnValue(referral));
				oneOf(claimantReferralConverter).convert(referral);
			}
		});

		final CreateClaimantReferralDto inputDto = new CreateClaimantReferralDto(null, ProductType.PPI.getId(), claimantId, agentId, diallerReferenceId, phoneNumber, timeStamp, note);
		this.controller.createProductReferral(inputDto);
	}

	@Test
	public void testGetClaimantsAndAddressByIds() {
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantsAndAddressByIds(ImmutableList.of(1, 2));
			}
		});
		this.controller.getClaimantsAndAddressByIds("1, 2");
	}

	@Test
	public void testGetClaimantsByIds() {
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantsByIds(ImmutableList.of(1, 2));
			}
		});
		this.controller.getClaimantsByIds("1, 2");
	}

	@Test
	public void testGetClaimantsByIdsWithException() {
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantsByIds(ImmutableList.of(1, 2));
				will(throwException(new Exception()));
			}
		});

		boolean exceptionThrown = false;
		try {
			this.controller.getClaimantsByIds("1, 2");
		} catch ( final Exception e ) {
			exceptionThrown = true;
		}

		assertThat(exceptionThrown, is(true));
		assertThat(this.errorMessages.size(), is(1));
		assertThat(this.errorMessages.get(0),is("[ERROR] getClaimantsByIds ids 1, 2 failed"));
	}


	@Test
	public void testGetClaimantReferralByReferreeId() {
		final ClaimantReferral referral = new ClaimantReferral(1, 2, 10, 90119, 123);
		referral.setId(3);

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantReferralByReferreeId(10);
				will(returnValue(referral));
				oneOf(claimantReferralConverter).convert(referral);
			}
		});

		this.controller.getClaimantReferralByReferreeId(10);
	}

	@Test
	public void testLockClaimantAlreadyLocked() {
		final ClaimantLog claimantLog = new ClaimantLog(10, 0, new LocalDateTime(), new LocalDateTime(), 90119);

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).lockClaimant(10, 90119, 1);
				will(returnValue(claimantLog));
			}
		});

		this.controller.lockClaimant(10, 90119, 1);
	}

	@Test
	public void testUnlockClaimant() {
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).unlockClaimant(10, 90119);
			}
		});

		this.controller.unlockClaimant(10, 90119);
	}

	@Test
	public void testUnlockClaimantWithNullClaimantLog() {
		final ClaimantLog claimantLog = null;

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).unlockClaimant(10, 90119);
				will(returnValue(claimantLog));
			}
		});

		this.controller.unlockClaimant(10, 90119);
	}

	@Test
	public void testClaimantLockStatus() {
		final ClaimantLog claimantLog = new ClaimantLog(10, 0, new LocalDateTime(), null, 90119);

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantLog(10);
				will(returnValue(claimantLog));
			}
		});

		this.controller.claimantLockStatus(10);
	}

	@Test
	public void testClaimantLockStatusWithNullClaimantLog() {
		final ClaimantLog claimantLog = null;

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantLog(10);
				will(returnValue(claimantLog));
			}
		});

		this.controller.claimantLockStatus(10);
	}

	@Test
	public void testSearchForClaimantByBlankSurname() {
		final List<ClaimantAndAddress> claimantAndAddresses = newArrayList();
		claimantAndAddresses.add(newDummyClaimantAndAddress("test-surname", "A1 1AA"));
		claimantAndAddresses.add(newDummyClaimantAndAddress("another-surname", "B1 1BB"));
		
		expectConvertClaimant(claimantAndAddresses.get(0).getClaimant(), newDummyClaimantDto("test-surname"));
		expectConvertClaimant(claimantAndAddresses.get(1).getClaimant(), newDummyClaimantDto("another-surname"));

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).searchForClaimantBySurname("");
				will(returnValue(claimantAndAddresses));
			}
		});

		this.controller.searchForClaimantBySurname();
	}

	@Test
	public void testSearchForClaimantBySurname() {
		final List<ClaimantAndAddress> claimantAndAddresses = newArrayList();
		claimantAndAddresses.add(newDummyClaimantAndAddress("zxcqweqwe", "A1 1AA"));
		claimantAndAddresses.add(newDummyClaimantAndAddress("qweqwee", "B1 1BB"));
		
		expectConvertClaimant(claimantAndAddresses.get(0).getClaimant(), newDummyClaimantDto("zxcqweqwe"));
		expectConvertClaimant(claimantAndAddresses.get(1).getClaimant(), newDummyClaimantDto("qweqwee"));

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).searchForClaimantBySurname("test");
				will(returnValue(claimantAndAddresses));
			}
		});

		this.controller.searchForClaimantBySurname("test");
	}

	@Test
	public void testSearchForClaimantBySurnameWithException() {

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).searchForClaimantBySurname("test");
				will(throwException(new Exception()));
			}
		});

		boolean exceptionThrown = false;
		try {
			this.controller.searchForClaimantBySurname("test");
		} catch ( final Exception e ) {
			exceptionThrown = true;
		}

		assertThat(exceptionThrown, is(true));
		assertThat(this.errorMessages.size(), is(1));
		assertThat(this.errorMessages.get(0), is("[ERROR] searchForClaimantBySurname test failed"));
	}

	public static ClaimantAndAddress newDummyClaimantAndAddress(final String surname, final String postcode) {
		return new ClaimantAndAddress(newDummyClaimant(surname), newDummyAddress(postcode));
	}

	private static Claimant newDummyClaimant(final String surname) {
		return new ClaimantBuilder().setId(0)
				.setLeadId(1)
				.setSellerAccountId(2)
				.setSellerCompanyId(3)
				.setTitle("Mr")
				.setForename("Matt")
				.setMiddleName("Guy")
				.setSurname(surname)
				.setPreviousSurname("")
				.setDob(new LocalDate(1964, 11, 5))
				.setAddressId(4)
				.setHomeTelephone("0")
				.setMobileTelephone("1")
				.setAlternativeTelephone("2")
				.setWorkTelephone("2")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.setFormalDebtArrangement(TriState.NO)
				.setIvaCompanyId(1234)
				.setIvaReference("iva-ref")
				.setInformalDebtArrangement(TriState.NO)
				.setDebtManagementCompanyId(12121)
				.setDebtManagementReference("debt-ref")
				.createClaimant();
	}
	
	private static ClaimantDto newDummyClaimantDto(final String surname) {
		return new ClaimantDto(0, 1, 2, 3, "Mr", "Matt",
				"Guy", surname, null, "05/11/1964", 4, "0",
				"1", "2", "2", "me@me.com", "JP467431D", false,
				null, 0, false, null, 0, null, false,
				null, 0, null,
				false, null, true, null,
				null, null, newArrayList(), newArrayList(), newArrayList(), TriState.NO.toValue(), null, 0,null,
				TriState.NO.toValue(), null, null, null, null, false, Sets.newHashSet(), VulnerableDetailTriState.NO.toValue(), null);
	}

	private static Address newDummyAddress(final String postcode) {
		final Address address = new Address("a", "1", "b", "2", "c", "d", "e", "f", "g", "h", postcode, "a");
		address.setId(123);

		return address;
	}

	@Test
	public void testLockClaimant() {
		final ClaimantLog claimantLog = new ClaimantLog(10, 0, new LocalDateTime(), null, 90119);

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).lockClaimant(10, 90119, 1);
				will(returnValue(claimantLog));
			}
		});

		this.controller.lockClaimant(10, 90119, 1);
	}

	@Test
	public void testLockClaimantWithOptimisticLockException() {
		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantControllerTest.this.claimantService).lockClaimant(10, 11, 0);
				will(throwException(new OptimisticLockException()));
			}
		});

		boolean exceptionThrown = false;
		try {
			this.controller.lockClaimant(10, 11, 0);
		} catch ( final OptimisticLockException e ) {
			exceptionThrown = true;
		}

		assertThat(exceptionThrown, is(true));
		assertThat(this.errorMessages.size(), is(1));
		assertThat(this.errorMessages.get(0),is("[WARN] lockClaimant 10 by user 11 failed because of because of an optimistic locking exception."));
	}


	@Test
	public void testLockClaimantWithException() {
		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantControllerTest.this.claimantService).lockClaimant(10, 11, 0);
				will(throwException(new Exception()));
			}
		});

		boolean exceptionThrown = false;
		try {
			this.controller.lockClaimant(10, 11, 0);
		} catch ( final Exception e ) {
			exceptionThrown = true;
		}

		assertThat(exceptionThrown, is(true));
		assertThat(this.errorMessages.size(), is(1));
		assertThat(this.errorMessages.get(0),is("[ERROR] lockClaimant 10 by user 11 failed."));
	}


	@Test
	public void testUnlockClaimantWithOptimisticLockException() throws Exception {
		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantControllerTest.this.claimantService).unlockClaimant(10, 11);
				will(throwException(new OptimisticLockException()));
			}
		});

		boolean exceptionThrown = false;
		try {
			this.controller.unlockClaimant(10, 11);
		} catch ( final OptimisticLockException e ) {
			exceptionThrown = true;
		}

		assertThat(exceptionThrown, is(true));
		assertThat(this.errorMessages.size(), is(1));
		assertThat(this.errorMessages.get(0),is("[WARN] unlockClaimant 10 by user 11 failed because of an optimistic locking exception."));
	}

	@Test
	public void testUnlockClaimantWithException() throws Exception {
		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantControllerTest.this.claimantService).unlockClaimant(10, 11);
				will(throwException(new Exception()));
			}
		});

		boolean exceptionThrown = false;
		try {
			this.controller.unlockClaimant(10, 11);
		} catch ( final Exception e ) {
			exceptionThrown = true;
		}

		assertThat(exceptionThrown, is(true));
		assertThat(this.errorMessages.size(), is(1));
		assertThat(this.errorMessages.get(0),is("[ERROR] unlockClaimant 10 by user 11 failed."));
	}

	@Test
	public void testClaimantLockStatusWithOptimisticLockException() throws Exception {
		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantControllerTest.this.claimantService).getClaimantLog(10);
				will(throwException(new OptimisticLockException()));
			}
		});

		boolean exceptionThrown = false;
		try {
			this.controller.claimantLockStatus(10);
		} catch ( final OptimisticLockException e ) {
			exceptionThrown = true;
		}

		assertThat(exceptionThrown, is(true));
		assertThat(this.errorMessages.size(), is(1));
		assertThat(this.errorMessages.get(0),is("[WARN] claimantLockStatus 10 failed because of an optimistic locking exception."));
	}

	@Test
	public void testClaimantLockStatusWithException() throws Exception {
		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantControllerTest.this.claimantService).getClaimantLog(10);
				will(throwException(new Exception()));
			}
		});

		boolean exceptionThrown = false;
		try {
			this.controller.claimantLockStatus(10);
		} catch ( final Exception e ) {
			exceptionThrown = true;
		}

		assertThat(exceptionThrown, is(true));
		assertThat(this.errorMessages.size(), is(1));
		assertThat(this.errorMessages.get(0),is("[ERROR] claimantLockStatus 10 failed."));
	}

	@Test
	public void testGetInteractionsForClaimant() {
		final List<ClaimantInteraction> notes = newArrayList();
		notes.add(dummyInteraction(ClaimantInteractionType.NOTE, dummyUser(123)));
		notes.add(dummyInteraction(ClaimantInteractionType.NOTE, dummyUser(345)));
		notes.add(dummyInteraction(ClaimantInteractionType.NOTE, dummyUser(456)));

		final List<ClaimantInteraction> events = newArrayList();
		events.add(dummyInteraction(ClaimantInteractionType.EVENT, dummyUser(123)));
		events.add(dummyInteraction(ClaimantInteractionType.EVENT, dummyUser(123)));

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getNotesForClaimant(CLAIMANT_ID);
				will(returnValue(notes));
				oneOf(claimantService).getEventsForClaimant(CLAIMANT_ID);
				will(returnValue(events));
				exactly(notes.size() + events.size()).of(claimantInteractionConverter).convert((ClaimantInteraction) with(notNullValue()));
				with(any(ClaimantInteractionDto.class));
			}
		});

		this.controller.claimantInteractions(CLAIMANT_ID);
	}

	@Test
	public void testGetNotesForClaimant() {
		final List<ClaimantInteraction> notes = newArrayList();
		notes.add(dummyInteraction(ClaimantInteractionType.NOTE, dummyUser(123)));
		notes.add(dummyInteraction(ClaimantInteractionType.NOTE, dummyUser(345)));

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getNotesForClaimant(CLAIMANT_ID);
				will(returnValue(notes));
				exactly(notes.size()).of(claimantInteractionConverter).convert((ClaimantInteraction) with(notNullValue()));
				with(any(ClaimantInteractionDto.class));
			}
		});

		this.controller.claimantNotes(CLAIMANT_ID);
	}

	@Test
	public void testGetEventsForClaimant() {
		final List<ClaimantInteraction> events = newArrayList();
		events.add(dummyInteraction(ClaimantInteractionType.EVENT, dummyUser(123)));
		events.add(dummyInteraction(ClaimantInteractionType.EVENT, dummyUser(123)));
		events.add(dummyInteraction(ClaimantInteractionType.EVENT, dummyUser(999)));

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getEventsForClaimant(CLAIMANT_ID);
				will(returnValue(events));
				exactly(events.size()).of(claimantInteractionConverter).convert((ClaimantInteraction) with(notNullValue()));
				with(any(ClaimantInteractionDto.class));
			}
		});

		this.controller.claimantEvents(CLAIMANT_ID);
	}

	@Test
	public void testSaveNote() {
		final ClaimantInteractionDto claimantInteractionDto = dummyInteractionDto("this is a note");
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).saveNote(claimantInteractionDto.getClaimantId(), null, claimantInteractionDto.getUserId(), claimantInteractionDto.getContent(), CLAIMANT);
			}
		});
		this.controller.saveNote(claimantInteractionDto);
	}

	@Test
	public void testSaveNoteWithInteractionDateTime() {
		final ClaimantInteractionDto claimantInteractionDto = dummyInteractionDto("this is a note");
		claimantInteractionDto.setProductId(2);
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).saveNoteWithInteractionDateTime(claimantInteractionDto.getClaimantId(), 2, claimantInteractionDto.getUserId(), claimantInteractionDto.getContent(), CLAIMANT, JodaUtils.timestampStringToLocalDateTimeOrNull(claimantInteractionDto.getInteractionDateTime()));
			}
		});
		this.controller.saveNoteWithInteractionDateTime(claimantInteractionDto);
	}

	@Test
	public void testUpdateNote() {
		final ClaimantInteractionDto claimantInteractionDto = dummyInteractionDto("this is a note");
		claimantInteractionDto.setId(123);
		claimantInteractionDto.setVersion(5);

		final ClaimantInteraction claimantInteraction = dummyInteraction(ClaimantInteractionType.NOTE, dummyUser(999));
		claimantInteraction.setId(123);
		claimantInteraction.setVersion(5);

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).updateNote(claimantInteractionDto.getId(), claimantInteractionDto.getClaimantId(), null, claimantInteractionDto.getUserId(), claimantInteractionDto.getContent(), CLAIMANT, 5);
				will(returnValue(claimantInteraction));
				oneOf(claimantInteractionConverter).convert(claimantInteraction);
			}
		});
		this.controller.updateNote(claimantInteractionDto);
	}

	@Test
	public void testSaveEvent() {
		final ClaimantInteractionDto claimantInteractionDto = dummyInteractionDto("this is an event");
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).saveEvent(claimantInteractionDto.getClaimantId(), null, claimantInteractionDto.getUserId(), claimantInteractionDto.getContent(), CLAIMANT);
			}
		});
		this.controller.saveEvent(dummyInteractionDto("this is an event"));
	}

	@Test
	public void testGetNoProductReferrals() {
		final List<ClaimantReferral> productReferrals = newArrayList();
		final List<ClaimantReferralDto> expected = newArrayList();

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getProductReferralsForClaimant(CLAIMANT_ID);
				will(returnValue(productReferrals));
			}
		});

		final List<ClaimantReferralDto> result = this.controller.getProductReferralsForClaimant(CLAIMANT_ID);

		assertThat(result, is(expected));
	}

	@Test
	public void testGetProductReferrals() {
		final List<ClaimantReferral> productReferrals = newArrayList(dummyProductReferral(1234), dummyProductReferral(5678));

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getProductReferralsForClaimant(CLAIMANT_ID);
				will(returnValue(productReferrals));
				exactly(2).of(claimantReferralConverter).convert(with(any(ClaimantReferral.class)));
				with(any(ClaimantReferralDto.class));
			}
		});

		final List<ClaimantReferralDto> result = this.controller.getProductReferralsForClaimant(CLAIMANT_ID);

		assertThat(result.size(), is(2));
	}

	@Test
	public void claimantInteractionsBySources() {
		final ClaimantInteractionsDto claimantInteractionsDto = new ClaimantInteractionsDto();
		ClaimantInteraction event1 = ClaimantInteraction.newEvent(CLAIMANT_ID, null,  dummyUser(123), "Referred customer (0) mr a surname", CLAIMANT);
		ClaimantInteraction note1 = ClaimantInteraction.newNote(CLAIMANT_ID,null, dummyUser(123), "Referred customer (0) mr a surname", CLAIMANT);
		ClaimantInteractionDto eventInteractionDto = new ClaimantInteractionDto();
		List<ClaimantInteraction> events = newArrayList(event1);
		List<ClaimantInteraction> notes = newArrayList(note1);

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getEventsForClaimantBySources(CLAIMANT_ID, newArrayList("PAYMENTS", "CLAIMANT", "PORTAL"),1 );
				will(returnValue(events));
				oneOf(claimantService).getNotesForClaimantBySources(CLAIMANT_ID, newArrayList("PAYMENTS", "CLAIMANT", "PORTAL"),1);
				will(returnValue(notes));
				atLeast(1).of(claimantInteractionConverter).convert(event1);
				will(returnValue(eventInteractionDto));
				atLeast(1).of(claimantInteractionConverter).convert(note1);
				will(returnValue(eventInteractionDto));
			}
		});

		final ClaimantInteractionsDto result = this.controller.claimantInteractionsBySources(CLAIMANT_ID, "PAYMENTS,CLAIMANT,PORTAL",1);
		assertThat(result.getEvents().size(), is(1));
	}

	private static ClaimantReferral dummyProductReferral(final int diallerReferenceId) {
		return new ClaimantReferral(1, CLAIMANT_ID, CLAIMANT_ID, 3388, diallerReferenceId);
	}

	private static User dummyUser(final int userId) {
		final User user = new User();
		user.setId(userId);

		return user;
	}

	private static ClaimantInteraction dummyInteraction(final ClaimantInteractionType type, final User user) {
		return new ClaimantInteraction(CLAIMANT_ID, null, type.toValue(), user, "test " + type.toPrettyString(), CLAIMANT.name());
	}

	private static ClaimantInteractionDto dummyInteractionDto(final String content) {
		return new ClaimantInteractionDto(null, CLAIMANT_ID, null, 1234, "some user", JodaUtils.newCurrentTimestampString(), content, CLAIMANT.name(), 0);
	}
}
