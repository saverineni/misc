package com.leadx.claimant.reference;

import com.leadx.test.integration.AbstractIntegrationTest;
import org.hibernate.SessionFactory;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;


@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class DebtManagementCompanyRepositoryIntTest extends AbstractIntegrationTest {

	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	private DebtManagementCompanyRepository repo;

	@Test
	public void shouldGetDebtManagementCompanies() {
		final DebtManagementCompany company = new DebtManagementCompany(1,"Test Company","","Organisation","","","1","","TEST TERRACE","","","TEST","","WA14 4DZ");
		final List<DebtManagementCompany> companies = this.repo.getDebtManagementCompanies();

		assertThat(companies.get(1), is(company));
	}
}