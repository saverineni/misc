package com.leadx.claimant.claimantservice;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.leadx.claimant.util.ClaimantTestUtils;
import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.RequiresTestData;

@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class ClaimantContactPreferenceRepositoryIntTest extends AbstractIntegrationTest {

	@Autowired
	ClaimantContactPreferenceRepository repository;

	private static final int CLAIMANT_ID = 12345;

	@Test
	@RequiresTestData(locations = { "clear" })
	public void testCreateClaimantContactPreference() throws Exception {
		final ClaimantContactPreference contactPreference = ClaimantTestUtils.createBlankContactPreference(CLAIMANT_ID);

		this.repository.saveOrUpdate(contactPreference);

		this.repository.evict(contactPreference);

		final ClaimantContactPreference createdContactPreference = this.repository.getByClaimantId(CLAIMANT_ID);
		assertThat(createdContactPreference.getClaimantId(), is(CLAIMANT_ID));
	}

	@Test
	@RequiresTestData(locations = { "claimant_contact_preferences" })
	public void testGetClaimantContactPreferenceByClaimantId() {
		final ClaimantContactPreference preference = this.repository.getByClaimantId(CLAIMANT_ID);
		assertThat(preference.getCancellation(), is(false));
	}

	@Test
	@RequiresTestData(locations = { "claimant_contact_preferences" })
	public void testGetClaimantContactPreferenceInvalidClaimantId() {
		final ClaimantContactPreference preferences = this.repository.getByClaimantId(1);
		assertNull(preferences);
	}

	@Test
	@RequiresTestData(locations = { "claimant_contact_preferences" })
	public void testGetClaimantContactPreferenceById() throws Exception {
		final ClaimantContactPreference preference = this.repository.getById(400);
		assertThat(preference.getId(), is(400));
		assertThat(preference.getClaimantId(), is(99999));
		assertThat(preference.getTelephoneOptIn(), is(false));
		assertThat(preference.getEmailOptIn(), is(true));
		assertThat(preference.getSmsOptIn(), is(false));
		assertThat(preference.getMarketingMailingOptIn(), is(true));
		assertThat(preference.getCancellation(), is(false));
	}

	@Test
	@RequiresTestData(locations = { "claimant_contact_preferences" })
	public void testUpdateClaimantContactPreference() {
		ClaimantContactPreference preference = this.repository.getById(400);
		assertThat(preference.getId(), is(400));
		assertThat(preference.getClaimantId(), is(99999));
		assertThat(preference.getTelephoneOptIn(), is(false));
		assertThat(preference.getEmailOptIn(), is(true));
		assertThat(preference.getSmsOptIn(), is(false));
		assertThat(preference.getMarketingMailingOptIn(), is(true));
		assertThat(preference.getCancellation(), is(false));

		preference.setTelephoneOptIn(true);
		preference.setEmailOptIn(false);
		preference.setSmsOptIn(true);
		preference.setMarketingMailingOptIn(false);
		preference.setCancellation(true);

		this.repository.saveOrUpdate(preference);

		preference = this.repository.getById(400);

		assertThat(preference.getId(), is(400));
		assertThat(preference.getClaimantId(), is(99999));
		assertThat(preference.getTelephoneOptIn(), is(true));
		assertThat(preference.getEmailOptIn(), is(false));
		assertThat(preference.getSmsOptIn(), is(true));
		assertThat(preference.getMarketingMailingOptIn(), is(false));
		assertThat(preference.getCancellation(), is(true));


	}
}
