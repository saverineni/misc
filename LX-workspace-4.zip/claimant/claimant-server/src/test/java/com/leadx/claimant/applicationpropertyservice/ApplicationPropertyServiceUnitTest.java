package com.leadx.claimant.applicationpropertyservice;

import static com.leadx.test.MockUtils.mockAndSetOn;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;

@SuppressWarnings("unqualified-field-access")
public class ApplicationPropertyServiceUnitTest {

	private ApplicationPropertyService applicationPropertyService;
	private ApplicationPropertyRepository applicationPropertyRepository;

	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
		}
	};

	@Before
	public void setup() {
		this.applicationPropertyService = new ApplicationPropertyService();
		this.applicationPropertyRepository = mockAndSetOn(this.context, ApplicationPropertyRepository.class, this.applicationPropertyService);
	}

	@Test
	public void shouldGetApplicationProperty() {
		final String propertyString = "findThisProperty";

		this.context.checking(new Expectations() {
			{
				oneOf(applicationPropertyRepository).get(propertyString);
				will(returnValue(any(String.class)));
			}
		});
	}
}