package com.leadx.claimant.util;

import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

import org.joda.time.LocalDateTime;
import org.junit.Test;

import com.leadx.claimant.client.ProductType;
import com.leadx.claimant.utils.CallRequestBuilder;
import com.leadx.lib.utl.JodaUtils;
import com.leadx.services.client.TcgCallRequest;

public class CallRequestBuilderTest {

	@Test
	public void createAssessmentCall(){
		final String assessmentCallGroup = ProductType.PBA.getShortName();
		final int claimantId = 111;
		final long leadId = 222;
		final String title = "Mr";
		final String forename = "Brendon";
		final String surname = "McCullum";
		final String homePhoneNumber = "01234567899";
		final String mobilePhoneNumber = "07777777777";
		final String postcode = "M5 5JL";
		final LocalDateTime scheduledDateTime = JodaUtils.newCurrentDateTime().plusDays(5);

		final TcgCallRequest tcgCallRequest = CallRequestBuilder.createAssessmentCall(assessmentCallGroup, claimantId, leadId, title,
															forename, surname, homePhoneNumber, mobilePhoneNumber, postcode, scheduledDateTime);

		assertThat(tcgCallRequest, is(notNullValue()));
		assertThat(tcgCallRequest.getClaimantId(), is(claimantId));
		assertThat(tcgCallRequest.getForename(), is(forename));
		assertThat(tcgCallRequest.getSurname(), is(surname));
		assertThat(tcgCallRequest.getPhoneNumber1(), is(homePhoneNumber));
		assertThat(tcgCallRequest.getPhoneNumber2(), is(mobilePhoneNumber));
		assertThat(tcgCallRequest.getPostcode(), is(postcode));
		assertThat(tcgCallRequest.getScheduledDateTime(), is(scheduledDateTime));
	}

	@Test
	public void createChaseCall(){
		final String chaseCallGroup = ProductType.PBA.getShortName();
		final int claimantId = 111;
		final long leadId = 222;
		final String title = "Mr";
		final String forename = "Brendon";
		final String surname = "McCullum";
		final String homePhoneNumber = "01234567899";
		final String mobilePhoneNumber = "07777777777";
		final String postcode = "M5 5JL";
		final LocalDateTime scheduledDateTime = JodaUtils.newCurrentDateTime().plusDays(5);

		final TcgCallRequest tcgCallRequest = CallRequestBuilder.createChaseCall(chaseCallGroup, claimantId, leadId, title,
										forename, surname, homePhoneNumber, mobilePhoneNumber, postcode, scheduledDateTime);

		assertThat(tcgCallRequest, is(notNullValue()));
		assertThat(tcgCallRequest.getClaimantId(), is(claimantId));
		assertThat(tcgCallRequest.getForename(), is(forename));
		assertThat(tcgCallRequest.getSurname(), is(surname));
		assertThat(tcgCallRequest.getPhoneNumber1(), is(homePhoneNumber));
		assertThat(tcgCallRequest.getPhoneNumber2(), is(mobilePhoneNumber));
		assertThat(tcgCallRequest.getPostcode(), is(postcode));
		assertThat(tcgCallRequest.getScheduledDateTime(), is(scheduledDateTime));
	}
}
