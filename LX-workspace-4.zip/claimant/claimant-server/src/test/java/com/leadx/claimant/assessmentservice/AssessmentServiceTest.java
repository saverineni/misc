package com.leadx.claimant.assessmentservice;

import static com.leadx.test.MockUtils.mockAndSetOn;

import org.apache.commons.lang3.StringUtils;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.lib.concurrent.Synchroniser;
import org.jmock.lib.legacy.ClassImposteriser;
import org.joda.time.DateTimeUtils;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.junit.Before;
import org.junit.Test;

import com.leadx.claimant.callallocationservice.CallAllocationService;
import com.leadx.claimant.callallocationservice.ClaimantGroupAllocation;
import com.leadx.claimant.calllogservice.CallLog;
import com.leadx.claimant.calllogservice.CallLogService;
import com.leadx.claimant.claimantservice.Claimant;
import com.leadx.claimant.claimantservice.ClaimantBuilder;
import com.leadx.claimant.claimantservice.ClaimantService;
import com.leadx.claimant.client.AssessmentDispositionDto;
import com.leadx.claimant.client.CallDisposition;
import com.leadx.claimant.client.CallType;
import com.leadx.claimant.client.ProductType;
import com.leadx.claimant.reference.TriState;
import com.leadx.claimant.utils.CallRequestBuilder;
import com.leadx.lib.utl.JodaUtils;
import com.leadx.services.client.CallReason;
import com.leadx.services.client.TcgCallRequest;
import com.leadx.services.client.TcgProduct;
import com.leadx.services.client.service.TelephonyService;
import com.leadx.services.distribution.client.DistributionClient;

public class AssessmentServiceTest{
	private AssessmentService assessmentService;
	private CallLogService callLogService;
	private TelephonyService telephonyService;
	private ClaimantService claimantService;
	private DistributionClient distributionClient;
	private CallAllocationService callAllocationService;
	private static final LocalDateTime NOW =  new LocalDateTime(2014, 10, 5, 14, 55, 10, 0);

	private final Synchroniser synchroniser = new Synchroniser();

	private final Mockery context = new Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
			setThreadingPolicy(AssessmentServiceTest.this.synchroniser);
		}
	};


	@Before
	public void setUp() {
		DateTimeUtils.setCurrentMillisFixed(NOW.toDateTime().getMillis());
		this.assessmentService = new AssessmentService();
		this.claimantService = mockAndSetOn(this.context, ClaimantService.class, this.assessmentService);
		this.callLogService = mockAndSetOn(this.context, CallLogService.class, this.assessmentService);
		this.telephonyService = mockAndSetOn(this.context, TelephonyService.class, this.assessmentService);
		this.distributionClient = mockAndSetOn(this.context, DistributionClient.class, this.assessmentService);
		this.callAllocationService = mockAndSetOn(this.context, CallAllocationService.class, this.assessmentService);
	}

	@Test
	public void dispositionOutboundChaseCallBack() throws Exception {
		final int claimantId = 111;
		final int dispositionId = 74;
		final CallDisposition callDisposition = CallDisposition.getById(dispositionId);
		final int diallerRefId = 222;
		final boolean inbound = false;
		final int userId = 555;
		final String title = "Mr";
		final String forename = "Brendon";
		final String surname = "McCullum";
		final String homePhoneNumber = "01234567899";
		final String mobilePhoneNumber = "07777777777";
		final String callbackDatetime = "01/01/2025 12:30:45";
		final LocalDateTime scheduledDateTime = JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(callbackDatetime);
		final String chaseCallGroup = ProductType.PBA.getShortName();
		final CallLog callLog = new CallLog(claimantId, callDisposition, CallType.CHASE, diallerRefId, inbound, userId);

		final AssessmentDispositionDto assessmentDispositionDto = buildAssessmentDispositionDto(claimantId, false, CallReason.CHASE, dispositionId, diallerRefId, callbackDatetime, userId);
		final TcgCallRequest tcgCallRequest = CallRequestBuilder.createChaseCall(chaseCallGroup, claimantId, 0L, title,
				forename, surname, homePhoneNumber, mobilePhoneNumber, StringUtils.EMPTY, scheduledDateTime);

		this.context.checking(new Expectations() {
			{
				oneOf(AssessmentServiceTest.this.claimantService).getClaimantById(claimantId);
				will(returnValue(buildClaimant()));
				atLeast(1).of(AssessmentServiceTest.this.distributionClient).cancel(with(any(com.leadx.services.distribution.client.CancellationRequest.class)));
				oneOf(AssessmentServiceTest.this.callLogService).saveCallLog(callLog);
				never(AssessmentServiceTest.this.telephonyService).scheduleCall(tcgCallRequest);
				oneOf(AssessmentServiceTest.this.claimantService).unlockClaimant(claimantId, userId);

			}
		});

		this.assessmentService.dispositionCall(assessmentDispositionDto, callDisposition);
	}

	@Test
	public void dispositionOutboundChaseNoCallBack() throws Exception {
		final int claimantId = 111;
		final int dispositionId = 76;
		final CallDisposition callDisposition = CallDisposition.getById(dispositionId);
		final int diallerRefId = 222;
		final boolean inbound = false;
		final int userId = 555;
		final String title = "Mr";
		final String forename = "Brendon";
		final String surname = "McCullum";
		final String homePhoneNumber = "01234567899";
		final String mobilePhoneNumber = "07777777777";
		final String callbackDatetime = "01/01/2025 12:30:45";
		final LocalDateTime scheduledDateTime = JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(callbackDatetime);
		final String chaseCallGroup = ProductType.PBA.getShortName();
		final CallLog callLog = new CallLog(claimantId, callDisposition, CallType.CHASE, diallerRefId, inbound, userId);

		final AssessmentDispositionDto assessmentDispositionDto = buildAssessmentDispositionDto(claimantId, false, CallReason.CHASE, dispositionId, diallerRefId, callbackDatetime, userId);
		final TcgCallRequest tcgCallRequest = CallRequestBuilder.createChaseCall(chaseCallGroup, claimantId, 0L, title,
				forename, surname, homePhoneNumber, mobilePhoneNumber, StringUtils.EMPTY, scheduledDateTime);

		this.context.checking(new Expectations() {
			{
				oneOf(AssessmentServiceTest.this.claimantService).getClaimantById(claimantId);
				will(returnValue(buildClaimant()));
				atLeast(1).of(AssessmentServiceTest.this.distributionClient).cancel(with(any(com.leadx.services.distribution.client.CancellationRequest.class)));
				oneOf(AssessmentServiceTest.this.callLogService).saveCallLog(callLog);
				never(AssessmentServiceTest.this.telephonyService).scheduleCall(tcgCallRequest);
				oneOf(AssessmentServiceTest.this.claimantService).unlockClaimant(claimantId, userId);

			}
		});

		this.assessmentService.dispositionCall(assessmentDispositionDto, callDisposition);
	}

	@Test
	public void dispositionOutboundChaseNewClaimant() throws Exception {
		final int claimantId = 111;
		final int dispositionId = 1;
		final CallDisposition callDisposition = CallDisposition.getById(dispositionId);
		final int diallerRefId = 222;
		final boolean inbound = false;
		final int userId = 555;
		final String title = "Mr";
		final String forename = "Brendon";
		final String surname = "McCullum";
		final String homePhoneNumber = "01234567899";
		final String mobilePhoneNumber = "07777777777";
		final String callbackDatetime = "01/01/2025 12:30:45";
		final LocalDateTime scheduledDateTime = JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(callbackDatetime);
		final CallLog callLog = new CallLog(claimantId, callDisposition, CallType.CHASE, diallerRefId, inbound, userId);

		final AssessmentDispositionDto assessmentDispositionDto = buildAssessmentDispositionDto(claimantId, false, CallReason.CHASE, dispositionId, diallerRefId, callbackDatetime, userId);
		assessmentDispositionDto.setNewClaimant(true);
		final TcgCallRequest tcgCallRequest = CallRequestBuilder.createChaseCall(StringUtils.EMPTY, claimantId, 0L, title,
				forename, surname, homePhoneNumber, mobilePhoneNumber, StringUtils.EMPTY, scheduledDateTime);

		this.context.checking(new Expectations() {
			{
				oneOf(AssessmentServiceTest.this.claimantService).getClaimantById(claimantId);
				will(returnValue(buildClaimant()));
				never(AssessmentServiceTest.this.distributionClient).cancel(with(any(com.leadx.services.distribution.client.CancellationRequest.class)));
				never(AssessmentServiceTest.this.callLogService).saveCallLog(callLog);
				oneOf(AssessmentServiceTest.this.callLogService).saveCallLogNoConstraints(callLog);
				never(AssessmentServiceTest.this.telephonyService).scheduleCall(tcgCallRequest);
				oneOf(AssessmentServiceTest.this.claimantService).unlockClaimant(claimantId, userId);

			}
		});

		this.assessmentService.dispositionCall(assessmentDispositionDto, callDisposition);
	}

	@Test
	public void callbackDispositionOutboundChaseNewClaimant() throws Exception {
		final int claimantId = 111;
		final int dispositionId = 10;
		final CallDisposition callDisposition = CallDisposition.getById(dispositionId);
		final int diallerRefId = 222;
		final boolean inbound = false;
		final int userId = 555;
		final String title = "Mr";
		final String forename = "Brendon";
		final String surname = "McCullum";
		final String homePhoneNumber = "01234567899";
		final String mobilePhoneNumber = "07777777777";
		final String callbackDatetime = "01/01/2025 12:30:45";
		final LocalDateTime scheduledDateTime = JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(callbackDatetime);
		final CallLog callLog = new CallLog(claimantId, callDisposition, CallType.CHASE, diallerRefId, inbound, userId);

		final AssessmentDispositionDto assessmentDispositionDto = buildAssessmentDispositionDto(claimantId, false, CallReason.CHASE, dispositionId, diallerRefId, callbackDatetime, userId);
		assessmentDispositionDto.setNewClaimant(true);
		final TcgCallRequest tcgCallRequest = CallRequestBuilder.createAssessmentCall(ProductType.PBA.getShortName(), claimantId, 0L, title,
				forename, surname, homePhoneNumber, mobilePhoneNumber, StringUtils.EMPTY, scheduledDateTime);

		this.context.checking(new Expectations() {
			{
				oneOf(AssessmentServiceTest.this.claimantService).getClaimantById(claimantId);
				will(returnValue(buildClaimant()));
				never(AssessmentServiceTest.this.distributionClient).cancel(with(any(com.leadx.services.distribution.client.CancellationRequest.class)));
				never(AssessmentServiceTest.this.callLogService).saveCallLog(callLog);
				oneOf(AssessmentServiceTest.this.callLogService).saveCallLogNoConstraints(callLog);
				oneOf(AssessmentServiceTest.this.telephonyService).scheduleCall(tcgCallRequest);
				oneOf(AssessmentServiceTest.this.claimantService).unlockClaimant(claimantId, userId);

			}
		});

		this.assessmentService.dispositionCall(assessmentDispositionDto, callDisposition);
	}

	@Test
	public void dispositionInboundChaseCallBack() throws Exception {
		final int claimantId = 111;
		final int dispositionId = 74;
		final CallDisposition callDisposition = CallDisposition.getById(dispositionId);
		final int diallerRefId = 222;
		final boolean inbound = true;
		final int userId = 555;
		final String title = "Mr";
		final String forename = "Brendon";
		final String surname = "McCullum";
		final String homePhoneNumber = "01234567899";
		final String mobilePhoneNumber = "07777777777";
		final String callbackDatetime = "01/01/2025 12:30:45";
		final LocalDateTime scheduledDateTime = JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(callbackDatetime);
		final String chaseCallGroup = ProductType.PBA.getShortName();
		final CallLog callLog = new CallLog(claimantId, callDisposition, CallType.CHASE, diallerRefId, inbound, userId);
		final ClaimantGroupAllocation claimantGroupAllocation = new ClaimantGroupAllocation(claimantId, "chase", "ppi", new LocalDateTime());

		final AssessmentDispositionDto assessmentDispositionDto = buildAssessmentDispositionDto(claimantId, true, CallReason.CHASE, dispositionId, diallerRefId, callbackDatetime, userId);
		final TcgCallRequest tcgCallRequest = CallRequestBuilder.createChaseCall(chaseCallGroup, claimantId, 0L, title,
				forename, surname, homePhoneNumber, mobilePhoneNumber, StringUtils.EMPTY, scheduledDateTime);

		this.context.checking(new Expectations() {
			{
				oneOf(AssessmentServiceTest.this.claimantService).getClaimantById(claimantId);
				will(returnValue(buildClaimant()));
				atLeast(1).of(AssessmentServiceTest.this.distributionClient).cancel(with(any(com.leadx.services.distribution.client.CancellationRequest.class)));
				oneOf(AssessmentServiceTest.this.callLogService).saveCallLog(callLog);
				oneOf(callAllocationService).getClaimantGroupAllocationByClaimantId(claimantId);
				will(returnValue(claimantGroupAllocation));
				oneOf(callAllocationService).updateClaimantsGroupAllocation(claimantId, TcgProduct.PPI, scheduledDateTime);
				oneOf(AssessmentServiceTest.this.claimantService).unlockClaimant(claimantId, userId);

			}
		});

		this.assessmentService.dispositionCall(assessmentDispositionDto, callDisposition);
	}

	@Test
	public void dispositionInboundChaseNoCallBack() throws Exception {
		final int claimantId = 111;
		final int dispositionId = 76;
		final CallDisposition callDisposition = CallDisposition.getById(dispositionId);
		final int diallerRefId = 222;
		final boolean inbound = true;
		final int userId = 555;
		final String title = "Mr";
		final String forename = "Brendon";
		final String surname = "McCullum";
		final String homePhoneNumber = "01234567899";
		final String mobilePhoneNumber = "07777777777";
		final String callbackDatetime = "01/01/2025 12:30:45";
		final LocalDateTime scheduledDateTime = JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(callbackDatetime);
		final String chaseCallGroup = ProductType.PBA.getShortName();
		final CallLog callLog = new CallLog(claimantId, callDisposition, CallType.CHASE, diallerRefId, inbound, userId);

		final AssessmentDispositionDto assessmentDispositionDto = buildAssessmentDispositionDto(claimantId, true, CallReason.CHASE, dispositionId, diallerRefId, callbackDatetime, userId);
		final TcgCallRequest tcgCallRequest = CallRequestBuilder.createChaseCall(chaseCallGroup, claimantId, 0L, title,
				forename, surname, homePhoneNumber, mobilePhoneNumber, StringUtils.EMPTY, scheduledDateTime);

		this.context.checking(new Expectations() {
			{
				oneOf(AssessmentServiceTest.this.claimantService).getClaimantById(claimantId);
				will(returnValue(buildClaimant()));
				atLeast(1).of(AssessmentServiceTest.this.distributionClient).cancel(with(any(com.leadx.services.distribution.client.CancellationRequest.class)));
				oneOf(AssessmentServiceTest.this.callLogService).saveCallLog(callLog);
				never(AssessmentServiceTest.this.telephonyService).scheduleCall(tcgCallRequest);
				oneOf(AssessmentServiceTest.this.claimantService).unlockClaimant(claimantId, userId);

			}
		});

		this.assessmentService.dispositionCall(assessmentDispositionDto, callDisposition);
	}


	@Test
	public void dispositionOutboundAssessmentCallBack() throws Exception {
		final int claimantId = 111;
		final int dispositionId = 10;
		final CallDisposition callDisposition = CallDisposition.getById(dispositionId);
		final int diallerRefId = 222;
		final boolean inbound = false;
		final int userId = 555;
		final String title = "Mr";
		final String forename = "Brendon";
		final String surname = "McCullum";
		final String homePhoneNumber = "01234567899";
		final String mobilePhoneNumber = "07777777777";
		final String callbackDatetime = "01/01/2025 12:30:45";
		final LocalDateTime scheduledDateTime = JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(callbackDatetime);
		final CallLog callLog = new CallLog(claimantId, callDisposition, CallType.ASSESSMENT, diallerRefId, inbound, userId);

		final AssessmentDispositionDto assessmentDispositionDto = buildAssessmentDispositionDto(claimantId, false, CallReason.ASSESSMENT, dispositionId, diallerRefId, callbackDatetime, userId);
		final TcgCallRequest tcgCallRequest = CallRequestBuilder.createAssessmentCall(StringUtils.EMPTY, claimantId, 0L, title,
															forename, surname, homePhoneNumber, mobilePhoneNumber, StringUtils.EMPTY, scheduledDateTime);

		this.context.checking(new Expectations() {
			{
				oneOf(AssessmentServiceTest.this.claimantService).getClaimantById(claimantId);
				will(returnValue(buildClaimant()));
				atLeast(1).of(AssessmentServiceTest.this.distributionClient).cancel(with(any(com.leadx.services.distribution.client.CancellationRequest.class)));
				oneOf(AssessmentServiceTest.this.callLogService).saveCallLog(callLog);
				never(AssessmentServiceTest.this.telephonyService).scheduleCall(tcgCallRequest);
				oneOf(AssessmentServiceTest.this.claimantService).unlockClaimant(claimantId, userId);

			}
		});

		this.assessmentService.dispositionCall(assessmentDispositionDto, callDisposition);
	}

	@Test
	public void dispositionOutboundAssessmentNoCallBack() throws Exception {
		final int claimantId = 111;
		final int dispositionId = 1;
		final CallDisposition callDisposition = CallDisposition.getById(dispositionId);
		final int diallerRefId = 222;
		final boolean inbound = false;
		final int userId = 555;
		final String title = "Mr";
		final String forename = "Brendon";
		final String surname = "McCullum";
		final String homePhoneNumber = "01234567899";
		final String mobilePhoneNumber = "07777777777";
		final String callbackDatetime = "01/01/2025 12:30:45";
		final LocalDateTime scheduledDateTime = JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(callbackDatetime);
		final CallLog callLog = new CallLog(claimantId, callDisposition, CallType.ASSESSMENT, diallerRefId, inbound, userId);

		final AssessmentDispositionDto assessmentDispositionDto = buildAssessmentDispositionDto(claimantId, false, CallReason.ASSESSMENT, dispositionId, diallerRefId, callbackDatetime, userId);
		final TcgCallRequest tcgCallRequest =CallRequestBuilder.createAssessmentCall(StringUtils.EMPTY, claimantId, 0L, title,
				forename, surname, homePhoneNumber, mobilePhoneNumber, StringUtils.EMPTY, scheduledDateTime);

		this.context.checking(new Expectations() {
			{
				oneOf(AssessmentServiceTest.this.claimantService).getClaimantById(claimantId);
				will(returnValue(buildClaimant()));
				never(AssessmentServiceTest.this.distributionClient).cancel(with(any(com.leadx.services.distribution.client.CancellationRequest.class)));
				oneOf(AssessmentServiceTest.this.callLogService).saveCallLog(callLog);
				never(AssessmentServiceTest.this.telephonyService).scheduleCall(tcgCallRequest);
				oneOf(AssessmentServiceTest.this.claimantService).unlockClaimant(claimantId, userId);

			}
		});

		this.assessmentService.dispositionCall(assessmentDispositionDto, callDisposition);
	}

	@Test
	public void dispositionOutboundAssessmentNewClaimant() throws Exception {
		final int claimantId = 111;
		final int dispositionId = 1;
		final CallDisposition callDisposition = CallDisposition.getById(dispositionId);
		final int diallerRefId = 222;
		final boolean inbound = false;
		final int userId = 555;
		final String title = "Mr";
		final String forename = "Brendon";
		final String surname = "McCullum";
		final String homePhoneNumber = "01234567899";
		final String mobilePhoneNumber = "07777777777";
		final String callbackDatetime = "01/01/2025 12:30:45";
		final LocalDateTime scheduledDateTime = JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(callbackDatetime);
		final CallLog callLog = new CallLog(claimantId, callDisposition, CallType.ASSESSMENT, diallerRefId, inbound, userId);

		final AssessmentDispositionDto assessmentDispositionDto = buildAssessmentDispositionDto(claimantId, false, CallReason.ASSESSMENT, dispositionId, diallerRefId, callbackDatetime, userId);
		assessmentDispositionDto.setNewClaimant(true);

		final TcgCallRequest tcgCallRequest =CallRequestBuilder.createAssessmentCall(StringUtils.EMPTY, claimantId, 0L, title,
				forename, surname, homePhoneNumber, mobilePhoneNumber, StringUtils.EMPTY, scheduledDateTime);

		this.context.checking(new Expectations() {
			{
				oneOf(AssessmentServiceTest.this.claimantService).getClaimantById(claimantId);
				will(returnValue(buildClaimant()));
				never(AssessmentServiceTest.this.distributionClient).cancel(with(any(com.leadx.services.distribution.client.CancellationRequest.class)));
				never(AssessmentServiceTest.this.callLogService).saveCallLog(callLog);
				oneOf(AssessmentServiceTest.this.callLogService).saveCallLogNoConstraints(callLog);
				never(AssessmentServiceTest.this.telephonyService).scheduleCall(tcgCallRequest);
				oneOf(AssessmentServiceTest.this.claimantService).unlockClaimant(claimantId, userId);

			}
		});

		this.assessmentService.dispositionCall(assessmentDispositionDto, callDisposition);
	}

	@Test
	public void dispositionInboundAssessmentCallBack() throws Exception {
		final int claimantId = 111;
		final int dispositionId = 10;
		final CallDisposition callDisposition = CallDisposition.getById(dispositionId);
		final int diallerRefId = 222;
		final boolean inbound = true;
		final int userId = 555;
		final String title = "Mr";
		final String forename = "Brendon";
		final String surname = "McCullum";
		final String homePhoneNumber = "01234567899";
		final String mobilePhoneNumber = "07777777777";
		final String callbackDatetime = "01/01/2025 12:30:45";
		final LocalDateTime scheduledDateTime = JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(callbackDatetime);
		final CallLog callLog = new CallLog(claimantId, callDisposition, CallType.ASSESSMENT, diallerRefId, inbound, userId);

		final AssessmentDispositionDto assessmentDispositionDto = buildAssessmentDispositionDto(claimantId, true, CallReason.ASSESSMENT, dispositionId, diallerRefId, callbackDatetime, userId);
		final TcgCallRequest tcgCallRequest = CallRequestBuilder.createAssessmentCall(StringUtils.EMPTY, claimantId, 0L, title,
				forename, surname, homePhoneNumber, mobilePhoneNumber, StringUtils.EMPTY, scheduledDateTime);
		assessmentDispositionDto.setCallReasonGroup("ppi");

		this.context.checking(new Expectations() {
			{
				oneOf(AssessmentServiceTest.this.claimantService).getClaimantById(claimantId);
				will(returnValue(buildClaimant()));
				atLeast(1).of(AssessmentServiceTest.this.distributionClient).cancel(with(any(com.leadx.services.distribution.client.CancellationRequest.class)));
				oneOf(AssessmentServiceTest.this.callLogService).saveCallLog(callLog);
				oneOf(AssessmentServiceTest.this.telephonyService).scheduleCall(tcgCallRequest);
				oneOf(AssessmentServiceTest.this.claimantService).unlockClaimant(claimantId, userId);

			}
		});

		this.assessmentService.dispositionCall(assessmentDispositionDto, callDisposition);
	}

	@Test
	public void dispositionInboundAssessmentNoCallBack() throws Exception {
		final int claimantId = 111;
		final int dispositionId = 1;
		final CallDisposition callDisposition = CallDisposition.getById(dispositionId);
		final int diallerRefId = 222;
		final boolean inbound = true;
		final int userId = 555;
		final String title = "Mr";
		final String forename = "Brendon";
		final String surname = "McCullum";
		final String homePhoneNumber = "01234567899";
		final String mobilePhoneNumber = "07777777777";
		final String callbackDatetime = "01/01/2025 12:30:45";
		final LocalDateTime scheduledDateTime = JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(callbackDatetime);
		final CallLog callLog = new CallLog(claimantId, callDisposition, CallType.ASSESSMENT, diallerRefId, inbound, userId);

		final AssessmentDispositionDto assessmentDispositionDto = buildAssessmentDispositionDto(claimantId, true, CallReason.ASSESSMENT, dispositionId, diallerRefId, callbackDatetime, userId);
		final TcgCallRequest tcgCallRequest = CallRequestBuilder.createAssessmentCall(StringUtils.EMPTY, claimantId, 0L, title,
				forename, surname, homePhoneNumber, mobilePhoneNumber, StringUtils.EMPTY, scheduledDateTime);

		this.context.checking(new Expectations() {
			{
				oneOf(AssessmentServiceTest.this.claimantService).getClaimantById(claimantId);
				will(returnValue(buildClaimant()));
				never(AssessmentServiceTest.this.distributionClient).cancel(with(any(com.leadx.services.distribution.client.CancellationRequest.class)));
				oneOf(AssessmentServiceTest.this.callLogService).saveCallLog(callLog);
				never(AssessmentServiceTest.this.telephonyService).scheduleCall(tcgCallRequest);
				oneOf(AssessmentServiceTest.this.claimantService).unlockClaimant(claimantId, userId);

			}
		});

		this.assessmentService.dispositionCall(assessmentDispositionDto, callDisposition);
	}

	@Test
	public void dispositionInboundAssessmentNoCallBackSuppressClaimant() throws Exception {
		final int claimantId = 111;
		final int dispositionId = 6;
		final CallDisposition callDisposition = CallDisposition.getById(dispositionId);
		final int diallerRefId = 222;
		final boolean inbound = true;
		final int userId = 555;
		final String title = "Mr";
		final String forename = "Brendon";
		final String surname = "McCullum";
		final String homePhoneNumber = "01234567899";
		final String mobilePhoneNumber = "07777777777";
		final String callbackDatetime = "01/01/2025 12:30:45";
		final LocalDateTime scheduledDateTime = JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(callbackDatetime);
		final CallLog callLog = new CallLog(claimantId, callDisposition, CallType.ASSESSMENT, diallerRefId, inbound, userId);

		final AssessmentDispositionDto assessmentDispositionDto = buildAssessmentDispositionDto(claimantId, true, CallReason.ASSESSMENT, dispositionId, diallerRefId, callbackDatetime, userId);
		final TcgCallRequest tcgCallRequest = CallRequestBuilder.createAssessmentCall(StringUtils.EMPTY, claimantId, 0L, title,
				forename, surname, homePhoneNumber, mobilePhoneNumber, StringUtils.EMPTY, scheduledDateTime);

		this.context.checking(new Expectations() {
			{
				oneOf(AssessmentServiceTest.this.claimantService).getClaimantById(claimantId);
				will(returnValue(buildClaimant()));
				exactly(2).of(AssessmentServiceTest.this.distributionClient).cancel(with(any(com.leadx.services.distribution.client.CancellationRequest.class)));
				oneOf(AssessmentServiceTest.this.callLogService).saveCallLog(callLog);
				never(AssessmentServiceTest.this.telephonyService).scheduleCall(tcgCallRequest);
				oneOf(AssessmentServiceTest.this.claimantService).markClaimantAsSuppressed(claimantId, userId);
				oneOf(AssessmentServiceTest.this.claimantService).unlockClaimant(claimantId, userId);

			}
		});

		this.assessmentService.dispositionCall(assessmentDispositionDto, callDisposition);
	}

	private static AssessmentDispositionDto buildAssessmentDispositionDto(int claimantId, boolean inbound, String callReason, int dispositionId, int diallerRefId, String callbackDatetime, int userId){
		final AssessmentDispositionDto assessmentDispositionDto = new AssessmentDispositionDto();
		assessmentDispositionDto.setClaimantId(claimantId);
		assessmentDispositionDto.setDispositionId(dispositionId);
		assessmentDispositionDto.setDiallerRefId(diallerRefId);
		assessmentDispositionDto.setInbound(inbound);
		assessmentDispositionDto.setCallReason(callReason);
		assessmentDispositionDto.setCallbackDateTime(callbackDatetime);
		assessmentDispositionDto.setUserId(userId);
		assessmentDispositionDto.setCallReasonGroup(ProductType.PBA.getShortName());

		return assessmentDispositionDto;
	}

	private static Claimant buildClaimant(){
		return new ClaimantBuilder().setId(111)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("Mr")
				.setForename("Brendon")
				.setMiddleName(StringUtils.EMPTY)
				.setSurname("McCullum")
				.setPreviousSurname(StringUtils.EMPTY)
				.setDob(new LocalDate(1980, 2, 21))
				.setHomeTelephone("01234567899")
				.setMobileTelephone("07777777777")
				.setAlternativeTelephone("1234567890")
				.setWorkTelephone(StringUtils.EMPTY)
				.setEmail("me1@me.com")
				.setFreePpi(true)
				.setFormalDebtArrangement(TriState.NO)
				.setIvaCompanyId(1234)
				.setIvaReference("iva-ref")
				.setInformalDebtArrangement(TriState.NO)
				.setDebtManagementCompanyId(12121)
				.setDebtManagementReference("debt-ref")
				.createClaimant();
	}
}
