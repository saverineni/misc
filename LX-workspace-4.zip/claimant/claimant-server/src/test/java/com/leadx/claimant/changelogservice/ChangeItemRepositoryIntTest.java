package com.leadx.claimant.changelogservice;

import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import org.joda.time.LocalDateTime;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.NoTestData;

@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class ChangeItemRepositoryIntTest extends AbstractIntegrationTest {

	@Autowired
	ChangeItemRepository repository;

	@Test
	@NoTestData
	public void testCreateChangeItem() throws Exception {
		final ChangeGroup changeGroup = new ChangeGroup(1, 2, new LocalDateTime(2014, 3, 23, 11, 45));
		final ChangeItem changeItem = new ChangeItem(changeGroup, "field", "old", "new");
		this.repository.createChangeItem(changeItem);

		final ChangeItem newItem = this.repository.getChangeItemById(changeItem.getId());
		assertThat(newItem.getId(), is(greaterThan(0)));

	}
}