package com.leadx.claimant.addressservice;

import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.ImmutableList;
import com.leadx.claimant.client.AddressServiceWrapper;
import com.leadx.claimant.util.UrlTester;

@SuppressWarnings("unqualified-field-access")
public class AddressWrapperTest extends UrlTester {
	private AddressServiceWrapper wrapper;


	@Before
	public void setUp() {
		this.wrapper = new AddressServiceWrapper();
		super.setUp(wrapper);

	}

	@Test
	public void testUrlsMatchForGetByIds() throws Exception {
		final String urlMapping = "/address/ids";
		setWrapperExpectation("http://host:port" + urlMapping + "/2,3", String.class);
		this.wrapper.getAddressesByIds(ImmutableList.of(2, 3));

		testControllerUrl(AddressController.class, "getAddressesByIds", String.class, urlMapping + "/{csvIds}");
	}

}
