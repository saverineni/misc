package com.leadx.claimant.claimantservice;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created by kiran.prakash on 30/03/2017.
 */
public class SourceTest {

    @Test
    public void testFromValue(){
        Assert.assertEquals(Source.CLAIMANT, Source.fromValue("claimant"));
    }

    @Test(expected=IllegalArgumentException.class)
    public void fromValueReturnsNullWhenNoMatch(){
        Assert.assertNull(Source.fromValue("claimants"));
    }

    @Test
    public void fromValueIgnoresCase(){
        Assert.assertEquals(Source.SALES, Source.fromValue("SALES"));
    }

    @Test
    public void fromValueReturnsForCamelCase(){
        Assert.assertEquals(Source.SALES, Source.fromValue("Sales"));
    }
}
