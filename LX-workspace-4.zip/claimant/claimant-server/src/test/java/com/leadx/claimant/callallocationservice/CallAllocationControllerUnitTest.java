package com.leadx.claimant.callallocationservice;

import static org.hamcrest.Matchers.is;
import static org.jmock.lib.legacy.ClassImposteriser.INSTANCE;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import ch.qos.logback.classic.Level;
import ch.qos.logback.core.AppenderBase;

import com.leadx.claimant.calllogservice.CallLogController;
import com.leadx.claimant.client.CancelCallRequestDto;
import com.leadx.services.client.TcgProduct;

public class CallAllocationControllerUnitTest {


	private final Mockery context = new Mockery() {
		{
			setImposteriser(INSTANCE);
		}
	};


	private CallAllocationController callAllocationController;
	private CallAllocationService callAllocationService;
	private List<String> errorMessages;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Before
	public void setUp() {
		this.callAllocationController = new CallAllocationController();

		this.callAllocationService = this.context.mock(CallAllocationService.class);
		ReflectionTestUtils.setField(this.callAllocationController, "callAllocationService", this.callAllocationService);

		// Add a log appender to capture all the error messages
		final ch.qos.logback.classic.Logger log = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(CallLogController.class);
		log.setLevel(Level.WARN);
		this.errorMessages = new ArrayList<>();

		final AppenderBase appender = new AppenderBase() {
			@Override
			protected void append(final Object eventObject) {
				CallAllocationControllerUnitTest.this.errorMessages.add(eventObject.toString());
			}
		};

		appender.start();
		log.addAppender(appender);
	}


	@Test
	public void testScheduleCallAllocations() {


		this.context.checking(new Expectations() {
			{
				oneOf(CallAllocationControllerUnitTest.this.callAllocationService).updateCallAllocations(0);
			}
		});

		final ResponseEntity<String> response = this.callAllocationController.scheduleCallAllocations(0);
		assertThat(response.getStatusCode(), is(HttpStatus.OK));
	}


	@Test
	public void testCancelCallAllocation() {

		final CancelCallRequestDto cancelCallRequestDto = new CancelCallRequestDto();
		cancelCallRequestDto.setClaimantId(1234);
		cancelCallRequestDto.setTcgProduct(TcgProduct.PPI);
		cancelCallRequestDto.setUserId(1234);

		this.context.checking(new Expectations() {
			{
				oneOf(CallAllocationControllerUnitTest.this.callAllocationService).cancelCallAllocation(cancelCallRequestDto.getClaimantId(), cancelCallRequestDto.getUserId(), cancelCallRequestDto.getTcgProduct());
			}
		});

		final ResponseEntity<String> response = this.callAllocationController.cancelCallAllocation(cancelCallRequestDto);
		assertThat(response.getStatusCode(), is(HttpStatus.OK));

	}

	@Test
	public void reconcileCallAllocation() {
		final int offsetDays = 1;

		this.context.checking(new Expectations() {
			{
				oneOf(CallAllocationControllerUnitTest.this.callAllocationService).reconcileCallAllocations(offsetDays);
			}
		});

		final ResponseEntity<String> response = this.callAllocationController.reconcileCallAllocations(offsetDays);
		assertThat(response.getStatusCode(), is(HttpStatus.OK));
	}



}
