package com.leadx.claimant.claimantservice;

import static com.google.common.collect.Lists.newArrayList;
import static com.leadx.claimant.util.ClaimantTestUtils.createBlankContactPreference;
import static com.leadx.claimant.util.ClaimantTestUtils.createBlankContactPreferenceDto;
import static com.leadx.test.MockUtils.mockAndSetOn;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.util.List;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;

import com.leadx.claimant.client.ClaimantContactPreferenceDto;

@SuppressWarnings("unqualified-field-access")
public class ClaimantContactPreferenceControllerTest {

	private ClaimantContactPreferenceController controller;
	private ClaimantContactPreferenceService service;
	private ClaimantContactPreferenceConverter claimantContactPreferenceConverter;
	private ClaimantContactPreferenceDtoConverter claimantContactPreferenceDtoConverter;

	private static final int CLAIMANT_ID = 12345;

	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
		}
	};

	@Before
	public void setUp() {
		this.controller = new ClaimantContactPreferenceController();

		this.service = mockAndSetOn(this.context, ClaimantContactPreferenceService.class, this.controller);
		this.claimantContactPreferenceConverter = mockAndSetOn(this.context, ClaimantContactPreferenceConverter.class, this.controller);
		this.claimantContactPreferenceDtoConverter = mockAndSetOn(this.context, ClaimantContactPreferenceDtoConverter.class, this.controller);
	}


	@Test
	public void testGetById() throws Exception {
		final ClaimantContactPreference preference = createBlankContactPreference(CLAIMANT_ID);
		final ClaimantContactPreferenceDto expected = createBlankContactPreferenceDto(CLAIMANT_ID);

		this.context.checking(new Expectations() {
			{
				oneOf(service).getById(54321);
				will(returnValue(preference));
				oneOf(claimantContactPreferenceConverter).convert(preference);
				will(returnValue(expected));
			}
		});
		
		final ClaimantContactPreferenceDto actual = this.controller.getById(54321);

		assertThat(actual, is(expected));

	}

	@Test
	public void testGetByClaimantId() throws Exception {
		final ClaimantContactPreference preference = createBlankContactPreference(CLAIMANT_ID);
		final ClaimantContactPreferenceDto expected = createBlankContactPreferenceDto(CLAIMANT_ID);

		this.context.checking(new Expectations() {
			{
				oneOf(service).getByClaimantId(CLAIMANT_ID);
				will(returnValue(preference));
				oneOf(claimantContactPreferenceConverter).convert(preference);
				will(returnValue(expected));
			}
		});

		final ClaimantContactPreferenceDto actual = this.controller.getClaimantById(CLAIMANT_ID);
		assertThat(actual, is(expected));
	}

	@Test
	public void testSave() throws Exception {
		final ClaimantContactPreferenceDto preferenceDto = createBlankContactPreferenceDto(CLAIMANT_ID);
		final ClaimantContactPreference preference = createBlankContactPreference(CLAIMANT_ID);

		this.context.checking(new Expectations() {
			{
				oneOf(claimantContactPreferenceDtoConverter).convert(preferenceDto);
				will(returnValue(preference));
				oneOf(service).saveOrUpdate(preference);
			}
		});

		this.controller.save(preferenceDto);
	}
}
