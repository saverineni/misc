package com.leadx.claimant.lead;

import static com.google.common.collect.Lists.newArrayList;
import static com.leadx.claimant.claimantservice.ClaimantInteraction.newEvent;
import static com.leadx.claimant.lead.SaveClaimantProcessor.CAMPAIGN_USER_ID;
import static com.leadx.claimant.lead.SaveClaimantProcessor.generateAddress;
import static com.leadx.lib.utl.JodaUtils.newCurrentDateTime;
import static com.leadx.lib.utl.ObjectUtils.isNotNull;
import static com.leadx.test.MockUtils.mockAndSetOn;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.api.Action;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.joda.time.DateTimeUtils;
import org.joda.time.LocalDate;
import org.junit.Before;
import org.junit.Test;

import com.leadx.claimant.addressservice.Address;
import com.leadx.claimant.addressservice.AddressService;
import com.leadx.claimant.claimantservice.*;
import com.leadx.claimant.client.ClaimantLead;
import com.leadx.claimant.selleraccountservice.SellerAccount;
import com.leadx.claimant.selleraccountservice.SellerAccountService;
import com.leadx.claimant.user.User;
import com.leadx.claimant.user.UserService;
import com.leadx.lib.utl.JodaUtils;
import com.leadx.services.claims.client.ClaimRequest;
import com.leadx.services.claims.client.ClaimRequest.ClaimRequestBuilder;
import com.leadx.test.ReflectionUtils;


@SuppressWarnings("unqualified-field-access")
public class SaveClaimantProcessorUnitTest {

	private ClaimantService claimantService;
	private AddressService addressService;
	private AddressVerificationProcessor addressVerificationProcessor;
	private SellerAccountService sellerAccountService;
	private UserService userService;
	private ClaimantInteractionRepository claimantInteractionRepository;
	private AddressFailureService addressFailureService;

	private SaveClaimantProcessor saveClaimantProcessor;

	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
		}
	};

	@Before
	public void setUp() {
		this.saveClaimantProcessor = new SaveClaimantProcessor();
		ReflectionUtils.setField(this.saveClaimantProcessor,"sellerAccountsRequiringAddressVerification", newArrayList(1,2,3,4));

		this.claimantService = mockAndSetOn(this.context, ClaimantService.class, this.saveClaimantProcessor);
		this.addressService = mockAndSetOn(this.context, AddressService.class, this.saveClaimantProcessor);
		this.addressVerificationProcessor = mockAndSetOn(this.context, AddressVerificationProcessor.class, this.saveClaimantProcessor);
		this.sellerAccountService = mockAndSetOn(this.context, SellerAccountService.class, this.saveClaimantProcessor);
		this.userService = mockAndSetOn(this.context, UserService.class, this.saveClaimantProcessor);
		this.claimantInteractionRepository = mockAndSetOn(this.context, ClaimantInteractionRepository.class, this.saveClaimantProcessor);
		this.addressFailureService = mockAndSetOn(this.context, AddressFailureService.class, this.saveClaimantProcessor);
	}

	@Test
	public void testLongFieldsAreTruncated() {
		final ClaimRequestBuilder crb = new ClaimRequestBuilder();

		crb.address().departmentName("123456789012345678901234567890123456789012345678901234567890qwerty");
		crb.address().organisationName("123456789012345678901234567890123456789012345678901234567890qwerty");
		crb.address().subBuildingName("123456789012345678901234567890qwerty");
		crb.address().buildingName("12345678901234567890123456789012345678901234567890qwerty");
		crb.address().buildingNumber("12345678901234567890qwerty");
		crb.address().thoroughfare("12345678901234567890123456789012345678901234567890123456789012345678901234567890qwerty");
		crb.address().dependentLocality("12345678901234567890123456789012345qwerty");
		crb.address().town("123456789012345678901234567890qwerty");
		crb.address().postcode("1234567890qwert");

		crb.claimant().title("1234567890qwerty");
		crb.claimant().forename("1234567890123456789012345678901234567890qwerty");
		crb.claimant().surname("1234567890123456789012345678901234567890qwerty");
		crb.claimant().dob(new LocalDate("1990-07-15"));
		crb.claimant().homeTelephone("12345678901234567890qwerty");
		crb.claimant().mobileTelephone("12345678901234567890qwerty");
		crb.claimant().email("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890qwerty");

		crb.sellerAccountId(1);
		crb.sellerCompanyId(2);

		final ClaimRequest.Address previousAddress1 = new ClaimRequest.AddressBuilder().buildingName("some name").postcode("WA14 4DZ").build();
		final ClaimRequest.Address previousAddress2 = new ClaimRequest.AddressBuilder().buildingName("a name").postcode("M4 5DB").build();

		crb.previousAddresses(newArrayList(previousAddress1, previousAddress2));
		crb.agreements(newArrayList());

		final ClaimRequest claimRequest = crb.build();

		final Address address = new Address("123456789012345678901234567890123456789012345678901234567890",
			"123456789012345678901234567890123456789012345678901234567890",
			"123456789012345678901234567890",
			"12345678901234567890123456789012345678901234567890",
			"12345678901234567890",
			"",
			"12345678901234567890123456789012345678901234567890123456789012345678901234567890",
			"",
			"12345678901234567890123456789012345",
			"123456789012345678901234567890",
			"1234567890","");

		final Address convertedPrevAddress1 = new Address("",
				"",
				"",
				"some name",
				"",
				"",
				"",
				"",
				"",
				"",
				"WA14 4DZ","");

		final Address convertedPrevAddress2 = new Address("",
				"",
				"",
				"a name",
				"",
				"",
				"",
				"",
				"",
				"",
				"M4 5DB","");

		final Claimant claimant = new ClaimantBuilder().setId(0)
				.setLeadId(0)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("1234567890")
				.setForename("1234567890123456789012345678901234567890")
				.setMiddleName("")
				.setSurname("1234567890123456789012345678901234567890")
				.setPreviousSurname("")
				.setDob(new LocalDate("1990-07-15"))
				.setAddressId(3)
				.setHomeTelephone("12345678901234567890")
				.setMobileTelephone("12345678901234567890")
				.setAlternativeTelephone("12345678901234567890")
				.setWorkTelephone("")
				.setEmail("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890")
				.setFreePpi(true)
				.createClaimant();

		this.context.checking(new Expectations() {
			{
				oneOf(addressService).saveAddress(0, address, false);
				will(createNewAddress(address));
				oneOf(sellerAccountService).getByAccountId(1);
				with(any(SellerAccount.class));
				oneOf(claimantService).createClaimant(with(any(Claimant.class)));
				will(createNewClaimant(claimant));
				oneOf(addressService).savePreviousAddress(1, convertedPrevAddress1, false);
				oneOf(addressService).savePreviousAddress(1, convertedPrevAddress2, false);
			}
		});

		this.saveClaimantProcessor.saveClaimant(claimRequest);
	}

	@Test
	public void testTransformIntoValidLead() {
		final ClaimRequest claimRequest = createDummyClaimRequest(0);

		final Address address = new Address("a","b","c","d","e","","f","","g","h","i","");
		final Claimant claimant = new ClaimantBuilder().setId(0)
				.setLeadId(0)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("k")
				.setForename("l")
				.setMiddleName("")
				.setSurname("m")
				.setPreviousSurname("")
				.setDob(new LocalDate("1990-07-15"))
				.setAddressId(1)
				.setHomeTelephone("n")
				.setMobileTelephone("o")
				.setAlternativeTelephone("1234567890")
				.setWorkTelephone("")
				.setEmail("p")
				.setFreePpi(true)
				.createClaimant();

		this.context.checking(new Expectations() {
			{
				oneOf(addressService).saveAddress(0, address, false);
				will(createNewAddress(address));
				oneOf(sellerAccountService).getByAccountId(1);
				with(any(SellerAccount.class));
				oneOf(claimantService).createClaimant(with(any(Claimant.class)));
				will(createNewClaimant(claimant));
			}
		});

		final ClaimantLead claimantLead = this.saveClaimantProcessor.saveClaimant(claimRequest);

		assertTrue(isNotNull(claimantLead.getClaimRequest().getAddress()));
		assertThat(claimantLead.getClaimRequest().getAddress().getDepartmentName(), is("a"));
		assertThat(claimantLead.getClaimRequest().getAddress().getOrganisationName(), is("b"));
		assertThat(claimantLead.getClaimRequest().getAddress().getSubBuildingName(), is("c"));
		assertThat(claimantLead.getClaimRequest().getAddress().getBuildingName(), is("d"));
		assertThat(claimantLead.getClaimRequest().getAddress().getBuildingNumber(), is("e"));
		assertThat(claimantLead.getClaimRequest().getAddress().getThoroughfare(), is("f"));
		assertThat(claimantLead.getClaimRequest().getAddress().getDependentLocality(), is("g"));
		assertThat(claimantLead.getClaimRequest().getAddress().getTown(), is("h"));
		assertThat(claimantLead.getClaimRequest().getAddress().getPostcode(), is("i"));

		assertTrue(isNotNull(claimantLead.getClaimantId()));
		assertThat(claimantLead.getClaimantId(), is(1));
		assertThat(claimantLead.getClaimRequest().getClaimant().getTitle(), is("k"));
		assertThat(claimantLead.getClaimRequest().getClaimant().getForename(), is("l"));
		assertThat(claimantLead.getClaimRequest().getClaimant().getSurname(), is("m"));
		assertThat(claimantLead.getClaimRequest().getClaimant().getDob(), is(new LocalDate("1990-07-15")));
		assertThat(claimantLead.getClaimRequest().getClaimant().getHomeTelephone(), is("n"));
		assertThat(claimantLead.getClaimRequest().getClaimant().getMobileTelephone(), is("o"));
		assertThat(claimantLead.getClaimRequest().getClaimant().getEmail(), is("p"));

		assertThat(claimantLead.getClaimRequest().getSellerAccountId(), is(1));
		assertThat(claimantLead.getClaimRequest().getSellerCompanyId(), is(2));
	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldExceptionWhenClaimRequestHasNullClaimant() {
		final ClaimRequest claimRequest = createDummyClaimRequest(123);
		ReflectionUtils.setField(claimRequest, "claimant", null);
		
		this.saveClaimantProcessor.updateClaimant(claimRequest);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void shouldExceptionWhenClaimRequestAClaimantWithAZeroId() {
		final ClaimRequest claimRequest = createDummyClaimRequest(0);
		
		this.saveClaimantProcessor.updateClaimant(claimRequest);
	}
	
	@Test(expected = RuntimeException.class)
	public void shouldExceptionWhenExistingClaimantCannotBeFound() {
		final ClaimRequest claimRequest = createDummyClaimRequest(123);
		
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(123);
				will(returnValue(null));
			}
		});
		
		this.saveClaimantProcessor.updateClaimant(claimRequest);
	}
	
	@Test
	public void shouldUpdateClaimantAndUpdateAddress() {
		final int claimantId = 12345;
		final ClaimRequest claimRequest = createDummyClaimRequest(claimantId);
		final User campaignUser = new User();
		campaignUser.setId(CAMPAIGN_USER_ID);
		
		final Claimant claimant = new ClaimantBuilder().setId(claimantId)
				.setLeadId(0)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("1234567890")
				.setForename("1234567890123456789012345678901234567890")
				.setMiddleName("")
				.setSurname("1234567890123456789012345678901234567890")
				.setPreviousSurname("")
				.setDob(new LocalDate("1990-07-15"))
				.setAddressId(3)
				.setHomeTelephone("12345678901234567890")
				.setMobileTelephone("12345678901234567890")
				.setAlternativeTelephone("12345678901234567890")
				.setWorkTelephone("")
				.setEmail("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890")
				.setFreePpi(true)
				.createClaimant();

		final Address existingAddress = new Address();
		existingAddress.setId(3);
		existingAddress.setBuildingNumber("123");
		existingAddress.setThoroughfare("Some lane");
		existingAddress.setPostcode("1A 1AA");

		final Address newAddress = generateAddress(claimRequest.getAddress());

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(claimantId);
				will(returnValue(claimant));
				oneOf(sellerAccountService).getByAccountId(1);
				with(any(SellerAccount.class));
				oneOf(sellerAccountService).getByAccountId(claimRequest.getSellerAccountId());
				with(any(SellerAccount.class));
				oneOf(userService).getById(CAMPAIGN_USER_ID);
				will(returnValue(campaignUser));
				oneOf(addressVerificationProcessor).verifyAndReturnAddress(claimantId, false, newAddress);
				will(returnValue(AddressVerificationResult.success(newAddress)));
				oneOf(addressService).getAddressById(3);
				will(returnValue(existingAddress));
				oneOf(addressService).saveHouseMove(claimantId, newAddress);
				oneOf(claimantInteractionRepository).save(newEvent(claimantId, null, campaignUser, "Claimant Address updated from LP Campaign", Source.CLAIMANT));
				oneOf(claimantService).updateMergedClaimant(claimant, CAMPAIGN_USER_ID);
			}
		});
		
		this.saveClaimantProcessor.updateClaimant(claimRequest);
	}

	@Test
	public void shouldNotUpdateExistingAddress() {
		final int claimantId = 12345;
		final ClaimRequest claimRequest = createDummyClaimRequest(claimantId);
		final User campaignUser = new User();
		campaignUser.setId(CAMPAIGN_USER_ID);

		final Claimant claimant = new ClaimantBuilder().setId(claimantId)
				.setLeadId(0)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("1234567890")
				.setForename("1234567890123456789012345678901234567890")
				.setMiddleName("")
				.setSurname("1234567890123456789012345678901234567890")
				.setPreviousSurname("")
				.setDob(new LocalDate("1990-07-15"))
				.setAddressId(3)
				.setHomeTelephone("12345678901234567890")
				.setMobileTelephone("12345678901234567890")
				.setAlternativeTelephone("12345678901234567890")
				.setWorkTelephone("")
				.setEmail("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890")
				.setFreePpi(true)
				.createClaimant();

		final Address addressFromLead = createDummyAddress();

		final Address existingAddress = new Address();
		existingAddress.setId(3);
		existingAddress.setSubBuildingName("c");
		existingAddress.setBuildingName("d");
		existingAddress.setBuildingNumber("e");
		existingAddress.setThoroughfare("f");
		existingAddress.setPostcode("i");

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(claimantId);
				will(returnValue(claimant));
				oneOf(sellerAccountService).getByAccountId(1);
				with(any(SellerAccount.class));
				oneOf(sellerAccountService).getByAccountId(claimRequest.getSellerAccountId());
				with(any(SellerAccount.class));
				oneOf(userService).getById(CAMPAIGN_USER_ID);
				will(returnValue(campaignUser));
				oneOf(addressVerificationProcessor).verifyAndReturnAddress(claimantId, false, addressFromLead);
				will(returnValue(AddressVerificationResult.success(addressFromLead)));
				oneOf(addressService).getAddressById(3);
				will(returnValue(existingAddress));
				oneOf(claimantInteractionRepository).save(newEvent(claimantId, null, campaignUser, "Claimant confirmed No Change to the current Address", Source.CLAIMANT));
				oneOf(claimantService).updateMergedClaimant(claimant, CAMPAIGN_USER_ID);
			}
		});

		this.saveClaimantProcessor.updateClaimant(claimRequest);
	}

	@Test
	public void shouldUpdateHomeTelephoneNumber() {
		final int claimantId = 12345;
		final ClaimRequest claimRequest = createDummyClaimRequest(claimantId);
		final User campaignUser = new User();
		campaignUser.setId(CAMPAIGN_USER_ID);

		final Claimant claimant = new ClaimantBuilder().setId(claimantId)
				.setLeadId(0)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("1234567890")
				.setForename("1234567890123456789012345678901234567890")
				.setMiddleName("")
				.setSurname("1234567890123456789012345678901234567890")
				.setPreviousSurname("")
				.setDob(new LocalDate("1990-07-15"))
				.setAddressId(3)
				.setHomeTelephone("12345678901234567890")
				.setMobileTelephone("07777777777")
				.setAlternativeTelephone("12345678901234567890")
				.setWorkTelephone("")
				.setEmail("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890")
				.setFreePpi(true)
				.createClaimant();

		final Address existingAddress = new Address();
		existingAddress.setId(3);
		existingAddress.setSubBuildingName("c");
		existingAddress.setBuildingName("d");
		existingAddress.setBuildingNumber("e");
		existingAddress.setThoroughfare("f");
		existingAddress.setPostcode("i");

		final Address addressFromLead = createDummyAddress();

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(claimantId);
				will(returnValue(claimant));
				oneOf(sellerAccountService).getByAccountId(1);
				with(any(SellerAccount.class));
				oneOf(sellerAccountService).getByAccountId(claimRequest.getSellerAccountId());
				with(any(SellerAccount.class));
				oneOf(userService).getById(CAMPAIGN_USER_ID);
				will(returnValue(campaignUser));
				oneOf(addressVerificationProcessor).verifyAndReturnAddress(claimantId, false, addressFromLead);
				will(returnValue(AddressVerificationResult.success(addressFromLead)));
				oneOf(addressService).getAddressById(3);
				will(returnValue(existingAddress));
				oneOf(claimantInteractionRepository).save(newEvent(claimantId, null, campaignUser, "Claimant confirmed No Change to the current Address", Source.CLAIMANT));
				oneOf(claimantInteractionRepository).save(newEvent(claimantId, null, campaignUser, "Claimant updated their Telephone Number From: o To: 12345678901234567890", Source.CLAIMANT));
				oneOf(claimantService).updateMergedClaimant(claimant, CAMPAIGN_USER_ID);
			}
		});

		this.saveClaimantProcessor.updateClaimant(claimRequest);
	}

	@Test
	public void shouldUpdateMobileTelephoneNumber() {
		final int claimantId = 12345;
		final ClaimRequest claimRequest = createDummyClaimRequest(claimantId);
		final User campaignUser = new User();
		campaignUser.setId(CAMPAIGN_USER_ID);

		final Claimant claimant = new ClaimantBuilder().setId(claimantId)
				.setLeadId(0)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("1234567890")
				.setForename("1234567890123456789012345678901234567890")
				.setMiddleName("")
				.setSurname("1234567890123456789012345678901234567890")
				.setPreviousSurname("")
				.setDob(new LocalDate("1990-07-15"))
				.setAddressId(3)
				.setHomeTelephone("n")
				.setMobileTelephone("01111111111")
				.setAlternativeTelephone("12345678901234567890")
				.setWorkTelephone("")
				.setEmail("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890")
				.setFreePpi(true)
				.createClaimant();

		final Address existingAddress = new Address();
		existingAddress.setId(3);
		existingAddress.setSubBuildingName("c");
		existingAddress.setBuildingName("d");
		existingAddress.setBuildingNumber("e");
		existingAddress.setThoroughfare("f");
		existingAddress.setPostcode("i");

		final Address addressFromLead = createDummyAddress();

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(claimantId);
				will(returnValue(claimant));
				oneOf(sellerAccountService).getByAccountId(1);
				with(any(SellerAccount.class));
				oneOf(sellerAccountService).getByAccountId(claimRequest.getSellerAccountId());
				with(any(SellerAccount.class));
				oneOf(userService).getById(CAMPAIGN_USER_ID);
				will(returnValue(campaignUser));
				oneOf(addressVerificationProcessor).verifyAndReturnAddress(claimantId, false, addressFromLead);
				will(returnValue(AddressVerificationResult.success(addressFromLead)));
				oneOf(addressService).getAddressById(3);
				will(returnValue(existingAddress));
				oneOf(claimantInteractionRepository).save(newEvent(claimantId, null, campaignUser, "Claimant confirmed No Change to the current Address", Source.CLAIMANT));
				oneOf(claimantInteractionRepository).save(newEvent(claimantId, null, campaignUser, "Claimant updated their Telephone Number From: o To: 12345678901234567890", Source.CLAIMANT));
				oneOf(claimantService).updateMergedClaimant(claimant, CAMPAIGN_USER_ID);
			}
		});

		this.saveClaimantProcessor.updateClaimant(claimRequest);
	}

	@Test
	public void shouldUpdateClaimantAndCreateNewAddress() {
		final int claimantId = 12345;
		DateTimeUtils.setCurrentMillisFixed(JodaUtils.currentMillis());
		final ClaimRequest claimRequest = createDummyClaimRequest(claimantId);
		final User campaignUser = new User();
		campaignUser.setId(CAMPAIGN_USER_ID);

		final Claimant claimant = new ClaimantBuilder().setId(claimantId)
				.setLeadId(0)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("1234567890")
				.setForename("1234567890123456789012345678901234567890")
				.setMiddleName("")
				.setSurname("1234567890123456789012345678901234567890")
				.setPreviousSurname("")
				.setDob(new LocalDate("1990-07-15"))
				.setAddressId(0)
				.setHomeTelephone("12345678901234567890")
				.setMobileTelephone("12345678901234567890")
				.setAlternativeTelephone("12345678901234567890")
				.setWorkTelephone("")
				.setEmail("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890")
				.setFreePpi(true)
				.createClaimant();

		final Address address = createDummyAddress();

		final AddressFailure addressFailure = new AddressFailure(12345, 0, AddressFailureStatus.action_required, newCurrentDateTime());

		this.context.checking(new Expectations() {
			{
				exactly(2).of(claimantService).getClaimantById(claimantId);
				will(returnValue(claimant));
				oneOf(sellerAccountService).getByAccountId(1);
				with(any(SellerAccount.class));
				oneOf(sellerAccountService).getByAccountId(claimRequest.getSellerAccountId());
				with(any(SellerAccount.class));
				oneOf(userService).getById(CAMPAIGN_USER_ID);
				will(returnValue(campaignUser));
				oneOf(addressVerificationProcessor).verifyAndReturnAddress(claimantId, false, address);
				will(returnValue(AddressVerificationResult.failure(address)));
				oneOf(addressService).saveAddress(claimantId, address, false);
				oneOf(claimantInteractionRepository).save(newEvent(claimantId, null, campaignUser, "Claimant Address updated from LP Campaign", Source.CLAIMANT));
				oneOf(claimantService).updateMergedClaimant(claimant, CAMPAIGN_USER_ID);
				oneOf(addressFailureService).save(addressFailure);
			}
		});
		
		this.saveClaimantProcessor.updateClaimant(claimRequest);
	}
	
	public <T> Action createNewAddress(final Address address) {
		return new CreateAddressAction(address);
	}

	public <T> Action createNewClaimant(final Claimant claimant) {
		return new CreateClaimantAction(claimant);
	}
	
	private static Address createDummyAddress() {
		return new Address("a", "b", "c", "d", "e", "", "f", "", "g", "h", "i", "");
	}
	
	private static ClaimRequest createDummyClaimRequest(final int claimantId) {
		final ClaimRequestBuilder crb = new ClaimRequestBuilder();

		crb.address().departmentName("a");
		crb.address().organisationName("b");
		crb.address().subBuildingName("c");
		crb.address().buildingName("d");
		crb.address().buildingNumber("e");
		crb.address().thoroughfare("f");
		crb.address().dependentLocality("g");
		crb.address().town("h");
		crb.address().postcode("i");

		crb.claimant().id(claimantId);
		crb.claimant().title("k");
		crb.claimant().forename("l");
		crb.claimant().surname("m");
		crb.claimant().dob(new LocalDate("1990-07-15"));
		crb.claimant().homeTelephone("n");
		crb.claimant().mobileTelephone("o");
		crb.claimant().email("p");

		crb.sellerAccountId(1);
		crb.sellerCompanyId(2);

		crb.previousAddresses(newArrayList());
		crb.agreements(newArrayList());

		return crb.build();
	}
}
