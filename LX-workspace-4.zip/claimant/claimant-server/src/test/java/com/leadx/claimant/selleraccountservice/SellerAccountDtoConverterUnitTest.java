package com.leadx.claimant.selleraccountservice;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.google.common.collect.ImmutableList;
import com.leadx.claimant.client.LeadTypeDto;
import com.leadx.claimant.client.MethodOfContact;
import com.leadx.claimant.client.ProductTypeDto;
import com.leadx.claimant.client.SellerAccountDto;

public class SellerAccountDtoConverterUnitTest {

	@Test
	public void testConvert() {
		final SellerAccountDtoConverter sellerAccountDtoConverter = new SellerAccountDtoConverter();
		final ProductTypeDto selected = new ProductTypeDto(0, "ppi", true);
		final LeadTypeDto leadTypeDto = new LeadTypeDto(1, "FPPIC Web Lead");
		final SellerAccountDto sellerAccountDto = new SellerAccountDto(0, 1234,"GP_SELLER_ACC","Seller Name", "Display Name", "", MethodOfContact.telephone, "LOGO.swf","tcg_pack",false,"call_reason_group","smsScript","emailScript","email_icon.png", ImmutableList.of("1234"), selected, false, leadTypeDto);

		final SellerAccount sellerAccount = sellerAccountDtoConverter.convert(sellerAccountDto);

		assertThat(sellerAccount, is(notNullValue()));

		assertThat(sellerAccount.getAccountId(), is(1234));
		assertThat(sellerAccount.getGpSellerAccount(), is("GP_SELLER_ACC"));
		assertThat(sellerAccount.getName(), is("Seller Name"));
		assertThat(sellerAccount.getDisplayName(), is("Display Name"));
		assertThat(sellerAccount.getSourceDescription(), is(""));
		assertThat(sellerAccount.getApplicationLogo(), is("LOGO.swf"));
		assertThat(sellerAccount.getPackType(), is("tcg_pack"));
		assertThat(sellerAccount.getDistributeAppointmentReminder(), is(false));
		assertThat(sellerAccount.getAssessmentCallReasonGroup(), is("call_reason_group"));
		assertThat(sellerAccount.getAssessmentInitialSmsMessageScript(), is("smsScript"));
		assertThat(sellerAccount.getAssessmentInitialEmailMessageScript(), is("emailScript"));
		assertThat(sellerAccount.getEmailIconImageName(), is("email_icon.png"));
		assertThat(sellerAccount.getFreePpi(), is(false));
	}

	@Test
	public void testConvertNull() {
		final SellerAccountDtoConverter sellerAccountDtoConverter = new SellerAccountDtoConverter();
		final SellerAccount sellerAccount = sellerAccountDtoConverter.convert(null);

		assertThat(sellerAccount, is(nullValue()));
	}
}
