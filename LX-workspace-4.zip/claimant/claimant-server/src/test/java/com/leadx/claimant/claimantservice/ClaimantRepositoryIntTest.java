package com.leadx.claimant.claimantservice;

import static com.google.common.collect.Sets.newHashSet;
import static com.leadx.claimant.client.VulnerabilityCategory.*;
import static com.leadx.claimant.util.ClaimantTestUtils.*;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.util.List;

import com.leadx.claimant.reference.VulnerableDetailTriState;
import org.joda.time.DateTime;
import org.joda.time.DateTimeUtils;
import org.joda.time.LocalDate;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.google.common.collect.ImmutableList;
import com.leadx.claimant.util.ClaimantTestUtils;
import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.NoTestData;
import com.leadx.test.integration.RequiresTestData;

@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class ClaimantRepositoryIntTest extends AbstractIntegrationTest {

	@Autowired
	private ClaimantRepository repository;

	@Before
	public void setUp(){
		DateTimeUtils.setCurrentMillisFixed(new DateTime(2016, 3, 15, 15, 0, 0).getMillis());
	}

	@Test
	@NoTestData
	public void testCreateClaimantWithExecutor() {
		final Claimant claimant = new ClaimantBuilder().setId(0)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("matt")
				.setMiddleName("middle")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(0)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("")
				.setVulnerableCustomerReviewDate(new LocalDate(2016, 11, 18))
				.setFreePpi(true)
				.setOtherNames(buildOtherNames("Name1", "Name2"))
				.setAdditionalPreviousNames(buildAdditionalPreviousNames("Name3", "Name4", "Name5"))
				.setClaimantUnpresentedCheque(buildClaimantUnpresentedCheque())
				.setClaimantExecutor(buildClaimantExecutor(0))
				.setHasVulnerability(false)
				.setVulnerabilityCategories(newHashSet(V1, V3))
				.setCanStoreVulnerabilityDetail(VulnerableDetailTriState.YES)
				.setVulnerabilityDetail("some detail")
				.createClaimant();
		this.repository.createClaimant(claimant);
		assertThat(claimant.getId(), is(greaterThan(0)));

		// Get the new claim back from the db and check it is as expected
		final Claimant newClaimant = this.repository.getClaimantById(claimant.getId());
		assertThat(newClaimant.equals(claimant), is(true));
	}

	@Test
	@NoTestData
	public void testCreateClaimantWithoutExecutor() {
		final Claimant claimant = new ClaimantBuilder().setId(0)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("matt")
				.setMiddleName("middle")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(0)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setVulnerableCustomerReviewDate(new LocalDate(2016, 11, 18))
				.setFreePpi(true)
				.setOtherNames(ClaimantTestUtils.buildOtherNames("Name1", "Name2"))
				.setAdditionalPreviousNames(ClaimantTestUtils.buildAdditionalPreviousNames("Name3", "Name4", "Name5"))
				.setHasVulnerability(true)
				.setVulnerabilityCategories(newHashSet(V2))
				.setCanStoreVulnerabilityDetail(VulnerableDetailTriState.NO)
				.setVulnerabilityDetail("")
				.createClaimant();

		this.repository.createClaimant(claimant);
		assertThat(claimant.getId(), is(greaterThan(0)));

		// Get the new claim back from the db and check it is as expected
		final Claimant newClaimant = this.repository.getClaimantById(claimant.getId());
		assertThat(newClaimant.equals(claimant), is(true));
	}

	@Test
	@NoTestData
	public void testUpdateClaimant() {
		final Claimant claimant = new ClaimantBuilder().setId(0)
				.setLeadId(234)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("matt")
				.setMiddleName("middle")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(0)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setVulnerableCustomerReviewDate(new LocalDate(2016, 11, 15))
				.setFreePpi(true)
				.setOtherNames(buildOtherNames("Name1", "Name2"))
				.setAdditionalPreviousNames(buildAdditionalPreviousNames("Name3", "Name4", "Name5"))
				.setClaimantUnpresentedCheque(buildClaimantUnpresentedCheque())
				.setClaimantExecutor(buildClaimantExecutor(0))
				.setHasVulnerability(false)
				.setVulnerabilityCategories(newHashSet(V6))
				.setCanStoreVulnerabilityDetail(VulnerableDetailTriState.NO)
				.setVulnerabilityDetail("test123")
				.createClaimant();
		this.repository.createClaimant(claimant);
		this.repository.evict(claimant);

		final Claimant updatedClaimant = new ClaimantBuilder().setId(0)
				.setLeadId(345)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("matt")
				.setMiddleName("middle")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(0)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me2@me.com")
				.setNationalInsuranceNumber("")
				.setVulnerableCustomerReviewDate(new LocalDate(2016, 11, 20))
				.setFreePpi(true)
				.setOtherNames(buildOtherNames("Name1", "Name2"))
				.setAdditionalPreviousNames(buildAdditionalPreviousNames("Name3", "Name4", "Name5"))
				.setClaimantUnpresentedCheque(buildClaimantUnpresentedCheque())
				.setClaimantExecutor(buildClaimantExecutor(0))
				.setHasVulnerability(false)
				.setVulnerabilityCategories(newHashSet(V6))
				.setCanStoreVulnerabilityDetail(VulnerableDetailTriState.NO)
				.setVulnerabilityDetail("test123")
				.createClaimant();
		updatedClaimant.setId(claimant.getId());

		this.repository.updateClaimant(updatedClaimant);

		final Claimant claimantInDb = this.repository.getClaimantById(claimant.getId());

		assertThat(claimantInDb, is(updatedClaimant));
	}

	@Test
	@NoTestData
	public void testSearchForClaimantsBySurnameNoMatches() {
		final List<Claimant> claimants = this.repository.searchForClaimantBySurname("not a match");
		assertThat(claimants.size(), is(0));
	}

	@Test
	public void testSearchForClaimantsBySurname() {
		final List<Claimant> claimants = this.repository.searchForClaimantBySurname("Helliwell");
		assertThat(claimants.size(), is(2));
	}

	@Test
	public void testSearchForClaimantsByPostcode() {
		final List<Claimant> claimants = this.repository.searchForClaimantByPostcode("ST7%");
		assertThat(claimants.size(), is(2));
	}

	@Test
	public void testSearchForClaimantsByTelephoneNumber() {
		final List<Claimant> claimants1 = this.repository.searchForClaimantByTelephoneNumber("0203189251%");
		assertThat(claimants1.size(), is(3));

		final List<Claimant> claimants2 = this.repository.searchForClaimantByTelephoneNumber("07796136602%");
		assertThat(claimants2.size(), is(2));
	}

	@Test
	@RequiresTestData(locations = "testGetClaimantsByIds")
	public void testGetClaimantsByIds() {
		final List<Claimant> claimants = this.repository.getClaimantsByIds(ImmutableList.of(1, 99, 3));
		assertThat(claimants.size(), is(2));
	}


	@Test
	@RequiresTestData(locations = "testGetClaimantsByIds")
	public void testGetClaimantsByIdsNoMatches() {
		final List<Claimant> claimants = this.repository.getClaimantsByIds(ImmutableList.of(99));
		assertThat(claimants.size(), is(0));
	}

	@Test
	@RequiresTestData(locations = "getRecentlyUnlockedClaimants")
	public void getRecentlyUnlockedClaimants() {
		final List<Integer> claimantIds = this.repository.getRecentlyUnlockedClaimants(1);
		assertThat(claimantIds.size(), is(1));
		assertThat(claimantIds.get(0), is(2));
	}
}
