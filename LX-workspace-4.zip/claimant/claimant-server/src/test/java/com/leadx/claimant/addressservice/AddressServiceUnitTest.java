package com.leadx.claimant.addressservice;

import static com.leadx.test.MockUtils.mockAndSetOn;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

import java.util.List;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.concurrent.Synchroniser;
import org.jmock.lib.legacy.ClassImposteriser;
import org.joda.time.LocalDate;
import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.leadx.claimant.changelogservice.ChangeLogService;
import com.leadx.claimant.claimantservice.Claimant;
import com.leadx.claimant.claimantservice.ClaimantBuilder;
import com.leadx.claimant.claimantservice.ClaimantConverter;
import com.leadx.claimant.claimantservice.ClaimantService;
import com.leadx.claimant.client.ClaimantDto;
import com.leadx.claimant.logiclaimservice.LogiClaimService;
import com.leadx.claimant.reference.TriState;
import com.leadx.lib.utl.JodaUtils;

@SuppressWarnings({"unqualified-field-access"})
public class AddressServiceUnitTest {
	
	private AddressService addressService;
	
	private AddressRepository addressRepository;
	
	private ChangeLogService changeLogService;
	
	private ClaimantService claimantService;

	private LogiClaimService logiClaimService;

	private ClaimantConverter claimantConverter;
	
	private static final int ADDRESS_ID = 1234;
	private static final int CLAIMANT_ID = 5678;
	private static final int USER_ID = 1357;
	
	private final Synchroniser synchroniser = new Synchroniser();
	
	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
			setThreadingPolicy(synchroniser);
		}
	};
	
	@Before
	public void setUp() {
		this.addressService = new AddressService();
		
		this.addressRepository = mockAndSetOn(this.context, AddressRepository.class, this.addressService);
		this.changeLogService = mockAndSetOn(this.context, ChangeLogService.class, this.addressService);
		this.claimantService = mockAndSetOn(this.context, ClaimantService.class, this.addressService);
		this.logiClaimService = mockAndSetOn(this.context, LogiClaimService.class, this.addressService);
		this.claimantConverter = mockAndSetOn(this.context, ClaimantConverter.class, this.addressService);
	}

	@Test
	public void testGetAddressById() {

		this.context.checking(new Expectations() {
			{
				oneOf(addressRepository).getAddressById(ADDRESS_ID);
				will(returnValue(newDummyAddress("WA14 4DZ")));
			}
		});

		this.addressService.getAddressById(ADDRESS_ID);
	}

	@Test
	public void testGetAddressesByIds() {

		this.context.checking(new Expectations() {
			{
				oneOf(addressRepository).getAddressesByIds(ImmutableList.of(ADDRESS_ID));
				will(returnValue(ImmutableList.of(newDummyAddress("WA14 4DZ"))));
			}
		});

		this.addressService.getAddressesByIds(ImmutableList.of(ADDRESS_ID));
	}
	@Test
	public void testGetAddressForClaimant() {
		
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(newDummyClaimant()));
				oneOf(addressRepository).getAddressById(ADDRESS_ID);
			}
		});
		
		this.addressService.getAddressForClaimant(CLAIMANT_ID);
	}
	
	@Test
	public void testGetAddressForClaimantCanReturnNull() {
		final Claimant claimant = null;
		
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(99999);
				will(returnValue(claimant));
			}
		});
		
		final Address address = this.addressService.getAddressForClaimant(99999);
		
		assertThat(address, is(nullValue()));
	}
	
	@Test
	public void testGetAllAddressesForClaimant() {
		final PreviousAddress previousAddress1 = newDummyPreviousAddress(newDummyAddress("WA14 4DZ"), true);
		final PreviousAddress previousAddress2 = newDummyPreviousAddress(newDummyAddress("M20 4TZ"), false);
		final List<PreviousAddress> previousAddresses = Lists.newArrayList(previousAddress1, previousAddress2);
		
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(newDummyClaimant()));
				oneOf(addressRepository).getPreviousAddressesForClaimant(CLAIMANT_ID);
				will(returnValue(previousAddresses));
				oneOf(addressRepository).getAddressById(ADDRESS_ID);
			}
		});
		
		this.addressService.getAllAddressesForClaimant(CLAIMANT_ID);
	}
	
	@Test
	public void testGetDeletedPreviousAddresses() {
		this.context.checking(new Expectations() {
			{
				oneOf(addressRepository).getDeletedPreviousAddressesForClaimant(CLAIMANT_ID);
				will(returnValue(Lists.newArrayList()));
			}
		});
		
		this.addressService.getDeletedPreviousAddresses(CLAIMANT_ID);
	}
	
	@Test
	public void testGetOrderedPreviousAddressesForClaimant() {
		this.context.checking(new Expectations() {
			{
				oneOf(addressRepository).getOrderedPreviousAddressesForClaimant(CLAIMANT_ID);
				will(returnValue(Lists.newArrayList()));
			}
		});
		
		this.addressService.getOrderedPreviousAddressesForClaimant(CLAIMANT_ID);
	}
	
	@Test
	public void testGetPreviousAddresses() {
		this.context.checking(new Expectations() {
			{
				oneOf(addressRepository).getPreviousAddressesForClaimant(CLAIMANT_ID);
				will(returnValue(Lists.newArrayList()));
			}
		});
		
		this.addressService.getPreviousAddresses(CLAIMANT_ID);
	}
	
	@Test
	public void testSaveHouseMove() {
		final Address oldAddress = newDummyAddress("WA14 4DX");
		oldAddress.setId(123);
		final Address oldAddressFromDb = newDummyAddress("WA14 4DX");
		oldAddressFromDb.setVersion(1);
		final Address newAddress = newDummyAddress("WA14 4DZ");
		
		final PreviousAddress previousAddress = new PreviousAddress(CLAIMANT_ID, oldAddressFromDb, true);

		final Claimant claimant = newDummyClaimant();
		final ClaimantDto claimantDto = new ClaimantDto();

		
		this.context.checking(new Expectations() {
			{
				oneOf(addressRepository).getAddressById(123);
				will(returnValue(oldAddressFromDb));
				oneOf(addressRepository).savePreviousAddress(previousAddress);
				oneOf(addressRepository).saveAddress(newAddress, true);
				oneOf(claimantService).updateAddressId(CLAIMANT_ID, newAddress);

				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(claimantConverter).convert(claimant);
				will(returnValue(claimantDto));
				oneOf(logiClaimService).sendToLogiclaim(claimantDto);
			}
		});
		
		this.addressService.saveHouseMove(CLAIMANT_ID, oldAddress, newAddress);
	}
	
	@Test
	public void testSavePreviousAddress() {
		final Address newAddress = newDummyAddress("M33 4HH");
		final PreviousAddress previousAddress = new PreviousAddress(CLAIMANT_ID, newAddress, false);

		final Claimant claimant = newDummyClaimant();
		final ClaimantDto claimantDto = new ClaimantDto();
		
		this.context.checking(new Expectations() {
			{
				oneOf(addressRepository).saveAddress(newAddress, true);
				oneOf(claimantService).updateAddressId(CLAIMANT_ID, newAddress);
				oneOf(addressRepository).savePreviousAddress(previousAddress);

				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(claimantConverter).convert(claimant);
				will(returnValue(claimantDto));
				oneOf(logiClaimService).sendToLogiclaim(claimantDto);
			}
		});
		
		this.addressService.savePreviousAddress(CLAIMANT_ID, newAddress);
	}

	@Test
	public void testSavePreviousAddressInConfinement() {
		final Address newAddress = newDummyAddress("M33 4HH");
		final PreviousAddress previousAddress = new PreviousAddress(CLAIMANT_ID, newAddress, false);

		final Claimant claimant = newDummyClaimant();
		final ClaimantDto claimantDto = new ClaimantDto();

		this.context.checking(new Expectations() {
			{
				oneOf(addressRepository).saveAddress(newAddress, true);
				oneOf(claimantService).updateAddressId(CLAIMANT_ID, newAddress);
				oneOf(addressRepository).savePreviousAddress(previousAddress);

				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(claimantConverter).convert(claimant);
				will(returnValue(claimantDto));
				never(logiClaimService).sendToLogiclaim(claimantDto);
			}
		});

		this.addressService.savePreviousAddressInConfinement(CLAIMANT_ID, newAddress);
	}
	
	@Test
	public void testDeletePreviousAddress() {
		final PreviousAddress previousAddress = new PreviousAddress(CLAIMANT_ID, newDummyAddress("WA14 4DZ"), true);

		final Claimant claimant = newDummyClaimant();
		final ClaimantDto claimantDto = new ClaimantDto();

		this.context.checking(new Expectations() {
			{
				oneOf(addressRepository).getPreviousAddress(ADDRESS_ID);
				will(returnValue(previousAddress));

				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(claimantConverter).convert(claimant);
				will(returnValue(claimantDto));
				oneOf(logiClaimService).sendToLogiclaim(claimantDto);
			}
		});

		previousAddress.setDeletedDateTime(JodaUtils.newCurrentDateTime());
		previousAddress.setFkUserIdDeletedBy(USER_ID);

		this.context.checking(new Expectations() {
			{
				oneOf(addressRepository).updatePreviousAddress(previousAddress);
			}
		});

		this.addressService.deletePreviousAddress(ADDRESS_ID, USER_ID);
	}

	@Test
	public void testDeletePreviousAddressInConfinement() {
		final PreviousAddress previousAddress = new PreviousAddress(CLAIMANT_ID, newDummyAddress("WA14 4DZ"), true);

		final Claimant claimant = newDummyClaimant();
		final ClaimantDto claimantDto = new ClaimantDto();

		this.context.checking(new Expectations() {
			{
				oneOf(addressRepository).getPreviousAddress(ADDRESS_ID);
				will(returnValue(previousAddress));

				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(claimantConverter).convert(claimant);
				will(returnValue(claimantDto));
				never(logiClaimService).sendToLogiclaim(claimantDto);
			}
		});

		previousAddress.setDeletedDateTime(JodaUtils.newCurrentDateTime());
		previousAddress.setFkUserIdDeletedBy(USER_ID);

		this.context.checking(new Expectations() {
			{
				oneOf(addressRepository).updatePreviousAddress(previousAddress);
			}
		});

		this.addressService.deletePreviousAddressInConfinement(ADDRESS_ID, USER_ID);
	}

	@Test
	public void testSaveAddress() {
		final Address address = newDummyAddress("WA14 4DZ");
		final Claimant claimant = newDummyClaimant();
		final ClaimantDto claimantDto = new ClaimantDto();

		this.context.checking(new Expectations() {
			{
				oneOf(addressRepository).saveAddress(address, true);
				oneOf(claimantService).updateAddressId(CLAIMANT_ID, address);
				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(claimantConverter).convert(claimant);
				will(returnValue(claimantDto));
				oneOf(logiClaimService).sendToLogiclaim(claimantDto);
			}
		});
		
		this.addressService.saveAddress(CLAIMANT_ID, address, true);
	}
	
	@Test
	public void testSaveAddressNoClaimantId() {
		final Address address = newDummyAddress("WA14 4DY");
		
		this.context.checking(new Expectations() {
			{
				oneOf(addressRepository).saveAddress(address, true);
			}
		});
		
		this.addressService.saveAddress(0, address, true);
	}

	@Test
	public void testSaveAddressInConfinement() {
		final Address address = newDummyAddress("WA14 4DZ");
		final Claimant claimant = newDummyClaimant();
		final ClaimantDto claimantDto = new ClaimantDto();

		this.context.checking(new Expectations() {
			{
				oneOf(addressRepository).saveAddress(address, true);
				oneOf(claimantService).updateAddressId(CLAIMANT_ID, address);
				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(claimantConverter).convert(claimant);
				will(returnValue(claimantDto));
				never(logiClaimService).sendToLogiclaim(claimantDto);
			}
		});

		this.addressService.saveAddressInConfinement(CLAIMANT_ID, address, true);
	}

	@Test
	public void testUpdateAddress() {
		final Address address = newDummyAddress("M1 1EP");
		address.setId(1234);
		final Address oldAddress = newDummyAddress("WA14 4DL");

		final Claimant claimant = newDummyClaimant();
		final ClaimantDto claimantDto = new ClaimantDto();
		
		this.context.checking(new Expectations() {
			{
				oneOf(addressRepository).getAddressById(ADDRESS_ID);
				will(returnValue(oldAddress));
				oneOf(addressRepository).evict(oldAddress);
				oneOf(addressRepository).updateAddress(address, true);
				oneOf(changeLogService).saveChangeValues(CLAIMANT_ID, oldAddress, address, USER_ID);

				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(claimantConverter).convert(claimant);
				will(returnValue(claimantDto));
				oneOf(logiClaimService).sendToLogiclaim(claimantDto);
			}
		});
		
		this.addressService.updateAddress(CLAIMANT_ID, address, USER_ID, true);
	}

	@Test
	public void testUpdateAddressInConfinement() {
		final Address address = newDummyAddress("M1 1EP");
		address.setId(1234);
		final Address oldAddress = newDummyAddress("WA14 4DL");

		final Claimant claimant = newDummyClaimant();
		final ClaimantDto claimantDto = new ClaimantDto();

		this.context.checking(new Expectations() {
			{
				oneOf(addressRepository).getAddressById(ADDRESS_ID);
				will(returnValue(oldAddress));
				oneOf(addressRepository).evict(oldAddress);
				oneOf(addressRepository).updateAddress(address, false);
				oneOf(changeLogService).saveChangeValues(CLAIMANT_ID, oldAddress, address, USER_ID);

				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(claimantConverter).convert(claimant);
				will(returnValue(claimantDto));
				never(logiClaimService).sendToLogiclaim(claimantDto);
			}
		});

		this.addressService.updateAddressInConfinement(CLAIMANT_ID, address, USER_ID);
	}
	
	private static Address newDummyAddress(final String postcode) {
		return new Address("a", "1", "b", "2", "c", "d", "e", "f", "g", "h", postcode, "a");
	}

	private static PreviousAddress newDummyPreviousAddress(Address address, boolean fromCurrent) {
		return new PreviousAddress(1 , address, fromCurrent);
	}
	
	private static Claimant newDummyClaimant() {
		final LocalDate dob = JodaUtils.britishDateStringToLocalDateOrNull("02/02/1988");
		return new ClaimantBuilder().setId(9)
				.setLeadId(1)
				.setSellerAccountId(2)
				.setSellerCompanyId(3)
				.setTitle("Mr")
				.setForename("a")
				.setMiddleName("a")
				.setSurname("a")
				.setPreviousSurname("a")
				.setDob(dob)
				.setAddressId(ADDRESS_ID)
				.setHomeTelephone("01234567890")
				.setMobileTelephone("07777777777")
				.setAlternativeTelephone("01234567890")
				.setWorkTelephone("")
				.setEmail("a")
				.setFreePpi(true)
				.setFormalDebtArrangement(TriState.NO)
				.setIvaCompanyId(1234)
				.setIvaReference("iva-ref")
				.setInformalDebtArrangement(TriState.NO)
				.setDebtManagementCompanyId(12121)
				.setDebtManagementReference("debt-ref")
				.createClaimant();
	}
}
