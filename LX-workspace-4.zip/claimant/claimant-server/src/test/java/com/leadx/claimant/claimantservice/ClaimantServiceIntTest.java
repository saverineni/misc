package com.leadx.claimant.claimantservice;

import com.leadx.logiclaimadaptor.client.LogiClaimAdaptorClient;
import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.RequiresTestData;
import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@ContextConfiguration(locations = {"classpath:/spring/spring-libTest.xml", "classpath:/spring/spring-test-integrationFiles.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
public class ClaimantServiceIntTest extends AbstractIntegrationTest {

	@Autowired
	ClaimantService claimantService;

	@Autowired
	ClaimantRepository repository;

	@Autowired
	private CamelContext camelContext;


	private static final String MOCK_LOGICLAIM_ADAPTOR = "mock:logiclaim-adaptor";
	private MockEndpoint logiclaimAdaptorEndpoint;

	private final RouteBuilder logiclaimAdaptorRouteBuilder = new RouteBuilder() {
		@Override
		public void configure() throws Exception {
			from(LogiClaimAdaptorClient.CLAIMANT_QUEUE).to(MOCK_LOGICLAIM_ADAPTOR);
		}
	};

	private void configureLogiclaimAdaptorQueue() throws Exception {
		this.camelContext.start();
		this.camelContext.removeComponent("jms");
		this.camelContext.addComponent("jms", this.camelContext.getComponent("seda"));

		this.logiclaimAdaptorEndpoint = this.camelContext.getEndpoint(MOCK_LOGICLAIM_ADAPTOR, MockEndpoint.class);
		this.camelContext.addRoutes(this.logiclaimAdaptorRouteBuilder);

	}

	@Test
	@RequiresTestData
	public void testUpdateClaimant() throws Exception {
		configureLogiclaimAdaptorQueue();
		this.logiclaimAdaptorEndpoint.setExpectedMessageCount(1);
		final Claimant claimant = this.claimantService.getClaimantById(999);
		claimant.setVersion(0);

		this.claimantService.updateClaimant(claimant, 123);

		this.logiclaimAdaptorEndpoint.assertIsSatisfied();
	}
}
