package com.leadx.claimant.claimantservice;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.util.Collection;
import java.util.List;

import org.joda.time.DateTimeUtils;
import org.joda.time.LocalDateTime;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.google.common.collect.ImmutableList;
import com.leadx.claimant.client.ProductType;
import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.NoTestData;
import com.leadx.test.integration.RequiresTestData;

@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class ClaimantReferralRepositoryIntTest  extends AbstractIntegrationTest {

	private static final LocalDateTime NOW =  new LocalDateTime(2014, 10, 5, 14, 55, 10, 0);

	@Autowired
	private ClaimantReferralRepository repository;

	@Before
	public void setUp() {
		DateTimeUtils.setCurrentMillisFixed(NOW.toDateTime()
			.getMillis());
	}

	@Test
	@NoTestData
	public void testCreateClaimantReferral() throws Exception {
		final ClaimantReferral referral = new ClaimantReferral(ProductType.PPI.getId(), 10, 100, 98, 99);

		this.repository.createClaimantReferral(referral);
		this.repository.evict(referral);

		final ClaimantReferral createdClaimantReferral = this.repository.getClaimantReferralById(referral.getId());
		assertThat(createdClaimantReferral.getCreatedDateTime(), is(NOW));
	}

	@Test
	public void testGetReferralByReferreeId() throws Exception {
		final ClaimantReferral ref = this.repository.getClaimantReferralByReferreeId(100);
		assertThat(ref.getId(), is(3));
	}

	@Test
	@RequiresTestData(locations = "testGetReferralByReferreeId")
	public void testGetReferralsByReferreeIds() throws Exception {
		final Collection<ClaimantReferral> ref = this.repository.getClaimantReferralsByReferreeIds(ImmutableList.of(100, 101));
		assertThat(ref.size(), is(3));
	}

	@Test
	@NoTestData
	public void testGetNoProductReferrals() throws Exception {
		final List<ClaimantReferral> referrals = this.repository.getProductReferralsForClaimant(1234);

		assertThat(referrals.size(), is(0));
	}

	@Test
	@RequiresTestData(locations = "testGetProductReferrals")
	public void testGetProductReferrals() throws Exception {
		final List<ClaimantReferral> referrals = this.repository.getProductReferralsForClaimant(100);

		assertThat(referrals.size(), is(2));
	}
}