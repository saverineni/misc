package com.leadx.claimant.applicationpropertyservice;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.RequiresTestData;

@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class ApplicationPropertyRepositoryIntTest extends AbstractIntegrationTest{
	@Autowired
	private ApplicationPropertyRepository applicationPropertyRepository;

	@Test
	@RequiresTestData(locations = "getApplicationProperty")
	public void shouldGetEmptyApplicationProperty() {
		final String propertyString = "Test1";
		assertThat(this.applicationPropertyRepository.get(propertyString), is(""));
	}

	@Test
	@RequiresTestData(locations = "getApplicationProperty")
	public void shouldGetValidApplicationProperty() {
		final String propertyString = "Test2";
		assertThat(this.applicationPropertyRepository.get(propertyString), is("Test2Result"));
	}
}