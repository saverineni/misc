package com.leadx.claimant.util;

import java.math.BigDecimal;
import java.util.Set;

import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;

import com.google.common.collect.Sets;
import com.leadx.claimant.claimantservice.*;
import com.leadx.claimant.client.ClaimantContactPreferenceDto;


public class ClaimantTestUtils {
	
	public static Set<ClaimantOtherName> buildOtherNames(String otherName1, String otherName2) {
		Set<ClaimantOtherName> otherNames = Sets.newLinkedHashSet();
		otherNames.add(new ClaimantOtherName(1, otherName1, false));
		otherNames.add(new ClaimantOtherName(2, otherName2, false));
		
		return otherNames;
	}
	
	public static Set<ClaimantAdditionalPreviousName> buildAdditionalPreviousNames(String previousName1, String previousName2, String previousName3) {
		Set<ClaimantAdditionalPreviousName> previousNames = Sets.newLinkedHashSet();
		previousNames.add(new ClaimantAdditionalPreviousName(1, previousName1, false));
		previousNames.add(new ClaimantAdditionalPreviousName(2, previousName2, false));
		previousNames.add(new ClaimantAdditionalPreviousName(3, previousName3, false));
		
		return previousNames;
	}

	public static ClaimantContactPreference createBlankContactPreference(final int claimantId) {
		return new ClaimantContactPreference.Builder().setClaimantId(claimantId).allTrue().createClaimantContactPreference();
	}

	public static ClaimantContactPreferenceDto createBlankContactPreferenceDto(final int claimantId) {
		return new ClaimantContactPreferenceDto.Builder().setClaimantId(claimantId).allTrue().createClaimantContactPreferenceDto();
	}
	public static ClaimantUnpresentedCheque buildClaimantUnpresentedCheque() {
		ClaimantUnpresentedCheque claimantUnpresentedCheque = new ClaimantUnpresentedCheque();
		claimantUnpresentedCheque.setId(1);
		claimantUnpresentedCheque.setDateChequeIssued(new LocalDate(2018, 01, 01));
		claimantUnpresentedCheque.setAmount(new BigDecimal("500.00"));

		return claimantUnpresentedCheque;
	}

	public static ClaimantExecutor buildClaimantExecutor(final int claimantId) {
		final ClaimantExecutor claimantExecutor = new ClaimantExecutor();
		claimantExecutor.setClaimantId(claimantId);
		claimantExecutor.setTitle("Ms");
		claimantExecutor.setForename("Some Forename");
		claimantExecutor.setMiddleName("Some Middle name");
		claimantExecutor.setSurname("Some Surname");
		claimantExecutor.setPreviousSurname("Some Previous Surname");
		claimantExecutor.setEmail("test@test.com");
		claimantExecutor.setExecutorUpdateDateTime(new LocalDateTime(2017, 8, 8, 9, 0, 0));
		claimantExecutor.setIsExecutorConfirmed(true);
		claimantExecutor.setExecutorConfirmedUpdateDateTime(new LocalDateTime(2018, 9, 9, 9, 0, 0));
		claimantExecutor.setMobileTelephone("07777777777");
		claimantExecutor.setHomeTelephone("016111111111");

		return claimantExecutor;
	}
}
