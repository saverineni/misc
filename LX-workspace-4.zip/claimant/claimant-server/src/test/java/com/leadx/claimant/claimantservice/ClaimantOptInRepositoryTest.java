package com.leadx.claimant.claimantservice;

import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.NoTestData;

@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class ClaimantOptInRepositoryTest extends AbstractIntegrationTest {

	@Autowired
	private ClaimantOptInRepository repository;

	@Test
	@NoTestData
	public void testCreateOptInOptedIn() throws Exception {
		final ClaimantOptIn optIn = new ClaimantOptIn(99, true);
		this.repository.createOptIn(optIn);
		this.repository.evict(optIn);

		final ClaimantOptIn newOptIn = this.repository.getClaimantOptInById(optIn.getId());
		assertThat(newOptIn.getId(), is(greaterThan(0)));
		assertThat(newOptIn.getOptInDateTime(), is(notNullValue()));
	}

	@Test
	@NoTestData
	public void testCreateOptInOptedOut() throws Exception {
		final ClaimantOptIn optIn = new ClaimantOptIn(99, false);
		this.repository.createOptIn(optIn);
		this.repository.evict(optIn);

		final ClaimantOptIn newOptIn = this.repository.getClaimantOptInById(optIn.getId());
		assertThat(newOptIn.getId(), is(greaterThan(0)));
		assertThat(newOptIn.getOptInDateTime(), is(notNullValue()));
	}

	@Test
	public void testUpdateOptIn() throws Exception {
		final ClaimantOptIn optIn = this.repository.getClaimantOptInByClaimantId(9);
		optIn.setOptIn(true);

		this.repository.updateOptIn(optIn);

		final ClaimantOptIn newOptIn = this.repository.getClaimantOptInById(optIn.getId());
		assertThat(newOptIn.getOptIn(), is(true));
	}
}