package com.leadx.claimant.selleraccountservice;


import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.ImmutableList;
import com.leadx.claimant.client.SellerAccountServiceWrapper;
import com.leadx.claimant.util.UrlTester;

public class SellerAccountServiceWrapperTest extends UrlTester {

	private SellerAccountServiceWrapper wrapper;

	@Before
	public void setUp() {
		this.wrapper = new SellerAccountServiceWrapper();
		super.setUp(this.wrapper);

	}

	@Test
	public void testUrlsMatchForGetByIds() throws Exception {
		final String urlMapping = "/selleraccount/ids";
		setWrapperExpectation("http://host:port" + urlMapping + "/2,3", String.class);
		this.wrapper.getByIds(ImmutableList.of(2, 3));

		testControllerUrl(SellerAccountController.class, "getByAccountIds", String.class, urlMapping + "/{ids}");
	}
}
