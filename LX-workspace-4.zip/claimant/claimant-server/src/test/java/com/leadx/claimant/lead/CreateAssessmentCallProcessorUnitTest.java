package com.leadx.claimant.lead;

import static com.leadx.test.MockUtils.mockAndSetOn;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.joda.time.DateTime;
import org.joda.time.DateTimeUtils;
import org.junit.Before;
import org.junit.Test;

import com.leadx.claimant.client.ClaimantLead;
import com.leadx.claimant.client.MethodOfContact;
import com.leadx.claimant.selleraccountservice.SellerAccount;
import com.leadx.claimant.selleraccountservice.SellerAccountService;
import com.leadx.lib.utl.JodaUtils;
import com.leadx.services.claims.client.ClaimRequest.ClaimRequestBuilder;
import com.leadx.services.client.CallReason;
import com.leadx.services.client.TcgCallRequest;
import com.leadx.services.client.service.TelephonyService;

@SuppressWarnings("unqualified-field-access")
public class CreateAssessmentCallProcessorUnitTest {

	private CreateAssessmentCallProcessor createAssessmentCallProcessor;

	private SellerAccountService sellerAccountService;
	private TelephonyService telephonyService;
	
	private static final int CLAIMANT_ID = 1234;
	private static final int ACCOUNT_ID = 5678;
	private static final String CALL_REASON_GROUP = "some call reason group";
	
	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
		}
	};

	@Before
	public void setUp() {
		this.createAssessmentCallProcessor = new CreateAssessmentCallProcessor();

		this.sellerAccountService = mockAndSetOn(this.context, SellerAccountService.class, this.createAssessmentCallProcessor);
		this.telephonyService = mockAndSetOn(this.context, TelephonyService.class, this.createAssessmentCallProcessor);
		
		DateTimeUtils.setCurrentMillisFixed(new DateTime(2014, 11, 27, 13, 05, 44, 0).getMillis());
	}

	@Test
	public void shouldCreateAssessmentCall() {
		final ClaimRequestBuilder crb = new ClaimRequestBuilder();
		crb.claimant().title("Mr");
		crb.address().postcode("WA14 4DZ");
		crb.appointment().requestedDateTime(JodaUtils.newCurrentDateTime());
		crb.sellerAccountId(ACCOUNT_ID);
		
		final ClaimantLead claimantLead = new ClaimantLead(crb.build(), CLAIMANT_ID);
		final SellerAccount sellerAccount = newDummySellerAccount();
		
		this.context.checking(new Expectations() {
			{
				oneOf(sellerAccountService).getByAccountId(ACCOUNT_ID);
				will(returnValue(sellerAccount));
				oneOf(telephonyService).scheduleCall(newDummyCallRequest());
			}
		});
		
		this.createAssessmentCallProcessor.createAssessmentCall(claimantLead);
	}
	
	private static final TcgCallRequest newDummyCallRequest() {
		final CallReason callReason = new CallReason("assessment", CALL_REASON_GROUP);
		
		final TcgCallRequest callRequest = new TcgCallRequest();
		callRequest.setCallReason(callReason);
		callRequest.setTitle("Mr");
		callRequest.setPostcode("WA14 4DZ");
		callRequest.setScheduledDateTime(JodaUtils.newCurrentDateTime());
		callRequest.setClaimantId(CLAIMANT_ID);
		
		return callRequest;
	}
	
	private static SellerAccount newDummySellerAccount() {
		
		final SellerAccount sellerAccount = 
				new SellerAccount(ACCOUNT_ID, "", "", "", "", MethodOfContact.telephone, "", "", true, CALL_REASON_GROUP, "", "", "", false);
		
		sellerAccount.setAccountId(ACCOUNT_ID);
		sellerAccount.setAssessmentCallReasonGroup(CALL_REASON_GROUP);
		
		return sellerAccount;
	}
}
