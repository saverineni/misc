package com.leadx.claimant.calllogservice;

import static com.leadx.test.MockUtils.mockAndSetOn;

import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.SessionFactory;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;

import com.leadx.claimant.client.CallDisposition;
import com.leadx.claimant.client.CallLogDto;
import com.leadx.claimant.client.CallType;
import com.leadx.test.integration.NoTestData;

@SuppressWarnings("unqualified-field-access")
public class CallLogServiceUnitTest {

	@Autowired
	protected CallLogService callLogService;

	protected CallLogRepository callLogRepository;
	protected Converter<CallLog, CallLogDto> callLogConverter;

	@Resource(name = "sessionFactory")
	private SessionFactory sessionFactory;

	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
		}
	};

	private static final int CLAIMANT_ID = 4882;
	private static final Integer USER_ID_1 = 24;
	private static final int DIALLER_REFERENCE_1 = 10001;

	@Before
	public void setUp() {
		this.callLogService = new CallLogService();
		this.callLogRepository = mockAndSetOn(this.context, CallLogRepository.class, this.callLogService);
		this.callLogConverter = mockAndSetOn(this.context, CallLogConverter.class, this.callLogService);
	}

	@Test
	@NoTestData
	public void testSaveCallLog() {
		final CallLog callLog = new CallLog(CLAIMANT_ID,CallDisposition.ANSWERPHONE,CallType.ASSESSMENT,DIALLER_REFERENCE_1, false, USER_ID_1);
		this.context.checking(new Expectations() {
			{
				oneOf(callLogRepository).isDiallerReferenceUnique(DIALLER_REFERENCE_1, CallType.ASSESSMENT);
				will(returnValue(true));
				oneOf(callLogRepository).saveCallLog(callLog);
			}
		});

		this.callLogService.saveCallLog(callLog);
	}

	@Test
	public void testSaveCallLogNoConstraints() {
		final CallLog callLog = new CallLog(CLAIMANT_ID,CallDisposition.ANSWERPHONE,CallType.ASSESSMENT,DIALLER_REFERENCE_1, false, USER_ID_1);
		this.context.checking(new Expectations() {
			{
				never(callLogRepository).isDiallerReferenceUnique(DIALLER_REFERENCE_1, CallType.ASSESSMENT);
				oneOf(callLogRepository).saveCallLog(callLog);
			}
		});

		this.callLogService.saveCallLogNoConstraints(callLog);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	@NoTestData
	public void testfindCallLogsForClaimant() {
		final CallLog callLog = new CallLog(CLAIMANT_ID,CallDisposition.ANSWERPHONE,CallType.ASSESSMENT,DIALLER_REFERENCE_1, false, USER_ID_1);
		final CallLogDto logDto =  new CallLogDto(CLAIMANT_ID,CallDisposition.ANSWERPHONE.getName(),CallType.ASSESSMENT.getName(),DIALLER_REFERENCE_1, false, USER_ID_1);
		final List<CallLog> logList = new ArrayList();
		final List<Time> durList = new ArrayList();
		this.context.checking(new Expectations() {
			{
				oneOf(callLogRepository).findCallLogsForClaimant(CLAIMANT_ID);
				will(returnValue(logList));
				oneOf(callLogRepository).getCallDurationForClaimant(CLAIMANT_ID);
				will(returnValue(durList));
				oneOf(callLogConverter).convert(callLog);
				will(returnValue(logDto));
			}
		});

		this.callLogService.findCallLogsForClaimant(CLAIMANT_ID);
	}
}
