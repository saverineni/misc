package com.leadx.claimant.selleraccountservice;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.Collection;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.leadx.claimant.client.MethodOfContact;
import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.NoTestData;
import com.leadx.test.integration.RequiresTestData;

@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class SellerAccountRepositoryIntTest extends AbstractIntegrationTest {
	@Autowired
	SellerAccountRepository repository;

	@Test
	@RequiresTestData(locations = "seller_account")
	public void testGetByAccountIds() {
		final Collection<SellerAccount> sellerAccounts = this.repository.getByAccountIds(ImmutableList.of(12,11));

		assertThat(sellerAccounts.size(), is(2));

	}

	@Test
	@RequiresTestData(locations = "seller_account")
	public void testGetByAccountId() {
		final SellerAccount sellerAccount = this.repository.getByAccountId(11);

		assertThat(sellerAccount.getId(), is(1));
		assertThat(sellerAccount.getGpSellerAccount(), is("GP_SELLER_ACC"));
		assertThat(sellerAccount.getName(), is("Seller Name"));
		assertThat(sellerAccount.getDisplayName(), is("Display Name"));
		assertThat(sellerAccount.getSourceDescription(), is(""));
		assertThat(sellerAccount.getApplicationLogo(), is("LOGO.swf"));
		assertThat(sellerAccount.getPackType(), is("tcg_pack"));
		assertThat(sellerAccount.getAssessmentCallReasonGroup(), is("call_reason_group"));
		assertThat(sellerAccount.getEmailIconImageName(), is("email_icon.png"));
		assertThat(sellerAccount.getAssessmentInitialSmsMessageScript(), is("smsScript"));
		assertThat(sellerAccount.getAssessmentInitialEmailMessageScript(), is("emailScript"));
		assertThat(sellerAccount.getDistributeAppointmentReminder(), is(true));

		final SellerAccount sellerAccount2 = this.repository.getByAccountId(12);
		assertThat(sellerAccount2.getInboundNumbers().size(), is(1));
		assertThat(sellerAccount2.getInboundNumbers().get(0), is("02999999941"));
		assertThat(sellerAccount2.getProductType().getId(), is(1));
	}

	@Test
	@RequiresTestData(locations = "seller_account")
	public void testGetAllSellerAccounts() {
		final List<SellerAccount> sellerAccounts = this.repository.getAll();

		assertThat(sellerAccounts.size(), is(5));
	}

	@Test
	@NoTestData
	public void testUpdateSellerAccount() {
		final SellerAccount sellerAccount = new SellerAccount(0,"GP_SELLER_ACC","Seller Name", "Display Name", "", MethodOfContact.telephone, "LOGO.swf","tcg_pack",false,"call_reason_group","smsScript","emailScript","email_icon.png", false);
		final ProductType selected = new ProductType(1, "ppi");
		sellerAccount.setProductType(selected);
		this.repository.create(sellerAccount);
		this.repository.evict(sellerAccount);

		sellerAccount.setName("Updated Seller Name");
		sellerAccount.setDisplayName("Updated Display Name");
		sellerAccount.setSourceDescription("Updated Source Description");
		sellerAccount.setAssessmentInitialEmailMessageScript("updatedEmailScript");
		sellerAccount.setAssessmentInitialSmsMessageScript("updatedSmsScript");
		sellerAccount.setPackType("updated_pack_type");

		this.repository.update(sellerAccount);

		final SellerAccount expected = this.repository.getByAccountId(sellerAccount.getAccountId());

		assertThat(expected.getName(), is("Updated Seller Name"));
		assertThat(expected.getDisplayName(), is("Updated Display Name"));
		assertThat(expected.getAssessmentInitialEmailMessageScript(), is("updatedEmailScript"));
		assertThat(expected.getAssessmentInitialSmsMessageScript(), is("updatedSmsScript"));
		assertThat(expected.getPackType(), is("updated_pack_type"));
	}

	@Test
	@NoTestData
	public void testCreateSellerAccount() {
		final SellerAccount newSellerAccount = new SellerAccount(0,"GP_SELLER_ACC","Seller Name", "Display Name", "", MethodOfContact.telephone, "LOGO.swf","tcg_pack",false,"call_reason_group","smsScript","emailScript","email_icon.png", false);
		final ProductType selected = new ProductType(1, "ppi");
		newSellerAccount.setProductType(selected);
		this.repository.create(newSellerAccount);
		this.repository.evict(newSellerAccount);

		final SellerAccount createdSellerAccount = this.repository.getByAccountId(newSellerAccount.getAccountId());

		assertThat(createdSellerAccount.getProductType().getId(), is(1));
		assertThat(createdSellerAccount.getInboundNumbers().size(), is(0));
	}

	@Test
	@RequiresTestData(locations = "seller_account")
	public void testGetSourcedSellerAccounts() {
		final List<String> numbers = Lists.newArrayList("02999999941", "02999999943");
		final List<SellerAccount> sellerAccount = this.repository.getSourcedSellerAccounts();

		assertThat(sellerAccount.size(), is(3));

		assertThat(sellerAccount.get(0).getAccountId(), is(12));
		assertThat(sellerAccount.get(0).getSourceDescription(), is("Source Description 2"));
		assertThat(sellerAccount.get(0).getInboundNumbers().get(0), is(numbers.get(0)));

		assertThat(sellerAccount.get(1).getAccountId(), is(14));
		assertThat(sellerAccount.get(1).getSourceDescription(), is("Source Description 4"));
		assertThat(sellerAccount.get(1).getInboundNumbers().get(0), is(numbers.get(1)));

		assertThat(sellerAccount.get(2).getAccountId(), is(15));
		assertThat(sellerAccount.get(2).getSourceDescription(), is("Source Description 5"));
	}

	@Test
	@NoTestData
	public void testFreePPi() {
		final int sellerAccountId = 1234;
		final SellerAccount newSellerAccount = new SellerAccount(sellerAccountId,"GP_SELLER_ACC","Seller Name", "Display Name", "", MethodOfContact.telephone, "LOGO.swf","tcg_pack",false,"call_reason_group","smsScript","emailScript","email_icon.png", true);
		final ProductType selected = new ProductType(1, "ppi");
		newSellerAccount.setProductType(selected);
		this.repository.create(newSellerAccount);

		boolean isFreePpi = this.repository.isFreePpi(sellerAccountId);
		assertTrue(isFreePpi);
	}

	@Test
	@NoTestData
	public void testFreePPiWhenSellerAccountNotPresent() {
		final int sellerAccountId = 1234;
		boolean isFreePpi = this.repository.isFreePpi(sellerAccountId);
		assertFalse(isFreePpi);
	}
}