package com.leadx.claimant.lead;
import org.hamcrest.Description;
import org.jmock.api.Action;
import org.jmock.api.Invocation;

import com.leadx.claimant.claimantservice.Claimant;

public class CreateClaimantAction implements Action {
	@SuppressWarnings("unused")
	private final Claimant claimant;
	
	public CreateClaimantAction( final Claimant claimant) {
		this.claimant = claimant;
	}
	
	@Override
	public void describeTo(final Description description) {
	}

	@Override
	public Object invoke(final Invocation invocation) throws Throwable {
		((Claimant) invocation.getParameter(0)).setId(1);
		return null;
	}
	
}