package com.leadx.claimant.lead;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.leadx.services.address.Address;

public class AddressComparisonUtilsUnitTest {
	private AddressComparisonUtils addressComparisonUtils;

	@Before
	public void setUp() {
		this.addressComparisonUtils = new AddressComparisonUtils();
	}

	@Test
	public void addressesMatch(){
		final String postCode = "M5 3AA";
		com.leadx.claimant.addressservice.Address address = new com.leadx.claimant.addressservice.Address(null, null, null, null, "50", null, "Some Lane", null, null, "Salford", postCode, null);

		Address pafAddress = new Address();
		pafAddress.setBuildingNumber("50");
		pafAddress.setThoroughfare("Some Lane");
		pafAddress.setTown("Salford");
		pafAddress.setPostcode(postCode);

		assertTrue(this.addressComparisonUtils.addressStringsMatch(address, pafAddress));
	}

	@Test
	public void addressWithSpecialChars(){
		final String postCode = "M5 3AA";
		com.leadx.claimant.addressservice.Address address = new com.leadx.claimant.addressservice.Address(null, null, null, "St. Hudson Court", "172", "Hollies Lane", "Broad Street", null, null, "Stoke on trent", postCode, null);

		Address pafAddress = new Address();
		pafAddress.setBuildingNumber("172");
		pafAddress.setBuildingName("St Hudson Court");
		pafAddress.setThoroughfare("Hollies Lane, Broad Street");
		pafAddress.setTown("Stoke-on-trent");
		pafAddress.setPostcode(postCode);

		assertTrue(this.addressComparisonUtils.addressStringsMatch(address, pafAddress));
	}

	@Test
	public void addressWithFlatPrefix(){
		final String postCode = "M5 3AA";
		com.leadx.claimant.addressservice.Address address = new com.leadx.claimant.addressservice.Address(null, null, null, "172 Hudson Court", null, null, "Hollies Lane", null, null, "Salford", postCode, null);

		Address pafAddress = new Address();
		pafAddress.setBuildingName("FLAT 172 Hudson Court");
		pafAddress.setThoroughfare("Hollies Lane");
		pafAddress.setTown("Salford");
		pafAddress.setPostcode(postCode);

		assertTrue(this.addressComparisonUtils.addressStringsMatch(address, pafAddress));
	}
}
