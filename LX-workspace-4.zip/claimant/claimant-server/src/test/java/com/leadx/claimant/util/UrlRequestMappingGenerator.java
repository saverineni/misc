package com.leadx.claimant.util;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.lang.reflect.Method;

import org.springframework.web.bind.annotation.RequestMapping;

/**
 * This used reflection to look at a clss and generate the url from the request mapping annotations
 */
public class UrlRequestMappingGenerator  {
	public String getUrlMapping(final Class<?> clazz, final String name, final Class<?>... parameterTypes) throws NoSuchMethodException {
		return getMappingForClass(clazz) + getMappingForMethod(clazz, name, parameterTypes);
	}

	private static String getMappingForClass(final Class<?> clazz) {
		final RequestMapping mapping = clazz.getAnnotation(RequestMapping.class);
		if ( mapping == null ) {
			return "";
		}

		final String[] values = mapping.value();
		if ( values == null ) {
			return "";
		}

		assertThat(values.length, is(1));
		return values[0];
	}

	private static String getMappingForMethod(final Class<?> clazz, final String name, final Class<?>... parameterTypes) throws NoSuchMethodException {
		final Method method = clazz.getMethod(name, parameterTypes);
		final String[] values = method.getAnnotation(RequestMapping.class).value();
		assertThat(values.length, is(1));
		return values[0];
	}

}
