package com.leadx.claimant.util;

import static org.hamcrest.core.Is.is;
import static org.jmock.lib.legacy.ClassImposteriser.INSTANCE;
import static org.junit.Assert.assertThat;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestOperations;

public class UrlTester {
	private final Mockery context = new Mockery() {
		{
			setImposteriser(INSTANCE);
		}
	};

	private RestOperations restOperations ;
	private ResponseEntity<String> response;
	private final UrlRequestMappingGenerator generator = new UrlRequestMappingGenerator();

	protected void setUp(final Object wrapper) {
		this.restOperations = this.context.mock(RestOperations.class);
		ReflectionTestUtils.setField(wrapper, "restOperations", this.restOperations);
		ReflectionTestUtils.setField(wrapper, "protocol", "http");
		ReflectionTestUtils.setField(wrapper, "host", "host");
		ReflectionTestUtils.setField(wrapper, "port", "port");

		this.response = new ResponseEntity<>("[]", HttpStatus.OK);
	}

	protected void setWrapperExpectation(final String expectedUrl, final Class parameterType) {
		this.context.checking(new Expectations() {
			{
				// Check the url the wrapper usinging
				oneOf(restOperations).getForEntity(expectedUrl, parameterType);
				will(returnValue(response));
			}
		});
	}

	protected void testControllerUrl(final Class controllerClass, final String method, final Class parameterType, final String expectedUrl) throws NoSuchMethodException {
		assertThat(this.generator.getUrlMapping(controllerClass, method, parameterType), is(expectedUrl));
	}

}
