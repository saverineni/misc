package com.leadx.claimant.claimantservice;

import static com.leadx.claimant.claimantservice.ClaimantContactPreferenceService.*;
import static com.leadx.test.MockUtils.mockAndSetOn;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.joda.time.DateTimeUtils;
import org.junit.Before;
import org.junit.Test;

import com.leadx.claimant.callallocationservice.TelephonyHelper;
import com.leadx.claimant.user.User;
import com.leadx.claimant.user.UserService;
import com.leadx.claimant.util.ClaimantTestUtils;
import com.leadx.services.client.TcgProduct;
import com.leadx.services.distribution.client.CancellationRequest;
import com.leadx.services.distribution.client.DistributionClient;

@SuppressWarnings({"unqualified-field-access","serial"})
public class ClaimantContactPreferenceServiceUnitTest {

	private ClaimantContactPreferenceService service;
	private ClaimantContactPreferenceRepository repository;
	private UserService userService;
	private ClaimantInteractionRepository claimantInteractionRepository;
	private TelephonyHelper telephonyHelper;
	private DistributionClient distributionClient;

	private static final int CLAIMANT_ID = 54321;
	private static final int USER_ID = 111;
	private User user;

	private final Mockery context = new Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
		}
	};

	@Before
	public void setUp() {
		this.service = new ClaimantContactPreferenceService();
		this.repository = mockAndSetOn(this.context, ClaimantContactPreferenceRepository.class, this.service);
		this.telephonyHelper = mockAndSetOn(this.context, TelephonyHelper.class, this.service);
		this.distributionClient = mockAndSetOn(this.context, DistributionClient.class, this.service);
		this.userService = mockAndSetOn(this.context, UserService.class, this.service);
		this.claimantInteractionRepository = mockAndSetOn(this.context, ClaimantInteractionRepository.class, this.service);
		this.user = new User();
		user.setId(USER_ID);

		DateTimeUtils.setCurrentMillisFixed(DateTimeUtils.currentTimeMillis());
	}

	@Test
	public void testGetByClaimantId() {
		this.context.checking(new Expectations() {
			{
				oneOf(repository).getByClaimantId(CLAIMANT_ID);
				will(returnValue(with(any(ClaimantContactPreference.class))));
			}
		});

		this.service.getByClaimantId(54321);
	}

	@Test
	public void testGetById() {
		this.context.checking(new Expectations() {
			{
				oneOf(repository).getById(54321);
				will(returnValue(ClaimantTestUtils.createBlankContactPreference(CLAIMANT_ID)));
			}
		});

		this.service.getById(54321);
	}

	@Test
	public void testSaveOrUpdateAllMethodsOptedIn() {
		final ClaimantContactPreference existing = new ClaimantContactPreference.Builder()
				.setClaimantId(CLAIMANT_ID)
				.setTelephoneOptIn(false)
				.setEmailOptIn(false)
				.setSmsOptIn(false)
				.setMarketingMailingOptIn(false)
				.setUserIdUpdated(USER_ID)
				.createClaimantContactPreference();

		final ClaimantContactPreference contactPreference = new ClaimantContactPreference.Builder()
				.setClaimantId(CLAIMANT_ID)
				.allTrue()
				.createClaimantContactPreference();

		final String content = "Claimant has opted in to all contact preferences";
		final ClaimantInteraction event = ClaimantInteraction.newEvent(CLAIMANT_ID, null, user, content, Source.CLAIMANT);

		this.context.checking(new Expectations() {
			{
				oneOf(repository).getByClaimantId(CLAIMANT_ID);
				will(returnValue(existing));
				oneOf(repository).evict(existing);
				oneOf(repository).saveOrUpdate(with(any(ClaimantContactPreference.class)));
				never(telephonyHelper);
				never(distributionClient);
				oneOf(userService).getById(0);
				will(returnValue(user));
				oneOf(claimantInteractionRepository).save(event);
			}
		});

		this.service.saveOrUpdate(contactPreference);
	}

	@Test
	public void testSaveOrUpdateEmailAndSmsOptedOut() {
		final ClaimantContactPreference existing = new ClaimantContactPreference.Builder()
				.setClaimantId(CLAIMANT_ID)
				.setTelephoneOptIn(true)
				.setEmailOptIn(true)
				.setSmsOptIn(true)
				.setUserIdUpdated(USER_ID)
				.createClaimantContactPreference();

		final ClaimantContactPreference contactPreference = new ClaimantContactPreference.Builder()
				.setClaimantId(CLAIMANT_ID)
				.setTelephoneOptIn(true)
				.setEmailOptIn(false)
				.setSmsOptIn(false)
				.setUserIdUpdated(USER_ID)
				.createClaimantContactPreference();

		final String content = "Claimant has opted out of the following methods of contact: Email,SMS";
		final ClaimantInteraction event = ClaimantInteraction.newEvent(CLAIMANT_ID, null, user, content, Source.CLAIMANT);

		this.context.checking(new Expectations() {
			{
				oneOf(repository).getByClaimantId(CLAIMANT_ID);
				will(returnValue(existing));
				oneOf(repository).evict(existing);
				oneOf(repository).saveOrUpdate(contactPreference);
				never(telephonyHelper);
				oneOf(distributionClient).cancel(createDistributionRequest(WELCOME_SMS_FLOW_ID));
				oneOf(distributionClient).cancel(createDistributionRequest(PACK_SMS_OUT_FLOW_ID));
				oneOf(distributionClient).cancel(createDistributionRequest(WELCOME_EMAIL_FLOW_ID));
				oneOf(distributionClient).cancel(createDistributionRequest(PACK_OUT_EMAIL_FLOW_ID_PPI));
				oneOf(distributionClient).cancel(createDistributionRequest(PACK_OUT_EMAIL_FLOW_ID_PBA));
				oneOf(userService).getById(USER_ID);
				will(returnValue(user));
				oneOf(claimantInteractionRepository).save(event);
			}
		});

		this.service.saveOrUpdate(contactPreference);
	}

	@Test
	public void testSaveOrUpdateEmailAndSmsOptedIn() {
		final ClaimantContactPreference existing = new ClaimantContactPreference.Builder()
				.setClaimantId(CLAIMANT_ID)
				.setTelephoneOptIn(true)
				.setEmailOptIn(false)
				.setSmsOptIn(false)
				.setTelephoneOptIn(false)
				.setMarketingMailingOptIn(false)
				.setUserIdUpdated(USER_ID)
				.createClaimantContactPreference();

		final ClaimantContactPreference contactPreference = new ClaimantContactPreference.Builder()
				.setClaimantId(CLAIMANT_ID)
				.setTelephoneOptIn(false)
				.setEmailOptIn(true)
				.setSmsOptIn(true)
				.setUserIdUpdated(USER_ID)
				.createClaimantContactPreference();

		final String content = "Claimant has opted in to the following methods of contact: Email,SMS";
		final ClaimantInteraction event = ClaimantInteraction.newEvent(CLAIMANT_ID, null, user, content, Source.CLAIMANT);

		this.context.checking(new Expectations() {
			{
				oneOf(repository).getByClaimantId(CLAIMANT_ID);
				will(returnValue(existing));
				oneOf(repository).evict(existing);
				oneOf(repository).saveOrUpdate(with(any(ClaimantContactPreference.class)));
				oneOf(telephonyHelper).cancelCalls(CLAIMANT_ID, USER_ID, TcgProduct.PPI);
				oneOf(telephonyHelper).cancelCalls(CLAIMANT_ID, USER_ID, TcgProduct.PBA);
				oneOf(telephonyHelper).cancelCalls(CLAIMANT_ID, USER_ID, TcgProduct.COMBINED);
				never(distributionClient);
				never(claimantInteractionRepository);
				oneOf(userService).getById(USER_ID);
				will(returnValue(user));
				oneOf(claimantInteractionRepository).save(event);
			}
		});

		this.service.saveOrUpdate(contactPreference);
	}

	private static CancellationRequest createDistributionRequest(final int flowId){
		return new CancellationRequest.CancellationRequestBuilder()
				.reference(CLAIMANT_ID)
				.flow(flowId)
				.build();
	}
}
