package com.leadx.claimant.callallocationservice;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;


public class ClaimantGroupAllocationConverterUnitTest {

	@Test
	public void testConvert() throws Exception {

		final ClaimantGroupAllocationConverter converter = new ClaimantGroupAllocationConverter();
		final ClaimantGroupAllocation claimantGroupAllocation = new ClaimantGroupAllocation(12345, "chase test", "PPI Only");
		final ClaimantGroupAllocationDto dto = converter.convert(claimantGroupAllocation);

		assertThat(dto.getClaimantId(), is(12345));
		assertThat(dto.getCallReason(), is("chase test"));
		assertThat(dto.getCallReasonGroup(), is("PPI Only"));

	}



}
