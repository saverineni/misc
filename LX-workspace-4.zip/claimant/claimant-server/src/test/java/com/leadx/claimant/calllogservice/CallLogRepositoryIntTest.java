package com.leadx.claimant.calllogservice;

import static com.leadx.lib.utl.matcher.Matchers.deepEquals;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.sql.Time;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.SessionFactory;
import org.joda.time.DateTime;
import org.joda.time.DateTimeUtils;
import org.joda.time.LocalDateTime;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.leadx.claimant.client.CallDisposition;
import com.leadx.claimant.client.CallType;
import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.RequiresTestData;

@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class CallLogRepositoryIntTest extends AbstractIntegrationTest {

	private static final int CLAIMANT_ID = 4882;
	private static final Integer LOG_ID_1 = 1;
	private static final Integer USER_ID_1 = 24;
	private static final int DIALLER_REFERENCE_1 = 10001;
	private static final Integer LOG_ID_2 = 2;
	private static final Integer USER_ID_2 = 25;
	private static final int DIALLER_REFERENCE_2 = 10002;

	@Autowired
	private CallLogRepository callLogRepository;

	@Resource(name = "sessionFactory")
	private SessionFactory sessionFactory;

	@Before
	public void setup() {
		DateTimeUtils.setCurrentMillisFixed(new DateTime(2011, 3, 15, 15, 0, 0).getMillis());
	}

	@Test
	@RequiresTestData(locations = "call_log")
	public void shouldConsiderZeroAsAlwaysUnique() {

		final boolean found = this.callLogRepository.isDiallerReferenceUnique(0, CallType.ASSESSMENT);
		assertThat(found, is(true));

		final boolean foundChase = this.callLogRepository.isDiallerReferenceUnique(0, CallType.CHASE);
		assertThat(foundChase, is(true));
	}

	@Test
	@RequiresTestData(locations = "call_log")
	public void shouldFindExistingDiallerReferenceId() {

		final boolean found = this.callLogRepository.isDiallerReferenceUnique(10001, CallType.ASSESSMENT);
		assertThat(found, is(false));

	}

	@Test
	@RequiresTestData(locations = "call_log")
	public void shouldNotFindNonExistentDiallerReferenceId() {

		final boolean found = this.callLogRepository.isDiallerReferenceUnique(10000, CallType.ASSESSMENT);
		assertThat(found, is(true));

	}

	@Test
	@RequiresTestData(locations = "call_log")
	public void shouldNotFindExistingDiallerReferenceIdWithDifferentCallType() {

		final boolean found = this.callLogRepository.isDiallerReferenceUnique(10001, CallType.CHASE);
		assertThat(found, is(true));

	}

	@Test
	@RequiresTestData(locations = "extended_call_log")
	public void shouldFindCallLogsForClaimant() {

		final CallLog log1 = new CallLog(CLAIMANT_ID, CallDisposition.ANSWERPHONE, CallType.ASSESSMENT, DIALLER_REFERENCE_1, false, USER_ID_1);
		log1.setDispositionDateTime(new LocalDateTime(2011, 3, 15, 11, 0, 0, 0));
		log1.setId(LOG_ID_1);

		final CallLog log2 = new CallLog(CLAIMANT_ID, CallDisposition.ALREADY_ARRANGED, CallType.ASSESSMENT, DIALLER_REFERENCE_2, false, USER_ID_2);
		log2.setId(LOG_ID_2);

		log2.setDispositionDateTime(new LocalDateTime(2011, 3, 15, 12, 0, 0, 0));

		final List<CallLog> results = this.callLogRepository.findCallLogsForClaimant(CLAIMANT_ID);
		assertThat(results.size(), is(2));
		assertThat(results.get(0), is(deepEquals(log2)));
		assertThat(results.get(1), is(deepEquals(log1)));
	}

	@Test
	@RequiresTestData(locations = "extended_call_log")
	public void shouldFindCallDurationsForClaimant() {

		@SuppressWarnings("deprecation")
		final Time time1 = new Time(0, 10, 0);

		@SuppressWarnings("deprecation")
		final Time time2 = new Time(0, 30, 0);

		final List<Time> result = this.callLogRepository.getCallDurationForClaimant(CLAIMANT_ID);
		assertThat(result.size(), is(2));
		assertThat(result.get(0), is(time1));
		assertThat(result.get(1), is(time2));
	}
}
