package com.leadx.claimant.selleraccountservice;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.leadx.claimant.client.DropdownConfigurationDto;

public class DropdownConfigurationConverterTest {

	@Test
	public void testConvert() {
		final DropdownConfigurationConverter dropdownConfigurationConverter = new DropdownConfigurationConverter();
		final DropdownConfiguration dropdownConfiguration = new DropdownConfiguration("fieldName", "fieldValue", 1);
		
		final DropdownConfigurationDto dropdownConfigurationDto = dropdownConfigurationConverter.convert(dropdownConfiguration);

		assertThat(dropdownConfigurationDto, is(notNullValue()));
		assertThat(dropdownConfigurationDto.getFieldName(), is("fieldName"));
		assertThat(dropdownConfigurationDto.getFieldValue(), is("fieldValue"));
		assertThat(dropdownConfigurationDto.getFieldOrder(), is(1));
	}

	@Test
	public void testConvertNull() {
		final DropdownConfigurationConverter dropdownConfigurationConverter = new DropdownConfigurationConverter();
		final DropdownConfigurationDto dropdownConfigurationDto = dropdownConfigurationConverter.convert(null);

		assertThat(dropdownConfigurationDto, is(nullValue()));
	}
}