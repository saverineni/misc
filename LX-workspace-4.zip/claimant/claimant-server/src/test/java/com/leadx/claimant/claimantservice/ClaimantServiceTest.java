package com.leadx.claimant.claimantservice;

import static com.leadx.claimant.claimantservice.ClaimantService.buildNoteDto;
import static com.google.common.collect.Lists.newArrayList;
import static com.leadx.claimant.claimantservice.Source.CLAIMANT;
import static com.leadx.claimant.claimantservice.Source.PAYMENTS;
import static com.leadx.test.MockUtils.mockAndSetOn;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.util.List;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.joda.time.DateTimeUtils;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.google.common.collect.ImmutableList;
import com.leadx.claimant.addressservice.Address;
import com.leadx.claimant.addressservice.AddressService;
import com.leadx.claimant.changelogservice.ChangeLogService;
import com.leadx.claimant.client.ClaimantDto;
import com.leadx.claimant.client.ProductType;
import com.leadx.claimant.logiclaimservice.LogiClaimService;
import com.leadx.claimant.selleraccountservice.SellerAccount;
import com.leadx.claimant.selleraccountservice.SellerAccountService;
import com.leadx.claimant.user.User;
import com.leadx.claimant.user.UserService;
import com.leadx.claimant.utils.CallRequestBuilder;
import com.leadx.logiclaimadaptor.client.LogiClaimAdaptorServiceWrapper;
import com.leadx.services.client.service.TelephonyService;

@SuppressWarnings({"unqualified-field-access","serial"})
public class ClaimantServiceTest {
	private ClaimantService claimantService;
	private ClaimantRepository claimantRepository;
	private ChangeLogService changeLogService;
	private AddressService addressService;
	private TelephonyService telephonyService;
	private UserService userService;
	private SellerAccountService sellerAccountService;
	private LogiClaimService logiClaimService;
	private ClaimantConverter claimantConverter;

	private ClaimantLogRepository claimantLogRepository;
	private ClaimantOptInRepository claimantOptInRepository;
	private ClaimantReferralRepository claimantReferralRepository;
	private ClaimantInteractionRepository claimantInteractionRepository;
	private LogiClaimAdaptorServiceWrapper logiClaimAdaptorServiceWrapper;
	private static final LocalDateTime NOW =  new LocalDateTime(2014, 10, 5, 14, 55, 10, 0);

	private static final int CLAIMANT_ID = 123456;
	private static final int USER_ID = 3388;
	private static final int AGENT_ID = 90185;
	
	private final Mockery context = new Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
		}
	};

	@Before
	public void setUp() {
		DateTimeUtils.setCurrentMillisFixed(NOW.toDateTime().getMillis());
		this.claimantService = new ClaimantService();
		this.claimantRepository = mockAndSetOn(this.context, ClaimantRepository.class, this.claimantService);
		this.changeLogService = mockAndSetOn(this.context, ChangeLogService.class, this.claimantService);
		this.addressService = mockAndSetOn(this.context, AddressService.class, this.claimantService);
		this.telephonyService = mockAndSetOn(this.context, TelephonyService.class, this.claimantService);
		this.userService = mockAndSetOn(this.context, UserService.class, this.claimantService);
		this.claimantInteractionRepository = mockAndSetOn(this.context, ClaimantInteractionRepository.class, this.claimantService);
		this.sellerAccountService = mockAndSetOn(this.context, SellerAccountService.class, this.claimantService);
		this.logiClaimService = mockAndSetOn(this.context, LogiClaimService.class, this.claimantService);
		this.claimantConverter = mockAndSetOn(this.context, ClaimantConverter.class, this.claimantService);
		this.logiClaimAdaptorServiceWrapper = mockAndSetOn(this.context, LogiClaimAdaptorServiceWrapper.class, this.claimantService);

		this.claimantLogRepository = this.context.mock(ClaimantLogRepository.class);
		this.claimantOptInRepository = this.context.mock(ClaimantOptInRepository.class);
		this.claimantReferralRepository = this.context.mock(ClaimantReferralRepository.class);

		ReflectionTestUtils.setField(this.claimantService, "claimantLogRepository", this.claimantLogRepository);
		ReflectionTestUtils.setField(this.claimantService, "claimantOptInRepository", this.claimantOptInRepository);
		ReflectionTestUtils.setField(this.claimantService, "claimantReferralRepository", this.claimantReferralRepository);
		ReflectionTestUtils.setField(this.claimantService, "claimantInteractionRepository", this.claimantInteractionRepository);
	}

	@Test
	public void testGetClaimantsByIds() {
		final Claimant claimant1 = new ClaimantBuilder().setId(11)
				.setLeadId(1231)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("matt1")
				.setMiddleName("middle1")
				.setSurname("matty1")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 21))
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me1@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();
		final Claimant claimant2 = new ClaimantBuilder().setId(12)
				.setLeadId(1232)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mrx")
				.setForename("matt2")
				.setMiddleName("middle2")
				.setSurname("matty2")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 22))
				.setAddressId(0)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me2@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();
		final Claimant claimant3 = new ClaimantBuilder().setId(13)
				.setLeadId(1233)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mrx")
				.setForename("matt3")
				.setMiddleName("middle3")
				.setSurname("matty3")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 23))
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me3@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();

		final List<Claimant> claimants = newArrayList(claimant1, claimant2, claimant3);

		this.context.checking(new Expectations() {
			{
				oneOf(claimantRepository).getClaimantsByIds(newArrayList(11, 12, 13));
				will(returnValue(claimants));
				atLeast(3).of(addressService).getAddressById(0);
			}
		});

		this.claimantService.getClaimantsAndAddressByIds(newArrayList(11, 12, 13));
	}

	@Test
	public void testCreateClaimant() throws Exception {
		final Claimant inputClaimant = new ClaimantBuilder().setId(10)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("matt")
				.setMiddleName("middle")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();
		final Claimant expectedClaimant = new ClaimantBuilder().setId(0)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("matt")
				.setMiddleName("middle")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();
		this.context.checking(new Expectations() {
			{
				oneOf(claimantRepository).createClaimant(expectedClaimant);
				oneOf(claimantRepository).evict(expectedClaimant);
				oneOf(claimantRepository).getClaimantById(0); // Id is zero because mock call to createClaimant doesn't update the id like hibernate does
				will(returnValue(null));
			}
		});

		this.claimantService.createClaimant(inputClaimant);
	}

	@Test
	public void testUpdateClaimant() throws Exception {
		final Claimant originalClaimant = new ClaimantBuilder().setId(10)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mrx")
				.setForename("mattx")
				.setMiddleName("middlex")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(0)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();
		final Claimant inputClaimant = new ClaimantBuilder().setId(10)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("matt")
				.setMiddleName("middle")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();
		
		final ClaimantDto claimantDto = new ClaimantDto();

		this.context.checking(new Expectations() {
			{
				oneOf(claimantRepository).getClaimantById(10);
				will(returnValue(originalClaimant));
				oneOf(claimantRepository).evict(originalClaimant);
				oneOf(claimantRepository).updateClaimant(inputClaimant);
				oneOf(changeLogService).saveChangeValues(10, originalClaimant, inputClaimant, 99);
				oneOf(claimantConverter).convert(inputClaimant);
				will(returnValue(claimantDto));
				oneOf(logiClaimService).sendToLogiclaim(claimantDto);

			}
		});

		this.claimantService.updateClaimant(inputClaimant, 99);
	}

	@Test
	public void testUpdateClaimantLockFromDialler() throws Exception {
		final User user = new User();
		user.setId(AGENT_ID);
		final String content = "Claimant removed from dialling";
		final ClaimantInteraction ppiClaimantInteraction = ClaimantInteraction.newEvent(CLAIMANT_ID, ProductType.PPI.getId(), user, content, Source.CLAIMANT);
		final ClaimantInteraction pbaClaimantInteraction = ClaimantInteraction.newEvent(CLAIMANT_ID, ProductType.PBA.getId(), user, content, Source.CLAIMANT);

		final Claimant originalClaimant = new ClaimantBuilder().setId(CLAIMANT_ID)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mrx")
				.setForename("mattx")
				.setMiddleName("middlex")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(0)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.setLockedFromDialler(false)
				.createClaimant();
		final Claimant inputClaimant = new ClaimantBuilder().setId(CLAIMANT_ID)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("matt")
				.setMiddleName("middle")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.setLockedFromDialler(true)
				.createClaimant();

		final ClaimantDto claimantDto = new ClaimantDto();

		this.context.checking(new Expectations() {
			{
				oneOf(claimantRepository).getClaimantById(CLAIMANT_ID);
				will(returnValue(originalClaimant));
				oneOf(claimantRepository).evict(originalClaimant);
				oneOf(claimantRepository).updateClaimant(inputClaimant);
				oneOf(changeLogService).saveChangeValues(CLAIMANT_ID, originalClaimant, inputClaimant, AGENT_ID);
				oneOf(claimantConverter).convert(inputClaimant);
				will(returnValue(claimantDto));
				oneOf(logiClaimService).sendToLogiclaim(claimantDto);
				exactly(2).of(userService).getById(AGENT_ID);
				will(returnValue(user));
				oneOf(claimantInteractionRepository).save(ppiClaimantInteraction);
				oneOf(claimantInteractionRepository).save(pbaClaimantInteraction);
				oneOf(logiClaimAdaptorServiceWrapper).saveNote(buildNoteDto(CLAIMANT_ID, content, AGENT_ID, true));
			}
		});

		this.claimantService.updateClaimant(inputClaimant, AGENT_ID);
	}

	@Test
	public void testUpdateClaimantUnlockFromDialler() throws Exception {
		final User user = new User();
		user.setId(AGENT_ID);
		final String content = "Claimant added to dialling";
		final ClaimantInteraction ppiClaimantInteraction = ClaimantInteraction.newEvent(CLAIMANT_ID, ProductType.PPI.getId(), user, content, Source.CLAIMANT);
		final ClaimantInteraction pbaClaimantInteraction = ClaimantInteraction.newEvent(CLAIMANT_ID, ProductType.PBA.getId(), user, content, Source.CLAIMANT);

		final Claimant originalClaimant = new ClaimantBuilder().setId(CLAIMANT_ID)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mrx")
				.setForename("mattx")
				.setMiddleName("middlex")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(0)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.setLockedFromDialler(true)
				.createClaimant();
		final Claimant inputClaimant = new ClaimantBuilder().setId(CLAIMANT_ID)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("matt")
				.setMiddleName("middle")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.setLockedFromDialler(false)
				.createClaimant();

		final ClaimantDto claimantDto = new ClaimantDto();

		this.context.checking(new Expectations() {
			{
				oneOf(claimantRepository).getClaimantById(CLAIMANT_ID);
				will(returnValue(originalClaimant));
				oneOf(claimantRepository).evict(originalClaimant);
				oneOf(claimantRepository).updateClaimant(inputClaimant);
				oneOf(changeLogService).saveChangeValues(CLAIMANT_ID, originalClaimant, inputClaimant, AGENT_ID);
				oneOf(claimantConverter).convert(inputClaimant);
				will(returnValue(claimantDto));
				oneOf(logiClaimService).sendToLogiclaim(claimantDto);
				exactly(2).of(userService).getById(AGENT_ID);
				will(returnValue(user));
				oneOf(claimantInteractionRepository).save(ppiClaimantInteraction);
				oneOf(claimantInteractionRepository).save(pbaClaimantInteraction);
				oneOf(logiClaimAdaptorServiceWrapper).saveNote(buildNoteDto(CLAIMANT_ID, content, AGENT_ID, true));
			}
		});

		this.claimantService.updateClaimant(inputClaimant, AGENT_ID);
	}

	@Test
	public void testUpdateClaimantFlagAsVulnerable() throws Exception {
		final User user = new User();
		user.setId(AGENT_ID);
		final String content = "Vulnerable Customer flag added";
		final ClaimantInteraction ppiClaimantInteraction = ClaimantInteraction.newEvent(CLAIMANT_ID, ProductType.PPI.getId(), user, content, Source.CLAIMANT);
		final ClaimantInteraction pbaClaimantInteraction = ClaimantInteraction.newEvent(CLAIMANT_ID, ProductType.PBA.getId(), user, content, Source.CLAIMANT);

		final Claimant originalClaimant = new ClaimantBuilder().setId(CLAIMANT_ID)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mrx")
				.setForename("mattx")
				.setMiddleName("middlex")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(0)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.setLockedFromDialler(false)
				.setVulnerableCustomer(false)
				.createClaimant();
		final Claimant inputClaimant = new ClaimantBuilder().setId(CLAIMANT_ID)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("matt")
				.setMiddleName("middle")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.setLockedFromDialler(true)
				.setVulnerableCustomer(true)
				.createClaimant();

		final ClaimantDto claimantDto = new ClaimantDto();

		this.context.checking(new Expectations() {
			{
				oneOf(claimantRepository).getClaimantById(CLAIMANT_ID);
				will(returnValue(originalClaimant));
				oneOf(claimantRepository).evict(originalClaimant);
				oneOf(claimantRepository).updateClaimant(inputClaimant);
				oneOf(changeLogService).saveChangeValues(CLAIMANT_ID, originalClaimant, inputClaimant, AGENT_ID);
				oneOf(claimantConverter).convert(inputClaimant);
				will(returnValue(claimantDto));
				oneOf(logiClaimService).sendToLogiclaim(claimantDto);
				exactly(2).of(userService).getById(AGENT_ID);
				will(returnValue(user));
				oneOf(claimantInteractionRepository).save(ppiClaimantInteraction);
				oneOf(claimantInteractionRepository).save(pbaClaimantInteraction);
				oneOf(logiClaimAdaptorServiceWrapper).saveNote(buildNoteDto(CLAIMANT_ID, content, AGENT_ID, true));
			}
		});

		this.claimantService.updateClaimant(inputClaimant, AGENT_ID);
	}

	@Test
	public void testUpdateClaimantRemoveVulnerableFlag() throws Exception {
		final User user = new User();
		user.setId(AGENT_ID);
		final String content = "Vulnerable Customer flag removed";
		final ClaimantInteraction ppiClaimantInteraction = ClaimantInteraction.newEvent(CLAIMANT_ID, ProductType.PPI.getId(), user, content, Source.CLAIMANT);
		final ClaimantInteraction pbaClaimantInteraction = ClaimantInteraction.newEvent(CLAIMANT_ID, ProductType.PBA.getId(), user, content, Source.CLAIMANT);

		final Claimant originalClaimant = new ClaimantBuilder().setId(CLAIMANT_ID)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mrx")
				.setForename("mattx")
				.setMiddleName("middlex")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(0)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.setLockedFromDialler(true)
				.setVulnerableCustomer(true)
				.createClaimant();
		final Claimant inputClaimant = new ClaimantBuilder().setId(CLAIMANT_ID)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("matt")
				.setMiddleName("middle")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.setLockedFromDialler(false)
				.setVulnerableCustomer(false)
				.createClaimant();

		final ClaimantDto claimantDto = new ClaimantDto();

		this.context.checking(new Expectations() {
			{
				oneOf(claimantRepository).getClaimantById(CLAIMANT_ID);
				will(returnValue(originalClaimant));
				oneOf(claimantRepository).evict(originalClaimant);
				oneOf(claimantRepository).updateClaimant(inputClaimant);
				oneOf(changeLogService).saveChangeValues(CLAIMANT_ID, originalClaimant, inputClaimant, AGENT_ID);
				oneOf(claimantConverter).convert(inputClaimant);
				will(returnValue(claimantDto));
				oneOf(logiClaimService).sendToLogiclaim(claimantDto);
				exactly(2).of(userService).getById(AGENT_ID);
				will(returnValue(user));
				oneOf(claimantInteractionRepository).save(ppiClaimantInteraction);
				oneOf(claimantInteractionRepository).save(pbaClaimantInteraction);
				oneOf(logiClaimAdaptorServiceWrapper).saveNote(buildNoteDto(CLAIMANT_ID, content, AGENT_ID, true));
			}
		});

		this.claimantService.updateClaimant(inputClaimant, AGENT_ID);
	}

	@Test
	public void testSyncClaimantToLogiClaim() throws Exception {
		final Claimant claimant = new ClaimantBuilder().setId(10)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mrx")
				.setForename("mattx")
				.setMiddleName("middlex")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();
		final ClaimantDto claimantDto = new ClaimantDto();

		this.context.checking(new Expectations() {
			{
				oneOf(claimantRepository).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
				oneOf(claimantConverter).convert(claimant);
				will(returnValue(claimantDto));
				oneOf(logiClaimService).sendToLogiclaim(claimantDto);

			}
		});

		this.claimantService.syncClaimantToLogiClaim(CLAIMANT_ID);
	}

	@Test
	public void testUpdateClaimantInConfinement() throws Exception {
		final Claimant originalClaimant = new ClaimantBuilder().setId(10)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mrx")
				.setForename("mattx")
				.setMiddleName("middlex")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();
		final Claimant inputClaimant = new ClaimantBuilder().setId(10)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("matt")
				.setMiddleName("middle")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();

		final ClaimantDto claimantDto = new ClaimantDto();

		this.context.checking(new Expectations() {
			{
				oneOf(claimantRepository).getClaimantById(10);
				will(returnValue(originalClaimant));
				oneOf(claimantRepository).evict(originalClaimant);
				oneOf(claimantRepository).updateClaimant(inputClaimant);
				oneOf(changeLogService).saveChangeValues(10, originalClaimant, inputClaimant, 99);
				oneOf(claimantConverter).convert(inputClaimant);
				will(returnValue(claimantDto));

			}
		});

		this.claimantService.updateClaimantInConfinement(inputClaimant, 99);
	}


	@Test
	public void testUpdateAddressId() {
		final Address address = new Address("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "WA14 4DZ", "k");
		address.setId(123);

		final Claimant originalClaimant = new ClaimantBuilder().setId(10)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("matt")
				.setMiddleName("middle")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(0)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();
		final Claimant inputClaimant = new ClaimantBuilder().setId(10)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("matt")
				.setMiddleName("middle")
				.setSurname("matty")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(123)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();

		this.context.checking(new Expectations() {
			{
				oneOf(claimantRepository).getClaimantById(10);
				will(returnValue(originalClaimant));
				oneOf(claimantRepository).updateClaimant(inputClaimant);
			}
		});

		this.claimantService.updateAddressId(10, address);
	}

	@Test
	public void testLockClaimantNoExistingClaimantLog() throws Exception {

		final ClaimantLog newClaimantLog = new ClaimantLog(10, 1, NOW, null, 100);
		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantLogRepository).getClaimantLogByClaimantId(10);
				will(returnValue(null));
				oneOf(ClaimantServiceTest.this.claimantLogRepository).createClaimantLog(newClaimantLog);
			}
		});

		final ClaimantLog result = this.claimantService.lockClaimant(10, 100, 1);
		assertThat(result.isLocked(), is(true));
	}

	@Test
	public void testLockClaimantClaimantAlreadyLockedByDifferentUser() throws Exception {

		final ClaimantLog lockedClaimantLog = new ClaimantLog(10, 1, new LocalDateTime(2014, 10, 5, 14, 0, 0, 0), null, 99);
		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantLogRepository).getClaimantLogByClaimantId(10);
				will(returnValue(lockedClaimantLog));
			}
		});

		final ClaimantLog result = this.claimantService.lockClaimant(10, 100, 1);
		assertThat(result.isLocked(), is(true));
		assertThat(result.getUserId(), is(99));
	}

	@Test
	public void testLockClaimantClaimantAlreadyLockedBySameUser() throws Exception {

		final ClaimantLog lockedClaimantLog = new ClaimantLog(10, 1, new LocalDateTime(2014, 10, 5, 14, 0, 0, 0), null, 100);
		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantLogRepository).getClaimantLogByClaimantId(10);
				will(returnValue(lockedClaimantLog));
			}
		});

		final ClaimantLog result = this.claimantService.lockClaimant(10, 100, 1);
		assertThat(result.isLocked(), is(true));
	}

	@Test
	public void testLockClaimantNotLocked() throws Exception {

		final ClaimantLog unlockedClaimantLog = new ClaimantLog(10, 1, new LocalDateTime(2014, 10, 5, 14, 0, 0, 0), new LocalDateTime(2014, 10, 5, 14, 30, 0, 0), 99);
		final ClaimantLog newClaimantLog = new ClaimantLog(10, 1, NOW, null, 100);
		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantLogRepository).getClaimantLogByClaimantId(10);
				will(returnValue(unlockedClaimantLog));
				oneOf(ClaimantServiceTest.this.claimantLogRepository).createClaimantLog(newClaimantLog);
			}
		});

		final ClaimantLog result = this.claimantService.lockClaimant(10, 100, 1);
		assertThat(result.isLocked(), is(true));
	}

	@Test
	public void testUnlockClaimant() {
		final ClaimantLog lockedClaimantLog = new ClaimantLog(10, 1, new LocalDateTime(2014, 10, 5, 14, 0, 0, 0), null, 100);
		final ClaimantLog newClaimantLog = new ClaimantLog(10, 1, new LocalDateTime(2014, 10, 5, 14, 0, 0, 0), NOW, 100);
		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantLogRepository).getClaimantLogByClaimantId(10);
				will(returnValue(lockedClaimantLog));
				oneOf(ClaimantServiceTest.this.claimantLogRepository).updateClaimantLog(newClaimantLog);
			}
		});

		this.claimantService.unlockClaimant(10, 100);
	}

	@Test
	public void testUnlockClaimantReturnsNullOnError() {
		final ClaimantLog nullClaimantLog = null;

		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantLogRepository).getClaimantLogByClaimantId(10);
				will(returnValue(nullClaimantLog));
			}
		});

		this.claimantService.unlockClaimant(10, 100);
	}

	/** Should only unlock if locked by current user */
	@Test
	public void testUnlockClaimantClaimantLockedBySomeoneElse() {
		final ClaimantLog lockedClaimantLog = new ClaimantLog(10, 1, new LocalDateTime(2014, 10, 5, 14, 0, 0, 0), null, 100);
		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantLogRepository).getClaimantLogByClaimantId(10);
				will(returnValue(lockedClaimantLog));
			}
		});

		assertThat(this.claimantService.unlockClaimant(10, 99), is(lockedClaimantLog));
	}

	@Test
	public void testUnlockClaimantThatIsntLocked() {
		final ClaimantLog unlockedClaimantLog = new ClaimantLog(10, 1, new LocalDateTime(2014, 10, 5, 14, 0, 0, 0), new LocalDateTime(2014, 10, 5, 14, 30, 0, 0), 100);
		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantLogRepository).getClaimantLogByClaimantId(10);
				will(returnValue(unlockedClaimantLog));
			}
		});

		this.claimantService.unlockClaimant(10, 100);
	}

	@Test
	public void testRetrieveLockStatus() {
		final ClaimantLog lockedClaimantLog = new ClaimantLog(10, 1, new LocalDateTime(2014, 10, 5, 14, 0, 0, 0), null, 100);
		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantLogRepository).getClaimantLogByClaimantId(10);
				will(returnValue(lockedClaimantLog));
			}
		});

		this.claimantService.getClaimantLog(10);
	}

	@Test
	public void testSetExistingClaimantOptIn() {
		final Claimant claimant = new ClaimantBuilder().setId(10)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("a")
				.setMiddleName("middle")
				.setSurname("surname")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(98)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();
		final ClaimantOptIn claimantOptIn = new ClaimantOptIn(claimant.getId(), false);
		final ClaimantOptIn updatedClaimantOptIn = new ClaimantOptIn(claimant.getId(), true);

		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantOptInRepository).getClaimantOptInByClaimantId(10);
				will(returnValue(claimantOptIn));
				oneOf(ClaimantServiceTest.this.claimantOptInRepository).updateOptIn(updatedClaimantOptIn);
			}
		});

		this.claimantService.setClaimantOptIn(10, true);
	}

	@Test
	public void testSetNewClaimantOptIn() {
		final ClaimantOptIn nullClaimantOptIn = null;
		final ClaimantOptIn claimantOptIn = new ClaimantOptIn(9999, true);

		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantOptInRepository).getClaimantOptInByClaimantId(9999);
				will(returnValue(nullClaimantOptIn));
				oneOf(ClaimantServiceTest.this.claimantOptInRepository).createOptIn(claimantOptIn);
			}
		});

		this.claimantService.setClaimantOptIn(9999, true);
	}

	@Test
	public void testCreateClaimantAndClaimantReferralFreePpiSeller() {
		final int addressId = 98;
		final Claimant referredClaimant = new ClaimantBuilder().setId(0)
				.setLeadId(123)
				.setTitle("mr")
				.setForename("a")
				.setMiddleName("middle")
				.setSurname("surname")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(addressId)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();
		final int referrerClaimantId = 99;
		final int sellerAccountId = 12503;

		final Claimant referrerClaimant = new Claimant() {
				private static final long serialVersionUID = -2589011968781452513L;

				@Override
			    public String getFullName() {
					return "referrer name";
				}

				@Override
			    public int getSellerAccountId() {
					return sellerAccountId;
				}
		};

		final int diallerReferenceId = 123;
		final LocalDateTime scheduledDateTime = new LocalDateTime(2014, 12, 10, 9, 30, 0);

		final int referredClaimantId = 10;
		final Claimant createdClaimant = new ClaimantBuilder().setId(referredClaimantId)
				.setLeadId(123)
				.setSellerAccountId(sellerAccountId)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("a")
				.setMiddleName("middle")
				.setSurname("surname")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(addressId)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();

		final ClaimantReferral referral = new ClaimantReferral(1, referrerClaimantId, 0, AGENT_ID, diallerReferenceId);

		final User user = new User() {
			@Override public String getFullName() {
				return "Matt Helliwell";
			}
		};
		user.setId(AGENT_ID);

		final String noteContent = "This is a note";
		final ClaimantInteraction note = ClaimantInteraction.newNote(0, null, user, noteContent, CLAIMANT);

		final ClaimantInteraction event1 = ClaimantInteraction.newEvent(referrerClaimantId, null, user, "Referred customer (0) mr a surname", CLAIMANT);
		final ClaimantInteraction event2 = ClaimantInteraction.newEvent(0, null, user, "Created Claimant 0, Referred by Customer (99): referrer name", CLAIMANT);

		this.context.checking(new Expectations() {
			{
				oneOf(claimantRepository).getClaimantById(referrerClaimantId);
				will(returnValue(referrerClaimant));

				allowing(userService).getById(AGENT_ID);
				will(returnValue(user));

				oneOf(sellerAccountService).isFreePpi(sellerAccountId);
				will(returnValue(true));

				// Create the claimant. The claimantId would be updated by this call so doesn't call getClaimantById with id of 0
				// when it is run with a real repo
				oneOf(sellerAccountService).getByAccountId(0);
				with(any(SellerAccount.class));
				oneOf(claimantRepository).createClaimant(referredClaimant);
				oneOf(claimantRepository).evict(referredClaimant);
				oneOf(claimantRepository).getClaimantById(0);
				will(returnValue(createdClaimant));

				// Create the referral
				oneOf(ClaimantServiceTest.this.claimantReferralRepository).createClaimantReferral(referral);

				// Schedule the assessment call
				oneOf(addressService).getAddressById(addressId);
				will(returnValue(null));
				oneOf(telephonyService).scheduleCall(CallRequestBuilder.createAssessmentCall(ClaimantService.PPI_NEW_CLAIMANT_REFERRAL_CALL_REASON_GROUP, 0, 0L, "mr", "a", "surname", null, null, "", scheduledDateTime));

				// create the note
				oneOf(claimantInteractionRepository).save(note);

				// Save the event for creating the referral
				oneOf(claimantInteractionRepository).save(event1);

				// Save the event for creating the claimant
				oneOf(claimantRepository).getClaimantById(referrerClaimantId);
				will(returnValue(referrerClaimant));
				oneOf(claimantInteractionRepository).save(event2);

			}
		});

		this.claimantService.createClaimantAndClaimantReferral(referredClaimant, 1, referrerClaimantId, AGENT_ID, diallerReferenceId, scheduledDateTime, noteContent);
		assertThat(referredClaimant.getFreePpi(), is(true));
	}

	@Test
	public void testCreateClaimantAndClaimantReferralNonFreePpiSeller() {
		final int addressId = 98;
		final Claimant referredClaimant = new ClaimantBuilder().setId(0)
				.setLeadId(123)
				.setTitle("mr")
				.setForename("a")
				.setMiddleName("middle")
				.setSurname("surname")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(addressId)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();

		final int referrerClaimantId = 99;
		final int sellerAccountId = 12503;
		final Claimant referrerClaimant = new Claimant() {
			private static final long serialVersionUID = -2589011968781452513L;

			@Override
			public String getFullName() {
				return "referrer name";
			}

			@Override
			public int getSellerAccountId() {
				return sellerAccountId;
			}
		};

		final int diallerReferenceId = 123;
		final LocalDateTime scheduledDateTime = new LocalDateTime(2014, 12, 10, 9, 30, 0);

		final int referredClaimantId = 10;
		final Claimant createdClaimant = new ClaimantBuilder().setId(referredClaimantId)
				.setLeadId(123)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("a")
				.setMiddleName("middle")
				.setSurname("surname")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(addressId)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();

		final ClaimantReferral referral = new ClaimantReferral(1, referrerClaimantId, 0, AGENT_ID, diallerReferenceId);

		final User user = new User() {
			@Override public String getFullName() {
				return "Matt Helliwell";
			}
		};
		user.setId(AGENT_ID);

		final String noteContent = "This is a note";
		final ClaimantInteraction note = ClaimantInteraction.newNote(0, null, user, noteContent, CLAIMANT);

		final ClaimantInteraction event1 = ClaimantInteraction.newEvent(referrerClaimantId, null, user, "Referred customer (0) mr a surname", CLAIMANT);
		final ClaimantInteraction event2 = ClaimantInteraction.newEvent(0, null, user, "Created Claimant 0, Referred by Customer (99): referrer name", CLAIMANT);

		this.context.checking(new Expectations() {
			{
				oneOf(claimantRepository).getClaimantById(referrerClaimantId);
				will(returnValue(referrerClaimant));
				
				allowing(userService).getById(AGENT_ID);
				will(returnValue(user));

				oneOf(sellerAccountService).isFreePpi(sellerAccountId);
				will(returnValue(false));

				// Create the claimant. The claimantId would be updated by this call so doesn't call getClaimantById with id of 0
				// when it is run with a real repo
				oneOf(sellerAccountService).getByAccountId(0);
				with(any(SellerAccount.class));
				oneOf(claimantRepository).createClaimant(referredClaimant);
				oneOf(claimantRepository).evict(referredClaimant);
				oneOf(claimantRepository).getClaimantById(0);
				will(returnValue(createdClaimant));

				// Create the referral
				oneOf(ClaimantServiceTest.this.claimantReferralRepository).createClaimantReferral(referral);

				// Schedule the assessment call
				oneOf(addressService).getAddressById(addressId);
				will(returnValue(null));
				oneOf(telephonyService).scheduleCall(CallRequestBuilder.createAssessmentCall(ClaimantService.PPI_NEW_CLAIMANT_REFERRAL_CALL_REASON_GROUP, 0, 0L, "mr", "a", "surname", null, null, "", scheduledDateTime));

				// create the note
				oneOf(claimantInteractionRepository).save(note);

				// Save the event for creating the referral
				oneOf(claimantInteractionRepository).save(event1);

				// Save the event for creating the claimant
				oneOf(claimantRepository).getClaimantById(referrerClaimantId);
				will(returnValue(referrerClaimant));
				oneOf(claimantInteractionRepository).save(event2);

			}
		});

		this.claimantService.createClaimantAndClaimantReferral(referredClaimant, 1, referrerClaimantId, AGENT_ID, diallerReferenceId, scheduledDateTime, noteContent);
		assertThat(referredClaimant.getSellerAccountId(), is(0));
	}

	@Test
	public void testCreateProductReferral() {
		final int claimantId = 111;
		final int addressId = 222;
		final int diallerReferenceId = 333;
		final String phoneNumber = "07777777777";
		final int productTypeId = 1;
		final String title = "Mr";
		final String firstName = "Phil";
		final String middleName = "Rodger";
		final String lastName = "Jenkins";
		final String callReasonGroup = ClaimantService.PPI_PRODUCT_REFERRAL_CALL_REASON_GROUP;
		final String noteContent = "This is a note";
		final LocalDateTime scheduledDateTime = new LocalDateTime(2014, 12, 10, 9, 30, 0);
		final Claimant claimant = new ClaimantBuilder().setId(claimantId)
				.setLeadId(1)
				.setSellerAccountId(2)
				.setSellerCompanyId(3)
				.setTitle(title)
				.setForename(firstName)
				.setMiddleName(middleName)
				.setSurname(lastName)
				.setPreviousSurname("")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(addressId)
				.setHomeTelephone("01234567890")
				.setMobileTelephone(phoneNumber)
				.setAlternativeTelephone("01234567890")
				.setWorkTelephone("01233333333")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();
		final ClaimantReferral referral = new ClaimantReferral(productTypeId, claimantId, claimantId, AGENT_ID, diallerReferenceId);

		final String eventProductReferral = String.format("Created %s product referral for claimant %s", "PPI", claimantId);

		final User user = new User() {
			@Override public String getFullName() {
				return "Matt Helliwell";
			}
		};
		user.setId(AGENT_ID);


		final ClaimantInteraction note = ClaimantInteraction.newNote(claimantId, null, user, noteContent, CLAIMANT);

		final ClaimantInteraction event1 = ClaimantInteraction.newEvent(claimantId,null,  user, String.format("Referred customer (%s) %s", claimantId, claimant.getFullName()), CLAIMANT);
		final ClaimantInteraction event2 = ClaimantInteraction.newEvent(claimantId, null, user, eventProductReferral, CLAIMANT);

		this.context.checking(new Expectations() {
			{
				allowing(userService).getById(AGENT_ID);
				will(returnValue(user));

				oneOf(claimantRepository).getClaimantById(claimantId);
				will(returnValue(claimant));

				// Create the referral
				oneOf(ClaimantServiceTest.this.claimantReferralRepository).createClaimantReferral(referral);

				// Schedule the assessment call
				oneOf(addressService).getAddressById(addressId);
				will(returnValue(null));
				oneOf(telephonyService).scheduleCall(CallRequestBuilder.createAssessmentCall(callReasonGroup, claimantId, 0L, title, firstName, lastName, phoneNumber, null, "", scheduledDateTime));

				// create the note
				oneOf(claimantInteractionRepository).save(note);

				// Save the event for creating the referral
				oneOf(claimantInteractionRepository).save(event1);

				oneOf(claimantInteractionRepository).save(event2);

			}
		});

		this.claimantService.createProductReferral(claimantId, phoneNumber, productTypeId, AGENT_ID, diallerReferenceId, scheduledDateTime, noteContent);
	}
	
	@Test
	public void testCreatePbaClaimantAndClaimantReferral() {
		final int addressId = 98;
		final Claimant referredClaimant = new ClaimantBuilder().setId(0)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("a")
				.setMiddleName("middle")
				.setSurname("surname")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(addressId)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();

		final int referrerClaimantId = 99;
		final int sellerAccountId = 555;
		final Claimant referrerClaimant = new Claimant() {
			private static final long serialVersionUID = -2589011968781452513L;

			@Override
			public String getFullName() {
				return "referrer name";
			}

			@Override
			public int getSellerAccountId() {
				return sellerAccountId;
			}
		};

		final int diallerReferenceId = 123;
		final LocalDateTime scheduledDateTime = new LocalDateTime(2014, 12, 10, 9, 30, 0);

		final int referredClaimantId = 10;
		final Claimant createdClaimant = new ClaimantBuilder().setId(referredClaimantId)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("a")
				.setMiddleName("middle")
				.setSurname("surname")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(addressId)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();

		final ClaimantReferral referral = new ClaimantReferral(2, referrerClaimantId, 0, AGENT_ID, diallerReferenceId);

		final User user = new User() {
			@Override public String getFullName() {
				return "Matt Helliwell";
			}
		};
		user.setId(AGENT_ID);

		final String noteContent = "This is a note";
		final ClaimantInteraction note = ClaimantInteraction.newNote(0, null, user, noteContent, CLAIMANT);

		final ClaimantInteraction event1 = ClaimantInteraction.newEvent(referrerClaimantId, null, user, "Referred customer (0) mr a surname", CLAIMANT);
		final ClaimantInteraction event2 = ClaimantInteraction.newEvent(0, null, user, "Created Claimant 0, Referred by Customer (99): referrer name", CLAIMANT);

		this.context.checking(new Expectations() {
			{
				oneOf(claimantRepository).getClaimantById(referrerClaimantId);
				will(returnValue(referrerClaimant));
				
				allowing(userService).getById(AGENT_ID);
				will(returnValue(user));

				oneOf(sellerAccountService).isFreePpi(sellerAccountId);
				will(returnValue(false));

				// Create the claimant. The claimantId would be updated by this call so doesn't call getClaimantById with id of 0
				// when it is run with a real repo
				oneOf(sellerAccountService).getByAccountId(1);
				with(any(SellerAccount.class));
				oneOf(claimantRepository).createClaimant(referredClaimant);
				oneOf(claimantRepository).evict(referredClaimant);
				oneOf(claimantRepository).getClaimantById(0);
				will(returnValue(createdClaimant));

				// Create the referral
				oneOf(ClaimantServiceTest.this.claimantReferralRepository).createClaimantReferral(referral);

				// Schedule the assessment call
				oneOf(addressService).getAddressById(addressId);
				will(returnValue(null));
				oneOf(telephonyService).scheduleCall(CallRequestBuilder.createAssessmentCall(ClaimantService.PBA_NEW_CLAIMANT_REFERRAL_CALL_REASON_GROUP, 0, 0L, "mr", "a", "surname", null, null, "", scheduledDateTime));

				// create the note
				oneOf(claimantInteractionRepository).save(note);

				// Save the event for creating the referral
				oneOf(claimantInteractionRepository).save(event1);

				// Save the event for creating the claimant
				oneOf(claimantRepository).getClaimantById(referrerClaimantId);
				will(returnValue(referrerClaimant));
				oneOf(claimantInteractionRepository).save(event2);

			}
		});

		this.claimantService.createClaimantAndClaimantReferral(referredClaimant, 2, referrerClaimantId, AGENT_ID, diallerReferenceId, scheduledDateTime, noteContent);
	}

	@Test
	public void testGetClaimantReferralByReferreeId() {
		final ClaimantReferral referral = new ClaimantReferral(1, 10, 0, 90119, 123);

		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantReferralRepository).getClaimantReferralByReferreeId(90119);
				will(returnValue(referral));
			}
		});

		this.claimantService.getClaimantReferralByReferreeId(90119);
	}

	@Test
	public void testGetClaimantReferralsByReferreeIds() {
		final ClaimantReferral referral = new ClaimantReferral(1, 10, 0, 90119, 123);

		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantReferralRepository).getClaimantReferralsByReferreeIds(ImmutableList.of(90119));
				will(returnValue(ImmutableList.of(referral)));
			}
		});

		this.claimantService.getClaimantReferralsByReferreeIds(ImmutableList.of(90119));
	}

	@Test
	public void testSearchForClaimantBySurname() {
		final List<Claimant> claimants = ImmutableList.of(new ClaimantBuilder().setId(10)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("a")
				.setMiddleName("middle")
				.setSurname("surname")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(98)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant(),
				new ClaimantBuilder().setId(11)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("b")
				.setMiddleName("")
				.setSurname("surname")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1960, 2, 20))
				.setAddressId(99)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me2@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant()
		);

		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantRepository).searchForClaimantBySurname("surname%");
				will(returnValue(claimants));
				oneOf(ClaimantServiceTest.this.addressService).getAddressById(98);
				oneOf(ClaimantServiceTest.this.addressService).getAddressById(99);
			}
		});

		this.claimantService.searchForClaimantBySurname("surname");
	}

	@Test
	public void testSearchForClaimantByTelephoneNumber() {
		final List<Claimant> claimants = ImmutableList.of(new ClaimantBuilder().setId(10)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("a")
				.setMiddleName("middle")
				.setSurname("surname")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(98)
				.setHomeTelephone("01234567890")
				.setMobileTelephone("07712345678")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant(),
				new ClaimantBuilder().setId(11)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("b")
				.setMiddleName("")
				.setSurname("surname")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1960, 2, 20))
				.setAddressId(99)
				.setHomeTelephone("07712345678")
				.setMobileTelephone("")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me2@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant()
			);

			this.context.checking(new Expectations() {
				{
					oneOf(ClaimantServiceTest.this.claimantRepository).searchForClaimantByTelephoneNumber("07712345678%");
					will(returnValue(claimants));
					oneOf(ClaimantServiceTest.this.addressService).getAddressById(98);
					oneOf(ClaimantServiceTest.this.addressService).getAddressById(99);
				}
			});

			this.claimantService.searchForClaimantByTelephoneNumber("07712345678");
	}

	@Test
	public void testSearchForClaimantByPostcode() {
		final List<Claimant> claimants = ImmutableList.of(new ClaimantBuilder().setId(10)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("a")
				.setMiddleName("middle")
				.setSurname("surname")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 20))
				.setAddressId(98)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant(),
				new ClaimantBuilder().setId(11)
				.setLeadId(123)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("b")
				.setMiddleName("")
				.setSurname("surname")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1960, 2, 20))
				.setAddressId(99)
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me2@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant()
		);

		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantRepository).searchForClaimantByPostcode("ST7%2SH%");
				will(returnValue(claimants));
				oneOf(ClaimantServiceTest.this.addressService).getAddressById(98);
				oneOf(ClaimantServiceTest.this.addressService).getAddressById(99);
			}
		});

		this.claimantService.searchForClaimantByPostcode("ST72SH");
	}


	@Test
	public void testSearchForClaimantByLongPostcode() {
		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantRepository).searchForClaimantByPostcode("ST7%2SH%");
			}
		});

		this.claimantService.searchForClaimantByPostcode("ST72SH");
	}

	@Test
	public void testSearchForClaimantByShortPostcode() {
		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantRepository).searchForClaimantByPostcode("ST%");
			}
		});

		this.claimantService.searchForClaimantByPostcode("ST");
	}

	@Test
	public void testSearchForClaimantByMediumPostcode() {
		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantRepository).searchForClaimantByPostcode("ST7%");
			}
		});

		this.claimantService.searchForClaimantByPostcode("ST7");
	}
	
	@Test
	public void testGetNotesForClaimant() {
		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantInteractionRepository).getByClaimantId(CLAIMANT_ID, ClaimantInteractionType.NOTE);
			}
		});
		
		this.claimantService.getNotesForClaimant(CLAIMANT_ID);
	}
	
	@Test
	public void testGetEventsForClaimant() {
		this.context.checking(new Expectations() {
			{
				oneOf(ClaimantServiceTest.this.claimantInteractionRepository).getByClaimantId(CLAIMANT_ID, ClaimantInteractionType.EVENT);
			}
		});
		
		this.claimantService.getEventsForClaimant(CLAIMANT_ID);
	}
	
	@Test
	public void testSavePpiNote() {
		final User user = new User();
		user.setId(USER_ID);
		final ClaimantInteraction note = ClaimantInteraction.newNote(CLAIMANT_ID, 1, user, "some content", CLAIMANT);
		this.context.checking(new Expectations() {
			{
				oneOf(userService).getById(USER_ID);
				will(returnValue(user));
				oneOf(claimantInteractionRepository).save(note);
			}
		});
		
		this.claimantService.saveNote(CLAIMANT_ID, 1, USER_ID, "some content", CLAIMANT);
	}

	@Test
	public void testSavePbaNote() {
		final User user = new User();
		user.setId(USER_ID);
		final String content = "some content";
		final ClaimantInteraction note = ClaimantInteraction.newNote(CLAIMANT_ID, 2, user, content, PAYMENTS);
		this.context.checking(new Expectations() {
			{
				oneOf(userService).getById(USER_ID);
				will(returnValue(user));
				oneOf(logiClaimAdaptorServiceWrapper).saveNote(buildNoteDto(CLAIMANT_ID, content, USER_ID, true));
				oneOf(claimantInteractionRepository).save(note);
			}
		});

		this.claimantService.saveNote(CLAIMANT_ID, 2, USER_ID, content, PAYMENTS);
	}

	@Test
	public void testSaveNoteWithInteractionDateTime() {
		final User user = new User();
		user.setId(USER_ID);
		final ClaimantInteraction note = ClaimantInteraction.newNoteWithInteractionDateTime(CLAIMANT_ID, null, user, "some content", Source.LOGICLAIM, NOW);
		this.context.checking(new Expectations() {
			{
				oneOf(userService).getById(USER_ID);
				will(returnValue(user));
				oneOf(claimantInteractionRepository).save(note);
			}
		});

		this.claimantService.saveNoteWithInteractionDateTime(CLAIMANT_ID, null, USER_ID, "some content", Source.LOGICLAIM, NOW);
	}


	@Test
	public void testUpdatePpiNote() {
		final User user = new User();
		user.setId(USER_ID);
		final int noteId = 123;
		final int noteVersion = 5;
		final ClaimantInteraction note = ClaimantInteraction.newNote(CLAIMANT_ID, 1, user, "some content", CLAIMANT);
		note.setId(noteId);
		note.setVersion(noteVersion);

		this.context.checking(new Expectations() {
			{
				oneOf(userService).getById(USER_ID);
				will(returnValue(user));
				oneOf(claimantInteractionRepository).update(note);
			}
		});

		this.claimantService.updateNote(noteId, CLAIMANT_ID, 1, USER_ID, "some content", CLAIMANT, noteVersion);
	}

	@Test
	public void testUpdatePbaNote() {
		final User user = new User();
		user.setId(USER_ID);
		final String content = "some content";
		final int noteId = 123;
		final int noteVersion = 5;
		final ClaimantInteraction note = ClaimantInteraction.newNote(CLAIMANT_ID, 2, user, content, PAYMENTS);
		note.setId(noteId);
		note.setVersion(noteVersion);

		this.context.checking(new Expectations() {
			{
				oneOf(userService).getById(USER_ID);
				will(returnValue(user));
				oneOf(logiClaimAdaptorServiceWrapper).saveNote(buildNoteDto(CLAIMANT_ID, content, USER_ID, false));
				oneOf(claimantInteractionRepository).update(note);
			}
		});

		this.claimantService.updateNote(noteId, CLAIMANT_ID, 2, USER_ID, content, PAYMENTS, noteVersion);
	}

	@Test
	public void testSaveEvent() {
		final User user = new User();
		user.setId(USER_ID);
		final ClaimantInteraction event = ClaimantInteraction.newEvent(CLAIMANT_ID, null, user, "some event content", CLAIMANT);
		this.context.checking(new Expectations() {
			{
				oneOf(userService).getById(USER_ID);
				will(returnValue(user));
				oneOf(claimantInteractionRepository).save(event);
			}
		});
		
		this.claimantService.saveEvent(CLAIMANT_ID, null, USER_ID, "some event content", CLAIMANT);
	}

	@Test
	public void testSaveEventPba() {
		final User user = new User();
		user.setId(USER_ID);
		final String content = "some event content";
		final ClaimantInteraction event = ClaimantInteraction.newEvent(CLAIMANT_ID, 2, user, content, PAYMENTS);
		this.context.checking(new Expectations() {
			{
				oneOf(userService).getById(USER_ID);
				will(returnValue(user));
				oneOf(logiClaimAdaptorServiceWrapper).saveNote(buildNoteDto(CLAIMANT_ID, content, USER_ID, true));
				oneOf(claimantInteractionRepository).save(event);
			}
		});

		this.claimantService.saveEvent(CLAIMANT_ID, 2, USER_ID, content, PAYMENTS);
	}

	@Test
	public void getEventsForClaimantBySources() {
		List<String> sources = newArrayList("PAYMENTS", "CLAIMANT", "PORTAL");
		final User user = new User();
		user.setId(USER_ID);
		final ClaimantInteraction event = ClaimantInteraction.newEvent(CLAIMANT_ID, 1,user, "some event content", CLAIMANT);
		this.context.checking(new Expectations() {
			{
				oneOf(claimantInteractionRepository).getByClaimantIdBySources(CLAIMANT_ID, ClaimantInteractionType.EVENT ,sources,1);
				will(returnValue(newArrayList(event)));
			}
		});

		this.claimantService.getEventsForClaimantBySources(CLAIMANT_ID, sources,1);
	}

	@Test
	public void getNotesForClaimantBySources() {
		List<String> sources = newArrayList("PAYMENTS", "CLAIMANT", "PORTAL");
		final User user = new User();
		user.setId(USER_ID);
		final ClaimantInteraction event = ClaimantInteraction.newNote(CLAIMANT_ID, 1, user, "some event content", CLAIMANT);
		this.context.checking(new Expectations() {
			{
				oneOf(claimantInteractionRepository).getByClaimantIdBySources(CLAIMANT_ID, ClaimantInteractionType.NOTE ,sources,1);
				will(returnValue(newArrayList(event)));
			}
		});

		this.claimantService.getNotesForClaimantBySources(CLAIMANT_ID, sources,1);
	}
}
