package com.leadx.claimant.selleraccountservice;

import static com.leadx.test.MockUtils.mockAndSetOn;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.concurrent.Synchroniser;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.leadx.claimant.client.*;
import com.leadx.lib.utl.json.JsonUtils;

@SuppressWarnings("unqualified-field-access")
public class SellerAccountControllerUnitTest {

	private SellerAccountController sellerAcccountController;
	private SellerAccountService sellerAccountService;
	private SellerAccountDtoConverter sellerAccountDtoConverter;
	private SellerAccountConverter sellerAccountConverter;

	private static final int SELLER_ACCOUNT_ID = 9785;

	private final Synchroniser synchroniser = new Synchroniser();

	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
			setThreadingPolicy(SellerAccountControllerUnitTest.this.synchroniser);
		}
	};

	@Before
	public void setUp() {
		this.sellerAcccountController = new SellerAccountController();

		this.sellerAccountService = mockAndSetOn(this.context, SellerAccountService.class, this.sellerAcccountController);
		this.sellerAccountDtoConverter = mockAndSetOn(this.context, SellerAccountDtoConverter.class, this.sellerAcccountController);
		this.sellerAccountConverter = mockAndSetOn(this.context, SellerAccountConverter.class, this.sellerAcccountController);
	}

	@Test
	public void testCreateSellerAccount() {
		final SellerAccount sellerAccount = newDummySellerAccount();
		final SellerAccountDto sellerAccountDto = newDummySellerAccountDto();

		this.context.checking(new Expectations() {
			{
				oneOf(sellerAccountDtoConverter).convert(sellerAccountDto);
				will(returnValue(sellerAccount));
				oneOf(sellerAccountService).create(sellerAccount);
			}
		});

		this.sellerAcccountController.createSellerAccount(JsonUtils.serialize(sellerAccountDto, false));
	}

	@Test
	public void testCreateSellerAccountHandlesException() {
		final SellerAccount sellerAccount = newDummySellerAccount();
		final SellerAccountDto sellerAccountDto = newDummySellerAccountDto();

		this.context.checking(new Expectations() {
			{
				oneOf(sellerAccountDtoConverter).convert(sellerAccountDto);
				will(returnValue(sellerAccount));
				oneOf(sellerAccountService).create(sellerAccount);
				will(throwException(new Exception()));
			}
		});

		final ResponseEntity<String> response =
				this.sellerAcccountController.createSellerAccount(JsonUtils.serialize(sellerAccountDto, false));

		assertThat(response.getStatusCode(), is(HttpStatus.INTERNAL_SERVER_ERROR));
	}

	@Test
	public void testUpdateSellerAccount() {
		final SellerAccount sellerAccount = newDummySellerAccount();
		final SellerAccountDto sellerAccountDto = newDummySellerAccountDto();

		this.context.checking(new Expectations() {
			{
				oneOf(sellerAccountDtoConverter).convert(sellerAccountDto);
				will(returnValue(sellerAccount));
				oneOf(sellerAccountService).update(sellerAccount);
			}
		});

		this.sellerAcccountController.updateSellerAccount(JsonUtils.serialize(sellerAccountDto, false));
	}

	@Test
	public void testUpdateSellerAccountHandlesException() {
		final SellerAccount sellerAccount = newDummySellerAccount();
		final SellerAccountDto sellerAccountDto = newDummySellerAccountDto();

		this.context.checking(new Expectations() {
			{
				oneOf(sellerAccountDtoConverter).convert(sellerAccountDto);
				will(returnValue(sellerAccount));
				oneOf(sellerAccountService).update(sellerAccount);
				will(throwException(new Exception()));
			}
		});

		final ResponseEntity<String> response =
				this.sellerAcccountController.updateSellerAccount(JsonUtils.serialize(sellerAccountDto, false));

		assertThat(response.getStatusCode(), is(HttpStatus.INTERNAL_SERVER_ERROR));
	}

	@Test
	public void testGetById() {
		final SellerAccount expectedSellerAccount = newDummySellerAccount();

		this.context.checking(new Expectations() {
			{
				oneOf(sellerAccountService).getByAccountId(SELLER_ACCOUNT_ID);
				will(returnValue(expectedSellerAccount));
				oneOf(sellerAccountConverter).convert(expectedSellerAccount);
				will(returnValue(newDummySellerAccountDto()));
			}
		});

		final SellerAccountDto sellerAccountDto = this.sellerAcccountController.getByAccountId(SELLER_ACCOUNT_ID);
		assertThat(sellerAccountDto.getAccountId(), is(SELLER_ACCOUNT_ID));
		assertThat(sellerAccountDto.getGpSellerAccount(), is("SWINTON"));
		assertThat(sellerAccountDto.getName(), is("Swinton"));
		assertThat(sellerAccountDto.getDisplayName(), is("Swinton"));
		assertThat(sellerAccountDto.getSourceDescription(), is("Partner introduction"));
		assertThat(sellerAccountDto.getApplicationLogo(), is("SWINTON_LOGO.swf"));
		assertThat(sellerAccountDto.getPackType(), is("tcg_pack_swinton"));
		assertThat(sellerAccountDto.getDistributeAppointmentReminder(), is(true));
		assertThat(sellerAccountDto.getAssessmentCallReasonGroup(), is("swinton"));
		assertThat(sellerAccountDto.getAssessmentInitialSmsMessageScript(), is("DirectUploadClaimAppointmentSmsScript"));
		assertThat(sellerAccountDto.getAssessmentInitialEmailMessageScript(), is("DirectUploadPartnerClaimAppointmentEmailScript"));
		assertThat(sellerAccountDto.getEmailIconImageName(), is("swinton.jpg"));
	}

	@Test
	public void testGetByIdReturnsNull() {
		final SellerAccount expectedSellerAccount = null;

		this.context.checking(new Expectations() {
			{
				oneOf(sellerAccountService).getByAccountId(99999);
				will(returnValue(expectedSellerAccount));
				oneOf(sellerAccountConverter).convert(expectedSellerAccount);
				will(returnValue(null));
			}
		});

		final SellerAccountDto sellerAccountDto = this.sellerAcccountController.getByAccountId(99999);
		assertThat(sellerAccountDto, is(nullValue()));
	}

	@Test
	public void testGetAllSellerAccounts() {
		final SellerAccount expectedSellerAccount = newDummySellerAccount();
		final List<SellerAccount> expectedSellerAccounts = ImmutableList.of(expectedSellerAccount);

		this.context.checking(new Expectations() {
			{
				oneOf(sellerAccountService).getAll();
				will(returnValue(expectedSellerAccounts));
				oneOf(sellerAccountConverter).convert(expectedSellerAccount);
				will(returnValue(newDummySellerAccountDto()));
			}
		});

		final List<SellerAccountDto> sellerAccounts = this.sellerAcccountController.getAll();
		assertThat(sellerAccounts.size(), is(1));

		final SellerAccountDto sellerAccountDto = sellerAccounts.get(0);
		assertThat(sellerAccountDto.getAccountId(), is(SELLER_ACCOUNT_ID));
		assertThat(sellerAccountDto.getGpSellerAccount(), is("SWINTON"));
		assertThat(sellerAccountDto.getName(), is("Swinton"));
		assertThat(sellerAccountDto.getDisplayName(), is("Swinton"));
		assertThat(sellerAccountDto.getSourceDescription(), is("Partner introduction"));
		assertThat(sellerAccountDto.getApplicationLogo(), is("SWINTON_LOGO.swf"));
		assertThat(sellerAccountDto.getPackType(), is("tcg_pack_swinton"));
		assertThat(sellerAccountDto.getDistributeAppointmentReminder(), is(true));
		assertThat(sellerAccountDto.getAssessmentCallReasonGroup(), is("swinton"));
		assertThat(sellerAccountDto.getAssessmentInitialSmsMessageScript(), is("DirectUploadClaimAppointmentSmsScript"));
		assertThat(sellerAccountDto.getAssessmentInitialEmailMessageScript(), is("DirectUploadPartnerClaimAppointmentEmailScript"));
		assertThat(sellerAccountDto.getEmailIconImageName(), is("swinton.jpg"));
	}

	@Test
	public void testGetSourcedSellerAccounts() {
		final SellerAccount expectedSellerAccount = newDummySellerAccount();
		final List<SellerAccount> expectedSellerAccounts = ImmutableList.of(expectedSellerAccount);

		this.context.checking(new Expectations() {
			{
				oneOf(sellerAccountService).getSourcedSellerAccounts();
				will(returnValue(expectedSellerAccounts));
				oneOf(sellerAccountConverter).convert(expectedSellerAccount);
				will(returnValue(newDummySellerAccountDto()));
			}
		});

		final List<SellerAccountDto> sellerAccounts = this.sellerAcccountController.getSourcedSellerAccounts();
		assertThat(sellerAccounts.size(), is(1));

		final SellerAccountDto sellerAccount = sellerAccounts.get(0);
		assertThat(sellerAccount.getAccountId(), is(SELLER_ACCOUNT_ID));
		assertThat(sellerAccount.getGpSellerAccount(), is("SWINTON"));
		assertThat(sellerAccount.getName(), is("Swinton"));
		assertThat(sellerAccount.getDisplayName(), is("Swinton"));
		assertThat(sellerAccount.getSourceDescription(), is("Partner introduction"));
		assertThat(sellerAccount.getApplicationLogo(), is("SWINTON_LOGO.swf"));
		assertThat(sellerAccount.getPackType(), is("tcg_pack_swinton"));
		assertThat(sellerAccount.getDistributeAppointmentReminder(), is(true));
		assertThat(sellerAccount.getAssessmentCallReasonGroup(), is("swinton"));
		assertThat(sellerAccount.getAssessmentInitialSmsMessageScript(), is("DirectUploadClaimAppointmentSmsScript"));
		assertThat(sellerAccount.getAssessmentInitialEmailMessageScript(), is("DirectUploadPartnerClaimAppointmentEmailScript"));
		assertThat(sellerAccount.getEmailIconImageName(), is("swinton.jpg"));
	}

	@SuppressWarnings("unused")
	@Test
	public void testGetDropdownItemsForField() {
		final List<DropdownConfiguration> expected = Lists.newArrayList();

		this.context.checking(new Expectations() {
			{
				oneOf(sellerAccountService).getDropdownItemsForField("seller_gpSellerAccount");
				will(returnValue(expected));
			}
		});

		final List<DropdownConfigurationDto> result = this.sellerAcccountController.getDropdownItemsForField("seller_gpSellerAccount");
	}

	@Test
	public void isFreePpi() {
		final int sellerAccountId = 1234;
		final boolean freePpi = true;
		this.context.checking(new Expectations() {
			{
				oneOf(sellerAccountService).isFreePpi(sellerAccountId);
				will(returnValue(freePpi));
			}
		});

		boolean result = this.sellerAcccountController.isFreePpi(sellerAccountId);
		assertTrue(result);
	}

	private static SellerAccount newDummySellerAccount() {
		final SellerAccount acc = new SellerAccount(SELLER_ACCOUNT_ID, "SWINTON", "Swinton", "Swinton", "Partner introduction", MethodOfContact.telephone, "SWINTON_LOGO.swf", "tcg_pack_swinton", true, "swinton", "DirectUploadClaimAppointmentSmsScript", "DirectUploadPartnerClaimAppointmentEmailScript", "swinton.jpg", false);
		final ProductType selected = new ProductType(1, "ppi");
		acc.setProductType(selected);
		acc.setInboundNumbers(ImmutableList.of("1234"));
		return acc;
	}

	private static SellerAccountDto newDummySellerAccountDto() {
		final ProductTypeDto selected = new ProductTypeDto(1, "ppi", true);
		final LeadTypeDto leadTypeDto = new LeadTypeDto(1, "BAU Text Lead");
		return new SellerAccountDto(0, SELLER_ACCOUNT_ID, "SWINTON", "Swinton", "Swinton", "Partner introduction", MethodOfContact.telephone, "SWINTON_LOGO.swf", "tcg_pack_swinton", true, "swinton", "DirectUploadClaimAppointmentSmsScript", "DirectUploadPartnerClaimAppointmentEmailScript", "swinton.jpg", ImmutableList.<String>of(""), selected, false, leadTypeDto);
	}

}
