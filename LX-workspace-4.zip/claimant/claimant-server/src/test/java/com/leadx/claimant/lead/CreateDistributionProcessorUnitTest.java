package com.leadx.claimant.lead;

import static com.leadx.test.MockUtils.mockAndSetOn;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.concurrent.Synchroniser;
import org.jmock.lib.legacy.ClassImposteriser;
import org.joda.time.DateTime;
import org.joda.time.DateTimeUtils;
import org.junit.Before;
import org.junit.Test;

import com.leadx.claimant.applicationpropertyservice.ApplicationPropertyService;
import com.leadx.claimant.client.ClaimantLead;
import com.leadx.claimant.client.MethodOfContact;
import com.leadx.claimant.selleraccountservice.ProductType;
import com.leadx.claimant.selleraccountservice.SellerAccount;
import com.leadx.claimant.selleraccountservice.SellerAccountService;
import com.leadx.lib.utl.JodaUtils;
import com.leadx.services.claims.client.ClaimRequest.ClaimRequestBuilder;
import com.leadx.services.distribution.client.DistributionClient;
import com.leadx.services.distribution.client.DistributionRequest;
import com.leadx.services.distribution.client.DistributionRequest.DistributionRequestBuilder;

@SuppressWarnings("unqualified-field-access")
public class CreateDistributionProcessorUnitTest {

	private CreateDistributionProcessor createDistributionProcessor;

	private SellerAccountService sellerAccountService;
	private DistributionClient distributionClient;
	private ApplicationPropertyService applicationPropertyService;

	private static final int CLAIMANT_ID = 1234;
	private static final int ACCOUNT_ID = 5678;
	private static final String CALL_REASON_GROUP = "some call reason group";

	private final Synchroniser synchroniser = new Synchroniser();

	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
			setThreadingPolicy(synchroniser);
		}
	};

	@Before
	public void setUp() {
		this.createDistributionProcessor = new CreateDistributionProcessor();

		this.sellerAccountService = mockAndSetOn(this.context, SellerAccountService.class, this.createDistributionProcessor);
		this.distributionClient = mockAndSetOn(this.context, DistributionClient.class, this.createDistributionProcessor);
		this.applicationPropertyService = mockAndSetOn(this.context, ApplicationPropertyService.class, this.createDistributionProcessor);

		DateTimeUtils.setCurrentMillisFixed(new DateTime(2014, 11, 27, 13, 5, 44, 0).getMillis());
	}

	@Test
	public void shouldDistributeBothSmsAndEmail() throws Exception {
		final ClaimRequestBuilder crb = new ClaimRequestBuilder();
		crb.sellerAccountId(ACCOUNT_ID);
		crb.claimant().mobileTelephone("07777777777");
		crb.claimant().forename("TestForename");
		crb.claimant().email("some@email.com");
		crb.appointment().requestedDateTime(JodaUtils.newCurrentDateTime());

		final ClaimantLead claimantLead = new ClaimantLead(crb.build(), CLAIMANT_ID);
		final SellerAccount sellerAccount = newDummySellerAccount("ClaimsGuysEmail", "Sms", MethodOfContact.telephone);

		final ProductType productType = new ProductType(1, "ppi");
		sellerAccount.setProductType(productType);

		final DistributionRequest smsDistributionRequest = newDummySmsDistributionRequest(claimantLead);
		final DistributionRequest emailDistributionRequest = newDummyEmailDistributionRequest(claimantLead);

		this.context.checking(new Expectations() {
			{
				oneOf(sellerAccountService).getByAccountId(ACCOUNT_ID);
				will(returnValue(sellerAccount));
				oneOf(applicationPropertyService).get("distribution.scripts.welcomeEmail");
				will(returnValue("ClaimsGuysEmail.groovy?emailId=4445"));
				oneOf(applicationPropertyService).get("distribution.scripts.welcomeSms");
				will(returnValue("Sms.groovy?smsId=4441"));
				exactly(2).of(applicationPropertyService).get("distribution.scripts.contactPhoneNumber");
				will(returnValue(""));
				oneOf(distributionClient).distribute(smsDistributionRequest);
				oneOf(distributionClient).distribute(emailDistributionRequest);
			}
		});

		this.createDistributionProcessor.createWebDistributionFlow(claimantLead);
	}

	@Test
	public void shouldDistributePackOutEmail() throws Exception {
		final ClaimRequestBuilder crb = new ClaimRequestBuilder();
		crb.sellerAccountId(ACCOUNT_ID);
		crb.claimant().mobileTelephone("07777777777");
		crb.claimant().forename("TestForename");
		crb.claimant().email("some@email.com");
		crb.appointment().requestedDateTime(JodaUtils.newCurrentDateTime());

		final ClaimantLead claimantLead = new ClaimantLead(crb.build(), CLAIMANT_ID);
		final SellerAccount sellerAccount = newDummySellerAccount("ClaimsGuysEmail", "Sms", MethodOfContact.post);

		final ProductType productType = new ProductType(1, "ppi");
		sellerAccount.setProductType(productType);

		final DistributionRequest emailDistributionRequest = newDummyEmailDistributionRequestForPostalContacts(claimantLead);

		this.context.checking(new Expectations() {
			{
				oneOf(sellerAccountService).getByAccountId(ACCOUNT_ID);
				will(returnValue(sellerAccount));
				oneOf(applicationPropertyService).get("distribution.scripts.packOutEmailPostalContact");
				will(returnValue("ClaimsGuysEmail.groovy?emailId=4446"));
				oneOf(applicationPropertyService).get("distribution.scripts.contactPhoneNumber");
				will(returnValue(""));
				oneOf(distributionClient).distribute(emailDistributionRequest);
			}
		});

		this.createDistributionProcessor.createWebDistributionFlow(claimantLead);
	}

	private static DistributionRequest newDummyEmailDistributionRequest(final ClaimantLead claimantLead) {
		final DistributionRequest appointmentEmailRequest = new DistributionRequestBuilder()
			.reference(claimantLead.getClaimantId())
			.buyerAccountId(0)
			.flow(30)
			.step(1)
			.script("ClaimsGuysEmail.groovy?emailId=4445")
			.parameter("emailAddress", claimantLead.getClaimRequest().getClaimant().getEmail())
			.parameter("forename", claimantLead.getClaimRequest().getClaimant().getForename())
			.parameter("activeProducts", "PPI")
			.parameter("contactPhoneNumber", "")
			.build();

		return appointmentEmailRequest;
	}

	private static DistributionRequest newDummyEmailDistributionRequestForPostalContacts(final ClaimantLead claimantLead) {
		final DistributionRequest appointmentEmailRequest = new DistributionRequestBuilder()
				.reference(claimantLead.getClaimantId())
				.buyerAccountId(0)
				.flow(34)
				.step(1)
				.script("ClaimsGuysEmail.groovy?emailId=4446")
				.parameter("emailAddress", claimantLead.getClaimRequest().getClaimant().getEmail())
				.parameter("forename", claimantLead.getClaimRequest().getClaimant().getForename())
				.parameter("activeProducts", "PPI")
				.parameter("contactPhoneNumber", "")
				.build();

		return appointmentEmailRequest;
	}

	private static DistributionRequest newDummySmsDistributionRequest(final ClaimantLead claimantLead) {
		final DistributionRequest appointmentSmsRequest = new DistributionRequestBuilder()
				.reference(claimantLead.getClaimantId())
				.buyerAccountId(0)
				.flow(31)
				.step(1)
				.script("Sms.groovy?smsId=4441")
				.parameter("mobile", claimantLead.getClaimRequest().getClaimant().getMobileTelephone())
				.parameter("firstname", claimantLead.getClaimRequest().getClaimant().getForename())
				.parameter("activeProducts", "PPI")
				.parameter("contactPhoneNumber", "")
				.build();

		return appointmentSmsRequest;
	}

	private static SellerAccount newDummySellerAccount(final String smsScript, final String emailScript, MethodOfContact methodOfContact) {
		final SellerAccount sellerAccount =
				new SellerAccount(ACCOUNT_ID, "", "", "", "", methodOfContact, "", "", true, CALL_REASON_GROUP, smsScript, emailScript, "", false);

		sellerAccount.setAccountId(ACCOUNT_ID);
		sellerAccount.setAssessmentCallReasonGroup(CALL_REASON_GROUP);

		return sellerAccount;
	}

}
