package com.leadx.claimant.callallocationservice;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

public class ClaimantGroupAllocationDtoConverterUnit {

	@Test
	public void testConvert() throws Exception {
		final ClaimantGroupAllocationDtoConverter converter = new ClaimantGroupAllocationDtoConverter();
		final ClaimantGroupAllocationDto claimantGroupAllocationDto = new ClaimantGroupAllocationDto(12345, "chase test", "PPI Only");
		final ClaimantGroupAllocation claimantGroupAllocation = converter.convert(claimantGroupAllocationDto);

		assertThat(claimantGroupAllocation.getClaimantId(), is(12345));
		assertThat(claimantGroupAllocation.getCallReason(), is("chase test"));
		assertThat(claimantGroupAllocation.getCallReasonGroup(), is("PPI Only"));



	}







}
