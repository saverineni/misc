package com.leadx.claimant.lead;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SuppressWarnings("unused")
public class IncomingLeadCaller extends Thread {

	private static final Logger LOG = LoggerFactory.getLogger(IncomingLeadCaller.class);
	private final int timesToRun;
	private final int delay;
	private final String threadName;
	private final String host;

	private static final String LOCAL_HOST = 		"tcp://localhost:61616";
	private static final String ZIDANE_HOST = 	"tcp://zidane.dev.aws.eu.leadx.co.uk:61616";
	private static final String ZAMORA_HOST = 	"tcp://zamora.dev.aws.eu.leadx.co.uk:61616";
	private static final String ZOLA_HOST = 		"tcp://zola.dev.aws.eu.leadx.co.uk:61616";
	private static final String MIRROR_HOST = 	"tcp://mirror.dev.aws.eu.leadx.co.uk:61616";

	private static final String queueName = "leadservices-claimant-leads";

	public IncomingLeadCaller(final int timesToRun, final int delay, final String threadName) {

		this.timesToRun = timesToRun;
		this.delay = delay;
		this.threadName = threadName;
		this.host = ZAMORA_HOST;
	}

	@Override
	public void run() {
		try {
			for (int i = 0; i < this.timesToRun; i++) {
				//gen params
				final String params = generateLeadParams(this.threadName, i);
				try {
					//msg to q
					sendJMS(params, this.threadName, i, this.host);
				}
				catch (final JMSException e) {
					LOG.error(e.getMessage());
				}
				Thread.sleep(this.delay);
			}
		}
		catch (final InterruptedException ie) {
			// no problem
		}
	}


	public static void main(final String[] args) {
		final int numThreads = 10;
		final int numRunsPerThread = 10;
		final int threadRunDelay = 10;

		for (int j = 0; j < numThreads; j++) {
			new IncomingLeadCaller(numRunsPerThread, threadRunDelay, "" + j).start();
		}
	}

	private static void sendJMS(final String params, final String threadName, final int iteration, final String hostURL) throws JMSException {
        // Getting JMS connection from the server and starting it
        final ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(hostURL);
        final Connection connection = connectionFactory.createConnection();
        connection.start();

        // JMS messages are sent and received using a Session. We will
        // create here a non-transactional session object. If you want
        // to use transactions you should set the first parameter to 'true'
        final Session session = connection.createSession(false,
            Session.AUTO_ACKNOWLEDGE);

        // Destination represents our queue. You don't have to do anything special on the
        // server to create it, it will be created automatically.
        final Destination destination = session.createQueue(queueName);

        // MessageProducer is used for sending messages (as opposed
        // to MessageConsumer which is used for receiving them)
        final MessageProducer producer = session.createProducer(destination);

        // Create the message
        final TextMessage message = session.createTextMessage(params);

        // Send the message
        producer.send(message);
        LOG.info("Thread: " + threadName + "\nIteration: " + iteration);

        connection.close();
	}

	private static String generateLeadParams(final String threadName, final int iteration) {
		return "{\"leadId\" : 15004375," +
  "\"transactionDetailId\" : 252348401," +
  "\"sellerAccountId\" : 100," +
  "\"sellerCompanyId\" : 1," +
  "\"assignedClaimConsultantId\" : 0," +
  "\"note\" : \"Claim created from TCG website\"," +
  "\"requestDateTime\" : \"2014-10-01 10:52:16\"," +
  "\"claimant\" : {" +
    "\"title\" : \"Mr\"," +
    "\"forename\" : \"" + threadName + "jim\"," +
    "\"surname\" : \"" + threadName + "smith\"," +
    "\"dob\" : \"1980-11-21\"," +
    "\"homeTelephone\" : \"0161456788" + iteration + "\"," +
    "\"mobileTelephone\" : \"0798965431" + iteration + "\"," +
    "\"email\" : \"i" + iteration + "@t" + threadName + ".co.uk\"" +
  "}," +
  "\"address\" : {" +
    "\"departmentName\" : \"\"," +
    "\"organisationName\" : \"\"," +
    "\"buildingName\" : \"Station House\"," +
    "\"thoroughfare\" : \"Stamford New Road\"," +
    "\"postcode\" : \"WA141EP 0A0\"" +
  "}," +
  "\"appointment\" : {" +
    "\"madeBy\" : 0," +
    "\"madeByName\" : \"\"," +
    "\"requestedDateTime\" : \"2012-12-12 09:00:00\"" +
  "}" +
"}";
	}
}
