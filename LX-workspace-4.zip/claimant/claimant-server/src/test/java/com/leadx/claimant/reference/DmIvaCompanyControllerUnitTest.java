package com.leadx.claimant.reference;

import com.leadx.claimant.client.reference.DebtManagementCompanyDto;
import com.leadx.claimant.client.reference.IvaCompanyDto;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static com.google.common.collect.Lists.newArrayList;
import static com.leadx.test.MockUtils.mockAndSetOn;
import static org.jmock.lib.legacy.ClassImposteriser.INSTANCE;

@SuppressWarnings("unqualified-field-access")
public class DmIvaCompanyControllerUnitTest {

	private DmIvaCompanyController dmIvaCompanyController;

	private DebtManagementCompanyService debtManagementCompanyService;
	private IvaCompanyService ivaCompanyService;
	private DebtManagementCompanyConverter debtManagementCompanyConverter;
	private IvaCompanyConverter ivaCompanyConverter;

	private final Mockery context = new Mockery() {
		{
			setImposteriser(INSTANCE);
		}
	};
	
	@Before
	public void setUp() throws Exception {
		this.dmIvaCompanyController = new DmIvaCompanyController();
		
		this.debtManagementCompanyService = mockAndSetOn(this.context, DebtManagementCompanyService.class, this.dmIvaCompanyController);
		this.ivaCompanyService = mockAndSetOn(this.context, IvaCompanyService.class, this.dmIvaCompanyController);
		this.debtManagementCompanyConverter = mockAndSetOn(this.context, DebtManagementCompanyConverter.class, this.dmIvaCompanyController);
		this.ivaCompanyConverter = mockAndSetOn(this.context, IvaCompanyConverter.class, this.dmIvaCompanyController);
	}
	
	@Test
	public void getDebtManagementCompanies() {
		final List<DebtManagementCompany> debtManagementCompanyList = newArrayList();
		debtManagementCompanyList.add(buildDebtManagementCompany(1, "DM Company A"));
		debtManagementCompanyList.add(buildDebtManagementCompany(2, "DM Company B"));

		final List<DebtManagementCompanyDto> debtManagementCompanyDtoList = newArrayList();
		debtManagementCompanyDtoList.add(buildDebtManagementCompanyDto(1, "DM Company A"));
		debtManagementCompanyDtoList.add(buildDebtManagementCompanyDto(2, "DM Company B"));

		this.context.checking(new Expectations() {
			{
				oneOf(debtManagementCompanyService).getDebtManagementCompanies();
				will(returnValue(debtManagementCompanyList));
				oneOf(debtManagementCompanyConverter).convertList(debtManagementCompanyList);
				will(returnValue(debtManagementCompanyDtoList));
			}
		});
		
		this.dmIvaCompanyController.getDebtManagementCompanies();
	}

	@Test
	public void getIvaCompanies() {
		final List<IvaCompany> ivaCompanyList = newArrayList();
		ivaCompanyList.add(buildIvaCompany(1, "Iva Company A"));
		ivaCompanyList.add(buildIvaCompany(2, "Iva Company B"));

		final List<IvaCompanyDto> ivaCompanyDtoList = newArrayList();
		ivaCompanyDtoList.add(buildIvaCompanyDto(1, "Iva Company A"));
		ivaCompanyDtoList.add(buildIvaCompanyDto(2, "Iva Company B"));

		this.context.checking(new Expectations() {
			{
				oneOf(ivaCompanyService).getIvaCompanies();
				will(returnValue(ivaCompanyList));
				oneOf(ivaCompanyConverter).convertList(ivaCompanyList);
				will(returnValue(ivaCompanyDtoList));
			}
		});

		this.dmIvaCompanyController.getIvaCompanies();
	}

	private static DebtManagementCompany buildDebtManagementCompany(int id, String name){
		final DebtManagementCompany debtManagementCompany = new DebtManagementCompany();
		debtManagementCompany.setId(id);
		debtManagementCompany.setName(name);

		return debtManagementCompany;
	}

	private static DebtManagementCompanyDto buildDebtManagementCompanyDto(int id, String name){
		final DebtManagementCompanyDto debtManagementCompanyDto = new DebtManagementCompanyDto();
		debtManagementCompanyDto.setId(id);
		debtManagementCompanyDto.setName(name);

		return debtManagementCompanyDto;
	}

	private static IvaCompany buildIvaCompany(int id, String name){
		final IvaCompany ivaCompany = new IvaCompany();
		ivaCompany.setId(id);
		ivaCompany.setName(name);

		return ivaCompany;
	}

	private static IvaCompanyDto buildIvaCompanyDto(int id, String name){
		final IvaCompanyDto ivaCompanyDto = new IvaCompanyDto();
		ivaCompanyDto.setId(id);
		ivaCompanyDto.setName(name);

		return ivaCompanyDto;
	}
}
