package com.leadx.claimant.searchservice;

import static com.google.common.collect.Lists.newArrayList;
import static com.leadx.test.MockUtils.mockAndSetOn;
import static org.junit.Assert.assertEquals;

import java.util.List;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.concurrent.Synchroniser;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;

import com.leadx.claimant.client.search.SearchRequestDto;
import com.leadx.claimant.client.search.SearchResultClaimantDto;

public class ClaimantSearchControllerUnitTest {

	private ClaimantSearchController claimantSearchController;
	private ClaimantSearchService claimantSearchService;

	private final Synchroniser synchroniser = new Synchroniser();
	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
			setThreadingPolicy(synchroniser);
		}
	};

	@Before
	public void setUp() {
		this.claimantSearchController = new ClaimantSearchController();
		this.claimantSearchService = mockAndSetOn(this.context, ClaimantSearchService.class, this.claimantSearchController);
	}

	@Test
	public void searchSuccess() throws Exception {
		final SearchRequestDto searchRequestDto = new SearchRequestDto.Builder().setSurname("Laporte").setPhone("1234567890").createSearchRequestDto();
		final SearchResultClaimantDto searchResultClaimantDto = new SearchResultClaimantDto.Builder().setClaimantId(1111).setSurname("Laporte")
				.setPostcode("1AA AAA").createSearchResultClaimantDto();

		final List<SearchResultClaimantDto> result = newArrayList(searchResultClaimantDto);

		this.context.checking(new Expectations() {
			{
				oneOf(claimantSearchService).search(searchRequestDto);
				will(returnValue(result));
				
			}
		});

		final List<SearchResultClaimantDto> searchResultClaimantDtos = this.claimantSearchController.search(searchRequestDto);
		assertEquals(result, searchResultClaimantDtos);
	}

	@Test(expected = RuntimeException.class)
	public void searchFailure() throws Exception {
		final SearchRequestDto searchRequestDto = new SearchRequestDto.Builder().setSurname("Laporte").setPhone("1234567890").createSearchRequestDto();

		this.context.checking(new Expectations() {
			{
				oneOf(claimantSearchService).search(searchRequestDto);
				will(throwException(new IllegalArgumentException()));
			}
		});

		this.claimantSearchController.search(searchRequestDto);
	}
}
