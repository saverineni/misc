package com.leadx.claimant.selleraccountservice;

import static com.leadx.test.integration.TestDataRowCounter.assertRowCount;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.test.context.ContextConfiguration;

import com.leadx.claimant.client.MethodOfContact;
import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.NoTestData;

@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class SellerAccountServiceIntTest extends AbstractIntegrationTest {
	@Autowired
	SellerAccountService sellerAccountService;

	@Autowired
	SellerAccountRepository sellerAccountRepository;

	@Resource(name = "claimantNamedParameterJdbcOperations")
	private transient NamedParameterJdbcOperations jdbcOperations;

	@Test
	@NoTestData
	public void testCreateSellerAccount() {

		assertRowCount(this.jdbcOperations, "seller_account", 33);
		final SellerAccount sellerAccount = new SellerAccount(0,"GP_SELLER_ACC","Seller Name", "Display Name", "", MethodOfContact.telephone, "LOGO.swf","tcg_pack",false,"call_reason_group","smsScript","emailScript","email_icon.png", false);
		final ProductType selected = new ProductType(1, "ppi");
		sellerAccount.setProductType(selected);
		this.sellerAccountService.create(sellerAccount);
		assertRowCount(this.jdbcOperations, "seller_account", 34);
	}

	@Test
	@NoTestData
	public void testUpdateSellerAccount() {
		final SellerAccount sellerAccount = new SellerAccount(0,"GP_SELLER_ACC","Seller Name", "Display Name", "", MethodOfContact.telephone, "LOGO.swf","tcg_pack",false,"call_reason_group","smsScript","emailScript","email_icon.png", false);
		final ProductType selected = new ProductType(1, "ppi");
		sellerAccount.setProductType(selected);
		this.sellerAccountService.create(sellerAccount);
		this.sellerAccountRepository.evict(sellerAccount);

		sellerAccount.setName("Updated Seller Name");
		sellerAccount.setGpSellerAccount("UPDATED_SELLER");
		sellerAccount.setDisplayName("Updated Display Name");
		sellerAccount.setSourceDescription("Updated Source Description");
		sellerAccount.setApplicationLogo("UPDATED_LOGO.swf");
		sellerAccount.setPackType("updated_tcg_pack");
		sellerAccount.setDistributeAppointmentReminder(true);
		sellerAccount.setAssessmentCallReasonGroup("updated_call_reason_group");
		sellerAccount.setAssessmentInitialSmsMessageScript("updatedSmsScript");
		sellerAccount.setAssessmentInitialEmailMessageScript("updatedEmailScript");
		sellerAccount.setEmailIconImageName("updated_email_icon.png");

		this.sellerAccountService.update(sellerAccount);

		final SellerAccount sellerAccountOut = this.sellerAccountService.getByAccountId(sellerAccount.getAccountId());

		assertThat(sellerAccountOut.getName(), is(sellerAccount.getName()));
		assertThat(sellerAccountOut.getGpSellerAccount(), is(sellerAccount.getGpSellerAccount()));
		assertThat(sellerAccountOut.getDisplayName(), is(sellerAccount.getDisplayName()));
		assertThat(sellerAccountOut.getSourceDescription(), is(sellerAccount.getSourceDescription()));
		assertThat(sellerAccountOut.getApplicationLogo(), is(sellerAccount.getApplicationLogo()));
		assertThat(sellerAccountOut.getPackType(), is(sellerAccount.getPackType()));
		assertThat(sellerAccountOut.getDistributeAppointmentReminder(), is(sellerAccount.getDistributeAppointmentReminder()));
		assertThat(sellerAccountOut.getAssessmentCallReasonGroup(), is(sellerAccount.getAssessmentCallReasonGroup()));
		assertThat(sellerAccountOut.getAssessmentInitialSmsMessageScript(), is(sellerAccount.getAssessmentInitialSmsMessageScript()));
		assertThat(sellerAccountOut.getAssessmentInitialEmailMessageScript(), is(sellerAccount.getAssessmentInitialEmailMessageScript()));
		assertThat(sellerAccountOut.getEmailIconImageName(), is(sellerAccount.getEmailIconImageName()));
	}

	@Test
	@NoTestData
	public void testGetById() {
		final SellerAccount notNullSellerAccount = this.sellerAccountService.getByAccountId(9785);
		assertThat(notNullSellerAccount, is(notNullValue()));
		assertThat(notNullSellerAccount.getLeadType(), is(new LeadType(1, "Text Lead - BAU")));

		final SellerAccount nullSellerAccount = this.sellerAccountService.getByAccountId(99999);
		assertThat(nullSellerAccount, is(nullValue()));
	}

	@Test
	@NoTestData
	public void testGetAllSellerAccounts() {
		final List<SellerAccount> allSellerAccounts = this.sellerAccountService.getAll();

		assertThat(allSellerAccounts.size(), is(33));
	}

	@Test
	@NoTestData
	public void testGetSourcedSellerAccounts() {
		final List<SellerAccount> sourcedSellerAccounts = this.sellerAccountService.getSourcedSellerAccounts();

		assertThat(sourcedSellerAccounts.size(), is(5));
	}
}
