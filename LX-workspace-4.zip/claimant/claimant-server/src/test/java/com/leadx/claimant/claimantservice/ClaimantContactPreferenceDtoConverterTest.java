package com.leadx.claimant.claimantservice;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.leadx.claimant.client.ClaimantContactPreferenceDto;
import com.leadx.claimant.util.ClaimantTestUtils;

public class ClaimantContactPreferenceDtoConverterTest {
	
	private ClaimantContactPreferenceDtoConverter claimantContactPreferenceDtoConverter;

	private int CLAIMANT_ID = 1000;

	@Before
	public void setUp() throws Exception {
		this.claimantContactPreferenceDtoConverter = new ClaimantContactPreferenceDtoConverter();
	}
	
	@Test
	public final void canConvert() {
		final ClaimantContactPreferenceDto input = ClaimantTestUtils.createBlankContactPreferenceDto(CLAIMANT_ID);
		final ClaimantContactPreference expected = ClaimantTestUtils.createBlankContactPreference(CLAIMANT_ID);

		final ClaimantContactPreference actual = this.claimantContactPreferenceDtoConverter.convert(input);
		
		assertTrue(actual.equals(expected));
	}
	
	@Test
	public final void canHandleNullSource() {
		final ClaimantContactPreferenceDto nullAddress = null;
		
		final ClaimantContactPreference actual = this.claimantContactPreferenceDtoConverter.convert(nullAddress);
		
		assertThat(actual, is(nullValue()));
	}
}
