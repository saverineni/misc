package com.leadx.claimant.calllogservice;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import javax.annotation.Resource;

import org.hibernate.SessionFactory;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.test.context.ContextConfiguration;

import com.leadx.claimant.client.CallDisposition;
import com.leadx.claimant.client.CallLogDto;
import com.leadx.claimant.client.CallType;
import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.NoTestData;

@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class CallLogDtoConverterIntTest extends AbstractIntegrationTest {

	@Autowired
	protected CallLogService callLogService;

	@Autowired
	protected Converter<CallLog, CallLogDto> callLogConverter;

	@Resource(name = "sessionFactory")
	private SessionFactory sessionFactory;

	private static final int CLAIMANT_ID = 4882;
	private static final Integer USER_ID = 24;
	private static final int DIALLER_REFERENCE = 10001;
	private static final CallType callType = CallType.ASSESSMENT;
	private static final CallDisposition disposition = CallDisposition.ALREADY_ARRANGED;

	@Test
	@NoTestData
	public void testSaveCallLog() {
		final CallLog source = new CallLog(CLAIMANT_ID, disposition, callType, DIALLER_REFERENCE, false, USER_ID);
		final CallLogDto result = new CallLogDto(CLAIMANT_ID, disposition.getName(), callType.getName(), DIALLER_REFERENCE, false, USER_ID);
		this.callLogConverter.convert(source);
		assertThat(source.getCallDisposition().getName(), is(result.getCallDisposition()));
		assertThat(source.getCallType().getName(), is(result.getCallType()));
		assertThat(source.getClaimantId(), is(result.getClaimantId()));
	}
}
