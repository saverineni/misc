package com.leadx.claimant.calllogservice;

import org.junit.Before;
import org.junit.Test;

import com.leadx.claimant.client.CallLogServiceWrapper;
import com.leadx.claimant.util.UrlTester;

/**
 * Tests that the urls mappings used by the wrapper match those used by the controller
 */
public class CallLogServiceWrapperTest extends UrlTester{

	private CallLogServiceWrapper wrapper = new CallLogServiceWrapper();

	@Before
	public void setUp() {
		this.wrapper = new CallLogServiceWrapper();
		super.setUp(this.wrapper);
	}

	@Test
	public void testUrlsMatchForFindCallLogsForClaimant() throws Exception {
		final String urlMapping = "/calllog/unique";
		setWrapperExpectation("http://host:port" + urlMapping + "/99", String.class);
		this.wrapper.findCallLogsForClaimant(99);

		testControllerUrl(CallLogController.class, "findCallLogsForClaimant", int.class, urlMapping + "/{id}");
	}
}
