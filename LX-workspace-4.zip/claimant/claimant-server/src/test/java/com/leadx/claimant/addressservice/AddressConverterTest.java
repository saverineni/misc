package com.leadx.claimant.addressservice;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.leadx.claimant.client.AddressDto;

public class AddressConverterTest {
	
	private AddressConverter addressConverter;
	
	@Before
	public void setUp() throws Exception {
		this.addressConverter = new AddressConverter();
	}
	
	@Test
	public final void canConvert() {
		final Address address = new Address("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "WA14 4DX", "k");
		address.setId(123);
		final AddressDto expected = new AddressDto(123, "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "WA14 4DX", "k", null, null);
		
		final AddressDto actual = this.addressConverter.convert(address);
		
		assertTrue(actual.equals(expected));
	}
	
	@Test
	public final void canHandleNullSource() {
		final Address nullAddress = null;
		
		final AddressDto actual = this.addressConverter.convert(nullAddress);
		
		assertThat(actual, is(nullValue()));
	}
}