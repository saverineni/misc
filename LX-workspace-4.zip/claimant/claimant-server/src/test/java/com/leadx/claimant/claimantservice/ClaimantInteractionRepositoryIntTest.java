package com.leadx.claimant.claimantservice;

import static com.leadx.claimant.claimantservice.Source.PAYMENTS;
import static com.leadx.claimant.claimantservice.Source.SALES;
import static org.junit.Assert.assertTrue;

import java.util.List;

import com.google.common.collect.Lists;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.leadx.claimant.user.User;
import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.NoTestData;
import com.leadx.test.integration.RequiresTestData;


@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class ClaimantInteractionRepositoryIntTest extends AbstractIntegrationTest {

	@Autowired
	private ClaimantInteractionRepository claimantInteractionRepository;
	
	private static final int CLAIMANT_ID = 123456;
	
	@Test
	@RequiresTestData
	public void testGetNotesByClaimantId() {
		final ClaimantInteraction expected1 = new ClaimantInteraction(CLAIMANT_ID, null, ClaimantInteractionType.NOTE.toValue(), new User(), "Test Note 3", SALES.name());
		final ClaimantInteraction expected2 = new ClaimantInteraction(CLAIMANT_ID, null, ClaimantInteractionType.NOTE.toValue(), new User(), "Test Note 2", SALES.name());
		final ClaimantInteraction expected3 = new ClaimantInteraction(CLAIMANT_ID, null, ClaimantInteractionType.NOTE.toValue(), new User(), "Test Note 1", SALES.name());
		final List<ClaimantInteraction> interactions = this.claimantInteractionRepository.getByClaimantId(CLAIMANT_ID, ClaimantInteractionType.NOTE);
		
		assertTrue(interactions.size() == 3);
		assertClaimantInteractionAreIdentical(expected1, interactions.get(0));
		assertClaimantInteractionAreIdentical(expected2, interactions.get(1));
		assertClaimantInteractionAreIdentical(expected3, interactions.get(2));
	}
	
	@Test
	@RequiresTestData(locations = "testGetNotesByClaimantId")
	public void testGetEventsByClaimantId() {
		final ClaimantInteraction expected1 = new ClaimantInteraction(CLAIMANT_ID, null, ClaimantInteractionType.EVENT.toValue(), new User(), "Test Event 1", SALES.name());
		final List<ClaimantInteraction> interactions = this.claimantInteractionRepository.getByClaimantId(CLAIMANT_ID, ClaimantInteractionType.EVENT);
		
		assertTrue(interactions.size() == 1);
		assertClaimantInteractionAreIdentical(expected1, interactions.get(0));
	}

	@Test
	public void testGetNotesByClaimantIdAndSource() {
		final ClaimantInteraction expected1 = new ClaimantInteraction(CLAIMANT_ID, null, ClaimantInteractionType.NOTE.toValue(), new User(), "Payments Note 1", PAYMENTS.name());
		final List<ClaimantInteraction> interactions = this.claimantInteractionRepository.getByClaimantIdAndSource(CLAIMANT_ID, ClaimantInteractionType.NOTE, PAYMENTS.name(), 1);

		assertTrue(interactions.size() == 1);
		assertClaimantInteractionAreIdentical(expected1, interactions.get(0));
	}

	@Test
	@RequiresTestData(locations = "testGetNotesByClaimantIdAndSource")
	public void testGetNotesByClaimantIdAndSources() {
		final ClaimantInteraction expected1 = new ClaimantInteraction(CLAIMANT_ID, null, ClaimantInteractionType.NOTE.toValue(), new User(), "Payments Note 1", PAYMENTS.name());
		final List<ClaimantInteraction> interactions = this.claimantInteractionRepository.getByClaimantIdBySources(CLAIMANT_ID, ClaimantInteractionType.NOTE, Lists.newArrayList("PAYMENTS", "SALES"), 1);

		assertTrue(interactions.size() == 4);
		assertClaimantInteractionAreIdentical(expected1, interactions.get(0));
	}
	
	@Test
	@NoTestData
	public void testCreateNote() {
		final User dummyUser = new User();
		dummyUser.setId(123);
		
		final ClaimantInteraction expectedNote = new ClaimantInteraction(CLAIMANT_ID, null, ClaimantInteractionType.NOTE.toValue(), dummyUser, "Test Note 3", SALES.name());
		this.claimantInteractionRepository.save(expectedNote);
		
		final List<ClaimantInteraction> result = this.claimantInteractionRepository.getByClaimantId(CLAIMANT_ID, ClaimantInteractionType.NOTE);
		assertTrue(result.size() == 1);
		assertClaimantInteractionAreIdentical(expectedNote, result.get(0));
	}

	@Test
	@NoTestData
	public void testUpdateNote() {
		final User dummyUser = new User();
		dummyUser.setId(123);

		final ClaimantInteraction note = new ClaimantInteraction(CLAIMANT_ID, null, ClaimantInteractionType.NOTE.toValue(), dummyUser, "Test Note 3", SALES.name());
		this.claimantInteractionRepository.save(note);

		final ClaimantInteraction update = this.claimantInteractionRepository.getByClaimantId(CLAIMANT_ID, ClaimantInteractionType.NOTE).get(0);
		update.setContent("Updated content");
		this.claimantInteractionRepository.save(update);

		final ClaimantInteraction noteFromDB = this.claimantInteractionRepository.getByClaimantId(CLAIMANT_ID, ClaimantInteractionType.NOTE).get(0);
		assertClaimantInteractionAreIdentical(update, noteFromDB);
	}

	@Test
	@NoTestData
	public void testCreateEvent() {
		final User dummyUser = new User();
		dummyUser.setId(123);
		
		final ClaimantInteraction expectedEvent = new ClaimantInteraction(CLAIMANT_ID, null, ClaimantInteractionType.EVENT.toValue(), dummyUser, "Test Event 1", SALES.name());
		this.claimantInteractionRepository.save(expectedEvent);
		
		final List<ClaimantInteraction> result = this.claimantInteractionRepository.getByClaimantId(CLAIMANT_ID, ClaimantInteractionType.EVENT);
		assertTrue(result.size() == 1);
		assertClaimantInteractionAreIdentical(expectedEvent, result.get(0));
	}
	
	private static void assertClaimantInteractionAreIdentical(final ClaimantInteraction expected, final ClaimantInteraction actual) {
		assertTrue(expected.getClaimantId() == actual.getClaimantId());
		assertTrue(expected.getContent().equals(actual.getContent()));
		assertTrue(expected.getType().equalsIgnoreCase(actual.getType()));
	}
}
