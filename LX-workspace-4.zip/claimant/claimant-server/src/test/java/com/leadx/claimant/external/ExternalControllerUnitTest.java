package com.leadx.claimant.external;

import static com.leadx.claimant.claimantservice.Source.PORTAL;
import static com.leadx.test.MockUtils.mockAndSetOn;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.security.NoSuchAlgorithmException;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.concurrent.Synchroniser;
import org.jmock.lib.legacy.ClassImposteriser;
import org.joda.time.LocalDate;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.leadx.claimant.addressservice.Address;
import com.leadx.claimant.addressservice.AddressDtoConverter;
import com.leadx.claimant.addressservice.AddressService;
import com.leadx.claimant.authenticationservice.AuthenticationService;
import com.leadx.claimant.claimantservice.Claimant;
import com.leadx.claimant.claimantservice.ClaimantBuilder;
import com.leadx.claimant.claimantservice.ClaimantService;
import com.leadx.claimant.client.AddressDto;
import com.leadx.claimant.client.ClaimantAuthenticationDto;
import com.leadx.claimant.client.ClaimantDto;
import com.leadx.claimant.client.SaveAddressDto;
import com.leadx.lib.utl.json.JsonUtils;

@SuppressWarnings({"unqualified-field-access"})
public class ExternalControllerUnitTest {

	private ExternalController externalController;

	private AddressService addressService;
	private AuthenticationService authenticationService;
	private ClaimantService claimantService;
	private AddressDtoConverter addressDtoConverter;


	private static final int CLAIMANT_ID = 54321;
	private static final int ADDRESS_ID = 321;

	private final Synchroniser synchroniser = new Synchroniser();

	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
			setThreadingPolicy(synchroniser);
		}
	};

	@Before
	public void setUp() {
		this.externalController = new ExternalController();

		this.addressService = mockAndSetOn(this.context, AddressService.class, this.externalController);
		this.authenticationService = mockAndSetOn(this.context, AuthenticationService.class, this.externalController);
		this.claimantService = mockAndSetOn(this.context, ClaimantService.class, this.externalController);
		this.addressDtoConverter = mockAndSetOn(this.context, AddressDtoConverter.class, this.externalController);
	}

	@Test
	public void shouldAuthenticateSuccessfully() throws NoSuchAlgorithmException {
		final ClaimantAuthenticationDto claimantAuthenticationDto = new ClaimantAuthenticationDto(CLAIMANT_ID, "some password");

		this.context.checking(new Expectations() {
			{
				oneOf(authenticationService).authenticate(claimantAuthenticationDto);
				will(returnValue(true));
			}
		});

		final ResponseEntity<String> response = this.externalController.authenticate(JsonUtils.serialize(claimantAuthenticationDto, true));

		assertThat(response.getStatusCode(), is(HttpStatus.OK));
	}

	@Test
	public void shouldHandleFailedAuthentication() throws NoSuchAlgorithmException {
		final ClaimantAuthenticationDto claimantAuthenticationDto = new ClaimantAuthenticationDto(CLAIMANT_ID, "some password");

		this.context.checking(new Expectations() {
			{
				oneOf(authenticationService).authenticate(claimantAuthenticationDto);
				will(returnValue(false));
			}
		});

		final ResponseEntity<String> response = this.externalController.authenticate(JsonUtils.serialize(claimantAuthenticationDto, true));

		assertThat(response.getStatusCode(), is(HttpStatus.UNAUTHORIZED));
	}

	@Test
	public void shouldSuccessfullyGetClaimantName() {
		final Claimant claimant = createDummyClaimant(CLAIMANT_ID);
		final ClaimantDto claimantWithOnlyName = new ClaimantDto(CLAIMANT_ID, 0, 0, 0, "mr",
				"test", null, "testing", null, null, 0, null,
				null, null, null, null, null,false,
				null, 0, false, null, 0, null, false,
				null, 0, null,
				false, null, false, null,
				null, null, Lists.newArrayList(), Lists.newArrayList(), Lists.newArrayList(),  null, null, 0,null,
				null, null, null, null, null, null, Sets.newHashSet(), null, null);

		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(claimant));
			}
		});

		final ClaimantDto claimantDto = this.externalController.getClaimantName(CLAIMANT_ID);

		assertThat(claimantDto.equals(claimantWithOnlyName), is(true));

	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldHandleFailedClaimantLookup() {
		this.context.checking(new Expectations() {
			{
				oneOf(claimantService).getClaimantById(CLAIMANT_ID);
				will(returnValue(null));
			}
		});

		this.externalController.getClaimantName(CLAIMANT_ID);

	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldRejectMissingClaimantIds() {
		this.externalController.getClaimantName(0);

	}

	@Test
	public void testSaveHouseMove() {
		final Address newAddress = newDummyAddress("SO53 2HX");
		final AddressDto newAddressDto = newDummyAddressDto("SO53 2HX");

		final SaveAddressDto saveAddressDto = new SaveAddressDto();
		saveAddressDto.setAddressDto(newAddressDto);
		saveAddressDto.setClaimantId(CLAIMANT_ID);
		saveAddressDto.setMarkAsPafValidated(true);
		saveAddressDto.setUserId(0);

		this.context.checking(new Expectations() {
			{
				oneOf(addressDtoConverter).convert(newAddressDto);
				will(returnValue(newAddress));
				oneOf(addressService).saveHouseMove(CLAIMANT_ID, newAddress);
				oneOf(claimantService).saveEvent(CLAIMANT_ID, null, 91995, "Address updated from customer portal", PORTAL);

			}
		});

		this.externalController.updateAddress(JsonUtils.serialize(saveAddressDto,true));
	}

	private static Address newDummyAddress(final String postcode) {
		return new Address("a", "1", "b", "2", "c", "d", "e", "f", "g", "h", postcode, "a");
	}

	private static AddressDto newDummyAddressDto(final String postcode) {
		return new AddressDto(ADDRESS_ID, "a", "1", "b", "2", "c", "d", "e", "f", "g", "h", postcode, "a", null, null);
	}

	private Claimant createDummyClaimant(final int claimantId) {
		final Claimant claimant = new ClaimantBuilder().setId(claimantId)
				.setLeadId(1231)
				.setSellerAccountId(1)
				.setSellerCompanyId(2)
				.setTitle("mr")
				.setForename("test")
				.setMiddleName("tester")
				.setSurname("testing")
				.setPreviousSurname("xxx")
				.setDob(new LocalDate(1980, 2, 21))
				.setHomeTelephone("123")
				.setMobileTelephone("234")
				.setAlternativeTelephone("5678")
				.setWorkTelephone("2345")
				.setEmail("me1@me.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.createClaimant();

		return claimant;
	}

}
