package com.leadx.claimant.addressservice;

import static com.google.common.collect.Sets.newHashSet;
import static com.leadx.claimant.util.ClaimantTestUtils.*;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.util.List;

import com.leadx.claimant.reference.VulnerableDetailTriState;
import org.joda.time.LocalDate;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.leadx.claimant.changelogservice.ChangeItem;
import com.leadx.claimant.claimantservice.Claimant;
import com.leadx.claimant.claimantservice.ClaimantBuilder;
import com.leadx.claimant.claimantservice.ClaimantService;
import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.NoTestData;

@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class AddressServiceIntTest extends AbstractIntegrationTest {
	@Autowired
	private AddressService addressService;
	
	@Autowired
	private ClaimantService claimantService;

	@Autowired
	private AddressRepository repository;

	@Test
	@NoTestData
	public void testUpdateAddress() throws Exception {
		final Address address = new Address("dept", "", "subbuilding", "bulding", "23", "deptf", "tf", "ddl", "local", "town", "postcode", "county");
		this.addressService.saveAddress(0, address, false);
		
		final Claimant claimant = new ClaimantBuilder().setId(0)
				.setLeadId(1)
				.setSellerAccountId(2)
				.setSellerCompanyId(3)
				.setTitle("testTitle")
				.setForename("testForename")
				.setMiddleName("testMid")
				.setSurname("testSurname")
				.setPreviousSurname("testPrevSurname")
				.setDob(new LocalDate("1990-07-15"))
				.setAddressId(address.getId())
				.setHomeTelephone("01234567890")
				.setMobileTelephone("07712345678")
				.setAlternativeTelephone("1234567890")
				.setWorkTelephone("")
				.setEmail("test@test.com")
				.setNationalInsuranceNumber("JP467431D")
				.setFreePpi(true)
				.setOtherNames(buildOtherNames("Name1", "Name2"))
				.setAdditionalPreviousNames(buildAdditionalPreviousNames("Name1", "Name2", "Name3"))
				.setClaimantUnpresentedCheque(buildClaimantUnpresentedCheque())
				.setHasVulnerability(false)
				.setVulnerabilityCategories(newHashSet())
				.setCanStoreVulnerabilityDetail(VulnerableDetailTriState.NO)
				.setVulnerabilityDetail("")
				.createClaimant();
		this.claimantService.createClaimant(claimant);
		
		this.repository.evict(address);

		final Address newAddress = new Address("dep1t", "", "subbuilding", "bulding", "23", "deptf", "tf", "ddl", "local", "town", "postcode1", "county");
		newAddress.setId(address.getId());
		final List<ChangeItem> changeItems = this.addressService.updateAddress(23, newAddress, 99, true);
		assertThat(changeItems.size(), is(3));
	}
}