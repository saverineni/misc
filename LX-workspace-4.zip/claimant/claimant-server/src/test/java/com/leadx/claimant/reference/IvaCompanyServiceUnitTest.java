package com.leadx.claimant.reference;

import org.jmock.Expectations;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static com.leadx.test.MockUtils.mockAndSetOn;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class IvaCompanyServiceUnitTest {


	private final JUnit4Mockery context = new JUnit4Mockery() {

		{
			setImposteriser(ClassImposteriser.INSTANCE);
		}
	};

	private IvaCompanyService ivaCompanyService;

	protected IvaCompanyRepository ivaCompanyRepository;

	@Before
	public void setUp() {
		this.ivaCompanyService = new IvaCompanyService();
		this.ivaCompanyRepository = mockAndSetOn(this.context, IvaCompanyRepository.class, this.ivaCompanyService);
	}

	@SuppressWarnings("unqualified-field-access")
	@Test
	public void shouldGetIvaCompanies() {
		final IvaCompany company = new IvaCompany();
		company.setName("Test Name");
		company.setPostcode("WA14 4DZ");

		final List<IvaCompany> companies = Arrays.asList(company);

		this.context.checking(new Expectations() {

			{
				one(ivaCompanyRepository).getIvaCompanies();
				will(returnValue(companies));
			}
		});

		final List<IvaCompany> result = this.ivaCompanyService.getIvaCompanies();
		assertThat(result.get(0), is(company));
	}
}