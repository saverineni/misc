package com.leadx.claimant.lead;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.leadx.test.integration.AbstractIntegrationTest;

@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class AddressFailureRepositoryIntTest extends AbstractIntegrationTest{

	@Autowired
	AddressFailureRepository addressFailureRepository;

	@Test
	public void getAddressFailure(){
		AddressFailure addressFailure = this.addressFailureRepository.getById(1);
		assertNotNull(addressFailure);
		assertEquals(11166677, addressFailure.getClaimantId());
		assertEquals(22233344, addressFailure.getAddressId());
		assertEquals(AddressFailureStatus.action_required, addressFailure.getStatus());
	}
}
