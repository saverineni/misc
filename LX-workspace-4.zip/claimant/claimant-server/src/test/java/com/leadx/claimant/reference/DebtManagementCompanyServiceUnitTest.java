package com.leadx.claimant.reference;

import org.jmock.Expectations;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static com.leadx.test.MockUtils.mockAndSetOn;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class DebtManagementCompanyServiceUnitTest {


	private final JUnit4Mockery context = new JUnit4Mockery() {

		{
			setImposteriser(ClassImposteriser.INSTANCE);
		}
	};

	private DebtManagementCompanyService debtManagementCompanyService;

	protected DebtManagementCompanyRepository debtManagementCompanyRepository;

	@Before
	public void setUp() {
		this.debtManagementCompanyService = new DebtManagementCompanyService();
		this.debtManagementCompanyRepository = mockAndSetOn(this.context, DebtManagementCompanyRepository.class, this.debtManagementCompanyService);
	}

	@SuppressWarnings("unqualified-field-access")
	@Test
	public void shouldGetDebtManagementCompanies() {
		final DebtManagementCompany company = new DebtManagementCompany();
		company.setName("Test Name");
		company.setPostcode("WA14 4DZ");

		final List<DebtManagementCompany> companies = Arrays.asList(company);

		this.context.checking(new Expectations() {

			{
				one(debtManagementCompanyRepository).getDebtManagementCompanies();
				will(returnValue(companies));
			}
		});

		final List<DebtManagementCompany> result = this.debtManagementCompanyService.getDebtManagementCompanies();
		assertThat(result.get(0), is(company));
	}
}