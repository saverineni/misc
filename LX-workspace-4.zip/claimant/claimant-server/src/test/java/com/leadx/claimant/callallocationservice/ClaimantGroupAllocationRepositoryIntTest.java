package com.leadx.claimant.callallocationservice;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import javax.annotation.Resource;

import org.hibernate.SessionFactory;
import org.joda.time.DateTime;
import org.joda.time.DateTimeUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.NoTestData;
import com.leadx.test.integration.RequiresTestData;


@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class ClaimantGroupAllocationRepositoryIntTest extends AbstractIntegrationTest {

	@Resource(name = "sessionFactory")
	private SessionFactory sessionFactory;

	@Autowired
	private ClaimantGroupAllocationRepository claimantGroupAllocationRepository;


	@Before
	public void setup() {
		DateTimeUtils.setCurrentMillisFixed(new DateTime(2011, 3, 15, 15, 0, 0).getMillis());

		final ClaimantGroupAllocationRepository claimantGroupAllocationRepositorySetUp = new ClaimantGroupAllocationRepository(this.sessionFactory);
		claimantGroupAllocationRepository = claimantGroupAllocationRepositorySetUp;
	}

	@Test
	@NoTestData
	public void shouldInsertClaimantCallGroupAllocationEntry() {

		final int claimantId = 1234;
		final String callReason = "chase";
		final String callReasonGroup = "PPI";

		final ClaimantGroupAllocation claimantGroupAllocation = new ClaimantGroupAllocation(claimantId, callReason, callReasonGroup);
		this.claimantGroupAllocationRepository.insertClaimantCallGroupAllocationEntry(claimantGroupAllocation);

		final boolean existingClaimant = this.claimantGroupAllocationRepository.checkClaimantCallGroupAllocationEntry(claimantId);
		assertThat(existingClaimant, is(true));

	}

	@Test
	@RequiresTestData(locations = "claimant_group_allocation")
	public void shouldUpdateClaimantCallGroupAllocationEntry() {

		final int claimantId = 12345;
		final String callReasonGroup = "PPI";
		ClaimantGroupAllocation currentCallReasonGroup;

		currentCallReasonGroup = this.claimantGroupAllocationRepository.getClaimantGroupAllocationByClaimantId(claimantId);
		assertThat(currentCallReasonGroup.getCallReasonGroup(), is("Combined"));

		currentCallReasonGroup.setCallReasonGroup(callReasonGroup);
		this.claimantGroupAllocationRepository.updateClaimantCallGroupAllocationEntry(currentCallReasonGroup);

		currentCallReasonGroup = this.claimantGroupAllocationRepository.getClaimantGroupAllocationByClaimantId(claimantId);
		assertThat(currentCallReasonGroup.getCallReasonGroup(), is(callReasonGroup));

	}


	@Test
	@RequiresTestData(locations = "claimant_group_allocation")
	public void shouldDeleteClaimantCallGroupAllocationEntry() {

		final int claimantId = 12346;
		boolean existingClaimantIdList;

		existingClaimantIdList = this.claimantGroupAllocationRepository.checkClaimantCallGroupAllocationEntry(claimantId);
		assertThat(existingClaimantIdList, is(true));

		final ClaimantGroupAllocation claimantGroupAllocation = this.claimantGroupAllocationRepository.getClaimantGroupAllocationByClaimantId(claimantId);
		this.claimantGroupAllocationRepository.deleteClaimantCallGroupAllocationEntry(claimantGroupAllocation);

	}

}
