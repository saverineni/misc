package com.leadx.claimant.claimantservice;

import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.ImmutableList;
import com.leadx.claimant.client.ClaimantServiceWrapper;
import com.leadx.claimant.util.UrlTester;

@SuppressWarnings("unqualified-field-access")
public class ClaimantServiceWrapperTest extends UrlTester {

	private ClaimantServiceWrapper wrapper;


	@Before
	public void setUp() {
		this.wrapper = new ClaimantServiceWrapper();
		super.setUp(wrapper);

	}

	@Test
	public void testUrlsMatchForGetByIds() throws Exception {
		final String urlMapping = "/claimant/claimantReferral/referreeIds";
		setWrapperExpectation("http://host:port" + urlMapping + "/2,3", String.class);
		this.wrapper.getClaimantReferralsByReferreeIds(ImmutableList.of(2, 3));

		testControllerUrl(ClaimantController.class, "getClaimantReferralsByReferreeIds", String.class, urlMapping + "/{csvIds}");
	}

}
