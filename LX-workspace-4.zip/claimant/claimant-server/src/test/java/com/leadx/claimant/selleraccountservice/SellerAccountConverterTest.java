package com.leadx.claimant.selleraccountservice;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.leadx.claimant.client.MethodOfContact;
import com.leadx.claimant.client.SellerAccountDto;

public class SellerAccountConverterTest {

	@Test
	public void testConvert() {
		final SellerAccountConverter sellerAccountConverter = new SellerAccountConverter();
		final SellerAccount sellerAccount = new SellerAccount(1234,"GP_SELLER_ACC","Seller Name", "Display Name", "", MethodOfContact.telephone, "LOGO.swf","tcg_pack",false,"call_reason_group","smsScript","emailScript","email_icon.png", false);
		final ProductType selected = new ProductType(1, "ppi");
		sellerAccount.setProductType(selected);
		sellerAccount.setId(0);
		final SellerAccountDto sellerAccountDto = sellerAccountConverter.convert(sellerAccount);

		assertThat(sellerAccountDto, is(notNullValue()));
		assertThat(sellerAccountDto.getId(), is(0));
		assertThat(sellerAccountDto.getAccountId(), is(1234));
		assertThat(sellerAccountDto.getGpSellerAccount(), is("GP_SELLER_ACC"));
		assertThat(sellerAccountDto.getName(), is("Seller Name"));
		assertThat(sellerAccountDto.getDisplayName(), is("Display Name"));
		assertThat(sellerAccountDto.getSourceDescription(), is(""));
		assertThat(sellerAccountDto.getApplicationLogo(), is("LOGO.swf"));
		assertThat(sellerAccountDto.getPackType(), is("tcg_pack"));
		assertThat(sellerAccountDto.getDistributeAppointmentReminder(), is(false));
		assertThat(sellerAccountDto.getAssessmentCallReasonGroup(), is("call_reason_group"));
		assertThat(sellerAccountDto.getAssessmentInitialSmsMessageScript(), is("smsScript"));
		assertThat(sellerAccountDto.getAssessmentInitialEmailMessageScript(), is("emailScript"));
		assertThat(sellerAccountDto.getEmailIconImageName(), is("email_icon.png"));
		assertThat(sellerAccountDto.getFreePpi(), is(false));
	}

	@Test
	public void testConvertNull() {
		final SellerAccountConverter sellerAccountConverter = new SellerAccountConverter();
		final SellerAccountDto sellerAccountDto = sellerAccountConverter.convert(null);
		assertThat(sellerAccountDto, is(nullValue()));
	}
}