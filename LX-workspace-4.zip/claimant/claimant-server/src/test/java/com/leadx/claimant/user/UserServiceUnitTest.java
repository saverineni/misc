package com.leadx.claimant.user;

import static com.leadx.test.MockUtils.mockAndSetOn;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;

@SuppressWarnings("unqualified-field-access")
public class UserServiceUnitTest {

	private UserService userService;
	private UserRepository userRepository;

	private static final int USER_ID = 12345;


	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
		}
	};

	@Before
	public void setUp() {
		this.userService = new UserService();
		this.userRepository = mockAndSetOn(this.context, UserRepository.class, this.userService);
	}

	@Test
	public void testGetById() {
		this.context.checking(new Expectations() {
			{
				oneOf(userRepository).getById(USER_ID);
				will(returnValue(new User()));
			}
		});

		this.userService.getById(USER_ID);
	}
}