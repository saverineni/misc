package com.leadx.claimant.lead;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.leadx.claimant.client.ClaimantLead;

@Ignore //not to be run all the time
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class AddressVerificationProcessorIntTest {

	@Autowired
	AddressVerificationProcessor addressVerificationProcessor;

	@Autowired
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Test
	public void verifyAddress(){
		List<Integer> claimantIds = getClaimants().subList(0, 200);

		for(int claimantId : claimantIds){
			addressVerificationProcessor.process(new ClaimantLead(null, claimantId));
		}

	}

	private List<Integer> getClaimants(){
		return this.namedParameterJdbcTemplate.queryForList(sqlGetClaimantsForAddressVerification, new MapSqlParameterSource(), Integer.class);
	}

	private static final String sqlGetClaimantsForAddressVerification = "SELECT c.ID FROM claimant.claimant c JOIN claimant.`seller_account` sa ON c.`FK_AccountID_Seller` = sa.`FK_AccountID` \n"
			+ "JOIN claimant.`address` a ON c.`FK_AddressID` = a.ID \n" + "WHERE sa.`MethodOfContact` LIKE 'post' \n"
			+ "AND c.`CreatedDateTime` > '2016-06-15'\n" + "AND a.PafValidatedDate = 0";

}
