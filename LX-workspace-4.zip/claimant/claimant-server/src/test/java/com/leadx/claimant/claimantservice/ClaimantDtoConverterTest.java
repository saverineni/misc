package com.leadx.claimant.claimantservice;

import static com.google.common.collect.Sets.newHashSet;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.core.IsNull.nullValue;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

import com.leadx.claimant.reference.VulnerableDetailTriState;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.leadx.claimant.client.ClaimantDto;
import com.leadx.claimant.client.ClaimantExecutorDto;
import com.leadx.claimant.reference.TriState;

public class ClaimantDtoConverterTest {
	
	final ClaimantDtoConverter converter = new ClaimantDtoConverter();
	final ClaimantOtherNameDtoConverter otherNameDtoConverter = new ClaimantOtherNameDtoConverter();
	final ClaimantAdditionalPreviousNameDtoConverter previousNamesDtoConverter = new ClaimantAdditionalPreviousNameDtoConverter();
	final ClaimantPreviousEmailDtoConverter previousEmailDtoConverter = new ClaimantPreviousEmailDtoConverter();
	final ClaimantUnpresentedChequeDtoConverter unpresentedChequeDtoConverter = new ClaimantUnpresentedChequeDtoConverter();
	final ClaimantExecutorDtoConverter claimantExecutorDtoConverter = new ClaimantExecutorDtoConverter();
	
	@Before
	public void setUp(){
		ReflectionTestUtils.setField(this.converter, "otherNamesDtoConverter", this.otherNameDtoConverter);
		ReflectionTestUtils.setField(this.converter, "previousNamesDtoConverter", this.previousNamesDtoConverter);
		ReflectionTestUtils.setField(this.converter, "previousEmailDtoConverter", this.previousEmailDtoConverter);
		ReflectionTestUtils.setField(this.converter, "claimantUnpresentedChequeDtoConverter", this.unpresentedChequeDtoConverter);
		ReflectionTestUtils.setField(this.converter, "claimantExecutorDtoConverter", this.claimantExecutorDtoConverter);
	}

	@Test
	public void testConvert() throws Exception {
		final ClaimantExecutorDto claimantExecutor = new ClaimantExecutorDto(1, 1, "Mr", "John", "George", "Smith", "Phil", "12/11/1991", 5, "01617778888", "07871717171", "test@test.co.uk", "08/08/2017 09:00:00", true, "09/09/2018 09:00:00", "08/08/2017 09:00:00","08/08/2017 09:35:41", false, 0);

		final ClaimantDto claimantDto = new ClaimantDto(0, 1, 2, 3, "Mr", "Matt", "Guy", "Helliwell", "previousname", "05/11/1964", 4, "1", "2", "3", "3", "me@me.com", "JP467431D", false,
				"13/10/2014 12:34:14", 5, false, null, 5,null, false, "13/10/2014 12:34:14", 5, "05/11/2016", true, "27/03/2017 09:00:00", true, "8/10/2014 12:34:14", "3/10/2014 11:30:00", "5/10/2014 14:22:55", Lists.newArrayList(), Lists.newArrayList(), Lists.newArrayList(), TriState.NO.toValue(), null, 0,null,
				TriState.NO.toValue(), null, null, null, claimantExecutor, true, newHashSet("v1", "v2"), VulnerableDetailTriState.YES.toValue(), "something");
		final Claimant claimant = this.converter.convert(claimantDto);

		assertThat(claimant.getLeadId(), is(1));
		assertThat(claimant.getSellerAccountId(), is(2));
		assertThat(claimant.getSellerCompanyId(), is(3));
		assertThat(claimant.getTitle(), is("Mr"));
		assertThat(claimant.getMiddleName(), is("Guy"));
		assertThat(claimant.getSurname(), is("Helliwell"));
		assertThat(claimant.getPreviousSurname(), is("previousname"));
		assertThat(claimant.getDob(), is(new LocalDate(1964, 11, 5)));
		assertThat(claimant.getAddressId(), is(4));
		assertThat(claimant.getHomeTelephone(), is("1"));
		assertThat(claimant.getMobileTelephone(), is("2"));
		assertThat(claimant.getAlternativeTelephone(), is ("3"));
		assertThat(claimant.getWorkTelephone(), is("3"));
		assertThat(claimant.getEmail(), is("me@me.com"));
		assertThat(claimant.getNationalInsuranceNumber(), is("JP467431D"));
		assertThat(claimant.getLockedFromDialler(), is(false));
		assertThat(claimant.getLockedFromDiallerUpdateDateTime(), is(new LocalDateTime(2014, 10, 13, 12, 34, 14)));
		assertThat(claimant.getLockedFromDiallerUpdateUserId(), is(5));
		assertThat(claimant.getVulnerableCustomerReviewDate(), is(new LocalDate(2016, 11, 5)));
		assertThat(claimant.getIncorrectAddressUpdateDateTime(), is(new LocalDateTime(2017, 3, 27, 9, 0, 0)));
		assertThat(claimant.getSuppressedDateTime(), is(new LocalDateTime(2014, 10, 8, 12, 34, 14)));
		assertThat(claimant.getCreatedDateTime(), is(new LocalDateTime(2014, 10, 3, 11, 30, 0)));
		assertThat(claimant.getTimestamp(), is(new LocalDateTime(2014, 10, 5, 14, 22 ,55)));
		assertThat(claimant.getClaimantOtherNames(), is(newHashSet()));
		assertThat(claimant.getClaimantAdditionalPreviousNames(), is(newHashSet()));
		assertNull(claimant.getClaimantUnpresentedCheque());
		assertThat(claimant.getClaimantExecutor(), is(new ClaimantExecutor(1, 1, "Mr", "John", "George", "Smith", "Phil", new LocalDate(1991, 11, 12), 5, "01617778888", "07871717171", "test@test.co.uk", new LocalDateTime(2017, 8, 8, 9, 0, 0), true, new LocalDateTime(2018, 9, 9, 9, 0, 0), new LocalDateTime(2017, 8, 8, 9, 0, 0), new LocalDateTime(2017, 8, 8, 9, 35, 41), false)));
	}


	@Test
	public void testConvertWithNulls() throws Exception {
	final ClaimantDto claimantDto = new ClaimantDto(0, 1, 2, 3, null,
				null, null, null, null, null, 0, null,
				null, null, null, null, null, false,
				null, 0, false, null, 0, null, false,
				null, 0, null,
				false, null, true, null,
				null, null, null, null, null, TriState.NO.toValue(), null, 0,null,
			TriState.NO.toValue(), null, null, null, null, false, Sets.newHashSet(), VulnerableDetailTriState.NO.toValue(), null);

	final Claimant claimant = this.converter.convert(claimantDto);

	assertThat(claimant.getLeadId(), is(1));
	assertThat(claimant.getSellerAccountId(), is(2));
	assertThat(claimant.getSellerCompanyId(), is(3));
	assertThat(claimant.getTitle(), is(""));
	assertThat(claimant.getMiddleName(), is(""));
	assertThat(claimant.getSurname(), is(""));
	assertThat(claimant.getPreviousSurname(), is(""));
	assertThat(claimant.getDob(), is(nullValue()));
	assertThat(claimant.getAddressId(), is(0));
	assertThat(claimant.getHomeTelephone(), is(""));
	assertThat(claimant.getMobileTelephone(), is(""));
	assertThat(claimant.getAlternativeTelephone(), is(""));
	assertThat(claimant.getWorkTelephone(), is(""));
	assertThat(claimant.getEmail(), is(""));
	assertThat(claimant.getNationalInsuranceNumber(), is(""));
	assertThat(claimant.getLockedFromDialler(), is(false));
	assertThat(claimant.getLockedFromDiallerUpdateDateTime(), is(nullValue()));
	assertThat(claimant.getLockedFromDiallerUpdateUserId(), is(0));
	assertThat(claimant.getVulnerableCustomerReviewDate(), is(nullValue()));
	assertThat(claimant.getIncorrectAddressUpdateDateTime(), is(nullValue()));
	assertThat(claimant.getSuppressedDateTime(), is(nullValue()));
	assertThat(claimant.getCreatedDateTime(), is(nullValue()));
	assertThat(claimant.getTimestamp(), is(nullValue()));
	assertThat(claimant.getClaimantOtherNames(), is(newHashSet()));
	assertThat(claimant.getClaimantAdditionalPreviousNames(), is(newHashSet()));
	assertNull(claimant.getClaimantUnpresentedCheque());
	}

}
