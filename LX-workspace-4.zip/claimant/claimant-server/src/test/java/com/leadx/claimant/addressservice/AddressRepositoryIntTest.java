package com.leadx.claimant.addressservice;

import static com.leadx.lib.utl.ObjectUtils.isNotNull;
import static com.leadx.lib.utl.ObjectUtils.isNull;
import static com.leadx.test.integration.TestDataRowCounter.assertRowCount;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.Collection;
import java.util.List;

import javax.annotation.Resource;

import com.google.common.collect.ImmutableList;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.test.context.ContextConfiguration;

import com.leadx.lib.utl.JodaUtils;
import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.RequiresTestData;

@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class AddressRepositoryIntTest extends AbstractIntegrationTest {
	
	@Autowired
	private AddressRepository repository;

	@Resource(name = "claimantNamedParameterJdbcOperations")
	private NamedParameterJdbcOperations jdbcOperations;
	
	private static final int CLAIMANT_ID = 1;

	@Test
	@RequiresTestData(locations = { "previous_addresses" })
	public void testGetAddressesByIds() {
		final Collection<Address> addresses = this.repository.getAddressesByIds(ImmutableList.of(2, 4));
		assertThat(addresses.size(), is(2));

	}

	@Test
	@RequiresTestData(locations = { "clear" })
	public void testSaveAddress() throws Exception {
		assertClearedDown();
		
		final Address address = new Address("dept", "", "subbuilding", "bulding", "23", "deptf", "tf", "ddl", "local", "town", "postcode", "county");
		this.repository.saveAddress(address, true);
		
		assertRowCount(this.jdbcOperations, "address", 1);
		assertThat(address.getId(), is(greaterThan(0)));

		final Address newAddress = this.repository.getAddressById(address.getId());
		assertTrue(newAddress.equals(address));
	}

	@Test
	@RequiresTestData(locations = { "clear" })
	public void testUpdateAddressPafValidated() {
		assertClearedDown();
		
		final Address address = new Address("dept", "", "subbuilding", "bulding", "23", "deptf", "tf", "ddl", "local", "town", "postcode", "county");
		this.repository.saveAddress(address, true);
		final LocalDate dateToday = new LocalDate();
		
		assertRowCount(this.jdbcOperations, "address", 1);

		address.setDepartmentName("new dept name");
		address.setOrganisationName("new org");
		address.setSubBuildingName("new subbuilding");
		address.setBuildingName("new building");
		address.setBuildingNumber("9999");
		address.setDependentThoroughfare("new deptf");
		address.setThoroughfare("new tf");
		address.setDoubleDependentLocality("new ddl");
		address.setDependentLocality("new dl");
		address.setTown("new town");
		address.setCounty("new county");

		this.repository.updateAddress(address, true);

		assertRowCount(this.jdbcOperations, "address", 1);
		
		final Address newAddress = this.repository.getAddressById(address.getId());

		assertThat(newAddress.getPafValidatedDate(), is(dateToday));

		assertThat(newAddress.getDepartmentName(), is("new dept name"));
		assertThat(newAddress.getOrganisationName(), is("new org"));
		assertThat(newAddress.getSubBuildingName(), is("new subbuilding"));
		assertThat(newAddress.getBuildingName(), is("new building"));
		assertThat(newAddress.getBuildingNumber(), is("9999"));
		assertThat(newAddress.getDependentThoroughfare(), is("new deptf"));
		assertThat(newAddress.getThoroughfare(), is("new tf"));
		assertThat(newAddress.getDoubleDependentLocality(), is("new ddl"));
		assertThat(newAddress.getDependentLocality(), is("new dl"));
		assertThat(newAddress.getTown(), is("new town"));
		assertThat(newAddress.getCounty(), is("new county"));
	}

	@Test
	@RequiresTestData(locations = { "clear" })
	public void testUpdateAddressNotPafValidated() {
		assertClearedDown();
		
		final Address address = new Address("dept", "", "subbuilding", "bulding", "23", "deptf", "tf", "ddl", "local", "town", "postcode", "county");
		this.repository.saveAddress(address, false);
		
		assertRowCount(this.jdbcOperations, "address", 1);
		
		address.setDepartmentName("new dept name");
		address.setOrganisationName("new org");
		address.setSubBuildingName("new subbuilding");
		address.setBuildingName("new building");
		address.setBuildingNumber("9999");
		address.setDependentThoroughfare("new deptf");
		address.setThoroughfare("new tf");
		address.setDoubleDependentLocality("new ddl");
		address.setDependentLocality("new dl");
		address.setTown("new town");
		address.setCounty("new county");
		
		this.repository.updateAddress(address, false);
		
		assertRowCount(this.jdbcOperations, "address", 1);
		
		final Address newAddress = this.repository.getAddressById(address.getId());
		
		assertThat(newAddress.getPafValidatedDate(), is(nullValue()));
		
		assertThat(newAddress.getDepartmentName(), is("new dept name"));
		assertThat(newAddress.getOrganisationName(), is("new org"));
		assertThat(newAddress.getSubBuildingName(), is("new subbuilding"));
		assertThat(newAddress.getBuildingName(), is("new building"));
		assertThat(newAddress.getBuildingNumber(), is("9999"));
		assertThat(newAddress.getDependentThoroughfare(), is("new deptf"));
		assertThat(newAddress.getThoroughfare(), is("new tf"));
		assertThat(newAddress.getDoubleDependentLocality(), is("new ddl"));
		assertThat(newAddress.getDependentLocality(), is("new dl"));
		assertThat(newAddress.getTown(), is("new town"));
		assertThat(newAddress.getCounty(), is("new county"));
	}
	
	@Test
	@RequiresTestData(locations = { "previous_addresses" })
	public void testGetDeletedPreviousAddressesForClaimant() {
		assertCorrectPreviousAddressConfiguration();
		
		final List<PreviousAddress> deletedPreviousAddresses = this.repository.getDeletedPreviousAddressesForClaimant(CLAIMANT_ID);
		
		assertThat(deletedPreviousAddresses.size(), is(2));
		assertThat(deletedPreviousAddresses.get(0).getAddress().getPostcode(), is("WA14 4DX"));
		assertThat(deletedPreviousAddresses.get(1).getAddress().getPostcode(), is("WA14 4DZ"));
	}
	
	@Test
	@RequiresTestData(locations = { "previous_addresses" })
	public void testGetPreviousAddressesForClaimant() {
		assertCorrectPreviousAddressConfiguration();
		
		final List<PreviousAddress> previousAddresses = this.repository.getPreviousAddressesForClaimant(CLAIMANT_ID);
		
		assertThat(previousAddresses.size(), is(3));
		
		for (final PreviousAddress previousAddress : previousAddresses) {
			assertThat(previousAddress.getId(), is(greaterThan(0)));
			assertTrue(isNotNull(previousAddress.getAddress().getUpdatedDateTime()));
		}
	}
	
	@Test
	@RequiresTestData(locations = { "previous_addresses" })
	public void testGetPreviousAddress() {
		assertCorrectPreviousAddressConfiguration();
		
		final PreviousAddress previousAddress = this.repository.getPreviousAddress(2);
		
		assertTrue(isNotNull(previousAddress));
		assertTrue(previousAddress.getAddress().getPostcode().equals("WA14 4DX"));
		assertTrue(previousAddress.getDeletedDateTime().equals(JodaUtils.britishTimeStampStringToLocalDateTimeOrNull("01/01/2014 00:00:00")));
	}
	
	@Test
	@RequiresTestData(locations = { "clear" })
	public void testSavePreviousAddress() {
		assertClearedDown();
		
		final Address address1 = new Address("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "WA14 4DZ", "a");
		final PreviousAddress previousAddress1 = new PreviousAddress(CLAIMANT_ID, address1, false);

		final Address address2 = new Address("z", "y", "x", "w", "v", "u", "t", "s", "r", "q", "WA14 4DZ", "b");
		final PreviousAddress previousAddress2 = new PreviousAddress(CLAIMANT_ID, address2, false, new LocalDateTime(), 0);
		
		this.repository.savePreviousAddress(previousAddress1);
		this.repository.savePreviousAddress(previousAddress2);
		
		assertRowCount(this.jdbcOperations, "address", 2);
		assertRowCount(this.jdbcOperations, "previous_address", 2);
		
		final List<PreviousAddress> persistedPreviousAddress = this.repository.getPreviousAddressesForClaimant(CLAIMANT_ID);
		
		assertTrue(persistedPreviousAddress.get(0).getAddress().equals(address1));
		assertTrue(persistedPreviousAddress.get(1).getAddress().equals(address2));
	}
	
	@Test
	@RequiresTestData(locations = { "previous_addresses" })
	public void testUpdatePreviousAddress() {
		final PreviousAddress previousAddress = this.repository.getPreviousAddress(1);
		final Address address = previousAddress.getAddress();
		
		address.setPostcode("M20 4TZ");
		previousAddress.setAddress(address);
		previousAddress.setClaimantId(2);
		previousAddress.setFromCurrent(false);
		
		this.repository.updatePreviousAddress(previousAddress);
		this.repository.evict(address);
		
		final PreviousAddress expected = this.repository.getPreviousAddress(1);
		
		assertThat(expected.getAddress().getPostcode(), is("M20 4TZ"));
		assertThat(expected.getClaimantId(), is(2));
		assertThat(expected.getFromCurrent(), is(false));
	}
	
	@Test
	@RequiresTestData(locations = { "previous_addresses" })
	public void testDeletePreviousAddress() {
		assertCorrectPreviousAddressConfiguration();

		final PreviousAddress previousAddress = this.repository.getPreviousAddress(3);
		
		assertTrue(isNotNull(previousAddress));
		assertTrue(isNull(previousAddress.getDeletedDateTime()));
		
		previousAddress.setDeletedDateTime(JodaUtils.newCurrentDateTime());
		previousAddress.setFkUserIdDeletedBy(3388);
		
		this.repository.savePreviousAddress(previousAddress);
		
		assertCorrectPreviousAddressConfiguration();
		
		final PreviousAddress persistedPreviousAddress = this.repository.getPreviousAddress(3);
		
		assertTrue(isNotNull(persistedPreviousAddress));
		assertTrue(isNotNull(persistedPreviousAddress.getDeletedDateTime()));
	}
	
	@Test
	@RequiresTestData(locations = { "previous_addresses" })
	public void testGetOrderedPreviousAddressesForClaimant() {
		assertCorrectPreviousAddressConfiguration();
		
		final List<PreviousAddress> previousAddresses = this.repository.getOrderedPreviousAddressesForClaimant(CLAIMANT_ID);
		
		assertTrue(previousAddresses.size() == 3);
		assertTrue(previousAddresses.get(0).getId() == 4);
		assertTrue(previousAddresses.get(1).getId() == 5);
		assertTrue(previousAddresses.get(2).getId() == 3);
	}
	
	private void assertClearedDown() {
		assertRowCount(this.jdbcOperations, "claimant", 0);
		assertRowCount(this.jdbcOperations, "address", 0);
		assertRowCount(this.jdbcOperations, "previous_address", 0);
	}
	
	private void assertCorrectPreviousAddressConfiguration() {
		assertRowCount(this.jdbcOperations, "claimant", 1);
		assertRowCount(this.jdbcOperations, "address", 5);
		assertRowCount(this.jdbcOperations, "previous_address", 5);
	}
}