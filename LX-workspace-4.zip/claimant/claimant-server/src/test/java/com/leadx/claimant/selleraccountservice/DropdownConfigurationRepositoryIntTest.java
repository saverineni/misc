package com.leadx.claimant.selleraccountservice;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.NoTestData;

@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class DropdownConfigurationRepositoryIntTest extends AbstractIntegrationTest {
	@Autowired
	DropdownConfigurationRepository repository;
	
	@Test
	@NoTestData
	public void testGetDropdownItemsForField() {
		List<DropdownConfiguration> result = this.repository.getDropdownItemsForField("seller_packType");
		
		assertThat(result.size(), is(2));
		assertThat(result.get(0).getFieldValue(), is("tcg_pack"));
		assertThat(result.get(0).getFieldOrder(), is(0));
		
		assertThat(result.get(1).getFieldValue(), is("tcg_pack_swinton"));
		assertThat(result.get(1).getFieldOrder(), is(1));
	}
}