package com.leadx.claimant.addressservice;

import static com.leadx.test.MockUtils.mockAndSetOn;
import static org.junit.Assert.assertTrue;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.concurrent.Synchroniser;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;

import com.leadx.claimant.client.AddressDto;
import com.leadx.claimant.client.PreviousAddressDto;

@SuppressWarnings({"unqualified-field-access"})
public class PreviousAddressConverterTest {
	
	private PreviousAddressConverter previousAddressConverter;
	private AddressConverter addressConverter;
	
	private final Synchroniser synchroniser = new Synchroniser();
	
	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
			setThreadingPolicy(synchroniser);
		}
	};
	
	@Before
	public void setUp() throws Exception {
		this.previousAddressConverter = new PreviousAddressConverter();
		
		this.addressConverter = mockAndSetOn(this.context, AddressConverter.class, this.previousAddressConverter);
	}
	
	@Test
	public final void canConvert() {
		final Address address = new Address("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "WA14 4DX", "k");
		address.setId(123);
		final PreviousAddress previousAddress = new PreviousAddress(456, address, true);
		previousAddress.setId(789);
		
		final AddressDto addressDto = new AddressDto(123, "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "WA14 4DX", "k", null, null);
		
		this.context.checking(new Expectations() {
			{
				oneOf(addressConverter).convert(address);
				will(returnValue(addressDto));
			}
		});
		
		final PreviousAddressDto expected = new PreviousAddressDto(789, 456, addressDto, true, null, 0);
		final PreviousAddressDto actual = this.previousAddressConverter.convert(previousAddress);
		
		assertTrue(actual.equals(expected));
	}
}