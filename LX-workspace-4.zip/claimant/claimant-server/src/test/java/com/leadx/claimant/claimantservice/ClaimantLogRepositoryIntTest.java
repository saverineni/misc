package com.leadx.claimant.claimantservice;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

import org.joda.time.LocalDateTime;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.NoTestData;

@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class ClaimantLogRepositoryIntTest  extends AbstractIntegrationTest {

	@Autowired
	ClaimantLogRepository repository;

	@Test
	@NoTestData
	public void testCreateClaimantLog() throws Exception {
		final LocalDateTime openTimed = new LocalDateTime(2014, 10, 1, 10, 15);
		final LocalDateTime closedTimed = null;

		final ClaimantLog claimantLog = new ClaimantLog(10, 1, openTimed, closedTimed, 90125);
		this.repository.createClaimantLog(claimantLog);

		this.repository.evict(claimantLog);

		final ClaimantLog newClaimantLog = this.repository.getClaimantLogById(claimantLog.getId());
		assertThat(newClaimantLog, is(claimantLog));

	}

	/** If claimant has been opened and closed several times, make sure we get the latest row. */
	@Test
	public void testGetClaimantLogByClaimantId() {
		final ClaimantLog claimantLog = this.repository.getClaimantLogByClaimantId(100);
		assertThat(claimantLog.getClosedDateTime(), is(nullValue()));
	}

	@Test
	public void testGetClaimantLogInvalidClaimantId() {
		final ClaimantLog claimantLog = this.repository.getClaimantLogByClaimantId(1);
		assertThat(claimantLog, is(nullValue()));
	}

	@Test
	public void testGetClaimantLogById() throws Exception {
		final ClaimantLog claimantLog = this.repository.getClaimantLogById(10);
		assertThat(claimantLog.getId(), is(10));
		assertThat(claimantLog.getScheduledTaskId(), is(1));
		assertThat(claimantLog.getClaimantId(), is(100));
		assertThat(claimantLog.getOpenedDateTime().toString(), is("2014-10-05T12:24:12.000"));
		assertThat(claimantLog.getClosedDateTime(), is(nullValue()));
		assertThat(claimantLog.getUserId(), is(1000));
	}
	
	@Test
	public void testUpdateClaimantLog() {
		final LocalDateTime currentTime = new LocalDateTime();
		
		final ClaimantLog claimantLog = this.repository.getClaimantLogById(10);
		assertThat(claimantLog.getClosedDateTime(), is(nullValue()));

		claimantLog.setClosedDateTime(currentTime);
		
		this.repository.updateClaimantLog(claimantLog);
		
		final ClaimantLog expectedClaimantLog = this.repository.getClaimantLogById(10);
		assertThat(expectedClaimantLog.getClosedDateTime(), is(currentTime));
	}
}
