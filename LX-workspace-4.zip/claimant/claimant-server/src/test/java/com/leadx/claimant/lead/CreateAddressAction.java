package com.leadx.claimant.lead;
import org.hamcrest.Description;
import org.jmock.api.Action;
import org.jmock.api.Invocation;

import com.leadx.claimant.addressservice.Address;

public class CreateAddressAction implements Action {
	@SuppressWarnings("unused")
	private final Address address;
	
	public CreateAddressAction(final Address address) {
		this.address = address;
	}
	
	@Override
	public void describeTo(final Description description) {
	}

	@Override
	public Object invoke(final Invocation invocation) throws Throwable {
		((Address)invocation.getParameter(1)).setId(1);
		
		return null;
	}
	
}