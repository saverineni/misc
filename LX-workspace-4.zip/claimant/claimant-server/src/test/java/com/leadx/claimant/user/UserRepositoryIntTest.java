package com.leadx.claimant.user;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.leadx.test.integration.AbstractIntegrationTest;
import com.leadx.test.integration.NoTestData;

@ContextConfiguration(locations = { "classpath:/spring/spring-test-integrationFiles.xml" })
public class UserRepositoryIntTest extends AbstractIntegrationTest {
	
	@Autowired
	private UserRepository repository;

	@Test
	@NoTestData
	public void testGetById() {
		final User user = this.repository.getById(90185);
		
		assertTrue(user.getForename().equals("Matt"));
		assertTrue(user.getSurname().equals("Helliwell"));
		assertTrue(user.getFullName().equals("Matt Helliwell"));
	}
}