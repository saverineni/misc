DELETE FROM `claimant`.`application_property`;
INSERT INTO `claimant`.`application_property` (`Property`,`PropertyValue`) VALUES
("distribution.scripts.welcomeEmail","ClaimsGuysEmail.groovy?emailId=4445"),
("distribution.scripts.welcomeSms","Sms.groovy?smsId=4441"),
("distribution.scripts.contactPhoneNumber",""),
("distribution.scripts.packOutEmailPostalContact","ClaimsGuysEmail.groovy?emailId=4446");