DELETE FROM claimant.product_type;
INSERT INTO claimant.product_type (ID, NAME, OBJ_VERSION) VALUES 
(1, 'PPI', 0),
(2, 'PBA', 0),
(3, 'STL', 0),
(4, 'INV', 0);