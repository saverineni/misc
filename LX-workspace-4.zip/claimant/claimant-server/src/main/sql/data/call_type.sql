DELETE FROM `claimant`.`call_type`;
INSERT INTO `claimant`.`call_type` (`ID`,`Name`,`Description`)
VALUES 
(1,'assessment','Drives initial population of claims into TCG'),
(2,'chase','Prompt to get claimant to return pack'),
(3,'cash_collection','Collecting cash from successful claims'),
(4,'customer_service','Customer Services Call'),
(5,'incompletes','Incompletes Call'),
(6,'fos_to_claimant','FOS To Claimant'),
(7,'dsar_loa','DSAR LOA'),
(8, 'clmnt_info_req', 'Claimant Information Required'),
(9,'dsar_mir', 'DSAR More Info Required'),
(10, 'ldr_q_ppi_check', 'Lender Questionnaire PPI Check'),
(11, 'remediation', 'LBG Remediation'),
(12, 'ldr_q_bau','Lender Questionnaire BAU'),
(13, 'ldr_q_loa_req','Lender Questionnaire LOA Required'),
(14, 'ldr_q_info_req', 'Lender Questionnaire Information Required'),
(15, 'plvn_crtsy_call', 'Plevin Courtesy Call'),
(16, 'fscs_incomplete', 'FSCS Incomplete'),
(17, 'plr chase loa', 'PLR Chase LOA'),
(18, 'plr incomplete', 'PLR Incomplete');