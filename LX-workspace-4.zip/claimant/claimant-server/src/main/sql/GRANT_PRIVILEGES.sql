-- LOCAL ONLY
GRANT ALL PRIVILEGES ON claimant.* TO 'migration.test'@'localhost' IDENTIFIED BY 'm3m0r3x';
GRANT ALL PRIVILEGES ON claimant.* TO 'migration.test'@'127.0.0.1' IDENTIFIED BY 'm3m0r3x';
