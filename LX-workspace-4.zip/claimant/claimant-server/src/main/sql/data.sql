SOURCE data/application_property.sql;
SOURCE data/call_disposition.sql;
SOURCE data/call_type.sql;
SOURCE data/product_type.sql;