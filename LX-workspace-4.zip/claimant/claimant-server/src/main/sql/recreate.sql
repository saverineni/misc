DROP DATABASE IF EXISTS `claimant`;
CREATE DATABASE `claimant`;
USE `claimant`;
SOURCE claimant.sql;
SOURCE data.sql;
SOURCE test-data.sql;