DELETE FROM claimant.`address`;

INSERT INTO claimant.`address` SET
  `ID`=1, 
  `DepartmentName`='', 
  `OrganisationName`='LeadX Limited', 
  `SubBuildingName`='', 
  `BuildingName`='Lynnfield House', 
  `BuildingNumber`='', 
  `DependentThoroughfare`='', 
  `Thoroughfare`='Church Street', 
  `DoubleDependentLocality`='', 
  `DependentLocality`='', 
  `Town`='Altrincham', 
  `County`='Cheshire', 
  `Postcode`='WA14 4DZ',
  `PafValidatedDate`='2012-12-06';

INSERT INTO claimant.`address` SET
  `ID`=2, 
  `DepartmentName`='', 
  `OrganisationName`='The Claims Guys', 
  `SubBuildingName`='', 
  `BuildingName`='Lynnfield House', 
  `BuildingNumber`='', 
  `DependentThoroughfare`='', 
  `Thoroughfare`='Church Street', 
  `DoubleDependentLocality`='', 
  `DependentLocality`='', 
  `Town`='Altrincham', 
  `County`='Cheshire', 
  `Postcode`='WA14 4DZ',
  `PafValidatedDate`='2012-12-06';
  
  
INSERT INTO claimant.`address` SET
  `ID`=20, 
  `DepartmentName`='', 
  `OrganisationName`='The Claims Guys', 
  `SubBuildingName`='', 
  `BuildingName`='Lynnfield House', 
  `BuildingNumber`='', 
  `DependentThoroughfare`='', 
  `Thoroughfare`='Church Street', 
  `DoubleDependentLocality`='', 
  `DependentLocality`='', 
  `Town`='Altrincham', 
  `County`='Cheshire', 
  `Postcode`='WA14 4DZ',
  `PafValidatedDate`='2012-12-06';
  
    
INSERT INTO claimant.`address` SET
  `ID`=21, 
  `DepartmentName`='', 
  `OrganisationName`='The Claims Guys', 
  `SubBuildingName`='', 
  `BuildingName`='Lynnfield House', 
  `BuildingNumber`='', 
  `DependentThoroughfare`='', 
  `Thoroughfare`='Church Street', 
  `DoubleDependentLocality`='', 
  `DependentLocality`='', 
  `Town`='Altrincham', 
  `County`='Cheshire', 
  `Postcode`='WA14 4DZ',
  `PafValidatedDate`='2012-12-06';
  
INSERT INTO claimant.`address` SET
  `ID`=22, 
  `DepartmentName`='', 
  `OrganisationName`='The Claims Guys', 
  `SubBuildingName`='', 
  `BuildingName`='Lynnfield House', 
  `BuildingNumber`='', 
  `DependentThoroughfare`='', 
  `Thoroughfare`='Church Street', 
  `DoubleDependentLocality`='', 
  `DependentLocality`='', 
  `Town`='Altrincham', 
  `County`='Cheshire', 
  `Postcode`='WA14 4DZ',
  `PafValidatedDate`='2012-12-06';
  
 INSERT INTO claimant.`address` SET
  `ID`=23, 
  `DepartmentName`='', 
  `OrganisationName`='The Claims Guys', 
  `SubBuildingName`='', 
  `BuildingName`='Lynnfield House', 
  `BuildingNumber`='', 
  `DependentThoroughfare`='', 
  `Thoroughfare`='Church Street', 
  `DoubleDependentLocality`='', 
  `DependentLocality`='', 
  `Town`='Altrincham', 
  `County`='Cheshire', 
  `Postcode`='WA14 4DZ',
  `PafValidatedDate`='2012-12-06';
  
  INSERT INTO claimant.`address` SET
  `ID`=24, 
  `DepartmentName`='', 
  `OrganisationName`='The Claims Guys', 
  `SubBuildingName`='', 
  `BuildingName`='Lynnfield House', 
  `BuildingNumber`='', 
  `DependentThoroughfare`='', 
  `Thoroughfare`='Church Street', 
  `DoubleDependentLocality`='', 
  `DependentLocality`='', 
  `Town`='Altrincham', 
  `County`='Cheshire', 
  `Postcode`='WA14 4DZ',
  `PafValidatedDate`='2012-12-06';
  
  
-- Previous addresses for claimant 24
  
  INSERT INTO claimant.`address` SET
  `ID`=25, 
  `DepartmentName`='', 
  `OrganisationName`='', 
  `SubBuildingName`='', 
  `BuildingName`='Flat 3', 
  `BuildingNumber`='4', 
  `DependentThoroughfare`='', 
  `Thoroughfare`='Talford Grove', 
  `DoubleDependentLocality`='', 
  `DependentLocality`='West Didsbury', 
  `Town`='Manchester', 
  `County`='', 
  `Postcode`='M20 2HL',
  `PafValidatedDate`='2012-11-15',
  `Timestamp`='2012-11-15 12:30:45';
  
  INSERT INTO claimant.`address` SET
  `ID`=26, 
  `DepartmentName`='', 
  `OrganisationName`='', 
  `SubBuildingName`='', 
  `BuildingName`='Flat 2', 
  `BuildingNumber`='73', 
  `DependentThoroughfare`='', 
  `Thoroughfare`='Moss Lane', 
  `DoubleDependentLocality`='', 
  `DependentLocality`='', 
  `Town`='Altrincham', 
  `County`='', 
  `Postcode`='WA15 8HL',
  `PafValidatedDate`='2010-11-29',
  `Timestamp`='2010-11-29 12:30:45';
  
  INSERT INTO claimant.`address` SET
  `ID`=27, 
  `DepartmentName`='', 
  `OrganisationName`='', 
  `SubBuildingName`='', 
  `BuildingName`='Flat 1', 
  `BuildingNumber`='74', 
  `DependentThoroughfare`='', 
  `Thoroughfare`='Mass Lone', 
  `DoubleDependentLocality`='', 
  `DependentLocality`='', 
  `Town`='Altringham', 
  `County`='', 
  `Postcode`='WA15 8HL',
  `PafValidatedDate`='2010-11-28',
  `Timestamp`='2010-11-28 12:30:45';
  