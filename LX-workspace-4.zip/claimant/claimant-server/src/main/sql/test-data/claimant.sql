DELETE FROM claimant.`claimant`;

INSERT INTO claimant.`claimant` SET
	ID=1,
	FK_LeadID=8000001,
	FK_AddressID=1,
	FK_AccountID_Seller=9785,
	Title='Mr',
	Forename='Jim',
	Surname='Bobbins',
	Email='jim@bobbins.com',
	HomeTelephone='02031892512',
	MobileTelephone='07796136602',
	WorkTelephone='08448714386',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;

-- Brunel Franklin & Ashworth Law
INSERT INTO claimant.`claimant` SET
	ID=2,
	FK_LeadID=8000002,
	FK_AddressID=2,
	FK_AccountID_Seller=9785,
	Title='Mrs',
	Forename='Jessica',
	Surname='Bobbins',
	Email='jessica@bobbins.com',
	HomeTelephone='02031892512',
	MobileTelephone='07796136602',
	WorkTelephone='08448714386',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;

-- Aims
INSERT INTO claimant.`claimant` SET
	ID=3,
	FK_LeadID=8000004,
	FK_AddressID=2,
	Title='Mr',
	Forename='Eric',
	Surname='Bobbins',
	Email='eric@bobbins.com',
	HomeTelephone='02031892512',
	MobileTelephone='07796136602',
	WorkTelephone='08448714386',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;

-- TCG - Internal
INSERT INTO claimant.`claimant` SET
	ID=4,
	FK_LeadID=8000004,
	FK_AddressID=2,
	Title='Mrs',
	Forename='Jane',
	Surname='Bobbins',
	Email='jane@bobbins.com',
	HomeTelephone='02031892512',
	MobileTelephone='07796136602',
	WorkTelephone='08448714386',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;

-- Claimant in Bad Debt
INSERT INTO claimant.`claimant` SET
	ID=5,
	FK_LeadID=8000005,
	FK_AddressID=2,
	Title='Mr',
	Forename='Bob',
	Surname='Bobbins',
	Email='bob@bobbins.com',
	HomeTelephone='02031892512',
	MobileTelephone='07796136602',
	WorkTelephone='08448714386',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;

INSERT INTO claimant.`claimant` SET
	ID=6,
	FK_LeadID=8000006,
	FK_AddressID=2,
	FK_AccountID_Seller=9785,
	Title='Mr',
	Forename='Bob',
	Surname='Robertson',
	Email='bob@bobmail.com',
	HomeTelephone='02031892512',
	MobileTelephone='07796136602',
	WorkTelephone='08448714386',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;

INSERT INTO claimant.`claimant` SET
	ID=7,
	FK_LeadID=8000007,
	FK_AddressID=2,
	Title='Mrs',
	Forename='Pippa',
	Surname='Phillips',
	Email='pippa@phillipsnet.com',
	HomeTelephone='02031892512',
	MobileTelephone='07796136602',
	WorkTelephone='08448714386',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;

INSERT INTO claimant.`claimant` SET
	ID=8,
	FK_LeadID=8000008,
	FK_AddressID=2,
	FK_AccountID_Seller=9785,
	Title='Mr',
	Forename='Dick',
	Surname='Richards',
	Email='r.richards@notanemailprovider.com',
	HomeTelephone='02031892512',
	MobileTelephone='07796136602',
	WorkTelephone='08448714386',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;

INSERT INTO claimant.`claimant` SET
	ID=9,
	FK_LeadID=8000009,
	FK_AddressID=2,
	Title='Rev',
	Forename='Jimmy',
	Surname='James',
	Email='jj@vicarsnet.com',
	HomeTelephone='02031892512',
	MobileTelephone='07796136602',
	WorkTelephone='08448714386',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;

INSERT INTO claimant.`claimant` SET
	ID=10,
	FK_LeadID=8000010,
	FK_AddressID=2,
	Title='Mr',
	Forename='Dave',
	Surname='Davis',
	Email='dave@worldofdave.com',
	HomeTelephone='02031892512',
	MobileTelephone='07796136602',
	WorkTelephone='08448714386',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;

INSERT INTO claimant.`claimant` SET
	ID=11,
	FK_LeadID=8000011,
	FK_AddressID=2,
	Title='Cpl',
	Forename='Mike',
	Surname='Michaels',
	Email='mikeym@planetmichael.net',
	HomeTelephone='02031892512',
	MobileTelephone='07796136602',
	WorkTelephone='08448714386',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;

INSERT INTO claimant.`claimant` SET
	ID=12,
	FK_LeadID=8000012,
	FK_AddressID=2,
	Title='Mr',
	Forename='Payment',
	Surname='Plan',
	Email='Payment@Plan.com',
	HomeTelephone='02031892512',
	MobileTelephone='02031892512',
	WorkTelephone='02031892512',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;

INSERT INTO claimant.`claimant` SET
	ID=20,
	FK_LeadID=8000020,
	FK_AddressID=20,
	Title='Mr',
	Forename='Card',
	Surname='Declined',
	Email='declined@card.com',
	HomeTelephone='02031892512',
	MobileTelephone='02031892512',
	WorkTelephone='02031892512',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;

INSERT INTO claimant.`claimant` SET
	ID=21,
	FK_LeadID=8000021,
	FK_AddressID=21,
	Title='Mr',
	Forename='Refuses',
	Surname='ToPay',
	Email='refuseTo@pay.com',
	HomeTelephone='02031892512',
	MobileTelephone='02031892512',
	WorkTelephone='02031892512',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;

INSERT INTO claimant.`claimant` SET
	ID=22,
	FK_LeadID=8000022,
	FK_AddressID=22,
	Title='Mr',
	Forename='Bad',
	Surname='Debt',
	Email='inbad@debt.com',
	HomeTelephone='02031892512',
	MobileTelephone='02031892512',
	WorkTelephone='02031892512',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;


INSERT INTO claimant.`claimant` SET
	ID=23,
	FK_LeadID=0,
	FK_AddressID=23,
	Title='Mr',
	Forename='ReadyFor',
	Surname='Offset',
	Dob='1987-03-14',
	Email='mr-readyFor@offset.com',
	HomeTelephone='01234567890',
	MobileTelephone='02031892512',
	WorkTelephone='02031892512',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;

INSERT INTO claimant.`claimant` SET
	ID=24,
	FK_LeadID=0,
	FK_AddressID=24,
	Title='Mr',
	Forename='Loadsa',
	Surname='Issues',
	Dob='1987-03-14',
	Email='loadsa@issues.com',
	HomeTelephone='01234567890',
	MobileTelephone='02031892512',
	WorkTelephone='02031892512',
	CurrentlyInIva=0,
	CurrentlyInDebtManagementProgramme=0,
	CurrentlyInBankruptcy=0;