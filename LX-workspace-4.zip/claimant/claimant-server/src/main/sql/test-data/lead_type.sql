DELETE FROM `claimant`.`lead_type`;
INSERT INTO `claimant`.`lead_type` (`Name`) VALUES
('Text Lead - BAU'),
('Text Lead - FPPIC'),
('Web Lead - BAU'),
('Web Lead - FPPIC');
