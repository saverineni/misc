INSERT INTO claimant.`pla_users`
	SELECT * FROM LeadX.pla_users;
