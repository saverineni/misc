DELETE FROM claimant.`dropdown_configuration`;

INSERT INTO claimant.`dropdown_configuration` (`FieldName`, `FieldValue`, `FieldOrder`) VALUES 
('seller_gpSellerAccount', 'ALLEN AND ALLEN', '0'),
('seller_gpSellerAccount', 'CALL CONN 2', '1'),
('seller_gpSellerAccount', 'CALL CONNECTION', '2'),
('seller_gpSellerAccount', 'EXPERIAN', '3'),
('seller_gpSellerAccount', 'Q4', '4'),
('seller_gpSellerAccount', 'SWINTON', '5'),
('seller_gpSellerAccount', 'TELEPROSPECTS', '6'),
('seller_gpSellerAccount', 'TCG', '7'),
('seller_gpSellerAccount', 'VAN COMPARE', '8'),
--
('seller_packType', 'tcg_pack', '0'),
('seller_packType', 'tcg_pack_swinton', '1'),
--
('seller_assessmentCallReasonGroup', 'cc', '0'),
('seller_assessmentCallReasonGroup', 'data', '1'),
('seller_assessmentCallReasonGroup', 'swinton', '2'),
--
('seller_assessmentInitialEmailMessageScript', 'DirectUploadPartnerClaimAppointmentEmailScript', '0'),
('seller_assessmentInitialEmailMessageScript', 'DirectUploadTCGClaimAppointmentEmailScript', '1'),
-- 
('seller_assessmentInitialSmsMessageScript', 'DirectUploadClaimAppointmentSmsScript1','0'),
('seller_assessmentInitialSmsMessageScript', 'DirectUploadClaimAppointmentSmsScript2','1'),
--
('seller_productType', 'ppi', 0),
('seller_productType', 'pba', 1),
--
('seller_methodOfContact','telephone',0),
('seller_methodOfContact','post',1);