DELETE FROM claimant.`previous_address`;

INSERT INTO claimant.`previous_address`(`FK_ClaimantID`, `FK_AddressID`, `FromCurrent`, `DeletedDateTime`, `FK_UserID_DeletedBy`) VALUES
('24', '25', 1, '0000-00-00 00:00:00', '0'),
('24', '26', 0, '0000-00-00 00:00:00', '0'),
('24', '27', 1, '2010-11-29 12:30:45', '3192');