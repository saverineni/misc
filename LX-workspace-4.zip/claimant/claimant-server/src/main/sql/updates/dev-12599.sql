ALTER TABLE `claimant`.`seller_account`
  ADD COLUMN `Category` VARCHAR(100) DEFAULT ''  NOT NULL AFTER `FK_LeadTypeID`,
  ADD COLUMN `Group` VARCHAR(100) DEFAULT ''  NOT NULL AFTER `Category`;