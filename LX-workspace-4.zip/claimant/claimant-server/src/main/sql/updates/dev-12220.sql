ALTER TABLE claimant.`claimant_interaction` MODIFY COLUMN `Source` ENUM('SALES','PAYMENTS','CLAIMANT','PORTAL') NOT NULL DEFAULT 'SALES';

UPDATE claimant.`claimant_interaction` c SET c.`Source` = 'PORTAL' WHERE c.`Content` LIKE '%customer portal%';