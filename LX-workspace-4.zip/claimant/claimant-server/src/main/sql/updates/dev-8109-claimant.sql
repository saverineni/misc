DROP TABLE IF EXISTS claimant.`claimant`;
CREATE TABLE claimant.`claimant` (
	`ID` MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT,
	`FK_LeadID` INT(10) UNSIGNED NOT NULL DEFAULT '0',
	`FK_CompanyID_Seller` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`FK_AccountID_Seller` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`Title` VARCHAR(10) NOT NULL DEFAULT '',
	`Forename` VARCHAR(40) NOT NULL DEFAULT '',
	`MiddleName` VARCHAR(40) NOT NULL DEFAULT '',
	`Surname` VARCHAR(40) NOT NULL DEFAULT '',
	`PreviousSurname` VARCHAR(40) NOT NULL DEFAULT '',
	`Dob` DATE NOT NULL DEFAULT '0000-00-00',
	`FK_AddressID` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`HomeTelephone` VARCHAR(20) NOT NULL DEFAULT '',
	`MobileTelephone` VARCHAR(20) NOT NULL DEFAULT '',
	`WorkTelephone` VARCHAR(20) NOT NULL DEFAULT '',
	`Email` VARCHAR(100) NOT NULL DEFAULT '',
	`CreatedDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`SuppressedDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`LockedFromDialler` TINYINT(1) NOT NULL DEFAULT '0',
	`Timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	`OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`),
	KEY `claimant_index1` (`Surname`),
	KEY `claimant_index2` (`FK_AddressID`),
	KEY `claimant_index3` (`HomeTelephone`),
	KEY `claimant_index4` (`MobileTelephone`),
	KEY `claimant_index5` (`WorkTelephone`),
	KEY `claimant_index6` (`CreatedDateTime`),
	KEY `claimant_index7` (`FK_AccountID_Seller`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;

INSERT INTO claimant.`claimant` (ID, FK_LeadID, FK_CompanyID_Seller, FK_AccountID_Seller,
																 Title, Forename, MiddleName, Surname, PreviousSurname, Dob, FK_AddressID, HomeTelephone, MobileTelephone, WorkTelephone,
																 Email, CreatedDateTime, SuppressedDateTime, LockedFromDialler)
	SELECT ID, FK_LeadID, FK_CompanyID_Seller, FK_AccountID_Seller,
		Title, Forename, MiddleName, Surname, PreviousSurname, Dob, FK_AddressID, HomeTelephone, MobileTelephone, WorkTelephone,
		Email, CreatedDateTime, SuppressedDateTime, LockedFromDialler
	FROM claim.`claimant`;
