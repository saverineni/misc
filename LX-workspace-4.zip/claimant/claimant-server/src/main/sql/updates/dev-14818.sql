ALTER TABLE `claimant`.`claimant`
  MODIFY `FormalDebtArrangementType` SET (
    'debtrelieforder',
    'iva',
    'bankruptcy',
    'protectedtrustdeed',
    'sequestration',
    'debtarrangementscheme',
    'adminorder'
  )  DEFAULT NULL;