CREATE TABLE `claimant`.`application_property`(
	`Property` VARCHAR(128),
	`PropertyValue` VARCHAR(128),
	PRIMARY KEY (`Property`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `claimant`.`application_property` (`Property`,`PropertyValue`) VALUES
("distribution.scripts.welcomeEmail","ClaimsGuysEmail.groovy?emailId=4445"),
("distribution.scripts.welcomeSms","Sms.groovy?smsId=4441"),
("distribution.scripts.contactPhoneNumber","");