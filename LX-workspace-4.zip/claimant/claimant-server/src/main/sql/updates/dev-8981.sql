ALTER TABLE claimant.seller_account 
ADD COLUMN `FK_ProductTypeID` SMALLINT(5) UNSIGNED NOT NULL 
AFTER `ID`;

INSERT INTO claimant.`dropdown_configuration` (FieldName, FieldValue, FieldOrder, OBJ_VERSION)
VALUES
('seller_productType', 'ppi', 0, 0),
('seller_productType', 'pba', 1, 0);

UPDATE claimant.seller_account sa
JOIN claimant.seller_account_product_type sapt ON sa.`FK_AccountID` = sapt.`FK_AccountID`
SET sa.`FK_ProductTypeID` =  sapt.`FK_ProductTypeID`;