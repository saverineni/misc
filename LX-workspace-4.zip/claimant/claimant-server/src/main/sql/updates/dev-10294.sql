ALTER TABLE claimant.claimant ADD COLUMN `LockedFromDiallerUpdateDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER LockedFromDialler;
ALTER TABLE claimant.claimant ADD COLUMN `FK_UserID_LockedFromDiallerUpdate` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0' AFTER LockedFromDiallerUpdateDateTime;
ALTER TABLE claimant.claimant ADD INDEX `claimant_index8` (`LockedFromDiallerUpdateDateTime`);

DROP TABLE data_ops.`temp_interactions`;
CREATE TABLE data_ops.temp_interactions (
  `ID` INT(1) UNSIGNED NOT NULL AUTO_INCREMENT,
  `FK_ClaimantID` INT(10) UNSIGNED NOT NULL DEFAULT '0',
  `FK_UserID` INT(10) UNSIGNED NOT NULL DEFAULT '0',
  `Locked` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
  `DateTime` DATETIME DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;

INSERT INTO data_ops.`temp_interactions` (FK_ClaimantID, FK_UserID, `DateTime`, Locked)
SELECT FK_ClaimantID, FK_UserID_Creator, CreatedDateTime, IF(i.Content = 'Claimant added to cash collecting dialling', 0, 1) FROM claim.`interaction` i
WHERE i.`Content` IN ('Claimant added to cash collecting dialling', 'Claimant removed from cash collecting dialling') AND i.ID > 16889074;

UPDATE claimant.claimant cl
JOIN (SELECT x.FK_ClaimantID, x.FK_UserID, x.Locked, x.DateTime FROM (SELECT * FROM data_ops.`temp_interactions` ORDER BY `ID` DESC) `x` GROUP BY FK_ClaimantID) temp ON cl.`ID` = temp.FK_ClaimantID
SET cl.`LockedFromDiallerUpdateDateTime` = temp.DateTime, cl.`FK_UserID_LockedFromDiallerUpdate` = temp.FK_UserID;
