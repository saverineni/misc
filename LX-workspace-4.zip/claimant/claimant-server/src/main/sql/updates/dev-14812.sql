ALTER TABLE claimant.`claimant`
CHANGE `CanStoreVulnerabilityDetail` `OldCanStoreVulnerabilityDetail` TINYINT(1) UNSIGNED DEFAULT '0',
ADD COLUMN `CanStoreVulnerabilityDetail` ENUM('yes','no','written') AFTER `OldCanStoreVulnerabilityDetail`;

UPDATE claimant.`claimant` c
SET c.`CanStoreVulnerabilityDetail`='yes'
WHERE c.`OldCanStoreVulnerabilityDetail`=1;

UPDATE claimant.`claimant` c
SET c.`CanStoreVulnerabilityDetail`='no'
WHERE c.`OldCanStoreVulnerabilityDetail`=0;

ALTER TABLE claimant.`claimant`
DROP COLUMN `OldCanStoreVulnerabilityDetail`;