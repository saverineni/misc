INSERT INTO `claimant`.`call_type` (`ID`,`Name`,`Description`) VALUES
  (15, 'plvn_crtsy_call', 'Plevin Courtesy Call');
