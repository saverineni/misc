DROP TABLE IF EXISTS claimant.`previous_address`;
CREATE TABLE claimant.`previous_address` (
	`ID` MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT,
	`FK_ClaimantID` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`FK_AddressID` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`FromCurrent` SMALLINT(1) UNSIGNED NOT NULL DEFAULT '0',
	`DeletedDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`FK_UserID_DeletedBy` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`),
	KEY `previous_address_index1` (`FK_ClaimantID`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;

INSERT INTO claimant.`previous_address` (`FK_ClaimantID`, `FK_AddressID`, `FromCurrent`, `DeletedDateTime`, `FK_UserID_DeletedBy`)
	SELECT FK_ClaimantID, FK_AddressID, FromCurrent, DeletedDateTime, FK_UserID_DeletedBy FROM claim.`previous_address`;
