DROP TABLE IF EXISTS claimant.`claimant_referral`;
CREATE TABLE claimant.`claimant_referral` (
	`ID` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`FK_ProductTypeID` SMALLINT(2) UNSIGNED NOT NULL,
	`FK_ClaimantID_Referral` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`FK_ClaimantID_Referrer` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`CreatedDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`FK_UserID_CreatedBy` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`DiallerReferenceID` INT(10) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`),
	KEY `claimant_referral_index1` (`FK_ClaimantID_Referral`),
	KEY `claimant_referral_index2` (`FK_ClaimantID_Referrer`),
	KEY `claimant_referral_index3` (`DiallerReferenceID`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;

INSERT INTO claimant.`claimant_referral` (ID, FK_ProductTypeID, FK_ClaimantID_Referral, FK_ClaimantID_Referrer, CreatedDateTime, FK_UserID_CreatedBy, DiallerReferenceID)
	SELECT ID, 1, FK_ClaimantID_Referral, FK_ClaimantID_Referrer, CreatedDateTime, FK_UserID_CreatedBy, DiallerReferenceID FROM claim.`claimant_referral`;
