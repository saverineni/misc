ALTER TABLE `claimant`.`seller_account` ADD FreePpi tinyint(1) unsigned NOT NULL DEFAULT '0' AFTER AccountName;

UPDATE `claimant`.`seller_account` set FreePpi = 1 where FK_AccountID IN ('12484','12485','12486','12487','12491','12494','12495','12496','12502','12503');