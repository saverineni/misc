ALTER TABLE claimant.`seller_account` ADD `MethodOfContact` ENUM('telephone','post') NOT NULL DEFAULT 'telephone' AFTER `SourceDescription`;

INSERT INTO claimant.`dropdown_configuration`(FieldName, FieldValue, FieldOrder) VALUES
('seller_methodOfContact', 'telephone', 0),
('seller_methodOfContact', 'post', 1);

INSERT INTO `claimant`.`application_property` (`Property`,`PropertyValue`) VALUES
("distribution.scripts.packOutEmailPostalContact","ClaimsGuysEmail.groovy?emailId=4446");

UPDATE claimant.`seller_account` SET MethodOfContact = 'post' WHERE `AssessmentCallReasonGroup` LIKE 'Free PPI Post';