UPDATE claimant.`claimant_group_allocation` cga, (
SELECT clt.`ID` FROM claimant.claimant clt
INNER JOIN claim.claim clm ON clt.`ID` = clm.`FK_ClaimantID` AND clm.`ReturnedDateTime` = 0 AND clm.`NPWDateTime` = 0 AND clm.`CreatedDateTime` < CURDATE()
INNER JOIN claim_incubation.`claim` clim ON clt.`ID` = clim.`FK_ClaimantID` AND clim.`ReturnedDateTime` = 0 AND clim.`NPWDateTime` = 0 AND clim.`CreatedDateTime` < CURDATE()
LEFT JOIN claimant.`claimant_group_allocation` cg ON clt.`ID` = cg.`FK_ClaimantID` AND cg.`CallReasonGroup` = 'combined' AND cg.`IsDeleted` = 0
LEFT JOIN claimant.`claimant_group_allocation` cg2 ON cg2.`FK_ClaimantID` = clt.`ID` AND cg2.`IsDeleted` = 0
WHERE cg.`ID` IS NULL
GROUP BY clt.`ID`
) temp SET cga.`CallReasonGroup` = 'combined' WHERE cga.FK_ClaimantID = temp.ID AND cga.isDeleted = 0;