ALTER TABLE claimant.claimant
ADD COLUMN VulnerableCustomer TINYINT(1) NOT NULL DEFAULT '0' AFTER `FK_UserID_LockedFromDiallerUpdate`,
ADD COLUMN VulnerableCustomerUpdateDateTime DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER `VulnerableCustomer`,
ADD COLUMN FK_UserID_VulnerableCustomerUpdate MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0' AFTER `VulnerableCustomerUpdateDateTime`,
ADD COLUMN VulnerableCustomerReviewDate DATE NOT NULL DEFAULT '0000-00-00' AFTER `FK_UserID_VulnerableCustomerUpdate`;