ALTER TABLE claimant.`claimant`
ADD COLUMN `FormalDebtArrangement` ENUM('yes','no','unsure') DEFAULT NULL AFTER `FreePpi`,
ADD COLUMN `FormalDebtArrangementType` ENUM('debtrelieforder','iva','bankruptcy','protectedtrustdeed','sequestration','debtarrangementscheme','adminorder') DEFAULT NULL AFTER `FormalDebtArrangement`,
ADD COLUMN `InformalDebtArrangement` ENUM('yes','no','unsure') DEFAULT NULL AFTER `IvaReference`;

UPDATE claimant.claimant c
SET c.`InformalDebtArrangement` = CASE
	WHEN `CurrentlyInDebtManagementProgramme` = 1 THEN 'yes'
	WHEN `CurrentlyInDebtManagementProgramme` = 0 THEN 'no'
	ELSE `CurrentlyInDebtManagementProgramme`
END;

UPDATE claimant.claimant c
JOIN claim.`ppi_claimant` p ON c.ID = p.`FK_ClaimantID`
JOIN claim.`credit_agreement` ca ON ca.FK_ClaimantID = c.ID
SET c.`InformalDebtArrangement` = CASE
	WHEN c.`InformalDebtArrangement` IS NULL THEN 'unsure'
	ELSE c.`InformalDebtArrangement`
END;

UPDATE claimant.claimant c
JOIN claim_incubation.`pba_claimant` p ON c.ID = p.`FK_ClaimantID`
JOIN claim_incubation.`pba_agreement` a ON a.FK_ClaimantID = c.ID
SET c.`InformalDebtArrangement` = CASE
	WHEN c.`InformalDebtArrangement` IS NULL THEN 'unsure'
	ELSE c.`InformalDebtArrangement`
END;

UPDATE claimant.claimant c
SET c.`FormalDebtArrangement` = CASE
	WHEN currentlyInIva = 1 OR currentlyInBankruptcy = 1 THEN 'yes'
	WHEN currentlyInIva = 0 AND currentlyInBankruptcy = 0 THEN 'no'
	ELSE c.`FormalDebtArrangement`
END;

UPDATE claimant.claimant c
JOIN claim.`ppi_claimant` p ON c.ID = p.`FK_ClaimantID`
JOIN claim.`credit_agreement` ca ON ca.FK_ClaimantID = c.ID
SET c.`FormalDebtArrangement` = CASE
	WHEN c.`FormalDebtArrangement` IS NULL THEN 'unsure'
	ELSE c.`FormalDebtArrangement`
END;

UPDATE claimant.claimant c
JOIN claim_incubation.`pba_claimant` p ON c.ID = p.`FK_ClaimantID`
JOIN claim_incubation.`pba_agreement` a ON a.FK_ClaimantID = c.ID
SET c.`FormalDebtArrangement` = CASE
	WHEN c.`FormalDebtArrangement` IS NULL THEN 'unsure'
	ELSE c.`FormalDebtArrangement`
END;

UPDATE claimant.claimant cl SET cl.`FormalDebtArrangementType` = 'bankruptcy' WHERE cl.`FormalDebtArrangement` = 'yes' AND cl.`CurrentlyInBankruptcy` = 1;

UPDATE claimant.claimant cl SET cl.`FormalDebtArrangementType` = 'iva' WHERE cl.`FormalDebtArrangement` = 'yes' AND cl.`CurrentlyInIva` = 1;

INSERT INTO claim.`interaction`(`FK_ClaimantID`, `Type`, `FK_UserID_Creator`, `CreatedDateTime`, `Content`)
SELECT ID, 'event', 3388, CURRENT_TIME, 'Financial Circumstances not known pre FCA' FROM claimant.claimant c
WHERE c.`FormalDebtArrangement` LIKE 'unsure' OR c.`InformalDebtArrangement` LIKE 'unsure';




