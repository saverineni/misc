-- Claimant
DROP TABLE IF EXISTS claimant.`claimant`;
CREATE TABLE claimant.`claimant` (
	`ID` MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT,
	`FK_LeadID` INT(10) UNSIGNED NOT NULL DEFAULT '0',
	`FK_CompanyID_Seller` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`FK_AccountID_Seller` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`Title` VARCHAR(10) NOT NULL DEFAULT '',
	`Forename` VARCHAR(40) NOT NULL DEFAULT '',
	`MiddleName` VARCHAR(40) NOT NULL DEFAULT '',
	`Surname` VARCHAR(40) NOT NULL DEFAULT '',
	`PreviousSurname` VARCHAR(40) NOT NULL DEFAULT '',
	`Dob` DATE NOT NULL DEFAULT '0000-00-00',
	`FK_AddressID` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`HomeTelephone` VARCHAR(20) NOT NULL DEFAULT '',
	`MobileTelephone` VARCHAR(20) NOT NULL DEFAULT '',
	`WorkTelephone` VARCHAR(20) NOT NULL DEFAULT '',
	`Email` VARCHAR(100) NOT NULL DEFAULT '',
	`CreatedDateTime` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`SuppressedDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`LockedFromDialler` TINYINT(1) NOT NULL DEFAULT '0',
	`Timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	`OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`),
	KEY `claimant_index1` (`Surname`),
	KEY `claimant_index2` (`FK_AddressID`),
	KEY `claimant_index3` (`HomeTelephone`),
	KEY `claimant_index4` (`MobileTelephone`),
	KEY `claimant_index5` (`WorkTelephone`),
	KEY `claimant_index6` (`CreatedDateTime`),
	KEY `claimant_index7` (`FK_AccountID_Seller`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;

INSERT INTO claimant.`claimant` (ID, FK_LeadID, FK_CompanyID_Seller, FK_AccountID_Seller,
																 Title, Forename, MiddleName, Surname, PreviousSurname, Dob, FK_AddressID, HomeTelephone, MobileTelephone, WorkTelephone,
																 Email, CreatedDateTime, SuppressedDateTime, LockedFromDialler)
	SELECT ID, FK_LeadID, FK_CompanyID_Seller, FK_AccountID_Seller,
		Title, Forename, MiddleName, Surname, PreviousSurname, Dob, FK_AddressID, HomeTelephone, MobileTelephone, WorkTelephone,
		Email, CreatedDateTime, SuppressedDateTime, LockedFromDialler
	FROM claim.`claimant`;

-- Claimant opt in
DROP TABLE IF EXISTS claimant.`claimant_opt_in`;
CREATE TABLE claimant.`claimant_opt_in` (
	`ID` MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT,
	`FK_ClaimantID` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`OptIn` SMALLINT(1) NOT NULL DEFAULT '0',
	`OptInDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`),
	UNIQUE KEY (`FK_ClaimantID`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;

INSERT INTO claimant.`claimant_opt_in`
	SELECT * FROM claim.`claimant_opt_in`;

-- Claimant referral
DROP TABLE IF EXISTS claimant.`claimant_referral`;
CREATE TABLE claimant.`claimant_referral` (
	`ID` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`FK_ProductTypeID` SMALLINT(2) UNSIGNED NOT NULL,
	`FK_ClaimantID_Referral` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`FK_ClaimantID_Referrer` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`CreatedDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`FK_UserID_CreatedBy` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`DiallerReferenceID` INT(10) UNSIGNED NOT NULL DEFAULT '0',
	`OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`),
	KEY `claimant_referral_index1` (`FK_ClaimantID_Referral`),
	KEY `claimant_referral_index2` (`FK_ClaimantID_Referrer`),
	KEY `claimant_referral_index3` (`DiallerReferenceID`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;

INSERT INTO claimant.`claimant_referral` (ID, FK_ProductTypeID, FK_ClaimantID_Referral, FK_ClaimantID_Referrer, CreatedDateTime, FK_UserID_CreatedBy, DiallerReferenceID)
	SELECT ID, 1, FK_ClaimantID_Referral, FK_ClaimantID_Referrer, CreatedDateTime, FK_UserID_CreatedBy, DiallerReferenceID FROM claim.`claimant_referral`;

-- Address
DROP TABLE IF EXISTS claimant.`address`;
CREATE TABLE claimant.`address` (
	`ID` MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT,
	`DepartmentName` VARCHAR(60) NOT NULL DEFAULT '',
	`OrganisationName` VARCHAR(60) NOT NULL DEFAULT '',
	`SubBuildingName` VARCHAR(30) NOT NULL DEFAULT '',
	`BuildingName` VARCHAR(50) NOT NULL DEFAULT '',
	`BuildingNumber` VARCHAR(20) NOT NULL DEFAULT '',
	`DependentThoroughfare` VARCHAR(60) NOT NULL DEFAULT '',
	`Thoroughfare` VARCHAR(80) NOT NULL DEFAULT '',
	`DoubleDependentLocality` VARCHAR(35) NOT NULL DEFAULT '',
	`DependentLocality` VARCHAR(35) NOT NULL DEFAULT '',
	`Town` VARCHAR(30) NOT NULL DEFAULT '',
	`County` VARCHAR(30) NOT NULL DEFAULT '',
	`Postcode` VARCHAR(10) NOT NULL DEFAULT '',
	`PafValidatedDate` DATE NOT NULL DEFAULT '0000-00-00',
	`Timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	`OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`),
	KEY `address_index1` (`Postcode`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;

INSERT INTO claimant.address
	SELECT * FROM claim.address;

-- Previous address
DROP TABLE IF EXISTS claimant.`previous_address`;
CREATE TABLE claimant.`previous_address` (
	`ID` MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT,
	`FK_ClaimantID` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`FK_AddressID` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`FromCurrent` SMALLINT(1) UNSIGNED NOT NULL DEFAULT '0',
	`DeletedDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`FK_UserID_DeletedBy` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`),
	KEY `previous_address_index1` (`FK_ClaimantID`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;

INSERT INTO claimant.`previous_address` (`FK_ClaimantID`, `FK_AddressID`, `FromCurrent`, `DeletedDateTime`, `FK_UserID_DeletedBy`)
	SELECT FK_ClaimantID, FK_AddressID, FromCurrent, DeletedDateTime, FK_UserID_DeletedBy FROM claim.`previous_address`;

-- Change group/change item
ALTER TABLE claimant.change_item CHANGE OldValue OldString VARCHAR(255) DEFAULT NULL;
ALTER TABLE claimant.change_item CHANGE NewValue NewString VARCHAR(255) DEFAULT NULL;

INSERT INTO claimant.change_group
SELECT cg.ID, cg.FK_ClaimantID, cg.FK_UserID, cg.DateTime, 0 FROM claim.change_group cg
INNER JOIN claim.change_item ci ON cg.`ID` = ci.`FK_ChangeGroupID`
WHERE cg.`FK_ClaimID` = 0
AND (ci.`Field` LIKE 'claimant.%' OR ci.`Field` LIKE 'address.%')
GROUP BY cg.ID;

INSERT INTO claimant.`change_item`
SELECT ci.ID, ci.FK_ChangeGroupID, ci.Field, ci.OldString, ci.NewString, 0 FROM claim.change_item ci
INNER JOIN claimant.`change_group` cg ON cg.ID = ci.FK_ChangeGroupID;
