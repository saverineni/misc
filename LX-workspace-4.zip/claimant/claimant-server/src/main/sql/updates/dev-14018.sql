INSERT INTO claimant.`call_type` VALUES
(17,'plr chase loa','PLR Chase LOA'),
(18,'plr incomplete','PLR Incomplete');