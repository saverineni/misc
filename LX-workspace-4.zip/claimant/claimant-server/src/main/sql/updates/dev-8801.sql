DROP TABLE IF EXISTS claimant.`seller_account`;
CREATE TABLE claimant.`seller_account` (
  `ID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `FK_AccountID` mediumint(8) unsigned NOT NULL,
  -- GP can only accepct 15 char length values 
  `GpSellerAccount` varchar(15) NOT NULL DEFAULT '',
  `Name` varchar(32) NOT NULL DEFAULT '',
  `DisplayName` varchar(100) NOT NULL DEFAULT '',
  `SourceDescription` VARCHAR(200) NOT NULL DEFAULT '',
  `ApplicationLogo` varchar(50) NOT NULL DEFAULT '',
  `PackType` varchar(30) NOT NULL DEFAULT '',
  `DistributeAppointmentReminder` tinyint(1) NOT NULL DEFAULT '0',
  `AssessmentCallReasonGroup` varchar(32) NOT NULL DEFAULT '',
  `EmailIconImageName` varchar(32) NOT NULL DEFAULT '',
  `AssessmentInitialSmsMessageScript` varchar(64) NOT NULL DEFAULT '',
  `AssessmentInitialEmailMessageScript` varchar(64) NOT NULL DEFAULT '',
  `Web` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `AccountName` varchar(100) NOT NULL DEFAULT '', 
  `OBJ_VERSION` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `seller_account_index1` (`FK_AccountID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS claimant.`seller_account_inbound_number`;
CREATE TABLE claimant.`seller_account_inbound_number` (
  `ID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `FK_AccountID` mediumint(8) NOT NULL DEFAULT 0,
  `DDI` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `seller_account_inbound_number_index1` (`FK_AccountID`),
  UNIQUE KEY `seller_account_inbound_number_index2` (`DDI`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS claimant.`seller_account_product_type`;
CREATE TABLE claimant.`seller_account_product_type` (
	`ID` MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT,
	`FK_AccountID` MEDIUMINT(8) NOT NULL DEFAULT 0,
	`FK_ProductTypeID`TINYINT(8) NOT NULL DEFAULT 0,
	PRIMARY KEY (`ID`),
	KEY `seller_account_product_type_index1` (`FK_AccountID`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS claimant.`dropdown_configuration`;
CREATE TABLE claimant.`dropdown_configuration` (
  `ID` SMALLINT(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `FieldName` VARCHAR(100) NOT NULL DEFAULT '',
  `FieldValue` VARCHAR(100) NOT NULL DEFAULT '',
  `FieldOrder` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `dropdown_configuration_index1` (`FieldName`,`FieldValue`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS claimant.product_type;
CREATE TABLE claimant.product_type (
	`ID` TINYINT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`Name` VARCHAR(20) NOT NULL, 
	`OBJ_VERSION` smallint(5) unsigned NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`)
);



INSERT INTO claimant.`seller_account` (`FK_AccountID`,`GpSellerAccount`,`Name`,`DisplayName`,`SourceDescription`,`ApplicationLogo`,`PackType`,
											`DistributeAppointmentReminder`,`AssessmentCallReasonGroup`,`EmailIconImageName`,
											`AssessmentInitialSmsMessageScript`,`AssessmentInitialEmailMessageScript`,`Web`,`AccountName`,`OBJ_VERSION`)
SELECT * FROM claim.seller_account;

INSERT INTO claimant.`seller_account_inbound_number` 
SELECT * FROM claim.seller_account_inbound_number;

INSERT INTO claimant.`seller_account_product_type` (`FK_AccountID`, `FK_ProductTypeID`)
SELECT `ID`, 1 FROM claim.`seller_account`;

INSERT INTO claimant.`dropdown_configuration`
SELECT `ID`, `FieldName`, `FieldValue`, `FieldOrder`, 0 FROM claim.`dropdown_configuration`;

INSERT INTO claimant.product_type (ID, NAME, OBJ_VERSION) VALUES 
(1, 'PPI', 0),
(2, 'PBA', 0);
