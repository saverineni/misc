UPDATE claimant.claimant cl SET cl.`NationalInsuranceNumber` = '' WHERE cl.`ID` > 14308504 AND cl.`NationalInsuranceNumber` = 'JP467431D';
