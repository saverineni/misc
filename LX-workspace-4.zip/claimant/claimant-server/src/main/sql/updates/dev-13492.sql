ALTER TABLE `claimant`.`claimant`
  ADD COLUMN `RightToBeForgotten` TINYINT(1) DEFAULT 0  NOT NULL AFTER `FK_UserID_LockedFromDiallerUpdate`,
  ADD COLUMN `RightToBeForgottenUpdateDateTime`  DATETIME DEFAULT '0000-00-00 00:00:00' NOT NULL AFTER  `RightToBeForgotten`,
  ADD COLUMN `FK_UserID_RightToBeForgottenUpdate` MEDIUMINT(8) UNSIGNED DEFAULT 0  NOT NULL AFTER `RightToBeForgottenUpdateDateTime`,
  ADD COLUMN `RightToBeForgottenNewestClosedClaimDate` DATE DEFAULT '0000-00-00'  NOT NULL AFTER `FK_UserID_RightToBeForgottenUpdate`;