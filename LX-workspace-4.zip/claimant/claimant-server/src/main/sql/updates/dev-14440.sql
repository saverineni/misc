ALTER TABLE claimant.claimant
  ADD COLUMN `HasVulnerability` TINYINT(1) DEFAULT NULL AFTER `FK_ClaimantExecutorID`,
  ADD COLUMN `VulnerabilityCategories` SET('','V1','V2','V3','V4','V5','V6') NOT NULL DEFAULT '' AFTER `HasVulnerability`,
  ADD COLUMN `CanStoreVulnerabilityDetail` TINYINT(1) DEFAULT NULL AFTER `VulnerabilityCategories`,
  ADD COLUMN `VulnerabilityDetail` VARCHAR(1500) NOT NULL DEFAULT '' AFTER `CanStoreVulnerabilityDetail`;

UPDATE claimant.claimant cl SET cl.`HasVulnerability` = 1, cl.`VulnerabilityCategories` = ('V6'), cl.`CanStoreVulnerabilityDetail` = 0 WHERE cl.`VulnerableCustomer` = 1;

UPDATE claimant.claimant cl SET cl.`HasVulnerability` = 0 WHERE cl.`VulnerableCustomer` = 0;
