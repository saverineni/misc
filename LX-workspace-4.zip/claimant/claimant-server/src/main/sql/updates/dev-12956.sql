ALTER TABLE `claimant`.`claimant`
  ADD COLUMN `Deleted` TINYINT(1) DEFAULT 0  NOT NULL AFTER `CurrentlyInBankruptcy`,
  ADD COLUMN `DeletedDateTime` DATETIME DEFAULT '0000-00-00 00:00:00'  NOT NULL AFTER `Deleted`,
  DROP INDEX `claimant_index6`,
  ADD  INDEX `claimant_index6` (`CreatedDateTime`, `Deleted`),
  ADD  INDEX `claimant_index11` (`FK_LeadID`);