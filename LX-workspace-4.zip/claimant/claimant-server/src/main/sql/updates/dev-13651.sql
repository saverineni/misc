ALTER TABLE claimant.`seller_account` MODIFY COLUMN MethodOfContact ENUM('telephone','post','email');
