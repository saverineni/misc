ALTER TABLE claimant.`claimant_executor`
ADD COLUMN `MiddleName` VARCHAR(40) NOT NULL DEFAULT '' AFTER `Forename`,
ADD COLUMN `PreviousSurname` VARCHAR(40) NOT NULL DEFAULT '' AFTER `Surname`,
ADD COLUMN `ExecutorUpdateDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER `Email`,
ADD COLUMN `IsExecutorConfirmed` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0' AFTER `ExecutorUpdateDateTime`,
ADD COLUMN `ExecutorConfirmedUpdateDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER `IsExecutorConfirmed`;