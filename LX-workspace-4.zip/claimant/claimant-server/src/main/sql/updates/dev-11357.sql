INSERT INTO claimant.`call_type` VALUES
(14, 'ldr_q_info_req', 'Lender Questionnaire Information Required');

