CREATE TABLE claimant.`claimant_other_name` (
  `ID` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `FK_ClaimantID` INT(10) UNSIGNED NOT NULL DEFAULT '0',
  `OtherName` VARCHAR(40) NOT NULL DEFAULT '',
  `IsDeleted` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
  `OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `claimant_other_name_index1` (`FK_ClaimantID`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;

CREATE TABLE claimant.`claimant_additional_previous_name` (
  `ID` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `FK_ClaimantID` INT(10) UNSIGNED NOT NULL DEFAULT '0',
  `AdditionalPreviousName` VARCHAR(40) NOT NULL DEFAULT '',
  `IsDeleted` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
  `OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `claimant_additional_previous_name_index1` (`FK_ClaimantID`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;


ALTER TABLE claimant.`claimant` ADD COLUMN 
`AlternativeTelephone` VARCHAR(20) NOT NULL DEFAULT '' AFTER `MobileTelephone`;

ALTER TABLE claimant.`claimant` ADD KEY `claimant_index9` (`AlternativeTelephone`);