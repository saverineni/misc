ALTER TABLE claimant.`claimant` ADD COLUMN `FreePpi` TINYINT(1) NOT NULL DEFAULT '0' AFTER `FK_UserID_LockedFromDiallerUpdate`;

UPDATE claimant.`claimant` cl
INNER JOIN claimant.`seller_account` sa ON cl.`FK_AccountID_Seller` = sa.`FK_AccountID`
SET cl.`FreePpi` = sa.`FreePpi`;

UPDATE data_ops.`contact` dc
INNER JOIN data_ops.`contact_claimants` dcc ON dcc.`ContactID`=dc.`ID`
INNER JOIN claimant.`claimant` ct ON ct.`ID`=dcc.`ClaimantID`
INNER JOIN LeadX.`pla_accounts` a ON a.`ID`=dcc.`Note`
LEFT JOIN data_ops.`contact_claimants` dcc2 ON dcc2.`ClaimantID`=dcc.`ClaimantID` AND dcc2.`ContactID`<dcc.`ContactID`
SET ct.`FK_AccountID_Seller`=dcc.`Note`, ct.`FK_CompanyID_Seller`=a.`FK_CompanyID`
WHERE dc.`ContactType`='POST'
AND dcc.`Note`!=''
AND dcc2.`ClaimantID` IS NULL
AND dcc.`Note`!=ct.`FK_AccountID_Seller`;
