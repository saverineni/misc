ALTER TABLE claimant.`claimant_interaction` ADD COLUMN `Source` ENUM('SALES','PAYMENTS', 'CLAIMANT') NOT NULL DEFAULT 'SALES' AFTER `Content`;

UPDATE claimant.claimant_interaction a
   SET a.Source = 'claimant' WHERE a.content LIKE 'Referred customer%' OR content LIKE 'Created Claimant%';