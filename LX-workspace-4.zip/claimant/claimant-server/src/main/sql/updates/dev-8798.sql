ALTER TABLE claimant.claimant_log ADD `OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE claimant.claimant_log_archive DROP FK_ScheduledTaskID;
