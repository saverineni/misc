SOURCE dev-8109-address.sql;
SOURCE dev-8109-call_disposition.sql;
SOURCE dev-8109-call_log.sql;
SOURCE dev-8109-call_type.sql;
SOURCE dev-8109-claimant.sql;
SOURCE dev-8109-claimant_log.sql;
SOURCE dev-8109-claimant_log_archive.sql;
SOURCE dev-8109-claimant_opt_in.sql;
SOURCE dev-8109-claimant_referral.sql;
SOURCE dev-8109-previous_address.sql;

DROP TABLE IF EXISTS claimant.product_type;
CREATE TABLE claimant.product_type (
  `ID` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Name` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`ID`)
);
	
INSERT INTO claimant.product_type (ID, NAME) 
VALUES (1, 'PPI'),
       (2, 'PBA');

DROP TABLE IF EXISTS claimant.`change_group`;
CREATE TABLE claimant.`change_group` (
	`ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
	`FK_ClaimantID` mediumint(8) unsigned NOT NULL DEFAULT '0',
	`FK_UserID` mediumint(8) unsigned NOT NULL DEFAULT '0',
	`DateTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
	`OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`),
	KEY `change_group_index1` (`FK_ClaimantID`),
	KEY `change_group_index3` (`DateTime`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS claimant.`change_item`;
CREATE TABLE claimant.`change_item` (
	`ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
	`FK_ChangeGroupID` int(10) unsigned NOT NULL DEFAULT '0',
	`Field` varchar(255) NOT NULL DEFAULT '',
	`OldString` varchar(255) DEFAULT NULL,
	`NewString` varchar(255) DEFAULT NULL,
	`OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`),
	KEY `change_item_index1` (`FK_ChangeGroupID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;
