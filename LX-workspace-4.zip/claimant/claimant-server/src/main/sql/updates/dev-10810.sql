CREATE TABLE claimant.`address_verification_failures` (
  `ID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `FK_ClaimantID` mediumint(9) unsigned NOT NULL,
  `FK_AddressID` int(11) unsigned NOT NULL,
  `Status` enum('action_required','updated','verified','failed') NOT NULL,
  `CreatedDateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `FK_UserID_Updated` mediumint(9) unsigned DEFAULT NULL,
  `UpdatedDateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `OBJ_VERSION` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `address_verification_failures_index1` (`FK_ClaimantID`),
	KEY `address_verification_failures_index2` (`FK_AddressID`),
	KEY `address_verification_failures_index3` (`Status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;