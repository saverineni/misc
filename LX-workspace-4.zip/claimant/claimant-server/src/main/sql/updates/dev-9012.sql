CREATE TABLE claimant.`claimant_interaction` (
  `ID` INT(10) unsigned NOT NULL AUTO_INCREMENT,
  `FK_ClaimantID` MEDIUMINT(8) unsigned NOT NULL DEFAULT '0',
  `Type` ENUM('EVENT','NOTE') NOT NULL DEFAULT 'EVENT',
  `FK_UserID` MEDIUMINT(8) unsigned NOT NULL DEFAULT '0',
  `CreatedDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Content` VARCHAR(1000) NOT NULL DEFAULT '',
  `OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `claimant_interaction_index1` (`FK_ClaimantID`),
  KEY `claimant_interaction_index2` (`FK_UserID`),
  KEY `claimant_interaction_index3` (`CreatedDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE claimant.`pla_users` (
  `ID` mediumint(8) unsigned NOT NULL auto_increment,
  `Username` varchar(100) NOT NULL default '',
  `Password` varchar(36) NOT NULL default '',
  `Title` varchar(100) default NULL,
  `Forename` varchar(100) default NULL,
  `Surname` varchar(100) default NULL,
  `PhoneNumber` varchar(100) default NULL,
  `MobileNumber` varchar(100) default NULL,
  `FaxNumber` varchar(100) default NULL,
  `CreatedDateTime` datetime default NULL,
  `LastLoginDateTime` datetime default NULL,
  `FailedLoginAttempts` smallint(5) unsigned NOT NULL default '0',
  `FreshProspectsPerHour` smallint(3) unsigned NOT NULL default '0',
  `IsLocked` tinyint(1) unsigned NOT NULL default '0',
  `LockedChangedDateTime` datetime default NULL,
  `IsDeleted` tinyint(1) unsigned NOT NULL default '0',
  `DeletedChangedDateTime` datetime default NULL,
  `OBJ_VERSION` mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `PlaUsers_Index1` (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO claimant.`pla_users`
    SELECT * FROM LeadX.pla_users;
