ALTER TABLE claimant.`claimant` ADD COLUMN `CurrentlyInIva` tinyint(1) unsigned DEFAULT NULL  AFTER `FreePpi`,
ADD COLUMN `FK_IvaCompanyID` mediumint(8) NOT NULL DEFAULT '0'  AFTER `CurrentlyInIva`,
ADD COLUMN `IvaReference` varchar(25) DEFAULT NULL  AFTER `FK_IvaCompanyID`,
ADD COLUMN `CurrentlyInDebtManagementProgramme` tinyint(1) unsigned DEFAULT NULL  AFTER `IvaReference`,
ADD COLUMN `FK_DebtManagementCompanyID` mediumint(8) NOT NULL DEFAULT '0'  AFTER `CurrentlyInDebtManagementProgramme`,
ADD COLUMN `DebtManagementReference` varchar(25) DEFAULT NULL  AFTER `FK_DebtManagementCompanyID`,
ADD COLUMN `CurrentlyInBankruptcy` tinyint(1) unsigned DEFAULT NULL  AFTER `DebtManagementReference`;

CREATE TABLE claimant.`debt_management_company` (
  `ID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL DEFAULT '',
  `DepartmentName` varchar(60) NOT NULL DEFAULT '',
  `OrganisationName` varchar(60) NOT NULL DEFAULT '',
  `SubBuildingName` varchar(30) NOT NULL DEFAULT '',
  `BuildingName` varchar(50) NOT NULL DEFAULT '',
  `BuildingNumber` varchar(20) NOT NULL DEFAULT '',
  `DependentThoroughfare` varchar(60) NOT NULL DEFAULT '',
  `Thoroughfare` varchar(80) NOT NULL DEFAULT '',
  `DoubleDependentLocality` varchar(35) NOT NULL DEFAULT '',
  `DependentLocality` varchar(35) NOT NULL DEFAULT '',
  `Town` varchar(30) NOT NULL DEFAULT '',
  `County` varchar(30) NOT NULL DEFAULT '',
  `Postcode` varchar(10) NOT NULL DEFAULT '',
  `OBJ_VERSION` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE claimant.`iva_company` (
  `ID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL DEFAULT '',
  `DepartmentName` varchar(60) NOT NULL DEFAULT '',
  `OrganisationName` varchar(60) NOT NULL DEFAULT '',
  `SubBuildingName` varchar(30) NOT NULL DEFAULT '',
  `BuildingName` varchar(50) NOT NULL DEFAULT '',
  `BuildingNumber` varchar(20) NOT NULL DEFAULT '',
  `DependentThoroughfare` varchar(60) NOT NULL DEFAULT '',
  `Thoroughfare` varchar(80) NOT NULL DEFAULT '',
  `DoubleDependentLocality` varchar(35) NOT NULL DEFAULT '',
  `DependentLocality` varchar(35) NOT NULL DEFAULT '',
  `Town` varchar(30) NOT NULL DEFAULT '',
  `County` varchar(30) NOT NULL DEFAULT '',
  `Postcode` varchar(10) NOT NULL DEFAULT '',
  `OBJ_VERSION` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO claimant.`debt_management_company`
    SELECT * FROM claim.`debt_management_company`;

INSERT INTO claimant.`iva_company`
    SELECT * FROM claim.`iva_company`;

UPDATE claimant.`claimant` c JOIN claim.`ppi_claimant` pc ON c.`ID` = pc.`FK_ClaimantID`
	SET c.`CurrentlyInIva` = pc.`CurrentlyInIva`,
	 c.`IvaReference` = pc.`IvaReference` ,
	 c.`FK_IvaCompanyID` = pc.`FK_IvaCompanyID` ,
	 c.`CurrentlyInBankruptcy` = pc.`CurrentlyInBankruptcy` ,
	 c.`CurrentlyInDebtManagementProgramme` = pc.`CurrentlyInDebtManagementProgramme` ,
	 c.`FK_DebtManagementCompanyID` = pc.`FK_DebtManagementCompanyID` ,
	 c.`DebtManagementReference` = pc.`DebtManagementReference`;