ALTER TABLE claimant.`claimant`
ADD COLUMN `NationalInsuranceNumber` VARCHAR(10) NOT NULL DEFAULT '' AFTER `Email`;