INSERT INTO `claimant`.`call_disposition`  
VALUES
('93', '840', 'Silent Line');