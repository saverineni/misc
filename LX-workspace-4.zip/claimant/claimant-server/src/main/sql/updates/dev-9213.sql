INSERT INTO `claimant`.`call_disposition` (`ID`,`UltraID`,`Name`) VALUES
(74, '7001', 'Chase Call Back'),
(75, '7002', 'Chase No DMC Call back'),
(76, '7003', 'Chase Caller Hung Up'),
(77, '7004', 'Chase Refused DPA'),
(78, '7005', 'Chase Answerphone'),
(79, '7006', 'Chase NPW Claimant'),
(80, '7007', 'Chase Call Complete');
