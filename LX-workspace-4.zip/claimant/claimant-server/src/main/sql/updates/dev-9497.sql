INSERT INTO `claimant`.`call_disposition` VALUES
(82, 7009, 'Chase Wrong Department');

UPDATE `claimant`.`call_disposition` AS cd SET cd.`Name` = 'Assessment Wrong Department' WHERE cd.ID = 73 AND cd.`UltraID` = 620;