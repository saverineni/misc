INSERT INTO `claimant`.`call_type` (`ID`,`Name`,`Description`) VALUES 
(11, 'remediation', 'LBG Remediation');