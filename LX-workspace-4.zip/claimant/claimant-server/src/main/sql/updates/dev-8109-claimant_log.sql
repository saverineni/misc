DROP TABLE IF EXISTS claimant.`claimant_log`;
CREATE TABLE claimant.`claimant_log` (
	`ID` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`FK_ClaimantID` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`FK_ScheduledTaskID` INT(10) UNSIGNED NOT NULL DEFAULT '0',
	`OpenedDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`ClosedDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`FK_UserID` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`),
	KEY `claimant_log_index1` (`FK_ClaimantID`),
	KEY `claimant_log_index2` (`FK_ScheduledTaskID`),
	KEY `claimant_log_index3` (`FK_UserID`),
	KEY `claimant_log_index4` (`OpenedDateTime`),
	KEY ` claimant_log_index5` (`ClosedDateTime`,`OpenedDateTime`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;

INSERT INTO claimant.`claimant_log`
	SELECT * FROM claim.`claimant_log`;
