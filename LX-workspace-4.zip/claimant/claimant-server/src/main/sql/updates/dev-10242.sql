INSERT INTO `claimant`.`call_type`
VALUES (12, 'ldr_q_bau','Lender Questionnaire BAU');

INSERT INTO `claimant`.`call_disposition`
VALUES
  (94, '2910', 'Lender Questionnaire BAU Callback'),
  (95, '2920', 'Lender Questionnaire BAU No DMC - Callback'),
  (96, '2930', 'Lender Questionnaire BAU Answerphone'),
  (97, '2940', 'Lender Questionnaire BAU Caller Hung Up'),
  (98, '2950', 'Lender Questionnaire BAU Call Complete');

 /** Lender Questionnaire LOA Required  **/ 
  
INSERT INTO `claimant`.`call_type`
VALUES (13, 'ldr_q_loa_req','Lender Questionnaire LOA Required');

INSERT INTO `claimant`.`call_disposition`
VALUES
  (99, '3010', 'Lender Questionnaire LOA Required Callback'),
  (100, '3020', 'Lender Questionnaire LOA Required No DMC - Callback'),
  (101, '3030', 'Lender Questionnaire LOA Required Answerphone'),
  (102, '3040', 'Lender Questionnaire LOA Required Caller Hung Up'),
  (103, '3050', 'Lender Questionnaire LOA Required Call Complete');