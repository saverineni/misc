ALTER TABLE claimant.`seller_account`
  MODIFY COLUMN `MethodOfContact` ENUM('telephone','post','email','esignature') NOT NULL DEFAULT 'telephone';

UPDATE claimant.`seller_account` sa SET sa.`MethodOfContact` = 'esignature' WHERE sa.`FK_AccountID` = 13120;
