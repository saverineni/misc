INSERT INTO claimant.`claimant_contact_preference` (FK_ClaimantID, TelephoneOptIn, EmailOptIn, SmsOptIn, MarketingMailingOptIn, FK_UserID_Updated)
SELECT c.ID, 1, 0, 1, 1, 3388 FROM distribution.`never_contact` n JOIN claimant.claimant c ON n.`EmailAddress` = c.`Email`
ON DUPLICATE KEY UPDATE EmailOptIn = 0;

INSERT INTO claimant.`claimant_contact_preference` (FK_ClaimantID, TelephoneOptIn, EmailOptIn, SmsOptIn, MarketingMailingOptIn, FK_UserID_Updated)
SELECT c.ID, 0, 1, 1, 1, 3388 FROM telephony.`never_dial` n JOIN claimant.claimant c ON n.TelephoneNumber = c.HomeTelephone
ON DUPLICATE KEY UPDATE TelephoneOptIn = 0;

INSERT INTO claimant.`claimant_contact_preference` (FK_ClaimantID, TelephoneOptIn, EmailOptIn, SmsOptIn, MarketingMailingOptIn, FK_UserID_Updated)
SELECT c.ID, 0, 1, 1, 1, 3388 FROM telephony.`never_dial` n JOIN claimant.claimant c ON n.TelephoneNumber = c.MobileTelephone
ON DUPLICATE KEY UPDATE TelephoneOptIn = 0;

INSERT INTO claimant.`claimant_contact_preference` (FK_ClaimantID, TelephoneOptIn, EmailOptIn, SmsOptIn, MarketingMailingOptIn, FK_UserID_Updated)
SELECT c.ID, 1, 0, 1, 1, 3388 FROM data_ops.`pure360_email_optout` p JOIN claimant.claimant c ON p.`Email` = c.`Email` WHERE p.Type = 'Opt-out'
ON DUPLICATE KEY UPDATE EmailOptIn = 0;


-- Note: Update the Timestamp value below:
-- ---------------------------------------
INSERT INTO claimant.`claimant_interaction` (`FK_ClaimantID`, `Type`, `FK_UserID`, `CreatedDateTime`, `Content`, `Source`)
SELECT c.FK_ClaimantID, 'EVENT', 3388, CURRENT_TIME, 'Contact Preferences updated from initial migration', 'CLAIMANT'
FROM claimant.`claimant_contact_preference` c WHERE c.`Timestamp` > '2018-05-22 08:00:00';
