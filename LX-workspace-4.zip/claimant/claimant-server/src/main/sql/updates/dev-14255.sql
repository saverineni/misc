INSERT INTO claimant.`product_type`
VALUES(4,'INV',0);