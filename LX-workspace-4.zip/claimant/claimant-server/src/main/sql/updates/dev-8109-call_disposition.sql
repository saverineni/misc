DROP TABLE IF EXISTS claimant.`call_disposition`;
CREATE TABLE claimant.`call_disposition` (
	`ID` MEDIUMINT(8) UNSIGNED NOT NULL,
	`UltraID` VARCHAR(16) DEFAULT '',
	`Name` VARCHAR(60) NOT NULL DEFAULT '',
	PRIMARY KEY (`ID`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;

INSERT INTO claimant.`call_disposition`
	SELECT * FROM claim.`call_disposition`;
