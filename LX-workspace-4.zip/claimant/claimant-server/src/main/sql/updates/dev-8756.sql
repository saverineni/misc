ALTER TABLE claimant.claimant ADD COLUMN `Password` VARCHAR(36) DEFAULT '' AFTER `Email`;

ALTER TABLE claimant.claimant ADD COLUMN `PasswordDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER `Password`;
