INSERT INTO `claimant`.`call_type` (`ID`, `Name`, `Description`)
VALUES (10, 'ldr_q_ppi_check', 'Lender Questionnaire PPI Check');

INSERT INTO `claimant`.`call_disposition` (`ID`, `UltraID`, `Name`) VALUES 
(83, 2710, 'Lender Questionnaire PPI Check Callback'),
(84, 2720, 'Lender Questionnaire PPI Check No DMC - Callback'),
(85, 2730, 'Lender Questionnaire PPI Check Answerphone'),
(86, 2740, 'Lender Questionnaire PPI Check Caller Hung Up'),
(87, 2750, 'Lender Questionnaire PPI Check Call Complete');