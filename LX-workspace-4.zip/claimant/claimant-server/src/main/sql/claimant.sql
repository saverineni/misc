DROP DATABASE IF EXISTS claimant;
CREATE DATABASE claimant;

-- 
-- Table structure for table `address`
--

DROP TABLE IF EXISTS claimant.`address`;
CREATE TABLE claimant.`address` (
  `ID` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`DepartmentName` VARCHAR(60) NOT NULL DEFAULT '',
	`OrganisationName` VARCHAR(60) NOT NULL DEFAULT '',
	`SubBuildingName` VARCHAR(30) NOT NULL DEFAULT '',
	`BuildingName` VARCHAR(50) NOT NULL DEFAULT '',
	`BuildingNumber` VARCHAR(20) NOT NULL DEFAULT '',
	`DependentThoroughfare` VARCHAR(60) NOT NULL DEFAULT '',
	`Thoroughfare` VARCHAR(80) NOT NULL DEFAULT '',
	`DoubleDependentLocality` VARCHAR(35) NOT NULL DEFAULT '',
	`DependentLocality` VARCHAR(35) NOT NULL DEFAULT '',
	`Town` VARCHAR(30) NOT NULL DEFAULT '',
	`County` VARCHAR(30) NOT NULL DEFAULT '',
	`Postcode` VARCHAR(10) NOT NULL DEFAULT '',
	`PafValidatedDate` DATE NOT NULL DEFAULT '0000-00-00',
	`Timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	`OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`),
	KEY `address_index1` (`Postcode`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;


-- 
-- Table structure for table `application_property`
--

DROP TABLE IF EXISTS claimant.`application_property`;
CREATE TABLE claimant.`application_property`(
	`Property` VARCHAR(128),
	`PropertyValue` VARCHAR(128),
	PRIMARY KEY (`Property`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 
-- Table structure for table `call_disposition`
--

DROP TABLE IF EXISTS claimant.`call_disposition`;
CREATE TABLE claimant.`call_disposition` (
	`ID` MEDIUMINT(8) UNSIGNED NOT NULL,
	`UltraID` VARCHAR(16) DEFAULT '',
	`Name` VARCHAR(60) NOT NULL DEFAULT '',
	`DMC` tinyint(1) NOT NULL DEFAULT 0, 
	PRIMARY KEY (`ID`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;


-- 
-- Table structure for table `call_log`
--

DROP TABLE IF EXISTS claimant.`call_log`;
CREATE TABLE claimant.`call_log` (
	`ID` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`FK_ClaimantID` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`FK_CallTypeID` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`FK_CallDispositionID` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`FK_UserID_Agent` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`DiallerReferenceID` INT(10) UNSIGNED NOT NULL DEFAULT '0',
	`Inbound` SMALLINT(1) NOT NULL DEFAULT '0',
	`DispositionDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`),
	KEY `call_log_index1` (`FK_ClaimantID`),
	KEY `call_log_index2` (`DispositionDateTime`),
	KEY `call_log_index3` (`DiallerReferenceID`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;


-- 
-- Table structure for table `call_type`
--

DROP TABLE IF EXISTS claimant.`call_type`;
CREATE TABLE claimant.`call_type` (
	`ID` MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT,
	`Name` VARCHAR(30) NOT NULL DEFAULT '',
	`Description` VARCHAR(255) NOT NULL DEFAULT '',
	PRIMARY KEY (`ID`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;


-- 
-- Table structure for table `change_group`
--

DROP TABLE IF EXISTS claimant.`change_group`;
CREATE TABLE claimant.`change_group` (
	`ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
	`FK_ClaimantID` mediumint(8) unsigned NOT NULL DEFAULT '0',
	`FK_UserID` mediumint(8) unsigned NOT NULL DEFAULT '0',
	`DateTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
	`OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`),
	KEY `change_group_index1` (`FK_ClaimantID`),
	KEY `change_group_index3` (`DateTime`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

-- 
-- Table structure for table `change_item`
--

DROP TABLE IF EXISTS claimant.`change_item`;
CREATE TABLE claimant.`change_item` (
	`ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
	`FK_ChangeGroupID` int(10) unsigned NOT NULL DEFAULT '0',
	`Field` varchar(255) NOT NULL DEFAULT '',
	`OldString` varchar(255) DEFAULT NULL,
	`NewString` varchar(255) DEFAULT NULL,
	`OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`),
	KEY `change_item_index1` (`FK_ChangeGroupID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

-- 
-- Table structure for table `claimant`
--

DROP TABLE IF EXISTS claimant.`claimant`;
CREATE TABLE claimant.`claimant` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `FK_LeadID` int(10) unsigned NOT NULL DEFAULT '0',
  `FK_CompanyID_Seller` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `FK_AccountID_Seller` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `Title` varchar(10) NOT NULL DEFAULT '',
  `Forename` varchar(40) NOT NULL DEFAULT '',
  `MiddleName` varchar(40) NOT NULL DEFAULT '',
  `Surname` varchar(40) NOT NULL DEFAULT '',
  `PreviousSurname` varchar(40) NOT NULL DEFAULT '',
  `Dob` date NOT NULL DEFAULT '0000-00-00',
  `FK_AddressID` int(10) unsigned NOT NULL DEFAULT '0',
  `HomeTelephone` varchar(20) NOT NULL DEFAULT '',
  `MobileTelephone` varchar(20) NOT NULL DEFAULT '',
  `AlternativeTelephone` varchar(20) NOT NULL DEFAULT '',
  `WorkTelephone` varchar(20) NOT NULL DEFAULT '',
  `Email` varchar(100) NOT NULL DEFAULT '',
  `NationalInsuranceNumber` varchar(10) NOT NULL DEFAULT '',
  `Password` varchar(36) DEFAULT '',
	`PasswordDateTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `CreatedDateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `SuppressedDateTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `LockedFromDialler` tinyint(1) NOT NULL DEFAULT '0',
  `LockedFromDiallerUpdateDateTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `FK_UserID_LockedFromDiallerUpdate` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `RightToBeForgotten` TINYINT(1) DEFAULT 0  NOT NULL,
  `RightToBeForgottenUpdateDateTime`  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `FK_UserID_RightToBeForgottenUpdate` MEDIUMINT(8) UNSIGNED DEFAULT 0  NOT NULL,
  `RightToBeForgottenNewestClosedClaimDate` DATE DEFAULT '0000-00-00'  NOT NULL,
  `VulnerableCustomer` tinyint(1) NOT NULL DEFAULT '0',
  `VulnerableCustomerUpdateDateTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `FK_UserID_VulnerableCustomerUpdate` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `VulnerableCustomerReviewDate` date NOT NULL DEFAULT '0000-00-00',
  `IncorrectAddress` tinyint(1) NOT NULL DEFAULT '0',
  `IncorrectAddressUpdateDateTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `FreePpi` tinyint(1) NOT NULL DEFAULT '0',
  `FormalDebtArrangement` ENUM('yes','no','unsure') DEFAULT NULL,
  `FormalDebtArrangementType` set('debtrelieforder','iva','bankruptcy','protectedtrustdeed','sequestration','debtarrangementscheme','adminorder') DEFAULT NULL,
  `CurrentlyInIva` tinyint(1) unsigned DEFAULT NULL,
  `FK_IvaCompanyID` mediumint(8) NOT NULL DEFAULT '0',
  `IvaReference` varchar(25) DEFAULT NULL,
  `InformalDebtArrangement` ENUM('yes','no','unsure') DEFAULT NULL,
  `CurrentlyInDebtManagementProgramme` tinyint(1) unsigned DEFAULT NULL,
  `FK_DebtManagementCompanyID` mediumint(8) NOT NULL DEFAULT '0',
  `DebtManagementReference` varchar(25) DEFAULT NULL,
  `CurrentlyInBankruptcy` tinyint(1) unsigned DEFAULT NULL,
  `Deleted` TINYINT(1) DEFAULT 0  NOT NULL,
  `DeletedDateTime` DATETIME DEFAULT '0000-00-00 00:00:00'  NOT NULL,
  `FK_ClaimantExecutorID` int(10) unsigned,
  `HasVulnerability` tinyint(1) DEFAULT NULL,
  `VulnerabilityCategories` set('','V1','V2','V3','V4','V5','V6') NOT NULL DEFAULT '',
  `CanStoreVulnerabilityDetail` ENUM('yes','no','written') DEFAULT NULL,
  `VulnerabilityDetail` varchar(1500) NOT NULL DEFAULT '',
  `Timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `OBJ_VERSION` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `claimant_index1` (`Surname`),
  KEY `claimant_index2` (`FK_AddressID`),
  KEY `claimant_index3` (`HomeTelephone`),
  KEY `claimant_index4` (`MobileTelephone`),
  KEY `claimant_index5` (`WorkTelephone`),
  KEY `claimant_index6` (`CreatedDateTime`, `Deleted`),
  KEY `claimant_index7` (`FK_AccountID_Seller`),
  KEY `claimant_index8` (`LockedFromDiallerUpdateDateTime`),
  KEY `claimant_index9` (`AlternativeTelephone`),
  KEY `claimant_index10` (`Email`),
  KEY `claimant_index11` (`FK_LeadID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `claimant_additional_previous_name`
--

DROP TABLE IF EXISTS claimant.`claimant_additional_previous_name`;
CREATE TABLE claimant.`claimant_additional_previous_name` (
  `ID` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `FK_ClaimantID` INT(10) UNSIGNED NOT NULL DEFAULT '0',
  `AdditionalPreviousName` VARCHAR(40) NOT NULL DEFAULT '',
  `IsDeleted` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
  `OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `claimant_additional_previous_name_index1` (`FK_ClaimantID`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;

--
-- Table structure for table `claimant_contact_preference`
--
DROP TABLE IF EXISTS claimant.`claimant_contact_preference`;
CREATE TABLE claimant.`claimant_contact_preference` (
  `ID` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `FK_ClaimantID` INT(10) UNSIGNED NOT NULL DEFAULT '0',
  `TelephoneOptIn` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
  `EmailOptIn` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
  `SmsOptIn` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
  `MarketingMailingOptIn` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
  `Cancellation` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
  `FK_UserID_Updated` MEDIUMINT(9) UNSIGNED NOT NULL DEFAULT '0',
  `Timestamp` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `claimant_contact_preference_index1` (`FK_ClaimantID`),
  KEY `claimant_contact_preference_index2` (`Timestamp`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;

--
-- Table structure for table `claimant_executor`
--

DROP TABLE IF EXISTS claimant.`claimant_executor`;
CREATE TABLE claimant.`claimant_executor` (
	`ID` MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT,
	`FK_ClaimantID` INT(10) UNSIGNED NOT NULL DEFAULT '0',
	`Title` VARCHAR(10) NOT NULL DEFAULT '',
	`Forename` VARCHAR(40) NOT NULL DEFAULT '',
	`MiddleName` VARCHAR(40) NOT NULL DEFAULT '',
	`Surname` VARCHAR(40) NOT NULL DEFAULT '',
	`PreviousSurname` VARCHAR(40) NOT NULL DEFAULT '',
	`Dob` DATE NOT NULL DEFAULT '0000-00-00',
	`FK_AddressID` INT(10) UNSIGNED NOT NULL DEFAULT '0',
	`HomeTelephone` VARCHAR(20) NOT NULL DEFAULT '',
	`MobileTelephone` VARCHAR(20) NOT NULL DEFAULT '',
	`Email` VARCHAR(100) NOT NULL DEFAULT '',
	`ExecutorUpdateDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`IsExecutorConfirmed` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
	`ExecutorConfirmedUpdateDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`CreatedDateTime` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`Timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	`IsDeleted` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
	`OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY(`ID`),
	KEY `claimant_executor_index1` (`FK_ClaimantID`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;

--
-- Table structure for table 'claimant_group_allocation'
--
DROP TABLE IF EXISTS claimant.`claimant_group_allocation`;
CREATE TABLE claimant.`claimant_group_allocation` (
  `ID` MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `FK_ClaimantID` MEDIUMINT(8) UNSIGNED NOT NULL,
  `CallReason` VARCHAR(16) NOT NULL DEFAULT '',
  `CallReasonGroup` VARCHAR(25) NOT NULL DEFAULT '',
  `CallGroupAllocationDateTime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `IsDeleted` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
  `OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `claimant_group_allocation_index1` (`FK_ClaimantID`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;


-- 
-- Table structure for table `claimant_interaction`
--

DROP TABLE IF EXISTS claimant.`claimant_interaction`;
CREATE TABLE claimant.`claimant_interaction` (
  `ID` INT(10) unsigned NOT NULL AUTO_INCREMENT,
  `FK_ClaimantID` MEDIUMINT(8) unsigned NOT NULL DEFAULT '0',
  `FK_ProductTypeID` SMALLINT(5) unsigned DEFAULT NULL,
  `Type` ENUM('EVENT','NOTE') NOT NULL DEFAULT 'EVENT',
  `FK_UserID` MEDIUMINT(8) unsigned NOT NULL DEFAULT '0',
  `CreatedDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Content` VARCHAR(1000) NOT NULL DEFAULT '',
  `Source` ENUM('SALES','PAYMENTS', 'CLAIMANT', 'PORTAL', 'LOGICLAIM') NOT NULL DEFAULT 'SALES',
  `OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `claimant_interaction_index1` (`FK_ClaimantID`),
  KEY `claimant_interaction_index2` (`FK_UserID`),
  KEY `claimant_interaction_index3` (`CreatedDateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Table structure for table `claimant_log`
--

DROP TABLE IF EXISTS claimant.`claimant_log`;
CREATE TABLE claimant.`claimant_log` (
	`ID` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`FK_ClaimantID` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`FK_ScheduledTaskID` int(10) unsigned NOT NULL DEFAULT '0',
	`OpenedDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`ClosedDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`FK_UserID` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`),
	KEY `claimant_log_index1` (`FK_ClaimantID`),
	KEY `claimant_log_index2` (`FK_UserID`),
	KEY `claimant_log_index3` (`OpenedDateTime`),
	KEY ` claimant_log_index4` (`ClosedDateTime`,`OpenedDateTime`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;

--
-- Table structure for table `claimant_log_archive`
--

DROP TABLE IF EXISTS claimant.`claimant_log_archive`;
CREATE TABLE claimant.`claimant_log_archive` (
	`ID` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`FK_ClaimantID` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`OpenedDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`ClosedDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`FK_UserID` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;

-- 
-- Table structure for table `claimant_opt_in`
--

DROP TABLE IF EXISTS claimant.`claimant_opt_in`;
CREATE TABLE claimant.`claimant_opt_in` (
	`ID` MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT,
	`FK_ClaimantID` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`OptIn` SMALLINT(1) NOT NULL DEFAULT '0',
	`OptInDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`),
	UNIQUE KEY (`FK_ClaimantID`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;

--
-- Table structure for table `claimant_other_name`
--

DROP TABLE IF EXISTS claimant.`claimant_other_name`;
CREATE TABLE claimant.`claimant_other_name` (
  `ID` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `FK_ClaimantID` INT(10) UNSIGNED NOT NULL DEFAULT '0',
  `OtherName` VARCHAR(40) NOT NULL DEFAULT '',
  `IsDeleted` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
  `OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `claimant_other_name_index1` (`FK_ClaimantID`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;

-- 
-- Table structure for table `claimant_referral`
--

DROP TABLE IF EXISTS claimant.`claimant_referral`;
CREATE TABLE claimant.`claimant_referral` (
	`ID` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`FK_ProductTypeID` SMALLINT(2) UNSIGNED NOT NULL,
	`FK_ClaimantID_Referral` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`FK_ClaimantID_Referrer` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`CreatedDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`FK_UserID_CreatedBy` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`DiallerReferenceID` INT(10) UNSIGNED NOT NULL DEFAULT '0',
	`OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`),
	KEY `claimanat_referral_index1` (`FK_ClaimantID_Referral`),
	KEY `claimanat_referral_index2` (`FK_ClaimantID_Referrer`),
	KEY `claimanat_referral_index3` (`DiallerReferenceID`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;

-- 
-- Table structure for table `dropdown_configuration`
--

DROP TABLE IF EXISTS claimant.`dropdown_configuration`;
CREATE TABLE claimant.`dropdown_configuration` (
  `ID` SMALLINT(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `FieldName` VARCHAR(100) NOT NULL DEFAULT '',
  `FieldValue` VARCHAR(100) NOT NULL DEFAULT '',
  `FieldOrder` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `dropdown_configuration_index1` (`FieldName`,`FieldValue`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;


--
-- Table structure for table `lead_type`
--

DROP TABLE IF EXISTS claimant.`lead_type`;
CREATE TABLE claimant.`lead_type` (
  `ID` TINYINT(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Name` VARCHAR(60) NOT NULL DEFAULT '',
  `OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;

--
-- Table structure for table `previous_address`
--

DROP TABLE IF EXISTS claimant.`previous_address`;
CREATE TABLE claimant.`previous_address` (
	`ID` MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT,
	`FK_ClaimantID` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
  `FK_AddressID` INT(10) UNSIGNED NOT NULL DEFAULT '0',
	`FromCurrent` SMALLINT(1) UNSIGNED NOT NULL DEFAULT '0',
	`DeletedDateTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`FK_UserID_DeletedBy` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
	`OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`),
	KEY `previous_address_index1` (`FK_ClaimantID`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;


-- 
-- Table structure for table `product_type`
--

DROP TABLE IF EXISTS claimant.product_type;
CREATE TABLE claimant.product_type (
	`ID` TINYINT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`Name` VARCHAR(20) NOT NULL, 
	`OBJ_VERSION` smallint(5) unsigned NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`)
);


--
-- Table structure for table `seller_account`
--

DROP TABLE IF EXISTS claimant.`seller_account`;
CREATE TABLE claimant.`seller_account` (
  `ID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `FK_ProductTypeID` smallint(5) unsigned NOT NULL,
  `FK_AccountID` mediumint(8) unsigned NOT NULL,
  -- GP can only accepct 15 char length values
  `GpSellerAccount` varchar(15) NOT NULL DEFAULT '',
  `Name` varchar(32) NOT NULL DEFAULT '',
  `DisplayName` varchar(100) NOT NULL DEFAULT '',
  `SourceDescription` varchar(200) NOT NULL DEFAULT '',
  `MethodOfContact` ENUM('telephone','post','email','esignature') NOT NULL DEFAULT 'telephone',
  `ApplicationLogo` varchar(50) NOT NULL DEFAULT '',
  `PackType` varchar(30) NOT NULL DEFAULT '',
  `DistributeAppointmentReminder` tinyint(1) NOT NULL DEFAULT '0',
  `AssessmentCallReasonGroup` varchar(32) NOT NULL DEFAULT '',
  `EmailIconImageName` varchar(32) NOT NULL DEFAULT '',
  `AssessmentInitialSmsMessageScript` varchar(64) NOT NULL DEFAULT '',
  `AssessmentInitialEmailMessageScript` varchar(64) NOT NULL DEFAULT '',
  `Web` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `AccountName` varchar(100) NOT NULL DEFAULT '',
  `FreePpi` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `FK_LeadTypeID` tinyint(3) unsigned DEFAULT NULL,
  `Category` varchar(100) NOT NULL DEFAULT '',
  `Group` varchar(100) NOT NULL DEFAULT '',
  `OBJ_VERSION` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `seller_account_index1` (`FK_AccountID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Table structure for table `seller_account_inbound_number`
--

DROP TABLE IF EXISTS claimant.`seller_account_inbound_number`;
CREATE TABLE claimant.`seller_account_inbound_number` (
  `ID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `FK_AccountID` mediumint(8) NOT NULL DEFAULT 0,
  `DDI` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `seller_account_inbound_number_index1` (`FK_AccountID`),
  UNIQUE KEY `seller_account_inbound_number_index2` (`DDI`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS claimant.`pla_users`;
CREATE TABLE claimant.`pla_users` (
	`ID` mediumint(8) unsigned NOT NULL auto_increment,
	`Username` varchar(100) NOT NULL default '',
	`Password` varchar(36) NOT NULL default '',
	`Title` varchar(100) default NULL,
	`Forename` varchar(100) default NULL,
	`Surname` varchar(100) default NULL,
	`PhoneNumber` varchar(100) default NULL,
	`MobileNumber` varchar(100) default NULL,
	`FaxNumber` varchar(100) default NULL,
	`CreatedDateTime` datetime default NULL,
	`LastLoginDateTime` datetime default NULL,
	`FailedLoginAttempts` smallint(5) unsigned NOT NULL default '0',
	`FreshProspectsPerHour` smallint(3) unsigned NOT NULL default '0',
	`IsLocked` tinyint(1) unsigned NOT NULL default '0',
	`LockedChangedDateTime` datetime default NULL,
	`IsDeleted` tinyint(1) unsigned NOT NULL default '0',
	`DeletedChangedDateTime` datetime default NULL,
	`OBJ_VERSION` mediumint(8) unsigned NOT NULL default '0',
	PRIMARY KEY  (`ID`),
	UNIQUE KEY `PlaUsers_Index1` (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `address_verification_failures`
--

DROP TABLE IF EXISTS claimant.`address_verification_failures`;
CREATE TABLE claimant.`address_verification_failures` (
  `ID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `FK_ClaimantID` mediumint(9) unsigned NOT NULL,
  `FK_AddressID` int(11) unsigned NOT NULL,
  `Status` enum('action_required','updated','verified','failed') NOT NULL,
  `CreatedDateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `FK_UserID_Updated` mediumint(9) unsigned DEFAULT NULL,
  `UpdatedDateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `OBJ_VERSION` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `address_verification_failures_index1` (`FK_ClaimantID`),
	KEY `address_verification_failures_index2` (`FK_AddressID`),
	KEY `address_verification_failures_index3` (`Status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Table structure for table `iva_company`
--

DROP TABLE IF EXISTS claimant.`iva_company`;


CREATE TABLE claimant.`iva_company` (
  `ID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL DEFAULT '',
  `DepartmentName` varchar(60) NOT NULL DEFAULT '',
  `OrganisationName` varchar(60) NOT NULL DEFAULT '',
  `SubBuildingName` varchar(30) NOT NULL DEFAULT '',
  `BuildingName` varchar(50) NOT NULL DEFAULT '',
  `BuildingNumber` varchar(20) NOT NULL DEFAULT '',
  `DependentThoroughfare` varchar(60) NOT NULL DEFAULT '',
  `Thoroughfare` varchar(80) NOT NULL DEFAULT '',
  `DoubleDependentLocality` varchar(35) NOT NULL DEFAULT '',
  `DependentLocality` varchar(35) NOT NULL DEFAULT '',
  `Town` varchar(30) NOT NULL DEFAULT '',
  `County` varchar(30) NOT NULL DEFAULT '',
  `Postcode` varchar(10) NOT NULL DEFAULT '',
  `OBJ_VERSION` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Table structure for table `debt_management_company`
--

DROP TABLE IF EXISTS claimant.`debt_management_company`;


CREATE TABLE claimant.`debt_management_company` (
  `ID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL DEFAULT '',
  `DepartmentName` varchar(60) NOT NULL DEFAULT '',
  `OrganisationName` varchar(60) NOT NULL DEFAULT '',
  `SubBuildingName` varchar(30) NOT NULL DEFAULT '',
  `BuildingName` varchar(50) NOT NULL DEFAULT '',
  `BuildingNumber` varchar(20) NOT NULL DEFAULT '',
  `DependentThoroughfare` varchar(60) NOT NULL DEFAULT '',
  `Thoroughfare` varchar(80) NOT NULL DEFAULT '',
  `DoubleDependentLocality` varchar(35) NOT NULL DEFAULT '',
  `DependentLocality` varchar(35) NOT NULL DEFAULT '',
  `Town` varchar(30) NOT NULL DEFAULT '',
  `County` varchar(30) NOT NULL DEFAULT '',
  `Postcode` varchar(10) NOT NULL DEFAULT '',
  `OBJ_VERSION` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `unpresented_cheque`
--

DROP TABLE IF EXISTS claimant.`claimant_unpresented_cheque`;

CREATE TABLE claimant.`claimant_unpresented_cheque` (
  `ID` MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `FK_ClaimantID` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
  `DateChequeIssued` DATE NOT NULL DEFAULT '0000-00-00',
  `Amount` DECIMAL(10,2) NOT NULL DEFAULT '0.00',
  `Timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `unpresented_cheque_index1` (`FK_ClaimantID`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;

--
-- Table structure for table `claimant_previous_email`
--

DROP TABLE IF EXISTS claimant.`claimant_previous_email`;

CREATE TABLE claimant.`claimant_previous_email` (
  `ID` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `FK_ClaimantID` INT(10) UNSIGNED NOT NULL DEFAULT '0',
  `PreviousEmail` VARCHAR(100) NOT NULL DEFAULT '',
  `IsDeleted` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
  `OBJ_VERSION` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `claimant_previous_email_index1` (`FK_ClaimantID`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;
