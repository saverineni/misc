package com.leadx.claimant.claimantservice;

import com.leadx.claimant.client.ClaimantUnpresentedChequeDto;

import java.math.BigDecimal;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import static com.leadx.lib.utl.JodaUtils.britishDateStringToLocalDateOrNull;
import static java.util.Objects.isNull;
import static org.apache.commons.lang.StringUtils.isBlank;

@Component("claimantUnpresentedChequeDtoConverter")
public class ClaimantUnpresentedChequeDtoConverter implements Converter<ClaimantUnpresentedChequeDto, ClaimantUnpresentedCheque> {

	@Override
	public ClaimantUnpresentedCheque convert(ClaimantUnpresentedChequeDto source) {
		if (isNull(source)) {
			return null;
		}

		ClaimantUnpresentedCheque claimantUnpresentedCheque = new ClaimantUnpresentedCheque();
		claimantUnpresentedCheque.setId(source.getId() == 0 ? null : source.getId());
		claimantUnpresentedCheque.setClaimantId(source.getClaimantId());
		claimantUnpresentedCheque.setDateChequeIssued(britishDateStringToLocalDateOrNull(source.getDateChequeIssued()));
		claimantUnpresentedCheque.setAmount(isBlank(source.getAmount()) ? new BigDecimal("0.00") : new BigDecimal(source.getAmount()));
		claimantUnpresentedCheque.setVersion(source.getVersion());

		return claimantUnpresentedCheque;
	}
}
