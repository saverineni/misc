package com.leadx.claimant.lead;

import static org.apache.commons.collections.CollectionUtils.isNotEmpty;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.leadx.claimant.client.ClaimantLead;
import com.leadx.services.claims.client.ClaimRequest;

@Component
public class ClaimantFilter {

	@Value("#{'${selleraccounts.address.verification.required}'.split(',')}")
	private List<Integer> sellerAccountsRequiringAddressVerification;

	public boolean shouldUpdateClaimant(final ClaimRequest claimRequest) {
		return claimRequest.getClaimant().getId() != 0;
	}

	public boolean shouldVerifyAddress(final ClaimantLead claimantLead) {
		final int sellerAccountId = claimantLead.getClaimRequest().getSellerAccountId();

		if(isNotEmpty(sellerAccountsRequiringAddressVerification) && sellerAccountsRequiringAddressVerification.contains(sellerAccountId)){
			return true;
		}

		return false;
	}
}
