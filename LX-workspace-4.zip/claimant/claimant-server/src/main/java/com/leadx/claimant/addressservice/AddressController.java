package com.leadx.claimant.addressservice;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

import javax.persistence.OptimisticLockException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.hibernate4.HibernateOptimisticLockingFailureException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.leadx.claimant.client.*;
import com.leadx.lib.utl.json.JsonUtils;

@RequestMapping(value = "/address")
@Controller
public class AddressController {
	private static final Logger LOG = LoggerFactory.getLogger(AddressController.class);

	@Autowired
	private AddressService addressService;

	@Autowired
	private Converter<AddressDto, Address> addressDtoConverter;

	@Autowired
	private Converter<Collection<Address>, Collection<AddressDto>> addressesConverter;

	@Autowired
	private Converter<Address, AddressDto> addressConverter;

	@Autowired
	private Converter<PreviousAddress, PreviousAddressDto> previousAddressConverter;

	@ResponseBody
	@RequestMapping(value = "/id/{id}", method = RequestMethod.GET)
	public AddressDto getAddressById(@PathVariable final int id) {
		LOG.debug("getAddressById " + id);
		return this.addressConverter.convert(this.addressService.getAddressById(id));
	}

	@ResponseBody
	@RequestMapping(value = "/ids/{csvIds}", method = RequestMethod.GET)
	public Collection<AddressDto> getAddressesByIds(@PathVariable final String csvIds) {
		LOG.debug("getAddressesByIds " + csvIds);
		try {
			final String[] idsStr = csvIds.split(",");
			final ImmutableList.Builder<Integer> ids = new ImmutableList.Builder<>();
			for ( final String idStr: idsStr ) {
				ids.add(Integer.parseInt(idStr.trim()));  // can throw exception back to call if not an integer
			}

			final Collection<Address> addresses = this.addressService.getAddressesByIds(ids.build());

			return this.addressesConverter.convert(addresses);
		} catch ( final Exception e ) {
			LOG.error("getAddressesByIds ids " + csvIds + " failed", e);
			throw e;
		}
	}


	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ResponseEntity<Integer> saveAddress(@RequestBody final String newAddressDto) {
		final SaveAddressDto deserialized = JsonUtils.deserialize(newAddressDto, SaveAddressDto.class);

		final Address newAddress = this.addressDtoConverter.convert(deserialized.getAddressDto());
		final int claimantId = deserialized.getClaimantId();
		final boolean markAsPafValidated = deserialized.getMarkAsPafValidated();

		LOG.debug("saveAddress for Claimant: {}, Address: {}  and markPafValidated: {}", claimantId, newAddress, markAsPafValidated );

		try {
			this.addressService.saveAddress(claimantId, newAddress, markAsPafValidated);
		} catch (final HibernateOptimisticLockingFailureException| OptimisticLockException e) {
			LOG.warn("saveAddress for Claimant: " + claimantId + " failed because of an optimistic locking exception.", e);
			throw e;
		} catch ( final Exception e ) {
			LOG.error("saveAddress for Claimant: " + claimantId + " failed", e);
			throw e;
		}

		return new ResponseEntity<>(newAddress.getId(), HttpStatus.CREATED);
	}

	@RequestMapping(value = "/saveAddress", method = RequestMethod.POST)
	public ResponseEntity<Integer> saveAddress(@RequestBody final Address address) {
		try {
			this.addressService.saveAddress(address);
		} catch (final HibernateOptimisticLockingFailureException| OptimisticLockException e) {
			LOG.warn("saveAddress failed because of an optimistic locking exception.", e);
			throw e;
		} catch (final Exception e) {
			LOG.error("saveAddress failed", e);
			throw e;
		}

		return new ResponseEntity<>(address.getId(), HttpStatus.CREATED);
	}

	@RequestMapping(value = "/confinement/save", method = RequestMethod.POST)
	public ResponseEntity<Integer> saveAddressInConfinement(@RequestBody final String newAddressDto) {
		final SaveAddressDto deserialized = JsonUtils.deserialize(newAddressDto, SaveAddressDto.class);

		final Address newAddress = this.addressDtoConverter.convert(deserialized.getAddressDto());
		final int claimantId = deserialized.getClaimantId();
		final boolean markAsPafValidated = deserialized.getMarkAsPafValidated();

		LOG.debug("saveAddress for Claimant: {}, Address: {}  and markPafValidated: {}", claimantId, newAddress, markAsPafValidated );

		try {
			this.addressService.saveAddressInConfinement(claimantId, newAddress, markAsPafValidated);
		} catch (final HibernateOptimisticLockingFailureException| OptimisticLockException e) {
			LOG.warn("saveAddress for Claimant: " + claimantId + " failed because of because of an optimistic locking exception.", e);
			throw e;
		} catch ( final Exception e ) {
			LOG.error("saveAddress for Claimant: " + claimantId + " failed", e);
			throw e;
		}

		return new ResponseEntity<>(newAddress.getId(), HttpStatus.CREATED);
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public ResponseEntity<String> updateAddress(@RequestBody final String updatedAddressDto) {
		final SaveAddressDto deserialized = JsonUtils.deserialize(updatedAddressDto, SaveAddressDto.class);

		final Address updatedAddress = this.addressDtoConverter.convert(deserialized.getAddressDto());
		final int claimantId = deserialized.getClaimantId();
		final int userId = deserialized.getUserId();
		final boolean markAsPafValidated = deserialized.getMarkAsPafValidated();

		LOG.debug("updateAddress for Claimant: {}, Address: {}, User ID: {} and markPafValidated: {}",  claimantId, updatedAddress, userId, markAsPafValidated);

		updateAddressActions(claimantId, updatedAddress, userId, markAsPafValidated);

		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@RequestMapping(value = "/confinement/update", method = RequestMethod.POST)
	public ResponseEntity<String> updateAddressInConfinement(@RequestBody final String updatedAddressDto) {
		final SaveAddressDto deserialized = JsonUtils.deserialize(updatedAddressDto, SaveAddressDto.class);

		final Address updatedAddress = this.addressDtoConverter.convert(deserialized.getAddressDto());
		final int claimantId = deserialized.getClaimantId();
		final int userId = deserialized.getUserId();

		LOG.debug("updateAddress for Claimant: {}, Address: {}, User ID: {}",  claimantId, updatedAddress, userId);

		updateAddressActionsInConfinement(claimantId, updatedAddress, userId);

		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@ResponseBody
	@RequestMapping(value = "/claimant/{claimantId}", method = RequestMethod.GET)
	public AddressDto getAddressForClaimant(@PathVariable final int claimantId) {
		LOG.debug("getAddressForClaimant for Claimant: " + claimantId);
		try {
			return this.addressConverter.convert(this.addressService.getAddressForClaimant(claimantId));
		} catch ( final Exception e ) {
			LOG.error("getAddressForClaimant for Claimant: " + claimantId + " failed", e);
			throw e;
		}
	}


	@ResponseBody
	@RequestMapping(value = "/claimant/{claimantId}/all", method = RequestMethod.GET)
	public List<AddressDto> getAllAddressesForClaimant(@PathVariable final int claimantId) {
		LOG.debug("getAllAddressesForClaimant for Claimant: " + claimantId);
		try {
			final List<AddressDto> addresses = Lists.newArrayList();

			for (final Address address : this.addressService.getAllAddressesForClaimant(claimantId)) {
				addresses.add(this.addressConverter.convert(address));
			}

			return addresses;
		} catch ( final Exception e ) {
			LOG.error("getAllAddressesForClaimant for Claimant: " + claimantId + " failed", e);
			throw e;
		}
	}

	@ResponseBody
	@RequestMapping(value = "/previous/claimant/{claimantId}", method = RequestMethod.GET)
	public List<PreviousAddressDto> getPreviousAddresses(@PathVariable final int claimantId) {
		LOG.debug("getPreviousAddresses for Claimant: " + claimantId);

		try {
			final List<PreviousAddressDto> previousAddressDtos = Lists.newArrayList();

			for (final PreviousAddress previousAddress : this.addressService.getPreviousAddresses(claimantId)) {
				previousAddressDtos.add(this.previousAddressConverter.convert(previousAddress));
			}

			return previousAddressDtos;
		} catch ( final Exception e ) {
			LOG.error("getPreviousAddresses for Claimant: " + claimantId + " failed", e);
			throw e;
		}
	}

	@ResponseBody
	@RequestMapping(value = "/previous/ordered/claimant/{claimantId}", method = RequestMethod.GET)
	public List<PreviousAddressDto> getOrderedPreviousAddressesForClaimant(@PathVariable final int claimantId) {
		LOG.debug("getOrderedPreviousAddressesForClaimant: " + claimantId);

		try {
			final List<PreviousAddressDto> previousAddressDtos = Lists.newArrayList();

			for (final PreviousAddress previousAddress : this.addressService.getOrderedPreviousAddressesForClaimant(claimantId)) {
				previousAddressDtos.add(this.previousAddressConverter.convert(previousAddress));
			}

			return previousAddressDtos;
		} catch ( final Exception e ) {
			LOG.error("getPreviousAddresses for Claimant: " + claimantId + " failed", e);
			throw e;
		}
	}

	@ResponseBody
	@RequestMapping(value = "/previous/deleted/claimant/{claimantId}", method = RequestMethod.GET)
	public List<PreviousAddressDto> getDeletedPreviousAddresses(@PathVariable final int claimantId) {
		LOG.debug("getDeletedPreviousAddresses for Claimant: " + claimantId);
		try {
			final List<PreviousAddressDto> deletedAddresses = Lists.newArrayList();

			for (final PreviousAddress previousAddress : this.addressService.getDeletedPreviousAddresses(claimantId)) {
				deletedAddresses.add(this.previousAddressConverter.convert(previousAddress));
			}

			return deletedAddresses;
		} catch ( final Exception e ) {
			LOG.error("getDeletedPreviousAddresses for Claimant: " + claimantId + " failed", e);
			throw e;
		}
	}

	@RequestMapping(value = "/previous/save", method = RequestMethod.POST)
	public ResponseEntity<String> savePreviousAddress(@RequestBody final String savePreviousAddressDto) {
		final SavePreviousAddressDto deserialized = JsonUtils.deserialize(savePreviousAddressDto, SavePreviousAddressDto.class);
		LOG.debug("savePreviousAddress for Claimant: {} and Address ID: {}", deserialized.getClaimantId(), deserialized.getCurrentAddressId());
		savePreviousAddressActions(deserialized);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@RequestMapping(value = "/previous/confinement/save", method = RequestMethod.POST)
	public ResponseEntity<String> savePreviousAddressInConfinement(@RequestBody final String savePreviousAddressDto) {
		final SavePreviousAddressDto deserialized = JsonUtils.deserialize(savePreviousAddressDto, SavePreviousAddressDto.class);
		LOG.debug("savePreviousAddress for Claimant: {} and Address ID: {}", deserialized.getClaimantId(), deserialized.getCurrentAddressId());
		savePreviousAddressActionsInConfinement(deserialized);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}


	@RequestMapping(value = "/previous/save/all", method = RequestMethod.POST)
	public ResponseEntity<String> saveAllPreviousAddresses(@RequestBody final String savePreviousAddressDto) throws IOException {
		final ObjectMapper mapper = new ObjectMapper();
		List<SavePreviousAddressDto> previousAddresses = null;
		try {
			previousAddresses = mapper.readValue(savePreviousAddressDto, new TypeReference<List<SavePreviousAddressDto>>() { });
		}
		catch (final IOException e) {
			LOG.error("Failed to parse savePreviousAddressDto", e);
			throw e;
		}

		if(previousAddresses != null) {
			for(final SavePreviousAddressDto previousAddressDto : previousAddresses){
				LOG.debug("processPreviousAddress for Claimant: {} and Address ID: {}", previousAddressDto.getClaimantId(), previousAddressDto.getCurrentAddressId());
				if(previousAddressDto.getNewAddress().getId() == 0) {
					savePreviousAddressActions(previousAddressDto);
				} else {
					final Address updatedAddress = this.addressDtoConverter.convert(previousAddressDto.getNewAddress());
					final int claimantId = previousAddressDto.getClaimantId();
					final int userId = previousAddressDto.getUserId();
					final boolean markAsPafValidated = true;

					LOG.debug("Updating previous address for Claimant: {}, Address: {}, User ID: {} and markPafValidated: {}",  claimantId, updatedAddress, userId, markAsPafValidated);
					updateAddressActions(claimantId, updatedAddress, userId, false);
				}
			}
		}
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@RequestMapping(value = "/previous/delete/{id}/{userId}", method = RequestMethod.GET)
	public ResponseEntity<String> deletePreviousAddress(@PathVariable final int id, @PathVariable final int userId) {
		LOG.debug("deletePreviousAddress for address id: " + id);

		try {
			this.addressService.deletePreviousAddress(id, userId);
		} catch (final HibernateOptimisticLockingFailureException| OptimisticLockException e) {
			LOG.warn("deletePreviousAddress for id: " + id + " failed because of because of an optimistic locking exception.", e);
			throw e;
		} catch ( final Exception e ) {
			LOG.error("deletePreviousAddress for id: " + id + " failed", e);
			throw e;
		}

		return new ResponseEntity<>(HttpStatus.OK);
	}

	@RequestMapping(value = "/previous/confinement/delete/{id}/{userId}", method = RequestMethod.GET)
	public ResponseEntity<String> deletePreviousAddressInConfinement(@PathVariable final int id, @PathVariable final int userId) {
		LOG.debug("deletePreviousAddress for address id: " + id);

		try {
			this.addressService.deletePreviousAddressInConfinement(id, userId);
		} catch (final HibernateOptimisticLockingFailureException| OptimisticLockException e) {
			LOG.warn("deletePreviousAddress for id: " + id + " failed because of because of an optimistic locking exception.", e);
			throw e;
		} catch ( final Exception e ) {
			LOG.error("deletePreviousAddress for id: " + id + " failed", e);
			throw e;
		}

		return new ResponseEntity<>(HttpStatus.OK);
	}

	@RequestMapping(value = "/houseMove", method = RequestMethod.POST)
	public ResponseEntity<String> saveHouseMove(@RequestBody final String savePreviousAddressDto) {
		final SavePreviousAddressDto deserialized = JsonUtils.deserialize(savePreviousAddressDto, SavePreviousAddressDto.class);
		LOG.debug("saveHouseMove for Claimant: " + deserialized.getClaimantId() + ", Old Address ID: " + deserialized.getCurrentAddressId() + ", and New Address: " + deserialized.getNewAddress());

		final Address oldAddress = this.addressService.getAddressById(deserialized.getCurrentAddressId());
		final Address newAddress = this.addressDtoConverter.convert(deserialized.getNewAddress());

		try {
			this.addressService.saveHouseMove(deserialized.getClaimantId(), oldAddress, newAddress);
		} catch (final HibernateOptimisticLockingFailureException| OptimisticLockException e) {
			LOG.warn("saveHouseMove for claimant id: " + deserialized.getClaimantId() + " failed because of because of an optimistic locking exception.", e);
			throw e;
		} catch ( final Exception e ) {
			LOG.error("saveHouseMove for claimant id: " + deserialized.getClaimantId() + " failed", e);
			throw e;
		}

		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@ResponseBody
	@RequestMapping(value = "/all/{claimantId}", method = RequestMethod.GET)
	public AddressServiceDto getAllAddressDetails(@PathVariable final int claimantId) {
		LOG.debug("getAllAddressDetails for Claimant: " + claimantId);

		try {
			final AddressServiceDto addressServiceDto = new AddressServiceDto();
			addressServiceDto.setCurrentAddress(getAddressForClaimant(claimantId));
			addressServiceDto.setOrderedPreviousAddresses(getOrderedPreviousAddressesForClaimant(claimantId));
			addressServiceDto.setDeletedPreviousAddresses(getDeletedPreviousAddresses(claimantId));

			return addressServiceDto;
		} catch ( final Exception e ) {
			LOG.error("getAllAddressDetails for Claimant: " + claimantId + " failed", e);
			throw e;
		}
	}

	private void updateAddressActions(final int claimantId, final Address updatedAddress, final int userId, final Boolean markAsPafValidated) {
		try {
			this.addressService.updateAddress(claimantId, updatedAddress, userId, markAsPafValidated);
		} catch (final HibernateOptimisticLockingFailureException| OptimisticLockException e) {
			LOG.warn("updateAddress for Claimant: " + claimantId + " failed because of because of an optimistic locking exception.", e);
			throw e;
		} catch ( final Exception e ) {
			LOG.error("updateAddress for Claimant: " + claimantId + " failed", e);
			throw e;
		}
	}

	private void updateAddressActionsInConfinement(final int claimantId, final Address updatedAddress, final int userId) {
		try {
			this.addressService.updateAddressInConfinement(claimantId, updatedAddress, userId);
		} catch (final HibernateOptimisticLockingFailureException| OptimisticLockException e) {
			LOG.warn("updateAddress for Claimant: " + claimantId + " failed because of because of an optimistic locking exception.", e);
			throw e;
		} catch ( final Exception e ) {
			LOG.error("updateAddress for Claimant: " + claimantId + " failed", e);
			throw e;
		}
	}

	private void savePreviousAddressActions(final SavePreviousAddressDto dto) {
		try {
			final Address address;

			if (dto.getCurrentAddressId() == 0) {
				address = this.addressDtoConverter.convert(dto.getNewAddress());
			} else {
				address = this.addressService.getAddressById(dto.getCurrentAddressId());
			}
			this.addressService.savePreviousAddress(dto.getClaimantId(), address);
		} catch (final HibernateOptimisticLockingFailureException| OptimisticLockException e) {
			LOG.warn("savePreviousAddress for Claimant: " + dto.getClaimantId() + " failed because of because of an optimistic locking exception.", e);
			throw e;
		} catch ( final Exception e ) {
			LOG.error("savePreviousAddress for Claimant: " + dto.getClaimantId() + " failed", e);
			throw e;
		}
	}

	private void savePreviousAddressActionsInConfinement(final SavePreviousAddressDto dto) {
		try {
			final Address address;

			if (dto.getCurrentAddressId() == 0) {
				address = this.addressDtoConverter.convert(dto.getNewAddress());
			} else {
				address = this.addressService.getAddressById(dto.getCurrentAddressId());
			}
			this.addressService.savePreviousAddressInConfinement(dto.getClaimantId(), address);
		} catch (final HibernateOptimisticLockingFailureException| OptimisticLockException e) {
			LOG.warn("savePreviousAddress for Claimant: " + dto.getClaimantId() + " failed because of because of an optimistic locking exception.", e);
			throw e;
		} catch ( final Exception e ) {
			LOG.error("savePreviousAddress for Claimant: " + dto.getClaimantId() + " failed", e);
			throw e;
		}
	}
}
