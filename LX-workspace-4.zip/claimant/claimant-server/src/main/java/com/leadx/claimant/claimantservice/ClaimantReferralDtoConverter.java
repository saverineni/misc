package com.leadx.claimant.claimantservice;

import static com.leadx.lib.utl.ObjectUtils.isNull;

import com.leadx.claimant.client.ClaimantReferralDto;

public class ClaimantReferralDtoConverter {
	
	public ClaimantReferral convert(ClaimantReferralDto source) {
		if (isNull(source)) {
			return null;
		}
		
		return new ClaimantReferral(source.getProductTypeId(), source.getReferrerClaimantId(), source.getReferralClaimantId(), source.getCreatedByAgentId(), source.getDiallerReferenceId());
	}
	
}