package com.leadx.claimant.claimantservice;

import java.util.Collection;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
@SuppressWarnings("unchecked")
class ClaimantReferralRepository {
	@Autowired
	private SessionFactory sessionFactory;

	ClaimantReferral getClaimantReferralById(final int id) {
		return (ClaimantReferral)this.sessionFactory.getCurrentSession().get(ClaimantReferral.class, id);
	}

	void createClaimantReferral(final ClaimantReferral referral) {
		this.sessionFactory.getCurrentSession()
			.save(referral);
	}

	/** claimant referral id should be unique as everytime add a new referral it creates a new claimant but TCG SQL
	 * code tried to allow for multiple entries. Therefore in case there is any dodgy historic data from TCG, this code
	 * also allows for multiple entries but returns the latest one
 	 */
	ClaimantReferral getClaimantReferralByReferreeId(final int claimantIdReferree) {
		// Product referrals are excluded at this level
		return (ClaimantReferral) this.sessionFactory.getCurrentSession()
			.createQuery("FROM ClaimantReferral r WHERE r.referralClaimantId = :claimantId AND r.referrerClaimantId != :claimantId ORDER BY ID DESC")
			.setParameter("claimantId", claimantIdReferree)
			.setMaxResults(1)
			.setFirstResult(0)
			.uniqueResult();
	}

	Collection<ClaimantReferral> getClaimantReferralsByReferreeIds(final Collection<Integer> ids) {
		return this.sessionFactory.getCurrentSession()
			.createQuery("FROM ClaimantReferral r WHERE r.referralClaimantId IN (:ids)")
			.setParameterList("ids", ids)
			.list();
	}

	List<ClaimantReferral> getProductReferralsForClaimant(final int claimantId) {
		return this.sessionFactory.getCurrentSession()
				.createQuery("FROM ClaimantReferral r WHERE r.referralClaimantId = :claimantId AND r.referrerClaimantId = :claimantId ORDER BY ID DESC")
				.setParameter("claimantId", claimantId)
				.list();
	}
	
	void evict(final ClaimantReferral claimantReferral) {
		this.sessionFactory.getCurrentSession().evict(claimantReferral);
	}

}
