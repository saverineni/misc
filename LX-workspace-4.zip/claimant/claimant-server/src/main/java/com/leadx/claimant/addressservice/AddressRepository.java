package com.leadx.claimant.addressservice;

import java.util.Collection;
import java.util.List;

import org.hibernate.SessionFactory;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
class AddressRepository {

	@Autowired
	private SessionFactory sessionFactory;

	void saveAddress(final Address address, final boolean markPafValidated) {
		if (markPafValidated) {
			address.setPafValidatedDate(new LocalDate());
		}
		
		this.sessionFactory.getCurrentSession()
			.save(address);
	}

	void updateAddress(final Address address, final boolean markPafValidated) {
		if (markPafValidated) {
			address.setPafValidatedDate(new LocalDate());
		}
		
		this.sessionFactory.getCurrentSession()
			.update(address);
	}

	Address getAddressById(final int id) {
		return (Address)this.sessionFactory.getCurrentSession().get(Address.class, id);
	}

	@SuppressWarnings("unchecked")
	Collection<Address> getAddressesByIds(final Collection<Integer> ids) {
		return this.sessionFactory.getCurrentSession().
			createQuery("FROM Address c WHERE ID in (:ids)")
			.setParameterList("ids", ids)
			.list();
	}

	@SuppressWarnings("unchecked")
	List<PreviousAddress> getDeletedPreviousAddressesForClaimant(final int claimantId) {

		return this.sessionFactory.getCurrentSession()
				.createQuery("FROM PreviousAddress pa WHERE pa.claimantId = :claimantId AND pa.deletedDateTime != '0000-00-00 00:00:00' ORDER BY pa.fromCurrent DESC, pa.address.updatedDateTime DESC")
				.setParameter("claimantId", claimantId)
				.list();
	}
	
	@SuppressWarnings("unchecked")
	List<PreviousAddress> getPreviousAddressesForClaimant(final int claimantId) {

		return this.sessionFactory.getCurrentSession()
				.createQuery("FROM PreviousAddress pa WHERE pa.claimantId = :claimantId and pa.userIdDeletedBy = 0")
				.setParameter("claimantId", claimantId)
				.list();
	}
	
	@SuppressWarnings("unchecked")
	List<PreviousAddress> getOrderedPreviousAddressesForClaimant(final int claimantId) {

		return this.sessionFactory.getCurrentSession()
				.createQuery("FROM PreviousAddress pa WHERE pa.claimantId = :claimantId AND pa.userIdDeletedBy = 0 ORDER BY pa.fromCurrent DESC, pa.address.updatedDateTime DESC")
				.setParameter("claimantId", claimantId)
				.list();
	}
	
	PreviousAddress getPreviousAddress(final int previousAddressId) {	
		return (PreviousAddress)this.sessionFactory.getCurrentSession().get(PreviousAddress.class, previousAddressId); 
	}
	
	void savePreviousAddress(final PreviousAddress previousAddress) {
		this.sessionFactory.getCurrentSession().save(previousAddress);
	}
	
	void updatePreviousAddress(final PreviousAddress previousAddress) {
		this.sessionFactory.getCurrentSession().update(previousAddress);
	}
	
	void evict(final Address address) {
		this.sessionFactory.getCurrentSession().evict(address);
	}

}
