package com.leadx.claimant.selleraccountservice;

import java.util.Collection;
import java.util.List;

import javax.persistence.OptimisticLockException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.hibernate4.HibernateOptimisticLockingFailureException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.ImmutableList;
import com.leadx.claimant.client.DropdownConfigurationDto;
import com.leadx.claimant.client.ProductTypeDto;
import com.leadx.claimant.client.SellerAccountDto;
import com.leadx.lib.utl.json.JsonUtils;


/**
 * Webservice entry points for the seller account web service
 */
@RequestMapping(value = "/selleraccount")
@Controller
public class SellerAccountController {

	@Autowired
	private Converter<SellerAccountDto, SellerAccount> sellerAccountDtoConverter;

	@Autowired
	private Converter<SellerAccount, SellerAccountDto> sellerAccountConverter;

	@Autowired
	private Converter<ProductType, ProductTypeDto> productTypeConverter;

	@Autowired
	private Converter<DropdownConfiguration, DropdownConfigurationDto> dropdownConfigurationConverter;

	private static final Logger LOG = LoggerFactory.getLogger(SellerAccountController.class);

	@Autowired
	private SellerAccountService sellerAccountService;

	@ResponseBody
	@RequestMapping(value = "/create",  method = RequestMethod.POST)
	public ResponseEntity<String> createSellerAccount(@RequestBody final String accDto) {
		final SellerAccount acc = this.sellerAccountDtoConverter.convert(JsonUtils.deserialize(accDto, SellerAccountDto.class));
		LOG.debug("Saving seller account");
		try{
			this.sellerAccountService.create(acc);
			LOG.info("Saved seller account with id: {}", acc.getAccountId());
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (final HibernateOptimisticLockingFailureException|OptimisticLockException e) {
			LOG.warn("createSellerAccount for " + acc.getName() + " failed.", e);
		} catch (final Exception e) {
			LOG.error("Problem saving seller account. Exception: {}", e);
		}
		return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ResponseBody
	@RequestMapping(value = "/update",  method = RequestMethod.POST)
	public ResponseEntity<String> updateSellerAccount(@RequestBody final String accDto) {
		final SellerAccount acc = this.sellerAccountDtoConverter.convert(JsonUtils.deserialize(accDto, SellerAccountDto.class));
		LOG.debug("Updating seller account");
		try{
			this.sellerAccountService.update(acc);
			LOG.info("Updated seller account with id: {}", acc.getId());
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (final HibernateOptimisticLockingFailureException|OptimisticLockException e) {
			LOG.warn("updateSellerAccount for " + acc.getName() + " failed.", e);
		} catch (final Exception e) {
			LOG.error("Problem updating seller account. Exception: {}", e);
		}
		return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ResponseBody
	@RequestMapping(value = "/id/{id}",  method = RequestMethod.GET)
	public SellerAccountDto getByAccountId(@PathVariable final int id) {
		LOG.debug("Getting seller account with id: {}", id);
		return this.sellerAccountConverter.convert(this.sellerAccountService.getByAccountId(id));
	}

	@ResponseBody
	@RequestMapping(value = "/ids/{ids}",  method = RequestMethod.GET)
	public Collection<SellerAccountDto> getByAccountIds(@PathVariable final String ids) {
		LOG.debug("getByIds: {}", ids);

		final String[] idsStr = ids.split(",");
		final ImmutableList.Builder<Integer> idsList = new ImmutableList.Builder<>();
		for ( final String idStr: idsStr ) {
			idsList.add(Integer.parseInt(idStr.trim()));  // can throw exception back to caller if not an integer
		}

		final Collection<SellerAccount> sellerAccounts = this.sellerAccountService.getByAccountIds(idsList.build());

		final ImmutableList.Builder<SellerAccountDto> dtos = new ImmutableList.Builder<>();
		for ( final SellerAccount sellerAccount: sellerAccounts ) {
			dtos.add(this.sellerAccountConverter.convert(sellerAccount));
		}

		return dtos.build();
	}


	@ResponseBody
	@RequestMapping(value = "/all",  method = RequestMethod.GET)
	public List<SellerAccountDto> getAll() {
		LOG.debug("Getting all seller accounts");
		final ImmutableList.Builder<SellerAccountDto> builder = new ImmutableList.Builder<>();
		for ( final SellerAccount account: this.sellerAccountService.getAll()) {
			builder.add(this.sellerAccountConverter.convert(account));
		}
		return builder.build();
	}

	@ResponseBody
	@RequestMapping(value = "/sourced",  method = RequestMethod.GET)
	public List<SellerAccountDto> getSourcedSellerAccounts() {
		LOG.debug("Getting all sourced seller accounts");
		final ImmutableList.Builder<SellerAccountDto> builder = new ImmutableList.Builder<>();
		for ( final SellerAccount account: this.sellerAccountService.getSourcedSellerAccounts()) {
			builder.add(this.sellerAccountConverter.convert(account));
		}
		return builder.build();
	}

	@ResponseBody
	@RequestMapping(value = "/producttypes",  method = RequestMethod.GET)
	public List<ProductTypeDto> getProductTypes() {
		LOG.debug("Getting all available product types");
		final ImmutableList.Builder<ProductTypeDto> builder = new ImmutableList.Builder<>();
		for ( final ProductType productType: this.sellerAccountService.getProductTypes()) {
			builder.add(this.productTypeConverter.convert(productType));
		}
		return builder.build();
	}

	@ResponseBody
	@RequestMapping(value = "/dropdown/{fieldName}", method = RequestMethod.GET)
	public List<DropdownConfigurationDto> getDropdownItemsForField(@PathVariable final String fieldName) {
		LOG.debug("Getting dropdown configuration items for field name: {}", fieldName);
		final ImmutableList.Builder<DropdownConfigurationDto> builder = new ImmutableList.Builder<>();

		for (final DropdownConfiguration dropdownConfiguration : this.sellerAccountService.getDropdownItemsForField(fieldName)) {
			builder.add(this.dropdownConfigurationConverter.convert(dropdownConfiguration));
		}

		return builder.build();
	}

	@ResponseBody
	@RequestMapping(value = "/isFreePpi/{id}",  method = RequestMethod.GET)
	public boolean isFreePpi(@PathVariable final int id) {
		LOG.debug("Checking if the seller account {} is a Free Ppi account", id);
		return this.sellerAccountService.isFreePpi(id);
	}
}