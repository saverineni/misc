package com.leadx.claimant.assessmentservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.leadx.claimant.addressservice.Address;
import com.leadx.claimant.addressservice.PreviousAddress;
import com.leadx.claimant.claimantservice.Claimant;
import com.leadx.claimant.claimantservice.ClaimantContactPreferenceConverter;
import com.leadx.claimant.claimantservice.ClaimantReferral;
import com.leadx.claimant.client.*;
import com.leadx.claimant.selleraccountservice.LeadType;
import com.leadx.claimant.selleraccountservice.SellerAccount;

@Component("assessmentDtoConverter")
public class AssessmentDtoConverter implements Converter<Assessment, AssessmentDto> {
	
	@Autowired
	private Converter<Claimant, ClaimantDto> claimantConverter;
	
	@Autowired
	private Converter<ClaimantReferral, ClaimantReferralDto> claimantReferralConverter;
	
	@Autowired
	private Converter<Address, AddressDto> addressConverter;
	
	@Autowired
	private Converter<PreviousAddress, PreviousAddressDto> previousAddressConverter;

	@Autowired
	private Converter<LeadType, LeadTypeDto> leadTypeConverter;

	@Autowired
	private ClaimantContactPreferenceConverter claimantContactPreferenceConverter;

	@Override
	public AssessmentDto convert(final Assessment source) {
		final ClaimantDto claimantDto = this.claimantConverter.convert(source.getClaimant());
		final AddressDto addressDto = this.addressConverter.convert(source.getAddress());
		final ClaimantReferralDto claimantReferralDto = this.claimantReferralConverter.convert(source.getClaimantReferral());
		final ClaimantBrandingDto claimantBrandingDto = SellerAccount.toClaimantBrandingDto(source.getSellerAccount());

		LeadTypeDto leadTypeDto = null;

		if (null != source.getSellerAccount()) {
			leadTypeDto = this.leadTypeConverter.convert(source.getSellerAccount().getLeadType());
		}

		final List<PreviousAddressDto> previousAddressDtos = Lists.newArrayList();
		
		for (final PreviousAddress previousAddress : source.getPreviousAddresses()) {
			previousAddressDtos.add(this.previousAddressConverter.convert(previousAddress));
		}

		final ClaimantContactPreferenceDto contactPreferenceDto = this.claimantContactPreferenceConverter.convert(source.getClaimantContactPreference());
		
		return new AssessmentDto(leadTypeDto, claimantDto, addressDto, previousAddressDtos, claimantReferralDto, claimantBrandingDto, contactPreferenceDto, false, false);
	}
}
