package com.leadx.claimant.assessmentservice;

import com.leadx.claimant.client.AddressDto;

public class AssessmentClaimantAndAddressDto {
	private AssessmentClaimantDto assessmentClaimantDto;
	private AddressDto addressDto;

	public AssessmentClaimantAndAddressDto(final AssessmentClaimantDto assessmentClaimantDto, final AddressDto addressDto) {
		this.assessmentClaimantDto = assessmentClaimantDto;
		this.addressDto = addressDto;
	}

	public AssessmentClaimantAndAddressDto() {
	}

	public AssessmentClaimantDto getAssessmentClaimantDto() {
		return this.assessmentClaimantDto;
	}

	public AddressDto getAddressDto() {
		return this.addressDto;
	}
}