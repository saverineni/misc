package com.leadx.claimant.claimantservice;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
class ClaimantLogRepository {
	@Autowired
	private SessionFactory sessionFactory;

	ClaimantLog getClaimantLogById(final int id) {
		return (ClaimantLog)this.sessionFactory.getCurrentSession().get(ClaimantLog.class, id);
	}

	/** Gets the latest claimant log entry for the claimant. */
	ClaimantLog getClaimantLogByClaimantId(final int claimantId) {
		return (ClaimantLog) this.sessionFactory.getCurrentSession().createQuery("FROM ClaimantLog WHERE claimantId = :claimantId order by ID DESC")
			.setInteger("claimantId", claimantId)
			.setMaxResults(1)
			.setFirstResult(0)
			.uniqueResult();
	}


	void createClaimantLog(final ClaimantLog claimantLog) {
		this.sessionFactory.getCurrentSession()
			.save(claimantLog);
	}

	void updateClaimantLog(final ClaimantLog claimantLog) {
		this.sessionFactory.getCurrentSession()
			.update(claimantLog);
	}

	void evict(final ClaimantLog claimantLog) {
		this.sessionFactory.getCurrentSession().evict(claimantLog);
	}

}
