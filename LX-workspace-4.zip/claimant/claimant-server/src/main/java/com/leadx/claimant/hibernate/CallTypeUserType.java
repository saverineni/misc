package com.leadx.claimant.hibernate;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.type.IntegerType;

import com.leadx.claimant.client.CallType;
import com.leadx.lib.hibernate.AbstractImmutableUserType;

public class CallTypeUserType extends AbstractImmutableUserType {

	@Override
	public int[] sqlTypes() {
		return new int[] { IntegerType.INSTANCE.sqlType() };
	}

	@Override
	public Class<?> returnedClass() {
		return CallType.class;
	}

	@Override
	public Object nullSafeGet(final ResultSet rs, final String[] names, final SessionImplementor session, final Object owner) throws HibernateException, SQLException {
		final int value = rs.getInt(names[0]);
		if (0 == value) {
			return null;
		}
		return CallType.getById(value);
	}

	@Override
	public void nullSafeSet(final PreparedStatement st, final Object value, final int index, final SessionImplementor session) throws HibernateException, SQLException {
		if (null == value) {
			st.setNull(index, IntegerType.INSTANCE.sqlType());
		}
		else {
			st.setInt(index, ((CallType) value).getId());
		}
	}
}
