package com.leadx.claimant.searchservice;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.leadx.claimant.client.search.SearchRequestDto;
import com.leadx.claimant.client.search.SearchResultClaimantDto;


@Controller
public class ClaimantSearchController {

	private static final Logger LOG = LoggerFactory.getLogger(ClaimantSearchController.class);

	@Autowired
	private ClaimantSearchService claimantSearchService;

	@ResponseBody
	@RequestMapping(value = "/claimant/search", method = RequestMethod.POST)
	public List<SearchResultClaimantDto> search(@RequestBody final SearchRequestDto searchRequestDto) {
		LOG.debug("Searching claimants for criteria: " + searchRequestDto);
		try {
			return claimantSearchService.search(searchRequestDto);
		} catch ( final Exception e ) {
			LOG.error("Error occurred when searching claimants: ", e);
			throw e;
		}
	}
}
