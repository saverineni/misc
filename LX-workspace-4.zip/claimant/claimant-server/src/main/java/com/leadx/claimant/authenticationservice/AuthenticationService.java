package com.leadx.claimant.authenticationservice;

import static com.google.common.base.Preconditions.checkArgument;
import static com.leadx.lib.utl.ObjectUtils.isNotNull;
import static com.leadx.lib.utl.ObjectUtils.isNull;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.leadx.claimant.claimantservice.Claimant;
import com.leadx.claimant.claimantservice.ClaimantService;
import com.leadx.claimant.client.ClaimantAuthenticationDto;

@Component
public class AuthenticationService {

	private static final Logger LOG = LoggerFactory.getLogger(AuthenticationService.class);

	@Autowired
	private ClaimantService claimantService;

	private static String SALT = "int3gr4l";

	public boolean authenticate(final ClaimantAuthenticationDto claimantAuthenticationDto) throws NoSuchAlgorithmException {
		checkArgument(isNotNull(claimantAuthenticationDto), "Cannot authenticate without a claimant ID and password");

		final int claimantId = claimantAuthenticationDto.getClaimantId();

		checkArgument(claimantId > 0, "Cannot authenticate without a claimant ID");
		checkArgument(isNotBlank(claimantAuthenticationDto.getPassword()), "Cannot authenticate without a password");

		final Claimant claimant = this.claimantService.getClaimantById(claimantId);

		if (isNull(claimant)) {
			throw new IllegalArgumentException("Failed to locate claimant with ID: " + claimantId);
		}

		if (isBlank(claimant.getPassword())) {
			LOG.warn("Claimant " + claimant.getId() + " attempted to authenticate but has no password set");
			return false;
		}

		final String stringToHash = claimantAuthenticationDto.getPassword() + SALT;

		final MessageDigest md = MessageDigest.getInstance("MD5");
		md.reset();
		md.update(stringToHash.getBytes());

		return new String(Hex.encodeHex(md.digest())).equals(claimant.getPassword());
	}
}
