package com.leadx.claimant.claimantservice;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.leadx.claimant.client.ClaimantAdditionalPreviousNameDto;

@Component("claimantAdditionalPreviousNamesConverter")
public class ClaimantAdditionalPreviousNameConverter implements Converter<Set<ClaimantAdditionalPreviousName>, List<ClaimantAdditionalPreviousNameDto>>{

	@Override
	public List<ClaimantAdditionalPreviousNameDto> convert(Set<ClaimantAdditionalPreviousName> source) {
		if(source == null) {
			return Lists.newArrayList();
		}
		
		return source.stream().map(ClaimantAdditionalPreviousName::fromDto).collect(Collectors.toList());
	}
}
