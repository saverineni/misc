package com.leadx.claimant.claimantservice;

import com.leadx.claimant.client.ClaimantInteractionDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.leadx.claimant.user.UserService;

@Component
class ClaimantInteractionDtoConverter implements Converter<ClaimantInteractionDto, ClaimantInteraction> {

	@Autowired
	private UserService userService;
	
	@Override
	public ClaimantInteraction convert(final ClaimantInteractionDto source) {

		return new ClaimantInteraction(
				source.getClaimantId(),
				source.getProductId(),
				ClaimantInteractionType.EVENT.toValue(), 
				this.userService.getById(source.getUserId()), 
				source.getContent(), source.getSource()
			);

	}
}
