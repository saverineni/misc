package com.leadx.claimant.applicationpropertyservice;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ApplicationPropertyRepository {

	private final SessionFactory sessionFactory;

	@Autowired
	public ApplicationPropertyRepository(final SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public String get(final String property) {
		return (String)this.sessionFactory.getCurrentSession().createSQLQuery("SELECT propertyValue FROM application_property where property = :property")
				.setParameter("property", property)
				.uniqueResult();
	}
}