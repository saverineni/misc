package com.leadx.claimant.claimantservice;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.leadx.lib.utl.JodaUtils;

/**
 * Hibernate implementation of the claimant repo. This should not be used outside the package by other services or repos.
 */
@Repository
class ClaimantRepository {
	@Autowired
	private SessionFactory sessionFactory;

	@Value("${claimant.server.claimantsearchlimit}")
	private int claimantSearchLimit;


	/** Get claimant from an id. Returns null if no claimant found. */
	Claimant getClaimantById(final int id) {
		return (Claimant)this.sessionFactory.getCurrentSession().get(Claimant.class, id);
	}

	/** Create a new claimant. Claimant that was passed in will have its new id set */
	void createClaimant(final Claimant claimant) {
		this.sessionFactory.getCurrentSession()
			.save(claimant);
	}

	void updateClaimant(final Claimant claimant) {
		this.sessionFactory.getCurrentSession()
			.update(claimant);
	}

	void evict(final Claimant claimant) {
		this.sessionFactory.getCurrentSession().evict(claimant);
	}

	@SuppressWarnings("unchecked")
	public List<Claimant> searchForClaimantBySurname(final String surname) {
		return this.sessionFactory.getCurrentSession().
			createQuery("FROM Claimant c WHERE c.surname like :surname ORDER BY ID DESC")
			.setParameter("surname", surname)
			.setMaxResults(this.claimantSearchLimit)
			.list();
	}

	public Claimant getByLeadId(final int leadId) {
		return (Claimant) this.sessionFactory.getCurrentSession().
				createQuery("FROM Claimant c WHERE c.leadId = :leadId ORDER BY ID DESC")
				.setParameter("leadId", leadId)
				.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	public List<Claimant> searchForClaimantByPostcode(final String postcode) {
		return this.sessionFactory.getCurrentSession().
			createSQLQuery("SELECT c.* FROM claimant c JOIN address a on c.FK_AddressID = a.ID WHERE a.postcode like :postcode ORDER BY c.ID DESC")
			.addEntity("claimant", Claimant.class)
			.setParameter("postcode", postcode)
			.setMaxResults(this.claimantSearchLimit)
			.list();
	}

	@SuppressWarnings("unchecked")
	public List<Claimant> searchForClaimantByTelephoneNumber(final String number) {
		return this.sessionFactory.getCurrentSession().
			createQuery("FROM Claimant c WHERE c.homeTelephone like :number OR c.workTelephone like :number OR c.mobileTelephone like :number ORDER BY ID DESC")
			.setParameter("number", number)
			.setMaxResults(this.claimantSearchLimit)
			.list();
	}

	@SuppressWarnings("unchecked")
	public List<Claimant> getClaimantsByIds(final List<Integer> ids) {
		return this.sessionFactory.getCurrentSession().
		createQuery("FROM Claimant c WHERE ID in (:ids) ORDER BY ID DESC")
			.setParameterList("ids", ids)
			.list();
	}

	public List<Integer> getRecentlyUnlockedClaimants(final int offsetDays){
		return this.sessionFactory.getCurrentSession()
				.createSQLQuery("SELECT c.ID FROM claimant.`claimant` c " +
						"WHERE c.LockedFromDiallerUpdateDateTime BETWEEN CONCAT(DATE_SUB(:dateNow, INTERVAL :offsetDays DAY), ' ', '00:00:00') " +
						"AND CONCAT(DATE_SUB(:dateNow, INTERVAL :offsetDays DAY), ' ', '23:59:59') " +
						"AND c.LockedFromDialler = 0")
				.setParameter("dateNow", JodaUtils.newCurrentDateString())
				.setParameter("offsetDays", offsetDays)
				.list();
	}
}
