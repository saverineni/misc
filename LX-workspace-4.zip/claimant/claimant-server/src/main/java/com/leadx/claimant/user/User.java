package com.leadx.claimant.user;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.leadx.hibernate.domain.BaseIntegerDomain;

@Entity
@Table(name = "pla_users")
public class User extends BaseIntegerDomain {

	private static final long serialVersionUID = 3208651879877773870L;

	@Column(nullable = false)
	private final String username = "";
	private final String title = "";
	private String forename;
	private String surname;
	private String phoneNumber;
	private String mobileNumber;
	private String faxNumber;
	private final short failedLoginAttempts = 0;
	private final short freshProspectsPerHour = 0;
	private final boolean isLocked = false;
	private final boolean isDeleted = false;

	public short getFailedLoginAttempts() {
		return this.failedLoginAttempts;
	}

	public short getFreshProspectsPerHour() {
		return this.freshProspectsPerHour;
	}

	public String getFaxNumber() {
		return this.faxNumber;
	}

	public String getForename() {
		return this.forename;
	}

	public boolean getIsDeleted() {
		return this.isDeleted;
	}

	public boolean getIsLocked() {
		return this.isLocked;
	}


	public String getMobileNumber() {
		return this.mobileNumber;
	}

	public String getPhoneNumber() {
		return this.phoneNumber;
	}
	public String getSurname() {
		return this.surname;
	}
	public String getTitle() {
		return this.title;
	}

	public String getUsername() {
		return this.username;
	}

	public String getFullName() {
		return this.forename + " " + this.surname;
	}

	@Override
	public boolean equals(final Object obj) {
		return deepEquals(obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

}
