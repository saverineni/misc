package com.leadx.claimant.claimantservice;

import static com.leadx.claimant.utils.ObjectUtils.isNotNull;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.*;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.*;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;

import com.google.common.collect.Sets;
import com.leadx.claimant.changelogservice.ChangeHistory;
import com.leadx.claimant.client.VulnerabilityCategory;
import com.leadx.claimant.reference.FormalDebtArrangement;
import com.leadx.claimant.reference.TriState;
import com.leadx.claimant.reference.VulnerableDetailTriState;
import com.leadx.hibernate.domain.BaseIntegerDomain;
import com.leadx.lib.utl.JodaUtils;


/**
 * This is the claimant domain object corresponding to the claimant table in the database. Note that at the moment, this does not keep an audit trail
 */
@Entity
@SelectBeforeUpdate
@Table(name = "claimant")
public class Claimant  extends BaseIntegerDomain {

	private static final long serialVersionUID = -4854561831609156253L;

	@Column(name = "FK_LeadID")
	private int leadId;

	@Column(name = "FK_AccountID_Seller")
	private int sellerAccountId;
	@Column(name = "FK_CompanyID_Seller")
	private int sellerCompanyId;

	@ChangeHistory
	private String title;
	@ChangeHistory
	private String forename;
	@ChangeHistory
	private String middleName;
	@ChangeHistory
	private String surname;
	@ChangeHistory
	private String previousSurname;
	@ChangeHistory
	@Type(type = "local_date_not_null")
	private LocalDate dob;

	@Column(name = "FK_AddressID")
	private int addressId;
	@ChangeHistory
	private String homeTelephone;
	@ChangeHistory
	private String mobileTelephone;
	@ChangeHistory
	private String alternativeTelephone;
	@Deprecated
	private String workTelephone;
	@ChangeHistory
	private String email;
	@ChangeHistory
	private String nationalInsuranceNumber;

	private String password;
	@Type(type = "local_date_time_not_null")
	private LocalDateTime passwordDateTime;

	@Type(type = "local_date_time_not_null")
	private LocalDateTime suppressedDateTime;
	@Type(type = "local_date_time_not_null")
	@Column(updatable = false, insertable = false)
	private LocalDateTime createdDateTime;
	private boolean lockedFromDialler;

	private boolean freePpi;

	@Type(type = "local_date_time_not_null")
	private LocalDateTime lockedFromDiallerUpdateDateTime;
	@Column(name = "FK_UserID_LockedFromDiallerUpdate")
	private int lockedFromDiallerUpdateUserId;

	private boolean rightToBeForgotten;

	@Type(type = "local_date_time_not_null")
	private LocalDateTime rightToBeForgottenUpdateDateTime;

	@Column(name = "FK_UserID_RightToBeForgottenUpdate")
	private int rightToBeForgottenUpdateUserId;

	@Type(type = "local_date_not_null")
	private LocalDate rightToBeForgottenNewestClosedClaimDate;

	private boolean vulnerableCustomer;

	@Type(type = "local_date_time_not_null")
	private LocalDateTime vulnerableCustomerUpdateDateTime;
	@Column(name = "FK_UserID_VulnerableCustomerUpdate")
	private int vulnerableCustomerUpdateUserId;
	@Type(type = "local_date_not_null")
	private LocalDate vulnerableCustomerReviewDate;

	private boolean incorrectAddress;
	@Type(type = "local_date_time_not_null")
	private LocalDateTime incorrectAddressUpdateDateTime;

	@ChangeHistory
	private Boolean hasVulnerability;
	@Type(type = "enum_set", parameters = { @Parameter(name = "enum", value = "client.VulnerabilityCategory") })
	private Set<VulnerabilityCategory> vulnerabilityCategories;
	private String vulnerabilityDetail;
	@Type(type = "vulnerable_detail_tri_state")
	private VulnerableDetailTriState canStoreVulnerabilityDetail;

	@Type(type = "local_date_time_not_null")
	@Column(updatable = false, insertable = false)
	private LocalDateTime timestamp;
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "FK_ClaimantID", nullable = false)
	@Where(clause="isDeleted='false'")
	@OrderBy("id")
	private Set<ClaimantOtherName> otherNames;
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "FK_ClaimantID", nullable = false)
	@Where(clause="isDeleted='false'")
	@OrderBy("id")
	private Set<ClaimantAdditionalPreviousName> additionalPreviousNames;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "FK_ClaimantID", nullable = false)
	@Where(clause="isDeleted='false'")
	@OrderBy("id")
	private Set<ClaimantPreviousEmail> previousEmails;

	@Type(type = "tri_state")
	private TriState formalDebtArrangement;

	@Type(type = "enum_set", parameters = { @Parameter(name = "enum", value = "reference.FormalDebtArrangement") })
	private Set<FormalDebtArrangement> formalDebtArrangementType;

	@Column(name = "FK_IvaCompanyID")
	@ChangeHistory(fieldName = "FK_IvaCompanyID")
	private int ivaCompanyId;

	@Column(name = "IvaReference")
	@ChangeHistory(fieldName = "IvaReference")
	private String ivaReference;

	@Type(type = "tri_state")
	private TriState informalDebtArrangement;

	@Column(name = "FK_DebtManagementCompanyID")
	@ChangeHistory(fieldName = "FK_DebtManagementCompanyID")
	private int debtManagementCompanyId;

	@Column(name = "DebtManagementReference")
	@ChangeHistory(fieldName = "DebtManagementReference")
	private String debtManagementReference;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "ID", referencedColumnName = "FK_ClaimantID", insertable = false, updatable = false)
	@NotFound(action = NotFoundAction.IGNORE)
	private ClaimantUnpresentedCheque claimantUnpresentedCheque;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "FK_ClaimantExecutorID")
	private ClaimantExecutor claimantExecutor;

	public Claimant() {
		// do nothing
	}

	public Claimant(final int id, final int leadId, final int sellerAccountId, final int sellerCompanyId, final String title, final String forename,
					final String middleName, final String surname, final String previousSurname, final LocalDate dob, final int addressId,
					final String homeTelephone, final String mobileTelephone, final String alternativeTelephone, final String workTelephone, final String email,
					final String nationalInsuranceNumber, final boolean lockedFromDialler, LocalDateTime lockedFromDiallerUpdateDateTime, int lockedFromDiallerUpdateUserId,
					final boolean rightToBeForgotten, final LocalDate rightToBeForgottenNewestClosedClaimDate, final int rightToBeForgottenUpdateUserId,
					final LocalDateTime rightToBeForgottenUpdateDateTime, final boolean vulnerableCustomer, final LocalDateTime vulnerableCustomerUpdateDateTime,
					final int vulnerableCustomerUpdateUserId, final LocalDate vulnerableCustomerReviewDate, final boolean incorrectAddress,
					final LocalDateTime incorrectAddressUpdateDateTime, final boolean freePpi, final LocalDateTime suppressedDateTime,
					final LocalDateTime createdDateTime, final LocalDateTime updateDateTime, final Set<ClaimantOtherName> otherNames,
					final Set<ClaimantAdditionalPreviousName> additionalPreviousNames, final Set<ClaimantPreviousEmail> previousEmails,
					final TriState formalDebtArrangement, final Set<FormalDebtArrangement> formalDebtArrangementType, final int ivaCompanyId,
					final String ivaReference, final TriState informalDebtArrangement, final int debtManagementCompanyId, final String debtManagementReference,
					final ClaimantUnpresentedCheque claimantUnpresentedCheque, final ClaimantExecutor claimantExecutor, final Boolean hasVulnerability, final Set<VulnerabilityCategory> vulnerabilityCategories,
					final VulnerableDetailTriState canStoreVulnerabilityDetail, final String vulnerabilityDetail) {


		setId(id);
		this.leadId = leadId;
		this.sellerAccountId = sellerAccountId;
		this.sellerCompanyId = sellerCompanyId;
		this.title = title;
		this.forename = forename;
		this.middleName = middleName;
		this.surname = surname;
		this.previousSurname = previousSurname;
		this.dob = dob;
		this.addressId = addressId;
		this.homeTelephone = homeTelephone;
		this.mobileTelephone = mobileTelephone;
		this.alternativeTelephone = alternativeTelephone;
		this.workTelephone = workTelephone;
		this.email = email;
		this.nationalInsuranceNumber = nationalInsuranceNumber;
		this.lockedFromDialler = lockedFromDialler;
		this.lockedFromDiallerUpdateDateTime = lockedFromDiallerUpdateDateTime;
		this.lockedFromDiallerUpdateUserId = lockedFromDiallerUpdateUserId;
		this.rightToBeForgotten = rightToBeForgotten;
		this.rightToBeForgottenNewestClosedClaimDate = rightToBeForgottenNewestClosedClaimDate;
		this.rightToBeForgottenUpdateUserId = rightToBeForgottenUpdateUserId;
		this.rightToBeForgottenUpdateDateTime = rightToBeForgottenUpdateDateTime;
		this.vulnerableCustomer = vulnerableCustomer;
		this.vulnerableCustomerUpdateDateTime = vulnerableCustomerUpdateDateTime;
		this.vulnerableCustomerUpdateUserId = vulnerableCustomerUpdateUserId;
		this.vulnerableCustomerReviewDate = vulnerableCustomerReviewDate;
		this.incorrectAddress = incorrectAddress;
		this.incorrectAddressUpdateDateTime = incorrectAddressUpdateDateTime;
		this.freePpi = freePpi;
		this.createdDateTime = createdDateTime;
		this.timestamp = updateDateTime;
		this.suppressedDateTime = suppressedDateTime;
		this.otherNames = otherNames == null ? Sets.newLinkedHashSet() : otherNames;
		this.additionalPreviousNames = additionalPreviousNames == null ? Sets.newLinkedHashSet() : additionalPreviousNames;
		this.previousEmails = previousEmails == null ? Sets.newLinkedHashSet() : previousEmails;
		this.formalDebtArrangement = formalDebtArrangement;
		this.formalDebtArrangementType = formalDebtArrangementType;
		this.ivaCompanyId = ivaCompanyId;
		this.ivaReference = ivaReference;
		this.informalDebtArrangement = informalDebtArrangement;
		this.debtManagementCompanyId = debtManagementCompanyId;
		this.debtManagementReference = debtManagementReference;
		this.claimantUnpresentedCheque = claimantUnpresentedCheque;
		this.claimantExecutor = claimantExecutor;
		this.hasVulnerability = hasVulnerability;
		this.vulnerabilityCategories = vulnerabilityCategories;
		this.canStoreVulnerabilityDetail = canStoreVulnerabilityDetail;
		this.vulnerabilityDetail = vulnerabilityDetail;
	}

	public String getFullName() {
		final StringBuilder builder = new StringBuilder();
		if ( this.title != null && this.title.length() > 0 ) {
			builder.append(this.title);
			builder.append((" "));
		}

		if ( this.forename != null && this.forename.length() > 0 ) {
			builder.append(this.forename);
			builder.append((" "));
		}

		if ( this.surname != null && this.surname.length() > 0 ) {
			builder.append(this.surname);
			builder.append((" "));
		}

		return builder.toString().trim();
	}

	public int getLeadId() {
		return this.leadId;
	}

	public int getSellerAccountId() {
		return this.sellerAccountId;
	}

	public void setSellerAccountId(int sellerAccountId) {
		this.sellerAccountId = sellerAccountId;
	}

	public int getSellerCompanyId() {
		return this.sellerCompanyId;
	}

	public void setSellerCompanyId(int sellerCompanyId) {
		this.sellerCompanyId = sellerCompanyId;
	}

	public String getTitle() {
		return this.title;
	}

	public String getForename() {
		return this.forename;
	}

	public String getMiddleName() {
		return this.middleName;
	}

	public String getSurname() {
		return this.surname;
	}

	public String getPreviousSurname() {
		return this.previousSurname;
	}

	public void setPreviousSurname(String previousSurname) {
		this.previousSurname = previousSurname;
	}

	public LocalDate getDob() {
		return this.dob;
	}

	public int getAddressId() {
		return this.addressId;
	}

	void setAddressId(final int addressId) {
		this.addressId = addressId;
	}

	public String getHomeTelephone() {
		return this.homeTelephone;
	}

	public void setHomeTelephone(String homeTelephone) {
		this.homeTelephone = homeTelephone;
	}

	public String getMobileTelephone() {
		return this.mobileTelephone;
	}

	public void setMobileTelephone(final String mobileTelephone) {
		this.mobileTelephone = mobileTelephone;
	}
	
	public String getAlternativeTelephone() {
		return this.alternativeTelephone;
	}
	
	public void setAlternativeTelephone(final String alternativeTelephone) {
		this.alternativeTelephone = alternativeTelephone;
	}

	public String getWorkTelephone() {
		return this.workTelephone;
	}

	public String getEmail() {
		return this.email;
	}

	void setEmail(final String email) {
		this.email = email;
	}

	public String getNationalInsuranceNumber() { return this.nationalInsuranceNumber; }

	void setNationalInsuranceNumber(final String nationalInsuranceNumber) { this.nationalInsuranceNumber = nationalInsuranceNumber; }

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public LocalDateTime getPasswordDateTime() {
		return passwordDateTime;
	}

	public void setPasswordDateTime(LocalDateTime passwordDateTime) {
		this.passwordDateTime = passwordDateTime;
	}

	public LocalDateTime getSuppressedDateTime() {
		return this.suppressedDateTime;
	}

	public LocalDateTime getCreatedDateTime() {
		return this.createdDateTime;
	}

	public boolean getLockedFromDialler() {
		return this.lockedFromDialler;
	}

	public boolean getFreePpi() {
		return freePpi;
	}

	public void setFreePpi(boolean freePpi) {
		this.freePpi = freePpi;
	}

	public LocalDateTime getTimestamp() {
		return this.timestamp;
	}

	public void setSuppressedDateTime(LocalDateTime suppressedDateTime) {
		this.suppressedDateTime = suppressedDateTime;
	}

	public LocalDateTime getLockedFromDiallerUpdateDateTime() {
		return this.lockedFromDiallerUpdateDateTime;
	}

	public void setLockedFromDiallerUpdateDateTime(LocalDateTime lockedFromDiallerUpdateDateTime) {
		this.lockedFromDiallerUpdateDateTime = lockedFromDiallerUpdateDateTime;
	}

	public int getLockedFromDiallerUpdateUserId() {
		return this.lockedFromDiallerUpdateUserId;
	}

	public void setLockedFromDiallerUpdateUserId(int lockedFromDiallerUpdateUserId) {
		this.lockedFromDiallerUpdateUserId = lockedFromDiallerUpdateUserId;
	}

	public boolean getRightToBeForgotten() {
		return rightToBeForgotten;
	}

	public void setRightToBeForgotten(boolean rightToBeForgotten) {
		this.rightToBeForgotten = rightToBeForgotten;
	}

	public LocalDate getRightToBeForgottenNewestClosedClaimDate() {
		return rightToBeForgottenNewestClosedClaimDate;
	}

	public void setRightToBeForgottenNewestClosedClaimDate(LocalDate rightToBeForgottenNewestClosedClaimDate) {
		this.rightToBeForgottenNewestClosedClaimDate = rightToBeForgottenNewestClosedClaimDate;
	}

	public int getRightToBeForgottenUpdateUserId() {
		return rightToBeForgottenUpdateUserId;
	}

	public void setRightToBeForgottenUpdateUserId(int rightToBeForgottenUpdateUserId) {
		this.rightToBeForgottenUpdateUserId = rightToBeForgottenUpdateUserId;
	}

	public LocalDateTime getRightToBeForgottenUpdateDateTime() {
		return rightToBeForgottenUpdateDateTime;
	}

	public void setRightToBeForgottenUpdateDateTime(LocalDateTime rightToBeForgottenUpdateDateTime) {
		this.rightToBeForgottenUpdateDateTime = rightToBeForgottenUpdateDateTime;
	}

	public boolean getVulnerableCustomer() {
		return vulnerableCustomer;
	}

	public void setVulnerableCustomer(boolean vulnerableCustomer) {
		this.vulnerableCustomer = vulnerableCustomer;
	}

	public LocalDateTime getVulnerableCustomerUpdateDateTime() {
		return vulnerableCustomerUpdateDateTime;
	}

	public void setVulnerableCustomerUpdateDateTime(LocalDateTime vulnerableCustomerUpdateDateTime) {
		this.vulnerableCustomerUpdateDateTime = vulnerableCustomerUpdateDateTime;
	}

	public int getVulnerableCustomerUpdateUserId() {
		return vulnerableCustomerUpdateUserId;
	}

	public void setVulnerableCustomerUpdateUserId(int vulnerableCustomerUpdateUserId) {
		this.vulnerableCustomerUpdateUserId = vulnerableCustomerUpdateUserId;
	}

	public LocalDate getVulnerableCustomerReviewDate() {
		return vulnerableCustomerReviewDate;
	}

	public void setVulnerableCustomerReviewDate(LocalDate vulnerableCustomerReviewDate) {
		this.vulnerableCustomerReviewDate = vulnerableCustomerReviewDate;
	}

	public boolean getIncorrectAddress() {
		return this.incorrectAddress;
	}

	public void setIncorrectAddress(boolean incorrectAddress) {
		this.incorrectAddress = incorrectAddress;
	}

	public LocalDateTime getIncorrectAddressUpdateDateTime() {
		return this.incorrectAddressUpdateDateTime;
	}

	public void setIncorrectAddressUpdateDateTime(LocalDateTime incorrectAddressUpdateDateTime) {
		this.incorrectAddressUpdateDateTime = incorrectAddressUpdateDateTime;
	}
	
	public Set<ClaimantOtherName> getClaimantOtherNames() {
		return this.otherNames;
	}
	
	public void setClaimantOtherNames(Set<ClaimantOtherName> otherNames) {
		this.otherNames = otherNames;
	}
	
	public Set<ClaimantAdditionalPreviousName> getClaimantAdditionalPreviousNames() {
		return this.additionalPreviousNames;
	}
	
	public void setClaimantAdditionalPreviousNames(Set<ClaimantAdditionalPreviousName> additionalPreviousNames) {
		this.additionalPreviousNames = additionalPreviousNames;
	}

	public Set<ClaimantPreviousEmail> getPreviousEmails() {
		return this.previousEmails;
	}

	public void setPreviousEmails(Set<ClaimantPreviousEmail> previousEmails) {
		this.previousEmails = previousEmails;
	}

	public TriState getFormalDebtArrangement() {
		return formalDebtArrangement;
	}

	public void setFormalDebtArrangement(TriState formalDebtArrangement) {
		this.formalDebtArrangement = formalDebtArrangement;
	}

	public Set<FormalDebtArrangement> getFormalDebtArrangementType() {
		return formalDebtArrangementType;
	}

	public void setFormalDebtArrangementType(Set<FormalDebtArrangement> formalDebtArrangementType) {
		this.formalDebtArrangementType = formalDebtArrangementType;
	}

	public int getIvaCompanyId() {
		return this.ivaCompanyId;
	}


	public void setIvaCompanyId(int ivaCompanyId) {
		this.ivaCompanyId = ivaCompanyId;
	}


	public String getIvaReference() {
		return this.ivaReference;
	}


	public void setIvaReference(String ivaReference) {
		this.ivaReference = ivaReference;
	}

	public TriState getInformalDebtArrangement() {
		return informalDebtArrangement;
	}

	public void setInformalDebtArrangement(TriState informalDebtArrangement) {
		this.informalDebtArrangement = informalDebtArrangement;
	}

	public int getDebtManagementCompanyId() {
		return this.debtManagementCompanyId;
	}

	public void setDebtManagementCompanyId(final int debtManagementCompanyId) {
		this.debtManagementCompanyId = debtManagementCompanyId;
	}

	public String getDebtManagementReference() {
		return this.debtManagementReference;
	}

	public void setDebtManagementReference(final String debtManagementReference) {
		this.debtManagementReference = debtManagementReference;
	}

	public ClaimantUnpresentedCheque getClaimantUnpresentedCheque() {
		return claimantUnpresentedCheque;
	}

	public void setClaimantUnpresentedCheque(ClaimantUnpresentedCheque claimantUnpresentedCheque) {
		this.claimantUnpresentedCheque = claimantUnpresentedCheque;
	}

	public ClaimantExecutor getClaimantExecutor() {
		return this.claimantExecutor;
	}

	public void setClaimantExecutor(ClaimantExecutor claimantExecutor) {
		this.claimantExecutor = claimantExecutor;
	}

	public Boolean getHasVulnerability() {
		return hasVulnerability;
	}

	public void setHasVulnerability(Boolean hasVulnerability) {
		this.hasVulnerability = hasVulnerability;
	}

	public Set<VulnerabilityCategory> getVulnerabilityCategories() {
		return vulnerabilityCategories;
	}

	public void setVulnerabilityCategories(Set<VulnerabilityCategory> vulnerabilityCategories) {
		this.vulnerabilityCategories = vulnerabilityCategories;
	}

	public VulnerableDetailTriState getCanStoreVulnerabilityDetail() { return canStoreVulnerabilityDetail; }

	public void setCanStoreVulnerabilityDetail(VulnerableDetailTriState canStoreVulnerabilityDetail) {
		this.canStoreVulnerabilityDetail = canStoreVulnerabilityDetail;
	}

	public String getVulnerabilityDetail() {
		return vulnerabilityDetail;
	}

	public void setVulnerabilityDetail(String vulnerabilityDetail) {
		this.vulnerabilityDetail = vulnerabilityDetail;
	}

	// This is currently the minimum number of fields we need to merge, feel free to add to this as required
	public void merge(final Claimant claimant) {
		this.title = isNotBlank(claimant.getTitle()) ? claimant.getTitle() : this.title;
		this.forename = isNotBlank(claimant.getForename()) ? claimant.getForename() : this.forename;
		this.middleName = isNotBlank(claimant.getMiddleName()) ? claimant.getMiddleName() : this.middleName;
		this.surname = isNotBlank(claimant.getSurname()) ? claimant.getSurname() : this.surname;
		this.previousSurname = isNotBlank(claimant.getPreviousSurname()) ? claimant.getPreviousSurname() : this.previousSurname;
		this.dob = isNotNull(claimant.getDob()) ? claimant.getDob() : this.dob;
		this.email = isNotBlank(claimant.getEmail()) ? claimant.getEmail() : this.email;
		this.nationalInsuranceNumber = isNotBlank(claimant.getNationalInsuranceNumber()) ? claimant.getNationalInsuranceNumber() : this.nationalInsuranceNumber;
		this.addressId = claimant.getAddressId() != 0 ? claimant.getAddressId() : this.addressId;
		this.mobileTelephone = isNotBlank(claimant.getMobileTelephone()) ? claimant.getMobileTelephone() : this.mobileTelephone;
		this.homeTelephone = isNotBlank(claimant.getHomeTelephone()) ? claimant.getHomeTelephone() : this.homeTelephone;
		this.sellerCompanyId = claimant.getSellerCompanyId() != 0 ? claimant.getSellerCompanyId() : this.sellerCompanyId;
		this.sellerAccountId = claimant.getSellerAccountId() != 0 ? claimant.getSellerAccountId() : this.sellerAccountId;
		this.formalDebtArrangement = isNotNull(claimant.getFormalDebtArrangement()) ? claimant.getFormalDebtArrangement() : this.formalDebtArrangement;
		this.informalDebtArrangement = isNotNull(claimant.getInformalDebtArrangement()) ? claimant.getInformalDebtArrangement() : this.informalDebtArrangement;
	}

	public void toggleLockedFromDialler(final int userId) {
		this.lockedFromDialler = !this.lockedFromDialler;
		this.lockedFromDiallerUpdateDateTime = JodaUtils.newCurrentDateTime();
		this.lockedFromDiallerUpdateUserId = userId;
	}

	@Override
	public boolean equals(final Object obj) {
		return deepEquals(obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

}
