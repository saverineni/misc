package com.leadx.claimant.applicationpropertyservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("applicationPropertyService")
public class ApplicationPropertyService {

	@Autowired
	private ApplicationPropertyRepository applicationPropertyRepository;

	@Transactional(readOnly = true)
	@Cacheable("applicationProperties")
	public String get(final String property) {
		final String propertyFound = this.applicationPropertyRepository.get(property);
		if(null == propertyFound) {
			throw new IllegalArgumentException("Application property was null");
		}
		return propertyFound;
	}
}