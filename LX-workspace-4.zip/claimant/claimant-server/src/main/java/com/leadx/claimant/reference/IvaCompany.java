package com.leadx.claimant.reference;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "iva_company")
public class IvaCompany extends DmIvaCompany {
	
	private static final long serialVersionUID = -4430107819503154233L;

	public IvaCompany() {
		super();
	}

	public IvaCompany(final Integer id, final String name, final String departmentName, final String organisationName, final String subBuildingName, final String buildingName, final String buildingNumber,
                      final String dependentThoroughfare, final String thoroughfare, final String doubleDependentLocality, final String dependentLocality, final String town, final String county, final String postcode) {
		
		super(id, name, departmentName, organisationName, subBuildingName, buildingName, buildingNumber, dependentThoroughfare, thoroughfare, doubleDependentLocality, dependentLocality, town, county, postcode);
	}
}