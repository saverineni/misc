package com.leadx.claimant.lead;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AddressFailureService {

	@Autowired
	AddressFailureRepository addressFailureRepository;

	@Transactional
	public void getById(int id){
		this.addressFailureRepository.getById(id);
	}

	@Transactional
	public void save(AddressFailure addressFailure){
		this.addressFailureRepository.save(addressFailure);
	}

}
