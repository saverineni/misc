package com.leadx.claimant.user;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
class UserRepository {

	private final SessionFactory sessionFactory;

	@Autowired
	public UserRepository(final SessionFactory claimSessionFactory) {
		this.sessionFactory = claimSessionFactory;
	}
	
	protected User getById(final int id) {
		return (User)this.sessionFactory.getCurrentSession().get(User.class, id);
	}

}