package com.leadx.claimant.addressservice;

import java.util.Collection;

import com.google.common.collect.ImmutableCollection;
import com.google.common.collect.ImmutableList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.leadx.claimant.client.AddressDto;

@Component
public class AddressesConverter implements Converter<Collection<Address>, Collection<AddressDto>> {

	@Autowired
	private Converter<Address, AddressDto> addressConverter;

	@Override
	public Collection<AddressDto> convert(final Collection<Address> addresses) {
		final ImmutableCollection.Builder<AddressDto> addressDtos = new ImmutableList.Builder<>();
		for ( final Address address: addresses ) {
			addressDtos.add(this.addressConverter.convert(address));
		}

		return addressDtos.build();
	}
}
