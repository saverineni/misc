package com.leadx.claimant.selleraccountservice;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;

import com.leadx.hibernate.domain.BaseIntegerDomain;

@Entity
@Table(name = "dropdown_configuration")
public class DropdownConfiguration extends BaseIntegerDomain {
	
	private static final long serialVersionUID = -2567070354347861357L;
	
	private String fieldName;
	private String fieldValue;
	
	private int fieldOrder;
	
	public DropdownConfiguration() {
	}
	
	public DropdownConfiguration(final String fieldName, final String fieldValue, final int fieldOrder) {
		this.fieldName = fieldName;
		this.fieldValue = fieldValue;
		this.fieldOrder = fieldOrder;
	}
	
	public String getFieldName() {
		return this.fieldName;
	}

	public String getFieldValue() {
		return this.fieldValue;
	}

	public int getFieldOrder() {
		return this.fieldOrder;
	}

	@Override
	public boolean deepEquals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}
	
}