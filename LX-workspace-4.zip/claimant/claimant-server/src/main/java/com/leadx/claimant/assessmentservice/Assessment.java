package com.leadx.claimant.assessmentservice;

import java.util.List;

import com.leadx.claimant.addressservice.Address;
import com.leadx.claimant.addressservice.PreviousAddress;
import com.leadx.claimant.claimantservice.Claimant;
import com.leadx.claimant.claimantservice.ClaimantContactPreference;
import com.leadx.claimant.claimantservice.ClaimantReferral;
import com.leadx.claimant.selleraccountservice.SellerAccount;

public class Assessment {
	
	private Claimant claimant;
	
	private Address address;
	
	private List<PreviousAddress> previousAddresses;
	
	private ClaimantReferral claimantReferral;
	
	private SellerAccount sellerAccount;

	private ClaimantContactPreference claimantContactPreference;
	
	public Assessment() {}
	
	public Assessment(final Claimant claimant, final Address address, final List<PreviousAddress> previousAddresses,
			final ClaimantReferral claimantReferral, final SellerAccount sellerAccount, final ClaimantContactPreference claimantContactPreference) {
		this.claimant = claimant;
		this.address = address;
		this.previousAddresses = previousAddresses;
		this.claimantReferral = claimantReferral;
		this.sellerAccount = sellerAccount;
		this.claimantContactPreference = claimantContactPreference;
	}

	public Claimant getClaimant() {
		return this.claimant;
	}

	public Address getAddress() {
		return this.address;
	}

	public List<PreviousAddress> getPreviousAddresses() {
		return this.previousAddresses;
	}

	public ClaimantReferral getClaimantReferral() {
		return this.claimantReferral;
	}

	public SellerAccount getSellerAccount() {
		return this.sellerAccount;
	}

	public ClaimantContactPreference getClaimantContactPreference() {
		return claimantContactPreference;
	}
}
