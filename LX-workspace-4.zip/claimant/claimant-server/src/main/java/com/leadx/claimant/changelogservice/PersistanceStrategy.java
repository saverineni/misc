package com.leadx.claimant.changelogservice;

public interface PersistanceStrategy {
	String process(String originalVal);

}
