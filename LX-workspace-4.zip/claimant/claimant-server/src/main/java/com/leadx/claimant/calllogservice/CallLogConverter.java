package com.leadx.claimant.calllogservice;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.leadx.claimant.client.CallLogDto;

@Component("callLogConverter")
public class CallLogConverter implements Converter<CallLog, CallLogDto>  {

	@Override
	public CallLogDto convert(final CallLog source) {
		final String callDisposition = source.getCallDisposition().getName();
		final String callType = source.getCallType().getName();
		return new CallLogDto(source.getClaimantId(), callDisposition, callType, source.getDiallerReferenceId(), source.getInbound(), source.getAgentUserId());
	}
}