package com.leadx.claimant.addressservice;

import static com.leadx.lib.utl.ObjectUtils.isNull;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.leadx.claimant.client.AddressDto;
import com.leadx.lib.utl.JodaUtils;

@Component("addressConverter")
public class AddressConverter implements Converter<Address, AddressDto> {
	
	@Override
	public AddressDto convert(final Address source) {
		if (isNull(source)) {
			return null;
		}

		return new AddressDto(source.getId(),
				source.getDepartmentName(),
				source.getOrganisationName(),
				source.getSubBuildingName(),
				source.getBuildingName(),
				source.getBuildingNumber(),
				source.getDependentThoroughfare(),
				source.getThoroughfare(),
				source.getDoubleDependentLocality(),
				source.getDependentLocality(),
				source.getTown(),
				source.getPostcode(),
				source.getCounty(),
				JodaUtils.localDateToBritishDateStampStringOrNull(source.getPafValidatedDate()),
				JodaUtils.localDateTimeToBritishDateFormatOrNull(source.getUpdatedDateTime()));
	}
}