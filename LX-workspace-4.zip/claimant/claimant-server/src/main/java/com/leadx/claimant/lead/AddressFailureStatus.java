package com.leadx.claimant.lead;

public enum AddressFailureStatus {
	action_required, verified, updated, failed
}
