package com.leadx.claimant.lead;

import static org.apache.commons.lang3.StringUtils.*;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import com.google.common.collect.Lists;
import com.leadx.services.address.Address;

public class AddressComparisonUtils {
	private static List<Field> claimantAddressFields = getClaimantAddressFields();
	private static List<Field> pafAddressFields = getPafAddressFields();
	public static final String regexSpecialChars = "[^a-zA-Z0-9]";

	/**
	 * Verify if the address contained in AddressDto matches the Address from Paf database
	 * @param claimantAddress the claimant address
	 * @param pafAddress address from paf database
	 * @return true if both addresses match
	 */
	public static boolean addressesMatch(final com.leadx.claimant.addressservice.Address claimantAddress, final Address pafAddress){
		for (Field pafAddressField : pafAddressFields) {
			final String value = getFieldValue(pafAddressField, pafAddress);
			if(!fieldExists(value, claimantAddress)){
				return false;
			}
		}

		return true;
	}

	/**
	 * Verify if the string representation of addressDto matches that of pafAddress
	 * If not, try a series of other options to see if the addresses match
	 * @param claimantAddress the claimant address
	 * @param pafAddress address from paf database
	 * @return true if the string contents match
	 */
	public static boolean addressStringsMatch(final com.leadx.claimant.addressservice.Address claimantAddress, final Address pafAddress){
		String claimantAddressString = concatClaimantAddress(claimantAddress);
		String pafAddressString = concatPafAddress(pafAddress);

		if(claimantAddressString.equals(pafAddressString)){
			return true;
		}

		if("FLAT".concat(claimantAddressString).equals(pafAddressString)){
			return true;
		}

		if(claimantAddressString.replaceAll(regexSpecialChars, EMPTY).equals(pafAddressString.replaceAll(regexSpecialChars, EMPTY))){
			return true;
		}

		return false;
	}


	/**
	 * Check if the given field is present in the address
	 * @param pafFieldValue value to find
	 * @param claimantAddress the claimant address
	 * @return true if the field is found
	 */
	private static boolean fieldExists(final String pafFieldValue, final com.leadx.claimant.addressservice.Address claimantAddress){
		if(isEmpty(pafFieldValue)){
			return true;
		}

		for(Field claimantAddressField : claimantAddressFields){
			final String addressFieldValue = getFieldValue(claimantAddressField, claimantAddress);

			if(isEmpty(addressFieldValue)){
				continue;
			}

			if(equalsIgnoreCase(addressFieldValue, pafFieldValue)){
				return true;
			}
		}

		return false;
	}

	/**
	 * Returns the required fields from com.leadx.claimant.addressservice.Address class
	 * @return an array of fields excluding the fields that we do not want to compare
	 */
	private static List<Field> getClaimantAddressFields(){
		Field[] fields = com.leadx.claimant.addressservice.Address.class.getDeclaredFields();
		List<Field> fieldList = new LinkedList<>(Arrays.asList(fields));
		Iterator<Field> fieldListIterator = fieldList.iterator();
		while(fieldListIterator.hasNext()){
			Field field = fieldListIterator.next();
			final String fieldName = field.getName();
			if("id".equals(fieldName) || "pafValidatedDate".equals(fieldName) || "updatedDateTime".equals(fieldName) ||
					"version".equals(fieldName) || "serialVersionUID".equals(fieldName)){
				fieldListIterator.remove();
			}
		}

		return fieldList;
	}

	/**
	 * Returns the required fields from Address class
	 * @return an array of fields excluding the fields that we do not want to compare
	 */
	private static List<Field> getPafAddressFields(){
		Field[] fields = Address.class.getDeclaredFields();
		List<Field> fieldList = new LinkedList<>(Arrays.asList(fields));
		Iterator<Field> fieldListIterator = fieldList.iterator();
		while(fieldListIterator.hasNext()){
			Field field = fieldListIterator.next();
			final String fieldName = field.getName();
			if(Lists.newArrayList("id", "udprn", "dependentThoroughfare", "doubleDependentLocality", "dependentLocality").contains(fieldName)) {
				fieldListIterator.remove();
			}
		}

		return fieldList;
	}

	/**
	 * Return the field value
	 * @param field the field we need to retrieve value from
	 * @param object containing instance
	 * @return
	 */
	private static String getFieldValue(final Field field, final Object object){
		field.setAccessible(true);
		Object value = null;
		try {
			value = field.get(object);
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return (String) value;
	}

	/**
	 * Concatenates all the fields into a String
	 * @param address
	 * @return the string representation
	 */
	public static String concatPafAddress(final Address address){
		StringBuilder addressBuilder = new StringBuilder();
		addressBuilder.append(defaultString(address.getDepartmentName()));
		addressBuilder.append(defaultString(address.getOrganisationName()));
		addressBuilder.append(defaultString(address.getSubBuildingName()));
		addressBuilder.append(defaultString(address.getBuildingName()));
		addressBuilder.append(defaultString(address.getBuildingNumber()));
		addressBuilder.append(defaultString(address.getDependentThoroughfare()));
		addressBuilder.append(defaultString(address.getThoroughfare()));
		addressBuilder.append(defaultString(address.getDoubleDependentLocality()));
		addressBuilder.append(defaultString(address.getDependentLocality()));
		addressBuilder.append(defaultString(address.getTown()));
		String strAddress = addressBuilder.toString();
		return strAddress.replace(SPACE, EMPTY).toUpperCase();
	}

	/**
	 * Concatenates all the fields into a String
	 * @param claimantAddress the claimant address
	 * @return the string representation
	 */
	public static String concatClaimantAddress(final com.leadx.claimant.addressservice.Address claimantAddress){
		StringBuilder addressBuilder = new StringBuilder();
		addressBuilder.append(defaultString(claimantAddress.getDepartmentName()));
		addressBuilder.append(defaultString(claimantAddress.getOrganisationName()));
		addressBuilder.append(defaultString(claimantAddress.getSubBuildingName()));
		addressBuilder.append(defaultString(claimantAddress.getBuildingName()));
		addressBuilder.append(defaultString(claimantAddress.getBuildingNumber()));
		addressBuilder.append(defaultString(claimantAddress.getDependentThoroughfare()));
		addressBuilder.append(defaultString(claimantAddress.getThoroughfare()));
		addressBuilder.append(defaultString(claimantAddress.getDoubleDependentLocality()));
		addressBuilder.append(defaultString(claimantAddress.getDependentLocality()));
		addressBuilder.append(defaultString(claimantAddress.getTown()));
		String strAddress = addressBuilder.toString();
		return strAddress.replace(SPACE, EMPTY).toUpperCase();
	}
}
