package com.leadx.claimant.addressservice;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.SelectBeforeUpdate;
import org.hibernate.annotations.Type;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;

import com.leadx.claimant.changelogservice.ChangeHistory;
import com.leadx.hibernate.domain.BaseIntegerDomain;

@Entity
@SelectBeforeUpdate
@Table(name = "address")
@Embeddable
public class Address extends BaseIntegerDomain {

	private static final long serialVersionUID = -2513645299427016177L;

	@ChangeHistory
	private String departmentName;
	@ChangeHistory
	private String organisationName;
	@ChangeHistory
	private String subBuildingName;
	@ChangeHistory
	private String buildingName;
	@ChangeHistory
	private String buildingNumber;
	@ChangeHistory
	private String dependentThoroughfare;
	@ChangeHistory
	private String thoroughfare;
	@ChangeHistory
	private String doubleDependentLocality;
	@ChangeHistory
	private String dependentLocality;
	@ChangeHistory
	private String town;
	@ChangeHistory
	private String postcode;
	@ChangeHistory
	private String county;
	@Type(type = "local_date_not_null")
	@ChangeHistory
	private LocalDate pafValidatedDate;
	@Column(name = "Timestamp", updatable = false, insertable = false)
	@Type(type = "local_date_time_not_null")
	private LocalDateTime updatedDateTime;

	public Address(final String departmentName, final String organisationName, final String subBuildingName, final String buildingName,
				   final String buildingNumber, final String dependentThoroughfare, final String thoroughfare, final String doubleDependentLocality,
				   final String dependentLocality, final String town, final String postcode, final String county) {
		this.departmentName = departmentName;
		this.organisationName = organisationName;
		this.subBuildingName = subBuildingName;
		this.buildingName = buildingName;
		this.buildingNumber = buildingNumber;
		this.dependentThoroughfare = dependentThoroughfare;
		this.thoroughfare = thoroughfare;
		this.doubleDependentLocality = doubleDependentLocality;
		this.dependentLocality = dependentLocality;
		this.town = town;
		this.postcode = postcode;
		this.county = county;
	}

	public Address() {
	}

	public String getDepartmentName() {
		return this.departmentName;
	}

	public void setDepartmentName(final String departmentName) {
		this.departmentName = departmentName;
	}

	public String getOrganisationName() {
		return this.organisationName;
	}

	public void setOrganisationName(final String organisationName) {
		this.organisationName = organisationName;
	}

	public String getSubBuildingName() {
		return this.subBuildingName;
	}

	public void setSubBuildingName(final String subBuildingName) {
		this.subBuildingName = subBuildingName;
	}

	public String getBuildingName() {
		return this.buildingName;
	}

	public void setBuildingName(final String buildingName) {
		this.buildingName = buildingName;
	}

	public String getBuildingNumber() {
		return this.buildingNumber;
	}

	public void setBuildingNumber(final String buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	public String getDependentThoroughfare() {
		return this.dependentThoroughfare;
	}

	public void setDependentThoroughfare(final String dependentThoroughfare) {
		this.dependentThoroughfare = dependentThoroughfare;
	}

	public String getThoroughfare() {
		return this.thoroughfare;
	}

	public void setThoroughfare(final String thoroughfare) {
		this.thoroughfare = thoroughfare;
	}

	public String getDoubleDependentLocality() {
		return this.doubleDependentLocality;
	}

	public void setDoubleDependentLocality(final String doubleDependentLocality) {
		this.doubleDependentLocality = doubleDependentLocality;
	}

	public String getDependentLocality() {
		return this.dependentLocality;
	}

	public void setDependentLocality(final String dependentLocality) {
		this.dependentLocality = dependentLocality;
	}

	public String getTown() {
		return this.town;
	}

	public void setTown(final String town) {
		this.town = town;
	}

	public String getPostcode() {
		return this.postcode;
	}

	public void setPostcode(final String postcode) {
		this.postcode = postcode;
	}

	public String getCounty() {
		return this.county;
	}

	public void setCounty(final String county) {
		this.county = county;
	}
	
	public LocalDate getPafValidatedDate() {
		return this.pafValidatedDate;
	}

	public void setPafValidatedDate(final LocalDate pafValidatedDate) {
		this.pafValidatedDate = pafValidatedDate;
	}
	
	public LocalDateTime getUpdatedDateTime() {
		return this.updatedDateTime;
	}

	@Override
	public boolean equals(final Object obj) {
		return deepEquals(obj);
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean deepEquals(final Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}
}
