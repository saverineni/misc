package com.leadx.claimant.addressservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.Type;
import org.joda.time.LocalDateTime;

import com.leadx.claimant.changelogservice.ChangeHistory;
import com.leadx.hibernate.domain.BaseIntegerDomain;

@Entity
@Table(name = "previous_address")
public class PreviousAddress extends BaseIntegerDomain {

	private static final long serialVersionUID = 6321409502586268471L;
	
	@Column(name = "FK_ClaimantID")
	private int claimantId;
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_AddressID")
	@Cascade(CascadeType.SAVE_UPDATE)
	private Address address;
	@ChangeHistory
	private boolean fromCurrent;
	@ChangeHistory
	@Type(type = "local_date_time_not_null")
	private LocalDateTime deletedDateTime;
	@ChangeHistory
	@Column(name = "FK_UserId_DeletedBy")
	private int userIdDeletedBy;
	
	public PreviousAddress() { 
		// do nothing
	}
	
	public PreviousAddress(final int claimantId, final Address address, final boolean fromCurrent, final LocalDateTime deletedDateTime, final int userIdDeletedBy) {
		this.claimantId = claimantId;
		this.address = address;
		this.fromCurrent = fromCurrent;
		this.deletedDateTime = deletedDateTime;
		this.userIdDeletedBy = userIdDeletedBy;
	}
	
	public PreviousAddress(final int claimantId, final Address address, final boolean fromCurrent) {
		this.claimantId = claimantId;
		this.address = address;
		this.fromCurrent = fromCurrent;
		this.deletedDateTime = null;
		this.userIdDeletedBy = 0;
	}

	public int getClaimantId() {
		return this.claimantId;
	}

	void setClaimantId(final int claimantId) {
		this.claimantId = claimantId;
	}

	public Address getAddress() {
		return this.address;
	}

	void setAddress(final Address address) {
		this.address = address;
	}

	public boolean getFromCurrent() {
		return this.fromCurrent;
	}

	void setFromCurrent(final boolean fromCurrent) {
		this.fromCurrent = fromCurrent;
	}

	public LocalDateTime getDeletedDateTime() {
		return this.deletedDateTime;
	}

	void setDeletedDateTime(final LocalDateTime deletedDateTime) {
		this.deletedDateTime = deletedDateTime;
	}

	public int getFkUserIdDeletedBy() {
		return this.userIdDeletedBy;
	}

	void setFkUserIdDeletedBy(final int fkUserIdDeletedBy) {
		this.userIdDeletedBy = fkUserIdDeletedBy;
	}

	@Override
	public boolean equals(final Object obj) {
		return deepEquals(obj);
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean deepEquals(final Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}
}