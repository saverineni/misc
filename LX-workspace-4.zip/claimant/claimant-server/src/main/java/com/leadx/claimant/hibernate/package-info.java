@org.hibernate.annotations.TypeDefs({
	@org.hibernate.annotations.TypeDef(name = "local_date_time", typeClass = JodaLocalDateTimeUserType.class),
	@org.hibernate.annotations.TypeDef(name = "local_date_time_not_null", typeClass = JodaLocalDateTimeNotNullUserType.class),
	@org.hibernate.annotations.TypeDef(name = "local_time_not_null", typeClass = JodaLocalTimeNotNullUserType.class),
	@org.hibernate.annotations.TypeDef(name = "local_date", typeClass = JodaLocalDateUserType.class),
	@org.hibernate.annotations.TypeDef(name = "local_date_not_null", typeClass = JodaLocalDateNotNullUserType.class),
	@org.hibernate.annotations.TypeDef(name = "call_type", typeClass = CallTypeUserType.class),
	@org.hibernate.annotations.TypeDef(name = "call_disposition", typeClass = CallDispositionUserType.class),
	@org.hibernate.annotations.TypeDef(name = "formal_debt_arrangement", typeClass = FormalDebtArrangementUserType.class),
	@org.hibernate.annotations.TypeDef(name = "tri_state", typeClass = TriStateUserType.class),
	@org.hibernate.annotations.TypeDef(name = "vulnerable_detail_tri_state", typeClass = VulnerableDetailTriStateUserType.class),
	@org.hibernate.annotations.TypeDef(name = "enum_set", typeClass = EnumSetUserType.class)
})
package com.leadx.claimant.hibernate;

import com.leadx.lib.hibernate.JodaLocalDateTimeNotNullUserType;
import com.leadx.lib.hibernate.JodaLocalDateTimeUserType;
import com.leadx.lib.hibernate.JodaLocalDateUserType;
import com.leadx.lib.hibernate.JodaLocalTimeNotNullUserType;

