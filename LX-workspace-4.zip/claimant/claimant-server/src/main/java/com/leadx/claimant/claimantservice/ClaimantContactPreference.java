package com.leadx.claimant.claimantservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Type;
import org.joda.time.LocalDateTime;

import com.leadx.hibernate.domain.BaseIntegerDomain;

@Entity
@Table(name = "claimant_contact_preference")
public class ClaimantContactPreference extends BaseIntegerDomain {

	@Column(name = "FK_ClaimantID")
	private int claimantId;

	private boolean telephoneOptIn;

	private boolean emailOptIn;

	private boolean smsOptIn;

	private boolean marketingMailingOptIn;

	private boolean cancellation;

	@Column(name = "FK_UserID_Updated")
	private int userIdUpdated;

	@Column(name = "Timestamp", updatable = false, insertable = false)
	@Type(type = "local_date_time_not_null")
	private LocalDateTime updatedDateTime;

	public ClaimantContactPreference(final Integer id, final int claimantId, final boolean telephoneOptIn,
			final boolean emailOptIn, final boolean smsOptIn, final boolean marketingMailingOptIn, final boolean cancellation, final int userIdUpdated,
			final int version) {
		this.setId(id);
		this.claimantId = claimantId;
		this.telephoneOptIn = telephoneOptIn;
		this.emailOptIn = emailOptIn;
		this.smsOptIn = smsOptIn;
		this.marketingMailingOptIn = marketingMailingOptIn;
		this.cancellation = cancellation;
		this.userIdUpdated = userIdUpdated;
		this.setVersion(version);
	}

	public ClaimantContactPreference() {
	}

	public int getClaimantId() {
		return claimantId;
	}

	public void setClaimantId(int claimantId) {
		this.claimantId = claimantId;
	}

	public boolean getTelephoneOptIn() {
		return telephoneOptIn;
	}

	public void setTelephoneOptIn(boolean telephoneOptIn) {
		this.telephoneOptIn = telephoneOptIn;
	}

	public boolean getEmailOptIn() {
		return emailOptIn;
	}

	public void setEmailOptIn(boolean emailOptIn) {
		this.emailOptIn = emailOptIn;
	}

	public boolean getSmsOptIn() {
		return smsOptIn;
	}

	public void setSmsOptIn(boolean smsOptIn) {
		this.smsOptIn = smsOptIn;
	}

	public boolean getMarketingMailingOptIn() {
		return marketingMailingOptIn;
	}

	public void setMarketingMailingOptIn(boolean marketingMailingOptIn) {
		this.marketingMailingOptIn = marketingMailingOptIn;
	}

	public boolean getCancellation() {
		return cancellation;
	}

	public void setCancellation(boolean cancellation) {
		this.cancellation = cancellation;
	}

	public int getUserIdUpdated() {
		return userIdUpdated;
	}

	public void setUserIdUpdated(int userIdUpdated) {
		this.userIdUpdated = userIdUpdated;
	}

	public LocalDateTime getUpdatedDateTime() {
		return this.updatedDateTime;
	}

	public void setUpdatedDateTime(LocalDateTime updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

	@Override
	public boolean equals(final Object object) {
		return deepEquals(object);
	}

	public static class Builder {

		private Integer id;
		private int claimantId;
		private boolean telephoneOptIn;
		private boolean emailOptIn;
		private boolean smsOptIn;
		private boolean marketingMailingOptIn;
		private boolean cancellation;
		private int userIdUpdated;
		private int version;

		public Builder setId(final Integer id) {
			this.id = id;
			return this;
		}

		public Builder setClaimantId(int claimantId) {
			this.claimantId = claimantId;
			return this;
		}

		public Builder setTelephoneOptIn(boolean telephoneOptIn) {
			this.telephoneOptIn = telephoneOptIn;
			return this;
		}

		public Builder setEmailOptIn(boolean emailOptIn) {
			this.emailOptIn = emailOptIn;
			return this;
		}

		public Builder setSmsOptIn(boolean smsOptIn) {
			this.smsOptIn = smsOptIn;
			return this;
		}

		public Builder setMarketingMailingOptIn(boolean marketingMailingOptIn) {
			this.marketingMailingOptIn = marketingMailingOptIn;
			return this;
		}

		public Builder setCancellation(boolean cancellation) {
			this.cancellation = cancellation;
			return this;
		}
		public Builder setUserIdUpdated(int userIdUpdated) {
			this.userIdUpdated = userIdUpdated;
			return this;
		}

		public Builder setVersion(int version) {
			this.version = version;
			return this;
		}

		public Builder allTrue() {
			this.telephoneOptIn = true;
			this.emailOptIn = true;
			this.smsOptIn = true;
			this.marketingMailingOptIn = true;
			this.cancellation = true;
			return this;
		}

		public ClaimantContactPreference createClaimantContactPreference() {
			return new ClaimantContactPreference(id, claimantId, telephoneOptIn, emailOptIn, smsOptIn, marketingMailingOptIn,
					cancellation, userIdUpdated, version);
		}
	}
}
