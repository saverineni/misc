package com.leadx.claimant.reference;

import static java.util.Objects.isNull;

import org.apache.commons.lang3.StringUtils;

import com.leadx.lib.domain.PersistableEnum;

public enum VulnerableDetailTriState implements PersistableEnum {

	YES("Yes", "yes"),

	NO("No", "no"),

	WRITTEN("Written", "written");

	private String prettyName;
	private String internalName;

	VulnerableDetailTriState(final String prettyName, final String internalName) {
		this.internalName = internalName;
		this.prettyName = prettyName;
	}

	public static VulnerableDetailTriState fromValue(final String input) throws IllegalArgumentException {
		if (StringUtils.isEmpty(input)) {
			return null;
		}

		for (final VulnerableDetailTriState VulnerableDetailTriStateOption : values()) {
			if (VulnerableDetailTriStateOption.internalName.equals(input)) {
				return VulnerableDetailTriStateOption;
			}
		}

		throw new IllegalArgumentException("Could not map value [" + input + "] to VulnerableDetailTriState");
	}

	public static VulnerableDetailTriState fromBoolean(final Boolean input) {
		if (null == input) {
			return null;
		}

		return input
				? VulnerableDetailTriState.YES
				: VulnerableDetailTriState.NO;
	}

	public Boolean toBoolean() {
		return this.equals(VulnerableDetailTriState.YES);
	}

	public Boolean isYes() {
		return this.equals(VulnerableDetailTriState.YES);
	}

	public Boolean isNo() {
		return this.equals(VulnerableDetailTriState.NO);
	}

	public Boolean isNotYes() {
		return !this.equals(VulnerableDetailTriState.YES);
	}

	@Override
	public String toValue() {
		return this.internalName;
	}

	@Override
	public String toPrettyString() {
		return this.prettyName;
	}

	public static String toValue(final VulnerableDetailTriState VulnerableDetailTriState) {
		if (isNull(VulnerableDetailTriState)) {
			return null;
		}
		return VulnerableDetailTriState.toValue();
	}

	public static Boolean isNo(final VulnerableDetailTriState VulnerableDetailTriState) {
		if (isNull(VulnerableDetailTriState)) {
			return false;
		}

		return VulnerableDetailTriState.isNo();
	}

	public static Boolean isNotYes(final VulnerableDetailTriState VulnerableDetailTriState) {
		if (isNull(VulnerableDetailTriState)) {
			return true;
		}
		return VulnerableDetailTriState.isNotYes();
	}
}
