package com.leadx.claimant.callallocationservice;

import static org.slf4j.LoggerFactory.getLogger;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Preconditions;
import com.leadx.claimant.claimantservice.Claimant;
import com.leadx.claimant.claimantservice.ClaimantService;
import com.leadx.lib.utl.JodaUtils;
import com.leadx.services.client.CallReason;
import com.leadx.services.client.TCGCallCancellation;
import com.leadx.services.client.TcgCallRequest;
import com.leadx.services.client.TcgProduct;
import com.leadx.services.client.service.TelephonyService;
import com.leadx.services.client.validators.PhoneNumberMapper;
import com.leadx.services.client.validators.PhoneNumberMapper.PhoneNumbers;


@Component
public class TelephonyHelper {

	private static final Logger LOG = getLogger(TelephonyHelper.class);

	@Autowired
	private TelephonyService telephonyService;

	@Autowired
	private ClaimantService claimantService;

	@Value("${claimant-server.chase.callbackDaysInFuture:11}")
	private int callbackDaysInFuture;

	@Value("${claimant-server.chase.automatedCallbackDaysInFuture:5}")
	private int automatedCallbackDaysInFuture;

	@Value("${claimant-server.chase.callUploadHour:9}")
	private int callUploadHour;

	private static final String PHONE_NUMBER_ORDERING = "home,mobile";

	@Transactional
	public void createClaimantChaseCall(final Claimant claimant, final TcgProduct tcgProduct){
		final LocalDateTime chaseCallbackScheduledTime =
				JodaUtils.newCurrentDateTime()
						.plusDays(this.callbackDaysInFuture)
						.withHourOfDay(this.callUploadHour)
						.withMinuteOfHour(0)
						.withSecondOfMinute(0);

		createClaimantChaseCall(claimant, chaseCallbackScheduledTime, tcgProduct);
	}

	@Transactional
	public void createClaimantChaseCall(final Claimant claimant, final TcgProduct tcgProduct, final LocalDateTime chaseCallbackScheduledTime){
		createClaimantChaseCall(claimant, chaseCallbackScheduledTime, tcgProduct);
	}

	@Transactional
	public void cancelClaimantChaseCall(int claimantId, int userId, final TcgProduct tcgProduct){
		final TCGCallCancellation tcgCancellationRequest = TCGCallCancellation.createCancellationRequest(userId);
		tcgCancellationRequest.setClaimantId(claimantId);
		tcgCancellationRequest.setTcgProduct(tcgProduct);
		tcgCancellationRequest.setCallReason(CallReason.CHASE);

		this.telephonyService.cancelCall(tcgCancellationRequest);
	}

	@Transactional
	public void cancelCalls(int claimantId, int userId, final TcgProduct tcgProduct){
		final TCGCallCancellation tcgCancellationRequest = TCGCallCancellation.createCancellationRequest(userId);
		tcgCancellationRequest.setClaimantId(claimantId);
		tcgCancellationRequest.setTcgProduct(tcgProduct);

		this.telephonyService.cancelCall(tcgCancellationRequest);
	}

	@Transactional
	private void createClaimantChaseCall(final Claimant claimant, final LocalDateTime scheduledDateTime, final TcgProduct tcgProduct) {
		final int claimantId = claimant.getId();
		Preconditions.checkArgument(claimantId > 0, "Claimant ID required to create " + tcgProduct.toString().toLowerCase()  + " chase call");

		if (!hasPhoneNumber(claimant)) {
			LOG.info("Cannot create " + tcgProduct.toString().toLowerCase() + " for claimant " + claimantId + " as they have no telephone number");
			return;
		}

		if (claimant.getLockedFromDialler()) {
			throw new RuntimeException("Cannot create " + tcgProduct.toString().toLowerCase() + " chase call, claimant locked from dialler");
		}

		this.telephonyService.scheduleCall(createChaseCall(claimant, scheduledDateTime, tcgProduct));
	}

	private static TcgCallRequest createChaseCall(final Claimant claimant, final LocalDateTime scheduledDateTime, final TcgProduct tcgProduct) {
		final TcgCallRequest callRequest = TcgCallRequest.createChaseCall(tcgProduct.toString().toLowerCase());
			callRequest.setClaimantId(claimant.getId());
			callRequest.setTitle(claimant.getTitle());
			callRequest.setForename(claimant.getForename());
			callRequest.setSurname(claimant.getSurname());

			setPhoneNumbers(claimant.getHomeTelephone(), claimant.getMobileTelephone(), callRequest);

			callRequest.setScheduledDateTime(scheduledDateTime);

			return callRequest;
		}

		private static void setPhoneNumbers(final String homePhoneNumber, final String mobilePhoneNumber, final TcgCallRequest callRequest) {
			final PhoneNumbers phoneNumbers = PhoneNumberMapper.determinePhoneNumbers(homePhoneNumber, mobilePhoneNumber, PHONE_NUMBER_ORDERING);
			callRequest.setPhoneNumber1(phoneNumbers.phoneNumber1);
			callRequest.setPhoneNumber2(phoneNumbers.phoneNumber2);
		}

		private static boolean hasPhoneNumber(final Claimant claimant) {
			return claimant != null &&
				(StringUtils.isNotBlank(claimant.getMobileTelephone()) || StringUtils.isNotBlank(claimant.getHomeTelephone()));
		}



}
