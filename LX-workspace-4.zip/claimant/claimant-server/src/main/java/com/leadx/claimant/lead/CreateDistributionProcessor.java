package com.leadx.claimant.lead;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.leadx.claimant.applicationpropertyservice.ApplicationPropertyService;
import com.leadx.claimant.client.ClaimantLead;
import com.leadx.claimant.client.MethodOfContact;
import com.leadx.claimant.client.ProductType;
import com.leadx.claimant.selleraccountservice.SellerAccount;
import com.leadx.claimant.selleraccountservice.SellerAccountService;
import com.leadx.services.claims.client.ClaimRequest;
import com.leadx.services.distribution.client.DistributionClient;
import com.leadx.services.distribution.client.DistributionRequest;
import com.leadx.services.distribution.client.DistributionRequest.DistributionRequestBuilder;

@Component
public class CreateDistributionProcessor {

	private static final Logger LOG = LoggerFactory.getLogger(CreateDistributionProcessor.class);

	@Autowired
	private DistributionClient distributionClient;

	@Autowired
	private SellerAccountService sellerAccountService;

	@Autowired
	private ApplicationPropertyService applicationPropertyService;

	private static final int WELCOME_EMAIL_FLOWID = 30;
	private static final int WELCOME_SMS_FLOWID = 31;
	private static final int PACK_OUT_EMAIL_POSTAL_CONTACT_FLOWID = 34;

	public ClaimantLead createWebDistributionFlow(final ClaimantLead claimantLead) {
		final SellerAccount sellerAccount = this.sellerAccountService.getByAccountId(claimantLead.getClaimRequest().getSellerAccountId());

		LOG.debug("Attempting to create distribution flows for Claimant {}", claimantLead.getClaimantId());

		if(MethodOfContact.telephone.equals(sellerAccount.getMethodOfContact())){
			if (shouldDistributeEmailWebApplicationFlow(sellerAccount, claimantLead)) {
				this.distributionClient.distribute(createEmailWebFlowRequest(WELCOME_EMAIL_FLOWID, this.applicationPropertyService.get("distribution.scripts.welcomeEmail"),
						this.applicationPropertyService.get("distribution.scripts.contactPhoneNumber"), claimantLead, sellerAccount));
			} else {
				LOG.debug("Could not create distribution email flow for Claimant {}", claimantLead.getClaimantId());
			}

			if (shouldDistributeSmsWebApplicationFlow(sellerAccount, claimantLead)) {
				this.distributionClient.distribute(createSmsWebFlowRequest(WELCOME_SMS_FLOWID, this.applicationPropertyService.get("distribution.scripts.welcomeSms"),
						this.applicationPropertyService.get("distribution.scripts.contactPhoneNumber"), claimantLead, sellerAccount));
			} else {
				LOG.debug("Could not create distribution sms flow for Claimant {}", claimantLead.getClaimantId());
			}
		} else if (MethodOfContact.post.equals(sellerAccount.getMethodOfContact())) {
			if (shouldDistributeEmailWebApplicationFlow(sellerAccount, claimantLead)) {
				this.distributionClient.distribute(createEmailWebFlowRequest(PACK_OUT_EMAIL_POSTAL_CONTACT_FLOWID, this.applicationPropertyService.get("distribution.scripts.packOutEmailPostalContact"),
						this.applicationPropertyService.get("distribution.scripts.contactPhoneNumber"), claimantLead, sellerAccount));
			} else {
				LOG.debug("Could not create distribution email flow for Claimant {}", claimantLead.getClaimantId());
			}
		}

		return claimantLead;
	}

	private static DistributionRequest createEmailWebFlowRequest(final int emailFlowId, final String emailScript, final String contactPhoneNumber, final ClaimantLead claimantLead, final SellerAccount seller) {
		final ClaimRequest.Claimant claimant = claimantLead.getClaimRequest().getClaimant();
		final String productType = ProductType.getById(seller.getProductType().getId()).getLongName();

		final DistributionRequest emailWebApplicationFlow = new DistributionRequestBuilder().reference(claimantLead.getClaimantId())
				.buyerAccountId(0)
				.flow(emailFlowId)
				.step(1)
				.script(emailScript)
				.parameter("emailAddress", claimant.getEmail())
				.parameter("forename", claimant.getForename())
				.parameter("activeProducts", productType)
				.parameter("contactPhoneNumber", contactPhoneNumber)
				.build();

		return emailWebApplicationFlow;
	}

	private static DistributionRequest createSmsWebFlowRequest(final int smsFlowId, final String smsScript, final String contactPhoneNumber, final ClaimantLead claimantLead, final SellerAccount seller) {
		final ClaimRequest.Claimant claimant = claimantLead.getClaimRequest().getClaimant();
		final String productType = StringUtils.upperCase(seller.getProductType().getName());

		final DistributionRequest smsWebApplicationFlow = new DistributionRequestBuilder().reference(claimantLead.getClaimantId())
				.buyerAccountId(0)
				.flow(smsFlowId)
				.step(1)
				.script(smsScript)
				.parameter("mobile", claimant.getMobileTelephone())
				.parameter("firstname", claimant.getForename())
				.parameter("activeProducts", productType)
				.parameter("contactPhoneNumber", contactPhoneNumber)
				.build();

		return smsWebApplicationFlow;
	}

	private static boolean shouldDistributeEmailWebApplicationFlow(final SellerAccount sellerAccount, final ClaimantLead claimantLead) {
		return StringUtils.isNotBlank(claimantLead.getClaimRequest().getClaimant().getEmail()) &&
				sellerAccount.getDistributeAppointmentReminder();
	}

	private static boolean shouldDistributeSmsWebApplicationFlow(final SellerAccount sellerAccount, final ClaimantLead claimantLead) {
		return  StringUtils.isNotBlank(claimantLead.getClaimRequest().getClaimant().getMobileTelephone()) &&
				sellerAccount.getDistributeAppointmentReminder();
	}

}
