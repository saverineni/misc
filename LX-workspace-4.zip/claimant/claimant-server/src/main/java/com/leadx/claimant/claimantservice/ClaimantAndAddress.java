package com.leadx.claimant.claimantservice;

import com.leadx.claimant.addressservice.Address;

/**
 * A combination of claimant and address domain objects. Used for search results where we need the address along with a claimant. We
 * have this because the claimant domain object does not have an address object in it, instead it just has an address id
 */
public class ClaimantAndAddress {
	private final Claimant claimant;
	private final Address address;

	public ClaimantAndAddress(final Claimant claimant, final Address address) {
		this.claimant = claimant;
		this.address = address;
	}

	public Claimant getClaimant() {
		return this.claimant;
	}

	public Address getAddress() {
		return this.address;
	}
}
