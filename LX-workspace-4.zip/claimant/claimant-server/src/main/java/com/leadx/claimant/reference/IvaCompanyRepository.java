package com.leadx.claimant.reference;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("ivaCompanyRepository")
public class IvaCompanyRepository{

	private SessionFactory sessionFactory;

	@Autowired
	public IvaCompanyRepository(final SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@SuppressWarnings("unchecked")
	public List<IvaCompany> getIvaCompanies() {
		return this.sessionFactory.getCurrentSession()
				.createQuery("from IvaCompany order by name asc")
				.list();
	}

}