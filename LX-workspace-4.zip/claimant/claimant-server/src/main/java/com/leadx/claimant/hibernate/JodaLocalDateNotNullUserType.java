package com.leadx.claimant.hibernate;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.type.DateType;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.leadx.lib.hibernate.AbstractImmutableUserType;

public class JodaLocalDateNotNullUserType extends AbstractImmutableUserType {

	private static final DateTimeFormatter DATE_FORMAT = DateTimeFormat.forPattern("yyyy-MM-dd");
	private static final String EMPTY_DATE = "0000-00-00";

	@Override
	public int[] sqlTypes() {
		return new int[] { DateType.INSTANCE.sqlType() };
	}

	@Override
	public Class<?> returnedClass() {
		return LocalDate.class;
	}

	@Override
	public Object nullSafeGet(final ResultSet rs, final String[] names, final SessionImplementor session, final Object owner) throws HibernateException, SQLException {
		final String dateString = rs.getString(names[0]);
		if (StringUtils.isBlank(dateString)) {
			return null;
		}
		if (EMPTY_DATE.equals(dateString)) {
			return null;
		}

		return DATE_FORMAT.parseDateTime(dateString)
			.toLocalDate();
	}

	@Override
	public void nullSafeSet(final PreparedStatement st, final Object value, final int index, final SessionImplementor session) throws HibernateException, SQLException {
		if (null == value) {
			st.setString(index, EMPTY_DATE);
		}
		else {
			st.setString(index, ((LocalDate) value).toString(DATE_FORMAT));
		}
	}

}
