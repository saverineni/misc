package com.leadx.claimant.lead;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class MessageLog {
	private static final Logger LOG = LoggerFactory.getLogger(MessageLog.class);
	
	public void tidyUp(final String rootDirectory, final String todaysDirectory, final String timestamp) {
		try {
			final File file = new File(rootDirectory + "/" + todaysDirectory + "/FAILED-" + timestamp + ".msg");
			
			if (file.exists()) {
				file.delete();
			}
		} catch (final Exception e) {
			LOG.error("Failed to tidy up message log: " + e.getMessage());
		}
	}
	
	public static String now() {
		final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HHmmssSSS");
		return sdf.format(new Date());
	}
}
