package com.leadx.claimant.reference;

import static java.util.Objects.isNull;

import com.leadx.lib.domain.PersistableEnum;

public enum FormalDebtArrangement implements PersistableEnum {

	DEBT_RELIEF_ORDER("Debt Relief Order", "debtrelieforder"),
	IVA("IVA", "iva"),
	BANKRUPTCY("Bankruptcy", "bankruptcy"),
	PROTECTED_TRUST_DEED("Protected Trust Deed", "protectedtrustdeed"),
	SEQUESTRATION("Sequestration", "sequestration"),
	DEBT_ARRANGEMENT_SCHEME("Debt Arrangement Scheme", "debtarrangementscheme"),
	ADMIN_ORDER("Admin Order", "adminorder");

	private String prettyName;
	private String internalName;

	FormalDebtArrangement(final String prettyName, final String internalName) {
		this.internalName = internalName;
		this.prettyName = prettyName;
	}

	public static FormalDebtArrangement fromValue(final String input) {
		for (final FormalDebtArrangement value : values()) {
			if (value.internalName.equals(input)) {
				return value;
			}
		}
		return null;
	}

	public static String toValue(final FormalDebtArrangement formalDebtArrangement) {
		if (isNull(formalDebtArrangement)) {
			return null;
		}
		return formalDebtArrangement.toValue();
	}

	@Override
	public String toValue() {
		return this.internalName;
	}

	@Override
	public String toPrettyString() {
		return this.prettyName;
	}

}
