package com.leadx.claimant.changelogservice;

import java.util.Map;

import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;

import com.google.common.base.Function;
import com.google.common.base.Functions;
import com.google.common.collect.Maps;
import com.leadx.lib.utl.JodaUtils;

@SuppressWarnings("rawtypes")
class ConvertersFactory {

	static Function getConverterForClass(final Class clazz) {
		return Functions.forMap(CONVERTERS, DEFAULT_CONVERTER)
			.apply(clazz);
	}

	private static final Function<Object, String> DEFAULT_CONVERTER = new DefaultConverter();

	private static final Map<Class, Function> CONVERTERS = Maps.newHashMap();
	static {
		CONVERTERS.put(LocalDate.class, new ConvertLocalDate());
		CONVERTERS.put(LocalDateTime.class, new ConvertLocalDateTime());
	}

	private static class DefaultConverter implements Function<Object, String> {
		@Override
		public String apply(final Object input) {
			return input.toString();
		}
	}

	private static class ConvertLocalDateTime implements Function<LocalDateTime, String> {
		@Override
		public String apply(final LocalDateTime input) {
			return JodaUtils.localDateTimeToTimestampStringOrNull(input);
		}
	}

	private static class ConvertLocalDate implements Function<LocalDate, String> {
		@Override
		public String apply(final LocalDate input) {
			return JodaUtils.localDateToDateStringOrNull(input);
		}
	}
}
