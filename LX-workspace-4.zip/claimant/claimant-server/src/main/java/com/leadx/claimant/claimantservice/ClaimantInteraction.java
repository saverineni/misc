package com.leadx.claimant.claimantservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Type;
import org.joda.time.LocalDateTime;

import com.leadx.claimant.user.User;
import com.leadx.hibernate.domain.BaseIntegerDomain;
import com.leadx.lib.utl.JodaUtils;

@Entity
@Table(name = "claimant_interaction")
public class ClaimantInteraction extends BaseIntegerDomain {

	private static final long serialVersionUID = 809416279123741968L;

	@Column(name = "FK_ClaimantID")
	private int claimantId;

	@Column(name = "FK_ProductTypeID")
	private Integer productId;
	
	@Column(name = "Type")
	private String type;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_UserID")
	private User user;
	
	@Column
	@Type(type = "local_date_time_not_null")
	private LocalDateTime createdDateTime;
	
	@Column
	private String content;

	@Column
	private String source;

	public ClaimantInteraction() { }
	
	public ClaimantInteraction(final int claimantId, final Integer productId, final String type, final User user, final String content, final String source) {
		this.claimantId = claimantId;
		this.productId = productId;
		this.type = type;
		this.user = user;
		this.source = source;
		this.createdDateTime = JodaUtils.newCurrentDateTime();
		this.content = content;
	}

	public ClaimantInteraction(final int claimantId, final Integer productId, final String type, final User user, final String content, final String source, final LocalDateTime interactionDateTime) {
		this.claimantId = claimantId;
		this.productId = productId;
		this.type = type;
		this.user = user;
		this.source = source;
		this.createdDateTime = interactionDateTime;
		this.content = content;
	}

	public int getClaimantId() {
		return this.claimantId;
	}

	public Integer getProductId() {
		return productId;
	}

	public String getType() {
		return this.type;
	}

	public User getUser() {
		return this.user;
	}

	public LocalDateTime getCreatedDateTime() {
		return this.createdDateTime;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public static ClaimantInteraction newNote(final int claimantId, final Integer productId, final User user, final String content, final Source source) {
		return new ClaimantInteraction(claimantId, productId, ClaimantInteractionType.NOTE.toValue(), user, content, source.name());
	}

	public static ClaimantInteraction newNoteWithInteractionDateTime(final int claimantId, final Integer productId, final User user, final String content, final Source source, final LocalDateTime interactionDateTime) {
		return new ClaimantInteraction(claimantId, productId, ClaimantInteractionType.NOTE.toValue(), user, content, source.name(), interactionDateTime);
	}

	public static ClaimantInteraction newEvent(final int claimantId, final Integer productId, final User user, final String content, final Source source) {
		return new ClaimantInteraction(claimantId, productId, ClaimantInteractionType.EVENT.toValue(), user, content, source.name());
	}
	
	@Override
	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

	@Override
	public boolean equals(final Object object) {
		return this.deepEquals(object);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}
}
