package com.leadx.claimant.reference;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service("ivaCompanyService")
public class IvaCompanyService {

	@Autowired
	private IvaCompanyRepository ivaCompanyRepository;

	private static final Logger LOG = LoggerFactory.getLogger(IvaCompanyService.class);

	@Transactional(readOnly=true)
	public List<IvaCompany> getIvaCompanies() {
		LOG.info("Getting Iva companies");
		return this.ivaCompanyRepository.getIvaCompanies();
	}

}