package com.leadx.claimant.lead;

import static com.leadx.claimant.claimantservice.ClaimantInteraction.newEvent;
import static com.leadx.claimant.client.MethodOfContact.esignature;
import static com.leadx.claimant.utils.ObjectUtils.isNotNull;
import static com.leadx.lib.utl.JodaUtils.newCurrentDateTime;
import static java.lang.Math.toIntExact;
import static org.apache.commons.lang3.StringUtils.*;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.google.common.base.Preconditions;
import com.google.common.primitives.Ints;
import com.leadx.claimant.addressservice.Address;
import com.leadx.claimant.addressservice.AddressService;
import com.leadx.claimant.claimantservice.*;
import com.leadx.claimant.client.ClaimantLead;
import com.leadx.claimant.reference.TriState;
import com.leadx.claimant.selleraccountservice.SellerAccount;
import com.leadx.claimant.selleraccountservice.SellerAccountService;
import com.leadx.claimant.user.User;
import com.leadx.claimant.user.UserService;
import com.leadx.services.claims.client.ClaimRequest;

@Component
public class SaveClaimantProcessor {

	@Autowired
	private ClaimantService claimantService;

	@Autowired
	private AddressService addressService;

	@Autowired
	private AddressVerificationProcessor addressVerificationProcessor;

	@Autowired
	AddressFailureService addressFailureService;

	@Autowired
	private SellerAccountService sellerAccountService;

	@Autowired
	private ClaimantInteractionRepository claimantInteractionRepository;

	@Autowired
	private UserService userService;

	@Value("#{'${selleraccounts.address.verification.required}'.split(',')}")
	private List<Integer> sellerAccountsRequiringAddressVerification;

	private static final Logger LOG = LoggerFactory.getLogger(AddressVerificationProcessor.class);

	protected static final int SYSTEM_USER_ID = 3388;
	protected static final int ESIGN_USER_ID = 93846;

	public static final int CAMPAIGN_USER_ID = 93864;

	@Transactional
	public ClaimantLead saveClaimant(final ClaimRequest claimRequest) {
		final Address address = generateAddress(claimRequest.getAddress());

		final SellerAccount sellerAccount = this.sellerAccountService.getByAccountId(claimRequest.getSellerAccountId());

		if (esignature.equals(sellerAccount.getMethodOfContact())) {
			final Claimant existingClaimant = this.claimantService.getByLeadId(toIntExact(claimRequest.getLeadId()));

			if (isNotNull(existingClaimant)) {
				final int existingClaimantId = existingClaimant.getId();
				updateClaimantWithClaimantId(claimRequest, existingClaimantId);

				return new ClaimantLead(claimRequest, existingClaimantId);
			}
		}

		if (!isBlankAddress(address)) {
			this.addressService.saveAddress(0, address, false);
		}


		final Claimant claimant = generateClaimant(claimRequest, address, sellerAccount.getFreePpi());
		this.claimantService.createClaimant(claimant);

		if (isNotNull(claimRequest.getPreviousAddresses())) {
			for (final ClaimRequest.Address previousAddress : claimRequest.getPreviousAddresses()) {
				final Address convertedPreviousAddress = generateAddress(previousAddress);

				this.addressService.savePreviousAddress(claimant.getId(), convertedPreviousAddress, false);
			}
		}

		return new ClaimantLead(claimRequest, claimant.getId());
	}

	@Transactional
	public ClaimantLead updateClaimant(final ClaimRequest claimRequest) {
		Preconditions.checkArgument(claimRequest.getClaimant() != null, "Cannot update a claimant without claimant details");
		Preconditions.checkArgument(claimRequest.getClaimant().getId() != 0, "Cannot update a claimant without a claimant ID");

		return updateClaimantWithClaimantId(claimRequest, claimRequest.getClaimant().getId());
	}

	private ClaimantLead updateClaimantWithClaimantId(final ClaimRequest claimRequest, final int claimantId) {
		final Claimant existingClaimant = this.claimantService.getClaimantById(claimantId);
		final SellerAccount sellerAccount = this.sellerAccountService.getByAccountId(existingClaimant.getSellerAccountId());
		final SellerAccount sellerAccountFromRequest = this.sellerAccountService.getByAccountId(claimRequest.getSellerAccountId());

		if(existingClaimant == null) {
			throw new RuntimeException("Ceasing update of claimant as claimant " + claimantId + " cannot be found");
		}

		final int existingAddressId = existingClaimant.getAddressId();
		final Address address = generateAddress(claimRequest.getAddress());

		if (esignature.equals(sellerAccount.getMethodOfContact()) || esignature.equals(sellerAccountFromRequest.getMethodOfContact())) {

			if (existingAddressId == 0) {
				this.addressService.saveAddress(claimantId, address, false);
			}
			else {
				address.setId(existingAddressId);
				this.addressService.updateAddress(claimantId, address, ESIGN_USER_ID, false);
			}

			for (final ClaimRequest.Address previousAddress : claimRequest.getPreviousAddresses()) {
				final Address convertedPreviousAddress = generateAddress(previousAddress);

				this.addressService.savePreviousAddress(claimantId, convertedPreviousAddress, false);
			}

			return getClaimantLead(claimRequest, existingClaimant, address, ESIGN_USER_ID);
		} else {
			final User campaignUser = this.userService.getById(CAMPAIGN_USER_ID);

			final AddressVerificationResult addressVerificationResult =
					this.addressVerificationProcessor.verifyAndReturnAddress(claimantId, false, address);

			final Address addressToUpdate = addressVerificationResult.getResult() ? addressVerificationResult.getAddress() : address;

			if (existingAddressId == 0) {
				this.addressService.saveAddress(claimantId, addressToUpdate, addressVerificationResult.getResult());
				this.claimantInteractionRepository.save(newEvent(claimantId, null, campaignUser, "Claimant Address updated from LP Campaign", Source.CLAIMANT));
			} else {
				final Address existingAddress = this.addressService.getAddressById(existingAddressId);

				if(addressChanged(existingAddress, addressToUpdate)){
					this.addressService.saveHouseMove(claimantId, addressToUpdate);
					this.claimantInteractionRepository.save(newEvent(claimantId, null, campaignUser, "Claimant Address updated from LP Campaign", Source.CLAIMANT));
				}else{
					this.claimantInteractionRepository.save(newEvent(claimantId, null, campaignUser, "Claimant confirmed No Change to the current Address", Source.CLAIMANT));
				}
			}

			if (!addressVerificationResult.getResult()) {
				final Claimant reloadClaimant = this.claimantService.getClaimantById(claimantId);
				LOG.info("Lead has an invalid address. The address will be saved to address_verification_failures table");
				AddressFailure addressFailure = new AddressFailure(claimantId, reloadClaimant.getAddressId(), AddressFailureStatus.action_required, newCurrentDateTime());
				this.addressFailureService.save(addressFailure);
			}

			return getClaimantLead(claimRequest, existingClaimant, addressToUpdate, CAMPAIGN_USER_ID);
		}
	}

	private ClaimantLead getClaimantLead(ClaimRequest claimRequest, Claimant existingClaimant, Address address, int userId) {
		if (sellerAccountsRequiringAddressVerification.contains(claimRequest.getSellerAccountId())) {
			// claimant details should not be updated to the database
			return new ClaimantLead(claimRequest, existingClaimant.getId());
		}

		final Claimant claimant = generateClaimant(claimRequest, address, existingClaimant.getFreePpi());
		if (userId == ESIGN_USER_ID) {
			existingClaimant.merge(claimant);

			final User esignUser = this.userService.getById(ESIGN_USER_ID);
			this.claimantInteractionRepository.save(newEvent(existingClaimant.getId(), null, esignUser, "Claimant Updated", Source.CLAIMANT));
		} else {
			final User campaignUser = this.userService.getById(CAMPAIGN_USER_ID);

			merge(existingClaimant, claimant, campaignUser);
		}
		this.claimantService.updateMergedClaimant(existingClaimant, userId);
		return new ClaimantLead(claimRequest, existingClaimant.getId());
	}

	private void merge(final Claimant existingClaimant, final Claimant claimant, final User campaignUser){
		final int claimantId = existingClaimant.getId();

		if(isNotBlank(claimant.getHomeTelephone()) && !claimant.getHomeTelephone().equals(existingClaimant.getHomeTelephone())){
			String eventMessage;
			if(isNotBlank(existingClaimant.getHomeTelephone())){
				eventMessage = String.format("Claimant updated their Telephone Number From: %s To: %s", existingClaimant.getHomeTelephone(),
						claimant.getHomeTelephone());
			}
			else{
				eventMessage = String.format("Claimant added Telephone Number of %s", claimant.getHomeTelephone());
			}
			this.claimantInteractionRepository.save(newEvent(claimantId, null, campaignUser, eventMessage, Source.CLAIMANT));
			existingClaimant.setHomeTelephone(claimant.getHomeTelephone());
		}

		if(isNotBlank(claimant.getMobileTelephone())&& !claimant.getMobileTelephone().equals(existingClaimant.getMobileTelephone())){
			String eventMessage;
			if(isNotBlank(existingClaimant.getMobileTelephone())){
				eventMessage = String.format("Claimant updated their Telephone Number From: %s To: %s", existingClaimant.getMobileTelephone(),
						claimant.getMobileTelephone());
			}
			else{
				eventMessage = String.format("Claimant added Telephone Number of %s", claimant.getMobileTelephone());
			}
			this.claimantInteractionRepository.save(newEvent(claimantId, null, campaignUser, eventMessage, Source.CLAIMANT));
			existingClaimant.setMobileTelephone(claimant.getMobileTelephone());
		}

		if (isNotBlank(claimant.getPreviousSurname())) {
			existingClaimant.setPreviousSurname(claimant.getPreviousSurname());
		}
	}

	private static boolean addressChanged(final Address oldAddress, final Address newAddress){
		boolean sameAddress = equalsIgnoreCase(oldAddress.getPostcode(), newAddress.getPostcode()) &&
				equalsIgnoreCase(oldAddress.getBuildingNumber(), newAddress.getBuildingNumber()) &&
				equalsIgnoreCase(oldAddress.getBuildingName(), newAddress.getBuildingName()) &&
				equalsIgnoreCase(oldAddress.getSubBuildingName(), newAddress.getSubBuildingName());

		return !sameAddress;
	}

	private static Claimant generateClaimant(final ClaimRequest claimRequest, final Address address, final boolean freePpi) {
		final ClaimRequest.Claimant claimant = claimRequest.getClaimant();
		final String title = trimToLength(claimant.getTitle(), ClaimantService.MAX_TITLE_LENGTH);
		final String forename = trimToLength(claimant.getForename(), ClaimantService.MAX_FORENAME_LENGTH);
		final String middleName = trimToLength(claimant.getMiddleName(), ClaimantService.MAX_MIDDLE_NAME_LENGTH);
		final String surname = trimToLength(claimant.getSurname(), ClaimantService.MAX_SURNAME_LENGTH);
		final String previousSurname = trimToLength(claimant.getPreviousSurname(), ClaimantService.MAX_PREVIOUS_SURNAME_LENGTH) ;
		final String homeTelephone = trimToLength(claimant.getHomeTelephone(), ClaimantService.MAX_HOME_TELELPHONE_LENGTH);
		final String mobileTelephone = trimToLength(claimant.getMobileTelephone(), ClaimantService.MAX_MOBILE_TELEPHONE_LENGTH);
		final String alternativeTelephone = "";
		final String workTelephone = "";
		final String email = trimToLength(claimant.getEmail(), ClaimantService.MAX_EMAIL_LENGTH);

		return new ClaimantBuilder().setId(claimant.getId())
				.setLeadId(Ints.checkedCast(claimRequest.getLeadId()))
				.setSellerAccountId(claimRequest.getSellerAccountId())
				.setSellerCompanyId(claimRequest.getSellerCompanyId())
				.setTitle(changeToEmptyStringIfNull(title))
				.setForename(changeToEmptyStringIfNull(forename))
				.setMiddleName(changeToEmptyStringIfNull(middleName))
				.setSurname(changeToEmptyStringIfNull(surname))
				.setPreviousSurname(changeToEmptyStringIfNull(previousSurname))
				.setDob(claimRequest.getClaimant().getDob())
				.setAddressId(address.getId() != null ? address.getId() : 0)
				.setHomeTelephone(changeToEmptyStringIfNull(homeTelephone))
				.setMobileTelephone(changeToEmptyStringIfNull(mobileTelephone))
				.setAlternativeTelephone(changeToEmptyStringIfNull(alternativeTelephone))
				.setWorkTelephone(changeToEmptyStringIfNull(workTelephone))
				.setEmail(changeToEmptyStringIfNull(email))
				.setNationalInsuranceNumber("")
				.setFreePpi(freePpi)
				.setVulnerabilityDetail("")
				.setFormalDebtArrangement(TriState.fromValue(claimant.getFormalDebtArrangement()))
				.setInformalDebtArrangement(TriState.fromValue(claimant.getInformalDebtArrangement()))
				.createClaimant();

	}

	protected static Address generateAddress(final ClaimRequest.Address address) {
		final String departmentName = trimToLength(address.getDepartmentName(), AddressService.MAX_DEPARTMENT_NAME_LENGTH);
		final String organisationName = trimToLength(address.getOrganisationName(), AddressService.MAX_ORGANISATION_NAME_LENGTH);
		final String subBuildingName = trimToLength(address.getSubBuildingName(), AddressService.MAX_SUB_BUILDING_NAME_LENGTH);
		final String buildingName = trimToLength(address.getBuildingName(), AddressService.MAX_BUILDING_NAME_LENGTH);
		final String buildingNumber = trimToLength(address.getBuildingNumber(), AddressService.MAX_BUILDING_NUMBER_LENGTH);
		final String dependentThoroughfare = "";
		final String thoroughfare = trimToLength(address.getThoroughfare(), AddressService.MAX_THOROUGHFARE_LENGTH);
		final String doubleDependentLocality = "";
		final String dependentLocality = trimToLength(address.getDependentLocality(), AddressService.MAX_DEPENDENT_LOCALITY_LENGTH);
		final String town = trimToLength(address.getTown(), AddressService.MAX_TOWN_LENGTH);
		final String postcode = trimToLength(address.getPostcode(), AddressService.MAX_POSTCODE_LENGTH);
		final String county = "";

		return new Address(changeToEmptyStringIfNull(departmentName),
			changeToEmptyStringIfNull(organisationName),
			changeToEmptyStringIfNull(subBuildingName),
			changeToEmptyStringIfNull(buildingName),
			changeToEmptyStringIfNull(buildingNumber),
			changeToEmptyStringIfNull(dependentThoroughfare),
			changeToEmptyStringIfNull(thoroughfare),
			changeToEmptyStringIfNull(doubleDependentLocality),
			changeToEmptyStringIfNull(dependentLocality),
			changeToEmptyStringIfNull(town),
			changeToEmptyStringIfNull(postcode),
			changeToEmptyStringIfNull(county));
	}

	private static String trimToLength(final String field, final int length) {
		return StringUtils.substring(field, 0, length);
	}

	private static String changeToEmptyStringIfNull(final String str) {
		return str == null? "": str;
	}

	private boolean isBlankAddress(final com.leadx.claimant.addressservice.Address address) {
		return isBlank(address.getOrganisationName()) &&
				isBlank(address.getSubBuildingName()) &&
				isBlank(address.getBuildingName()) &&
				isBlank(address.getBuildingName()) &&
				isBlank(address.getBuildingNumber()) &&
				isBlank(address.getDependentThoroughfare()) &&
				isBlank(address.getThoroughfare()) &&
				isBlank(address.getDoubleDependentLocality()) &&
				isBlank(address.getDependentLocality()) &&
				isBlank(address.getTown()) &&
				isBlank(address.getPostcode());
	}
}
