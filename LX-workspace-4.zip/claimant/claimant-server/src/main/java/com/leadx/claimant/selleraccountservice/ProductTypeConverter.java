package com.leadx.claimant.selleraccountservice;

import static com.leadx.lib.utl.ObjectUtils.isNull;

import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.leadx.claimant.client.ProductTypeDto;

@Component("productTypeConverter")
public class ProductTypeConverter implements Converter<ProductType, ProductTypeDto>  {

	@Override
	public ProductTypeDto convert(final ProductType source) {
		if (isNull(source)) {
			return null;
		}
		final ProductTypeDto dto = new ProductTypeDto(source.getId(), source.getName(), false);
		return dto;
	}

	public List<ProductTypeDto> convertFromList(final List<ProductType> source, final Integer check ) {
		if (isNull(source)) {
			return null;
		}
		final List<ProductTypeDto> dtoList = Lists.newArrayList();
		for(final ProductType current : source) {
			final ProductTypeDto dto = convert(current);
			if (check == dto.getId()) {
				dto.setSelected(true);
			}
			dtoList.add(dto);
		}
		return dtoList;
	}
}