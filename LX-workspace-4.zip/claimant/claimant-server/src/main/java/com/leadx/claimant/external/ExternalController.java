package com.leadx.claimant.external;

import static com.leadx.claimant.claimantservice.Source.PORTAL;
import static com.leadx.lib.utl.ObjectUtils.isNull;
import static com.leadx.lib.utl.json.JsonUtils.deserialize;

import javax.persistence.OptimisticLockException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.hibernate4.HibernateOptimisticLockingFailureException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.google.common.base.Preconditions;
import com.leadx.claimant.addressservice.Address;
import com.leadx.claimant.addressservice.AddressConverter;
import com.leadx.claimant.addressservice.AddressService;
import com.leadx.claimant.authenticationservice.AuthenticationService;
import com.leadx.claimant.claimantservice.Claimant;
import com.leadx.claimant.claimantservice.ClaimantService;
import com.leadx.claimant.claimantservice.Source;
import com.leadx.claimant.client.AddressDto;
import com.leadx.claimant.client.ClaimantAuthenticationDto;
import com.leadx.claimant.client.ClaimantDto;
import com.leadx.claimant.client.SaveAddressDto;
import com.leadx.lib.utl.json.JsonUtils;

// This controller is externally accessible (through portal-server) via an Application Load Balancer
@RequestMapping(value = "/external")
@Controller
public class ExternalController {

	private static final Logger LOG = LoggerFactory.getLogger(ExternalController.class);

	@Autowired
	private Converter<AddressDto, Address> addressDtoConverter;

	@Autowired
	private AddressService addressService;

	@Autowired
	private AuthenticationService authenticationService;

	@Autowired
	private ClaimantService claimantService;

	@Autowired
	private AddressConverter addressConverter;

	public static final int PORTAL_USER_ID = 91995;

	@RequestMapping(value = "/address/update", method = RequestMethod.POST)
	public ResponseEntity<String> updateAddress(@RequestBody final String updatedAddressDtoString) {
		final SaveAddressDto updatedAddressDto = JsonUtils.deserialize(updatedAddressDtoString, SaveAddressDto.class);

		final Address updatedAddress = this.addressDtoConverter.convert(updatedAddressDto.getAddressDto());
		final int claimantId = updatedAddressDto.getClaimantId();

		LOG.debug("updateAddress from an external source for Claimant: {}, Address: {}",  claimantId, updatedAddress);

		try {
			this.addressService.saveHouseMove(claimantId, updatedAddress);

			this.claimantService.saveEvent(claimantId, null, PORTAL_USER_ID, "Address updated from customer portal", PORTAL);
		} catch (final HibernateOptimisticLockingFailureException | OptimisticLockException e) {
			LOG.warn("updateAddress from an external source for Claimant: " + claimantId + " failed because of because of an optimistic locking exception.", e);
			throw e;
		} catch ( final Exception e ) {
			LOG.error("updateAddress from an external source for Claimant: " + claimantId + " failed", e);
			throw e;
		}

		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public ResponseEntity<String> authenticate(@RequestBody final String claimantAuthenticationDto) {
		final ClaimantAuthenticationDto deserialized = deserialize(claimantAuthenticationDto, ClaimantAuthenticationDto.class);

		boolean authenticated;

		try {
			authenticated = this.authenticationService.authenticate(deserialized);
		} catch (final Exception e) {
			LOG.error("Failed to authenticate claimant: ", e);
			return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
		}

		return new ResponseEntity<>(authenticated ? HttpStatus.OK : HttpStatus.UNAUTHORIZED);
	}

	@RequestMapping(value = "/claimant/name/{claimantId}", method = RequestMethod.GET)
	@ResponseBody
	public ClaimantDto getClaimantName(@PathVariable final int claimantId) {
		Preconditions.checkArgument(claimantId > 0, "Claimant ID must be supplied to retrieve a claimant's name");

		final Claimant claimant = this.claimantService.getClaimantById(claimantId);

		if (isNull(claimant)) {
			throw new IllegalArgumentException("Unable to find claimant for ID " + claimantId);
		}

		return ClaimantDto.fromName(claimant.getId(), claimant.getTitle(), claimant.getForename(), claimant.getSurname());
	}

	@RequestMapping(value = "/claimant/address/{claimantId}", method = RequestMethod.GET)
	@ResponseBody
	public AddressDto getClaimantAddress(@PathVariable final int claimantId) {
		Preconditions.checkArgument(claimantId > 0, "Claimant ID must be supplied to retrieve a claimant's address");

		final Address address = this.addressService.getAddressForClaimant(claimantId);

		if (isNull(address)) {
			throw new IllegalArgumentException("Unable to find address for claimant " + claimantId);
		}

		return this.addressConverter.convert(address);
	}

	@RequestMapping(value = "/claimant/{claimantId}/correctAddress", method = RequestMethod.POST)
	@ResponseBody
	public void correctAddress(@PathVariable final int claimantId) {
		Preconditions.checkArgument(claimantId > 0, "Claimant ID must be supplied to flag a claimant's address as correct");

		this.claimantService.saveEvent(claimantId, null, PORTAL_USER_ID, "Claimant confirmed no change to current address", Source.PORTAL);
	}
}
