package com.leadx.claimant.callallocationservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.leadx.claimant.client.CancelCallRequestDto;

@Controller
@RequestMapping(value = "/callAllocation/")
public class CallAllocationController {
	private static final Logger LOG = LoggerFactory.getLogger(CallAllocationController.class);

	@Autowired
	private CallAllocationService callAllocationService;

	@Autowired
	private TelephonyHelper telephonyHelper;

	@RequestMapping(value = "/schedule/{offsetDays}", method = RequestMethod.GET)
	public ResponseEntity<String> scheduleCallAllocations(@PathVariable final int offsetDays) {
		try {
			this.callAllocationService.updateCallAllocations(offsetDays);
			return new ResponseEntity<>(HttpStatus.OK);
		}
		catch (final Exception e) {
			LOG.error("scheduling call request failed for claimant {}", e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/cancel/", method = RequestMethod.POST)
	public ResponseEntity<String> cancelCallAllocation(@RequestBody final CancelCallRequestDto cancelCallRequestDto) {
		try {
			LOG.debug("Cancelling call request for claimant id {} ", cancelCallRequestDto.getClaimantId());
			this.callAllocationService.cancelCallAllocation(cancelCallRequestDto.getClaimantId(), cancelCallRequestDto.getUserId(), cancelCallRequestDto.getTcgProduct());

			return new ResponseEntity<>(HttpStatus.OK);

		}
		catch (final Exception e) {
			LOG.error("cancelling call request failed for claimant {}", e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(value = "/reconcileCallAllocations/{offsetDays}", method = RequestMethod.GET)
	public ResponseEntity<String> reconcileCallAllocations(@PathVariable final int offsetDays){
		try {
			this.callAllocationService.reconcileCallAllocations(offsetDays);
			return new ResponseEntity<>(HttpStatus.OK);
		}
		catch (final Exception e) {
			LOG.error("Error occurred while cancelling call allocations", e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
