package com.leadx.claimant.claimantservice;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.leadx.claimant.client.ClaimantPreviousEmailDto;
import com.leadx.hibernate.domain.BaseIntegerDomain;

@Entity
@Table(name = "claimant_previous_email")
public class ClaimantPreviousEmail extends BaseIntegerDomain {

	private static final long serialVersionUID = -834574312609343537L;

	private String previousEmail;
	private boolean isDeleted;

	public ClaimantPreviousEmail() {

	}

	public ClaimantPreviousEmail(final Integer id, final String previousEmail, final boolean isDeleted) {
		setId(id);
		this.previousEmail = previousEmail;
		this.isDeleted = isDeleted;
	}
	
	public String getPreviousEmail() {
		return this.previousEmail;
	}

	public void setPreviousEmail(String previousEmail) {
		this.previousEmail = previousEmail;
	}

	public boolean getIsDeleted() {
		return this.isDeleted;
	}

	public void setIsDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	
	public static ClaimantPreviousEmail fromDto(final ClaimantPreviousEmailDto previousEmailDto) {
		ClaimantPreviousEmail claimantPreviousEmail =
				new ClaimantPreviousEmail(previousEmailDto.getId() == 0 ? null : previousEmailDto.getId(), previousEmailDto.getPreviousEmail(), previousEmailDto.getIsDeleted());
		claimantPreviousEmail.setVersion(previousEmailDto.getVersion());
		
		return claimantPreviousEmail;
	}
	
	public static ClaimantPreviousEmailDto toDto(final ClaimantPreviousEmail previousEmail) {
		ClaimantPreviousEmailDto claimantPreviousEmailDto = new ClaimantPreviousEmailDto(previousEmail.getId(), previousEmail.getPreviousEmail(),
				previousEmail.getIsDeleted(), previousEmail.getVersion());
		
		return claimantPreviousEmailDto;
	}

	@Override
	public boolean equals(final Object obj) {
		return deepEquals(obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}
}
