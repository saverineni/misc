package com.leadx.claimant.claimantservice;

import static com.leadx.claimant.claimantservice.ClaimantInteraction.newNote;
import static com.leadx.claimant.claimantservice.Source.CLAIMANT;
import static com.leadx.lib.utl.ObjectUtils.isNot;
import static com.leadx.lib.utl.ObjectUtils.isNotNull;
import static java.util.Objects.nonNull;
import static java.util.stream.Collectors.joining;
import static org.apache.commons.lang.BooleanUtils.isTrue;
import static org.apache.commons.lang.StringUtils.isNotEmpty;
import static org.apache.commons.lang3.ObjectUtils.notEqual;

import java.util.Collection;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableList;
import com.leadx.claimant.addressservice.Address;
import com.leadx.claimant.addressservice.AddressService;
import com.leadx.claimant.changelogservice.ChangeLogService;
import com.leadx.claimant.client.CallAllocationGroupServiceWrapper;
import com.leadx.claimant.client.CancelCallRequestDto;
import com.leadx.claimant.client.ProductType;
import com.leadx.claimant.client.VulnerabilityCategory;
import com.leadx.claimant.logiclaimservice.LogiClaimService;
import com.leadx.claimant.selleraccountservice.SellerAccount;
import com.leadx.claimant.selleraccountservice.SellerAccountService;
import com.leadx.claimant.user.User;
import com.leadx.claimant.user.UserService;
import com.leadx.claimant.utils.CallRequestBuilder;
import com.leadx.lib.utl.JodaUtils;
import com.leadx.logiclaimadaptor.NoteDto;
import com.leadx.logiclaimadaptor.client.LogiClaimAdaptorServiceWrapper;
import com.leadx.services.client.TCGCallCancellation;
import com.leadx.services.client.service.TelephonyService;

/**
 * Contains the implementation of the CRU methods for the claimant webservice. Any transactions should be defined in this class. It is called by
 * the spring MVC controller or by other service or routing level object, eg new lead routing, that need to manipulate claims.
 */
@Service
public class ClaimantService {
	private static final Logger LOG = LoggerFactory.getLogger(ClaimantService.class);

	public static final int MAX_TITLE_LENGTH = 10;
	public static final int MAX_FORENAME_LENGTH = 40;
	public static final int MAX_MIDDLE_NAME_LENGTH = 40;
	public static final int MAX_SURNAME_LENGTH = 40;
	public static final int MAX_PREVIOUS_SURNAME_LENGTH = 40;
	public static final int MAX_HOME_TELELPHONE_LENGTH = 20;
	public static final int MAX_MOBILE_TELEPHONE_LENGTH = 20;
	public static final int MAX_WORK_TELEPHONE_LENGTH = 20;
	public static final int MAX_EMAIL_LENGTH = 100;

	protected static final String PPI_PRODUCT_REFERRAL_CALL_REASON_GROUP = "referrals";
	protected static final String PPI_NEW_CLAIMANT_REFERRAL_CALL_REASON_GROUP = "nc-referrals";
	protected static final String PBA_PRODUCT_REFERRAL_CALL_REASON_GROUP = "pba-referrals";
	protected static final String PBA_NEW_CLAIMANT_REFERRAL_CALL_REASON_GROUP = "pba-nc-referrals";
	private static final String logiClaimNotePrefix = "## ";
	private static final String logiClaimEditNotePrefix = "## [Edited] ";


	@Autowired
	private ChangeLogService changeLogService;

	@Autowired
	private ClaimantRepository claimantRepository;

	@Autowired
	private ClaimantOptInRepository claimantOptInRepository;

	@Autowired
	private ClaimantReferralRepository claimantReferralRepository;

	@Autowired
	private ClaimantLogRepository claimantLogRepository;

	@Autowired
	private ClaimantInteractionRepository claimantInteractionRepository;

	@Autowired
	private AddressService addressService;

	@Autowired
	private UserService userService;

	@Autowired
	private TelephonyService telephonyService;

	@Autowired
	private SellerAccountService sellerAccountService;

	@Autowired
	private LogiClaimService logiClaimService;

	@Autowired
	private ClaimantConverter claimantConverter;

	@Autowired
	private CallAllocationGroupServiceWrapper callAllocationGroupServiceWrapper;

	@Autowired
	private LogiClaimAdaptorServiceWrapper logiClaimAdaptorServiceWrapper;


	@Transactional
	public Claimant getClaimantById(final int id) {
		return this.claimantRepository.getClaimantById(id);
	}

	@Transactional
	public Claimant getByLeadId(final int leadId) {
		return this.claimantRepository.getByLeadId(leadId);
	}

	@Transactional
	public void updateAddressId(final int claimantId, final Address address) {
		final Claimant claimant = this.claimantRepository.getClaimantById(claimantId);
		claimant.setAddressId(address.getId());

		this.claimantRepository.updateClaimant(claimant);
	}

	/**
	 * Creates a new claimant in the database.
	 *
	 * @param claimant Claimant to be created. After call it will be updated to contain the new id, created and updated timestamps.
	 *                 Claimant id is ignored as new claimant is always created
	 */
	@Transactional
	public Claimant createClaimant(final Claimant claimant) {
		claimant.setFreePpi(true);
		return createTheClaimant(claimant);
	}

	private Claimant createTheClaimant(final Claimant claimant) {
		claimant.setId(0);
		this.claimantRepository.createClaimant(claimant);
		LOG.debug("Created claimant with id " + claimant.getId());

		this.claimantRepository.evict(claimant);
		return this.claimantRepository.getClaimantById(claimant.getId());
	}

	@Transactional
	public void updateClaimant(final Claimant claimant, final int userId) {
		final Claimant oldClaimant = this.claimantRepository.getClaimantById(claimant.getId());
		this.claimantRepository.evict(oldClaimant);
		claimant.setVersion(oldClaimant.getVersion());
		claimant.setPassword(oldClaimant.getPassword());
		claimant.setPasswordDateTime(oldClaimant.getPasswordDateTime());

		this.claimantRepository.updateClaimant(claimant);
		LOG.debug("Updated claimant with id {}", claimant.getId());
		this.changeLogService.saveChangeValues(claimant.getId(), oldClaimant, claimant, userId);
		addEvents(oldClaimant, claimant, userId);
		LOG.debug("Sending the claimant details to Logiclaim adaptor queue");
		this.logiClaimService.sendToLogiclaim(this.claimantConverter.convert(claimant));
	}

	private void addEvents(final Claimant oldClaimant, final Claimant newClaimant, final int userId){
		final int claimantId = newClaimant.getId();
		String content = null;

		if (vulnerableFlagAdded(oldClaimant, newClaimant)) {
			content = "Vulnerable Customer flag added";
		} else if (vulnerableFlagRemoved(oldClaimant, newClaimant)) {
			content = "Vulnerable Customer flag removed";
		} else if (lockedFromDialler(oldClaimant, newClaimant)) {
			content = "Claimant removed from dialling";
		} else if (unlockedFromDialler(oldClaimant, newClaimant)) {
			content = "Claimant added to dialling";
		} else if (financialCircumstancesChanged(oldClaimant, newClaimant)) {
			content = generateFinancialCircumstancesEvent(newClaimant);
			saveEvent(claimantId, ProductType.PPI.getId(), userId, content, CLAIMANT);
			return;
		} else if (vulnerabilityChanged(oldClaimant, newClaimant)) {
			content = generateVulnerabilityEvent(newClaimant);
			saveEvent(claimantId, ProductType.PPI.getId(), userId, content, Source.CLAIMANT);
			return;
		}

		if (isNotNull(content)){
			saveEvent(claimantId, ProductType.PPI.getId(), userId, content, Source.CLAIMANT);
			saveEvent(claimantId, ProductType.PBA.getId(), userId, content, Source.CLAIMANT);
		}
	}

	@Transactional
	public void syncClaimantToLogiClaim(final int claimantId) {
		final Claimant claimant = this.claimantRepository.getClaimantById(claimantId);
		LOG.debug("Sending the claimant details to Logiclaim adaptor queue");
		this.logiClaimService.sendToLogiclaim(this.claimantConverter.convert(claimant));
	}

	/**
	 * This is a variation of the method {@link #updateClaimant(Claimant, int)}}
	 * This method does not send the update back to the logiclaim queue
	 *
	 * @param claimant the claimant to be updated
	 * @param userId user updating the claimant
	 */
	@Transactional
	public void updateClaimantInConfinement(final Claimant claimant, final int userId) {
		final Claimant oldClaimant = this.claimantRepository.getClaimantById(claimant.getId());
		this.claimantRepository.evict(oldClaimant);
		claimant.setVersion(oldClaimant.getVersion());
		claimant.setPassword(oldClaimant.getPassword());
		claimant.setPasswordDateTime(oldClaimant.getPasswordDateTime());
		this.claimantRepository.updateClaimant(claimant);
		LOG.debug("Updated claimant with id {}", claimant.getId());
		addEvents(oldClaimant, claimant, userId);
		this.changeLogService.saveChangeValues(claimant.getId(), oldClaimant, claimant, userId);
	}

	@Transactional
	public void updateMergedClaimant(final Claimant claimant, final int userId) {
		this.claimantRepository.evict(claimant);
		final Claimant oldClaimant = this.claimantRepository.getClaimantById(claimant.getId());
		this.claimantRepository.evict(oldClaimant);
		claimant.setVersion(oldClaimant.getVersion());
		this.claimantRepository.updateClaimant(claimant);
		LOG.debug("Updated claimant with id {}", claimant.getId());
		this.changeLogService.saveChangeValues(claimant.getId(), oldClaimant, claimant, userId);
	}

	/** Given a string containing a list of claimant ids, gets the claimant and address details. We return the address with
	 * the claimant, rather than making a separate call with a list of address ids, so that we know they are matching pairs. Otherwise
	 * if we had 10 claimants but only 9 of them had address it would be difficult to match up with claimants with their addresses */
	@Transactional
	public List<ClaimantAndAddress> getClaimantsAndAddressByIds(final List<Integer> ids) {
		final List<Claimant> claimants = this.claimantRepository.getClaimantsByIds(ids);

		return toClaimantsAndAddresses(claimants);
	}

	@Transactional
	public Collection<Claimant> getClaimantsByIds(final List<Integer> ids) {
		return this.claimantRepository.getClaimantsByIds(ids);
	}

	@Transactional
	public List<ClaimantAndAddress> searchForClaimantBySurname(final String surname) {
		LOG.debug("searchForClaimantBySurname {}", surname);

		final List<Claimant> claimants = this.claimantRepository.searchForClaimantBySurname(surname + "%");
		return toClaimantsAndAddresses(claimants);
	}

	@Transactional
	public List<ClaimantAndAddress> searchForClaimantByTelephoneNumber(final String number) {
		final List<Claimant> claimants = this.claimantRepository.searchForClaimantByTelephoneNumber(number + "%");
		return toClaimantsAndAddresses(claimants);
	}


	@Transactional
	public List<ClaimantAndAddress> searchForClaimantByPostcode(final String postcode) {
		// Insert a wild card into the middle of the post code
		final String searchString;
		if ( postcode.length() > 3 ) {
			final String firstPart = postcode.substring(0, postcode.length() - 3);
			final String secondPart = postcode.substring(postcode.length() - 3);
			searchString = firstPart + "%" + secondPart + "%";
		} else {
			searchString = postcode + "%";
		}

		final List<Claimant> claimants = this.claimantRepository.searchForClaimantByPostcode(searchString);
		return toClaimantsAndAddresses(claimants);
	}

	@Transactional
	public void setClaimantOptIn(final int claimantId, final boolean optIn) {
		final ClaimantOptIn claimantOptIn = this.claimantOptInRepository.getClaimantOptInByClaimantId(claimantId);
		if ( claimantOptIn == null ) {
			final ClaimantOptIn newClaimantOptIn = new ClaimantOptIn(claimantId, optIn);
			this.claimantOptInRepository.createOptIn(newClaimantOptIn);
		} else {
			claimantOptIn.setOptIn(optIn);
			this.claimantOptInRepository.updateOptIn(claimantOptIn);
		}
	}


	/** Creates a new claimant and creates a claimant referral for that claimant. */
	@Transactional
	public ClaimantReferral createClaimantAndClaimantReferral(final Claimant referredClaimant, final int productTypeId, final int referrerClaimantId, final int createdByAgentId, final int diallerReferenceId, final LocalDateTime scheduledDateTime, final String note) {

		createClaimant(referredClaimant);

		// Create the claimant

		// Create the referral
		final ClaimantReferral claimantReferral = new ClaimantReferral(productTypeId, referrerClaimantId, referredClaimant.getId(), createdByAgentId, diallerReferenceId);
		this.claimantReferralRepository.createClaimantReferral(claimantReferral);
		LOG.debug("createClaimantReferral: created referral with id {}", claimantReferral.getId());

		// Schedule the assessment call
		final Address address = this.addressService.getAddressById(referredClaimant.getAddressId());

		final String callReasonGroup = productTypeId == ProductType.PBA.getId() ? PBA_NEW_CLAIMANT_REFERRAL_CALL_REASON_GROUP : PPI_NEW_CLAIMANT_REFERRAL_CALL_REASON_GROUP;

		if(scheduledDateTime != null){
			this.telephonyService.scheduleCall(
					CallRequestBuilder.createAssessmentCall(callReasonGroup, referredClaimant.getId(), 0L, referredClaimant.getTitle(), referredClaimant.getForename(),
							referredClaimant.getSurname(), referredClaimant.getHomeTelephone(), referredClaimant.getMobileTelephone(), null != address ? address.getPostcode() : "", scheduledDateTime));
		}

		// Save the note if supplied
		if ( note != null && note.length() > 0) {
			saveNote(referredClaimant.getId(), null, createdByAgentId, note, CLAIMANT);
		}

		// Save the event for creating the referral
		if ( referrerClaimantId != 0 ) {
			saveEvent(referrerClaimantId, null, createdByAgentId, "Referred customer (" + referredClaimant.getId() + ") " + referredClaimant.getFullName(), CLAIMANT);
		}

		// Save the event for creating the claimant
		final String referrerName = getReferrerName(referrerClaimantId, createdByAgentId);
		final int referrerId =  referrerClaimantId == 0? createdByAgentId: referrerClaimantId;
		final String referrerRelationship = referrerClaimantId == 0? "Colleague": "Customer";

		final String event = "Created Claimant " + referredClaimant.getId() + ", Referred by " + referrerRelationship + " (" + referrerId + "): " + referrerName;

		saveEvent(referredClaimant.getId(), null, createdByAgentId, event, CLAIMANT);

		return claimantReferral;
	}

	/**
	 * Creates a claimant referral for a different product for the same claimant
	 */
	@Transactional
	public ClaimantReferral createProductReferral(final int claimantId, final String phoneNumber, final int productTypeId, final int createdByAgentId, final int diallerReferenceId, final LocalDateTime scheduledDateTime, final String note) {
		final Claimant claimant = getClaimantById(claimantId);

		// Create the referral
		final ClaimantReferral claimantReferral = new ClaimantReferral(productTypeId, claimantId, claimantId, createdByAgentId, diallerReferenceId);
		this.claimantReferralRepository.createClaimantReferral(claimantReferral);
		LOG.debug("Created product referral with ID: {} for Claimant ID: {}", claimantReferral.getId(), claimantId);

		// Schedule the assessment call
		final Address address = this.addressService.getAddressById(claimant.getAddressId());
		final String callReasonGroup = productTypeId == ProductType.PBA.getId() ? PBA_PRODUCT_REFERRAL_CALL_REASON_GROUP : PPI_PRODUCT_REFERRAL_CALL_REASON_GROUP;

		this.telephonyService.scheduleCall(
				CallRequestBuilder.createAssessmentCall(callReasonGroup, claimantId, 0L, claimant.getTitle(), claimant.getForename(),
						claimant.getSurname(), phoneNumber, null, null != address ? address.getPostcode() : "", scheduledDateTime));

		// Save the note if supplied
		if (note != null && note.length() > 0) {
			saveNote(claimantId, null, createdByAgentId, note, CLAIMANT);
		}

		final String productType = (productTypeId == 1) ? "PPI" : "PBA";
		final String eventProductReferral = String.format("Created %s product referral for claimant %s", productType, claimantId);

		saveEvent(claimantId, null, createdByAgentId, eventProductReferral, CLAIMANT);

		return claimantReferral;
	}

	private String getReferrerName(final int referrerClaimantId, final int createdByAgentId) {
		final String referrerName;
		if ( referrerClaimantId != 0 ) {
			final Claimant referrerClaimant = getClaimantById(referrerClaimantId);
			referrerName = referrerClaimant.getFullName();
		} else {
			final User user = this.userService.getById(createdByAgentId);
			referrerName = user.getFullName();
		}
		return referrerName;
	}


	/** Attempts to lock a claimant. Returns the ClaimantLog row that was found/updated/created.
	 */
	@Transactional
	public ClaimantLog lockClaimant(final int claimantId, final int userId, final int scheduledTaskId) {

		final ClaimantLog claimantLog = this.claimantLogRepository.getClaimantLogByClaimantId(claimantId);
		if ( claimantLog == null ) {
			// not locked by anyone, create a new row
			return createClaimantLog(claimantId, userId, scheduledTaskId);
		} else if ( claimantLog.isLocked() ) {
			if ( claimantLog.getUserId() == userId ) {
				// locked by same user so ok
				LOG.debug("User id {} has already locked claimant {}", userId, claimantId);
			} else {
				// locked by someone else
				LOG.debug("User id {} failed to lock claimant {}, already locked by user id {}", userId, claimantId, claimantLog.getUserId());
			}

			return claimantLog;
		} else {
			// Not locked so create a new row
			return createClaimantLog(claimantId, userId, scheduledTaskId);
		}
	}

	@Transactional
	public ClaimantLog unlockClaimant(final int claimantId, final int userId) {
		final ClaimantLog claimantLog = this.claimantLogRepository.getClaimantLogByClaimantId(claimantId);
		if ( claimantLog != null ) {
			if ( claimantLog.isLocked() ) {
				if ( claimantLog.getUserId() == userId ) {
					// Same person has it locked as is unlocking it
					claimantLog.setClosedDateTime(LocalDateTime.now());
					this.claimantLogRepository.updateClaimantLog(claimantLog);
				} else {
					LOG.warn("Attempted to unlock claimant {} by user but user {} has it locked", claimantId, userId, claimantLog.getClosedDateTime());
				}
			} else {
				LOG.warn("Attempted to unlock claimant {} but claimant already unlocked at {}", claimantId, claimantLog.getClosedDateTime());
			}

			return claimantLog;
		}
		LOG.warn("Attempted to unlock claimant {} but no row found in claimant_log", claimantId);
		return null;
	}

	@Transactional
	public ClaimantLog getClaimantLog(final int claimantId) {
		return this.claimantLogRepository.getClaimantLogByClaimantId(claimantId);
	}

	@Transactional
	public ClaimantReferral getClaimantReferralByReferreeId(final int referreeId) {
		return this.claimantReferralRepository.getClaimantReferralByReferreeId(referreeId);
	}

	@Transactional
	public Collection<ClaimantReferral> getClaimantReferralsByReferreeIds(final Collection<Integer> referreeIds) {
		return this.claimantReferralRepository.getClaimantReferralsByReferreeIds(referreeIds);
	}

	@Transactional
	public List<ClaimantReferral> getProductReferralsForClaimant(final int claimantId) {
		Preconditions.checkArgument(claimantId != 0, "Unable to lookup product referrals with no claimant ID");

		return this.claimantReferralRepository.getProductReferralsForClaimant(claimantId);
	}

	@Transactional
	public void markClaimantAsSuppressed(final int claimantId, final int userId) {
		final Claimant claimant = getClaimantById(claimantId);
		claimant.setSuppressedDateTime(JodaUtils.newCurrentDateTime());
		updateClaimant(claimant, userId);
	}

	@Transactional
	public List<ClaimantInteraction> getNotesForClaimant(final int claimantId) {
		return this.claimantInteractionRepository.getByClaimantId(claimantId, ClaimantInteractionType.NOTE);
	}

	@Transactional
	public List<ClaimantInteraction> getEventsForClaimant(final int claimantId) {
		return this.claimantInteractionRepository.getByClaimantId(claimantId, ClaimantInteractionType.EVENT);
	}

	@Transactional
	public List<ClaimantInteraction> getNotesForClaimantBySource(final int claimantId, final String source, final int productType) {
		return this.claimantInteractionRepository.getByClaimantIdAndSource(claimantId, ClaimantInteractionType.NOTE, source, productType);
	}

	@Transactional
	public List<ClaimantInteraction> getEventsForClaimantBySource(final int claimantId, final String source, final int productType) {
		return this.claimantInteractionRepository.getByClaimantIdAndSource(claimantId, ClaimantInteractionType.EVENT, source, productType);
	}

	@Transactional
	public List<ClaimantInteraction> getNotesForClaimantBySources(final int claimantId, final List<String> sources, final int productType) {
		return this.claimantInteractionRepository.getByClaimantIdBySources(claimantId, ClaimantInteractionType.NOTE, sources, productType);
	}

	@Transactional
	public List<ClaimantInteraction> getEventsForClaimantBySources(final int claimantId, final List<String> sources, final int productType) {
		return this.claimantInteractionRepository.getByClaimantIdBySources(claimantId, ClaimantInteractionType.EVENT, sources, productType);
	}

	@Transactional
	public int saveNote(final int claimantId, final Integer productId, final int userId, final String content, final Source source) {
		final User user = this.userService.getById(userId);

		if(isPba(productId)){
			this.logiClaimAdaptorServiceWrapper.saveNote(buildNoteDto(claimantId, content, userId, true));
		}

		return this.claimantInteractionRepository.save(newNote(claimantId, productId, user, content, source));
	}


	@Transactional
	public int saveNoteWithInteractionDateTime(final int claimantId, final Integer productId, final int userId, final String content, final Source source, final LocalDateTime interactionDateTime) {
		final User user = this.userService.getById(userId);
		final ClaimantInteraction claimantInteraction = ClaimantInteraction.newNoteWithInteractionDateTime(claimantId, productId, user, content, source, interactionDateTime);

		return this.claimantInteractionRepository.save(claimantInteraction);
	}

	@Transactional
	public ClaimantInteraction updateNote(final int noteId, final int claimantId, final Integer productId, final int userId, final String content, final Source source, final int version) {
		final User user = this.userService.getById(userId);
		final ClaimantInteraction claimantInteraction = newNote(claimantId, productId, user, content, source);
		claimantInteraction.setId(noteId);
		claimantInteraction.setVersion(version);

		if(isPba(productId)){
			this.logiClaimAdaptorServiceWrapper.saveNote(buildNoteDto(claimantId, content, userId, false));
		}

		return this.claimantInteractionRepository.update(claimantInteraction);
	}

	@Transactional
	public void saveEvent(final int claimantId, final Integer productId, final int userId, final String content, final Source source) {
		final User user = this.userService.getById(userId);
		final ClaimantInteraction claimantInteraction = ClaimantInteraction.newEvent(claimantId, productId, user, content, source);

		if(isPba(productId)){
			this.logiClaimAdaptorServiceWrapper.saveNote(buildNoteDto(claimantId, content, userId, true));
		}
		this.claimantInteractionRepository.save(claimantInteraction);
	}

	@Transactional
	public List<Integer> getRecentlyUnlockedClaimants(final int offsetDays) {
		return this.claimantRepository.getRecentlyUnlockedClaimants(offsetDays);
	}

	// Instead of making multiple calls to address service, we could add a method to address service to get addresses
	// for list of claimant ids. It would have to cope with some claimants not having an address and must return results
	// in correct order.
	private List<ClaimantAndAddress> toClaimantsAndAddresses(final List<Claimant> claimants) {
		final ImmutableList.Builder<ClaimantAndAddress> results = new ImmutableList.Builder<>();
		for ( final Claimant claimant: claimants) {
			final Address address = this.addressService.getAddressById(claimant.getAddressId());
			results.add(new ClaimantAndAddress(claimant, address));
		}

		return results.build();
	}

	@Transactional
	public void unlockClaimantFromTheDialler(final int claimantId, final int userId) {
		Claimant claimant = getClaimantById(claimantId);
		this.claimantRepository.evict(claimant);
		if (claimant.getLockedFromDialler()) {
			claimant.toggleLockedFromDialler(userId);
			updateClaimant(claimant, userId);
		}
	}

	@Transactional
	public void lockClaimantFromTheDialler(final int claimantId, final int userId) {
		Claimant claimant = getClaimantById(claimantId);
		this.claimantRepository.evict(claimant);
		if (isNot(claimant.getLockedFromDialler())) {
			claimant.toggleLockedFromDialler(userId);
			updateClaimant(claimant, userId);
		}

		final TCGCallCancellation cancellationRequest = TCGCallCancellation.createCancellationRequest(userId);
		cancellationRequest.setClaimantId(claimantId);
		this.telephonyService.cancelCall(cancellationRequest);

		try {
			this.callAllocationGroupServiceWrapper.cancelCallAllocation(new CancelCallRequestDto(claimantId, userId, null));
		} catch (final Exception e){
			LOG.error("cancelling call request failed for claimant: " + claimantId);
			e.printStackTrace();
		}
	}

	public String getSellerAccountNameById(final Integer id) {
		final SellerAccount acc = this.sellerAccountService.getByAccountId(id);
		if (acc != null) {
			return acc.getDisplayName();
		}
		return "";
	}

	private ClaimantLog createClaimantLog(final int claimantId, final int userId, final int scheduledTaskId) {
		final ClaimantLog newClaimantLog = new ClaimantLog(claimantId, scheduledTaskId, LocalDateTime.now(), null, userId);
		this.claimantLogRepository.createClaimantLog(newClaimantLog);
		return newClaimantLog;
	}

	private static boolean isPba(final Integer productId){
		return nonNull(productId) && ProductType.PBA.getId() == productId;
	}

	protected static NoteDto buildNoteDto(final int claimantId, final String content, final int userId, final boolean isNewNote){
		final String prefix = isNewNote ? logiClaimNotePrefix : logiClaimEditNotePrefix;

		return new NoteDto.Builder()
				.setClaimantId(claimantId)
				.setContent(new StringBuilder(prefix).append(content).toString())
				.setUserId(userId)
				.createNoteDto();
	}

	private static boolean vulnerableFlagAdded(final Claimant oldClaimant, final Claimant newClaimant) {
		return !oldClaimant.getVulnerableCustomer() && newClaimant.getVulnerableCustomer();
	}

	private static boolean vulnerableFlagRemoved(final Claimant oldClaimant, final Claimant newClaimant) {
		return oldClaimant.getVulnerableCustomer() && !newClaimant.getVulnerableCustomer();
	}

	private static boolean lockedFromDialler(final Claimant oldClaimant, final Claimant newClaimant) {
		return !oldClaimant.getLockedFromDialler() && newClaimant.getLockedFromDialler();
	}

	private static boolean unlockedFromDialler(final Claimant oldClaimant, final Claimant newClaimant) {
		return oldClaimant.getLockedFromDialler() && !newClaimant.getLockedFromDialler();
	}

	private boolean financialCircumstancesChanged(final Claimant oldClaimant, final Claimant newClaimant) {
		return (notEqual(oldClaimant.getFormalDebtArrangement(), newClaimant.getFormalDebtArrangement())) ||
				(notEqual(oldClaimant.getFormalDebtArrangementType(), newClaimant.getFormalDebtArrangementType())) ||
				(notEqual(oldClaimant.getInformalDebtArrangement(), newClaimant.getInformalDebtArrangement()));
	}

	private String generateFinancialCircumstancesEvent(final Claimant newClaimant) {
		final StringBuilder stringBuilder = new StringBuilder();

		stringBuilder.append("Financial Circumstances - Q1 = ");

		if (isNotNull(newClaimant.getFormalDebtArrangement())) {
			final String formalDebtArrangement = prettyPrintAnswer(newClaimant.getFormalDebtArrangement().toValue());
			stringBuilder.append(formalDebtArrangement);

			if (isNotEmpty(formalDebtArrangement) && formalDebtArrangement.equals("Yes") && isNotNull(newClaimant.getFormalDebtArrangementType())) {
				stringBuilder.append(" (");
				stringBuilder.append(newClaimant.getFormalDebtArrangementType().stream().map(v -> v.toPrettyString()).collect(joining(", ")));
				stringBuilder.append(")");
			}
		}

		stringBuilder.append(", Q2 = ");
		if (isNotNull(newClaimant.getInformalDebtArrangement())) {
			stringBuilder.append(prettyPrintAnswer(newClaimant.getInformalDebtArrangement().toValue()));
		}

		return stringBuilder.toString();
	}


	private static boolean vulnerabilityChanged(final Claimant oldClaimant, final Claimant newClaimant){
		return (notEqual(oldClaimant.getHasVulnerability(), newClaimant.getHasVulnerability())) ||
				(notEqual(oldClaimant.getCanStoreVulnerabilityDetail(), newClaimant.getCanStoreVulnerabilityDetail())) ||
				(notEqual(oldClaimant.getVulnerabilityDetail(), newClaimant.getVulnerabilityDetail())) ||
				(notEqual(oldClaimant.getVulnerabilityCategories(), newClaimant.getVulnerabilityCategories()));
	}

	private String generateVulnerabilityEvent(Claimant newClaimant) {
		final StringBuilder stringBuilder = new StringBuilder();

		stringBuilder.append("Personal Circumstances - Q1 = ");
		if (isTrue(newClaimant.getHasVulnerability())) {
			stringBuilder.append("Yes");

			final Set<VulnerabilityCategory> vulnerabilityCategories = newClaimant.getVulnerabilityCategories();
			if (isNotNull(vulnerabilityCategories) && !vulnerabilityCategories.isEmpty()) {
				stringBuilder.append(" (");
				stringBuilder.append(newClaimant.getVulnerabilityCategories().stream().map(v -> v.toPrettyString()).collect(joining(", ")));
				stringBuilder.append(")");
			}

			if (isNotNull(newClaimant.getCanStoreVulnerabilityDetail())) {
				stringBuilder.append(", Q2 = ");
				stringBuilder.append(newClaimant.getCanStoreVulnerabilityDetail().toPrettyString());
			}

		} else {
			stringBuilder.append("No");
		}

		return stringBuilder.toString();
	}

	private static String prettyPrintAnswer(final String answer){
		switch(answer){
			case "yes":
				return "Yes";
			case "no":
				return "No";
			case "unsure":
				return "Don't Know";
		}
		return StringUtils.EMPTY;
	}
}
