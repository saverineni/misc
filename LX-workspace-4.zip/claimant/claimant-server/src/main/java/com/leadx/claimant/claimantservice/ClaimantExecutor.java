package com.leadx.claimant.claimantservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Type;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;

import com.leadx.claimant.changelogservice.ChangeHistory;
import com.leadx.hibernate.domain.BaseIntegerDomain;

@Entity
@Table(name = "claimant_executor")
public class ClaimantExecutor extends BaseIntegerDomain {
	
	private static final long serialVersionUID = 6497426821967646175L;

	@ChangeHistory
	private String title;
	@Column(name = "FK_ClaimantID")
	private int claimantId;
	@ChangeHistory
	private String forename;
	@ChangeHistory
	private String middleName;
	@ChangeHistory
	private String surname;
	@ChangeHistory
	private String previousSurname;
	@ChangeHistory
	@Type(type = "local_date_not_null")
	private LocalDate dob;

	@Column(name = "FK_AddressID")
	private int addressId;

	@ChangeHistory
	@Column(name = "HomeTelephone", nullable = false)
	private String homeTelephone;
	@ChangeHistory
	private String mobileTelephone;
	@ChangeHistory
	private String email;

	@Type(type = "local_date_time_not_null")
	private LocalDateTime executorUpdateDateTime;

	private boolean isExecutorConfirmed;

	@Type(type = "local_date_time_not_null")
	private LocalDateTime executorConfirmedUpdateDateTime;

	@Type(type = "local_date_time_not_null")
	@Column(updatable = false, insertable = false)
	private LocalDateTime createdDateTime;

	@Type(type = "local_date_time_not_null")
	@Column(updatable = false, insertable = false)
	private LocalDateTime timestamp;

	private boolean isDeleted;

	public ClaimantExecutor() {

	}

	public ClaimantExecutor(final Integer id, final int claimantId, final String title, final String forename, final String middleName, final String surname,
							final String previousSurname, final LocalDate dob, final int addressId, final String homeTelephone, final String mobileTelephone,
							final String email, final LocalDateTime executorUpdateDateTime, final boolean isExecutorConfirmed,
							final LocalDateTime executorConfirmedUpdateDateTime, final LocalDateTime createdDateTime, final LocalDateTime timestamp,
							final boolean isDeleted) {

		setId(id);
		this.claimantId = claimantId;
		this.title = title;
		this.forename = forename;
		this.middleName = middleName;
		this.surname = surname;
		this.previousSurname = previousSurname;
		this.dob = dob;
		this.addressId = addressId;
		this.homeTelephone = homeTelephone;
		this.mobileTelephone = mobileTelephone;
		this.email = email;
		this.executorUpdateDateTime = executorUpdateDateTime;
		this.isExecutorConfirmed = isExecutorConfirmed;
		this.executorConfirmedUpdateDateTime = executorConfirmedUpdateDateTime;
		this.createdDateTime = createdDateTime;
		this.timestamp = timestamp;
		this.isDeleted = isDeleted;
	}

	public int getClaimantId() {
		return claimantId;
	}

	public void setClaimantId(int claimantId) {
		this.claimantId = claimantId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getForename() {
		return forename;
	}

	public void setForename(String forename) {
		this.forename = forename;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getPreviousSurname() {
		return previousSurname;
	}

	public void setPreviousSurname(String previousSurname) {
		this.previousSurname = previousSurname;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getHomeTelephone() {
		return homeTelephone;
	}

	public void setHomeTelephone(String homeTelephone) {
		this.homeTelephone = homeTelephone;
	}

	public String getMobileTelephone() {
		return mobileTelephone;
	}

	public void setMobileTelephone(String mobileTelephone) {
		this.mobileTelephone = mobileTelephone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LocalDateTime getExecutorUpdateDateTime() {
		return executorUpdateDateTime;
	}

	public void setExecutorUpdateDateTime(LocalDateTime executorUpdateDateTime) {
		this.executorUpdateDateTime = executorUpdateDateTime;
	}

	public boolean getIsExecutorConfirmed() {
		return isExecutorConfirmed;
	}

	public void setIsExecutorConfirmed(boolean executorConfirmed) {
		isExecutorConfirmed = executorConfirmed;
	}

	public LocalDateTime getExecutorConfirmedUpdateDateTime() {
		return executorConfirmedUpdateDateTime;
	}

	public void setExecutorConfirmedUpdateDateTime(LocalDateTime executorConfirmedUpdateDateTime) {
		this.executorConfirmedUpdateDateTime = executorConfirmedUpdateDateTime;
	}

	public LocalDateTime getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(LocalDateTime createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}

	public boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(boolean deleted) {
		isDeleted = deleted;
	}

	@Override
	public boolean equals(final Object obj) {
		return deepEquals(obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}
}
