package com.leadx.claimant.hibernate;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.type.StringType;

import com.leadx.claimant.reference.VulnerableDetailTriState;
import com.leadx.lib.hibernate.AbstractImmutableUserType;

public class VulnerableDetailTriStateUserType extends AbstractImmutableUserType {

	/* (non-Javadoc)
	 * @see org.hibernate.VulnerableDetailTriState.VulnerableDetailTriState#sqlTypes()
	 */
	@Override
	public int[] sqlTypes() {
		return new int[] {StringType.INSTANCE.sqlType()};
	}

	/* (non-Javadoc)
	 * @see org.hibernate.VulnerableDetailTriState.VulnerableDetailTriState#returnedClass()
	 */
	@Override
	public Class<?> returnedClass() {
		return VulnerableDetailTriState.class;
	}

	/* (non-Javadoc)
	 * @see org.hibernate.VulnerableDetailTriState.VulnerableDetailTriState#nullSafeGet(java.sql.ResultSet, java.lang.String[], java.lang.Object)
	 */
	public Object nullSafeGet(final ResultSet rs, final String[] names, final SessionImplementor session, final Object owner) throws HibernateException,
			SQLException {
		final String value = rs.getString(names[0]);
		if (null == value) {
			return null;
		}

		return VulnerableDetailTriState.fromValue(value);

	}

	/* (non-Javadoc)
	 * @see org.hibernate.VulnerableDetailTriState.VulnerableDetailTriState#nullSafeSet(java.sql.PreparedStatement, java.lang.Object, int)
	 */
	@Override
	public void nullSafeSet(final PreparedStatement st, final Object value, final int index, final SessionImplementor session) throws HibernateException,
			SQLException {

		if (value == null) {
			st.setString(index, null);
		} else {
			st.setString(index, ((VulnerableDetailTriState) value).toValue());
		}
	}
}
