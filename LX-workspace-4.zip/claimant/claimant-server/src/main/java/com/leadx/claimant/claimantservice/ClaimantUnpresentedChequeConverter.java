package com.leadx.claimant.claimantservice;

import com.leadx.claimant.client.ClaimantUnpresentedChequeDto;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import static com.leadx.claimant.utils.ObjectUtils.isNull;
import static com.leadx.lib.utl.JodaUtils.localDateToBritishDateStampStringOrNull;

@Component("claimantUnpresentedChequeConverter")
public class ClaimantUnpresentedChequeConverter implements Converter<ClaimantUnpresentedCheque, ClaimantUnpresentedChequeDto> {

	@Override
	public ClaimantUnpresentedChequeDto convert(ClaimantUnpresentedCheque source) {
		if (isNull(source)) {
			return null;
		}

		ClaimantUnpresentedChequeDto claimantUnpresentedChequeDto = new ClaimantUnpresentedChequeDto();
		claimantUnpresentedChequeDto.setId(source.getId());
		claimantUnpresentedChequeDto.setClaimantId(source.getClaimantId());
		claimantUnpresentedChequeDto.setDateChequeIssued(localDateToBritishDateStampStringOrNull(source.getDateChequeIssued()));
		claimantUnpresentedChequeDto.setAmount(String.valueOf(source.getAmount()));
		claimantUnpresentedChequeDto.setVersion(source.getVersion());

		return claimantUnpresentedChequeDto;

	}
}
