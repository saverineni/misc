package com.leadx.claimant.selleraccountservice;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository("ProductTypeRepository")
public class ProductTypeRepository {

	private SessionFactory sessionFactory;

	@Autowired
	public ProductTypeRepository(final SessionFactory claimSessionFactory) {
		this.sessionFactory = claimSessionFactory;
	}

	@SuppressWarnings("unchecked")
	public List<ProductType> getAll() {
		return this.sessionFactory.getCurrentSession().createQuery("FROM ProductType ORDER BY id").list();
	}
}