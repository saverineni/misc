package com.leadx.claimant.addressservice;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.leadx.claimant.client.AddressDto;
import com.leadx.lib.utl.JodaUtils;

@Component("addressDtoConverter")
public class AddressDtoConverter implements Converter<AddressDto, Address> {
	
	@Override
	public Address convert(final AddressDto source) {
		final Address address = new Address(StringUtils.defaultString(source.getDepartmentName()),
				StringUtils.defaultString(source.getOrganisationName()),
				StringUtils.defaultString(source.getSubBuildingName()),
				StringUtils.defaultString(source.getBuildingName()),
				StringUtils.defaultString(source.getBuildingNumber()),
				StringUtils.defaultString(source.getDependentThoroughfare()),
				StringUtils.defaultString(source.getThoroughfare()),
				StringUtils.defaultString(source.getDoubleDependentLocality()),
				StringUtils.defaultString(source.getDependentLocality()),
				StringUtils.defaultString(source.getTown()),
				StringUtils.defaultString(source.getPostcode()),
				StringUtils.defaultString(source.getCounty()));
		
		if (source.getId() != 0) {
			address.setId(source.getId());
		}
		
		address.setPafValidatedDate(JodaUtils.britishDateStringToLocalDateOrNull(source.getPafValidatedDate()));
		
		return address;
	}
}