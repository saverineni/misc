package com.leadx.claimant.selleraccountservice;

import java.util.Collection;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
class SellerAccountRepository {

	private final SessionFactory sessionFactory;

	@Autowired
	public SellerAccountRepository(final SessionFactory claimSessionFactory) {
		this.sessionFactory = claimSessionFactory;
	}

	SellerAccount getByAccountId(final int id) {
		return (SellerAccount) this.sessionFactory.getCurrentSession()
				.createQuery("FROM SellerAccount WHERE accountId = :id")
				.setParameter("id", id)
				.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	List<SellerAccount> getAll() {
		return this.sessionFactory.getCurrentSession().createQuery("FROM SellerAccount ORDER BY id").list();
	}

	void update(final SellerAccount sellerAccount) {
		this.sessionFactory.getCurrentSession().update(sellerAccount);
	}

	void create(final SellerAccount sellerAccount) {
		this.sessionFactory.getCurrentSession().save(sellerAccount);
	}

	@SuppressWarnings("unchecked")
	Collection<SellerAccount> getByAccountIds(final Collection<Integer> ids) {
		return this.sessionFactory.getCurrentSession().
			createQuery("FROM SellerAccount c WHERE accountId in (:ids)")
			.setParameterList("ids", ids)
			.list();
	}

	@SuppressWarnings("unchecked")
	List<SellerAccount> getSourcedSellerAccounts() {
		return this.sessionFactory.getCurrentSession().createQuery("FROM SellerAccount sa WHERE sa.sourceDescription != ''").list();
	}

	void evict(final SellerAccount sellerAccount) {
		this.sessionFactory.getCurrentSession().evict(sellerAccount);
	}

	public boolean isFreePpi(int sellerAccountId){
		SellerAccount sellerAccount = getByAccountId(sellerAccountId);
		return sellerAccount == null ? false : sellerAccount.getFreePpi();
	}
}