package com.leadx.claimant.selleraccountservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.leadx.hibernate.domain.BaseIntegerDomain;

@SuppressWarnings("serial")
@Entity
@Table(name = "product_type")
public class ProductType extends BaseIntegerDomain {

	@Column(name="Name")
	private String name;

	public ProductType() {}

	public ProductType(final int id, final String name) {
		setId(id);
		this.name = name;
	}

	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

	@Override
	public boolean equals(final Object other) {
		return deepEquals(other);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}
}