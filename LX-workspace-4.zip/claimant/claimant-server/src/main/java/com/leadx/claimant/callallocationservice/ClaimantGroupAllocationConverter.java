package com.leadx.claimant.callallocationservice;

import org.springframework.core.convert.converter.Converter;

public class ClaimantGroupAllocationConverter implements Converter<ClaimantGroupAllocation, ClaimantGroupAllocationDto>{


		@Override
		public ClaimantGroupAllocationDto convert(final ClaimantGroupAllocation source) {
			if ( source == null ) {
				return null;
			}

			return new ClaimantGroupAllocationDto(
				source.getClaimantId(),
				source.getCallReason(),
				source.getCallReasonGroup());

		}

}
