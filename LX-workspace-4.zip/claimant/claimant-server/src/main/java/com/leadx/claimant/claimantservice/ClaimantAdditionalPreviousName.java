package com.leadx.claimant.claimantservice;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.leadx.claimant.client.ClaimantAdditionalPreviousNameDto;
import com.leadx.hibernate.domain.BaseIntegerDomain;

@Entity
@Table(name = "claimant_additional_previous_name")
public class ClaimantAdditionalPreviousName extends BaseIntegerDomain {
	
	private static final long serialVersionUID = -7978944312604647537L;
	
	private String additionalPreviousName;
	private boolean isDeleted;
	
	public ClaimantAdditionalPreviousName() {
		
	}
	
	public ClaimantAdditionalPreviousName(final Integer id, final String additionalPreviousName, final boolean isDeleted) {
		setId(id);
		this.additionalPreviousName = additionalPreviousName;
		this.isDeleted = isDeleted;
	}
	
	public String getAdditionalPreviousName() {
		return this.additionalPreviousName;
	}

	public void setAdditionalPreviousName(String additionalPreviousName) {
		this.additionalPreviousName = additionalPreviousName;
	}

	public boolean getIsDeleted() {
		return this.isDeleted;
	}

	public void setIsDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	
	public static ClaimantAdditionalPreviousName toDto(final ClaimantAdditionalPreviousNameDto additionalPreviousName) {
		ClaimantAdditionalPreviousName claimantPreviousName = 
				new ClaimantAdditionalPreviousName(additionalPreviousName.getId() == 0 ? null : additionalPreviousName.getId(), additionalPreviousName.getAdditionalPreviousName(), additionalPreviousName.getIsDeleted());
		claimantPreviousName.setVersion(additionalPreviousName.getVersion());
		
		return claimantPreviousName;
	}
	
	public static ClaimantAdditionalPreviousNameDto fromDto(final ClaimantAdditionalPreviousName previousName) {
		ClaimantAdditionalPreviousNameDto claimantPreviousNamesDto = new ClaimantAdditionalPreviousNameDto(previousName.getId(), previousName.getAdditionalPreviousName(), previousName.getIsDeleted(), previousName.getVersion());
		
		return claimantPreviousNamesDto;
	}

	@Override
	public boolean equals(final Object obj) {
		return deepEquals(obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}
}
