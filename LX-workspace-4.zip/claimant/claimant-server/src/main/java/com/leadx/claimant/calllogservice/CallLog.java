package com.leadx.claimant.calllogservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Type;
import org.joda.time.LocalDateTime;

import com.leadx.claimant.client.CallDisposition;
import com.leadx.claimant.client.CallType;
import com.leadx.hibernate.domain.BaseIntegerDomain;
import com.leadx.lib.utl.JodaUtils;

@Entity
@Table(name = "call_log")
@Inheritance(strategy = InheritanceType.JOINED)
public class CallLog extends BaseIntegerDomain {

	public CallLog() {}

	/**
	 *
	 * @param claimantId
	 * @param disposition
	 * @param callType
	 * @param diallerRefId
	 * @param inbound
	 * @param userId
	 * @return successful save
	 */
	public CallLog(final int claimantId, final CallDisposition disposition, final CallType callType, final int diallerRefId,
			final boolean inbound, final int userId) {
		this.claimantId = claimantId;
		this.callDisposition = disposition;
		this.callType = callType;
		this.diallerReferenceId = diallerRefId;
		this.agentUserId = userId;
		this.dispositionDateTime = JodaUtils.newCurrentDateTime();
		this.inbound = inbound;
	}

	private static final long serialVersionUID = -2110586329264961128L;

	@Column(name = "FK_ClaimantID")
	private int claimantId;

	@Column(name = "FK_CallTypeID")
	@Type(type = "call_type")
	private CallType callType;

	@Column(name = "FK_CallDispositionID")
	@Type(type = "call_disposition")
	private CallDisposition callDisposition;

	@Column(name = "FK_UserID_Agent")
	private int agentUserId;

	private int diallerReferenceId;

	@Type(type = "local_date_time_not_null")
	private LocalDateTime dispositionDateTime;

	private boolean inbound;

	public int getClaimantId() {
		return this.claimantId;
	}

	public void setClaimantId(final int claimantId) {
		this.claimantId = claimantId;
	}

	public CallType getCallType() {
		return this.callType;
	}

	public void setCallType(final CallType callType) {
		this.callType = callType;
	}

	public CallDisposition getCallDisposition() {
		return this.callDisposition;
	}

	public void setCallDisposition(final CallDisposition callDisposition) {
		this.callDisposition = callDisposition;
	}

	public int getAgentUserId() {
		return this.agentUserId;
	}

	public void setAgentUserId(final int agentUserId) {
		this.agentUserId = agentUserId;
	}

	public int getDiallerReferenceId() {
		return this.diallerReferenceId;
	}

	public void setDiallerReferenceId(final int diallerReferenceId) {
		this.diallerReferenceId = diallerReferenceId;
	}

	public LocalDateTime getDispositionDateTime() {
		return this.dispositionDateTime;
	}

	public void setDispositionDateTime(final LocalDateTime dispositionDateTime) {
		this.dispositionDateTime = dispositionDateTime;
	}

	public boolean getInbound() {
		return this.inbound;
	}

	public void setInbound(final boolean inbound) {
		this.inbound = inbound;
	}

	@Override
	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

	@Override
	public boolean equals(final Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
