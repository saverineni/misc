package com.leadx.claimant.reference;

import com.leadx.claimant.client.reference.DebtManagementCompanyDto;
import com.leadx.claimant.client.reference.IvaCompanyDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@RequestMapping(value = "/unsecure")
@Controller
public class DmIvaCompanyController {

	private static final Logger LOG = LoggerFactory.getLogger(DmIvaCompanyController.class);

	@Autowired
	private DebtManagementCompanyService debtManagementCompanyService;

	@Autowired
	private IvaCompanyService ivaCompanyService;

	@Autowired
	private DebtManagementCompanyConverter debtManagementCompanyConverter;

	@Autowired
	private IvaCompanyConverter ivaCompanyConverter;

	@ResponseBody
	@RequestMapping(value = "/debtManagementCompanies", method= RequestMethod.GET)
	public List<DebtManagementCompanyDto> getDebtManagementCompanies(){
		LOG.info("Retrieving Debt Management companies...");
		final List<DebtManagementCompanyDto> debtManagementCompanyDtos;

		try{
			debtManagementCompanyDtos = debtManagementCompanyConverter.convertList(debtManagementCompanyService.getDebtManagementCompanies());
		}catch(Exception e){
			LOG.error("Failed to retrieve Debt Management companies", e);
			throw new RuntimeException(e);
		}

		LOG.info("Successfully retrieved Debt Management companies");
		return debtManagementCompanyDtos;
	}

	@ResponseBody
	@RequestMapping(value = "/ivaCompanies", method= RequestMethod.GET)
	public List<IvaCompanyDto> getIvaCompanies(){
		LOG.info("Retrieving IVA Companies...");
		final List<IvaCompanyDto> ivaCompanyDtos;

		try{
			ivaCompanyDtos = ivaCompanyConverter.convertList(ivaCompanyService.getIvaCompanies());
		}catch(Exception e){
			LOG.error("Failed to retrieve IVA companies", e);
			throw new RuntimeException(e);
		}

		LOG.info("Successfully retrieved IVA companies");
		return ivaCompanyDtos;
	}
}
