package com.leadx.claimant.logiclaimservice;

import com.leadx.claimant.client.ClaimantDto;
import com.leadx.lib.utl.json.JsonUtils;
import com.leadx.logiclaimadaptor.client.LogiClaimAdaptorClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("logiClaimService")
public class LogiClaimService {
	@Autowired
	private LogiClaimAdaptorClient logiClaimAdaptorClient;

	public void sendToLogiclaim(final ClaimantDto claimantDto) {
		this.logiClaimAdaptorClient.sendClaimant(JsonUtils.serialize(claimantDto, true));
	}
}
