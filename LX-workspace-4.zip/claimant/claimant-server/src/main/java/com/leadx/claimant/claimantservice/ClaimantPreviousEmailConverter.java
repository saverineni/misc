package com.leadx.claimant.claimantservice;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.leadx.claimant.client.ClaimantPreviousEmailDto;

@Component("claimantPreviousEmailConverter")
public class ClaimantPreviousEmailConverter implements Converter<Set<ClaimantPreviousEmail>, List<ClaimantPreviousEmailDto>>{

	@Override
	public List<ClaimantPreviousEmailDto> convert(Set<ClaimantPreviousEmail> source) {
		if(source == null) {
			return Lists.newArrayList();
		}
		
		return source.stream().map(ClaimantPreviousEmail::toDto).collect(Collectors.toList());
	}
}
