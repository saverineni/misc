package com.leadx.claimant.claimantservice;

import static com.leadx.lib.utl.ObjectUtils.isNull;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.leadx.claimant.client.ClaimantContactPreferenceDto;

@Component("claimantContactPreferenceDtoConverter")
public class ClaimantContactPreferenceDtoConverter implements Converter<ClaimantContactPreferenceDto, ClaimantContactPreference> {
	
	@Override
	public ClaimantContactPreference convert(final ClaimantContactPreferenceDto source) {
		if (isNull(source)) {
			return null;
		}

		return new ClaimantContactPreference.Builder()
				.setId(source.getId())
				.setClaimantId(source.getClaimantId())
				.setTelephoneOptIn(source.getTelephoneOptIn())
				.setEmailOptIn(source.getEmailOptIn())
				.setSmsOptIn(source.getSmsOptIn())
				.setMarketingMailingOptIn(source.getMarketingMailingOptIn())
				.setCancellation(source.getCancellation())
				.setUserIdUpdated(source.getUserIdUpdated())
				.setVersion(source.getVersion())
				.createClaimantContactPreference();
	}

}
