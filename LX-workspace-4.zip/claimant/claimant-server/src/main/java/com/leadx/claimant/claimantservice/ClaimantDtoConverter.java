package com.leadx.claimant.claimantservice;

import static com.leadx.claimant.client.VulnerabilityCategory.fromValue;
import static com.leadx.claimant.utils.ObjectUtils.isNotNull;
import static java.util.stream.Collectors.toSet;

import java.util.Set;

import com.leadx.claimant.reference.VulnerableDetailTriState;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.google.common.collect.Sets;
import com.leadx.claimant.client.ClaimantDto;
import com.leadx.claimant.reference.FormalDebtArrangement;
import com.leadx.claimant.reference.TriState;
import com.leadx.claimant.client.VulnerabilityCategory;
import com.leadx.lib.utl.JodaUtils;

@Component
public class ClaimantDtoConverter implements Converter<ClaimantDto, Claimant> {
	
	@Autowired
	private ClaimantOtherNameDtoConverter otherNamesDtoConverter;
	
	@Autowired
	private ClaimantAdditionalPreviousNameDtoConverter previousNamesDtoConverter;

	@Autowired
	private ClaimantPreviousEmailDtoConverter previousEmailDtoConverter;

	@Autowired
	private ClaimantUnpresentedChequeDtoConverter claimantUnpresentedChequeDtoConverter;

	@Autowired
	private ClaimantExecutorDtoConverter claimantExecutorDtoConverter;

	@Override
	public Claimant convert(final ClaimantDto source) {

		final Set<VulnerabilityCategory> vulnerabilityCategories = isNotNull(source.getVulnerabilityCategories()) ?
				source.getVulnerabilityCategories().stream().map(v -> fromValue(v)).collect(toSet()) :
				Sets.newHashSet();

		final Set<FormalDebtArrangement> formalDebtArrangementType = isNotNull(source.getFormalDebtArrangementType()) ?
				source.getFormalDebtArrangementType().stream().map(v -> FormalDebtArrangement.fromValue(v)).collect(toSet()) :
				Sets.newHashSet();

		return new ClaimantBuilder().setId(source.getId())
				.setLeadId(source.getLeadId())
				.setSellerAccountId(source.getSellerAccountId())
				.setSellerCompanyId(source.getSellerCompanyId())
				.setTitle(StringUtils.defaultString(source.getTitle()))
				.setForename(StringUtils.defaultString(source.getForename()))
				.setMiddleName(StringUtils.defaultString(source.getMiddleName()))
				.setSurname(StringUtils.defaultString(source.getSurname()))
				.setPreviousSurname(StringUtils.defaultString(source.getPreviousSurname()))
				.setDob(JodaUtils.britishDateStringToLocalDateOrNull(source.getDob()))
				.setAddressId(source.getAddressId())
				.setHomeTelephone(StringUtils.defaultString(source.getHomeTelephone()))
				.setMobileTelephone(StringUtils.defaultString(source.getMobileTelephone()))
				.setAlternativeTelephone(StringUtils.defaultString(source.getAlternativeTelephone()))
				.setWorkTelephone(StringUtils.defaultString(source.getWorkTelephone()))
				.setEmail(StringUtils.defaultString(source.getEmail()))
				.setNationalInsuranceNumber(StringUtils.defaultString(source.getNationalInsuranceNumber()))
				.setLockedFromDialler(source.getLockedFromDialler())
				.setLockedFromDiallerUpdateDateTime(JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(source.getLockedFromDiallerUpdateDateTime()))
				.setLockedFromDiallerUpdateUserId(source.getLockedFromDiallerUpdateUserId())
				.setRightToBeForgotten(source.getRightToBeForgotten())
				.setRightToBeForgottenNewestClosedClaimDate(JodaUtils.britishDateStringToLocalDateOrNull(source.getRightToBeForgottenNewestClosedClaimDate()))
				.setRightToBeForgottenUpdateUserId(source.getRightToBeForgottenUpdateUserId())
				.setRightToBeForgottenUpdateDateTime(JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(source.getRightToBeForgottenUpdateDateTime()))
				.setVulnerableCustomer(source.getVulnerableCustomer())
				.setVulnerableCustomerUpdateDateTime(JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(source.getVulnerableCustomerUpdateDateTime()))
				.setVulnerableCustomerUpdateUserId(source.getVulnerableCustomerUpdateUserId())
				.setVulnerableCustomerReviewDate(JodaUtils.britishDateStringToLocalDateOrNull(source.getVulnerableCustomerReviewDate()))
				.setIncorrectAddress(source.getIncorrectAddress())
				.setIncorrectAddressUpdateDateTime(JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(source.getIncorrectAddressUpdateDateTime()))
				.setFreePpi(source.getFreePpi())
				.setSuppressedDateTime(JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(source.getSuppressedDateTime()))
				.setCreatedDateTime(JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(source.getCreatedDateTime()))
				.setUpdateDateTime(JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(source.getUpdateDateTime()))
				.setOtherNames(this.otherNamesDtoConverter.convert(source.getOtherNames()))
				.setAdditionalPreviousNames(this.previousNamesDtoConverter.convert(source.getAdditionalPreviousNames()))
				.setPreviousEmails(this.previousEmailDtoConverter.convert(source.getPreviousEmails()))
				.setFormalDebtArrangement(TriState.fromValue(source.getFormalDebtArrangement()))
				.setFormalDebtArrangementType(formalDebtArrangementType)
				.setIvaCompanyId(null != source.getIvaCompanyId() ? source.getIvaCompanyId() : 0)
				.setIvaReference(source.getIvaReference())
				.setInformalDebtArrangement(TriState.fromValue(source.getInformalDebtArrangement()))
				.setDebtManagementReference(source.getDebtManagementReference())
				.setDebtManagementCompanyId(null != source.getDebtManagementCompanyId() ? source.getDebtManagementCompanyId() : 0)
				.setClaimantUnpresentedCheque(this.claimantUnpresentedChequeDtoConverter.convert(source.getUnpresentedCheque()))
				.setClaimantExecutor(this.claimantExecutorDtoConverter.convert(source.getClaimantExecutor()))
				.setHasVulnerability(source.getHasVulnerability())
				.setVulnerabilityCategories(vulnerabilityCategories)
				.setCanStoreVulnerabilityDetail(VulnerableDetailTriState.fromValue(source.getCanStoreVulnerabilityDetail()))
				.setVulnerabilityDetail(StringUtils.defaultString(source.getVulnerabilityDetail()))
				.createClaimant();
	}
}
