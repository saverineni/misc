package com.leadx.claimant.callallocationservice;

import java.io.Serializable;

import org.joda.time.LocalDateTime;

public class ClaimantGroupAllocationDto implements Serializable {

	private static final long serialVersionUID = -3904280746491317050L;

		private int claimantId;
		private String callReason;
	 	private String callReasonGroup;
		private LocalDateTime callGroupAllocationDateTime;

	    public ClaimantGroupAllocationDto(Integer claimantId, String callReason, String callReasonGroup) {
	        this.claimantId = claimantId;
	        this.callReason = callReason;
	        this.callReasonGroup = callReasonGroup;
	        this.callGroupAllocationDateTime = null;
	    }

		public int getClaimantId() {
			return this.claimantId;
		}

		public void setClaimantID(int claimantId) {
			this.claimantId = claimantId;
		}

		public String getCallReason() {
			return this.callReason;
		}

		public void setCallReason(String callReason) {
			this.callReason = callReason;
		}

		public String getCallReasonGroup() {
			return this.callReasonGroup;
		}

		public void setCallReasonGroup(String callReasonGroup) {
			this.callReasonGroup = callReasonGroup;
		}

		public LocalDateTime getCallGroupAllocationDateTime() {
			return this.callGroupAllocationDateTime;
		}

}
