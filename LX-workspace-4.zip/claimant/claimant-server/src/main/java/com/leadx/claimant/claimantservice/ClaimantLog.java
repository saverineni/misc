package com.leadx.claimant.claimantservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Type;
import org.joda.time.LocalDateTime;

import com.leadx.hibernate.domain.BaseIntegerDomain;

@Entity
@Table(name = "claimant_log")
public class ClaimantLog extends BaseIntegerDomain {

	private static final long serialVersionUID = 7669126149485708562L;

	@Column(name = "FK_ClaimantID")
	private int claimantId;

	@Column(name = "FK_ScheduledTaskID")
	private int scheduledTaskId;

	@Type(type = "local_date_time_not_null")
	private LocalDateTime openedDateTime;

	@Type(type = "local_date_time_not_null")
	private LocalDateTime closedDateTime;

	@Column(name = "FK_UserID")
	private int userId;

	public ClaimantLog(final int claimantId, final int scheduledTaskId,  final LocalDateTime openedDateTime, final LocalDateTime closedDateTime, final int userId) {
		this.claimantId = claimantId;
		this.scheduledTaskId = scheduledTaskId;
		this.openedDateTime = openedDateTime;
		this.closedDateTime = closedDateTime;
		this.userId = userId;
	}

	public ClaimantLog() {
	}

	public boolean isLocked() {
		return this.openedDateTime != null & this.closedDateTime == null;
	}

	public int getClaimantId() {
		return this.claimantId;
	}

	public LocalDateTime getOpenedDateTime() {
		return this.openedDateTime;
	}

	public LocalDateTime getClosedDateTime() {
		return this.closedDateTime;
	}

	public int getUserId() {
		return this.userId;
	}

	public void setClosedDateTime(final LocalDateTime closedDateTime) {
		this.closedDateTime = closedDateTime;
	}

	public int getScheduledTaskId() {
		return this.scheduledTaskId;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

	@Override
	public boolean equals(final Object object) {
		return deepEquals(object);
	}
}
