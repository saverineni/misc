package com.leadx.claimant.claimantservice;

import static com.leadx.lib.utl.ObjectUtils.isNull;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.leadx.claimant.client.ClaimantContactPreferenceDto;

@Component("claimantContactPreferenceConverter")
public class ClaimantContactPreferenceConverter implements Converter<ClaimantContactPreference, ClaimantContactPreferenceDto> {
	
	@Override
	public ClaimantContactPreferenceDto convert(final ClaimantContactPreference source) {
		if (isNull(source)) {
			return null;
		}

		return new ClaimantContactPreferenceDto.Builder()
				.setId(source.getId())
				.setClaimantId(source.getClaimantId())
				.setTelephoneOptIn(source.getTelephoneOptIn())
				.setEmailOptIn(source.getEmailOptIn())
				.setSmsOptIn(source.getSmsOptIn())
				.setMarketingMailingOptIn(source.getMarketingMailingOptIn())
				.setCancellation(source.getCancellation())
				.setUserIdUpdated(source.getUserIdUpdated())
				.setVersion(source.getVersion())
				.createClaimantContactPreferenceDto();
	}
}
