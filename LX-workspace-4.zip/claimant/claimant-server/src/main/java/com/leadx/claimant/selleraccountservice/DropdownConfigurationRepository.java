package com.leadx.claimant.selleraccountservice;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
class DropdownConfigurationRepository {

	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	List<DropdownConfiguration> getDropdownItemsForField(final String fieldName) {
		return this.sessionFactory.getCurrentSession()
				.createQuery("FROM DropdownConfiguration dc WHERE dc.fieldName = :fieldName ORDER BY dc.fieldOrder ASC")
				.setParameter("fieldName", fieldName)
				.list();
	}
}