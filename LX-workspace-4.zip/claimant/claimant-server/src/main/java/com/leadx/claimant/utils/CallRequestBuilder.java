package com.leadx.claimant.utils;

import org.joda.time.LocalDateTime;

import com.leadx.services.claims.client.ClaimRequest;
import com.leadx.services.client.TcgCallRequest;
import com.leadx.services.client.validators.PhoneNumberMapper;
import com.leadx.services.client.validators.PhoneNumberMapper.PhoneNumbers;

public class CallRequestBuilder {
	
	private static final String PHONE_NUMBER_ORDERING = "home,mobile";
	
	public static TcgCallRequest createAssessmentCall(final int claimantId, final ClaimRequest claimRequest, final String assessmentCallGroup) {
		final ClaimRequest.Claimant claimant = claimRequest.getClaimant();
		return createAssessmentCall(assessmentCallGroup, claimantId, claimRequest.getLeadId(), claimant.getTitle(), claimant.getForename(), claimant.getSurname(),
				claimant.getHomeTelephone(), claimant.getMobileTelephone(), claimRequest.getAddress().getPostcode(), claimRequest.getAppointment().getRequestedDateTime());
	}
	
	public static TcgCallRequest createAssessmentCall(final String assessmentCallGroup, final int claimantId, final long leadId, final String title, final String forename, final String surname,
			final String homePhoneNumber, final String mobilePhoneNumber, final String postcode, final LocalDateTime scheduledDateTime) {

		final TcgCallRequest callRequest = TcgCallRequest.createProspectCall();
		callRequest.getCallReason().addGroup(assessmentCallGroup);
		callRequest.setClaimantId(claimantId);
		callRequest.setLeadId(leadId);
		callRequest.setTitle(title);
		callRequest.setForename(forename);
		callRequest.setSurname(surname);

		setPhoneNumbers(homePhoneNumber, mobilePhoneNumber, callRequest);

		if (null != postcode) {
			callRequest.setPostcode(postcode);
		}
		callRequest.setScheduledDateTime(scheduledDateTime);

		return callRequest;
	}

	public static TcgCallRequest createChaseCall(final String chaseCallGroup, final int claimantId, final long leadId, final String title, final String forename, final String surname,
													  final String homePhoneNumber, final String mobilePhoneNumber, final String postcode, final LocalDateTime scheduledDateTime) {

		final TcgCallRequest callRequest = TcgCallRequest.createChaseCall(chaseCallGroup);
		callRequest.setClaimantId(claimantId);
		callRequest.setLeadId(leadId);
		callRequest.setTitle(title);
		callRequest.setForename(forename);
		callRequest.setSurname(surname);

		setPhoneNumbers(homePhoneNumber, mobilePhoneNumber, callRequest);

		if (null != postcode) {
			callRequest.setPostcode(postcode);
		}
		callRequest.setScheduledDateTime(scheduledDateTime);

		return callRequest;
	}
	
	private static void setPhoneNumbers(final String homePhoneNumber, final String mobilePhoneNumber, final TcgCallRequest callRequest) {
		final PhoneNumbers phoneNumbers = PhoneNumberMapper.determinePhoneNumbers(homePhoneNumber, mobilePhoneNumber, PHONE_NUMBER_ORDERING);
		callRequest.setPhoneNumber1(phoneNumbers.phoneNumber1);
		callRequest.setPhoneNumber2(phoneNumbers.phoneNumber2);
	}
}
