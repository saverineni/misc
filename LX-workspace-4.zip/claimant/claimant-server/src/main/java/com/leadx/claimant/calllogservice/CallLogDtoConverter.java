package com.leadx.claimant.calllogservice;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.leadx.claimant.client.CallDisposition;
import com.leadx.claimant.client.CallLogDto;
import com.leadx.claimant.client.CallType;

@Component("callLogDtoConverter")
public class CallLogDtoConverter implements Converter<CallLogDto, CallLog>  {

	@Override
	public CallLog convert(final CallLogDto source) {
		final CallDisposition callDisposition = CallDisposition.getByName(source.getCallDisposition());
		final CallType callType = CallType.getByName(source.getCallType());
		return new CallLog(source.getClaimantId(), callDisposition, callType, source.getDiallerReferenceId(), source.getInbound(), source.getAgentUserId());
	}
}