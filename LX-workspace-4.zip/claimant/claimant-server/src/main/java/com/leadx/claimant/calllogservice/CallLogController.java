package com.leadx.claimant.calllogservice;

import java.util.List;

import javax.persistence.OptimisticLockException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.hibernate4.HibernateOptimisticLockingFailureException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.leadx.claimant.client.CallLogDto;
import com.leadx.lib.utl.json.JsonUtils;


/**
 * Webservice entry points for call log web service
 */
@RequestMapping(value = "/calllog")
@Controller
public class CallLogController {

	@Autowired
	private Converter<CallLogDto, CallLog> callLogDtoConverter;

	private static final Logger LOG = LoggerFactory.getLogger(CallLogController.class);

	@Autowired
	private CallLogService callLogService;

	@ResponseBody
	@RequestMapping(value = "/save",  method = RequestMethod.POST)
	public ResponseEntity<String> saveCallLog(@RequestBody final String logDto) {
		CallLog log = null;
		try {
			log = this.callLogDtoConverter.convert(JsonUtils.deserialize(logDto, CallLogDto.class));
			LOG.debug("Saving call log for call claimant id {} ", log.getClaimantId());
			if (this.callLogService.saveCallLog(log)) {
				return new ResponseEntity<>(HttpStatus.OK);
			}

			// This can happen on row already updated in the DB, eg double clicking on disposition in the client. Return
			// OK to avoid retrying as this means we have already inserted the row probably due to a double click
			LOG.info("Failed to save call log for call with claimant: {}.", log.getClaimantId());
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (final HibernateOptimisticLockingFailureException | OptimisticLockException e) {
			LOG.warn("saveCallLog failed for claimant: " + safeGetClaimantId(log) + " failed because of because of an optimistic locking exception.", e);
			throw e;
		} catch ( final Exception e ) {
			LOG.error("saveCallLog failed for claimant: " + safeGetClaimantId(log));
			throw e;
		}
	}

	@ResponseBody
	@RequestMapping(value = "/unique/{id}",  method = RequestMethod.GET)
	public List<CallLogDto> findCallLogsForClaimant(@PathVariable final int id) {
		LOG.debug("Finding call logs for claimant: {}", id);
		try {
			return this.callLogService.findCallLogsForClaimant(id);
		} catch ( final Exception e ) {
			LOG.error("Failed findCallLogsForClaimant, claimant id " + id, e);
			throw e;
		}
	}

	private static String safeGetClaimantId(final CallLog log) {
		if ( log == null ) {
			return "unknown";
		}
		return "" + log.getClaimantId();
	}
}