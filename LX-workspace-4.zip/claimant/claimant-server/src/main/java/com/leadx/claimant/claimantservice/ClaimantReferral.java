package com.leadx.claimant.claimantservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Type;
import org.joda.time.LocalDateTime;

import com.leadx.hibernate.domain.BaseIntegerDomain;
import com.leadx.lib.utl.JodaUtils;

@Entity
@Table(name = "claimant_referral")
public class ClaimantReferral extends BaseIntegerDomain {

	private static final long serialVersionUID = -4711902556894701263L;

	@Column(name = "FK_ProductTypeId")
	private int productTypeId;
	@Column(name = "FK_ClaimantID_Referrer")
	private int referrerClaimantId;
	@Column(name = "FK_ClaimantID_Referral")
	private int referralClaimantId;
	@Type(type = "local_date_time_not_null")
	private LocalDateTime createdDateTime;
	@Column(name = "FK_UserID_CreatedBy")
	private int createdByAgentId;
	private int diallerReferenceId;

	public ClaimantReferral() {
	}

	public ClaimantReferral(final int productTypeId, final int referrerClaimantId, final int referralClaimantId, final int createdByAgentId, final int diallerReferenceId) {
		this.productTypeId = productTypeId;
		this.referrerClaimantId = referrerClaimantId;
		this.referralClaimantId = referralClaimantId;
		this.createdDateTime = JodaUtils.newCurrentDateTime();
		this.createdByAgentId = createdByAgentId;
		this.diallerReferenceId = diallerReferenceId;
	}

	public int getProductTypeId() {
		return this.productTypeId;
	}

	public int getReferrerClaimantId() {
		return this.referrerClaimantId;
	}

	public int getReferralClaimantId() {
		return this.referralClaimantId;
	}

	public LocalDateTime getCreatedDateTime() {
		return this.createdDateTime;
	}

	public int getCreatedByAgentId() {
		return this.createdByAgentId;
	}

	public int getDiallerReferenceId() {
		return this.diallerReferenceId;
	}

	@Override
	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean equals(final Object object) {
		return deepEquals(object);
	}
}
