package com.leadx.claimant.claimantservice;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.leadx.claimant.client.ClaimantOtherNameDto;

@Component("claimantOtherNamesConverter")
public class ClaimantOtherNameConverter implements Converter<Set<ClaimantOtherName>, List<ClaimantOtherNameDto>> {

	@Override
	public List<ClaimantOtherNameDto> convert(Set<ClaimantOtherName> source) {
		if(source == null) {
			return Lists.newArrayList();
		}
		
		return source.stream().map(ClaimantOtherName::fromDto).collect(Collectors.toList());
	}
}
