package com.leadx.claimant.claimantservice;

import static com.leadx.claimant.utils.ObjectUtils.isNotNull;
import static java.util.stream.Collectors.toSet;

import java.util.Set;

import com.leadx.claimant.reference.VulnerableDetailTriState;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.google.common.collect.Sets;
import com.leadx.claimant.client.ClaimantDto;
import com.leadx.claimant.reference.FormalDebtArrangement;
import com.leadx.claimant.reference.TriState;
import com.leadx.lib.utl.JodaUtils;

@Component("claimantConverter")
public class ClaimantConverter implements Converter<Claimant, ClaimantDto>  {
	
	@Autowired
	private ClaimantOtherNameConverter otherNamesConverter;
	
	@Autowired
	private ClaimantAdditionalPreviousNameConverter previousNamesConverter;

	@Autowired
	private ClaimantPreviousEmailConverter previousEmailConverter;

	@Autowired
	private ClaimantUnpresentedChequeConverter claimantUnpresentedChequeConverter;

	@Autowired
	private ClaimantExecutorConverter claimantExecutorConverter;
	
	@Override
	public ClaimantDto convert(final Claimant source) {
		if ( source == null ) {
			return null;
		}

		final Set<String> vulnerabilityCategories = isNotNull(source.getVulnerabilityCategories()) ?
				source.getVulnerabilityCategories().stream().map(v -> v.toValue()).collect(toSet()) :
				Sets.newHashSet();

		final Set<String> formalDebtArrangementType = isNotNull(source.getFormalDebtArrangementType()) ?
				source.getFormalDebtArrangementType().stream().map(v -> v.toValue()).collect(toSet()) :
				Sets.newHashSet();

		return new ClaimantDto(source.getId(),
			source.getLeadId(),
			source.getSellerAccountId(),
			source.getSellerCompanyId(),
			source.getTitle(),
			source.getForename(),
			source.getMiddleName(),
			source.getSurname(),
			source.getPreviousSurname(),
			JodaUtils.localDateToBritishDateStampStringOrNull(source.getDob()),
			source.getAddressId(), 
			source.getHomeTelephone(),
			source.getMobileTelephone(),
			source.getAlternativeTelephone(),
			source.getWorkTelephone(),
			source.getEmail(),
			source.getNationalInsuranceNumber(),
			source.getLockedFromDialler(),
			JodaUtils.localDateTimeToBritishDateFormatOrNull(source.getLockedFromDiallerUpdateDateTime()),
			source.getLockedFromDiallerUpdateUserId(),
			source.getRightToBeForgotten(),
			JodaUtils.localDateToBritishDateStampStringOrNull(source.getRightToBeForgottenNewestClosedClaimDate()),
			source.getRightToBeForgottenUpdateUserId(),
			JodaUtils.localDateTimeToBritishDateFormatOrNull(source.getRightToBeForgottenUpdateDateTime()),
			source.getVulnerableCustomer(),
			JodaUtils.localDateTimeToBritishDateFormatOrNull(source.getVulnerableCustomerUpdateDateTime()),
			source.getVulnerableCustomerUpdateUserId(),
			JodaUtils.localDateToBritishDateStampStringOrNull(source.getVulnerableCustomerReviewDate()),
			source.getIncorrectAddress(),
			JodaUtils.localDateTimeToBritishDateFormatOrNull(source.getIncorrectAddressUpdateDateTime()),
			source.getFreePpi(),
			JodaUtils.localDateTimeToBritishDateFormatOrNull(source.getSuppressedDateTime()),
			JodaUtils.localDateTimeToBritishDateFormatOrNull(source.getCreatedDateTime()),
			JodaUtils.localDateTimeToBritishDateFormatOrNull(source.getTimestamp()),
			this.otherNamesConverter.convert(source.getClaimantOtherNames()),
			this.previousNamesConverter.convert(source.getClaimantAdditionalPreviousNames()),
			this.previousEmailConverter.convert(source.getPreviousEmails()),
			TriState.toValue(source.getFormalDebtArrangement()),
			formalDebtArrangementType,
			source.getIvaCompanyId(),
			source.getIvaReference(),
			TriState.toValue(source.getInformalDebtArrangement()),
			source.getDebtManagementCompanyId(),
			source.getDebtManagementReference(),
			this.claimantUnpresentedChequeConverter.convert(source.getClaimantUnpresentedCheque()),
			this.claimantExecutorConverter.convert(source.getClaimantExecutor()),
			source.getHasVulnerability(),
			vulnerabilityCategories,
			VulnerableDetailTriState.toValue(source.getCanStoreVulnerabilityDetail()),
			source.getVulnerabilityDetail()
		);

	}
}
