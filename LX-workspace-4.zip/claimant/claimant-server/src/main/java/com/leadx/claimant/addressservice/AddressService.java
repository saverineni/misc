package com.leadx.claimant.addressservice;

import java.util.Collection;
import java.util.List;

import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.leadx.claimant.changelogservice.ChangeItem;
import com.leadx.claimant.changelogservice.ChangeLogService;
import com.leadx.claimant.claimantservice.Claimant;
import com.leadx.claimant.claimantservice.ClaimantConverter;
import com.leadx.claimant.claimantservice.ClaimantService;
import com.leadx.claimant.logiclaimservice.LogiClaimService;

@Service
public class AddressService {
	private static final Logger LOG = LoggerFactory.getLogger(AddressService.class);

	public static final int MAX_DEPARTMENT_NAME_LENGTH = 60;
	public static final int MAX_ORGANISATION_NAME_LENGTH = 60;
	public static final int MAX_SUB_BUILDING_NAME_LENGTH = 30;
	public static final int MAX_BUILDING_NAME_LENGTH = 50;
	public static final int MAX_BUILDING_NUMBER_LENGTH = 20;
	public static final int MAX_DEPENDENT_THOROUGHFARE_LENGTH = 60;
	public static final int MAX_THOROUGHFARE_LENGTH = 80;
	public static final int MAX_DOUBLE_DEPENDENT_LOCALITY_LENGTH = 35;
	public static final int MAX_DEPENDENT_LOCALITY_LENGTH = 35;
	public static final int MAX_TOWN_LENGTH = 30;
	public static final int MAX_POSTCODE_LENGTH = 10;

	@Autowired
	private ChangeLogService changeLogService;

	@Autowired
	private AddressRepository addressRepository;

	@Autowired
	private ClaimantService claimantService;

	@Autowired
	private LogiClaimService logiClaimService;

	@Autowired
	private ClaimantConverter claimantConverter;


	@Transactional(readOnly = true)
	public Address getAddressById(final int id) {
		return this.addressRepository.getAddressById(id);
	}

	@Transactional(readOnly = true)
	public Collection<Address> getAddressesByIds(final Collection<Integer> ids) {
		return this.addressRepository.getAddressesByIds(ids);
	}


	@Transactional(readOnly = true)
	public Address getAddressForClaimant(final int claimantId) {
		final Claimant claimant = this.claimantService.getClaimantById(claimantId);

		if (claimant == null || claimant.getAddressId() == 0) {
			return null;
		}

		return getAddressById(claimant.getAddressId());
	}
	
	@Transactional(readOnly = true)
	public List<Address> getAllAddressesForClaimant(final int claimantId) {
		final List<Address> addresses = Lists.newArrayList();
		
		addresses.add(getAddressForClaimant(claimantId));
		
		for (final PreviousAddress previousAddress : getPreviousAddresses(claimantId)) {
			addresses.add(previousAddress.getAddress());
		}
		
		return addresses;
	}

	@Transactional(readOnly = true)
	public List<PreviousAddress> getDeletedPreviousAddresses(final int claimantId) {
		return this.addressRepository.getDeletedPreviousAddressesForClaimant(claimantId);
	}

	@Transactional(readOnly = true)
	public List<PreviousAddress> getPreviousAddresses(final int claimantId) {
		return this.addressRepository.getPreviousAddressesForClaimant(claimantId);
	}
	
	@Transactional(readOnly = true)
	public List<PreviousAddress> getOrderedPreviousAddressesForClaimant(final int claimantId) {
		return this.addressRepository.getOrderedPreviousAddressesForClaimant(claimantId);
	}

	@Transactional
	public void saveHouseMove(final int claimantId, final Address oldAddress, final Address newAddress) {
		final Address oldAddressFromDb = this.getAddressById(oldAddress.getId());

		saveHouseMoveWithOldAddress(claimantId, oldAddressFromDb, newAddress);
	}

	@Transactional
	public void saveHouseMove(final int claimantId, final Address newAddress) {
		final Address oldAddressFromDb = this.getAddressForClaimant(claimantId);

		saveHouseMoveWithOldAddress(claimantId, oldAddressFromDb, newAddress);
	}

	private void saveHouseMoveWithOldAddress(final int claimantId, final Address oldAddress, final Address newAddress) {
		final PreviousAddress previousAddress = new PreviousAddress(claimantId, oldAddress, true);
		this.addressRepository.savePreviousAddress(previousAddress);
		this.addressRepository.saveAddress(newAddress, true);

		this.claimantService.updateAddressId(claimantId, newAddress);

		LOG.debug("Sending the claimant details to Logiclaim adaptor queue");
		Claimant claimant = this.claimantService.getClaimantById(claimantId);
		this.logiClaimService.sendToLogiclaim(this.claimantConverter.convert(claimant));
	}

	@Transactional
	public void savePreviousAddress(final int claimantId, final Address address) {
		savePreviousAddress(claimantId, address, true);
	}

	@Transactional
	public void savePreviousAddress(final int claimantId, final Address address, final boolean pafValidated) {
		this.saveAddress(0, address, pafValidated);
		final PreviousAddress previousAddress = new PreviousAddress(claimantId, address, false);
		this.addressRepository.savePreviousAddress(previousAddress);

		LOG.debug("Sending the claimant details to Logiclaim adaptor queue");
		Claimant claimant = this.claimantService.getClaimantById(claimantId);
		this.logiClaimService.sendToLogiclaim(this.claimantConverter.convert(claimant));
	}

	@Transactional
	public void deletePreviousAddress(final int previousAddressId, final int userId) {
		final PreviousAddress previousAddress = this.addressRepository.getPreviousAddress(previousAddressId);
		previousAddress.setDeletedDateTime(new LocalDateTime());
		previousAddress.setFkUserIdDeletedBy(userId);
		this.addressRepository.updatePreviousAddress(previousAddress);

		LOG.debug("Sending the claimant details to Logiclaim adaptor queue");
		Claimant claimant = this.claimantService.getClaimantById(previousAddress.getClaimantId());
		this.logiClaimService.sendToLogiclaim(this.claimantConverter.convert(claimant));

	}

	@Transactional
	public void saveAddress(final int claimantId, final Address address, final boolean markPafValidated) {
		this.addressRepository.saveAddress(address, markPafValidated);

		if (claimantId != 0) {
			this.claimantService.updateAddressId(claimantId, address);

			LOG.debug("Sending the claimant details to Logiclaim adaptor queue");
			Claimant claimant = this.claimantService.getClaimantById(claimantId);
			this.logiClaimService.sendToLogiclaim(this.claimantConverter.convert(claimant));
		}
	}

	@Transactional
	public void saveAddress(final Address address) {
		this.addressRepository.saveAddress(address, false);
	}

	/** Saves the new address and returns the list of change items generated by this. Returned values are only used for testing. */
	@Transactional
	public List<ChangeItem> updateAddress(final int claimantId, final Address address, final int userId, final boolean markPafValidated) {
		final Address oldAddress = this.addressRepository.getAddressById(address.getId());
		this.addressRepository.evict(oldAddress);

		address.setVersion(oldAddress.getVersion());

		if (!markPafValidated) {
			address.setPafValidatedDate(oldAddress.getPafValidatedDate());
		}
		
		this.addressRepository.updateAddress(address, markPafValidated);

		LOG.debug("Sending the claimant details to Logiclaim adaptor queue");
		Claimant claimant = this.claimantService.getClaimantById(claimantId);
		this.logiClaimService.sendToLogiclaim(this.claimantConverter.convert(claimant));

		return this.changeLogService.saveChangeValues(claimantId, oldAddress, address, userId);
	}

	@Transactional
	public void savePreviousAddressInConfinement(final int claimantId, final Address address) {
		this.saveAddressInConfinement(0, address, true);
		final PreviousAddress previousAddress = new PreviousAddress(claimantId, address, false);
		this.addressRepository.savePreviousAddress(previousAddress);
	}

	@Transactional
	public void deletePreviousAddressInConfinement(final int previousAddressId, final int userId) {
		final PreviousAddress previousAddress = this.addressRepository.getPreviousAddress(previousAddressId);
		previousAddress.setDeletedDateTime(new LocalDateTime());
		previousAddress.setFkUserIdDeletedBy(userId);
		this.addressRepository.updatePreviousAddress(previousAddress);
	}

	@Transactional
	public void saveAddressInConfinement(final int claimantId, final Address address, final boolean markPafValidated) {
		this.addressRepository.saveAddress(address, markPafValidated);

		if (claimantId != 0) {
			this.claimantService.updateAddressId(claimantId, address);
		}
	}

	/** Saves the new address and returns the list of change items generated by this. Returned values are only used for testing. */
	@Transactional
	public List<ChangeItem> updateAddressInConfinement(final int claimantId, final Address address, final int userId) {
		final Address oldAddress = this.addressRepository.getAddressById(address.getId());
		this.addressRepository.evict(oldAddress);

		address.setVersion(oldAddress.getVersion());

		if (null == oldAddress.getPafValidatedDate()) {
			address.setPafValidatedDate(LocalDate.now());
		} else {
			address.setPafValidatedDate(oldAddress.getPafValidatedDate());
		}

		this.addressRepository.updateAddress(address, false);
		return this.changeLogService.saveChangeValues(claimantId, oldAddress, address, userId);
	}
}
