package com.leadx.claimant.lead;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.leadx.claimant.client.ClaimantLead;
import com.leadx.claimant.client.MethodOfContact;
import com.leadx.claimant.selleraccountservice.SellerAccount;
import com.leadx.claimant.selleraccountservice.SellerAccountService;
import com.leadx.claimant.utils.CallRequestBuilder;
import com.leadx.services.claims.client.ClaimRequest.Claimant;
import com.leadx.services.client.TcgCallRequest;
import com.leadx.services.client.service.TelephonyService;

@Component
public class CreateAssessmentCallProcessor {
	
	@Autowired
	private SellerAccountService sellerAccountService;
	
	@Autowired
	private TelephonyService telephonyService;
	
	public ClaimantLead createAssessmentCall(final ClaimantLead claimantLead) {
		final Claimant claimant = claimantLead.getClaimRequest().getClaimant();
		final SellerAccount sellerAccount = this.sellerAccountService.getByAccountId(claimantLead.getClaimRequest().getSellerAccountId());
		final MethodOfContact methodOfContact = sellerAccount.getMethodOfContact();
		if (MethodOfContact.telephone.equals(methodOfContact) && (StringUtils.isNotBlank(claimant.getMobileTelephone()) || StringUtils.isNotBlank(claimant.getHomeTelephone()))) {
			final String assessmentCallGroup = null != sellerAccount
					? sellerAccount.getAssessmentCallReasonGroup()
					: "";
			
			final TcgCallRequest request = CallRequestBuilder.createAssessmentCall(claimantLead.getClaimantId(), claimantLead.getClaimRequest(), assessmentCallGroup);
			
			this.telephonyService.scheduleCall(request);
		}
		
		return claimantLead;
	}


}
