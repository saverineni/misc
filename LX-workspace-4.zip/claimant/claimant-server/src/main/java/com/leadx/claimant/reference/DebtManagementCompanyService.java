package com.leadx.claimant.reference;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service("debtManagementCompanyService")
public class DebtManagementCompanyService{

	@Autowired
	private DebtManagementCompanyRepository debtManagementCompanyRepository;

	private static final Logger LOG = LoggerFactory.getLogger(DebtManagementCompanyService.class);

	@Transactional(readOnly=true)
	public List<DebtManagementCompany> getDebtManagementCompanies() {
		LOG.info("Getting Debt Management companies");
		return this.debtManagementCompanyRepository.getDebtManagementCompanies();
	}

}