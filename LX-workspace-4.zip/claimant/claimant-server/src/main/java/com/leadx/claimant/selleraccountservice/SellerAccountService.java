package com.leadx.claimant.selleraccountservice;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("sellerAccountService")
public class SellerAccountService {

	@Autowired
	private SellerAccountRepository sellerAccountRepository;

	@Autowired
	private ProductTypeRepository productTypeRepository;

	@Autowired
	private DropdownConfigurationRepository dropdownConfigurationRepository;

	@Transactional
	public void create(final SellerAccount sellerAccount) {
		this.sellerAccountRepository.create(sellerAccount);
	}

	@Transactional
	public void update(final SellerAccount sellerAccount) {
		final SellerAccount oldSellerAccount = this.sellerAccountRepository.getByAccountId(sellerAccount.getAccountId());
		this.sellerAccountRepository.evict(oldSellerAccount);
		sellerAccount.setId(oldSellerAccount.getId());
		sellerAccount.setVersion(oldSellerAccount.getVersion());
		this.sellerAccountRepository.update(sellerAccount);
	}

	@Transactional
	public SellerAccount getByAccountId(final int id) {
		return this.sellerAccountRepository.getByAccountId(id);
	}

	@Transactional
	public Collection<SellerAccount> getByAccountIds(final Collection<Integer> ids) {
		return this.sellerAccountRepository.getByAccountIds(ids);
	}

	@Transactional
	public List<SellerAccount> getAll() {
		return this.sellerAccountRepository.getAll();
	}

	// A sourced seller account is one with the description set.
	@Transactional
	public List<SellerAccount> getSourcedSellerAccounts() {
		return this.sellerAccountRepository.getSourcedSellerAccounts();
	}

	// DropdownConfiguration
	@Transactional
	public List<DropdownConfiguration> getDropdownItemsForField(final String fieldName) {
		return this.dropdownConfigurationRepository.getDropdownItemsForField(fieldName);
	}

	@Transactional
	public List<ProductType> getProductTypes() {
		return this.productTypeRepository.getAll();
	}

	@Transactional
	public boolean isFreePpi(int sellerAccountId){
		return this.sellerAccountRepository.isFreePpi(sellerAccountId);
	}

}