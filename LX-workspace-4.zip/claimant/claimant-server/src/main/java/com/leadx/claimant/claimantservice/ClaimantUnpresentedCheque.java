package com.leadx.claimant.claimantservice;

import com.leadx.claimant.client.ClaimantUnpresentedChequeDto;
import com.leadx.hibernate.domain.BaseIntegerDomain;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Type;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;

import static com.leadx.lib.utl.JodaUtils.localDateToBritishDateStampStringOrNull;

@Entity
@Table(name = "claimant_unpresented_cheque")
public class ClaimantUnpresentedCheque extends BaseIntegerDomain {

	@Column(name = "FK_ClaimantID")
	private int claimantId;

	@Type(type = "local_date_not_null")
	private LocalDate dateChequeIssued;

	private BigDecimal amount;

	@Type(type = "local_date_time_not_null")
	@Column(updatable = false, insertable = false)
	private LocalDateTime timestamp;



	public ClaimantUnpresentedCheque() {

	}

	public ClaimantUnpresentedCheque(final Integer id, final int claimantId, final LocalDate dateChequeIssued, final BigDecimal amount, final LocalDateTime timestamp) {
		setId(id);
		this.claimantId = claimantId;
		this.dateChequeIssued = dateChequeIssued;
		this.amount = amount;
		this.timestamp = timestamp;
	}

	public int getClaimantId() {
		return claimantId;
	}

	public void setClaimantId(int claimantId) {
		this.claimantId = claimantId;
	}

	public LocalDate getDateChequeIssued() {
		return dateChequeIssued;
	}

	public void setDateChequeIssued(LocalDate dateChequeIssued) {
		this.dateChequeIssued = dateChequeIssued;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public boolean equals(final Object obj) {
		return deepEquals(obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}
}
