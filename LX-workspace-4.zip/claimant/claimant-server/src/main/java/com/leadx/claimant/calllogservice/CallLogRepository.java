package com.leadx.claimant.calllogservice;

import java.sql.Time;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.leadx.claimant.client.CallType;
import com.leadx.lib.utl.JodaUtils;

@Repository("callLogRepository")
public class CallLogRepository{

	private final SessionFactory sessionFactory;

	@Autowired
	public CallLogRepository(final SessionFactory claimSessionFactory) {
		this.sessionFactory = claimSessionFactory;
	}

	void saveCallLog(final CallLog callLog) {
		this.sessionFactory.getCurrentSession()
			.saveOrUpdate(callLog);
	}

	boolean isDiallerReferenceUnique(final int diallerReferenceId, final CallType callType) {

		final Long count = (Long) this.sessionFactory.getCurrentSession()
			.createQuery("select count(*) from CallLog cl where cl.diallerReferenceId = :diallerReferenceId and cl.callType = :callType")
			.setParameter("diallerReferenceId", diallerReferenceId)
			.setParameter("callType", callType)
			.uniqueResult();

		return count == 0;
	}

	@SuppressWarnings("unchecked")
	List<CallLog> findCallLogsForClaimant(final int claimantId) {
		return this.sessionFactory.getCurrentSession()
			.createSQLQuery(
						  " SELECT cl.*"
						+ " FROM `claimant`.`call_log` cl "
						+ " INNER JOIN `claimant`.`claimant_log` cl2 "
						+ " 	ON cl.`FK_ClaimantID` = cl2.`FK_ClaimantID` "
						+ " 	AND cl.`FK_UserID_Agent` = cl2.`FK_UserID` "
						+ " 	AND cl2.`ClosedDateTime` BETWEEN DATE_SUB( cl.`DispositionDateTime`, INTERVAL 10 SECOND ) AND DATE_ADD( cl.`DispositionDateTime`, INTERVAL 10 SECOND ) "
						+ " WHERE cl.`FK_ClaimantID` = :claimantId " + " 	AND cl.`DispositionDateTime` > DATE_SUB( :currentDate, INTERVAL 1 MONTH ) "
						+ " ORDER BY cl.`DispositionDateTime` DESC ")
			.addEntity("call_log", CallLog.class)
			.setParameter("currentDate", JodaUtils.newCurrentDateString())
			.setParameter("claimantId", claimantId)
			.list();
	}

	@SuppressWarnings("unchecked")
	List<Time> getCallDurationForClaimant(final int claimantId) {
		return this.sessionFactory.getCurrentSession()
			.createSQLQuery(
					    " SELECT TIMEDIFF(cl2.`closedDateTime`, cl2.`OpenedDateTime`) "
					  + " FROM `claimant`.`call_log` cl "
					  + " INNER JOIN `claimant`.`claimant_log` cl2 "
					  + " 	ON cl.`FK_ClaimantID` = cl2.`FK_ClaimantID` "
					  + " 	AND cl.`FK_UserID_Agent` = cl2.`FK_UserID` "
					  + " 	AND cl2.`ClosedDateTime` BETWEEN DATE_SUB( cl.`DispositionDateTime`, INTERVAL 10 SECOND ) AND DATE_ADD( cl.`DispositionDateTime`, INTERVAL 10 SECOND ) "
					  + " WHERE cl.`FK_ClaimantID` = :claimantId " + " 	AND cl.`DispositionDateTime` > DATE_SUB( :currentDate, INTERVAL 1 MONTH ) "
					  + " ORDER BY cl.`DispositionDateTime` DESC ")
			.setParameter("currentDate", JodaUtils.newCurrentDateString())
			.setParameter("claimantId", claimantId)
			.list();
	}
}