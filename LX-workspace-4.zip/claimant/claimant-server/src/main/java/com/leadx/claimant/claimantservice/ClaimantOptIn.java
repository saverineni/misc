package com.leadx.claimant.claimantservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Type;
import org.joda.time.LocalDateTime;

import com.leadx.hibernate.domain.BaseIntegerDomain;
import com.leadx.lib.utl.JodaUtils;

@Entity
@Table(name = "claimant_opt_in")
public class ClaimantOptIn extends BaseIntegerDomain {

	private static final long serialVersionUID = 5487619751208946137L;

	@Column(name = "FK_ClaimantID")
	private int claimantId;

	private boolean optIn;

	// OptIn time gets set regardless of whether optin in or out
	@Type(type = "local_date_time_not_null")
	private LocalDateTime optInDateTime;

	public ClaimantOptIn() {
	}

	public ClaimantOptIn(final int claimantId, final boolean optIn) {
		this.claimantId = claimantId;
		this.optIn = optIn;
		this.optInDateTime = JodaUtils.newCurrentDateTime();
	}

	public int getClaimantId() {
		return this.claimantId;
	}

	public LocalDateTime getOptInDateTime() {
		return this.optInDateTime;
	}

	public boolean getOptIn() {
		return this.optIn;
	}

	public void setOptIn(final boolean optIn) {
		this.optIn = optIn;
		this.optInDateTime = JodaUtils.newCurrentDateTime();
	}

	@Override
	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

	@Override
	public boolean equals(final Object object) {
		return this.deepEquals(object);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
