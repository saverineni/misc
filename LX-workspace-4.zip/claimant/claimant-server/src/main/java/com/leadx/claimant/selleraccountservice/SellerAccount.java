package com.leadx.claimant.selleraccountservice;

import java.util.List;

import javax.persistence.*;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.google.common.collect.Lists;
import com.leadx.claimant.client.ClaimantBrandingDto;
import com.leadx.claimant.client.MethodOfContact;
import com.leadx.hibernate.domain.BaseIntegerDomain;

@Entity
@Table(name = "seller_account")
@SuppressWarnings("serial")
@SecondaryTable(name = "seller_account_inbound_number")
public class SellerAccount extends BaseIntegerDomain {

	@Column(name = "FK_AccountID")
	protected Integer accountId;

	protected String gpSellerAccount;
	protected String name;
	protected String displayName;
	protected String sourceDescription;
	@Enumerated(EnumType.STRING)
	protected MethodOfContact methodOfContact;
	protected String applicationLogo;
	protected String packType;
	protected boolean distributeAppointmentReminder;
	protected String assessmentCallReasonGroup;
	protected String assessmentInitialSmsMessageScript;
	protected String assessmentInitialEmailMessageScript;
	protected String emailIconImageName;
	protected boolean freePpi;

	@ElementCollection(fetch = FetchType.EAGER)
	@JoinTable(name = "seller_account_inbound_number", joinColumns = @JoinColumn(name = "FK_AccountID", referencedColumnName = "FK_AccountID"))
	@Column(name = "DDI", table = "seller_account_inbound_number")
	private List<String> inboundNumbers = Lists.newArrayList();

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_ProductTypeID")
	private ProductType productType;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_LeadTypeID")
	private LeadType leadType;

	public SellerAccount() {}

	public SellerAccount(final Integer accountID, final String gpSellerAccount, final String name, final String displayName, final String sourceDescription,
						 MethodOfContact methodOfContact, final String applicationLogo, final String packType, final Boolean distributeAppointmentReminder, final String assessmentCallReasonGroup,
						 final String assessmentInitialSmsMessageScript, final String assessmentInitialEmailMessageScript, final String emailIconImageName, final boolean freePpi) {
		this.accountId = accountID;
		this.gpSellerAccount = gpSellerAccount;
		this.name = name;
		this.displayName = displayName;
		this.sourceDescription = sourceDescription;
		this.methodOfContact = methodOfContact;
		this.applicationLogo = applicationLogo;
		this.packType = packType;
		this.distributeAppointmentReminder = distributeAppointmentReminder;
		this.assessmentCallReasonGroup = assessmentCallReasonGroup;
		this.assessmentInitialSmsMessageScript = assessmentInitialSmsMessageScript;
		this.assessmentInitialEmailMessageScript = assessmentInitialEmailMessageScript;
		this.emailIconImageName = emailIconImageName;
		this.freePpi = freePpi;
	}

	public ProductType getProductType() {
		return this.productType;
	}

	public void setProductType(ProductType productType) {
		this.productType = productType;
	}

	public Integer getAccountId() {
		return this.accountId;
	}

	public void setAccountId(final Integer id) {
		this.accountId = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public String getGpSellerAccount() {
		return this.gpSellerAccount;
	}

	public void setGpSellerAccount(final String gpSellerAccount) {
		this.gpSellerAccount = gpSellerAccount;
	}

	public String getDisplayName() {
		return this.displayName;
	}

	public void setDisplayName(final String displayName) {
		this.displayName = displayName;
	}

	public String getSourceDescription() {
		return this.sourceDescription;
	}

	public void setSourceDescription(final String sourceDescription) {
		this.sourceDescription = sourceDescription;
	}

	public String getApplicationLogo() {
		return this.applicationLogo;
	}

	public void setApplicationLogo(final String applicationLogo) {
		this.applicationLogo = applicationLogo;
	}

	public String getPackType() {
		return this.packType;
	}

	public void setPackType(final String packType) {
		this.packType = packType;
	}

	public boolean getDistributeAppointmentReminder() {
		return this.distributeAppointmentReminder;
	}

	public void setDistributeAppointmentReminder(final boolean distributeAppointmentReminder) {
		this.distributeAppointmentReminder = distributeAppointmentReminder;
	}

	public String getAssessmentCallReasonGroup() {
		return this.assessmentCallReasonGroup;
	}

	public void setAssessmentCallReasonGroup(final String assessmentCallReasonGroup) {
		this.assessmentCallReasonGroup = assessmentCallReasonGroup;
	}

	public String getAssessmentInitialSmsMessageScript() {
		return this.assessmentInitialSmsMessageScript;
	}

	public void setAssessmentInitialSmsMessageScript(final String assessmentInitialSmsMessageScript) {
		this.assessmentInitialSmsMessageScript = assessmentInitialSmsMessageScript;
	}

	public String getAssessmentInitialEmailMessageScript() {
		return this.assessmentInitialEmailMessageScript;
	}

	public void setAssessmentInitialEmailMessageScript(final String assessmentInitialEmailMessageScript) {
		this.assessmentInitialEmailMessageScript = assessmentInitialEmailMessageScript;
	}

	public String getEmailIconImageName() {
		return this.emailIconImageName;
	}

	public void setEmailIconImageName(final String emailIconImageName) {
		this.emailIconImageName = emailIconImageName;
	}

	public List<String> getInboundNumbers() {
		return this.inboundNumbers;
	}

	public void setInboundNumbers(final List<String> inboundNumbers) {
		this.inboundNumbers = inboundNumbers;
	}

	public boolean getFreePpi() {
		return this.freePpi;
	}

	public void setFreePpi(boolean freePpi) {
		this.freePpi = freePpi;
	}

	public LeadType getLeadType() {
		return this.leadType;
	}

	public void setLeadType(LeadType productType) {
		this.leadType = leadType;
	}

	public MethodOfContact getMethodOfContact() {
		return this.methodOfContact;
	}

	public void setMethodOfContact(MethodOfContact methodOfContact) {
		this.methodOfContact = methodOfContact;
	}

	public boolean isPost() {
		return MethodOfContact.post.equals(this.methodOfContact);
	}

	public boolean isEmail() {
		return MethodOfContact.email.equals(this.methodOfContact);
	}

	public static ClaimantBrandingDto toClaimantBrandingDto(final SellerAccount sellerAccount) {
		if (null == sellerAccount) {
			return null;
		}

		final ClaimantBrandingDto branding = new ClaimantBrandingDto();
		branding.setLogo(sellerAccount.getApplicationLogo());
		branding.setName(sellerAccount.getDisplayName());
		branding.setSellerAccountId(sellerAccount.getAccountId());
		return branding;
	}

	@Override
	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

	@Override
	public boolean equals(final Object other) {
		return deepEquals(other);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
