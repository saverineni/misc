package com.leadx.claimant.changelogservice;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

import com.leadx.hibernate.domain.BaseIntegerDomain;

@Entity
@Table(name = "change_item")
public class ChangeItem extends BaseIntegerDomain {

	private static final long serialVersionUID = 122094999303603330L;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_ChangeGroupID", nullable = false)
	@Cascade(CascadeType.SAVE_UPDATE)
	private ChangeGroup changeGroup;
	private String field;
	private String oldString;
	private String newString;

	public ChangeItem() {}

	public ChangeItem(final ChangeGroup changeGroup, final String field,final String oldString, final String newString) {
		this.changeGroup = changeGroup;
		this.field = field;
		this.oldString = oldString;
		this.newString = newString;
	}

	public ChangeGroup getChangeGroup() {
		return this.changeGroup;
	}

	public String getField() {
		return this.field;
	}

	public String getOldString() {
		return this.oldString;
	}

	public String getNewString() {
		return this.newString;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean deepEquals(final Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}

}
