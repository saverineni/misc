package com.leadx.claimant.reference;

import com.leadx.claimant.client.reference.IvaCompanyDto;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.google.common.collect.Lists.newArrayList;
import static com.leadx.lib.utl.ObjectUtils.isNull;
import static java.util.stream.Collectors.toList;

@Component("ivaCompanyConverter")
public class IvaCompanyConverter implements Converter<IvaCompany, IvaCompanyDto> {

	@Override
	public IvaCompanyDto convert(final IvaCompany source) {
		if (isNull(source)) {
			return null;
		}

		final IvaCompanyDto dto = new IvaCompanyDto(
				source.getId(),
				source.getName(),
				source.getDepartmentName(),
				source.getOrganisationName(),
				source.getSubBuildingName(),
				source.getBuildingName(),
				source.getBuildingNumber(),
				source.getDependentThoroughfare(),
				source.getThoroughfare(),
				source.getDoubleDependentLocality(),
				source.getDependentLocality(),
				source.getTown(),
				source.getCounty(),
				source.getPostcode());
		return dto;
	}

	public List<IvaCompanyDto> convertList(List<IvaCompany> source){
		if (isNull(source)) {
			return newArrayList();
		}

		return source.stream()
				.map(this::convert)
				.collect(toList());
	}
}