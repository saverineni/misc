package com.leadx.claimant.lead;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Logs the stack trace of caught exception at error level. Used because can't get the camel stack trace logging working.
 */
@Component
public class StackTraceLogger implements Processor {
	private static final Logger LOG = LoggerFactory.getLogger(StackTraceLogger.class);

	@Override
	public void process(final Exchange exchange) throws Exception {
		final Exception e = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
		LOG.error(getStackTrace(e));
	}

	private static String getStackTrace(final Exception ex) {
		final StringWriter sw = new StringWriter();
		final PrintWriter pw = new PrintWriter(sw);
		ex.printStackTrace(pw);
		return sw.toString();
	}
}
