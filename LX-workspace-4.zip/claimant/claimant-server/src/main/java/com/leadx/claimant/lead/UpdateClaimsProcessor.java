package com.leadx.claimant.lead;

import com.leadx.claimant.client.ClaimantLead;
import com.leadx.claimant.client.MethodOfContact;
import com.leadx.claimant.selleraccountservice.SellerAccount;
import com.leadx.claimant.selleraccountservice.SellerAccountService;
import com.leadx.lib.utl.json.JsonUtils;
import com.leadx.services.claims.client.ClaimRequest;
import org.apache.camel.ProducerTemplate;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UpdateClaimsProcessor {
	
	@Autowired
	private ProducerTemplate producerTemplate;

	protected static final String CLAIMANT_TCG_UPDATE_CLAIMS_QUEUE = "jms:claimant-tcg-update-leads-with-claims";

	public ClaimantLead updateClaims(final ClaimantLead claimantLead) {
		final ClaimRequest claimRequest = claimantLead.getClaimRequest();

		if(!claimRequest.getAgreements().isEmpty() ) {
			ClaimRequest.Agreement agreement = claimRequest.getAgreements().get(0);
			if (agreement.getClaimId() != 0){
				this.producerTemplate.sendBody(CLAIMANT_TCG_UPDATE_CLAIMS_QUEUE, JsonUtils.serialize(claimantLead, false));
			}
		}

		return claimantLead;
	}


}
