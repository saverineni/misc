package com.leadx.claimant.claimantservice;

import static com.leadx.lib.utl.JodaUtils.timestampStringToLocalDateTimeOrNull;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import javax.persistence.OptimisticLockException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.orm.hibernate4.HibernateOptimisticLockingFailureException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.leadx.claimant.addressservice.Address;
import com.leadx.claimant.client.*;
import com.leadx.lib.utl.JodaUtils;

/**
 * Webservice entry points for claimant web service
 */
@Controller
public class ClaimantController {
	private static final Logger LOG = LoggerFactory.getLogger(ClaimantController.class);

	@Autowired
	private ClaimantService claimantService;

	@Autowired
	private Converter<ClaimantDto, Claimant> claimantDtoConverter;

	@Autowired
	private Converter<Claimant, ClaimantDto> claimantConverter;

	@Autowired
	private Converter<Address, AddressDto> addressConverter;

	@Autowired
	private Converter<ClaimantReferral, ClaimantReferralDto> claimantReferralConverter;

	@Autowired
	private Converter<Collection<ClaimantReferral>, Collection<ClaimantReferralDto>> claimantReferralsConverter;
	
	@Autowired
	private Converter<ClaimantInteraction, ClaimantInteractionDto> claimantInteractionConverter;

	@Autowired
	private Converter<ClaimantExecutorDto, ClaimantExecutor> claimantExecutorDtoConverter;

	@ResponseBody
	@RequestMapping(value = "/claimant/{claimantId}", method = RequestMethod.GET)
	public ClaimantDto getClaimantById(@PathVariable final int claimantId) {
		LOG.debug("getClaimantById: {}", claimantId);
		try {
			final Claimant claimant = this.claimantService.getClaimantById(claimantId);
			return this.claimantConverter.convert(claimant);
		} catch ( final Exception e ) {
			LOG.error("getClaimantById id " + claimantId + " failed", e);
			throw e;
		}
	}

	@ResponseBody
	@RequestMapping(value = "/claimant/ids/{csvIds}/address", method = RequestMethod.GET)
	public List<ClaimantAndAddressDto> getClaimantsAndAddressByIds(@PathVariable final String csvIds) {
		LOG.debug("getClaimantsAndAddressByIds {}", csvIds);
		try {
			final String[] idsStr = csvIds.split(",");
			final ImmutableList.Builder<Integer> ids = new ImmutableList.Builder<>();
			for ( final String idStr: idsStr ) {
				ids.add(Integer.parseInt(idStr.trim()));  // can throw exception back to call if not an integer
			}

			final List<ClaimantAndAddress> claimantsWithAddress = this.claimantService.getClaimantsAndAddressByIds(ids.build());

			return toClaimantAndAddressDtos(claimantsWithAddress);
		} catch ( final Exception e ) {
			LOG.error("getClaimantsAndAddressByIds ids " + csvIds + " failed", e);
			throw e;
		}
	}

	@ResponseBody
	@RequestMapping(value = "/claimant/ids/{csvIds}", method = RequestMethod.GET)
	public Collection<ClaimantDto> getClaimantsByIds(@PathVariable final String csvIds) {
		LOG.debug("getClaimantsByIds {}", csvIds);

		try {
			final String[] idsStr = csvIds.split(",");
			final ImmutableList.Builder<Integer> ids = new ImmutableList.Builder<>();
			for ( final String idStr: idsStr ) {
				ids.add(Integer.parseInt(idStr.trim()));  // can throw exception back to call if not an integer
			}

			final Collection<Claimant> claimants = this.claimantService.getClaimantsByIds(ids.build());
			return toClaimantDtos(claimants);
		} catch ( final Exception e ) {
			LOG.error("getClaimantsByIds ids " + csvIds + " failed", e);
			throw e;
		}
	}


	@ResponseBody
	@RequestMapping(value = "/claimant/surname", method = RequestMethod.GET)
	public List<ClaimantAndAddressDto> searchForClaimantBySurname() {
		try {
			final List<ClaimantAndAddress> claimantsWithAddress = this.claimantService.searchForClaimantBySurname("");

			return toClaimantAndAddressDtos(claimantsWithAddress);
		} catch ( final Exception e ) {
			LOG.error("searchForClaimantBySurname failed", e);
			throw e;
		}
	}

	@ResponseBody
	@RequestMapping(value = "/claimant/surname/{surname}", method = RequestMethod.GET)
	public List<ClaimantAndAddressDto> searchForClaimantBySurname(@PathVariable final String surname) {
		try {
			final List<ClaimantAndAddress> claimantsWithAddress = this.claimantService.searchForClaimantBySurname(surname);

			return toClaimantAndAddressDtos(claimantsWithAddress);
		} catch ( final Exception e ) {
			LOG.error("searchForClaimantBySurname " + surname + " failed", e);
			throw e;
		}
	}

	@ResponseBody
	@RequestMapping(value = "/claimant/create", method = RequestMethod.POST)
	public ClaimantDto createClaimant(@RequestBody final ClaimantDto claimantDto) {
		LOG.debug("createClaimant");

		try {
			final Claimant claimant = this.claimantDtoConverter.convert(claimantDto);

			final Claimant createdClaimant = this.claimantService.createClaimant(claimant);

			return this.claimantConverter.convert(createdClaimant);
		} catch (final HibernateOptimisticLockingFailureException|OptimisticLockException e) {
			LOG.warn("createClaimant failed because of an optimistic locking exception.", e);
			throw e;
		} catch ( final Exception e ) {
			LOG.error("createClaimant failed.", e);
			throw e;
		}
	}

	@ResponseBody
	@RequestMapping(value = "/claimant/update/userId/{userId}", method = RequestMethod.POST)
	public void updateClaimant(@RequestBody final ClaimantDto claimantDto, @PathVariable final int userId) {
		LOG.debug("updateClaimant id {}", claimantDto.getId());

		try {
			final Claimant claimant = this.claimantDtoConverter.convert(claimantDto);

			this.claimantService.updateClaimant(claimant, userId);
		} catch (final HibernateOptimisticLockingFailureException | OptimisticLockException e) {
			LOG.warn("updateClaimant id " + claimantDto.getId() + " failed because of an optimistic locking exception.", e);
			throw e;
		} catch (final Exception e) {
			LOG.error("updateClaimant id " + claimantDto.getId() + " failed.", e);
			throw e;
		}
	}

	/**
	 * Send the claimant details to logiClaim so it can be synced
	 * @param claimantId the claimant to be synced
	 *
	 */
	@ResponseBody
	@RequestMapping(value = "/claimant/sync/logiClaim/{claimantId}", method = RequestMethod.GET)
	public void syncClaimantToLogiClaim(@PathVariable final int claimantId){
		this.claimantService.syncClaimantToLogiClaim(claimantId);
	}

	/**
	 * Send the claimant details to logiClaim so it can be synced
	 * @param claimantIdList the list of claimants to be synced
	 *
	 */
	@ResponseBody
	@RequestMapping(value = "/claimant/sync/logiClaim", method = RequestMethod.POST)
	public void syncClaimantToLogiClaim(@RequestParam final String claimantIdList){
		for(String claimantId : claimantIdList.split(" ")){
			this.claimantService.syncClaimantToLogiClaim(Integer.valueOf(claimantId));
		}
	}

	/**
	 * This is a variation of the method {@link #updateClaimant(ClaimantDto, int)}}
	 * This method does not send the update back to the logiclaim queue
	 *
	 * @param claimantDto the claimant to be updated
	 * @param userId user updating the claimant
	 */
	@ResponseBody
	@RequestMapping(value = "/claimant/confinement/update/userId/{userId}", method = RequestMethod.POST)
	public void updateClaimantInConfinement(@RequestBody final ClaimantDto claimantDto, @PathVariable final int userId) {
		LOG.debug("updateClaimant id {}", claimantDto.getId());

		try {
			final Claimant claimant = this.claimantDtoConverter.convert(claimantDto);

			this.claimantService.updateClaimantInConfinement(claimant, userId);
		} catch (final HibernateOptimisticLockingFailureException | OptimisticLockException e) {
			LOG.warn("updateClaimant id " + claimantDto.getId() + " failed because of because of an optimistic locking exception.", e);
			throw e;
		} catch (final Exception e) {
			LOG.error("updateClaimant id " + claimantDto.getId() + " failed.", e);
			throw e;
		}
	}

	@ResponseBody
	@RequestMapping(value = "/claimant/{claimantId}/optIn/{optIn}", method = RequestMethod.GET)
	public void setClaimantOptIn(@PathVariable final int claimantId, @PathVariable final boolean optIn) {
		LOG.debug("setClaimantOptIn claimant id {}, optIn {}", claimantId, optIn);

		try {
			this.claimantService.setClaimantOptIn(claimantId, optIn);
		} catch (final HibernateOptimisticLockingFailureException | OptimisticLockException e) {
			LOG.warn("setClaimantOptIn id " + claimantId + " failed because of because of an optimistic locking exception.", e);
			throw e;
		} catch (final Exception e) {
			LOG.error("setClaimantOptIn id " + claimantId + " failed.", e);
			throw e;
		}
	}


	@ResponseBody
	@RequestMapping(value = "/claimant/claimantReferral", method = RequestMethod.POST)
	public ClaimantReferralDto createClaimantReferral(@RequestBody final CreateClaimantReferralDto createClaimantReferralDto) {
		LOG.debug("createClaimantReferral");

		try {
			final Claimant claimant = this.claimantDtoConverter.convert(createClaimantReferralDto.getClaimantDto());

			final ClaimantReferral claimantReferral = this.claimantService.createClaimantAndClaimantReferral(claimant,
				createClaimantReferralDto.getProductTypeId(),
				createClaimantReferralDto.getReferrerClaimantId(),
				createClaimantReferralDto.getCreatedByAgentId(),
				createClaimantReferralDto.getDiallerReferenceId(),
				JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(createClaimantReferralDto.getScheduledDateTime()),
				createClaimantReferralDto.getNote());
			return this.claimantReferralConverter.convert(claimantReferral);
		} catch (final HibernateOptimisticLockingFailureException | OptimisticLockException e) {
			LOG.warn("createClaimantReferral failed because of because of an optimistic locking exception.", e);
			throw e;
		} catch (final Exception e) {
			LOG.error("createClaimantReferral failed.", e);
			throw e;
		}
	}

	@ResponseBody
	@RequestMapping(value = "/claimant/productReferral", method = RequestMethod.POST)
	public ClaimantReferralDto createProductReferral(@RequestBody final CreateClaimantReferralDto createClaimantReferralDto) {
		LOG.debug("Creating a Product Referral for claimant {}", createClaimantReferralDto.getReferrerClaimantId());

		try {
			final ClaimantReferral claimantReferral = this.claimantService.createProductReferral(createClaimantReferralDto.getReferrerClaimantId(),
					createClaimantReferralDto.getPhoneNumber(),
					createClaimantReferralDto.getProductTypeId(),
					createClaimantReferralDto.getCreatedByAgentId(),
					createClaimantReferralDto.getDiallerReferenceId(),
					JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(createClaimantReferralDto.getScheduledDateTime()),
					createClaimantReferralDto.getNote());
			return this.claimantReferralConverter.convert(claimantReferral);
		} catch (final HibernateOptimisticLockingFailureException | OptimisticLockException e) {
			LOG.warn("Creating Product Referral failed because of an optimistic locking exception.", e);
			throw e;
		} catch (final Exception e) {
			LOG.error("Creating Product Referral failed.", e);
			throw e;
		}
	}

	@ResponseBody
	@RequestMapping(value = "/claimant/claimantReferral/referreeId/{referreeId}", method = RequestMethod.GET)
	public ClaimantReferralDto getClaimantReferralByReferreeId(@PathVariable final int referreeId) {
		LOG.debug("getClaimantReferralByReferreeId claimant id {}", referreeId);
		try {
			final ClaimantReferral claimantReferral =  this.claimantService.getClaimantReferralByReferreeId(referreeId);

			return this.claimantReferralConverter.convert(claimantReferral);
		} catch ( final Exception e ) {
			LOG.error("getClaimantReferralByReferreeId id " + referreeId + " failed", e);
			throw e;
		}
	}


	@ResponseBody
	@RequestMapping(value = "/claimant/claimantReferral/referreeIds/{csvIds}", method = RequestMethod.GET)
	public Collection<ClaimantReferralDto> getClaimantReferralsByReferreeIds(@PathVariable final String csvIds) {
		LOG.debug("getClaimantReferralsByReferreeIds claimants id {}", csvIds);
		try {
			final String[] idsStr = csvIds.split(",");
			final ImmutableList.Builder<Integer> ids = new ImmutableList.Builder<>();
			for ( final String idStr: idsStr ) {
				ids.add(Integer.parseInt(idStr.trim()));  // can throw exception back to call if not an integer
			}

			final Collection<ClaimantReferral> claimantReferrals =  this.claimantService.getClaimantReferralsByReferreeIds(ids.build());

			return this.claimantReferralsConverter.convert(claimantReferrals);
		} catch ( final Exception e ) {
			LOG.error("getClaimantReferralsByReferreeIds id " + csvIds + " failed", e);
			throw e;
		}
	}
	
	@ResponseBody
	@RequestMapping(value = "/claimant/{claimantId}/productReferrals", method = RequestMethod.GET)
	public List<ClaimantReferralDto> getProductReferralsForClaimant(@PathVariable final int claimantId) {
		LOG.debug("getProductReferralsForClaimant claimant id {}", claimantId);
		try {
			final List<ClaimantReferral> productReferrals =  this.claimantService.getProductReferralsForClaimant(claimantId);
			
			final List<ClaimantReferralDto> productReferralDtos = Lists.newArrayList();
			for (final ClaimantReferral productReferral : productReferrals) {
				productReferralDtos.add(this.claimantReferralConverter.convert(productReferral));
			}
			
			return productReferralDtos;
		} catch ( final Exception e ) {
			LOG.error("getProductReferralsForClaimant id " + claimantId + " failed", e);
			throw e;
		}
	}


	@ResponseBody
	@RequestMapping(value = "/claimant/{claimantId}/lock/user/{userId}/scheduledTaskId/{scheduledTaskId}", method = RequestMethod.GET)
	public ClaimantLockDto lockClaimant(@PathVariable final int claimantId, @PathVariable final int userId, @PathVariable final int scheduledTaskId) {
		LOG.debug("Lock claimant id {}, user id {}", claimantId, userId);

		try {
			final ClaimantLog claimantLog = this.claimantService.lockClaimant(claimantId, userId, scheduledTaskId);
			if (claimantLog.isLocked() && claimantLog.getUserId() == userId) {
				// User has, or already had, a lock
				return new ClaimantLockDto(true, claimantLog.getUserId());
			}
			return new ClaimantLockDto(false, claimantLog.getUserId());
		} catch (final HibernateOptimisticLockingFailureException|OptimisticLockException e) {
			LOG.warn("lockClaimant " + claimantId + " by user " + userId + " failed because of because of an optimistic locking exception.", e);
			throw e;
		} catch ( final Exception e ) {
			LOG.error("lockClaimant " + claimantId + " by user " + userId + " failed.", e);
			throw e;
		}
	}

	@ResponseBody
	@RequestMapping(value = "/claimant/{claimantId}/unlock/user/{userId}", method = RequestMethod.GET)
	public ClaimantUnlockDto unlockClaimant(@PathVariable final int claimantId, @PathVariable final int userId) {
		LOG.debug("Unlock claimant id {}", claimantId);
		try {
			final ClaimantLog claimantLog = this.claimantService.unlockClaimant(claimantId, userId);
			if ( claimantLog == null ) {
				return new ClaimantUnlockDto(0);
			}

			return new ClaimantUnlockDto(claimantLog.getUserId());
		} catch (final HibernateOptimisticLockingFailureException|OptimisticLockException e) {
			LOG.warn("unlockClaimant " + claimantId + " by user " + userId + " failed because of an optimistic locking exception.", e);
			throw e;
		} catch ( final Exception e ) {
			LOG.error("unlockClaimant " + claimantId + " by user " + userId + " failed.", e);
			throw e;
		}
	}

	@ResponseBody
	@RequestMapping(value = "/claimant/{claimantId}/lock/status", method = RequestMethod.GET)
	public ClaimantLockStatusDto claimantLockStatus(@PathVariable final int claimantId) {
		LOG.debug("claimantLockStatus claimant id {}", claimantId);
		try {
			final ClaimantLog claimantLog = this.claimantService.getClaimantLog(claimantId);

			if (null == claimantLog) {
				return new ClaimantLockStatusDto(false, 0);
			}

			return new ClaimantLockStatusDto(claimantLog.isLocked(), claimantLog.getUserId());
		} catch (final HibernateOptimisticLockingFailureException|OptimisticLockException e) {
			LOG.warn("claimantLockStatus " + claimantId + " failed because of an optimistic locking exception.", e);
			throw e;
		} catch ( final Exception e ) {
			LOG.error("claimantLockStatus " + claimantId + " failed.", e);
			throw e;
		}
	}
	
	@ResponseBody
	@RequestMapping(value="/claimant/{claimantId}/interactions", method = RequestMethod.GET)
	public ClaimantInteractionsDto claimantInteractions(@PathVariable final int claimantId) {
		LOG.debug("Retrieving all interactions for claimant {}", claimantId);
		try {
			final List<ClaimantInteraction> notes = this.claimantService.getNotesForClaimant(claimantId);
			final List<ClaimantInteraction> events = this.claimantService.getEventsForClaimant(claimantId);
			
			return new ClaimantInteractionsDto(toListClaimantInteractionDto(notes), toListClaimantInteractionDto(events));
		} catch (final Exception e) {
			LOG.error("Failed to retrieve interactions for claimant " + claimantId, e);
			throw e;
		}
	}

	@ResponseBody
	@RequestMapping(value="/claimant/{claimantId}/{source}/interactions/{productType}", method = RequestMethod.GET)
	public ClaimantInteractionsDto claimantInteractions(@PathVariable final int claimantId, @PathVariable final String source, @PathVariable final int productType) {
		LOG.debug("Retrieving all interactions for claimant {} by source {}", claimantId, source);
		try {
			final List<ClaimantInteraction> notes = this.claimantService.getNotesForClaimantBySource(claimantId, source, productType);
			final List<ClaimantInteraction> events = this.claimantService.getEventsForClaimantBySource(claimantId, source, productType);

			return new ClaimantInteractionsDto(toListClaimantInteractionDto(notes), toListClaimantInteractionDto(events));
		} catch (final Exception e) {
			LOG.error("Failed to retrieve interactions for claimant " + claimantId, e);
			throw e;
		}
	}

	@ResponseBody
	@RequestMapping(value="/claimant/{claimantId}/sources/{source}/interactions/{productType}", method = RequestMethod.GET)
	public ClaimantInteractionsDto claimantInteractionsBySources(@PathVariable final int claimantId, @PathVariable final String source, @PathVariable final int productType) {
		List<String> sources = Arrays.asList(source.split(","));
		LOG.debug("Retrieving all interactions for claimant {}", claimantId);
		try {
			final List<ClaimantInteraction> notes = this.claimantService.getNotesForClaimantBySources(claimantId, sources, productType);
			final List<ClaimantInteraction> events = this.claimantService.getEventsForClaimantBySources(claimantId, sources, productType);

			return new ClaimantInteractionsDto(toListClaimantInteractionDto(notes), toListClaimantInteractionDto(events));
		} catch (final Exception e) {
			LOG.error("Failed to retrieve interactions for claimant " + claimantId, e);
			throw e;
		}
	}
	
	@ResponseBody
	@RequestMapping(value="/claimant/{claimantId}/notes", method = RequestMethod.GET)
	public List<ClaimantInteractionDto> claimantNotes(@PathVariable final int claimantId) {
		LOG.debug("Retrieving notes for claimant {}", claimantId);
		try {
			final List<ClaimantInteraction> notes = this.claimantService.getNotesForClaimant(claimantId);
			
			return toListClaimantInteractionDto(notes);
		} catch (final Exception e) {
			LOG.error("Failed to retrieve notes for claimant " + claimantId, e);
			throw e;
		}
	}
	
	@ResponseBody
	@RequestMapping(value="/claimant/{claimantId}/events", method = RequestMethod.GET)
	public List<ClaimantInteractionDto> claimantEvents(@PathVariable final int claimantId) {
		LOG.debug("Retrieving events for claimant {}", claimantId);
		try {
			final List<ClaimantInteraction> events = this.claimantService.getEventsForClaimant(claimantId);
		
			return toListClaimantInteractionDto(events);
		} catch (final Exception e) {
			LOG.error("Failed to retrieve events for claimant " + claimantId, e);
			throw e;
		}
	}

	@ResponseBody
	@RequestMapping(value="/claimant/saveNote", method = RequestMethod.POST)
	public int saveNote(@RequestBody final ClaimantInteractionDto dto) {
		LOG.debug("saveNote for claimant {}", dto.getClaimantId());
		Integer interactionId;
		try {
			interactionId = this.claimantService.saveNote(dto.getClaimantId(), dto.getProductId(), dto.getUserId(), dto.getContent(), Source.fromValue(dto.getSource()));
		} catch (final Exception e) {
			LOG.error("Failed to save note for claimant " + dto.getClaimantId() + ".", e);
			throw e;
		}

		return interactionId;
	}

	@ResponseBody
	@RequestMapping(value="/claimant/saveNoteWithInteractionDateTime", method = RequestMethod.POST)
	public int saveNoteWithInteractionDateTime(@RequestBody final ClaimantInteractionDto dto) {
		LOG.debug("saveNote for claimant {}", dto.getClaimantId());
		Integer interactionId;
		try {
			interactionId = this.claimantService.saveNoteWithInteractionDateTime(dto.getClaimantId(), dto.getProductId(), dto.getUserId(), dto.getContent(), Source.fromValue(dto.getSource()), timestampStringToLocalDateTimeOrNull(dto.getInteractionDateTime()));
		} catch (final Exception e) {
			LOG.error("Failed to save note for claimant " + dto.getClaimantId() + ".", e);
			throw e;
		}

		return interactionId;
	}

	@ResponseBody
	@RequestMapping(value="/claimant/updateNote", method = RequestMethod.POST)
	public ClaimantInteractionDto updateNote(@RequestBody final ClaimantInteractionDto dto) {
		LOG.debug("update note for claimant {}", dto.getClaimantId());
		ClaimantInteraction claimantInteraction;
		try {
			claimantInteraction = this.claimantService.updateNote(dto.getId(), dto.getClaimantId(), dto.getProductId(), dto.getUserId(), dto.getContent(), Source.fromValue(dto.getSource()), dto.getVersion());
		} catch (final Exception e) {
			LOG.error("Failed to update note for claimant " + dto.getClaimantId() + ".", e);
			throw e;
		}

		return this.claimantInteractionConverter.convert(claimantInteraction);
	}

	@ResponseBody
	@RequestMapping(value="/claimant/saveEvent", method = RequestMethod.POST)
	public void saveEvent(@RequestBody final ClaimantInteractionDto dto) {
		LOG.debug("Saving event for claimant {}", dto.getClaimantId());
		try {
			this.claimantService.saveEvent(dto.getClaimantId(), dto.getProductId(), dto.getUserId(), dto.getContent(), Source.fromValue(dto.getSource()));
		} catch (final Exception e) {
			LOG.error("Failed to save event for claimant " + dto.getClaimantId() + ".", e);
			throw e;
		}
	}


	@ResponseBody
	@RequestMapping(value = "/claimant/lockFromDialler/{claimantId}/{userId}", method = RequestMethod.POST)
	public void lockClaimantFromTheDialler(@PathVariable final int claimantId, @PathVariable final int userId) {
		try {
			claimantService.lockClaimantFromTheDialler(claimantId, userId);
		} catch ( final Exception e ) {
			LOG.error("Failed to lock Claimant from Dialler" + e);
		}
	}


	@ResponseBody
	@RequestMapping(value = "/claimant/unlockFromDialler/{claimantId}/{userId}", method = RequestMethod.POST)
	public void unlockClaimantFromTheDialler(@PathVariable final int claimantId, @PathVariable final int userId) {
		try {
			claimantService.unlockClaimantFromTheDialler(claimantId, userId);
		} catch ( final Exception e ) {
			LOG.error("Failed to unlock Claimant from Dialler" + e);
		}
	}

	private List<ClaimantInteractionDto> toListClaimantInteractionDto(final List<ClaimantInteraction> interactions) {
		final List<ClaimantInteractionDto> dtos = Lists.newArrayList();
		
		for (final ClaimantInteraction interaction : interactions) {
			dtos.add(this.claimantInteractionConverter.convert(interaction));
		}
		
		return dtos;
	}
	
	private List<ClaimantAndAddressDto> toClaimantAndAddressDtos(final List<ClaimantAndAddress> claimantsWithAddress) {
		final ImmutableList.Builder<ClaimantAndAddressDto> results = new ImmutableList.Builder<>();
		for ( final ClaimantAndAddress claimantAndAddress: claimantsWithAddress ) {
			final ClaimantDto claimantDto = this.claimantConverter.convert(claimantAndAddress.getClaimant());
			final AddressDto addressDto = this.addressConverter.convert(claimantAndAddress.getAddress());
			results.add(new ClaimantAndAddressDto(claimantDto, addressDto));
		}
		return results.build();
	}

	private Collection<ClaimantDto> toClaimantDtos(final Collection<Claimant> claimants) {
		final ImmutableList.Builder<ClaimantDto> results = new ImmutableList.Builder<>();
		for ( final Claimant claimant: claimants ) {
			final ClaimantDto claimantDto = this.claimantConverter.convert(claimant);
			results.add(claimantDto);
		}

		return results.build();
	}

}
