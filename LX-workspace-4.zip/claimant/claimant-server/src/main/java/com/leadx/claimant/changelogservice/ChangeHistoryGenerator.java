package com.leadx.claimant.changelogservice;

import java.lang.reflect.Field;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import com.google.common.base.Preconditions;
import com.google.common.collect.Maps;
import com.leadx.lib.domain.PersistableEnum;
import org.apache.commons.collections.ComparatorUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ReflectionUtils;

import com.google.common.base.Function;
import com.google.common.base.Objects;
import com.google.common.base.Optional;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.leadx.hibernate.domain.BaseIntegerDomain;

import static com.leadx.claimant.utils.ObjectUtils.allNotNull;
import static com.leadx.claimant.utils.ObjectUtils.allNull;
import static com.leadx.claimant.utils.ObjectUtils.isNull;
import static java.lang.String.format;
import static org.apache.commons.lang.StringUtils.isBlank;
import static org.apache.commons.lang.StringUtils.isNotBlank;

class ChangeHistoryGenerator {

	private static final Logger LOG = LoggerFactory.getLogger(ChangeHistoryGenerator.class);

	public static HashMap<String, String> fieldToEventText = Maps.newHashMap();
	static {
		fieldToEventText.put("currentlyInIva", "Claimant updated –%s in IVA");
		fieldToEventText.put("currentlyInDebtManagementProgramme", "Claimant updated –%s in Debt Management");
		fieldToEventText.put("currentlyInBankruptcy", "Claimant updated –%s Bankrupt");
	}

	static <T extends BaseIntegerDomain> List<ChangeItem> generateChangeItems(final int claimantId, final T original, final T updated, final int userId) {
		try {
			if (original == null &&  updated == null) {
				return Lists.newArrayList();
			}

			final T primary = Objects.firstNonNull(original, updated);
			final String tableName = extractTableName(primary);
			final ChangeGroup group = new ChangeGroup(claimantId, userId, new LocalDateTime());

			return determineChangeItems(tableName, primary, group, original, updated);
		}
		catch (final Throwable e) {
			LOG.error("Error creating change item list", e);
		}

		return Lists.newArrayList();
	}

	public static <T> List<String> generateEvents(final T original, final T updated, final String claimId) {
		try {
			if (allNull(original, updated)) {
				return Lists.newArrayList();
			}

			final Object primary = validateAndReturnPrimary(original, updated);

			return determineChangeEvents(primary, original, updated, claimId);
		}
		catch (final Throwable e) {
			LOG.error("Error creating change event list for claim", e);
		}

		return Lists.newArrayList();
	}

	public static <T> List<String> generateEvents(final T original, final T updated) {
		try {
			if (allNull(original, updated)) {
				return Lists.newArrayList();
			}

			final Object primary = validateAndReturnPrimary(original, updated);

			return determineChangeEvents(primary, original, updated);
		}
		catch (final Throwable e) {
			LOG.error("Error creating change event list for claimant", e);
		}

		return Lists.newArrayList();
	}

	private static <T> Object validateAndReturnPrimary(final T original, final T updated) {
		validateSameClass(original, updated);

		final Object primary = Objects.firstNonNull(original, updated);
		validateAnnotationPresent(primary);

		return primary;
	}

	@SuppressWarnings("rawtypes")
	private static void validateSameClass(final Object original, final Object updated) {
		if (allNotNull(original, updated)) {
			final Class originalClass = original.getClass();
			final Class updatedClass = updated.getClass();
			Preconditions.checkArgument(originalClass.equals(updatedClass),
					format("Objects must be of the same class. Original [%s] Updated [%s]", originalClass, updatedClass));
		}
	}

	private static <T extends Object> void validateAnnotationPresent(final T candidate) {
		final boolean annotationMissing = !hasChangeHistoryField(candidate.getClass());

		if (annotationMissing) {
			throw new IllegalArgumentException(format(
					"Unable to parse change item for objects which dont contain any @ChangeHistory annotations, class: [%s]", candidate.getClass()
							.getSimpleName()));
		}
	}

	private static List<ChangeItem> determineChangeItems(final String tableName, final Object primary, final ChangeGroup group, final Object original, final Object updated)
		throws IllegalArgumentException {
		final List<ChangeItem> changes = Lists.newArrayList();

		ReflectionUtils.doWithFields(primary.getClass(), new ReflectionUtils.FieldCallback() {

			@SuppressWarnings({"synthetic-access", "unchecked", "rawtypes"})
			@Override
			public void doWith(final Field field) throws IllegalArgumentException, IllegalAccessException {
				if (isChangeHistoryField(field)) {
					ReflectionUtils.makeAccessible(field);

					final Object originalValue = getValue(original, field);
					final Object updatedValue = getValue(updated, field);

					final Object primaryValue = Optional.fromNullable(originalValue)
						.or(Optional.fromNullable(updatedValue))
						.orNull();

					final boolean hasValueChanged = hasValueChanged(originalValue, updatedValue);

					// If the item is an iterable then break out each item inside and try to log that
					if (hasValueChanged && isIterableClass(field.getType())) {

						// Enforce null safety
						final Iterable<Object> originalIterable = originalValue == null ? Lists.newArrayList() : Lists.newArrayList((Iterable<Object>) originalValue);
						final Iterable<Object> updatedIterable = updatedValue == null ? Lists.newArrayList() : Lists.newArrayList((Iterable<Object>) updatedValue);

						// Remove items that are in both lists and sort them
						final List<Object> originalValueCopy = Lists.newArrayList(originalIterable);
						Iterables.removeAll(originalIterable, (Collection<?>) updatedIterable);
						Iterables.removeAll(updatedIterable, originalValueCopy);
						Collections.sort((List) originalIterable, ComparatorUtils.naturalComparator());
						Collections.sort((List) updatedIterable, ComparatorUtils.naturalComparator());

						// Make lists the same size, padded with null values
						final int originalCount = Iterables.size(originalIterable);
						final int updatedCount = Iterables.size(updatedIterable);
						final int listSize = Math.max(originalCount, updatedCount);
						Iterables.addAll((Collection) originalIterable, createNullList(listSize - originalCount));
						Iterables.addAll((Collection) updatedIterable, createNullList(listSize - updatedCount));

						// Compare matching(by index) values from each iterable to work out what the changes between them are
						for (int i = 0; i < listSize; i++) {

							final Object innerOriginalValue = Iterables.get(originalIterable, i);
							final Object innerUpdatedValue = Iterables.get(updatedIterable, i);
							final Object innerPrimaryValue = Optional.fromNullable(innerOriginalValue)
								.or(Optional.fromNullable(innerUpdatedValue))
								.orNull();

							changes.addAll(determineChangeItems(extendTableName(tableName, field), innerPrimaryValue, group, innerOriginalValue, innerUpdatedValue));
						}
					} else if (hasValueChanged && hasChangeHistoryField(field.getType())) {
						changes.addAll(determineChangeItems(tableName, primaryValue, group, originalValue, updatedValue));
					} else if (hasValueChanged) {
						final String fieldName = createFieldName(tableName, field);
						LOG.debug("Creating item for field [{}] type [{}] original [{}] updated [{}]", fieldName, field.getType(), originalValue, updatedValue);

						changes.add(createChangeItem(group, field, fieldName, primaryValue, originalValue, updatedValue));
					}
				}
			}

		});

		return changes;
	}

	private static List<String> determineChangeEvents(final Object primary, final Object original, final Object updated)
			throws IllegalArgumentException {
		final List<String> changeEvents = Lists.newArrayList();

		ReflectionUtils.doWithFields(primary.getClass(), field -> {
			if (isChangeHistoryField(field) && shouldCreateEvent(field)) {
				ReflectionUtils.makeAccessible(field);

				final Object originalValue = getValue(original, field);
				final Object updatedValue = getValue(updated, field);

				final boolean hasValueChanged = hasValueChanged(originalValue, updatedValue);

				if(hasValueChanged){
					PersistanceStrategy strategy = getPersistanceStrategy(field);
					final String processedOriginalValue = isNull(originalValue) ? null : strategy.process(originalValue.toString());
					final String processedUpdatedValue = isNull(updatedValue) ? null : strategy.process(updatedValue.toString());

					if (isBoolean(field)) {
						if (setToTrue(updatedValue)) {
							changeEvents.add(format(format("%s", textFromFieldName(field.getName())), ""));
						} else if (setToFalse(updatedValue)) {
							changeEvents.add(format(format("%s", textFromFieldName(field.getName())), " not"));
						}
					} else {
						if (valueAdded(originalValue, updatedValue)) {
							changeEvents.add(format("%s has been added of %s", textFromFieldName(field.getName()), processedUpdatedValue));
						}
						else if (valueRemoved(originalValue, updatedValue)) {
							changeEvents.add(format("%s has been removed", textFromFieldName(field.getName())));
						}
						else {
							changeEvents.add(format("%s has been amended from %s to %s", textFromFieldName(field.getName()), processedOriginalValue,
									processedUpdatedValue));
						}
					}
				}
			}
		});

		return changeEvents;
	}

	private static List<String> determineChangeEvents(final Object primary, final Object original, final Object updated, final String claimId)
			throws IllegalArgumentException {
		final List<String> changeEvents = Lists.newArrayList();

		ReflectionUtils.doWithFields(primary.getClass(), field -> {
			if (isChangeHistoryField(field) && shouldCreateEvent(field)) {
				ReflectionUtils.makeAccessible(field);

				final Object originalValue = getValue(original, field);
				final Object updatedValue = getValue(updated, field);

				final boolean hasValueChanged = hasValueChanged(originalValue, updatedValue);

				if(hasValueChanged){
					if (updatedValue instanceof PersistableEnum) {
						if(originalValue != null){
							changeEvents.add(
									textFromFieldName(field.getName()) + " - Claim(s) " + claimId + " amended " + ((PersistableEnum) originalValue).toPrettyString() + " to " + ((PersistableEnum) updatedValue).toPrettyString());
						}
					} else {
						PersistanceStrategy strategy = getPersistanceStrategy(field);
						final String processedOriginalValue = strategy.process(originalValue.toString());
						final String processedUpdatedValue = strategy.process(updatedValue.toString());

						if(valueAdded(originalValue, updatedValue)){
							changeEvents.add(format(eventPrefix(claimId) + "%s has been added of %s", textFromFieldName(field.getName()), processedUpdatedValue));
						} else if (valueRemoved(originalValue, updatedValue)){
							changeEvents.add(format(eventPrefix(claimId) + "%s has been removed", textFromFieldName(field.getName())));
						} else {
							changeEvents.add(format(eventPrefix(claimId) + "%s has been amended from %s to %s", textFromFieldName(field.getName()), processedOriginalValue, processedUpdatedValue));
						}
					}
				}
			}
		});

		return changeEvents;
	}

	private static String eventPrefix(final String claimId) {
		return isNotBlank(claimId) ? "Claim " + claimId + " " : "";
	}

	private static boolean shouldCreateEvent(final Field field) {
		final ChangeHistory annotation = field.getAnnotation(ChangeHistory.class);
		return annotation.createEvent();
	}

	private static boolean valueAdded(final Object originalValue, final Object updatedValue) {
		return (originalValue == null || isBlank(originalValue.toString())) && (updatedValue != null && isNotBlank(updatedValue.toString()));
	}

	private static boolean valueRemoved(final Object originalValue, final Object updatedValue) {
		return (originalValue != null && isNotBlank(originalValue.toString())) && (updatedValue == null || isBlank(updatedValue.toString()));
	}

	private static String textFromFieldName(final String fieldName) {
		return fieldToEventText.get(fieldName);
	}

	private static boolean isBoolean(final Field field) {
		return field.getType().equals(Boolean.class) || field.getType().equals(boolean.class);
	}

	private static boolean setToTrue(final Object updatedValue) {
		return (Boolean) updatedValue;
	}

	private static boolean setToFalse(final Object updatedValue) {
		return !(Boolean) updatedValue;
	}

	@SuppressWarnings("rawtypes")
	private static boolean isIterableClass(final Class c) {
		return Iterable.class.isAssignableFrom(c);
	}

	private static boolean isChangeHistoryField(final Field field) {
		return field.isAnnotationPresent(ChangeHistory.class);
	}

	private static String extractTableName(final Object candidate) {
		return StringUtils.lowerCase(candidate.getClass()
			.getSimpleName());
	}

	private static Object getValue(final Object object, final Field field) throws IllegalAccessException {
		if (object == null) {
			return null;
		}
		return field.get(object);
	}


	private static boolean hasChangeHistoryField(final Class<?> type) {
		for (final Field field : type.getDeclaredFields()) {
			if (isChangeHistoryField(field)) {
				return true;
			}
		}
		return false;
	}

	private static boolean hasValueChanged(final Object originalValue, final Object updatedValue) {
		return !Objects.equal(originalValue, updatedValue);
	}

	private static String createFieldName(final String tableName, final Field field) {

		final ChangeHistory annotation = field.getAnnotation(ChangeHistory.class);

		final String prefix = tableName + ".";
		final String suffix = StringUtils.isNotBlank(annotation.fieldName())
			? annotation.fieldName()
			: StringUtils.capitalize(field.getName());

		return prefix + suffix;
	}

	private static String extendTableName(final String tableName, final Field field) {
		return String.format("%s.%s", tableName, field.getName());
	}

	private static List<Object> createNullList(final int listSize) {
		final List<Object> nulls = Lists.newArrayList();
		for (int i = 0; i < listSize; i++) {
			nulls.add(null);
		}
		return nulls;
	}

	@SuppressWarnings({ "unchecked" })
	private static ChangeItem createChangeItem(final ChangeGroup group, final Field objField, final String field, final Object primaryValue, final Object oldString, final Object newString) {
		final Function<Object, String> converter = ConvertersFactory.getConverterForClass(primaryValue.getClass());
		final PersistanceStrategy strategy = getPersistanceStrategy(objField);

		final String oldStringVal = oldString == null? null: strategy.process(converter.apply(oldString));
		final String newStringVal = newString == null? null: strategy.process(converter.apply(newString));

		return new ChangeItem(group, field, oldStringVal, newStringVal);
	}

	private static PersistanceStrategy getPersistanceStrategy(final Field field) {
		final ChangeHistory annotation = field.getAnnotation(ChangeHistory.class);
		final Class<? extends PersistanceStrategy> strategy = annotation.strategy();
		try {
			return strategy.newInstance();
		}
		catch (final InstantiationException | IllegalAccessException e) {
			LOG.error("Exception", e);
		}

		return DefaultStrategy.INSTANCE;
	}
}
