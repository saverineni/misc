package com.leadx.claimant.reference;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("debtManagementCompanyRepository")
public class DebtManagementCompanyRepository {

	private SessionFactory sessionFactory;

	@Autowired
	public DebtManagementCompanyRepository(final SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@SuppressWarnings("unchecked")
	public List<DebtManagementCompany> getDebtManagementCompanies() {
		return this.sessionFactory.getCurrentSession()
				.createQuery("from DebtManagementCompany order by name asc")
				.list();
	}

}