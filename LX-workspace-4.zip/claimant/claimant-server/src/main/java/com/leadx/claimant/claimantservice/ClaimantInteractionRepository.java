package com.leadx.claimant.claimantservice;

import java.util.List;

import com.leadx.claimant.client.ProductType;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
@SuppressWarnings("unchecked")
public class ClaimantInteractionRepository {

	private final SessionFactory sessionFactory;

	@Autowired
	public ClaimantInteractionRepository(final SessionFactory claimSessionFactory) {
		this.sessionFactory = claimSessionFactory;
	}
	
	protected List<ClaimantInteraction> getByClaimantId(final int claimantId, final ClaimantInteractionType type) {
		return this.sessionFactory.getCurrentSession()
				.createQuery("FROM ClaimantInteraction WHERE claimantId = :claimantId AND type = :type order by id desc")
				.setParameter("claimantId", claimantId)
				.setParameter("type", type.toValue())
				.list();
	}

	protected List<ClaimantInteraction> getByClaimantIdAndSource(final int claimantId, final ClaimantInteractionType type, final String source, final int productType ) {
		String productTypeConstraint = productType == ProductType.PPI.getId() ? " OR productId IS NULL " : "";
		return this.sessionFactory.getCurrentSession()
				.createQuery("FROM ClaimantInteraction WHERE claimantId = :claimantId AND type = :type AND source = :source AND (productId = :productId "+productTypeConstraint+") order by id desc")
				.setParameter("claimantId", claimantId)
				.setParameter("type", type.toValue())
				.setParameter("source", source)
				.setParameter("productId", productType)
				.list();
	}


	protected List<ClaimantInteraction> getByClaimantIdBySources(final int claimantId, final ClaimantInteractionType type, final List<String> sources, final int productType) {
		String productTypeConstraint = productType == ProductType.PPI.getId() ? " OR productId IS NULL " : "";
		return this.sessionFactory.getCurrentSession()
				.createQuery("FROM ClaimantInteraction WHERE claimantId = :claimantId AND type = :type AND source IN (:sources) AND (productId = :productId "+productTypeConstraint+") order by id desc")
				.setParameter("claimantId", claimantId)
				.setParameter("type", type.toValue())
				.setParameterList("sources", sources)
				.setParameter("productId", productType)
				.list();
	}


	public int save(final ClaimantInteraction claimantInteraction) {
		return (Integer) this.sessionFactory.getCurrentSession().save(claimantInteraction);
	}

	protected ClaimantInteraction update(final ClaimantInteraction claimantInteraction) {
		this.sessionFactory.getCurrentSession().update(claimantInteraction);
		return claimantInteraction;
	}
}
