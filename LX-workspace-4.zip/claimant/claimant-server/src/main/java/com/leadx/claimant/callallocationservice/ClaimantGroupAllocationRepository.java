package com.leadx.claimant.callallocationservice;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("claimantGroupAllocationRepository")
@SuppressWarnings("unchecked")
public class ClaimantGroupAllocationRepository {

	@Autowired
	public ClaimantGroupAllocationRepository(final SessionFactory claimSessionFactory) {
		this.sessionFactory = claimSessionFactory;
	}

	private final static String CHECK_CLAIMANT_CALL_GROUP_ALLOCATION =
			"SELECT cga.`FK_ClaimantID` FROM claimant.`claimant_group_allocation` cga WHERE cga.`FK_ClaimantID` = :claimantId AND isDeleted != 1";


	private SessionFactory sessionFactory;

	@Transactional
	public void insertClaimantCallGroupAllocationEntry(final ClaimantGroupAllocation claimantGroupAllocation) {
		this.sessionFactory.getCurrentSession()
			.save(claimantGroupAllocation);
	}

	@Transactional
	public void updateClaimantCallGroupAllocationEntry(final ClaimantGroupAllocation claimantGroupAllocation) {
		this.sessionFactory.getCurrentSession()
			.update(claimantGroupAllocation);
	}

	@Transactional
	public void deleteClaimantCallGroupAllocationEntry(final ClaimantGroupAllocation claimantGroupAllocation) {
		claimantGroupAllocation.setIsDeleted(true);
		this.sessionFactory.getCurrentSession()
			.update(claimantGroupAllocation);
	}

	@Transactional
	public boolean checkClaimantCallGroupAllocationEntry(final int claimantId) {
		return this.sessionFactory.getCurrentSession().createSQLQuery(CHECK_CLAIMANT_CALL_GROUP_ALLOCATION)
				.setParameter("claimantId", claimantId)
				.list().isEmpty() ? false : true;
	}

	@Transactional
	public ClaimantGroupAllocation getClaimantGroupAllocationByClaimantId(final int claimantId) {
		return (ClaimantGroupAllocation) this.sessionFactory.getCurrentSession()
				.createQuery("FROM ClaimantGroupAllocation WHERE claimantId = :claimantId AND isDeleted != 1")
				.setInteger("claimantId", claimantId)
				.uniqueResult();
	}

	@Transactional
	public void evict(final ClaimantGroupAllocation claimantGroupAllocation) {
		this.sessionFactory.getCurrentSession().evict(claimantGroupAllocation);
	}



}
