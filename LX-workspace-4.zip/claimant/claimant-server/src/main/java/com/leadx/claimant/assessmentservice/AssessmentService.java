package com.leadx.claimant.assessmentservice;

import static com.leadx.lib.utl.ObjectUtils.isNotNull;

import java.util.List;

import org.joda.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.leadx.claimant.addressservice.Address;
import com.leadx.claimant.addressservice.AddressService;
import com.leadx.claimant.addressservice.PreviousAddress;
import com.leadx.claimant.callallocationservice.CallAllocationService;
import com.leadx.claimant.callallocationservice.ClaimantGroupAllocation;
import com.leadx.claimant.calllogservice.CallLog;
import com.leadx.claimant.calllogservice.CallLogService;
import com.leadx.claimant.claimantservice.*;
import com.leadx.claimant.client.AssessmentDispositionDto;
import com.leadx.claimant.client.AssessmentDto;
import com.leadx.claimant.client.CallDisposition;
import com.leadx.claimant.client.CallType;
import com.leadx.claimant.client.ClaimantReferralDto;
import com.leadx.claimant.client.ProductType;
import com.leadx.claimant.selleraccountservice.SellerAccount;
import com.leadx.claimant.selleraccountservice.SellerAccountService;
import com.leadx.claimant.user.UserService;
import com.leadx.claimant.utils.CallRequestBuilder;
import com.leadx.lib.utl.JodaUtils;
import com.leadx.services.client.CallReason;
import com.leadx.services.client.TcgCallRequest;
import com.leadx.services.client.TcgProduct;
import com.leadx.services.client.service.TelephonyService;
import com.leadx.services.distribution.client.CancellationRequest;
import com.leadx.services.distribution.client.CancellationRequest.CancellationRequestBuilder;
import com.leadx.services.distribution.client.DistributionClient;

@Service
public class AssessmentService {
	@Autowired
	private ClaimantService claimantService;

	@Autowired
	private AddressService addressService;

	@Autowired
	private SellerAccountService sellerAccountService;

	@Autowired
	private Converter<Assessment, AssessmentDto> assessmentDtoConverter;

	@Autowired
	private CallLogService callLogService;

	@Autowired
	private CallAllocationService callAllocationService;

	@Autowired
	private DistributionClient distributionClient;

	@Autowired
	private UserService userService;

	@Autowired
	private TelephonyService telephonyService;

	@Autowired
	private ClaimantContactPreferenceService claimantContactPreferenceService;

	private static final int SMS_WELCOME_FLOW = 31;
	private static final int EMAIL_WELCOME_FLOW = 30;

	@Transactional
	public AssessmentDto loadClaimant(final int claimantId, final int userId, final boolean lockClaimant) {
		final Claimant claimant = this.claimantService.getClaimantById(claimantId);

		if (null == claimant) {
			return AssessmentDto.claimantNotFound(claimantId);
		}

		if (lockClaimant) {
			if (this.claimantService.lockClaimant(claimantId, userId, 0).getUserId() != userId) {
				return AssessmentDto.lockedClaimant(claimantId);
			}
		}

		final Address address = this.addressService.getAddressById(claimant.getAddressId());
		final List<PreviousAddress> previousAddresses = this.addressService.getOrderedPreviousAddressesForClaimant(claimantId);
		final ClaimantReferral claimantReferral = this.claimantService.getClaimantReferralByReferreeId(claimantId);
		final SellerAccount sellerAccount = this.sellerAccountService.getByAccountId(claimant.getSellerAccountId());
		final ClaimantContactPreference contactPreference = this.claimantContactPreferenceService.getByClaimantId(claimantId);

		final AssessmentDto assessmentDto = this.assessmentDtoConverter.convert(new Assessment(claimant, address, previousAddresses, claimantReferral, sellerAccount, contactPreference));

		if (isNotNull(claimantReferral)) {
			assessmentDto.setClaimantReferralDto(appendReferralDetails(assessmentDto.getClaimantReferralDto()));
		}

		return assessmentDto;
	}

	@Transactional
	public void dispositionCall(final AssessmentDispositionDto disposition, final CallDisposition callDisposition) {
		final int claimantId = disposition.getClaimantId();
		final Claimant claimant = this.claimantService.getClaimantById(claimantId);

		if (callDisposition.shouldStopContactFlow() && disposition.getCallReason().equals(CallReason.ASSESSMENT)) {
			cancelDistributionFlowForClaimant(claimantId, SMS_WELCOME_FLOW);
			cancelDistributionFlowForClaimant(claimantId, EMAIL_WELCOME_FLOW);
		}

		final CallLog callLog;
		if (CallReason.ASSESSMENT.equals(disposition.getCallReason())){
			callLog = new CallLog(claimantId, callDisposition, CallType.ASSESSMENT, disposition.getDiallerRefId(), disposition.getInbound(), disposition.getUserId());
		} else if (CallReason.CHASE.equals(disposition.getCallReason())) {
			callLog = new CallLog(claimantId, callDisposition, CallType.CHASE, disposition.getDiallerRefId(), disposition.getInbound(), disposition.getUserId());
		} else {
			throw new RuntimeException("Unexpected Call Reason");
		}

		if(disposition.isNewClaimant()){
			this.callLogService.saveCallLogNoConstraints(callLog);
		}else{
			this.callLogService.saveCallLog(callLog);
		}

		final String callReasonGroup = disposition.getCallReasonGroup();
		final String product = ProductType.PPI.getShortName().equals(callReasonGroup) ? "" : callReasonGroup;

		if(callDisposition.isCallback()){
			// Inbound calls don't have an entry in Ultra so can't use the usual callback process, hence creating a new call
			if ((disposition.getInbound() && CallReason.ASSESSMENT.equals(disposition.getCallReason())) || disposition.isNewClaimant()) {
				// The default PPI assessment pot has no call reason group, hence clearing down the value
				final TcgCallRequest callRequest =
						CallRequestBuilder.createAssessmentCall(product, claimantId, 0L, claimant.getTitle(),
								claimant.getForename(), claimant.getSurname(), claimant.getHomeTelephone(), claimant.getMobileTelephone(), "",
								JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(disposition.getCallbackDateTime()));

				this.telephonyService.scheduleCall(callRequest);
			} else if (disposition.getInbound() && CallReason.CHASE.equals(disposition.getCallReason())){
				final ClaimantGroupAllocation currentAllocation = this.callAllocationService.getClaimantGroupAllocationByClaimantId(claimantId);
				final LocalDateTime callbackDateTime = JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(disposition.getCallbackDateTime());
				final TcgProduct callbackProduct = CallAllocationService.productForCallReasonGroup(null != currentAllocation ? currentAllocation.getCallReasonGroup() : callReasonGroup);

				this.callAllocationService.updateClaimantsGroupAllocation(claimantId, callbackProduct, callbackDateTime);
			}
		}

		if (callDisposition.requiresClaimantSuppression()) {
			this.claimantService.markClaimantAsSuppressed(claimantId, disposition.getUserId());
		}

		this.claimantService.unlockClaimant(claimantId, disposition.getUserId());
	}

	private void cancelDistributionFlowForClaimant(final int claimantId, final int flowId) {
		final CancellationRequest cancellationRequest = new CancellationRequestBuilder().flow(flowId)
			.reference(claimantId)
			.build();
		this.distributionClient.cancel(cancellationRequest);
	}

	private ClaimantReferralDto appendReferralDetails(ClaimantReferralDto claimantReferralDto) {
		if (claimantReferralDto.getReferrerClaimantId() != 0) {
			claimantReferralDto.setReferrerClaimantName(this.claimantService.getClaimantById(claimantReferralDto.getReferrerClaimantId()).getFullName());
		}
		claimantReferralDto.setCreatedByAgentName(this.userService.getById(claimantReferralDto.getCreatedByAgentId()).getFullName());

		return claimantReferralDto;
	}

}
