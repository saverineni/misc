package com.leadx.claimant.claimantservice;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.leadx.claimant.client.ClaimantReferralDto;
import com.leadx.lib.utl.JodaUtils;

@Component
public class ClaimantReferralConverter implements Converter<ClaimantReferral, ClaimantReferralDto> {
	@Override
	public ClaimantReferralDto convert(final ClaimantReferral source) {
		if ( source == null ) {
			return null;
		}
		
		return new ClaimantReferralDto(source.getId(),
			source.getProductTypeId(),
			source.getReferrerClaimantId(),
			source.getReferralClaimantId(),
			JodaUtils.localDateTimeToBritishDateFormatOrNull(source.getCreatedDateTime()),
			source.getCreatedByAgentId(),
			source.getDiallerReferenceId());
	}
}
