package com.leadx.claimant.lead;

import org.apache.camel.ProducerTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.leadx.claimant.client.ClaimantLead;
import com.leadx.claimant.client.MethodOfContact;
import com.leadx.claimant.selleraccountservice.SellerAccount;
import com.leadx.claimant.selleraccountservice.SellerAccountService;
import com.leadx.lib.utl.json.JsonUtils;
import com.leadx.services.claims.client.ClaimRequest;
import com.leadx.services.claims.client.ClaimRequest.Claimant;

@Component
public class CreateClaimsProcessor {
	
	@Autowired
	private SellerAccountService sellerAccountService;

	@Autowired
	private ProducerTemplate producerTemplate;

	protected static final String CLAIMANT_TCG_CLAIMS_QUEUE = "jms:claimant-tcg-leads-with-claims";

	public ClaimantLead createClaims(final ClaimantLead claimantLead) {
		final ClaimRequest claimRequest = claimantLead.getClaimRequest();

		final SellerAccount sellerAccount = this.sellerAccountService.getByAccountId(claimRequest.getSellerAccountId());
		final MethodOfContact methodOfContact = sellerAccount.getMethodOfContact();

		if (MethodOfContact.esignature.equals(methodOfContact) && !claimRequest.getAgreements().isEmpty()) {
			ClaimRequest.Agreement agreement = claimRequest.getAgreements().get(0);
			if (agreement.getClaimId() == 0){
				this.producerTemplate.sendBody(CLAIMANT_TCG_CLAIMS_QUEUE, JsonUtils.serialize(claimantLead, false));
			}
		}
		return claimantLead;
	}


}
