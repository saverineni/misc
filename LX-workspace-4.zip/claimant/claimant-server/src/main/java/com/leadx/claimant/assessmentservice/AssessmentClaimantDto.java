package com.leadx.claimant.assessmentservice;

import com.leadx.claimant.client.ClaimantDto;


public class AssessmentClaimantDto extends ClaimantDto{
	private String sellerAccountDisplayName;

	public AssessmentClaimantDto(final ClaimantDto claimantDto, String name) {
		this.sellerAccountDisplayName = name;
		this.setId(claimantDto.getId());
		this.setLeadId(claimantDto.getLeadId());
		this.setSellerAccountId(claimantDto.getSellerAccountId());
		this.setSellerCompanyId(claimantDto.getSellerCompanyId());
		this.setTitle(claimantDto.getTitle());
		this.setForename(claimantDto.getForename());
		this.setMiddleName(claimantDto.getMiddleName());
		this.setSurname(claimantDto.getSurname());
		this.setPreviousSurname(claimantDto.getPreviousSurname());
		this.setDob(claimantDto.getDob());
		this.setAddressId(claimantDto.getAddressId());
		this.setHomeTelephone(claimantDto.getHomeTelephone());
		this.setMobileTelephone(claimantDto.getMobileTelephone());
		this.setAlternativeTelephone(claimantDto.getAlternativeTelephone());
		this.setWorkTelephone(claimantDto.getWorkTelephone());
		this.setEmail(claimantDto.getEmail());
		this.setLockedFromDialler(claimantDto.getLockedFromDialler());
		this.setSuppressedDateTime(claimantDto.getSuppressedDateTime());
		this.setCreatedDateTime(claimantDto.getCreatedDateTime());
		this.setUpdateDateTime(claimantDto.getUpdateDateTime());
		this.setOtherNames(claimantDto.getOtherNames());
		this.setAdditionalPreviousNames(claimantDto.getAdditionalPreviousNames());
		this.setUnpresentedCheque(claimantDto.getUnpresentedCheque());
		this.setClaimantExecutor(claimantDto.getClaimantExecutor());
	}

	public String getSellerAccountDisplayName() {
		return this.sellerAccountDisplayName;
	}

	public void setSellerAccountDisplayName(final String name) {
		this.sellerAccountDisplayName = name;
	}
}
