package com.leadx.claimant.claimantservice;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.leadx.claimant.client.ClaimantOtherNameDto;
import com.leadx.hibernate.domain.BaseIntegerDomain;

@Entity
@Table(name = "claimant_other_name")
public class ClaimantOtherName extends BaseIntegerDomain{
	
	private static final long serialVersionUID = 7018779712816060908L;
	
	private String otherName;
	private boolean isDeleted;
	
	public ClaimantOtherName() {
		
	}

	public ClaimantOtherName(final Integer id, final String otherName, final boolean isDeleted) {
		setId(id);
		this.otherName = otherName;
		this.isDeleted = isDeleted;
	}
	
	public String getOtherName() {
		return this.otherName;
	}

	public void setOtherName(String otherName) {
		this.otherName = otherName;
	}

	public boolean getIsDeleted() {
		return this.isDeleted;
	}

	public void setIsDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public static ClaimantOtherName toDto(final ClaimantOtherNameDto otherNames) {
		ClaimantOtherName claimantOtherNames = new ClaimantOtherName(otherNames.getId() == 0 ? null : otherNames.getId(), otherNames.getOtherName(), otherNames.getIsDeleted());
		claimantOtherNames.setVersion(otherNames.getVersion());
		
		return claimantOtherNames;
	}
	
	public static ClaimantOtherNameDto fromDto(final ClaimantOtherName otherName) {
		ClaimantOtherNameDto claimantOtherNamesDto = new ClaimantOtherNameDto(otherName.getId(), otherName.getOtherName(), otherName.getIsDeleted(), otherName.getVersion());
		
		return claimantOtherNamesDto;
	}
	
	@Override
	public boolean equals(final Object obj) {
		return deepEquals(obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean deepEquals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

}
