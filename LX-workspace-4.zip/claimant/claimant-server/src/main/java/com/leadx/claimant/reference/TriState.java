package com.leadx.claimant.reference;

import static java.util.Objects.isNull;

import org.apache.commons.lang3.StringUtils;

import com.leadx.lib.domain.PersistableEnum;

public enum TriState implements PersistableEnum {

	YES("Yes", "yes"),

	NO("No", "no"),

	UNSURE("Unsure", "unsure");

	private String prettyName;
	private String internalName;

	TriState(final String prettyName, final String internalName) {
		this.internalName = internalName;
		this.prettyName = prettyName;
	}

	public static TriState fromValue(final String input) throws IllegalArgumentException {
		if (StringUtils.isEmpty(input)) {
			return null;
		}

		for (final TriState triStateOption : values()) {
			if (triStateOption.internalName.equals(input)) {
				return triStateOption;
			}
		}

		throw new IllegalArgumentException("Could not map value [" + input + "] to TriState");
	}

	public static TriState fromBoolean(final Boolean input) {
		if (null == input) {
			return null;
		}

		return input
				? TriState.YES
				: TriState.NO;
	}

	public Boolean toBoolean() {
		return this.equals(TriState.YES);
	}

	public Boolean isYes() {
		return this.equals(TriState.YES);
	}
	
	public Boolean isNo() {
		return this.equals(TriState.NO);
	}
	
	public Boolean isNotYes() {
		return !this.equals(TriState.YES);
	}
	
	@Override
	public String toValue() {
		return this.internalName;
	}

	@Override
	public String toPrettyString() {
		return this.prettyName;
	}

	public static String toValue(final TriState triState) {
		if (isNull(triState)) {
			return null;
		}
		return triState.toValue();
	}

	public static Boolean isNo(final TriState triState) {
		if (isNull(triState)) {
			return false;
		}
		
		return triState.isNo();
	}
	
	public static Boolean isNotYes(final TriState triState) {
		if (isNull(triState)) {
			return true;
		}
		return triState.isNotYes();
	}
}
