package com.leadx.claimant.callallocationservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Type;
import org.joda.time.LocalDateTime;

import com.leadx.hibernate.domain.BaseIntegerDomain;
import com.leadx.lib.utl.JodaUtils;

@Entity
@Table(name = "claimant_group_allocation")
public class ClaimantGroupAllocation extends BaseIntegerDomain {

	private static final long serialVersionUID = 8322444823264251520L;

	@Column(name = "FK_ClaimantID")
	private int claimantId;

	@Column(name = "CallReason")
	private String callReason;

	@Column(name = "CallReasonGroup")
 	private String callReasonGroup;

	@Type(type = "local_date_time_not_null")
	@Column(name = "CallGroupAllocationDateTime", updatable = false, insertable = false)
	private LocalDateTime callGroupAllocationDateTime;

	private boolean isDeleted;

    @Override
    public boolean equals(final Object object) {
        return EqualsBuilder.reflectionEquals(this, object);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }

    @Override
    public boolean deepEquals(final Object object) {
        return equals(object);
    }

	public ClaimantGroupAllocation() {
		// do nothing
	}

    public ClaimantGroupAllocation(Integer claimantId, String callReason, String callReasonGroup) {
        this.claimantId = claimantId;
        this.callReason = callReason;
        this.callReasonGroup = callReasonGroup;
        this.callGroupAllocationDateTime = JodaUtils.newCurrentDateTime();
    }

    public ClaimantGroupAllocation(Integer claimantId, String callReason, String callReasonGroup, LocalDateTime callGroupAllocationDateTime) {
        this.claimantId = claimantId;
        this.callReason = callReason;
        this.callReasonGroup = callReasonGroup;
        this.callGroupAllocationDateTime = callGroupAllocationDateTime;
    }

    public int getClaimantId() {
        return this.claimantId;
	}

	public void setClaimantID(int claimantId) {
		this.claimantId = claimantId;
	}

	public String getCallReason() {
		return this.callReason;
	}

	public void setCallReason(String callReason) {
		this.callReason = callReason;
	}

	public String getCallReasonGroup() {
		return this.callReasonGroup;
	}

	public void setCallReasonGroup(String callReasonGroup) {
		this.callReasonGroup = callReasonGroup;
	}

	public LocalDateTime getCallGroupAllocationDateTime() {
		return this.callGroupAllocationDateTime;
	}

	public boolean getIsDeleted() {
		return this.isDeleted;
	}

	public void setIsDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}


}
