package com.leadx.claimant.calllogservice;

import java.sql.Time;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.leadx.claimant.client.CallLogDto;
import com.leadx.claimant.client.CallType;

@Service("callLogService")
public class CallLogService {

	private static final Logger LOG = LoggerFactory.getLogger(CallLogService.class);

	@Autowired
	private CallLogRepository callLogRepository;

	@Autowired
	private Converter<CallLog, CallLogDto> callLogConverter;

	@Transactional
	public Boolean saveCallLog(final CallLog callLog) {
		final int diallerReferenceId = callLog.getDiallerReferenceId();
		final CallType callType = callLog.getCallType();
		//0 diallerRefId check copied from TCG. Not sure if needed.
		if(0 == diallerReferenceId || this.callLogRepository.isDiallerReferenceUnique(diallerReferenceId, callType))
		{
			this.callLogRepository.saveCallLog(callLog);
			return true;
		}
		return false;
	}

	@Transactional
	public Boolean saveCallLogNoConstraints(final CallLog callLog) {
		LOG.info("Saving the call log for claimant {} created during {} call", callLog.getClaimantId(), callLog.getCallType().getName());
		this.callLogRepository.saveCallLog(callLog);
		return true;
	}

	@Transactional
	public List<CallLogDto> findCallLogsForClaimant(final int claimantId) {
		final List<CallLog> callList = this.callLogRepository.findCallLogsForClaimant(claimantId);
		final List<Time> callDurations = this.callLogRepository.getCallDurationForClaimant(claimantId);
		final List<CallLogDto> callLogDtoList = Lists.newArrayList();
		for(int i = 0; i < callList.size(); i++){
			final CallLogDto convertedLog = this.callLogConverter.convert(callList.get(i));
			convertedLog.setCallDuration(callDurations.get(i).toString());
			callLogDtoList.add(convertedLog);
		}
		return callLogDtoList;
	}
}