package com.leadx.claimant.claimantservice;

import com.leadx.lib.domain.PersistableEnum;

public enum ClaimantInteractionType implements PersistableEnum {

	NOTE("Note", "note"),

	EVENT("Event", "event");
	
	private String prettyName;
	private String internalName;
	
	private ClaimantInteractionType(final String prettyName, final String internalName) {
		this.internalName = internalName;
		this.prettyName = prettyName;
	}
	
	@Override
	public String toValue() {
		return this.internalName;
	}

	@Override
	public String toPrettyString() {
		return this.prettyName;
	}

}
