package com.leadx.claimant.changelogservice;

public class DefaultStrategy implements PersistanceStrategy {

	public static final PersistanceStrategy INSTANCE = new DefaultStrategy();

	@Override
	public String process(final String originalVal) {
		return originalVal;
	}

}
