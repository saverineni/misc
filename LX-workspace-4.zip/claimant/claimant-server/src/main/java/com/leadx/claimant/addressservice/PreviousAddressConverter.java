package com.leadx.claimant.addressservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.leadx.claimant.client.AddressDto;
import com.leadx.claimant.client.PreviousAddressDto;
import com.leadx.lib.utl.JodaUtils;

@Component("previousAddressConverter")
public class PreviousAddressConverter implements Converter<PreviousAddress, PreviousAddressDto> {

	@Autowired
	private Converter<Address, AddressDto> addressConverter;
	
	@Override
	public PreviousAddressDto convert(final PreviousAddress source) {
		return new PreviousAddressDto(source.getId(),
										source.getClaimantId(),
										this.addressConverter.convert(source.getAddress()),
										source.getFromCurrent(),
										JodaUtils.localDateTimeToBritishDateFormatOrNull(source.getDeletedDateTime()),
										source.getFkUserIdDeletedBy());
	}
	
}