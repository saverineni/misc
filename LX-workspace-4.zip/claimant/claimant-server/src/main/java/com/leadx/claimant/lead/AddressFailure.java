package com.leadx.claimant.lead;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Type;
import org.joda.time.LocalDateTime;

import com.leadx.hibernate.domain.BaseIntegerDomain;

@Entity
@Table(name = "address_verification_failures")
public class AddressFailure extends BaseIntegerDomain {

	private static final long serialVersionUID = 3429126149485708562L;

	@Column(name = "FK_ClaimantID")
	private int claimantId;

	@Column(name = "FK_AddressID")
	private int addressId;

	@Enumerated(EnumType.STRING)
	private AddressFailureStatus status;

	@Type(type = "local_date_time_not_null")
	private LocalDateTime createdDateTime;

	@Column(name = "FK_UserID_Updated")
	private int userIdUpdated;

	@Type(type = "local_date_time_not_null")
	private LocalDateTime updatedDateTime;

	public AddressFailure() {
	}

	public AddressFailure(int claimantId, int addressId, AddressFailureStatus status, LocalDateTime createdDateTime) {
		this.claimantId = claimantId;
		this.addressId = addressId;
		this.status = status;
		this.createdDateTime = createdDateTime;
	}

	public AddressFailure(int claimantId, int addressId, AddressFailureStatus status, LocalDateTime createdDateTime, int userIdUpdated, LocalDateTime updatedDateTime) {
		this.claimantId = claimantId;
		this.addressId = addressId;
		this.status = status;
		this.createdDateTime = createdDateTime;
		this.userIdUpdated = userIdUpdated;
		this.updatedDateTime = updatedDateTime;
	}

	public int getClaimantId() {
		return this.claimantId;
	}

	public void setClaimantId(int claimantId) {
		this.claimantId = claimantId;
	}

	public int getUserIdUpdated() {
		return this.userIdUpdated;
	}

	public void setUserIdUpdated(int userIdUpdated) {
		this.userIdUpdated = userIdUpdated;
	}

	public int getAddressId() {
		return this.addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public AddressFailureStatus getStatus() {
		return this.status;
	}

	public void setStatus(AddressFailureStatus status) {
		this.status = status;
	}

	public LocalDateTime getCreatedDateTime() {
		return this.createdDateTime;
	}

	public void setCreatedDateTime(LocalDateTime createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public LocalDateTime getUpdatedDateTime() {
		return this.updatedDateTime;
	}

	public void setUpdatedDateTime(LocalDateTime updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

	@Override
	public boolean equals(final Object object) {
		return EqualsBuilder.reflectionEquals(this, object);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean deepEquals(final Object object) {
		return equals(object);
	}
}
