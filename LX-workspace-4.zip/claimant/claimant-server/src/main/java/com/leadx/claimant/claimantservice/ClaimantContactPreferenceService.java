package com.leadx.claimant.claimantservice;

import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Sets.newLinkedHashSet;
import static com.leadx.claimant.claimantservice.ClaimantInteraction.newEvent;
import static java.util.Objects.nonNull;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.leadx.claimant.callallocationservice.TelephonyHelper;
import com.leadx.claimant.user.User;
import com.leadx.claimant.user.UserService;
import com.leadx.services.client.TcgProduct;
import com.leadx.services.distribution.client.CancellationRequest;
import com.leadx.services.distribution.client.DistributionClient;

@Service
public class ClaimantContactPreferenceService {
	private static final Logger LOG = LoggerFactory.getLogger(ClaimantContactPreferenceService.class);

	@Autowired
	private ClaimantContactPreferenceRepository claimantContactPreferenceRepository;

	@Autowired
	private ClaimantInteractionRepository claimantInteractionRepository;

	@Autowired
	private UserService userService;

	@Autowired
	private TelephonyHelper telephonyHelper;

	@Autowired
	private DistributionClient distributionClient;

	protected static final int WELCOME_EMAIL_FLOW_ID = 30;
	protected static final int WELCOME_SMS_FLOW_ID = 31;
	protected static final int PACK_SMS_OUT_FLOW_ID = 33;
	protected static final int PACK_OUT_EMAIL_FLOW_ID_PPI = 35;
	protected static final int PACK_OUT_EMAIL_FLOW_ID_PBA = 36;

	@Transactional(readOnly = true)
	public ClaimantContactPreference getById(final int id) {
		LOG.debug("Loading claimant contact preference(s) for ID " + id);
		return this.claimantContactPreferenceRepository.getById(id);
	}

	@Transactional(readOnly = true)
	public ClaimantContactPreference getByClaimantId(final int claimantId) {
		LOG.debug("Loading claimant contact preference(s) for claimant " + claimantId);
		return this.claimantContactPreferenceRepository.getByClaimantId(claimantId);
	}

	@Transactional
	public void saveOrUpdate(final ClaimantContactPreference contactPreference) {
		final int claimantId = contactPreference.getClaimantId();
		final ClaimantContactPreference existing = this.claimantContactPreferenceRepository.getByClaimantId(claimantId);

		if(nonNull(existing)){
			this.claimantContactPreferenceRepository.evict(existing);
		}

		this.claimantContactPreferenceRepository.saveOrUpdate(contactPreference);
		cancelContactRequests(contactPreference);
		addOptOutEvent(existing, contactPreference);
		addOptInEvent(existing, contactPreference);
	}

	private void addOptOutEvent(final ClaimantContactPreference existing, final ClaimantContactPreference updated){
		final Set<ContactMethod> optedOutContactMethods = getContactMethods(existing, updated);

		if(!optedOutContactMethods.isEmpty()){
			final User user = this.userService.getById(updated.getUserIdUpdated());
			final String optedOutMethods = buildContactMethodList(optedOutContactMethods);
			final String content = String.format("Claimant has opted out of the following methods of contact: %s", optedOutMethods);

			this.claimantInteractionRepository.save(newEvent(updated.getClaimantId(), null, user, content, Source.CLAIMANT));
		}
	}

	private void addOptInEvent(final ClaimantContactPreference existing, final ClaimantContactPreference updated) {
		final Set<ContactMethod> optedInContactMethods = getOptInContactMethods(existing, updated);

		if (!optedInContactMethods.isEmpty()) {
			final User user = this.userService.getById(updated.getUserIdUpdated());

			final String content = hasOptedInAll(existing, updated) ?
					"Claimant has opted in to all contact preferences" :
					String.format("Claimant has opted in to the following methods of contact: %s", buildContactMethodList(optedInContactMethods));

			this.claimantInteractionRepository.save(newEvent(updated.getClaimantId(), null, user, content, Source.CLAIMANT));
		}
	}

	private String buildContactMethodList(final Set<ContactMethod> contactMethods) {
		return contactMethods.stream()
				.map(ContactMethod::getLabel)
				.collect(Collectors.joining(","));
	}

	private static Set<ContactMethod> getContactMethods(final ClaimantContactPreference existing, final ClaimantContactPreference updated){
		final Set<ContactMethod> optedOutMethods = newLinkedHashSet();

		if(hasOptedOutOfTelephone(existing, updated)){
			optedOutMethods.add(ContactMethod.Telephone);
		}

		if(hasOptedOutOfEmail(existing, updated)){
			optedOutMethods.add(ContactMethod.Email);
		}

		if(hasOptedOutOfSms(existing, updated)){
			optedOutMethods.add(ContactMethod.SMS);
		}

		if(hasOptedOutOfMarketing(existing, updated)){
			optedOutMethods.add(ContactMethod.Marketing);
		}

		return optedOutMethods;
	}

	private static Set<ContactMethod> getOptInContactMethods(final ClaimantContactPreference existing, final ClaimantContactPreference updated) {
		final Set<ContactMethod> optedInMethods = newLinkedHashSet();

		if (hasOptedInTelephone(existing, updated)) {
			optedInMethods.add(ContactMethod.Telephone);
		}

		if (hasOptedInEmail(existing, updated)) {
			optedInMethods.add(ContactMethod.Email);
		}

		if (hasOptedInSms(existing, updated)) {
			optedInMethods.add(ContactMethod.SMS);
		}

		if (hasOptedInMarketing(existing, updated)) {
			optedInMethods.add(ContactMethod.Marketing);
		}

		return optedInMethods;
	}

	private static boolean hasOptedOutOfTelephone(final ClaimantContactPreference existing, final ClaimantContactPreference updated){
		if(nonNull(existing)){
			return existing.getTelephoneOptIn() && !updated.getTelephoneOptIn();
		}

		return !updated.getTelephoneOptIn();
	}

	private static boolean hasOptedInTelephone(final ClaimantContactPreference existing, final ClaimantContactPreference updated) {
		return nonNull(existing) && !existing.getTelephoneOptIn() && updated.getTelephoneOptIn();
	}

	private static boolean hasOptedOutOfEmail(final ClaimantContactPreference existing, final ClaimantContactPreference updated){
		if(nonNull(existing)){
			return existing.getEmailOptIn() && !updated.getEmailOptIn();
		}

		return !updated.getEmailOptIn();
	}

	private static boolean hasOptedInEmail(final ClaimantContactPreference existing, final ClaimantContactPreference updated) {
		return nonNull(existing) && !existing.getEmailOptIn() && updated.getEmailOptIn();
	}

	private static boolean hasOptedOutOfSms(final ClaimantContactPreference existing, final ClaimantContactPreference updated){
		if(nonNull(existing)){
			return existing.getSmsOptIn() && !updated.getSmsOptIn();
		}

		return !updated.getSmsOptIn();
	}

	private static boolean hasOptedInSms(final ClaimantContactPreference existing, final ClaimantContactPreference updated) {
		return nonNull(existing) && !existing.getSmsOptIn() && updated.getSmsOptIn();
	}

	private static boolean hasOptedOutOfMarketing(final ClaimantContactPreference existing, final ClaimantContactPreference updated){
		if(nonNull(existing)){
			return existing.getMarketingMailingOptIn() && !updated.getMarketingMailingOptIn();
		}

		return !updated.getMarketingMailingOptIn();
	}

	private static boolean hasOptedInMarketing(final ClaimantContactPreference existing, final ClaimantContactPreference updated) {
		return nonNull(existing) && !existing.getMarketingMailingOptIn() && updated.getMarketingMailingOptIn();
	}

	private static boolean hasOptedInAll(final ClaimantContactPreference existing, final ClaimantContactPreference updated) {
		return hasOptedInTelephone(existing, updated) &&
				hasOptedInEmail(existing, updated) &&
				hasOptedInSms(existing, updated) &&
				hasOptedInMarketing(existing, updated);
	}

	private void cancelContactRequests(final ClaimantContactPreference contactPreference){
		final int claimantId = contactPreference.getClaimantId();

		if(!contactPreference.getTelephoneOptIn()){
			telephonyHelper.cancelCalls(claimantId, contactPreference.getUserIdUpdated(), TcgProduct.PPI);
			telephonyHelper.cancelCalls(claimantId, contactPreference.getUserIdUpdated(), TcgProduct.PBA);
			telephonyHelper.cancelCalls(claimantId, contactPreference.getUserIdUpdated(), TcgProduct.COMBINED);
		}

		if(!contactPreference.getSmsOptIn()){
			sendDistributionCancellation(claimantId, newArrayList(WELCOME_SMS_FLOW_ID, PACK_SMS_OUT_FLOW_ID));
		}

		if(!contactPreference.getEmailOptIn()){
			sendDistributionCancellation(claimantId, newArrayList(WELCOME_EMAIL_FLOW_ID, PACK_OUT_EMAIL_FLOW_ID_PPI, PACK_OUT_EMAIL_FLOW_ID_PBA));
		}
	}

	private void sendDistributionCancellation(final int claimantId, final List<Integer> flowIds) {
		flowIds.forEach(flowId -> {
			final CancellationRequest request = new CancellationRequest.CancellationRequestBuilder()
					.reference(claimantId)
					.flow(flowId)
					.build();
			this.distributionClient.cancel(request);
		});
	}

	private enum ContactMethod {
		Telephone("Telephone"),
		Email("Email"),
		SMS("SMS"),
		Marketing("Marketing/Other products or services");

		private String label;

		public String getLabel() {
			return label;
		}

		ContactMethod(final String value) {
			this.label = value;
		}
	}
}
