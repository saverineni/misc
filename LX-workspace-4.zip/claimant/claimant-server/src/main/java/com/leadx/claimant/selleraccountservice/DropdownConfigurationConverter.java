package com.leadx.claimant.selleraccountservice;

import static com.leadx.lib.utl.ObjectUtils.isNull;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.leadx.claimant.client.DropdownConfigurationDto;

@Component("dropdownConfigurationConverter")
public class DropdownConfigurationConverter implements Converter<DropdownConfiguration, DropdownConfigurationDto>  {

	@Override
	public DropdownConfigurationDto convert(final DropdownConfiguration source) {
		if (isNull(source)) {
			return null;
		}
		
		final DropdownConfigurationDto dto = 
				new DropdownConfigurationDto(source.getFieldName(), source.getFieldValue(), source.getFieldOrder());
		
		return dto;
	}
}