package com.leadx.claimant.claimantservice;

import java.util.Set;

import com.leadx.claimant.reference.VulnerableDetailTriState;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;

import com.leadx.claimant.reference.FormalDebtArrangement;
import com.leadx.claimant.reference.TriState;
import com.leadx.claimant.client.VulnerabilityCategory;

public class ClaimantBuilder {
	private int id;
	private int leadId;
	private int sellerAccountId;
	private int sellerCompanyId;
	private String title;
	private String forename;
	private String middleName;
	private String surname;
	private String previousSurname;
	private LocalDate dob;
	private int addressId;
	private String homeTelephone;
	private String mobileTelephone;
	private String alternativeTelephone;
	private String workTelephone;
	private String email;
	private String nationalInsuranceNumber;
	private boolean lockedFromDialler;
	private LocalDateTime lockedFromDiallerUpdateDateTime;
	private int lockedFromDiallerUpdateUserId;
	private boolean rightToBeForgotten;
	private LocalDate rightToBeForgottenNewestClosedClaimDate;
	private int rightToBeForgottenUpdateUserId;
	private LocalDateTime rightToBeForgottenUpdateDateTime;
	private boolean vulnerableCustomer;
	private LocalDateTime vulnerableCustomerUpdateDateTime;
	private int vulnerableCustomerUpdateUserId;
	private LocalDate vulnerableCustomerReviewDate;
	private boolean incorrectAddress;
	private LocalDateTime incorrectAddressUpdateDateTime;
	private boolean freePpi;
	private LocalDateTime suppressedDateTime;
	private LocalDateTime createdDateTime;
	private LocalDateTime updateDateTime;
	private Set<ClaimantOtherName> otherNames;
	private Set<ClaimantAdditionalPreviousName> additionalPreviousNames;
	private Set<ClaimantPreviousEmail> previousEmails;
	private TriState formalDebtArrangement;
	private Set<FormalDebtArrangement> formalDebtArrangementType;
	private int ivaCompanyId;
	private String ivaReference;
	private TriState informalDebtArrangement;
	private int debtManagementCompanyId;
	private String debtManagementReference;
	private ClaimantUnpresentedCheque claimantUnpresentedCheque;
	private ClaimantExecutor claimantExecutor;
	private Boolean hasVulnerability;
	private Set<VulnerabilityCategory> vulnerabilityCategories;
	private VulnerableDetailTriState canStoreVulnerabilityDetail;
	private String vulnerabilityDetail;

	public ClaimantBuilder setId(int id) {
		this.id = id;
		return this;
	}

	public ClaimantBuilder setLeadId(int leadId) {
		this.leadId = leadId;
		return this;
	}

	public ClaimantBuilder setSellerAccountId(int sellerAccountId) {
		this.sellerAccountId = sellerAccountId;
		return this;
	}

	public ClaimantBuilder setSellerCompanyId(int sellerCompanyId) {
		this.sellerCompanyId = sellerCompanyId;
		return this;
	}

	public ClaimantBuilder setTitle(String title) {
		this.title = title;
		return this;
	}

	public ClaimantBuilder setForename(String forename) {
		this.forename = forename;
		return this;
	}

	public ClaimantBuilder setMiddleName(String middleName) {
		this.middleName = middleName;
		return this;
	}

	public ClaimantBuilder setSurname(String surname) {
		this.surname = surname;
		return this;
	}

	public ClaimantBuilder setPreviousSurname(String previousSurname) {
		this.previousSurname = previousSurname;
		return this;
	}

	public ClaimantBuilder setDob(LocalDate dob) {
		this.dob = dob;
		return this;
	}

	public ClaimantBuilder setAddressId(int addressId) {
		this.addressId = addressId;
		return this;
	}

	public ClaimantBuilder setHomeTelephone(String homeTelephone) {
		this.homeTelephone = homeTelephone;
		return this;
	}

	public ClaimantBuilder setMobileTelephone(String mobileTelephone) {
		this.mobileTelephone = mobileTelephone;
		return this;
	}

	public ClaimantBuilder setAlternativeTelephone(String alternativeTelephone) {
		this.alternativeTelephone = alternativeTelephone;
		return this;
	}

	public ClaimantBuilder setWorkTelephone(String workTelephone) {
		this.workTelephone = workTelephone;
		return this;
	}

	public ClaimantBuilder setEmail(String email) {
		this.email = email;
		return this;
	}

	public ClaimantBuilder setNationalInsuranceNumber(String nationalInsuranceNumber) {
		this.nationalInsuranceNumber = nationalInsuranceNumber;
		return this;
	}

	public ClaimantBuilder setLockedFromDialler(boolean lockedFromDialler) {
		this.lockedFromDialler = lockedFromDialler;
		return this;
	}

	public ClaimantBuilder setLockedFromDiallerUpdateDateTime(LocalDateTime lockedFromDiallerUpdateDateTime) {
		this.lockedFromDiallerUpdateDateTime = lockedFromDiallerUpdateDateTime;
		return this;
	}

	public ClaimantBuilder setLockedFromDiallerUpdateUserId(int lockedFromDiallerUpdateUserId) {
		this.lockedFromDiallerUpdateUserId = lockedFromDiallerUpdateUserId;
		return this;
	}

	public ClaimantBuilder setRightToBeForgotten(boolean rightToBeForgotten) {
		this.rightToBeForgotten = rightToBeForgotten;
		return this;
	}

	public ClaimantBuilder setRightToBeForgottenNewestClosedClaimDate(LocalDate rightToBeForgottenNewestClosedClaimDate) {
		this.rightToBeForgottenNewestClosedClaimDate = rightToBeForgottenNewestClosedClaimDate;
		return this;
	}

	public ClaimantBuilder setRightToBeForgottenUpdateUserId(int rightToBeForgottenUpdateUserId) {
		this.rightToBeForgottenUpdateUserId = rightToBeForgottenUpdateUserId;
		return this;
	}

	public ClaimantBuilder setRightToBeForgottenUpdateDateTime(LocalDateTime rightToBeForgottenUpdateDateTime) {
		this.rightToBeForgottenUpdateDateTime = rightToBeForgottenUpdateDateTime;
		return this;
	}

	public ClaimantBuilder setVulnerableCustomer(boolean vulnerableCustomer) {
		this.vulnerableCustomer = vulnerableCustomer;
		return this;
	}

	public ClaimantBuilder setVulnerableCustomerUpdateDateTime(LocalDateTime vulnerableCustomerUpdateDateTime) {
		this.vulnerableCustomerUpdateDateTime = vulnerableCustomerUpdateDateTime;
		return this;
	}

	public ClaimantBuilder setVulnerableCustomerUpdateUserId(int vulnerableCustomerUpdateUserId) {
		this.vulnerableCustomerUpdateUserId = vulnerableCustomerUpdateUserId;
		return this;
	}

	public ClaimantBuilder setVulnerableCustomerReviewDate(LocalDate vulnerableCustomerReviewDate) {
		this.vulnerableCustomerReviewDate = vulnerableCustomerReviewDate;
		return this;
	}

	public ClaimantBuilder setIncorrectAddress(boolean incorrectAddress) {
		this.incorrectAddress = incorrectAddress;
		return this;
	}

	public ClaimantBuilder setIncorrectAddressUpdateDateTime(LocalDateTime incorrectAddressUpdateDateTime) {
		this.incorrectAddressUpdateDateTime = incorrectAddressUpdateDateTime;
		return this;
	}

	public ClaimantBuilder setFreePpi(boolean freePpi) {
		this.freePpi = freePpi;
		return this;
	}

	public ClaimantBuilder setSuppressedDateTime(LocalDateTime suppressedDateTime) {
		this.suppressedDateTime = suppressedDateTime;
		return this;
	}

	public ClaimantBuilder setCreatedDateTime(LocalDateTime createdDateTime) {
		this.createdDateTime = createdDateTime;
		return this;
	}

	public ClaimantBuilder setUpdateDateTime(LocalDateTime updateDateTime) {
		this.updateDateTime = updateDateTime;
		return this;
	}

	public ClaimantBuilder setOtherNames(Set<ClaimantOtherName> otherNames) {
		this.otherNames = otherNames;
		return this;
	}

	public ClaimantBuilder setAdditionalPreviousNames(Set<ClaimantAdditionalPreviousName> additionalPreviousNames) {
		this.additionalPreviousNames = additionalPreviousNames;
		return this;
	}

	public ClaimantBuilder setPreviousEmails(Set<ClaimantPreviousEmail> previousEmails) {
		this.previousEmails = previousEmails;
		return this;
	}

	public ClaimantBuilder setFormalDebtArrangement(TriState formalDebtArrangement) {
		this.formalDebtArrangement = formalDebtArrangement;
		return this;
	}

	public ClaimantBuilder setFormalDebtArrangementType(Set<FormalDebtArrangement> formalDebtArrangementType) {
		this.formalDebtArrangementType = formalDebtArrangementType;
		return this;
	}

	public ClaimantBuilder setIvaCompanyId(Integer ivaCompanyId) {
		this.ivaCompanyId = ivaCompanyId;
		return this;
	}

	public ClaimantBuilder setIvaReference(String ivaReference) {
		this.ivaReference = ivaReference;
		return this;
	}

	public ClaimantBuilder setInformalDebtArrangement(TriState informalDebtArrangement) {
		this.informalDebtArrangement = informalDebtArrangement;
		return this;
	}

	public ClaimantBuilder setDebtManagementCompanyId(Integer debtManagementCompanyId) {
		this.debtManagementCompanyId = debtManagementCompanyId;
		return this;
	}

	public ClaimantBuilder setDebtManagementReference(String debtManagementReference) {
		this.debtManagementReference = debtManagementReference;
		return this;
	}

	public ClaimantBuilder setClaimantUnpresentedCheque(ClaimantUnpresentedCheque claimantUnpresentedCheque) {
		this.claimantUnpresentedCheque = claimantUnpresentedCheque;
		return this;
	}


	public ClaimantBuilder setClaimantExecutor(ClaimantExecutor claimantExecutor) {
		this.claimantExecutor = claimantExecutor;
		return this;
	}

	public ClaimantBuilder setHasVulnerability(Boolean hasVulnerability) {
		this.hasVulnerability = hasVulnerability;
		return this;
	}

	public ClaimantBuilder setVulnerabilityCategories(Set<VulnerabilityCategory> vulnerabilityCategories) {
		this.vulnerabilityCategories = vulnerabilityCategories;
		return this;
	}

	public ClaimantBuilder setCanStoreVulnerabilityDetail(VulnerableDetailTriState canStoreVulnerabilityDetail) {
		this.canStoreVulnerabilityDetail = canStoreVulnerabilityDetail;
		return this;
	}

	public ClaimantBuilder setVulnerabilityDetail(String vulnerabilityDetail) {
		this.vulnerabilityDetail = vulnerabilityDetail;
		return this;
	}

	public Claimant createClaimant() {
		return new Claimant(id, leadId, sellerAccountId, sellerCompanyId, title, forename, middleName, surname, previousSurname, dob, addressId, homeTelephone,
				mobileTelephone, alternativeTelephone, workTelephone, email, nationalInsuranceNumber, lockedFromDialler, lockedFromDiallerUpdateDateTime, lockedFromDiallerUpdateUserId,
				rightToBeForgotten, rightToBeForgottenNewestClosedClaimDate, rightToBeForgottenUpdateUserId, rightToBeForgottenUpdateDateTime,
				vulnerableCustomer, vulnerableCustomerUpdateDateTime, vulnerableCustomerUpdateUserId, vulnerableCustomerReviewDate, incorrectAddress,
				incorrectAddressUpdateDateTime, freePpi, suppressedDateTime, createdDateTime, updateDateTime, otherNames, additionalPreviousNames,
				previousEmails, formalDebtArrangement, formalDebtArrangementType, ivaCompanyId, ivaReference, informalDebtArrangement, debtManagementCompanyId,
				debtManagementReference, claimantUnpresentedCheque, claimantExecutor, hasVulnerability, vulnerabilityCategories,
				canStoreVulnerabilityDetail, vulnerabilityDetail);
	}
}
