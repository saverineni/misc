package com.leadx.claimant.claimantservice;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.google.common.collect.Sets;
import com.leadx.claimant.client.ClaimantAdditionalPreviousNameDto;

@Component("claimantAdditionalPreviousNamesDtoConverter")
public class ClaimantAdditionalPreviousNameDtoConverter implements Converter<List<ClaimantAdditionalPreviousNameDto>, Set<ClaimantAdditionalPreviousName>>{

	@Override
	public Set<ClaimantAdditionalPreviousName> convert(List<ClaimantAdditionalPreviousNameDto> source) {
		if(source == null) {
			return Sets.newLinkedHashSet();
		}
		
		return source.stream().map(ClaimantAdditionalPreviousName::toDto).collect(Collectors.toCollection(LinkedHashSet::new));
	}
}
