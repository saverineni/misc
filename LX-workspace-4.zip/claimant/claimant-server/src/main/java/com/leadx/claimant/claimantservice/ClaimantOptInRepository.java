package com.leadx.claimant.claimantservice;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ClaimantOptInRepository {
	@Autowired
	private SessionFactory sessionFactory;

	void createOptIn(final ClaimantOptIn claimantOptIn) {
		this.sessionFactory.getCurrentSession()
			.save(claimantOptIn);
	}

	void updateOptIn(final ClaimantOptIn claimantOptIn) {
		this.sessionFactory.getCurrentSession()
			.update(claimantOptIn);
	}

	ClaimantOptIn getClaimantOptInById(final int id) {
		return (ClaimantOptIn)this.sessionFactory.getCurrentSession().get(ClaimantOptIn.class, id);
	}

	ClaimantOptIn getClaimantOptInByClaimantId(final int claimantId) {
		return (ClaimantOptIn) this.sessionFactory.getCurrentSession().createQuery("FROM ClaimantOptIn WHERE claimantId = :claimantId")
			.setInteger("claimantId", claimantId)
			.uniqueResult();
	}

	void evict(final ClaimantOptIn claimantOptIn) {
		this.sessionFactory.getCurrentSession().evict(claimantOptIn);
	}
}
