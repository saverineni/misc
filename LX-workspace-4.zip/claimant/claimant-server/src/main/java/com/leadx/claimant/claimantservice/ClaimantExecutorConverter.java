package com.leadx.claimant.claimantservice;

import com.leadx.claimant.client.ClaimantExecutorDto;
import com.leadx.lib.utl.JodaUtils;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component("claimantExecutorConverter")
public class ClaimantExecutorConverter implements Converter<ClaimantExecutor, ClaimantExecutorDto>{

	@Override
	public ClaimantExecutorDto convert(ClaimantExecutor source) {
		if (source == null) {
			return null;
		}

		return new ClaimantExecutorDto(source.getId(),
				source.getClaimantId(),
				source.getTitle(),
				source.getForename(),
				source.getMiddleName(),
				source.getSurname(),
				source.getPreviousSurname(),
				JodaUtils.localDateToBritishDateStampStringOrNull(source.getDob()),
				source.getAddressId(),
				source.getHomeTelephone(),
				source.getMobileTelephone(),
				source.getEmail(),
				JodaUtils.localDateTimeToBritishDateFormatOrNull(source.getExecutorUpdateDateTime()),
				source.getIsExecutorConfirmed(),
				JodaUtils.localDateTimeToBritishDateFormatOrNull(source.getExecutorConfirmedUpdateDateTime()),
				JodaUtils.localDateTimeToBritishDateFormatOrNull(source.getCreatedDateTime()),
				JodaUtils.localDateTimeToBritishDateFormatOrNull(source.getTimestamp()),
				source.getIsDeleted(),
				source.getVersion());
	}
}
