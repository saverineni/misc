package com.leadx.claimant.lead;

import static com.leadx.claimant.lead.AddressComparisonUtils.*;
import static com.leadx.claimant.lead.AddressVerificationResult.failure;
import static com.leadx.claimant.lead.AddressVerificationResult.success;
import static com.leadx.claimant.lead.SaveClaimantProcessor.SYSTEM_USER_ID;
import static com.leadx.lib.utl.JodaUtils.newCurrentDateTime;
import static com.leadx.lib.utl.ObjectUtils.isNotNull;
import static org.apache.commons.lang3.StringUtils.*;

import java.util.List;

import org.apache.camel.ProducerTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.leadx.claimant.addressservice.AddressConverter;
import com.leadx.claimant.addressservice.AddressService;
import com.leadx.claimant.client.ClaimantLead;
import com.leadx.claimant.selleraccountservice.SellerAccount;
import com.leadx.claimant.selleraccountservice.SellerAccountService;
import com.leadx.services.address.Address;
import com.leadx.services.address.internal.WebAddressLookupClient;

@Component
public class AddressVerificationProcessor {
	@Autowired
	AddressService addressService;

	@Autowired
	AddressConverter addressConverter;

	@Autowired
	WebAddressLookupClient webAddressLookupClient;

	@Autowired
	AddressFailureService addressFailureService;

	@Autowired
	SellerAccountService sellerAccountService;

	@Autowired
	ProducerTemplate producerTemplate;

	private static final Logger LOG = LoggerFactory.getLogger(AddressVerificationProcessor.class);
	protected static final String POST_CODE_LOOKUP_REFERENCE = "Claimant Server - Post leads";
	protected static final String CLAIMANT_TCG_LEADS_QUEUE = "jms:claimant-tcg-leads";

	public ClaimantLead process(final ClaimantLead claimantLead){
		final int claimantId = claimantLead.getClaimantId();
		com.leadx.claimant.addressservice.Address claimantAddress = this.addressService.getAddressForClaimant(claimantId);

		if (isNotNull(claimantAddress)) {
			verifyAndUpdateAddress(claimantId, false, claimantAddress);
		}

		if (shouldCreatePpiClaimant(claimantLead)) {
			createPpiClaimant(claimantId);
		}

		return claimantLead;
	}

	private boolean shouldCreatePpiClaimant(final ClaimantLead claimantLead) {
		final SellerAccount sellerAccount = this.sellerAccountService.getByAccountId(claimantLead.getClaimRequest().getSellerAccountId());
		return sellerAccount.isPost() || sellerAccount.isEmail();
	}

	private void createPpiClaimant(int claimantId){
		this.producerTemplate.sendBody(CLAIMANT_TCG_LEADS_QUEUE, claimantId);
	}

	private AddressVerificationResult getMatchingAddress(com.leadx.claimant.addressservice.Address claimantAddress, boolean switchSimilarNumbersAndLetters) {
		boolean validAddress = false;

		final String rawPostcode = claimantAddress.getPostcode();
		if (isBlank(rawPostcode)) {
			LOG.debug("Lead has no postcode so we won't attempt PAF validation");
			return failure(claimantAddress);
		}

		String postcode = cleanPostcode(rawPostcode);

		if (switchSimilarNumbersAndLetters) {
			postcode = switchSimilarNumbersAndLetters(postcode);
		}

		int excludingOrganisationMatchCount = 0;

		if(claimantAddress != null && isNotEmpty(postcode)){
			claimantAddress.setPostcode(postcode);

			List<Address> addressesForPostCode = this.webAddressLookupClient.getForPostcode(postcode, POST_CODE_LOOKUP_REFERENCE);
			for(Address pafAddress : addressesForPostCode){
				if(addressesMatch(claimantAddress, pafAddress)){
					assignAddressProperties(pafAddress, claimantAddress);
					return success(claimantAddress);
				}

				if(addressStringsMatch(claimantAddress, pafAddress)){
					assignAddressProperties(pafAddress, claimantAddress);
					return success(claimantAddress);
				}
			}

			// The following block removes the organisation name before matching, we then say its successful if only one match is found
			for (Address pafAddress : addressesForPostCode) {
				pafAddress.setOrganisationName("");
				if(addressesMatch(claimantAddress, pafAddress)){
					excludingOrganisationMatchCount++;
					assignAddressProperties(pafAddress, claimantAddress);
					validAddress = true;
					continue;
				}

				if(addressStringsMatch(claimantAddress, pafAddress)){
					excludingOrganisationMatchCount++;
					assignAddressProperties(pafAddress, claimantAddress);
					validAddress = true;
					continue;
				}
			}

			if (validAddress) {
				return success(claimantAddress, excludingOrganisationMatchCount);
			}
		}

		return failure(claimantAddress);
	}

	private void verifyAndUpdateAddress(final int claimantId, final boolean switchSimilarNumbersAndLetters, final com.leadx.claimant.addressservice.Address claimantAddress){
		final AddressVerificationResult result = getMatchingAddress(claimantAddress, switchSimilarNumbersAndLetters);

		if(result.getResult() && result.getExcludingOrganisationMatchCount() < 2 && hasPremises(result.getAddress())){
			LOG.info("Lead has a valid address. Updating pafValidatedDate for address...");
			this.addressService.updateAddressInConfinement(claimantId, result.getAddress(), SYSTEM_USER_ID);
		}else{
			if (switchSimilarNumbersAndLetters) {
				LOG.info("Lead has an invalid address. The address will be saved to address_verification_failures table");
				AddressFailure addressFailure = new AddressFailure(claimantId, claimantAddress.getId(), AddressFailureStatus.action_required, newCurrentDateTime());
				this.addressFailureService.save(addressFailure);
			} else {
				verifyAndUpdateAddress(claimantId, true, claimantAddress);
			}
		}
	}

	public AddressVerificationResult verifyAndReturnAddress(final int claimantId, final boolean switchSimilarNumbersAndLetters, final com.leadx.claimant.addressservice.Address claimantAddress){
		final AddressVerificationResult result = getMatchingAddress(claimantAddress, switchSimilarNumbersAndLetters);

		if(result.getResult() && result.getExcludingOrganisationMatchCount() < 2 && hasPremises(result.getAddress())){
			LOG.info("Lead has a valid address. Returning matched address");
			return result;
		}else{
			if (switchSimilarNumbersAndLetters) {
				return result;
			} else {
				verifyAndReturnAddress(claimantId, true, claimantAddress);
			}
		}

		return failure(claimantAddress);
	}

	private String switchSimilarNumbersAndLetters(String postcode) {
		return postcode.replace("O", "0").replace("I", "1");
	}

	private static boolean hasPremises(final com.leadx.claimant.addressservice.Address claimantAddress) {
		return isNotBlank(claimantAddress.getOrganisationName()) ||
			   isNotBlank(claimantAddress.getSubBuildingName()) ||
			   isNotBlank(claimantAddress.getBuildingName()) ||
			   isNotBlank(claimantAddress.getBuildingNumber());
	}

	private static String cleanPostcode(final String postcode) {
		final String output = stripAccents(postcode);
		output.replaceAll(regexSpecialChars, EMPTY);

		return output;
	}

	private void assignAddressProperties(final Address pafAddress, final com.leadx.claimant.addressservice.Address claimantAddress) {
		claimantAddress.setDepartmentName(defaultString(pafAddress.getDepartmentName()));
		claimantAddress.setOrganisationName(defaultString(pafAddress.getOrganisationName()));
		claimantAddress.setSubBuildingName(defaultString(pafAddress.getSubBuildingName()));
		claimantAddress.setBuildingName(defaultString(pafAddress.getBuildingName()));
		claimantAddress.setBuildingNumber(defaultString(pafAddress.getBuildingNumber()));
		claimantAddress.setDependentThoroughfare(defaultString(pafAddress.getDependentThoroughfare()));
		claimantAddress.setThoroughfare(defaultString(pafAddress.getThoroughfare()));
		claimantAddress.setDoubleDependentLocality(defaultString(pafAddress.getDoubleDependentLocality()));
		claimantAddress.setDependentLocality(defaultString(pafAddress.getDependentLocality()));
		claimantAddress.setTown(defaultString(pafAddress.getTown()));
		claimantAddress.setPostcode(defaultString(pafAddress.getPostcode()));
	}

}
