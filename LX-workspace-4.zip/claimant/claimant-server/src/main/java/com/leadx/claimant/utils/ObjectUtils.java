package com.leadx.claimant.utils;

public class ObjectUtils {

	public static boolean allNotNull(final Object... objects) {
		for (final Object obj : objects) {
			if (isNull(obj)) {
				return false;
			}
		}
		return true;
	}

	public static boolean allNull(final Object... objects) {
		for (final Object obj : objects) {
			if (isNotNull(obj)) {
				return false;
			}
		}
		return true;
	}

	public static boolean isNotNull(final Object object) {
		return null != object;
	}

	public static boolean isNull(final Object object) {
		return null == object;
	}

	public static <T> T valueOrDefault(final T string, final T defaultString) {
		return isNull(string)
				? defaultString
				: string;
	}

	public static boolean noneOf(final boolean... objs) {

		for (final boolean obj : objs) {
			if (obj) {
				return false;
			}
		}
		return true;
	}

	public static boolean anyOf(final boolean... objs) {

		for (final boolean obj : objs) {
			if (obj) {
				return true;
			}
		}
		return false;
	}

}
