package com.leadx.claimant.claimantservice;

/**
 * Created by matt.helliwell on 26/11/2014.
 */
public class ClaimantReferralListConverter {
}
