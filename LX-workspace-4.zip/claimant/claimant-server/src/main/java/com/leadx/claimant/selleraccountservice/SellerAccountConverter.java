package com.leadx.claimant.selleraccountservice;

import static com.leadx.lib.utl.ObjectUtils.isNull;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.leadx.claimant.client.LeadTypeDto;
import com.leadx.claimant.client.ProductTypeDto;
import com.leadx.claimant.client.SellerAccountDto;

@Component("sellerAccountConverter")
public class SellerAccountConverter implements Converter<SellerAccount, SellerAccountDto>  {

	@Override
	public SellerAccountDto convert(final SellerAccount source) {
		if (isNull(source)) {
			return null;
		}
		final ProductTypeDto dto = new ProductTypeDto(source.getProductType().getId(), source.getProductType().getName(), true);
		final LeadTypeDto leadTypeDto = null != source.getLeadType() ?
				new LeadTypeDto(source.getLeadType().getId(), source.getLeadType().getName()) :
				null;

		final SellerAccountDto converted = new SellerAccountDto(source.getAccountId(), source.getGpSellerAccount(), source.getName(), source.getDisplayName(), source.getSourceDescription(),
				source.getMethodOfContact(), source.getApplicationLogo(), source.getPackType(), source.getDistributeAppointmentReminder(), source.getAssessmentCallReasonGroup(),
				source.getAssessmentInitialSmsMessageScript(), source.getAssessmentInitialEmailMessageScript(), source.getEmailIconImageName(), source.getInboundNumbers(), dto, source.getFreePpi(), leadTypeDto);
		converted.setId(source.getId());
		return converted;
	}
}
