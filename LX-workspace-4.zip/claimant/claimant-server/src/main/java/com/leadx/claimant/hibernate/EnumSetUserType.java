package com.leadx.claimant.hibernate;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.type.StringType;
import org.hibernate.usertype.ParameterizedType;
import org.hibernate.usertype.UserType;

import com.google.common.collect.Sets;
import com.leadx.lib.domain.PersistableEnum;
import com.leadx.lib.hibernate.AbstractImmutableUserType;

/**
 * Converts to and from a EnumSet to String.
 *
 * Enum Class should extend PersistableEnum
 *
 * The parameter value for 'enum' as to be set with Class name prefixed with the package folder it belongs to
 *
 * e.g Complaint is Enum Class and it is in pba folder. So the enum value is set 'pba.Complaint'.
 *
 *
 */
public class EnumSetUserType<T extends PersistableEnum> extends AbstractImmutableUserType implements UserType, ParameterizedType {

	private Class<T> enumClass;

	public void setParameterValues(Properties parameters) {
		String enumClassName = "com.leadx.claimant." + parameters.getProperty("enum");

		try {
			enumClass = (Class<T>) Class.forName(enumClassName);
		} catch (ClassNotFoundException cnfe) {
			throw new HibernateException("Enum class not found", cnfe);
		}
	}

	@Override
	public int[] sqlTypes() {
		return new int[] { StringType.INSTANCE.sqlType() };
	}

	@Override
	public Class<?> returnedClass() {
		return Set.class;
	}

	@Override
	public Object nullSafeGet(final ResultSet rs, final String[] names, final SessionImplementor session, final Object owner) throws SQLException {
		if(rs == null){
			return Sets.newHashSet();
		}
		String enumString = rs.getString(names[0]);
		if (StringUtils.isBlank(enumString)) {
			return Sets.newHashSet();
		}
		final String[] strings = enumString.split(",");
		final Set<T> returnValue = Sets.newConcurrentHashSet();

		for (final String stringValue : strings) {
			for (final T enumValue : enumClass.getEnumConstants()) {

				if (StringUtils.equalsIgnoreCase(enumValue.toValue(), stringValue)) {
					returnValue.add(enumValue);
				}
			}
		}

		return returnValue;
	}

	@Override
	public void nullSafeSet(final PreparedStatement st, final Object value, final int index, final SessionImplementor session) throws SQLException {
		if (null == value) {
			st.setString(index, "");
		}
		else {
			final Set<String> returnValue = Sets.newConcurrentHashSet();
			for (final T enumValue : (Set<T>)value) {
				returnValue.add(enumValue.toValue());
			}
			String enumString = String.join(",", returnValue);
			st.setString(index, enumString);
		}
	}
}
