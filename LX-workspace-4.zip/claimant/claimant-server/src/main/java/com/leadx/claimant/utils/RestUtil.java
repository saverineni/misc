package com.leadx.claimant.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class RestUtil {
	@Value("${tcg.client.protocol}")
	private String httpProtocol;

	@Value("${tcg.client.host}")
	private String tcgHost;

	@Value("${tcg.client.port}")
	private String tcgPort;

	public String generateTcgUri(String endpoint) {
		endpoint = "/unsecure/".concat(endpoint).concat(".form");
		return String.format("%s://%s:%s%s", this.httpProtocol, this.tcgHost, this.tcgPort, endpoint);
	}

}
