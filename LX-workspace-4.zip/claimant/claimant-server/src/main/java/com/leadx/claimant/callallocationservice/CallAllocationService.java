package com.leadx.claimant.callallocationservice;

import static com.google.common.collect.Lists.newArrayList;
import static java.util.stream.Collectors.joining;
import static org.slf4j.LoggerFactory.getLogger;

import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestOperations;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Sets;
import com.leadx.claimant.claimantservice.Claimant;
import com.leadx.claimant.claimantservice.ClaimantService;
import com.leadx.claimincubation.client.wrappers.ClaimServiceWrapper;
import com.leadx.claimincubation.client.wrappers.PbaClaimantServiceWrapper;
import com.leadx.services.client.TcgProduct;

@Service
public class CallAllocationService {
	@Value("${tcg.client.protocol}")
	private String tcgProtocol;

	@Value("${tcg.client.host}")
	private String tcgHost;

	@Value("${tcg.client.port}")
	private String tcgPort;

	@Autowired
	@Qualifier("claimantRestOperations")
	private RestOperations restOperations;

	@Autowired
	private ClaimantGroupAllocationRepository claimantGroupAllocationRepository;

	@Autowired
	private TelephonyHelper telephonyHelper;

	@Autowired
	private ClaimServiceWrapper claimServiceWrapper;

	@Autowired
	private ClaimantService claimantService;

	@Autowired
	private PbaClaimantServiceWrapper pbaClaimantServiceWrapper;

	public static final String PBA = "pba";
	public static final String PPI = "ppi";
	public static final String COMBINED = "combined";
	private static final String CALL_REASON = "chase";
	private static final int SYSTEM_USER_ID = 3388;

	private static final Logger LOG = getLogger(CallAllocationService.class);

	public ClaimantGroupAllocation getClaimantGroupAllocationByClaimantId(final int claimantId) {
		LOG.debug("Retrieving claimant group allocation for claimant " + claimantId);

		return this.claimantGroupAllocationRepository.getClaimantGroupAllocationByClaimantId(claimantId);
	}

	@SuppressWarnings("unchecked")
	public List<Integer> createTcgCallAllocationClaimantList(final int offsetDays, final String recentlyUnlockedClaimants) {
		final String endpoint = "/unsecure/claimant/generateActiveClaimsClaimantList/offsetDays/%s/recentlyUnlockedClaimants/%s.form";
		final String uri = generateUri(this.tcgProtocol, this.tcgHost, this.tcgPort, endpoint, offsetDays, recentlyUnlockedClaimants);

		final ResponseEntity<List> response = this.restOperations.getForEntity(uri, List.class);

		List<Integer> claimantsFromTcg = newArrayList();
		if (response.getStatusCode() == HttpStatus.OK) {
			claimantsFromTcg = response.getBody();
		} else {
			LOG.error("Failed to retrieve Claimants for Call Allocation from TCG. Http StatusCode: {}", response.getStatusCode());
		}

		return claimantsFromTcg;
	}

	@SuppressWarnings("unchecked")
	public void updateCallAllocations(final int offsetDays) {
		final String recentlyUnlockedClaimants = this.claimantService.getRecentlyUnlockedClaimants(offsetDays)
													.stream()
													.map(String::valueOf)
													.collect(joining(","));

		final List<Integer> claimantsFromTcg = createTcgCallAllocationClaimantList(offsetDays, recentlyUnlockedClaimants);
		final List<Integer> claimantsFromClaimIncubation = this.claimServiceWrapper.generateActiveClaimsClaimantList(offsetDays, recentlyUnlockedClaimants);

		if (claimantsFromTcg.isEmpty() && claimantsFromClaimIncubation.isEmpty()){
			LOG.info("No Claimants found for PPI or PBA");
			return;
		}

		final List<Integer> actualCombined = (List<Integer>) CollectionUtils.intersection(claimantsFromTcg, claimantsFromClaimIncubation);
		claimantsFromTcg.removeAll(actualCombined);
		claimantsFromClaimIncubation.removeAll(actualCombined);

		actionClaimantList(claimantsFromTcg, TcgProduct.PPI);
		actionClaimantList(claimantsFromClaimIncubation, TcgProduct.PBA);
		actionClaimantList(actualCombined, TcgProduct.COMBINED);
	}

	public void addChaseCall(final Claimant claimant, final TcgProduct tcgProduct) {
		final int claimantId = claimant.getId();
		try {
			LOG.debug("Adding new chase call for {} for claimant {}", tcgProduct.toString(), claimantId);
			this.telephonyHelper.createClaimantChaseCall(claimant, tcgProduct);
		} catch (final Exception e) {
			logError(claimantId, e);
		}
	}

	public void addChaseCall(final Claimant claimant, final TcgProduct tcgProduct, final LocalDateTime scheduledDateTime) {
		final int claimantId = claimant.getId();
		try {
			LOG.debug("Adding new chase call with scheduled date time for {} for claimant {}", tcgProduct.toString(), claimantId);
			this.telephonyHelper.createClaimantChaseCall(claimant, tcgProduct, scheduledDateTime);
		} catch (final Exception e) {
			logError(claimantId, e);
		}
	}

	public void reconcileCallAllocations(int offsetDays){
		Set<Integer> claimantsFromTcg = getClaimantsFromTcgForCallCancellation(offsetDays);
		Set<Integer> claimantsFromClaimIncubation = getClaimantsFromClaimIncubationForCallCancellation(offsetDays);
		Set<Integer> claimantsForCombinedCalls = ImmutableSet.copyOf(Sets.intersection(claimantsFromTcg, claimantsFromClaimIncubation));

		for(int claimantId : claimantsForCombinedCalls){
			try{
				cancelCallAllocation(claimantId, SYSTEM_USER_ID, TcgProduct.COMBINED);
			} catch (Exception e){
				logError(claimantId, e);
			}
		}

		claimantsFromTcg.removeAll(claimantsForCombinedCalls);
		for(int claimantId : claimantsFromTcg){
			try{
				cancelCallAllocation(claimantId, SYSTEM_USER_ID, TcgProduct.PPI);
			} catch(Exception e){
				logError(claimantId, e);
			}

		}

		claimantsFromClaimIncubation.removeAll(claimantsForCombinedCalls);
		for(int claimantId : claimantsFromClaimIncubation){
			try{
				cancelCallAllocation(claimantId, SYSTEM_USER_ID, TcgProduct.PBA);
			} catch(Exception e){
				logError(claimantId, e);
			}
		}
	}

	public void cancelCallAllocation(final int claimantId, final int userId, final TcgProduct tcgProduct) {
		final Claimant claimant  = this.claimantService.getClaimantById(claimantId);
		final ClaimantGroupAllocation existingCallEntry = this.claimantGroupAllocationRepository.getClaimantGroupAllocationByClaimantId(claimantId);
		if (existingCallEntry == null) {
			LOG.info("No call entry exists for Claimant {}", claimantId);
			return;
		}

		final TcgProduct product = determineProductToCancelChaseCall(existingCallEntry, tcgProduct);
		final boolean combinedCallExists = COMBINED.equals(existingCallEntry.getCallReasonGroup());

		LOG.info("Cancelling call for " + claimantId + " for product " + (combinedCallExists ? TcgProduct.COMBINED : product));
		this.telephonyHelper.cancelClaimantChaseCall(claimantId, userId, (combinedCallExists ? TcgProduct.COMBINED : product));

		if((!combinedCallExists && callEntryMatchesProduct(existingCallEntry, product)) || TcgProduct.COMBINED.equals(product)){
			this.claimantGroupAllocationRepository.deleteClaimantCallGroupAllocationEntry(existingCallEntry);
			return;
		} else if (combinedCallExists) {
			handleCancellationWhenCombinedCallExists(claimant, product, existingCallEntry);
		}
	}

	private static boolean callEntryMatchesProduct(final ClaimantGroupAllocation callEntry, final TcgProduct product){
		return callEntry.getCallReasonGroup().equals(product.toString().toLowerCase());
	}

	private static TcgProduct determineProductToCancelChaseCall(final ClaimantGroupAllocation existingCallEntry, final TcgProduct tcgProduct){
		if(tcgProduct == null){ //if no product is specified, then remove the existing call entry
			return productForCallReasonGroup(existingCallEntry.getCallReasonGroup());
		}

		return tcgProduct;
	}

	public void updateClaimantsGroupAllocation(final int claimantId, final TcgProduct tcgProduct){
		final Claimant claimant  = this.claimantService.getClaimantById(claimantId);

		if(claimant.getLockedFromDialler()){
			LOG.info("Claimant {} is locked from dialler. No chase calls will be added", claimantId);
			return;
		}

		final TcgProduct updatedProduct = processClaimantsCallAllocation(claimant, tcgProduct);
		if (null != updatedProduct) {
			addChaseCall(claimant, updatedProduct);
		}
	}

	/**
	 * Overloaded method to update the group allocation for an individual claimant, because we are
	 * providing a new scheduled time we ALWAYS want to cancel the existing call and add a new one,
	 * regardless of whether the allocated group has changed
	 */
	public void updateClaimantsGroupAllocation(final int claimantId, final TcgProduct tcgProduct, final LocalDateTime scheduledDateTime){
		final Claimant claimant  = this.claimantService.getClaimantById(claimantId);

		if(claimant.getLockedFromDialler()){
			LOG.info("Claimant {} is locked from dialler. No chase calls will be added", claimantId);
			return;
		}

		final TcgProduct updatedProduct = processClaimantsCallAllocation(claimant, tcgProduct);
		final TcgProduct productToUse = updatedProduct == null ? tcgProduct : updatedProduct;

		this.telephonyHelper.cancelClaimantChaseCall(claimantId, SYSTEM_USER_ID, productToUse);
		addChaseCall(claimant, productToUse, scheduledDateTime);
	}

	private TcgProduct processClaimantsCallAllocation(final Claimant claimant, final TcgProduct tcgProduct) {
		final int claimantId = claimant.getId();
		LOG.debug("Processing Call Allocation for claimant {}", claimantId);
		final boolean existingClaimant = this.claimantGroupAllocationRepository.checkClaimantCallGroupAllocationEntry(claimantId);
		String callReasonGroup = callReasonGroupForProduct(tcgProduct);

		if (existingClaimant){
			final ClaimantGroupAllocation existingClaimantGroupAllocation = this.claimantGroupAllocationRepository.getClaimantGroupAllocationByClaimantId(claimantId);
			String existingCallReasonGroup = existingClaimantGroupAllocation.getCallReasonGroup();
			String callReasonGroupCombined = callReasonGroupForProduct(TcgProduct.COMBINED);

			if (existingCallReasonGroup.equals(callReasonGroup) || existingCallReasonGroup.equals(callReasonGroupCombined)) {
				LOG.debug("Call entry already exists for claimant {} for product {}. No changes will be made", claimantId, existingCallReasonGroup);
				return null;
			}

			LOG.debug("Call entry exists for claimant {} for {}", claimantId, existingCallReasonGroup);

			final TcgProduct productToCancel = productForCallReasonGroup(existingCallReasonGroup);

			LOG.debug("Cancelling scheduled call for " + productToCancel);
			this.telephonyHelper.cancelClaimantChaseCall(claimantId, SYSTEM_USER_ID, productToCancel);
			this.claimantGroupAllocationRepository.deleteClaimantCallGroupAllocationEntry(existingClaimantGroupAllocation);

				ClaimantGroupAllocation claimantGroupAllocation = buildClaimantGroupAllocationFromExisting(existingClaimantGroupAllocation, callReasonGroupCombined);
				this.claimantGroupAllocationRepository.insertClaimantCallGroupAllocationEntry(claimantGroupAllocation);
			return TcgProduct.COMBINED;
		} else {
				final ClaimantGroupAllocation claimantGroupAllocation = new ClaimantGroupAllocation(claimantId, CALL_REASON, callReasonGroup);
				this.claimantGroupAllocationRepository.insertClaimantCallGroupAllocationEntry(claimantGroupAllocation);
			return tcgProduct;
		}
	}

	private Set<Integer> getClaimantsFromTcgForCallCancellation(int offsetDays){
		final String endpoint = "/unsecure/claimant/getClaimantsForCallCancellation/%s.form";
		final String uri = generateUri(this.tcgProtocol, this.tcgHost, this.tcgPort, endpoint, offsetDays);
		final ResponseEntity<Set> response = this.restOperations.getForEntity(uri, Set.class);

		Set<Integer> claimantsForCallCancellation;
		if (response.getStatusCode() == HttpStatus.OK) {
			claimantsForCallCancellation = response.getBody();
		} else {
			throw new RuntimeException("Failed to retrieve Claimants for Call Allocation from TCG. Http StatusCode: " + response.getStatusCode());
		}

		return claimantsForCallCancellation;
	}


	private Set<Integer> getClaimantsFromClaimIncubationForCallCancellation(int offsetDays){
		return this.pbaClaimantServiceWrapper.getClaimantsForCallCancellation(offsetDays);
	}

	private void handleCancellationWhenCombinedCallExists(Claimant claimant, TcgProduct tcgProduct, ClaimantGroupAllocation existingCallEntry){
		final int claimantId = claimant.getId();
		TcgProduct otherProduct = TcgProduct.PPI.equals(tcgProduct) ? TcgProduct.PBA : TcgProduct.PPI;

		this.claimantGroupAllocationRepository.deleteClaimantCallGroupAllocationEntry(existingCallEntry);

		if(claimant.getLockedFromDialler()){
			LOG.info("Claimant {} is locked from dialler. No chase calls will be added", claimantId);
			return;
		}

		ClaimantGroupAllocation claimantGroupAllocation = buildClaimantGroupAllocationFromExisting(existingCallEntry, callReasonGroupForProduct(otherProduct));
		this.claimantGroupAllocationRepository.insertClaimantCallGroupAllocationEntry(claimantGroupAllocation);

		try {
			LOG.info("Adding chase call for {} for claimant {}", otherProduct.toString(), claimantId);
			this.telephonyHelper.createClaimantChaseCall(claimant, otherProduct);
		} catch (final Exception e) {
			logError(claimantId, e);
		}
	}

	private ClaimantGroupAllocation buildClaimantGroupAllocationFromExisting(ClaimantGroupAllocation existing, String callReasonGroup){
		return new ClaimantGroupAllocation(existing.getClaimantId(), existing.getCallReason(), callReasonGroup);
	}

	private void actionClaimantList(List<Integer> claimantList, TcgProduct tcgProduct){
		logSchedulingProcess(tcgProduct);

		for (final int claimantId : claimantList) {
			try {
				updateClaimantsGroupAllocation(claimantId, tcgProduct);
			} catch (Exception e){
				logError(claimantId, e);
			}
		}
	}

	public static String callReasonGroupForProduct(TcgProduct tcgProduct){
		switch (tcgProduct){
			case PPI:
				return PPI;
			case PBA:
				return PBA;
		}
		return COMBINED;
	}

	public static TcgProduct productForCallReasonGroup(String callReasonGroup){
		switch (callReasonGroup){
			case PPI:
				return TcgProduct.PPI;
			case PBA:
				return TcgProduct.PBA;
		}
		return TcgProduct.COMBINED;
	}

	private void logSchedulingProcess(TcgProduct tcgProduct){
		switch (tcgProduct) {
			case PPI:
				LOG.info("Scheduling calls for claimants having only PPI claims...");
				break;
			case PBA:
				LOG.info("Scheduling calls for claimants having only PBA claims...");
				break;
			default:
				LOG.info("Scheduling calls for claimants having PPI and PBA claims...");
		}
	}

	private static String generateUri(final String protocol, final String host, final String port, final String format, final Object... args) {
		return String.format("%s://%s:%s", protocol, host, port) + String.format(format, args);
	}

	private void logError(int claimantId, Exception exception){
		String message = String.format("Error occurred while processing call allocation for claimant %s", claimantId);
		LOG.error(message, exception);
	}

	public void setRestOperations(RestOperations restOperations) {
		this.restOperations = restOperations;
	}

	public void setTelephonyHelper(TelephonyHelper callAllocationServiceTelephonyHelper) {
		this.telephonyHelper = callAllocationServiceTelephonyHelper;
	}

}
