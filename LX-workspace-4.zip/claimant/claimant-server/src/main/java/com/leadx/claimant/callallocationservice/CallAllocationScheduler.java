package com.leadx.claimant.callallocationservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class CallAllocationScheduler {
	private static final Logger LOG = LoggerFactory.getLogger(CallAllocationScheduler.class);


	@Autowired
	private CallAllocationService callAllocationService;

	@Value("${claimant.server.scheduler.scheduleClaimantCallAllocation.enabled:true}")
	private Boolean scheduleClaimantCallAllocation;

	@Value("${claimant.server.scheduler.reconcileCallAllocation.enabled:true}")
	private Boolean reconcileCallAllocation;

	@Scheduled(cron="${claimant.server.scheduler.scheduleClaimantCallAllocation.cron}")
	public void triggerUpdateCallAllocations() {
		// In a clustered environment this property will be set to true on only one server
		if (this.scheduleClaimantCallAllocation) {
			LOG.debug("Call Allocation process is enabled, proceeding...");
			this.callAllocationService.updateCallAllocations(1);
		}
	}

	@Scheduled(cron="${claimant.server.scheduler.reconcileCallAllocation.cron}")
	public void triggerReconcileCallAllocations() {
		// In a clustered environment this property will be set to true on only one server
		if (this.reconcileCallAllocation) {
			LOG.debug("Reconcile Call Allocation process is enabled, proceeding...");
			this.callAllocationService.reconcileCallAllocations(1);
		}
	}

}
