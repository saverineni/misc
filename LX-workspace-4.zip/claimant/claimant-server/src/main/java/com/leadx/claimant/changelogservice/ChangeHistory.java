package com.leadx.claimant.changelogservice;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface ChangeHistory {

	/**
	 * @return the name to used when creating a {@link ChangeItem} `field`, if none is set then the title cased field name is used
	 */
	String fieldName() default "";

	/**
	 * @return the {@link PersistanceStrategy} for saving change history values, if none is specified the default uses {@link DefaultStrategy} which does
	 *         nothing
	 */
	Class<? extends PersistanceStrategy> strategy() default DefaultStrategy.class;

	boolean createEvent() default false;
}
