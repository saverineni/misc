package com.leadx.claimant.changelogservice;

import java.util.List;

import com.leadx.claimant.claimantservice.ClaimantInteraction;
import com.leadx.claimant.claimantservice.ClaimantInteractionRepository;
import com.leadx.claimant.claimantservice.Source;
import com.leadx.claimant.client.ClaimantInteractionDto;
import com.leadx.claimant.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.leadx.hibernate.domain.BaseIntegerDomain;

@Service
public class ChangeLogService {
	@Autowired
	private ChangeItemRepository repository;
	@Autowired
	private ClaimantInteractionRepository claimantInteractionRepository;
	@Autowired
	private UserService userService;

	@Transactional
	public <T extends BaseIntegerDomain> List<ChangeItem> saveChangeValues(final int claimantId, final T oldString, final T newString, final int userId) {
		final List<ChangeItem> changeItems = ChangeHistoryGenerator.generateChangeItems(claimantId, oldString, newString, userId);
		for ( final ChangeItem item: changeItems ) {
			this.repository.createChangeItem(item);
		}
		for (final String changeEvent : ChangeHistoryGenerator.generateEvents(oldString, newString)) {
			ClaimantInteraction claimantInteraction = ClaimantInteraction.newEvent(claimantId, null, userService.getById(userId), changeEvent, Source.CLAIMANT);
			this.claimantInteractionRepository.save(claimantInteraction);
		}
		return changeItems;
	}
}
