package com.leadx.claimant.assessmentservice;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.leadx.lib.utl.ObjectUtils.isNull;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.ImmutableList;
import com.leadx.claimant.addressservice.Address;
import com.leadx.claimant.claimantservice.Claimant;
import com.leadx.claimant.claimantservice.ClaimantAndAddress;
import com.leadx.claimant.claimantservice.ClaimantService;
import com.leadx.claimant.client.AddressDto;
import com.leadx.claimant.client.AssessmentDispositionDto;
import com.leadx.claimant.client.AssessmentDto;
import com.leadx.claimant.client.CallDisposition;
import com.leadx.claimant.client.ClaimantDto;

@RequestMapping(value = "/assessment")
@Controller
public class AssessmentController {
	private static final Logger LOG = LoggerFactory.getLogger(AssessmentController.class);

	@Autowired
	private AssessmentService assessmentService;

	@Autowired
	private ClaimantService claimantService;

	@Autowired
	private Converter<Claimant, ClaimantDto> claimantConverter;

	@Autowired
	private Converter<Address, AddressDto> addressConverter;

	@ResponseBody
	@RequestMapping(value = "/loadClaimant/{claimantId}/user/{userId}", method = RequestMethod.GET)
	public AssessmentDto loadClaimant(@PathVariable final int claimantId, @PathVariable final int userId) {
		LOG.debug("loadClaimant: {}", claimantId);
		try {
			final AssessmentDto assessmentDto = this.assessmentService.loadClaimant(claimantId, userId, true);

			if (isNull(assessmentDto)) {
				throw new RuntimeException("Failed to load assessment details for Claimant ID " + claimantId);
			}

			return assessmentDto;
		} catch (final RuntimeException e) {
			throw e;
		}
	}

	@RequestMapping(value = "/disposition", method = RequestMethod.POST, consumes = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<String> dispositionCall(@RequestBody final AssessmentDispositionDto disposition) {
		LOG.debug("dispositionCall");
		checkNotNull(disposition, "Cannot disposition call with null disposition");

		final CallDisposition callDisposition = CallDisposition.getById(disposition.getDispositionId());
		checkNotNull(callDisposition, "Unknown disposition: " + disposition);

		this.assessmentService.dispositionCall(disposition, callDisposition);

		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@ResponseBody
	@RequestMapping(value = "/searchClaimant/telephone/{number}", method = RequestMethod.GET)
	public List<AssessmentClaimantAndAddressDto> searchForClaimantByTelephoneNumber(@PathVariable final String number) {
		try {
			final List<ClaimantAndAddress> claimantsWithAddress = this.claimantService.searchForClaimantByTelephoneNumber(number);
			LOG.debug("Searching for claimants with telephone: " + number);
			return toAssessmentClaimantDtos(claimantsWithAddress);
		} catch ( final Exception e ) {
			LOG.error("searchForClaimantByTelephoneNumber " + number + " failed", e);
			throw e;
		}
	}

	@ResponseBody
	@RequestMapping(value = "/searchClaimant/postcode/{postcode}", method = RequestMethod.GET)
	public List<AssessmentClaimantAndAddressDto> searchForClaimantByPostcode(@PathVariable final String postcode) {
		try {
			final List<ClaimantAndAddress> claimantsWithAddress = this.claimantService.searchForClaimantByPostcode(postcode);
			LOG.debug("Searching for claimants with postcode: " + postcode);
			return toAssessmentClaimantDtos(claimantsWithAddress);
		} catch ( final Exception e ) {
			LOG.error("searchForClaimantByPostcode " + postcode + " failed", e);
			throw e;
		}
	}

	@ResponseBody
	@RequestMapping(value = "/searchClaimant/claimant/{claimantId}", method = RequestMethod.GET)
	public AssessmentDto searchForClaimantByClaimantId(@PathVariable final int claimantId) {
		try {
			LOG.debug("Searching for claimant with claimant id: " + claimantId);
			final AssessmentDto assessmentDto = this.assessmentService.loadClaimant(claimantId, 0, false);

			if (isNull(assessmentDto)) {
				throw new RuntimeException("Search failed for Claimant ID: " + claimantId);
			}

			return assessmentDto;
		} catch ( final Exception e ) {
			LOG.error("searchForClaimantByClaimantId " + claimantId + " failed", e);
			throw e;
		}
	}

	private List<AssessmentClaimantAndAddressDto> toAssessmentClaimantDtos(final List<ClaimantAndAddress> claimantsWithAddress) {
		final ImmutableList.Builder<AssessmentClaimantAndAddressDto> results = new ImmutableList.Builder<>();
		for ( final ClaimantAndAddress claimantAndAddress: claimantsWithAddress ) {
			final ClaimantDto claimantDto = this.claimantConverter.convert(claimantAndAddress.getClaimant());
			final AssessmentClaimantDto assessmentClaimantDto = new AssessmentClaimantDto(claimantDto, this.claimantService.getSellerAccountNameById(claimantDto.getSellerAccountId()));
			final AddressDto addressDto = this.addressConverter.convert(claimantAndAddress.getAddress());
			results.add(new AssessmentClaimantAndAddressDto(assessmentClaimantDto, addressDto));
		}
		return results.build();
	}
}