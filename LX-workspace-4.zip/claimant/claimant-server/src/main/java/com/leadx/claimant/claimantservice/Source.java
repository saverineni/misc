package com.leadx.claimant.claimantservice;

/**
 * Created by kiran.prakash on 30/03/2017.
 */
public enum Source {

    SALES("sales"),
    PAYMENTS("payments"),
    CLAIMANT("claimant"),
    PORTAL("portal"),
    LOGICLAIM("logiclaim");

    private String name;

    Source(String name){
        this.name = name;
    }

    public static Source fromValue(String name) {
        for (Source source:Source.values()) {
            if(source.name.equalsIgnoreCase(name)){
                return source;
            }
        }
        throw new IllegalArgumentException("Source not found for  : " + name);
    }
}
