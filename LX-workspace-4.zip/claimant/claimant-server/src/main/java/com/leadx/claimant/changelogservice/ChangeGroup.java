package com.leadx.claimant.changelogservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Type;
import org.joda.time.LocalDateTime;

import com.leadx.hibernate.domain.BaseIntegerDomain;

@Entity
@Table(name = "change_group")
public class ChangeGroup extends BaseIntegerDomain {

	private static final long serialVersionUID = -7635268548253752033L;
	
	@Column(name = "FK_ClaimantId")
	private int claimantId;
	@Column(name = "FK_UserID")
	private int userId;

	@Type(type = "local_date_time_not_null")
	private LocalDateTime dateTime;


	public ChangeGroup() {}

	public ChangeGroup(final int claimantId, final int userId, final LocalDateTime dateTime) {
		this.claimantId = claimantId;
		this.userId = userId;
		this.dateTime = dateTime;
	}

	public int getClaimantId() {
		return this.claimantId;
	}

	public int getUserId() {
		return this.userId;
	}

	public LocalDateTime getDateTime() {
		return this.dateTime;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public boolean deepEquals(final Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}
}
