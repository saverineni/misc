package com.leadx.claimant.claimantservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.leadx.claimant.client.ClaimantContactPreferenceDto;

@Controller
@RequestMapping(value = "/contactpreference")
public class ClaimantContactPreferenceController {
	private static final Logger LOG = LoggerFactory.getLogger(ClaimantContactPreferenceController.class);

	@Autowired
	private ClaimantContactPreferenceService claimantContactPreferenceService;

	@Autowired
	private ClaimantContactPreferenceConverter claimantContactPreferenceConverter;

	@Autowired
	private ClaimantContactPreferenceDtoConverter claimantContactPreferenceDtoConverter;

	@ResponseBody
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public ClaimantContactPreferenceDto getById(@PathVariable final int id) {
		LOG.debug("Retrieving claimant contact preferences by ID " + id);
		final ClaimantContactPreference contactPreferences = this.claimantContactPreferenceService.getById(id);

		return this.claimantContactPreferenceConverter.convert(contactPreferences);
	}

	@ResponseBody
	@RequestMapping(value = "/claimant/{claimantId}", method = RequestMethod.GET)
	public ClaimantContactPreferenceDto getClaimantById(@PathVariable final int claimantId) {
		LOG.debug("Retrieving claimant contact preferences by claimant ID " + claimantId);
		final ClaimantContactPreference contactPreference = this.claimantContactPreferenceService.getByClaimantId(claimantId);

		return this.claimantContactPreferenceConverter.convert(contactPreference);
	}

	@ResponseBody
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public void save(@RequestBody final ClaimantContactPreferenceDto contactPreferenceDto) {
		LOG.debug("Saving claimant contact preferences");
		final ClaimantContactPreference contactPreference = this.claimantContactPreferenceDtoConverter.convert(contactPreferenceDto);

		this.claimantContactPreferenceService.saveOrUpdate(contactPreference);

	}
}
