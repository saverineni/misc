package com.leadx.claimant.changelogservice;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
class ChangeItemRepository {
	@Autowired
	private SessionFactory sessionFactory;

	ChangeItem getChangeItemById(final int id) {
		return (ChangeItem)this.sessionFactory.getCurrentSession().get(ChangeItem.class, id);
	}

	void createChangeItem(final ChangeItem changeItem) {
		this.sessionFactory.getCurrentSession()
			.save(changeItem);
	}
}
