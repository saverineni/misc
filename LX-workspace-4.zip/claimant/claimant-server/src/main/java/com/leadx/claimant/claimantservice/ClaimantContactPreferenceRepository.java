package com.leadx.claimant.claimantservice;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
class ClaimantContactPreferenceRepository {

	@Autowired
	private SessionFactory sessionFactory;

	ClaimantContactPreference getById(final int id) {
		return (ClaimantContactPreference) this.sessionFactory.getCurrentSession().get(ClaimantContactPreference.class, id);
	}

	ClaimantContactPreference getByClaimantId(final int claimantId) {
		return (ClaimantContactPreference) this.sessionFactory.getCurrentSession().createQuery("FROM ClaimantContactPreference WHERE claimantId = :claimantId")
			.setInteger("claimantId", claimantId)
			.uniqueResult();
	}

	void saveOrUpdate(final ClaimantContactPreference claimantContactPreference) {
		this.sessionFactory.getCurrentSession().saveOrUpdate(claimantContactPreference);
	}

	void evict(final ClaimantContactPreference claimantContactPreference) {
		this.sessionFactory.getCurrentSession().evict(claimantContactPreference);
	}

}
