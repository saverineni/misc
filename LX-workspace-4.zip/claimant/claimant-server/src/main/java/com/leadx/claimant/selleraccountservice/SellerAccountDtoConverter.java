package com.leadx.claimant.selleraccountservice;

import static com.leadx.lib.utl.ObjectUtils.isNull;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.leadx.claimant.client.SellerAccountDto;

@Component("sellerAccountDtoConverter")
public class SellerAccountDtoConverter implements Converter<SellerAccountDto, SellerAccount>  {

	@Override
	public SellerAccount convert(final SellerAccountDto source) {
		if (isNull(source)) {
			return null;
		}

		final SellerAccount converted = new SellerAccount(source.getAccountId(), source.getGpSellerAccount(), source.getName(), source.getDisplayName(), source.getSourceDescription(),
				source.getMethodOfContact(), source.getApplicationLogo(), source.getPackType(), source.getDistributeAppointmentReminder(), source.getAssessmentCallReasonGroup(),
				source.getAssessmentInitialSmsMessageScript(), source.getAssessmentInitialEmailMessageScript(), source.getEmailIconImageName(), source.getFreePpi());
		converted.setId(source.getId());
		if(source.getInboundNumbers() != null) {
			converted.setInboundNumbers(source.getInboundNumbers());
		}
		converted.setProductType(new ProductType(source.getProductType().getId(), source.getProductType().getName()));
		return converted;
	}
}