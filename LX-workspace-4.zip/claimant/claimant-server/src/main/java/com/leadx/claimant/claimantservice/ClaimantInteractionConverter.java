package com.leadx.claimant.claimantservice;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.leadx.claimant.client.ClaimantInteractionDto;
import com.leadx.lib.utl.JodaUtils;

@Component
class ClaimantInteractionConverter implements Converter<ClaimantInteraction, ClaimantInteractionDto> {

	@Override
	public ClaimantInteractionDto convert(final ClaimantInteraction source) {

		return new ClaimantInteractionDto(
				source.getId(),
				source.getClaimantId(),
				source.getProductId(),
				source.getUser().getId(),
				source.getUser().getFullName(),
				JodaUtils.localDateTimeToBritishDateFormatOrNull(source.getCreatedDateTime()),
				source.getContent(),
				source.getSource(),
				source.getVersion()
			);

	}
}
