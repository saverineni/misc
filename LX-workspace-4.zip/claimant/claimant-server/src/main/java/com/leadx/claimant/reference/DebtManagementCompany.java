package com.leadx.claimant.reference;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "debt_management_company")
public class DebtManagementCompany extends DmIvaCompany {

	private static final long serialVersionUID = 7754430113603581942L;

	public DebtManagementCompany() {
		super();
	}

	public DebtManagementCompany(final Integer id, final String name, final String departmentName, final String organisationName, final String subBuildingName, final String buildingName, final String buildingNumber,
                                 final String dependentThoroughfare, final String thoroughfare, final String doubleDependentLocality, final String dependentLocality, final String town, final String county, final String postcode) {
		
		super(id, name, departmentName, organisationName, subBuildingName, buildingName, buildingNumber, dependentThoroughfare, thoroughfare, doubleDependentLocality, dependentLocality, town, county, postcode);
	}
}