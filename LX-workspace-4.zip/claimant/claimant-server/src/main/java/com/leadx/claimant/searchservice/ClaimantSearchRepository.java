package com.leadx.claimant.searchservice;

import static org.apache.commons.collections.CollectionUtils.isNotEmpty;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.leadx.claimant.client.search.SearchRequestDto;
import com.leadx.claimant.client.search.SearchResultClaimantDto;


@Repository
public class ClaimantSearchRepository {

	@Autowired
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	public List<SearchResultClaimantDto> search(final SearchRequestDto searchRequestDto){
		final MapSqlParameterSource params = new MapSqlParameterSource();

		final String searchQuery = buildSearchQuery(searchRequestDto, params);
		final List<SearchResultClaimantDto> searchResultClaimantDtos = this.namedParameterJdbcTemplate.query(searchQuery, params, new SearchResultClaimantRowMapper());

		return searchResultClaimantDtos;
	}

	private static String buildSearchQuery(final SearchRequestDto searchRequestDto, final MapSqlParameterSource params){
		final StringBuilder queryBuilder = new StringBuilder("SELECT c.ID, c.Title, c.Surname, c.Forename, c.Dob, c.HomeTelephone, c.MobileTelephone, c.Email, a.Postcode FROM claimant c ");
		if(isNotBlank(searchRequestDto.getSurname()) && isNotBlank(searchRequestDto.getPostcode())) {
			queryBuilder.append("FORCE INDEX (claimant_index1)");
		}
		queryBuilder.append(" LEFT JOIN address a ON c.FK_AddressID = a.ID WHERE");

		if(isNotEmpty(searchRequestDto.getClaimantIds())){
			params.addValue("claimantIds", searchRequestDto.getClaimantIds());
			queryBuilder.append(" c.id IN (:claimantIds)");
		} else{
			queryBuilder.append(" c.id IS NOT NULL");
		}

		if(isNotBlank(searchRequestDto.getSurname())){
			params.addValue("surname", searchRequestDto.getSurname() + "%"); //wildcard search
			queryBuilder.append(" AND c.surname LIKE :surname");
		}
		if(isNotBlank(searchRequestDto.getPhone())){
			params.addValue("phone", searchRequestDto.getPhone());
			queryBuilder.append(" AND (c.homeTelephone = :phone OR c.mobileTelephone = :phone)");
		}
		if(isNotBlank(searchRequestDto.getEmail())){
			params.addValue("email", searchRequestDto.getEmail() + "%");
			queryBuilder.append(" AND c.email LIKE :email");
		}
		if(isNotBlank(searchRequestDto.getPostcode())){
			params.addValue("postcode", searchRequestDto.getPostcode() + "%");
			queryBuilder.append(" AND a.postcode LIKE :postcode");
		}

		queryBuilder.append(" ORDER BY c.ID DESC LIMIT 100");

		return queryBuilder.toString();
	}
}
