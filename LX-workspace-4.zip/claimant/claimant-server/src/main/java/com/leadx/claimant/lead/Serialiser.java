package com.leadx.claimant.lead;

import org.springframework.stereotype.Component;

import com.leadx.claimant.client.ClaimantLead;
import com.leadx.lib.utl.json.JsonUtils;
import com.leadx.services.claims.client.ClaimRequest;

@Component
public class Serialiser {
	public ClaimRequest deserialise(final String message) {
		return JsonUtils.deserialize(message, ClaimRequest.class);
	}

	public String serialise(final ClaimantLead claimantLead) {
		return JsonUtils.serialize(claimantLead, true);
	}
}
