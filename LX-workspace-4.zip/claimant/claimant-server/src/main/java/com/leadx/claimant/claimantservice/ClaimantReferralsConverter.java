package com.leadx.claimant.claimantservice;

import java.util.Collection;

import com.google.common.collect.ImmutableList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.leadx.claimant.client.ClaimantReferralDto;

@Component
public class ClaimantReferralsConverter implements Converter<Collection<ClaimantReferral>, Collection<ClaimantReferralDto>> {

	@Autowired
	private Converter<ClaimantReferral, ClaimantReferralDto> claimantReferralConverter;

	@Override
	public Collection<ClaimantReferralDto> convert(final Collection<ClaimantReferral> referrals) {
		final ImmutableList.Builder<ClaimantReferralDto> dtos = new ImmutableList.Builder<>();
		for ( final ClaimantReferral referral: referrals) {
			dtos.add(this.claimantReferralConverter.convert(referral));
		}

		return dtos.build();
	}
}
