package com.leadx.claimant.lead;

import com.leadx.claimant.addressservice.Address;

public class AddressVerificationResult {

	private boolean result;
	private int excludingOrganisationMatchCount;
	private Address address;

	public AddressVerificationResult(boolean result, Address address) {
		this.result = result;
		this.address = address;
	}

	public AddressVerificationResult(boolean result, Address address, int excludingOrganisationMatchCount) {
		this.result = result;
		this.excludingOrganisationMatchCount = excludingOrganisationMatchCount;
		this.address = address;
	}

	public boolean getResult() {
		return result;
	}

	public void setResult(boolean result) {
		this.result = result;
	}

	public int getExcludingOrganisationMatchCount() {
		return excludingOrganisationMatchCount;
	}

	public void setExcludingOrganisationMatchCount(int excludingOrganisationMatchCount) {
		this.excludingOrganisationMatchCount = excludingOrganisationMatchCount;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public static AddressVerificationResult failure(final Address address) {
		return new AddressVerificationResult(false, address);
	}

	public static AddressVerificationResult success(final Address address) {
		return new AddressVerificationResult(true, address);
	}

	public static AddressVerificationResult success(final Address address, final int excludingOrganisationMatchCount) {
		return new AddressVerificationResult(true, address, excludingOrganisationMatchCount);
	}
}
