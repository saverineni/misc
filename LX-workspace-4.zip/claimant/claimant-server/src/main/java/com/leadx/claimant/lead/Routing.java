package com.leadx.claimant.lead;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.leadx.services.claims.client.internal.ClientRouting;

/** Contains the Camel routes relating to lead handling. */
@Component
public class Routing extends RouteBuilder {

	@Value("${claimant.server.routing.messageStore:target/messages}")
	private String messageStore;

	@Value("${claimant.server.routing.jmsConsumersEnabled:true}")
	private boolean jmsConsumersEnabled;

	@Override
	public void configure() throws Exception {
		onException(Exception.class)
			.redeliveryPolicyRef("leadRedelivery")
			.processRef("stackTraceLogger")
			.to(ClientRouting.LEADSERVICES_TO_CLAIMANT_ERROR_QUEUE);

		if (this.jmsConsumersEnabled) {
			from(ClientRouting.LEADSERVICES_TO_CLAIMANT_QUEUE)
				.routeId("LeadProcessing")
				.setHeader("now", simple("${bean:messageLog?method=now}"))
				.to("file:" + this.messageStore + "?fileName=${date:now:yyyyMMdd}/FAILED-${header.now}.msg")
				.beanRef("serialiser", "deserialise")
				.choice()
					.when().method("claimantFilter", "shouldUpdateClaimant")
						.log("Updating claimant")
						.beanRef("saveClaimantProcessor", "updateClaimant")
						.choice()
							.when().method("claimantFilter", "shouldVerifyAddress")
								.log("Verifying address")
								.beanRef("addressVerificationProcessor", "process")
						.end()
						.to("bean:messageLog?method=tidyUp(" + this.messageStore + ",${date:now:yyyyMMdd},${header.now})")
						.stop()
				.end()
				.log("Saving claimant to claimant database")
				.beanRef("saveClaimantProcessor", "saveClaimant")
				.log("Verifying address")
				.beanRef("addressVerificationProcessor", "process")
				.log("Creating claims")
				.beanRef("createClaimsProcessor", "createClaims")
				.log("Updating claims")
				.beanRef("updateClaimsProcessor", "updateClaims")
				.log("Creating assessment call")
				.beanRef("createAssessmentCallProcessor", "createAssessmentCall")
				.log("Potentially creating a web distribution flow")
				.beanRef("createDistributionProcessor", "createWebDistributionFlow")
				.to("bean:messageLog?method=tidyUp(" + this.messageStore + ",${date:now:yyyyMMdd},${header.now})");
		}

	}
}
