package com.leadx.claimant.claimantservice;

import com.leadx.claimant.client.ClaimantExecutorDto;
import com.leadx.lib.utl.JodaUtils;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component("claimantExecutorDtoConverter")
public class ClaimantExecutorDtoConverter implements Converter<ClaimantExecutorDto, ClaimantExecutor>{

	@Override
	public ClaimantExecutor convert(ClaimantExecutorDto source) {
		if (source == null) {
			return null;
		}

		ClaimantExecutor claimantExecutor = new ClaimantExecutor();
		claimantExecutor.setId(source.getId() == 0 ? null : source.getId());
		claimantExecutor.setClaimantId(source.getClaimantId());
		claimantExecutor.setTitle(changeToEmptyStringIfNull(source.getTitle()));
		claimantExecutor.setForename(changeToEmptyStringIfNull(source.getForename()));
		claimantExecutor.setMiddleName(changeToEmptyStringIfNull(source.getMiddleName()));
		claimantExecutor.setSurname(changeToEmptyStringIfNull(source.getSurname()));
		claimantExecutor.setPreviousSurname(changeToEmptyStringIfNull(source.getPreviousSurname()));
		claimantExecutor.setDob(JodaUtils.britishDateStringToLocalDateOrNull(source.getDob()));
		claimantExecutor.setAddressId(source.getAddressId());
		claimantExecutor.setHomeTelephone(changeToEmptyStringIfNull(source.getHomeTelephone()));
		claimantExecutor.setMobileTelephone(changeToEmptyStringIfNull(source.getMobileTelephone()));
		claimantExecutor.setEmail(changeToEmptyStringIfNull(source.getEmail()));
		claimantExecutor.setExecutorUpdateDateTime(JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(source.getExecutorUpdateDateTime()));
		claimantExecutor.setIsExecutorConfirmed(source.getIsExecutorConfirmed());
		claimantExecutor.setExecutorConfirmedUpdateDateTime(JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(source.getExecutorConfirmedUpdateDateTime()));
		claimantExecutor.setCreatedDateTime(JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(source.getCreatedDateTime()));
		claimantExecutor.setTimestamp(JodaUtils.britishTimeStampStringToLocalDateTimeOrNull(source.getTimestamp()));
		claimantExecutor.setIsDeleted(source.getIsDeleted());
		claimantExecutor.setVersion(source.getVersion());

		return claimantExecutor;
	}

	private String changeToEmptyStringIfNull(final String str) {
		return str == null ? "" : str;
	}
}
