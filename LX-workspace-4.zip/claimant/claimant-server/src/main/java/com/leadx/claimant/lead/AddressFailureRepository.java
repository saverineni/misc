package com.leadx.claimant.lead;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class AddressFailureRepository {
	@Autowired
	private SessionFactory sessionFactory;

 	public AddressFailure getById(int id){
		return (AddressFailure) this.sessionFactory.getCurrentSession().get(AddressFailure.class, id);
	}

	public void save(AddressFailure addressFailure){
		this.sessionFactory.getCurrentSession().save(addressFailure);
	}
}
