package com.leadx.claimant.callallocationservice;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class ClaimantGroupAllocationDtoConverter implements Converter<ClaimantGroupAllocationDto, ClaimantGroupAllocation>{


	@Override
	public ClaimantGroupAllocation convert(final ClaimantGroupAllocationDto source) {
		if ( source == null ) {
			return null;
		}

		return new ClaimantGroupAllocation(
			source.getClaimantId(),
			source.getCallReason(),
			source.getCallReasonGroup());

	}



}
