package com.leadx.claimant.searchservice;

import static com.leadx.lib.utl.JodaUtils.localDateToBritishDateStampStringOrNull;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang.StringUtils.isNotBlank;
import static org.apache.commons.lang3.StringUtils.SPACE;
import static org.joda.time.LocalDate.fromDateFields;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.leadx.claimant.client.search.SearchResultClaimantDto;

public class SearchResultClaimantRowMapper implements RowMapper<SearchResultClaimantDto> {

	@Override
	public SearchResultClaimantDto mapRow(ResultSet rs, int rowNum) throws SQLException {
		final String title = rs.getString("Title");
		final String forename = rs.getString("Forename");
		final String surname = rs.getString("Surname");

		StringBuilder nameBuilder = new StringBuilder();
		if(isNotBlank(title)){
			nameBuilder.append(title);
			nameBuilder.append(SPACE);
		}
		if(isNotBlank(forename)){
			nameBuilder.append(forename);
			nameBuilder.append(SPACE);
		}
		if(isNotBlank(surname)){
			nameBuilder.append(surname);
		}

		SearchResultClaimantDto searchResultClaimantDto = new SearchResultClaimantDto.Builder().createSearchResultClaimantDto();
		searchResultClaimantDto.setClaimantId(rs.getInt("ID"));
		searchResultClaimantDto.setName(nameBuilder.toString());
		searchResultClaimantDto.setForename(forename);
		searchResultClaimantDto.setSurname(surname);
		searchResultClaimantDto.setEmail(rs.getString("Email"));
		searchResultClaimantDto.setHomeTelephone(rs.getString("HomeTelephone"));
		searchResultClaimantDto.setMobileTelephone(rs.getString("MobileTelephone"));
		searchResultClaimantDto.setPostcode(rs.getString("Postcode"));

		final Date dob = rs.getDate("Dob");
		if(nonNull(dob)){
			String dateOfBirth = localDateToBritishDateStampStringOrNull(fromDateFields(dob));
			searchResultClaimantDto.setDateOfBirth(dateOfBirth);
		}

		return searchResultClaimantDto;
	}
}
