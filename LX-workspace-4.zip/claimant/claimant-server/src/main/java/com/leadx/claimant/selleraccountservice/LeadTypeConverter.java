package com.leadx.claimant.selleraccountservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.leadx.claimant.addressservice.Address;
import com.leadx.claimant.addressservice.PreviousAddress;
import com.leadx.claimant.client.AddressDto;
import com.leadx.claimant.client.LeadTypeDto;
import com.leadx.claimant.client.PreviousAddressDto;
import com.leadx.lib.utl.JodaUtils;

@Component("leadTypeConverter")
public class LeadTypeConverter implements Converter<LeadType, LeadTypeDto> {
	
	@Override
	public LeadTypeDto convert(final LeadType source) {
		if (null == source) {
			return null;
		}

		return new LeadTypeDto(source.getId(), source.getName());
	}
	
}
