package com.leadx.claimant.addressservice;

import java.util.Collection;

import com.google.common.collect.ImmutableCollection;
import com.google.common.collect.ImmutableList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;

import com.leadx.claimant.client.AddressDto;

public class AddressDtosConverter implements Converter<Collection<AddressDto>, Collection<Address>> {

	@Autowired
	private Converter<AddressDto, Address> addressDtoConverter;

	@Override
	public Collection<Address> convert(final Collection<AddressDto> dtos) {
		final ImmutableCollection.Builder<Address> addresses = new ImmutableList.Builder<>();
		for ( final AddressDto dto: dtos ) {
			addresses.add(this.addressDtoConverter.convert(dto));
		}

		return addresses.build();
	}
}
