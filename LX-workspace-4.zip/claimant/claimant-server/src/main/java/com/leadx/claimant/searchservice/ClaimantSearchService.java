package com.leadx.claimant.searchservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.leadx.claimant.client.search.SearchRequestDto;
import com.leadx.claimant.client.search.SearchResultClaimantDto;

@Service
public class ClaimantSearchService {

	@Autowired
	private ClaimantSearchRepository claimantSearchRepository;

	@Transactional
	public List<SearchResultClaimantDto> search(final SearchRequestDto searchRequestDto){
		return this.claimantSearchRepository.search(searchRequestDto);
	}
}
