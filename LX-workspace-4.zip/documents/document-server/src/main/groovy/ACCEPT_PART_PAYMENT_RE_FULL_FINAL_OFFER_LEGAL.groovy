import com.leadx.documents.server.PageCostingType

import static com.leadx.documents.server.generation.TemplatePdfPages.ACCEPT_PART_PAYMENT_RE_FULL_FINAL_OFFER_LEGAL_COVER_LETTER
import static context.ClaimContext.createClaimantAndClaimContext
import static context.Utils.determineAddressFields
import static pages.PageUtils.*

def claimant = packRequest.claimant
def agreement = packRequest.creditAgreement[0]
def claim = agreement.claim[0]

def outputFile = createOutputPdfFileClaim(shouldPrintInternal, outputDir, packRequest.documentTemplate, claimant, claim)
def context = createClaimantAndClaimContext(claimant, agreement, claim, packRequest.requestedByUsername)
def createStream = createStreamHelper(outputRequirements)
def addPages = addPagesHelper(pageBuilder, outputFile, outputRequirements, PageCostingType.COLOUR, documentReference)

agreement.seller.each {k,v -> deliveryAddress[k] = v}
determineAddressFields(agreement.seller, context, "seller")
deliveryAddress['lender'] = context['lenderName']

addPages(createStream([ACCEPT_PART_PAYMENT_RE_FULL_FINAL_OFFER_LEGAL_COVER_LETTER]).withLenderAddress(), context)

return outputFile.closeAndRetrieveOutputFile()