import com.leadx.documents.server.PageCostingType
import com.leadx.documents.server.generation.TemplatePdfPages

import static DocumentGenerationUtils2.attachOnBaseDocs
import static context.ClaimContext.createClaimantAndClaimContext
import static pages.PageUtils.*

def claimant = packRequest.claimant
def agreement = packRequest.creditAgreement[0]
def claim = agreement.claim[0]

def outputPdf = createOutputPdfFileClaim(shouldPrintInternal, outputDir, documentTemplate, claimant, claim)
def context = createClaimantAndClaimContext(claimant, agreement, claim, packRequest.requestedByUsername)
def addPages = addPagesHelper(pageBuilder, outputPdf, outputRequirements, PageCostingType.COLOUR, documentReference)
def createStream = createStreamHelper(outputRequirements)

def invoicedDate = documentRequestDto.ppiDto.creditAgreementDto.claimDtos[0].invoicedDateTime?.toString("dd/MM/yyyy")

context.put('invoicedDate', invoicedDate)

packRequest.claimant.address.each {k,v -> deliveryAddress[k] = v}

addPages(createStream([TemplatePdfPages.ACCEPTANCE_LETTER_CHASE_COVER_LETTER]).withCustomerAddress(), context)

attachOnBaseDocs(addPages,packRequest,outputDir)

return outputPdf.closeAndRetrieveOutputFile()
