import org.slf4j.LoggerFactory

import pages.PageUtils

import com.leadx.documents.server.PageCostingType
import com.leadx.documents.server.generation.OutputRequirements
import com.leadx.documents.server.generation.PdfPage
import com.leadx.documents.server.generation.TemplatePdfPages

import context.Utils

def log = LoggerFactory.getLogger("com.leadx.documents.server.ClientCancellationLetter")

def claim = packRequest.creditAgreement[0].claim[0]
def lenderAgreementNumber = Utils.determineAgreementNumber(packRequest.creditAgreement[0], false)
def lenderReference = claim?.lenderReferenceNumber
def claimant = packRequest.claimant;
def agreement = packRequest.creditAgreement[0]

def context = context.ClaimContext.createClaimantAndClaimContext(claimant, agreement, claim)

context = context.ClaimContext.determineLenderAddress(claim, context )
context["lenderAddress"].each {k,v -> deliveryAddress[k] = v}
context.put("lenderAgreementNumber", lenderAgreementNumber)
context.put("lenderReference", lenderReference)
context.put("requestedByUsername",packRequest.requestedByUsername.replaceAll("\\.", " "))
context.put("lenderName", claim.additionalParams.lender.lenderName)
context.put("subDocumentRequests", packRequest.subDocumentRequests)
context.put("agentInitials", DocumentGenerationUtils2.initialsFromUsername(packRequest.requestedByUsername))
context.put("agreement.creditCardNumber", context.get("agreement.creditCardNumberUnMasked"))

if (Utils.isCreditCardAgreement(agreement.typeOfCredit)){
	context.put("agreementNumber", context.get("agreement.creditCardNumberUnMasked"))
}

final boolean printInternal = 'internal' == packRequest['printLocation']
context.put("printInternal", printInternal)
final OutputRequirements outputReqs = PageUtils.getOutputRequirements(printInternal)

def outputFile = PageUtils.createOutputPdfFileClaim(printInternal, outputDir, packRequest.documentTemplate, claimant, claim)
def addPages = PageUtils.addPagesHelper(pageBuilder, outputFile, outputReqs, PageCostingType.COLOUR, documentReference)
def createStream = PageUtils.createStreamHelper(outputReqs)

addPages(createStream([
	TemplatePdfPages.ACCEPTANCE_TO_LENDER_COVER_LETTER
]), context)


List<File> onBaseDocs = DocumentGenerationUtils2.getOnBaseDocs(packRequest, outputDir)
onBaseDocs.each {
	addPages([
		PdfPage.fromAPdf(it, false)
	], [:], PageCostingType.BLACK_AND_WHITE)
}

outputFile.close()
DocumentGenerationUtils2.clearUpOnBaseDocs(onBaseDocs)
return outputFile.getOutputFile()