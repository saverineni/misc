package com.leadx.documents.client

import java.io.OutputStream;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet 
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle 
import org.joda.time.LocalDate 
import org.joda.time.LocalDateTime;

import groovy.util.BuilderSupport;

/**
 * @author gareth.evans
 *
 */
class SpreadsheetBuilder extends BuilderSupport {
	
	private HSSFWorkbook workbook;
	
	// cell styles
	private CellStyle localDateTimeCellStyle, localDateCellStyle;

	private int rowIndex = 0;
	private int cellIndex = 0;
	
	protected void setParent(Object parent, Object child) {
	
	}
	
	protected Object createNode(Object name) {
		createNode(name, null, null)
	}
	
	protected Object createNode(Object name, Object value) {
		createNode(name, null, value)
	}
	
	protected Object createNode(Object name, Map attributes) {
		createNode(name, attributes, null)
	}
	
	protected Object createNode(Object name, Map attributes, Object value) {
		switch (name) {
			case 'sheet':
				return sheet(value)
			case 'row':
				return row()
			case 'cell':
				return cell(value)
			default:
				return null
		}
	}
	
	def createWorkbook() {
		def workbook = new HSSFWorkbook()
		def creationHelper = workbook.getCreationHelper()
		localDateTimeCellStyle = workbook.createCellStyle()
		localDateTimeCellStyle.setDataFormat( creationHelper.createDataFormat().getFormat('m/d/yy h:mm') )
		localDateCellStyle = workbook.createCellStyle()
		localDateCellStyle.setDataFormat( creationHelper.createDataFormat().getFormat('m/d/yy') )
		return workbook
	}
	
	def sheet(String name) {
		if ( !workbook) {
			workbook = createWorkbook()
		}
		rowIndex = 0
		workbook.createSheet(name)
	}
	
	def row() {
		cellIndex = 0
		HSSFSheet sheet = getCurrent()
		sheet.createRow(rowIndex++)
	}
	
	def cell(String value) {
		HSSFRow row = getCurrent()
		row.createCell(cellIndex++).setCellValue(value)
	}
	
	def cell(Number value) {
		HSSFRow row = getCurrent()
		row.createCell(cellIndex++).setCellValue(value)
	}
	
	def cell(boolean value) {
		HSSFRow row = getCurrent()
		row.createCell(cellIndex++).setCellValue(value)
	}
	
	def cell(LocalDate value) {
		HSSFRow row = getCurrent()
		def cell = row.createCell(cellIndex++)
		cell.setCellValue(value?.toDateTimeAtStartOfDay().toDate())
		cell.setCellStyle(localDateCellStyle)
	}
	
	def cell(LocalDateTime value) {
		HSSFRow row = getCurrent()
		def cell = row.createCell(cellIndex++)
		cell.setCellValue(value?.toDateTime().toDate())
		cell.setCellStyle(localDateTimeCellStyle)
	}
	
	def cell(Object value) {
		HSSFRow row = getCurrent()
		row.createCell(cellIndex++).setCellValue(value?.toString())
	}
	
	def writeTo(OutputStream outputStream) {
		workbook.write(outputStream)
	}
	
}
