package com.leadx.documents.client.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.leadx.claimant.client.AddressDto;

@JsonAutoDetect
public class ClaimantAndAddressDto {

	private com.leadx.claimant.client.ClaimantDto claimantDto;
	private List<AddressDto> addressDtos;
	
	
	public ClaimantAndAddressDto(final com.leadx.claimant.client.ClaimantDto claimantDto, final List<AddressDto> addressDtos) {
		this.claimantDto = claimantDto;
		this.addressDtos = addressDtos;
	}
	
	public ClaimantAndAddressDto() {
	}

	public com.leadx.claimant.client.ClaimantDto getClaimantDto() {
		return this.claimantDto;
	}

	public List<AddressDto> getAddressDtos() {
		return this.addressDtos;
	}

}
