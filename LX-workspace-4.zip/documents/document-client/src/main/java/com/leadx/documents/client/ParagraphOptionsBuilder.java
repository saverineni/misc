package com.leadx.documents.client;

import java.math.BigDecimal;

import com.itextpdf.text.BaseColor;

public class ParagraphOptionsBuilder {
	private Float size;
	private BaseColor color;
	private Integer alignment;
	private Float indent;
	private Integer style;
	private Integer lineSpacing;

	public ParagraphOptionsBuilder color(final BaseColor newColor) {
		this.color = newColor;
		return this;
	}

	public ParagraphOptionsBuilder size(final float newSize) {
		this.size = newSize;
		return this;
	}

	public ParagraphOptionsBuilder alignment(final int newAlignment) {
		this.alignment = newAlignment;
		return this;
	}

	public ParagraphOptionsBuilder indent(final BigDecimal newIndent) {
		this.indent = newIndent.floatValue();
		return this;
	}

	public ParagraphOptionsBuilder style(final int newStyle) {
		this.style = newStyle;
		return this;
	}

	public ParagraphOptionsBuilder lineSpacing(final int newLineSpacing) {
		this.lineSpacing = newLineSpacing;
		return this;
	}

	public BaseColor getColor() {
		return this.color;
	}

	public Float getSize() {
		return this.size;
	}

	public Integer getAlignment() {
		return this.alignment;
	}

	public Float getIndent() {
		return this.indent;
	}

	public Integer getStyle() {
		return this.style;
	}

	public Integer getLineSpacing() {
		return this.lineSpacing;
	}
}
