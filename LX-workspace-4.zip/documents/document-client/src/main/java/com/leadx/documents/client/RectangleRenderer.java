/**
 *
 */
package com.leadx.documents.client;

import java.io.IOException;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfStamper;

/**
 * @author pete.holmes
 */
public class RectangleRenderer extends PdfRenderer {
	
	private BaseColor fill;
	private BaseColor stroke;	
	
	public RectangleRenderer(final int pageNumber, final int x, final int y, final float height, final float width, final BaseColor fill, final BaseColor stroke) throws DocumentException, IOException{
		
		super.setHeight(height);
		super.setWidth(width);
		super.setPageNumber(pageNumber);
		super.setX(x);
		super.setY(y);		
				
		this.fill = fill;
		this.stroke = stroke;
	}
	
	public RectangleRenderer(final int x, final int y, final float height, final float width, final BaseColor fill, final BaseColor stroke) throws DocumentException, IOException{
		this(0, x, y, height, width, fill, stroke);
	}
	
	@Override
	public void render(final PdfStamper pdfStamper) throws DocumentException {
		render(pdfStamper, super.getPageNumber());
	}
		
	@Override
	public void render(final PdfStamper pdfStamper, final int pageNumber) throws DocumentException {		
		final PdfContentByte pdfContentByte = pdfStamper.getOverContent(pageNumber);		
		final Rectangle rect = new Rectangle(super.getX(), super.getY(), super.getX() + super.getWidth(), super.getY() + super.getHeight());		
		rect.setBackgroundColor(this.fill);
		rect.setBorderWidth(1f);		
		rect.setBorder(Rectangle.BOX);		
		rect.setBorderColor(this.stroke);		
		pdfContentByte.rectangle(rect);		
	}

	public BaseColor getFill() {
		return this.fill;
	}

	public void setFill(BaseColor fill) {
		this.fill = fill;
	}

	public BaseColor getStroke() {
		return this.stroke;
	}

	public void setStroke(BaseColor stroke) {
		this.stroke = stroke;
	}
}
