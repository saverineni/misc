package com.leadx.documents.client;

import java.math.BigInteger;

import org.docx4j.jaxb.Context;
import org.docx4j.openpackaging.exceptions.Docx4JException;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.wml.CTBorder;
import org.docx4j.wml.ObjectFactory;
import org.docx4j.wml.STBorder;
import org.docx4j.wml.Tbl;
import org.docx4j.wml.TblBorders;
import org.docx4j.wml.TblPr;
import org.docx4j.wml.TblWidth;
import org.docx4j.wml.Tc;
import org.docx4j.wml.TcPr;
import org.docx4j.wml.Tr;

public class SettingColumnWidthForTable {
	private static WordprocessingMLPackage wordMLPackage;
	private static ObjectFactory factory;

	/**
	 * &nbsp;We create a table with borders and then add a row to it. Then we add &nbsp;two cells with content and the given width to it.
	 */
	public static void main(final String[] args) throws Docx4JException {
		wordMLPackage = WordprocessingMLPackage.createPackage();
		factory = Context.getWmlObjectFactory();

		final Tbl table = factory.createTbl();
		addBorders(table);

		final Tr tr = factory.createTr();

		addTableCellWithWidth(tr, "Field 1", 2500);
		addTableCellWithWidth(tr, "Field 2", 0);

		table.getContent()
			.add(tr);

		wordMLPackage.getMainDocumentPart()
			.addObject(table);
		wordMLPackage.save(new java.io.File("src/main/resources/HelloWord13.docx"));
	}

	/**
	 * &nbsp;In this method we create a cell and add the given content to it. &nbsp;If the given width is greater than 0, we set the width on the cell.
	 * &nbsp;Finally, we add the cell to the row.
	 */
	private static void addTableCellWithWidth(final Tr row, final String content, final int width) {
		final Tc tableCell = factory.createTc();
		tableCell.getContent()
			.add(wordMLPackage.getMainDocumentPart()
				.createParagraphOfText(content));

		if (width > 0) {
			setCellWidth(tableCell, width);
		}
		row.getContent()
			.add(tableCell);
	}

	/**
	 * &nbsp;In this method we create a table cell properties object and a table width &nbsp;object. We set the given width on the width object and then add it
	 * to &nbsp;the&nbsp;properties object. Finally we set the properties on the table cell.
	 */
	private static void setCellWidth(final Tc tableCell, final int width) {
		final TcPr tableCellProperties = new TcPr();
		final TblWidth tableWidth = new TblWidth();
		tableWidth.setW(BigInteger.valueOf(width));
		tableCellProperties.setTcW(tableWidth);
		tableCell.setTcPr(tableCellProperties);
	}

	/**
	 * &nbsp;In this method we'll add the borders to the table.
	 */
	private static void addBorders(final Tbl table) {
		table.setTblPr(new TblPr());
		final CTBorder border = new CTBorder();
		border.setColor("auto");
		border.setSz(new BigInteger("4"));
		border.setSpace(new BigInteger("0"));
		border.setVal(STBorder.SINGLE);

		final TblBorders borders = new TblBorders();
		borders.setBottom(border);
		borders.setLeft(border);
		borders.setRight(border);
		borders.setTop(border);
		borders.setInsideH(border);
		borders.setInsideV(border);
		table.getTblPr()
			.setTblBorders(borders);
	}
}
