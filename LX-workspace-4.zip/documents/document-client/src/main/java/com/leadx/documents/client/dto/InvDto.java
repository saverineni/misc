package com.leadx.documents.client.dto;

import com.leadx.web.tcg.client.claimservice.InvestmentAgreementDto;

import java.util.List;

public class InvDto {

    private List<InvestmentAgreementDto> investmentAgreementDto;
    private ClaimantDto claimantDto;

    public InvDto(){}

    public InvDto(final List<InvestmentAgreementDto> investmentAgreementDto, final ClaimantDto claimantDto) {
        this.investmentAgreementDto = investmentAgreementDto;
        this.claimantDto = claimantDto;
    }

    public List<InvestmentAgreementDto> getInvestmentAgreementDto() {
        return investmentAgreementDto;
    }

    public void setInvestmentAgreementDto(List<InvestmentAgreementDto> investmentAgreementDto) {
        this.investmentAgreementDto = investmentAgreementDto;
    }

    public ClaimantDto getClaimantDto() {
        return claimantDto;
    }

    public void setClaimantDto(ClaimantDto claimantDto) {
        this.claimantDto = claimantDto;
    }
}
