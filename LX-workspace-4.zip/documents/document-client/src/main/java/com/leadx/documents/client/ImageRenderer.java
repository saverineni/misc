/**
 *
 */
package com.leadx.documents.client;

import java.io.IOException;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfStamper;

/**
 * @author pete.holmes
 */
public class ImageRenderer extends PdfRenderer {

	private Image image;

	public ImageRenderer(final int pageNumber, final String image, final int x, final int y, final float height, final float width)
			throws DocumentException, IOException {

		super.setPageNumber(pageNumber);
		super.setHeight(height);
		super.setWidth(width);
		super.setX(x);
		super.setY(y);

		this.image = Image.getInstance(image);
		this.image.setAbsolutePosition(x, y);
		this.image.scaleAbsolute(width, height);
	}

	public ImageRenderer(final String image, final int x, final int y, final float height, final float width) throws DocumentException,
			IOException {
		this(0, image, x, y, height, width);
	}

	@Override
	public void render(final PdfStamper pdfStamper) throws DocumentException {
		render(pdfStamper, super.getPageNumber());
	}

	@Override
	public void render(final PdfStamper pdfStamper, final int pageNumber) throws DocumentException {
		final PdfContentByte pdfContentByte = pdfStamper.getOverContent(pageNumber);
		pdfContentByte.addImage(this.image);
	}

	public Image getImage() {
		return this.image;
	}

	public void setImage(Image image) {
		this.image = image;
	}
}
