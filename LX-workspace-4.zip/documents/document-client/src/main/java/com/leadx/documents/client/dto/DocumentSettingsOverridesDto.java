package com.leadx.documents.client.dto;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

/** Allows document level overrides to be passed over to doc server. */
@JsonAutoDetect
public class DocumentSettingsOverridesDto {
	public DocumentSettingsOverridesDto(final boolean forceReturn, final boolean forceStitch, final boolean forceEmail, final boolean forceStorePublicly) {
		this.forceReturn = forceReturn;
		this.forceStitch = forceStitch;
		this.forceEmail = forceEmail;
		this.forceStorePublicly = forceStorePublicly;
	}

	public DocumentSettingsOverridesDto() {
	}

	public boolean isForceReturn() {
		return forceReturn;
	}

	public boolean isForceStitch() {
		return forceStitch;
	}

	public boolean isForceEmail() {
		return forceEmail;
	}

	public boolean isForceStorePublicly() {
		return forceStorePublicly;
	}

	private boolean forceReturn;
	private boolean forceStitch;
	private boolean forceEmail;
	private boolean forceStorePublicly;
}
