package com.leadx.documents.client.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.leadx.web.tcg.client.claimservice.CreditAgreementAndClaimDto;

@JsonAutoDetect
public class CreditAgreementDto {
	public CreditAgreementDto(final int id, final List<ClaimDto> claimDtos) {
		this.id = id;
		this.claimDtos = claimDtos;
	}

	public CreditAgreementDto() {
	}

	public int getId() {
		return this.id;
	}
	public List<ClaimDto> getClaimDtos() {
		return this.claimDtos;
	}

	private int id;
	private List<ClaimDto> claimDtos;

}
