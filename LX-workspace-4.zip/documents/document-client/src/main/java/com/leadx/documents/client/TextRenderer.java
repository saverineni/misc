/**
 *
 */
package com.leadx.documents.client;

import java.io.IOException;

import org.apache.commons.lang3.text.WordUtils;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfStamper;

/**
 * @author Gareth.Evans
 */
public class TextRenderer extends PdfRenderer {

	private int fontSize;
	private BaseFont baseFont;
	private String[] lines;
	private int alignment;
	private boolean firstPageOnly;

	/**
	 * @param pageNumber
	 * @param x
	 * @param y
	 * @param fontSize
	 * @param baseFont
	 * @param lines
	 */
	public TextRenderer(final int pageNumber, final int x, final int y, final int fontSize, final BaseFont baseFont, final int alignment,
			final String... lines) {

		super.setPageNumber(pageNumber);
		super.setX(x);
		super.setY(y);
		this.fontSize = fontSize;
		this.baseFont = baseFont;
		this.lines = lines;
		this.alignment = alignment;
	}

	/**
	 * @param pageNumber
	 * @param x
	 * @param y
	 * @param fontSize
	 * @param baseFont
	 * @param line
	 * @param wrapAfter
	 */
	public TextRenderer(final int pageNumber, final int x, final int y, final int fontSize, final BaseFont baseFont, final String line,
			final int wrapAfter) {
		this(pageNumber, x, y, fontSize, baseFont, PdfContentByte.ALIGN_LEFT, wordWrap(line, wrapAfter));
	}

	/**
	 * @param pageNumber
	 * @param x
	 * @param y
	 * @param fontSize
	 * @param line
	 * @param wrapAfter
	 * @throws IOException
	 * @throws DocumentException
	 */
	public TextRenderer(final int pageNumber, final int x, final int y, final int fontSize, final String line, final int wrapAfter)
			throws DocumentException, IOException {
		this(pageNumber, x, y, fontSize, PdfUtils.getDefaultFont(), PdfContentByte.ALIGN_LEFT, wordWrap(line, wrapAfter));
	}

	public TextRenderer(final int x, final int y, final int fontSize, final String line, final int alignment, final int wrapAfter) {
		this(0, x, y, fontSize, PdfUtils.getDefaultFont(), alignment, wordWrap(line, wrapAfter));
	}

	public TextRenderer(final int x, final int y, final int fontSize, final String line, final int alignment, final int wrapAfter,
			final boolean firstPageOnly) {
		this(0, x, y, fontSize, PdfUtils.getDefaultFont(), alignment, wordWrap(line, wrapAfter));
		this.firstPageOnly = firstPageOnly;
	}

	public TextRenderer(final int pageNumber, final int x, final int y, final int fontSize, final String line, final int alignment,
			final int wrapAfter) {
		this(pageNumber, x, y, fontSize, PdfUtils.getDefaultFont(), alignment, wordWrap(line, wrapAfter));
	}

	/**
	 * @param pageNumber
	 * @param x
	 * @param y
	 * @param fontSize
	 * @param line
	 * @param wrapAfter
	 * @throws IOException
	 * @throws DocumentException
	 */
	public TextRenderer(final int x, final int y, final int fontSize, final String line, final int wrapAfter) throws DocumentException,
			IOException {
		this(0, x, y, fontSize, PdfUtils.getDefaultFont(), PdfContentByte.ALIGN_LEFT, wordWrap(line, wrapAfter));
	}

	/**
	 * @param pageNumber
	 * @param x
	 * @param y
	 * @param fontSize
	 * @param lines
	 * @throws DocumentException
	 * @throws IOException
	 */
	public TextRenderer(final int pageNumber, final int x, final int y, final int fontSize, final String... lines)
			throws DocumentException, IOException {
		this(pageNumber, x, y, fontSize, PdfUtils.getDefaultFont(), PdfContentByte.ALIGN_LEFT, lines);
	}

	/* (non-Javadoc)
	 * @see com.leadx.lib.utl.pdf.Renderable#render()
	 */
	@Override
	public void render(final PdfStamper pdfStamper) {
		render(pdfStamper, super.getPageNumber());
	}

	@Override
	public void render(final PdfStamper pdfStamper, final int pageNumber) {
		final PdfContentByte pdfContentByte = pdfStamper.getOverContent(pageNumber);
		pdfContentByte.beginText();
		pdfContentByte.setFontAndSize(this.baseFont, this.fontSize);

		int startingY = super.getY();

		// we show some text starting on some absolute position with a given alignment
		if (!this.firstPageOnly || pageNumber == 1) {
			for (final String textLine : this.lines) {
				pdfContentByte.showTextAligned(this.alignment, textLine, super.getX(), startingY, 0);
				startingY -= (this.fontSize + 2);
			}
		}

		// we tell the contentByte, we've finished drawing text
		pdfContentByte.endText();
	}

	/**
	 * @param text
	 * @param string
	 * @param i
	 * @return
	 */
	protected static String[] wordWrap(final String text, final int maxLineLength) {
		return WordUtils.wrap(text, maxLineLength)
			.split("\\r\\n|\\n|\\r");
	}

	public int getFontSize() {
		return this.fontSize;
	}

	public void setFontSize(final int fontSize) {
		this.fontSize = fontSize;
	}

	public BaseFont getBaseFont() {
		return this.baseFont;
	}

	public void setBaseFont(final BaseFont baseFont) {
		this.baseFont = baseFont;
	}

	public String[] getLines() {
		return this.lines;
	}

	public void setLines(final String[] lines) {
		this.lines = lines;
	}
}
