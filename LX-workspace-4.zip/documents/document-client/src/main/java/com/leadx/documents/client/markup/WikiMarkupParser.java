package com.leadx.documents.client.markup;

import static com.leadx.documents.client.markup.Style.BOLD;
import static com.leadx.documents.client.markup.Style.ITALIC;
import static com.leadx.documents.client.markup.Style.UNDERLINE;
import static java.util.EnumSet.of;

import com.itextpdf.text.ListItem;
import com.itextpdf.text.Paragraph;

/**
 * Searches for allowable markup within a string and generates separate Phrases as required by the markup. It uses an instance of WikiMarkupVisitor to do the
 * actual operations on the pdf phrases so that the visitor can control exactly which fonts to use etc.
 */
public class WikiMarkupParser {

	private final WikiMarkupVisitor visitor;

	public WikiMarkupParser(final WikiMarkupVisitor visitor) {
		this.visitor = visitor;
	}

	public void parseForParagraph(final String input) {
		final String[] lines = input.split("\n\n");
		for (final String line : lines) {
			final Paragraph p = this.visitor.startParagraph();
			this.visitor.indentParagraph(p);
			addPhrases(p, line);
			this.visitor.endParagraph(p);
		}
	}

	public void parseForParagraphWithLineSpacing(final String input, final int lineSpacing) {
		final String[] lines = input.split("\n\n");
		for (final String line : lines) {
			final Paragraph p = this.visitor.startParagraph(lineSpacing);
			this.visitor.indentParagraph(p);
			addPhrases(p, line);
			this.visitor.endParagraph(p);
		}
	}

	public Paragraph parseAndReturnParagraph(final String input) {
		final String[] lines = input.split("\n\n");
		Paragraph p = null;

		for (final String line : lines) {
			p = this.visitor.startParagraph();
			this.visitor.indentParagraph(p);
			addPhrases(p, line);
		}

		return p;
	}

	public void parseForJustifiedParagraph(final String input) {
		final String[] lines = input.split("\n\n");
		for (final String line : lines) {
			final Paragraph p = this.visitor.startParagraph();
			this.visitor.alignParagraph(p);
			this.visitor.indentParagraph(p);
			addPhrases(p, line);
			this.visitor.endParagraph(p);
		}
	}

	public void parseForListItem(final ListItem item, final String input) {
		final String[] lines = input.split("\n\n");
		for (final String line : lines) {
			addPhrases(item, line);
		}
	}

	// Create a series of Phrases based on the markup and adds them to the specified paragraph. As a list item is also a paragraph this works with
	// paragraphs or list items.
	private void addPhrases(final Paragraph p, final String line) {
		final String trimmedLineWithoutWhitespace = line.trim()
			.replaceAll("\\s", " ");

		final int lineLength = trimmedLineWithoutWhitespace.length();
		int startParseLoction = 0;
		int index = 0;
		final StringBuilder sb = new StringBuilder(trimmedLineWithoutWhitespace);

		if (trimmedLineWithoutWhitespace.isEmpty()) {
			this.visitor.write(p, "", null);
		}

		while (index < sb.length()) {
			final char character = sb.charAt(index);

			if (isReservedCharacter(index, sb)) {

				if (startParseLoction != index) {
					this.visitor.write(p, sb.substring(startParseLoction, index), null);
				}

				// startParseLoction = index + 1;
				startParseLoction = getStartParseLocation(character, sb, index);

				// final int nextIndex = sb.indexOf(Character.toString(character), startParseLoction + 1);
				final int nextIndex = sb.indexOf(Character.toString(character), getEndParseLocation(character, sb, startParseLoction));

				final String text = sb.substring(startParseLoction, nextIndex);

				switch (character) {
					case '*':
						this.visitor.write(p, text, of(BOLD));
						break;
					// Removed as causing too many issues in docs and we don't actually use it anywhere
					// case '-':
					// this.visitor.write(p, text, of(STRIKETHRU));
					// break;
					case '_':
						this.visitor.write(p, text, of(ITALIC));
						break;
					case '+':
						this.visitor.write(p, text, of(UNDERLINE));
						break;
					case '{':
						this.visitor.write(p, text, of(UNDERLINE));
						break;
					default:
						this.visitor.write(p, text, null);
				}

				startParseLoction = nextIndex + 1;
				index = nextIndex + 1;
			}

			index++;
		}

		if (startParseLoction != lineLength) {
			this.visitor.write(p, sb.substring(startParseLoction, Math.min(index, lineLength)), null);
		}
	}

	private static int getStartParseLocation(final char reservedChar, final StringBuilder sb, final int currentIndex) {

		if (reservedChar != '{') {
			return currentIndex + 1;
		}
		return sb.indexOf("}");
	}

	private static int getEndParseLocation(final char reservedChar, final StringBuilder sb, final int startPosition) {

		if (reservedChar != '{') {
			return startPosition + 1;
		}
		return sb.indexOf("}", startPosition);
	}

	private static boolean isReservedCharacter(final int index, final StringBuilder sb) {
		final char character = sb.charAt(index);
		if (character == '*' || character == '_' || character == '+' || character == '{') {
			return sb.indexOf(Character.toString(character), index + 1) != -1;
		}
		return false;
	}
}
