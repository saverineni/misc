package com.leadx.documents.client;

import java.io.IOException;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfStamper;

public abstract class PdfRenderer implements Renderable {
	
	private int pageNumber;
	private float height;
	private float width;
	private int x;
	private int y;	

	@Override
	public abstract void render(PdfStamper pdfStamper) throws DocumentException, IOException;

	@Override
	public abstract void render(PdfStamper pdfStamper, int pageNumber)throws DocumentException, IOException;
	
	public int getPageNumber() {
		return this.pageNumber;
	}

	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}

	public float getHeight() {
		return this.height;
	}

	public void setHeight(float height) {
		this.height = height;
	}

	public float getWidth() {
		return this.width;
	}

	public void setWidth(float width) {
		this.width = width;
	}

	public int getX() {
		return this.x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return this.y;
	}

	public void setY(int y) {
		this.y = y;
	}
}
