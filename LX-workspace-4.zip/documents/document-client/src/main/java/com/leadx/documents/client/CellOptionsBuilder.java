package com.leadx.documents.client;

/** Various options to set on a table cell. Defaults to Null which means they won't be applied. Can simply be extended if we need to add extra
 * control to individual cells. */
public class CellOptionsBuilder {
	public CellOptionsBuilder() {
	}

	/** Convenience constructors to allow border and padding to be quickly set. */
	public CellOptionsBuilder(Integer border) {
		this.border = border;
	}

	public CellOptionsBuilder(Integer border, Float padding) {
		this.border = border;
		this.padding = padding;
	}

	private Integer border;

	private Float padding;
	private Float paddingTop;
	private Float paddingLeft;
	private Float paddingBottom;
	private Float paddingRight;

	public Integer getBorder() {
		return this.border;
	}

	/** To set more than one border use for example Rectangle.BOTTOM_BORDER + Rectangle.RIGHT_BORDER */
	public CellOptionsBuilder setBorder(Integer border) {
		this.border = border;
		return this;
	}

	public Float getPadding() {
		return this.padding;
	}

	public CellOptionsBuilder setPadding(Float padding) {
		this.padding = padding;
		return this;
	}

	public Float getPaddingTop() {
		return this.paddingTop;
	}

	public CellOptionsBuilder setPaddingTop(Float paddingTop) {
		this.paddingTop = paddingTop;
		return this;
	}

	public Float getPaddingLeft() {
		return this.paddingLeft;
	}

	public CellOptionsBuilder setPaddingLeft(Float paddingLeft) {
		this.paddingLeft = paddingLeft;
		return this;
	}

	public Float getPaddingBottom() {
		return this.paddingBottom;
	}

	public CellOptionsBuilder setPaddingBottom(Float paddingBottom) {
		this.paddingBottom = paddingBottom;
		return this;
	}

	public Float getPaddingRight() {
		return this.paddingRight;
	}

	public CellOptionsBuilder setPaddingRight(Float paddingRight) {
		this.paddingRight = paddingRight;
		return this;
	}
}
