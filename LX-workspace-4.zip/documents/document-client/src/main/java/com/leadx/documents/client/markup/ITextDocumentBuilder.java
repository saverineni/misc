package com.leadx.documents.client.markup;

import static org.eclipse.mylyn.wikitext.core.parser.DocumentBuilder.BlockType.PARAGRAPH;

import java.util.Deque;
import java.util.LinkedList;

import org.apache.commons.lang3.NotImplementedException;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.mylyn.wikitext.core.parser.Attributes;
import org.eclipse.mylyn.wikitext.core.parser.DocumentBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.List;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;

public class ITextDocumentBuilder extends DocumentBuilder {

	private static final String COLOR_TAG = "color: ";

	private static final Logger LOG = LoggerFactory.getLogger(ITextDocumentBuilder.class);

	private final Document document;

	private Deque<BlockType> blockTypeStack = new LinkedList<DocumentBuilder.BlockType>();
	private Deque<SpanType> spanTypeStack = new LinkedList<DocumentBuilder.SpanType>();

	private List list;
	private Font font = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);

	private boolean headerMode;

	public ITextDocumentBuilder(final Document document) {
		this.document = document;

	}

	@Override
	public void acronym(final String arg0, final String arg1) {
		throw new NotImplementedException("");
	}

	@Override
	public void beginBlock(final BlockType blockTypeVal, final Attributes attributes) {
		this.blockTypeStack.add(blockTypeVal);
		if (LOG.isDebugEnabled()) {
			LOG.debug(String.format("beginBlock(%s,%s)", blockTypeVal, attributes.getCssStyle()));
		}

		handleAttributes(attributes);

		switch (blockTypeVal) {
			case BULLETED_LIST:
				this.list = new List();
				return;
			case NUMERIC_LIST:
				this.list = new List(true);
				return;
		}
	}

	@Override
	public void beginDocument() {
		if (!this.document.isOpen()) {
			this.document.open();
		}
	}

	@Override
	public void beginHeading(final int header, final Attributes attributes) {
		this.blockTypeStack.add(PARAGRAPH);
		this.headerMode = true;
		configureFontSize(getHeaderFontSize(header));
		configureFontColor(BaseColor.BLUE);
	}

	private static int getHeaderFontSize(final int header) {
		if (1 == header) {
			return 20;
		}
		if (2 == header) {
			return 18;
		}
		if (3 == header) {
			return 16;
		}
		if (4 == header) {
			return 14;
		}
		if (5 == header) {
			return 12;
		}
		return 11;
	}

	@Override
	public void beginSpan(final SpanType spanType, final Attributes attributes) {
		if (LOG.isDebugEnabled()) {
			LOG.debug(String.format("beginSpan(%s,%s)", spanType, attributes.getCssStyle()));
		}
		this.spanTypeStack.add(spanType);
		switch (spanType) {
			case STRONG:
				configureFontStyle(Font.BOLD);
				return;
			case EMPHASIS:
				configureFontStyle(Font.ITALIC);
				return;
			case DELETED:
				configureFontStyle(Font.STRIKETHRU);
				return;
			case UNDERLINED:
				configureFontStyle(Font.UNDERLINE);
				return;
			case MONOSPACE:
				configureFontFace(FontFactory.COURIER);
				return;
		}
	}

	@Override
	public void characters(final String characters) {
		final BlockType blockType = this.blockTypeStack.peekLast();
		if (LOG.isDebugEnabled()) {
			LOG.debug(String.format("characters(%s), blockType=%s", characters, blockType));
		}
		try {
			switch (blockType) {
				case PARAGRAPH:
					if (this.headerMode) {
						this.document.add(new Paragraph(characters, this.font));
					}
					else {
						this.document.add(new Phrase(characters, this.font));
					}
					return;
				case LIST_ITEM:
					this.list.add(new ListItem(characters, this.font));
					return;
				default:
					throw new RuntimeException("Unknown blockType :" + blockType);
			}

		}
		catch (final DocumentException e) {
			throw new RuntimeException("Unable to add paragraph", e);
		}
	}

	@Override
	public void charactersUnescaped(final String arg0) {
		throw new NotImplementedException("");
	}

	@Override
	public void endBlock() {
		final BlockType blockType = this.blockTypeStack.pollLast();
		if (LOG.isDebugEnabled()) {
			LOG.debug(String.format("endBlock(%s)", blockType));
		}
		try {
			switch (blockType) {
				case BULLETED_LIST:
					this.document.add(this.list);
					this.list = null;
					return;
				case NUMERIC_LIST:
					this.document.add(this.list);
					this.list = null;
					return;
				case DIV:
					configureFontColor(BaseColor.BLACK);
					return;
			}
		}
		catch (final DocumentException e) {
			throw new RuntimeException("Unable to add paragraph", e);
		}
	}

	@Override
	public void endDocument() {
		// not required
	}

	@Override
	public void endHeading() {
		if (LOG.isDebugEnabled()) {
			LOG.debug(String.format("endHeading()"));
		}
		this.headerMode = false;
		this.blockTypeStack.pollLast();
		configureFontSize(10);
		configureFontColor(BaseColor.BLACK);
	}

	@Override
	public void endSpan() {
		final SpanType spanType = this.spanTypeStack.pollLast();
		if (LOG.isDebugEnabled()) {
			LOG.debug(String.format("endSpan(%s)", spanType));
		}
		if (null != spanType) {
			switch (spanType) {
				case MONOSPACE:
					configureFontFace(FontFactory.HELVETICA);
					return;
				case UNDERLINED:
				case DELETED:
				case EMPHASIS:
				case STRONG:
					configureFontStyle(Font.NORMAL);
					return;
			}
		}

	}

	@Override
	public void entityReference(final String arg0) {
		throw new NotImplementedException("");
	}

	@Override
	public void image(final Attributes arg0, final String arg1) {
		throw new NotImplementedException("");
	}

	@Override
	public void imageLink(final Attributes arg0, final Attributes arg1, final String arg2, final String arg3) {
		throw new NotImplementedException("");
	}

	@Override
	public void lineBreak() {
		try {
			this.document.add(new Paragraph("\n", this.font));
		}
		catch (final DocumentException e) {
			throw new RuntimeException("Unable to add lineBreak", e);
		}
	}

	@Override
	public void link(final Attributes arg0, final String arg1, final String arg2) {
		throw new NotImplementedException("");
	}

	private void handleAttributes(final Attributes attributes) {
		final String cssStyle = attributes.getCssStyle();
		if (StringUtils.isEmpty(cssStyle)) {
			return;
		}

		if (cssStyle.contains(COLOR_TAG)) {
			final int startIndex = cssStyle.indexOf(COLOR_TAG) + COLOR_TAG.length();
			final String colorName = cssStyle.substring(startIndex, cssStyle.indexOf(";", startIndex));

			try {
				configureFontColor((BaseColor) BaseColor.class.getField(colorName.toUpperCase())
					.get(null));
			}
			catch (final Exception e) {
				throw new RuntimeException("Unable to set color", e);
			}
		}
	}

	private void configureFontSize(final int fontSize) {
		this.font = FontFactory.getFont(this.font.getFamilyname(), fontSize, this.font.getStyle(), this.font.getColor());
	}

	private void configureFontColor(final BaseColor fontColor) {
		this.font = FontFactory.getFont(this.font.getFamilyname(), this.font.getSize(), this.font.getStyle(), fontColor);
	}

	private void configureFontStyle(final int fontStyle) {
		this.font = FontFactory.getFont(this.font.getFamilyname(), this.font.getSize(), fontStyle, this.font.getColor());
	}

	private void configureFontFace(final String fontFace) {
		this.font = FontFactory.getFont(fontFace, this.font.getSize(), this.font.getStyle(), this.font.getColor());
	}

}
