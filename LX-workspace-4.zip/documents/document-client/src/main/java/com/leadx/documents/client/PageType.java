package com.leadx.documents.client;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum PageType {
	LOA(1, "LOA"),
	LENDER_QUESTIONNAIRE(2, "Lender Questionnaire"),
	FOS(3, "FOS"),
	PDLQ(4, "Payday Loan Questionnaire"),
	INVQ(5, "Investment Questionnaire"),
	FSCSQ(6, "FSCS Questionnaire"),
	SIPPQ(7, "SIPP Questionnaire"),
	DBT(8,"DBT Questionnaire");

	private int id;
	private String name;


	PageType(final int id, final String name) {
		this.id = id;
		this.name = name;
	}

	public String getName(){
		return this.name;
	}

	@JsonValue
	public int getId() {
		return this.id;
	}

	@JsonCreator
	public static PageType getById(final int id) {
		for (final PageType pageType : values()) {
			if (pageType.getId() == id) {
				return pageType;
			}
		}
		return null;
	}

}
