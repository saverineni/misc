package com.leadx.documents.client.dto;

/** Corresponds to entries in outstanding_item_type_group table. First entry of NONE is to force ordinal of enum to match
 * the id in the table, to avoid defining a separate integer value in the class
 */
public enum OutstandingItemTypeGroup {
	NONE,
	FIRST_LETTER_OF_CLAIM,
	TRACE,
	INCOMPLETE_FOS_INFORMATION,
	DSAR_RFI,
	PDLQ,
	PDL_RFI,
	INVESTMENT_QUESTIONNAIRE,
	INV_RFI,
	ISA_QUESTIONNAIRE,
	ISA_RFI,
	PENSION_QUESTIONNAIRE,
	PENSION_RFI,
	WHOLE_OF_LIFE_QUESTIONNAIRE,
	WOL_RFI,
	FSCS,
	DSAR_DOCUMENT_CHECK_LIST,
	PLEVIN_DSAR

}
