package com.leadx.documents.client.dto;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect
public class DocumentRequestDto {
	private PpiDto ppiDto;
	private PbaDto pbaDto;
	private StlDto stlDto;
	private InvDto invDto;
	private PenDto penDto;
	private ClaimantAndAddressDto claimantAndAddressDto;
	private DocumentSettingsOverridesDto documentSettingsOverridesDto;
	private Integer mailingId;
	private Integer templateId;
	private boolean sampleMailing;
	private String overrideFilename;
	private String password;

	public DocumentRequestDto(PpiDto ppiDto, PbaDto pbaDto, StlDto stlDto, InvDto invDto, PenDto penDto, ClaimantAndAddressDto claimantAndAddressDto,
			DocumentSettingsOverridesDto documentSettingsOverridesDto, Integer mailingId, Integer templateId, boolean sampleMailing, String overrideFilename,
			String password) {
		this.ppiDto = ppiDto;
		this.pbaDto = pbaDto;
		this.stlDto = stlDto;
		this.invDto = invDto;
		this.penDto = penDto;
		this.claimantAndAddressDto = claimantAndAddressDto;
		this.documentSettingsOverridesDto = documentSettingsOverridesDto;
		this.mailingId = mailingId;
		this.templateId = templateId;
		this.sampleMailing = sampleMailing;
		this.overrideFilename = overrideFilename;
		this.password = password;
	}

	public DocumentRequestDto() {
	}

	public PpiDto getPpiDto() {
		return this.ppiDto;
	}

	public void setPpiDto(PpiDto ppiDto) {
		this.ppiDto = ppiDto;
	}

	public PbaDto getPbaDto() {
		return this.pbaDto;
	}

	public void setPbaDto(PbaDto pbaDto) {
		this.pbaDto = pbaDto;
	}

	public StlDto getStlDto() {
		return stlDto;
	}

	public void setStlDto(StlDto stlDto) {
		this.stlDto = stlDto;
	}

	public InvDto getInvDto() {
		return invDto;
	}

	public void setInvDto(InvDto invDto) {
		this.invDto = invDto;
	}

	public PenDto getPenDto() { return penDto; }

	public void setPenDto() { this.penDto = penDto; }

	public ClaimantAndAddressDto getClaimantAndAddressDto() {
		return this.claimantAndAddressDto;
	}

	public void setClaimantAndAddressDto(ClaimantAndAddressDto claimantAndAddressDto) {
		this.claimantAndAddressDto = claimantAndAddressDto;
	}

	public DocumentSettingsOverridesDto getDocumentSettingsOverridesDto() {
		return this.documentSettingsOverridesDto;
	}

	public void setDocumentSettingsOverridesDto(DocumentSettingsOverridesDto documentSettingsOverridesDto) {
		this.documentSettingsOverridesDto = documentSettingsOverridesDto;
	}

	public Integer getMailingId() {
		return this.mailingId;
	}

	public void setMailingId(Integer mailingId) {
		this.mailingId = mailingId;
	}

	public Integer getTemplateId() {
		return this.templateId;
	}

	public void setTemplateId(Integer templateId) {
		this.templateId = templateId;
	}

	public boolean isSampleMailing() {
		return sampleMailing;
	}

	public void setSampleMailing(final boolean sampleMailing) {
		this.sampleMailing = sampleMailing;
	}

	public String getOverrideFilename() {
		return overrideFilename;
	}

	public void setOverrideFilename(String overrideFilename) {
		this.overrideFilename = overrideFilename;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
