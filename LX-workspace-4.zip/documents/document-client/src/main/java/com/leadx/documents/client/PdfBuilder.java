package com.leadx.documents.client;

import static com.leadx.documents.client.markup.Style.BOLD;
import static com.leadx.documents.client.markup.Style.ITALIC;
import static com.leadx.documents.client.markup.Style.STRIKETHRU;
import static com.leadx.documents.client.markup.Style.UNDERLINE;
import groovy.util.BuilderSupport;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Map;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.NotImplementedException;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.util.HSSFColor;
import org.eclipse.mylyn.wikitext.confluence.core.ConfluenceLanguage;
import org.eclipse.mylyn.wikitext.core.parser.MarkupParser;
import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.List;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfWriter;
import com.leadx.documents.client.markup.ITextDocumentBuilder;
import com.leadx.documents.client.markup.Style;
import com.leadx.documents.client.markup.WikiMarkupParser;
import com.leadx.documents.client.markup.WikiMarkupVisitor;

/**
 * @author gareth.evans
 */
public class PdfBuilder extends BuilderSupport implements WikiMarkupVisitor {

	public static final float OVERSIZED_A4_X = 650.0f;
	public static final float OVERSIZED_A4_Y = 919.0f;

	private static final Logger LOG = LoggerFactory.getLogger(PdfBuilder.class);

	private static BaseColor DEFAULT_COLOUR = BaseColor.BLACK;
	private static BaseColor BLUE = new BaseColor(83, 157, 234);
	private static BaseColor DARK_BLUE = new BaseColor(17, 38, 153);
	public static BaseColor GREEN = new BaseColor(0, 100, 0);
	private static final BaseColor DARK_GREEN = new BaseColor(0, 176, 80);

	private static final float DEFAULT_SIZE = 11f;
	private static final int DEFAULT_ALIGNMENT = Element.ALIGN_JUSTIFIED;
	private static final int DEFAULT_LEFT_INDENT = 0;
	private static final float DEFAULT_INNER_MARGIN = 0;
	private static final int DEFAULT_STYLE = Font.NORMAL;
	private static final int DEFAULT_LINE_SPACING = 16;

	private static final Font FONT_H1 = new Font(PdfUtils.getDefaultBoldFont(), 20f, Font.NORMAL, BLUE);
	private static final Font FONT_H2 = new Font(PdfUtils.getDefaultBoldFont(), 18f, Font.NORMAL, BLUE);
	private static final Font FONT_H3 = new Font(PdfUtils.getDefaultBoldFont(), 16f, Font.NORMAL, BLUE);
	private static final Font FONT_H4 = new Font(PdfUtils.getDefaultBoldFont(), 14f, Font.NORMAL, BLUE);
	private static final Font FONT_H5 = new Font(PdfUtils.getDefaultBoldFont(), 12f, Font.NORMAL, BLUE);
	private static final Font FONT_H6 = new Font(PdfUtils.getDefaultBoldFont(), 11f, Font.NORMAL, BLUE);

	private static final Font FONT_H1_DARK = new Font(PdfUtils.getDefaultBoldFont(), 20f, Font.NORMAL, DARK_BLUE);
	private static final Font FONT_H2_DARK = new Font(PdfUtils.getDefaultBoldFont(), 18f, Font.NORMAL, DARK_BLUE);
	private static final Font FONT_H3_DARK = new Font(PdfUtils.getDefaultBoldFont(), 16f, Font.NORMAL, DARK_BLUE);
	private static final Font FONT_H4_DARK = new Font(PdfUtils.getDefaultBoldFont(), 14f, Font.NORMAL, DARK_BLUE);
	private static final Font FONT_H5_DARK = new Font(PdfUtils.getDefaultBoldFont(), 12f, Font.NORMAL, DARK_BLUE);
	private static final Font FONT_H6_DARK = new Font(PdfUtils.getDefaultBoldFont(), 11f, Font.NORMAL, DARK_BLUE);

	private static final Font FONT_H5_REM = new Font(PdfUtils.getDefaultBoldFont(), 12f, Font.NORMAL, DARK_GREEN);
	private static final Font FONT_H5_BLACK = new Font(PdfUtils.getDefaultBoldFont(), 12f, Font.NORMAL, BaseColor.BLACK);

	private static final Font FONT_IMPORTANT = new Font(PdfUtils.getDefaultBoldFont(), 11f, Font.NORMAL, BaseColor.RED);
	private static final Font FONT_IMPORTANT_CENTRE = new Font(PdfUtils.getDefaultBoldFont(), 14f, Font.NORMAL, BaseColor.RED);
	private static final Font LEGAL_HEADING = new Font(PdfUtils.getDefaultBoldFont(), 20f, Font.UNDERLINE, BaseColor.RED);

	private static final Font FONT_P = new Font(PdfUtils.getDefaultFont(), 11f, Font.NORMAL, BaseColor.BLACK);
	private static final Font FONT_F = new Font(PdfUtils.getDefaultBoldFont(), 11f, Font.NORMAL, BaseColor.BLACK);
	private static final Font FONT_B = new Font(PdfUtils.getDefaultBoldFont(), 11f, Font.NORMAL, BLUE);
	private static final Font FONT_T = new Font(PdfUtils.getDefaultBoldFont(), 13f, Font.UNDERLINE, BaseColor.BLACK);

	private BaseColor currentFontColor = BaseColor.BLACK;
	private float currentFontSize = DEFAULT_SIZE;
	private int currentAlignment = DEFAULT_ALIGNMENT;
	private float currentLeftIndent = DEFAULT_LEFT_INDENT;
	private int currentStyle = DEFAULT_STYLE;
	private int currentLineSpacing = DEFAULT_LINE_SPACING;

	private float innerLeftMargin = DEFAULT_INNER_MARGIN;
	private float innerRightMargin = DEFAULT_INNER_MARGIN;

	private Object previousParent;
	private Object parent;
	private Object child;

	private final Document document;
	private final WikiMarkupParser parser;
	private final PdfPageHelper pageHelper;
	private final MarkupParser markupParser;
	private final java.util.List<Page> templatedData = new ArrayList<Page>();
	private PdfPCell keepTogether;

	private ByteArrayOutputStream byteArrayOutputStream;
	private boolean includePageNumbering = false;
	private boolean includePaymentForm = false;
	private String header = "";
	private String headerImage = "";
	private String headerDocRef = "";
	private String claimantId = "";
	private boolean bleed = false;
	private File generatedDocumentBackground = null;

	private java.util.List<PdfPCell[]> rows = Lists.newArrayList();
	private int columnIndex = 0;

	private final Map<Integer, java.util.List<PdfRenderer>> stamps = Maps.newHashMap();
	private java.util.List<String> address;
	private String date;

	public static PdfBuilder newInstance() throws DocumentException {
		return new PdfBuilder();
	}

	public static PdfBuilder newInstance(final Rectangle pageSize) throws DocumentException {
		return new PdfBuilder(pageSize);
	}

	protected PdfBuilder(final Rectangle pageSize) throws DocumentException {
		this.byteArrayOutputStream = new ByteArrayOutputStream();
		// Leave space at the top of the first page for the address
		this.document = new Document(pageSize, 68, 68, 298, 65);
		final PdfWriter writer = PdfWriter.getInstance(this.document, this.byteArrayOutputStream);
		this.pageHelper = new PdfPageHelper(writer, this.document);
		this.document.open();
		this.parser = new WikiMarkupParser(this);
		this.markupParser = new MarkupParser();
		this.markupParser.setMarkupLanguage(new ConfluenceLanguage());
		this.markupParser.setBuilder(new ITextDocumentBuilder(this.document));
		// Now the document is open we can reduce the space at the top of the page for subsequent pages
		this.document.setMargins(68, 68, 65, 65);
		this.keepTogether = null;
	}

	protected PdfBuilder() throws DocumentException {
		this(PageSize.A4);
	}

	public PdfBuilder bleed() {
		this.bleed = true;
		return this;
	}

	public PdfBuilder innerMargins(final float left, final float right) {
		this.innerLeftMargin = left;
		this.innerRightMargin = right;
		return this;
	}

	@Override
	protected Object createNode(final Object name) {
		return createNode(name, null, null);
	}

	@Override
	protected Object createNode(final Object name, final Object value) {
		return createNode(name, null, value);
	}

	@Override
	protected Object createNode(final Object name, @SuppressWarnings("rawtypes") final Map attributes) {
		return createNode(name, attributes, null);
	}

	@Override
	protected Object createNode(final Object name, @SuppressWarnings("rawtypes") final Map attributes, final Object value) {
		final NodeType nodeType = NodeType.valueOf(name.toString());
		switch (nodeType) {
			case call:
				return NodeType.call;
			case ul:
				return ul();
			case ol:
				return ol();
			case table:
				if (attributes != null) {
					// num columns can come down either as an attribute or a value but not both. Not sure why we can't get
					// attributes and a value coming down but it doesn't seem to work.
					Integer columns = (Integer) attributes.get("columns");

					ArrayList widths = (ArrayList) attributes.get("widths");

					return table(columns, widths);
				}

				return table(Integer.parseInt(value.toString()));
			case row:
				return row();
			default:
				throw new NotImplementedException("Unknown function " + name);
		}
	}

	@Override
	protected void setParent(final Object parent, final Object child) {
		this.previousParent = this.parent;
		this.parent = parent;
		this.child = child;
	}

	@Override
	protected void nodeCompleted(final Object parentNode, final Object node) {
		if (node instanceof List) {

			/**
			 * This is a horrendous hack put in place because ListItem doesn't respect the keepTogether flag. The "solution" is to break every List into a set
			 * of Lists each containing a single ListItem. Each of these Lists can then be wrapped in a PdfPTable to get the keepTogether behaviour. One day
			 * someone might answer my StackOverflow question and this can be changed to something not as bad. http://stackoverflow.com/q/22757444/2273542
			 */
			final List list = (List) node;
			for (final Element element : list.getItems()) {

				final List subList = new List();
				subList.setNumbered(list.isNumbered());
				subList.setSymbolIndent(list.getSymbolIndent());
				subList.setIndentationLeft(list.getIndentationLeft());
				subList.setIndentationRight(list.getIndentationRight());
				subList.setAlignindent(list.isAlignindent());
				subList.setAutoindent(list.isAutoindent());
				subList.add(element);

				final PdfPCell cell = new PdfPCell();
				cell.setPadding(0);
				cell.setBorder(Rectangle.NO_BORDER);
				cell.addElement(subList);

				final PdfPTable table = new PdfPTable(1);
				table.setKeepTogether(true);
				table.setWidthPercentage(100);
				table.addCell(cell);

				addElementToGroupOrDocument(table);
			}

		}

		if (node instanceof PdfPTable) {
			for (PdfPCell[] row : this.rows) {
				for (PdfPCell cell : row) {
					if (cell == null) {
						PdfPCell fillerCell = new PdfPCell(new Phrase(" "));
						fillerCell.setBorder(Rectangle.NO_BORDER);
						((PdfPTable) node).addCell(fillerCell);
					}
					else {
						((PdfPTable) node).addCell(cell);
					}
				}
			}
			addElementToGroupOrDocument((PdfPTable) node);
		}

		setParent(this.previousParent, this.parent);
	}

	public List ul() {
		return new List(true, 10f);
	}

	public List ol() {
		return new List();
	}

	public void li(final String text) {
		if (this.child instanceof List) {
			final ListItem item = new ListItem();
			item.setListSymbol(new Chunk("\u2022", new Font(PdfUtils.getDefaultBoldFont(), 11f, Font.NORMAL, BaseColor.BLACK)));
			this.parser.parseForListItem(item, text);

			((List) this.child).setIndentationLeft(this.innerLeftMargin);
			((List) this.child).setIndentationRight(this.innerRightMargin);
			((List) this.child).add(item);
		}
	}

	/**
	 * Literal list item - ie does not attempt to parse the string using the wiki markup. We should change the wiki markup parser to allow markup characters to
	 * be escaped rather than use a separate function.
	 */
	public void lil(final String text) {
		if (this.child instanceof List) {
			final ListItem item = new ListItem(new Phrase(text, FONT_P));
			item.setListSymbol(new Chunk("\u2022", new Font(PdfUtils.getDefaultBoldFont(), 11f, Font.NORMAL, BaseColor.BLACK)));

			((List) this.child).setIndentationLeft(this.innerLeftMargin);
			((List) this.child).setIndentationRight(this.innerRightMargin);
			((List) this.child).add(item);
		}
	}

	public void lin(final String text) {
		if (this.child instanceof List) {
			final ListItem item = new ListItem();
			item.setFont(new Font(PdfUtils.getDefaultBoldFont(), 11f, Font.NORMAL, BaseColor.BLACK));
			this.parser.parseForListItem(item, text);

			((List) this.child).setIndentationLeft(this.innerLeftMargin);
			((List) this.child).setIndentationRight(this.innerRightMargin);
			((List) this.child).add(item);
		}
	}

	public void lin(final String listNumber, final String text) {
		if (this.child instanceof List) {
			final ListItem item = new ListItem();
			item.setListSymbol(new Chunk(listNumber + ".", new Font(PdfUtils.getDefaultBoldFont(), 11f, Font.NORMAL, BaseColor.BLACK)));
			this.parser.parseForListItem(item, text);

			((List) this.child).setIndentationLeft(this.innerLeftMargin);
			((List) this.child).setIndentationRight(this.innerRightMargin);
			((List) this.child).add(item);
		}
	}

	private static Paragraph newParagraph(final String text, final Font font) {
		final Paragraph paragraph = new Paragraph(text, font);
		paragraph.setKeepTogether(true);
		return paragraph;
	}

	public void h1(final String text) {
		final Paragraph element = newParagraph(text, FONT_H1);
		addElementToGroupOrDocument(element);
	}

	public void h1(final String text, final Boolean dark) {
		addElementToGroupOrDocument(newParagraph(text, dark
				? FONT_H1_DARK
				: FONT_H1));
	}

	public void h2(final String text) {
		addElementToGroupOrDocument(newParagraph(text, FONT_H2));
	}

	public void h2(final String text, final Boolean dark) {
		addElementToGroupOrDocument(newParagraph(text, dark
				? FONT_H2_DARK
				: FONT_H2));
	}

	public void h3(final String text) {
		addElementToGroupOrDocument(newParagraph(text, FONT_H3));
	}

	public void h3(final String text, final Boolean dark) {
		addElementToGroupOrDocument(newParagraph(text, dark
				? FONT_H3_DARK
				: FONT_H3));
	}

	public void h4(final String text) {
		addElementToGroupOrDocument(newParagraph(text, FONT_H4));
	}

	public void h4(final String text, final Boolean dark) {
		addElementToGroupOrDocument(newParagraph(text, dark
				? FONT_H4_DARK
				: FONT_H4));
	}

	public void h5(final String text) {
		addElementToGroupOrDocument(newParagraph(text, FONT_H5));
	}

	public void h5(final String text, final Boolean dark) {
		addElementToGroupOrDocument(newParagraph(text, dark
				? FONT_H5_DARK
				: FONT_H5));
	}

	public void h5rem(final String text) {
		addElementToGroupOrDocument(newParagraph(text, FONT_H5_REM));
	}

	public void h5black(final String text) {
		addElementToGroupOrDocument(newParagraph(text, FONT_H5_BLACK));
	}

	public void h6(final String text) {
		addElementToGroupOrDocument(newParagraph(text, FONT_H6));
	}

	public void h6(final String text, final Boolean dark) {
		addElementToGroupOrDocument(newParagraph(text, dark
				? FONT_H6_DARK
				: FONT_H6));
	}

	public void important(final String text) {
		addElementToGroupOrDocument(newParagraph(text, FONT_IMPORTANT));
	}
	
	public void important_centre(final String text) {
		final Paragraph element = newParagraph(text, FONT_IMPORTANT_CENTRE);
		element.setAlignment(Element.ALIGN_CENTER);
		addElementToGroupOrDocument(element);
	}

	public void lh(final String fieldName, final String value) {
		final Phrase field = new Phrase(fieldName, FONT_F);
		final Paragraph paragraph = new Paragraph(13.0f, value, FONT_P);
		paragraph.add(0, field);
		paragraph.setKeepTogether(true);
		addElementToGroupOrDocument(paragraph);
	}

	public void lh(final String value) {
		lh("", value);
	}

	public void lhb(final String fieldName, final String value, final boolean parse) {
		final Phrase field = new Phrase(fieldName, FONT_B);
		final Paragraph paragraph;

		if(parse){
			paragraph = this.parser.parseAndReturnParagraph(value);
		}else{
			paragraph = new Paragraph(13.0f, value, FONT_P);
		}

		paragraph.add(0, field);
		paragraph.setKeepTogether(true);
		addElementToGroupOrDocument(paragraph);
	}

	public void lhb(final String fieldName, final String value) {
		lhb(fieldName, value, false);
	}

	public void lhb(final String value) {
		lhb("", value);
	}

	public void title(final String value) {
		final Paragraph p = newParagraph(value, FONT_T);
		p.setAlignment(1);
		addElementToGroupOrDocument(p);
	}

	public void p(final String text) {
		ParagraphOptionsBuilder options = new ParagraphOptionsBuilder();
		p(options, text);
	}

	public void p(final ParagraphOptionsBuilder options, final String text) {
		setStyles(options);

		if (StringUtils.isEmpty(text)) {
			LOG.warn("p \"\" detected, this does not work as expected for pdf documents, consider using spacer() instead");
		}
		
		if (this.currentLineSpacing == DEFAULT_LINE_SPACING) {
			this.parser.parseForParagraph(text);
		} else {
			this.parser.parseForParagraphWithLineSpacing(text, this.currentLineSpacing);
		}

		resetStyles();
	}

	private void setStyles(ParagraphOptionsBuilder options) {
		if (options.getSize() != null) {
			this.currentFontSize = options.getSize();
		}

		if (options.getColor() != null) {
			this.currentFontColor = options.getColor();
		}

		if (options.getAlignment() != null) {
			this.currentAlignment = options.getAlignment();
		}

		if (options.getIndent() != null) {
			this.currentLeftIndent = options.getIndent();
		}

		if (options.getStyle() != null) {
			this.currentStyle = options.getStyle();
		}
		
		if (options.getLineSpacing() != null) {
			this.currentLineSpacing = options.getLineSpacing();
		}
	}

	private void resetStyles() {
		this.currentFontColor = DEFAULT_COLOUR;
		this.currentFontSize = DEFAULT_SIZE;
		this.currentAlignment = DEFAULT_ALIGNMENT;
		this.currentLeftIndent = DEFAULT_LEFT_INDENT;
		this.currentStyle = DEFAULT_STYLE;
		this.currentLineSpacing = DEFAULT_LINE_SPACING;
	}

	public void pbc(final String text, final BaseColor backgroundColour) {
		final Chunk textAsChunk = new Chunk(text);
		textAsChunk.setFont(FONT_P);
		textAsChunk.setBackground(backgroundColour);
		final Paragraph paragraph = new Paragraph(textAsChunk);
		paragraph.setKeepTogether(true);
		addElementToGroupOrDocument(paragraph);
	}

	public void pj(final String text) {
		if (StringUtils.isEmpty(text)) {
			LOG.warn("p \"\" detected, this does not work as expected for pdf documents, consider using spacer() instead");
		}
		this.parser.parseForJustifiedParagraph(text);
	}

	public void pj(final ParagraphOptionsBuilder options, final String text) {

		setStyles(options);

		if (StringUtils.isEmpty(text)) {
			LOG.warn("p \"\" detected, this does not work as expected for pdf documents, consider using spacer() instead");
		}
		this.parser.parseForJustifiedParagraph(text);

		resetStyles();
	}

	public void header(final Map<String, String> parameters) {
		final String telephone = StringUtils.defaultIfEmpty(parameters.get("telephone"), "0844 357 1622");
		final String email = StringUtils.defaultIfEmpty(parameters.get("email"), "enquiries@theclaimsguys.co.uk");
		this.headerDocRef = StringUtils.defaultIfEmpty(parameters.get("reference"), "");
		this.headerImage = StringUtils.defaultIfEmpty(parameters.get("image"), "src/test/templates/header.png");
		this.header = createHeader(telephone, email).toString();
	}

	public void headerWithoutTelephone(final Map<String, String> parameters) {
		final String email = StringUtils.defaultIfEmpty(parameters.get("email"), "enquiries@theclaimsguys.co.uk");
		this.headerDocRef = StringUtils.defaultIfEmpty(parameters.get("reference"), "");
		this.headerImage = StringUtils.defaultIfEmpty(parameters.get("image"), "src/test/templates/header.png");
		this.header = createHeader(email).toString();
	}

	public void headerWithOrganisationName(final Map<String, String> parameters) {
		final String email = StringUtils.defaultIfEmpty(parameters.get("email"), "enquiries@theclaimsguys.co.uk");
		this.headerDocRef = StringUtils.defaultIfEmpty(parameters.get("reference"), "");
		this.headerImage = StringUtils.defaultIfEmpty(parameters.get("image"), "src/test/templates/header.png");
		this.header = createHeaderWithOrganisationName(email).toString();
	}

	public void address(final java.util.List<String> addressLines) {
		this.address = addressLines;
	}

	public void date(final String value) {
		this.date = value;
	}

	public void currentDate() {
		this.date = new LocalDateTime().toString("dd MMMM YYYY");
	}

	public void footer(final Map<String, Object> parameters) {
		this.includePageNumbering = BooleanUtils.toBooleanDefaultIfNull((Boolean) parameters.get("includePageNumbering"), false);
		this.includePaymentForm = BooleanUtils.toBooleanDefaultIfNull((Boolean) parameters.get("includePaymentForm"), false);
		this.claimantId = StringUtils.defaultIfEmpty((String) parameters.get("claimantId"), "");
	}

	public void spacer() {
		final Paragraph spacer = new Paragraph();
		spacer.setLeading(0);
		spacer.setSpacingBefore(7);
		write(spacer, " ", null);
		addElementToGroupOrDocument(spacer);
	}

	public void legalHeading(final String text) {
		final Paragraph element = newParagraph(text, LEGAL_HEADING);
		element.setAlignment(Element.ALIGN_CENTER);
		addElementToGroupOrDocument(element);
	}

	public void group() {
		if (this.keepTogether != null) {
			throw new RuntimeException("There is already an element group open, close it before opening a new one");
		}
		this.keepTogether = new PdfPCell();
		this.keepTogether.setPadding(0);
		this.keepTogether.setBorder(Rectangle.NO_BORDER);
	}

	public void endGroup() {
		final PdfPTable table = new PdfPTable(1);
		// table.setSplitRows(false);
		table.setKeepTogether(true);
		table.setWidthPercentage(100);
		table.addCell(this.keepTogether);
		try {
			this.document.add(table);
		}
		catch (final DocumentException exp) {
			throw new RuntimeException("Unable to add group", exp);
		}
		this.keepTogether = null;
	}

	public void newPage() {
		this.document.newPage();
	}

	public void body(final String bodyContent) {
		this.markupParser.parse(bodyContent);
	}

	public void background(final File pdf) {
		this.generatedDocumentBackground = pdf;
	}

	public static ParagraphOptionsBuilder options() {
		return new ParagraphOptionsBuilder();
	}

	@SuppressWarnings("unchecked")
	public void page(final Map<String, Object> parameters) {
		final File template = (File) parameters.get("template");
		final Map<String, Object> data = (Map<String, Object>) parameters.get("data");

		final boolean duplex = (Boolean) parameters.get("duplex");

		if (LOG.isDebugEnabled()) {
			LOG.debug(String.format("Generating page with template %s", template));
		}
		if (this.bleed) {
			this.templatedData.add(new Page(data, duplex, template).bleed());
		}
		else {
			this.templatedData.add(new Page(data, duplex, template));
		}
	}

	private static StringBuilder createHeader(final String telephone, final String email) {
		final StringBuilder sb = new StringBuilder();
		sb.append("Lynnfield House")
			.append("\nChurch Street")
			.append("\nAltrincham")
			.append("\nWA14 4DZ")
			.append("\nT  ")
			.append(telephone)
			.append("\nE  ")
			.append(email);
		return sb;
	}

	private static StringBuilder createHeader(final String email) {
		final StringBuilder sb = new StringBuilder();
		sb.append("Lynnfield House")
				.append("\nChurch Street")
				.append("\nAltrincham")
				.append("\nWA14 4DZ")
				.append("\nE  ")
				.append(email);
		return sb;
	}

	private static StringBuilder createHeaderWithOrganisationName(final String email) {
		final StringBuilder sb = new StringBuilder();
		sb.append("The Claims Guys Ltd")
				.append("\nLynnfield House")
				.append("\nChurch Street")
				.append("\nAltrincham")
				.append("\nCheshire")
				.append("\nWA14 4DZ")
				.append("\nE  ")
				.append(email);
		return sb;
	}

	public byte[] generate() throws IOException, DocumentException {
		final ByteArrayOutputStream baos = new ByteArrayOutputStream();
		save(baos, true);
		return baos.toByteArray();
	}

	public byte[] generate(final boolean includeHeaderText) throws IOException, DocumentException {
		final ByteArrayOutputStream baos = new ByteArrayOutputStream();
		save(baos, includeHeaderText);
		return baos.toByteArray();
	}

	public void save(final OutputStream outputStream) throws IOException, DocumentException {
		save(outputStream, true);
	}

	public void save(final OutputStream outputStream, final boolean includeHeaderText) throws IOException, DocumentException {

		final Document outputDocument = new Document();
		if (this.bleed) {
			outputDocument.setPageSize(new Rectangle(0, 0, OVERSIZED_A4_X, OVERSIZED_A4_Y));
		}

		final PdfWriter writer = PdfWriter.getInstance(outputDocument, outputStream);
		outputDocument.open();
		final PdfContentByte contentByte = writer.getDirectContent();

		int numberOfPages = 0;

		if (this.pageHelper.hasGeneratedContent()) {

			this.document.close();

			if (null != this.address) {
				this.byteArrayOutputStream = this.pageHelper.addAddress(this.byteArrayOutputStream, this.address);
			}

			if (null != this.date) {
				this.byteArrayOutputStream = this.pageHelper.addDate(this.byteArrayOutputStream, this.date);
			}

			if (includeHeaderText) {
				this.byteArrayOutputStream =
						this.pageHelper.addHeaderAndFooter(this.byteArrayOutputStream, this.header, this.headerImage, this.headerDocRef,
								this.includePageNumbering, this.includePaymentForm, this.claimantId);
			}
			else {
				this.byteArrayOutputStream =
						this.pageHelper.addHeaderAndFooter(this.byteArrayOutputStream, this.headerImage, this.headerDocRef, this.includePageNumbering,
								this.includePaymentForm, this.claimantId);
			}

			this.byteArrayOutputStream = this.pageHelper.addStamps(this.byteArrayOutputStream, this.stamps);

			final PdfReader reader = new PdfReader(this.byteArrayOutputStream.toByteArray());

			for (int pageIndex = 1; pageIndex <= reader.getNumberOfPages(); pageIndex++) {
				numberOfPages++;
				outputDocument.newPage();
				if (null != this.generatedDocumentBackground) {
					final PdfReader backgroundReader = new PdfReader(new FileInputStream(this.generatedDocumentBackground));
					final PdfImportedPage backgroundPage = writer.getImportedPage(backgroundReader, pageIndex);
					addPage(contentByte, backgroundPage);
				}
				final PdfImportedPage page = writer.getImportedPage(reader, pageIndex);
				addPage(contentByte, page);
			}

			if (!hasTemplateData()) {
				outputDocument.close();
			}
		}

		if (hasTemplateData()) {

			this.templatedData.get(0)
				.setDuplex(this.pageHelper.hasGeneratedContent()
						? numberOfPages % 2 == 1
						: false);

			for (final Page page : this.templatedData) {

				final File temporaryFile = page.renderAndFlatten();

				final PdfReader temporaryReader = new PdfReader(new FileInputStream(temporaryFile));

				for (int pageIndex = 1; pageIndex <= temporaryReader.getNumberOfPages(); pageIndex++) {

					outputDocument.newPage();
					final PdfImportedPage temporaryPage = writer.getImportedPage(temporaryReader, pageIndex);
					addPage(contentByte, temporaryPage);
				}

				temporaryFile.delete();
			}
			outputDocument.close();
		}

	}

	private void addPage(final PdfContentByte contentByte, final PdfImportedPage page) {
		if (this.bleed) {
			final Rectangle pageSize = page.getBoundingBox();
			final float padHorizontal = (OVERSIZED_A4_X - pageSize.getRight()) / 2;
			final float padVertical = (OVERSIZED_A4_Y - pageSize.getTop()) / 2;
			contentByte.addTemplate(page, padHorizontal, padVertical);
		}
		else {
			contentByte.addTemplate(page, 0, 0);
		}
	}

	private boolean hasTemplateData() {
		return this.templatedData != null && this.templatedData.size() > 0;
	}

	public void image(final String url, final float width, final float height) {
		try {
			final Image image = Image.getInstance(url);
			image.scaleAbsolute(width, height);
			addElementToGroupOrDocument(image);
		}
		catch (final Exception e) {
			LOG.error("Couldn't load image " + url);
		}
	}

	public void stampImage(final String url, final int x, final int y, final float width, final float height, final int pageNumber) {
		try {
			addStamp(new ImageRenderer(url, x, y, height, width), pageNumber);
		}
		catch (final Exception e) {
			LOG.error("Couldn't load image " + url);
		}
	}

	private void addStamp(final PdfRenderer renderer, final int pageNumber) {
		if (!this.stamps.containsKey(pageNumber)) {
			this.stamps.put(pageNumber, Lists.newArrayList(new ArrayList<PdfRenderer>()));
		}
		this.stamps.get(pageNumber)
			.add(renderer);
	}

	public PdfPTable table(final int columns, final ArrayList widths) {
		PdfPTable table = table(columns);

		int[] intWidths = new int[widths.size()];
		for (int i = 0; i < widths.size(); ++i) {
			intWidths[i] = (Integer) widths.get(i);
		}

		try {
			table.setWidths(intWidths);
		}
		catch (DocumentException e) {
			e.printStackTrace();
			LOG.error("Error setting table width - ignored " + e);
		}
		return table;
	}

	public PdfPTable table(final int columns) {
		PdfPTable table = new PdfPTable(columns);
		table.setWidthPercentage(100f);
		table.setKeepTogether(true);

		this.rows.clear();

		return table;
	}

	public NodeType row() {
		if (this.child instanceof PdfPTable) {
			this.columnIndex = 0;
			this.rows.add(new PdfPCell[((PdfPTable) this.child).getNumberOfColumns()]);
		}
		return NodeType.row;
	}

	public void cell(final String... text) {
		ParagraphOptionsBuilder options = new ParagraphOptionsBuilder();
		options.size(DEFAULT_SIZE);
		options.alignment(Element.ALIGN_LEFT);
		cell(options, new CellOptionsBuilder(), text);
	}

	public void cell(final CellOptionsBuilder cellOptions, final String... text) {
		ParagraphOptionsBuilder options = new ParagraphOptionsBuilder();
		options.size(DEFAULT_SIZE);
		options.alignment(Element.ALIGN_LEFT);
		cell(options, cellOptions, text);
	}

	public void cell(final ParagraphOptionsBuilder options, final String... text) {
		cell(options, new CellOptionsBuilder(), text);
	}

	public void cell(final ParagraphOptionsBuilder paraOptions, final CellOptionsBuilder cellOptions, final String... text) {
		Paragraph p = new Paragraph();

		setStyles(paraOptions);

		for (int i = 0; i < text.length; i++) {
			p.add(this.parser.parseAndReturnParagraph(text[i]));
			p.add("\n");
		}

		PdfPCell cell = new PdfPCell(p);

		if (cellOptions.getBorder() != null) {
			cell.setBorder(cellOptions.getBorder());
		}

		if (cellOptions.getPadding() != null) {
			cell.setPadding(cellOptions.getPadding());
		}

		if (cellOptions.getPaddingBottom() != null) {
			cell.setPaddingBottom(cellOptions.getPaddingBottom());
		}

		if (cellOptions.getPaddingTop() != null) {
			cell.setPaddingTop(cellOptions.getPaddingTop());
		}

		if (cellOptions.getPaddingLeft() != null) {
			cell.setPaddingLeft(cellOptions.getPaddingLeft());
		}

		if (cellOptions.getPaddingRight() != null) {
			cell.setPaddingRight(cellOptions.getPaddingRight());
		}

		cell.setHorizontalAlignment(paraOptions.getAlignment());

		this.rows.get(this.rows.size() - 1)[this.columnIndex] = cell;
		this.columnIndex++;

		// Reset font size etc as it is stateful
		resetStyles();
	}

	@Override
	public Paragraph startParagraph() {
		return startParagraph(this.currentLineSpacing);
	}
	
	@Override
	public Paragraph startParagraph(final int lineSpacing) {
		final Paragraph paragraph = new Paragraph(lineSpacing);
		paragraph.setKeepTogether(true);
		return paragraph;
	}

	@Override
	public void alignParagraph(final Paragraph paragraph) {
		paragraph.setAlignment(this.currentAlignment);
	}

	@Override
	public void indentParagraph(final Paragraph paragraph) {
		paragraph.setIndentationLeft(this.currentLeftIndent + this.innerLeftMargin);
		paragraph.setIndentationRight(this.innerRightMargin);
	}

	@Override
	public void endParagraph(final Paragraph paragraph) {
		paragraph.setKeepTogether(true);
		addElementToGroupOrDocument(paragraph);
	}

	private void addElementToGroupOrDocument(final Element element) {
		try {
			if (null != this.keepTogether) {
				this.keepTogether.addElement(element);
			}
			else {
				this.document.add(element);
			}
		}
		catch (final DocumentException exp) {
			throw new RuntimeException("Unable to add element", exp);
		}
	}

	@Override
	public void write(final Paragraph paragraph, final String text, final EnumSet<Style> textStyle) {
		write(paragraph, text, textStyle, this.currentFontColor);
	}

	@Override
	public void write(final Paragraph paragraph, final String text, final EnumSet<Style> textStyle, final BaseColor color) {
		final Phrase phrase = buildPhrase(text, textStyle, color);
		paragraph.add(phrase);
	}

	/**
	 * Creates a Phrase that can be used to change the style of part of a paragraph or list.
	 */
	private Phrase buildPhrase(final String text, final EnumSet<Style> textStyle, final BaseColor color) {
		if (LOG.isDebugEnabled()) {
			LOG.debug(String.format(" -> writing '%s' with style '%s'", text, textStyle));
		}

		final Font font;
		if (null == textStyle) {
			font = new Font(PdfUtils.getDefaultFont(), this.currentFontSize, this.currentStyle, color);
		}
		else if (textStyle.contains(BOLD)) {
			font = new Font(PdfUtils.getDefaultBoldFont(), this.currentFontSize, Font.NORMAL, color);
		}
		else if (textStyle.contains(ITALIC)) {
			font = new Font(PdfUtils.getDefaultFont(), this.currentFontSize, Font.ITALIC, color);
		}
		else if (textStyle.contains(STRIKETHRU)) {
			font = new Font(PdfUtils.getDefaultFont(), this.currentFontSize, Font.STRIKETHRU, color);
		}
		else if (textStyle.contains(UNDERLINE)) {
			font = new Font(PdfUtils.getDefaultFont(), this.currentFontSize, Font.UNDERLINE, color);
		}
		else {
			font = new Font(PdfUtils.getDefaultFont(), this.currentFontSize, Font.NORMAL, color);
		}

		return new Phrase(text, font);
	}

	protected enum NodeType {
		call, ul, ol, table, row
	}
}
