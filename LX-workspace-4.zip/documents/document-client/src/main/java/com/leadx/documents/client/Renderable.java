/**
 *
 */
package com.leadx.documents.client;

import java.io.IOException;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfStamper;

/**
 * @author Gareth.Evans
 */
public interface Renderable {
	/**
	 * @param pdfStamper
	 * @throws DocumentException
	 * @throws IOException
	 */
	void render(final PdfStamper pdfStamper) throws DocumentException, IOException;
	
	/**
	 * @param pdfStamper
	 * @param pageNumber
	 * @throws DocumentException
	 * @throws IOException
	 */
	void render(final PdfStamper pdfStamper, final int pageNumber) throws DocumentException, IOException;

}
