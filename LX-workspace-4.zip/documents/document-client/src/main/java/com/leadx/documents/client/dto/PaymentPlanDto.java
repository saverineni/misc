package com.leadx.documents.client.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect
public class PaymentPlanDto {

	private Integer paymentDate;
	private List<PaymentPlanScheduleDto> schedules;
	private String frequency;

	public PaymentPlanDto(List<PaymentPlanScheduleDto> schedules) {
		this.schedules = schedules;
	}

	public PaymentPlanDto() {
	}

	public List<PaymentPlanScheduleDto> getSchedules() {
		return this.schedules;
	}

	public Integer getPaymentDate() {
		return this.paymentDate;
	}

	public void setPaymentDate(final Integer paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
}