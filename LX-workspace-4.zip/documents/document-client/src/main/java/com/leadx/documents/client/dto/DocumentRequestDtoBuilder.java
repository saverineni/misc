package com.leadx.documents.client.dto;

import java.util.List;
import java.util.Map;

import com.leadx.claimant.client.AddressDto;
import com.leadx.claimincubation.client.PbaAgreementDto;
import com.leadx.claimincubation.client.PbaClaimantDto;
import com.leadx.web.tcg.client.claimservice.CreditAgreementAndClaimDto;
import com.leadx.web.tcg.client.claimservice.InvestmentAgreementDto;
import com.leadx.web.tcg.client.claimservice.PensionAgreementDto;
import com.leadx.web.tcg.client.claimservice.StlAgreementDto;

public class DocumentRequestDtoBuilder {

	private CreditAgreementDto creditAgreementDtoValue;
	private ClaimantDto claimantDtoValue;
	private ClaimantAndAddressDto claimantAndAddressDtoValue;
	private PaymentPlanDto paymentPlanDtoValue;
	private List<InvoiceDto> invoiceDtosValue;
	private DocumentSettingsOverridesDto documentSettingsOverridesDtoValue;
	private List<PbaAgreementDto> pbaAgreementDtosValue;
	private PbaClaimantDto pbaClaimantDtoValue;
	private Map<String, Object> legacyMessageValue;
	private Integer mailingIdValue;
	private Integer templateIdValue;
	private List<OutstandingItemTypeDto> allFosOutstandingItemTypes;
	private boolean sampleMailing;
	private List<CreditAgreementAndClaimDto> creditAgreementAndClaimDtos;
	private List<StlAgreementDto> stlAgreementDtos;
	private List<InvestmentAgreementDto> investmentAgreementDtos;
	private List<PensionAgreementDto> pensionAgreementDtos;
	private String overrideFilename;
	private String password;

	public DocumentRequestDtoBuilder() {}

	public DocumentRequestDto build() {
		PpiDto ppiDto = new PpiDto(this.creditAgreementDtoValue, this.claimantDtoValue, this.allFosOutstandingItemTypes, this.paymentPlanDtoValue,
				this.invoiceDtosValue, this.legacyMessageValue, this.creditAgreementAndClaimDtos);
		PbaDto pbaDto = new PbaDto(this.pbaAgreementDtosValue, this.pbaClaimantDtoValue);
		StlDto stlDto = new StlDto(this.stlAgreementDtos, this.claimantDtoValue);
		InvDto invDto = new InvDto(this.investmentAgreementDtos, this.claimantDtoValue);
		PenDto penDto = new PenDto(this.pensionAgreementDtos, this.claimantDtoValue);

		return new DocumentRequestDto(ppiDto, pbaDto, stlDto, invDto, penDto, this.claimantAndAddressDtoValue, this.documentSettingsOverridesDtoValue,
				this.mailingIdValue, this.templateIdValue, this.sampleMailing, this.overrideFilename, this.password);
	}

	public DocumentRequestDtoBuilder creditAgreement(final CreditAgreementDto value) {
		this.creditAgreementDtoValue = value;
		return this;
	}

	public DocumentRequestDtoBuilder claimant(final ClaimantDto value) {
		this.claimantDtoValue = value;
		return this;
	}
	
	public DocumentRequestDtoBuilder coreClaimant(final com.leadx.claimant.client.ClaimantDto value, final List<AddressDto> addressDtos) {
		this.claimantAndAddressDtoValue = new ClaimantAndAddressDto(value, addressDtos);
		return this;
	}

	public DocumentRequestDtoBuilder allFosOutstandingItemTypes(final List<OutstandingItemTypeDto> value) {
		this.allFosOutstandingItemTypes = value;
		return this;
	}

	public DocumentRequestDtoBuilder paymentPlan(final PaymentPlanDto value) {
		this.paymentPlanDtoValue = value;
		return this;
	}

	public DocumentRequestDtoBuilder invoiceDtos(final List<InvoiceDto> value) {
		this.invoiceDtosValue = value;
		return this;
	}

	public DocumentRequestDtoBuilder documentSettingOverrides(final DocumentSettingsOverridesDto value) {
		this.documentSettingsOverridesDtoValue = value;
		return this;
	}
	
	public DocumentRequestDtoBuilder pbaAgreementDtos(final List<PbaAgreementDto> value) {
		this.pbaAgreementDtosValue = value;
		return this;
	}
	
	public DocumentRequestDtoBuilder pbaClaimantDto(final PbaClaimantDto value) {
		this.pbaClaimantDtoValue = value;
		return this;
	}

	public DocumentRequestDtoBuilder legacyMessage(final Map<String, Object> value) {
		this.legacyMessageValue = value;
		return this;
	}

	public DocumentRequestDtoBuilder mailingId(final Integer value) {
		this.mailingIdValue = value;
		return this;
	}

	public DocumentRequestDtoBuilder templateId(final Integer value) {
		this.templateIdValue = value;
		return this;
	}

	public DocumentRequestDtoBuilder sampleMailing(final boolean value) {
		this.sampleMailing = value;
		return this;
	}

	public DocumentRequestDtoBuilder creditAgreementAndClaimDtos(List<CreditAgreementAndClaimDto> creditAgreementAndClaimDtos) {
		this.creditAgreementAndClaimDtos = creditAgreementAndClaimDtos;
		return this;
	}

	public DocumentRequestDtoBuilder stlAgreementDto(final List<StlAgreementDto> stlAgreementDto) {
		this.stlAgreementDtos = stlAgreementDto;
		return this;
	}

	public DocumentRequestDtoBuilder investmentAgreementDtos(final List<InvestmentAgreementDto> investmentAgreementDtos) {
		this.investmentAgreementDtos = investmentAgreementDtos;
		return this;
	}

	public DocumentRequestDtoBuilder pensionAgreementDtos(final List<PensionAgreementDto> pensionAgreementDtos) {
		this.pensionAgreementDtos = pensionAgreementDtos;
		return this;
	}

	public DocumentRequestDtoBuilder overrideFilename(final String overrideFilename) {
		this.overrideFilename = overrideFilename;
		return this;
	}

	public DocumentRequestDtoBuilder password(final String password) {
		this.password = password;
		return this;
	}
}
