package com.leadx.documents.client.dto;

import java.util.List;

import com.leadx.claimincubation.client.PbaAgreementDto;
import com.leadx.claimincubation.client.PbaClaimantDto;

public class PbaDto {

	private List<PbaAgreementDto> pbaAgreementDtos;
	private PbaClaimantDto pbaClaimantDto;

	public List<PbaAgreementDto> getPbaAgreementDtos() {
		return this.pbaAgreementDtos;
	}

	public void setPbaAgreementDtos(List<PbaAgreementDto> pbaAgreementDtos) {
		this.pbaAgreementDtos = pbaAgreementDtos;
	}

	public PbaClaimantDto getPbaClaimantDto() {
		return this.pbaClaimantDto;
	}

	public void setPbaClaimantDto(PbaClaimantDto pbaClaimantDto) {
		this.pbaClaimantDto = pbaClaimantDto;
	}

	public PbaDto(List<PbaAgreementDto> pbaAgreementDtos, PbaClaimantDto pbaClaimantDto) {
		this.pbaAgreementDtos = pbaAgreementDtos;
		this.pbaClaimantDto = pbaClaimantDto;
	}

	public PbaDto() {
	}
}
