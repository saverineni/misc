package com.leadx.documents.client;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.AcroFields;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;

/**
 * @author gareth.evans
 */
public class Page {

	private static final Logger LOG = LoggerFactory.getLogger(Page.class);

	private final File[] templates;
	private final Map<String, Object> data;
	private boolean duplex;
	private boolean bleed = false;

	public Page(final Map<String, Object> data, final boolean duplex, final File... templates) {
		this.templates = checkNotNull(templates);
		this.data = checkNotNull(data);
		this.duplex = duplex;
		for (final File template : templates) {
			checkArgument(template.exists(), "Cannot create a page as the template %s does not exist", template);
		}
	}

	public Page bleed() {
		this.bleed = true;
		return this;
	}

	public File renderAndFlatten() throws FileNotFoundException, IOException, DocumentException {
		final File tempFile = File.createTempFile("rendered_", ".pdf");
		if (1 == this.templates.length) {
			// single page, simple merge
			final PdfReader pdfReader = new PdfReader(new FileInputStream(this.templates[0]));
			final FileOutputStream fos = new FileOutputStream(tempFile);
			final PdfStamper pdfStamper = new PdfStamper(pdfReader, fos);

			final AcroFields acroFields = pdfStamper.getAcroFields();
			for (final Map.Entry<String, Object> entry : this.data.entrySet()) {
				final Object value = entry.getValue();
				if (!(value instanceof java.util.List || value instanceof java.util.Map)) {
					final String key = entry.getKey()
						.toString();
					acroFields.setField(key, null != value
							? value.toString()
							: "");
				}
			}

			pdfStamper.setFormFlattening(true);

			if (this.duplex) {
				pdfStamper.insertPage(1, this.bleed
						? new Rectangle(0, 0, PdfBuilder.OVERSIZED_A4_X, PdfBuilder.OVERSIZED_A4_Y)
						: new Rectangle(PageSize.A4.getLeft(), PageSize.A4.getBottom(), PageSize.A4.getRight(), PageSize.A4.getTop()));
			}

			pdfStamper.close();
			fos.close();
		}
		else {
			// multipage merge
			if (LOG.isDebugEnabled()) {
				LOG.debug(String.format("Performing multipage duplex merge for templates %s", Arrays.asList(this.templates)));
			}

			final Document document = new Document();
			if (this.bleed) {
				document.setPageSize(new Rectangle(0, 0, PdfBuilder.OVERSIZED_A4_X, PdfBuilder.OVERSIZED_A4_Y));
			}
			final PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(tempFile));

			document.open();
			final PdfContentByte cb = writer.getDirectContent();
			// final int pageOfCurrentReaderPDF = 0;
			final List<File> tempFilesToDelete = Lists.newArrayList();

			for (final File template : this.templates) {
				if (LOG.isDebugEnabled()) {
					LOG.debug(String.format("Merging %s", template));
				}

				final File pageTempFile = new Page(this.data, this.duplex, template).renderAndFlatten();
				final FileInputStream fis = new FileInputStream(pageTempFile);
				final PdfReader pdfReader = new PdfReader(fis);

				final int numberOfPages = pdfReader.getNumberOfPages();
				for (int pageIndex = 0; pageIndex <= numberOfPages; pageIndex++) {
					document.newPage();
					final PdfImportedPage pdfPage = writer.getImportedPage(pdfReader, pageIndex);
					if (this.bleed) {
						final Rectangle pageSize = pdfReader.getPageSize(1);
						final float padHorizontal = (PdfBuilder.OVERSIZED_A4_X - pageSize.getRight()) / 2;
						final float padVertical = (PdfBuilder.OVERSIZED_A4_Y - pageSize.getTop()) / 2;
						cb.addTemplate(pdfPage, padHorizontal, padVertical);
					}
					else {
						cb.addTemplate(pdfPage, 0, 0);
					}
				}

				fis.close();
				tempFilesToDelete.add(pageTempFile);
			}

			document.close();
			for (final File pageTempFile : tempFilesToDelete) {
				pageTempFile.delete();
			}
		}

		if (LOG.isDebugEnabled()) {
			LOG.debug(String.format("Saved to %s...", tempFile));
		}

		return tempFile;
	}

	@Override
	public String toString() {
		return String.format("Page: %s", Arrays.asList(this.templates));
	}

	public void setDuplex(final boolean value) {
		this.duplex = value;
	}
}
