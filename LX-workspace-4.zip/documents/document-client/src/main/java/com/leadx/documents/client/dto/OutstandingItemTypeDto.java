package com.leadx.documents.client.dto;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect
public class OutstandingItemTypeDto {
	public OutstandingItemTypeDto(final int id, final String name, final String description, final OutstandingItemTypeGroup outstandingItemTypeGroup) {
		this.id = id;
		this.name = name;
		this.description = description;
		this.outstandingItemTypeGroup = outstandingItemTypeGroup;
	}

	public OutstandingItemTypeDto() {
	}

	public int getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}

	public String getDescription() {
		return this.description;
	}

	public OutstandingItemTypeGroup getOutstandingItemTypeGroup() {
		return outstandingItemTypeGroup;
	}

	private int id;
	private String name;
	private String description;
	private OutstandingItemTypeGroup outstandingItemTypeGroup;
}
