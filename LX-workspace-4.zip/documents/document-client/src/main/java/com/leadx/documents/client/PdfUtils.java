/**
 *
 */
package com.leadx.documents.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.AcroFields;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfCopyFields;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;

/**
 * @author Gareth.Evans
 */
public class PdfUtils {

	private static final Logger LOG = LoggerFactory.getLogger(PdfUtils.class);
	
	/**
	 * Method takes the supplied template, containing an ArcoForm and fills in the template using the parameters supplied within the map.
	 * The form is then flattened before being saved to outputFile
	 * 
	 * @param pdfTemplate
	 * @param parameters
	 * @param outputFile
	 * @throws IOException
	 * @throws FileNotFoundException
	 * @throws DocumentException
	 */
	public static void fillInAcroForm(final File pdfTemplate, final Map<String, String> parameters, final File outputFile)
			throws FileNotFoundException, IOException, DocumentException {

		final PdfReader pdfReader = new PdfReader(new FileInputStream(pdfTemplate));
		final PdfStamper pdfStamper = new PdfStamper(pdfReader, new FileOutputStream(outputFile));

		final AcroFields acroFields = pdfStamper.getAcroFields();

		for (final Map.Entry<String, String> entry : parameters.entrySet()) {
			acroFields.setField(entry.getKey(), entry.getValue());
		}

		pdfStamper.setFormFlattening(true);

		pdfStamper.close();
	}

	/**
	 * Method can be used to merge a selection of PDF's which contain embedded AcroForms, the method will <br />
	 * copy all AcroForms fields so can be manipulated at a later stage
	 * 
	 * @param pdfsToMerge a list of PDF's file to merge in to one
	 * @param outputFile the expected output file to merge documents to
	 * @throws DocumentException
	 * @throws IOException
	 */
	public static void copyPdfsAndAcroFormFields(final List<File> pdfsToMerge, final File outputFile) throws DocumentException, IOException {

		final OutputStream finalDocument = new FileOutputStream(outputFile);

		final List<InputStream> pdfs = new ArrayList<InputStream>();
		for (final File PDF : pdfsToMerge) {
			pdfs.add(new FileInputStream(PDF));
		}

		final Iterator<InputStream> iteratorPDFs = pdfs.iterator();
		final PdfCopyFields copyFields = new PdfCopyFields(finalDocument);

		while (iteratorPDFs.hasNext()) {
			final InputStream singlePdf = iteratorPDFs.next();
			final PdfReader pdfReader = new PdfReader(singlePdf);
			copyFields.addDocument(pdfReader);
		}

		copyFields.close();
	}

	public static BaseFont getDefaultFont() {
		try {
			return BaseFont.createFont("fonts/calibri.ttf", BaseFont.WINANSI, BaseFont.EMBEDDED);
		}
		catch (final Exception e) {
			LOG.warn("Couldn't load calibri font", e);
			throw new RuntimeException(e);
		}
	}

	public static BaseFont getDefaultBoldFont() {
		try {
			return BaseFont.createFont("fonts/calibrib.ttf", BaseFont.WINANSI, BaseFont.EMBEDDED);
		}
		catch (final Exception e) {
			LOG.warn("Couldn't load calibri font", e);
			throw new RuntimeException(e);
		}
	}
}
