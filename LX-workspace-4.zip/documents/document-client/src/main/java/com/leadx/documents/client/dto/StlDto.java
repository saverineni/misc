package com.leadx.documents.client.dto;

import com.leadx.web.tcg.client.claimservice.StlAgreementDto;

import java.util.List;

public class StlDto {

	private List<StlAgreementDto> stlAgreementDto;
	private ClaimantDto claimantDto;

	public StlDto(){}

	public StlDto(final List<StlAgreementDto> stlAgreementDto, final ClaimantDto claimantDto) {
		this.stlAgreementDto = stlAgreementDto;
		this.claimantDto = claimantDto;
	}

	public List<StlAgreementDto> getStlAgreementDto() {
		return stlAgreementDto;
	}

	public void setStlAgreementDto(List<StlAgreementDto> stlAgreementDto) {
		this.stlAgreementDto = stlAgreementDto;
	}

	public ClaimantDto getClaimantDto() {
		return claimantDto;
	}

	public void setClaimantDto(ClaimantDto claimantDto) {
		this.claimantDto = claimantDto;
	}
}
