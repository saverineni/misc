package com.leadx.documents.client;

import com.itextpdf.text.BaseColor;

public class TcgPdfContent {

	public static final BaseColor HEADER_FOOTER_LINE_FILL = new BaseColor(76, 104, 143);
	public static final BaseColor HEADER_FOOTER_LINE_BORDER = new BaseColor(16, 54, 105);
	public static final BaseColor FORM_FILL = new BaseColor(242, 242, 242);
	public static final BaseColor FORM_BORDER = new BaseColor(203, 203, 203);
	public static final BaseColor WHITE = new BaseColor(255, 255, 255);

	public static final String FOOTER_TEXT =
			"The Claims Guys Limited is registered in England company no: 06821134. Registered address: Lynnfield House, Church Street, Altrincham, Cheshire, WA14 4DZ.\n" +
					"The Claims Guys Limited are authorised and regulated by the Financial Conduct Authority, Interim Permission Number 833489";

	public static final String PAYMENT_FOOTER_TEXT =
			"Credit/Debit Card Payment\n"
				+ "I/We authorise The Claims Guys to take payment from our active card in respect of all fees due. Please rest assured that your details are safe with us. Your card details will "
				+ "be held safely\nby our accounts department until your claim is settled. Once your payment has been collected, your details will be disposed of securely. Your details will "
				+ "never be passed to any third\nparties. We will never ask you for any passwords or PIN numbers.";
}
