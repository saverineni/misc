/**
 *
 */
package com.leadx.documents.client;

import java.io.IOException;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfStamper;

import static com.leadx.documents.client.TcgPdfContent.FORM_BORDER;
import static com.leadx.documents.client.TcgPdfContent.FORM_FILL;
import static com.leadx.documents.client.TcgPdfContent.PAYMENT_FOOTER_TEXT;
import static com.leadx.documents.client.TcgPdfContent.WHITE;

/**
 * @author pete.holmes
 */
public class PaymentFormRenderer extends PdfRenderer {

	private static final int TEXT_BOX_HEIGHT = 15;
	private static final int TEXT_BOX_LONG = 180;
	private static final int TEXT_BOX_SHORT = 100;

	private String claimantId;

	public PaymentFormRenderer(final int pageNumber, final int x, final int y, final String claimantId) {

		super.setHeight(165);
		super.setWidth(495);
		super.setPageNumber(pageNumber);
		super.setX(x);
		super.setY(y);
		this.claimantId = claimantId;
	}

	public PaymentFormRenderer(final int x, final int y, final String claimantId) {
		this(-1, x, y, claimantId);
	}

	@Override
	public void render(final PdfStamper pdfStamper) throws DocumentException {
		render(pdfStamper, super.getPageNumber());
	}

	@Override
	public void render(final PdfStamper pdfStamper, final int pageNumber) throws DocumentException {

		try {
			new RectangleRenderer(pageNumber, super.getX(), super.getY(), super.getHeight() - 50, super.getWidth(), FORM_FILL, FORM_BORDER).render(pdfStamper);
			addBox(pdfStamper, pageNumber, createBox(8, 80, TEXT_BOX_LONG), "CARD TYPE (Mastercard/Visa/Switch/Solo etc..)");
			addBox(pdfStamper, pageNumber, createBox(388, 80, TEXT_BOX_SHORT), "ISSUE NO.(if applicable)");
			addBox(pdfStamper, pageNumber, createBox(8, 45, TEXT_BOX_SHORT), "VALID FROM");
			addBox(pdfStamper, pageNumber, createBox(123, 45, TEXT_BOX_SHORT), "EXPIRY DATE");
			addBox(pdfStamper, pageNumber, createBox(238, 45, TEXT_BOX_SHORT), "SECURITY CODE (last 3 digits on signature strip)");
			addBox(pdfStamper, pageNumber, createBox(8, 10, TEXT_BOX_LONG), "CARDHOLDER'S NAME");
			addBox(pdfStamper, pageNumber, createBox(198, 10, TEXT_BOX_LONG), "SIGNATURE");
			RectangleRenderer claimantInput = createBox(388, 10, TEXT_BOX_SHORT);
			addBox(pdfStamper, pageNumber, claimantInput, "CLAIMANT ID");
			addText(pdfStamper, pageNumber, claimantInput.getX() + 5, claimantInput.getY() + 5, this.claimantId, 8);
			addText(pdfStamper, pageNumber, super.getX(), super.getY() + (int) super.getHeight() - 20, PAYMENT_FOOTER_TEXT, 6);
			addCreditCardNumberInput(pdfStamper, pageNumber, 198, 80, "CARD NO.(long number across front of card)");
			addPerforatedLine(pdfStamper, pageNumber);

		}
		catch (IOException e) {
			throw new DocumentException("Unable to create payment form: " + e);
		}
	}

	private RectangleRenderer createBox(final int relativeX, final int relativeY, final int width) throws DocumentException, IOException {
		return new RectangleRenderer(super.getX() + relativeX, super.getY() + relativeY, TEXT_BOX_HEIGHT, width, WHITE, FORM_BORDER);
	}

	private static void addBox(final PdfStamper pdfStamper, final int pageNumber, final RectangleRenderer textbox, final String label) throws DocumentException,
			IOException {
		textbox.render(pdfStamper, pageNumber);
		addText(pdfStamper, pageNumber, textbox.getX(), textbox.getY() + TEXT_BOX_HEIGHT + 5, label, 6);
	}

	private static void addText(final PdfStamper pdfStamper, final int pageNumber, final int x, final int y, final String text, final int fontSize)
			throws DocumentException, IOException {
		new TextRenderer(pageNumber, x, y, fontSize, text, 1000).render(pdfStamper);
	}

	private void addCreditCardNumberInput(final PdfStamper pdfStamper, final int pageNumber, int x, final int y, String label) throws DocumentException,
			IOException {

		int boxSize = TEXT_BOX_LONG / 18;

		for (int i = 0; i <= 17; i++) {
			addBox(pdfStamper, pageNumber, createBox(x, y, boxSize), label);
			x += boxSize;
			label = "";
		}
	}

	private void addPerforatedLine(final PdfStamper pdfStamper, final int pageNumber) {
		PdfContentByte cb = pdfStamper.getOverContent(pageNumber);
		cb.saveState();
		cb.moveTo(super.getX() + super.getWidth(), super.getY() + super.getHeight() - 10);
		cb.setLineDash(5f, 5f, 0f);
		cb.setLineWidth(1f);
		cb.lineTo(super.getX(), super.getY() + super.getHeight() - 10);
		cb.stroke();
		cb.restoreState();
	}
}
