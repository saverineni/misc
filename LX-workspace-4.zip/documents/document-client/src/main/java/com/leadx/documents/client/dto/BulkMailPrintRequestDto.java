package com.leadx.documents.client.dto;

import java.util.List;
import java.util.Map;

public class BulkMailPrintRequestDto {
	private int claimantId;
	private List<Integer> claimIds;
	private int userId;
	private Integer mailingId;
	private Integer documentId;
	private Integer templateId;
	private Map<String, Object> additionalData;
	private boolean isLastRequest;
	private boolean includeNpwClaims;

	public BulkMailPrintRequestDto() {
	}

	public BulkMailPrintRequestDto(int claimantId, List<Integer> claimIds, int userId, Integer mailingId, Integer documentId,
			Integer templateId, Map<String, Object> additionalData, boolean isLastRequest, boolean includeNpwClaims) {
		this.claimantId = claimantId;
		this.claimIds = claimIds;
		this.userId = userId;
		this.mailingId = mailingId;
		this.documentId = documentId;
		this.templateId = templateId;
		this.additionalData = additionalData;
		this.isLastRequest = isLastRequest;
		this.includeNpwClaims = includeNpwClaims;
	}

	public Integer getDocumentId() {
		return this.documentId;
	}

	public void setDocumentId(Integer documentId) {
		this.documentId = documentId;
	}

	public int getClaimantId() {
		return this.claimantId;
	}

	public void setClaimantId(int claimantId) {
		this.claimantId = claimantId;
	}

	public List<Integer> getClaimIds() {
		return this.claimIds;
	}

	public void setClaimIds(List<Integer> claimIds) {
		this.claimIds = claimIds;
	}

	public int getUserId() {
		return this.userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public Integer getMailingId() {
		return this.mailingId;
	}

	public void setMailingId(Integer mailingId) {
		this.mailingId = mailingId;
	}

	public Integer getTemplateId() {
		return this.templateId;
	}

	public void setTemplateId(Integer templateId) {
		this.templateId = templateId;
	}

	public Map<String, Object> getAdditionalData() {
		return this.additionalData;
	}

	public void setAdditionalData(Map<String, Object> additionalData) {
		this.additionalData = additionalData;
	}

	public boolean isLastRequest() {
		return this.isLastRequest;
	}

	public void setLastRequest(boolean lastRequest) {
		this.isLastRequest = lastRequest;
	}

	public boolean isIncludeNpwClaims() {
		return includeNpwClaims;
	}

	public void setIncludeNpwClaims(boolean includeNpwClaims) {
		this.includeNpwClaims = includeNpwClaims;
	}
}
