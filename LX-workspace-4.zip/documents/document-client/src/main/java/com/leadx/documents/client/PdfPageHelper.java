package com.leadx.documents.client;

import static com.leadx.documents.client.TcgPdfContent.FOOTER_TEXT;
import static com.leadx.documents.client.TcgPdfContent.HEADER_FOOTER_LINE_BORDER;
import static com.leadx.documents.client.TcgPdfContent.HEADER_FOOTER_LINE_FILL;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.google.common.base.Joiner;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;

/**
 * @author pete.holmes
 */
public class PdfPageHelper {

	private final PdfWriter writer;
	private final Document document;

	private PdfRenderer footerRenderer;
	private PdfRenderer pageNumberRenderer;
	private PdfRenderer paymentFormRenderer;

	private final List<PdfRenderer> renderers = new ArrayList<PdfRenderer>();

	private float currentPosition;
	private boolean generatedContent = false;

	public PdfPageHelper(final PdfWriter writer, final Document document) {

		this.writer = writer;
		this.document = document;
		this.writer.setPageEvent(new PageEvent());
	}

	public ByteArrayOutputStream addHeaderAndFooter(final ByteArrayOutputStream outputStream, final String headerText, final String headerImageVal,
			final String headerDocRef, final boolean includePageNumbers, final boolean includePaymentForm, final String claimantId) throws DocumentException,
			IOException {

		if (this.document.isOpen()) {
			this.document.close();
		}

		initRenderers(headerText, headerImageVal, headerDocRef, claimantId, includePageNumbers, includePaymentForm);

		return render(outputStream, includePaymentForm);
	}

	public ByteArrayOutputStream addHeaderAndFooter(final ByteArrayOutputStream outputStream, final String headerImageVal, final String headerDocRef,
			final boolean includePageNumbers, final boolean includePaymentForm, final String claimantId) throws DocumentException, IOException {

		if (this.document.isOpen()) {
			this.document.close();
		}

		initRenderers(headerImageVal, headerDocRef, claimantId, includePageNumbers, includePaymentForm);

		return render(outputStream, includePaymentForm);
	}

	private ByteArrayOutputStream render(final ByteArrayOutputStream outputStream, final boolean includePaymentForm) throws IOException, DocumentException {
		final PdfReader reader = new PdfReader(outputStream.toByteArray());
		final ByteArrayOutputStream stampedContent = new ByteArrayOutputStream();
		final PdfStamper stamper = new PdfStamper(reader, stampedContent);

		validateSpaceRemaining(stamper, reader, includePaymentForm);
		final int totalPages = reader.getNumberOfPages();

		for (int i = 1; i < totalPages + 1; i++) {
			render(stamper, totalPages);
		}

		if (includePaymentForm) {
			this.paymentFormRenderer.render(stamper, totalPages);
			this.footerRenderer.setY(this.footerRenderer.getY() + (int) this.paymentFormRenderer.getHeight());
			this.footerRenderer.render(stamper, totalPages);
			new RectangleRenderer(left(), this.footerRenderer.getY() + 10, 2, width(), HEADER_FOOTER_LINE_FILL, HEADER_FOOTER_LINE_BORDER).render(stamper,
					totalPages);
		}

		stamper.close();
		return stampedContent;
	}

	public ByteArrayOutputStream addStamps(final ByteArrayOutputStream outputStream, final Map<Integer, java.util.List<PdfRenderer>> stamps)
			throws DocumentException, IOException {
		final PdfReader reader = new PdfReader(outputStream.toByteArray());
		final ByteArrayOutputStream stampedContent = new ByteArrayOutputStream();
		final PdfStamper stamper = new PdfStamper(reader, stampedContent);

		if (!stamps.isEmpty()) {
			final int totalPages = reader.getNumberOfPages();
			for (int i = 1; i < totalPages + 1; i++) {
				final List<PdfRenderer> renderersForPage = stamps.get(i);
				if (null != renderersForPage) {
					for (final PdfRenderer renderer : renderersForPage) {
						renderer.setPageNumber(i);
						renderer.render(stamper);
					}
				}
			}
		}
		stamper.close();
		return stampedContent;
	}

	private void render(final PdfStamper stamper, final int totalPages) throws DocumentException, IOException {

		for (final PdfRenderer renderer : this.renderers) {

			if (renderer != null) {

				renderer.setPageNumber(renderer.getPageNumber() + 1);

				if (renderer == this.pageNumberRenderer) {
					final String[] content = { String.format("page %d of %d", renderer.getPageNumber(), totalPages) };
					((TextRenderer) renderer).setLines(content);
				}

				renderer.render(stamper);
			}
		}
	}

	private void initRenderers(final String headerTextVal, final String headerImageVal, final String headerDocRef, final String claimantRef,
			final boolean includePageNumbering, final boolean includePaymentForm) throws DocumentException, IOException {

		this.renderers.add(new TextRenderer(right(), top() - 10, 8, headerTextVal, PdfContentByte.ALIGN_RIGHT, 1000, true)); // header

		initRenderers(headerImageVal, headerDocRef, claimantRef, includePageNumbering, includePaymentForm);
	}

	private void initRenderers(final String headerImageVal, final String headerDocRef, final String claimantRef, final boolean includePageNumbering,
			final boolean includePaymentForm) throws DocumentException, IOException {

		this.renderers.add(new ImageRenderer(headerImageVal, right() - 73, top() + 5, 39f, 73.00f)); // header image
		this.renderers.add(new TextRenderer(left(), top() + 15, 7, headerDocRef, PdfContentByte.ALIGN_LEFT, 1000, false)); // header DocRef

		this.footerRenderer = new TextRenderer(left() + 230, bottom() - 10, 6, FOOTER_TEXT, PdfContentByte.ALIGN_CENTER,  1000);
		this.renderers.add(this.footerRenderer);

		if (includePageNumbering) {
			this.pageNumberRenderer = new TextRenderer(right() - 30, bottom() - 35, 6, "", 1000);
			this.renderers.add(this.pageNumberRenderer);
		}

		if (includePaymentForm) {
			this.paymentFormRenderer = new PaymentFormRenderer(left(), bottom() - 30, claimantRef);
		}
	}

	public ByteArrayOutputStream addAddress(final ByteArrayOutputStream input, final java.util.List<String> address) throws DocumentException, IOException {
		final PdfReader reader = new PdfReader(input.toByteArray());
		final ByteArrayOutputStream stampedContent = new ByteArrayOutputStream();
		final PdfStamper stamper = new PdfStamper(reader, stampedContent);
		// Distance from 'top' of page to bottom of address: 165pt/58mm, Space required per address line: 11pt = 4mm
		new TextRenderer(1, left(), (top() - 165) + (11 * address.size()), 11, Joiner.on("\n")
			.join(address), PdfContentByte.ALIGN_LEFT, 1000).render(stamper, 1);
		stamper.close();
		return stampedContent;
	}

	public ByteArrayOutputStream addDate(final ByteArrayOutputStream input, final String date) throws IOException, DocumentException {
		final PdfReader reader = new PdfReader(input.toByteArray());
		final ByteArrayOutputStream stampedContent = new ByteArrayOutputStream();
		final PdfStamper stamper = new PdfStamper(reader, stampedContent);
		// Distance from 'top' of page to bottom of address: 165pt/58mm
		new TextRenderer(1, right(), (top() - 165), 11, date, PdfContentByte.ALIGN_RIGHT, 1000).render(stamper, 1);
		stamper.close();
		return stampedContent;
	}

	private void validateSpaceRemaining(final PdfStamper stamper, final PdfReader reader, final boolean includePaymentForm) {
		if (includePaymentForm && getRemainingPageSpace() < this.paymentFormRenderer.getHeight()) {
			stamper.insertPage(reader.getNumberOfPages() + 1,
					new Rectangle(PageSize.A4.getLeft(), PageSize.A4.getBottom(), PageSize.A4.getRight(), PageSize.A4.getTop()));
		}
	}

	private float getRemainingPageSpace() {
		return this.currentPosition - this.document.bottom();
	}

	private int left() {
		return (int) this.document.left();
	}

	private int right() {
		return (int) this.document.right();
	}

	private int bottom() {
		return (int) this.document.bottom();
	}

	private int top() {
		return (int) this.document.top();
	}

	private int width() {
		return right() - left();
	}

	public boolean hasGeneratedContent() {
		return this.generatedContent;
	}

	/* 
	 */
	protected class PageEvent extends PdfPageEventHelper {

		@SuppressWarnings("unqualified-field-access")
		@Override
		public void onParagraphEnd(final PdfWriter writer1, final Document document1, final float paragraphPosition) {
			currentPosition = paragraphPosition;
			generatedContent = true;
		}
	}
}
