package com.leadx.documents.client.markup;

import java.util.EnumSet;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Paragraph;

public interface WikiMarkupVisitor {

	Paragraph startParagraph();
	
	Paragraph startParagraph(final int lineSpacing);

	void endParagraph(Paragraph paragraph);

	void alignParagraph(Paragraph paragraph);

	void indentParagraph(Paragraph paragraph);

	void write(Paragraph paragraph, String text, EnumSet<Style> textStyle);

	void write(Paragraph paragraph, String text, EnumSet<Style> textStyle, BaseColor color);
}
