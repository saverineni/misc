package com.leadx.documents.client.dto;

import java.math.BigDecimal;

import org.joda.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect
public class InvoiceDto {

	private String documentId;
	private int claimId;
	private BigDecimal amountOutstanding;
	private LocalDate date;

	public InvoiceDto() {

	}

	public InvoiceDto(final String documentId, final int claimId, final BigDecimal amountOutstanding, final LocalDate date) {
		this.documentId = documentId;
		this.claimId = claimId;
		this.amountOutstanding = amountOutstanding;
		this.date = date;
	}

	public String getDocumentId() {
		return this.documentId;
	}

	public int getClaimId() {
		return this.claimId;
	}

	public BigDecimal getAmountOutstanding() {
		return this.amountOutstanding;
	}

	public LocalDate getDate() {
		return this.date;
	}

}
