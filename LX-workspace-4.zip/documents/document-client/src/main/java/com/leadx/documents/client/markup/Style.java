package com.leadx.documents.client.markup;

public enum Style {
	BOLD, ITALIC, UNDERLINE, STRIKETHRU, PLAIN
}
