package com.leadx.documents.client.dto;

import java.util.List;

import org.joda.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect
public class ClaimDto {

	private int id;
	private LocalDateTime invoicedDateTime;
	private List<OutstandingItemTypeDto> outstandingItemTypeDtos;

	public ClaimDto(final int id, final LocalDateTime invoicedDateTime, final List<OutstandingItemTypeDto> outstandingItemTypeDtos) {
		this.id = id;
		this.invoicedDateTime = invoicedDateTime;
		this.outstandingItemTypeDtos = outstandingItemTypeDtos;
	}

	public ClaimDto() {
	}

	public int getId() {
		return this.id;
	}

	public LocalDateTime getInvoicedDateTime() {
		return this.invoicedDateTime;
	}

	public List<OutstandingItemTypeDto> getOutstandingItemTypeDtos() {
		return this.outstandingItemTypeDtos;
	}

}
