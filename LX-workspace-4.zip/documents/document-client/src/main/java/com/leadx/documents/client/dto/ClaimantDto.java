package com.leadx.documents.client.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect
public class ClaimantDto {
	public ClaimantDto(int id, List<OutstandingItemTypeDto> outstandingItemTypeDtos) {
		this.id = id;
		this.outstandingItemTypeDtos = outstandingItemTypeDtos;
	}

	public ClaimantDto() {
	}

	public int getId() {
		return id;
	}

	public List<OutstandingItemTypeDto> getOutstandingItemTypeDtos() {
		return this.outstandingItemTypeDtos;
	}

	private int id;
	private List<OutstandingItemTypeDto> outstandingItemTypeDtos;

}
