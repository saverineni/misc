package com.leadx.documents.client.dto;

import com.leadx.web.tcg.client.claimservice.CreditAgreementAndClaimDto;

import java.util.List;
import java.util.Map;

public class PpiDto {
	private CreditAgreementDto creditAgreementDto;
	private ClaimantDto claimantDto;
	private List<OutstandingItemTypeDto> allFosOutstandingItemTypes; // All possible fos items
	private PaymentPlanDto paymentPlanDto;
	private List<InvoiceDto> invoiceDtos;
	private Map<String, Object> legacyMessage;
	private List<CreditAgreementAndClaimDto> creditAgreementAndClaimDtos;

	public List<CreditAgreementAndClaimDto> getCreditAgreementAndClaimDtos() {
		return creditAgreementAndClaimDtos;
	}

	public void setCreditAgreementAndClaimDtos(List<CreditAgreementAndClaimDto> creditAgreementAndClaimDtos) {
		this.creditAgreementAndClaimDtos = creditAgreementAndClaimDtos;
	}

	public PpiDto(CreditAgreementDto creditAgreementDto, ClaimantDto claimantDto, List<OutstandingItemTypeDto> allFosOutstandingItemTypes, PaymentPlanDto paymentPlanDto, List<InvoiceDto> invoiceDtos, Map<String, Object> legacyMessage, List<CreditAgreementAndClaimDto> creditAgreementAndClaimDtos) {
		this.creditAgreementDto = creditAgreementDto;
		this.claimantDto = claimantDto;
		this.allFosOutstandingItemTypes = allFosOutstandingItemTypes;
		this.paymentPlanDto = paymentPlanDto;
		this.invoiceDtos = invoiceDtos;
		this.legacyMessage = legacyMessage;
		this.creditAgreementAndClaimDtos = creditAgreementAndClaimDtos;
	}

	public PpiDto() {
	}

	public CreditAgreementDto getCreditAgreementDto() {
		return this.creditAgreementDto;
	}

	public void setCreditAgreementDto(CreditAgreementDto creditAgreementDto) {
		this.creditAgreementDto = creditAgreementDto;
	}

	public ClaimantDto getClaimantDto() {
		return this.claimantDto;
	}

	public void setClaimantDto(ClaimantDto claimantDto) {
		this.claimantDto = claimantDto;
	}

	public List<OutstandingItemTypeDto> getAllFosOutstandingItemTypes() {
		return this.allFosOutstandingItemTypes;
	}

	public void setAllFosOutstandingItemTypes(List<OutstandingItemTypeDto> allFosOutstandingItemTypes) {
		this.allFosOutstandingItemTypes = allFosOutstandingItemTypes;
	}

	public PaymentPlanDto getPaymentPlanDto() {
		return this.paymentPlanDto;
	}

	public void setPaymentPlanDto(PaymentPlanDto paymentPlanDto) {
		this.paymentPlanDto = paymentPlanDto;
	}

	public List<InvoiceDto> getInvoiceDtos() {
		return this.invoiceDtos;
	}

	public void setInvoiceDtos(List<InvoiceDto> invoiceDtos) {
		this.invoiceDtos = invoiceDtos;
	}

	public Map<String, Object> getLegacyMessage() {
		return this.legacyMessage;
	}

	public void setLegacyMessage(Map<String, Object> legacyMessage) {
		this.legacyMessage = legacyMessage;
	}
}
