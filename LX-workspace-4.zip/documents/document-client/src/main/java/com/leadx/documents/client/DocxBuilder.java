package com.leadx.documents.client;

import groovy.util.BuilderSupport;

import java.io.File;
import java.io.OutputStream;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBElement;

import org.apache.commons.lang3.NotImplementedException;
import org.docx4j.model.structure.HeaderFooterPolicy;
import org.docx4j.model.structure.SectionWrapper;
import org.docx4j.openpackaging.exceptions.Docx4JException;
import org.docx4j.openpackaging.io.SaveToZipFile;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.WordprocessingML.HeaderPart;
import org.docx4j.vml.CTRoundRect;
import org.docx4j.vml.CTShape;
import org.docx4j.vml.CTTextbox;
import org.docx4j.wml.Br;
import org.docx4j.wml.ContentAccessor;
import org.docx4j.wml.P;
import org.docx4j.wml.PPr;
import org.docx4j.wml.PPrBase.Ind;
import org.docx4j.wml.PPrBase.NumPr;
import org.docx4j.wml.PPrBase.NumPr.Ilvl;
import org.docx4j.wml.PPrBase.NumPr.NumId;
import org.docx4j.wml.Pict;
import org.docx4j.wml.R;
import org.docx4j.wml.STBrType;
import org.docx4j.wml.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author gareth.evans
 */
public class DocxBuilder extends BuilderSupport {

	private static final org.docx4j.wml.ObjectFactory FACTORY = new org.docx4j.wml.ObjectFactory();
	private static final Logger LOG = LoggerFactory.getLogger(DocxBuilder.class);

	// Indent Multiplier - equates to about 0.63cm in a docx
	private static final long IM = 360L;

	protected enum NodeType {
		call, h1, h2, h3, h4, h5, h6, p, ul, ol, li, ind, s, header, pb, sar, inc
	}

	private Object parent;
	private String bulletStyle;
	private int indentationLevel = 0;

	private WordprocessingMLPackage wordMLPackage;


	public static DocxBuilder newInstance() {
		return new DocxBuilder();
	}

	@Override
	protected Object createNode(final Object name) {
		return createNode(name, null, null);
	}

	@Override
	protected Object createNode(final Object name, final Object value) {
		return createNode(name, null, value);
	}

	@Override
	protected Object createNode(final Object name, @SuppressWarnings("rawtypes") final Map attributes) {
		return createNode(name, attributes, null);
	}

	@Override
	protected Object createNode(final Object name, @SuppressWarnings("rawtypes") final Map attributes, final Object value) {
		final NodeType nodeType = NodeType.valueOf(name.toString());
		switch (nodeType) {
			case call:
				final Object templateObject = attributes.get("template");
				if (null != templateObject) {
					final String templateLocation = templateObject.toString();
					try {
						this.wordMLPackage = WordprocessingMLPackage.load(new File(templateLocation));
					}
					catch (final Docx4JException e) {
						throw new RuntimeException("Unable to open template " + templateLocation, e);
					}
				}
				return NodeType.call;
			case h1:
				addHeading(1, value.toString());
				return NodeType.h1;
			case h2:
				addHeading(2, value.toString());
				return NodeType.h2;
			case h3:
				addHeading(3, value.toString());
				return NodeType.h3;
			case h4:
				addHeading(4, value.toString());
				return NodeType.h4;
			case h5:
				addHeading(5, value.toString());
				return NodeType.h5;
			case h6:
				addHeading(6, value.toString());
				return NodeType.h6;
			case p:
				this.wordMLPackage.getMainDocumentPart()
					.addParagraphOfText(value.toString());
				return NodeType.p;
			case s:
				// Small oddity here, using the no spacing style as a double spaced style in the template.
				// The default style in the template is no spaced.
				this.wordMLPackage.getMainDocumentPart()
					.addStyledParagraphOfText("NoSpacing", value.toString());
				return NodeType.s;
			case ul:
				nodeStarted(this.parent, NodeType.ul);
				return NodeType.ul;
			case ol:
				nodeStarted(this.parent, NodeType.ol);
				return NodeType.ol;
			case li:
				addListItem((this.indentationLevel - 1), value.toString());
				return NodeType.li;
			case ind:
				addIndentedItem((this.indentationLevel - 1), value.toString());
				return NodeType.ind;
			case header:
				List<SectionWrapper> sectionWrappers = this.wordMLPackage.getDocumentModel()
					.getSections();
				HeaderPart header = null;
				for (SectionWrapper section : sectionWrappers) {
					HeaderFooterPolicy policy = section.getHeaderFooterPolicy();
					if (policy.getDefaultHeader() != null) {
						header = policy.getDefaultHeader();
					}
				}
				if (null != header) {
					replace(header, "ref", value.toString());
				}
				return NodeType.header;
			case sar:
				replace(this.wordMLPackage.getMainDocumentPart(), "##replace##", value.toString());
				return NodeType.sar;
			case pb:
				P para = FACTORY.createP();
				Br pageBreak = new Br();
				pageBreak.setType(STBrType.PAGE);
				para.getContent()
					.add(pageBreak);
				this.wordMLPackage.getMainDocumentPart()
					.getContent()
					.add(para);
				return NodeType.pb;
			case inc:
				final Object includedDocument = value;
				if (null != includedDocument) {
					final String templateLocation = includedDocument.toString();
					WordprocessingMLPackage includedWordMLPackage;
					try {
						includedWordMLPackage = WordprocessingMLPackage.load(new File(templateLocation));
					}
					catch (final Docx4JException e) {
						throw new RuntimeException("Unable to open included document " + templateLocation, e);
					}

					for (Object obj : includedWordMLPackage.getMainDocumentPart()
						.getContent()) {
						this.wordMLPackage.getMainDocumentPart()
							.addObject(obj);
					}
				}
				return NodeType.inc;
			default:
				throw new NotImplementedException("Unknown function " + name);
		}
	}

	@SuppressWarnings("rawtypes")
	private void replace(ContentAccessor node, String search, String replacement) {
		for (Object subNode : node.getContent()) {
			if (subNode instanceof JAXBElement) {
				replaceProcessJAXBElement((JAXBElement) subNode, search, replacement);
			}
			else if (subNode instanceof Text) {
				Text text = (Text) subNode;
				if (search.equals(text.getValue())) {
					text.setValue(replacement);
				}
			}
			else if (subNode instanceof ContentAccessor) {
				replace((ContentAccessor) subNode, search, replacement);
			}
		}
	}

	// This method will need adding to if the text being searched for is embedded in something not covered here
	@SuppressWarnings("rawtypes")
	private void replaceProcessJAXBElement(JAXBElement element, String search, String replacement) {
		JAXBElement castElement = element;
		Class type = castElement.getDeclaredType();
		if (type == Text.class) {
			Text text = ((Text) castElement.getValue());
			if (search.equals(text.getValue())) {
				text.setValue(replacement);
			}
		}
		else if (type == ContentAccessor.class) {
			replace((ContentAccessor) element.getValue(), search, replacement);
		}
		else if (type == Pict.class) {
			Pict pict = ((Pict) castElement.getValue());
			for (Object subElement : pict.getAnyAndAny()) {
				if (subElement instanceof JAXBElement) {
					replaceProcessJAXBElement((JAXBElement) subElement, search, replacement);
				}
			}
		}
		else if (type == CTRoundRect.class) {
			CTRoundRect rect = ((CTRoundRect) castElement.getValue());
			for (Object subElement : rect.getPathOrFormulasOrHandles()) {
				if (subElement instanceof JAXBElement) {
					replaceProcessJAXBElement((JAXBElement) subElement, search, replacement);
				}
			}
		}
		else if (type == CTShape.class) {
			CTShape shape = ((CTShape) castElement.getValue());
			for (Object subElement : shape.getPathOrFormulasOrHandles()) {
				if (subElement instanceof JAXBElement) {
					replaceProcessJAXBElement((JAXBElement) subElement, search, replacement);
				}
			}
		}
		else if (type == CTTextbox.class) {
			CTTextbox box = ((CTTextbox) castElement.getValue());
			for (Object subElement : box.getTxbxContent()
				.getEGBlockLevelElts()) {
				if (subElement instanceof ContentAccessor) {
					replace((ContentAccessor) subElement, search, replacement);
				}
			}
		}
	}

	protected void nodeStarted(final Object parentNode, final NodeType node) {
		this.parent = parentNode;
		if (Arrays.asList(NodeType.ul, NodeType.ol)
			.contains(node)) {
			this.bulletStyle = node.toString();
			this.indentationLevel++;
		}
	}

	@Override
	protected void nodeCompleted(final Object parentNode, final Object node) {
		this.parent = parentNode;
		if (Arrays.asList(NodeType.ul, NodeType.ol)
			.contains(node)) {
			this.bulletStyle = node.toString();
			this.indentationLevel--;
		}
	}

	protected void addHeading(final int level, final String text) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("Adding header" + level + " of '" + text + "'");
		}
		this.wordMLPackage.getMainDocumentPart()
			.addStyledParagraphOfText("Heading" + level, text);
	}

	private void addIndentedItem(int itemLevel, String text) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("Creating indenteditem of '" + text + "' with level " + itemLevel);
		}
		final P p = createParagraphWithText(text);

		final PPr ppr = FACTORY.createPPr();
		p.setPPr(ppr);

		indentParagraphToLevel(p, itemLevel, false);

		this.wordMLPackage.getMainDocumentPart()
			.addObject(p);
	}

	protected void addListItem(final int itemLevel, final String text) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("Creating listitem of '" + text + "' with level " + itemLevel);
		}
		final P p = createParagraphWithText(text);

		final PPr ppr = FACTORY.createPPr();
		p.setPPr(ppr);

		final NumPr numPr = FACTORY.createPPrBaseNumPr();
		ppr.setNumPr(numPr);

		final Ilvl ilvlElement = FACTORY.createPPrBaseNumPrIlvl();
		numPr.setIlvl(ilvlElement);
		ilvlElement.setVal(BigInteger.valueOf(itemLevel));

		final NumId numIdElement = FACTORY.createPPrBaseNumPrNumId();
		numPr.setNumId(numIdElement);
		NodeType style = NodeType.valueOf(this.bulletStyle);
		numIdElement.setVal(BigInteger.valueOf(NodeType.ul.equals(style)
				? 1L
				: 5L));

		indentParagraphToLevel(p, itemLevel, true);

		this.wordMLPackage.getMainDocumentPart()
			.addObject(p);
	}

	@Override
	protected void setParent(final Object parent, final Object child) {
		this.parent = parent;
	}

	public void save(final String location) throws Docx4JException {
		final SaveToZipFile saver = new SaveToZipFile(this.wordMLPackage);
		saver.save(location);
	}

	public void save(final OutputStream outputStream) throws Docx4JException {
		final SaveToZipFile saver = new SaveToZipFile(this.wordMLPackage);
		saver.save(outputStream);
	}

	private static P createParagraphWithText(final String text) {
		final P p = FACTORY.createP();
		final Text t = FACTORY.createText();
		t.setValue(text);
		final R run = FACTORY.createR();
		run.getContent()
			.add(t);
		p.getContent()
			.add(run);
		return p;
	}

	private static void indentParagraphToLevel(final P paragraph, final int level, final boolean containsBulletChar) {
		Ind ind = new Ind();
		BigInteger spacer = BigInteger.valueOf(IM)
			.add(BigInteger.valueOf(IM)
				.multiply(BigInteger.valueOf(level)));
		ind.setLeft(spacer);
		if (containsBulletChar) {
			ind.setHanging(BigInteger.valueOf(IM));
		}
		paragraph.getPPr()
			.setInd(ind);
	}

}
