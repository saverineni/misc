package com.leadx.documents.client.dto;

import com.leadx.web.tcg.client.claimservice.PensionAgreementDto;

import java.util.List;

public class PenDto {

	private List<PensionAgreementDto> pensionAgreementDto;
	private ClaimantDto claimantDto;

	public PenDto(){}

	public PenDto(final List<PensionAgreementDto> pensionAgreementDto, final ClaimantDto claimantDto) {
		this.pensionAgreementDto = pensionAgreementDto;
		this.claimantDto = claimantDto;
	}

	public List<PensionAgreementDto> getPensionAgreementDto() { return pensionAgreementDto; }

	public void setPensionAgreementDto(List<PensionAgreementDto> pensionAgreementDto) {
		this.pensionAgreementDto = pensionAgreementDto;
	}

	public ClaimantDto getClaimantDto() { return claimantDto; }

	public void setClaimantDto(ClaimantDto claimantDto) { this.claimantDto = claimantDto; }
}
