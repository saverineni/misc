/**
 *
 */
package com.leadx.documents.client;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;

/**
 * @author Gareth.Evans
 * @author Adam.George
 */
public class PdfProducer {

	private InputStream inputStream;
	private List<Renderable> renderers;

	/**
	 * Constructs a new {@link PdfProducer} based on the given PDF {@link File}.
	 * 
	 * @param template The {@link File} representing PDF file to use as a template
	 * @throws FileNotFoundException if the given {@link File} does not exist
	 */
	public PdfProducer(final File template) throws FileNotFoundException {
		this.inputStream = new FileInputStream(template);
	}

	/**
	 * Constructs a new {@link PdfProducer} based on the given {@link InputStream}.
	 * 
	 * @param inputStream The {@link InputStream} to construct the {@link PdfProducer} from
	 */
	public PdfProducer(final InputStream inputStream) {
		this.inputStream = inputStream;
	}

	/**
	 * Adds the given {@link Renderable} to this {@link PdfProducer}.
	 * 
	 * @param renderable The {@link Renderable} object to add
	 * @return <code>this</code> for method chaining
	 */
	public PdfProducer render(final Renderable renderable) {
		if (null == this.renderers) {
			this.renderers = new ArrayList<Renderable>();
		}
		this.renderers.add(renderable);
		return this;
	}

	/**
	 * Reads the template PDF file and writes it to the given {@link OutputStream}, adding each {@link Renderable} that has been set on this
	 * {@link PdfProducer}. If no {@link Renderable}s have been added then the template is simply written to the given {@link OutputStream}.
	 * 
	 * @param outputStream The {@link OutputStream} to which the rendered PDF file content should be sent
	 * @throws IOException If an I/O error occurs
	 * @throws DocumentException If the template document is invalid
	 */
	public void saveTo(final OutputStream outputStream) throws IOException, DocumentException {
		final PdfReader pdfReader = new PdfReader(this.inputStream);
		final PdfStamper pdfStamper = new PdfStamper(pdfReader, outputStream);

		if (null != this.renderers && this.renderers.size() > 0) {
			for (final Renderable renderer : this.renderers) {
				renderer.render(pdfStamper);
			}
		}

		this.inputStream.close();
		pdfStamper.setFormFlattening(true);
		pdfStamper.close();
	}

	/**
	 * Reads the template PDF file, renders all {@link Renderable}s set on this {@link PdfProducer} and returns the resultant file content
	 * as an {@link InputStream}.
	 * 
	 * @return The rendered PDF file in the form of an {@link InputStream}
	 * @throws IOException If an I/O error occurs
	 * @throws DocumentException If the template document is invalid
	 */
	public InputStream getPdfAsInputStream() throws IOException, DocumentException {
		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		saveTo(outputStream);
		return new ByteArrayInputStream(outputStream.toByteArray());
	}

}
