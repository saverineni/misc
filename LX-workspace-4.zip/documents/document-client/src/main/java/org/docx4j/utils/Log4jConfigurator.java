package org.docx4j.utils;

/** Overrides the version in docx4j to avoid pulling in log4j dependencies. Otherwise these get pulled in even if you aren't using it so you have to include them
 * in you pom. Version 3 of docx should remove the need for this.
 */
@SuppressWarnings("unused")
public class Log4jConfigurator {

	public synchronized static void configure() {

	}

}
