package com.leadx.documents.client;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import org.junit.Test;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.leadx.documents.client.PdfPageHelper;

/**
 * @author pete.holmes
 */
public class PdfHelperUnitTest {

	private final static String headerImage = "src/test/templates/header.png";

	private final static String header = "Lynnfield House" + "\nChurch Street" + "\nAltrincham" + "\nWA14 4DZ" + "\nT  0844 357 1622"
		+ "\nE  enquiries@theclaimsguys.co.uk" + "\nW  www.theclaimsguys.co.uk";

	@Test
	public void canGeneratePdfWithHeaderAndFooter() throws Exception {

		final String outputFile = "target/stampedOutputPdf.pdf";

		final Document document = new Document(PageSize.A4, 50, 50, 140, 70);

		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		final PdfWriter writer = PdfWriter.getInstance(document, stream);
		final PdfPageHelper pageHelper = new PdfPageHelper(writer, document);
		document.open();

		for (int i = 0; i < 10; i++) {
			final Paragraph par =
					new Paragraph("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc congue gravida enim,"
						+ " eu lacinia leo sollicitudin ut. Curabitur et hendrerit magna. Donec laoreet, nulla ut dictum posuere, "
						+ "libero est adipiscing felis, at ullamcorper quam erat nec ipsum. Morbi gravida dolor mi, ac feugiat nunc. "
						+ "Nam sit amet pretium ipsum. Donec ut risus mauris. Cum sociis natoque penatibus et magnis dis parturient "
						+ "montes, nascetur ridiculus mus. Donec ornare convallis tempus. Donec viverra, leo sit amet tempus venenatis, "
						+ "justo diam aliquam felis, eu consectetur risus sapien eget risus. Vestibulum eleifend imperdiet ultricies. "
						+ "Phasellus sodales enim eu lectus bibendum in suscipit elit varius. Aliquam rutrum molestie ante a rhoncus.");

			document.add(par);
		}

		stream = pageHelper.addHeaderAndFooter(stream, header, headerImage, "", true, true, "Claimant_123");

		new FileOutputStream(outputFile).write(stream.toByteArray());
		assertThat(new File(outputFile).exists(), is(true));
	}
}
