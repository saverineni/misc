package com.leadx.documents.client.markup;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.eclipse.mylyn.wikitext.confluence.core.ConfluenceLanguage;
import org.eclipse.mylyn.wikitext.core.parser.MarkupParser;
import org.junit.Test;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;
import com.leadx.documents.client.markup.ITextDocumentBuilder;

public class WikiTextParserUnitTest {

	@Test
	public void canParseContent() throws DocumentException, FileNotFoundException, IOException {
		final String content = FileUtils.readFileToString(new File("src/test/resources/testdata/wikitext.txt"));
		assertThat(content, is(notNullValue()));

		final MarkupParser markupParser = new MarkupParser();
		markupParser.setMarkupLanguage(new ConfluenceLanguage());

		final ByteArrayOutputStream stream = new ByteArrayOutputStream();
		final Document document = new Document(PageSize.A4, 50, 50, 140, 70);
		PdfWriter.getInstance(document, stream);

		document.open();

		markupParser.setBuilder(new ITextDocumentBuilder(document));
		markupParser.parse(content);

		document.close();

		final File output = new File("target/generated_from_wiki_text.pdf");
		new FileOutputStream(output).write(stream.toByteArray());
		assertThat(output.exists(), is(true));
	}
}
