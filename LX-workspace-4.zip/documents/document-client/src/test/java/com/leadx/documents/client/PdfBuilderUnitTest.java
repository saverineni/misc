package com.leadx.documents.client;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import groovy.lang.Binding;
import groovy.util.GroovyScriptEngine;
import groovy.util.ResourceException;
import groovy.util.ScriptException;
import org.junit.Test;

/**
 * @author gareth.evans
 */
public class PdfBuilderUnitTest {

	@Test
	public void canGenerateDocument() throws IOException, ResourceException, ScriptException {
		final GroovyScriptEngine groovyScriptEngine = new GroovyScriptEngine("src/test/groovy");
		final File file = new File("target/generated.pdf");
		final OutputStream outputStream = new FileOutputStream(file);
		final Binding binding = createBinding(outputStream);

		groovyScriptEngine.run("EXAMPLE_PDF.groovy", binding);
		assertThat(file.exists(), is(true));
	}

	@Test
	public void canGenerateDocument2() throws IOException, ResourceException, ScriptException {
		final GroovyScriptEngine groovyScriptEngine = new GroovyScriptEngine("src/test/groovy");
		final File file = new File("target/generated2.pdf");
		final OutputStream outputStream = new FileOutputStream(file);
		final Binding binding = createBinding(outputStream);

		groovyScriptEngine.run("EXAMPLE2_PDF.groovy", binding);
		assertThat(file.exists(), is(true));
	}

	@Test
	public void canGenerateDocument3() throws IOException, ResourceException, ScriptException {
		final GroovyScriptEngine groovyScriptEngine = new GroovyScriptEngine("src/test/groovy");
		final File file = new File("target/generated3.pdf");
		final OutputStream outputStream = new FileOutputStream(file);
		final Binding binding = createBinding(outputStream);

		groovyScriptEngine.run("EXAMPLE3_PDF.groovy", binding);
		assertThat(file.exists(), is(true));
	}

	@Test
	public void canGenerateDoucment4() throws IOException, ResourceException, ScriptException {
		final GroovyScriptEngine groovyScriptEngine = new GroovyScriptEngine("src/test/groovy");
		final File file = new File("target/generated4.pdf");
		final OutputStream outputStream = new FileOutputStream(file);
		final Binding binding = createBinding(outputStream);

		groovyScriptEngine.run("EXAMPLE4_PDF.groovy", binding);
		assertThat(file.exists(), is(true));
	}

	@Test
	public void canGenerateDocumentWithTables() throws IOException, ResourceException, ScriptException {
		final GroovyScriptEngine groovyScriptEngine = new GroovyScriptEngine("src/test/groovy");
		final File file = new File("target/generated5.pdf");
		final OutputStream outputStream = new FileOutputStream(file);
		final Binding binding = createBinding(outputStream);

		groovyScriptEngine.run("EXAMPLE_TABLES_PDF.groovy", binding);
		assertThat(file.exists(), is(true));
	}

	private static Binding createBinding(final OutputStream outputStream) {
		final Binding binding = new Binding();
		binding.setProperty("outputStream", outputStream);
		binding.setProperty("templateDirectory", new File("src/test/templates"));
		return binding;
	}
}
