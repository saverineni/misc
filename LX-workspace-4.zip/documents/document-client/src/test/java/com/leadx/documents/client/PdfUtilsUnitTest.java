/**
 *
 */
package com.leadx.documents.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.itextpdf.text.DocumentException;
import com.leadx.documents.client.PdfUtils;
import com.leadx.documents.client.TextRenderer;

import org.junit.Test;

/**
 * @author Gareth.Evans
 */
public class PdfUtilsUnitTest {

	@Test
	public void stringSplittingShouldWorkCorrectly() {
		final String text = "the brown fox jumped over the lazy dog and then swam in the pond";
		final String[] splitString = TextRenderer.wordWrap(text, 30);
		assertNotNull(splitString);
		assertEquals(3, splitString.length);
		assertEquals("the brown fox jumped over the", splitString[0]);
		assertEquals("lazy dog and then swam in the", splitString[1]);
		assertEquals("pond", splitString[2]);
	}

	@Test
	public void canCorrectlySplitAnAddress() {
		final String address = "LeadX Limited, Lynnfield House, Church Street, Altrincham, WA14 4DZ";
		final String[] splitAddress = TextRenderer.wordWrap(address, 35);
		assertNotNull(splitAddress);
		assertEquals(2, splitAddress.length);
		assertEquals("LeadX Limited, Lynnfield House,", splitAddress[0]);
		assertEquals("Church Street, Altrincham, WA14 4DZ", splitAddress[1]);
	}

	@Test
	public void testCanMergeAcroFormsAndPdfs() throws IOException, DocumentException {
		final File pdfTemplatePage1 =
				new File("src" + File.separator + "test" + File.separator + "resources" + File.separator + "testdata" + File.separator
					+ "Letter_-_Credit_Card_Charges.pdf");

		final File pdfTemplatePage2 =
				new File("src" + File.separator + "test" + File.separator + "resources" + File.separator + "testdata" + File.separator
					+ "RL_Letter_of_Authority_Credit_Card_1.pdf");

		// Parameters for AcroForm
		final Map<String, String> acroFormParams = new HashMap<String, String>();
		acroFormParams.put("addressArea", "1 address line \r\n \n \r \n test ");
		acroFormParams.put("salutation", "Dear Jimmy");
		acroFormParams.put("agentSignature", "Barrbie Bobbins");
		acroFormParams.put("Name", "Mr Jimmy Bobbins");
		acroFormParams.put("Address 1", "Address line 1");
		acroFormParams.put("Address 2", "Address line 2");
		acroFormParams.put("Postcode", "WA14 4DZ");
		acroFormParams.put("Telephone 1", "011328822548");
		// "Yes/Off/No"
		acroFormParams.put("checkBox1", "Yes");
		acroFormParams.put("checkBox2", "No");
		acroFormParams.put("radioButton1", "Yes");
		acroFormParams.put("radioButton2", "No");

		final List<File> pdfs = new ArrayList<File>();
		pdfs.add(pdfTemplatePage1);
		pdfs.add(pdfTemplatePage2);

		final File file = new File("target" + File.separator, "finalMegreAcroFormTest.pdf");

		// Copy pdf's containing AcroForm fields
		PdfUtils.copyPdfsAndAcroFormFields(pdfs, file);

		// Attempt to fill in acroform's
		PdfUtils.fillInAcroForm(file, acroFormParams, file);

		assertTrue(file.exists());
	}
}
