package com.leadx.documents.client;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import groovy.lang.Binding;
import groovy.util.GroovyScriptEngine;
import groovy.util.ResourceException;
import groovy.util.ScriptException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.junit.Test;

/**
 * @author gareth.evans
 */
public class DocxBuilderUnitTest {

	@Test
	public void canGenerateDocument() throws IOException, ResourceException, ScriptException {
		final GroovyScriptEngine groovyScriptEngine = new GroovyScriptEngine("src/test/groovy");
		final File file = new File("target/generated.docx");
		final OutputStream outputStream = new FileOutputStream(file);
		final Binding binding = new Binding();
		binding.setProperty("outputStream", outputStream);

		groovyScriptEngine.run("EXAMPLE_DOCX.groovy", binding);
		assertThat(file.exists(), is(true));
	}
}
