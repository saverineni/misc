package com.leadx.documents.client.markup;

import static com.leadx.documents.client.markup.Style.BOLD;
import static com.leadx.documents.client.markup.Style.ITALIC;
import static com.leadx.documents.client.markup.Style.UNDERLINE;
import static java.util.EnumSet.of;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JMock;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.Paragraph;
import com.leadx.documents.client.markup.WikiMarkupParser;
import com.leadx.documents.client.markup.WikiMarkupVisitor;

/**
 * @author gareth.evans
 */
@SuppressWarnings("unqualified-field-access")
@RunWith(JMock.class)
public class WikiMarkupParserUnitTest {

	private final Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
		}
	};

	private WikiMarkupParser parser;

	protected WikiMarkupVisitor visitor;
	private Paragraph paragraph;

	@Before
	public void before() {
		this.visitor = this.context.mock(WikiMarkupVisitor.class);
		this.paragraph = this.context.mock(Paragraph.class);
		this.parser = new WikiMarkupParser(this.visitor);
	}

	@Test
	public void canParseWikiMarkup() {
		this.context.checking(new Expectations() {
			{
				one(visitor).startParagraph();
				will(returnValue(paragraph));
				one(visitor).indentParagraph(paragraph);
				one(visitor).write(paragraph, "This is a single line block of text", null);
				one(visitor).endParagraph(paragraph);
			}
		});

		this.parser.parseForParagraph("This is a single line block of text");
	}

	@Test
	public void canParseWikiMarkupForTwoLinesOfText() {
		this.context.checking(new Expectations() {
			{
				one(visitor).startParagraph();
				will(returnValue(paragraph));
				one(visitor).indentParagraph(paragraph);
				one(visitor).write(paragraph, "This is a single line block of text. This is a single line block of text", null);
				one(visitor).endParagraph(paragraph);
			}
		});
		this.parser.parseForParagraph("This is a single line block of text.\nThis is a single line block of text");
	}

	@Test
	public void canParseWikiMarkupForTwoParagraphs() {
		this.context.checking(new Expectations() {
			{
				one(visitor).startParagraph();
				will(returnValue(paragraph));
				one(visitor).indentParagraph(paragraph);
				one(visitor).write(paragraph, "This is a single line block of text.", null);
				one(visitor).endParagraph(paragraph);

				one(visitor).startParagraph();
				will(returnValue(paragraph));
				one(visitor).indentParagraph(paragraph);
				one(visitor).write(paragraph, "This is a single line block of text", null);
				one(visitor).endParagraph(paragraph);
			}
		});
		this.parser.parseForParagraph("This is a single line block of text.\n\nThis is a single line block of text");
	}

	@Test
	public void canParseWikiMarkupWithInlineBoldText() {
		this.context.checking(new Expectations() {
			{
				one(visitor).startParagraph();
				will(returnValue(paragraph));
				one(visitor).indentParagraph(paragraph);
				one(visitor).write(paragraph, "This is a ", null);
				one(visitor).write(paragraph, "single line block", of(BOLD));
				one(visitor).write(paragraph, " of text", null);
				one(visitor).endParagraph(paragraph);
			}
		});
		this.parser.parseForParagraph("This is a *single line block* of text");
	}

	@Test
	public void canParseWikiMarkupWithInlineItalicText() {
		this.context.checking(new Expectations() {
			{
				one(visitor).startParagraph();
				will(returnValue(paragraph));
				one(visitor).indentParagraph(paragraph);
				one(visitor).write(paragraph, "This is a ", null);
				one(visitor).write(paragraph, "single line block", of(ITALIC));
				one(visitor).write(paragraph, " of text", null);
				one(visitor).endParagraph(paragraph);
			}
		});
		this.parser.parseForParagraph("This is a _single line block_ of text");
	}

	@Test
	public void canParseWikiMarkupWithInlineUnderlineText() {
		this.context.checking(new Expectations() {
			{
				one(visitor).startParagraph();
				will(returnValue(paragraph));
				one(visitor).indentParagraph(paragraph);
				one(visitor).write(paragraph, "This is a ", null);
				one(visitor).write(paragraph, "single line block", of(UNDERLINE));
				one(visitor).write(paragraph, " of text", null);
				one(visitor).endParagraph(paragraph);
			}
		});
		this.parser.parseForParagraph("This is a +single line block+ of text");
	}

	@Test
	public void canHandleMarkupAtTheEndOfAParagraph() {
		this.context.checking(new Expectations() {
			{
				one(visitor).startParagraph();
				will(returnValue(paragraph));
				one(visitor).indentParagraph(paragraph);
				one(visitor).write(paragraph, "Credit Card Number: ", null);
				one(visitor).write(paragraph, "4000000000000002", of(BOLD));
				one(visitor).endParagraph(paragraph);
			}
		});
		this.parser.parseForParagraph("Credit Card Number: *4000000000000002*");
	}

	@Test
	public void canHandleMarkupAtTheStartOfAParagraph() {
		this.context.checking(new Expectations() {
			{
				one(visitor).startParagraph();
				will(returnValue(paragraph));
				one(visitor).indentParagraph(paragraph);
				one(visitor).write(paragraph, "Credit Card Number", of(BOLD));
				one(visitor).write(paragraph, ": 4000000000000002", null);
				one(visitor).endParagraph(paragraph);
			}
		});
		this.parser.parseForParagraph("*Credit Card Number*: 4000000000000002");
	}

	@Test
	public void canHandleMarkupForACompleteParagraph() {
		this.context.checking(new Expectations() {
			{
				one(visitor).startParagraph();
				will(returnValue(paragraph));
				one(visitor).indentParagraph(paragraph);
				one(visitor).write(paragraph, "Credit Card Number: 4000000000000002", of(BOLD));
				one(visitor).endParagraph(paragraph);
			}
		});
		this.parser.parseForParagraph("*Credit Card Number: 4000000000000002*");
	}

	public void canHandleColorFormatting() {
		this.context.checking(new Expectations() {
			{
				one(visitor).startParagraph();
				will(returnValue(paragraph));
				one(visitor).indentParagraph(paragraph);
				one(visitor).write(paragraph, "Make sure you allow", null, BaseColor.RED);
				one(visitor).write(paragraph, " each command to ", null);
				one(visitor).write(paragraph, "complete before moving on to the next one", null, BaseColor.BLUE);
				one(visitor).write(paragraph, " - the ", null);
				one(visitor).write(paragraph, "svn co command", null, BaseColor.GREEN);
				one(visitor).write(paragraph, " can take ", null);
				one(visitor).write(paragraph, "several seconds", null, BaseColor.YELLOW);
				one(visitor).endParagraph(paragraph);
			}
		});
		this.parser.parseForParagraph("{color:red}Make sure you allow{color} each command to {color:blue}complete before moving on to the next one{color} - the {color:green}svn co command{color} can take {color:yellow}several seconds{color}");
	}

	@Test
	public void testParseForListItem() {
		final ListItem listItem = this.context.mock(ListItem.class);
		this.context.checking(new Expectations() {
			{
				one(visitor).write(listItem, "Bold part", of(BOLD));
				one(visitor).write(listItem, " normal part", null);
				one(visitor).write(listItem, "line two", null);
			}
		});
		this.parser.parseForListItem(listItem, "*Bold part* normal part\n\nline two");
	}

	@Test
	public void canParseWikiMarkupWithTripleAsterisk() {
		this.context.checking(new Expectations() {
			{
				one(visitor).startParagraph();
				will(returnValue(paragraph));
				one(visitor).indentParagraph(paragraph);
				one(visitor).write(paragraph, "This is a single line block", null);
				one(visitor).write(paragraph, "*", of(BOLD));
				one(visitor).write(paragraph, " of text", null);
				one(visitor).endParagraph(paragraph);
			}
		});
		this.parser.parseForParagraph("This is a single line block*** of text");
	}

	@Test
	public void canParseWikiMarkupWithQuadrupleAsterisk() {
		// Quad Asterisk creates a single bold asterisk first, and a single non-bold second
		this.context.checking(new Expectations() {
			{
				one(visitor).startParagraph();
				will(returnValue(paragraph));
				one(visitor).indentParagraph(paragraph);
				one(visitor).write(paragraph, "This is a single line block", null);
				one(visitor).write(paragraph, "*", of(BOLD));
				one(visitor).write(paragraph, "* of text", null);
				one(visitor).endParagraph(paragraph);
			}
		});
		this.parser.parseForParagraph("This is a single line block**** of text");
	}

	@Test
	public void canParseWikiMarkupWithTripleAsteriskInsideBold() {
		// Triple Asterisk inside a bold block creates an asterisk which isn't bold
		this.context.checking(new Expectations() {
			{
				one(visitor).startParagraph();
				will(returnValue(paragraph));
				one(visitor).indentParagraph(paragraph);
				one(visitor).write(paragraph, "This is a ", null);
				one(visitor).write(paragraph, "single line", of(BOLD));
				one(visitor).write(paragraph, "*", null);
				one(visitor).write(paragraph, " block of", of(BOLD));
				one(visitor).write(paragraph, " text", null);
				one(visitor).endParagraph(paragraph);
			}
		});
		this.parser.parseForParagraph("This is a *single line*** block of* text");
	}

	@Test
	public void canParseWikiMarkupWithQuadAsteriskInsideBold() {
		// Quad Asterisk inside a bold block creates a single non-bold asterisk first, and a single bold second
		this.context.checking(new Expectations() {
			{
				one(visitor).startParagraph();
				will(returnValue(paragraph));
				one(visitor).indentParagraph(paragraph);
				one(visitor).write(paragraph, "This is a ", null);
				one(visitor).write(paragraph, "single line", of(BOLD));
				one(visitor).write(paragraph, "*", null);
				one(visitor).write(paragraph, "* block of", of(BOLD));
				one(visitor).write(paragraph, " text", null);
				one(visitor).endParagraph(paragraph);
			}
		});
		this.parser.parseForParagraph("This is a *single line**** block of* text");
	}
}
