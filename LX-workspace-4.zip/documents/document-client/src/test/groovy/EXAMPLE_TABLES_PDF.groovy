import com.itextpdf.text.Element
import com.itextpdf.text.Rectangle
import com.leadx.documents.client.CellOptionsBuilder
import com.leadx.documents.client.ParagraphOptionsBuilder
import com.leadx.documents.client.PdfBuilder

def builder = PdfBuilder.newInstance()
def paraOptions = new ParagraphOptionsBuilder().size(12)
paraOptions.alignment(Element.ALIGN_RIGHT);

builder {
	header(telephone: '07730684363')
	p "Dear Mr Bobbins,"
	spacer()

	CellOptionsBuilder cellOptions = new CellOptionsBuilder()
	cellOptions.setBorder(Rectangle.NO_BORDER)

	table(2) {
		row {
			cell cellOptions, "_By Cheque_:", "Please make cheques payable to _The Claims Guys Ltd_ and send it to us in the envelope provided. Please write your reclaim reference and request for payment number above on the back of the cheque."
			cell paraOptions, "_By Internet or Telephone Banking_:", "Bank: ROYAL BANK OF SCOTLAND", "Sort Code", "Acc Number"
		}
	}

	spacer()
	innerMargins(300,30)
	table(2) {
		row {
			cell cellOptions, "Organisation/Policy:", "Amount Recovered:", "Our Fee of 30\u0025 of this:", "VAT:", "Our total Charges:", "Total Now Due:"
			cell paraOptions, cellOptions, "0005", "\u00A3"+"276.91", "\u00A3"+"83.07", "\u00A3"+"16.62", "\u00A3"+"99.69", "\u00A3"+"99.69"
		}
	}
	innerMargins(0,0)

	table(2) {
		row {
			cell "hello", "world"
			cell paraOptions, "test", "test", "test", "test"
		}
	}
}
builder.save(outputStream)