package com.leadx.documents.client;

import static org.junit.Assert.*

import org.joda.time.LocalDate
import org.joda.time.LocalDateTime
import org.junit.Test

/**
 * @author gareth.evans
 */
class SpreadsheetBuilderUnitTest {
	
	@Test
	public void canGenerateSpreadsheet() {
		def file = new File('target/generated_spreadsheet.xls')
		file.delete()
		assert !file.exists()
		
		def builder = new SpreadsheetBuilder() 
		builder {
			(1..3).each { sheetNumber -> 
				sheet("Sheet ${sheetNumber}") {
					row {
						cell("String Column")
						cell("Number Column")
						cell("BigDecimal Column")
						cell("Boolean Column")
						cell("LocalDate Column")
						cell("LocalDateTime Column")
					}
					(1..20).each { rowNumber -> 
						row {
							cell("String Value ${rowNumber}")
							cell(rowNumber)
							cell(rowNumber*1.12)
							cell(rowNumber%2?true:false)
							cell(new LocalDate().plusDays(rowNumber))
							cell(new LocalDateTime().plusMinutes(rowNumber))
						}
					}
				}
			}
		}
		
		builder.writeTo(new FileOutputStream(file))
		assert file.exists()
	}
}
