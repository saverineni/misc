import org.joda.time.*

import com.leadx.documents.client.DocxBuilder

def builder = DocxBuilder.newInstance()
def dir = 'src/test/templates'
builder(template: "${dir}/template.docx") {
	h1 "Header 1"
	p "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec viverra arcu quis lectus vehicula placerat rutrum ligula mollis. In hac habitasse platea dictumst. Nunc non eros augue. Nulla elementum pulvinar mauris ac tempor. Curabitur lacinia cursus magna, id pellentesque enim gravida et. Proin pulvinar magna nec diam tristique sed gravida nibh semper. Praesent eros leo, pellentesque eleifend placerat vel, congue eget est. Nunc feugiat, lectus et sodales pretium, sapien neque consectetur quam, sed fermentum justo odio eget sem. Phasellus egestas pellentesque risus ac aliquet. Curabitur suscipit leo sed enim mollis ornare. Donec sollicitudin ipsum ante. Praesent a odio sed quam faucibus tempus at eget ante. Integer ac nibh metus, vitae pellentesque purus. Nullam sollicitudin turpis quis nisi suscipit varius."
	h2 "Header 2"
	p "Maecenas enim lacus, dignissim nec interdum vel, sodales sit amet risus. Quisque nec tortor odio, vel molestie felis. Etiam ut odio diam. Pellentesque vehicula eros diam. Quisque sed risus augue, a viverra quam. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec euismod blandit scelerisque. Nulla sodales mattis dui consequat tristique. Suspendisse ac ipsum urna, quis dapibus sem. Integer in lacus ut nunc mattis gravida nec ut tellus. Cras facilisis commodo commodo. Integer hendrerit ultricies convallis. Aliquam feugiat urna vel elit vulputate vel vulputate velit ullamcorper. Sed convallis libero sit amet justo sagittis tincidunt. Maecenas leo augue, ultrices et blandit sit amet, malesuada consectetur leo. Sed tortor risus, gravida non elementum sit amet, blandit in quam. Mauris vel orci nisl. Nunc auctor aliquam ligula. Morbi quis semper ligula. "
	h3 "Header 3"
	p "Vestibulum elementum, arcu sit amet fringilla commodo, magna ante tincidunt purus, ut interdum erat sapien a magna. Aenean suscipit consectetur est et malesuada. Pellentesque neque turpis, pharetra ut interdum ut, pretium sit amet ante. Nam feugiat purus eget urna semper fringilla. Sed sed lorem nec mi molestie rhoncus. Donec auctor libero enim. Suspendisse ultricies elit eget nulla viverra nec lobortis neque egestas. Aliquam vel diam lectus. Integer semper imperdiet faucibus. Sed elementum metus sit amet libero sagittis non mattis nulla viverra. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla facilisi. Vivamus tristique ultrices magna, eget rhoncus nunc pharetra eu. In aliquet rutrum ligula eget aliquet. Donec ac lorem dapibus nunc facilisis porta. "
	h4 "Header 4"
	p "Praesent pretium lacinia suscipit. Nullam ligula elit, commodo quis malesuada ut, sollicitudin malesuada purus. Etiam sollicitudin tortor et nibh vehicula ac sollicitudin enim elementum. Sed eros risus, pretium id tristique mollis, adipiscing ornare augue. Sed rhoncus ullamcorper magna eget fermentum. Nunc quis placerat odio. Nulla velit sem, auctor non tincidunt in, pellentesque at purus. Pellentesque eu viverra tellus. Integer pretium augue cursus nunc facilisis et elementum velit gravida. Aenean et risus sed nulla viverra mollis. Donec elementum vulputate neque, nec dignissim dui faucibus at. Donec eleifend imperdiet pharetra. Donec aliquam dui hendrerit libero varius quis congue justo convallis. "
	h5 "Header 5"
	p "Etiam non leo non leo bibendum ullamcorper quis sit amet purus. Donec eget cursus erat. Praesent luctus risus eget massa suscipit iaculis. Duis facilisis libero a arcu semper lacinia. Quisque a leo felis. Suspendisse potenti. Nam et nibh et nibh commodo mattis in nec velit. Morbi pulvinar scelerisque tellus sit amet viverra. Etiam accumsan, ante non interdum blandit, quam dolor vulputate leo, eu auctor ipsum lectus pulvinar nisl. Donec eleifend, libero at posuere interdum, lectus nisl molestie erat, eu interdum lectus mi eget erat. Maecenas rutrum vehicula est vel pellentesque. Quisque orci ante, fermentum vel ornare imperdiet, ultrices a magna. Etiam vel consequat tortor. "
	h6 "Header 6"
	p "n viverra congue purus eget tristique. Vivamus pharetra lorem tellus. Sed venenatis fermentum molestie. Sed diam purus, posuere quis dapibus quis, congue sit amet nisi. In non mauris urna. Ut velit tellus, luctus non dignissim tincidunt, aliquet sed felis. Sed a enim sem, a aliquet risus. Quisque tempus, mi a posuere elementum, nibh neque imperdiet felis, sed viverra nulla sem ut diam. Integer posuere consequat erat, gravida suscipit massa convallis pellentesque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. "
	
	h1 "Bullet Points Test"
	ul {
		li "Item 1"
		li "Item 2"
		ul {
			li "Item 2.1"
			li "Item 2.2"
		}
		li "Item 3"
		li "Item 4"
		li "Item 5"
		ul {
			li "Item 5.1"
			li "Item 5.2"
			ul {
				li "Item 5.2.1"
				li "Item 5.2.2"
				ul {
					li "Item 5.2.2.1"
					li "Item 5.2.2.2"
				}
				li "Item 5.2.3"
			}
			li "Item 5.3"
			li "Item 5.4"
			li "Item 5.5"
		}
	}
	
	h1 "Numbering Test"
	ol {
		li "Item 1"
		li "Item 2"
		ol {
			li "Item 2.1"
			li "Item 2.2"
		}
		li "Item 3"
		li "Item 4"
		li "Item 5"
		ol {
			li "Item 5.1"
			li "Item 5.2"
			ol {
				li "Item 5.2.1"
				li "Item 5.2.2"
				ol {
					li "Item 5.2.2.1"
					li "Item 5.2.2.2"
				}
				li "Item 5.2.3"
			}
			li "Item 5.3"
			li "Item 5.4"
			li "Item 5.5"
		}
	}
}

builder.save(outputStream)
