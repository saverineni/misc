import org.joda.time.*

import com.leadx.documents.client.*

def formContext = [:]
def timestamp = '[0-9_-]*'

File.metaClass.locate { name ->
	def fileSet = FileSet.build([dir:delegate, includeRegex: ".*${name}"])
	def files = fileSet.files()
	if(!files[0]) {
		throw new FileNotFoundException("Unable to locate file matching '${name}' in dir ${delegate}");
	}
	files[0]
}

def builder = PdfBuilder.newInstance()
builder {
	header(telephone: '07730684363', email: 'gareth.evans@leadx.com', image: "${templateDirectory}/header.png".toString())
	p "HSBC"
	p "SERVICE QUALITY TEAM"
	p "MILLSHAW PARK LANE"
	p "LEEDS"
	p "WEST YORKSHIRE"
	p "LS11 0PP"
	spacer()
	
	p "26 October 2010"
	spacer()
	h6 "Re: Mr Gareth Evans"
	h6 "Credit Card Number: 4000000000000002"
	h6 "Client D.O.B: 23 January 1980"
	h6 "Clients Address: 2 Stagshead Courtyard, Glynne Way, Hawarden, Deeside, CH5 3NL"
	h6 "Clients Previous Address: Old Address, A Valley, Wales, WA14 4DZ"
	h6 "Our reference number: 00000001_00000002"
	spacer()	
	
	p "Dear Sir / Madam,"
	spacer()
	
	p "We are acting on behalf of the above client(s) in relation to the credit card charges applied to the account detailed above."  
	spacer()
	
	p "As you are aware the Unfair Terms in Consumer Contracts Regulations 1999 (UTCCRs) makes clear that all charges levied by credit card providers must be proportionate to the actual limited administrative costs incurred." 
	spacer()
	
	p "We would refer you to the following principle from the Office of Fair Trading report of April 2006:"
	spacer()
	
	p "An unfair standard term is not binding on the consumer. A term is considered unfair under the UTCCR if contrary to the requirement of good faith, it causes a significant imbalance in the parties' rights and obligations arising under the contract, to the detriment of the consumer."
	newPage()
	
	p "Default charges are subject to the general test of fairness set out in the UTCCRs and in applying the test the OFT takes the view that a court would be likely to regard a default charge unfair where it enables the issuer to recover more than the damages which would be awarded at common law and, therefore, default charges should not exceed a reasonable pre-estimate of the administrative costs that the consumer ought to have realised would be likely to be incurred by the card issuer in dealing with defaults."
	spacer()
	
	p "Notwithstanding the reduction in your charges following the publication of the April 2006 OFT report we are instructed to make a claim for all default charges applied to our client's account both prior to and after this date. As has been stated in the Standard Parliamentary Note of 23rd December 2009 'Where credit card default charges are set at more than GBP 12, the OFT will presume that they are unfair, and is likely to challenge the charge unless there are limited, exceptional business factors in play. A default charge is not fair simply because it is GBP 12 or below.'"
	spacer()
	
	p "The Office of Fair Trading also stated in its April 2006 report into credit card charges that it considers charges are at a higher level than is legally fair."
	spacer()
	
	p "It is not necessary for the claim to be particularised as we are requesting on behalf of our client a full refund of all charges, and any associated interest paid. In accordance with statutory guidelines, 8% statutory interest should be added to the sums due."
	spacer()
	
	p "As you can see from our authority, our clients have authorised us to receive the claim on their behalf, and so we would be grateful if you would forward your refund to the above address making all cheques payable to 'The Claims Guys Limited'. We have arranged to distribute funds to our client thereafter."
	spacer()
	
	p "We look forward to your full and prompt response to our letter and for the matter to be concluded within eight weeks in accordance with the Financial Services Authority guidelines."
	spacer()
	
	p "Yours faithfully,"
	spacer()
	spacer()
	spacer()
	p "Gareth Evans"
	spacer()
	p "The Claims Guys Limited"
	page(template: new File(templateDirectory,"q_tcg_ppi_page1.pdf"), data: formContext, duplex:false)
	page(template: new File(templateDirectory,"q_tcg_ppi_page1.pdf"), data: formContext, duplex:false)
	page(template: new File(templateDirectory,"q_tcg_ppi_page1.pdf"), data: formContext, duplex:false)
	footer(includePageNumbering: true)	
}
builder.save(outputStream)