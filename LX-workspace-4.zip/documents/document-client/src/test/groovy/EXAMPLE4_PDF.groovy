import com.leadx.documents.client.*

def builder = PdfBuilder.newInstance()
builder.bleed()
builder {
	
	background(new File("src/test/templates/example.pdf"))
	
	header(telephone: '07730684363', email: 'gareth.evans@leadx.com', image: "${templateDirectory}/header.png".toString())
	p "HSBC"
	p "SERVICE QUALITY TEAM"
	p "MILLSHAW PARK LANE"
	p "LEEDS"
	p "WEST YORKSHIRE"
	p "LS11 0PP"
	spacer()
	
	p "26 October 2010"
	spacer()
	body """
Credit Card Number: {{4000 0000 0000 0002}}
Client D.O.B: 23 January 1980
Clients Address: 2 Stagshead Courtyard, Glynne Way, Hawarden, CH5 3NL
Clients Previous Address: 18 Bridge Road, Mossley Hill, Liverpool, L18 5EG
Joint Applicant: Miss Some Random Bird
Loan amount: *�2,000*

h6. Our Reference Number: 00000001_00000002

Dear Sir / Madam,
	
We are instructed by our Client in relation to a complaint regarding the sale of a Payment Protection Insurance (PPI) Policy.
Please find enclosed:
# A signed PPI Consumer Questionnaire which our Client has completed following a rigorous fact find establishing the true substance of the claim
# Original Letter of Authority providing us with full authority to act on behalf of our Client as stipulated in the FSA handbook. All correspondence relating to this claim should be released to our office in accordance with the attached authority.
\\\\
We are requesting on behalf of our Client a full refund of all premiums, and any associated interest paid. In accordance with statutory guidelines, eight percent statutory interest should be added to the sums due.
\\\\
Furthermore, in respect of the default and arrears related charges applied to our Client's account, we consider these contractually unfair and would refer you to the decision of the House of Lords in Director General of Fair Trading v First National Bank:
\\\\
_"In assessing the fairness of the charges and in particular whether they amount to a disproportionately high sum...the amount of money stated as being payable on breach must be compared with the damages which would be awarded at common law in the event that a consumer was individually sued for breach of contract."_
\\\\
The OFT stated in their 2006 report: _'We consider that in a consumer contract, where the parties are not of equal bargaining power, any estimate that included costs which could not legitimately be claimed as damages from an individual consumer in a case brought at common law, and which made a material difference to the overall charge, is likely to constitute a penalty in law.'_
\\\\
We agree with the OFT's statement and are instructed to pursue a full reimbursement of all penalty charges levied on our Client's account.
\\\\
In accordance with the original Letter of Authority attached we would be grateful if you could forward your refund to our above address making all cheques payable to '*The Claims Guys Limited*'. We have arranged to distribute funds to our Client thereafter.
\\\\
We look forward to your full and prompt response to our letter and the attached questionnaire and for the matter to be concluded within eight weeks in accordance with the Financial Services Authority guidelines.
\\\\
Yours faithfully,
\\\\
Gareth Evans
\\\\
The Claims Guys Limited"""
	footer(includePaymentForm: true, claimantId: "91827364")
}
builder.save(outputStream)
